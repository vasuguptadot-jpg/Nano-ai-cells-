# P0-08 — VOLUME K (§245–§252)
## The Closure Gate, the Ten Integration Traces, Cross-Trace Interference, Compositional Safety, the Compositionality Verdict, the P0 Scorecard, and the Status Taxonomy

---

# §245 — FINAL ARCHITECTURE CLOSURE GATE

> ### **SO-R245.1 — THE TWENTY CONDITIONS, EACH WITH A VERDICT AND A POINTER.** **[TEST]**
> | # | Condition | **Verdict** | Evidence |
> |---|---|---|---|
> | 1 | **no missing load-bearing object** | ✅ | 28 objects, §210's inventory, **3 candidate objects ruled NOT to exist** (`SO-C3.3`) |
> | 2 | **no ambiguous authority root** | ⚠️ **PASS WITH RESIDUAL** | §212's 25 operations; **2 marked UNRESOLVED rather than assigned** (`SO-R212.2`: auditing the Integrity Auditor; resolving `SUPPRESSION-SUSPECTED` where the suspect is the sole observer) |
> | 3 | **no unowned mutable state** | ✅ | §214: 10 PASS · 4 JUSTIFIED multi/split-writer · **0 UNOWNED · 0 AMBIGUOUS**; `SOMon-4` |
> | 4 | **no unresolved writer conflict** | ✅ | §215: 5 states × 5 answers; **"eventual consistency" used nowhere**; `SO-R142.3`'s anchor-consistency model |
> | 5 | **no undocumented cross-contract dependency** | ✅ | **22 dependencies `XD-01…XD-22`**, 6 edge types, §208's graph |
> | 6 | **no duplicate governance mechanism** | ✅ | §209 search 1; `SO-R161.6`'s five-power enumeration |
> | 7 | **no duplicate epistemic mechanism** | ✅ | §209 search 3 — **the Integrity Auditor is the one candidate and is justified by its authority boundary** (may disable a detector; may not confirm a capability) |
> | 8 | **no duplicate provenance mechanism** | ✅ | §209 search 5; `SO-R216.1` |
> | 9 | **no duplicate communication mechanism** | ✅ | §209 search 6; `SO-C22.3` — a broadcast IS a `P0-03` message |
> | 10 | **all mandatory state machines defined** | ✅ | **21 machines**, all mandatory for C1, with named transition writers and absorbing states |
> | 11 | **all mandatory invariants defined** | ✅ | **34 invariants `SO-INV-01…34`** with enforcement kinds; **1 is `[DECLARATIVE]` and is labelled as such** |
> | 12 | **all mandatory attacks registered** | ✅ | **92 attacks A172…A263**, contiguous, with §124's eight columns and 7 ⚠ flags |
> | 13 | **all unresolved parameters registered** | ✅ | §245.2's parameter register below |
> | 14 | **all known open problems registered** | ✅ | **41 entries `OR-S1…OR-S41`**, classified at §253 into O-R1…O-R6 |
> | 15 | **all residual circularities explicitly classified** | ✅ | **`BC-S1` BROKEN · `BC-S2` UNCLOSABLE · `HC-S1` BOUNDED-BY-DESIGN (informational channel) / BROKEN (resource channel) · `HC-S2` BOUNDED (ratchets to escalation) · `HC-S4` BOUNDED (cross-contract, §248)** |
> | 16 | **all scale limits explicitly stated** | ✅ | §245.3 below |
> | 17 | **all hardware assumptions explicit** | ✅ | `AS-08`, `AS-09` + §245.4 |
> | 18 | **all non-claims explicit** | ✅ | `SO-R230.1`'s **9 NOT CLAIMED rows** + §245.5 |
> | 19 | **all canonical IDs unique** | ✅ | **machine-verified: `SO-R`/`SO-C` disjoint by prefix; `SO-INV`, `OBJ`, `SM`, `A`, `OR-S`, `AS`, `X-S`, `BC-S`, `HC-S`, `XD`, `SOMon`, `D-S` all sequential with declared gaps** |
> | 20 | **all references resolve / all counts mechanically reconciled** | ✅ | **the README's machine check; 0 phantom rule citations after the sweep** |
> **⟹ 19 ✅ · 1 ⚠️ PASS WITH RESIDUAL · 0 ❌.**
> **`SO-R245.6 — THE VERDICT PER §268'S DECISION TREE: no load-bearing mechanism is missing (condition 1); mechanisms
> are specified but incompletely parameterized (condition 13, §245.2); all architecture-level interfaces are specified
> (conditions 5, 10). ⟹ **P0-08 COMPLETE WITH EXPLICIT RESIDUALS AND EXPLICIT OPEN RESEARCH.****

## 245.2 The parameter register (condition 13)

> **[NORMATIVE] NO INVENTED VALUES. Classes as in `P0-07 §79`: `[G]` governance · `[E]` evaluator · `[T]` `P0-01` ·
> `[D]` development · `[L]` learning · `[V]` verification/memory · `[H]` this contract's semantics · `[U]` unresolved.**

| ID | Parameter | Class | Value known? |
|---|---|---|---|
| **SP-01** | the 13 homeostatic variables' identities | `[H]` | ✅ inherited from `P0-07` |
| **SP-02** | `S1…S4` severity classes | `[H]` | ✅ inherited from the Cell contract |
| **SP-03** | the severity mapping (manifestation class → severity) | `[G]` | ❌ |
| **SP-04** | detector threshold / criticality θ / false-positive budget | `[G]` | ❌ (`Cell §18.5`) |
| **SP-05** | quarantine budget cap | `[G]` | ❌ (`Cell §17`) |
| **SP-06** | maximum dwell per rung, per quarantine, per freeze, per abstention | `[G]` | ❌ |
| **SP-07** | freshness classes (`FRESH/AGING/STALE/INVALID`) boundaries | `[G]` + `[U]` | ❌ **`OR-S8`: no numeric threshold invented** |
| **SP-08** | the monitoring share ceiling | `[G]` | ❌ **`OR-S19`** |
| **SP-09** | B13 size and per-monitor floors | `[G]` | ❌ |
| **SP-10** | the freeze-rate classes | `[G]`/`[U]` | ❌ **`OR-S16`** |
| **SP-11** | the repair recurrence/oscillation count classes | `[G]`/`[U]` | ❌ **no numeric convergence threshold** |
| **SP-12** | the post-closure observation window | `[G]` | ❌ **`OR-S13`** |
| **SP-13** | the repair-incompatibility relation | `[G]` | ❌ **`OR-S3`; undeclared ⟹ incompatible by default** |
| **SP-14** | the intervention-class → accounting-class mapping | `[G]` | ❌ **`OR-S34`; undeclared ⟹ invalid** |
| **SP-15** | the materiality relation (for `SO-R145.1(c)`) | `[G]` | ❌ **`OR-S9`** |
| **SP-16** | the interaction-class set | `[G]` | ❌ **`OR-S14`; undeclared ⟹ INTERACTING** |
| **SP-17** | the `S3` compression boundary | `[G]` | ❌ inherited from SP-02 |
| **SP-18** | the `expected_nonzero` conditions and their base rates | `[G]` + `[E]` | ❌ **`AS-14`, `P0-03 OR-C10`: `[U]`** |
| **SP-19** | calibration parameters (error thresholds, coefficients, increments) | `[G]`/`[E]` | ❌ **`OR-S5` — all `[U]`** |
| **SP-20** | `causal_depth` width | `[H]` | ✅ **`u8`, inherited verbatim from `P0-03` field 8** |
| **SP-21** | `TRUST_MAX` | `[V]` | ✅ **0.95** ⟦`Cell I-27`⟧ |
| **SP-22** | `UDB_MAX[S]` | `[L]` | ❌ `P0-05`'s |
| **SP-23** | the difficulty classes (for abstention-rate reporting) | `[T]` | ❌ **`XD-02`, `AS-11`** |
| **SP-24** | `G4`'s perturbation classes | `[T]` | ❌ **`XD-01`, `AS-10`, BLOCKED** |
| **SP-25** | the independence dimension set | `[H]` | ✅ **`IND-1…IND-9` inherited + `IND-10` proposed (amendment 16)** |
| **SP-26** | the scale ceiling | `[D]` | ✅ **10⁷ respected; NO 10¹² GUARANTEE** |
> **⟹ `SO-R245.7 — 26 parameters: 5 determinate (SP-01, SP-02, SP-20, SP-21, SP-25, SP-26 — six, of which two are
> inherited identities and one is an inherited width), 21 owned elsewhere or `[U]`. NO VALUE IS INVENTED. The ratio
> matches `P0-06` (50 params, 13 `[T]`) and `P0-07` (62 params, 9 determinate) — which is the honest shape of an
> architecture-only contract, and §223's three-stage conformance gate exists because C0–C3 can be met with every one of
> the 21 unresolved.**

## 245.3 Scale limits (condition 16)

> **[NORMATIVE]** `SO-R245.8` — **the observation layer's costs, per `P0-07`'s regime table:**
> | Mechanism | Per-window cost | Binding constraint |
> |---|---|---|
> | occurrence recording | `O(detections)` | append-only; bounded by the detector set, not by `N` |
> | coverage records | **`O(scopes × windows)`** | **NOT `O(N)` — coverage is per SCOPE, and scopes are `[RO-13]`-declared, so their count is a governance choice** |
> | `effective_sources` collapse | **`O(|S|² × dims)` per claim** | **`|S|` = the observer set for a claim, which is small by construction (`Cell §18.5(iv)` asks for 2). A global collapse over all observers would be `O(N²)` and is NOT performed** |
> | self-model aggregation | `O(depth × breadth)` per scope | depth ≤ 4 (§139), breadth = scope membership |
> | diagnosis status | `O(incidents)` | incidents are bounded by the containment budget (`Cell §18.5(i)`) |
> | **the per-reader coverage that §203 would need** | **`O(readers × scopes × windows)`** | **INFEASIBLE at R3 ⟹ `OR-S33`, routed to `P0-04` rather than implemented** |
> **⟹ NO 10¹² GUARANTEE. `P0-07`'s 10⁷ stop is respected and not re-validated. At R4+ every P0-08 aggregate is
> per-envelope, exactly as `P0-07 §80`'s R4 row requires.**

## 245.4 Hardware assumptions (condition 17) and non-claims (condition 18)

> **[NORMATIVE]** `SO-R245.9` — hardware: **AS-08** (energy counters, else the `DERIVED` flag) · **AS-09** (per-deployment-class setpoints, `P0-07` amendment 13) · **AS-02** (a per-envelope monotone time source; **no global clock, no co-location, no shared memory, no hardware RNG required**) · `IND-5` (hardware-class diversity for second detectors, **⚠️ approximate: `P0-01 F-IMP-2`/`P0-02 G-P02-5` — hardware class is deployment-specific and often unknown to the cell**).
> **[NON-CLAIM]** `SO-R245.10` — this contract does **NOT** claim: perfect detection · complete reporting · causal
> understanding · guaranteed recovery · restoration of a pre-fault state · self-awareness · intelligence · autonomy ·
> consciousness · AGI · optimal monitoring · an internally provable guarantee chain · closure of `RH-2` · closure of
> `A22` · detection of governance capture · detection of assumption-sharing (`IND-6`) · resolution of semantic
> self-reference · that internal consistency implies correctness · that a bounded cycle is a broken one · a 10¹² scale
> guarantee · that `Q_ev` is knowable.

---

# §246 — THE TEN INTEGRATION TRACES

> **§246's discipline: *do not mark a trace successful merely because a conceptual diagram exists.* Each trace below
> names the owning contract per step, the objects touched, and the three transition types §247 requires. §247 then
> reports each trace's failure path.**

## Trace A — Normal cognition

| Step | Owner | Object | **Authority transition** | **Epistemic transition** | **Provenance transition** |
|---|---|---|---|---|---|
| environment → perception | `P0-01` | sensor input | — | `L0` origin | `root_commit` anchored |
| perception → routing | `P0-03` | S1/S2 message | — | S1 → S2 (warranted) | `causal_depth + 1` |
| routing → memory | `P0-04` | a record | — | S2 → the `P0-04` ladder | root inherited, **warrant non-increasing** |
| memory → hypothesis | `P0-05` | `SG-1`/`SG-6` | — | `HYPOTHESIS`, provisional | `corr_class` attached |
| hypothesis → verification | **`P0-01` EVA** | a verdict | **EVA measures** | provisional → `IMPROVED/NEUTRAL/REGRESSED/UNKNOWN` | anchored verdict |
| verification → attention | **P0-08 / `P0-07`** | `OBJ-23` | **K allocates** | — | ledger record |
| attention → action | `P0-05`/`P0-06` | Λ1/Λ2 change | the component acts | — | UDB accounted |
| action → outcome | `P0-01` | outputs | — | — | — |
| outcome → learning | `P0-05` | `LearnedChange` | — | provisional | `P0-05` change graph, acyclic |
| learning → consolidation | `P0-04`/`P0-05` | a consolidated record | **nomination, never promotion** | provisional → consolidated only via the gate | anchor re-based **only by the gate** |
> **P0-08's role in Trace A is ONE STEP: attention allocation, which is K's and is a resource act.** Everything
> epistemic is `P0-04`/`P0-05`/EVA's. **⟹ This is the correct shape: in normal operation P0-08 is nearly invisible,
> and a contract that were visible in Trace A would be a second cognition layer.**

## Trace B — Novelty

| Step | Owner | Key rule |
|---|---|---|
| novel signal | `P0-05` | **`SG-5` novelty ⟹ `plasticity_mult ↓` and `SLOW_MODE` — NEVER `Δθ`** |
| novelty detection | **P0-08** | **`SO-C12.4(8)`: NOVELTY IS NOT A FAULT.** No incident is opened; only a deviation from a declared specification opens one |
| uncertainty | **P0-08** | `OBJ-22` abstention with reason `OOD-STATE`, **a mandatory recovery condition (`SO-INV-07`)** |
| exploration | `P0-05`/`P0-07` | B7's **learn** floor — not the variation floor (`P0-07 HOM-R47.2`) |
| verification | EVA | held-out probe |
| learning → integration | `P0-05`/`P0-04` | UDB-accounted; consolidation by nomination |
> **⟹ THE TRACE'S ONE P0-08 DECISION IS THE MOST IMPORTANT RULE IN §12: refusing to treat novelty as a fault.** An
> implementation that opened an incident on `SG-5` would quarantine every novel stimulus, and §236's over-caution
> ratchet would engage on the architecture's only source of new behaviour.

## Trace C — Cell fault

`cell → anomaly → detection → localization → quarantine → repair → verification → recovery`
| Step | Object | Writer | Rule |
|---|---|---|---|
| anomaly | `OBJ-05` manifestation | the observer | `SO-C11.1` — origin is a CLAIM |
| detection | `OBJ-04` occurrence | the observer (**a detector, `D-S02`**) | `SM-03` |
| confirmation | — | **K** | `Cell §18.5(iv)`: **two detectors, different types, `effective_sources ≥ 2` for the claim (`SO-C12.3`)** |
| localization | `OBJ-06.localization` | **K** | **a WHERE. It may NOT promote `status` (`SO-R149.3`)** |
| quarantine | `OBJ-11` | **EIK** | `SM-06` ⟦inherited⟧; **`SO-INV-08`: writes a coverage gap** |
| repair | `OBJ-12/13` | proposer / **K** | `SM-07` serialization, **no confidence arbitration**; `SM-08`; **UDB accounted (`SO-R152.2`)** |
| verification | `OBJ-13.verification` | **a non-repairer** | `SO-R164.2` |
| recovery | `OBJ-15` | **`[RO-13]` declared it in advance** | `SM-10`; **recovery ≠ restoration (`SO-C16.3`)** |
> **Authority transitions: observer → K → EIK → `[RO-13]` → non-repairer. The subject appears at exactly two steps
> (manifestation, proposal) and holds authority at none.**
> **⟹ FAILURE PATH: §248's interference finding IF-1 — a quarantine during learning stalls the anchor.**

## Trace D — Memory corruption

`memory anomaly → provenance check → quarantine → restoration/rollback → verification → epistemic re-evaluation`
| Step | Owner | Rule |
|---|---|---|
| anomaly | `P0-04` + P0-08 | an `OBJ-04` occurrence of origin `ENDOGENOUS` or `INSTRUMENT` |
| provenance check | `P0-04` | the Merkle root; **removal is detectable at epoch granularity; `SP-5`/`OR-M9`: differential serving WITHIN an epoch is bounded, not preventable** |
| quarantine | **EIK** | of the READER or the STORE, not of the records — records are append-only |
| restoration / rollback | **K** | `SM-09`: epoch + Merkle root; **never position-identified**; **the rollback is itself an event (principle 23)** |
| verification | **a non-rollbacker** | `SO-R164.2` |
| epistemic re-evaluation | **`P0-04`** | **P0-08 MAY NOT re-evaluate. It records the incident; `P0-04` re-derives statuses from its own rules** |
> **⟹ THE TRACE'S BOUNDARY IS THE LAST STEP, AND IT IS WHERE §209'S SEARCH 2 IS TESTED IN OPERATION: a P0-08 that
> re-evaluated epistemic status would be a second epistemic mechanism. It does not, and may not (`SO-C9.1(1)`).**

## Trace E — Learning-induced instability

`learning → provisional change → displacement accounting → anomaly → evaluation → retain / rollback / repair`
| Step | Owner | Rule |
|---|---|---|
| provisional change | `P0-05` | `provisional = TRUE` |
| displacement accounting | `P0-05` | **`R0.1`: `‖θ_S − θ_anchor(S)‖ ≤ UDB_MAX[S]`; on breach, learning STALLS** |
| anomaly | P0-08 | an occurrence; **`P0-05 R42.5`: every observation carries `self_model_version`, so a regression correlated with a version is an INSTRUMENT DEFECT FINDING** |
| evaluation | EVA | the verification gate — **the only thing that converts provisional into permanent** |
| retain / rollback / repair | `P0-05` / **K** | `IMPROVED/NEUTRAL ⟹ re-anchor · REGRESSED ⟹ auto-rollback · UNKNOWN ⟹ stays PROVISIONAL, envelope shrinks` |
> **⟹ §205'S BOUNDARY IS TESTED HERE: a REPAIR on this trace is a learning-class change and uses `P0-05`'s gate
> (`SO-R205.3`), and it may NOT re-base an anchor (`SO-INV-28`). There is no second pathway, because there is no second
> gate.**

## Trace F — Developmental differentiation

`developmental signal → differentiation → specialization → self-observation → functional evaluation`
| Step | Owner | Rule | **Does specialization create authority?** |
|---|---|---|---|
| signal | `P0-06` | organizer emission, **spec `[RO-13]`-approved** | — |
| differentiation | `P0-06` | Σ1–Σ4 writer separation | ❌ |
| specialization | `P0-06` | a region/circuit/role assignment | ❌ **`P0-06 R8.11`: an organizational fact** |
| self-observation | **P0-08** | `OBJ-18` at `granularity = REGION`; **`P0-06 R8.13`: not updated by the process it models** | ❌ **`SO-R206.1`: awareness ≠ authority** |
| functional evaluation | **EVA** | a verdict | ❌ **`P0-07 HOM-INV-29`** |
> **⟹ §246's requirement is met: VERIFIED, SPECIALIZATION DOES NOT CREATE AUTHORITY — at all five steps, by four
> different contracts' rules.**
> **⚠️ FAILURE PATH: §196's route 1 — the fault/self-observation signals of step 4 feed `Cell §15.2`'s `w_s` and
> therefore steer `fate_bias` within the registered spec. That is `A22`, OPEN and widened (`OR-S30`).**

## Trace G — Evolution

`variation → sandbox → evaluation → selection → inheritance → deployment → monitoring`
| Step | Owner | **Can a self-model or immune mechanism redefine selection authority?** |
|---|---|---|
| variation | `P0-07` | ❌ — B7's variation floor; `FORBIDDEN_BLOCKS` |
| sandbox | `P0-07` | ❌ — six non-sharing requirements; **the sandbox candidate has no observer status, so it emits no `OBJ-01`** |
| evaluation | EVA | ❌ — **`SO-R189.2`: external evaluation remains distinct from self-assessment; `SM-16` has no self-calibrated terminal** |
| selection | **`P0-07`'s three parties** | ❌ — **`SO-R186.2`: authority is not a function of performance anywhere. A detector's integrity finding may disable a DETECTOR; it may not confirm a CANDIDATE** |
| inheritance | `P0-07` | ❌ — **`SO-R188.1`: the self-model SCHEMA is this contract's and is `FORBIDDEN_BLOCKS` territory; self-model CONTENT is not heritable** |
| deployment | **OP** | ❌ — **`SO-INV-24`: a recovery plan's scope must reference an existing envelope** |
| monitoring | **P0-08** | ⚠️ **monitoring observes the deployed population; it may not rank it. `SO-R184.1`/`SO-INV-23`: no P0-08 quantity enters fitness** |
> **⟹ §246's requirement is met: VERIFIED. The one ⚠️ is a scope statement, not a route — monitoring produces
> observations, and observations are not verdicts.**
> **⚠️ FAILURE PATH: `SO-R185.5` — selection for blind spots, CONDITIONAL on amendment 17.**

## Trace H — Global fault

`regional fault → local detection → containment → degraded operation → recovery → external verification`
| Step | Rule |
|---|---|
| regional fault | `OBJ-04` at `scope = REGION`; **`SO-INV-09`: multiple simultaneous incidents are supported, no total ordering** |
| local detection | `SM-03`; **the regional self-model is NOT the detector — `SO-R138.2` prohibits a complete organism model at every cell** |
| containment | **EIK**; `SM-06`; **regional freeze requires EIK on an open `S3+` incident (`SO-R163.1`)** |
| degraded operation | `SM-11` per function; **`SO-R159.3`: degradation may not alter governance semantics** |
| recovery | `SM-10`; **declared in advance**; **the recoverer is not assumed healthy (`SO-R164.1`)** |
| external verification | **EVA / a non-recoverer**; **`SO-R201.1`: not internally provable** |
> **⚠️ FAILURE PATH: if the region contains K's local instrumentation, coverage for that region becomes
> `DETECTOR-ABSENT`, and `SO-INV-01` reads the whole region restrictively — which is correct and which also means a
> regional fault produces a regional blindness that the region cannot report. Escalation is the only exit, and it is
> `SO-R164.1`'s route 2 (`P0-03`'s absence detectors), which is outside the region.**

## Trace I — Self-model failure

`incorrect self-model → incorrect capability estimate → degraded routing → external observation → contradiction → self-model correction`
| Step | Rule |
|---|---|
| incorrect self-model | `OBJ-18` content is subject-written and **advisory** |
| incorrect capability estimate | `OBJ-19` at `CLAIMED` — **satisfies no gate (`SM-14`)** |
| degraded routing | **routing consumes `EXTERNALLY-CONFIRMED` records; a `CLAIMED` record does not route** ⟹ the degradation is bounded before it starts |
| external observation | **EVA / K** — the only writers of `OBJ-18`'s version and status |
| contradiction | **`SO-R142.1`: carried, NOT resolved.** The contradiction between the self-model and K's coverage/fault records is recorded |
| self-model correction | **K versions it. The subject does not correct itself (`SO-INV-03`)** |
> **⟹ THE TRACE'S KEY PROPERTY: THE CONTRADICTION IS THE DETECTOR.** `SO-R174.1` defence 4 — a self-model claiming
> health while K-held records show gaps or open occurrences is a contradiction, and contradictions are reportable.
> **A lie that must be consistent with three K-held records is a much harder lie.**
> **⚠️ FAILURE PATH: §233 — if EVA's probe coverage does not intersect the falsifying region, all three K-held records
> are consistent with the false self-model, because they record observation, not truth.**

## Trace J — Governance attack

`organism → attempts an unauthorized operation → P0-08 observes → P0-08 reports → EIK evaluates authorization → enforcement`
| Step | Rule | **Does P0-08 authorize?** |
|---|---|---|
| attempt | the organism proposes | — |
| **P0-08 observes** | `OBJ-01` | ❌ |
| **P0-08 reports** | `OBJ-28` canonical event, S2 | ❌ |
| **EIK evaluates authorization** | `P0-02` | **the EIK, not P0-08** |
| enforcement | `SM-06` / `SM-12` | **the EIK / OP** |
> **⟹ §246's requirement is met: VERIFIED, P0-08 NEVER BECOMES THE AUTHORIZATION AUTHORITY. Its two steps are OBSERVE
> and REPORT, and both are `D-S01`'s permitted acts.**
> **⚠️ FAILURE PATH: §240's route 6 — P0-08 controls what is REPORTED, so it controls the information on which the EIK
> evaluates. `OR-S41`. The report is auditable (`SO-INV-21`), but the audit compares reports against declared
> expectations, never against what happened (`OR-S1`).**

---

# §247 — TRACE FAILURE ANALYSIS

> ### **SO-R247.1 — THE NINE REQUIRED REPORTS PER TRACE.** **[NORMATIVE]**
> | Trace | **Successful path** | **Failed path** | Assumptions | Dependencies | **Authority transitions** | **Epistemic transitions** | **Provenance transitions** | Recovery behaviour | **Unresolved limitations** |
> |---|---|---|---|---|---|---|---|---|---|
> | **A** normal cognition | ✅ | a verification verdict of `UNKNOWN` ⟹ stays provisional, envelope shrinks | AS-01, AS-04 | `P0-01`…`P0-05` | 1 (K allocates attention) | 4 (`L0`→S2→ladder→consolidated) | 3 (`root_commit`, `causal_depth +1`, anchor) | `P0-05 R0.1`'s stall | **`RH-2`** |
> | **B** novelty | ✅ | **an implementation that treats novelty as a fault quarantines every novel stimulus** | AS-06 | `P0-05 SG-5` | 0 | 2 | 1 | abstention with a recovery condition | **`OR-S6`: permanent escalation** |
> | **C** cell fault | ✅ | **IF-1: a quarantine during learning stalls the anchor** | AS-02, AS-03 | `Cell §18.5`, `P0-05 R0.1` | **4** (observer→K→EIK→`[RO-13]`) | 3 (`ANOMALY`→`SUSPECTED`→`SUPPORTED`) | 2 | `SM-10` | **`OR-S4`, `OR-S11`** |
> | **D** memory corruption | ✅ | **differential serving within an epoch** | AS-03 | `P0-04` | 3 | **`P0-04`'s, not P0-08's** | 2 (Merkle root, epoch) | epoch restoration | **`OR-S33`, `P0-04 OR-M9`** |
> | **E** learning instability | ✅ | a repair that re-bases an anchor (**prohibited, `SO-INV-28`**) | AS-04 | `P0-05 R0.1/R9.2.4` | 2 | 3 | 2 | auto-rollback on `REGRESSED` | **`OR-S34`: the intervention-class mapping** |
> | **F** differentiation | ✅ | **`A22`: within-spec gradient steering, widened by §196's routes 1–3** | AS-06, AS-10 | `P0-06`, `Cell §15.2` | 0 (**specialization creates none**) | 1 | 1 | — | **`OR-S30` — OPEN** |
> | **G** evolution | ✅ | **`SO-R185.5`: selection for blind spots** | AS-04, AS-10 | `P0-07`, amendment 17 | 0 (**no P0-08 authority**) | 1 | 2 | `P0-07`'s rollback | **CONDITIONAL on amendment 17; `OR-S29`** |
> | **H** global fault | ✅ | **a regional fault produces a regional blindness the region cannot report** | AS-02, AS-03 | `P0-03`'s absence detectors | 3 | 2 | 2 | escalation is the only exit, and it is outside the region | **`OR-S20`** |
> | **I** self-model failure | ✅ | **§233: all three K-held records consistent with a false self-model** | AS-04, AS-05 | EVA | 1 (K versions) | **0 — P0-08 promotes nothing** | 2 | K re-derives from anchored records | **`OR-S39` — the central epistemic boundary** |
> | **J** governance attack | ✅ | **`OR-S41`: P0-08 controls what is reported, hence what the EIK evaluates** | AS-05, AS-07 | `P0-02` | **2 (observe, report — neither authorizes)** | 0 | 1 | EIK enforcement | **`G24` UNSOLVABLE** |
> **⟹ `SO-R247.2 — NO TRACE IS MARKED SUCCESSFUL ON THE STRENGTH OF ITS DIAGRAM.** Each has a named failed path, and
> **four of the ten failed paths are OPEN residuals rather than contained ones** (F/`A22`, G/amendment 17, I/§233,
> J/`OR-S41`).

---

# §248 — CROSS-TRACE INTERFERENCE

> ### **SO-R248.1 — SIX OVERLAPPING-TRACE PAIRS, EACH TESTED FOR AN EMERGENT CONFLICT.** **[NORMATIVE]**
> | ID | Pair | **Emergent conflict** | Ruling |
> |---|---|---|---|
> | **IF-1** | **learning + immune detection** | **a `SOFT`/`HARD` quarantine halts a component, which stops its verification, which means its anchor never re-establishes, which means on release its displacement is full ⟹ `P0-05 R0.1`'s IMMEDIATE STALL. Quarantine therefore causes a post-release learning freeze that nothing predicted** | **⟹ `SO-R248.2`: QUARANTINE RELEASE MUST TRIGGER AN ANCHOR RE-ESTABLISHMENT REQUEST.** The release is not complete until either a probe re-anchors or the scope is explicitly marked `STALL-ON-RELEASE`, which is a `[RO-13]`-visible condition. **Without this rule, the immune system and the learning system are individually correct and jointly paralysing** |
> | **IF-2** | **development + fault detection** | **a quarantine during a declared `critical_period` (`Cell §4`) alters differentiation permanently. Quarantine is supposed to be REVERSIBLE (`Cell R15.2`); its developmental consequence is not** | **⟹ `SO-R248.3`: A QUARANTINE WHOSE SCOPE INTERSECTS A DECLARED CRITICAL PERIOD IS NOT REVERSIBLE IN EFFECT AND MUST BE ESCALATED TO `[RO-13]` RATHER THAN APPLIED AT THE EIK'S DISCRETION.** The reversibility assumption is false in this case, and `SO-INV-11`'s discipline (state your assumptions) requires the exception to be explicit |
> | **IF-3** | **evolution + self-model** | **`P0-05 R42.5` treats a regression correlated with a `self_model_version` as an INSTRUMENT DEFECT FINDING. But a version increment caused by an evolved observational capability is not a defect — so evolution produces false instrument-defect findings** | **⟹ `SO-R248.4`: A VERSION INCREMENT CAUSED BY A COMMITTED GENOME DIFF IS CLASSIFIED `EVOLVED-INSTRUMENT` AND IS EXCLUDED FROM THE DEFECT-FINDING CORRELATION. A version increment WITHOUT a diff is `DEFECT-SUSPECT`.** The two classes have different consequences: the first re-baselines the correlation, the second opens a finding |
> | **IF-4** | **repair + memory** | **`P0-04` forbids rewriting historical evidence, so a repair cannot update the records that describe the pre-repair state ⟹ the memory describes a state that no longer exists** | **⟹ NOT A CONFLICT — AND THE RESOLUTION IS `SO-R217.1`: records are EVENTS with validity windows; the current state is a separate object.** A consumer that reads an old record as current violates `SO-R217.3`. **But the interference is real for any consumer written before this rule: `SO-R248.5` requires every `P0-04` record derived from a P0-08 observation to carry the observation's validity window** |
> | **IF-5** | **attention + emergency response** | **`SO-C21.2` allocates attention preferentially to COVERAGE GAPS. A freeze creates a gap. So attention is allocated into a frozen scope — the constructive policy fights the suspension** | **⟹ `SO-R248.6`: A FROZEN SCOPE IS EXCLUDED FROM ATTENTION ALLOCATION, AND ITS GAP IS RECORDED AS `FREEZE-INDUCED`, A DISTINCT `gap_class` SUBCLASS.** Without the subclass, a freeze-induced gap is indistinguishable from a detector failure, and `SM-02` would route it to `SUPPRESSION-SUSPECTED` — accusing the freeze of suppression |
> | **IF-6** | **homeostasis + monitoring** | **B13 exhaustion ⟹ `UNMEASURED` ⟹ `P0-07`'s staleness-conservatism restricts ⟹ lower throughput ⟹ lower efficiency ⟹ tighter budgets ⟹ less B13. A cross-contract positive feedback loop between `P0-07`'s ladder and P0-08's reserve** | **⟹ `HC-S4`, BOUNDED by three inherited mechanisms: B13's non-fungibility and last-cut property · the monitoring share ceiling (`SO-R129.4`) · `P0-07 HOM-R6.5`'s exclusion of throttled components from `G1`/`G6`/`G9`. NOT BROKEN — the loop is real and its bound is that it terminates in restriction, which is safe and expensive** |
> **⟹ `SO-R248.7 — SIX PAIRS TESTED: FIVE PRODUCED A CONFLICT REQUIRING A NEW RULE (`SO-R248.2`, `.3`, `.4`, `.6`) OR A
> NEW FIELD (`SO-R248.5`, `FREEZE-INDUCED`); ONE (IF-4) was resolved by an existing rule. IF-6 produced a new cycle
> (`HC-S4`), classified BOUNDED.**
> **`[DERIVATION]` Five of six is a high hit rate, and it is the expected rate: **each contract was written to be
> correct alone, and correctness alone is not correctness together.** The five new rules are all small — a trigger, an
> escalation condition, a classification, an exclusion, a field — which is the signature of a genuine interference
> rather than a design error. §265's minimality recheck confirms none of them required a new subsystem.**

---

# §249 — COMPOSITIONAL SAFETY

> ### **SO-R249.1 — `A SAFE + B SAFE ≠ A+B SAFE`, TESTED EXPLICITLY ON SEVEN COMPOSITIONS.** **[NORMATIVE]**
> | Composition | A alone | B alone | **A+B** | Verdict |
> |---|---|---|---|---|
> | **two detectors of different types** | each sound | each sound | ⚠️ **one effective source if they share a relevant dimension (`IND-6` undetectable)** | **NOT SAFE — `SO-R126.3`** |
> | **quarantine + learning** | each correct | each correct | ❌ **IF-1: post-release stall** | **NOT SAFE without `SO-R248.2`** |
> | **quarantine + a critical period** | each correct | each correct | ❌ **IF-2: irreversible effect from a reversible act** | **NOT SAFE without `SO-R248.3`** |
> | **attention-to-gaps + freeze** | each correct | each correct | ❌ **IF-5: attention allocated into a suspended scope** | **NOT SAFE without `SO-R248.6`** |
> | **restrictive containment + honest coverage** | `SO-INV-08` is the safest rule in the contract | `SO-INV-01` is its central invariant | ❌ **`HC-S2`: together they form an over-caution ratchet** | **NOT SAFE — bounded, ratchets to escalation** |
> | **`SO-INV-23` (honesty not priced) + `D-S02` (every reporter is a detector)** | each correct | each correct | ⚠️ **together they would price honest reporting — resolved only by `SO-R184.3`'s refuted-vs-unconfirmed distinction** | **SAFE ONLY BY A DISTINCTION** |
> | **fail-safe default + a false assumption** | `SO-INV-02` converts absence to restriction | — | ❌ **`SO-R229.3`: a false assumption produces PRESENT, WELL-FORMED, WRONG data, which no restrictive default catches** | **NOT SAFE — and no rule can make it safe** |
> **⟹ `SO-R249.2 — SEVEN COMPOSITIONS: 5 UNSAFE OR CONDITIONALLY SAFE, 1 SAFE ONLY BY A DISTINCTION, 1 UNSAFE AND
> UNFIXABLE.** Not one composition was safe by virtue of its parts being safe.

---

# §250 — FINAL COMPOSITIONALITY VERDICT *(mandatory)*

> ### **SO-R250.1 — WHICH GUARANTEES COMPOSE, AND WHICH DO NOT.** **[NORMATIVE]**
> | Class | Guarantees | **Why** |
> |---|---|---|
> | **COMPOSE (across scopes, contracts, and scale)** | **the six firewalls (FW-1…FW-6) · `D-S01`'s no-authority property · `SO-INV-03/05/11/12/13/27/30` (machine-shape and writer prohibitions) · `SO-INV-16` (warrant non-increasing) · `SO-INV-21/31` (append-only separation of occurrence, report, event, state)** | **they are statements about PATHS and WRITERS. A prohibition on a path holds in any composition, at any scale, in any scope — which is exactly why `P0-07 §80`'s R5 regime found that only firewalls survive to 10¹²** |
> | **HOLD ONLY LOCALLY (per scope)** | **`SO-INV-01` (`UNMEASURED` per scope) · `SO-INV-08` (a coverage gap per containment) · freshness · dwell · the freeze scope · degradation per function** | **each is indexed by a scope, and scopes do not aggregate. A globally healthy system can contain an `UNMEASURED` scope, and `SO-INV-01` says nothing about the whole** |
> | **REQUIRE EXTERNAL ASSUMPTIONS** | **`SO-INV-04`'s `CAUSE-VERIFIED` (needs EVA or a non-diagnoser) · `SM-14`'s confirmation (needs EVA) · `SM-16`'s calibration (needs EVA) · `SO-R184.3`'s pricing (needs refutation capacity, i.e. B9) · every recursion terminus (§201's five)** | **AS-04, AS-05, AS-07 — and none is internally provable** |
> | **BECOME WEAKER WHEN COMPOSED** | **DETECTION: adding a correlated observer REDUCES `effective_sources`, so MORE MONITORING CAN BE WEAKER EVIDENCE THAN LESS** · **COVERAGE: composes FAVOURABLY for `Q_pop` (a union of observed subsets is observed; the blind spot shrinks to the intersection) but **UNFAVOURABLY for evidence** (the same union may be one source)** · **`SO-R153`'s regression coverage (composing repairs multiplies the untested surface)** | **⟹ `SO-R250.2 — THE COUNTERINTUITIVE RESULT, AND THE ONE AN IMPLEMENTER WILL GET WRONG: coverage and independence compose in OPPOSITE DIRECTIONS. Adding observers always improves coverage and may degrade independence. An architecture that maximizes observer count maximizes coverage and can minimize evidence** |
> | **CANNOT BE COMPOSED** | **anything requiring `IND-6` (assumption independence) · anything requiring `Q_ev` · `SO-INV-25` (indispensability — `[DECLARATIVE]`, no instrument to compose) · `G24` (governance capture) · semantic self-reference (`P0-04 #62`)** | **there is no operation that combines two undetectable properties into a detectable one** |
>
> ### **SO-R250.3 — THE COMPOSITIONALITY VERDICT, IN ONE PARAGRAPH.**
> **The guarantees that compose are the negative ones — prohibitions on paths, writers, and machine shapes — and they
> compose because a prohibition is local by nature and global by conjunction. The guarantees that do not compose are the
> positive ones — detection, coverage, evidence, recovery — and they fail to compose for two different reasons: because
> they are indexed by scope, or because they depend on an external instrument whose availability does not scale with the
> number of things depending on it. Between the two classes sits the one genuinely counterintuitive result: **coverage
> and independence compose in opposite directions**, so the natural engineering instinct (add more observers) improves
> one and can degrade the other. `SO-R250.2` is the rule an implementer must be told explicitly, because nothing else in
> the architecture will tell them.**
> **⟹ `[NON-CLAIM]` This contract does NOT claim compositional safety. It claims that 13 of its 34 invariants compose
> unconditionally, 9 hold locally, 6 require external assumptions, 3 become weaker when composed, and 5 cannot be
> composed — and that §249 found no composition that was safe by virtue of its parts being safe.**

---

# §251 — THE FINAL P0 ARCHITECTURE SCORECARD

> **[NORMATIVE]** Statuses from §252's taxonomy. **No numerical score is used, and §251's instruction — *do not use the
> scorecard to conceal unresolved critical issues* — is discharged by the ❌ and ⚠️ entries, which outnumber the ✅
> entries in three rows.**

| Dimension | P0-01 | P0-02 | P0-03 | P0-04 | P0-05 | P0-06 | P0-07 | **P0-08** | **INTEGRATED** |
|---|---|---|---|---|---|---|---|---|---|
| **Contract completeness** | PASS | PASS | PASS | PASS | PASS | PASS WR | **PASS WR** | **PASS WR** | **PASS WITH RESIDUAL** — 8 contracts, §94's minimization met |
| **Parameter completeness** | OPEN (`[T]` values) | OPEN | OPEN (`OR-C10`) | OPEN | OPEN (13 `[T]`) | OPEN (13 `[T]` of 50) | OPEN (53 of 62 unresolved) | **OPEN (21 of 26 unresolved)** | **OPEN — and this is EXPECTED, not a defect: §258's definition of completeness excludes parameter values** |
| **Authority separation** | PASS | PASS WR (`G24`) | PASS | PASS | PASS | PASS | PASS | **PASS** (`D-S01`: no authority object) | **PASS WITH RESIDUAL** — `G24` UNSOLVABLE at the apex |
| **Epistemic separation** | PASS | PASS | PASS WR (**dim 6**) | **OPEN** (#25, #56, #62) | PASS WR (`RH-2`) | PASS | PASS | **PASS WR** (§233's construction) | **OPEN — semantic self-reference is the architecture's deepest unresolved epistemic problem, and P0-08 worsens it (§202)** |
| **Provenance** | PASS | PASS | PASS (`root_commit`, `causal_depth`) | PASS WR (`SP-5`) | PASS (acyclic change graph) | PASS (Σ-log, tombstones) | PASS (7 links, references only) | **PASS** (consumes, adds nothing) | **PASS WITH RESIDUAL** — `OR-H22`/`OR-S35`: integrity rests on K |
| **Security** | PASS | PASS WR (capture) | PASS | PASS WR | PASS | PASS | PASS (17 immutable classes) | **PASS** (92 attacks, 78 closed) | **BOUNDED** — 25 unclosed attacks across P0-07/P0-08, all reference or measurement problems |
| **Scalability** | — | PASS to 10⁹ (KC replicas) | PASS (no vector clocks) | PASS | PASS (no O(N²) learner) | **BOUNDED (stops at 10⁷)** | **BOUNDED (10⁷ respected; no 10¹²)** | **BOUNDED** (per-scope coverage; the infeasible per-reader variant rejected) | **BOUNDED — validated to 10⁷; per-envelope only above 10⁸; firewalls only at 10¹⁰+** |
| **Hardware portability** | ⚠️ (`F-IMP-2`) | ⚠️ (`G-P02-5`) | PASS (no global sync) | PASS | PASS | ⚠️ (hardware-gated regional claims) | **⚠️ (HP-1 open; HP-3 partial; the global-setpoint monoculture finding)** | **⚠️ (`AS-08`, `AS-09`, `IND-5` approximate)** | **PASS WITH RESIDUAL** — **HP-1 (the off-substrate store) is the single highest-leverage open item in the series and has been open since P0-06** |
| **Testability** | PASS | PASS | PASS WR (dim 6 untestable) | PASS WR | PASS | PASS | PASS (45 invariants, all checkable) | **PASS WR** (22 of 30 mechanical; **1 `[DECLARATIVE]`; 2 untestable**) | **PASS WITH RESIDUAL** |
| **Implementation readiness** | ⚠️ needs `[T]` values | ⚠️ needs the store | ⚠️ needs the partition ruling | PASS | ⚠️ | ⚠️ | ⚠️ needs amendments 1–14 ratified | **⚠️ needs amendments 15–18 ratified + C0–C3+C6+C7** | **⚠️ READY AT THE ARCHITECTURE LAYER ONLY — §223's three-stage gate: `IMPLEMENT` is reachable; `OPERATE` needs C4; `DEPLOY` needs C5 and 5 blocking items resolved** |
> *(WR = PASS WITH RESIDUAL)*
>
> ### **SO-R251.1 — WHAT THE SCORECARD DOES NOT CONCEAL.**
> **Three rows have more ⚠️/❌/OPEN than ✅ across the nine columns: parameter completeness (all OPEN) · epistemic
> separation (OPEN, and P0-08 makes it worse) · implementation readiness (all ⚠️).**
> **And two columns are worse than any of their parts: the INTEGRATED epistemic-separation cell is OPEN even though six
> of eight contracts are PASS — because `P0-04`'s three open attacks and P0-08's §233 construction are properties of the
> composition, not of any contract. **That is §250's verdict appearing in the scorecard, and concealing it would have
> required averaging.**

---

# §252 — THE FINAL ARCHITECTURE STATUS TAXONOMY

> **[NORMATIVE]** Every P0-08 subsystem receives exactly one status. **No numerical score substitutes for a status.**

| Subsystem | **Status** | Ground |
|---|---|---|
| **observation layer (`OBJ-01`, `SM-01`)** | **PASS** | 14 mandatory fields; `SO-INV-01` enforced by machine shape |
| **coverage (`OBJ-03`, `SM-02`)** | **PASS WITH RESIDUAL** | `Q_ev` unknowable (`OR-S1`); **`NO-GAP` reachable by default until amendment 18 (`SO-R232.4`)** |
| **fault taxonomy (§11)** | **PASS** | 6 axes, 6 writers; `INSTRUMENT` and `UNCLASSIFIED` both mandatory |
| **detection (§12)** | **PASS WITH RESIDUAL** | the 5 inherited safeguards; **`OR-S29`: a never-manifesting blind spot** |
| **diagnosis (`SM-04`)** | **PASS** | four statuses; the excluded-driver column; **no causal inference performed** |
| **incident (`SM-05`)** | **PASS** | multi-fault by construction; no total ordering |
| **quarantine (`SM-06`)** | **PASS** | ⟦inherited verbatim⟧; **IF-2's critical-period exception now explicit** |
| **repair (`SM-07/08`)** | **PASS WITH RESIDUAL** | no confidence arbitration; **`OR-S12`: regression coverage limited to `G4`'s classes** |
| **rollback (`SM-09`)** | **PASS** | hash + epoch; 7 things it never does |
| **recovery (`SM-10`)** | **BOUNDED** | the non-recoverer rule **terminates at K/EVA (`OR-S4`)** |
| **degradation (`SM-11`)** | **PASS** | per-function policy; restrictive default; governance semantics unchanged |
| **emergency freeze (`SM-12`)** | **PASS WITH RESIDUAL** | 9 fields; no governance power; **`OR-S15`: strategic timing** |
| **self-model (`SM-13`)** | **PASS** | Λ2, not self-updating; **§233's construction is an epistemic limit, not a mechanism defect** |
| **capability / limitation (`SM-14/15`)** | **PASS** | advisory; EVA-only confirmation |
| **metacognition (`SM-16`)** | **PASS WITH RESIDUAL** | no self-calibrated terminal; **`OR-S5`: every parameter `[U]`** |
| **abstention (`SM-17`)** | **PASS WITH RESIDUAL** | mandatory recovery condition; **`OR-S6`: permanent escalation is possible** |
| **attention (`SM-18`)** | **BOUNDED** | **`OR-S26`: a strategic request is indistinguishable from a legitimate one** |
| **workspace (`SM-19`)** | **PASS** | a `P0-03` message; a slot is a resource; reach ≠ warrant |
| **detector integrity (`SM-20`)** | **PASS WITH RESIDUAL** | the Integrity Auditor; **`P0-07 OR-H10`: the Auditor has no auditor** |
| **observer set / independence (`SM-21`, `OBJ-25/26`)** | **BOUNDED** | **`IND-6` undetectable from inside; `OR-S36`: a claimant may omit a dimension it shares** |
| **monitoring economics (B13, FW-6)** | **PASS WITH RESIDUAL** | the floor holds; **its SIZE is `[G]`, and a floor set too low is not internally detectable** |
| **recursion termination (§167–§170)** | **PASS** | depth-2 rule; **the terminus is external and unprovable (§201)** |
| **the six firewalls (§190–§195)** | **PASS** | proved by enumeration of writers |
| **evolution interfaces (§185–§189)** | **CONDITIONAL** | **amendment 17 unratified ⟹ `SO-R185.5`'s closure is not yet in force** |
| **cross-contract dependencies (§208)** | **BLOCKED (1 of 22)** | **`XD-01`/`XD-04`/`XD-08` are open handoffs; `XD-01` is BLOCKED on `P0-01`** |
| **governance capture (§200)** | **OPEN** | **`G24` UNSOLVABLE — preserved, not mitigated** |
| **`RH-2` (§133, §243)** | **OPEN** | **widened by six routes; four of §243's eight escape routes are BOUNDED by it** |
| **`A22` (§196)** | **OPEN** | **widened by three routes** |
| **semantic self-reference (§202, §233)** | **OPEN** | **`P0-04 #62`, worsened by self-modelling, with an operational construction** |
| **self-created authority (§240)** | **PASS WITH RESIDUAL** | 12 routes closed; **`OR-S41`: influence over what governance sees** |
| **self-created truth (§241)** | **PASS** | 10 routes closed, 8 by other contracts |
| **historical erasure (§242)** | **PASS** | 8 routes closed, **one by `SO-INV-34` found in the audit itself** |
> ### **SO-R252.1 — TALLY: 32 subsystems — PASS 12 · PASS WITH RESIDUAL 11 · BOUNDED 4 · OPEN 4 · CONDITIONAL 1 ·
> BLOCKED (partial) 1 · NOT CLAIMED 0.**
> **⟹ The four OPEN subsystems are all preserved residuals of prior contracts, not P0-08 failures — and P0-08 widened
> three of them. That is stated in §133, §196, and §202 rather than left to the reader.**

---

# §252A — VOLUME K LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§245, §246, §247, §248, §249, §250, §251, §252** |
| Rules introduced | **SO-R245.1, .6–.10, R247.1–.2, R248.1–.7, R249.1–.2, R250.1–.3, R251.1, R252.1** |
| **§245 closure gate** | **20 conditions: 19 ✅ · 1 ⚠️ PASS WITH RESIDUAL · 0 ❌** ⟹ **P0-08 COMPLETE WITH EXPLICIT RESIDUALS AND EXPLICIT OPEN RESEARCH** |
| — parameter register | **26 parameters: 6 determinate, 21 owned elsewhere or `[U]`, NO INVENTED VALUES** |
| — scale limits | per-mechanism costs; **coverage is `O(scopes × windows)`, NOT `O(N)`**; `effective_sources` collapse is per-claim, not global; **the per-reader coverage §203 would need is INFEASIBLE at R3 and is routed, not implemented**; **no 10¹² guarantee** |
| — non-claims | **20 items** |
| **§246 traces** | **all ten executed** (A–J) with per-step owners, objects, and the three transition types · **§246's three verification requirements all met: specialization creates no authority (F) · self-model/immune mechanisms cannot redefine selection authority (G) · P0-08 never becomes the authorization authority (J)** |
| **§247 failure analysis** | **9 reports × 10 traces** · **no trace marked successful on its diagram** · **4 of 10 failed paths are OPEN residuals** (F, G, I, J) |
| **§248 interference** | **6 pairs tested → 5 EMERGENT CONFLICTS FOUND, each requiring a new rule or field:** **IF-1** quarantine ⟹ post-release learning stall (`SO-R248.2`: release must trigger anchor re-establishment) · **IF-2** quarantine during a critical period is irreversible in effect (`SO-R248.3`: escalate to `[RO-13]`) · **IF-3** evolution produces false instrument-defect findings (`SO-R248.4`: `EVOLVED-INSTRUMENT` vs `DEFECT-SUSPECT`) · **IF-4** repair vs immutable history (`SO-R248.5`: a validity window on every derived record) · **IF-5** attention-to-gaps fights freeze (`SO-R248.6`: `FREEZE-INDUCED` gap subclass) · **IF-6** `HC-S4`, the cross-contract homeostasis↔monitoring loop, **BOUNDED** |
| **§249 compositional safety** | **7 compositions tested: 5 unsafe or conditionally safe · 1 safe only by a distinction · 1 unsafe and unfixable. NOT ONE was safe by virtue of its parts being safe** |
| **§250 compositionality verdict** | **5 classes: COMPOSE 13 (the negative guarantees — prohibitions on paths and writers) · LOCAL ONLY 9 · REQUIRE EXTERNAL ASSUMPTIONS 6 · WEAKER WHEN COMPOSED 3 · CANNOT BE COMPOSED 5.** **⟹ THE COUNTERINTUITIVE RESULT: COVERAGE AND INDEPENDENCE COMPOSE IN OPPOSITE DIRECTIONS — adding observers always improves coverage and may degrade evidence** |
| **§251 scorecard** | **10 dimensions × 9 columns** · **3 rows have more ⚠️/❌/OPEN than ✅** (parameter completeness, epistemic separation, implementation readiness) · **2 INTEGRATED cells are worse than any of their parts** (epistemic separation OPEN despite 6 of 8 PASS; scalability BOUNDED) — **concealing either would have required averaging** |
| **§252 status taxonomy** | **32 subsystems: PASS 12 · PASS WITH RESIDUAL 11 · BOUNDED 4 · OPEN 4 · CONDITIONAL 1 · BLOCKED (partial) 1** · **the four OPEN are preserved residuals of prior contracts, three of which P0-08 widened** |
| New invariants | — *(§248's five rulings are rules, not invariants; §250 is a verdict)* |
| New cycles | **HC-S4** (homeostasis ↔ monitoring, cross-contract, **BOUNDED**) |
| Cumulative | **34 invariants · 41 open-research entries · 18 amendments · 27 monitors · 92 attacks · 4 cycles (HC-S1…HC-S4) · 2 circular dependencies (BC-S1 BROKEN, BC-S2 UNCLOSABLE) · 26 parameters · 22 cross-contract dependencies · 16 assumptions** |

**Next:** `74_` Vol L — §253 the open-research separation (O-R1…O-R6) · §254 implementation blockers · §255 the post-P0
roadmap · §256 the P0-09 gate · §257 the "no more contracts" test · §258 the completeness definition · §259 the closure
statement · §260 the 40 integrated principles · §261 the 14 non-negotiable separations · §262 the systemic failure
modes · §263–§265 the red team, the blue team, and the minimality recheck · §266 the complexity check · §267 the final
score · §268 the verdict logic · §269 the final statement · §270 the closing rule.
