# P0-08 — VOLUME D (§161–§170)
## Emergency Freeze, Freeze Abuse and Escalation, the Recovery Root, Immune-Subsystem Failure, and the Termination of Every Recursion

---

# §161 — EMERGENCY FREEZE, EXACTLY

> ### **SO-R161.1 — THE NINE FIELDS, SPECIFIED.** **[NORMATIVE]** — *`SO-C4.4` gives the schema; this gives the semantics.*
>
> | # | Field | **Exact semantics** | Writer | What an invalid value means |
> |---|---|---|---|---|
> | **1** | **trigger** | a **reference** to the detection, verdict, or coverage state that caused the freeze. Never a narrative. **A freeze with no trigger reference is invalid, not conservative** | EIK / OP | invalid ⟹ not issued |
> | **2** | **authority** | **EIK** below `Cell §17`'s cap; **OP** at or above it. **Never the subject. Never K alone. Never `[RO-13]` acting without EIK's safety concurrence for a scope above a cell** | EIK / OP | invalid ⟹ not issued |
> | **3** | **scope** | an `OBJ-02` reference. **A freeze without a scope is INVALID — it is not global by default.** The default-global reading is the single most dangerous possible ambiguity in this field | EIK | invalid ⟹ not issued |
> | **4** | **duration semantics** | **`MAX-DWELL` + a release condition, both declared. NOT a wall-clock expiry.** Dwell is counted in intervals (`Cell §18.2`'s convention), so a freeze is not shortened by a fast clock or lengthened by a stalled one | EIK / `[RO-13]` | a wall-clock-only duration is a schema violation |
> | **5** | **preserved state** | what is frozen and retained. **`Cell §18.2` HARD's rule: state frozen, in-flight captured as evidence.** Nothing is discarded by a freeze | K | a freeze that discards state is a rollback, and requires `SM-09` |
> | **6** | **blocked operations** | **ENUMERATED. An unenumerated operation is NOT blocked** — default-permit within the freeze's own scope, because a freeze that blocked everything would block its own release and audit | EIK | an open-ended "all operations" value is invalid |
> | **7** | **permitted recovery operations** | **ENUMERATED and RESTRICTIVE-ONLY** (`P0-07 HOM-INV-09`). **A permitted recovery operation that grants capacity, widens authority, raises a threshold, or restores a status is invalid** | `[RO-13]` (declared in advance) | invalid ⟹ the freeze cannot be issued |
> | **8** | **release authority** | **STRICTLY HIGHER than the trigger authority** (`SO-R161.3`'s table) | — | a peer or self release is invalid |
> | **9** | **audit record** | an `OBJ-28` canonical event + `P0-04` provenance, **immutable once sealed** | K | a freeze with no audit record did not happen, and the absence is itself reportable |
>
> ### **SO-R161.2 — WHAT A FREEZE IS, IN ONE SENTENCE.** **[DEFINITION]**
> **A freeze is a scoped, time-bounded, enumerated, restrictively-recoverable suspension of ordinary operations, issued
> by an authority that cannot release it, recorded immutably.**
> **Every one of those eight adjectives removes one route by which a freeze could become governance:**
> *scoped* ⟹ not global · *time-bounded* ⟹ not permanent · *enumerated* ⟹ not open-ended · *restrictively-recoverable*
> ⟹ cannot grant · *issued by an authority that cannot release it* ⟹ cannot be self-terminating · *recorded
> immutably* ⟹ cannot be denied.
>
> ### **SO-R161.6 — A FREEZE IS NOT AN ALTERNATIVE GOVERNANCE SYSTEM. THE PROOF, BY ENUMERATION.** **[NORMATIVE]**
> **A governance system must be able to do at least one of: make a rule · grant an exception · alter a threshold ·
> confer authority · change an objective. A FreezeOrder can do none of the five:**
> | Governance power | Available to a FreezeOrder? | Blocked by |
> |---|---|---|
> | make a rule | ❌ | field 6 is enumerated; a freeze blocks listed operations and creates no new ones |
> | grant an exception | ❌ | field 7 is restrictive-only; **an exception is a capacity grant** |
> | alter a threshold, band, gate, or setpoint | ❌ | all are `[G]` (`P0-07 HOM-INV-10`); no P0-08 object writes them |
> | confer authority | ❌ | **`D-S01`: P0-08 has no authority-bearing object. §212's authority roots are all external to this contract** |
> | change an objective | ❌ | OP-sole (`P0-07 §76`) |
> **⟹ `SO-R161.7 — THE ONE RESIDUAL, STATED: a freeze CAN change what happens, by suspending it.** A freeze that is
> issued selectively, repeatedly, or at a chosen moment is a de facto intervention in the system's behaviour — and no
> field of `OBJ-17` prevents selectivity. **The defences are `SO-R162.2`'s freeze-rate budget and `SO-R163.1`'s
> per-level evidence requirements, both of which are governance-side. `[OPEN: OR-S15]` — a freeze issued for
> legitimate safety reasons at a strategically chosen moment is indistinguishable from a freeze issued strategically.
> This is `P0-06 A22`/`P0-07 A171`'s within-spec steering in the fault domain, and it is open for the same reason.**

---

# §162 — FREEZE ABUSE

> ### **SO-R162.1 — THE TWO ATTACKS.** **[NORMATIVE — the attacks defended against]**
> **A1: `false fault → freeze → system unable to operate.`**
> **A2: `repeated freeze → permanent denial of service.`**
>
> ### **SO-R162.2 — THE DEFENCES, AND THE ONE GAP THEY EXPOSED.** **[NORMATIVE]**
> | Defence | Ground | Which attack |
> |---|---|---|
> | **A false fault is a detector false positive, and `Cell §18.5(ii)` already prices it: exceeding the false-positive budget causes the DETECTOR to be recalibrated or DISABLED** | `SM-20`, inherited | **A1** — **the attacker's own instrument is removed** |
> | **Two-detector confirmation of different types above criticality θ before `CONFIRMED`** | `Cell §18.5(iv)`, `SM-03`, dimension-qualified by `SO-C12.3` | **A1** — a single false report yields `UNCONFIRMED`, which is retained but does not confirm |
> | **A cell may only SELF-SUSPEND.** A scope freeze requires EIK (or OP above the cap) | `P0-07 §76`'s matrix; `SO-R161.1` field 2 | **A1** — **a cell cannot freeze anything but itself, and self-suspension is restrictive, so it is not an attack on others** |
> | **A FREEZE-RATE BUDGET, on the derivative** | **NEW — `SO-R162.3`** | **A2** |
> | **Release authority strictly higher than trigger authority; never self- or peer-released; never auto-expired into normal operation** | `SO-R161.3`, `SO-R161.5`, `SM-12` | **A2** — each escalation moves the decision to a smaller body with higher evidence requirements |
> | **Repeated freeze is itself an incident, with origin class `INSTRUMENT` or `GOVERNANCE`, never `ENDOGENOUS`** | `SO-C11.2` | **A2** — **the repetition is diagnosed as a defect in the detector or the policy, not in the frozen subject** |
>
> ### **SO-R162.3 — THE FREEZE-RATE BUDGET.** **[NORMATIVE]**
> **K maintains a freeze rate per ⟨scope class, authority⟩, and `Cell §18.5(iii)`'s derivative principle applies: a
> rising freeze RATE — not a high freeze count — triggers immune dampening plus operator escalation.**
> **NO NUMERIC THRESHOLD IS INVENTED. The rate classes and their boundaries are `[G]`/`[U]`. `[OPEN: OR-S16]`**
> **⟹ `[DERIVATION]` Why the derivative: a busy system may freeze often and legitimately. A system whose freeze rate is
> *rising* is either degrading or being attacked, and both require the same response — dampening plus a human — while a
> level threshold would fire on the busy system and stay silent on the slowly-attacked one. This is the third use of the
> same principle in this contract (`Cell §18.5(iii)` for quarantine, `P0-07 HOM-R21.2` for repair, here for freeze),
> and its repeated applicability is evidence that it is a property of the architecture rather than a device for one
> subsystem.**
>
> ### **D-S02 — EVERY OBSERVER THAT REPORTS A FAULT IS A DETECTOR FOR THE PURPOSES OF `Cell §18.5(ii)`.** **[NORMATIVE]**
> **The gap the defences exposed: `Cell §18.5(ii)`'s false-positive budget attaches to a DETECTOR, and `SO-R214.3`
> deliberately makes fault-occurrence writing MULTI-WRITER — every observer may report. An observer that is not a
> registered detector therefore has NO budget that a false report consumes, and A1 has a route that costs the attacker
> nothing.**
> **⟹ THE RULING: emitting an `OBJ-04` occurrence makes the emitter a detector, with a declared threshold class, a
> false-positive budget, and a disablement record. There is no such thing as an occasional fault reporter.**
> **This is a real cost — it means every component that can report a fault can be disabled for over-reporting — and it
> is the correct cost, because the alternative is an unpriced channel into the containment system.**
> **`[TEST: SOMon-9 — every `OBJ-04.observer_id` resolves to a registered `OBJ-09`]**

---

# §163 — FREEZE ESCALATION

> ### **SO-R163.1 — ESCALATION IS POSSIBLE AT FOUR LEVELS, AND EACH LEVEL HAS ITS OWN AUTHORITY AND EVIDENCE REQUIREMENT.** **[NORMATIVE]**
> | Level | Scope frozen | **Trigger authority** | **Evidence requirement** | **Release authority** |
> |---|---|---|---|---|
> | **cell** | one cell | **the cell itself** (a restrictive self-act, always permitted) *or* K on a detection | a detection reference, or none for self-suspension | **K** |
> | **circuit** | one circuit | **K**, on EIK concurrence | **a `CONFIRMED` occurrence** (two detectors, different types) **or a `SUPPRESSION-SUSPECTED` coverage gap** | **EIK** |
> | **region** | one region | **EIK** | **an open `OBJ-07` incident with `severity ≥ S3`, or a derivative-triggered cascade signal** | **`[RO-13]`** |
> | **organism** | the whole organism | **EIK** below `Cell §17`'s cap; **OP** at or above it | **at or above the cap: `Cell §17` requires HUMAN AUTHORIZATION and a defined degraded mode *instead*.** Below it: two or more open regional incidents, or a cascade signal at organism scope | **OP** |
>
> ### **SO-R163.3 — ESCALATION IS NOT AUTOMATIC, AND THE EVIDENCE REQUIREMENT STRICTLY INCREASES.** **[NORMATIVE]**
> **Two properties:**
> **(a) MONOTONE EVIDENCE.** Each level's evidence requirement is strictly stronger than the level below: a reference →
>     a confirmed occurrence → an open `S3+` incident → human authorization. **⟹ An attacker that can manufacture a
>     cell-level freeze cannot manufacture an organism-level one, because it cannot manufacture `Cell §17`'s human
>     authorization.**
> **(b) NO SKIP.** A regional freeze may not be issued without either a regional incident or a cascade signal; an
>     organism freeze may not be issued as "the union of cell freezes". **`Cell §18.2`'s never-skip-upward property,
>     generalized from rungs to scopes.**
> **⟹ `SO-R163.4 — THE DIRECTION THAT MATTERS: ESCALATION IS EASIER TO TRIGGER THAN TO RELEASE, AND THAT IS
> DELIBERATE.** A restrictive act should be fast (`Cell R15.1`: *"latency in self-restriction is a safety cost"*) and a
> permissive act should be slow. **Release authority is strictly higher at every level, so the asymmetry compounds
> upward: an organism freeze is issued by EIK and released only by OP.**

---

# §165 — THE RECOVERY ROOT

> ### **SO-R165.1 — THE MINIMUM RECOVERY SUBSTRATE.** **[NORMATIVE]**
> **§165 asks for the minimum substrate that must remain outside ordinary mutable cognition for recovery to be possible.
> It has exactly four components:**
> | # | Component | Why it must be outside mutable cognition | Owner |
> |---|---|---|---|
> | **1** | **the anchored record stores** — the ledger, the genome-artifact store, the provenance chain, the archive, the memory epochs | a recoverer needs a record of what to recover TO. If the record is mutable by the recovering cognition, recovery is unfalsifiable | **K, off-substrate** (`P0-07 HP-1`) |
> | **2** | **the coverage records** (`OBJ-03`) | `SO-INV-01` requires that unobserved never read as healthy; if the recovering cognition wrote its own coverage, it could declare itself observed | **K** |
> | **3** | **the declared recovery plans** (`OBJ-15`) and degradation policies (`OBJ-16`) | `SO-C16.1`: a plan declared during a fault is an improvisation | **`[RO-13]`** |
> | **4** | **the fail-safe default** (`SO-INV-02`) | when all three above are unavailable, the default must be restriction. **A default is not a component anyone can hold, which is why it is a rule and not a store** | **the contract itself** |
>
> ### **SO-R165.2 — THE RECOVERY ROOT IS GOVERNANCE-CRITICAL, AND IT BELONGS UNDER `P0-02`. IT IS ALREADY THERE.** **[NORMATIVE]**
> **Components 1–3 are all K-held or `[RO-13]`-declared off-substrate objects, and `P0-02` is the contract that
> specifies off-substrate authority and the EIK's attestation chain. **Component 4 is a rule of this contract.**
> **⟹ NO NEW KERNEL IS CREATED. The recovery root is `P0-02`'s EIK + K's anchored stores + `[RO-13]`'s declared plans +
> one default rule. §209's "second immutable kernel" and "second safety kernel" searches both return a MERGE, and
> `D-S01`'s consequence (2) is discharged.**
>
> ### **SO-R165.3 — THE HONEST LIMIT OF THE RECOVERY ROOT.** **[NON-CLAIM / OPEN]**
> **The recovery root is only as trustworthy as K, and K is the only off-substrate writer.**
> **`P0-07 OR-H1` — *K meters, evaluates, writes the evaluation, and consumes it; writer separation is unavailable* —
> appears here for the **fifth** time (Σ1 in `P0-06`; measurement in `P0-07 §75`; the distance oracle in `P0-07 BC-H10`;
> the non-recoverer rule in `SO-R164.2`; and now the recovery root).**
> **⟹ `[NON-CLAIM]` This contract does NOT claim that recovery is guaranteed. It claims that recovery has a declared
> root, that the root is outside mutable cognition, that its acts are finite, logged, anchored, hash-chained and
> expiring — and that when the root itself is the failing component, verification is external or absent.
> `[OPEN: OR-S4, OR-S17]`**

---

# §166 — IMMUNE-SUBSYSTEM FAILURE

> ### **SO-R166.1 — THE FOUR QUESTIONS, ANSWERED.** **[NORMATIVE]**
> | Question | Answer |
> |---|---|
> | **Who monitors the immune subsystem?** | **The EIK Integrity Auditor** (`OBJ-10`), which verifies that quarantine decisions correlate with actual failures (`Cell §18.5(v)`). **It is not part of the immune subsystem, and the immune system MUST NOT monitor itself** |
> | **What happens if a detector fails?** | **Three routes, all restrictive:** (a) its false-positive budget is exceeded ⟹ recalibrated or **disabled** (`Cell §18.5(ii)`); (b) it produces no observations ⟹ `OBJ-03.gap_class = DETECTOR-ABSENT` ⟹ `UNMEASURED` ⟹ `SO-INV-01` reads restrictively; (c) the Integrity Auditor finds its decisions do not correlate ⟹ `AUDIT-FINDING` ⟹ `[RO-13]`/OP |
> | **Are there redundant detectors?** | ✅ **`Cell §18.5(iv)`: two independent detectors of DIFFERENT TYPES above criticality θ** — **with `SO-C12.3`'s dimension qualification: "different types" is necessary and NOT sufficient. Two detectors sharing `IND-4` (model class), `IND-5` (hardware), or `IND-6` (latent assumptions) are one effective source** |
> | **Can external evaluation detect immune failure?** | ⚠️ **PARTIALLY.** EVA can detect a *consequence* of immune failure (a fault that reached the outputs). **EVA cannot detect a silent immune failure whose consequence is an absence — a fault that was never contained and never manifested in the evaluated outputs.** **⟹ `OR-S18`: absence-consequence immune failure is not externally detectable either, and this is the fault-domain form of `P0-07 A83`'s exhaustion-as-defence problem: attribution requires a counterfactual** |
>
> ### **SO-R166.2 — THE THREE WAYS THE IMMUNE SUBSYSTEM ITSELF FAILS, AND THEIR DETECTABILITY.** **[DERIVATION]**
> | Failure | Detectable? | By what |
> |---|---|---|
> | **over-reaction** (false positives) | ✅ **YES** | the false-positive budget — **and the detector is disabled, which is the only self-modification the immune system performs, and it is self-REDUCING** |
> | **under-reaction** (false negatives) | ⚠️ **PARTIALLY** | the Integrity Auditor's correlation check catches false negatives **that later manifest as failures**; it cannot catch false negatives whose faults never manifest |
> | **misdirection** (reacting to the wrong subject) | ⚠️ **PARTIALLY** | the correlation check + `OBJ-26`'s independence collapse. **A misdirected immune system that quarantines rivals rather than faults is `P0-07 A147`, BOUNDED via `OR-H15` because `G3`/`G7` are organism-measured** |
> **⟹ `SO-R166.3 — THE ASYMMETRY IS THE RESULT: OVER-REACTION IS FULLY DETECTABLE AND SELF-CORRECTING; UNDER-REACTION
> IS DETECTABLE ONLY THROUGH ITS CONSEQUENCES.** An immune system will therefore drift toward under-reaction unless the
> coverage records are audited, because under-reaction is cheap and over-reaction is priced. **`SOMon-10` audits the
> joint distribution of (detector disablements × coverage gap classes) for exactly this drift.**

---

# §167–§170 — THE TERMINATION OF EVERY RECURSION

> ### **SO-R167.1 — THE MONITOR-OF-MONITOR CHAIN, AND WHERE IT TERMINATES.** **[NORMATIVE]**
> ```
>   depth 0  the process                         (the cell, circuit, region, population)
>   depth 1  the observer / detector / self-model (INTERNAL. Λ2. NOT self-updating. Advisory)
>   depth 2  the auditor                          (EXTERNAL: the EIK Integrity Auditor, EVA, OP)
>   depth 3  ——— DOES NOT EXIST ———
> ```
> **The chain terminates at depth 2 BY MAKING DEPTH 2 EXTERNAL.**
> | Chain | Depth 0 | Depth 1 | **Depth 2 (terminus)** | Why it cannot go deeper |
> |---|---|---|---|---|
> | **monitor of monitor** (§167) | the subject | the detector | **the EIK Integrity Auditor** | the auditor is EIK's; **auditing the auditor is OP's or external** — `P0-07 OR-H10`, preserved |
> | **self-model of self-model** (§168) | the process | `OBJ-18`, **Λ2** | **K's versioning of it, driven by an EXTERNAL observation or verdict** | **`P0-05 R59.1`: Λ2 and NOT self-updating. There is no Λ3-of-observation inside the organism** |
> | **metacognition of metacognition** (§169) | the forecast | `OBJ-21` | **EVA's external calibration** | **`SO-R179.3`: no self-calibrated terminal state exists** |
> | **recovery of recovery** (§164) | the failed scope | the recoverer | **a non-recoverer verifier** | **`SO-R164.2`; terminates at K/EVA — `OR-S4`** |
> | **verification of verification** (§166) | the subject | the verifier | **a verifier of a different `IND-4` class, or EVA** | terminates at EVA, which is external |
>
> ### **SO-R167.2 — THE FINAL GUARANTOR IS EXTERNAL AND CANNOT BE INTERNALLY PROVEN.** **[NON-CLAIM]**
> **Accepted explicitly, per §167's instruction. Three statements of the same limit, from three contracts:**
> - **`P0-02`: *"The architecture cannot internally guarantee the correctness of every external guarantor."* And:
>   *"A captured OP is indistinguishable from a legitimate OP by any mechanism OP authorizes"* (`OR-13`/`G24`,
>   UNSOLVABLE).**
> - **`P0-07 OR-H1`: writer separation is unavailable wherever K meters, evaluates, writes and consumes.**
> - **`P0-05 RH-2` / `P0-07 A82`: evaluator independence is BOUNDED, not closed.**
> **⟹ `[NON-CLAIM]` This contract does not claim a complete internal guarantee chain. It claims that **every internal
> recursion terminates**, that **every terminus is named**, and that **the termini are external and unprovable from
> inside**. Terminating is not proving, and the difference is §201's content.**
>
> ### **SO-R168.1 — THE OPERATIONAL STOPPING POINT FOR SELF-MODELS.** **[NORMATIVE]**
> **`self-model → model of self-model → …` is stopped by TWO rules, either of which suffices:**
> **(a) THE Λ-CLASS IS FIXED AT Λ2** (`P0-05 R59.1`, inherited). A model of the self-model would be Λ3, and Λ3 is not
>     constructible inside the organism.
> **(b) THE VERSIONING WRITER IS EXTERNAL TO THE MODEL.** `SM-13`: `updated_by = K`, on an external observation or
>     verdict. **A model of the self-model would have to be written by something that can observe the self-model — and
>     the only such writers are K and EVA, both external.**
> **⟹ `SO-R168.2 — WHAT EXISTS INSTEAD OF A MODEL OF THE SELF-MODEL: a VERSION HISTORY plus a DEFECT-FINDING
> mechanism.** `P0-05 R42.5`: *every observation carries `self_model_version`; a regression correlated with a version is
> a SELF-MODEL DEFECT FINDING.* **A version history plus correlation-with-regression is an operational substitute for a
> meta-model: it does not represent the model's model, it represents the model's ERROR, which is the only thing anyone
> ever needed the meta-model for.** `[DERIVATION]`

### SO-R169.1 — THE BOUNDED OPERATIONAL HIERARCHY FOR METACOGNITION. **[NORMATIVE]**
> **`metacognition → monitor metacognition → …` is bounded at three levels:**
> | Level | Object | Writer | Bounded by |
> |---|---|---|---|
> | **1** | a **forecast** with a scope and horizon class | the subject | `SM-16`: a forecast recorded after its outcome is a schema violation |
> | **2** | the **error** between forecast and outcome | **K** | the subject may not compute its own error |
> | **3** | the **calibration** of the error series | **EVA / `[RO-13]`** | **no self-calibrated terminal state exists (`SO-R179.3`)** |
> **⟹ There is no level 4. A "monitor of the calibration" would be a level-4 object, and level 3 is already external —
> so a level 4 would be an external monitor of an external monitor, which is not a recursion inside the architecture
> but a governance question about EVA, and it belongs to `P0-01`/`P0-02`.**
>
> ### **SO-R170.1 — THE RECURSION PRINCIPLE, DERIVED.** **[NORMATIVE]**
> > ## **«RECURSIVE SELF-DESCRIPTION MUST TERMINATE IN A BOUNDED OPERATIONAL REPRESENTATION OR AN EXTERNAL
> > AUTHORITY/EVALUATOR.»**
> **The two permitted termini, and which of §167's five chains uses which:**
> | Terminus | Meaning | Chains using it |
> |---|---|---|
> | **BOUNDED OPERATIONAL REPRESENTATION** | replace the meta-level object with a finite record of the level below: a **version history** instead of a model of the model; an **error series** instead of a monitor of the monitor; a **coverage record** instead of an observation of observation | self-model of self-model (`SO-R168.2`) · metacognition of metacognition (levels 1–3) |
> | **EXTERNAL AUTHORITY / EVALUATOR** | hand the meta-level to a body outside the recursion: the EIK Integrity Auditor, EVA, `[RO-13]`, OP | monitor of monitor · recovery of recovery · verification of verification |
> **⟹ `SO-R170.2 — THE PRINCIPLE DOES NOT CLAIM THAT RECURSIVE SELF-REFERENCE IS ELIMINATED. It claims that every
> INTERNAL recursion terminates, and that the terminus is either a finite record or an external body.**
> **What remains, and is not eliminated:**
> **(a) SEMANTIC SELF-REFERENCE — `P0-04`'s attack #62, `[U]`, with no measure.** Whether a proposition about the
>     system's own knowledge is self-referential in *meaning* (not in provenance) has no internal test. **§203 carries
>     this forward; P0-08 makes it worse, and §202 says how.**
> **(b) DIMENSION-6 CORRELATION — `P0-03`'s undetectable dimension: two implementations by two teams from one
>     specification correlate in ways neither can report.** Recursion termination does not touch it. **§202.**
> **(c) THE EXTERNAL TERMINUS IS ITSELF UNPROVABLE — `P0-02`'s guarantor limit.** **§201.**
> **(d) K IS THE ONLY OFF-SUBSTRATE WRITER — `P0-07 OR-H1`, fifth appearance.** **`SO-R165.3`.**
> **⟹ `[NON-CLAIM]` Recursive self-reference is BOUNDED in this architecture, not eliminated. Every claim stronger than
> "bounded" would be false, and the four items above are the reasons.**

---

# §166A — VOLUME D LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§161, §162, §163, §165, §166, §167, §168, §169, §170** (§164 completed in Vol B) |
| Rules introduced | **SO-R161.1–.2, .6–.7, R162.1–.3, R163.1, .3–.4, R165.1–.3, R166.1–.3, R167.1–.2, R168.1–.2, R169.1, R170.1–.2 · D-S02** |
| **Emergency freeze** | **9 fields fully specified** · **8 adjectives in the one-sentence definition, each removing one route to governance** · **the enumeration proof that a FreezeOrder holds none of the five governance powers** |
| **Freeze residual** | **`OR-S15` — a freeze issued for legitimate reasons at a strategically chosen moment is indistinguishable from one issued strategically. This is `P0-06 A22`/`P0-07 A171`'s within-spec steering in the fault domain, open for the same reason** |
| **Freeze abuse** | **2 attacks · 6 defences · 1 GAP FOUND AND CLOSED BY `D-S02`:** an observer that is not a registered detector has no false-positive budget, so a false report was unpriced ⟹ **every fault-reporting observer IS a detector** |
| **Freeze-rate budget** | **on the DERIVATIVE, no numeric threshold** — **the third use of `Cell §18.5(iii)`'s principle in this contract** (quarantine, repair, freeze) |
| **Freeze escalation** | **4 levels · monotone evidence (reference → confirmed occurrence → S3+ incident → human authorization) · no skip · release strictly higher at every level, so the asymmetry compounds upward** |
| **Recovery root** | **4 components** (anchored stores · coverage records · declared plans · the fail-safe default) · **belongs under `P0-02` and is already there** · **NO SECOND KERNEL CREATED** (§209 searches 2 and 7 both return a merge) · **`OR-S17`: the root is only as trustworthy as K** |
| **Immune failure** | **4 questions answered** · **3 failure modes with 3 different detectabilities** · **`SO-R166.3`: over-reaction is fully detectable and self-correcting; under-reaction is detectable only through its consequences ⟹ the immune system drifts toward under-reaction unless coverage is audited (`SOMon-10`)** · **`OR-S18`: absence-consequence immune failure is not externally detectable either** |
| **Recursion termination** | **THE DEPTH-2 RULE: depth 0 process · depth 1 internal observer (Λ2, advisory, not self-updating) · depth 2 EXTERNAL auditor · depth 3 does not exist.** 5 chains, each with its named terminus |
| **The recursion principle** | **derived, with TWO permitted termini** (a bounded operational representation · an external authority/evaluator) and **4 things it does NOT eliminate**: semantic self-reference (`P0-04 #62`) · dimension-6 correlation (`P0-03`) · the unprovable external terminus (`P0-02`) · K's uniqueness (`P0-07 OR-H1`) |
| **The substitute for a meta-model** | **`SO-R168.2`: a VERSION HISTORY plus correlation-with-regression (`P0-05 R42.5`) replaces a model of the model — it represents the model's ERROR, which is the only thing the meta-model was ever needed for** |
| Decisions | **D-S02** (every fault-reporting observer is a detector, with a false-positive budget) |
| New invariants implied | **SO-INV-11** (a freeze has no governance power: it cannot make a rule, grant an exception, alter a threshold, confer authority, or change an objective) · **SO-INV-12** (every internal recursion terminates at depth 2, and depth 2 is external) · **SO-INV-13** (no self-calibrated terminal state exists) — *formally numbered in Vol G* |
| Open research raised | **OR-S15** (strategically timed legitimate freeze) · **OR-S16** (freeze-rate classes are `[G]`/`[U]`) · **OR-S17** (the recovery root's trustworthiness rests on K) · **OR-S18** (absence-consequence immune failure is not externally detectable) |
| Verification instruments | **SOMon-9** (every occurrence's `observer_id` resolves to a registered detector) · **SOMon-10** (the joint distribution of detector disablements × coverage gap classes, for under-reaction drift) · **SOMon-11** (no `OBJ-17` field 7 contains a capacity-granting operation) · **SOMon-12** (no self-model version is written by its subject; no metacognitive record is self-calibrated) |

**Next:** `67_` Vol E — canon §17–§22: self-model, capability, limitation, metacognition, attention and
global-workspace rules; §128 the observer–observed collapse; §139–§141 hierarchical modelling, compression and
aggregation failure; §171 self-model security; §176–§178 population and collective self-knowledge; §180 confidence
dynamics; §183 abstention gaming.
