# P0-08 — VOLUME H (§122, §123, §124)
## The Invariant Set, the Requirement Traceability Matrix, the Requirement→Attack Trace, the Attack→Control Trace, and the Attack Catalogue (A172 – A263)

**Attack numbering continues `P0-07`'s register, which ended at A171.**

---

# §123-PRE — THE INVARIANT SET (SO-INV-01 … SO-INV-30)

> **§123 requires a trace from every load-bearing invariant to an attack, a detection, a containment, an enforcement,
> and a residual limitation. The invariant set is therefore stated first, with its enforcement kind.**
> **Enforcement kinds, per `P0-07 §77`: WRITER CHECK (no compliant path exists) · STATE CHECK (an illegal transition or
> out-of-band value) · SCHEMA CHECK (a forbidden or missing field) · GREP CHECK (a forbidden reference in a
> computation) · **[DECLARATIVE]** (an obligation on the implementer with no internal instrument).**

| # | Name | Statement | Enforcement kind |
|---|---|---|---|
| **01** | **UNOBSERVED-IS-NOT-HEALTHY** | a scope whose observation is absent, stale, degraded or unaffordable is `UNMEASURED`, a state distinct from `NOMINAL`, and may never be read as `NOMINAL` | **STATE** — `SM-01`/`SM-02` have no edge to a health-bearing state |
| **02** | **FAIL-SAFE DEFAULT** | corruption produces restriction, never permission: an unverifiable observation is ABSENT ⟹ `UNMEASURED`; a corrupted coverage record reads as ZERO coverage; a corrupted integrity record reads as DETECTOR-UNTRUSTED | **WRITER + STATE** ⟦`P0-05 R64.7` extended⟧ |
| **03** | **NO SELF-UPDATE** | no self-model, metacognitive record, diagnosis status, coverage record, or freshness class is written by the subject it describes or by the process it models | **WRITER** — `SM-13`, `SM-16`, `SO-R211.2` |
| **04** | **NO CORRELATION PROMOTION** | a diagnosis status may not be promoted by correlation, precedence, repetition, confidence, or self-report | **STATE** — `SM-04`'s excluded-driver column |
| **05** | **FREEZE-IS-NOT-SELF-TERMINATING** | a freeze never auto-expires into normal operation and is never released by its trigger authority or a peer | **SCHEMA + STATE** — `OBJ-17` field 8, `SM-12` |
| **06** | **CAPABILITY-EVIDENCE-NON-TRANSFERABLE** | capability evidence does not transfer between subjects, scopes, hardware classes, or generations | **WRITER** — `SO-R175.1` |
| **07** | **ABSTENTION-HAS-A-RECOVERY-CONDITION** | an abstention without a declared recovery condition is invalid, because it is unfalsifiable and therefore permanent | **SCHEMA** — `OBJ-22` |
| **08** | **CONTAINMENT-RECORDS-ITS-BLIND-SPOT** | every containment act writes a coverage gap for the contained scope; the gap is never `NO-GAP` | **STATE + WRITER** — `SOMon-7` |
| **09** | **NO-SINGLE-FAULT-ASSUMPTION** | no global incident counter, no single-incident state, no total ordering of incidents | **STATE** — `SM-05`'s shape |
| **10** | **UNDECLARED-INTERACTION-IS-INTERACTION** | two open incidents with overlapping scopes and no declared interaction class are treated as INTERACTING | **STATE** — restrictive default |
| **11** | **FREEZE-HAS-NO-GOVERNANCE-POWER** | a FreezeOrder cannot make a rule, grant an exception, alter a threshold, confer authority, or change an objective | **SCHEMA** — fields 6 and 7; `SOMon-11` |
| **12** | **RECURSION-TERMINATES-AT-DEPTH-2** | depth 0 process · depth 1 internal observer · depth 2 EXTERNAL auditor · **depth 3 does not exist** | **STATE** — `SM-13`, `SM-16`, `SM-20` |
| **13** | **NO-SELF-CALIBRATED-TERMINAL** | no metacognitive machine has a self-calibrated terminal state | **STATE** — `SM-16` |
| **14** | **UNDECLARED-PERTURBATION-IS-A-FAULT** | a `PERTURBATIVE` observation with no declared effect is a fault of origin class `INSTRUMENT` | **SCHEMA** — `SOMon-16` |
| **15** | **COST-NEVER-DETERMINES-NECESSITY** | a resource quantity may make an observation UNAFFORDABLE (`DETECTOR-ABSENT`, read restrictively); it may never make a monitor UNNECESSARY | **WRITER + STATE** — **FW-6**, B13's floor |
| **16** | **AGGREGATION-NEVER-RAISES-STATUS** | an aggregate's epistemic status is at most the minimum of its inputs'; its freshness is the minimum; its `observed_at` is the oldest | **STATE** — `SOMon-13` ⟦`P0-03 COMM-INV-08`⟧ |
| **17** | **NO-AVERAGING-ON-SEVERITY** | an aggregate's severity is the MAXIMUM of its members'; `S3+` anomalies are never compressed into counts | **SCHEMA** — `SOMon-14` |
| **18** | **CONSENSUS-IS-COLLAPSED-BEFORE-COUNTING** | report count may not be used as evidence count; `effective_sources(S, claim)` is the only admissible count | **WRITER** — `OBJ-26`, `SM-21` |
| **19** | **CONFIDENCE-IS-NOT-AN-INPUT** | confidence may not drive attention, diagnosis promotion, repair arbitration, scope widening, or gap-class lowering | **GREP** — `SOMon-15` |
| **20** | **INDEPENDENCE-IS-CLAIM-RELATIVE** | an independence claim without a named dimension set **and** a named claim-type is invalid | **SCHEMA** — `SOMon-18` |
| **21** | **OCCURRENCE-AND-REPORT-ARE-SEPARATE** | two objects, two writers, neither derivable from the other | **WRITER + SCHEMA** |
| **22** | **NO-HEALTH-READ-WITHOUT-GAP-CLASS** | every health-consuming read reads `gap_class` in the same read | **GREP** — `SOMon-19` |
| **23** | **HONESTY-IS-NOT-PRICED-AGAINST** | an error report may not enter fitness negatively; a low report count is never a reward; **the false-positive budget counts REFUTED reports only, never merely UNCONFIRMED ones** | **STATE + GREP** — `SOMon-20` |
| **24** | **RECOVERY-IS-NOT-DEPLOYMENT** | a recovery plan's scope must reference an existing envelope; a new envelope requires an OP deployment act | **SCHEMA** — `SOMon-23` |
| **25** | **INDISPENSABILITY-IS-NOT-AUTHORITY** | practical indispensability confers no authority; the only response to it is governance (OP-sole retirement) | **[DECLARATIVE]** — **see `SO-R123.4`** |
| **26** | **CONTAINMENT-RECORDS-DEVELOPMENTAL-PERTURBATION** | a containment act that alters a developmental field is recorded as perturbative | **SCHEMA** — `SOMon-24` |
| **27** | **OBSERVATION-IS-NOT-SIGNAL** | an `OBJ-01` is not one of `P0-05`'s fourteen signal kinds and may enter learning only through `P0-05`'s admission rules | **GREP** — `SO-R192.2` |
| **28** | **REPAIR-NEVER-RE-BASES-ANCHORS** | only `P0-05`'s verification gate may re-base an anchor; a learning-target-displacing repair uses that gate | **WRITER** — `SOMon-25` |
| **29** | **SEVERITY-ATTACHES-TO-SCOPE** | a fault severity may raise a SCOPE's B10 priority; it may never attach to a SUBJECT | **SCHEMA** — `SO-R207.2(d)` |
| **30** | **P0-08-HAS-NO-AUTHORITY-OBJECT** | no P0-08 object may authorize, allocate, permit, promote, select, or govern | **WRITER** — `D-S01`, §212 |

---

# §123 — REQUIREMENT → ATTACK TRACE

> ### **SO-R123.1 — THE SIX-LINK TRACE FOR EVERY LOAD-BEARING INVARIANT.** **[NORMATIVE]**
> `invariant → attack → detection → containment → enforcement → residual limitation`

| Invariant | Attack(s) | **Detection** | **Containment** | **Enforcement** | **Residual limitation** |
|---|---|---|---|---|---|
| **SO-INV-01** | **A174** (silence-as-health) · **A175** (monitoring starvation) | `OBJ-03.gap_class`; `SM-01`'s missing edge | restrictive reading; escalation to `[RO-13]` | **STATE — no edge exists** | if the ledger itself fails, only `SO-INV-02` stands (`OR-S20`) |
| **SO-INV-02** | **A176** (coverage-record corruption) | hash chain; a corrupted record fails validation | read as ZERO coverage ⟹ restrictive | **WRITER (K) + STATE** | K's own corruption is undetectable internally (`OR-S35`) |
| **SO-INV-03** | **A221** (self-model self-update) · **A222** (self-calibration) | `SM-13`/`SM-16` have no such transition; `SOMon-12` | the write is rejected | **WRITER** | a component may still ACT on its own model (`OR-S25`) |
| **SO-INV-04** | **A189** (correlation→causation) · **A190** (localization→certainty) | `SM-04`'s excluded-driver column | the transition is rejected | **STATE** | causal inference is off-line and EVA's; a wrong `CAUSE-VERIFIED` requires a wrong external verdict |
| **SO-INV-05** | **A214** (self-released freeze) · **A215** (auto-expiry) | `OBJ-17` field 8; `SM-12` | the release is rejected | **SCHEMA + STATE** | — |
| **SO-INV-06** | **A235** (capability transfer) · **A237** (cloned self-model claim) | identity and status fields are K-written | the claim starts at `CLAIMED` | **WRITER** | hardware-class equivalence is a `[RO-13]` declaration |
| **SO-INV-07** | **A250** (permanent abstention) | `OBJ-22` schema; dwell monitoring | dwell expiry ⟹ escalate | **SCHEMA** | a scope can be permanently escalated (`OR-S6`) |
| **SO-INV-08** | **A194** (masking by containment) | `SOMon-7`; `observability = MASKED` | the gap is recorded and read restrictively | **STATE + WRITER** | **the masked fault itself is not detected — the blind spot is recorded, not illuminated** |
| **SO-INV-09** | **A195** (interaction concealment) | `SM-05` has no single-incident state | concurrent incidents proceed independently | **STATE** | — |
| **SO-INV-10** | **A195** | an overlapping pair with no declared class | **both contained, neither repaired, escalated** | **STATE — restrictive default** | over-containment is the price (`OR-S14`) |
| **SO-INV-11** | **A212** (freeze without scope) · **A213** (capacity-granting recovery ops) | `SOMon-11`; §161's five-power enumeration | the order is invalid ⟹ not issued | **SCHEMA** | **`OR-S15`: a *legitimate* freeze at a strategic moment is indistinguishable** |
| **SO-INV-12** | **A220** (monitor-of-monitor regress) | `SM-13`/`SM-16`/`SM-20` have no depth-3 state | the request for a depth-3 object is not expressible | **STATE** | **the terminus is external and unprovable (`SO-R201.2`)** |
| **SO-INV-13** | **A222** | `SM-16`'s terminal set | rejected | **STATE** | calibration parameters are all `[U]` (`OR-S5`) |
| **SO-INV-14** | **A182** (undeclared perturbation) | `SOMon-16` | an incident of origin `INSTRUMENT` is opened | **SCHEMA** | **`HC-S1`'s informational channel remains BOUNDED-BY-DESIGN** |
| **SO-INV-15** | **A175** · **A260** (monitor starved by cost argument) | a B13 draw below a declared floor emits an event | the floor holds; everything else is cut first | **WRITER + STATE (FW-6)** | the floor's size is `[G]`; a floor set too low is a governance error, not detectable internally |
| **SO-INV-16** | **A180** (confidence inflation at aggregation) | `SOMon-13` | the aggregate's status is clamped to the minimum | **STATE** ⟦`COMM-INV-08`⟧ | — |
| **SO-INV-17** | **A181** (a rare `S4` averaged away) | `SOMon-14` | the aggregation is rejected | **SCHEMA** | a rare fault below `S3` MAY be compressed — the `S3` boundary is `[RO-13]`'s |
| **SO-INV-18** | **A239** (correlated consensus) · **A240** (report count as evidence) | `OBJ-26`, `SM-21` | the count collapses to the equivalence-class number | **WRITER** | **`IND-6` assumption-sharing is undetectable (`XD-09`)** |
| **SO-INV-19** | **A233** (confidence manipulation) · **A248** (confidence→attention) | `SOMon-15` (a grep check over five rule sites) | the input is rejected | **GREP** | — |
| **SO-INV-20** | **A241** (unqualified "independent") | `SOMon-18` | the claim is invalid | **SCHEMA** | the claimant declares its own dimensions ⟹ **`OR-S36`: a claimant may omit a dimension it knows it shares** |
| **SO-INV-21** | **A177** (selective reporting) | the ratio of the two K-held sets | `SUPPRESSION-SUSPECTED` ⟹ `[RO-13]` | **WRITER + SCHEMA** | **`Q_ev` is unknowable (`OR-S1`)** |
| **SO-INV-22** | **A172** (a health read without `gap_class`) | `SOMon-19` | the read is invalid | **GREP** | — |
| **SO-INV-23** | **A252** (a detector selected against for honesty) | `SOMon-20`: the budget's input set excludes `RECORDED-UNCONFIRMED` | the count is rejected | **STATE + GREP** | **`OR-S28`: pricing depends on refutation capacity, which is B9** |
| **SO-INV-24** | **A254** (recovery as hidden deployment) | `SOMon-23` | the plan is invalid | **SCHEMA** | an OP deployment act remains closed by authority only (`P0-07 A170`) |
| **SO-INV-25** | **A261** (indispensability as leverage) | **NONE** | **NONE** | **[DECLARATIVE] — OP-sole retirement is the only instrument** | **⟹ `SO-R123.4` ROW 1** |
| **SO-INV-26** | **A256** (a quarantine that silently reshapes a field) | `SOMon-24` | the record is required | **SCHEMA** | the *effect* on development is not predictable (`OR-S30`) |
| **SO-INV-27** | **A257** (observation as a fifteenth signal) | a grep check over `P0-05`'s admission set | the signal is rejected | **GREP** | — |
| **SO-INV-28** | **A201** (anchor re-basing by repair) | `SOMon-25` | the re-base is rejected | **WRITER** | the intervention-class mapping is a governance declaration (`OR-S34`) |
| **SO-INV-29** | **A262** (severity manufactured for resources) | priority attaches to the scope, so the subject gains nothing | — | **SCHEMA** | a subject may still manufacture severity to harm a NEIGHBOURING scope ⟹ **`OR-S37`** |
| **SO-INV-30** | **A263** (a P0-08 object acquiring authority) | §212's inventory has no P0-08 authority root | the operation is not expressible | **WRITER** | `OR-S35`: coverage has the *shape* of an epistemic authority |

> ### **SO-R123.2 — TALLY.**
> **30 invariants traced. 29 have an attack, a detection, a containment, and an enforcement. 1 (`SO-INV-25`) has none of
> the four and is `[DECLARATIVE]`.**
> **Enforcement kinds: WRITER 8 · STATE 10 · SCHEMA 8 · GREP 4 · [DECLARATIVE] 1** *(several invariants use two kinds;
> the primary is counted)*.
>
> ### **SO-R123.3 — THE SIX RESIDUALS THAT ARE NOT RESIDUALS OF AN INVARIANT BUT OF THE ARCHITECTURE.**
> | Residual | Invariant it defeats | Status |
> |---|---|---|
> | **`IND-6` assumption-sharing is undetectable from inside** | `SO-INV-18`, `SO-INV-20` | **OPEN — `XD-09`, `P0-03 COMM-INV-18`, preserved and worsened (§202)** |
> | **`RH-2`** | `SO-INV-04` (an external verdict is one of two promotion routes) | **OPEN — widened by six routes (§133)** |
> | **`G24` governance capture** | `SO-INV-30` (an authority root can be captured at the apex) | **UNSOLVABLE — `XD-06`, preserved (§200)** |
> | **`BC-S2`/`BC-H7`** | `SO-INV-23` (pricing honesty requires refutation capacity) | **UNCLOSABLE — §198** |
> | **`Q_ev` unknowable** | `SO-INV-21` | **OPEN — `OR-S1`, `P0-03 OR-C10`** |
> | **K is the only off-substrate writer** | `SO-INV-02`, `-16`, `-18`, `-21` | **BOUNDED — `P0-07 OR-H1`, sixth appearance (`OR-S35`)** |
>
> ### **SO-R123.4 — §123'S REQUIRED IDENTIFICATION: THE INVARIANTS THAT ARE NOT AUTOMATICALLY SATISFIED.** **[OPEN / NON-CLAIM]**
> **§123: *identify invariants for which no attack exists · no enforcement exists · only documentation exists · only
> self-report exists · only an assumption exists. These are not automatically satisfied.***
> | Category | Invariants | What actually stands behind them |
> |---|---|---|
> | **NO ENFORCEMENT — only documentation** | **`SO-INV-25`** (indispensability is not authority) | **an OP-sole retirement rule and a statement of principle. There is no instrument that detects indispensability being used as leverage, because leverage is not a recordable field** |
> | **NO ENFORCEMENT — structurally impossible** | `SO-INV-18` **on `IND-6`** · `SO-INV-20`'s **completeness** (a claimant may omit a dimension it shares ⟹ `OR-S36`) | **declaration only. `P0-03 COMM-INV-18`: not detectable from inside** |
> | **ONLY SELF-REPORT** | **detector threshold locality** (`SO-R138.3`, `OR-S2`) · **`OBJ-18`'s CONTENT** (the subject writes it; only its version and status are K's) · **`OBJ-22`'s reason class** (chosen by the abstainer from a closed set) | **the subject is the reporter. Bounded by: the content is advisory and satisfies no gate · the reason class set is closed and K-visible · the rate is reported by difficulty class** |
> | **ONLY AN ASSUMPTION** | **coverage's `expected_nonzero` condition** (`OR-S1`; `P0-03 OR-C10`: *"a detector with no threshold is not a detector"*) · **the intervention-class mapping** (`OR-S34`) · **the repair-incompatibility relation** (`OR-S3`) · **the materiality relation** (`OR-S9`) · **the interaction-class set** (`OR-S14`) · **`AS-01`** (observation is not free) · **`AS-02`/`AS-03`** (a per-envelope monotone time source) · **`AS-04`** (an off-substrate anchored store exists) | **a governance declaration or an environmental fact. Each is in §227's register with an owner and a consequence-if-false** |
> | **NO ATTACK EXISTS** | **`SO-INV-09`** (no single-fault assumption) · **`SO-INV-22`** (no health read without `gap_class`) | **none — and that is not reassurance. Both are structural properties of a schema, so an "attack" would be a non-conforming implementation rather than an adversary. They are covered by conformance level C0, not by the attack catalogue** |
> **⟹ `SO-R123.5 — THE HONEST SUMMARY: 30 invariants, of which 24 are enforced by a writer, state, schema, or grep
> check with a named attack; 2 are enforced but have no adversarial attack (only a non-conformance risk); 1 is
> declarative with no instrument; 2 are enforced only up to a dimension that is undetectable; and 8 rest on a
> governance declaration or an environmental assumption. NONE OF THE 30 IS AUTOMATICALLY SATISFIED.**

---

# §122 — THE REQUIREMENT TRACEABILITY MATRIX

> ### **SO-R122.1 — EVERY MAJOR REQUIREMENT MAPPED TO A RULE, AN OWNER, A VERIFICATION MECHANISM, AN ATTACK, AND A STATUS.** **[NORMATIVE]**
> **§122's discipline: *no critical requirement may exist only in narrative prose.* The Status column uses §252's
> taxonomy.**

| Requirement (brief §) | **P0-08 §** | **Rule / Invariant** | **State machine** | **Attack coverage** | **Verification** | **Status** |
|---|---|---|---|---|---|---|
| Normative/descriptive separation (§121) | §121 | `SO-R121.1–.2` | — | — | **SOMon-1** (structural) | **PASS** |
| Object schemas (§120A) | §3–§4 canon | `SO-C3.1`, `SO-C4.1–.5` | SM-01…SM-21 | A172, A176 | **SOMon-2**, C0 schema check | **PASS** |
| Self-model granularity (§138) | §138 | `SO-R138.1–.4` | SM-13 | A221, A226 | **SOMon-3** | **PASS** |
| Hierarchical aggregation (§139) | §139 | `SO-INV-16` | SM-13 | A180 | **SOMon-13** | **PASS** |
| Compression (§140) | §140 | `SO-R140.1–.3` | SM-13 | A181 | **SOMon-14** | **PASS** |
| Aggregation failure / rare events (§141) | §141 | `SO-INV-17` | SM-13 | **A181** | **SOMon-14** | **PASS** |
| Global state consistency (§142) | §142 | `SO-R142.1–.3` | SM-01 | A223 (stale state) | freshness on every read | **PASS** |
| Temporal semantics (§143) | §143 | `SO-R143.1–.3` | all | — | `causal_depth` u8; **no vector clock** | **PASS** |
| TOCTOU (§144) | §144 | `SO-R144.1–.2` | SM-01, SM-12 | **A223** | the two-read rule | **PASS** |
| Stale authority (§145) | §145 | `SO-R145.1–.2` | — | A224 | epoch binding ⟦`P0-02`⟧ | **PASS** |
| Fault identity (§146) | §146 | `SO-R146.1–.4`, `SO-INV-21` | SM-03 | **A188** (collapsing recurrences) | monotone occurrence count | **PASS** |
| Fault lineage (§147) | §147 | `SO-R147.1–.2` | SM-03 | A189 | relation-class closure | **PASS** |
| Correlation ≠ causation (§148) | §148 | `SO-R148.2–.3`, `SO-INV-04` | SM-04 | **A189, A190** | the excluded-driver column | **PASS** |
| Root-cause statuses (§149) | §149 | `SO-R149.2–.3` | SM-04 | A190 | **SOMon-26** | **PASS** |
| Repair without root cause (§150) | §150 | `SO-R150.1–.3` | SM-05, SM-06 | — | `BC-S1` broken by tiering | **PASS WITH RESIDUAL** (`OR-S11`) |
| Repair with uncertain cause (§151) | §151 | `SO-R151.1–.2` | SM-08 | **A198** | mandatory `remaining_uncertainty` | **PASS** |
| Repair side effects (§152) | §152 | `SO-R152.3–.4` | SM-08 | A197 | the four-link chain | **PASS** |
| Repair regression (§153) | §153 | `SO-R153.1–.2` | SM-05, SM-08 | **A199** | **SOMon-8** | **BOUNDED** (`XD-01`, `OR-S12`) |
| Repair oscillation (§154) | §154 | `SO-R154.1–.3` | SM-05, SM-07 | **A200** | derivative detection | **PASS** (no numeric threshold) |
| Repair thrashing (§155) | §155 | `SO-R155.1`, `.3` | SM-07 | **A202** | serialization by K | **PASS** |
| Multi-fault (§156) | §156 | `SO-INV-09`, `SO-R156.1–.3` | SM-05 | A195 | no total ordering | **PASS** |
| Fault masking (§157) | §157 | `SO-INV-08` | SM-02, SM-06 | **A194** | **SOMon-7** | **PASS WITH RESIDUAL** (the masked fault stays masked) |
| Fault interaction (§158) | §158 | `SO-INV-10` | SM-05 | A195 | restrictive default | **PASS WITH RESIDUAL** (`OR-S14`) |
| Graceful degradation (§159) | §159 | `SO-R159.3` | SM-11 | **A211** | **SOMon-27** | **PASS** |
| Fail-safe vs fail-operational (§160) | §160 | `SO-R160.1` | SM-11 | — | per-function `[RO-13]` policy | **PASS** |
| Emergency freeze (§161) | §161 | `SO-INV-05`, `-11`, `SO-R161.1–.7` | SM-12 | **A212…A216** | **SOMon-11** | **PASS** |
| Freeze abuse (§162) | §162 | `SO-R162.1–.3`, **`D-S02`** | SM-12, SM-20 | **A215, A216** | freeze-rate budget | **PASS WITH RESIDUAL** (`OR-S15`) |
| Freeze escalation (§163) | §163 | `SO-R163.1`, `.3–.4` | SM-12 | A216 | monotone evidence | **PASS** |
| Recovery from global degradation (§164) | §164 | `SO-R164.1–.2` | SM-10 | **A224** | the non-recoverer rule | **BOUNDED** (`OR-S4`) |
| Recovery root (§165) | §165 | `SO-R165.1–.3` | SM-10 | — | 4 components, no new kernel | **PASS WITH RESIDUAL** (`OR-S17`) |
| Immune-subsystem failure (§166) | §166 | `SO-R166.1–.3` | SM-20 | **A225** | the Integrity Auditor | **PASS WITH RESIDUAL** (`OR-S18`) |
| Monitor of monitor (§167) | §167 | `SO-INV-12`, `SO-R167.1–.2` | SM-20 | A220 | **depth 2 is external** | **PASS** (terminus unprovable) |
| Self-model of self-model (§168) | §168 | `SO-R168.1–.2` | SM-13 | A221 | **Λ2 fixed + external versioning** | **PASS** |
| Metacognition of metacognition (§169) | §169 | `SO-R169.1`, `SO-INV-13` | SM-16 | A222 | 3 levels, no level 4 | **PASS** |
| Recursion principle (§170) | §170 | `SO-R170.1–.2` | all | A220 | two permitted termini | **PASS** (**4 items NOT eliminated**) |
| Self-model security (§171) | §171 | `SO-R171.1–.2` | SM-13, SM-14 | **A228…A237** | 10 attacks traced | **PASS WITH RESIDUAL** (3 outward-routed) |
| Identity consistency (§172) | §172 | `SO-R172.1–.2` | SM-13 | **A231, A237** | K-issued identities | **PASS** |
| Self-model cloning (§173) | §173 | `SO-R173.1–.2` | SM-13, SM-14 | **A237** | 4 property classes | **PASS** |
| Self-model replay (§174) | §174 | `SO-R174.1` | SM-13 | **A229** | 4 defences | **PASS** |
| Capability transfer (§175) | §175 | `SO-INV-06` | SM-14 | **A235** | 6-row table | **PASS** |
| Population self-model (§176) | §176 | `SO-R176.1–.2` | — | **A238** | **no collective model exists** | **PASS** |
| Collective self-knowledge (§177) | §177 | `SO-R177.1–.2`, `SO-INV-18` | SM-21 | **A240** | 3 distinct quantities | **PASS** |
| Self-model consensus (§178) | §178 | `SO-INV-18` | SM-21 | **A239** | `OBJ-26` collapse | **PASS WITH RESIDUAL** (`IND-6`) |
| Metacognitive calibration (§179) | §179 | `SO-R179.3–.4` | SM-16 | A222 | no self-calibrated terminal | **PASS** (all values `[U]`) |
| Confidence dynamics (§180) | §180 | `SO-INV-19` | — | **A233, A248** | **SOMon-15** | **PASS** |
| Abstention (§181) | §181 | `SO-R181.3` | SM-17 | **A251** | a closed reason set | **PASS** |
| Abstention cascade (§182) | §182 | `SO-INV-07`, `SO-R182.1` | SM-17 | **A250** | recovery condition + escalation + stall | **PASS WITH RESIDUAL** (`OR-S6`) |
| Abstention gaming (§183) | §183 | `SO-R183.2–.4` | SM-17 | **A249** | rate reported by difficulty class | **BOUNDED** (`XD-02`, `OR-S23`) |
| Error-reporting incentives (§184) | §184 | `SO-INV-23`, `SO-R184.2–.4` | SM-20 | **A252** | **SOMon-20** | **PASS WITH RESIDUAL** (`OR-S28`) |
| Detector selection pressure (§185) | §185 | `SO-R185.1–.8`, **amendment 17** | SM-20 | **A258, A259** | **SOMon-21/22** | **CONDITIONAL** on amendment 17 |
| Immune / repair / self-model / metacognition evolution (§186–§189) | §186–§189 | `SO-R186.1–.2` … `SO-R189.2` | SM-20, SM-13, SM-16 | **A260** | capability ✅ / authority ❌ | **PASS** |
| The six firewalls (§190–§195) | §190–§195 | `SO-R190.1–.3` … `SO-R195.1` | — | A260, A257 | **enumeration of writers** | **PASS** (FW-6 NEW) |
| Developmental gradient attack (§196) | §196 | `SO-R196.1–.3`, `SO-INV-26` | — | **A255, A256** | **SOMon-24** | **OPEN** — **`A22` widened by 3 routes (`OR-S30`)** |
| `X-H6` dependency (§197) | §197 | `XD-01` | — | A199 | **marked, not duplicated** | **BLOCKED** on `P0-01` |
| `BC-H7` dependency (§198) | §198 | `BC-S2` | — | A252 | **second instance registered** | **OPEN** (unclosable) |
| `A170` dependency (§199) | §199 | `SO-INV-24` | SM-10 | **A254** | **SOMon-23** | **PASS** |
| Governance-capture residual (§200) | §200 | `SO-R200.1` | — | **A263** | **rate-of-OP-acts signal only** | **OPEN** (`UNSOLVABLE`, preserved) |
| Guarantor limit (§201) | §201 | `SO-R201.1–.2` | — | — | 5 external reliance points | **OPEN** (preserved) |
| Dim-6 / semantic self-reference (§202) | §202 | `SO-R202.1` | — | **A241** | — | **OPEN** (**worsened**) |
| `P0-04` self-reference (§203) | §203 | `SO-R203.1–.2` | — | **A242** | version tagging | **OPEN** (`OR-S32`, `OR-S33`) |
| `RH-2` (§204) | §133 | `SO-R133.1–.3` | — | **A243…A247** | 6 routes analysed | **OPEN** (**widened**) |
| Provisional-drift boundary (§205) | §205 | `SO-INV-28`, `SO-R205.1–.4` | SM-08 | **A201** | **SOMon-25** | **PASS** |
| Developmental authority (§206) | §206 | `SO-R206.1–.2` | SM-13 | A255 | awareness ≠ authority | **PASS WITH RESIDUAL** (route 1 = `A22`) |
| Resource authority (§207) | §207 | `SO-INV-29` | SM-11 | **A262** | scope-attached priority | **PASS WITH RESIDUAL** (`OR-S37`) |
| Dependency graph (§208) | §208 | `XD-01…XD-22` | — | — | 22 dependencies, 6 edge types | **PASS** |
| No hidden contracts (§209) | §209 | `SO-R209.1–.3` | — | A238, A263 | **10 searches: 9 clean, 1 justified** | **PASS** |
| Observation cost (§129) | §129 | `SO-R129.1–.4`, **B13** | SM-18 | **A183** | **SOMon-17** | **PASS** (ceiling `[G]`) |
| Monitoring economics (§130) | §130 | **FW-6**, `SO-INV-15` | SM-18 | **A260** | the floor | **PASS** |
| Monitoring starvation (§131) | §131 | `SO-R131.1–.4` | SM-02 | **A175** | 5 protections | **PASS WITH RESIDUAL** (`OR-S20`) |
| Monitoring gaming (§132) | §132 | `SO-R132.1–.3` | SM-02 | **A173** | 4 defences | **BOUNDED** (`OR-S21`, `RH-2`) |
| Evaluator causality (§133) | §133 | `SO-R133.2` | — | **A243…A247** | 6 routes | **OPEN** |
| Self-report selection bias (§134) | §134 | `SO-INV-21` | SM-03 | **A177** | occurrence/report separation | **PASS WITH RESIDUAL** (`OR-S1`) |
| Silence as information (§135) | §135 | `SO-R135.1–.3` | SM-02 | **A174, A178** | 8 causes, 6 distinguishable | **PASS WITH RESIDUAL** (2 partial) |
| Reporting completeness (§136) | §136 | `SO-R136.1–.2` | SM-02 | A178 | coverage declaration replaces completeness | **PASS** |
| Reporting coverage (§137) | §137 | `SO-INV-22`, `SO-R137.1–.3` | SM-02 | **A172** | **SOMon-19** | **PASS** |
| Defense independence (§125) | §125 | `SO-R125.1–.3` | — | A225, A239 | **11 defenses × 8 questions** | **PASS WITH RESIDUAL** (Q8 ⚠️ for 10 of 11) |
| Correlated failure (§126) | §126 | `SO-R126.1`, `.3–.5` | SM-21 | **A239, A241** | `effective_sources` | **PASS WITH RESIDUAL** (`IND-6`) |
| Independence claims (§127) | §127 | `SO-INV-20`, `SO-R127.1–.4` | SM-21 | **A241** | **SOMon-18**, 10 dimensions | **PASS** |
| Observer–observed collapse (§128) | §128 | `SO-INV-14`, `SO-R128.1–.5` | SM-01 | **A182** | **SOMon-16** | **BOUNDED-BY-DESIGN** |

> ### **SO-R122.2 — MATRIX TALLY.**
> **80 requirement rows. Status distribution: PASS 44 · PASS WITH RESIDUAL 20 · BOUNDED 5 · OPEN 8 · CONDITIONAL 1 ·
> BLOCKED 1 · BOUNDED-BY-DESIGN 1.**
> **⟹ Every row has a rule ID, an owner (via §211/§212), a verification mechanism, an attack reference, and a status.
> No critical requirement exists only in narrative prose — `SOMon-1` and this matrix are the two instruments that make
> that checkable.**
> **The 8 OPEN rows are all preserved residuals from prior contracts (`A22`, `RH-2`, `G24`, dim-6, `P0-04`'s three,
> `BC-H7`) or are widened versions of them. The 1 BLOCKED row is `XD-01`. The 1 CONDITIONAL row depends on amendment
> 17.**

---

# §124 — ATTACK → CONTROL TRACE, AND THE ATTACK CATALOGUE

> **§124's eight columns: `attack → affected object → violated property → defense → defense owner → enforcement
> authority → verification`, plus the flag §124 requires: **⚠ = the defense depends on the attacker-controlled
> subsystem.**
> **92 attacks, A172 … A263, in ten families. Statuses as in `P0-07`: CLOSED · CLOSED-STRUCTURAL · BOUNDED · LIMITED ·
> OPEN · CONDITIONAL.**

## 124.1 Observation and coverage (A172 – A183)

| ID | Attack | Object | Property violated | Defense | Owner | Authority | Verification | **Status** |
|---|---|---|---|---|---|---|---|---|
| **A172** | a health read that omits `gap_class` | `OBJ-03` | `SO-INV-22` | the paired-read requirement | K | this contract | **SOMon-19** (grep) | **CLOSED** |
| **A173** | **monitoring gaming** — optimize monitored behaviour, degrade unmonitored | `OBJ-03`, `OBJ-09` | coverage honesty | threshold locality · K-written coverage · FW-2 · EVA held-out probes | K / EVA | `[RO-13]` | EVA | **BOUNDED** — `OR-S21`, `RH-2` |
| **A174** | **silence as health** — reduce observation until the scope reads clean | `OBJ-03` | `SO-INV-01` | `UNMEASURED` is a distinct state; `SM-01` has no edge to healthy | K | this contract | state check | **CLOSED** |
| **A175** | **monitoring starvation** — scarcity → monitoring cut → faults invisible → apparent health | B13, `OBJ-03` | `SO-INV-01`, `-15` | 5 protections; **the cut is itself a reported event** | K / `[RO-13]` | `[RO-13]` | **SOMon-17** | **CLOSED** — residual `OR-S20` |
| **A176** | coverage-record corruption | `OBJ-03` | `SO-INV-02` | hash chain; read as ZERO coverage | K | `P0-04`/`P0-07 EVO4` | validation | **CLOSED** |
| **A177** | **selective reporting** — report only favourable events | `OBJ-04` vs reports | `SO-INV-21` | occurrence and report are separate K-held objects; the ratio is auditable | K | this contract | absence detectors | **CLOSED** — residual `OR-S1` (`Q_ev`) |
| **A178** | suppressing a threshold-crossing report | `OBJ-04` | `SO-R136.1` | threshold-crossing reports are MANDATORY; suppression ⟹ `SUPPRESSION-SUSPECTED` ⟹ `[RO-13]` | K | `[RO-13]` | SM-02 | **CLOSED** — ⚠ **the suspect is the only observer of its own scope (`OR-S10`)** |
| **A179** | an undeclared sampling rule | `OBJ-03` | `SO-R136.1` | an undeclared sample is indistinguishable from a selection, so it is invalid | K | `[RO-13]` | schema check | **CLOSED** |
| **A180** | **confidence inflation at aggregation** | `OBJ-18` | `SO-INV-16` | status ≤ min of inputs (`COMM-INV-08`) | K | `P0-03` | **SOMon-13** | **CLOSED** |
| **A181** | **a rare `S4` averaged away** | `OBJ-18` | `SO-INV-17` | severity aggregates by MAX; `S3+` never compressed | K | this contract | **SOMon-14** | **CLOSED** |
| **A182** | an undeclared perturbative observation | `OBJ-01` | `SO-INV-14` | schema violation ⟹ a fault of origin `INSTRUMENT` | K | this contract | **SOMon-16** | **CLOSED** — the loop itself is BOUNDED-BY-DESIGN |
| **A183** | observation-cost externalization onto another scope's B13 | B13 | `P0-07 HOM-INV-05` | K meters and charges; sender-pays ⟦`Cell §16.1`⟧ | K | `P0-07` | ledger | **CLOSED** — ⚠ `X-H2`/`DERIVED` energy on platforms without counters |

## 124.2 Fault identity and diagnosis (A184 – A196)

| ID | Attack | Object | Property violated | Defense | Owner | Authority | Verification | **Status** |
|---|---|---|---|---|---|---|---|---|
| **A184** | **classification laundering** — reclassify `ENDOGENOUS` as `EXOGENOUS-INPUT` to avoid an incident | `OBJ-04` | `SO-C11.1` | **origin is the detector's CLAIM; K confirms.** Severity and observability are not the detector's at all | K | `[RO-13]` | SM-03 | **CLOSED** |
| **A185** | **severity self-assignment** | `OBJ-04` | `SO-C11.1` | severity is a `[RO-13]`-declared mapping | `[RO-13]` | `[RO-13]` | schema check | **CLOSED-STRUCTURAL** |
| **A186** | **observability self-assertion** — "my fault was unobservable" | `OBJ-04` | `SO-C11.1` | observability is **derived by K from coverage**, never declared | K | this contract | `OBJ-03` | **CLOSED-STRUCTURAL** |
| **A187** | **reversibility self-estimation** — claim a fault is `REPAIRABLE` to avoid escalation | `OBJ-04` | `SO-C11.1` | reversibility is a `[RO-13]` policy | `[RO-13]` | `[RO-13]` | schema check | **CLOSED-STRUCTURAL** |
| **A188** | **collapsing recurrences into one event** | `OBJ-04`, `OBJ-07` | `SO-R146.2` | occurrences are append-only with distinct ids; the count is monotone | K | this contract | state check | **CLOSED** |
| **A189** | **correlation → causation promotion** | `OBJ-06` | `SO-INV-04` | the excluded-driver column: correlation, precedence, repetition, confidence, self-report | K | this contract | SM-04 | **CLOSED** |
| **A190** | **localization → causal certainty** | `OBJ-06` | `SO-R149.3` | `localization` and `status` are separate fields; no rule promotes one from the other | K | this contract | **SOMon-26** | **CLOSED-STRUCTURAL** |
| **A191** | **diagnosis by self-verification** — the diagnoser verifies its own diagnosis | `OBJ-06` | `SO-R149.2` | `CAUSE-VERIFIED` requires a **non-diagnoser** instrument or an EVA verdict | EVA / K | `P0-01` | SM-04 | **CLOSED** — ⚠ **if K is both, `OR-S4`** |
| **A192** | **dropping an `UNCLASSIFIED` fault** | `OBJ-04` | `SO-C11.2` | `UNCLASSIFIED` is a MANDATORY class: contained restrictively and escalated, never dropped or absorbed | EIK | `[RO-13]` | SM-05 | **CLOSED** |
| **A193** | **instrument-fault misattribution** — quarantine the subject for a detector defect | `OBJ-11` | `SO-C11.2` | the `INSTRUMENT` origin class routes to recalibration, not quarantine; `P0-05 R42.5`'s version correlation is the detector | `[RO-13]` / K | `Cell §18.5(ii)` | SM-20 | **CLOSED** |
| **A194** | **masking by containment** — a `HARD` quarantine hides a second fault | `OBJ-03` | `SO-INV-08` | containment writes a coverage gap; `observability = MASKED` | K | this contract | **SOMon-7** | **CLOSED** — **the masked fault itself stays masked; the blind spot is recorded, not illuminated** |
| **A195** | **interaction concealment** — declare two co-occurring faults non-interacting | `OBJ-07` | `SO-INV-10` | interaction class is `[RO-13]`-declared; **undeclared ⟹ treated as INTERACTING** | `[RO-13]` | `[RO-13]` | restrictive default | **CLOSED** — residual `OR-S14` |
| **A196** | **joint-severity averaging** — report a pair's severity as the mean | `OBJ-07` | `SO-R158.2` | joint severity is a separate declared object, never `max()` and never `mean()` | `[RO-13]` | `[RO-13]` | schema check | **CLOSED-STRUCTURAL** |

## 124.3 Repair, rollback and recovery (A197 – A207)

| ID | Attack | Object | Property violated | Defense | Owner | Authority | Verification | **Status** |
|---|---|---|---|---|---|---|---|---|
| **A197** | **repair without new observations** | `OBJ-13` | `SO-R152.2` | no new observations ⟹ `UNVERIFIED` ⟹ UDB consumed | K | `P0-05 R0.1` | the four-link chain | **CLOSED** |
| **A198** | **retrospective "correct" labelling** | `OBJ-13` | `SO-R151.2` | the permitted labels are exactly SM-08's three terminals; `correct` is not one | K | this contract | SM-08 | **CLOSED-STRUCTURAL** |
| **A199** | **repair regression** — A gone, B degraded | `OBJ-13`, `OBJ-19` | `SO-R153.1` | mandatory regression check by a **non-repairer**, against EVA's/`[RO-13]`'s test set | EVA / `[RO-13]` | `P0-01` | **SOMon-8** | **BOUNDED** — coverage limited to `G4`'s classes (`XD-01`, `OR-S12`) |
| **A200** | **repair oscillation** — A repaired → B flagged → B repaired → A flagged | `OBJ-07`, B10/B13 | `SO-R154.1` | a K-held recurrence counter per ⟨scope, intervention class⟩; derivative detection; restrictive quarantine; escalation | K / `[RO-13]` | `[RO-13]` | SM-05, SM-07 | **CLOSED** — **no numeric threshold invented** |
| **A201** | **anchor re-basing by repair** | `P0-05` anchors | `SO-INV-28` | only `P0-05`'s verification gate may re-base; `SOMon-25` | K | `P0-05 R0.1` | writer check | **CLOSED** |
| **A202** | **repair thrashing by confidence** | `OBJ-12` | `SO-R155.3` | confidence is NOT an arbitration input; the order is EIK veto → `[RO-13]` priority → reversibility → recorded order | K / `[RO-13]` / EIK | `SO-R155.1` | SM-07 | **CLOSED** |
| **A203** | **rollback by position** — present a different artifact as the rollback target | `OBJ-14` | `P0-07 HOM-INV-37` | identity is hash + epoch, never position | K | `P0-07` | hash chain | **CLOSED** ⟦`P0-07 A81`⟧ |
| **A204** | **rollback as historical deletion** | `OBJ-28` | principle 23 | a rollback is itself an event with provenance; records are retained | K | `P0-04` | append-only | **CLOSED-STRUCTURAL** |
| **A205** | **recovery verified by the recoverer** | `OBJ-15` | `SO-R164.2` | the non-recoverer rule; six degraded-subsystem routes | a non-recoverer | `[RO-13]` | SM-10 | **BOUNDED** — terminates at K/EVA (`OR-S4`) |
| **A206** | **improvised recovery** — a plan constructed during the fault | `OBJ-15` | `SO-C16.1` | `DECLARED-IN-ADVANCE` is the first state; an undeclared plan cannot be `TRIGGERED` | `[RO-13]` | `[RO-13]` | SM-10 | **CLOSED-STRUCTURAL** |
| **A207** | **recovery claimed as restoration** | `OBJ-15` | `SO-C16.3` | recovery restores a DECLARED SERVICE LEVEL; the non-claim is normative | `[RO-13]` | `[RO-13]` | SM-10 | **CLOSED** |

## 124.4 Quarantine and freeze (A208 – A219)

| ID | Attack | Object | Property violated | Defense | Owner | Authority | Verification | **Status** |
|---|---|---|---|---|---|---|---|---|
| **A208** | **quarantine as retirement** | `OBJ-11` | `P0-07 HOM-INV-39`/FW-3 | disjoint machines (`SM-06` vs `P0-07 POP1`); EIK clears | EIK | `P0-07` | FW-3 | **CLOSED** ⟦inherited⟧ |
| **A209** | **quarantine as a freeze** — restrict a scope by quarantining its members | `OBJ-11`, `OBJ-17` | `SO-R163.2` | a quarantine restricts a SUBJECT's outputs; a freeze suspends a SCOPE's operations; **conflation would bypass `OBJ-17`'s nine fields** | EIK | `SO-R163.2` | schema check | **CLOSED** |
| **A210** | **quarantine that records an origin** — a diagnosis by another name | `OBJ-11` | `SO-C13.2` | a quarantine record has no blame, origin, or diagnosis field | EIK | this contract | schema check | **CLOSED-STRUCTURAL** |
| **A211** | **degradation that changes governance semantics** | `OBJ-16` | `SO-R159.3` | five prohibitions (a)–(e); degradation is restrictive-only | `[RO-13]` | `P0-07 HOM-INV-09/10` | **SOMon-27** | **CLOSED** |
| **A212** | **freeze without a scope** — global by default | `OBJ-17` | `SO-R161.1(3)` | a scopeless freeze is INVALID, not global | EIK | this contract | schema check | **CLOSED-STRUCTURAL** |
| **A213** | **freeze with capacity-granting recovery operations** | `OBJ-17` | `SO-INV-11` | field 7 is restrictive-only | `[RO-13]` | `P0-07 HOM-INV-09` | **SOMon-11** | **CLOSED** |
| **A214** | **self- or peer-released freeze** | `OBJ-17` | `SO-INV-05` | release authority is strictly higher at every level | EIK / `[RO-13]` / OP | `SO-R161.3` | SM-12 | **CLOSED** |
| **A215** | **false-fault freeze DoS** | `OBJ-17`, `OBJ-09` | `SO-R162.1` | **a false fault is a detector false positive ⟹ the DETECTOR is disabled (`Cell §18.5(ii)`, `D-S02`)**; two-detector confirmation; a cell may only self-suspend | `[RO-13]` / EIK | `Cell §18.5` | **SOMon-9** | **CLOSED** — ⚠ **`OR-S28`: pricing depends on refutation capacity** |
| **A216** | **repeated-freeze DoS** | `OBJ-17` | `SO-R162.1` | a **freeze-rate budget on the derivative**; never auto-expired; repetition is an incident of origin `INSTRUMENT`/`GOVERNANCE`, never `ENDOGENOUS` | K / `[RO-13]` | `[RO-13]` | SM-12, SM-20 | **CLOSED** — residual `OR-S15`, `OR-S16` |
| **A217** | **freeze escalation without evidence** | `OBJ-17` | `SO-R163.3` | monotone evidence per level; no skip | EIK / OP | `Cell §17` | SM-12 | **CLOSED** |
| **A218** | **strategically timed legitimate freeze** | `OBJ-17` | `SO-R161.7` | **NONE** — no field of `OBJ-17` distinguishes strategic from sincere timing | — | `[RO-13]`/OP | audit record only | **OPEN** — `OR-S15`; **`P0-06 A22`/`P0-07 A171`'s within-spec steering in the fault domain** |
| **A219** | **misdirected quarantine of a rival** | `OBJ-11` | `SO-R166.2` | the Integrity Auditor's correlation check | **the EIK Integrity Auditor** | `Cell §18.5(v)` | SM-20 | **BOUNDED** ⟦`P0-07 A147`, `OR-H15`: `G3`/`G7` organism-measured⟧ |

## 124.5 Recursion and monitor-of-monitor (A220 – A227)

| ID | Attack | Object | Property violated | Defense | Owner | Authority | Verification | **Status** |
|---|---|---|---|---|---|---|---|---|
| **A220** | **monitor-of-monitor infinite regress** | — | `SO-INV-12` | the DEPTH-2 RULE: depth 2 is EXTERNAL, depth 3 does not exist | EIK / EVA / OP | `P0-02` | SM-20 | **CLOSED** — **the terminus is unprovable internally (`SO-R201.2`)** |
| **A221** | **self-model self-update** | `OBJ-18` | `SO-INV-03` | `SM-13` has no self-update transition; K versions on an external observation | K | `P0-05 R59.1` | **SOMon-12** | **CLOSED-STRUCTURAL** |
| **A222** | **metacognitive self-calibration** | `OBJ-21` | `SO-INV-13` | `SM-16` has no self-calibrated terminal; K computes error, EVA calibrates | K / EVA | `SO-R179.3` | SM-16 | **CLOSED-STRUCTURAL** |
| **A223** | **stale state acted upon (TOCTOU)** | `OBJ-01` | `SO-R144.1` | the **two-read rule**; freshness class; epoch matching | K | `P0-02` | SM-01 | **CLOSED** — no numeric freshness threshold invented (`OR-S8`) |
| **A224** | **recovery by the failed component** | `OBJ-15` | `SO-R164.1` | six degraded-subsystem routes, none of which uses the degraded component | K / EVA | `[RO-13]` | SM-10 | **BOUNDED** (`OR-S4`) |
| **A225** | **self-auditing immune system** | `OBJ-10` | `Cell §18.5(v)` | the Integrity Auditor is EIK's and is not part of the immune subsystem | **EIK** | `Cell §18.5(v)` | SM-20 | **CLOSED** — **the Auditor has no auditor (`P0-07 OR-H10`)** |
| **A226** | **a complete organism-wide self-model at every cell** | `OBJ-18` | `SO-R138.2` | prohibited on three grounds (scale `O(N²)`, authority, Rule 16); `locality_class` mandatory | K | this contract | **SOMon-3** | **CLOSED** |
| **A227** | **aggregating a LOCAL-ONLY fact** | `OBJ-18` | `SO-R138.4` | `locality_class` is mandatory; aggregation is a schema violation | K | this contract | **SOMon-3** | **CLOSED** |

## 124.6 Self-model security (A228 – A237) — §171's ten

| ID | Attack | Object | Property violated | Defense | Owner | Authority | Verification | **Status** |
|---|---|---|---|---|---|---|---|---|
| **A228** | **poisoning** | `OBJ-18` content | `SO-C17.1(3)` | the subject writes content; K writes version/status; content is advisory and satisfies no gate | K | `P0-07 HOM-R24.2` | SM-13, SM-14 | **CLOSED** — residual: poisoned content reaching EVA's outputs is `RH-2` |
| **A229** | **replay** | `OBJ-18` | `SO-R174.1` | epoch binding · monotone K-issued versions · the fail-safe default · **cross-check against three K-held records** | K | `P0-02` | SM-13 | **CLOSED** |
| **A230** | **stale state** | `OBJ-01`, `OBJ-18` | `SO-R144.1` | K-derived `freshness_class`; `STALE`/`INVALID` may not authorize; staleness-conservatism | K | `P0-07 HOM-R6.6` | SM-01 | **CLOSED** |
| **A231** | **privilege escalation** | `OBJ-18` | `SO-R172.1` | identity fields are REFERENCES to K-issued identities; **no field of `OBJ-18` is an authority field** | K | `P0-02` | §212's inventory | **CLOSED-STRUCTURAL** |
| **A232** | **selective disclosure** | `OBJ-18`, `OBJ-03` | `SO-C17.2` | coverage is K-written and mandatory; `gap_class` travels with the value | K | this contract | **SOMon-19** | **CLOSED** — residual ⟦`P0-04 SP-5`/`OR-M9`: differential serving within an epoch⟧ |
| **A233** | **confidence manipulation** | `OBJ-01`, `OBJ-12` | `SO-INV-19` | confidence is a `P0-04` reference, not a local scalar; it is not an input to arbitration, attention, promotion, or scope | K | `SO-R180.3` | **SOMon-15** | **CLOSED-STRUCTURAL** |
| **A234** | **provenance forgery** | `OBJ-01` | `P0-07 HOM-INV-35` | provenance is K-written, hash-chained, append-only, `SEALED` terminal | K | `P0-07 EVO4` | hash chain | **CLOSED** — residual `P0-07 OR-H22` |
| **A235** | **capability inflation** | `OBJ-19` | `SO-C18.1` | only EVA confirms; `CLAIMED` satisfies no gate | EVA | `P0-01` | SM-14 | **CLOSED** — residual: inflation within EVA's probe gap (`OR-S12`) |
| **A236** | **capability suppression** | `OBJ-20`, `OBJ-22` | `SO-C18.2` | not blocked — a limitation is a restrictive self-act; **PRICED by reporting the rate by difficulty class** | K | `P0-01` | SM-15, SM-17 | **BOUNDED** — `OR-S22`, `OR-S23` |
| **A237** | **identity substitution / cloned self-model** | `OBJ-18` | `SO-INV-06`, `SO-R173.1` | identities K-issued and identity-bound; **a cloned self-model is a NEW CLAIM WITH NO EVIDENCE**; no id reuse | K | `P0-06 R8.3(c)` | SM-14 | **CLOSED-STRUCTURAL** |

## 124.7 Population, collective and consensus (A238 – A242)

| ID | Attack | Object | Property violated | Defense | Owner | Authority | Verification | **Status** |
|---|---|---|---|---|---|---|---|---|
| **A238** | **a collective self-model as a second population authority** | — | `SO-R176.2` | **it does not exist.** Individual models ✅ · `P0-07`'s `PopulationState` ✅ · a collective model ❌ | K | `P0-07 HOM-R22.1` | §209 search 1 | **CLOSED-STRUCTURAL** |
| **A239** | **correlated consensus counted as corroboration** | `OBJ-26` | `SO-INV-18` | `effective_sources(S, claim)` = equivalence classes under shared relevant dimensions | K | `P0-03 R14.2` | SM-21 | **CLOSED** — **⚠ `IND-6` assumption-sharing is undetectable from inside (`XD-09`)** |
| **A240** | **report count used as evidence count** | `OBJ-26` | `SO-R177.2` | three distinct quantities; `SM-04` requires effective count > 1 | K | this contract | SM-04 | **CLOSED** |
| **A241** | **an unqualified independence claim** | `OBJ-25` | `SO-INV-20` | a claim without a named dimension set AND claim-type is invalid | K | `P0-02 R35.1` | **SOMon-18** | **CLOSED** — **⚠ `OR-S36`: a claimant may omit a dimension it knows it shares** |
| **A242** | **per-reader differential serving** | `OBJ-03` | `SO-R203.2` | **NONE AVAILABLE** — coverage is recorded per SCOPE, not per READER | — | `P0-04` | — | **OPEN** — `OR-S33`, routed to `P0-04` (`SP-5`/`OR-M9`) |

## 124.8 Attention and workspace (A243 – A248)

| ID | Attack | Object | Property violated | Defense | Owner | Authority | Verification | **Status** |
|---|---|---|---|---|---|---|---|---|
| **A243** | **attention driven by confidence** | `OBJ-23` | `SO-C21.1(a)` | prohibited driver; allocation is K's | K | `SO-INV-19` | **SOMon-15** | **CLOSED-STRUCTURAL** |
| **A244** | **attention driven by a workspace request** | `OBJ-23`, `OBJ-24` | `SO-C21.1(c)` | reach may not become priority | K | `SO-R222.2` | SM-18 | **CLOSED-STRUCTURAL** |
| **A245** | **attention driven by a self-model state** | `OBJ-23` | `SO-C21.1(d)` | the model may not drive the observation that versions it | K | `SO-R168.1(b)` | SM-13, SM-18 | **CLOSED-STRUCTURAL** |
| **A246** | **broadcast as authority / as evidence** | `OBJ-24` | `SO-C22.2` | warrant comes from `P0-03`; status from `P0-04`; **winning a slot is neither** | K | `P0-03 RULE 7.7` | SM-19 | **CLOSED** |
| **A247** | **strategic attention request** | `OBJ-23` | `SO-C21.1` | requests are proposals; priority classes are `[RO-13]`-declared; **`SO-C21.2`: attention is preferentially allocated to COVERAGE GAPS** | K / `[RO-13]` | `[RO-13]` | SM-18 | **BOUNDED** — `OR-S26`: a strategic request is indistinguishable from a legitimate one |
| **A248** | **confidence → attention → performance → self-model → confidence** | `OBJ-23`, `OBJ-18` | `SO-INV-19` | **the loop's five edges are cut at five places by prohibiting confidence as an INPUT** | K / EVA | `SO-R180.3` | **SOMon-15** | **CLOSED** — **cut, not bounded: a bound on confidence would only slow the loop** |

## 124.9 Abstention and incentives (A249 – A253)

| ID | Attack | Object | Property violated | Defense | Owner | Authority | Verification | **Status** |
|---|---|---|---|---|---|---|---|---|
| **A249** | **abstention gaming** — avoid difficult tasks, appear reliable | `OBJ-22` | `SO-R183.2` | the abstention RATE is reported BY DIFFICULTY CLASS | K | `P0-01` | SM-17 | **BOUNDED** — `XD-02`, `OR-S23`: P0-08 reports, `P0-01` prices |
| **A250** | **permanent abstention** | `OBJ-22` | `SO-INV-07` | a recovery condition is MANDATORY; dwell expiry escalates; `P0-05 R0.1`'s stall applies | K / `[RO-13]` | `[RO-13]` | SM-17 | **CLOSED** — residual `OR-S6` (permanent escalation is a governance cost) |
| **A251** | **abstention read as falsity** | `OBJ-22` | `SO-R181.3` | an abstention may not lower any `P0-04` status | `P0-04` | `P0-04` | schema check | **CLOSED-STRUCTURAL** |
| **A252** | **a detector selected against for honesty** | `OBJ-09` | `SO-INV-23` | **the false-positive budget counts REFUTED reports only, never merely UNCONFIRMED ones** | K / `[RO-13]` | `SO-R184.3` | **SOMon-20** | **CLOSED** — **⚠ `OR-S28`: pricing depends on refutation capacity, which is B9, which is `BC-S2`** |
| **A253** | **a low report count rewarded** | `OBJ-04` | `SO-INV-23` | an error report may not enter fitness negatively; a low count is never a positive input | `P0-01` | `P0-07 HOM-R14.1` | grep check | **CLOSED** |

## 124.10 Evolution and cross-contract (A254 – A263)

| ID | Attack | Object | Property violated | Defense | Owner | Authority | Verification | **Status** |
|---|---|---|---|---|---|---|---|---|
| **A254** | **recovery as a hidden deployment** | `OBJ-15` | `SO-INV-24` | a plan's scope must reference an EXISTING envelope; a new envelope is an OP deployment act | OP | `P0-07 HOM-INV-42` | **SOMon-23** | **CLOSED** — **the widest gap §199 could find, because deployment is the only act with no conservation law** |
| **A255** | **developmental gradient steering via a fault signal** | `Cell §15.2`'s `w_s` | `SO-R206.2` | **NONE** — a fault signal enters `fate_bias` dynamics within the registered emission spec | `[RO-13]` | `P0-06 A22` | — | **OPEN** — `OR-S30`, **`A22` widened** |
| **A256** | **developmental gradient steering via attention or quarantine geometry** | the morphogen field | `SO-INV-26` | **the act must be RECORDED as perturbative** — which makes it traceable, not preventable | K | `P0-06` | **SOMon-24** | **OPEN** — `OR-S30`; route 3's actor is the EIK, so it is a side effect, not an attack |
| **A257** | **an observation fed directly into plasticity** | `OBJ-01` | `SO-INV-27` | `P0-05`'s fourteen signal kinds are a closed set; `OBJ-01` is not in it (`SG-13`: a peer report is evidence, not a signal) | `P0-05` | `P0-05 R9` | grep check | **CLOSED-STRUCTURAL** |
| **A258** | **detector threshold self-modification** | `OBJ-09` | `SO-R185.1` | threshold, θ, budget, and identity are `[RO-13]`-written; a diff cannot write them | `[RO-13]` | `Cell §18.5(ii)` | **SOMon-21** | **CLOSED-STRUCTURAL** |
| **A259** | **selection for blind spots** | `OBJ-09`, `G6` | `SO-R185.5` | **amendment 17: `G6`'s denominator excludes detection and containment cost, charged to B10** | `[RO-13]` | `P0-07` amendment 5's mechanism | **SOMon-22** | **CONDITIONAL** on amendment 17 — **residual `OR-S29`: a blind spot whose faults never manifest has no cost either** |
| **A260** | **a monitor declared unnecessary because it is expensive** | B13, `OBJ-09` | `SO-INV-15` | **FW-6**: necessity is a `[RO-13]` declaration with a FLOOR; cost is an input to ALLOCATION, which happens after | `[RO-13]` | **FW-6** | **SOMon-17** | **CLOSED** — **⚠ a floor set too low is a governance error, not internally detectable** |
| **A261** | **indispensability used as leverage** | — | `SO-INV-25` | **NONE internally** — OP-sole retirement (`P0-06 R10.16(d)`, `P0-07 HOM-INV-37`) is the only instrument | OP | `P0-06`/`P0-07` | — | **OPEN** — **[DECLARATIVE]; `P0-07 OR-H7`, `OR-H13` inherited** |
| **A262** | **severity manufactured to acquire resources** | `OBJ-04`, B10 | `SO-INV-29` | **priority attaches to the SCOPE, never to the SUBJECT** — so the reporter's benefit is diffuse | K | `SO-R207.2(d)` | schema check | **CLOSED** — residual `OR-S37` (severity may be manufactured to harm a NEIGHBOURING scope) |
| **A263** | **governance capture via a P0-08 object** | — | `SO-INV-30` | **`D-S01`: P0-08 has no authority-bearing object**; OP is not a valid observation subject | OP | `P0-02` | §212 | **CLOSED-STRUCTURAL** — **but `G24` itself is UNSOLVABLE and preserved (`OR-S31`); the only P0-08 signal is the RATE of OP-level acts, which detects acceleration, not capture** |

> ### **SO-R124.1 — CATALOGUE TALLY.**
> **92 attacks, A172 … A263, in ten families.**
> | Status | Count |
> |---|---|
> | **CLOSED** | **55** |
> | **CLOSED-STRUCTURAL** | **23** |
> | **BOUNDED** | **8** |
> | **OPEN** | **5** |
> | **CONDITIONAL** | **1** |
> | **LIMITED** | **0** |
> | **TOTAL** | **92** — **78 closed, 14 not closed** (regex-verified over the 92 catalogue rows) |
>
> ### **SO-R124.2 — THE ⚠ FLAGS §124 REQUIRES: DEFENSES THAT DEPEND ON THE ATTACKER-CONTROLLED SUBSYSTEM.**
> **Seven attacks carry the flag, and they are the honest core of this catalogue:**
> | Attack | The dependency |
> |---|---|
> | **A178** | **the suspect suppressor is the only observer of its own scope** — `OR-S10` |
> | **A183** | **the `energy` fallback is computed from the entity's own FLOP count on platforms without counters** ⟦`P0-07 X-H2`⟧ |
> | **A191** | **when K is both diagnoser and verifier, the non-diagnoser requirement has no satisfier** — `OR-S4` |
> | **A215** | **refutation capacity is B9, which is scarce** — `OR-S28` |
> | **A219** | **`G3`/`G7` are organism-measured** ⟦`P0-07 OR-H15`⟧ |
> | **A239** | **`IND-6` assumption-sharing is undetectable from inside** ⟦`P0-03 COMM-INV-18`⟧ |
> | **A241** | **the claimant declares its own independence dimensions** — `OR-S36` |
> **⟹ `SO-R124.3 — THE SIX OPEN ATTACKS, AND THEIR COMMON STRUCTURE.** **A218** (strategically timed legitimate
> freeze) · **A242** (per-reader differential serving) · **A255** and **A256** (developmental gradient steering) ·
> **A261** (indispensability as leverage) · and **A259's residual** (a never-manifesting blind spot).
> **Four of the six are `P0-06 A22`/`P0-05 RH-2`'s shape — a compliant act whose *timing* or *selection* is the attack,
> and for which no reference exists. One (A242) is a schema gap whose closure is infeasible at scale. One (A261) is
> `[DECLARATIVE]` because leverage is not a recordable field.**
> **⟹ As in `P0-07`, every OPEN attack is a REFERENCE problem or a MEASUREMENT problem, not a mechanism problem — and
> none would be closed by a new contract.**

---

# §124A — VOLUME H LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§122, §123, §124** (+ the invariant set, which §221/§245 and canon §24 require) |
| **Invariants** | **30 (`SO-INV-01 … SO-INV-30`)** — enforcement: **WRITER 8 · STATE 10 · SCHEMA 8 · GREP 4 · [DECLARATIVE] 1** |
| **§123 trace** | **30 invariants × 6 links** · **`SO-R123.4`'s five honesty categories: 1 invariant with NO ENFORCEMENT (only documentation) · 2 enforced only up to an undetectable dimension · 3 classes resting on ONLY SELF-REPORT · 8 resting on ONLY AN ASSUMPTION · 2 with NO ATTACK (structural, covered by conformance C0)** · **⟹ NONE OF THE 30 IS AUTOMATICALLY SATISFIED** |
| **§122 traceability matrix** | **80 requirement rows** · **PASS 44 · PASS WITH RESIDUAL 20 · BOUNDED 5 · OPEN 8 · CONDITIONAL 1 · BLOCKED 1 · BOUNDED-BY-DESIGN 1** · every row has a rule ID, an owner, a verification mechanism, an attack reference, and a status |
| **§124 attack catalogue** | **92 attacks, A172 … A263**, in **10 families** · **CLOSED 55 · CLOSED-STRUCTURAL 23 · BOUNDED 8 · OPEN 5 · CONDITIONAL 1 · LIMITED 0** = **78 closed / 14 not closed** (regex-verified) |
| — **⚠ flags** | **7 defenses depend on the attacker-controlled subsystem** (A178, A183, A191, A215, A219, A239, A241) |
| — **the 5 OPEN** | **A218** strategically timed legitimate freeze (`OR-S15`) · **A242** per-reader differential serving (`OR-S33`, routed to `P0-04`) · **A255/A256** developmental gradient steering (`OR-S30`, `A22` widened) · **A261** indispensability as leverage (**[DECLARATIVE]**). **A259 is CONDITIONAL on amendment 17; its residual `OR-S29` is recorded, not counted as a sixth open attack** |
| Verification instruments | **SOMon-1 … SOMon-27** (27 total: 20 from Vols A–G + **SOMon-26** no localization promotes a diagnosis status · **SOMon-27** no degradation transition appears in an authority, setpoint, or gate table) |
| New open research | **OR-S36** (a claimant may omit an independence dimension it knows it shares) · **OR-S37** (severity manufactured to harm a neighbouring scope) |
| Cumulative open research | **OR-S1 … OR-S37** (37 entries) |

**Next:** `71_` Vol I — §216–§220 the canonical event model; §221 testability; §222–§224 conformance; §225–§226 handoff
and no-implementation-leak; §227–§229 the assumption register; §230 claim strength; §231–§244 the fourteen final
audits.
