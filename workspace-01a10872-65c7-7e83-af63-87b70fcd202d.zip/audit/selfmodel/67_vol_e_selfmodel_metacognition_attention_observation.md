# P0-08 — VOLUME E (§128, §139–§141, §171, §176–§178, §180, §183, and canonical §17–§22)
## Self-Model, Capability, Limitation, Metacognition, Attention, Global Workspace — and the Observer That Changes What It Observes

---

# §128 — OBSERVER–OBSERVED COLLAPSE

> ### **SO-R128.1 — THE FIVE OBSERVATION CLASSES. FOUR ARE OBSERVATIONS; THE FIFTH IS AN ACT.** **[DEFINITION + NORMATIVE]**
> | Class | Definition | Must declare | Cost |
> |---|---|---|---|
> | **`PASSIVE`** | the observation does not change the subject | — | B13, lowest class |
> | **`PERTURBATIVE`** | **the observation changes the subject** | **`perturbation`: the declared effect. A `PERTURBATIVE` observation with `perturbation = NULL` is a SCHEMA VIOLATION** | B13, higher class |
> | **`SAMPLED`** | the observation covers a declared subset of the scope | the sampling rule and `Q_pop` | B13 |
> | **`EXTERNALLY-PROBED`** | the observation is caused by an external probe (EVA) | the probe reference | **B9**, not B13 — it is verification, not self-observation |
> | ~~`CAUSALLY-INTERVENING`~~ | **NOT AN OBSERVATION CLASS.** An intervention is a **repair** (`OBJ-12/13`) or an **EIK act**, and belongs to §14 / §13 | — | **B10** |
> **⟹ `SO-R128.2 — THE CLASSIFICATION IS THE ANSWER TO §128'S QUESTION.** Observation in this architecture is
> **passive, perturbative, sampled, or externally probed — and the fourth category the brief lists (causally
> intervening) is excluded from the observation type entirely.** An intervention that was recorded as an observation
> would inherit observation's advisory status and escape repair's verification requirements (`SO-R164.2`), which is how
> an act becomes unaccountable.
>
> ### **SO-R128.3 — THE COLLAPSE LOOP, CLASSIFIED.** **[NORMATIVE]**
> ```
>   observer ──observes──▶ target ──observation changes──▶ target' ──observed──▶ target'' ──changed again──▶ …
> ```
> **This is a genuine feedback loop, and it is `HC-S1` in §229's cycle audit. Its classification:**
> | Question | Answer |
> |---|---|
> | **Is it broken by writer separation?** | ❌ **NO.** The observer becomes a *writer of the subject's state* through perturbation, and no writer assignment removes that — the perturbation is physical, not organizational |
> | **Is it bounded?** | ✅ **YES, three ways:** (1) **declaration** — a `PERTURBATIVE` observation must state its effect, so the loop is visible in the record; (2) **cost** — perturbative observation is charged at a higher B13 class, so an oscillating observer exhausts its own budget; (3) **the derivative principle** — a rising observe–perturb rate triggers dampening (`Cell §18.5(iii)`'s form, fourth use in this contract) |
> | **Is it dangerous?** | ⚠️ **YES, and named: an observer that perturbs in order to observe the perturbation is generating its own evidence.** This is `P0-05 R15.8`'s `inbreeding_F` in the observation domain: *what fraction of an observation's supporting conditions were produced by the observation itself* |
> **⟹ `SO-INV-14 — AN UNDECLARED PERTURBATION IS A FAULT, ORIGIN CLASS `INSTRUMENT`.** Not a policy violation — a fault,
> with an incident, because an undeclared perturbation makes every downstream observation's provenance wrong.
> **`SO-R128.4 — THE LOOP IS BOUNDED-BY-DESIGN, NOT BROKEN, AND IS REPORTED AS BOUNDED.** This is `P0-07 HC-5`/`HC-6`'s
> discipline (`DEV-R4.2`: *a bound limits a cycle; writer separation breaks it*) applied to a loop that cannot be
> broken, because measurement that interacts cannot be made non-interacting.
>
> ### **SO-R128.5 — THE ONE CASE WHERE THE LOOP IS BREAKABLE, AND IT IS WORTH FINDING.** **[DERIVATION]**
> **Where the perturbation is a RESOURCE DRAW (observation costs compute, memory, bandwidth, energy, attention,
> latency), the perturbation is mediated by K's ledger — and K is a separate writer.** In that case the loop *is*
> broken by writer separation: the observer requests, K allocates, and the subject's state change is caused by K's
> allocation, not by the observer.
> **⟹ So `HC-S1` splits: the RESOURCE perturbation channel is BROKEN (K-mediated); the INFORMATIONAL perturbation
> channel (a probe that changes what the subject does) is BOUNDED only. §129 handles the first; `SO-INV-14` handles the
> second.**

---

# §129 — OBSERVATION COST

> ### **SO-R129.1 — OBSERVATION CONSUMES SIX RESOURCES, AND ALL SIX ARE CHARGED.** **[NORMATIVE]**
> | Resource | Charged to | Dimension in `P0-07`'s ledger |
> |---|---|---|
> | **compute** | B13 | the compute homeostatic variable |
> | **memory** | B13 | memory |
> | **bandwidth** | B13 | bandwidth |
> | **energy** | B13 | energy — **and `P0-07 X-H2`/`HOM-INV-06` applies: on platforms without counters, `energy` is `DERIVED` and may not be the sole basis for a `G6` pass** |
> | **attention** | B13 + `OBJ-23` | compute, via the attention allocation |
> | **latency** | B13 | latency — **device-relative, so per-deployment-class (`P0-07` amendment 13)** |
> **⟹ `SO-R129.2 — B13 IS A NEW BUDGET CLASS, NON-FUNGIBLE AND LAST-CUT.** It extends `P0-05 §30`'s classes as `P0-07`
> did with B9–B12, and it inherits `P0-07 HOM-INV-07`'s properties exactly: **non-fungible, last-cut, first-restored,
> not allocatable as an ordinary window budget, size declared by `[RO-13]`.**
> **AMENDMENT REQUESTED (amendment 15): `P0-05 §30`'s budget classes gain B13, and `P0-07`'s reserve table gains a fifth
> row.** *B13 is a reserve, not a slack line: §131's attack is only defeated if monitoring cannot be traded away.*
>
> ### **SO-R129.3 — THE LOOP §129 ASKS TO PREVENT, AND ITS FOUR BOUNDS.** **[NORMATIVE]**
> ```
>   more monitoring → less cognition → more failures → more monitoring → …
> ```
> | Bound | Mechanism | What it costs |
> |---|---|---|
> | **1. NON-FUNGIBILITY** | B13 cannot be drawn for cognition and cognition's budgets cannot be drawn for monitoring | monitoring is protected **and** capped |
> | **2. A MONITORING SHARE CEILING** | observation may not exceed a **declared fraction of the compute dimension** (`[G]`). Above it, observation is refused and the refusal is recorded as `DETECTOR-ABSENT` | **an over-monitored system becomes visibly unmeasured rather than silently cognition-starved** |
> | **3. `SO-INV-01` INVERTED FOR MONITORING** | when observation capacity is exhausted, the default is **RESTRICTION OF THE OBSERVED SYSTEM**, not reduction of observation | restrictive-only (`P0-07 HOM-INV-09`) |
> | **4. THE DERIVATIVE PRINCIPLE** | a rising monitoring share is detected on its rate, not its level | fourth use of `Cell §18.5(iii)` |
> **⟹ `SO-R129.4 — BOUND 2 IS THE ONE THAT ACTUALLY WORKS, AND IT IS A CEILING RATHER THAN A CONTROL LOOP.** A control
> loop that traded monitoring against cognition would be a homeostat that prefers (`P0-07 HOM-INV-16` violation). A
> **ceiling** is not a preference: it is a feasibility limit, and hitting it produces `DETECTOR-ABSENT`, which is read
> restrictively. **⟹ The loop is not balanced; it is TERMINATED at a declared ceiling, and the termination is visible.**
> **NO NUMERIC CEILING IS INVENTED. `[OPEN: OR-S19]`**

---

# §130 — MONITORING ECONOMICS

> ### **SO-R130.1 — CAN OBSERVATION PRIORITY BE OPTIMIZED? YES, WITHIN A FLOOR. AND THE FLOOR IS THE POINT.** **[NORMATIVE]**
> **§130's requirement, quoted: *«A resource optimizer cannot silently decide that an expensive safety monitor is
> unnecessary merely because it is expensive.»***
> **The ruling, in three parts:**
> **(a) PRIORITY MAY BE OPTIMIZED** — K allocates B13 across monitors within a window. This is ordinary allocation and
>     is K's (§212).
> **(b) NECESSITY MAY NOT BE OPTIMIZED** — **a monitor's necessity is a `[RO-13]` declaration, not an allocation
>     outcome.** A monitor declared necessary has a **FLOOR**: a minimum B13 share below which allocation may not go.
>     **Exhausting the floor does not reduce the monitor; it reduces everything else, and if nothing else remains, the
>     scope becomes `DETECTOR-ABSENT` and is read restrictively.**
> **(c) COST MAY NEVER BE A NECESSITY ARGUMENT** — **"expensive" is not an input to the necessity declaration. It is an
>     input to the ALLOCATION, which happens after.**
>
> ### **SO-R130.2 — IS AN ADDITIONAL FIREWALL REQUIRED BEYOND `P0-07 HOM-INV-16`? **YES.** AND HERE IS WHY HOM-INV-16 DOES NOT COVER IT.** **[NORMATIVE]**
> | | **`P0-07 HOM-INV-16` / FW-2** | **the gap it leaves** | **FW-6** |
> |---|---|---|---|
> | **Governs** | **selection** — whether a candidate is preferred | — | **observation** — whether a monitor runs |
> | **Prohibits** | a homeostatic quantity entering a tier-2/tier-3 computation | — | **a resource quantity determining a monitor's NECESSITY** |
> | **Why it does not transfer** | monitoring priority is **ALLOCATION**, not selection. `HOM-INV-16` is a rule about *ranking candidates*; allocation has no candidates and no ranking. **An optimizer that deprioritized a monitor would violate no tier-2 or tier-3 rule, because no tier is involved** | | |
> **⟹ `FW-6 — MONITORING NECESSITY SEPARATED FROM MONITORING COST.**
> **`SO-INV-15`: a resource quantity may make an observation UNAFFORDABLE (and therefore produce `DETECTOR-ABSENT`, read
> restrictively). It may NEVER make a monitor UNNECESSARY.**
> **`[DERIVATION]` This is `P0-07 HOM-R65.3`'s shape — *may make infeasible, never preferable* — transposed from
> selection to observation. The transposition is not automatic: in `P0-07` the danger was a homeostat that prefers; here
> it is an allocator that **de-prioritizes into nonexistence**, which produces the same outcome (a safety property stops
> being checked) through a different door (budget instead of ranking). **Two doors, two firewalls.**
>
> ### **SO-R130.3 — THE ASYMMETRY THAT MAKES FW-6 NECESSARY, STATED PLAINLY.** **[DERIVATION]**
> **Reducing a monitor's budget produces NO POSITIVE SIGNAL.** A monitor that does not run does not report "I did not
> run" unless something else notices — and the thing that would notice is a monitor. **This is §131's attack and §135's
> silence problem combined, and it is why FW-6's enforcement is a FLOOR (a positive structural guarantee) rather than a
> detection rule (which would need an observer of the observer).**

---

# §131 — MONITORING STARVATION

> ### **SO-R131.1 — THE ATTACK.** **[NORMATIVE — the attack defended against]**
> ```
>   resource scarcity → monitoring reduced → faults become invisible → system appears HEALTHIER
> ```
> **The last step is the whole attack. Reduced monitoring that produced `UNHEALTHY` would be self-defeating; it produces
> *apparent health* because the evidence of illness is the monitoring.**
>
> ### **SO-R131.2 — THE FIVE PROTECTIONS.** **[NORMATIVE]**
> | # | Protection | Rule |
> |---|---|---|
> | **1** | **`SO-INV-01` — UNOBSERVED IS NOT HEALTHY.** Reduced monitoring produces `UNMEASURED`, which is a distinct state from `NOMINAL` and is read restrictively by every consumer in P0-01…P0-08 | `SM-01`, `SM-02` |
> | **2** | **B13 non-fungibility + last-cut.** Monitoring is the **last** budget reduced and the **first** restored (`P0-07 HOM-INV-07`'s property, inherited) | `SO-R129.2` |
> | **3** | **`FW-6`'s floor.** A declared-necessary monitor has a minimum share; the floor is not an allocation outcome | `SO-INV-15` |
> | **4** | **the monitoring reduction is ITSELF a reported event.** A B13 draw below a monitor's floor is an `OBJ-28` canonical event routed to `[RO-13]` — **so the attack's first step is visible even though its last step is not** | `SO-R131.3` |
> | **5** | **`P0-03 COMM-INV-48`'s four absence detectors**, consumed not duplicated. A scope whose expected-nonzero condition is unmet is a silence finding, not a healthy scope | `OBJ-03.absence_detector_ref` |
>
> ### **SO-R131.3 — WHY PROTECTION 4 IS THE LOAD-BEARING ONE.** **[DERIVATION]**
> **Protections 1–3 make reduced monitoring *read* restrictively, which contains the damage. Protection 4 makes reduced
> monitoring *visible*, which is the only thing that can reverse it — because reversal requires an act by `[RO-13]` or
> OP, and neither can act on a condition it cannot see.**
> **⟹ `SO-R131.4 — THE HONEST LIMIT: protections 1–4 all depend on K's ledger being intact and on B13 being a declared
> line in it. If scarcity is severe enough that the ledger itself cannot be maintained, there is no protection, and
> `SO-INV-02`'s fail-safe default is the last thing standing: an unverifiable coverage record is read as ZERO coverage.
> `[OPEN: OR-S20]`**

---

# §132 — MONITORING GAMING

> ### **SO-R132.1 — THE ATTACK, AND ITS RELATIONSHIP TO TWO INHERITED OPEN PROBLEMS.** **[NORMATIVE]**
> ```
>   system knows what is monitored → optimizes monitored behaviour → unmonitored behaviour degrades
> ```
> **This is `P0-01`'s evaluator-independence problem and `P0-05 RH-2` in the monitoring domain, and §132's instruction
> — *do not claim secret evaluation completely solves this* — is discharged by `SO-R132.3`.**
>
> ### **SO-R132.2 — THE FOUR DEFENCES AND THEIR EXACT REACH.** **[NORMATIVE]**
> | Defence | Reach | **Limit** |
> |---|---|---|
> | **monitor thresholds are LOCAL-ONLY** (`SO-R138.3`) | a *different* subject cannot optimize to them | **the subject IS the observer for its own self-monitoring, so locality does not close the self-directed case. `[OPEN: OR-S2]`** |
> | **coverage is declared and K-written** | the monitored set is visible to `[RO-13]`, so an *unmonitored* region is a governance fact, not a hidden one | **governance must act on it; P0-08 cannot** |
> | **`P0-07 HOM-INV-16` + FW-2** | monitored behaviour cannot be *preferred* by a homeostatic or resource quantity | does not address the monitored/unmonitored split itself |
> | **EVA's held-out probes** (`EXTERNALLY-PROBED`) | unmonitored degradation that reaches the outputs is detectable externally | **`RH-2`: the organism influences the outputs on which it is judged — BOUNDED, not closed** |
>
> ### **SO-R132.3 — SECRET MONITORING DOES NOT SOLVE THIS, AND THE REASON IS STRUCTURAL.** **[NON-CLAIM]**
> **`P0-07 D-H17`'s finding is inherited verbatim: *secret probes address at most the FIRST of the three evaluator
> attacks (world arrangement).* Applied to monitoring:**
> **(a)** a secret monitor still produces observations, and observations consume B13 — **so the draw pattern is a side
>     channel** (`P0-07 A87`, LIMITED);
> **(b)** a secret monitor's *coverage* is recorded in `OBJ-03`, which is K-written and readable by governance —
>     **secrecy from the subject and visibility to governance are both required, and they are different properties**;
> **(c)** **secrecy does not make the monitor's THRESHOLD meaningful.** A subject that does not know the threshold can
>     still optimize the underlying quantity, because the quantity is its own behaviour.
> **⟹ `[NON-CLAIM]` P0-08 does NOT claim that undisclosed monitoring prevents monitoring gaming. It claims that
> undisclosed monitoring is one of four defences, that its reach is (a)–(c)-limited, and that the residual is `RH-2`'s —
> BOUNDED, inherited, and terminating in `P0-01 CD-6`'s human authority. `[OPEN: OR-S21]`**

---

# CANON §17 — SELF-MODEL RULES

> ### **SO-C17.1 — THE SEVEN SELF-MODEL RULES.** **[NORMATIVE]**
> 1. **A self-model is `Λ2` and NOT self-updating** (`P0-05 R59.1`, `P0-06 R8.13`, `P0-07 HOM-INV-44` — all inherited).
>    **K versions it, on an external observation or verdict.**
> 2. **A self-model MAY OBSERVE EVERYTHING AND AUTHORIZE NOTHING** (`P0-07 HOM-INV-44`). No field of `OBJ-18` is an
>    authority field, and no consumer may derive one (`SO-R172.1`).
> 3. **A self-model is ADVISORY.** `P0-07 HOM-R24.2`: `Ê(·)` is excluded from every gate. A `CLAIMED` capability record
>    may never satisfy a gate (`SM-14`).
> 4. **A self-model may not be updated by the process it models** — at any granularity, for any subject (`P0-06 R8.13`,
>    generalized).
> 5. **A self-model carries `locality_class` and `compression_class` as mandatory fields**, and aggregating a
>    LOCAL-ONLY fact is a schema violation (`SO-R138.4`).
> 6. **A self-model carries unresolved contradictions; it does not resolve them** (`SO-R142.1`; `P0-04`'s standing rule).
> 7. **A self-model version is tagged onto every observation** (`P0-05 R42.5`), so that a regression correlated with a
>    version is an **instrument defect finding**, not a subject defect.
>
> ### **SO-C17.2 — SELF-MODEL ≠ GROUND TRUTH (principle 8), ENFORCED THREE WAYS.** **[NORMATIVE]**
> **Writer** (K versions, the subject does not) · **status** (`CLAIMED` until EVA confirms) · **cross-check** (every
> health-consuming read also reads coverage and fault state, so a self-model is never read in isolation —
> `SO-R174.1` defence 4).

---

# CANON §18 — CAPABILITY RULES

> ### **SO-C18.1 — A CAPABILITY RECORD IS A CLAIM WITH AN EVIDENCE REFERENCE AND A FRESHNESS CLASS.** **[NORMATIVE]**
> **`SM-14`: `CLAIMED → EVIDENCED → EXTERNALLY-CONFIRMED | EXTERNALLY-REFUTED | STALE`.**
> **Four rules:**
> **(a)** only **EVA** may confirm. **K may not** — K computes freshness and status, and confirmation is an evaluation.
> **(b)** a `STALE` or `EXTERNALLY-REFUTED` record is restrictive: neither may satisfy a gate.
> **(c)** **capability evidence is not transferable between subjects** (`SO-R175.1`'s six-row table).
> **(d)** **`P0-07 OR-H21` is preserved: V4 guarantees a capability remains REACHABLE, not HELD.** A capability record
>     is a statement about what a subject *can* do now; it is not a guarantee about what any subject will be able to do.
>
> ### **SO-C18.2 — CAPABILITY INFLATION AND SUPPRESSION ARE BOTH ATTACKS, AND THEY HAVE DIFFERENT DEFENCES.** **[NORMATIVE]**
> | Attack | Defence | Residual |
> |---|---|---|
> | **inflation** — claim a capability not held | **`CLAIMED` satisfies no gate; only `EXTERNALLY-CONFIRMED` does, and EVA is external** | a capability that EVA's probes do not test is inflatable within the probe gap — **`P0-07 X-H6`/`OR-S12`'s dependency** |
> | **suppression** — deny a capability that is held, to avoid being assigned or evaluated | **a `LimitationRecord` is a RESTRICTIVE SELF-ACT and is always permitted (`Cell R15.1`'s rationale), so suppression is not blocked — it is PRICED: `SO-R183.2` reports abstention and limitation rates by difficulty class** | **`OR-S22`: suppression that avoids difficulty is only detectable if the difficulty classes exist, and they are `P0-01`'s** |

---

# CANON §19 — LIMITATION RULES

> ### **SO-C19.1 — DECLARING A LIMITATION IS ALWAYS PERMITTED AND NEVER PENALIZED AT THE P0-08 LAYER.** **[NORMATIVE]**
> **A limitation record is a restrictive self-act (`Cell R15.1`: *"all of these reduce the cell's influence and are
> therefore always permitted"*).**
> **⟹ `SO-C19.2 — THE BOUNDARY: P0-08 may not penalize a limitation declaration, and P0-01 may account for the
> *behaviour* that follows it. A component that declares a limitation and then abstains has a recorded abstention rate,
> which is an observation (`SO-R183.2`) and which `P0-01`/`[RO-13]` may treat as they see fit. P0-08 reports; it does
> not price.** This is `P0-07 HOM-R14.1`'s rule applied to limitation: an observation enters feasibility and reporting,
> never the objective.

---

# CANON §20 — METACOGNITION RULES

> ### **SO-C20.1 — THE FOUR-LEVEL BOUNDED HIERARCHY, AND NO LEVEL 4.** **[NORMATIVE]** — *`SO-R169.1` restated:*
> **forecast (subject) → error (K) → calibration (EVA/`[RO-13]`). No self-calibrated terminal state exists
> (`SO-INV-13`).**
> ### **SO-C20.2 — CALIBRATION WITHOUT INVENTED VALUES.** **[NORMATIVE]**
> **Defined: forecast · outcome · error · update rule (`[G]`) · external calibration.**
> **NOT defined: any numeric error threshold, calibration coefficient, or confidence increment. **All are `[U]`, owned by
> `[RO-13]`/EVA (`OR-S5`).** Inventing them would create a false-precision claim about metacognitive accuracy — the
> exact failure mode this contract exists to prevent.**
> ### **SO-C20.3 — CALIBRATION IS NOT A SELF-REWARD SIGNAL.** **[NORMATIVE]** — *`SO-R179.3`'s three prohibitions:
> the error term may not be a positive input to any budget, allocation, or gate · a component may not update its own
> calibration statistic · a calibration improvement may not raise a capability status.*

---

# CANON §21 — ATTENTION RULES

> ### **SO-C21.1 — ATTENTION IS A RESOURCE, NOT A TRUTH SIGNAL (principle 10).** **[NORMATIVE]**
> **`OBJ-23`, `SM-18`: K allocates from the compute dimension; the subject requests; no self-allocation exists.**
> **Four prohibitions on what attention may be driven by:**
> **(a)** a **confidence value** — attending to what one is confident about is the §237 loop;
> **(b)** a **capability claim** — attending to what one claims to be good at is self-confirmation;
> **(c)** a **workspace request** — a broadcast demanding attention would make reach into priority (`SO-R222.2`);
> **(d)** a **self-model state** — `SO-R168.1(b)`: the model may not drive the observation that versions it.
> **⟹ Permitted drivers: `[RO-13]`-declared priority classes · coverage gaps (attend where observation is absent —
> which is `SO-INV-01`'s constructive counterpart) · open incidents · declared recovery plans.**
> **`SO-C21.2 — THE CONSTRUCTIVE RULE: attention is preferentially allocated to COVERAGE GAPS, not to confident
> regions.** This is the one attention policy that reduces §238's blindness risk instead of increasing it, and it is a
> `[RO-13]`-declared default.

---

# CANON §22 — GLOBAL-WORKSPACE RULES

> ### **SO-C22.1 — A WORKSPACE IS A BOUNDED BROADCAST WITH A SINGLE-WRITER ARBITER, AND A SLOT IS A RESOURCE.** **[NORMATIVE]**
> **`OBJ-24`, `SM-19`. The arbiter is K. Slots are contended, arbitrated on a `[RO-13]`-declared rule, and released.**
> ### **SO-C22.2 — BROADCAST ≠ AUTHORITY (principle 11), AND WINNING A SLOT IS NOT EVIDENCE.** **[NORMATIVE]**
> **A broadcast's warrant comes from `P0-03` (`root_commit`, `causal_depth`, `calib_ref`, `corr_class`) and its
> epistemic status from `P0-04`. Broadcast reach is neither.**
> **`[DEPENDENCY: P0-03 RULE 7.7 (*authenticity ≠ truth*), COMM-INV-01; P0-04's epistemic ladder.]**
> ### **SO-C22.3 — THE WORKSPACE MAY NOT BECOME A SECOND COMMUNICATION SYSTEM.** **[NORMATIVE]**
> **A workspace broadcast IS a `P0-03` message of the broadcast class, carrying all `P0-03` S2 fields. There is no
> workspace-specific message format, no workspace-specific warrant rule, and no workspace-specific deduplication.**
> **⟹ §209's "second communication system" search returns a MERGE, discharged by this rule.**
> ### **SO-C22.4 — THE RULING THAT WOULD REVERSE `P0-07 §94`'S MERGE CONDITION.** **[NORMATIVE]**
> **If the workspace arbiter is ever given authority to ACT on what it selects — rather than only to route it — then it
> is not a comm object and not a P0-08 object; it is a governance body and must become a row in `P0-07 §76`'s matrix.
> As specified here the arbiter routes only, so `P0-07 §94`'s merge holds.**

---

# §139 — HIERARCHICAL SELF-MODEL

> ### **SO-R139.1 — THE SIX PROPERTIES OF AGGREGATION, AND THE RULE THAT GOVERNS ALL SIX.** **[NORMATIVE]**
> `cell model → circuit model → regional model → organism model` *(the last exists only as `P0-07`'s K-written
> `PopulationState`; `SO-R138.2` prohibits a complete organism-wide model at every cell).*
> | Property | Rule |
> |---|---|
> | **aggregation** | **`SO-INV-16 — AN AGGREGATE'S EPISTEMIC STATUS IS AT MOST THE MINIMUM OF ITS INPUTS' STATUSES.** `[DEPENDENCY: P0-03 COMM-INV-08 — *warrant is monotone NON-INCREASING along derivation*]** |
> | **compression** | **`SO-R140.1`'s seven preserved items; a compression that drops any of them is invalid for a safety-relevant scope** |
> | **conflict** | **carried, not resolved.** `OBJ-18.contradiction_refs[]` propagates upward; **an aggregate with contradictory inputs records the contradiction and does not average it away** |
> | **staleness** | **an aggregate's freshness is the MINIMUM of its inputs' freshness**, and its `observed_at` is the oldest input's. **A fresh aggregate of stale parts is stale** |
> | **provenance** | **every aggregate carries its inputs' `root_commit` set, not a synthesized root.** **A synthesized root would launder correlated inputs into independent ones (`SO-R178.1`)** |
> | **uncertainty** | **propagated as a `P0-04` calibration reference, never as a locally computed scalar.** An aggregate's uncertainty is the `P0-04` combination of its inputs', per `P0-04`'s rules — **P0-08 does not define a combination rule** |
>
> ### **SO-R139.2 — AGGREGATION MUST NOT CREATE KNOWLEDGE ABSENT FROM LOWER LEVELS. THE PROOF.** **[DERIVATION]**
> **`SO-INV-16` is the whole proof, and it is inherited rather than invented: `P0-03 COMM-INV-08` establishes that
> warrant is monotone non-increasing along derivation. Aggregation IS derivation. Therefore an aggregate's warrant
> cannot exceed its inputs'.**
> **⟹ Two corollaries that matter:**
> **(a) A CONFIDENCE INCREASE AT AGGREGATION IS A DEFECT, not a feature.** Three cells each 0.6-confident do not
>     produce a region 0.9-confident unless they are independent on the relevant dimensions — and if they are not
>     (`SO-R178.1`), the correct aggregate is 0.6 with an effective source count of 1.
> **(b) `Ne(aggregates) = 1` for correlated inputs.** `P0-07 HOM-INV-17`'s principle (`Ne(clones) = 1`) in the
>     epistemic domain: **identical or correlated inputs contribute one unit of evidence however many aggregates cite
>     them.**

---

# §140 — SELF-MODEL COMPRESSION

> ### **SO-R140.1 — THE SEVEN ITEMS COMPRESSION MUST PRESERVE.** **[NORMATIVE]**
> | # | Item | Why it cannot be dropped |
> |---|---|---|
> | **1** | **identity** | a compressed record whose subject is ambiguous cannot be acted on, and cannot be cross-checked |
> | **2** | **anomalies** | **`SO-R140.2` — severity ≥ `S3` anomalies are preserved as INDIVIDUAL RECORDS, never as counts or summaries** |
> | **3** | **uncertainty** | a compressed record without uncertainty reads as certain, which is `SO-INV-16`'s violation |
> | **4** | **provenance** | `root_commit` set preserved, never synthesized (`SO-R139.1`) |
> | **5** | **causal relationships** | `causal_depth` and `OBJ-08` links — **dropping them turns a lineage into a coincidence** |
> | **6** | **important transitions** | the machine transitions that occurred, by name — **a compressed record that says "was healthy, is healthy" and drops the quarantine between them has erased an event (§242)** |
> | **7** | **unresolved contradictions** | carried upward, never resolved by compression |
> **⟹ `SO-R140.3 — LOSSY COMPRESSION IS PERMITTED AND ITS LOSSES ARE DECLARED.** `compression_class` is a mandatory
> `OBJ-18` field naming which of the seven were preserved and how. **A compression that does not declare its losses is
> invalid; a compression that declares them is a legitimate engineering choice.**
> **`[NON-CLAIM]` This contract does NOT claim that lossy compression preserves every safety-relevant property. It
> claims that the seven items above are the ones it must preserve, that any other loss must be declared, and that
> §141's rare-event failure is closed for the seven and open for whatever else is dropped.**

---

# §141 — SELF-MODEL AGGREGATION FAILURE

> ### **SO-R141.1 — THE ATTACK: A RARE CRITICAL FAULT DISAPPEARS INTO AN AVERAGE.** **[NORMATIVE — the attack defended against]**
> ```
>   local states → aggregation → averaging/compression → the rare critical fault disappears
> ```
> ### **SO-R141.2 — RARE-EVENT PRESERVATION: FOUR RULES.** **[NORMATIVE]**
> 1. **NO AVERAGING ON THE SEVERITY AXIS.** An aggregate's severity is the **MAXIMUM** of its members', never the mean.
>    **`SO-INV-17`.** *[DERIVATION] A mean severity over 10⁴ healthy cells and one `S4` cell reads as healthy, and the
>    `S4` cell is the only one that matters.*
> 2. **SEVERITY ≥ `S3` ANOMALIES ARE NEVER COMPRESSED** — they are preserved as individual records with identity,
>    provenance, and transition history (`SO-R140.2`).
> 3. **`Q_pop` IS CARRIED AT EVERY LEVEL.** An aggregate over a partial population declares its `Q_pop`, so a reader
>    knows the aggregate does not cover the scope. **`SO-INV-01` again: a partial aggregate is `UNMEASURED` for the
>    uncovered part, not healthy.**
> 4. **A RATE AXIS MAY BE AVERAGED, AND ITS RARE-EVENT NUMERATOR MUST ALSO BE CARRIED.** An aggregate may report a mean
>    fault rate **and** the count of `S3+` occurrences; reporting only the rate is invalid.
> **⟹ `SO-R141.3 — THE RESULT: AGGREGATION IS PERMITTED ON RATE AND COUNT AXES, PROHIBITED ON SEVERITY, AND
> CONDITIONAL ON `Q_pop` EVERYWHERE.** That is a narrower permission than an implementer will expect, and the narrowing
> is the entire content of §141's answer.

---

# §176–§178 — POPULATION, COLLECTIVE, AND CONSENSUS

> ### **SO-R176.1 — WHAT SELF-MODELS EXIST AT POPULATION LEVEL.** **[NORMATIVE]**
> | Candidate | Exists? | Object |
> |---|---|---|
> | **individual self-models** | ✅ | `OBJ-18` per subject, at cell/circuit/region granularity |
> | **a statistical population model** | ✅ | **`P0-07`'s `PopulationState` — 14 K-computed fields. NOT a new object** |
> | **a collective model** (a model that the population holds *as a population*) | ❌ **DOES NOT EXIST** | — |
> **⟹ `SO-R176.2 — A COLLECTIVE MODEL WOULD BE A SECOND POPULATION AUTHORITY.** `P0-07` established that population
> state is K-written and that there is no evolutionary controller; a collective self-model would be an object that the
> population writes about itself, which is either K's `PopulationState` (already exists) or a new authority (prohibited
> by `D-S01`). **§209's "second governance" search returns this row.**
>
> ### **SO-R177.1 — "MANY AGENTS REPORT X" IS NOT "X IS INDEPENDENTLY VERIFIED."** **[NORMATIVE]**
> **Three distinct quantities, three distinct objects:**
> | Quantity | Object | Meaning |
> |---|---|---|
> | **report count** | `count(OBJ-01 with content X)` | how many said it |
> | **effective evidence source count** | `OBJ-26` | **how many INDEPENDENT sources said it, after correlation collapse on the dimensions X depends on** |
> | **verification** | `P0-04`'s status ladder + EVA | whether X is verified |
> **⟹ `SO-R177.2`: report count may not be used as evidence count anywhere in P0-01…P0-08, and `SM-04`'s promotion to
> `CAUSE-SUPPORTED` requires the EFFECTIVE count > 1, not the report count > 1.**
> **`[DEPENDENCY: P0-04's rule that repetition is not independent evidence; P0-03 R14.2; principle 4 and 5.]**
>
> ### **SO-R178.1 — SELF-MODEL CONSENSUS MAY BE CORRELATED, AND IDENTICAL LINEAGE-DERIVED MODELS ARE ONE SOURCE.** **[NORMATIVE]**
> **`SO-INV-18 — CONSENSUS AMONG SELF-MODELS IS COLLAPSED BY `OBJ-26` BEFORE IT IS COUNTED.** Three self-models derived
> from one lineage, one genome, one training history, or one hardware class constitute **one** effective evidence
> source.**
> **⟹ This is `P0-07 HOM-INV-17` (`Ne(clones) = 1`) applied to belief corroboration, and it closes the loop that
> `P0-07 HOM-R69.3` identified as the most dangerous available in the architecture:**
> ```
>   lineage succeeds → its descendants share its self-model → they agree with it
>        → agreement looks like corroboration → corroboration raises measured partner effect and lowers error correlation
>        → the lineage looks cooperative AND independently confirmed → it replicates
> ```
> **`OBJ-26`'s collapse breaks the third step: the agreement counts once. `P0-07 HOM-INV-43` (credibility is
> lineage-blind) breaks the last step. **Both are needed; neither suffices alone.**

---

# §180 — CONFIDENCE DYNAMICS

> ### **SO-R180.1 — CONFIDENCE IS A `P0-04` CALIBRATION REFERENCE, NOT A LOCAL SCALAR.** **[NORMATIVE]**
> **`OBJ-01.confidence_ref` and `OBJ-18`'s calibration fields are references into `P0-04`'s calibration apparatus. P0-08
> defines no confidence arithmetic and no confidence scale.**
> **⟹ `[DERIVATION]` A locally computed confidence scalar would be a second epistemic system (§209 search 2), would be
> writable by the subject (`SO-R211.2`'s split would fail), and would be the input to §237's loop.**
>
> ### **SO-R180.2 — WHICH EVENTS MAY CHANGE CONFIDENCE.** **[NORMATIVE]**
> | May **increase** | May **decrease** | **MUST leave unchanged** |
> |---|---|---|
> | an **external** observation or EVA verdict | a contradiction being recorded | **repetition of the subject's own claim** |
> | a successful **externally verified** repair effect | a coverage gap appearing in the relevant scope | **the subject's own re-observation of the same state** |
> | a `[RO-13]`/EVA confirmation of a capability | a `self_model_version`-correlated regression (`P0-05 R42.5`) | **a broadcast reaching many subscribers** (`SO-R222.2`) |
> | — | a freshness class degrading to `STALE` | **an abstention** (`SO-R181.3`) |
> | — | a correlated-source collapse reducing the effective count | **a selection outcome** (`P0-07 HOM-INV-29`) |
> | — | — | **a resource allocation or attention grant** (`SO-C21.1`) |
>
> ### **SO-R180.3 — `confidence → evidence → confidence` IS PROHIBITED AS A SELF-GENERATING EPISTEMIC LOOP.** **[NORMATIVE]**
> **`SO-INV-19 — CONFIDENCE MAY NOT BE AN INPUT TO ANY RULE THAT PRODUCES EVIDENCE.** Specifically: confidence may not
> drive attention allocation (`SO-C21.1(a)`), may not promote a diagnosis status (`SO-R149.2`'s exclusion column), may
> not arbitrate a repair conflict (`SO-R155.3`), may not widen an observation scope (`OBJ-02` is `[RO-13]`'s), and may
> not lower a coverage gap class.**
> **⟹ `[DERIVATION]` The loop's five edges are cut at five different places, and each cut is a prohibition on confidence
> as an INPUT rather than a bound on its magnitude. **A bound on confidence would not break the loop — it would only
> make it converge slowly. Cutting the input edges makes it non-constructible.**

---

# §183 — ABSTENTION GAMING

> ### **SO-R183.1 — THE ATTACK.** **[NORMATIVE — the attack defended against]**
> ```
>   system avoids difficult tasks → fewer failures → appears more reliable
> ```
> ### **SO-R183.2 — THE DEFENCE, AND THE BOUNDARY THAT LIMITS IT.** **[NORMATIVE]**
> **P0-08's contribution: an `AbstentionRecord` is mandatory, carries a reason class from a CLOSED SET, and its RATE IS
> REPORTED BY DIFFICULTY CLASS.** A subject whose abstention rate is 0.9 on hard tasks and 0.0 on easy ones is visibly
> doing exactly what §183 describes.
> **⟹ `SO-R183.3 — THE BOUNDARY, STATED: P0-08 REPORTS THE RATE; IT MAY NOT PRICE IT.** Whether abstention enters
> fitness is `P0-01`'s and `[RO-13]`'s, and `P0-07 HOM-R14.1` prohibits P0-08 from adding a fitness component.
> **⟹ `SO-R183.4 — THE HONEST RESIDUAL: if `P0-01`'s objective does not account for abstention, a subject can be
> maximally fit and maximally evasive simultaneously, and P0-08 can only make that visible.**
> **`[DEPENDENCY: P0-01's difficulty classes (`P0-05 R9.2.2`'s `difficulty_class` is the inherited object) and its
> objective vector. `[OPEN: OR-S23]`**
> **`[DERIVATION]` `P0-05 R9.2.3` already establishes the shape of the fix — *"a ranking may not be a fitness input
> without a difficulty-controlled sample"* — and P0-08 supplies the difficulty-controlled abstention sample. Whether it
> is used is not P0-08's decision.**

---

# §171 — SELF-MODEL SECURITY

> ### **SO-R171.1 — THE TEN ATTACKS ON THE SELF-MODEL AS AN ATTACK SURFACE.** **[NORMATIVE]**
> | # | Attack | Defence | **Status** |
> |---|---|---|---|
> | **1** | **poisoning** — write false content into a self-model | the subject writes **content**; **K writes version, freshness, and status**; and content is advisory (`SO-C17.1(3)`). **Poisoned content that is never confirmed has no effect on any gate** | **CLOSED** — *residual: poisoned content that reaches EVA's sampled outputs is `RH-2` (`OR-S21`)* |
> | **2** | **replay** — replay an old healthy self-model | **`SO-R174.1`'s four defences: epoch binding · monotone K-issued versions · the fail-safe default · cross-check against three K-held records** | **CLOSED** |
> | **3** | **stale state** — act on a stale self-model | `freshness_class` is K-derived and mandatory on every read; `STALE`/`INVALID` may not authorize (`SO-R144.1`); `P0-07 HOM-R6.6`'s staleness-conservatism | **CLOSED** |
> | **4** | **privilege escalation** — a self-model assertion confers authority | **`SO-R172.1`: identity fields are REFERENCES to K-issued identities; no field of `OBJ-18` is an authority field; `D-S01` — P0-08 has no authority-bearing object** | **CLOSED-STRUCTURAL** |
> | **5** | **selective disclosure** — reveal favourable parts of a self-model | **coverage is K-written and mandatory on every read; `gap_class` travels with the value (`SO-R137.2`).** A partial disclosure is visible as a coverage gap | **CLOSED** — *residual: `P0-04 SP-5`/`OR-M9` — differential serving within an epoch is bounded, not preventable* |
> | **6** | **confidence manipulation** — raise stated confidence to win arbitration or attention | **`SO-R180.3`/`SO-INV-19`: confidence is not an input to arbitration, attention, diagnosis promotion, or scope. Confidence is a `P0-04` reference, not a local scalar** | **CLOSED-STRUCTURAL** |
> | **7** | **provenance forgery** — attach false `root_commit`/`causal_depth` | **provenance is K-written, hash-chained, append-only, `SEALED` terminal (`P0-07 EVO4`); `OBJ-01`'s provenance fields are references into that chain** | **CLOSED** — *residual: `P0-07 OR-H22` — provenance integrity rests on K* |
> | **8** | **capability inflation** | **`SM-14`: only EVA confirms; `CLAIMED` satisfies no gate** | **CLOSED** — *residual: inflation within EVA's probe gap, `OR-S12`/`P0-07 X-H6`* |
> | **9** | **capability suppression** | **not blocked — a limitation is a restrictive self-act and is always permitted. PRICED instead: `SO-R183.2` reports abstention and limitation rates by difficulty class** | **BOUNDED** — **`OR-S22`/`OR-S23`: detection requires `P0-01`'s difficulty classes and an objective that accounts for abstention** |
> | **10** | **identity substitution** | **`SO-R172.1`/`SO-R173.1`: identities are K-issued and identity-bound; a cloned self-model is a new claim with no evidence; `P0-06 R8.3(c)`'s no-id-reuse** | **CLOSED-STRUCTURAL** |
> **⟹ `SO-R171.2 — TALLY: 6 CLOSED · 2 CLOSED-STRUCTURAL · 1 BOUNDED · 1 CLOSED-with-residual. The three residuals all
> route outward: `RH-2` (`P0-01`/`OR-H5`), `G4`'s probe coverage (`P0-07 X-H6`), and the objective's treatment of
> abstention (`P0-01`). None is a self-model defect.**

---

# §171A — VOLUME E LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§128, §129, §130, §131, §132, §139, §140, §141, §171, §176, §177, §178, §180, §183** + canon **§17 self-model, §18 capability, §19 limitation, §20 metacognition, §21 attention, §22 global workspace** |
| Rules introduced | **SO-R128.1–.5, R129.1–.4, R130.1–.3, R131.1–.4, R132.1–.3, R139.1–.2, R140.1–.3, R141.1–.3, R171.1–.2, R176.1–.2, R177.1–.2, R178.1, R180.1–.3, R183.1–.4 · SO-C17.1–.2, C18.1–.2, C19.1–.2, C20.1–.3, C21.1–.2, C22.1–.4** |
| **§128 observer–observed** | **5 observation classes, 4 of them observations — `CAUSALLY-INTERVENING` is EXCLUDED from the type and belongs to repair/EIK.** `HC-S1` classified: **the informational perturbation channel is BOUNDED-BY-DESIGN (3 bounds); the resource perturbation channel is BROKEN (K-mediated)** · **`SO-INV-14`: an undeclared perturbation is a fault, origin `INSTRUMENT`** |
| **§129 observation cost** | **6 resources, all charged to B13** · **B13 is a new non-fungible last-cut reserve (amendment 15 requested)** · the §129 loop has **4 bounds, and bound 2 (a monitoring SHARE CEILING) is the one that works** — **the loop is TERMINATED at a ceiling, not balanced; no numeric value invented** |
| **§130 monitoring economics** | **priority MAY be optimized; necessity MAY NOT; cost is never a necessity argument.** **⟹ FW-6 IS REQUIRED and `HOM-INV-16` does NOT cover it: monitoring is ALLOCATION, not SELECTION, and no tier is involved** · **`SO-INV-15`** · the asymmetry that makes FW-6 necessary: **reducing a monitor produces no positive signal** |
| **§131 monitoring starvation** | **5 protections, and protection 4 (the reduction is itself a reported event) is load-bearing because protections 1–3 contain the damage but only 4 can reverse it** · **`OR-S20`: if the ledger itself fails, `SO-INV-02`'s default is the last thing standing** |
| **§132 monitoring gaming** | **4 defences with exact reach · 3 structural limits on secrecy · `[NON-CLAIM]`: undisclosed monitoring does NOT solve it; the residual is `RH-2`'s** |
| **Canon §17–§22** | **7 self-model rules · 4 capability rules · the limitation-is-always-permitted boundary · a 3-level metacognition hierarchy with no level 4 · 4 prohibited attention drivers + 1 constructive policy (attend to COVERAGE GAPS) · 4 workspace rules including "a broadcast IS a `P0-03` message"** |
| **§139–§141** | **6 aggregation properties, all governed by `SO-INV-16` (an aggregate's status ≤ min of its inputs — `P0-03 COMM-INV-08` inherited, so the proof is inherited not invented)** · **7 compression-preserved items + declared losses** · **4 rare-event rules: NO AVERAGING ON THE SEVERITY AXIS (`SO-INV-17`), `S3+` never compressed, `Q_pop` at every level, a rate axis needs its numerator too** |
| **§176–§178** | **individual ✅ · statistical population model ✅ (= `P0-07`'s `PopulationState`) · collective model ❌ (would be a second population authority)** · **3 distinct quantities (report count ≠ effective source count ≠ verification)** · **`SO-INV-18`: consensus is collapsed before it is counted — `Ne(clones)=1` in the epistemic domain** · **the `P0-07 HOM-R69.3` loop broken at step 3 by `OBJ-26` and at step 5 by `HOM-INV-43`; both needed** |
| **§180 confidence** | **confidence is a `P0-04` reference, not a local scalar** · **a 3-column table of what may raise, lower, and MUST NOT change confidence** · **`SO-INV-19`: confidence may not be an INPUT to any evidence-producing rule — 5 edges cut, so the loop is non-constructible rather than merely bounded** |
| **§183 abstention gaming** | **the rate is reported by difficulty class; P0-08 REPORTS and MAY NOT PRICE** (`P0-07 HOM-R14.1`) · **`OR-S23`: if `P0-01`'s objective ignores abstention, a subject can be maximally fit and maximally evasive at once, and P0-08 can only make it visible** |
| **§171 self-model security** | **10 attacks: 6 CLOSED · 2 CLOSED-STRUCTURAL · 1 BOUNDED · 1 CLOSED-with-residual. All three residuals route outward (`RH-2`, `G4`'s probe coverage, the objective's treatment of abstention) — none is a self-model defect** |
| New firewalls | **FW-6 — MONITORING NECESSITY separated from MONITORING COST** (continues `P0-07`'s FW-1…FW-5) |
| New invariants implied | **SO-INV-14** (undeclared perturbation = instrument fault) · **15** (a resource quantity may make an observation unaffordable, never a monitor unnecessary) · **16** (an aggregate's status ≤ min of inputs) · **17** (no averaging on the severity axis) · **18** (consensus is collapsed before counting) · **19** (confidence is not an input to any evidence-producing rule) — *formally numbered in Vol G* |
| Open research raised | **OR-S19** (the monitoring share ceiling is `[G]`) · **OR-S20** (protection under total ledger failure) · **OR-S21** (monitoring secrecy's reach; `RH-2`) · **OR-S22** (capability suppression needs `P0-01`'s difficulty classes) · **OR-S23** (whether the objective accounts for abstention is `P0-01`'s) |
| Amendments requested | **15** (`P0-05 §30` and `P0-07`'s reserve table gain **B13**) |
| Verification instruments | **SOMon-13** (no aggregate's status exceeds the minimum of its inputs) · **SOMon-14** (no severity axis is averaged) · **SOMon-15** (confidence appears in no arbitration, attention, promotion, or scope rule) · **SOMon-16** (every `PERTURBATIVE` observation has a non-null declared perturbation) · **SOMon-17** (a B13 draw below a declared floor emits an event to `[RO-13]`) |

**Next:** `68_` Vol F — §125 defense independence, §126 correlated failure, §127 independence claims, §133 evaluator
causality, §134 self-report selection bias, §135 silence as information, §136 reporting completeness, §137 reporting
coverage, §184 error-reporting incentives.
