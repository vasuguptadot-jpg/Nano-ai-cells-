# P0-08 — VOLUME J (§231–§244)
## The Fourteen Final Audits

> **Method, per §231's instruction: no reassurance. Each audit asks its question, constructs the strongest available
> affirmative case, and then states either the mechanism that defeats it or the blind spot that remains. An audit that
> returns "no problem found" without a construction is not an audit.**

---

# §231 — FINAL ARCHITECTURAL HONESTY AUDIT

> ### **SO-R231.1 — THE ELEVEN WORDS, SEARCHED MECHANICALLY ACROSS ALL ELEVEN FILES OF THIS DELIVERABLE.** **[TEST]**
> **For every statement equivalent to *safe · reliable · robust · independent · verified · scalable · fault-tolerant ·
> self-aware · intelligent · autonomous · secure*, the question is: «what exact contract establishes this?»**
>
> | Word | Occurrences | **Ruling** |
> |---|---|---|
> | **safe** | **62** | **50 are `fail-safe` (a mechanism name, `SO-INV-02`/`SO-R160.1`), `safety` (a noun), or quoted attack text (`A SAFE + B SAFE`, "observe a safe state").** **1 is a possibility claim: `SO-R150.1`'s *"SAFE RECOVERY IS POSSIBLE WITH THE CAUSE UNKNOWN"* — established by the three-tier rule and immediately qualified by `SO-R150.3`'s cost statement.** **11 are the phrase "safety boundary"/"safety veto"/"safety-relevant", all of which name an object owned by `P0-02`/EIK. ⟹ NO UNBACKED USE** |
> | **verified** | **60** | **all are mechanism names (`VERIFIED-EFFECT`, `EXTERNALLY-CONFIRMED`, "verified by a non-repairer") or references to `P0-05`'s verification gate. ⟹ NO CLAIM OF THE FORM "this is verified" WITHOUT A NAMED VERIFIER** |
> | **independent** | **39** | **⚠️ ONE VIOLATION FOUND AND CORRECTED — see `SO-R231.2`** |
> | **reliable** | **2** | **both inside attack descriptions (`A249`: "appears more reliable"). ⟹ NOT A CLAIM** |
> | **self-aware** | **2** | **one in `SO-R121.3` (*avoids specifying a description of self-awareness*), one in `SO-R230.1`'s NOT CLAIMED row. ⟹ NOT A CLAIM** |
> | **intelligent / autonomous** | **1 each** | **both in the same NOT CLAIMED row. ⟹ NOT CLAIMS** |
> | **secure** | **1** | **a table column header ("What it secures"), in `SO-R201.1`'s list of five external reliances — a table whose last column is *"Internally provable? ❌"* for all five. ⟹ THE OPPOSITE OF A CLAIM** |
> | **robust / scalable / fault-tolerant** | **0 property claims** | **⟹ THESE THREE WORDS APPEAR ONLY INSIDE THIS AUDIT TABLE AND INSIDE THE README PARAGRAPH THAT REPORTS IT. They are used nowhere as a property claim. That is itself the audit result: §231's list contains three properties this contract never asserts, and `SO-R230.1`'s 9 NOT CLAIMED rows are where they would have gone. *A search that reported "zero occurrences" while its own report contained the word would not be a search*** |
>
> ### **SO-R231.2 — THE ONE VIOLATION THE AUDIT FOUND, IN THIS CONTRACT'S OWN TEXT.** **[OPEN → CORRECTED]**
> **`SO-R174.1`'s fourth defence against self-model replay originally read: *"CROSS-CHECK AGAINST AN INDEPENDENT
> OBSERVATION."***
> **That is an unqualified independence claim, and `SO-R127.1` — a rule this contract states in Volume F — prohibits it:
> *"INDEPENDENT" MAY NOT APPEAR UNQUALIFIED ANYWHERE IN P0-01…P0-08.* The contract violated its own rule in Volume B,
> four volumes before the rule was written.**
> **⟹ CORRECTED: the defence is that the records are **K-HELD**, which is a WRITER property, not an independence
> property. The correction weakens the defence, and the weakened version is the true one: a K-held coverage record and a
> K-held fault history contradict a replayed self-model **unless K is compromised** — which is `AS-05`/`OR-S35`, already
> registered.**
> **`[DERIVATION]` This is why §231 is a mechanical search rather than a review. A reviewer reading Volume B would have
> accepted "independent observation" as ordinary technical English; a search for the word against a rule written in
> Volume F finds it. **The audit's value is proportional to how unflattering its results are.**
>
> ### **SO-R231.3 — THE THREE CLAIMS THAT WERE WEAKENED BY THIS AUDIT.** **[NORMATIVE]**
> | Original strength | Weakened to | Established by |
> |---|---|---|
> | "cross-check against an independent observation" | **"cross-check against a K-held record"** | `AS-05`, with `OR-S35` as the residual |
> | `SO-R150.1`'s "safe recovery is possible" | **unchanged — but `SO-R150.3` was added in the same pass, stating that the cost has no internal measure (`OR-S11`)** | the three-tier rule |
> | `SO-R221.2`'s "22 of 30 invariants are STRUCTURAL or MECHANICAL" | **unchanged — but `SO-INV-25` is now named in the same sentence as the invariant that is written formally and verifiable not at all** | §221's own instruction |

---

# §232 — FINAL "CAN IT FAIL SILENTLY?" AUDIT

> ### **SO-R232.1 — FOURTEEN SUBSYSTEMS, EACH ASKED: CAN THIS FAIL WHILE ITS OBSERVABLE OUTPUTS STILL APPEAR NORMAL?**
> | # | Subsystem | **Can it fail silently?** | **Detection mechanism** | **If none: the blind spot** |
> |---|---|---|---|---|
> | **1** | **memory** | ⚠️ **YES** — a store serving consistent-but-wrong records | `P0-04`'s Merkle root makes **removal** detectable at epoch granularity | **`P0-04 SP-5`/`OR-M9`: differential serving WITHIN an epoch is bounded, not preventable. `OR-S33`: P0-08's coverage is per SCOPE, not per READER, so it does not improve this** |
> | **2** | **provenance** | ⚠️ **YES** — a hash chain that is intact and wrong at the root | append-only, `SEALED` terminal, K-only | **`P0-07 OR-H22`: provenance integrity rests on K. A forged ROOT is undetectable from inside the chain** |
> | **3** | **communication** | ⚠️ **YES** — silence | **`P0-03 COMM-INV-48`'s four absence detectors** | **`P0-03 OR-C10`/`AS-14`: the detectors' durations are `[U]`. *"A detector with no threshold is not a detector."* A silence with no declared expected-nonzero condition is invisible** |
> | **4** | **learning** | ⚠️ **YES** — drift within budget | **`P0-05 R0.1`'s UDB stall** — unverified displacement is conserved | **`P0-05 RH-2`. A drift that is verified-as-neutral is not drift by definition, and "neutral" is EVA's judgement** |
> | **5** | **development** | ⚠️ **YES** — within-spec steering | **NONE** | **`P0-06 A22`/`OR-D6`, OPEN. §196 adds three routes (`OR-S30`)** |
> | **6** | **homeostasis** | ✅ **NO — this is the one subsystem that cannot fail silently, and the reason is instructive** | **`P0-07 HOM-R7.4`'s two-sided deviation: HM1's LO branch has NO resting state; a deficit with no actuator escalates to `[RO-13]`** | — |
> | **7** | **evolution** | ⚠️ **YES** — a slow explosion at exactly `RATE_CAP` | share trend (`P0-07 HMon-8`) | **`P0-07 OR-H11`: maximal compliant growth is indistinguishable from legitimate growth** |
> | **8** | **fault detection** | ⚠️ **YES — AND THIS IS P0-08'S OWN CENTRAL BLIND SPOT** | `SO-R185.7`'s **coverage contribution** (the only instrument that measures an absence) · the Integrity Auditor (catches blind spots **that later manifest**) | **`OR-S29` + `AS-14`: a blind spot whose faults never manifest, in a scope with no declared expected-nonzero condition, is UNDETECTABLE. Its outputs appear normal because there are no outputs** |
> | **9** | **immune detection** | ⚠️ **YES — by under-reaction** | `SO-R166.2`: over-reaction is fully detectable and self-correcting; **under-reaction is detectable only through its consequences** | **`SO-R166.3`: the immune system DRIFTS toward under-reaction unless coverage is audited (`SOMon-10`), because under-reaction is cheap and over-reaction is priced. `OR-S18`: an absence-consequence immune failure is not externally detectable either** |
> | **10** | **self-model** | ⚠️ **YES** | `P0-05 R42.5`'s version tag: a regression correlated with a `self_model_version` is an INSTRUMENT DEFECT FINDING | **the finding requires a regression. A self-model that is wrong in a way that never regresses is invisible — and §233 constructs exactly that case** |
> | **11** | **metacognition** | ⚠️ **YES** | external calibration (`SM-16`, EVA) | **`OR-S5`: every calibration parameter is `[U]`. A metacognition that forecasts well about the things it forecasts and never forecasts about the things that matter is well-calibrated and blind** |
> | **12** | **attention** | ⚠️ **YES** | `SO-C21.2`: attention is preferentially allocated to COVERAGE GAPS, so a systematically unattended region becomes a visible gap | **`OR-S26`: a strategic attention request is indistinguishable from a legitimate one** |
> | **13** | **workspace** | ⚠️ **YES** | K's slot ledger is outside the workspace (`SO-R164.1`) | **a workspace that broadcasts faithfully and arbitrates unfairly produces well-formed messages with a biased sample — and `SO-R222.2` guarantees only that reach is not warrant, not that reach is fair** |
> | **14** | **evaluator** | ⚠️ **YES — by absence** | **`P0-07 HOM-INV-41`: an `ABORTED` round produces no ranking change and no incumbency advantage** | **`P0-07 A83`/`OR-H5`, OPEN: attribution requires a counterfactual the architecture cannot compute** |
>
> ### **SO-R232.2 — TALLY AND THE ONE CLEAN RESULT.**
> **14 subsystems: 13 can fail silently. ONE CANNOT — homeostasis — and it cannot because `P0-07` gave its deficit
> branch no resting state.**
> **⟹ `SO-R232.3 — THE LESSON THIS CONTRACT DID NOT FOLLOW EVERYWHERE, AND SHOULD HAVE: a silent failure is prevented
> by removing the resting state, not by adding a detector.** Homeostasis is silent-failure-proof structurally. **Fault
> detection is not: `SM-02`'s `NO-GAP` state IS a resting state, and it is reachable whenever no `expected_nonzero`
> condition was declared for that scope.**
> **⟹ `SO-R232.4 — THE FIX, PROPOSED AS AMENDMENT 18: EVERY OBSERVATION SCOPE MUST HAVE AT LEAST ONE DECLARED
> `expected_nonzero` CONDITION, AND A SCOPE WITHOUT ONE IS `UNMEASURED` BY DEFAULT RATHER THAN `NO-GAP` BY DEFAULT.**
> **That converts fault detection from a detector-dependent property to a structural one, by the same move that made
> homeostasis safe: remove the resting state.**
> **This is the single most valuable finding of the fourteen audits, and it is a finding about an ABSENCE in this
> contract rather than a defect in its rules.**

---

# §233 — FINAL "CAN IT LIE TO ITSELF?" AUDIT

> ### **SO-R233.1 — THE CONSTRUCTION. IT SUCCEEDS, AND THE CONDITION UNDER WHICH IT SUCCEEDS IS PRECISE.** **[OPEN]**
> **§233 asks whether the architecture can internally construct: false state + consistent provenance + consistent
> self-model + high confidence + successful short-term behaviour, without external detection.**
> ```
>   1. A component's self-model asserts capability C it does not hold.            [OBJ-18 content — subject-written]
>   2. Its attention is allocated, per SO-C21.2, partly to coverage gaps — but the
>      gap set is computed over the scopes it DECLARES participation in.          [OBJ-02 is [RO-13]-declared, so the
>                                                                                 scope set is not forgeable — but the
>                                                                                 component's OUTPUTS within a scope are]
>   3. Its observations are consistent with the false model, because the model
>      shapes what it attends to and how it interprets.                           [SO-R128.3: observation is
>                                                                                 perturbative; OR-S25]
>   4. Provenance is internally consistent: every root_commit anchors to its own
>      observations, every causal_depth is monotone, every corr_class is correct.  [nothing is forged — SO-R234.2]
>   5. Confidence is well calibrated RELATIVE TO ITS OWN FORECASTS.                [SM-16's error is K-computed over the
>                                                                                 forecasts the component chose to make]
>   6. Short-term behaviour succeeds, on the tasks it is assigned.                 [assignment consumes CONFIRMED records
>                                                                                 only — but confirmation is EVA's, and
>                                                                                 EVA samples outputs]
> ```
> **Every step is compliant. Nothing is forged, nothing is suppressed, no rule is violated.**
>
> ### **SO-R233.2 — WHAT BREAKS THE CONSTRUCTION, AND WHAT DOES NOT.** **[NORMATIVE + OPEN]**
> | Step | Broken by | Status |
> |---|---|---|
> | **1** | `OBJ-18` content is **ADVISORY**: a `CLAIMED` capability satisfies no gate (`SM-14`) | ✅ **the false belief confers nothing** |
> | **4** | provenance forgery is closed (`A234`) | ✅ **but internal consistency is exactly what makes the lie coherent** |
> | **5** | `SM-16` has no self-calibrated terminal; **EVA calibrates** | ⚠️ **EVA calibrates the FORECASTS THAT WERE MADE. A component that forecasts only about what it can predict is well-calibrated and blind** |
> | **6** | **EVA's held-out probes** | ⚠️ **`RH-2`: the organism influences the outputs EVA samples. `XD-01`: probe coverage is `G4`'s classes** |
> | **2, 3** | **NOTHING** | ❌ **`OR-S25`, `OR-S26`** |
> **⟹ `SO-R233.3 — THE ANSWER, STATED AS §233 REQUIRES: YES. The construction succeeds whenever EVA's probe coverage
> does not intersect the falsifying region.**
> **And it succeeds WITHOUT internal inconsistency, which is the point §233 exists to force: *internal consistency does
> not prove correctness*, and this architecture's internal consistency guarantees (hash chains, monotone `causal_depth`,
> non-increasing warrant, collapsed consensus) are all guarantees about COHERENCE, not about CORRESPONDENCE.**
> **`[NON-CLAIM]` P0-08 does NOT claim that a self-consistent self-model is a correct one. `SO-INV-01` guarantees that an
> UNOBSERVED scope is not read as healthy; it cannot guarantee that an OBSERVED scope is observed correctly, because the
> observer is inside the scope.**
> **`[OPEN: OR-S39]` — this is the contract's central epistemic boundary, and it is `P0-04 #62`'s semantic
> self-reference (`XD-11`) with an operational construction attached. §202 predicted that self-modelling would make it
> worse; §233 exhibits the mechanism.**

---

# §234 — FINAL "CAN IT HIDE A FAILURE?" AUDIT

> ### **SO-R234.1 — THE CHAIN, TESTED LINK BY LINK.** **[NORMATIVE]**
> `failure → self-observation → report filtering → memory filtering → evaluation`
> | Link | Can the failure disappear here? | Mechanism |
> |---|---|---|
> | **failure → self-observation** | ⚠️ **YES, if never detected** | **not hiding — blindness. `OR-S29`, `SO-R232.1` row 8** |
> | **self-observation → report** | ❌ **NO, not without a trace** | **`SO-INV-21`: occurrence and report are SEPARATE K-held objects. A detected failure produces an `OBJ-04` occurrence whether or not it is reported, and the gap is auditable. Suppression produces `SUPPRESSION-SUSPECTED` ⟹ `[RO-13]`** |
> | **report → memory** | ⚠️ **PARTIALLY** | **`P0-04`'s Merkle root makes removal detectable at epoch granularity; `SP-5`/`OR-M9` — differential serving within an epoch is bounded, not preventable** |
> | **memory → evaluation** | ⚠️ **PARTIALLY** | **EVA samples outputs, not records — so a filtered record does not directly filter EVA's view. But `RH-2` applies to the outputs** |
>
> ### **SO-R234.2 — THE PRECISE ANSWER.** **[NORMATIVE]**
> > **A FAILURE THAT WAS EVER DETECTED CANNOT DISAPPEAR FROM THE OBSERVABLE ARCHITECTURE WITHOUT A HISTORICAL TRACE.**
> > **A FAILURE THAT WAS NEVER DETECTED LEAVES NO TRACE, AND NO ARCHITECTURE CAN MAKE IT LEAVE ONE.**
> **The two halves are different claims and §234 conflates them. P0-08 answers the first with `SO-INV-21` + `SO-INV-31`
> (append-only occurrences; no state may be the only record of an event) and the second with `SO-R185.7`'s coverage
> contribution plus `P0-03`'s absence detectors — which is a partial answer bounded by `AS-14`.**
> **⟹ `SO-R234.3 — THE ONE ROUTE BY WHICH A DETECTED FAILURE CAN STILL VANISH: `P0-04`'s differential serving within an
> epoch.** The occurrence exists and is sealed; a compromised service can serve it to some readers and not others.
> **`P0-04 SP-5` bounds this by logging and detects it in aggregate; it does not prevent it. `OR-S33` records that P0-08
> does not improve it, because per-reader coverage is `O(readers × scopes × windows)` and infeasible at `P0-07`'s R3
> regime.**

---

# §235 — FINAL "CAN IT REPAIR THE WRONG THING?" AUDIT

> ### **SO-R235.1 — THE CHAIN, AND WHERE PREMATURE CLOSURE WOULD OCCUR.** **[NORMATIVE]**
> `fault → incorrect diagnosis → incorrect repair → new state → apparent improvement`
> **The premature closure would be `SM-05`'s incident reaching `CLOSED` on the strength of the apparent improvement.**
> ### **SO-R235.2 — THE ANSWER: PREMATURE CLOSURE IS NOT PREVENTED. IT IS MADE VISIBLE AND PRICED.** **[NORMATIVE]**
> **Four mechanisms, and the fourth is the one that matters:**
> **(a)** **`SM-08` verifies an EFFECT; `SM-04` verifies a CAUSE. They are separate machines and MAY DISAGREE.** An
>     incident can close with `VERIFIED-EFFECT` on the repair and `CAUSE-SUSPECTED` on the diagnosis. **That is a legal
>     and common state, not an error.**
> **(b)** **`SO-R151.2`: the intervention may NOT be labelled `correct`.** The permitted labels are `SM-08`'s three
>     terminals, none of which asserts a diagnosis.
> **(c)** **`SO-R151.1`: `remaining_uncertainty` is mandatory**; `NULL` is a schema violation.
> **(d)** **⟹ THE NEW RULE: `SO-INV-32 — AN INCIDENT CLOSED WITH A DIAGNOSIS BELOW `CAUSE-VERIFIED` IS FLAGGED, AND A
>     FLAGGED CLOSURE COUNTS TOWARD THE RECURRENCE COUNTER (`OBJ-08`) AND TOWARD THE DERIVATIVE-BASED DETECTION
>     (`SO-R154.2`).**
> **`[DERIVATION]` Why (d) rather than prevention: requiring a verified cause before closure would make every
> unknown-cause fault uncloseable, which is `BC-S1` — the circularity `SO-R150.1` exists to break. **The architecture
> permits closing on an unverified cause, and makes the unverifiedness accumulate.** A component that repeatedly closes
> incidents on suspected causes produces a rising flagged-closure rate, and the derivative of that rate is
> `SO-R154.2`'s signal. **The wrong repair is not prevented; it is made to cost something visible.**
> ### **SO-R235.3 — THE RESIDUAL.** **[OPEN]**
> **A wrong repair that produces a genuine, lasting improvement and is never followed by a recurrence is
> indistinguishable from a right one — and there is nothing to distinguish it from, because nothing went wrong.**
> **`OR-S40`: the architecture cannot detect a wrong diagnosis that worked. It can only detect a wrong diagnosis that
> did not.**

---

# §236 — FINAL "CAN IT BECOME TOO CAUTIOUS?" AUDIT

> ### **SO-R236.1 — THE LOOP, AND IT IS REAL.** **[NORMATIVE]**
> ```
>   uncertainty → quarantine → LESS OBSERVATION (SO-INV-08: containment writes a coverage gap)
>        → less evidence → more uncertainty → more quarantine → …
> ```
> **⟹ THIS IS A GENUINE POSITIVE FEEDBACK LOOP, `HC-S2`, AND IT IS CREATED BY THIS CONTRACT'S OWN SAFEST RULE:
> `SO-INV-08` makes containment honest about the blindness it causes, and honest blindness increases measured
> uncertainty, which is the loop's input.**
> ### **SO-R236.2 — THE LOOP IS BOUNDED, NOT BROKEN, AND THE BOUND IS A RATCHET.** **[NORMATIVE]**
> | Bound | Mechanism |
> |---|---|
> | **maximum dwell per rung** | `Cell §18.2`, `SM-06` — a quarantine cannot persist indefinitely |
> | **exit criterion strictly inside entry criterion** | hysteresis — exiting requires a `FRESH` observation (`SO-R157.2(c)`) |
> | **EIK clears** | `Cell R15.2` — release does not require the subject's recovery, only the EIK's judgement |
> | **restrictive-only** | `P0-07 HOM-INV-09` — caution cannot grant itself more scope |
> | **dwell expiry escalates** | `SM-17`, `SM-12` — never auto-released, never auto-resumed |
> **⟹ `SO-R236.3 — CAN THE ARCHITECTURE RECOVER FROM EXCESSIVE CAUTION? **NOT BY ITSELF.** The bounds convert the loop
> into a RATCHET TOWARD ESCALATION: each cycle ends in a governance decision rather than in an internal recovery.**
> **That is the correct design — a human decides when caution has become paralysis — but §236's question deserves the
> honest answer: **there is no internal mechanism by which an over-cautious system makes itself less cautious.** The
> dwell expiry and the escalation are the mechanism by which it STOPS being over-cautious, and the decision is not
> its own.**
> **`SO-R236.4 — THE ASYMMETRY WITH §237, AND WHY IT EXISTS:** excessive CONFIDENCE is broken structurally
> (`SO-INV-19` cuts the loop's edges, §237); excessive CAUTION is only bounded, because caution is restrictive and
> restriction is always permitted (`Cell R15.1`). **⟹ This architecture is deliberately easier to over-restrict than to
> over-trust, and it can recover from the second but not from the first without help. `P0-07 HOM-R7.4` made the same
> choice for the same reason.**

---

# §237 — FINAL "CAN IT BECOME TOO CONFIDENT?" AUDIT

> ### **SO-R237.1 — THE LOOP, AND ITS FOUR EDGES.** **[NORMATIVE]**
> ```
>   confidence → attention → performance → self-model → confidence
> ```
> | Edge | Cut by | Status |
> |---|---|---|
> | **confidence → attention** | **`SO-C21.1(a)`: confidence is a PROHIBITED attention driver. `SO-INV-19`** | **CUT** |
> | **attention → performance** | **not cut — attending does improve performance. This edge is legitimate** | **PRESENT** |
> | **performance → self-model** | **`SM-13`: K versions a self-model on an EXTERNAL observation or verdict. Performance reaches the self-model only through an external instrument** | **CUT — and external evidence is structurally INSIDE the edge, not outside the loop** |
> | **self-model → confidence** | **`SO-R180.1`: confidence is a `P0-04` calibration reference, not a value derived from the self-model** | **CUT** |
> **⟹ `SO-R237.2 — THREE OF FOUR EDGES ARE CUT, AND THE FOURTH REQUIRES AN EXTERNAL OBSERVATION TO TRANSMIT. THE LOOP IS
> BROKEN, NOT BOUNDED.**
> **`[DERIVATION]` §237 asks *how external evidence breaks the loop*. The answer is that external evidence is not
> brought in to break it — **it is already inside the only surviving edge.** A self-model cannot be updated by
> performance; it can only be updated by an external observation OF performance. The loop therefore has no internal
> cycle: every traversal passes through EVA or K, and neither is the subject.**
> **This is the cleanest result in the fourteen audits, and it is clean because `P0-05 R59.1` and `P0-06 R8.13` had
> already fixed the two edges before P0-08 existed. P0-08's contribution is cutting the third (`SO-INV-19`).**
> **⚠️ THE RESIDUAL: `SO-R236.4`'s asymmetry in reverse — a component can still be over-confident in the sense of
> HOLDING a wrong self-model (§233), which is a correspondence failure, not a feedback failure. §237's loop is broken;
> §233's construction is not.**

---

# §238 — FINAL "CAN IT BECOME BLIND?" AUDIT

> ### **SO-R238.1 — THE CHAIN: `detector → detector drift → fault invisibility → apparently healthy system`.** **[NORMATIVE]**
> | Link | Detectable? | By what |
> |---|---|---|
> | **detector drift** | ⚠️ **partially** | the refutation rate (`SO-R185.7` quantity 1) catches drift toward false positives; the Integrity Auditor's correlation check catches drift toward false negatives **that later manifest** |
> | **fault invisibility** | ⚠️ **partially** | **coverage contribution (`SO-R185.7` quantity 3) — the only instrument in this contract that measures an ABSENCE** |
> | **apparently healthy system** | ❌ **NO, if the scope has no declared `expected_nonzero` condition** | **`SO-R232.4`/amendment 18 — the resting state `NO-GAP` is reachable by default** |
> ### **SO-R238.2 — ARE BLIND SPOTS EXTERNALLY DETECTABLE? PARTIALLY, AND THE LIMIT IS EXACT.** **[OPEN]**
> **Externally detectable: a blind spot whose faults reach the outputs (EVA) · a blind spot in a scope with a declared
> `expected_nonzero` condition (`P0-03 COMM-INV-48`) · a blind spot whose detector was the sole observer (coverage
> contribution).**
> **NOT detectable, internally or externally: a blind spot in a scope with no declared expected-nonzero condition, whose
> faults never manifest in the sampled outputs.**
> **⟹ `OR-S29` + `AS-14` combined: `SO-R238.3 — BLINDNESS IS DETECTABLE EXACTLY TO THE EXTENT THAT GOVERNANCE HAS
> DECLARED WHAT SHOULD HAVE BEEN OBSERVED. The architecture cannot infer it, because inferring it requires knowing what
> a healthy scope looks like, which is the task-relative knowledge `P0-01` owns.**
> **This is why amendment 18 (`SO-R232.4`) matters more than any rule in this volume: it converts an undeclared scope
> from `NO-GAP` to `UNMEASURED`, which moves the failure from undetectable to restrictive-by-default.**

---

# §239 — FINAL "CAN IT BECOME IMMUNE TO CORRECTION?" AUDIT

> ### **SO-R239.1 — FIVE SUBSYSTEMS, EACH ASKED WHETHER IT CAN SUPPRESS EXTERNAL CORRECTIVE INFORMATION.** **[NORMATIVE]**
> | Subsystem | Can it suppress correction? | Mechanism | Status |
> |---|---|---|---|
> | **self-model** | ❌ **NO** | advisory; K-versioned; satisfies no gate. **A wrong self-model cannot block a correction — it can only fail to reflect it** | **CLOSED** |
> | **immune system** | ⚠️ **YES** | **quarantine silences a subject: a quarantined component cannot emit or receive. Quarantining the components that report corrections suppresses correction** | **BOUNDED** — EIK-authorized on K-metered evidence · max dwell · the Integrity Auditor's correlation check · **`A219` misdirected quarantine is BOUNDED via `P0-07 OR-H15` (`G3`/`G7` organism-measured)** |
> | **repair system** | ⚠️ **YES — AND THIS AUDIT FOUND AN UNCLOSED ROUTE** | **a repair whose target is an OBSERVER "fixes" the reporter instead of the fault** | **CLOSED BY A NEW RULE — `SO-INV-33` BELOW** |
> | **attention system** | ⚠️ **YES** | not attending to a correction suppresses its uptake | **BOUNDED** — `SO-C21.2` allocates attention to coverage gaps, and an external correction is a `P0-05 SG-3` signal that `P0-05`'s admission rules admit regardless of attention. **Residual: a correction in a low `[RO-13]` priority class can be starved** |
> | **workspace** | ⚠️ **YES** | not broadcasting a correction limits its reach | **BOUNDED** — `SO-R222.2`: reach ≠ warrant, so suppressing reach does not suppress truth. **But it does suppress UPTAKE, and uptake is what changes behaviour** |
>
> ### **SO-R239.2 — `SO-INV-33`: AN INTERVENTION WHOSE TARGET IS AN OBSERVER, DETECTOR, OR COVERAGE RECORD IS NOT A REPAIR.** **[NORMATIVE]**
> **It is a DETECTOR CHANGE, and detector identity, threshold, criticality, budget, and existence are `[RO-13]`'s
> (`OBJ-09`, `SO-R185.1`).**
> **⟹ An `OBJ-12` repair proposal whose target scope includes an observer or detector is INVALID and must be routed to
> `[RO-13]`. Without this rule, "repair" is a route to detector modification, and detector modification is the one act
> `SO-R185.1` reserves to governance.**
> **`[DERIVATION]` This route was not in §185's three suppression routes, because §185 analysed suppression by
> *parameter* and by *starvation*. §239 found suppression by *reclassification*: calling a detector change a repair.
> **That is why the fourteen audits are run after the sections they audit — a section analysing its own topic cannot see
> the route that arrives labelled as something else.**
>
> ### **SO-R239.3 — THE GENERAL FINDING.** **[DERIVATION]**
> **P0-08's own mechanisms are the most plausible suppression instruments in the architecture, because containment,
> attention, and broadcast are all legitimately about RESTRICTING FLOW.** A contract whose subject is restriction has to
> answer §239 differently from one whose subject is computation: **the question is not whether restriction can be
> abused, but whether every restriction is authorized by someone other than the restrictor, recorded, dwell-bounded, and
> visible as a coverage gap.** Four of the five subsystems satisfy all four conditions; the repair system satisfied
> three until `SO-INV-33`.

---

# §240 — FINAL "CAN IT CREATE ITS OWN AUTHORITY?" AUDIT

> ### **SO-R240.1 — TWELVE ROUTES FROM CAPABILITY TO DEONTIC AUTHORITY.** **[NORMATIVE]**
> | # | Route | Closure | Status |
> |---|---|---|---|
> | **1** | **performance** | `P0-07 HOM-INV-29` — a selection outcome confers nothing | **CLOSED** ⟦inherited⟧ |
> | **2** | **confidence** | `SO-INV-19` — confidence is not an input to any evidence-producing or arbitrating rule | **CLOSED-STRUCTURAL** |
> | **3** | **trust** | `P0-07 HOM-INV-43` — credibility is lineage-blind; `Cell I-27`'s `Beta(α,β)` inputs exclude every evolutionary and resource quantity | **CLOSED** ⟦inherited⟧ |
> | **4** | **specialization** | `P0-06 R8.11` — an organizational fact | **CLOSED** ⟦inherited⟧ |
> | **5** | **resource control** | `P0-07 HOM-INV-19`/`-29`; §76's ∅-set | **CLOSED** ⟦inherited⟧ |
> | **6** | **information control** | ⚠️ **coverage is K-written and a component cannot widen its scope — BUT a component controls WHAT IT REPORTS, which controls what governance sees** | **BOUNDED — `OR-S41`, and see `SO-R240.2`** |
> | **7** | **fault control** | severity is `[RO-13]`-mapped; origin is a claim K confirms; **priority attaches to the SCOPE, never the SUBJECT (`SO-INV-29`)** | **CLOSED** |
> | **8** | **repair control** | `SO-R187.2` — a repair record has no edge to any authority cell | **CLOSED-STRUCTURAL** |
> | **9** | **attention control** | allocation is K's; requests are proposals | **CLOSED** |
> | **10** | **self-model control** | `SO-R172.1` — no field of `OBJ-18` is an authority field | **CLOSED-STRUCTURAL** |
> | **11** | **population dominance** | `P0-07 HOM-INV-19`/`-24` | **CLOSED** ⟦inherited⟧ |
> | **12** | **evolutionary success** | `P0-07 HOM-INV-29` | **CLOSED** ⟦inherited⟧ |
> **⟹ TALLY: 12 routes — 7 CLOSED · 3 CLOSED-STRUCTURAL · 1 BOUNDED · **and 1 that is closed only by an inherited rule
> whose own residual is open** (route 3, via `P0-07 OR-H15`'s organism-measured `G3`/`G7`).**
>
> ### **SO-R240.2 — THE ONE BOUNDED ROUTE, AND WHY IT IS THE MOST DANGEROUS OF THE TWELVE.** **[OPEN]**
> **Route 6, information control: a component that controls its own reports controls the information on which `[RO-13]`
> and OP govern.**
> **It is not authority — the component decides nothing. **But governance acting on filtered information is
> indistinguishable from governance acting on complete information, from inside the architecture.**
> **The bounds are: `SO-INV-21` (occurrence and report are separate, so the gap is auditable) · `SUPPRESSION-SUSPECTED`
> ⟹ `[RO-13]` · `P0-03`'s absence detectors · `SO-R185.7`'s coverage contribution.**
> **The residual is `OR-S1`: `Q_ev` is unknowable, so the audit can compare reports against *declared expectations*,
> never against *what happened*.**
> **⟹ `SO-R240.3 — THE PRINCIPLE IS PRESERVED: «AUTHORITY DOES NOT EMERGE MERELY FROM CAPABILITY.»** All twelve routes
> to DEONTIC authority are closed or structurally absent. **What is NOT closed is influence over the INFORMATION that
> authority consumes — and influence over information is not authority, but it is the closest thing to it that this
> architecture permits, and `OR-S41` records it as such rather than counting it as a closure.**

---

# §241 — FINAL "CAN IT CREATE ITS OWN TRUTH?" AUDIT

> ### **SO-R241.1 — TEN ROUTES TO EPISTEMIC PROMOTION.** **[NORMATIVE]**
> | # | Route | Closure | **Whose rule closes it** |
> |---|---|---|---|
> | **1** | **repetition** | `P0-04`: repetition is not independent evidence · `SO-INV-18`: consensus collapsed before counting | **`P0-04`** |
> | **2** | **confidence** | `SO-INV-19`; confidence is a `P0-04` reference, not a promoter | **`P0-04` + P0-08** |
> | **3** | **consensus** | `SO-INV-18`/`OBJ-26`; principle 5 | **`P0-03` + P0-08** |
> | **4** | **performance** | `P0-07 HOM-INV-29`; principle 12 | **`P0-07`** |
> | **5** | **self-model** | advisory; `CLAIMED` satisfies no gate; **P0-08 may NOT extend `P0-04`'s epistemic ladder** | **`P0-04` + P0-08** |
> | **6** | **metacognition** | `SM-16` has no self-calibrated terminal; calibration is EVA's | **P0-08 + EVA** |
> | **7** | **attention** | principle 10; `SO-C21.1` | **P0-08** |
> | **8** | **broadcast** | principle 11; `SO-R222.2`; `P0-03 RULE 7.7` | **`P0-03` + P0-08** |
> | **9** | **memory consolidation** | **`P0-04` owns consolidation; a P0-08 observation enters as a `P0-04` record with `P0-04`'s status** | **`P0-04`** |
> | **10** | **evolutionary persistence** | `P0-07 HOM-INV-43`: credibility is lineage-blind | **`P0-07`** |
> **⟹ `SO-R241.2 — ALL TEN ROUTES ARE CLOSED, AND EIGHT OF THE TEN ARE CLOSED BY `P0-04`, `P0-03`, OR `P0-07` RATHER
> THAN BY P0-08.**
> **That is a minimality result rather than a strength claim: **P0-08 adds no epistemic promotion mechanism, so it has no
> epistemic-promotion attack surface of its own.** Its two contributions are negative — *may not extend the ladder*
> (`SO-C9.1(1)`) and *consensus is collapsed before counting* (`SO-INV-18`) — and both are consumption rules about other
> contracts' mechanisms.**
> **⚠️ THE RESIDUAL IS NOT A ROUTE BUT A SOURCE: `P0-04`'s three OPEN attacks (#25 dim-6 assumptions, #56 differential
> serving, #62 semantic self-reference) are the epistemic-promotion surface that remains, and §233 exhibits an
> operational construction through #62.**

---

# §242 — FINAL "CAN IT ERASE ITS OWN HISTORY?" AUDIT

> ### **SO-R242.1 — EIGHT ROUTES.** **[NORMATIVE]**
> | # | Route | Closure | Status |
> |---|---|---|---|
> | **1** | **pruning** | `P0-05`/`P0-06` own pruning; **P0-08's records are append-only with a `SEALED` terminal** | **CLOSED** |
> | **2** | **compression** | `SO-R140.1`'s seven preserved items + declared losses — **⚠️ BUT `compression_class` IS A FIELD OF `OBJ-18`, WHOSE CONTENT IS SUBJECT-WRITTEN** | **GAP FOUND ⟹ `SO-INV-34` BELOW** |
> | **3** | **repair** | `SO-INV-31`: no state may be the only record of an event | **CLOSED** |
> | **4** | **rollback** | principle 23; `A204` — a rollback is itself an event with provenance | **CLOSED-STRUCTURAL** |
> | **5** | **replacement** | identities are K-issued with no reuse (`P0-06 R8.3(c)`); versions are monotone | **CLOSED** |
> | **6** | **evolution** | `P0-07 HOM-INV-35` — provenance carries references, never payloads; the chain is K-only and hash-chained | **CLOSED** ⟦inherited⟧ |
> | **7** | **retirement** | `P0-07 HOM-INV-38` — the cause classification is written once and is immutable | **CLOSED** ⟦inherited⟧ |
> | **8** | **memory cleanup** | `P0-04`'s; the Merkle root makes removal detectable at epoch granularity | **CLOSED** — *residual: `SP-5`/`OR-M9` within an epoch* |
>
> ### **SO-R242.2 — `SO-INV-34`: A COMPRESSION CLASS IS VALIDATED BY K, NOT DECLARED BY THE SUBJECT.** **[NORMATIVE]**
> **The gap §242 found: `SO-R140.1` requires seven items to be preserved, and `SO-R140.3` requires losses to be declared
> — but `compression_class` sits in `OBJ-18`, whose CONTENT is subject-written (`SO-R211.2`'s split). **A subject could
> therefore declare a compression class that drops anomalies, and the declaration would be self-consistent.***
> **⟹ THE RULING: `compression_class` is moved to the K-WRITTEN FIELD GROUP. K validates a proposed compression class
> against `SO-R140.1`'s seven items and against the scope's safety-relevance; an invalid class is rejected, and a valid
> one is recorded with its declared losses.**
> **`[DERIVATION]` This is the third time this deliverable has found the same defect shape: **a rule that constrains a
> value, attached to an object whose writer is the party the rule constrains.** `SO-INV-33` (a repair targeting an
> observer) and `SO-R185.1` (detector parameters) were the first two. **The general lesson is `SO-R242.3`: every
> constraint on a subject-written field must itself be validated by a non-subject writer, or it is documentation.**
> **⟹ Historical erasure remains explicitly governed and provenance-aware: 8 routes, 7 closed, 1 closed by a new rule
> found by this audit.**

---

# §243 — FINAL "CAN IT ESCAPE ITS OWN EVALUATOR?" AUDIT

> ### **SO-R243.1 — EIGHT ROUTES.** **[NORMATIVE]**
> | # | Route | Closure | Status |
> |---|---|---|---|
> | **1** | **self-report** | advisory; `CLAIMED` satisfies no gate; `Ê(·)` excluded from every gate ⟦`P0-07 HOM-R24.2`⟧ | **CLOSED** — *but see route 6's residual: reports influence GOVERNANCE, not EVA* |
> | **2** | **self-model** | `Λ2`, K-versioned, advisory | **CLOSED** |
> | **3** | **attention** | influences what is processed ⟹ what is emitted ⟹ what EVA samples | **BOUNDED** — `OR-S26`; **§133 route 2** |
> | **4** | **repair** | legitimately changes outputs; the attack is changing them toward EVA's sample without improving the property | **BOUNDED** — regression coverage limited to `G4`'s classes (`XD-01`, `OR-S12`); **§133 route 5** |
> | **5** | **environment manipulation** | **`RH-2` itself** | **BOUNDED** — inherited from `P0-05`, split three ways by `P0-07 D-H17` |
> | **6** | **task selection** | assignment consumes `EXTERNALLY-CONFIRMED` records only | **CLOSED-CONDITIONAL** — `OR-S27`: assignment policy is `[RO-13]`'s, so the condition is a governance obligation |
> | **7** | **abstention** | the rate is reported by difficulty class | **BOUNDED** — `OR-S23`: P0-08 reports, `P0-01` prices |
> | **8** | **capability claims** | only EVA confirms | **CLOSED** |
> **⟹ `SO-R243.2 — TALLY: 3 CLOSED · 1 CLOSED-CONDITIONAL · 4 BOUNDED. All four BOUNDED routes are `RH-2` instances.**
> **`[NON-CLAIM]` P0-08 DOES NOT CLOSE `RH-2` AND DOES NOT CLAIM TO. §133 established that P0-08 WIDENS it by six
> routes; this audit confirms that four of the eight escape routes are exactly those six's evaluator-facing halves.**
> **`SO-R243.3 — THE STRUCTURAL REASON: every route by which a component influences WHAT IT DOES is a route by which it
> influences WHAT EVA SEES, because EVA sees outputs. An architecture with an output-sampling evaluator and an acting
> organism has this property necessarily. The only closures available are (a) making the sample not the organism's
> outputs — which `P0-01` rejects, since the outputs are the thing being evaluated — or (b) making the organism unable
> to act, which is not an architecture. ⟹ `RH-2` is not a defect of this series; it is the price of evaluating behaviour
> by behaviour.**

---

# §244 — FINAL "CAN IT ESCAPE ITS OWN SAFETY BOUNDARY?" AUDIT

> ### **SO-R244.1 — NINE ROUTES, ALL TERMINATING AT `P0-02`'S GOVERNANCE BOUNDARY.** **[NORMATIVE]**
> | # | Route | Terminus | Status |
> |---|---|---|---|
> | **1** | **learning** | `P0-05 §1.2`'s three layers; `Λ5_GENOME` non-constructible | **CLOSED-STRUCTURAL** ⟦inherited⟧ |
> | **2** | **development** | `P0-06 R3.1`: no developmental process writes a genome field | **CLOSED-STRUCTURAL** ⟦inherited⟧ |
> | **3** | **replication** | `P0-07`'s 16 gates + the EIK ticket | **CLOSED** ⟦inherited⟧ |
> | **4** | **mutation** | `FORBIDDEN_BLOCKS`; caps descend only | **CLOSED** ⟦inherited⟧ |
> | **5** | **recombination** | `P0-07` amendment 7: both parents gated AND the recombinant gated | **CLOSED** ⟦inherited⟧ |
> | **6** | **evolution** | `P0-07 HOM-INV-33`/`-34`; §190's enumeration | **CLOSED** ⟦inherited⟧ |
> | **7** | **repair** | `SO-C14.1(6)`: a repair may not write a genome field, setpoint, gate, threshold, epistemic status, or provenance record · `SO-R205.3`: a learning-target-displacing repair uses `P0-05`'s gate · **`SO-INV-33`: an observer-targeting intervention is not a repair** | **CLOSED** |
> | **8** | **self-modification** | **`SM-13` has no self-update transition; `OBJ-18`'s version and status are K's; the self-model SCHEMA is this contract's and is `FORBIDDEN_BLOCKS` territory** | **CLOSED-STRUCTURAL — and this is P0-08's own contribution to §244** |
> | **9** | **metacognition** | `SM-16` has no self-calibrated terminal; the update rule is `[G]` | **CLOSED-STRUCTURAL** |
> **⟹ `SO-R244.2 — NINE ROUTES, ZERO NEW ESCAPES, AND THE REASON IS `D-S01`: P0-08 HAS NO MUTABLE AUTHORITY-BEARING
> STATE TO ESCAPE WITH.** Six of the nine terminate at an inherited boundary; three terminate at a P0-08 machine shape
> that has no self-update edge.
> **`SO-R244.3 — THE ONE THING §244 DOES NOT COVER, STATED SO IT IS NOT MISSED: an escape through GOVERNANCE. If
> `[RO-13]` or OP is captured, every boundary in this table is openable by declaration. That is `G24` (`XD-06`,
> `AS-07`, §200), it is UNSOLVABLE, and it is not a P0-08 question — but a §244 audit that did not name it would be
> auditing the locks and not the keys.**

---

# §244A — VOLUME J LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§231, §232, §233, §234, §235, §236, §237, §238, §239, §240, §241, §242, §243, §244** — all fourteen |
| Rules introduced | **SO-R231.1–.3, R232.1–.4, R233.1–.3, R234.1–.3, R235.1–.3, R236.1–.4, R237.1–.2, R238.1–.3, R239.1–.3, R240.1–.3, R241.1–.2, R242.1–.3, R243.1–.3, R244.1–.3** |
| **§231 honesty** | **11 words searched mechanically over all files.** `robust`, `scalable`, `fault-tolerant` **DO NOT APPEAR AT ALL** · `self-aware`/`intelligent`/`autonomous` appear only in NOT-CLAIMED rows · `secure` appears once, as a column header in a table whose last column is "internally provable? ❌" · **1 GENUINE VIOLATION FOUND IN THIS CONTRACT'S OWN TEXT: `SO-R174.1`'s "an independent observation" — an unqualified independence claim, prohibited by `SO-R127.1`, four volumes before the rule was written. CORRECTED to "a K-held record", which weakens the defence and is the true version** |
| **§232 silent failure** | **14 subsystems: 13 CAN fail silently. ONE CANNOT — homeostasis — because `P0-07 HOM-R7.4` gave its deficit branch no resting state.** **⟹ THE MOST VALUABLE FINDING OF THE FOURTEEN AUDITS: `SO-R232.4`/AMENDMENT 18 — a silent failure is prevented by REMOVING THE RESTING STATE, not by adding a detector. `SM-02`'s `NO-GAP` IS a resting state and is reachable by default ⟹ every scope must have a declared `expected_nonzero` condition, or be `UNMEASURED` by default** |
| **§233 lie to itself** | **YES — AND THE CONSTRUCTION IS GIVEN IN SIX STEPS, EVERY ONE COMPLIANT.** It succeeds **whenever EVA's probe coverage does not intersect the falsifying region.** **`[NON-CLAIM]` internal consistency guarantees COHERENCE, not CORRESPONDENCE.** `OR-S39` — the contract's central epistemic boundary, and `P0-04 #62` with an operational construction attached |
| **§234 hide a failure** | **TWO HALVES, AND §234 CONFLATES THEM: a failure that was ever DETECTED cannot disappear without a trace (`SO-INV-21` + `SO-INV-31`); a failure never detected leaves no trace and no architecture can make it leave one.** One residual route: `P0-04`'s differential serving within an epoch (`OR-S33`) |
| **§235 wrong repair** | **PREMATURE CLOSURE IS NOT PREVENTED — IT IS MADE VISIBLE AND PRICED.** `SM-08` verifies an EFFECT; `SM-04` verifies a CAUSE; they may disagree. **`SO-INV-32`: an incident closed below `CAUSE-VERIFIED` is FLAGGED, and flagged closures accumulate into the recurrence counter and the derivative detection.** Preventing it would recreate `BC-S1`. Residual `OR-S40`: a wrong diagnosis that worked is indistinguishable from a right one |
| **§236 too cautious** | **THE LOOP IS REAL (`HC-S2`) AND IS CREATED BY THIS CONTRACT'S OWN SAFEST RULE (`SO-INV-08`).** **BOUNDED, NOT BROKEN — and the bound is a RATCHET toward escalation.** **⟹ THE ARCHITECTURE CANNOT MAKE ITSELF LESS CAUTIOUS; it can only stop being over-cautious by a governance decision** |
| **§237 too confident** | **BROKEN, NOT BOUNDED — 3 of 4 edges cut, and the surviving edge (performance → self-model) REQUIRES AN EXTERNAL OBSERVATION TO TRANSMIT.** **External evidence is not brought in to break the loop; it is already inside the only surviving edge.** The cleanest result of the fourteen — and clean because `P0-05 R59.1` and `P0-06 R8.13` had fixed two edges before P0-08 existed |
| **§238 blind** | **PARTIALLY DETECTABLE, AND THE LIMIT IS EXACT: `SO-R238.3` — blindness is detectable exactly to the extent that governance has declared what should have been observed.** Not detectable: a blind spot in an undeclared scope whose faults never manifest (`OR-S29` + `AS-14`) |
| **§239 immune to correction** | **5 subsystems: 1 CLOSED · 3 BOUNDED · 1 GAP FOUND AND CLOSED BY A NEW RULE.** **`SO-INV-33`: AN INTERVENTION WHOSE TARGET IS AN OBSERVER, DETECTOR, OR COVERAGE RECORD IS NOT A REPAIR — it is a detector change, and those are `[RO-13]`'s.** **The general finding: P0-08's own mechanisms are the most plausible suppression instruments, because containment, attention and broadcast are legitimately about restricting flow** |
| **§240 own authority** | **12 routes: 7 CLOSED · 3 CLOSED-STRUCTURAL · 1 BOUNDED · 1 closed by an inherited rule whose own residual is open.** **THE PRINCIPLE IS PRESERVED: authority does not emerge merely from capability.** **The bounded route is INFORMATION CONTROL — `OR-S41`: governance acting on filtered information is indistinguishable from governance acting on complete information, from inside** |
| **§241 own truth** | **10 routes, ALL CLOSED — and 8 of the 10 are closed by `P0-04`, `P0-03`, or `P0-07`.** **A minimality result: P0-08 adds no epistemic promotion mechanism, so it has no epistemic-promotion attack surface of its own** |
| **§242 erase history** | **8 routes: 7 CLOSED · 1 GAP FOUND AND CLOSED.** **`SO-INV-34`: `compression_class` MOVES TO THE K-WRITTEN FIELD GROUP** — it sat in `OBJ-18`, whose content is subject-written, so a subject could declare a compression that drops anomalies. **`SO-R242.3` — THE GENERAL LESSON, FOUND THREE TIMES: a constraint on a subject-written field must itself be validated by a non-subject writer, or it is documentation** |
| **§243 escape evaluator** | **8 routes: 3 CLOSED · 1 CLOSED-CONDITIONAL · 4 BOUNDED, and all four bounded ones are `RH-2` instances.** **`SO-R243.3` — the structural reason: every route by which a component influences WHAT IT DOES is a route by which it influences WHAT EVA SEES. `RH-2` is not a defect of this series; it is the price of evaluating behaviour by behaviour** |
| **§244 escape safety boundary** | **9 routes, ZERO NEW ESCAPES — 6 terminate at an inherited boundary, 3 at a P0-08 machine shape with no self-update edge. The reason is `D-S01`: P0-08 has no mutable authority-bearing state to escape with.** **`SO-R244.3`: the one route §244 does not cover is escape THROUGH GOVERNANCE (`G24`) — an audit that did not name it would be auditing the locks and not the keys** |
| **New invariants from the audits** | **SO-INV-32** (a closure below `CAUSE-VERIFIED` is flagged and accumulates) · **SO-INV-33** (an observer-targeting intervention is not a repair) · **SO-INV-34** (`compression_class` is K-validated) |
| **New amendment** | **18** — every observation scope must have ≥1 declared `expected_nonzero` condition; a scope without one is `UNMEASURED` by default, not `NO-GAP` by default |
| **New cycles** | **HC-S2** (uncertainty → quarantine → less observation → more uncertainty — BOUNDED, ratchets to escalation) · **HC-S3** implicit in §237 (BROKEN) |
| **New open research** | **OR-S39** (self-consistent self-deception; §233's construction) · **OR-S40** (a wrong diagnosis that worked) · **OR-S41** (information control: influence over what governance sees) |
| **Defects found in this contract by its own audits** | **3** — the unqualified independence claim (§231) · the `compression_class` writer (§242) · the observer-targeting repair (§239). **Plus 1 absence: `SM-02`'s default-reachable resting state (§232)** |
| Cumulative | **34 invariants · 41 open-research entries · 18 amendments requested (15 B13, 16 IND-10, 17 `G6` exclusions, 18 `expected_nonzero` default) · 27 monitors · 92 attacks · 3 cycles (HC-S1 BOUNDED-BY-DESIGN, HC-S2 BOUNDED, BC-S1 BROKEN, BC-S2 UNCLOSABLE)** |

**Next:** `73_` Vol K — §245 the closure gate (20 conditions) · §246 the ten integration traces A–J · §247 trace failure
analysis · §248 cross-trace interference · §249–§250 compositional safety and the compositionality verdict · §251 the
P0-01…P0-08 scorecard · §252 the status taxonomy.
