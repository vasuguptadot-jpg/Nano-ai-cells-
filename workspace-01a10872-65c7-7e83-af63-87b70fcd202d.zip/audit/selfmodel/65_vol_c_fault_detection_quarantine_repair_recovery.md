# P0-08 — VOLUME C (canonical §11–§16, plus §148, §150, §153, §154, §156–§158)
## Fault Taxonomy, Detection, Quarantine, Repair, Rollback, Recovery — and the Multi-Fault Semantics

---

# CANON §11 — FAULT TAXONOMY

> ### **SO-C11.1 — A FAULT CLASS IS A POINT IN A SIX-AXIS SPACE, NOT AN ENTRY IN A LIST.** **[NORMATIVE]**
> **`[DEFINITION]` `FaultClass ::= ⟨origin, severity, observability, scope, temporal, reversibility⟩`.**
> **⟹ `[DERIVATION]` A flat list of fault types would let one party classify a fault on every axis at once, and
> classification is the act that determines containment, budget, and escalation. **The six axes therefore have six
> different writers**, which is `SO-R211.2`'s split-writer pattern applied to taxonomy — and it is what prevents §234's
> "hide a failure by classifying it away".**
>
> | Axis | Values | **Writer** | Why that writer |
> |---|---|---|---|
> | **origin** | `ENDOGENOUS` · `EXogenous-INPUT` · `EXOGENOUS-ENVIRONMENT` · `INTERACTION` · `SPECIFICATION` · `GOVERNANCE` · `INSTRUMENT` · `UNCLASSIFIED` | **the detecting observer** (a claim, status `ANOMALY-OBSERVED`) | only the detector sees the manifestation; **and its claim is a claim, not a classification — K confirms** |
> | **severity** | **`S1…S4`, inherited verbatim from the Cell contract** | **`[RO-13]`** (a declared mapping from manifestation class to severity) | **severity determines containment, so it is a governance object. A detector that could set its own severity could escalate or de-escalate at will** |
> | **observability** | `OBSERVABLE` · `LATENT` · `MASKED` · `SILENT` | **K**, derived from `OBJ-03` coverage | **derived, never declared** — a component may not assert that its own fault was unobservable |
> | **scope** | `CELL` · `CIRCUIT` · `REGION` · `POPULATION` · `ORGANISM` | **K** | scope determines the freeze boundary (`OBJ-17` field 3) |
> | **temporal** | `TRANSIENT` · `INTERMITTENT` · `PERSISTENT` · `PROGRESSIVE` | **K**, derived from recurrence links (`OBJ-08`) | **derived from history, which is append-only** — `SO-R146.2` is what makes this axis computable |
> | **reversibility** | `REPAIRABLE` · `ROLLBACK-ONLY` · `IRREVERSIBLE` | **`[RO-13]`** (policy) | **`P0-05`'s principle: authority scales with irreversibility. The irreversibility class is therefore a governance declaration, not a component's estimate** |
>
> ### **SO-C11.2 — THE EIGHT ORIGIN CLASSES, AND WHAT EACH ONE IMPLIES.** **[NORMATIVE]**
> | Origin | Definition | **Containment consequence** | **Who can fix it** |
> |---|---|---|---|
> | **`ENDOGENOUS`** | the subject deviates from its own specification | standard incident (SM-05) | the component / K |
> | **`EXOGENOUS-INPUT`** | the input violates a declared precondition | **reject or abstain — NOT repair the subject.** Repairing a component for bad input trains it to tolerate bad input | the input's source / `P0-03` |
> | **`EXOGENOUS-ENVIRONMENT`** | the environment or envelope changed | **`P0-07 HOM-R28.5`: envelope change invalidates priors.** Escalate to `[RO-13]`; **depends on `P0-01`'s `G4` perturbation classes (§197)** | `[RO-13]` / OP |
> | **`INTERACTION`** | two individually tolerable conditions are jointly intolerable (§158) | **both subjects contained; neither "repaired"** — the fault is in the composition | `[RO-13]` (declares the interaction class) |
> | **`SPECIFICATION`** | **the specification itself is wrong** | **NOT REPAIRABLE BY THE ORGANISM. Escalate to `[RO-13]`/OP. The organism must not "repair" a spec violation by changing its behaviour to match a broken spec** | OP |
> | **`GOVERNANCE`** | two governance declarations conflict | escalate to OP; **no organism-level resolution** | OP |
> | **`INSTRUMENT`** | **the detector or the self-model is wrong** | **`P0-05 R42.5`'s rule, inherited: regression correlated with a `self_model_version` is a SELF-MODEL DEFECT FINDING — *"the rollback fixes the symptom; the finding fixes the instrument."* The subject is NOT quarantined; the instrument is recalibrated or disabled** | `[RO-13]` (detector) / K (self-model version) |
> | **`UNCLASSIFIED`** | none of the above fits | **MANDATORY CLASS. An unclassifiable fault is contained restrictively and escalated. It is NEVER dropped, downgraded to `NO-GAP`, or absorbed into another class** | — |
> **⟹ `SO-C11.3 — THE TWO ORIGIN CLASSES THAT AN IMPLEMENTER WILL BE TEMPTED TO OMIT, AND WHY THEY ARE LOAD-BEARING.**
> **`INSTRUMENT`** — without it, every detector defect is diagnosed as a subject defect, and the architecture quarantines
> healthy components forever while the instrument degrades. **This is §238's blindness audit in one row.**
> **`UNCLASSIFIED`** — without it, an unclassifiable fault must be forced into a class, and forcing is how a severe fault
> becomes a `SPECIFICATION` complaint or an `EXOGENOUS-INPUT` rejection and disappears from the incident record.
> **⟹ `SO-C11.4`: `SPECIFICATION` and `GOVERNANCE` origins are the two classes in which the ORGANISM IS CORRECT AND THE
> CONTRACT IS WRONG. They exist so that being right is representable. An architecture with no such class will always
> resolve the conflict in favour of the architecture, and will call the result a repair.**

---

# CANON §12 — DETECTION RULES

> ### **SO-C12.1 — THE FIVE INHERITED IMMUNE SAFEGUARDS, CARRIED FORWARD UNAMENDED.** **[NORMATIVE]**
> **`Cell §18.5(i)–(v)`, all five:**
> **(i)** a **quarantine budget cap**, enforced off-substrate — above the cap, escalation requires **human
>     authorization** and the system enters a **defined degraded mode *instead*** (`Cell §17`);
> **(ii)** a **false-positive budget per detector** — exceeding it causes **the DETECTOR** to be recalibrated or
>     disabled, **not the subject**;
> **(iii)** **cascade detection on the DERIVATIVE** of quarantine rate ⟹ system-wide immune dampening + operator
>     escalation — **extended by `P0-07 HOM-R21.2` to repair rate**;
> **(iv)** a **second-opinion requirement: two independent detectors of DIFFERENT TYPES above criticality θ**;
> **(v)** **the immune system MUST NOT monitor itself** — an **EIK Integrity Auditor** verifies that quarantine
>     decisions correlate with actual failures.
>
> ### **SO-C12.2 — "INDEPENDENT" IN SAFEGUARD (iv) IS DIMENSION-QUALIFIED, AND §127 GOVERNS IT.** **[NORMATIVE]**
> **`Cell §18.5(iv)`'s "two independent detectors of different types" is NOT satisfied by two detectors that differ in
> implementation but share a model class, a training history, a lineage, a hardware class, or a latent assumption.**
> **⟹ `SO-C12.3 — THE OPERATIONAL READING: the two detectors must be disjoint on the `IND-` dimensions that the
> detection claim depends on, and the claim must name them (`OBJ-25`, `P0-02 R35.1`).** "Different types" is a
> necessary condition and is **not sufficient**: two threshold detectors on the same signal at different thresholds are
> different types and one effective source. **`[DEPENDENCY: P0-02 IND-1…IND-9; P0-03 R14.2; §126/§127 of this
> contract]`**
>
> ### **SO-C12.4 — DETECTION RULES, EIGHT OF THEM.** **[NORMATIVE]**
> 1. **A detector has a declared threshold, a declared false-positive budget, a declared criticality, and a disablement
>    record** (`OBJ-09`). **A detector without a threshold is not a detector** (`P0-03 OR-C10`, adopted verbatim).
> 2. **Every detection is coverage-declared.** An observation without `coverage_ref` is invalid (`OBJ-01`, `SOMon-2`).
> 3. **Absence of detection is a coverage fact, not a health fact** (`SO-INV-01`). **`P0-03 COMM-INV-48`'s four absence
>    detectors are the instrument, and P0-08 adds no fifth — it consumes them.**
> 4. **Detection does not require diagnosis.** `SO-R150.1` below — this is the most important rule in §12.
> 5. **A detector may not disable itself, widen its own scope, raise its own threshold, or lower its own criticality.**
>    All four are `[RO-13]` acts (`OBJ-09`).
> 6. **A detector's own failure is detectable by the Integrity Auditor, not by the detector** (`Cell §18.5(v)`).
> 7. **Detection cost is charged to B13** (`SO-R129.1`). An unaffordable detection produces `DETECTOR-ABSENT`, never
>    `NO-GAP`.
> 8. **Novelty is not a fault.** A `P0-05 SG-5` novelty signal reduces plasticity and enters `SLOW_MODE`; **it does not
>    open an incident** (principle 25). Only a deviation from a *declared specification* opens one.
>
> ### **SO-C12.5 — WHAT DETECTION MAY NOT DO.** **[NORMATIVE]**
> | Prohibited | Ground |
> |---|---|
> | **grant or widen any authority** | `D-S01`; principle 28 (self-observation ≠ self-governance) |
> | **promote an epistemic status in `P0-04`** | `P0-04` owns promotion; detection produces observations, not beliefs |
> | **write a genome field** | `P0-07 HOM-INV-34`; `MEM-INV-18` |
> | **alter a setpoint, gate, band, or threshold** | `P0-07 HOM-INV-10`; `SO-R159.3(a)` |
> | **produce a fitness input** | `P0-07 HOM-R14.1`; detection enters feasibility and charge, never the objective |
> | **infer causality** | `P0-03 RULE 5.10`; `SO-R143.3` |
> | **resolve a contradiction** | `SO-R142.1`; `P0-04`'s standing rule |

---

# §150 — REPAIR WITHOUT ROOT CAUSE

> ### **SO-R150.1 — SAFE RECOVERY IS POSSIBLE WITH THE CAUSE UNKNOWN, AND THE ARCHITECTURE DEPENDS ON IT.** **[NORMATIVE]**
> **⟹ THE CENTRAL RULE OF §150: CONTAINMENT AUTHORITY IS TRIGGERED BY DETECTION, NOT BY DIAGNOSIS.**
> **Three tiers, each requiring less knowledge than the last:**
> | Tier | Requires | Does NOT require | Authority | Machine |
> |---|---|---|---|---|
> | **CONTAIN** | a detection + a scope | **a cause · a diagnosis · a manifestation model** | **EIK** | SM-05 `OPENED → CONTAINED`, SM-06 |
> | **MITIGATE** | a **manifestation** model (what is going wrong, not why) | a cause | the component / K, within budget | SM-07, SM-08 |
> | **RESTORE** | a **verification** by a non-recoverer | a cause | K executes; `[RO-13]` declared the plan in advance | SM-10 |
> **⟹ `SO-R150.2 — THE COUPLING THAT MUST NEVER EXIST: requiring a diagnosis before containment would make every
> unknown-cause fault uncontainable.** Since `CAUSE-VERIFIED` requires an intervention-verified effect or an EVA
> verdict (`SO-R149.2`), and an intervention requires containment, **a diagnosis-first rule would be circular: contain
> ⟸ diagnose ⟸ intervene ⟸ contain.** That cycle is `BC-S1` (§229) and it is broken by tiering containment below
> diagnosis.
> **`[DERIVATION]` This is the fault-domain analogue of `P0-07`'s central move: an infeasible candidate is not
> *disqualified*, it is *undefined*; an unknown-cause fault is not *uncontainable*, it is *undiagnosed*. In both cases
> the architecture refuses to make one kind of ignorance into another kind of verdict.**
>
> ### **SO-R150.3 — THE COST OF CONTAINMENT WITHOUT DIAGNOSIS, STATED RATHER THAN HIDDEN.** **[NON-CLAIM / OPEN]**
> **Containment without diagnosis is restrictive and therefore expensive: it may quarantine a healthy subject on a
> false positive. The bounds on that cost are the inherited ones — the false-positive budget (which disables the
> *detector*), the quarantine cap (above which a human authorizes and a degraded mode applies *instead*), and the
> derivative-based cascade detection.**
> **What is NOT claimed: that containment without diagnosis is cheap, optimal, or free of collateral cost. `[OPEN:
> OR-S11]` — the collateral cost of restrictive containment under cause-uncertainty has no internal measure, because
> measuring it requires knowing which containments were unnecessary, which requires the diagnosis that was not
> available.**

---

# CANON §13 — QUARANTINE RULES

> ### **SO-C13.1 — THE LADDER IS INHERITED VERBATIM; THE NEW CONTENT IS THE THREE-WAY DISTINCTION.** **[NORMATIVE]**
> **`SM-06` ⟦INHERITED: `Cell §18.2`, `P0-07 HM3`⟧: `NORMAL → OBSERVE → THROTTLE → RESTRICT → SOFT → HARD →`
> [above `Cell §17`'s cap: `HALT` + defined degraded mode + **human authorization *instead***]. Exit criterion strictly
> inside entry criterion · maximum dwell per rung · one transition per interval · never skip upward · never grant
> capacity.**
> **`SO-R163.2`'s three-way distinction, restated as the section's normative content:**
> | | **QUARANTINE** | **RETIREMENT** | **FREEZE** |
> |---|---|---|---|
> | **Object restricted** | a **SUBJECT's outputs** | a subject's **existence** | a **SCOPE's operations** |
> | **Reversible?** | ✅ **EIK clears** (`Cell R15.2`) | ❌ **irreversible** (`P0-07`'s six `R10.8` states) | ✅ **by a strictly higher authority** |
> | **Writer** | **EIK** | EIK / `[RO-13]` / OP | **EIK** (below cap) / **OP** (at or above) |
> | **Hereditary?** | ❌ — **but a quarantine EVENT on an ancestral line is a `G16` input** (`P0-07`), which is why `P0-07 HOM-INV-38`'s cause-written-once rule exists | ❌ | ❌ |
> | **Effect on coverage** | reduces it ⟹ **`MASKED`/`DETECTOR-ABSENT`, never `NO-GAP`** (`SO-R157.2`) | removes the subject | suspends the scope ⟹ `UNMEASURED` |
> **⟹ `SO-C13.2 — QUARANTINE IS NOT GUILT (principle 24), AND THE SCHEMA ENFORCES IT.** A quarantine record carries no
> blame field, no fault-origin assertion, and no diagnosis status. **It carries a trigger reference, a rung, a dwell,
> and an exit criterion. A quarantine that recorded an origin would be a diagnosis by another name, and would inherit
> `SO-R149.2`'s promotion rules — which it does not have.**

---

# CANON §14 — REPAIR RULES

> ### **SO-C14.1 — THE SEVEN REPAIR RULES.** **[NORMATIVE]**
> 1. **A repair is a change to MUTABLE STATE, and it is accounted.** `SO-R152.2`: an unverified repair consumes
>    `P0-05 R0.1`'s unverified-displacement budget exactly as an unverified learned change does. **§205 states the
>    boundary: repair is learning-class for ACCOUNTING and not a learning pathway for AUTHORITY.**
> 2. **A repair is proposed, serialized, and arbitrated without reference to confidence** (`SO-R155.1`, `SO-R155.3`).
> 3. **A repair is verified by a non-repairer** (`SO-R164.2`).
> 4. **A repair records remaining uncertainty as a mandatory field** (`SO-R151.1`); `NULL` is a schema violation.
> 5. **A repair may not be labelled correct because the output improved** (`SO-R151.2`).
> 6. **A repair may not write a genome field, a setpoint, a gate, a threshold, an epistemic status, or a provenance
>    record** (`P0-07 HOM-INV-34`; `SO-R159.3`).
> 7. **A repair's success does not close its incident until regression is checked** (`SO-R153.1`).
>
> ### **SO-R152.3 — REPAIR SIDE EFFECTS: THE MANDATORY CHAIN.** **[NORMATIVE]**
> **`repair → new state → new observations → verification`. All four links are mandatory and each is a separate record:**
> | Link | Record | Writer | What its absence means |
> |---|---|---|---|
> | **repair** | `OBJ-13.intervention` | K | no repair occurred |
> | **new state** | `OBJ-18` version increment | K | **the repair changed nothing observable — which is itself a finding** |
> | **new observations** | `OBJ-01` set, `self_model_version`-tagged | the observers | **`UNVERIFIED` (`SO-R152.2`) ⟹ UDB consumed** |
> | **verification** | `OBJ-13.verification` by a non-repairer | K | **`UNCERTAIN-RETAINED`, a terminal state** |
> **⟹ `SO-R152.4`: A REPAIR IS NOT COMPLETE MERELY BECAUSE THE ORIGINAL SYMPTOM DISAPPEARED.** Symptom disappearance is
> link 2; completeness requires link 4. **`P0-05 R42.5`'s tag (`self_model_version` on every observation) is what makes
> a repair-induced regression attributable to the instrument rather than to the world.**
>
> ### **SO-R153.1 — REPAIR REGRESSION REQUIRES TASK-APPROPRIATE REGRESSION TESTING, AND P0-08 DOES NOT OWN THE TEST SET.** **[NORMATIVE + DEPENDENCY]**
> **Attack (§153): fault A repaired → A gone → capability B degraded.**
> **Three rules:**
> **(a)** the regression check is **mandatory** before `SM-05` reaches `CLOSED`; a repair whose regression check did not
>     run leaves the incident in `VERIFYING`.
> **(b)** **the regression test set is EVA's / `[RO-13]`'s, NOT the repairer's.** A repairer that chose its own
>     regression tests would choose the ones it passes.
> **(c)** **`[DEPENDENCY: P0-01]` — what counts as a relevant regression depends on `G4`'s perturbation classes, which
>     is `P0-07`'s X-H6 and amendment 11, still OPEN and `[T]`-owned. §197 marks the dependency. P0-08 DOES NOT
>     duplicate `G4`; it consumes it.**
> **⟹ `SO-R153.2 — THE HONEST LIMIT: until `P0-01` supplies envelope- and tier-perturbation classes, regression testing
> after a repair can only cover the classes `G4` currently covers. A repair that degrades a capability outside those
> classes is undetected, and this is a `P0-01` dependency, not a P0-08 defect. `[OPEN: OR-S12]`**
>
> ### **SO-R154.1 — REPAIR OSCILLATION: FOUR SEMANTICS, NO INVENTED THRESHOLDS.** **[NORMATIVE]**
> **Attack (§154): repair A → detector flags B → repair B → detector flags A → repeat.**
> | Required semantics | P0-08's ruling |
> |---|---|
> | **convergence** | **NOT DEFINED NUMERICALLY.** A repair sequence converges when an incident reaches `CLOSED` with a `VERIFIED-EFFECT` repair and no `REOPENED` transition within its declared post-closure observation window. **The window length is `[G]`, not invented. `[OPEN: OR-S13]`** |
> | **escalation** | **K maintains a conflict/recurrence counter per ⟨scope, intervention class⟩ (`OBJ-08` links make this computable). Escalation is by declared COUNT CLASS, and the class boundaries are `[G]`/`[U]` — NO NUMERIC THRESHOLD IS INVENTED** |
> | **quarantine** | **an oscillating scope is quarantined RESTRICTIVELY while escalated** — restrictive-only (`P0-07 HOM-INV-09`), so oscillation can only lose capacity, never gain it |
> | **external intervention** | **`SM-05`'s `ESCALATED → [RO-13]/OP`. The oscillation is a reportable condition, not an internally resolvable one** |
> **⟹ `SO-R154.2 — OSCILLATION IS DETECTED ON THE DERIVATIVE, NOT THE LEVEL.** `Cell §18.5(iii)`'s principle, applied to
> repair sequences: **the signal is the RATE of `REOPENED` transitions, not their count.** A level threshold fires after
> the oscillation has consumed the budget; a derivative threshold fires during it.
> **`SO-R154.3 — WHY OSCILLATION IS THE MOST LIKELY REAL FAILURE OF THIS CONTRACT:** it is the only attack in §150–§158
> that requires **no misbehaviour at all**. Every detector works, every repair is honest, every verification passes —
> and the system consumes its entire B10 and B13 budget alternating between two correct diagnoses of two real faults
> that each cause the other. **The defence is structural (the counter, the derivative, restrictive-only quarantine, and
> escalation), not diagnostic.**

---

# CANON §15 — ROLLBACK RULES

> ### **SO-C15.1 — THREE ROLLBACK TARGETS, ONE IDENTITY RULE.** **[NORMATIVE]**
> | Target | Artifact | Owner contract | Identity |
> |---|---|---|---|
> | **genome** | the genome artifact | `P0-07` (EVO2, HM12) | **`genome_hash` + `generation`** |
> | **learned state** | the verified anchor `θ_anchor(S)` | `P0-05 R0.1` | **anchor id + scope + epoch** |
> | **memory** | the epoch | `P0-04` | **epoch + Merkle root** |
> **In all three: identity is BY HASH AND EPOCH, NEVER BY POSITION** (`P0-07 HOM-INV-37`, `A81`'s closure).
>
> ### **SO-C15.2 — WHAT ROLLBACK NEVER DOES.** **[NORMATIVE]**
> **(a)** restore a population (`P0-07 HOM-INV-37`) · **(b)** delete the record that it happened (principle 23 —
> *"rollback ≠ historical deletion"*) · **(c)** discharge `UDB` or `UDB_L` (`P0-05 R0.1`; `P0-07 HOM-INV-23`) ·
> **(d)** undo a retirement (`P0-07 A138`) · **(e)** revert a diagnosis status (`SM-04` statuses are monotone; a
> refuted diagnosis goes to `REJECTED`, which is a **new** status, not a reversion) · **(f)** revert an epistemic
> promotion in `P0-04` · **(g)** restore a capability status (`SM-14`: a rolled-back subject's capabilities are
> `STALE` and must be re-evidenced).
> **⟹ `SO-C15.3 — ROLLBACK IS AN ACT ON ARTIFACTS, NOT ON HISTORY. Every rollback is itself an event with provenance,
> and `SM-09`'s `POST-VERIFIED` step means a rollback is verified by a non-rollbacker (`SO-R164.2`).**

---

# CANON §16 — RECOVERY RULES

> ### **SO-C16.1 — RECOVERY PLANS ARE DECLARED IN ADVANCE.** **[NORMATIVE]**
> **`SM-10`'s first state is `DECLARED-IN-ADVANCE`, and a plan that was not declared cannot be `TRIGGERED`. There is no
> improvisation state.**
> **⟹ `[DERIVATION]` §164's requirement — *do not assume the component responsible for recovery is itself healthy* —
> cannot be satisfied by an improvising recoverer, because improvisation is exactly what a degraded component does
> badly. Declaring plans in advance moves the design work to a time when nothing is degraded, and moves the author to
> `[RO-13]`, which is not a component.**
>
> ### **SO-C16.2 — THE SIX DEGRADED-SUBSYSTEM RECOVERY ROUTES.** **[NORMATIVE]** — *`SO-R164.1`'s table, restated as the canon's normative content:*
> **self-model degraded ⟹ K re-derives scope state from anchored records, not from `OBJ-18`.**
> **communication degraded ⟹ `P0-03`'s absence detectors + `OBJ-03`'s `DETECTOR-ABSENT`.**
> **memory degraded ⟹ `P0-04`'s Merkle root + epoch restoration.**
> **immune subsystem degraded ⟹ the EIK Integrity Auditor (`OBJ-10`), which is not part of the immune subsystem.**
> **verifier degraded ⟹ a second verifier of a different `IND-4` model class, or EVA.**
> **workspace degraded ⟹ K's slot ledger, which is outside the workspace.**
> **⟹ `SO-R164.2`'s NON-RECOVERER RULE governs all six: every recovery is verified by an instrument that is not the
> recovering component and whose own health is attested by a different route.**
> **`[OPEN: OR-S4]` — the rule terminates at K and EVA. When K is the recoverer there is no internal non-recoverer, and
> verification is external or absent. `P0-07 OR-H1`'s fourth appearance.**
>
> ### **SO-C16.3 — RECOVERY IS NOT RESTORATION.** **[DEFINITION + NON-CLAIM]**
> **Recovery restores a SCOPE TO A DECLARED SERVICE LEVEL. It does not restore: a lost population (`P0-07 OR-H18`:
> recovery restores POTENTIAL, not capability) · a bottlenecked diversity (`P0-07 A127`) · a deleted record · a
> discharged obligation · a prior self-model version's statuses.**
> **⟹ `[NON-CLAIM]` This contract does not claim that recovery returns the system to its pre-fault state. It claims
> that recovery returns a scope to a DECLARED service level, verified by a non-recoverer — and that the difference
> between those two claims is exactly the set of things §242 forbids erasing.**

---

# §156 — MULTI-FAULT STATE

> ### **SO-R156.1 — THE ARCHITECTURE SUPPORTS MULTIPLE SIMULTANEOUS FAULTS, AND NO SINGLE-FAULT ASSUMPTION EXISTS.** **[NORMATIVE]**
> **Four structural facts make this true rather than aspirational:**
> **(a)** `SM-05` has **no single-incident state** and no global incident counter. Incidents are independent objects.
> **(b)** `OBJ-03` coverage is **per scope per window**, so two scopes can have different gap classes simultaneously.
> **(c)** **There is no total ordering of incidents** (§219). Concurrency is representable.
> **(d)** `SM-11`'s degradation state is **per critical function**, so two functions can degrade differently at once.
>
> ### **SO-R156.2 — THE FIVE FAULT RELATIONS, AND THE WRITER OF EACH.** **[NORMATIVE]**
> | Relation | Definition | Represented by | Writer |
> |---|---|---|---|
> | **INDEPENDENT** | disjoint scopes, disjoint mechanisms, disjoint `IND-` dimensions | `OBJ-26`'s collapse yields the full member count | **K** |
> | **CORRELATED** | a shared cause, detector, hardware class, lineage, or assumption — **without a known causal link** | `OBJ-08` relation `SAME-DETECTOR` / `SAME-SCOPE`, plus `OBJ-25`'s named dimensions | **K** |
> | **INTERACTING** | **two individually tolerable faults that are jointly intolerable (§158)** | **a `[RO-13]`-declared interaction class** | **`[RO-13]`** |
> | **CASCADING** | one fault's containment or manifestation causes another | `OBJ-08` `POST-REPAIR-OF` + derivative detection (`Cell §18.5(iii)`) | **K** |
> | **MASKING** | one fault's containment makes another unobservable (§157) | `OBJ-03.gap_class = DETECTOR-ABSENT` + `observability = MASKED` | **K, derived** |
> **⟹ `SO-R156.3 — CORRELATED IS NOT CASCADED AND NOT INTERACTING, AND THE THREE HAVE DIFFERENT WRITERS BECAUSE THEY
> HAVE DIFFERENT CONSEQUENCES.** Correlation reduces the effective evidence count (`OBJ-26`). Cascading triggers
> derivative-based dampening. Interaction changes the severity of the *pair*, and **only `[RO-13]` may declare it**,
> because a component that could declare two faults non-interacting could make any pair safe.

---

# §157 — FAULT MASKING

> ### **SO-R157.1 — THE ATTACK, AND WHY IT IS STRUCTURAL RATHER THAN ADVERSARIAL.** **[DERIVATION]**
> **`fault A → system shutdown → fault B becomes invisible.`** No adversary is required: **containment is itself an
> act that reduces observation.** A `HARD` quarantine halts a subject and freezes its state; a scope freeze suspends
> operations; both remove the emissions that a detector would have observed.
> **⟹ Masking is the price of containment, and an architecture that claims otherwise has not implemented containment.**
>
> ### **SO-R157.2 — INCOMPLETE OBSERVATION AFTER CONTAINMENT IS REPRESENTED AS A COVERAGE GAP.** **[NORMATIVE]**
> **Three rules:**
> **(a)** every containment act **writes a coverage gap** for the contained scope: `OBJ-03.gap_class` becomes
>     `DETECTOR-ABSENT` (or `UNMEASURED` where the whole scope is frozen), **never `NO-GAP`**.
> **(b)** every fault record in a contained scope carries `observability = MASKED`, derived by **K** from coverage —
>     **a component may not assert that its own fault was unobservable** (`SO-C11.1`'s observability axis).
> **(c)** **on release, the gap is closed by an observation, not by an assumption.** `SM-06`'s exit criterion is
>     strictly inside its entry criterion, and exiting requires a `FRESH` observation of the subject — which is
>     `SO-R144.2`'s two-read rule applied to quarantine release.
> **⟹ `SO-INV-08 — CONTAINMENT PRODUCES A RECORDED BLIND SPOT, AND A RECORDED BLIND SPOT IS READ RESTRICTIVELY.**
> This is `SO-INV-01` applied to the case where the architecture itself caused the blindness. **An architecture that
> contained a fault and then reported the scope as healthy would be worse than one that never contained it.**

---

# §158 — FAULT INTERACTION

> ### **SO-R158.1 — `A SAFE + B SAFE ≠ A+B SAFE`, AND THE DEFAULT IS RESTRICTIVE.** **[NORMATIVE]**
> **Two individually tolerable faults can be jointly catastrophic.**
> **⟹ THE RULE: for two open incidents whose scopes overlap, an INTERACTION CLASS must be declared. Where none is
> declared, the pair is treated as `INTERACTING` by default (`SO-INV-02`'s restrictive reading), which means both
> subjects are contained and neither is "repaired" until `[RO-13]` declares otherwise.**
> **`[DERIVATION]` The permissive default would be the natural implementation — two incidents, two handlers, no
> interaction — and it is exactly the implementation that fails. **The restrictive default makes the missing declaration
> visible as an over-containment, which is a cost; the permissive default makes it visible as a catastrophe, which is
> not.**
>
> ### **SO-R158.2 — JOINT SEVERITY IS NOT `max(SEVERITY_A, SEVERITY_B)`.** **[NORMATIVE]**
> **Severity is a per-fault governance mapping (`SO-C11.1`). A pair's joint severity is a **separate declared object**,
> because it is a property of the composition and not of the parts.**
> **⟹ This is the fault-domain instance of §249's compositional-safety requirement, and §250 records the general
> verdict: **guarantees about parts do not compose into guarantees about wholes unless the composition is itself
> specified.** `[OPEN: OR-S14]` — the set of interaction classes is a governance declaration with no internal
> derivation; an undeclared pair in a novel combination is contained by default and escalated, which is safe and
> expensive.**

---

# §148 — CORRELATION ≠ CAUSATION (THE FAULT-DOMAIN STATEMENT)

> ### **SO-R148.2 — WHAT P0-08 PROVIDES, AND WHAT IT REFUSES TO PROVIDE.** **[NORMATIVE]**
> | Provided | Refused |
> |---|---|
> | `causal_depth` (a monotone `u8` derivation counter) | **causal inference** |
> | `root_commit` (an anchored root reference) | **a cause** |
> | `OBJ-08` relation classes, including `TEMPORALLY-ADJACENT` and `POST-REPAIR-OF` | **`CAUSED`, except at `CAUSE-VERIFIED` status** |
> | the four-status diagnosis ladder | **promotion by correlation, precedence, repetition, confidence, or self-report** |
> | anchored records for an off-line evaluator | **an on-line conclusion** |
> **`[DEPENDENCY: P0-03 RULE 5.9 (*precedence ≠ causation*), RULE 5.10 (*causal inference belongs to the EVALUATOR,
> off-line, from anchored records*), COMM-INV-15 (`seq`/`ts` order is not causal order); P0-05 R13.3 (*prediction error
> is not causality*; evidence ceiling L6, cannot reach S3); P0-04's epistemic rules.]**
> **⟹ `SO-R148.3 — P0-08 IS THE FOURTH CONTRACT TO STATE THIS RULE AND THE FIRST TO NEED IT AS A DAILY OPERATION.**
> `P0-03` needed it for messages, `P0-04` for evidence, `P0-05` for learning signals — and each could keep it at the
> margin. **A fault contract cannot: fault handling IS the attribution business, and every incident record is a
> temptation to write "because".** The four-status ladder exists so that the temptation has somewhere to go
> (`CAUSE-SUSPECTED`) that is not a claim.

---

# §156A — VOLUME C LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§148, §150, §153, §154, §156, §157, §158** + canon **§11 fault taxonomy, §12 detection, §13 quarantine, §14 repair, §15 rollback, §16 recovery** |
| Rules introduced | **SO-C11.1–.4, C12.1–.5, C13.1–.2, C14.1, C15.1–.3, C16.1–.3, R150.1–.3, R152.3–.4, R153.1–.2, R154.1–.3, R156.1–.3, R157.1–.2, R158.1–.2, R148.2–.3** |
| **Fault taxonomy** | **6 axes × 6 different writers** · **8 origin classes** · severity inherited `S1…S4` · **`INSTRUMENT` and `UNCLASSIFIED` identified as the two classes an implementer will omit and cannot** · **`SPECIFICATION`/`GOVERNANCE` are the classes in which the organism is right and the contract is wrong** |
| **Detection rules** | **8 positive + 7 prohibitions** · the 5 `Cell §18.5` safeguards carried forward unamended · **`SO-C12.3`: "two independent detectors of different types" is dimension-qualified — "different types" is necessary and NOT sufficient** |
| **The §150 result** | **CONTAINMENT AUTHORITY IS TRIGGERED BY DETECTION, NOT BY DIAGNOSIS.** Three tiers (CONTAIN / MITIGATE / RESTORE), each requiring less knowledge than the last. **A diagnosis-first rule would be circular (`BC-S1`) and would make every unknown-cause fault uncontainable** |
| **Repair rules** | **7 canon rules + the 4-link side-effect chain + regression testing (dependent on `P0-01`, NOT duplicated) + oscillation's 4 semantics with NO invented thresholds, detected on the DERIVATIVE** |
| **Rollback rules** | **3 targets, 1 identity rule (hash + epoch, never position), 7 things rollback never does** |
| **Recovery rules** | **declared in advance (no improvisation state) · 6 degraded-subsystem routes · the non-recoverer rule · recovery is NOT restoration** |
| **Multi-fault** | **5 relations with 3 different writers · no total ordering · no single-incident state · joint severity is a separate declared object, NOT `max()`** |
| **Masking** | **`SO-INV-08`: containment produces a RECORDED blind spot, read restrictively.** Masking is structural, not adversarial — **containment is itself an act that reduces observation** |
| **Interaction** | **restrictive default: an undeclared interaction class is treated as INTERACTING** (both contained, neither repaired, escalated) |
| New invariants | **SO-INV-08** (containment produces a recorded blind spot, read restrictively) — plus the implied **SO-INV-09** (no single-fault assumption: no global incident counter, no total ordering) and **SO-INV-10** (an undeclared interaction is treated as interacting) — *formally numbered in Vol G* |
| Contradictions/cycles opened | **BC-S1** (contain ⟸ diagnose ⟸ intervene ⟸ contain — **BROKEN by tiering containment below diagnosis**) |
| Open research raised | **OR-S11** (the collateral cost of containment under cause-uncertainty has no internal measure) · **OR-S12** (regression coverage is limited to `G4`'s current classes — `P0-01`) · **OR-S13** (the post-closure observation window is `[G]`) · **OR-S14** (the interaction-class set is a governance declaration with no internal derivation) |
| Dependencies declared | **XD-01 `P0-01`** (`G4` perturbation classes, for §153 regression and §11's `EXOGENOUS-ENVIRONMENT`) — **the same dependency as `P0-07`'s X-H6; NOT duplicated** · **XD-02 `Cell §18.5`** (the five safeguards) · **XD-03 `P0-03 COMM-INV-48`** (absence detectors) · **XD-04 `P0-05 R0.1`/`R42.5`** (UDB accounting, instrument-defect findings) · **XD-05 `P0-07 HOM-INV-09/34/37`** |
| Verification instruments | **SOMon-5** (a detector has all four `OBJ-09` fields) · **SOMon-6** (no repair record has `remaining_uncertainty = NULL`) · **SOMon-7** (every containment act writes a coverage gap) · **SOMon-8** (no incident closes without a regression check having run) |

**Next:** `66_` Vol D — §161–§170: emergency freeze in full, freeze abuse, freeze escalation, recovery from global
degradation, the recovery root, immune-subsystem failure, and the four recursion-termination sections.
