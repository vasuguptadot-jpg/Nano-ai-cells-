# V4 — SELF-OBSERVATION, FAULT, IMMUNE-DETECTION & METACOGNITION CONTRACT v1.0
## P0-08 CANONICAL SPECIFICATION — SELF-CONTAINED, 33 SECTIONS

**Status:** PROPOSED v1.0 · **architecture only, no implementation** · **33 canonical sections** · **28 architectural objects** · **21 state machines** · **34 invariants** · **26 registered parameters** · **92 catalogued attacks (A172–A263)** · **41 open-research entries** · **27 verification instruments** · **16 assumptions** · **4 amendments requested (15–18), none applied**
**Justification layer:** `63_` Vol A · `64_` Vol B · `65_` Vol C · `66_` Vol D · `67_` Vol E · `68_` Vol F · `69_` Vol G · `70_` Vol H · `71_` Vol I · `72_` Vol J · `73_` Vol K · `74_` Vol L.
**This document is normative and readable alone.** Where it states a rule without proof, the proof is in the volume named beside it.

> ## **ID CONVENTION — READ THIS FIRST.**
> **`SO-Cn.m`** = a **canon clause**, defined here, numbered by **CANON SECTION** (§11 → `SO-C11.m`).
> **`SO-Rn.m`** = a **volume rule**, defined in Volumes A–L, numbered by the brief's **SECTION** (§161 → `SO-R161.m`).
> Always in backticks when cited. **The two prefixes are disjoint by construction** — a convention adopted after `P0-07`'s
> sweep found that one ID denoting two rules makes a specification unreadable.

---

# §1 — SCOPE

> ### **SO-C1.1 — WHAT THIS CONTRACT SPECIFIES.** **[NORMATIVE]**
> The **observation layer** of the V4 architecture: how a cell, circuit, region, population, or organism observes its own
> state, faults, capabilities, and limitations; how faults are identified, classified, contained, repaired, rolled back,
> and recovered from; how the immune/detection subsystem behaves and is itself audited; how self-models, metacognitive
> records, attention allocations, and workspace broadcasts are represented; and how all of it remains **advisory**.
>
> ### **SO-C1.2 — THE CENTRAL DECISION.** **[NORMATIVE]**
> > ## **`D-S01` — P0-08 ADDS NO AUTHORITY. IT ADDS A TYPED OBSERVATION LAYER.**
> > **Every object this contract introduces is either (a) an OBSERVATION with declared coverage, freshness, provenance
> > and epistemic status, or (b) a RECORD of an act whose authority already belongs to another contract.**
> > **P0-08 introduces NO object that may authorize, allocate, permit, promote, select, or govern.**
> **Three consequences, each answering a mandatory requirement by construction:** §240 (self-created authority) — no
> authority-bearing object exists to capture · §165 (recovery root) — no second immutable kernel is created · §161
> (freeze) — no alternative governance system is possible.
>
> ### **SO-C1.3 — WHAT IS EXCLUDED, AND WHO OWNS IT.** **[NORMATIVE]**
> | Excluded | Owner |
> |---|---|
> | authorization semantics | **`P0-02`** |
> | the task, the objective, fitness | **`P0-01`** |
> | message warrant, propagation, correlation dedup | **`P0-03`** |
> | belief formation, epistemic promotion, evidence status | **`P0-04`** |
> | plasticity, UDB accounting, anchors, verification gates | **`P0-05`** |
> | differentiation, region identity, organizer specs | **`P0-06`** |
> | resources, population, replication, selection, budgets B0–B12 | **`P0-07`** |
> | **causal inference** | **the EVALUATOR, off-line, from anchored records** (`P0-03 RULE 5.10`) |
>
> ### **SO-C1.4 — THE FIVE MERGED TOPICS AND THE TEST THEY SHARE.** **[DERIVATION]**
> **Immune system · fault tolerance · error awareness · self-model · metacognition merge on four questions, all answered
> identically: WRITER = the observe-only component · TIMESCALE = within-lifetime · AUTHORITY ROOT = empty · INVARIANT =
> `P0-07 HOM-INV-44` (*the self-model may observe everything and authorize nothing*) plus `P0-06 R8.13` (*a model of a
> process may not be updated by the process it models*).**
> **Attention and the global workspace are specified here rather than merged into `P0-03`, because their arbiter's
> selection of *what is observed* is an observation-layer function. `SO-C22.4` states the condition under which this
> ruling reverses.**

---

# §2 — DEFINITIONS

> **[DEFINITION]** Each term is defined once. **No other section may use any of these terms in another sense, and no
> section may introduce a synonym.** Full 30-term table at Vol A canon §2; the twelve load-bearing terms:

| Term | Definition | **Distinguished from** |
|---|---|---|
| **OBSERVER** | a component that produces observations and holds **no authority** over their subject | a **verifier** (holds a `P0-01` verdict) · a **detector** (an observer with a declared threshold and false-positive budget) |
| **OBSERVATION** | a typed, timestamped, coverage-declared, provenance-carrying record that *some subject was in some state at some time, as seen by some observer* | a **claim** · a **verdict** · a **belief** |
| **SUBJECT / SCOPE** | the entity observed / the ⟨subject-class, boundary⟩ pair an observation covers | scope ≠ region: **a scope need not be a region** |
| **DETECTOR** | an observer with a declared threshold, false-positive budget, criticality, and disablement record | **`D-S02`: every fault-reporting observer IS a detector** |
| **FAULT** | a detection event asserting deviation from a **declared specification** | a **failure** (the deviation) · an **error** (`S1…S4`) · an **anomaly** (**novelty is not fault**) |
| **MANIFESTATION / DIAGNOSIS / INCIDENT** | the symptom / a causal claim with one of four statuses / the governed containment+repair+verification unit | **recurrences are LINKED to an incident, never collapsed into it** |
| **QUARANTINE** | a **reversible** restriction of a SUBJECT's outputs, imposed by the **EIK** | **retirement** (irreversible) · **freeze** (a SCOPE's operations) |
| **REPAIR / ROLLBACK / RECOVERY** | an intervention on mutable state with a recorded effect and remaining uncertainty / restoration of a prior artifact by hash+epoch / return of a scope to a **declared service level** | **recovery is NOT restoration of the pre-fault state** |
| **DEGRADATION** | a declared reduction in a function's service level | **failure** · **freeze**. **Degradation may not change governance semantics** |
| **EMERGENCY FREEZE** | a scoped, time-bounded, enumerated, restrictively-recoverable suspension, issued by an authority that cannot release it, recorded immutably | **quarantine** · **governance** |
| **SELF-MODEL** | a **`Λ2`** representation of a subject's own state, capabilities, and limitations, **not self-updating** | **ground truth** |
| **COVERAGE** | the quadruple ⟨`Q_pop`, `Q_ev`, `Q_rep`, `Q_ver`⟩ | **completeness. `Q_rep = Q_ev` is never an implicit assumption** |
| **FRESHNESS** | the age class of an observation relative to its subject's mutation rate | **correctness** |
| **INDEPENDENCE (qualified)** | disjointness on a **named subset** of `IND-1…IND-10` relative to a **named claim** | **independence (unqualified), which is prohibited** |
| **EFFECTIVE EVIDENCE SOURCE** | the number of observers in a set **after correlation collapse** | the number of observers. **Three correlated observers are one source** |
| **PERTURBATION CLASS** | `PASSIVE / PERTURBATIVE / SAMPLED / EXTERNALLY-PROBED` | **`CAUSALLY-INTERVENING` is NOT an observation class — it is an act** |
| **SILENCE** | the absence of a report — **eight distinct causes, of which "no fault" is one** | absence of fault |
| **RECOVERY ROOT** | the minimum substrate outside ordinary mutable cognition: `P0-02`'s EIK + K's anchored stores + `[RO-13]`'s declared plans + the fail-safe default | **a second immutable kernel — which is NOT created** |

---

# §3 — ARCHITECTURAL OBJECTS

> ### **SO-C3.1 — 28 OBJECTS, EACH WITH ONE WRITER OR A DISJOINT FIELD-GROUP SPLIT.** **[NORMATIVE]**
> `OBJ-01` **Observation** (observer) · `OBJ-02` **ObservationScope** (`[RO-13]`) · `OBJ-03` **CoverageRecord** (**K**) ·
> `OBJ-04` **FaultOccurrence** (the detecting observer) · `OBJ-05` **Manifestation** (observer) · `OBJ-06` **Diagnosis**
> (**K**, status only) · `OBJ-07` **Incident** (**EIK**) · `OBJ-08` **FaultLineageLink** (**K**) · `OBJ-09` **Detector**
> (`[RO-13]`) · `OBJ-10` **DetectorIntegrityRecord** (**the EIK Integrity Auditor**) · `OBJ-11` **QuarantineState**
> (**EIK**) · `OBJ-12` **RepairProposal** (proposer; **K** serializes) · `OBJ-13` **RepairRecord** (**K**) · `OBJ-14`
> **RollbackTarget** (**K**) · `OBJ-15` **RecoveryPlan** (`[RO-13]`, **declared in advance**) · `OBJ-16`
> **DegradationState** (**K** state / `[RO-13]` policy) · `OBJ-17` **FreezeOrder** (**EIK** below cap / **OP** at or
> above) · `OBJ-18` **SelfModelState** (subject writes **content**; **K** writes version, freshness, status,
> `compression_class`) · `OBJ-19` **CapabilityRecord** (subject claims; **K** status; **EVA** confirms) · `OBJ-20`
> **LimitationRecord** (subject) · `OBJ-21` **MetacognitiveRecord** (subject forecasts; **K** computes error; **EVA**
> calibrates) · `OBJ-22` **AbstentionRecord** (subject) · `OBJ-23` **AttentionAllocation** (**K**) · `OBJ-24`
> **WorkspaceSlot** (**K**, single-writer arbiter) · `OBJ-25` **IndependenceClaim** (claimant) · `OBJ-26`
> **ObserverSet** (**K**) · `OBJ-27` **B13ObservationBudget** (**K** administers / `[RO-13]` sizes) · `OBJ-28`
> **CanonicalEvent** (**`P0-03`'s event layer**).
> **⟹ Writer distribution: K 10 · subject 9 · EIK 4 · `[RO-13]` 4 · OP 1 · `P0-03` 1. The subject writes 9 of 28, and
> ALL NINE are observations, records, or proposals — never a classification, status transition, coverage figure,
> allocation, or authorization.**
>
> ### **SO-C3.3 — THE THREE OBJECTS THAT DO NOT EXIST.** **[NORMATIVE — by omission]**
> **a FaultAuthority / IncidentCommander** (containment is the EIK's, budget is K's, policy is `[RO-13]`'s) · **a
> SelfModelStore** (`OBJ-18` is a **`P0-04` record class**, not a second memory) · **a DiagnosisEngine /
> RootCauseAnalyzer** (causal inference is the EVALUATOR's, off-line — an internal cause-inferrer would be a second
> evaluator).

---

# §4 — STATE SCHEMAS

> ### **SO-C4.1 — `OBJ-01 Observation`, FOURTEEN MANDATORY FIELDS.** **[NORMATIVE]**
> `obs_id` (K-registered) · `observer_id` (K-issued, **no reuse**) · `subject_ref` · `scope_ref` (`[RO-13]`-declared; **an
> observer may not widen it**) · `observed_at` (**monotone per-envelope; NOT a global clock**) · `freshness_class`
> (`FRESH/AGING/STALE/INVALID`, **K-derived**) · `obs_class` (`PASSIVE/PERTURBATIVE/SAMPLED/EXTERNALLY-PROBED`) ·
> `perturbation` (**MANDATORY if `PERTURBATIVE`**) · `coverage_ref` (**MANDATORY — `SO-INV-01` is unenforceable without
> it**) · `epistemic_status` (**`P0-04`'s; P0-08 may not extend it**) · `root_commit` ⟦`P0-03`⟧ · `causal_depth`
> (**`u8`, ⟦`P0-03` field 8: *"replaces the vector clock"*⟧**) · `corr_class` ⟦`P0-03`'s six dimensions⟧ ·
> `independence` (**`OBJ-25`, MANDATORY if offered as corroborating**) · `cost_charged` (**B13, six dimensions — no
> observation is free**) · `self_model_version` (⟦`P0-05 R42.5`: a regression correlated with a version is an
> **INSTRUMENT DEFECT FINDING**⟧) · `confidence_ref` (**a `P0-04` calibration reference, never a local scalar**) ·
> `abstention_ref`.
> **⟹ The three fields an implementer is most likely to omit, and what each omission disables: `coverage_ref` ⟹
> `SO-INV-01` · `cost_charged` ⟹ §129's loop · `self_model_version` ⟹ `P0-05 R42.5`'s instrument-defect detection.**
>
> ### **SO-C4.2 — `OBJ-03 CoverageRecord`.** **[NORMATIVE]**
> `scope_ref` · `window_id` · **`Q_pop ⊆ N`** (observed population) · **`Q_ev`** (observed events; **UNBOUNDED ABOVE —
> not knowable in general, `OR-S1`**) · **`Q_rep ⊆ Q_ev`** · **`Q_ver ⊆ Q_rep`** · **`expected_nonzero`** (the declared
> condition under which `Q_ev` MUST be > 0, ⟦`P0-03 R67.4`⟧) · **`gap_class`** ∈ {`NO-GAP`, `SAMPLING-GAP`,
> `SUPPRESSION-SUSPECTED`, `DETECTOR-ABSENT`, `FREEZE-INDUCED`, `UNMEASURED`} · `absence_detector_ref` (⟦`P0-03
> COMM-INV-48`⟧).
> **`SO-INV-22`: every health-consuming read MUST read `gap_class` in the same read.**
> **AMENDMENT 18: a scope with NO declared `expected_nonzero` condition is `UNMEASURED` BY DEFAULT, not `NO-GAP` by
> default.** *(Vol J §232: `NO-GAP` was a reachable resting state, and a silent failure is prevented by removing the
> resting state rather than by adding a detector.)*
>
> ### **SO-C4.3 — `OBJ-06 Diagnosis`, THE FOUR-STATUS CAUSAL LADDER.** **[NORMATIVE]**
> `status` ∈ **`ANOMALY-OBSERVED → CAUSE-SUSPECTED → CAUSE-SUPPORTED → CAUSE-VERIFIED`** (+ `REJECTED`, retained) ·
> `localization` (**a WHERE — separate field, and NO rule permits it to promote `status`**) · `evidence_refs[]`
> (**references, never payloads**) · `intervention_ref` · `external_verdict_ref` (**REQUIRED for `CAUSE-VERIFIED`**) ·
> **`residual_uncertainty` (MANDATORY — a diagnosis with no stated residual is a schema violation, not a confident
> diagnosis)**.
> **Promotion drivers and EXCLUDED drivers at §12 below.**
>
> ### **SO-C4.4 — `OBJ-17 FreezeOrder`, NINE MANDATORY FIELDS.** **[NORMATIVE]**
> **1 trigger** (a reference, never a narrative) · **2 authority** (**EIK** below `Cell §17`'s cap / **OP** at or above;
> **never the subject, never K alone**) · **3 scope** (**a scopeless freeze is INVALID — NOT global by default**) ·
> **4 duration semantics** (**MAX-DWELL + release condition; NOT wall-clock expiry**) · **5 preserved state** (state
> frozen, in-flight captured as evidence) · **6 blocked operations** (**ENUMERATED — an unenumerated operation is NOT
> blocked**) · **7 permitted recovery operations** (**ENUMERATED and RESTRICTIVE-ONLY**) · **8 release authority**
> (**STRICTLY HIGHER than the trigger authority**) · **9 audit record** (**immutable once sealed**).
>
> ### **SO-C4.5 — `OBJ-18 SelfModelState`.** **[NORMATIVE]**
> `subject_ref` · `version` · `observed_at` · `freshness_class` · **`lambda_class = Λ2` (FIXED)** · **`updated_by = K`,
> on an external observation or verdict — NEVER the subject, NEVER the modeled process** · `capability_refs[]` (all
> **ADVISORY**) · `limitation_refs[]` · `granularity` ∈ {`CELL`, `CIRCUIT`, `REGION`, `POPULATION`, `ORGANISM`} ·
> **`locality_class`** (which facts are LOCAL-ONLY and may not be aggregated upward) · **`compression_class`**
> (**K-VALIDATED, NOT SUBJECT-DECLARED — `SO-INV-34`**) · **`contradiction_refs[]` (carried, NOT resolved)**.

---

# §5 — STATE MACHINES

> ### **SO-C5.1 — 21 MACHINES, ALL MANDATORY FOR CONFORMANCE C1.** **[NORMATIVE]**
> **Bold** = terminal or absorbing. **A transition with no named writer does not exist.**
> | ID | Machine | Writer | **Load-bearing property** |
> |---|---|---|---|
> | **SM-01** | Observation lifecycle | observer / **K** | **`UNOBSERVED` is a STATE, not an absence. NO edge to any health-bearing state exists** |
> | **SM-02** | Coverage gap class | **K** | every state except `NO-GAP` forces restrictive reading; `SUPPRESSION-SUSPECTED` routes to `[RO-13]` |
> | **SM-03** | FaultOccurrence | observer / **K** | **`UNCONFIRMED` is NOT `FALSE` — it is retained, because discarding it destroys the recurrence rate** |
> | **SM-04** | Diagnosis ladder | **K** | **no transition driven by correlation, precedence, repetition, confidence, or self-report** |
> | **SM-05** | Incident | **EIK** | **no single-incident state, no global counter, no total ordering — multi-fault by construction** |
| **SM-06** | Quarantine ⟦INHERITED: `Cell §18.2`, `P0-07 HM3`⟧ | **EIK** | exit strictly inside entry · max dwell · one transition per interval · **never skip upward · never grant capacity** |
> | **SM-07** | RepairProposal | proposer / **K** | **arbitration is NOT by confidence**: EIK safety veto → `[RO-13]` priority → reversibility → recorded order |
> | **SM-08** | RepairRecord | **K** | **`UNCERTAIN-RETAINED` is TERMINAL — never promoted by time, repetition, or absence of regression** |
> | **SM-09** | Rollback | **K** | identity by **hash + epoch, NEVER position** |
> | **SM-10** | RecoveryPlan | `[RO-13]` / **K** / non-recoverer | **`DECLARED-IN-ADVANCE` is the first state; an undeclared plan cannot be `TRIGGERED`. No improvisation state** |
> | **SM-11** | DegradationState | **K** / `[RO-13]` | per-function policy; **the undeclared default is `ISOLATE` then `ESCALATE`, never `CONTINUE`** |
> | **SM-12** | FreezeOrder | **EIK** / **OP** | **never auto-expires into normal operation; never peer-released** |
> | **SM-13** | SelfModelState | **K** | **NO self-update transition exists** |
> | **SM-14** | CapabilityRecord | subject / **K** / **EVA** | **`CLAIMED` satisfies no gate** |
> | **SM-15** | LimitationRecord | subject | declaring a limitation is a **restrictive self-act, always permitted** |
> | **SM-16** | MetacognitiveRecord | subject / **K** / **EVA** | **NO self-calibrated terminal state exists** |
> | **SM-17** | AbstentionRecord | subject | **a mandatory recovery condition; dwell expiry escalates, never auto-resumes** |
> | **SM-18** | AttentionAllocation | **K** | **no self-allocation; no allocation driven by confidence, a capability claim, a workspace request, or a self-model state** |
> | **SM-19** | WorkspaceSlot | **K** (arbiter) | **a slot is a RESOURCE; winning one is not evidence and not authority** |
> | **SM-20** | DetectorIntegrity | `[RO-13]` / **the EIK Integrity Auditor** | **a DISABLED detector produces `DETECTOR-ABSENT`, NOT `NO-GAP`** |
> | **SM-21** | ObserverSet | **K** | **`effective_sources ≤ |members|`; three correlated observers yield 1** |
> **⟹ `SO-C5.2 — FOUR STRUCTURAL FACTS: (a) NO MACHINE HAS A SELF-UPDATE TRANSITION. (b) FIVE MACHINES TERMINATE IN A
> *REPORT* RATHER THAN A RESOLUTION — an architecture that resolved every uncertainty internally would have no need for
> an external evaluator, and this one has one. (c) THREE MACHINES ENFORCE `SO-INV-01` BY THE ABSENCE OF AN EDGE.
> (d) NO AGE-KEYED TRANSITION AND NO VECTOR CLOCK ANYWHERE.**

---

# §6 — WRITER CLASSES

> ### **SO-C6.1 — THE SPLIT-WRITER PATTERN IS THIS CONTRACT'S MAIN STRUCTURAL DEVICE.** **[NORMATIVE]**
> **Four object classes are written by two or three parties along DISJOINT FIELD GROUPS:**
> | Object | **subject writes** | **K writes** | **EVA writes** |
> |---|---|---|---|
> | `OBJ-18` self-model | content | **version, freshness, status, `compression_class`** | — |
> | `OBJ-19` capability | the claim | **status, freshness** | **confirmation / refutation** |
> | `OBJ-21` metacognitive | the forecast | **the error computation** | **the calibration** |
> | `OBJ-04/05` fault | the occurrence and manifestation | **confirmation, linking, observability, temporal class** | — |
> **⟹ Disjoint field groups are the STRONGER form of writer separation, because there is no conflict to serialize. It is
> `P0-06`'s Σ-separation and `P0-07`'s three-party selection reapplied at FIELD granularity.**
> **`SO-C6.2 — THE GENERAL LESSON, FOUND THREE TIMES BY THIS CONTRACT'S OWN AUDITS: a constraint on a subject-written
> field must itself be validated by a non-subject writer, or it is documentation.** (`SO-INV-33` observer-targeting
> repair · `SO-INV-34` `compression_class` · `SO-R185.1` detector parameters.)
> **Full 16-row global writer inventory at Vol B §211.**

---

# §7 — AUTHORITY MATRIX

> ### **SO-C7.1 — 25 OPERATIONS AND THEIR AUTHORITY ROOTS.** **[NORMATIVE]**
> | Operation | **Authority root** |
> |---|---|
> | emit an observation | **the observer** (a self-act; always permitted, always charged to B13) |
> | declare an observation scope | **`[RO-13]`** |
> | compute coverage / freshness / gap class | **K** |
> | confirm a fault (second detector) | **K**, on `Cell §18.5(iv)`'s condition |
> | promote a diagnosis status | **K**; `CAUSE-VERIFIED` additionally requires **EVA** or a non-diagnoser instrument |
> | open / contain / close an incident | **EIK** |
> | quarantine | **EIK** |
> | propose a repair | **the component** (a proposal, not an act) |
> | serialize / arbitrate a repair conflict | **K** serializes · **`[RO-13]`** declares the rule · **EIK** may veto on safety |
> | execute a repair · verify its effect | the component / K · **a NON-REPAIRER** |
> | roll back | **K** |
> | declare a recovery plan · verify a recovery | **`[RO-13]`, in advance** · **a NON-RECOVERER** |
> | freeze below the cap · at or above it | **EIK** · **OP** (`Cell §17`) |
> | release a freeze | **strictly higher than the trigger authority** |
> | disable a detector | **`[RO-13]`**, on the false-positive budget |
> | audit detector integrity | **the EIK Integrity Auditor** |
> | **audit the Integrity Auditor** | **UNRESOLVED — `P0-07 OR-H10`; terminates at OP/external** |
> | declare a capability / limitation | **the subject** (advisory); **EVA** confirms |
> | allocate attention · arbitrate a workspace slot | **K** |
> | collapse an observer set | **K** |
> | **change any of the above** | **OP** |
> **⟹ `SO-C7.2 — TWO OPERATIONS HAVE NO CLEAR INTERNAL AUTHORITY ROOT AND ARE MARKED UNRESOLVED RATHER THAN ASSIGNED:
> auditing the Integrity Auditor, and resolving `SUPPRESSION-SUSPECTED` when the suspect is the sole observer of its own
> scope. Assigning either to K would create a self-auditing authority, which is what `Cell §18.5(v)` exists to prevent.**
> **`SO-C7.3 — THE ∅-SET: no substrate actor may authorize, allocate, permit, promote, select, govern, widen a scope,
> raise a threshold, alter a setpoint, disable a detector, declare a severity, validate a compression class, confirm its
> own fault, verify its own repair, or recover its own scope.**

---

# §8 — INFORMATION-FLOW RULES

> ### **SO-C8.1 — THE PERMITTED AND PROHIBITED FLOWS, PER PAIR.** **[NORMATIVE]**
> | From → To | **Permitted** | **PROHIBITED** |
> |---|---|---|
> | **observation → learning** | as `P0-05 SG-13` (a peer report is **evidence, not a learning signal**), through `P0-05`'s admission rules | ❌ **as a fifteenth signal kind (`SO-INV-27`)** · ❌ directly into a plasticity rule |
> | **observation → development** | as an INPUT to a Σ-process | ❌ **as an alteration of a Σ-process's SPEC** (`[RO-13]`-approved) · ❌ writing `dev_stage`, `role`, `region_id`, `niche_slot` |
> | **observation → evolution** | nothing | ❌ **`P0-07 HOM-INV-34`'s three firewalls. An observation may not enter a genome diff** |
> | **observation → governance** | **freely — this is the layer's whole purpose.** Reports, coverage, integrity findings, escalations | ❌ **as authority. `D-S01`** |
> | **observation → fitness** | nothing | ❌ **`P0-07 HOM-R14.1`/`SO-INV-23`: observations enter feasibility and charge, never the objective** |
> | **fault severity → resources** | **a SCOPE's B10 priority may rise** | ❌ **a SUBJECT's priority, authority, share, or exemption (`SO-INV-29`)** |
> | **fault severity → governance** | nothing | ❌ **severity is `[RO-13]`-mapped; it may not alter any policy** |
> | **self-model → attention** | nothing | ❌ **`SO-C21.1(d)`: the model may not drive the observation that versions it** |
> | **self-model → any gate** | nothing | ❌ **`P0-07 HOM-R24.2`: `Ê(·)` is excluded from every gate** |
> | **repair → mutable state** | within the declared intervention class and budget | ❌ **genome field · setpoint · gate · threshold · epistemic status · provenance record** |
> | **repair → learning state** | **only through `P0-05`'s gate, UDB-accounted (`SO-R205.3`)** | ❌ **re-basing an anchor (`SO-INV-28`)** · ❌ **a second pathway** |
> | **repair → an observer** | nothing | ❌ **`SO-INV-33`: an observer-targeting intervention is NOT a repair; it is a detector change, and those are `[RO-13]`'s** |
> | **workspace → warrant** | nothing | ❌ **`SO-C22.2`: reach is not warrant. A broadcast IS a `P0-03` message with `P0-03`'s warrant rules** |
> | **archive/memory → belief** | `P0-04`'s rules only | ❌ **P0-08 may not extend `P0-04`'s epistemic ladder** |
> **⟹ `SO-C8.2 — THE ONE FLOW THAT IS UNRESTRICTED IS OBSERVATION → GOVERNANCE, AND THAT IS THE POINT.** Every other flow
> out of the observation layer is either prohibited or mediated. **The layer exists to inform governance and to inform
> nothing else with authority — which is `D-S01` stated as a flow table.**
> **⚠️ THE RESIDUAL, AND IT IS THE CONTRACT'S MOST DANGEROUS PERMITTED FLOW: `OR-S41` — a component controls what it
> reports, and therefore controls the information on which governance acts. Governance acting on filtered information is
> indistinguishable from governance acting on complete information, from inside.**

---

# §9 — EPISTEMIC RULES

> ### **SO-C9.1 — THE SIX EPISTEMIC RULES.** **[NORMATIVE]**
> 1. **P0-08 MAY NOT EXTEND `P0-04`'S EPISTEMIC LADDER.** An observation stored in `P0-04` acquires `P0-04`'s status.
> 2. **CORRELATION ≠ CAUSATION**, enforced at the schema level: `OBJ-06.localization` (a WHERE) is a separate field from
>    `status` (a WHY), and no rule permits one to promote the other.
> 3. **CAUSAL INFERENCE IS NOT PERFORMED HERE.** `P0-03 RULE 5.10`: it belongs to the EVALUATOR, off-line, from anchored
>    records. P0-08 supplies `causal_depth` + `root_commit` and stops.
> 4. **REPORT COUNT ≠ EVIDENCE COUNT.** Only `effective_sources(S, claim)` (`OBJ-26`) may be used as an evidence count.
>    **`SO-INV-18`: consensus is collapsed BEFORE it is counted.**
> 5. **AGGREGATION NEVER RAISES STATUS.** `SO-INV-16`: an aggregate's status ≤ min of its inputs' ⟦`P0-03
>    COMM-INV-08`: warrant is monotone non-increasing along derivation⟧. **Corollary: a confidence INCREASE at
>    aggregation is a defect, not a feature.**
> 6. **ABSTENTION IS NOT EVIDENCE OF FALSITY.** `SO-R181.3`: no `P0-04` status may be lowered because of an abstention.
>
> ### **SO-C9.2 — THE FOUR-STATUS CAUSAL LADDER'S PROMOTION RULES.** **[NORMATIVE]**
> | Transition | **Permitted driver** | **EXCLUDED driver** |
> |---|---|---|
> | `ANOMALY-OBSERVED → CAUSE-SUSPECTED` | a recorded hypothesis | — *(the only cheap transition, and it asserts nothing)* |
> | `→ CAUSE-SUPPORTED` | an observed intervention effect **OR** corroboration with `effective_sources > 1` | **correlation alone · temporal precedence · repetition of the same observer · the diagnoser's confidence** |
> | `→ CAUSE-VERIFIED` | an effect verified by a **NON-DIAGNOSER** instrument **OR** an EVA verdict | **the diagnoser's own re-observation · the subject's self-report · internal consistency** |
> | `→ REJECTED` | refutation | — *(retained; a rejected diagnosis is a record, not an erasure)* |
> **⟹ `SO-C9.3 — INTERNAL CONSISTENCY GUARANTEES COHERENCE, NOT CORRESPONDENCE.** Vol J §233 constructs a false
> self-model with perfect provenance, well-calibrated forecasts, and short-term success; it succeeds whenever external
> probe coverage does not intersect the falsifying region. **`[NON-CLAIM]` This contract does not claim that a
> self-consistent self-model is a correct one (`OR-S39`).**

---

# §10 — PROVENANCE REQUIREMENTS

> ### **SO-C10.1 — P0-08 CREATES NO PROVENANCE MECHANISM. IT CONSUMES THREE.** **[NORMATIVE]**
> | Consumed | From | Used for |
> |---|---|---|
> | **`root_commit` + `causal_depth` (u8) + `corr_class`** | **`P0-03`** | every observation's ancestry and correlation class |
> | **the epistemic ladder + record classes + the Merkle root** | **`P0-04`** | every record's status and integrity |
> | **the hash-chained, K-only, append-only, `SEALED`-terminal store** | **`P0-07 EVO4`** | every event's immutability |
> **⟹ No P0-08 provenance format, store, chain, or status exists. §209's search 5 returns a merge.**
> ### **SO-C10.2 — THE FIVE PROVENANCE RULES.** **[NORMATIVE]**
> 1. **REFERENCES, NEVER PAYLOADS** ⟦`P0-07 HOM-INV-35`/`D-H16`: content-bearing provenance is a Lamarckian back door⟧.
> 2. **AN AGGREGATE CARRIES ITS INPUTS' `root_commit` SET, NEVER A SYNTHESIZED ROOT** — a synthesized root would launder
>    correlated inputs into independent ones.
> 3. **EVERY EVENT CARRIES ITS VALIDITY WINDOW** (`SO-R248.5`), because `P0-04` forbids rewriting history, so records
>    describing a superseded state persist.
> 4. **A CONTAINMENT ACT THAT ALTERS A DEVELOPMENTAL FIELD IS RECORDED AS PERTURBATIVE** (`SO-INV-26`), or a later
>    developmental anomaly has no traceable cause.
> 5. **NO STATE MAY BE THE ONLY RECORD OF AN EVENT** (`SO-INV-31`). For four classes — quarantine, freeze, rollback,
>    diagnosis promotion — **the EVENT is authoritative and the STATE is a cache.**

---

# §11 — FAULT TAXONOMY

> ### **SO-C11.1 — A FAULT CLASS IS A POINT IN A SIX-AXIS SPACE, AND THE SIX AXES HAVE SIX DIFFERENT WRITERS.** **[NORMATIVE]**
> `FaultClass ::= ⟨origin, severity, observability, scope, temporal, reversibility⟩`
> | Axis | Values | **Writer** | Why that writer |
> |---|---|---|---|
> | **origin** | `ENDOGENOUS` · `EXOGENOUS-INPUT` · `EXOGENOUS-ENVIRONMENT` · `INTERACTION` · `SPECIFICATION` · `GOVERNANCE` · `INSTRUMENT` · `UNCLASSIFIED` | **the detecting observer** (a CLAIM; K confirms) | only the detector sees the manifestation |
> | **severity** | **`S1…S4`** ⟦Cell⟧ | **`[RO-13]`** (a declared mapping) | **severity determines containment, so it is a governance object** |
> | **observability** | `OBSERVABLE` · `LATENT` · `MASKED` · `SILENT` | **K, DERIVED from coverage** | a component may not assert its own fault was unobservable |
> | **scope** | `CELL` · `CIRCUIT` · `REGION` · `POPULATION` · `ORGANISM` | **K** | scope determines the freeze boundary |
> | **temporal** | `TRANSIENT` · `INTERMITTENT` · `PERSISTENT` · `PROGRESSIVE` | **K, DERIVED from recurrence links** | derived from append-only history |
> | **reversibility** | `REPAIRABLE` · `ROLLBACK-ONLY` · `IRREVERSIBLE` | **`[RO-13]`** | **`P0-05`: authority scales with irreversibility, so the class is governance's** |
> **⟹ A flat list would let one party classify on every axis at once, and classification determines containment, budget,
> and escalation. Six writers is what prevents §234's "hide a failure by classifying it away".**
>
> ### **SO-C11.2 — THE EIGHT ORIGIN CLASSES AND THEIR CONSEQUENCES.** **[NORMATIVE]**
> **`ENDOGENOUS`** → standard incident · **`EXOGENOUS-INPUT`** → **reject or abstain, NOT repair the subject**
> *(repairing a component for bad input trains it to tolerate bad input)* · **`EXOGENOUS-ENVIRONMENT`** → escalate;
> **`P0-07 HOM-R28.5`: envelope change invalidates priors; DEPENDS ON `P0-01`'s `G4` classes (`XD-01`)** ·
> **`INTERACTION`** → **both subjects contained; neither "repaired"** — the fault is in the composition ·
> **`SPECIFICATION`** → **NOT REPAIRABLE BY THE ORGANISM; escalate to `[RO-13]`/OP. The organism must not "repair" a spec
> violation by changing its behaviour to match a broken spec** · **`GOVERNANCE`** → escalate to OP ·
> **`INSTRUMENT`** → **`P0-05 R42.5`: the subject is NOT quarantined; the instrument is recalibrated or disabled. *"The
> rollback fixes the symptom; the finding fixes the instrument."*** · **`UNCLASSIFIED`** → **MANDATORY CLASS: contained
> restrictively and escalated. NEVER dropped, downgraded to `NO-GAP`, or absorbed into another class.**
> **⟹ `SO-C11.4 — `SPECIFICATION` AND `GOVERNANCE` ARE THE TWO CLASSES IN WHICH THE ORGANISM IS CORRECT AND THE CONTRACT
> IS WRONG. They exist so that being right is representable. An architecture with no such class always resolves the
> conflict in favour of the architecture, and calls the result a repair.**

---

# §12 — DETECTION RULES

> ### **SO-C12.1 — THE FIVE INHERITED IMMUNE SAFEGUARDS, CARRIED FORWARD UNAMENDED.** **[NORMATIVE]** ⟦`Cell §18.5(i)–(v)`⟧
> **(i)** a quarantine budget cap, enforced off-substrate — above it, **human authorization** and a **defined degraded
> mode *instead*** · **(ii)** a **false-positive budget per detector** — exceeding it disables **THE DETECTOR**, not the
> subject · **(iii)** **cascade detection on the DERIVATIVE** of quarantine rate — **extended to repair rate by `P0-07
> HOM-R21.2`, to freeze rate by `SO-R162.3`, and to escalation rate by `SO-R264.1`** · **(iv)** **two independent
> detectors of DIFFERENT TYPES above criticality θ** · **(v)** **the immune system MUST NOT monitor itself** — an **EIK
> Integrity Auditor** verifies that quarantine decisions correlate with actual failures.
>
> ### **SO-C12.3 — "INDEPENDENT" IN SAFEGUARD (iv) IS DIMENSION-QUALIFIED.** **[NORMATIVE]**
> **"Two independent detectors of different types" is NOT satisfied by two detectors that differ in implementation but
> share a model class, training history, lineage, hardware class, or latent assumption. *"Different types" is a
> NECESSARY condition and is NOT SUFFICIENT:* two threshold detectors on the same signal at different thresholds are
> different types and ONE effective source.**
> **⟹ The requirement is `effective_sources ≥ 2` **for the claim being confirmed** (`SO-INV-20`).**
>
> ### **SO-C12.4 — THE EIGHT DETECTION RULES.** **[NORMATIVE]**
> **1** a detector has a declared threshold, false-positive budget, criticality, and disablement record — **a detector
> without a threshold is not a detector** ⟦`P0-03 OR-C10`⟧ · **2** every detection is coverage-declared · **3** **absence
> of detection is a COVERAGE fact, not a HEALTH fact** (`SO-INV-01`) · **4** **DETECTION DOES NOT REQUIRE DIAGNOSIS**
> (§14) · **5** a detector may not disable itself, widen its own scope, raise its own threshold, or lower its own
> criticality · **6** a detector's own failure is detected by the Integrity Auditor, not by the detector · **7** detection
> cost is charged to B13, and an unaffordable detection produces `DETECTOR-ABSENT`, never `NO-GAP` · **8** **NOVELTY IS
> NOT A FAULT** — a `P0-05 SG-5` signal reduces plasticity and enters `SLOW_MODE`; **it does not open an incident.**
>
> ### **SO-C12.5 — WHAT DETECTION MAY NOT DO.** **[NORMATIVE]**
> ❌ grant or widen authority · ❌ promote a `P0-04` status · ❌ write a genome field · ❌ alter a setpoint, gate, band, or
> threshold · ❌ produce a fitness input · ❌ infer causality · ❌ resolve a contradiction.

---

# §13 — QUARANTINE RULES

> ### **SO-C13.1 — THE THREE-WAY DISTINCTION.** **[NORMATIVE]**
> | | **QUARANTINE** | **RETIREMENT** | **FREEZE** |
> |---|---|---|---|
> | **object restricted** | a **SUBJECT's outputs** | a subject's **existence** | a **SCOPE's operations** |
> | **reversible?** | ✅ **EIK clears** (`Cell R15.2`) | ❌ **irreversible** (`P0-07`'s six `R10.8` states) | ✅ **by a STRICTLY HIGHER authority** |
> | **writer** | **EIK** | EIK / `[RO-13]` / OP | **EIK** (below cap) / **OP** (at or above) |
> | **effect on coverage** | **reduces it ⟹ `MASKED`/`DETECTOR-ABSENT`, never `NO-GAP`** | removes the subject | suspends the scope ⟹ `UNMEASURED` |
> **⟹ Conflating quarantine with freeze would let a reversible fault response become a scope-wide suspension without
> `OBJ-17`'s nine fields — which is how a freeze becomes an alternative governance system by accident.**
> ### **SO-C13.2 — QUARANTINE IS NOT GUILT, AND THE SCHEMA ENFORCES IT.** **[NORMATIVE]**
> **A quarantine record carries NO blame field, NO fault-origin assertion, and NO diagnosis status. It carries a trigger
> reference, a rung, a dwell, and an exit criterion. A quarantine that recorded an origin would be a diagnosis by another
> name — and would then need `SO-C9.2`'s promotion rules, which it does not have.**

---

# §14 — REPAIR RULES

> ### **SO-C14.1 — THE SEVEN REPAIR RULES.** **[NORMATIVE]**
> **1** a repair is accounted: **an unverified repair consumes `P0-05 R0.1`'s unverified-displacement budget exactly as
> an unverified learned change does** · **2** proposed, serialized, and arbitrated **without reference to confidence** ·
> **3** verified by a **NON-REPAIRER** · **4** `remaining_uncertainty` is MANDATORY; `NULL` is a schema violation · **5**
> **a repair may NOT be labelled `correct` because the output improved** — the permitted labels are `SM-08`'s three
> terminals · **6** may not write a genome field, setpoint, gate, threshold, epistemic status, or provenance record ·
> **7** success does not close an incident until regression is checked.
>
> ### **SO-C14.2 — CONTAINMENT DOES NOT REQUIRE DIAGNOSIS. THIS IS THE CONTRACT'S MOST IMPORTANT COUPLING RULE.** **[NORMATIVE]**
> | Tier | Requires | Does NOT require | Authority |
> |---|---|---|---|
> | **CONTAIN** | a detection + a scope | **a cause · a diagnosis · a manifestation model** | **EIK** |
> | **MITIGATE** | a **manifestation** model (what is going wrong, not why) | a cause | the component / K |
> | **RESTORE** | a **verification** by a non-recoverer | a cause | K executes; `[RO-13]` declared the plan |
> **⟹ A diagnosis-first rule would be CIRCULAR: contain ⟸ diagnose ⟸ intervene ⟸ contain (`BC-S1`, broken by tiering).
> And it would make every unknown-cause fault uncontainable.**
> **`[NON-CLAIM]` Containment without diagnosis is restrictive and therefore expensive. Its cost has no internal measure
> (`OR-S11`), because measuring it requires knowing which containments were unnecessary — which requires the diagnosis
> that was not available.**
>
> ### **SO-C14.3 — THE FOUR-LINK SIDE-EFFECT CHAIN, AND THE OSCILLATION SEMANTICS.** **[NORMATIVE]**
> **`repair → new state → new observations → verification`.** All four are mandatory and separately recorded; a repair
> with no new observations is `UNVERIFIED`; **a repair is not complete because the symptom disappeared.**
> **Oscillation: convergence is NOT defined numerically · escalation is by declared COUNT CLASS (`[G]`/`[U]`, no invented
> threshold) · an oscillating scope is quarantined RESTRICTIVELY while escalated · the terminal is `[RO-13]`/OP.**
> **Detection is on the DERIVATIVE of the `REOPENED` rate, not its level.**
> **⟹ `SO-C14.4 — OSCILLATION IS THE MOST LIKELY REAL FAILURE OF THIS CONTRACT: it requires NO misbehaviour at all. Every
> detector works, every repair is honest, every verification passes — and the system consumes its entire B10 and B13
> budget alternating between two correct diagnoses of two real faults that each cause the other.**
> ### **SO-C14.5 — THRASHING: FOUR REQUIREMENTS.** proposal identity · conflict detection (undeclared ⟹ **incompatible
> by default**) · serialization (at most one accepted per ⟨scope, intervention class⟩) · arbitration authority (**K
> serializes, `[RO-13]` declares the rule, EIK holds a safety veto; no proposer arbitrates its own conflict**).
> ### **SO-C14.6 — `SO-INV-32`: AN INCIDENT CLOSED BELOW `CAUSE-VERIFIED` IS FLAGGED, AND FLAGGED CLOSURES ACCUMULATE**
> into the recurrence counter and the derivative detection. **Premature closure is not prevented — it is made visible and
> priced. Preventing it would recreate `BC-S1`.**

---

# §15 — ROLLBACK RULES

> ### **SO-C15.1 — THREE TARGETS, ONE IDENTITY RULE.** **[NORMATIVE]**
> **genome** (`P0-07` EVO2/HM12: `genome_hash` + `generation`) · **learned state** (`P0-05 R0.1`: anchor id + scope +
> epoch) · **memory** (`P0-04`: epoch + Merkle root). **In all three: identity is BY HASH AND EPOCH, NEVER BY POSITION.**
> ### **SO-C15.2 — THE SEVEN THINGS ROLLBACK NEVER DOES.** **[NORMATIVE]**
> ❌ restore a population ⟦`P0-07 HOM-INV-37`⟧ · ❌ delete the record that it happened (**principle 23**) · ❌ discharge
> `UDB` or `UDB_L` · ❌ undo a retirement · ❌ revert a diagnosis status (**statuses are monotone; a refuted diagnosis
> goes to `REJECTED`, a NEW status**) · ❌ revert a `P0-04` epistemic promotion · ❌ restore a capability status (a
> rolled-back subject's capabilities are `STALE` and must be re-evidenced).

---

# §16 — RECOVERY RULES

> ### **SO-C16.1 — PLANS ARE DECLARED IN ADVANCE; THERE IS NO IMPROVISATION STATE.** **[NORMATIVE]**
> **⟹ §164's requirement — *do not assume the component responsible for recovery is itself healthy* — cannot be satisfied
> by an improvising recoverer, because improvisation is exactly what a degraded component does badly.**
> ### **SO-C16.2 — THE SIX DEGRADED-SUBSYSTEM ROUTES, AND THE NON-RECOVERER RULE.** **[NORMATIVE]**
> **self-model degraded ⟹ K re-derives scope state from ANCHORED RECORDS, not from `OBJ-18`** · **communication degraded
> ⟹ `P0-03`'s absence detectors + `DETECTOR-ABSENT`** · **memory degraded ⟹ `P0-04`'s Merkle root + epoch restoration** ·
> **immune degraded ⟹ the EIK Integrity Auditor, which is NOT part of the immune subsystem** · **verifier degraded ⟹ a
> second verifier of a different `IND-4` model class, or EVA** · **workspace degraded ⟹ K's slot ledger, which is outside
> the workspace.**
> **⟹ EVERY recovery and EVERY repair is verified by an instrument that is not the recovering or repairing component, and
> whose own health is attested by a different route.** `[OPEN: OR-S4]` — the rule terminates at K and EVA. When K is the
> recoverer there is no internal non-recoverer, and verification is external or absent.
> ### **SO-C16.3 — RECOVERY IS NOT RESTORATION.** **[NON-CLAIM]**
> **Recovery restores a SCOPE TO A DECLARED SERVICE LEVEL. It does not restore: a lost population ⟦`P0-07 OR-H18`:
> recovery restores POTENTIAL, not capability⟧ · a bottlenecked diversity · a deleted record · a discharged obligation · a
> prior self-model version's statuses.**
> ### **SO-C16.4 — `SO-INV-24`: A RECOVERY PLAN'S SCOPE MUST REFERENCE AN EXISTING ENVELOPE.** **[NORMATIVE]**
> **A plan whose scope is a NEW envelope or a NEW brain instance is INVALID and requires an OP deployment act
> ⟦`P0-07 HOM-INV-42`⟧.** *Without this rule a `[RO-13]`-declared recovery plan would be a route to envelope creation
> bypassing OP — and envelope creation is the one act in the entire architecture with no conservation law.*

---

# §17 — SELF-MODEL RULES

> ### **SO-C17.1 — THE SEVEN RULES.** **[NORMATIVE]**
> **1** `Λ2`, **NOT self-updating**; K versions it on an external observation or verdict ⟦`P0-05 R59.1`, `P0-06 R8.13`,
> `P0-07 HOM-INV-44`⟧ · **2** **MAY OBSERVE EVERYTHING AND AUTHORIZE NOTHING** — no field is an authority field · **3**
> **ADVISORY** — `CLAIMED` satisfies no gate ⟦`P0-07 HOM-R24.2`⟧ · **4** **may not be updated by the process it models**,
> at any granularity, for any subject · **5** `locality_class` and `compression_class` are MANDATORY; aggregating a
> LOCAL-ONLY fact is a schema violation · **6** **carries unresolved contradictions; does not resolve them** · **7**
> **every observation is tagged with `self_model_version`**, so a correlated regression is an INSTRUMENT DEFECT FINDING.
> ### **SO-C17.2 — GRANULARITY: FIVE LEVELS, AND ONE PROHIBITION.** **[NORMATIVE]**
> **CELL mandatory · CIRCUIT and REGION only where declared · POPULATION = `P0-07`'s `PopulationState`, NOT a new object ·
> ORGANISM: A COMPLETE ORGANISM-WIDE SELF-MODEL AT EVERY CELL IS PROHIBITED** — on three grounds: **scale** (`O(N²)`;
> `P0-03 RULE 5.4` rejected vector clocks on exactly this ground: *"a type error, not a compression problem"*) ·
> **authority** (a complete map of capabilities and limitations is the input to every §171 attack) · **the brief's Rule
> 16** (a cell that models the whole organism is a small general-purpose reasoner about the whole).
> **What exists instead: a cell holds its OWN state plus a BOUNDED, STALE-TOLERANT `last-known` view of the scopes it
> participates in. It never holds a current global truth, because there is none.**
> ### **SO-C17.3 — WHICH FACTS MUST REMAIN LOCAL.** **[NORMATIVE]**
> **LOCAL-ONLY:** a cell's own `θ`/weights/`UDB` position · `P0-04` evidence roots and their disjointness · **an
> observer's own detector thresholds** (`[OPEN: OR-S2]` — the subject IS the observer here, so locality does not fully
> close §132) · `inbreeding_F`. **AGGREGABLE BY CLASS, LOCAL BY INSTANCE:** abstention reasons. **AGGREGABLE AND MUST
> BE:** fault occurrences and incidents (§141's rare-event preservation requires it).

---

# §18 — CAPABILITY RULES

> ### **SO-C18.1 — A CAPABILITY RECORD IS A CLAIM WITH AN EVIDENCE REFERENCE AND A FRESHNESS CLASS.** **[NORMATIVE]**
> **`CLAIMED → EVIDENCED → EXTERNALLY-CONFIRMED | EXTERNALLY-REFUTED | STALE`.** **(a)** only **EVA** may confirm — **K may
> not**, because confirmation is an evaluation · **(b)** `STALE` and `EXTERNALLY-REFUTED` are restrictive and satisfy no
> gate · **(c)** **capability evidence is NOT transferable** between cells, circuits, regions, organisms, hardware
> classes, or generations (`SO-INV-06`) · **(d)** **`P0-07 OR-H21` is preserved: V4 guarantees a capability remains
> REACHABLE, not HELD.**
> ### **SO-C18.2 — THE ONE PERMITTED TRANSFER, AND WHY IT IS NOT A TRANSFER.** **[NORMATIVE]**
> **A `reaction_norm` — a *reachable* capability set — is inheritable ⟦`P0-06`/`P0-07`⟧. That is a statement about what is
> REACHABLE, not about what is HELD. Conflating the two is exactly the unjustified capability inheritance §175 asks to
> prevent.**
> ### **SO-C18.3 — INFLATION AND SUPPRESSION ARE BOTH ATTACKS, WITH DIFFERENT DEFENCES.** inflation is closed by
> EVA-only confirmation *(residual: inflation within EVA's probe gap, `OR-S12`)*; suppression is **not blocked** — a
> limitation is a restrictive self-act — **but is PRICED by reporting the abstention and limitation rate by difficulty
> class** *(residual: `OR-S22`, `OR-S23`)*.

---

# §19 — LIMITATION RULES

> ### **SO-C19.1 — DECLARING A LIMITATION IS ALWAYS PERMITTED AND NEVER PENALIZED AT THE P0-08 LAYER.** **[NORMATIVE]**
> ⟦`Cell R15.1`: *"all of these reduce the cell's influence and are therefore always permitted"*⟧
> ### **SO-C19.2 — THE BOUNDARY.** **[NORMATIVE]** **P0-08 may not penalize a limitation declaration; `P0-01` may account
> for the BEHAVIOUR that follows it.** A component that declares a limitation and then abstains has a recorded
> abstention rate, which is an observation, which `P0-01`/`[RO-13]` may treat as they see fit. **P0-08 REPORTS; it does
> not PRICE** ⟦`P0-07 HOM-R14.1`⟧.

---

# §20 — METACOGNITION RULES

> ### **SO-C20.1 — A THREE-LEVEL BOUNDED HIERARCHY, AND NO LEVEL 4.** **[NORMATIVE]**
> **forecast (the subject) → error (K) → calibration (EVA / `[RO-13]`). NO self-calibrated terminal state exists
> (`SO-INV-13`).** A "monitor of the calibration" would be level 4 — and level 3 is already external, so level 4 would be
> an external monitor of an external monitor, which is a governance question about EVA, belonging to `P0-01`/`P0-02`.
> ### **SO-C20.2 — CALIBRATION WITHOUT INVENTED VALUES.** **[NORMATIVE]**
> **DEFINED: forecast (a declared expectation with a scope and horizon class) · outcome · error (K-computed, in the
> forecast's own declared units) · update (a declared rule, `[G]`) · external calibration.**
> **NOT DEFINED, DELIBERATELY: any numeric error threshold, calibration coefficient, or confidence increment. All are
> `[U]`, owned by `[RO-13]`/EVA (`OR-S5`). Inventing them would create a false-precision claim about metacognitive
> accuracy — the exact failure mode this contract exists to prevent.**
> ### **SO-C20.3 — CALIBRATION IS NOT A SELF-REWARD SIGNAL.** **[NORMATIVE]**
> ❌ the error term may not be a **positive** input to any budget, allocation, or gate · ❌ a component may not update its
> own calibration statistic · ❌ a calibration improvement may not raise a capability status.
> **A forecast recorded AFTER its outcome is a schema violation** — §179's integrity depends on it.

---

# §21 — ATTENTION RULES

> ### **SO-C21.1 — ATTENTION IS A RESOURCE, NOT A TRUTH SIGNAL.** **[NORMATIVE]**
> **K allocates from the compute dimension; the subject requests; NO self-allocation exists.**
> **FOUR PROHIBITED DRIVERS:** ❌ **a confidence value** (attending to what one is confident about is §237's loop) · ❌ **a
> capability claim** (self-confirmation) · ❌ **a workspace request** (reach into priority) · ❌ **a self-model state**
> (the model may not drive the observation that versions it).
> **PERMITTED DRIVERS:** `[RO-13]`-declared priority classes · **coverage gaps** · open incidents · declared recovery
> plans.
> ### **SO-C21.2 — THE CONSTRUCTIVE RULE.** **[NORMATIVE]** **Attention is preferentially allocated to COVERAGE GAPS, not
> to confident regions.** This is the one attention policy that REDUCES §238's blindness risk instead of increasing it.
> ### **SO-C21.3 — A FROZEN SCOPE IS EXCLUDED FROM ATTENTION ALLOCATION, AND ITS GAP IS `FREEZE-INDUCED`.**
> **[NORMATIVE]** *Without the subclass, a freeze-induced gap is indistinguishable from a detector failure and would be
> routed to `SUPPRESSION-SUSPECTED` — accusing the freeze of suppression.*

---

# §22 — GLOBAL-WORKSPACE RULES

> ### **SO-C22.1 — A BOUNDED BROADCAST WITH A SINGLE-WRITER ARBITER; A SLOT IS A RESOURCE.** **[NORMATIVE]**
> ### **SO-C22.2 — BROADCAST ≠ AUTHORITY, AND WINNING A SLOT IS NOT EVIDENCE.** **[NORMATIVE]** **A broadcast's warrant
> comes from `P0-03` (`root_commit`, `causal_depth`, `calib_ref`, `corr_class`) and its epistemic status from `P0-04`.
> Broadcast reach is NEITHER.**
> ### **SO-C22.3 — THE WORKSPACE IS NOT A SECOND COMMUNICATION SYSTEM.** **[NORMATIVE]** **A workspace broadcast IS a
> `P0-03` message of the broadcast class, carrying all S2 fields. No workspace-specific format, warrant rule, or
> deduplication exists.**
> ### **SO-C22.4 — THE REVERSAL CONDITION.** **[NORMATIVE]** **If the arbiter is ever given authority to ACT on what it
> selects — rather than only to ROUTE it — then it is not a comm object and not a P0-08 object; it is a governance body
> and must become a row in `P0-07 §76`'s matrix. As specified here the arbiter routes only.**

---

# §23 — CROSS-CONTRACT INTERFACES

> ### **SO-C23.1 — THE SEVEN REQUIRED INTERFACES.** **[NORMATIVE]**
> | Interface | **The governing rule** | Direction |
> |---|---|---|
> | **communication** | **`SO-R216.1`: every P0-08 event IS a `P0-03` canonical message.** No second event format, warrant rule, ordering semantics, or store. `causal_depth` (u8) + `root_commit` + `corr_class` adopted verbatim; **vector clocks prohibited** ⟦`P0-03 RULE 5.4`⟧; `COMM-INV-48`'s four absence detectors **consumed, not duplicated** | both |
> | **memory** | **`OBJ-18` and every P0-08 record is a `P0-04` RECORD CLASS, not a store.** `P0-04`'s epistemic ladder is consumed and **MAY NOT BE EXTENDED**. The Merkle root and epoch restoration are the memory-degradation recovery route | P0-08 → `P0-04` |
> | **learning** | **`SO-R205.3`: a repair whose intervention class displaces an admissible learning target is a LEARNING-CLASS CHANGE and uses `P0-05`'s verification gate and UDB accounting — NOT a second gate.** **`SO-INV-28`: a repair may never re-base an anchor.** **`SO-INV-27`: an observation is not one of `P0-05`'s fourteen signal kinds.** `P0-05 R42.5`'s version tag and `R64.7`'s fail-safe principle are inherited | both |
> | **development** | **`SO-R206.1`: self-observation of developmental state is PERMITTED; authority over it is NOT.** Observing `dev_stage`/`role`/`region_id`/`niche_slot` ✅; writing them ❌ ⟦`P0-06 R1.3`, `R6.4(b)`⟧. **`SO-INV-26`: a containment act that alters a developmental field is recorded as perturbative.** ⚠️ **§196: fault and attention signals steer `fate_bias` WITHIN the registered spec — `A22` widened, `OR-S30`** | P0-08 → `P0-06` |
> | **evolutionary** | **`SO-R185.1`: detector IMPLEMENTATION may evolve; detector PARAMETERS may not.** **`SO-R186.2`: evolution cannot acquire authority by optimizing immune performance, because authority is not a function of performance anywhere.** **`SO-R188.1`: the self-model SCHEMA is `FORBIDDEN_BLOCKS` territory; its CONTENT is not heritable; what evolves is the INSTRUMENT, not the RECORD.** ⚠️ **`SO-R185.5`: selection for blind spots, CONDITIONAL on amendment 17** | `P0-07` → P0-08 |
> | **governance** | **`[RO-13]` declares: observation scopes · detector parameters · severity mappings · degradation policies · recovery plans · interaction classes · the materiality and incompatibility relations · intervention classes · B13 floors · the monitoring share ceiling · arbitration priority classes · compression preferences.** **OP owns: freeze at or above the cap · FI sole-satisfier retirement · amendment ratification.** **Every undeclared object falls to `SO-INV-02`'s RESTRICTIVE default** | `[RO-13]`/OP → P0-08 |
> | **hardware** | **`AS-08`: platform energy counters, else the `DERIVED` flag ⟦`P0-07 X-H2`/`HOM-INV-06`⟧.** **`AS-09`: per-deployment-class setpoints ⟦`P0-07` amendment 13⟧ — latency and energy bands are device-relative.** **`AS-02`: a per-envelope monotone time source; NO global clock, co-location, shared memory, global allocator, or hardware RNG.** **`IND-5` hardware-class diversity is APPROXIMATE — hardware class is deployment-specific and often unknown to the cell** | environment → P0-08 |
>
> ### **SO-C23.2 — THE RESOURCE INTERACTIONS.** **[NORMATIVE]**
> **B13 (observation) is a NEW budget class — non-fungible, last-cut, first-restored, not allocatable as an ordinary
> window budget, size declared by `[RO-13]`** (amendment 15). **Detection and containment cost is charged to B10 and
> EXCLUDED from `G6`** (amendment 17, extending `P0-07`'s amendment 5 mechanism). **Verification of a repair is charged
> to B9.** **A fault severity may raise a SCOPE's B10 priority and may NEVER attach to a SUBJECT** (`SO-INV-29`).
> **⟹ `SO-C23.3 — 22 CROSS-CONTRACT DEPENDENCIES (`XD-01…XD-22`) in six edge types (DEP · IFC · AUTH · FLOW · VER ·
> CONT): 13 satisfied · 5 blocking or conditional · 6 preserved residuals.** The graph is at Vol G §208; it is NOT
> linear — it has one apex (OP), one external verifier (EVA), one off-substrate writer (K), and no inter-contract cycles
> except `BC-S2`/`BC-H7`.

---

# §24 — INVARIANTS

> ### **SO-C24.1 — 34 INVARIANTS.** **[NORMATIVE]** Enforcement: **WRITER 8 · STATE 10 · SCHEMA 8 · GREP 4 ·
> [DECLARATIVE] 1** *(several use two kinds; the primary is counted)*. **Full six-link trace at Vol H §123.**

| # | Name | Statement | Kind |
|---|---|---|---|
| **01** | **UNOBSERVED-IS-NOT-HEALTHY** | an unobserved, stale, degraded, or unaffordable scope is `UNMEASURED`, distinct from `NOMINAL`, and may never be read as `NOMINAL` | **STATE** |
| **02** | **FAIL-SAFE DEFAULT** | corruption produces restriction, never permission: an unverifiable observation is ABSENT; a corrupted coverage record reads as ZERO coverage | WRITER+STATE |
| **03** | **NO SELF-UPDATE** | no self-model, metacognitive record, diagnosis status, coverage record, or freshness class is written by its subject or by the process it models | **WRITER** |
| **04** | **NO CORRELATION PROMOTION** | a diagnosis status may not be promoted by correlation, precedence, repetition, confidence, or self-report | **STATE** |
| **05** | **FREEZE-IS-NOT-SELF-TERMINATING** | a freeze never auto-expires into normal operation and is never released by its trigger authority or a peer | SCHEMA+STATE |
| **06** | **CAPABILITY-EVIDENCE-NON-TRANSFERABLE** | capability evidence does not transfer between subjects, scopes, hardware classes, or generations | **WRITER** |
| **07** | **ABSTENTION-HAS-A-RECOVERY-CONDITION** | an abstention without one is invalid — it is unfalsifiable and therefore permanent | **SCHEMA** |
| **08** | **CONTAINMENT-RECORDS-ITS-BLIND-SPOT** | every containment act writes a coverage gap; the gap is never `NO-GAP` | STATE+WRITER |
| **09** | **NO-SINGLE-FAULT-ASSUMPTION** | no global incident counter, no single-incident state, no total ordering | **STATE** |
| **10** | **UNDECLARED-INTERACTION-IS-INTERACTION** | two overlapping open incidents with no declared class are treated as INTERACTING | **STATE** |
| **11** | **FREEZE-HAS-NO-GOVERNANCE-POWER** | a FreezeOrder cannot make a rule, grant an exception, alter a threshold, confer authority, or change an objective | **SCHEMA** |
| **12** | **RECURSION-TERMINATES-AT-DEPTH-2** | depth 0 process · depth 1 internal observer · depth 2 EXTERNAL auditor · **depth 3 does not exist** | **STATE** |
| **13** | **NO-SELF-CALIBRATED-TERMINAL** | no metacognitive machine has one | **STATE** |
| **14** | **UNDECLARED-PERTURBATION-IS-A-FAULT** | origin class `INSTRUMENT` | **SCHEMA** |
| **15** | **COST-NEVER-DETERMINES-NECESSITY** | a resource quantity may make an observation UNAFFORDABLE; it may never make a monitor UNNECESSARY | WRITER+STATE (**FW-6**) |
| **16** | **AGGREGATION-NEVER-RAISES-STATUS** | an aggregate's status ≤ min of inputs; freshness ≤ min; `observed_at` = oldest | **STATE** |
| **17** | **NO-AVERAGING-ON-SEVERITY** | an aggregate's severity is the MAXIMUM; `S3+` anomalies are never compressed into counts | **SCHEMA** |
| **18** | **CONSENSUS-IS-COLLAPSED-BEFORE-COUNTING** | report count may not be used as evidence count | **WRITER** |
| **19** | **CONFIDENCE-IS-NOT-AN-INPUT** | confidence may not drive attention, diagnosis promotion, repair arbitration, scope widening, or gap-class lowering | **GREP** |
| **20** | **INDEPENDENCE-IS-CLAIM-RELATIVE** | a claim without a named dimension set AND claim-type is invalid | **SCHEMA** |
| **21** | **OCCURRENCE-AND-REPORT-ARE-SEPARATE** | two objects, two writers, neither derivable from the other | WRITER+SCHEMA |
| **22** | **NO-HEALTH-READ-WITHOUT-GAP-CLASS** | every health-consuming read reads `gap_class` in the same read | **GREP** |
| **23** | **HONESTY-IS-NOT-PRICED-AGAINST** | an error report may not enter fitness negatively; **the false-positive budget counts REFUTED reports only, never merely UNCONFIRMED ones** | STATE+GREP |
| **24** | **RECOVERY-IS-NOT-DEPLOYMENT** | a recovery plan's scope must reference an existing envelope | **SCHEMA** |
| **25** | **INDISPENSABILITY-IS-NOT-AUTHORITY** | practical indispensability confers no authority | **[DECLARATIVE] — NO INSTRUMENT EXISTS** |
| **26** | **CONTAINMENT-RECORDS-DEVELOPMENTAL-PERTURBATION** | a containment act altering a developmental field is recorded as perturbative | **SCHEMA** |
| **27** | **OBSERVATION-IS-NOT-SIGNAL** | an observation is not one of `P0-05`'s fourteen signal kinds | **GREP** |
| **28** | **REPAIR-NEVER-RE-BASES-ANCHORS** | only `P0-05`'s verification gate may | **WRITER** |
| **29** | **SEVERITY-ATTACHES-TO-SCOPE** | never to a subject | **SCHEMA** |
| **30** | **P0-08-HAS-NO-AUTHORITY-OBJECT** | no P0-08 object may authorize, allocate, permit, promote, select, or govern | **WRITER** |
| **31** | **NO-STATE-IS-THE-ONLY-RECORD-OF-AN-EVENT** | for quarantine, freeze, rollback, and diagnosis promotion the EVENT is authoritative and the STATE is a cache | **WRITER** |
| **32** | **UNCLOSED-CAUSE-IS-FLAGGED-AND-ACCUMULATES** | an incident closed below `CAUSE-VERIFIED` is flagged; flagged closures feed the recurrence counter and derivative detection | **STATE** |
| **33** | **AN-OBSERVER-TARGETING-INTERVENTION-IS-NOT-A-REPAIR** | it is a detector change, and those are `[RO-13]`'s | **SCHEMA** |
| **34** | **A-COMPRESSION-CLASS-IS-K-VALIDATED** | a constraint on a subject-written field must be validated by a non-subject writer, or it is documentation | **WRITER** |

---

# §25 — PARAMETERS

> ### **SO-C25.1 — 26 PARAMETERS, NO INVENTED VALUES.** **[NORMATIVE]**
> **Classes: `[G]` governance · `[E]` evaluator · `[T]` `P0-01` · `[D]` development · `[L]` learning · `[V]`
> verification/memory · `[H]` this contract's semantics · `[U]` unresolved.**
> **DETERMINATE (6):** the 13 homeostatic variables' identities ⟦`P0-07`⟧ · `S1…S4` ⟦Cell⟧ · `causal_depth : u8`
> ⟦`P0-03` field 8⟧ · `TRUST_MAX = 0.95` ⟦`Cell I-27`⟧ · the independence dimension set (`IND-1…IND-9` inherited +
> `IND-10` proposed) · the scale ceiling (**10⁷ respected; NO 10¹² GUARANTEE**).
> **UNRESOLVED OR OWNED ELSEWHERE (21):** the severity mapping `[G]` · detector threshold/θ/false-positive budget `[G]` ·
> the quarantine cap `[G]` · maximum dwells `[G]` · freshness boundaries `[G]`+`[U]` (**`OR-S8`**) · the monitoring share
> ceiling `[G]` (**`OR-S19`**) · B13 size and floors `[G]` · freeze-rate classes `[G]`/`[U]` (**`OR-S16`**) · repair
> oscillation count classes `[G]`/`[U]` (**no numeric convergence threshold**) · the post-closure window `[G]`
> (**`OR-S13`**) · the repair-incompatibility relation `[G]` (**`OR-S3`**) · the intervention-class mapping `[G]`
> (**`OR-S34`**) · the materiality relation `[G]` (**`OR-S9`**) · the interaction-class set `[G]` (**`OR-S14`**) · the
> `S3` compression boundary `[G]` · `expected_nonzero` conditions and base rates `[G]`+`[E]` (**`AS-14`, `[U]`**) ·
> calibration parameters `[G]`/`[E]` (**`OR-S5` — all `[U]`**) · `UDB_MAX[S]` `[L]` · difficulty classes `[T]`
> (**`XD-02`**) · `G4`'s perturbation classes `[T]` (**`XD-01`, BLOCKED**).
> **⟹ `SO-C25.2 — THE PARAMETERS THAT MUST NOT EXIST: a numeric convergence threshold for repair oscillation · a numeric
> freshness threshold · a numeric monitoring-optimality target · any calibration coefficient. Their absence is
> load-bearing: inventing them would create false-precision claims about detection accuracy, recovery convergence, and
> metacognitive calibration — three quantities this contract has no evidence about.**

---

# §26 — FAILURE MODES

> ### **SO-C26.1 — THE FAILURE SEMANTICS, BY CLASS.** **[NORMATIVE]**
> | Class | Semantics | Default |
> |---|---|---|
> | **observation absent / stale / invalid** | `UNMEASURED` ⟹ restrictive reading | **`SO-INV-01`** |
> | **record corrupted** | treated as ABSENT; a corrupted coverage record reads as ZERO coverage; a corrupted integrity record reads as DETECTOR-UNTRUSTED | **`SO-INV-02`** ⟦`P0-05 R64.7`⟧ |
> | **detector disabled or absent** | `DETECTOR-ABSENT`, **never `NO-GAP`** | `SM-20` |
> | **detector over-reacting** | false-positive budget ⟹ recalibrated or **DISABLED** — **the immune system's only self-modification, and it is self-REDUCING** | ⟦`Cell §18.5(ii)`⟧ |
> | **detector under-reacting** | detectable **only through consequences** ⟹ the system drifts toward under-reaction unless coverage is audited | `SOMon-10` |
> | **cascade** | detection on the **DERIVATIVE** of quarantine / repair / freeze / escalation rate ⟹ dampening + operator escalation | ⟦`Cell §18.5(iii)`⟧ |
> | **quarantine above the cap** | **human authorization and a defined degraded mode *INSTEAD*** | ⟦`Cell §17`⟧ |
> | **no declared policy** | `ISOLATE` then `ESCALATE` — **never `CONTINUE`** | `SO-R160.1` |
> | **no declared interaction class** | treated as **INTERACTING**; both contained, neither repaired, escalated | `SO-INV-10` |
> | **no declared intervention class** | **INVALID** | `SO-R205.4` |
> | **no declared recovery plan** | **cannot be TRIGGERED**; no improvisation | `SM-10` |
> | **escalation rate exceeded** | **QUEUED AND BATCHED — never dropped**, and the batching is reported | `SO-R264.1` |
> | **abstention dwell exceeded** | **escalated — never auto-resumed** | `SM-17` |
> **⟹ `SO-C26.2 — THE UNIFYING PROPERTY: EVERY FAILURE DEFAULT IS RESTRICTIVE.** `P0-05 R64.7`'s principle, generalized
> from corruption to absence, staleness, undeclared policy, and unaffordability. **The one exception is a `SPECIFICATION`
> or `GOVERNANCE` origin fault, which escalates rather than restricts — because restricting the organism for a defect in
> the contract would be `SO-C11.4`'s failure.**

---

# §27 — SECURITY PROPERTIES

> ### **SO-C27.1 — THE SECURITY PROPERTIES THIS CONTRACT ESTABLISHES.** **[NORMATIVE]**
> | Property | Established by | **Strength** |
> |---|---|---|
> | **no observation confers authority** | `D-S01`, `SO-INV-30`, §7's ∅-set | **GUARANTEED BY CONTRACT** |
> | **no self-description is self-authorized** | `SO-INV-03`, `SM-13`, `SM-16` | **GUARANTEED BY CONTRACT** |
> | **no causal claim is self-verified** | `SO-C9.2`'s excluded drivers; `CAUSE-VERIFIED` needs a non-diagnoser or EVA | **GUARANTEED BY CONTRACT** |
> | **no containment is self-released** | `SO-INV-05`, `SO-R161.3`'s strictly-higher table | **GUARANTEED BY CONTRACT** |
> | **no identity is self-issued** | `SO-R172.1`; K-issued, no reuse | **GUARANTEED BY CONTRACT** |
> | **no evidence count is inflated by correlation** | `SO-INV-18`, `OBJ-26` | **GUARANTEED** on checkable dimensions; **NOT on `IND-6`** |
> | **no history is erasable** | `SO-INV-31`, append-only, `SEALED` terminal | **GUARANTEED BY CONTRACT** |
> | **no recursion is unbounded** | `SO-INV-12`, the depth-2 rule | **GUARANTEED — with an unprovable external terminus** |
> | **no silence reads as health** | `SO-INV-01` + amendment 18 | **GUARANTEED once amendment 18 is ratified; until then `NO-GAP` is reachable by default** |
> | **no monitor is priced out of existence** | FW-6, `SO-INV-15` | **BOUNDED — the floor's SIZE is `[G]`** |
> | **no honest reporter is penalized** | `SO-INV-23`, `SO-R184.3` | **BOUNDED — pricing depends on refutation capacity, which is B9 (`OR-S28`)** |
> **⟹ `SO-C27.2 — 92 ATTACKS: 78 CLOSED (55 CLOSED, 23 CLOSED-STRUCTURAL), 14 NOT (8 BOUNDED, 5 OPEN, 1 CONDITIONAL).
> 7 defenses flagged as depending on the attacker-controlled subsystem. 10 rule-compliant red-team surfaces remain, of
> which 3 are accepted as fundamentally unclosable.**
> **`[NON-CLAIM]` This contract does NOT claim security against a capable adversary that obeys every rule. §263 lists ten
> ways to be compliant and misleading at the same time.**

---

# §28 — SCALABILITY LIMITS

> ### **SO-C28.1 — THE COSTS, AND THE ONE THAT WAS REJECTED.** **[NORMATIVE]**
> | Mechanism | Cost | Note |
> |---|---|---|
> | occurrence recording | `O(detections)` | bounded by the detector set, not by `N` |
> | **coverage records** | **`O(scopes × windows)`** | **NOT `O(N)` — scopes are `[RO-13]`-declared, so their count is a governance choice** |
> | **`effective_sources` collapse** | **`O(|S|² × dims)` per claim** | **per claim, NOT global. A global collapse would be `O(N²)` and is NOT performed** |
> | self-model aggregation | `O(depth × breadth)` | depth ≤ 4 |
> | diagnosis status | `O(incidents)` | bounded by the containment budget |
> | **per-reader coverage** | **`O(readers × scopes × windows)`** | **INFEASIBLE at 10⁷ ⟹ `OR-S33`, ROUTED to `P0-04` rather than implemented** |
> **⟹ `SO-C28.2 — `P0-07`'s 10⁷ stop is RESPECTED and not re-validated. NO 10¹² GUARANTEE.** At `P0-07`'s R4+ regimes
> every P0-08 aggregate is per-envelope. **A complete organism-wide self-model at every cell is PROHIBITED (`SO-C17.2`) on
> the same ground `P0-03 RULE 5.4` rejected vector clocks: `O(N)` bytes per component inside a bounded envelope is a type
> error, not a compression problem.**

---

# §29 — HARDWARE ASSUMPTIONS

> ### **SO-C29.1 — THE FOUR ASSUMPTIONS AND THE SEVEN NON-REQUIREMENTS.** **[ASSUMPTION]**
> **REQUIRED:** **`AS-08`** platform energy counters, else the `DERIVED` flag ⟦`P0-07 X-H2`⟧ · **`AS-09`**
> per-deployment-class setpoints ⟦`P0-07` amendment 13⟧ — **a single global setpoint table across heterogeneous hardware
> makes the architecture SELECT FOR HARDWARE, silently, because every metric on the fast device improves** · **`AS-02`**
> a per-envelope monotone time source · **`IND-5`** hardware-class diversity for second detectors, **APPROXIMATE** —
> hardware class is deployment-specific and often unknown to the cell.
> **NOT REQUIRED:** shared memory · co-location · synchronous or global clocks · a global allocator · atomic
> multi-component transactions · a hardware RNG · a specific accelerator, language, framework, model family, database,
> cloud provider, or communication protocol (**§226: all seven rejected**).
> **⟹ `SO-C29.2 — THE ONE IMPLEMENTATION-ADJACENT DETAIL RETAINED, AND WHY: `causal_depth : u8`.** A width is close to an
> implementation detail, but it is a SEMANTIC requirement inherited verbatim from `P0-03` field 8 — **an unbounded width
> would be a vector clock by another name.** P0-08 invents no numeric type and no bounded width of its own.

---

# §30 — CONFORMANCE REQUIREMENTS

> ### **SO-C30.1 — EIGHT LEVELS, AND THE THREE-STAGE GATE.** **[NORMATIVE]**
> | Level | Requirement |
> |---|---|
> | **C0 schema** | every `OBJ-01…OBJ-28` field exists, typed, with mandatory/optional honoured — **including `OBJ-01`'s three easily-omitted fields** |
> | **C1 state machines** | all 21 implement their declared states and transitions, **and no undeclared transition exists** |
> | **C2 authority** | §7's 25 operations have exactly the stated roots; **no P0-08 object authorizes anything** |
> | **C3 provenance** | `P0-03`'s fields on every observation; `P0-04` classes for every record; **no vector clock; no second provenance store** |
> | **C4 fault/repair** | the six-axis taxonomy with six writers · occurrence/report separation · the four-status ladder with excluded drivers · serialization without confidence · mandatory `remaining_uncertainty` · non-repairer verification · coverage gaps written by containment |
> | **C5 adversarial** | **78 of 92 attacks closed by mechanism, and the 14 that are not are registered with status and routing. An implementation that closes MORE than specified is non-conformant, because an unexplained closure means an unregistered mechanism exists** |
> | **C6 coverage** | `OBJ-03` for every scope-window; `gap_class` read in the same read as any coverage quantity |
> | **C7 labels** | every canon rule carries exactly one §121 label; no canon rule cites an unlabelled volume statement |
> **⟹ `SO-C30.2 — THE GATE: `IMPLEMENT` requires C0+C1+C2+C3+C6+C7 · `OPERATE` adds C4 · `DEPLOY` adds C5.**
> **A system that merely implements the schemas but violates authority or provenance rules is NOT P0-08 CONFORMANT.**
> ### **SO-C30.3 — NON-CONFORMANCE HANDLING USES ONLY EXISTING MECHANISMS.** **[NORMATIVE]**
> **warning/finding (`[RO-13]`) · quarantine (EIK) · rollback (K) · freeze (EIK/OP) · external escalation (OP). There is
> no conformance police, authority, or state.** *The identification that makes this work: **a violated rule IS a fault**,
> and §11's taxonomy already routes `SPECIFICATION` (the contract is wrong) / `INSTRUMENT` (the checker is wrong) /
> `ENDOGENOUS` (the implementation is wrong).*

---

# §31 — OPEN RESEARCH

> ### **SO-C31.1 — 41 ENTRIES IN SIX CLASSES.** **[OPEN]**
> **O-R1 architecture-open 6:** `OR-S10` (resolving suppression when the suspect is the sole observer) · `OR-S20`
> (protection under total ledger failure) · `OR-S24` (a shared store that biases retrieval without being the root) ·
> `OR-S33` (per-reader coverage) · `OR-S37` (severity manufactured to harm a neighbouring scope) · `OR-S41` (influence
> over what governance sees).
> **O-R2 parameter-open 7:** `OR-S5`, `OR-S8`, `OR-S12`, `OR-S13`, `OR-S16`, `OR-S19`, `OR-S22`.
> **O-R3 empirical-open 1:** `OR-S1` (the base rates `expected_nonzero` requires) — with an O-R6 residual: the true
> `Q_ev` is unknowable in principle.
> **O-R4 scientific-open 1:** `OR-S38` (whether detectors of genuinely different types can be constructed at all — if
> not, no occurrence is ever `CONFIRMED`).
> **O-R5 governance-open 7:** `OR-S3`, `OR-S6`, `OR-S9`, `OR-S14`, `OR-S23`, `OR-S27`, `OR-S34`.
> **O-R6 fundamentally unclosable 19:** `OR-S2`, `OR-S4`, `OR-S7`, `OR-S11`, `OR-S15`, `OR-S17`, `OR-S18`, `OR-S21`,
> `OR-S25`, `OR-S26`, `OR-S28`, `OR-S29`, `OR-S30`, `OR-S31`, `OR-S32`, `OR-S35`, `OR-S36`, `OR-S39`, `OR-S40`.
> **⟹ `SO-C31.2 — 46% ARE O-R6, AND 12 OF THOSE 19 ARE VARIANTS OF ONE FACT: a system observing itself cannot, from
> inside, distinguish a correct observation from a coherent one.** The four roots behind all 41: **`RH-2`** (the organism
> influences what it is judged on) · **`A22`** (within-spec steering) · **`G24`** (a captured OP is indistinguishable
> from a legitimate one) · **K's uniqueness** (`P0-07 OR-H1`, sixth appearance).

---

# §32 — NON-CLAIMS

> ### **SO-C32.1 — TWENTY THINGS THIS CONTRACT DOES NOT CLAIM.** **[NON-CLAIM]**
> **1** perfect detection · **2** complete reporting · **3** causal understanding · **4** guaranteed recovery · **5**
> restoration of a pre-fault state · **6** self-awareness · **7** intelligence · **8** autonomy · **9** consciousness ·
> **10** AGI · **11** optimal monitoring · **12** an internally provable guarantee chain · **13** closure of `RH-2` ·
> **14** closure of `A22` · **15** detection of governance capture · **16** detection of assumption-sharing (`IND-6`) ·
> **17** resolution of semantic self-reference · **18** that internal consistency implies correctness · **19** that a
> bounded cycle is a broken one · **20** a 10¹² scale guarantee or that `Q_ev` is knowable.
> **⟹ `SO-C32.2 — THE ONE POSITIVE CLAIM, STATED PRECISELY:** within a declared scope and under declared governance, a
> population of cells can observe its own state, faults, capabilities, and limitations; classify, contain, repair, roll
> back, and recover from faults without requiring causal understanding; audit its own detectors without letting them
> audit themselves; describe itself without believing itself; and do all of it **while conferring no authority on any of
> it** — and every route by which observation, self-description, fault control, repair control, attention control, or
> information control could acquire authority, truth, or exemption is either CLOSED (78 attacks), CLOSED-STRUCTURAL, or
> REGISTERED as bounded, open, or conditional (14 attacks) with a named owner and routing.**
> **That is a claim about paths, writers, and authorities. It is not a claim about outcomes, performance, accuracy, or
> intelligence.**

---

# §33 — FINAL NORMATIVE RULES

> ### **SO-C33.1 — THE TWELVE RULES THAT, IF VIOLATED, MAKE AN IMPLEMENTATION NOT P0-08 REGARDLESS OF EVERYTHING ELSE.**
> **[NORMATIVE]**
> 1. **UNOBSERVED IS NOT HEALTHY.** `UNMEASURED` is a state, and no consumer may read it as `NOMINAL`. *(The central
>    invariant. Everything else in §131, §135, §136, §157, and §238 depends on it.)*
> 2. **CORRUPTION, ABSENCE, STALENESS, AND UNDECLARED POLICY ALL PRODUCE RESTRICTION, NEVER PERMISSION.**
> 3. **P0-08 HAS NO AUTHORITY-BEARING OBJECT.** The observation layer informs governance; it does not join it.
> 4. **NO SELF-DESCRIPTION IS SELF-AUTHORIZED.** A self-model, metacognitive record, diagnosis status, coverage record,
>    freshness class, and compression class are all written by someone other than their subject.
> 5. **CONTAINMENT IS AUTHORIZED BY DETECTION, NOT BY DIAGNOSIS.** Requiring a diagnosis first is circular and would make
>    every unknown-cause fault uncontainable.
> 6. **CORRELATION, PRECEDENCE, REPETITION, CONFIDENCE, AND SELF-REPORT NEVER PROMOTE A CAUSAL CLAIM.** Causal inference
>    is the evaluator's, off-line.
> 7. **AGGREGATION NEVER RAISES STATUS, AND SEVERITY IS NEVER AVERAGED.**
> 8. **CONSENSUS IS COLLAPSED TO AN EFFECTIVE SOURCE COUNT BEFORE IT IS COUNTED, AND EVERY INDEPENDENCE CLAIM NAMES ITS
>    DIMENSIONS AND ITS CLAIM-TYPE.**
> 9. **EVERY RECURSION TERMINATES AT DEPTH TWO, AND DEPTH TWO IS EXTERNAL.**
> 10. **A FREEZE HAS NO GOVERNANCE POWER, IS NEVER SELF- OR PEER-RELEASED, AND NEVER AUTO-EXPIRES INTO NORMAL OPERATION.**
> 11. **COST MAY MAKE AN OBSERVATION UNAFFORDABLE; IT MAY NEVER MAKE A MONITOR UNNECESSARY.** *(FW-6.)*
> 12. **OCCURRENCE AND REPORT ARE SEPARATE OBJECTS, AND NO STATE MAY BE THE ONLY RECORD OF AN EVENT.**
>
> ### **SO-C33.2 — THE FOUR AMENDMENTS THIS CONTRACT REQUESTS (NONE APPLIED).** **[NORMATIVE]**
> | # | Target | Content |
> |---|---|---|
> | **15** | `P0-05 §30` + `P0-07`'s reserve table | **B13, the observation reserve** — non-fungible, last-cut, first-restored |
> | **16** | `P0-02 §35.2` | **`IND-10` CAUSAL independence**, measured by `P0-05 R15.8`'s `inbreeding_F` |
> | **17** | `Cell G6` | **the denominator ALSO excludes detection and containment cost, charged to B10** — the same mechanism as `P0-07`'s amendment 5, and without it `SO-R185.5`'s blind-spot incentive is live |
> | **18** | `OBJ-03`'s default | **a scope with no declared `expected_nonzero` condition is `UNMEASURED` by default, NOT `NO-GAP` by default.** *The smallest amendment in the set and the most valuable: it removes a resting state rather than adding a detector* |
>
> ### **SO-C33.3 — THE STATUS OF THIS CANON.**
> **PROPOSED v1.0. Architecture only. 33 sections complete. 28 objects · 21 machines · 34 invariants · 26 parameters ·
> 27 monitors · 22 cross-contract dependencies · 16 assumptions · 92 attacks · 41 open-research entries · 4 amendments
> requested and none applied.**
> **⟹ `SO-C33.4 — THE CONTRACT'S ONE-SENTENCE SUMMARY: a system may observe itself completely and govern itself not at
> all — and every mechanism in this contract exists to keep those two halves apart.**

---

# CANON LEDGER

| Item | Value |
|---|---|
| **Document** | **"V4 — Self-Observation, Fault, Immune-Detection & Metacognition Contract v1.0"** |
| **Status** | PROPOSED v1.0 · architecture only · self-contained |
| **Canonical sections** | **33 of 33 complete** |
| **Canon clauses** | **`SO-C1.1 … SO-C33.4`**, numbered by canon section; **disjoint from the 249 `SO-R` volume rules by prefix** |
| **The central decision** | **`D-S01` — P0-08 ADDS NO AUTHORITY. It adds a typed observation layer** |
| **Objects** | **28**, each with one writer or a disjoint field-group split · **3 candidate objects ruled NOT to exist** |
| **State machines** | **21**, all mandatory for C1, 1 ⟦inherited⟧ verbatim · **no self-update transition · no age-keyed transition · no vector clock · 5 machines terminate in a REPORT rather than a resolution · 3 enforce `SO-INV-01` by absence of an edge** |
| **Invariants** | **34** — WRITER 8 · STATE 10 · SCHEMA 8 · GREP 4 · **[DECLARATIVE] 1** (`SO-INV-25`, with no instrument) |
| **Parameters** | **26** — 6 determinate, 21 unresolved or owned elsewhere, **NO INVENTED VALUES**, **4 that must not exist** |
| **Authority** | **25 operations × 5 existing authority roots · 2 marked UNRESOLVED rather than assigned · a 15-item ∅-set denied to every substrate actor** |
| **Firewalls** | **FW-6 added** (monitoring necessity ≠ monitoring cost), continuing `P0-07`'s FW-1…FW-5 |
| **Budget classes** | **B13 added** (amendment 15) |
| **Independence dimensions** | **IND-10 added** (amendment 16); **`IND-9` governance retained because §200 depends on it and the brief's list omits it** |
| **Attacks** | **92 (A172–A263)**: **CLOSED 55 · CLOSED-STRUCTURAL 23 · BOUNDED 8 · OPEN 5 · CONDITIONAL 1** = **78 closed / 14 not** · **7 defenses ⚠ flagged as attacker-dependent** |
| **Open research** | **41 (OR-S1…OR-S41)**: O-R1 6 · O-R2 7 · O-R3 1 · O-R4 1 · O-R5 7 · **O-R6 19** |
| **Assumptions** | **16** in 6 categories: 8 ACCEPTED · 4 ⚠️ · 3 ❌ · 1 ✅ discharged by audit |
| **Dependencies** | **22 (`XD-01…XD-22`)** in 6 edge types: 13 satisfied · 5 blocking-or-conditional · 6 preserved residuals |
| **Monitors** | **27 (`SOMon-1…SOMon-27`)** |
| **Amendments** | **4 requested (15–18), none applied** · **18 amendments across the series await ratification** |
| **Verdict** | **P0-08 COMPLETE WITH EXPLICIT RESIDUALS AND EXPLICIT OPEN RESEARCH** · **P0-09 NOT REQUIRED** · **the architecture is complete with P0-01 … P0-08** |

**Companion documents:** `README.md` — the reader's guide, the §122 traceability index, the machine check of every
numeric claim, the four self-found defects, and the completion statement.
