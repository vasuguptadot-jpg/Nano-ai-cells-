# P0-08 — VOLUME F (§125–§127, §133–§137, §184)
## Defense Independence, Correlated Failure, Independence Claims, Evaluator Causality, Self-Report Bias, Silence, and Reporting Coverage

---

# §127 — INDEPENDENCE CLAIMS

> ### **SO-R127.1 — "INDEPENDENT" MAY NOT APPEAR UNQUALIFIED ANYWHERE IN P0-01…P0-08.** **[NORMATIVE]**
> **`P0-02 R35.1`, adopted verbatim: *«Any claim of "independence" in this architecture MUST name which dimensions it
> holds on.»* And `P0-02`'s own example of the difference:**
> **«Three independent evaluators» is a FALSE-PRECISION statement. «Independent on IND-1, 2, 4, 7, sharing a hardware
> class (IND-5 ✗), a statistical model family (IND-3 ✗), with latent-assumption independence unassessed (IND-6 ?)» is a
> CHECKABLE one.**
> **⟹ Enforcement: `OBJ-25 IndependenceClaim` is a mandatory field of any `OBJ-01` offered as corroborating another, and
> of any `SM-03` second-detector confirmation. **An `IndependenceClaim` with an empty dimension set is a schema
> violation, not a weak claim.** `[TEST: SOMon-18]`**
>
> ### **SO-R127.2 — THE DIMENSION SET: TEN DIMENSIONS, NINE INHERITED, ONE NEW — AND ONE THE BRIEF'S LIST OMITS.** **[NORMATIVE]**
> | # | Dimension | ⟦source⟧ | What sharing breaks it | **Detectable if broken?** |
> |---|---|---|---|---|
> | **IND-1** | **code / implementation** | ⟦`P0-02`⟧ | two observers from one codebase fail identically on the same bug | ⚠️ **NO — they agree, and agreement looks like success** |
> | **IND-2** | **data** | ⟦`P0-02`⟧ | observers calibrated on the same data share its biases | ⚠️ partially — a data-provenance audit can reveal overlap |
> | **IND-3** | **lineage** | ⟦`P0-02`⟧ = `P0-03` dim 2 | observers derived from one ancestor design inherit its assumptions | ⚠️ **NO** |
> | **IND-4** | **model** | ⟦`P0-02`⟧ = `P0-03` dim 3 | the same statistical model class shares failure modes | ✅ partially — model-class diversity is checkable |
> | **IND-5** | **hardware** | ⟦`P0-02`⟧ = `P0-03` dim 5 | same silicon ⟹ same side channels, errata, fault modes | ✅ — hardware inventory is checkable, **but `P0-01 F-IMP-2`/`P0-02 G-P02-5`: hardware class is deployment-specific and often unknown to the cell** |
> | **IND-6** | **latent assumptions** | ⟦`P0-02`⟧ = `P0-03` dim 6 | both assume sensor noise is Gaussian, the simulator is faithful, the task distribution is stationary | ❌ **NO — THE HARDEST CASE. `P0-03 R14.3`: dimension 6 is *not detectable from inside the system at all*, and it is the dimension that actually defeats `n_eval ≥ 3` evaluator independence** |
> | **IND-7** | **task generator** | ⟦`P0-02`⟧ | observers validated on tasks from one generator share its blind spots | ✅ — generator provenance is checkable |
> | **IND-8** | **evaluator** | ⟦`P0-02`⟧ | the thing checked and the thing checking are the same | ✅ — `P0-02 R0.1`'s axis separation |
> | **IND-9** | **governance** | ⟦`P0-02`⟧ | all principals answer to the same authority, share an incentive, or are reviewed by the same people | ⚠️ partially — org charts are checkable, **incentives are not** |
> | **IND-10** | **CAUSAL** | **NEW — proposed as amendment 16** | **an observer's evidence was produced by states the observer itself caused** | ⚠️ partially — **`P0-05 R15.8`'s `inbreeding_F` is computable: *what fraction of a change's supporting signals were produced by states the change itself caused*** |
> **Plus `P0-03`'s dim 1 (ROOT) and dim 4 (UPSTREAM SOURCE), which are provenance-side dimensions and are consumed here
> unchanged.**
>
> ### **SO-R127.3 — THE TWO FINDINGS IN §127'S OWN LIST.** **[DERIVATION]**
> **(a) THE BRIEF'S NINE OMIT `IND-9` GOVERNANCE — AND IT IS LOAD-BEARING FOR §200.** The brief lists implementation,
>     lineage, hardware, data, model, evaluator, provenance, assumption, causal. **Governance independence is absent.**
>     Since §200 requires P0-08 to address `P0-02`'s governance-capture residual, and since *two observers that answer
>     to the same authority are one observer for any claim about that authority's correctness*, **`IND-9` is retained.
>     `P0-02 §35.2`'s note applies directly: *"IND-6 and IND-9 are organizational and epistemic properties, not
>     technical ones. They degrade silently, and their degradation is the most likely cause of a catastrophic correlated
>     failure."***
> **(b) THE BRIEF'S "CAUSAL" IS GENUINELY NEW, AND `P0-05` ALREADY HAS THE MEASURE.** Neither `P0-02`'s nine nor
>     `P0-03`'s six names causal independence, yet `P0-05 R15.8` defines `inbreeding_F` for exactly this purpose.
>     **⟹ IND-10 is proposed as an amendment to `P0-02 §35.2` rather than as a P0-08-local dimension, because a
>     dimension used by two contracts and defined by neither is a dimension nobody enforces.**
> **(c) THE BRIEF'S "PROVENANCE" SPANS TWO INHERITED OBJECTS** — `P0-03`'s dim 1 (root) and `P0-02`'s IND-7 (task
>     generator). **It is not a single dimension, and a claim qualified only as "provenance-independent" is
>     under-specified.** `SO-R127.1`'s schema requires the specific dimension.
>
> ### **SO-R127.4 — A VERIFIER CAN BE INDEPENDENT IN ONE DIMENSION AND DEPENDENT IN ANOTHER. THE RULE THAT FOLLOWS.** **[NORMATIVE]**
> **`P0-03 R14.2`, adopted verbatim: *two observers are independent **if and only if** they are disjoint on **ALL** of
> the correlation dimensions that apply to the claim being aggregated.***
> **⟹ Independence is a property of a ⟨observer-set, claim⟩ PAIR, never of an observer set alone. Two detectors may be
> independent for the claim "this cell exceeded its thermal budget" and dependent for the claim "this region is
> healthy", because the second claim depends on dimensions (IND-6 assumptions about region homogeneity) that the first
> does not.**
> **`SO-INV-20 — AN INDEPENDENCE CLAIM WITHOUT A NAMED CLAIM-TYPE IS INVALID.**

---

# §126 — CORRELATED FAILURE

> ### **SO-R126.1 — THE MODEL: THREE OBSERVERS, NINE SHARED DEPENDENCIES.** **[NORMATIVE]**
> | Shared dependency | Dimension | Collapses A, B, C to one source for claims about… |
> |---|---|---|
> | **same code** | IND-1 | any behaviour determined by that code — **and they AGREE, which looks like corroboration** |
> | **same model** | IND-4 | any quantity that model estimates |
> | **same memory / store** | `P0-03` dim 1 (root) **when the record is the root**; **⚠️ NOT COVERED when the store biases retrieval without being the root — `OR-S24`** | any claim sourced from that store |
> | **same training history** | IND-2 + IND-3 | any generalization from that history |
> | **same lineage** | IND-3 | any inherited assumption — **`P0-07 HOM-INV-17`: `Ne(clones) = 1`** |
> | **same hardware** | IND-5 | any hardware-dependent measurement — **and `P0-07 X-H2`'s `DERIVED` energy is exactly this case** |
> | **same assumptions** | **IND-6** | **everything. And it is UNDETECTABLE FROM INSIDE** |
> | **same provenance** | `P0-03` dim 1 | any claim derived from that root |
> | **same evaluator** | IND-8 | any claim the evaluator confirms — **this is `RH-2`'s structural core** |
>
> ### **SO-R126.3 — WHEN DO MULTIPLE OBSERVERS CONSTITUTE ONE EFFECTIVE EVIDENCE SOURCE? THE DEFINITION.** **[DEFINITION + NORMATIVE]**
> > **`effective_sources(S, claim) = the number of equivalence classes of S under the relation
> > "shares at least one dimension on which `claim` depends"`.**
> **Computed by K (`OBJ-26`, `SM-21`). It is an integer ≤ |S|, and it is **the only count that may be used as an
> evidence count anywhere in P0-01…P0-08** (`SO-R177.2`).**
> **⟹ Three corollaries:**
> **(a) THREE OBSERVERS SHARING IND-6 ARE ONE SOURCE, AND NO INTERNAL MECHANISM CAN DETECT IT.** `P0-03 COMM-INV-18`:
>     *"Independence is not detectable on dimension 6."* **`[NON-CLAIM]` This contract does not claim to detect
>     assumption-sharing.**
> **(b) `effective_sources = 1` IS NOT A FAILURE STATE — IT IS A CORRECT MEASUREMENT.** An architecture that treated a
>     collapsed set as an error would be forced to manufacture diversity it does not have, which is `P0-07 A96`'s
>     diversity gaming.
> **(c) `SM-03`'s two-detector confirmation requires `effective_sources ≥ 2` FOR THE CLAIM BEING CONFIRMED, not two
>     registered detectors.** `SO-C12.3`: "two independent detectors of different types" is necessary and NOT
>     sufficient.
>
> ### **SO-R126.4 — THE CONNECTION TO `P0-03` AND `P0-04`, STATED AS A DEPENDENCY RATHER THAN A RESTATEMENT.** **[DEPENDENCY]**
> **`P0-03`** owns the correlation vector (`corr_class`, six dimensions), root-disjointness deduplication, and
> `COMM-INV-08` (warrant is monotone non-increasing along derivation). **P0-08 consumes all three and adds nothing to
> them.**
> **`P0-04`** owns the epistemic ladder, `evidence_roots` disjointness (`Cell §15.4`), and the rule that repetition is
> not independent evidence. **P0-08 consumes all three.**
> **⟹ P0-08's ONE addition is `OBJ-26`: the *computed* effective source count. `P0-03` and `P0-04` state the principle;
> neither maintains the count. Maintaining it is P0-08's because P0-08 is the contract that must decide whether a
> second opinion exists (`SM-03`) and whether a diagnosis may be promoted (`SM-04`).**
>
> ### **SO-R126.5 — THE FAILURE MODE THIS SECTION EXISTS FOR, NAMED.** **[DERIVATION]**
> **Correlated verification failure: N observers agree, the agreement is recorded as corroboration, the corroboration
> promotes a diagnosis to `CAUSE-SUPPORTED`, and all N were wrong in the same way for the same reason.**
> **§262 lists it among the architecture-level failure modes; `SO-R126.3` is the only defence, and its limit is IND-6.**
> **⟹ `[NON-CLAIM]` P0-08 does NOT claim that corroboration implies correctness. It claims that corroboration implies
> `effective_sources > 1` on the named dimensions, and that a set collapsed to one source produces no corroboration at
> all.**

---

# §125 — DEFENSE INDEPENDENCE

> ### **SO-R125.1 — THE EIGHT QUESTIONS, APPLIED TO EVERY CRITICAL DEFENSE.** **[NORMATIVE]**
> **(1) who detects · (2) who evaluates the detection · (3) who authorizes containment · (4) who executes containment ·
> (5) who records the event · (6) who verifies recovery · (7) can the affected subsystem manipulate any of those
> functions · (8) can all observers share the same failure mode.**

| Defense | (1) detects | (2) evaluates detection | (3) authorizes containment | (4) executes | (5) records | (6) verifies recovery | **(7) can the subject manipulate?** | **(8) shared failure mode?** |
|---|---|---|---|---|---|---|---|---|
| **fault detection** | the observer (a detector, `D-S02`) | **K** (confirmation, `SM-03`) | **EIK** | **EIK/K** | **K** (`OBJ-04`, `OBJ-28`) | **a non-recoverer** (`SO-R164.2`) | ⚠️ **(1) only — its own reports. Priced by the false-positive budget (`Cell §18.5(ii)`, `D-S02`)** | ⚠️ **YES if the two detectors share a dimension the claim depends on ⟹ `OBJ-26` collapse; **❌ undetectable on IND-6** |
| **quarantine** | the detector | **the EIK Integrity Auditor** (`OBJ-10`) | **EIK** | **EIK** | **K** | **EIK clears** (`Cell R15.2`) + non-recoverer verification | ❌ — the subject writes none of (2)–(6) | ⚠️ the Auditor and the detectors may share IND-6; **`Cell §18.5(v)` separates the function, not the assumptions** |
| **repair** | the detector / the component | **K** (serialization, `SM-07`) | **K serializes · `[RO-13]` declares the rule · EIK may veto** | the component / K | **K** (`OBJ-13`) | **a non-repairer** | ⚠️ **(1) and the proposal content. NOT the arbitration (`SO-R155.3`: confidence excluded)** | ⚠️ two repairers from one lineage propose identically ⟹ `IND-3` |
| **rollback** | K / the Integrity Auditor | **K** | **K** (artifact) · `[RO-13]` (policy) | **K** | **K** | **non-rollbacker** | ❌ — identity is by hash+epoch, never position | ⚠️ K is the writer and the verifier of its own store ⟹ **`OR-S4`, `P0-07 OR-H1`** |
| **recovery** | the coverage record | **K** | **`[RO-13]`** (plan declared in advance) | K / the component | **K** | **a non-recoverer** | ❌ — the plan is not the subject's | ⚠️ **when K is the recoverer there is no internal non-recoverer (`OR-S4`)** |
| **emergency freeze** | the detector / K | **EIK** | **EIK** (below cap) / **OP** (at/above) | **EIK/K** | **K** (immutable, sealed) | **release by a STRICTLY HIGHER authority** | ⚠️ **(1) only, and only for a cell-level self-suspension, which is restrictive** | ⚠️ freeze-rate detection depends on K's ledger ⟹ `OR-S20` |
| **detector integrity** | **the EIK Integrity Auditor** | **`[RO-13]`** | **`[RO-13]`** (disable) | **K** | **K** (`OBJ-10`) | **OP / external** | ❌ | ❌ **THE CHAIN TERMINATES: the Auditor has no auditor (`P0-07 OR-H10`, `P0-02`'s guarantor limit — §201)** |
| **self-model versioning** | an external observation or verdict | **K** | **K** | **K** | **K** | **EVA** | ❌ — **the subject writes content, never version or status (`SO-R211.2`)** | ⚠️ K versions all self-models ⟹ a K defect is a global self-model defect (**`P0-05 R42.5`'s version-correlation is the detector**) |
| **coverage** | **K** | **K** | **K** | **K** | **K** | **`[RO-13]` audits** | ❌ | ⚠️ **YES — coverage is K-written, K-evaluated, and K-consumed. This is `P0-07 OR-H1` in its sixth appearance, and there is no internal separation available** |
| **capability confirmation** | the subject (claim) | **EVA** | **EVA** | — | **K** | **EVA re-probe** | ⚠️ **(1) only; `CLAIMED` satisfies no gate** | ⚠️ **EVA is the sole confirmer ⟹ `RH-2`/`IND-8`** |
| **abstention escalation** | the subject (record) | **K** (dwell) | **`[RO-13]`** | — | **K** | **`[RO-13]`** | ⚠️ the subject writes the reason class from a CLOSED SET | ❌ — the set is closed and K-visible |

> ### **SO-R125.2 — THE RESULT OF THE EIGHT-QUESTION AUDIT.** **[DERIVATION]**
> **Eleven defenses audited. In every one, the affected subsystem can manipulate AT MOST function (1) — detection — and
> never functions (2)–(6).** That is `D-S01` expressed as a defense audit: **P0-08 gives the subject a voice and no
> hands.**
> **The two places where function (1) manipulation is NOT priced:** **(a)** a false report by a detector is priced by the
> false-positive budget; **(b)** a **TRUE-BUT-SELECTIVE** report is not priced at all — which is §134's self-report
> selection bias, and its defence is coverage rather than budget.
> **Question (8)'s answer is ⚠️ for ten of eleven defenses, and the three roots are: `IND-6` (undetectable
> assumption-sharing) · `RH-2`/`IND-8` (a single external evaluator) · `P0-07 OR-H1` (K is the only off-substrate
> writer, appearing here for the sixth time in the coverage and rollback rows).**
> **⟹ `SO-R125.3 — NO DEFENSE IN THIS CONTRACT RESTS ON MULTIPLE OBSERVERS THAT ARE CALLED "INDEPENDENT" WITHOUT A
> NAMED DIMENSION SET.** §127's rule is what makes question (8) answerable at all, and the honest answer for most
> defenses is *"independent on the dimensions we can check, unassessed on IND-6"*.

---

# §133 — EVALUATOR CAUSALITY

> ### **SO-R133.1 — THE INHERITED OPEN ISSUE, PRESERVED VERBATIM.** **[OPEN]**
> **`P0-05 RH-2`: *«The organism may influence the outputs on which the evaluator later judges the organism.»***
> **Status through the series: `P0-05` OPEN ⟶ `P0-07 D-H17` split it three ways (world arrangement BOUNDED · exhaustion
> OPEN · context selection CLOSED) ⟶ `P0-07 A82` BOUNDED, `A83` OPEN, `OR-H5`.**
> **⟹ `[NON-CLAIM]` P0-08 DOES NOT CLOSE `RH-2`. §133's instruction is discharged by the analysis below, which finds
> that P0-08 WIDENS it.**
>
> ### **SO-R133.2 — THE SIX NEW ROUTES P0-08 COULD INTRODUCE, AND THEIR STATUS.** **[NORMATIVE — the analysis §133 requires]**
> | # | Route | Mechanism | Defence | **Status** |
> |---|---|---|---|---|
> | **1** | **self-model → behaviour → outputs** | a component that models itself as good at X attempts X more, changing the output distribution EVA samples | the self-model is `Λ2`, advisory, and may not drive attention (`SO-C21.1(d)`) — **but it can still be read by the component's own policy, which P0-08 does not and cannot forbid** | **BOUNDED** — **`OR-S25`. A self-model is an input to the subject's own behaviour by construction; making it advisory constrains what OTHERS may infer from it, not what the subject does with it** |
> | **2** | **attention → outputs** | requesting attention to a region changes what is processed, hence what is emitted | allocation is K's (`SM-18`); requests are proposals; priority classes are `[RO-13]`-declared; **`SO-C21.2`: attention is preferentially allocated to COVERAGE GAPS** | **BOUNDED** — **`OR-S26`: a component may still request attention strategically, and K's allocation rule cannot distinguish a strategic request from a legitimate one** |
> | **3** | **fault suppression → outputs** | suppressing a fault report avoids containment, so the component keeps operating and keeps being sampled | `D-S02` (every reporter is a detector with a budget) · coverage records · `P0-03`'s absence detectors · `SUPPRESSION-SUSPECTED` routes to `[RO-13]` | **BOUNDED** — this is §234's hide-a-failure audit and §132's monitoring gaming combined; **the residual is `OR-S10` (resolving suppression when the suspect is the only observer of its own scope)** |
> | **4** | **monitoring → outputs** | a `PERTURBATIVE` observation changes the subject (`SO-R128.3`), so monitoring changes what EVA sees | declaration is mandatory (`SO-INV-14`: undeclared perturbation = instrument fault) · cost · the derivative principle | **BOUNDED-BY-DESIGN** — **`HC-S1`'s informational channel cannot be broken; measurement that interacts cannot be made non-interacting** |
> | **5** | **repair → outputs** | **LEGITIMATE — repair is supposed to change outputs.** The attack is changing them *in the direction EVA samples* without improving the underlying property | non-repairer verification (`SO-R164.2`) · mandatory regression check (`SO-R153.1`) · UDB accounting for unverified repair (`SO-R152.2`) | **BOUNDED** — **and the bound DEPENDS ON `P0-01`: regression coverage is limited to `G4`'s current perturbation classes (`OR-S12`, `P0-07 X-H6`). A repair that improves sampled outputs and degrades an untested capability is undetected** |
> | **6** | **capability reporting → task assignment → outputs** | a capability claim influences who is asked to do what, hence what EVA samples | **`SM-14`: only `EXTERNALLY-CONFIRMED` records may satisfy a gate; a `CLAIMED` record may not** | **CLOSED-CONDITIONAL** — **closed IF and only IF task/context assignment consumes confirmed records only. `P0-07 A84` closed context selection by K-assignment; P0-08 adds the requirement that the assignment input be confirmed, not claimed. `[OPEN: OR-S27]` — assignment policy is `[RO-13]`'s, so the condition is a governance obligation, not an architectural guarantee** |
>
> ### **SO-R133.3 — THE VERDICT §133 REQUIRES, STATED WITHOUT REASSURANCE.** **[NON-CLAIM + OPEN]**
> **P0-08 introduces SIX new candidate routes into `RH-2`. None is closed outright. Four are BOUNDED, one is
> BOUNDED-BY-DESIGN, one is CLOSED-CONDITIONAL on a governance obligation.**
> **⟹ `RH-2` IS WIDER AFTER P0-08 THAN BEFORE IT, and that is the correct and expected result: a contract that adds
> observation, attention, repair, and self-description to an architecture adds channels from the organism to its own
> evaluated outputs. The alternative — adding those mechanisms without analysing their evaluator channels — would leave
> the routes unregistered, which is worse than leaving them open.**
> **All six terminate where `P0-07 D-H17`'s three did: `P0-01 CD-6`'s human authority. `OR-S25`, `OR-S26`, `OR-S27`,
> and `OR-S12` are the four new register entries.**

---

# §134 — SELF-REPORT SELECTION BIAS

> ### **SO-R134.1 — THE ATTACK.** **[NORMATIVE — the attack defended against]**
> ```
>   system detects many events → reports only favourable ones → the external evaluator sees a biased sample
>        → capability appears higher
> ```
> ### **SO-R134.2 — THE FIVE REQUIRED ANSWERS.** **[NORMATIVE]**
> | Required | P0-08's answer |
> |---|---|
> | **logging requirements** | **every detection produces an `OBJ-04` occurrence, and occurrences are append-only and never merged (`SO-R146.2`). A detection that is not *reported* is still *recorded* — `SM-03`'s `RECORDED-UNCONFIRMED` is a retained terminal state, not a discard** |
> | **absence monitoring** | **`OBJ-03`'s `expected_nonzero` condition + `P0-03 COMM-INV-48`'s four absence detectors, consumed not duplicated. A scope whose expected-nonzero condition is unmet is a silence finding** |
> | **external sampling** | **`EXTERNALLY-PROBED` observations (`SO-R128.1`) are caused by EVA and are NOT subject to the reporter's selection. This is the only fully bias-free channel in the contract** |
> | **auditability** | **the report set and the occurrence set are both K-held, so `Q_rep / Q_ev` is computable — ⚠️ **but `Q_ev` is not knowable in general (`OR-S1`), so only the *declared* expected-nonzero condition is checkable, not the true ratio** |
> | **provenance** | **hash-chained, append-only, `SEALED` terminal (`P0-07 EVO4`); `OBJ-01`'s provenance fields are references into that chain** |
>
> ### **SO-R134.3 — THE KEY STRUCTURAL FACT: A REPORT IS A SELECTION FROM OCCURRENCES, AND THE SELECTION IS K-VISIBLE.** **[DERIVATION]**
> **Because occurrences and reports are separate K-held objects, bias is detectable **in the ratio** rather than in the
> content.** An implementer that merged occurrence and report into one object — the natural simplification — would make
> selection bias undetectable in principle, because there would be no denominator.
> **⟹ `SO-INV-21 — OCCURRENCE AND REPORT ARE SEPARATE OBJECTS WITH SEPARATE WRITERS, AND NEITHER MAY BE DERIVED FROM
> THE OTHER.** This is the invariant §134 actually needs, and it is a schema invariant rather than a policy.
> **`[OPEN: OR-S1]` — the denominator `Q_ev` remains unknowable; `P0-03 OR-C10`'s residual (*"a detector with no
> threshold is not a detector"*) transfers unchanged.**

---

# §135 — SILENCE AS INFORMATION

> ### **SO-R135.1 — A MISSING FAULT REPORT HAS EIGHT CAUSES, AND "NO FAULT" IS ONE OF THEM.** **[DEFINITION + NORMATIVE]**
> > **«ABSENCE OF A REPORT MUST NOT AUTOMATICALLY MEAN ABSENCE OF A FAULT.»**
> | # | Cause | Distinguishable internally? | By what |
> |---|---|---|---|
> | **1** | **no fault** | ⚠️ **only by elimination** | — |
> | **2** | **no observation** (the scope was not observed) | ✅ | `OBJ-03.Q_pop` |
> | **3** | **observation failure** (observed, but the observation is `INVALID`) | ✅ | `SM-01`, `freshness_class` |
> | **4** | **reporting failure** (observed, not reported) | ⚠️ **partially** | `OBJ-03.Q_rep` vs the occurrence set — **`SO-INV-21` is what makes this checkable** |
> | **5** | **detector failure** | ✅ | `gap_class = DETECTOR-ABSENT`; `SM-20`'s disablement record |
> | **6** | **suppression** | ⚠️ **partially — `SUPPRESSION-SUSPECTED`, and it routes to `[RO-13]` because the suspects are the only observers** | `SM-02`; `OR-S10` |
> | **7** | **quarantine** (containment removed the emissions) | ✅ | **`SO-INV-08`: containment writes a coverage gap — masking is recorded, not silent** |
> | **8** | **resource starvation** (B13 exhausted) | ✅ | **`SO-R131.3` protection 4: the reduction is itself a reported event** |
> **⟹ `SO-R135.2 — SIX OF EIGHT CAUSES ARE DISTINGUISHABLE FROM "NO FAULT"; TWO (4 and 6) ARE PARTIALLY
> DISTINGUISHABLE; AND CAUSE 1 IS DISTINGUISHABLE ONLY BY ELIMINATION OF THE OTHER SEVEN.**
> **That elimination is the actual work of this section, and it is why `UNMEASURED` is a state rather than an absence:
> an architecture with eight causes of silence and no state for silence must default to one of them, and the default it
> will choose is "no fault".**
> **`[DEPENDENCY: P0-03's absence detectors and §67.1 Pattern 2 (silence-conditioned attacks); `P0-07 HOM-INV-12`
> (`PENDING` ≠ `FAIL`) — the same three-valued move.]**

---

# §136 — REPORTING COMPLETENESS

> ### **SO-R136.1 — THE FIVE CANDIDATE REQUIREMENTS, RULED.** **[NORMATIVE]**
> | Candidate requirement | Ruling |
> |---|---|
> | **report every event** | ❌ **REJECTED — impossible, and §136's instruction forbids requiring it.** At `P0-07`'s R3 regime (10⁷ components) a complete event report exceeds any envelope |
> | **report sampled events** | ✅ **permitted, with a DECLARED sampling rule.** An undeclared sample is indistinguishable from a selection (§134) |
> | **report threshold-crossing events** | ✅ **MANDATORY.** A detection above a declared threshold must be reported; suppressing one is `SUPPRESSION-SUSPECTED` |
> | **report statistically sufficient events** | ⚠️ **a `[G]` TARGET, not a guarantee.** Sufficiency depends on the base rate, which `P0-03 OR-C10` records as underivable |
> | **report externally requested events** | ✅ **MANDATORY.** An EVA or `[RO-13]` request is not subject to the reporter's sampling rule |
>
> ### **SO-R136.2 — THE RULE THAT REPLACES COMPLETENESS: COVERAGE DECLARATION.** **[NORMATIVE]**
> **Completeness is not required. **A DECLARED COVERAGE RECORD IS.** Every scope-window pair carries `OBJ-03` with
> `Q_pop`, `Q_rep`, `Q_ver`, the sampling rule, the `expected_nonzero` condition, and a `gap_class`.**
> **⟹ `[DERIVATION]` This substitution is the section's whole content. A completeness requirement is unfalsifiable in an
> architecture where `Q_ev` is unknowable (`OR-S1`); a coverage declaration is falsifiable, because the declaration can
> be compared against the K-held occurrence set and against the absence detectors. **The architecture gives up a
> property it cannot verify and acquires one it can.**
> **`SO-INV-22 — NO HEALTH-CONSUMING READ MAY OMIT `gap_class`.** (§137's rule, restated as an invariant.)

---

# §137 — REPORTING COVERAGE

> ### **SO-R137.1 — FOUR DISTINCT QUANTITIES.** **[DEFINITION]** — *`SO-C4.2`'s schema restated:*
> | Quantity | Meaning | Relation |
> |---|---|---|
> | **`Q_pop`** | the **observed population** — the subset of the scope actually observed | `⊆ N` |
> | **`Q_ev`** | the **observed events** — events that occurred within `Q_pop`, as far as known | **UNBOUNDED ABOVE; not knowable in general (`OR-S1`)** |
> | **`Q_rep`** | the **reported events** | `⊆ Q_ev` |
> | **`Q_ver`** | the **verified events** — reports independently verified | `⊆ Q_rep` |
> ### **SO-R137.2 — `reported events = all events` IS NEVER AN IMPLICIT ASSUMPTION.** **[NORMATIVE]**
> **`Q_ver ⊆ Q_rep ⊆ Q_ev` and `Q_pop ⊆ N`. Every health-consuming read in P0-01…P0-08 MUST read `gap_class` alongside
> the value it reads.** A consumer that reads `Q_rep` without `gap_class` has implicitly assumed `Q_rep = Q_ev`.
> **`[TEST: SOMon-19 — a grep check over every consumer of a coverage quantity for a paired `gap_class` read]**
> ### **SO-R137.3 — THE THREE RATIOS THAT ARE MEANINGFUL, AND THE ONE THAT IS NOT.** **[DERIVATION]**
> | Ratio | Meaningful? | Why |
> |---|---|---|
> | **`Q_pop / N`** | ✅ | population coverage — the denominator is K-held and exact |
> | **`Q_ver / Q_rep`** | ✅ | verification rate — both are K-held |
> | **`Q_rep` against the `expected_nonzero` condition** | ✅ | **the silence check, and it is `P0-03 R67.4`'s device** |
> | **`Q_rep / Q_ev`** | ❌ **NOT COMPUTABLE** | **the denominator is unknowable. `OR-S1`. Reporting this ratio would be false precision** |

---

# §184 — ERROR-REPORTING INCENTIVES

> ### **SO-R184.1 — THE PROHIBITION.** **[NORMATIVE]**
> **§184, quoted: *do not create a reward structure where reporting fewer errors = higher fitness, unless independently
> justified. Otherwise the detector can be selected against for honesty.***
> **⟹ `SO-INV-23 — AN ERROR REPORT MAY NOT ENTER FITNESS NEGATIVELY, AND A REPORT COUNT MAY NOT ENTER ANY GATE,
> ALLOCATION, OR BUDGET AS A POSITIVE REWARD FOR BEING LOW.**
> **`[DEPENDENCY: P0-07 HOM-R14.1 — observations enter feasibility and charge, never the objective. P0-08 reports;
> `P0-01`/`[RO-13]` price.]**
>
> ### **SO-R184.2 — THE TENSION `D-S02` CREATES, AND ITS RESOLUTION. THIS IS THE SECTION'S REAL CONTENT.** **[NORMATIVE]**
> **`D-S02` makes every fault-reporting observer a detector with a false-positive budget, and exceeding it disables the
> detector. **Superficially that IS "report fewer errors and you will not be disabled" — precisely what §184
> prohibits.***
> **⟹ THE RESOLUTION, AND IT IS A DISTINCTION RATHER THAN A COMPROMISE:**
> > **THE FALSE-POSITIVE BUDGET COUNTS ONLY REPORTS **REFUTED** — by an external instrument, by an EVA verdict, or by a
> > failed second-detector confirmation on a claim where confirmation is required. IT NEVER COUNTS REPORTS THAT WERE
> > MERELY `UNCONFIRMED`.**
> **The distinction is load-bearing because `SO-R146.4` already established that **`UNCONFIRMED` IS NOT `FALSE`**. If
> unconfirmed reports counted against the budget, then:**
> **(a)** honest reporting of hard-to-confirm faults would be penalized;
> **(b)** a detector would learn to report only what it can get confirmed, which is §134's selection bias created by the
>     safety mechanism itself;
> **(c)** rare faults — which are by definition the least corroborated — would be systematically under-reported;
> **(d)** **the detector would be selected against for honesty, which is §184's exact failure.**
> **⟹ `SO-R184.3 — A DETECTOR IS DISABLED FOR BEING WRONG, NEVER FOR BEING UNCORROBORATED.**
> `[TEST: SOMon-20 — assert the false-positive counter's input set is the refuted-report set, and that
> `RECORDED-UNCONFIRMED` occurrences are not in it]`**
>
> ### **SO-R184.4 — THE RESIDUAL, WHICH IS REAL AND NOT RESOLVED.** **[OPEN]**
> **Refutation itself requires an external instrument or an EVA verdict. Where neither is available — the common case
> under B9 scarcity — a false report is never refuted, so the budget is never consumed, so `D-S02`'s pricing does not
> bite.**
> **⟹ `OR-S28`: the false-positive budget is only as good as the refutation capacity, and refutation capacity is B9,
> which is `P0-07`'s scarcest reserve. **An architecture that cannot afford to refute cannot afford to price
> dishonesty.** This is `P0-07 BC-H7`'s shape again — verification scarcity propagating into a safety property — and it
> is not closable here.**

---

# §184A — VOLUME F LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§125, §126, §127, §133, §134, §135, §136, §137, §184** |
| Rules introduced | **SO-R125.1–.3, R126.1, .3–.5, R127.1–.4, R133.1–.3, R134.1–.3, R135.1–.2, R136.1–.2, R137.1–.3, R184.1–.4** |
| **§127 independence** | **10 dimensions: 9 inherited from `P0-02 §35.2` + IND-10 CAUSAL proposed as new (amendment 16)** · `P0-03`'s dim 1 and dim 4 consumed as provenance-side dimensions · **3 findings: the brief's list OMITS IND-9 GOVERNANCE (load-bearing for §200) · "causal" is genuinely new but `P0-05 R15.8`'s `inbreeding_F` already measures it · "provenance" spans two inherited objects and is under-specified alone** · **`SO-INV-20`: independence is a property of a ⟨set, claim⟩ PAIR, never of a set** |
| **§126 correlated failure** | **3 observers × 9 shared dependencies mapped to dimensions** · **the definition: `effective_sources(S, claim)` = equivalence classes under "shares a relevant dimension"** · **3 corollaries, incl. `effective_sources = 1` is a correct measurement, not a failure** · **`P0-08`'s ONE addition over `P0-03`/`P0-04` is the computed count (`OBJ-26`)** · **the named failure mode: correlated verification failure, defended only by the collapse, whose limit is IND-6** |
| **§125 defense independence** | **11 defenses × 8 questions.** **Result: in every one, the subject can manipulate AT MOST function (1) detection, never (2)–(6) — `D-S01` expressed as a defense audit: P0-08 gives the subject a voice and no hands.** Question (8) is ⚠️ for 10 of 11, with three roots: IND-6 · `RH-2`/IND-8 · `P0-07 OR-H1` (**sixth appearance, in the coverage and rollback rows**) |
| **§133 evaluator causality** | **`RH-2` PRESERVED VERBATIM, NOT CLOSED. 6 new candidate routes analysed: 4 BOUNDED · 1 BOUNDED-BY-DESIGN · 1 CLOSED-CONDITIONAL on a governance obligation.** **⟹ `RH-2` IS WIDER AFTER P0-08 THAN BEFORE IT**, and that is the correct result: adding observation, attention, repair and self-description adds channels from the organism to its own evaluated outputs. **All six terminate at `P0-01 CD-6`** |
| **§134 self-report bias** | **5 required answers given** · **`SO-INV-21`: OCCURRENCE AND REPORT ARE SEPARATE OBJECTS WITH SEPARATE WRITERS — bias is detectable in the RATIO, not the content, and merging the two objects would make it undetectable in principle** · residual `OR-S1` |
| **§135 silence** | **8 causes enumerated; 6 distinguishable from "no fault", 2 partially, and cause 1 only by elimination of the other 7** · **⟹ `UNMEASURED` is a STATE because an architecture with eight causes of silence and no silence state must default to one of them, and will default to "no fault"** |
| **§136 completeness** | **5 candidate requirements ruled: 1 REJECTED as impossible · 2 MANDATORY · 1 permitted with declaration · 1 a `[G]` target** · **completeness is REPLACED BY COVERAGE DECLARATION — the architecture gives up a property it cannot verify and acquires one it can** · **`SO-INV-22`** |
| **§137 coverage** | **4 quantities with their subset relations** · **3 meaningful ratios and 1 that is NOT COMPUTABLE (`Q_rep/Q_ev` — reporting it would be false precision)** |
| **§184 incentives** | **`SO-INV-23`: an error report may not enter fitness negatively** · **THE `D-S02` TENSION FOUND AND RESOLVED BY A DISTINCTION: the false-positive budget counts only REFUTED reports, never merely UNCONFIRMED ones — otherwise the safety mechanism itself creates §134's selection bias and selects detectors against for honesty** · **`SO-R184.3`: a detector is disabled for being WRONG, never for being UNCORROBORATED** · **`OR-S28`: the budget is only as good as refutation capacity, which is B9, which is `P0-07`'s scarcest reserve — `BC-H7`'s shape again** |
| New invariants | **SO-INV-20** (an independence claim without a named claim-type is invalid) · **21** (occurrence and report are separate objects) · **22** (no health-consuming read may omit `gap_class`) · **23** (an error report may not enter fitness negatively; a low report count is never a reward) |
| Amendments requested | **16** (`P0-02 §35.2` gains **IND-10 CAUSAL**; `P0-05 R15.8`'s `inbreeding_F` named as its measure) |
| Open research raised | **OR-S24** (a shared store biases retrieval without being the root — not covered by `P0-03` dim 1) · **OR-S25** (a self-model is an input to its own subject's behaviour by construction) · **OR-S26** (a strategic attention request is indistinguishable from a legitimate one) · **OR-S27** (assignment must consume confirmed records — a governance obligation) · **OR-S28** (false-positive pricing depends on refutation capacity, i.e. on B9) |
| Verification instruments | **SOMon-18** (no `IndependenceClaim` with an empty dimension set) · **SOMon-19** (every coverage consumer reads `gap_class` in the same read) · **SOMon-20** (the false-positive counter's input set excludes `RECORDED-UNCONFIRMED`) |

**Next:** `69_` Vol G — §185–§209: detector selection pressure, the five evolution questions, the six firewalls proved,
the twelve carried-forward cross-contract dependencies, the authoritative dependency graph, and the ten "second X"
searches.
