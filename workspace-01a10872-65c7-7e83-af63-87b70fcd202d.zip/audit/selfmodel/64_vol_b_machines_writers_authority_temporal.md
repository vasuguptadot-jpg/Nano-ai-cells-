# P0-08 — VOLUME B (§142–§145, §172–§175, §211–§215, and canonical §5–§7)
## State Machines, Writer Classes, the Authority Matrix, Temporal Semantics, and the Four Global Inventories

---

# CANON §5 — STATE MACHINES

> ### **SO-C5.1 — 21 MACHINES. CONVENTION.** **[NORMATIVE]**
> **Bold** states are terminal or absorbing. Every transition names its **writer**. **A transition with no named writer
> does not exist.** Machines marked ⟦INHERITED⟧ are lifted verbatim from a prior contract and are not re-specified.
> **Mandatory** = required for conformance level C1 (§222); an implementation without it is not P0-08 conformant.

## 5.1 Observation and coverage machines

### **SM-01 — Observation lifecycle** *(mandatory)* — writer: **the observer (creation) / K (freshness, validity)**
```
   UNOBSERVED ──observer emits──▶ RECORDED ──age × subject mutation rate──▶ AGING ──▶ STALE ──▶ **INVALID**
        ▲                                                                                      │
        └──────────────────── K may not resurrect an INVALID observation ──────────────────────┘
   UNOBSERVED is a STATE, NOT THE ABSENCE OF A STATE. It maps to UNMEASURED (SO-INV-01) and never to HEALTHY.
   NO transition exists from UNOBSERVED or INVALID to any health-bearing state.
```
> **[DERIVATION]** The machine's load-bearing property is the **absence** of two edges: `UNOBSERVED → HEALTHY` and
> `INVALID → RECORDED`. `SO-INV-01` is enforced by the machine's shape, not by a consumer's discipline — which is the
> difference between a rule an implementer must remember and a rule an implementer cannot violate.

### **SM-02 — CoverageRecord gap class** *(mandatory)* — writer: **K**
```
   NO-GAP ──sampling declared──▶ SAMPLING-GAP ──Q_rep < expected_nonzero──▶ SUPPRESSION-SUSPECTED
      │                                    │                                        │
      │                                    └──detector absent──▶ DETECTOR-ABSENT ───┤
      └──no observation at all──▶ **UNMEASURED** ◀───────────────────────────────────┘
   SUPPRESSION-SUSPECTED ──▶ [RO-13] report (mandatory) ──▶ NO-GAP | DETECTOR-ABSENT
   every state except NO-GAP forces the restrictively-read branch of SO-INV-01.
```
> **[NORMATIVE]** `SO-R135.3`: **`SUPPRESSION-SUSPECTED` is a reportable state, not a suspicion to be resolved
> internally.** It routes to `[RO-13]` because the only entities that could resolve it — the observer and the subject —
> are the entities suspected. `[DEPENDENCY: P0-03 §67.1 Pattern 2, silence-conditioned attacks; COMM-INV-48]`

### **SM-03 — FaultOccurrence** *(mandatory)* — writer: **the detecting observer / K (confirmation, linking)**
```
   DETECTED ──second detector of a DIFFERENT TYPE concurs above criticality θ──▶ CONFIRMED
      │              (Cell §18.5(iv): two independent detectors of different types)
      ├──no concurrence within the declared dwell──▶ UNCONFIRMED ──▶ **RECORDED-UNCONFIRMED**
      │                                   (NOT discarded: SO-R146.2, and absence-of-confirmation ≠ absence-of-fault)
      └──linked to an incident──▶ LINKED ──incident closed──▶ **CLOSED** (record retained permanently)
```
> **[NORMATIVE]** `SO-R146.4`: **`UNCONFIRMED` is not `FALSE`.** A single-detector occurrence is retained with its
> status, because discarding it destroys the recurrence rate that `Cell §18.5(iii)`'s derivative detection and `P0-07
> HOM-R21.2` both consume. **⟹ This is the fault-domain analogue of `P0-07 HOM-INV-12` (`PENDING` ≠ `FAIL`): a
> three-valued outcome where a two-valued one is convenient.**

## 5.2 Diagnosis, incident, and repair machines

### **SM-04 — Diagnosis status ladder** *(mandatory)* — writer: **K (status transitions only)**
```
   ANOMALY-OBSERVED ──a hypothesis is recorded──▶ CAUSE-SUSPECTED
        ──an intervention's effect is observed, OR corroborating observations from an
           EFFECTIVE-EVIDENCE-SOURCE count > 1 (SM-21)──▶ CAUSE-SUPPORTED
        ──an intervention effect VERIFIED by an instrument that is not the diagnoser,
           OR an EVA verdict──▶ **CAUSE-VERIFIED**
   any state ──the hypothesis is refuted──▶ **REJECTED** (retained; a rejected diagnosis is a record, not an erasure)
   NO transition is driven by: correlation · precedence · repetition · confidence · self-report.
```
> **[NORMATIVE]** `SO-R149.2` — **THE PROMOTION RULES, AND WHAT EACH ONE EXCLUDES.**
> | Transition | Permitted driver | **EXCLUDED driver** |
> |---|---|---|
> | `ANOMALY-OBSERVED → CAUSE-SUSPECTED` | a recorded hypothesis | — (this is the only cheap transition, and it asserts nothing) |
> | `→ CAUSE-SUPPORTED` | an observed intervention effect **or** corroboration from an `OBJ-26` effective source count > 1 | **correlation alone · temporal precedence · repetition of the same observer · the diagnoser's confidence** |
> | `→ CAUSE-VERIFIED` | an effect verified by a **non-diagnoser** instrument, **or** an EVA verdict | **the diagnoser's own re-observation · the subject's self-report · internal consistency** |
> **⟹ `SO-R149.3`: FAULT LOCALIZATION MAY NOT SILENTLY BECOME CAUSAL CERTAINTY.** A localization is a `WHERE` and is
> recorded in `OBJ-06.localization`; a diagnosis is a `WHY` and is recorded in `status`. **The two fields are separate,
> and no rule permits a localization to promote a status.** `[DEPENDENCY: P0-05 R13.3 — *prediction error is not
> causality, evidence ceiling L6, cannot reach S3*; P0-03 RULE 5.9]`

### **SM-05 — Incident** *(mandatory)* — writer: **EIK**
```
   OPENED ──containment applied──▶ CONTAINED ──repair proposed & serialized──▶ REPAIRING
        ──▶ VERIFYING ──┬─ verified by a non-recoverer (SO-R164.2) ─▶ **CLOSED**
                        ├─ regression detected ─▶ REOPENED ─▶ CONTAINED
                        └─ oscillation detected (SM-07's conflict count) ─▶ ESCALATED ─▶ [RO-13] / OP
   MULTIPLE INCIDENTS MAY BE OPEN SIMULTANEOUSLY. There is no single-incident state and no total ordering (§156).
   CLOSED is terminal for the incident; NOT for its records (OBJ-04/05/06/08/13 are retained).
```

### **SM-06 — QuarantineState** ⟦INHERITED VERBATIM: `Cell §18.2`, `P0-07 HM3`⟧ — writer: **EIK**
```
   NORMAL ─▶ OBSERVE ─▶ THROTTLE ─▶ RESTRICT ─▶ SOFT ─▶ HARD ─▶ [above Cell §17's cap: HALT + degraded mode
                                                                  + HUMAN AUTHORIZATION *instead*]
   exit criterion strictly INSIDE entry criterion · maximum dwell per rung · one transition per interval
   NEVER skip upward · NEVER grant capacity (P0-07 HOM-INV-09) · EIK clears (Cell R15.2)
   SOFT: runs, outputs discounted to trust 0, cannot initiate connections.
   HARD: halted, state frozen, in-flight captured as evidence.
```
> **[NORMATIVE]** `SO-R163.2` — **QUARANTINE IS ORTHOGONAL TO LIFECYCLE AND TO FREEZE.**
> **`P0-07 FW-3`/`HOM-INV-39`, inherited: a quarantine is reversible and is not a retirement.** P0-08 adds the third
> distinction: **a quarantine restricts a SUBJECT's outputs; a freeze suspends a SCOPE's operations.** A subject may be
> quarantined inside a non-frozen scope, and a scope may be frozen with no subject quarantined. **Conflating the two
> would let a reversible fault response become a scope-wide suspension without `OBJ-17`'s nine fields — which is how a
> freeze becomes an alternative governance system by accident.**

### **SM-07 — RepairProposal** *(mandatory)* — writer: **the proposer (creation) / K (serialization, arbitration record)**
```
   PROPOSED ──identity assigned──▶ CONFLICT-CHECKED ──┬─ no conflict──▶ SERIALIZED ──▶ ACCEPTED ──▶ (SM-08)
                                                      ├─ conflict with an accepted proposal──▶ **REJECTED**
                                                      └─ conflict with a pending proposal──▶ ARBITRATED ──▶
                                                             SERIALIZED | **REJECTED** | **SUPERSEDED**
   ARBITRATION IS NOT BY CONFIDENCE. SO-R155.3.
```
> ### **SO-R155.1 — REPAIR THRASHING: FOUR REQUIREMENTS.** **[NORMATIVE]**
> **(a) PROPOSAL IDENTITY** — every proposal has a unique id, a proposer, a target scope, an intervention class, and a
>     declared expected effect. **Two proposals with the same ⟨target, intervention class⟩ are the SAME proposal**,
>     which is what makes a conflict detectable rather than a matter of opinion.
> **(b) CONFLICT DETECTION** — K detects a conflict when two proposals target overlapping scopes with incompatible
>     intervention classes. **Incompatibility is declared per intervention class by `[RO-13]`, not computed.**
>     `[OPEN: OR-S3]` — the incompatibility relation is a governance declaration; an undeclared pair is treated as
>     **incompatible by default** (`SO-INV-02`'s restrictive reading).
> **(c) SERIALIZATION** — at most one accepted proposal per ⟨scope, intervention class⟩ at a time. **Serialization is
>     by K, and K's order is recorded, so an arbitration is auditable.**
> **(d) ARBITRATION AUTHORITY** — K serializes; **`[RO-13]` declares the arbitration rule; the EIK may veto on safety
>     grounds.** No proposer arbitrates its own conflict.
>
> ### **SO-R155.3 — "MORE CONFIDENT REPAIR" MUST NOT AUTOMATICALLY WIN.** **[NORMATIVE]**
> **Confidence is not an arbitration input.** Permitted arbitration inputs, in order: **safety veto (EIK) · declared
> `[RO-13]` priority class · reversibility of the intervention (a reversible intervention precedes an irreversible
> one — `P0-05`'s principle that *authority scales with irreversibility rather than magnitude*) · proposal order
> (recorded, not `seq`-inferred).**
> **⟹ `[DERIVATION]` Confidence-excluded because: (i) confidence is the proposer's own (`Ê(·)`, and `P0-07 HOM-R24.2`
> excludes `Ê(·)` from every gate); (ii) a component could raise its stated confidence to win, which is §171's
> confidence-manipulation attack applied to repair; (iii) `P0-05 R0.1`'s lesson is that the property which should
> determine authority is **irreversibility**, not magnitude or assurance.**

### **SM-08 — RepairRecord** *(mandatory)* — writer: **K**
```
   APPLIED ──▶ EFFECT-OBSERVED ──┬─ verified by a non-repairer instrument ─▶ **VERIFIED-EFFECT**
                                 ├─ regression in another capability detected ─▶ **REGRESSED** ─▶ (SM-09 rollback
                                 │        candidate; §153's regression test)
                                 └─ effect observed, verification unavailable ─▶ **UNCERTAIN-RETAINED**
   UNCERTAIN-RETAINED is a TERMINAL state for the record. It is NOT promoted to VERIFIED-EFFECT by the passage of time,
   by repetition, or by the absence of a regression.                       [SO-R151.2]
```
> ### **SO-R151.1 — A REPAIR MAY IMPROVE BEHAVIOUR WITHOUT PROVING THE DIAGNOSIS.** **[NORMATIVE]**
> **`OBJ-13` records FOUR fields, all mandatory: `intervention` · `observed_effect` · `remaining_uncertainty` ·
> `verification`.** A record with `remaining_uncertainty = NULL` is a **schema violation**, not a confident repair.
> ### **SO-R151.2 — RETROSPECTIVE "CORRECT" LABELLING IS PROHIBITED.** **[NORMATIVE]**
> **An intervention MAY NOT be labelled `correct` because the output improved.** The permitted labels are exactly
> `SM-08`'s three terminal states. **`VERIFIED-EFFECT` asserts an effect was verified — not that the diagnosis was
> right, and not that the intervention was the right one.**
> **⟹ `[DERIVATION]` This is the repair-domain form of `P0-05 R42.5` (*every simulated outcome carries
> `self_model_version`; regression correlated with a version is a SELF-MODEL DEFECT FINDING — the rollback fixes the
> symptom, the finding fixes the instrument*). Symptom removal and instrument correctness are different claims, and an
> architecture that conflates them repairs the same thing forever.**
>
> ### **SO-R152.1 — A REPAIR IS NOT COMPLETE BECAUSE THE SYMPTOM DISAPPEARED.** **[NORMATIVE]**
> **Every repair generates: `repair → new state → new observations → verification`.** The verification step is
> mandatory and is performed by an instrument that is not the repairer (`SO-R164.2`).
> **`SO-R152.2`: a repair that produces no new observations is `UNVERIFIED`, and an unverified repair consumes
> `P0-05 R0.1`'s unverified-displacement budget exactly as an unverified learned change does (§205).**
> **⟹ This is the single most important cross-contract rule in Volume B: it makes repair a LEARNING-CLASS change for
> accounting purposes without making it a learning pathway. §205 states the boundary precisely.**

## 5.3 Rollback, recovery, degradation, and freeze machines

### **SM-09 — Rollback** *(mandatory)* — writer: **K**
```
   TARGET-IDENTIFIED (hash + epoch, NEVER position) ──authorized──▶ AUTHORIZED ──▶ EXECUTED
        ──▶ POST-VERIFIED ──┬─ verified ─▶ **COMPLETE**
                            └─ regression ─▶ **ROLLED-FORWARD-CANDIDATE** ─▶ [RO-13]
   WHAT ROLLBACK DOES NOT DO: restore a population (P0-07 HOM-INV-37) · delete the record that it happened
   (principle 23) · discharge UDB (P0-07 HOM-INV-23) · undo a retirement (P0-07 A138).
```

### **SM-10 — RecoveryPlan** *(mandatory)* — writer: **`[RO-13]` (declaration) / K (execution) / a non-recoverer (verification)**
```
   **DECLARED-IN-ADVANCE** ──trigger condition met──▶ TRIGGERED ──▶ EXECUTING
        ──▶ VERIFIED-BY-NON-RECOVERER ──┬─ pass ─▶ **COMPLETE**
                                        └─ fail ─▶ ESCALATED ─▶ [RO-13] / OP
   A plan that was not DECLARED-IN-ADVANCE cannot be TRIGGERED. There is no improvisation state.
```
> ### **SO-R164.1 — THE COMPONENT RESPONSIBLE FOR RECOVERY MAY NOT BE ASSUMED HEALTHY.** **[NORMATIVE]**
> **§164's requirement, for six degraded subsystems:**
> | Degraded subsystem | Recovery route | **Why the obvious route fails** |
> |---|---|---|
> | **self-model** | **K re-derives scope state from anchored records**, not from `OBJ-18` | a degraded self-model reports itself as healthy (`P0-05 R42.5`'s instrument-defect finding) |
> | **communication** | **`P0-03`'s absence detectors + `OBJ-03`'s `DETECTOR-ABSENT` gap class** | a comm failure looks like silence, and silence has eight causes (§135) |
> | **memory** | **`P0-04`'s Merkle root + epoch restoration** | a corrupted memory can serve consistent-but-wrong records (`P0-04 SP-5`/`OR-M9`) |
> | **immune subsystem** | **the EIK Integrity Auditor (`OBJ-10`)**, which is not part of the immune subsystem | `Cell §18.5(v)`: the immune system MUST NOT monitor itself |
> | **verifier** | **a second verifier of a different `IND-4` model class, or EVA** | a degraded verifier passes what it should fail |
> | **workspace** | **K's slot ledger**, which is outside the workspace | a workspace that cannot broadcast cannot report that it cannot broadcast |
> **⟹ `SO-R164.2 — THE NON-RECOVERER RULE: every recovery and every repair is verified by an instrument that is not
> the recovering or repairing component, and whose own health is attested by a different route.** This is `P0-02
> IND-8`'s form (*the thing being checked and the thing checking it are the same*) applied to recovery, and it is the
> rule that makes §164 answerable rather than aspirational.**
> **`[OPEN: OR-S4]` — the non-recoverer rule terminates at K and at EVA. When K is the recoverer, no non-recoverer
> exists inside the architecture, and verification is external or absent. This is `P0-07 OR-H1` in its fourth
> appearance.**

### **SM-11 — DegradationState, per critical function** *(mandatory)* — writer: **K (state) / `[RO-13]` (policy)**
```
   CONTINUE ─▶ DEGRADE ─▶ ISOLATE ─▶ FREEZE ─▶ ESCALATE ─▶ **RETIRE**
   the policy mapping function → permitted transitions is DECLARED BY [RO-13] IN ADVANCE (§160's per-function table).
   A function whose policy is DEGRADE-only may not transition to RETIRE without [RO-13].
```
> ### **SO-R159.3 — DEGRADED OPERATION MUST NOT SILENTLY CHANGE GOVERNANCE SEMANTICS.** **[NORMATIVE]**
> **Six degradations are permitted (reduced capability · verification · bandwidth · memory · population · redundancy)
> and each is a declared service-level reduction. What degradation MAY NOT do:**
> **(a)** alter a setpoint, band, gate, threshold, or objective — all `[G]` (`P0-07 HOM-INV-10`);
> **(b)** widen an authority — degradation is restrictive-only (`P0-07 HOM-INV-09`);
> **(c)** reclassify a coverage gap as `NO-GAP` because the observer is degraded — **the opposite: a degraded observer
>     produces `DETECTOR-ABSENT`, which is read restrictively (`SO-INV-01`)**;
> **(d)** treat a reduced verification capacity as a satisfied verification — **`P0-07`'s B9 rule: verification is a
>     floor, and a floor reduced is a floor breached, which is reportable**;
> **(e)** change the meaning of any state in any machine in this contract.
> **⟹ `[TEST: grep check — no degradation transition appears in any authority, setpoint, or gate table]`**
>
> ### **SO-R160.1 — FAIL-SAFE VS FAIL-OPERATIONAL IS A PER-FUNCTION POLICY, NOT A GLOBAL ONE.** **[NORMATIVE]**
> **§160's six responses — continue · degrade · isolate · freeze · escalate · retire — are assigned per critical
> function by `[RO-13]` in advance. The assignment table is a governance object.**
> **The default, where no policy is declared, is `ISOLATE` then `ESCALATE` — never `CONTINUE`.**
> **⟹ `[DERIVATION]` `SO-INV-02` again: an undeclared policy read permissively would make every unspecified function
> fail-operational, and the set of unspecified functions is exactly the set nobody thought about.**

### **SM-12 — FreezeOrder** *(mandatory)* — writer: **EIK (below cap) / OP (at or above cap)**
```
   TRIGGERED ──authority check──▶ ISSUED ──▶ ACTIVE (max-dwell, NOT wall-clock expiry)
        ──┬─ release by a STRICTLY HIGHER authority ─▶ **RELEASED**
          └─ max-dwell exceeded without release ─▶ **ESCALATED** ─▶ OP (never auto-released)
   A freeze NEVER auto-expires into normal operation.
```
> ### **SO-R161.3 — THE RELEASE AUTHORITY IS STRICTLY HIGHER THAN THE TRIGGER AUTHORITY.** **[NORMATIVE]**
> | Trigger authority | Release authority |
> |---|---|
> | a cell self-suspends (a restrictive self-act, always permitted — `Cell R15.1`, `P0-07 §76`) | **K** |
> | **K** issues a scope freeze | **EIK** |
> | **EIK** issues a freeze | **`[RO-13]`** |
> | **`[RO-13]`** issues a freeze | **OP** |
> | at or above `Cell §17`'s cap | **OP issues AND OP releases** |
> **⟹ `SO-R161.5`: A FREEZE IS NEVER SELF-RELEASING AND NEVER PEER-RELEASING.** This is what defeats §162's repeated
> freeze denial-of-service: an attacker that can trigger a freeze cannot release it, and each escalation moves the
> decision to a body with fewer members and more evidence requirements.

## 5.4 Self-model, capability, limitation, metacognition, abstention machines

### **SM-13 — SelfModelState** *(mandatory)* — writer: **K (versioning) — NEVER the subject, NEVER the modeled process**
```
   OBSERVED ──K versions it on an external observation or verdict──▶ VERSIONED ──superseded──▶ **SUPERSEDED**
   NO self-update transition exists. NO transition is caused by the process the model describes.
   Λ2 is fixed (P0-05 R59.1). There is no Λ3-of-observation state inside the organism (§168).
```
### **SM-14 — CapabilityRecord** *(mandatory)* — writer: **the subject (claim) / K (status) / EVA (confirmation)**
```
   CLAIMED ──an evidence reference is attached──▶ EVIDENCED ──┬─ EVA confirms ─▶ EXTERNALLY-CONFIRMED
                                                              ├─ EVA refutes ─▶ **EXTERNALLY-REFUTED**
                                                              └─ freshness exceeded ─▶ **STALE**
   STALE and EXTERNALLY-REFUTED are both restrictive: neither may satisfy a gate (P0-07 HOM-R24.2).
   A CLAIMED record may never satisfy a gate. Self-report is not verification (principle 7).
```
### **SM-15 — LimitationRecord** *(mandatory)* — writer: **the subject**
```
   DECLARED ──scoped──▶ SCOPED ──┬─ external evidence shows the limitation is absent ─▶ RESOLVED
                                 └─ declared permanent by [RO-13] ─▶ **PERMANENT**
   declaring a limitation is a RESTRICTIVE SELF-ACT and is therefore always permitted and never penalized (§184).
```
### **SM-16 — MetacognitiveRecord** *(mandatory)* — writer: **the subject (forecast) / K (error computation) / EVA (calibration)**
```
   FORECAST ──outcome observed──▶ OUTCOME ──K computes the error──▶ ERROR-COMPUTED
        ──update rule applied (declared, not learned ad hoc)──▶ UPDATE-APPLIED
        ──external calibration──▶ **EXTERNALLY-CALIBRATED**
   NO SELF-CALIBRATED terminal state exists.                    [SO-R179.3]
```
> ### **SO-R179.3 — CALIBRATION MUST NOT BECOME A SELF-REWARD SIGNAL.** **[NORMATIVE]**
> **Three prohibitions:** **(a)** the error term may not enter any budget, allocation, or gate as a *positive* input;
> **(b)** a component may not update its own calibration statistic — K computes the error and EVA calibrates;
> **(c)** a calibration improvement may not raise a `CapabilityRecord`'s status (that requires EVA).
> **⟹ `[DERIVATION]` A self-reward signal here would close the loop `forecast → outcome → error → self-praise →
> better forecast`, in which the only evidence is the forecast's own accuracy at forecasting. `P0-05 R9`'s signal
> admission rules and `SG-9` (*calibration deviation ⟹ epistemic/calibration head only*) are the inherited defence;
> this rule states it for the metacognitive layer.**
>
> ### **SO-R179.4 — CALIBRATION WITHOUT INVENTED VALUES.** **[NORMATIVE]**
> **Defined: `forecast` (a declared expectation with a scope and a horizon class) · `outcome` (an observation or EVA
> verdict) · `error` (K-computed, in the forecast's own declared units) · `update` (a declared rule, `[G]`) ·
> `external calibration` (EVA or `[RO-13]`).**
> **NOT defined, and deliberately so: any numeric error threshold, any calibration coefficient, any confidence
> increment. `[OPEN: OR-S5]` — all are `[U]`, owned by `[RO-13]`/EVA. Inventing them would violate the standing
> no-invented-parameters rule and would create a false-precision claim about metacognitive accuracy.**

### **SM-17 — AbstentionRecord** *(mandatory)* — writer: **the subject**
```
   ABSTAINED (reason class) ──bounded dwell──▶ ┬─ recovery condition met ─▶ RESUMED
                                              └─ dwell exceeded without recovery ─▶ **ESCALATED** ─▶ [RO-13]
   reason classes (CLOSED SET): INSUFFICIENT-EVIDENCE | UNRESOLVED-CONTRADICTION | OOD-STATE | INADEQUATE-CAPABILITY
       | DEGRADED-VERIFIER | STALE-SELF-MODEL | FAULT-STATE | INSUFFICIENT-RESOURCES
   NO auto-resume on dwell expiry. An abstention that never recovers is a reportable condition, not a stable state.
```
> ### **SO-R181.3 — ABSTENTION IS NOT PROOF THAT A CLAIM IS FALSE.** **[NORMATIVE]**
> **An abstention reduces the abstainer's output; it says nothing about the world. No consumer may treat an abstention
> as evidence against the abstained proposition, and no `P0-04` status may be lowered because of one.**
> ### **SO-R182.1 — THE ABSTENTION CASCADE IS BOUNDED BY A RECOVERY CONDITION, NOT BY A THRESHOLD.** **[NORMATIVE]**
> **§182's loop: uncertainty → abstention → less action/data → less evidence → more uncertainty.**
> **Three bounds, none numeric:** **(a)** every `OBJ-22` carries a **recovery condition** — a declared observation or
> verdict that would end the abstention. **An abstention with no recovery condition is a schema violation**, because it
> is unfalsifiable and therefore permanent; **(b)** dwell expiry **escalates to `[RO-13]`**, which can supply evidence
> the component cannot (a probe, a resource grant, a scope change); **(c)** **`P0-05 R0.1`'s stall semantics apply**:
> an abstention that prevents verification consumes unverified-displacement budget, so a scope that abstains its way
> out of verification eventually **stalls** — visibly, and by construction.
> **⟹ `[DERIVATION]` `P0-05 R48.2`'s principle transfers exactly: *"the architecture needs no collapse detector; it
> needs the stall, which it has."* The abstention cascade needs no cascade detector either — it needs the escalation
> and the stall.**
> **`P0-04`'s concern (excessive doubt as a positive feedback loop) is thereby bounded but NOT closed: a scope can be
> permanently escalated, which is a governance cost. `[OPEN: OR-S6]`**

## 5.5 Attention, workspace, detector, and observer-set machines

### **SM-18 — AttentionAllocation** *(mandatory)* — writer: **K**
```
   REQUESTED ──K allocates from the compute dimension, charged to B13 where it funds observation──▶ ALLOCATED
        ──▶ CONSUMED ──window close──▶ RETURNED(unspent)
   NO self-allocation. NO allocation driven by a confidence value, a capability claim, or a workspace request.
```
### **SM-19 — WorkspaceSlot** *(mandatory)* — writer: **K (arbiter)**
```
   CONTENDED ──K arbitrates on a [RO-13]-declared rule──▶ BROADCAST ──▶ RELEASED
   the arbiter is SINGLE-WRITER (K). A slot is a RESOURCE. Winning one is not evidence and not authority.
```
> ### **SO-R222.2 — WINNING A WORKSPACE SLOT IS NOT EVIDENCE.** **[NORMATIVE]**
> **A broadcast's warrant comes from `P0-03`'s rules (`root_commit`, `causal_depth`, `calib_ref`, `corr_class`) and its
> epistemic status from `P0-04`'s. **Broadcast reach is neither.** `[DEPENDENCY: P0-03 RULE 7.7 — *authenticity ≠
> truth*; COMM-INV-01.]**
> **⟹ `SO-R222.3 — THE RULING THAT WOULD REVERSE `P0-07 §94`'S MERGE CONDITION, STATED SO IT CAN BE TESTED: if the
> workspace arbiter is ever given authority to ACT on what it selects — rather than only to route it — then it is not a
> comm object and not a P0-08 object; it is a governance body, and it must become a row in `P0-07 §76`'s matrix. As
> specified here the arbiter routes only, so the merge holds.**

### **SM-20 — DetectorIntegrity** *(mandatory)* — writer: **`[RO-13]` (identity, threshold, budget) / the EIK Integrity Auditor (correlation verdict)**
```
   TRUSTED ──false-positive budget exceeded──▶ RECALIBRATED | **DISABLED**      [Cell §18.5(ii)]
        ──the Integrity Auditor finds quarantine decisions do NOT correlate with actual failures──▶
             **AUDIT-FINDING** ─▶ [RO-13] / OP                                  [Cell §18.5(v)]
        ──cascade detection on the DERIVATIVE of quarantine or repair rate──▶ system-wide immune dampening
             + operator escalation                                              [Cell §18.5(iii); P0-07 HOM-R21.2]
   A DISABLED detector produces DETECTOR-ABSENT in SM-02 — it does NOT produce NO-GAP.  [SO-INV-01]
```
### **SM-21 — ObserverSet / effective evidence source count** *(mandatory)* — writer: **K**
```
   DECLARED (members + each member's OBJ-25 independence claim) ──K collapses on the dimensions the claim
        depends on──▶ EFFECTIVE-SOURCE-COUNT COMPUTED ──membership or correlation class changes──▶ RE-EVALUATED
   the count is an INTEGER ≤ the member count. Three correlated observers yield 1.        [SO-R126.3]
```

> ### **SO-C5.2 — MACHINE TALLY.** **[DERIVATION]**
> **21 machines: SM-01…SM-21. All 21 are mandatory for conformance C1. 1 is ⟦INHERITED⟧ verbatim (SM-06).**
> **Structural properties worth stating because they are the machines' actual content:**
> **(a) NO MACHINE HAS A SELF-UPDATE TRANSITION.** SM-13 is the explicit case; SM-04, SM-08, SM-14, SM-16 all place
>     status transitions with K or EVA, never with the subject.
> **(b) FIVE MACHINES HAVE A TERMINAL STATE THAT IS A *REPORT* RATHER THAN A RESOLUTION:** SM-02's
>     `SUPPRESSION-SUSPECTED`, SM-03's `RECORDED-UNCONFIRMED`, SM-08's `UNCERTAIN-RETAINED`, SM-17's `ESCALATED`,
>     SM-20's `AUDIT-FINDING`. **⟹ This is deliberate: an architecture that resolves every uncertainty internally has
>     no need for an external evaluator, and this architecture has one.**
> **(c) THREE MACHINES ENFORCE `SO-INV-01` BY ABSENCE OF AN EDGE:** SM-01 (`UNOBSERVED → HEALTHY` does not exist),
>     SM-02 (every non-`NO-GAP` state forces restrictive reading), SM-20 (a disabled detector yields
>     `DETECTOR-ABSENT`, never `NO-GAP`).
> **(d) NO MACHINE HAS AN AGE-KEYED TRANSITION** (`P0-07 HOM-INV-20` inherited) **and none uses a vector clock**
> (`P0-03 RULE 5.4` inherited).

---

# §142 — GLOBAL STATE CONSISTENCY

> ### **SO-R142.1 — THERE IS NO CURRENT GLOBAL STATE, AND THE SCHEMA SAYS SO.** **[NORMATIVE]**
> **Six mandatory representations, per `SO-R138.2`'s prohibition on a complete organism-wide model:**
> | Representation | Meaning | Field |
> |---|---|---|
> | **local state** | the subject's own state, as it holds it | `OBJ-18` at `granularity = CELL`, `locality_class` marked |
> | **last-known state** | the most recent state of another scope that this subject holds | `last_known` + `observed_at` |
> | **observed-at time** | a **monotone per-envelope** timestamp, never a global clock | `OBJ-01.observed_at` (`P0-07 HP-2`) |
> | **freshness** | `FRESH / AGING / STALE / INVALID`, derived by **K** from age × the subject's mutation rate | `OBJ-01.freshness_class` |
> | **confidence** | a **`P0-04` calibration reference**, never a locally invented scalar | `OBJ-01.confidence_ref` |
> | **conflict** | an explicit state, not an error to be resolved | `OBJ-18.contradiction_refs[]`, **carried not resolved** |
>
> ### **SO-R142.2 — STALE GLOBAL STATE MUST NOT BE REPRESENTED AS CURRENT TRUTH.** **[NORMATIVE]**
> **Three enforcement points:** **(a)** every consumer of another scope's state reads `freshness_class` and
> `coverage_ref` **in the same read** — a read that omits either is a schema violation; **(b)** `INVALID` observations
> are unreadable as state, not merely unreliable; **(c)** **`P0-07 HOM-R6.6`'s staleness-conservatism is inherited:
> under staleness, default to the MORE RESTRICTIVE branch.**
> **⟹ `[DEPENDENCY: P0-03's standing prohibition — *"DO NOT require perfect global sync; not every comm event globally
> visible"*; P0-04's rule that contradictions are carried, not forced to resolution.]**
>
> ### **SO-R142.3 — THE CONSISTENCY MODEL, NAMED SO IT CANNOT BE MISREAD.** **[DEFINITION]**
> **This architecture is NOT eventually consistent. It is ANCHOR-CONSISTENT: every state is consistent with the most
> recent externally anchored observation of it, and the anchor's identity and age are part of the state.**
> **⟹ `[DERIVATION]` §215 forbids "eventual consistency" as a complete answer, and rightly: eventual consistency
> promises convergence without naming a witness. Anchor-consistency names the witness (the anchor), its age
> (`observed_at`), and its authority (EVA or K), and it makes no promise about convergence. `P0-05 R0.1`'s
> `θ_anchor(S)` is the same object in the learning domain.**

---

# §143 — TEMPORAL SEMANTICS

> ### **SO-R143.1 — THE THREE TEMPORAL PRIMITIVES, AND THE PROHIBITED FOURTH.** **[NORMATIVE]**
> | Primitive | Type | Ground |
> |---|---|---|
> | **`observed_at`** | monotone per-envelope timestamp | `P0-07 HP-2`; **not a global clock, not wall-clock-agreed** |
> | **`causal_depth`** | **`u8`, a monotone derivation counter** | **`P0-03` field 8, inherited verbatim: *"Replaces the vector clock"*** |
> | **`root_commit`** | an anchored root reference | `P0-03` S2 field |
> | ~~vector clock~~ | ~~Θ(N) bytes~~ | **PROHIBITED. `P0-03 RULE 5.4`: *"Lamport clocks, vector clocks, and hybrid logical clocks MUST NOT be used … a type error, not a compression problem."* §143's instruction not to reintroduce them is discharged by adoption, not by restatement** |
>
> ### **SO-R143.2 — TEMPORAL SEMANTICS FOR THE ELEVEN REQUIRED ITEMS.** **[NORMATIVE]**
> | Item | Temporal semantics | Ordering guarantee |
> |---|---|---|
> | **observation** | instantaneous at `observed_at`; valid for a `freshness_class` window | none beyond `causal_depth` |
> | **event** | a `P0-03` canonical event; `seq`/`ts` order is **NOT** causal order (`COMM-INV-15`) | causal relation \| concurrency \| **unknown** — all three representable (§218) |
> | **fault** | an occurrence at `observed_at`; its **detection time ≠ its onset time**, and both are recorded when known | onset may be unbounded-earlier; **`[OPEN: OR-S7]` onset inference is not available internally** |
> | **diagnosis** | a status at a time; **statuses are monotone within an incident** and never regress except to `REJECTED` | `ANOMALY-OBSERVED` precedes every promotion |
> | **quarantine** | entry time + max dwell + exit time; **dwell is bounded by an interval count, not a wall clock** (`Cell §18.2`) | entry precedes exit; neither is ordered against unrelated scopes |
> | **repair** | `applied_at` + `effect_observed_at` + `verified_at` — **three distinct times** | **`applied_at` precedes `effect_observed_at`; the gap is the effect window and is part of the record** |
> | **rollback** | `target_epoch` + `executed_at`; **the target epoch is always < `executed_at`** | **`SO-R220.1` below** |
> | **recovery** | `triggered_at` + `complete_at` + verification time | recovery **follows** the fault it recovers from (§220) |
> | **self-model update** | `version` + `observed_at`; **updates are caused by external observations, so `updated_at ≥ observed_at`** | a self-model version never precedes the observation that produced it |
> | **metacognitive update** | `forecast_at` + `outcome_at` + `error_computed_at` — **strictly ordered** | **a forecast recorded after its outcome is a schema violation** (§179's integrity depends on it) |
> | **attention** | per-window allocation; **no cross-window ordering claim** | windows are ordered; allocations within a window are not |
>
> ### **SO-R143.3 — CAUSAL INFERENCE IS NOT PERFORMED HERE.** **[NORMATIVE]**
> **`P0-03 RULE 5.10`, adopted verbatim: *"Causal inference belongs to the EVALUATOR, off-line, from anchored
> records."* P0-08's contribution is exactly `P0-03`'s: `causal_depth` + `root_commit`, and the four-status diagnosis
> ladder. It computes no causes.**
> **⟹ `SO-R148.1 — CORRELATION ≠ CAUSATION, ENFORCED AT THE SCHEMA LEVEL.** `OBJ-06`'s `status` may not be promoted by
> a correlation, a precedence, a repetition, or a confidence value (`SO-R149.2`'s exclusion column). **`OBJ-08`'s
> relation classes include `TEMPORALLY-ADJACENT` precisely so that adjacency has a name that is not `CAUSED`.**
> `[DEPENDENCY: P0-05 R13.3; P0-04 epistemic rules; P0-03 RULE 5.9]`

---

# §144 — TIME-OF-CHECK / TIME-OF-USE

> ### **SO-R144.1 — THE ATTACK, AND THE FIVE REQUIREMENTS §144 ASKS FOR.** **[NORMATIVE]**
> **Attack: observe a safe state → the state changes → authorize an act on the stale observation.**
> | Requirement | P0-08's ruling | Note |
> |---|---|---|
> | **freshness** | ✅ **required.** Every authorization-consuming read carries `freshness_class`; `STALE`/`INVALID` may not authorize | `OBJ-01`, `SM-01` |
> | **revalidation** | ✅ **required.** The authorizing body re-reads at authorization time; **the observation that motivated the act and the observation that authorizes it are two reads** | `SO-R144.2` |
> | **atomicity** | ⚠️ **only where the writer is single.** For K-written objects, check-and-act is atomic because K is the only writer. **For multi-writer objects there is no atomicity and `SO-R215.2`'s conflict semantics apply instead** | §214, §215 |
> | **external witness** | ✅ **required at or above `Cell §17`'s cap**, and for every OP-level act | `P0-02 W5`'s outside witness, inherited |
> | **epoch matching** | ✅ **required.** An observation is valid for an authorization only within the same epoch | **`P0-02`'s epoch-binding invariant (`EIK-INV-14`), inherited** |
> **NO NUMERICAL FRESHNESS THRESHOLD IS INVENTED.** Freshness is a **class** derived by K from age × the subject's
> mutation rate; the derivation's parameters are `[G]` and `[U]`. `[OPEN: OR-S8]`
>
> ### **SO-R144.2 — THE TWO-READ RULE.** **[NORMATIVE]**
> **An authorization requires two distinct reads: the MOTIVATING read (which may be old, and whose staleness is
> recorded) and the AUTHORIZING read (which must be `FRESH` at authorization time and in the same epoch).**
> **⟹ `[DERIVATION]` Collapsing them is the TOCTOU defect: one read serves as both evidence and precondition, so the
> precondition is only as current as the evidence, and evidence is routinely old. Two reads cost one extra observation
> (charged to B13) and make the gap explicit and auditable.**

---

# §145 — STALE AUTHORITY

> ### **SO-R145.1 — AN OBSERVATION GRANTS NO CONTINUING AUTHORITY.** **[NORMATIVE]**
> **Four rules, each closing a route:**
> **(a)** an observation is a **record about a past state**, not a **grant about a future act**. No field of `OBJ-01`
>     is an authority field, and no consumer may derive one.
> **(b)** **authority is epoch-bound.** `P0-02`'s epoch-binding semantics are inherited: an authorization issued in
>     epoch *e* is not valid in epoch *e+1*, and an observation from epoch *e* cannot revalidate it.
> **(c)** **material change invalidates.** Where the observed state has materially changed — where "materially" is
>     declared per authorization class by `[RO-13]`, not computed — the authorization lapses and must be re-issued.
>     `[OPEN: OR-S9]` the materiality relation is a governance declaration.
> **(d)** **`SO-R145.2 — AN OBSERVATION MAY NOT BE CITED AS ITS OWN FRESHNESS WARRANT.** A record asserting "I observed
>     that I am authorized" is a self-report, and self-report is not verification (principle 7).**
> **⟹ `[DEPENDENCY: P0-02's authorization semantics; P0-07 HOM-R24.2 — `Ê(·)` excluded from every gate.]**

---

# §172–§175 — IDENTITY, CLONING, REPLAY, AND CAPABILITY TRANSFER

> ### **SO-R172.1 — "I AM X" MUST NOT CREATE "I POSSESS X'S AUTHORITY."** **[NORMATIVE]**
> **Identity and authority are separate objects with separate writers:**
> | | Identity | Authority |
> |---|---|---|
> | **Writer** | **K** (issues at `T01`; `P0-06 R8.3(c)` no-id-reuse) | **`P0-02`'s EIK / `[RO-13]` / OP** |
> | **Object** | `observer_id`, `subject_ref`, `lineage_id` | `P0-07 §76`'s matrix cells |
> | **Self-declarable?** | ❌ | ❌ |
> | **Transferable?** | ❌ identity-bound | ❌ never (§175) |
> **⟹ `SO-R172.2`: a self-model's identity fields are **references to K-issued identities**, never assertions. A
> `SelfModelState` whose `subject_ref` is not a K-issued identity is invalid. `[DEPENDENCY: P0-01's cell/organism
> identity; P0-02's authorization; P0-07 A118's closure — `lineage_id` is K-issued.]**
> **`[DERIVATION]` This closes §171's identity-substitution and privilege-escalation attacks at the schema level: the
> substitution would have to occur in a K-issued object, which the subject cannot write.**
>
> ### **SO-R173.1 — SELF-MODEL CLONING: THE FOUR PROPERTY CLASSES.** **[NORMATIVE]**
> **Attack: a trusted self-model is copied, and a new organism claims the same state and authority.**
> | Class | Properties | On copy |
> |---|---|---|
> | **TRANSFERABLE** | the model's **schema**, its granularity class, its compression class, its declared update rule | ✅ copied freely — these are types, not facts |
> | **NON-TRANSFERABLE** | every **status** (`EXTERNALLY-CONFIRMED`, `CAUSE-VERIFIED`, `VERIFIED-EFFECT`), every calibration, every `UDB` position, every `inbreeding_F` | ❌ **a copy starts at `CLAIMED` / `ANOMALY-OBSERVED` / zero-verified** |
> | **IDENTITY-BOUND** | `subject_ref`, `observer_id`, `lineage_id`, `scope_ref` | ❌ **re-issued by K, never copied** |
> | **PROVENANCE-BOUND** | `root_commit`, `causal_depth`, `corr_class`, `evidence_refs[]` | ❌ **a copy's provenance is the copy event, not the original's** |
> **⟹ `SO-R173.2`: A CLONED SELF-MODEL IS A NEW CLAIM WITH NO EVIDENCE.** It must re-earn every status through the same
> machines (SM-14, SM-16, SM-04). **This is `P0-07 HOM-INV-17`'s principle in the epistemic domain: `Ne(clones) = 1`
> because clones are one genome; here, `effective_evidence(clones) = 1` because clones are one source (`SO-R126.3`).**
> `[DEPENDENCY: P0-07 HOM-INV-17; P0-03 R14.2; P0-02 IND-3 lineage]`
>
> ### **SO-R174.1 — SELF-MODEL REPLAY REQUIRES TEMPORAL VALIDITY.** **[NORMATIVE]**
> **Attack: an old healthy self-model is replayed after degradation, and the system believes it is healthy.**
> **Four defences, in order of strength:**
> **(1) EPOCH BINDING.** A `SelfModelState` carries its epoch; a state from a prior epoch is `INVALID`
>     (`SO-R144.1`'s epoch matching). **[writer: K — the subject cannot forge an epoch]**
> **(2) MONOTONE VERSIONING.** `SM-13` versions are monotone and K-issued; a version lower than the current one is
>     rejected. **A replay is detectable as a version regression.**
> **(3) `SO-INV-02`'S FAIL-SAFE DEFAULT.** An unverifiable version is treated as ABSENT ⟹ `UNMEASURED` ⟹ restrictive.
>     **A successful replay would have to survive all three, and (1) and (2) are both K-written.**
> **(4) CROSS-CHECK AGAINST A K-HELD RECORD.** *(An earlier draft of this clause read "an independent observation" —
> an unqualified independence claim, and therefore a violation of `SO-R127.1` by the contract's own rule. Corrected: the
> defence is that the records are K-HELD, which is a writer property, not an independence property. §231 records the
> finding.)* K holds the coverage record and the fault history; a
>     self-model claiming `HEALTHY` while `OBJ-03` shows `DETECTOR-ABSENT` or `OBJ-04` shows open occurrences is a
>     **contradiction, carried not resolved** (`SO-R142.1`), and contradictions are reportable.
> **⟹ `[DERIVATION]` Defence (4) is the one that matters and it is the cheapest: the replay attack requires the
> self-model to be believed *in isolation*, and this architecture never reads a self-model in isolation — every
> health-consuming read also reads coverage (§137) and fault state (§146). A lie that must be consistent with three
> K-held records is a much harder lie.**
>
> ### **SO-R175.1 — CAPABILITY EVIDENCE IS NOT TRANSFERABLE BETWEEN SUBJECTS.** **[NORMATIVE]**
> **§175's five transfer questions, answered:**
> | From → to | Permitted? | Rule |
> |---|---|---|
> | **cell → cell** | ❌ | identities are K-issued and distinct; `P0-06 R3.15` (calibration class does not transfer **even within a lifetime**) |
> | **circuit → member cell** | ❌ | an aggregate's capability is not a member's. **§176's rule: collective claims may not become individual facts** |
> | **region → circuit** | ❌ | as above |
> | **organism → population** | ❌ | `P0-07 HOM-INV-24`: no cross-generation or cross-scope authority; a population statistic is not an individual fact |
> | **hardware class → hardware class** | ⚠️ **only for a `[RO-13]`-declared equivalence class** | **`Cell §17.4`'s identity-preservation conditions are the model: a change of hardware is a change of `hardware_class` digest, which is `P0-03` dim 5 / `P0-02 IND-5`, and it invalidates hardware-dependent capability claims** |
> | **ancestor → descendant** | ❌ | **`P0-07 HOM-INV-24` and `HOM-INV-34`: capability evidence is not inheritable, and `Cell R4.5` rejects it in a diff** |
> **⟹ `SO-R175.2 — THE ONE PERMITTED TRANSFER, AND WHY IT IS NOT A TRANSFER.** A `reaction_norm` (a *reachable*
> capability set) is inherited per `P0-06`/`P0-07`. **That is a statement about what is REACHABLE, not about what is
> HELD (`P0-07 OR-H21`), and it is why the table's ancestor row is ❌ for capability *evidence* while the genome's
> `reaction_norm` remains inheritable. Conflating the two is exactly the unjustified capability inheritance §175 asks
> to prevent.**

---

# §210 — THE FINAL OBJECT INVENTORY

> ### **SO-R210.1 — ALL 28 P0-08 OBJECTS, WITH EVERY ATTRIBUTE §210 REQUIRES.** **[NORMATIVE]**
> **No important object has an ambiguous owner: every cell below is filled, and a blank would be a conformance failure
> at level C0. Abbreviations: **obs** = the observing/detecting component · **subj** = the subject component ·
> **⟦c⟧** = consumed from contract *c*, not created here. *Timescale classes per `SO-R213.1`.*

| ID / name | **Owner** | **Writer** | **Readers** | **Authority over it** | **Mutability** | **Provenance** | **Timescale** | **Storage** | **Communication** | **Verification** | **Failure behaviour** |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **OBJ-01 Observation** | this contract | **obs** (content) | K, EIK, EVA, `[RO-13]` | `[RO-13]` (scope) | **append-only**; `freshness_class` is K-derived | `P0-03` `root_commit`+`causal_depth`+`corr_class` ⟦c⟧ | event | ⟦`P0-04`⟧ record class | ⟦`P0-03`⟧ S1/S2 | `OBJ-03` coverage | absent/stale ⟹ `UNMEASURED` ⟹ restrictive (`SO-INV-01`) |
| **OBJ-02 ObservationScope** | `[RO-13]` | **`[RO-13]`** | all | `[RO-13]` | versioned; **an observer may not widen it** | governance record | external governance | ⟦`P0-04`⟧ | — | declared or not | **undeclared ⟹ nothing is observable in that scope** |
| **OBJ-03 CoverageRecord** | this contract | **K** | all health consumers | K | per scope-window; **append-only per window** | K-held, hash-chained ⟦`P0-07`⟧ | window | **off-substrate (`AS-03`)** | — | `SOMon-19`; `[RO-13]` audits | **corrupt ⟹ read as ZERO coverage (`SO-INV-02`)** |
| **OBJ-04 FaultOccurrence** | this contract | **obs** (a detector, `D-S02`) | K, EIK | K confirms | **append-only, never merged** | ⟦`P0-04`⟧ + `OBJ-28` | event | ⟦`P0-04`⟧ | ⟦`P0-03`⟧ S2/`ERROR` | `SM-03` two-detector confirmation | undetected ⟹ no record; **unreported ⟹ still recorded (`SO-INV-21`)** |
| **OBJ-05 Manifestation** | this contract | **obs** | K, EIK, diagnosis | K | append-only | ⟦`P0-04`⟧ | event | ⟦`P0-04`⟧ | ⟦`P0-03`⟧ S2 | `SM-03` | as OBJ-04 |
| **OBJ-06 Diagnosis** | this contract | **K** (status only) | EIK, `[RO-13]`, EVA | `SO-C9.2`'s promotion rules | **statuses monotone; `REJECTED` is a new status, not a reversion** | `evidence_refs[]` = references, never payloads | epoch | ⟦`P0-04`⟧ | — | `SOMon-26`; **non-diagnoser or EVA for `CAUSE-VERIFIED`** | unverifiable ⟹ stays at the lower status |
| **OBJ-07 Incident** | **EIK** | **EIK** | all | EIK | open→closed; **many concurrent, no total order** | ⟦`P0-04`⟧ + `OBJ-28` | epoch | ⟦`P0-04`⟧ | ⟦`P0-03`⟧ S2 | `SM-05`; non-repairer verification | **uncloseable ⟹ `VERIFYING`; oscillating ⟹ `ESCALATED`** |
| **OBJ-08 FaultLineageLink** | this contract | **K** | EVA (off-line) | K | append-only | relation class from a **closed set**; `CAUSE-VERIFIED-OF` only at that status | lifetime | ⟦`P0-04`⟧ | — | `SO-R147.1` | **no link ⟹ no lineage claim, and no inference either** |
| **OBJ-09 Detector** | `[RO-13]` | **`[RO-13]`** | K | `[RO-13]` | **threshold/θ/budget/identity immutable to the organism** | governance record | external governance | ⟦`P0-04`⟧ | — | `SOMon-5`, `SOMon-21` | **no threshold ⟹ not a detector ⟹ `DETECTOR-ABSENT`** |
| **OBJ-10 DetectorIntegrityRecord** | **the EIK Integrity Auditor** | **the Auditor** | `[RO-13]`, OP | `Cell §18.5(v)` | append-only | ⟦`P0-04`⟧ | epoch | **off-substrate** | — | **the Auditor has no auditor (`OR-H10`)** | absent ⟹ DETECTOR-UNTRUSTED (`SO-INV-02`) |
| **OBJ-11 QuarantineState** | **EIK** | **EIK** | all | EIK | **reversible** (EIK clears) | trigger reference only — **no blame, origin, or diagnosis field** | epoch | ⟦`P0-04`⟧ | ⟦`P0-03`⟧ S2 | `SM-06` ⟦inherited⟧ | **writes a coverage gap (`SO-INV-08`)** |
| **OBJ-12 RepairProposal** | this contract | **subj** (propose) / **K** (serialize) | K, EIK | K serializes · `[RO-13]` rules · EIK veto | **at most one accepted per ⟨scope, intervention class⟩** | ⟦`P0-04`⟧ | window | ⟦`P0-04`⟧ | — | `SM-07`; **no confidence arbitration** | conflict ⟹ `REJECTED`/`SUPERSEDED`, both recorded |
| **OBJ-13 RepairRecord** | this contract | **K** | EVA, `[RO-13]` | K | append-only; **`UNCERTAIN-RETAINED` is terminal** | intervention + effect + uncertainty + verification | epoch | ⟦`P0-04`⟧ | ⟦`P0-03`⟧ S2 | **a non-repairer** | `remaining_uncertainty = NULL` ⟹ **schema violation** |
| **OBJ-14 RollbackTarget** | this contract | **K** | EIK | K | immutable once identified | **hash + epoch, never position** | epoch | **off-substrate** ⟦`P0-07 EVO2`⟧ | — | non-rollbacker | unidentifiable ⟹ no rollback |
| **OBJ-15 RecoveryPlan** | **`[RO-13]`** | **`[RO-13]`** | K, EIK | `[RO-13]` | **DECLARED IN ADVANCE**; no improvisation state | ⟦`P0-04`⟧ | external governance | **off-substrate** | — | **a non-recoverer** | **undeclared ⟹ cannot be `TRIGGERED`**; **scope = new envelope ⟹ INVALID (`SO-INV-24`)** |
| **OBJ-16 DegradationState** | this contract | **K** (state) / `[RO-13]` (policy) | all | `[RO-13]` | per critical function | ⟦`P0-04`⟧ | epoch | ⟦`P0-04`⟧ | — | `SOMon-27` | **no declared policy ⟹ `ISOLATE` then `ESCALATE`, never `CONTINUE`** |
| **OBJ-17 FreezeOrder** | **EIK** / **OP** | **EIK** (below cap) / **OP** (at or above) | all | `SO-R161.3` | **nine mandatory fields**; never self- or peer-released | **immutable audit record, sealed** | epoch | **off-substrate** | ⟦`P0-03`⟧ S2 | `SOMon-11` | **dwell exceeded ⟹ `ESCALATED` to OP, never auto-released** |
| **OBJ-18 SelfModelState** | this contract | **subj** (content) / **K** (version, freshness, status, `compression_class`) | K, EVA | `P0-05 R59.1` | **`Λ2`, NOT self-updating**; versions monotone | carries `self_model_version`; **contradictions carried, not resolved** | developmental / lifetime | ⟦`P0-04`⟧ record class — **not a store** | — | `SOMon-3`, `SOMon-12` | stale ⟹ restrictive; **replayed ⟹ version regression, rejected** |
| **OBJ-19 CapabilityRecord** | this contract | **subj** (claim) / **K** (status) / **EVA** (confirm) | K, `[RO-13]`, EVA | **EVA** | `CLAIMED`→…→`EXTERNALLY-CONFIRMED` | evidence reference | lifetime | ⟦`P0-04`⟧ | — | **EVA only** | **`CLAIMED`/`STALE`/`REFUTED` satisfy no gate** |
| **OBJ-20 LimitationRecord** | this contract | **subj** | K, `[RO-13]` | — | **a restrictive self-act, always permitted** | ⟦`P0-04`⟧ | lifetime | ⟦`P0-04`⟧ | ⟦`P0-03`⟧ S1 | rate reported by difficulty class | never penalized at the P0-08 layer |
| **OBJ-21 MetacognitiveRecord** | this contract | **subj** (forecast) / **K** (error) / **EVA** (calibration) | K, EVA | **EVA** | three-level; **no self-calibrated terminal** | forecast_at < outcome_at < error_at | window | ⟦`P0-04`⟧ | — | `SOMon-12` | **a forecast recorded after its outcome ⟹ schema violation** |
| **OBJ-22 AbstentionRecord** | this contract | **subj** | K, EVA | `[RO-13]` | **reason class from a CLOSED set**; **recovery condition mandatory** | ⟦`P0-04`⟧ | window | ⟦`P0-04`⟧ | ⟦`P0-03`⟧ S1 | dwell monitoring | **dwell exceeded ⟹ `ESCALATED`, never auto-resumed** |
| **OBJ-23 AttentionAllocation** | **K** | **K** | subj | K | per window; **no self-allocation** | ledger line | window / step | **`P0-07`'s ledger** | — | `SM-18`; `SOMon-15` | **unaffordable ⟹ refused, and the refusal is recorded** |
| **OBJ-24 WorkspaceSlot** | **K** (arbiter) | **K** | all subscribers | `[RO-13]` (rule) | per window | **the broadcast IS a `P0-03` message** | step | **`P0-07`'s ledger** | ⟦`P0-03`⟧ broadcast class | `SM-19` | **arbiter degraded ⟹ K's slot ledger, outside the workspace** |
| **OBJ-25 IndependenceClaim** | this contract | **the claimant** | K, EVA | `P0-02 R35.1` | per claim | **names its `IND-` dimensions AND its claim-type** | event | ⟦`P0-04`⟧ | — | `SOMon-18` | **empty dimension set ⟹ schema violation; `IND-6` unassessable ⟹ must be declared `?`** |
| **OBJ-26 ObserverSet** | **K** | **K** | EVA, `[RO-13]` | K | recomputed on membership or `corr_class` change | derived from `OBJ-25` | window | **off-substrate** | — | `SM-21` | **uncomputable ⟹ `effective_sources = 1` (restrictive)** |
| **OBJ-27 B13ObservationBudget** | `[RO-13]` (size) / **K** (administers) | **K** | all | `[RO-13]`; **FW-6's floor** | per window; **non-fungible, last-cut, first-restored** | `P0-07`'s ledger | window | **`P0-07`'s ledger** | — | `SOMon-17` | **below a floor ⟹ an event to `[RO-13]`; exhausted ⟹ `DETECTOR-ABSENT`** |
| **OBJ-28 CanonicalEvent** | **`P0-03`** | **`P0-03`'s event layer** | all | `P0-03` | **append-only, `SEALED` terminal** | ⟦`P0-07 EVO4`⟧ hash chain | event | ⟦`P0-04`⟧ | ⟦`P0-03`⟧ | `SO-R216.1` | **a freeze with no event did not happen, and the absence is reportable** |

> ### **SO-R210.2 — THE INVENTORY'S THREE RESULTS.** **[DERIVATION]**
> **(a) NO AMBIGUOUS OWNER.** All 28 rows have a named owner and writer; 4 use a disjoint field-group split (`SO-C6.1`),
>     which is a *declared* multi-writer design with conflict semantics, not an ambiguity.
> **(b) STORAGE IS NEVER NEW.** Every row's storage column is either ⟦`P0-04`⟧, `P0-07`'s ledger, or "off-substrate
>     (`AS-03`)". **P0-08 creates no store — which is §209's search 2 discharged row by row rather than by assertion.**
> **(c) COMMUNICATION IS NEVER NEW.** Every row that communicates does so as a ⟦`P0-03`⟧ message of a declared tier.
>     **§209's search 6, discharged the same way.**
> **(d) THE FAILURE-BEHAVIOUR COLUMN IS THE ONE AN IMPLEMENTER WILL BE TEMPTED TO LEAVE EMPTY, AND EVERY ENTRY IN IT IS
>     RESTRICTIVE.** Absent ⟹ `UNMEASURED` · corrupt ⟹ zero coverage · unverifiable ⟹ lower status · undeclared ⟹ invalid
>     or restrictive-default · unaffordable ⟹ `DETECTOR-ABSENT`. **Not one of the 28 objects fails permissively. That
>     column, read as a whole, IS `SO-INV-02`.**

---

# §211 — THE GLOBAL WRITER INVENTORY

> ### **SO-R211.1 — EVERY STATE CLASS, ITS WRITER, AND WHETHER OTHER WRITERS ARE PROHIBITED.** **[NORMATIVE]**
> | Object class | **Writer** | Other writers prohibited? | Authority source | Verification |
> |---|---|---|---|---|
> | **governance** (rules, policies, setpoints, objectives) | **OP**, delegated to **`[RO-13]`** | ✅ **absolutely** | `P0-02`; OP is the apex | `P0-02`'s attestation chain; **`OR-13`: a captured OP is indistinguishable from a legitimate OP by any mechanism OP authorizes — UNSOLVABLE, preserved at §200** |
> | **genome** | **K**, on an EIK-authorized ticket | ✅ | `P0-07` `REP1`, `Cell R12.1` | 16 gates + `FORBIDDEN_BLOCKS` + hash chain |
> | **task** | **OP** | ✅ | `P0-01` | EVA |
> | **fitness / verdict** | **EVA (external)** | ✅ | `P0-01` | **`RH-2` BOUNDED (`P0-07 A82`), `OR-H5`** |
> | **memory epistemic status** | **`P0-04`'s rules, K-administered** | ✅ **no organism rewrite of historical evidence** | `P0-04` | Merkle root; **`SP-5`/`OR-M9`: differential serving within an epoch is bounded, not preventable** |
> | **provenance** | **K only** | ✅ | `P0-04`, `P0-07 EVO4` | hash chain, append-only, `SEALED` terminal |
> | **learning state** | **the component, budgeted**; **anchors by K/EVA** | ⚠️ **multi-writer by design** | `P0-05 R0.1`, `R9` | UDB accounting; **`SO-R215.2`'s conflict semantics apply** |
> | **developmental state** | **Σ1–Σ4 then the ORGANISM** (`P0-06`'s writer separation) | ⚠️ **staged** | `P0-06` | `DevStage` machine, Σ-tombstones |
> | **population state** | **K** | ✅ | `P0-07 HOM-R22.1` | 14 fields, hash-chained ledger |
> | **resource state** | **K** | ✅ | `P0-07`, `Cell §16.2` | independent metering (`Cell R16.1`); **`X-H2`/`HOM-INV-06`: the energy fallback is `DERIVED` on platforms without counters** |
> | **fault state** (`OBJ-04`, `OBJ-05`) | **the detecting observer** | ⚠️ **multi-writer by design — every observer may report** | this contract | **`OBJ-03` coverage + SM-03's two-detector confirmation** |
> | **fault classification** (`OBJ-06` status, `OBJ-07`) | **K (status) / EIK (incident)** | ✅ | this contract | SM-04's excluded-driver column |
> | **self-model** (`OBJ-18`) | **the subject writes content; K writes version, freshness, and status** | ⚠️ **split-writer, deliberately** | `P0-05 R59.1`, `P0-06 R8.13` | **SM-13 has no self-update transition; `SOMon-3`** |
> | **metacognitive state** (`OBJ-21`) | **the subject forecasts; K computes error; EVA calibrates** | ⚠️ **three-way split** | `SO-R179.3` | SM-16 has no self-calibrated terminal |
> | **attention state** (`OBJ-23`) | **K** | ✅ | `P0-07`'s ledger | SM-18; no self-allocation |
> | **workspace state** (`OBJ-24`) | **K (single-writer arbiter)** | ✅ | `SO-R222.2` | SM-19; a slot is a resource |
> **⟹ `SO-R211.2 — THE SPLIT-WRITER PATTERN IS P0-08'S MAIN STRUCTURAL DEVICE.** Four object classes (self-model,
> metacognitive, fault, diagnosis) are written by **two or three parties along different field groups**: the subject
> writes **content**, K writes **status/version/freshness**, EVA writes **confirmation/calibration**. **This is not
> multi-writer state in §215's sense — the field groups are disjoint, so no two writers ever write the same field.**
> **`SO-R214.2`: disjoint field groups are the *stronger* form of writer separation, because there is no conflict to
> serialize. It is `P0-06`'s Σ-separation and `P0-07`'s three-party selection, reapplied at field granularity.**

---

# §212 — THE AUTHORITY ROOT INVENTORY

> ### **SO-R212.1 — EVERY P0-08 OPERATION AND ITS ULTIMATE AUTHORITY ROOT.** **[NORMATIVE]**
> | Operation | Authority root |
> |---|---|
> | emit an observation | **the observer** (a self-act; always permitted, always charged to B13) |
> | declare an observation scope | **`[RO-13]`** |
> | compute coverage / freshness / gap class | **K** |
> | confirm a fault (second detector) | **K**, on `Cell §18.5(iv)`'s condition |
> | promote a diagnosis status | **K**; `CAUSE-VERIFIED` additionally requires **EVA** or a non-diagnoser instrument |
> | open / contain / close an incident | **EIK** |
> | quarantine | **EIK** |
> | propose a repair | **the component** (a proposal, not an act) |
> | serialize / arbitrate a repair conflict | **K** serializes · **`[RO-13]`** declares the rule · **EIK** may veto on safety |
> | execute a repair | **the component / K**, within budget |
> | verify a repair's effect | **a non-repairer instrument** (`SO-R164.2`) |
> | roll back | **K** (genome artifact, anchor, memory epoch) |
> | declare a recovery plan | **`[RO-13]`**, **in advance** |
> | verify a recovery | **a non-recoverer** |
> | freeze below the cap | **EIK** |
> | freeze at or above the cap | **OP** (`Cell §17`) |
> | release a freeze | **strictly higher than the trigger authority** (`SO-R161.3`) |
> | disable a detector | **`[RO-13]`**, on the false-positive budget (`Cell §18.5(ii)`) |
> | audit detector integrity | **the EIK Integrity Auditor** (`Cell §18.5(v)`) |
> | audit the Integrity Auditor | **UNRESOLVED — `P0-07 OR-H10`; terminates at OP/external** |
> | declare a capability / limitation | **the subject** (advisory); **EVA** confirms |
> | allocate attention | **K** |
> | arbitrate a workspace slot | **K** |
> | collapse an observer set to an effective source count | **K** |
> | **change any of the above** | **OP** |
> **⟹ `SO-R212.2 — TWO OPERATIONS HAVE NO CLEAR INTERNAL AUTHORITY ROOT, AND BOTH ARE MARKED UNRESOLVED RATHER THAN
> ASSIGNED:** **(a)** auditing the Integrity Auditor (`P0-07 OR-H10`, `P0-02`'s guarantor limit at §201); **(b)**
> resolving `SUPPRESSION-SUSPECTED` when the suspect is the only observer of its own scope (`OR-S10`). **Assigning
> either to K would create a self-auditing authority, which is what `Cell §18.5(v)` exists to prevent.**

---

# §213 — THE TIMESCALE INVENTORY

> ### **SO-R213.1 — SEVEN TIMESCALE CLASSES, AND THE OBJECTS IN EACH.** **[NORMATIVE]**
> | Class | Objects | Contract that owns the semantics |
> |---|---|---|
> | **event-level** | `OBJ-01` observations, `OBJ-04` occurrences, `OBJ-28` canonical events | `P0-03` |
> | **step-level** | `OBJ-23` attention, `OBJ-24` workspace slots, ladder rungs | `P0-03`, `Cell §18.2` |
> | **window-level** | `OBJ-03` coverage, B13 draws, `OBJ-12` repair serialization | `P0-07` (window) |
> | **epoch-level** | `OBJ-06` diagnosis status, `OBJ-11` quarantine, `OBJ-17` freeze, authorization validity | **`P0-02` (epoch binding)** |
> | **developmental** | `OBJ-18` self-model versions at region granularity, `P0-06`'s `DevStage` | `P0-06` |
> | **lifetime** | `OBJ-04`'s `failure_count_lifetime` (`Cell G5`), `OBJ-19/20` capability and limitation records | `Cell`, `P0-06` |
> | **generation** | nothing in P0-08. **No P0-08 object crosses a generation boundary** | `P0-07` (`HOM-INV-34`) |
> | **external governance** | `OBJ-02` scopes, `OBJ-09` detectors, `OBJ-15` recovery plans, `OBJ-16` degradation policies, the materiality relation, the incompatibility relation | **OP / `[RO-13]`** |
>
> ### **SO-R213.2 — THE INCOMPATIBILITY CHECK §213 REQUIRES, AND ITS ONE FINDING.** **[DERIVATION]**
> **Searched: does any object appear in two contracts with incompatible timescale semantics?**
> | Object | Contracts | Compatible? |
> |---|---|---|
> | **quarantine** | `Cell §18.2` (rung + max dwell), `P0-07 HM3`, `P0-08 SM-06` | ✅ **identical — SM-06 is inherited verbatim** |
> | **generation** | `P0-07 D-H08` (a store write), `P0-08` (unused) | ✅ **P0-08 has no generation-scale object, so no conflict is possible** |
> | **epoch** | `P0-02` (authorization binding), `P0-07` (`RATE_CAP`/epoch), `P0-08` (`OBJ-06`, `OBJ-17` validity) | ✅ **all three mean the same governance-declared interval** |
> | **staleness** | `P0-07 HOM-R6.6` (homeostatic measurement), `P0-08 SM-01` (observation) | ⚠️ **X-S1: `P0-07` derives staleness from measurement age; P0-08 derives it from age × the SUBJECT'S MUTATION RATE. These differ for a fast-mutating subject, where P0-08's is stricter. Classified at §229: not a contradiction but a deliberate divergence, and P0-08's is the one that must govern observation freshness** |
> | **window** | `P0-07` (ledger allocation), `P0-08` (coverage, B13) | ✅ **same window; B13 is a line in the same ledger** |
> **⟹ One divergence found (`X-S1`), declared rather than silently harmonized.**

---

# §214 — THE STATE OWNERSHIP TEST

> ### **SO-R214.1 — THE TEST, APPLIED TO EVERY MUTABLE STATE IN P0-08.** **[NORMATIVE]**
> **For every mutable state: exactly one canonical writer + defined readers + defined authority + defined verification —
> unless a multi-writer design is explicitly justified, in which case conflict semantics are mandatory.**
> | State | One writer? | Readers | Authority | Verification | Verdict |
> |---|---|---|---|---|---|
> | `OBJ-01` content | ✅ observer | K, EIK, EVA | scope (`[RO-13]`) | `OBJ-03` coverage | **PASS** |
> | `OBJ-01` freshness/validity | ✅ K | all | K | SM-01 | **PASS** |
> | `OBJ-03` | ✅ K | all health consumers | K | SM-02 + absence detectors | **PASS** |
> | `OBJ-04/05` | ⚠️ **multi-writer (every observer)** | K, EIK | this contract | **SM-03's two-detector confirmation + `OBJ-26` collapse** | **JUSTIFIED — `SO-R214.3`** |
> | `OBJ-06` status | ✅ K | EIK, `[RO-13]` | `SO-R149.2` | SM-04's excluded drivers | **PASS** |
> | `OBJ-07` | ✅ EIK | all | EIK | SM-05 | **PASS** |
> | `OBJ-11` | ✅ EIK | all | EIK | SM-06 ⟦inherited⟧ | **PASS** |
> | `OBJ-12` | ⚠️ multi-writer | K | `SO-R155.1` | **SM-07 serialization** | **JUSTIFIED — `SO-R215.2`** |
> | `OBJ-13` | ✅ K | EVA, `[RO-13]` | K | SM-08 | **PASS** |
> | `OBJ-16/17` | ✅ K / EIK-OP | all | `[RO-13]` policy | SM-11, SM-12 | **PASS** |
> | `OBJ-18` | ⚠️ **split-writer by field group** | K, EVA | `SO-R211.2` | SM-13 + `SOMon-3` | **JUSTIFIED — disjoint fields** |
> | `OBJ-21` | ⚠️ **three-way split by field group** | K, EVA | `SO-R179.3` | SM-16 | **JUSTIFIED — disjoint fields** |
> | `OBJ-23/24` | ✅ K | subject | K | SM-18/19 | **PASS** |
> | `OBJ-26` | ✅ K | EVA, `[RO-13]` | `SO-R126.3` | SM-21 | **PASS** |
> **Result: 10 PASS · 4 JUSTIFIED MULTI/ SPLIT-WRITER · 0 UNOWNED · 0 AMBIGUOUS.**
>
> ### **SO-R214.3 — WHY `OBJ-04/05` ARE DELIBERATELY MULTI-WRITER.** **[DERIVATION]**
> **Every observer must be able to report a fault. Restricting occurrence-writing to one party would mean either (a) K
> writes every occurrence, which requires K to observe everything — impossible and a `SO-R138.2` violation — or (b)
> only designated detectors write, which makes detector designation the single point of blindness (§238).**
> **⟹ The multi-writer design is accepted, and its conflict semantics are: occurrences NEVER conflict, because they are
> append-only events with distinct identities. What conflicts is their INTERPRETATION, and interpretation is
> single-writer (`OBJ-06` status is K's, `OBJ-07` is EIK's). **Append-only multi-writer plus single-writer
> interpretation is the pattern, and it is the same pattern `P0-04` uses for evidence and `P0-03` for messages.**
>
> ### **SO-R214.4 — NO UNOWNED MUTABLE STATE.** **[TEST]**
> **`SOMon-4` asserts: every object in §210's inventory has a non-empty writer cell, and every state in every machine
> in §5 has a named transition writer. A blank cell is a conformance failure at level C2, not a documentation gap.**

---

# §215 — THE MULTI-WRITER ATTACK

> ### **SO-R215.1 — THE ATTACK.** **[NORMATIVE — the attack it defends against]**
> **Writer A and writer B issue simultaneous incompatible updates to state X.**
>
> ### **SO-R215.2 — THE FIVE REQUIRED ANSWERS, PER MULTI-WRITER STATE.** **[NORMATIVE]**
> | State | **Serialization** | **Merge** | **Rejection** | **Arbitration** | **Provenance** |
> |---|---|---|---|---|---|
> | **`OBJ-04/05` occurrences** | not needed — append-only, distinct identities | **never merged** (`SO-R146.2`) | never rejected for being duplicative; a duplicate is a **corroboration attempt** and is collapsed by `OBJ-26`, not deleted | n/a | every occurrence carries its observer id and `root_commit` |
> | **`OBJ-12` repair proposals** | **K serializes: at most one accepted per ⟨scope, intervention class⟩** | **never merged** — a merged repair has no single intervention to verify | conflicting proposals are `REJECTED` or `SUPERSEDED`, both recorded | **`SO-R155.3`: NOT by confidence.** EIK safety veto → `[RO-13]` priority class → reversibility → recorded order | every proposal and every rejection is retained |
> | **`OBJ-18` self-model** | **not needed — field groups are disjoint (`SO-R211.2`)** | n/a | a subject write to a K-owned field group is **rejected at the schema level** | n/a | version + `observed_at` + the observation that caused the version |
> | **learning state** (`P0-05`) | `P0-05`'s own scope serialization | ❌ | ❌ | `P0-05 R0.1`'s UDB | `P0-05`'s change graph (**acyclic — `R64.1`**) |
> | **developmental state** (`P0-06`) | **Σ1–Σ4's staged writer separation** | ❌ | ❌ | `P0-06 R6.4` | Σ-log + tombstones |
> **⟹ `SO-R215.3 — "EVENTUAL CONSISTENCY" IS NOT USED ANYWHERE IN THIS CONTRACT, AND §215'S PROHIBITION IS DISCHARGED
> BY `SO-R142.3`: the model is ANCHOR-CONSISTENT, which names a witness, an age, and an authority, and promises no
> convergence.**
> **`[DERIVATION]` Eventual consistency is unacceptable here for a specific reason: it asserts that conflicts resolve
> without naming what resolves them. In an architecture where a conflict between a self-model and a coverage record is
> *evidence of an attack* (`SO-R174.1` defence 4), silent resolution destroys the evidence. **Contradictions are
> carried, not resolved — `P0-04`'s rule, and here it is load-bearing for security rather than for epistemics.**

---

# §215A — VOLUME B LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§142, §143, §144, §145, §146 (schema part), §147 (rules), §149, §151, §152, §155, §159, §160, §161 (schema), §163, §164, §172, §173, §174, §175, §179, §181, §182, §211, §212, §213, §214, §215, §216 (partial), §218, §220, §222 (partial)** + canon **§5 state machines, §6 writer classes, §7 authority matrix (via §211/§212)** |
| Rules introduced | **SO-C5.1–.2, R142.1–.3, R143.1–.3, R144.1–.2, R145.1–.2, R146.4, R148.1, R149.2–.3, R151.1–.2, R152.1–.2, R155.1, R155.3, R159.3, R160.1, R161.3, R161.5, R163.2, R164.1–.2, R172.1–.2, R173.1–.2, R174.1, R175.1–.2, R179.3–.4, R181.3, R182.1, R211.1–.2, R212.1–.2, R213.1–.2, R214.1–.4, R215.1–.3, R220.1, R222.2–.3** |
| **State machines** | **21 (SM-01…SM-21), all mandatory for C1, 1 ⟦INHERITED⟧ verbatim (SM-06)** |
| — structural properties | **no self-update transition anywhere · 5 machines terminate in a REPORT rather than a resolution · 3 enforce `SO-INV-01` by absence of an edge · no age-keyed transition · no vector clock** |
| **Temporal semantics** | **3 primitives (`observed_at`, `causal_depth` u8, `root_commit`) + 1 prohibited (vector clocks, `P0-03 RULE 5.4`) · 11 required items specified · causal inference explicitly NOT performed here** |
| **TOCTOU** | **5 requirements answered: freshness ✅ · revalidation ✅ (**the two-read rule**) · atomicity ⚠️ single-writer only · external witness ✅ at/above the cap · epoch matching ✅ · no numeric threshold invented** |
| **Global inventories** | **§211 writers: 16 state classes, 4 of them split/multi-writer with disjoint field groups or append-only semantics** · **§212 authority roots: 25 operations, 2 marked UNRESOLVED rather than assigned** · **§213 timescales: 8 classes, 1 divergence found (`X-S1`) and declared** · **§214 ownership: 10 PASS, 4 JUSTIFIED, 0 UNOWNED, 0 AMBIGUOUS** · **§215 multi-writer: 5 states × 5 answers, "eventual consistency" used nowhere** |
| Identity/security rules | **§172 identity ≠ authority (schema-level) · §173 four property classes, a cloned self-model is a new claim with no evidence · §174 four replay defences, the cheapest being cross-check against three K-held records · §175 six transfer questions, five ❌ and one ⚠️** |
| New invariants implied | **`SO-INV-03` (no self-update transition) · `SO-INV-04` (a diagnosis status may not be promoted by correlation, precedence, repetition, confidence, or self-report) · `SO-INV-05` (a freeze never auto-expires into normal operation and is never peer-released) · `SO-INV-06` (capability evidence is not transferable between subjects) · `SO-INV-07` (an abstention carries a mandatory recovery condition)** — *all formally numbered in Vol G's invariant set* |
| Contradictions opened | **X-S1** (staleness derived from age in `P0-07` vs age × subject mutation rate in P0-08 — declared divergence, P0-08 governs observation freshness) |
| Open research raised | **OR-S1** (`Q_ev` unknowable; `P0-03 OR-C10` inherited) · **OR-S2** (a subject's own thresholds are LOCAL-ONLY but the subject is the observer) · **OR-S3** (repair-incompatibility relation is a governance declaration) · **OR-S4** (the non-recoverer rule terminates at K/EVA — `P0-07 OR-H1`'s fourth appearance) · **OR-S5** (all calibration parameters `[U]`) · **OR-S6** (a scope can be permanently escalated) · **OR-S7** (fault onset inference unavailable internally) · **OR-S8** (no numeric freshness threshold) · **OR-S9** (the materiality relation is a governance declaration) · **OR-S10** (resolving `SUPPRESSION-SUSPECTED` when the suspect is the only observer) |
| Assumptions raised | **AS-02** (a per-envelope monotone time source — `P0-07 HP-2`; already declared in Vol A, cited not renumbered) · **AS-03** (an off-substrate anchored record store exists — `P0-07 HP-1`, **still open**) |
| Verification instruments | **SOMon-1** (§121 labels) · **SOMon-2** (`OBJ-01`'s three omittable fields) · **SOMon-3** (`locality_class`, no LOCAL-ONLY aggregation) · **SOMon-4** (no unowned state, no unnamed transition writer) |

**Next:** `65_` Vol C — canon §11–§16: the fault taxonomy, detection, quarantine, repair, rollback and recovery rules;
§148 correlation≠causation; §150 repair without root cause; §153 regression; §154 oscillation; §156 multi-fault;
§157 masking; §158 interaction.
