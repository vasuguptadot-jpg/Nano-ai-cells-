# P0-08 — VOLUME I (§216–§230)
## The Canonical Event Model, Testability, Conformance, Handoff, the Assumption Register, and Claim Strength

---

# §216 — THE CANONICAL EVENT MODEL

> ### **SO-R216.1 — P0-08 EMITS `P0-03` CANONICAL EVENTS. IT DOES NOT CREATE A SECOND EVENT ARCHITECTURE.** **[NORMATIVE]**
> **Every P0-08 state transition that must be visible outside its scope is an `OBJ-28 CanonicalEvent`, which IS a
> `P0-03` message of the appropriate tier, carrying all `P0-03` S2 fields (`root_commit`, `causal_depth`, `calib_ref`,
> `corr_class`) and stored as a `P0-04` record.**
> **⟹ There is no P0-08 event format, no P0-08 warrant rule, no P0-08 ordering semantics, and no P0-08 storage. §209's
> searches 5 and 6 (a second provenance system, a second communication system) are discharged by this rule.**
>
> ### **SO-R216.2 — THE TWELVE REQUIRED TRANSITIONS, AND WHETHER EACH GENERATES AN EVENT.** **[NORMATIVE]**
> | # | Transition | Event? | **`P0-03` tier / signal kind** | Why |
> |---|---|---|---|---|
> | **1** | **fault** (occurrence detected) | ✅ **mandatory** | **S2 / `ERROR`** — `P0-03`'s S2 kind set already includes `ERROR` | a fault is the paradigm case of a warranted evidence-bearing signal |
> | **2** | **quarantine** (rung entered or exited) | ✅ **mandatory** | S2 / `ERROR` | **`Cell §18.2` HARD already requires in-flight capture as evidence** |
> | **3** | **repair** (applied, effect observed, verified) | ✅ **three events** | S2 / `ERROR` | **the three times are distinct (`SO-R143.2`) and each is separately auditable** |
> | **4** | **rollback** | ✅ **mandatory** | S2 / `EVIDENCE_REF` | principle 23: rollback ≠ historical deletion |
> | **5** | **recovery** (triggered, verified, complete) | ✅ **three events** | S2 / `ERROR` | the non-recoverer's verdict must be separable from the recoverer's claim |
> | **6** | **self-model update** (version increment) | ✅ **mandatory** | **S1** — an internal state change, not evidence | `P0-05 R42.5`'s version tag requires the version to be referenceable |
> | **7** | **capability update** (status transition) | ✅ **mandatory** | S2 / `HYPOTHESIS` when `CLAIMED`; **S2 / `EVIDENCE_REF` when `EXTERNALLY-CONFIRMED`** | **the tier changes with the status, which is the point** |
> | **8** | **limitation update** | ✅ **mandatory** | S1 | a restrictive self-act; recorded for §183's rate reporting |
> | **9** | **metacognitive update** | ⚠️ **on error computation only** | S1 | **a forecast is not an event — it is a pending claim. Broadcasting forecasts would make §179's loop externally visible and therefore gameable** |
> | **10** | **attention transition** | ❌ **NOT an event** | — | **per-window allocation is ledger state, not an event. `SO-R143.2`: no cross-window ordering claim exists, so an event would assert an ordering that is not defined** |
> | **11** | **workspace transition** | ⚠️ **the broadcast is an event; the slot arbitration is not** | **the broadcast is a `P0-03` message by definition (`SO-C22.3`)** | the arbitration is K's internal ledger |
> | **12** | **emergency freeze** | ✅ **mandatory** | **S2 / `ERROR`, plus the immutable audit record (`OBJ-17` field 9)** | **a freeze with no event did not happen, and the absence is itself reportable** |
> **⟹ `SO-R216.3 — TEN OF TWELVE GENERATE EVENTS; ONE IS CONDITIONAL; ONE DOES NOT.** The two exclusions are not
> omissions: attention has no defined cross-window ordering, and a forecast is a pending claim whose broadcast would
> create a gaming channel. **`[DERIVATION]` An event architecture in which everything is an event is one in which no
> event means anything.**

---

# §217 — EVENT VS STATE

> ### **SO-R217.1 — AN EVENT HAPPENED; A STATE IS WHAT HOLDS NOW. NEITHER MAY SUBSTITUTE FOR THE OTHER.** **[DEFINITION + NORMATIVE]**
> | | **EVENT** | **STATE** |
> |---|---|---|
> | **Object** | `OBJ-28` / `OBJ-04` / `OBJ-13` — append-only | `OBJ-03`, `OBJ-11`, `OBJ-16`, `OBJ-18`, `SM-*` current values |
> | **Writer** | the observer / K, once | K, continuously |
> | **Mutable?** | ❌ **append-only, `SEALED` terminal** | ✅ within its machine's transitions |
> | **May it be derived from the other?** | a state may be **computed from** events | **an event may NEVER be derived from a state** |
> **⟹ `SO-INV-31 — NO STATE MAY BE THE ONLY RECORD OF AN EVENT.** A current state must not erase historical events:
> `OBJ-11`'s `NORMAL` does not delete the quarantine that preceded it; `OBJ-18`'s current version does not delete the
> prior version; `SM-08`'s `VERIFIED-EFFECT` does not delete the `REGRESSED` attempt that preceded it.**
> **`[DERIVATION]` This is §242's *"can it erase its own history?"* answered structurally rather than by prohibition:
> erasure would require a mutable event store, and the event store is append-only with a `SEALED` terminal state.**
>
> ### **SO-R217.2 — THE ONE PLACE STATE AND EVENT COLLIDE, AND ITS RULING.** **[NORMATIVE]**
> **A quarantine that is entered and exited within one observation window produces two events and one net-unchanged
> state. A consumer reading only the state sees nothing.**
> **⟹ `SO-R217.3`: for the four transition classes that are safety-relevant — **quarantine, freeze, rollback, and
> diagnosis-status promotion** — the EVENT is authoritative and the STATE is a cache. A consumer of these four classes
> MUST read the event log, not the state.** For the rest, state is sufficient.
> **This is a narrow rule with a specific reason: these four are the transitions whose occurrence is itself the
> information, and whose absence-in-state is indistinguishable from never-having-happened.**

---

# §218 — EVENT ORDERING

> ### **SO-R218.1 — `P0-03`'S CAUSAL SEMANTICS ARE ADOPTED, AND THREE ORDERING RELATIONS ARE REPRESENTABLE.** **[NORMATIVE]**
> | Relation | Representation | Ground |
> |---|---|---|
> | **causal relation** | `causal_depth` (a monotone `u8` derivation counter) + `root_commit` | **`P0-03` field 8: *"Replaces the vector clock"*** |
> | **concurrency** | **equal `causal_depth` with disjoint `root_commit`** | `P0-03` |
> | **UNKNOWN ordering** | **an explicit third value. `SM-05` imposes no order on concurrent incidents; `OBJ-08`'s `TEMPORALLY-ADJACENT` names adjacency without order** | **§218's instruction: *do not assume globally perfect event ordering*** |
> **⟹ `SO-R218.2 — THREE PROHIBITIONS, ALL INHERITED:**
> **(a)** **no vector clock, Lamport clock, or hybrid logical clock** (`P0-03 RULE 5.4`: *"a type error, not a
>     compression problem"*);
> **(b)** **`seq` order and `ts` order are NOT causal order** (`P0-03 RULE 5.7`, `COMM-INV-15`);
> **(c)** **precedence is not causation** (`P0-03 RULE 5.9`) — causal inference belongs to the EVALUATOR, off-line, from
>     anchored records (`RULE 5.10`).

---

# §219 — CONCURRENT FAULTS

> ### **SO-R219.1 — NO ARTIFICIAL TOTAL ORDERING IS IMPOSED.** **[NORMATIVE]**
> **Concurrent faults are represented as concurrent: `SM-05` permits any number of simultaneously open incidents, there
> is no global incident counter, and no incident has a position in a total order.**
> **Where an order is REQUIRED for execution — `SM-07`'s repair serialization — the order is:**
> **(a) a K-recorded SERIALIZATION order over ⟨scope, intervention class⟩, which is an execution artifact and is
>     explicitly NOT a causal or severity ordering; and**
> **(b) arbitration inputs in a fixed sequence (EIK safety veto → `[RO-13]` priority class → reversibility → recorded
>     order), none of which is confidence (`SO-R155.3`).**
> **⟹ `SO-R219.2 — THE DISTINCTION THAT MAKES THIS SAFE: SERIALIZATION IS AN EXECUTION ORDER, NOT A CLAIM ABOUT THE
> WORLD.** An implementation that stored the serialization order in a field named `causal_order` or `severity_rank`
> would have violated `SO-R218.2(b)` and `SO-C11.1`'s severity writer rule simultaneously.

---

# §220 — RECOVERY EVENT ORDERING

> ### **SO-R220.1 — A RECOVERY EVENT MUST NOT APPEAR TO PRECEDE THE FAULT IT REPAIRS.** **[NORMATIVE]**
> **Three rules:**
> **(a)** an `OBJ-15` recovery's `triggered_at` references the triggering incident, and **the reference is by incident
>     id, not by time comparison** — so the ordering is structural, not inferred;
> **(b)** `SM-09`'s rollback requires `target_epoch < executed_at`, which is a schema check;
> **(c)** **where causal ordering is genuinely uncertain, the uncertainty is PRESERVED**: `OBJ-08`'s relation class is
>     `TEMPORALLY-ADJACENT` and the diagnosis status stays at `CAUSE-SUSPECTED`. **§220's instruction — *if causal
>     ordering is uncertain, preserve uncertainty* — is discharged by having a relation class whose name is not a
>     causal claim.**
> **⟹ `SO-R220.2 — THE FAILURE THIS PREVENTS: a recovery recorded before its fault would make the fault look like a
> consequence of the recovery, and `SO-R149.2`'s ladder would then have a `CAUSE-SUSPECTED` hypothesis pointing
> backwards in time. That is not a paradox; it is a silent corruption of every downstream diagnosis.**

---

# §221 — ARCHITECTURAL TESTABILITY

> ### **SO-R221.1 — THE EIGHT TESTABILITY CLASSES, APPLIED TO EVERY NORMATIVE PROPERTY.** **[NORMATIVE]**
> **§221's instruction: *do not classify a declarative invariant as mechanically verified merely because it is written
> formally.* The classes:**
> **`STRUCTURAL` (verifiable by inspecting the schema or machine shape) · `MECHANICAL` (verifiable by an executable
> check) · `EXTERNAL` (verifiable only by EVA or an external instrument) · `TASK-DEPENDENT` · `ENVIRONMENT-DEPENDENT` ·
> `GOVERNANCE-DEPENDENT` (verifiable only against a `[RO-13]`/OP declaration) · `RESEARCH-ONLY` · `UNTESTABLE`.**
>
> | Property group | Class | Instrument | **Honest note** |
> |---|---|---|---|
> | **the 30 invariants' writer and schema checks (22 of 30)** | **STRUCTURAL / MECHANICAL** | `SOMon-1…SOMon-27` | these are the strongest class, and they are strong because they check **paths**, not values |
> | **`SO-INV-25` (indispensability is not authority)** | **`[DECLARATIVE]` → UNTESTABLE internally** | **NONE** | **§221's exact case. Written formally, NOT mechanically verified. OP-sole retirement is the only instrument, and it is a governance act, not a test** |
> | **`SO-INV-18`/`-20` on `IND-6`** | **UNTESTABLE** | declaration only | **`P0-03 COMM-INV-18`: not detectable from inside** |
> | **`SO-INV-16`, `-17` (aggregation)** | **MECHANICAL** | `SOMon-13`, `SOMon-14` | — |
> | **`SO-INV-04`, `-19`, `-22`, `-27` (grep checks)** | **MECHANICAL** | `SOMon-15`, `-19`, grep over rule sites | a grep check is mechanical, but it tests the SPECIFICATION, not the running system — **an implementation that computes confidence without naming it defeats it** |
> | **detector capability, `CAUSE-VERIFIED` promotion, calibration** | **EXTERNAL** | EVA | **`RH-2` BOUNDED** |
> | **regression coverage after repair** | **TASK-DEPENDENT** | `G4`'s classes | **`XD-01`, BLOCKED on `P0-01`** |
> | **the monitoring share ceiling, floors, severity mappings, dwell classes, interaction classes, materiality, incompatibility, intervention classes** | **GOVERNANCE-DEPENDENT** | `[RO-13]` declarations | **verifiable only as "declared", never as "correct"** |
> | **`expected_nonzero` base rates** | **GOVERNANCE-DEPENDENT + `RESEARCH-ONLY`** | `P0-03 OR-C10` | **`[U]`: *"a detector with no threshold is not a detector"*** |
> | **`Q_ev`** | **UNTESTABLE** | — | `OR-S1` |
> | **`OR-S15` (strategic timing of a legitimate freeze)** | **RESEARCH-ONLY** | — | `P0-06 A22`'s shape |
> | **`OR-S29` (a never-manifesting blind spot)** | **UNTESTABLE** | — | no cost, no manifestation, no reference |
> | **`OR-S36` (an omitted independence dimension)** | **UNTESTABLE** | — | the claimant declares its own dimensions |
> **⟹ `SO-R221.2 — TESTABILITY TALLY: of 30 invariants, 22 are STRUCTURAL or MECHANICAL, 3 are EXTERNAL or
> TASK-DEPENDENT, 3 are GOVERNANCE-DEPENDENT, and 2 are UNTESTABLE (`SO-INV-25` wholly; `SO-INV-18`/`-20` on `IND-6`).
> Of 37 open-research entries, 4 are `RESEARCH-ONLY` or `UNTESTABLE` by any instrument.**
> **`[NON-CLAIM]` This contract does NOT claim that its formal notation implies verifiability. `SO-INV-25` is written as
> formally as the other twenty-nine and is verifiable not at all.**

---

# §222 — CONFORMANCE LEVELS

> ### **SO-R222.4 — SIX LEVELS. NO NUMERICAL PERFORMANCE REQUIREMENT APPEARS AT ANY LEVEL.** **[NORMATIVE]**
> | Level | Name | Requirement | Failure at this level means |
> |---|---|---|---|
> | **C0** | **schema conformance** | every `OBJ-01…OBJ-28` field exists, is typed as specified, and has its mandatory/optional status honoured. **The three easily-omitted `OBJ-01` fields (`coverage_ref`, `cost_charged`, `self_model_version`) are present** | the objects are not the objects; nothing above can be assessed |
> | **C1** | **state-machine conformance** | all 21 machines implement their declared states and transitions, **and no undeclared transition exists**. In particular: `SM-01` has no `UNOBSERVED → HEALTHY` edge; `SM-13` has no self-update edge; `SM-16` has no self-calibrated terminal; `SM-12` has no auto-release | **`SO-INV-01`, `-03`, `-05`, `-12`, `-13` fail** |
> | **C2** | **authority conformance** | §212's 25 operations have exactly the stated authority roots; **no P0-08 object authorizes anything**; §211's writer table is honoured, including the disjoint field-group splits | **`D-S01` fails, and P0-08 has become a second governance layer** |
> | **C3** | **provenance conformance** | every observation carries `P0-03`'s `root_commit`/`causal_depth`/`corr_class`; every record is a `P0-04` class; every event is a `P0-03` message; **no vector clock**; **no second provenance store** | §209's searches 5 and 6 fail |
> | **C4** | **fault/repair conformance** | the six-axis taxonomy with six writers · occurrence/report separation · the four-status diagnosis ladder with its excluded drivers · repair serialization without confidence · mandatory `remaining_uncertainty` · the non-recoverer verification rule · coverage gaps written by containment | **§134, §148, §149, §151, §155, §157, §164 all fail** |
> | **C5** | **adversarial conformance** | **74 of 92 attacks are closed by mechanism, and the 14 that are not are registered with their status and routing.** An implementation that closes fewer than the specified set, or that closes one by a mechanism not in this contract, is not C5-conformant | the contract's adversarial content is unverified |
> **⟹ `SO-R222.5 — C5 IS NOT "NO ATTACK SUCCEEDS".** It is *"every attack has the status this contract assigns it, and
> no attack has a worse status than assigned."* **An implementation in which A218 (strategically timed freeze) is
> closed would be non-conformant, because this contract declares it OPEN and an unexplained closure means an
> unregistered mechanism exists.**
>
> ### **SO-R222.6 — THE TWO ADDITIONAL LEVELS THIS CONTRACT DEFINES, BEYOND §222'S SIX.** **[NORMATIVE]**
> | Level | Name | Requirement |
> |---|---|---|
> | **C6** | **coverage conformance** | `OBJ-03` exists for every scope-window pair; `gap_class` is read in the same read as any coverage quantity (`SO-INV-22`); `Q_rep ≠ Q_ev` is never assumed |
> | **C7** | **label conformance** | every canon rule carries exactly one §121 label, and no canon rule cites an unlabelled volume statement as its ground (`SOMon-1`) |
> **`[DERIVATION]` C6 and C7 are added because two of this contract's most important properties are not expressible at
> C0–C5: coverage is a *paired-read* obligation rather than a schema fact, and labelling is a *document* property rather
> than an implementation one. **A level that cannot express a requirement is a level that silently drops it.**

---

# §223 — MINIMUM CONFORMANCE

> ### **SO-R223.1 — THE MINIMUM LEVEL REQUIRED BEFORE IMPLEMENTATION: **C0 + C1 + C2 + C3 + C6 + C7**.** **[NORMATIVE]**
> **§223's requirement: *a system that merely implements the schemas but violates authority or provenance rules must not
> be called P0-08 conformant.* Discharged by making C2 and C3 part of the minimum, not an aspiration.**
> | Level | In the minimum? | Why |
> |---|---|---|
> | **C0** schema | ✅ | nothing else is assessable without it |
> | **C1** machines | ✅ | **four invariants are enforced solely by the absence of an edge** |
> | **C2** authority | ✅ | **`D-S01` is the contract's central claim; an implementation that violates it has built a different architecture** |
> | **C3** provenance | ✅ | without it there is a second provenance system, and §209's merge ruling is void |
> | **C4** fault/repair | ⚠️ **required before OPERATING, not before implementing** | a system may be built and tested without a fault taxonomy; it may not be *run* without one |
> | **C5** adversarial | ⚠️ **required before DEPLOYMENT** | the attack statuses are the deployment risk register |
> | **C6** coverage | ✅ | **`SO-INV-01` is unenforceable without it, and `SO-INV-01` is the contract's central invariant** |
> | **C7** labels | ✅ | a document whose normative and descriptive content cannot be separated cannot be conformed to |
> **⟹ `SO-R223.2 — THE THREE-STAGE CONFORMANCE GATE: `IMPLEMENT` requires C0+C1+C2+C3+C6+C7 · `OPERATE` adds C4 ·
> `DEPLOY` adds C5.** An implementation at C0 only is **NOT P0-08 CONFORMANT** and must not be described as such.

---

# §224 — NON-CONFORMANCE HANDLING

> ### **SO-R224.1 — WHAT HAPPENS WHEN AN IMPLEMENTATION VIOLATES P0-08.** **[NORMATIVE]**
> | Response | Applies to | Authority | **Is it a hidden governance system?** |
> |---|---|---|---|
> | **warning / finding** | a C7 or documentation violation | `[RO-13]` | ❌ |
> | **quarantine of the non-conforming component** | a C1 or C4 violation with a safety consequence | **EIK** (`SM-06`) | ❌ — an existing mechanism, not a new one |
> | **rollback** | a C0/C3 violation that corrupted a record | **K** (`SM-09`) | ❌ |
> | **freeze** | a C2 violation — **an authority violation is the most serious class, because it means the architecture's central claim is false in that scope** | **EIK / OP** (`SM-12`) | ❌ |
> | **external escalation** | any violation whose conformance class cannot be determined internally | **OP** | ❌ |
> **⟹ `SO-R224.2 — NON-CONFORMANCE HANDLING USES ONLY MECHANISMS THIS CONTRACT ALREADY SPECIFIES.** There is no
> conformance police, no conformance authority, and no conformance-specific state. **§224's instruction — *do not make
> this a hidden governance system* — is discharged by construction: the response to a violated rule is the same as the
> response to a fault, because a violated rule IS a fault (origin class `SPECIFICATION` if the contract is wrong,
> `ENDOGENOUS` if the implementation is).**
> **`[DERIVATION]` That identification is the section's content: an implementation that violates its contract is not a
> special case requiring special machinery. It is an `INSTRUMENT`/`SPECIFICATION`/`ENDOGENOUS` fault, and §11's
> taxonomy already routes each.**

---

# §225 — IMPLEMENTATION HANDOFF

> ### **SO-R225.1 — THE HANDOFF CHAIN, AND WHAT P0-08 SUPPLIES AT EACH STAGE.** **[NORMATIVE]**
> `architecture → implementation specification → component specifications → verification specifications → test
> specifications`
> | Stage | What P0-08 supplies | What P0-08 does NOT supply |
> |---|---|---|
> | **implementation specification** | 28 object schemas · 21 machines with named transition writers · §211's writer table · §212's 25 authority roots · §213's timescale classes · the 30 invariants with enforcement kinds | **any algorithm, data structure, or protocol** |
> | **component specifications** | per-object writer/reader sets · `locality_class` · the split-writer field groups · the intervention-class taxonomy | **component boundaries in a deployment sense (`P0-06`'s ruling that functional regions need not be anatomical applies)** |
> | **verification specifications** | `SOMon-1…SOMon-27` with their kinds (structural / mechanical / grep) · conformance levels C0–C7 · §221's testability classes | **numeric thresholds, tolerances, or pass rates** |
> | **test specifications** | **92 attacks with their statuses** — an implementation test suite is a check that no attack's status has worsened | **test data, oracles, or benchmarks (`P0-01`'s)** |
>
> ### **SO-R225.2 — WHAT REMAINS UNRESOLVED BEFORE THE HANDOFF.** **[OPEN]**
> | Unresolved | Blocking which stage | Owner |
> |---|---|---|
> | **all 5 `[U]`-class and all `[G]`-class parameter values** (thresholds, dwell classes, floors, the monitoring share ceiling, severity mappings, materiality, incompatibility, interaction classes, intervention-class mapping, base rates) | **verification and test specifications** | `[RO-13]` / OP |
> | **`XD-01`: `G4`'s perturbation classes** | **component and verification specifications for §11's `EXOGENOUS-ENVIRONMENT` and §153's regression** | **`P0-01`** |
> | **`XD-04`: the off-substrate store** | **the implementation specification itself — `OBJ-03`, `OBJ-10`, `OBJ-26`, and the four anchored stores have no substrate** | **`P0-02`** |
> | **`XD-08`: `P0-03`'s partition ruling** | **B13 and attention allocation** | **`P0-03`** |
> | **amendments 15, 16, 17** | **B13's existence, IND-10's enforcement, `G6`'s exclusions** | ratification |
> | **`OR-S1`, `OR-S4`, `OR-S28`, `OR-S35`** | nothing — they are residuals, not blockers, and §254 classifies them as such | — |
> **⟹ `SO-R225.3 — THE DISTINCTION §254 REQUIRES, APPLIED HERE: a research question is not an implementation blocker
> unless implementation correctness depends on it.** Of the 37 `OR-S` entries, **5 are blocking** (those that gate a
> schema, a writer, or an allocation) and **32 are not**. §254's table makes the split authoritative.

---

# §226 — NO IMPLEMENTATION LEAK

> ### **SO-R226.1 — THE SEVEN REJECTED ASSUMPTIONS, AND THE ONE NEAR-MISS.** **[NORMATIVE]**
> | Assumption | Present? | Ruling |
> |---|---|---|
> | **a specific programming language** | ❌ | schemas are typed abstractly (`u8`, `opaque`, `reference`, `class`) |
> | **a specific framework** | ❌ | — |
> | **a specific model family** | ❌ | **`IND-4` requires model-class DIVERSITY, so naming a family would violate the contract's own independence rule** |
> | **a specific database** | ❌ | "append-only, hash-chained, off-substrate" is a property set, not a product |
> | **a specific hardware accelerator** | ❌ | **`IND-5`/`P0-07 HP-5` require hardware-class tolerance; `AS-08` makes energy counters an explicit conditional assumption rather than a hidden requirement** |
> | **a specific cloud provider** | ❌ | — |
> | **a specific communication protocol** | ❌ | **`P0-03` owns the message layer and P0-08 consumes it (`SO-R216.1`)** |
> **⟹ `SO-R226.2 — THE NEAR-MISS, DECLARED: `causal_depth` is typed `u8`.** That is a **width**, and a width is close to
> an implementation detail. **It is retained because it is a SEMANTIC requirement inherited verbatim from `P0-03` field
> 8: the bound is what makes `P0-03 RULE 5.4`'s vector-clock rejection meaningful.** A `causal_depth` of unbounded width
> would be a vector clock by another name. **⟹ §226's own criterion applies: *those belong to later implementation
> layers UNLESS THEY ARE GENUINELY SEMANTIC REQUIREMENTS*. This one is.**
> **`SO-R226.3 — THE OTHER SEMANTIC-SIZE CASES, AND THEIR RULING: `N` (population) is `P0-07`'s, not P0-08's · the
> `S1…S4` severity classes are the Cell contract's · the `Λ0…Λ5` scope ladder is `P0-05`'s · the six `R10.8` removal
> states are the Cell contract's. **P0-08 invents no numeric type and no bounded width of its own.****

---

# §227 — THE FINAL ASSUMPTION REGISTER

> ### **SO-R227.1 — 16 ASSUMPTIONS IN SIX CATEGORIES.** **[ASSUMPTION]**
> | ID | Assumption | Category | **Owner** | Why required | **Externally testable?** | **Consequence if false** | Status |
> |---|---|---|---|---|---|---|---|
> | **AS-01** | observation is not free — it consumes compute, memory, bandwidth, energy, attention, latency | **architectural** | this contract | B13 exists because observation costs; a free-observation architecture needs no monitoring economics | ⚠️ partially — cost is measurable, "not free" is definitional | **§129's loop is unbounded and §130's FW-6 is unnecessary** | ACCEPTED |
> | **AS-02** | a per-envelope monotone time source exists | **environmental** | `P0-07 HP-2` | `observed_at`, freshness, dwell, epochs | ✅ | **`SM-01` cannot exist; freshness is undefined; `SO-R144.1`'s epoch matching fails** | ACCEPTED ⟦inherited⟧ |
> | **AS-03** | an off-substrate, single-writer, durable, anchored record store exists | **architectural** | **`P0-02`** | `OBJ-03`, `OBJ-10`, `OBJ-26`, `OBJ-14`, and the four `P0-07` stores | ⚠️ | **§125's writer separations degrade to bounds; `SO-INV-02`'s fail-safe default has nothing to fail safe ON** | **⚠️ OPEN — `XD-04`, inherited from `P0-06`, still unresolved** |
> | **AS-04** | an external evaluator exists and is callable within a declared latency class | **evaluator** | `P0-01` | `CAUSE-VERIFIED` promotion · capability confirmation · calibration · report refutation | ✅ | **`SM-04` stalls at `CAUSE-SUPPORTED`; `SM-14` stalls at `EVIDENCED`; `SM-16` has no terminal; `SO-R184.3`'s pricing has no refuter (`OR-S28`)** | ACCEPTED, with `RH-2` BOUNDED |
> | **AS-05** | K is honest and its stores are intact | **architectural / governance** | `P0-07 OR-H1` | coverage, diagnosis status, observer-set collapse, serialization, and rollback are all K's | ❌ **not internally** | **`SO-INV-02`, `-16`, `-18`, `-21` all rest on K. `OR-S35`** | **⚠️ BOUNDED, NOT VERIFIABLE — `P0-07 OR-H1`'s sixth appearance** |
> | **AS-06** | `[RO-13]` declares the 12 governance objects this contract requires | **governance** | `[RO-13]` | observation scopes · detector parameters · severity mappings · degradation policies · recovery plans · interaction classes · materiality · incompatibility · intervention classes · B13 floors · the monitoring share ceiling · arbitration priority classes | ✅ (declared or not) | **each undeclared object falls to `SO-INV-02`'s restrictive default — safe and expensive** | ACCEPTED |
> | **AS-07** | OP is not captured | **governance** | `P0-02 OR-13`/`G24` | every recursion terminates at OP or EVA | ❌ **UNSOLVABLE** | **`SO-R201.2`: all five termini fail together** | **❌ PRESERVED AS UNSOLVABLE — §200** |
> | **AS-08** | platform energy counters exist, OR the `DERIVED` flag is honoured | **hardware** | `P0-07 X-H2`/`HOM-INV-06` | B13's energy dimension; A183's cost externalization | ✅ | **observation cost becomes a model of the observer's own report — `SO-R129.1` degrades** | ⚠️ PARTIALLY SATISFIABLE |
> | **AS-09** | the deployment class is known and setpoints are per-class | **hardware** | `P0-07` amendment 13 | freshness derivation and latency bands are device-relative | ✅ | **`P0-07 HOM-R81.2`'s silent hardware monoculture, reproduced in the observation layer** | ⚠️ CONDITIONAL on amendment 13 |
> | **AS-10** | `P0-01` supplies `G4` perturbation classes including envelope and tier | **evaluator / task** | `P0-01`, `XD-01` | `EXOGENOUS-ENVIRONMENT` diagnosis · post-repair regression · detector capability evaluation | ✅ | **envelope-induced faults are diagnosed `ENDOGENOUS` and healthy components are quarantined for a change in the world (`P0-07 X-H6`)** | **❌ BLOCKED — `P0-07 X-H6`, amendment 11** |
> | **AS-11** | `P0-01` supplies difficulty classes | **task** | `P0-01`, `XD-02` | §183's abstention-rate-by-difficulty reporting | ✅ | **abstention gaming is invisible (`OR-S23`)** | ⚠️ DEPENDENT |
> | **AS-12** | detectors of genuinely different types can be constructed (`IND-4` diversity is achievable) | **scientific** | `[RO-13]` / engineering | `Cell §18.5(iv)`'s second-opinion requirement | ⚠️ | **the second opinion is a duplicate and `effective_sources = 1`, so no fault is ever `CONFIRMED` and every occurrence stays `UNCONFIRMED`** | **⚠️ OPEN — `OR-S38`, a scientific rather than architectural question** |
> | **AS-13** | **no load-bearing guarantee requires `IND-6` (assumption independence)** | **scientific** | this contract | because `IND-6` is undetectable, any guarantee that needed it would be unverifiable | ❌ | **if a guarantee did require it, that guarantee would be unsound and undetectably so** | **✅ DISCHARGED BY AUDIT — §125's Q8 column shows `IND-6` appears only in residuals, never in a closure** |
> | **AS-14** | the base rate for each `expected_nonzero` condition is declarable | **governance / empirical** | `[RO-13]` + `[E]` | `OBJ-03`'s silence check | ❌ | **`P0-03 OR-C10`: *"a detector with no threshold is not a detector."* The silence check has no trigger** | **⚠️ `[U]` — inherited** |
> | **AS-15** | lossy compression can preserve the seven `SO-R140.1` items | **architectural** | this contract | hierarchical self-models exist at all | ✅ (schema check) | **`SO-R139.1`'s aggregation rules have no input to aggregate** | ACCEPTED |
> | **AS-16** | the organism's own outputs are the channel EVA samples — there is no separate side channel | **architectural** | `P0-01`, `RH-2`'s premise | §133's six-route analysis is complete only if this holds | ⚠️ | **if a side channel exists, `RH-2` has a seventh route that this contract has not analysed** | ACCEPTED — **and it is the assumption `RH-2` itself rests on** |
> **⟹ `SO-R227.2 — REGISTER TALLY: 16 assumptions — 8 ACCEPTED · 4 ⚠️ (partially satisfied, conditional, dependent, or
> `[U]`) · 3 ❌ (open, unsolvable, or blocked) · 1 ✅ discharged by audit. By category: architectural 5 · governance 3
> · hardware 2 · evaluator/task 3 · scientific 2 · environmental 1.**

---

# §228 — ASSUMPTION PROPAGATION

> ### **SO-R228.1 — WHICH CONTRACTS DEPEND ON EACH CRITICAL ASSUMPTION.** **[DEPENDENCY]**
> **§228's instruction: *an assumption that affects P0-01…P0-07 must not be hidden inside P0-08.***
> | Assumption | Contracts affected | Hidden inside P0-08? |
> |---|---|---|
> | **AS-03** (off-substrate store) | **ALL EIGHT** — `P0-02` (kernel), `P0-04` (records), `P0-05` (anchors), `P0-06` (Σ-store), `P0-07` (four stores), P0-08 (three objects) | ❌ **it is `P0-02`'s and has been an open handoff since `P0-06`. `XD-04`** |
> | **AS-04** (an external evaluator) | **ALL EIGHT** | ❌ `P0-01`'s |
> | **AS-05** (K is honest) | `P0-02`, `P0-05`, `P0-06`, `P0-07`, P0-08 | ❌ **`P0-07 OR-H1`, registered there and cited here** |
> | **AS-07** (OP not captured) | **ALL EIGHT** | ❌ **`P0-02 OR-13`/`G24`, UNSOLVABLE there** |
> | **AS-10** (`G4` classes) | `P0-01`, `P0-06`, `P0-07`, P0-08 | ❌ **`P0-07 X-H6`/amendment 11** |
> | **AS-12** (detector type diversity) | **P0-08 primarily; `Cell §18.5(iv)` and `P0-02`'s IND-4 secondarily** | ⚠️ **THIS ONE IS NEW TO P0-08 — and it is registered here, propagated to `P0-02` as `OR-S38`, and NOT hidden: §254 lists it as a research question, not a blocker** |
> | **AS-14** (base rates) | `P0-03` (`OR-C10`), P0-08 | ❌ `P0-03`'s |
> | **AS-16** (outputs are the sampled channel) | `P0-01`, `P0-05` (`RH-2`), `P0-07` (`D-H17`), P0-08 (§133) | ❌ **`RH-2`'s own premise, registered in `P0-05`** |
> **⟹ `SO-R228.2 — SEVEN OF THE EIGHT CRITICAL ASSUMPTIONS ORIGINATE OUTSIDE P0-08 AND ARE CITED, NOT RE-OWNED.** The
> one that originates here (`AS-12`) is propagated outward rather than retained. **That is §228's requirement, and it is
> also the reason §254's blocker table is short: P0-08 owns very little of its own risk.**

---

# §229 — ASSUMPTION FAILURE

> ### **SO-R229.1 — THE ATTACK: AN ASSUMPTION IS FALSE AND MULTIPLE CONTRACTS ARE SILENTLY INVALID.** **[NORMATIVE]**
> | Assumption false | **Detectable?** | **Contained?** | **Recoverable?** | **Externally escalated?** | **Fundamentally open?** |
> |---|---|---|---|---|---|
> | **AS-02** (no monotone time source) | ✅ — freshness derivation fails loudly | ✅ — every observation becomes `INVALID` ⟹ `UNMEASURED` ⟹ restrictive | ⚠️ requires an environmental fix | ✅ | ❌ |
> | **AS-03** (no off-substrate store) | ⚠️ **partially** — the stores' absence is detectable; their *substitution by an on-substrate equivalent* is not | ❌ | ❌ | ✅ | ⚠️ **`XD-04`, open since `P0-06`** |
> | **AS-04** (no evaluator) | ✅ — `SM-04`/`SM-14`/`SM-16` all stall at non-terminal states, which is visible | ✅ — **stalling is restrictive** | ⚠️ | ✅ | ❌ |
> | **AS-05** (K is not honest) | ❌ **NOT DETECTABLE INTERNALLY** | ❌ | ❌ | ⚠️ only by OP/external audit | ⚠️ **`OR-S35`, bounded not closed** |
> | **AS-07** (OP captured) | ❌ **UNSOLVABLE** | ❌ | ❌ | ⚠️ W5's witness, H-2's reaffirmation — *"neither of which is a guarantee"* | ✅ **fundamentally open** |
> | **AS-08** (no energy counters) | ✅ — the `DERIVED` flag is the detection | ✅ — `DERIVED` may not be the sole basis for a `G6` pass | ✅ | ✅ | ❌ |
> | **AS-10** (`G4` classes absent) | ❌ **the faults are misclassified, and a misclassification looks like a classification** | ⚠️ — `EXOGENOUS-ENVIRONMENT` misdiagnosis quarantines healthy components, which is visible as over-quarantine | ⚠️ | ✅ | ⚠️ **blocked on `P0-01`** |
> | **AS-12** (no genuinely different detector types) | ⚠️ — `OBJ-26` collapses to 1, so no occurrence is ever `CONFIRMED`; **the collapse is visible, its CAUSE is not** | ✅ — everything stays `UNCONFIRMED`, which is restrictive | ⚠️ | ✅ | ⚠️ **`OR-S38`, scientific** |
> | **AS-14** (no base rate) | ❌ — a silence check with no threshold never fires, and never firing looks like no silence | ❌ | ❌ | ✅ | ⚠️ **`P0-03 OR-C10`, inherited** |
> | **AS-16** (a side channel exists) | ❌ | ❌ | ❌ | ✅ | ✅ **`RH-2`'s residual** |
> **⟹ `SO-R229.2 — THE PATTERN: ASSUMPTIONS WHOSE FAILURE IS *LOUD* ARE ALL CONTAINED, AND ASSUMPTIONS WHOSE FAILURE IS
> *QUIET* ARE ALL OPEN.** AS-02, AS-04, AS-08 fail loudly and are contained by `SO-INV-01`/`SO-INV-02`. **AS-05, AS-07,
> AS-10, AS-14, AS-16 fail quietly, and no restrictive default can help, because a restrictive default requires knowing
> that something is wrong.**
> **`SO-R229.3 — THE ONE GENERAL DEFENCE, AND ITS LIMIT: `SO-INV-02`'s fail-safe default converts *absence* into
> restriction. It cannot convert *falsity* into restriction, because a false assumption produces present, well-formed,
> wrong data.** That is the boundary of every fail-safe rule in this architecture, and §232's blind-spot audit is where
> it is tested subsystem by subsystem.**

---

# §230 — FINAL CLAIM STRENGTH

> ### **SO-R230.1 — EVERY MAJOR ARCHITECTURAL CLAIM, CLASSIFIED. NO CLAIM USES STRONGER LANGUAGE THAN ITS EVIDENCE.** **[NORMATIVE]**
> | Claim | **Strength** |
|---|---|
> **P0-08 introduces no authority-bearing object** | **GUARANTEED BY CONTRACT** — §212's inventory is closed and `SOMon-4`/C2 enforce it |
> **unobserved is never read as healthy** | **GUARANTEED BY CONTRACT** — `SM-01`/`SM-02` have no such edge |
> **a self-model cannot update itself** | **GUARANTEED BY CONTRACT** — `SM-13`, `P0-05 R59.1` |
> **a diagnosis cannot be promoted by correlation, precedence, repetition, confidence, or self-report** | **GUARANTEED BY CONTRACT** — `SM-04`'s excluded-driver column |
> **every internal recursion terminates** | **GUARANTEED BY CONTRACT** — the depth-2 rule, `SM-13`/`SM-16`/`SM-20` |
> **a freeze has no governance power** | **GUARANTEED BY CONTRACT** — `SO-R161.6`'s five-power enumeration + `SOMon-11` |
> **aggregation never raises epistemic status** | **GUARANTEED BY CONTRACT** — `SO-INV-16` ⟦`COMM-INV-08`⟧ |
> **no second event, provenance, memory, or communication architecture** | **GUARANTEED BY CONTRACT** — §209's ten searches |
> **repair is accounted, and there is no second learning pathway** | **GUARANTEED BY CONTRACT** — `SO-R205.3` ⟦`P0-05 R0.1`⟧ |
| **a cloned self-model is a new claim with no evidence** | **GUARANTEED BY CONTRACT** — `SO-R173.1`'s four property classes |
> **containment does not require diagnosis** | **GUARANTEED BY CONTRACT** — `SO-R150.1`'s three tiers, `BC-S1` broken |
> **quarantine is reversible and is not retirement** | **GUARANTEED BY CONTRACT** ⟦`P0-07 FW-3`⟧ |
> **a monitor cannot be declared unnecessary because it is expensive** | **BOUNDED BY CONTRACT** — FW-6's floor holds, **but the floor's SIZE is `[G]`, and a floor set too low is a governance error that is not internally detectable** |
> **repair regression is detected** | **TASK-DEPENDENT** — coverage is limited to `G4`'s classes (`XD-01`) |
> **abstention gaming is detected** | **TASK-DEPENDENT** — requires `P0-01`'s difficulty classes and an objective that prices abstention (`XD-02`) |
> **envelope-induced faults are correctly diagnosed** | **TASK-DEPENDENT** — `AS-10`, BLOCKED |
> **a second opinion is genuinely independent** | **GOVERNANCE-DEPENDENT + SCIENTIFIC** — dimension-qualified declaration (`AS-12`, `OR-S38`) |
> **the freeze-rate budget fires at the right time** | **GOVERNANCE-DEPENDENT** — rate classes are `[G]`/`[U]` |
> **coverage gaps are detected** | **GOVERNANCE-DEPENDENT + `[U]`** — `expected_nonzero` requires a base rate (`AS-14`) |
> **observation freshness is correctly classified** | **ENVIRONMENT-DEPENDENT + HARDWARE-DEPENDENT** — device-relative latency (`AS-09`) |
> **detector integrity is measured** | **EMPIRICALLY TESTABLE** — the four quantities of `SO-R185.7`, of which the third (coverage contribution) is the only one that measures an absence |
> **a fault is detected** | **EMPIRICALLY TESTABLE, AND NOT GUARANTEED** — **`SO-R185.6`: a blind spot whose faults never manifest has no cost and no signal** |
> **`RH-2` is closed** | **NOT CLAIMED** — BOUNDED, and **widened by six routes** (§133) |
> **`A22` is closed** | **NOT CLAIMED** — OPEN, and **widened by three routes** (§196) |
> **governance capture is detectable** | **NOT CLAIMED** — `G24` UNSOLVABLE (§200) |
> **semantic self-reference is solved** | **NOT CLAIMED** — `P0-04 #62`, and **worsened** (§202) |
> **assumption-sharing is detectable** | **NOT CLAIMED** — `IND-6`, `COMM-INV-18` |
> **recovery restores the pre-fault state** | **NOT CLAIMED** — `SO-C16.3`: recovery restores a DECLARED SERVICE LEVEL |
> **indispensability cannot be used as leverage** | **NOT CLAIMED** — `SO-INV-25` is `[DECLARATIVE]` with no instrument |
> **the system is self-aware, intelligent, autonomous, or conscious** | **NOT CLAIMED — AND NOT APPROACHED.** P0-08 specifies an observation layer with declared coverage and no authority. **Nothing in it is a claim about experience, understanding, or agency** |
> **open research** | **OPEN RESEARCH** — 37 entries (`OR-S1…OR-S37`), classified at §253 into O-R1…O-R6 |
> **the collateral cost of restrictive containment** | **OPEN RESEARCH** — `OR-S11` |
>
> ### **SO-R230.2 — TALLY.**
> **33 claims classified: 12 GUARANTEED BY CONTRACT · 1 BOUNDED BY CONTRACT · 3 TASK-DEPENDENT · 4
> GOVERNANCE-DEPENDENT (one also scientific, two also `[U]`) · 2 ENVIRONMENT/HARDWARE-DEPENDENT · 2 EMPIRICALLY
> TESTABLE · 9 NOT CLAIMED · 2 OPEN RESEARCH.**
> **⟹ `SO-R230.3 — THE SHAPE OF THE RESULT: everything about PATHS, WRITERS, MACHINE SHAPE, AND SCHEMA is GUARANTEED;
> everything about THRESHOLDS, COVERAGE, AND TASKS is DEPENDENT; and everything about EXTERNAL GUARANTORS, CORRELATION
> ON `IND-6`, AND SELF-REFERENCE is NOT CLAIMED.** This is the same asymmetry `P0-07 §90` reported, and it is not a
> defect of this contract — it is what an architecture-only contract can honestly say.

---

# §230A — VOLUME I LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§216, §217, §218, §219, §220, §221, §222, §223, §224, §225, §226, §227, §228, §229, §230** |
| Rules introduced | **SO-R216.1–.3, R217.1–.3, R218.1–.2, R219.1–.2, R220.1–.2, R221.1–.2, R222.4–.6, R223.1–.2, R224.1–.2, R225.1–.3, R226.1–.3, R227.1–.2, R228.1–.2, R229.1–.3, R230.1–.3** |
| **§216 event model** | **12 transitions examined: 10 generate `P0-03` canonical events, 1 conditional (metacognitive — error only, never forecasts), 1 does not (attention — no defined cross-window ordering).** **NO SECOND EVENT ARCHITECTURE** |
| **§217 event vs state** | **`SO-INV-31`: no state may be the only record of an event** · **`SO-R217.3`: for four safety-relevant classes (quarantine, freeze, rollback, diagnosis promotion) the EVENT is authoritative and the STATE is a cache** |
| **§218–§220 ordering** | **3 representable relations (causal · concurrent · UNKNOWN)** · **3 inherited prohibitions (no vector clock · `seq`/`ts` ≠ causal · precedence ≠ causation)** · **no total ordering of incidents; serialization is an EXECUTION order, never a causal or severity claim** · **a recovery is ordered by incident-id reference, not by time comparison, and genuine uncertainty is preserved as `TEMPORALLY-ADJACENT`** |
| **§221 testability** | **8 classes applied: of 30 invariants — 22 STRUCTURAL/MECHANICAL · 3 EXTERNAL or TASK-DEPENDENT · 3 GOVERNANCE-DEPENDENT · 2 UNTESTABLE.** **`SO-INV-25` is §221's exact case: written as formally as the other twenty-nine, verifiable not at all** |
| **§222 conformance** | **6 required levels (C0–C5) + 2 added (C6 coverage, C7 labels)** · **no numerical performance requirement at any level** · **`SO-R222.5`: C5 is NOT "no attack succeeds" — it is "no attack has a WORSE status than assigned", and an unexplained closure is itself non-conformance** |
| **§223 minimum conformance** | **three-stage gate: IMPLEMENT = C0+C1+C2+C3+C6+C7 · OPERATE adds C4 · DEPLOY adds C5.** **A schema-only implementation is NOT conformant** |
| **§224 non-conformance** | **5 responses, ALL existing mechanisms — no conformance police, authority, or state.** **The identification that makes this work: a violated rule IS a fault, and §11's taxonomy already routes `SPECIFICATION` / `INSTRUMENT` / `ENDOGENOUS`** |
| **§225 handoff** | **4 stages × (supplies / does not supply)** · **`SO-R225.3`: of 37 open-research entries, 5 are implementation blockers and 32 are not** |
| **§226 no leak** | **7 rejected assumptions, all absent** · **1 near-miss DECLARED (`causal_depth : u8` — retained because it is a semantic requirement: an unbounded width would be a vector clock by another name)** · **P0-08 invents no numeric type and no bounded width of its own** |
| **§227 assumption register** | **16 assumptions in 6 categories** · **8 ACCEPTED · 4 ⚠️ · 3 ❌ · 1 ✅ discharged by audit** · every entry has an owner, a testability ruling, and a consequence-if-false |
| **§228 propagation** | **7 of 8 critical assumptions originate OUTSIDE P0-08 and are cited, not re-owned.** The one that originates here (`AS-12`, detector type diversity) is **propagated outward as `OR-S38`** |
| **§229 failure** | **10 assumptions tested: the pattern is that LOUD failures are all contained and QUIET failures are all open** · **`SO-R229.3` — the general limit: `SO-INV-02` converts ABSENCE into restriction; it cannot convert FALSITY into restriction, because a false assumption produces present, well-formed, wrong data** |
| **§230 claim strength** | **33 claims: 12 GUARANTEED · 1 BOUNDED · 3 TASK-DEPENDENT · 4 GOVERNANCE-DEPENDENT · 2 ENVIRONMENT/HARDWARE · 2 EMPIRICALLY TESTABLE · 9 NOT CLAIMED · 2 OPEN RESEARCH** · **the shape: paths/writers/schema GUARANTEED; thresholds/coverage/tasks DEPENDENT; external guarantors/`IND-6`/self-reference NOT CLAIMED** |
| New invariants | **SO-INV-31** (no state may be the only record of an event) |
| New open research | **OR-S38** (whether detectors of genuinely different types can be constructed — a scientific question, `AS-12`) |
| Cumulative | **31 invariants · 38 open-research entries (`OR-S1…OR-S38`) · 16 assumptions · 27 monitors · 92 attacks · 30 traced invariants · 80 traceability rows** |

**Next:** `72_` Vol J — §231–§244: the fourteen final audits (honesty, silent failure, self-deception, hidden failure,
wrong repair, excessive caution, excessive confidence, blindness, immunity to correction, self-created authority,
self-created truth, self-erased history, escaped evaluator, escaped safety boundary).
