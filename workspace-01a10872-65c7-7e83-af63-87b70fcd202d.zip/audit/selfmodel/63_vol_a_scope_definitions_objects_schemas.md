# P0-08 — VOLUME A (§120A framing, §121, and canonical §1–§4 material)
## Scope, Normative Labelling, Definitions, Architectural Objects, Object Schemas, State Schemas

**Contract:** *V4 — Self-Observation, Fault, Immune-Detection & Metacognition Contract v1.0* (proposed).
**Directory:** `/home/user/audit/selfmodel/` · **Files `63_` … `74_` (Volumes A–L) + `75_` (canon) + README.**
**Inherits from:** `P0-01` task/fitness · `P0-02` EIK · `P0-03` communication · `P0-04` memory · `P0-05` learning · `P0-06` development · `P0-07` homeostasis/resources/population/evolution · the V4 Cell Contract.

---

# §0.A — ID CONVENTIONS, LOCKED BEFORE WRITING

> **[NORMATIVE]** Every identifier class in this deliverable is fixed here. **`P0-07`'s sweep found that an ID
> convention left implicit produced one collision in which a single ID denoted two different rules; the convention is
> therefore stated first and machine-checked last (README §89-analogue).**

| Prefix | Denotes | Numbered by | Range in this deliverable |
|---|---|---|---|
| **`SO-R<section>.<m>`** | a **volume rule** | the brief's **SECTION** number (§121 → `SO-R121.m`) | §120–§270 |
| **`SO-C<canon§>.<m>`** | a **canon clause** | the **canonical section** number (canon §1–§33) | 1–33 |
| **`SO-INV-<nn>`** | an **invariant** | sequential | 01… |
| **`OBJ-<nn>`** | an **architectural object** | sequential | 01… |
| **`SM-<nn>`** | a **state machine** | sequential | 01… |
| **`FT-<nn>`** | a **fault class** | sequential | 01… |
| **`A172…`** | an **attack** | **continues `P0-07`'s register, which ended at A171** | A172… |
| **`OR-S<n>`** | an **open research entry** | sequential | 1… |
| **`AS-<nn>`** | an **assumption** | sequential | 01… |
| **`X-S<n>`** | a **contradiction** | sequential | 1… |
| **`BC-S<n>`** | a **circular dependency** | sequential | 1… |
| **`XD-<nn>`** | a **cross-contract dependency** | sequential | 01… |
| **`D-S<nn>`** | a **decision record** | sequential | 01… |
| **`SOMon-<n>`** | a **monitor / verification instrument** | sequential | 1… |
| **`FW-6…`** | a **firewall** | **continues `P0-07`'s FW-1…FW-5** | 6… |
| **`B13…`** | a **budget class** | **continues `P0-07`'s B0…B12** | 13… |
| **`IND-1…IND-9`** | **independence dimensions** | **⟦INHERITED from `P0-02 §35.2`⟧**; **`IND-10` is proposed as new** | |
| **`dim 1…dim 6`** | **correlation dimensions** | **⟦INHERITED from `P0-03 R14.2`⟧** | |
| **`C0…C5`** | **conformance levels** | §222 | |

**`SO-R` and `SO-C` are disjoint by prefix.** A rule keyed by section and a clause keyed by canon-part can share a
numeric suffix without ambiguity, and no bare numeric form is ever used.

---

# §120 — FINAL DELIVERABLE FORMAT

> ### **SO-R120.1 — THE TWO ARTIFACTS AND THEIR RELATION.** **[NORMATIVE]**
> **A. DETAILED CONTRACT VOLUMES** (`63_` … `73_`): the complete normative architecture — definitions, object schemas,
> state models, state transitions, authority boundaries, writer ownership, information flows, provenance requirements,
> epistemic boundaries, failure semantics, recovery semantics, resource interactions, and the seven interface classes
> (communication, memory, learning, development, evolutionary, governance, hardware), plus scalability constraints,
> verification requirements, adversarial results, and unresolved assumptions.
> **B. CANONICAL STANDALONE CONTRACT** (`74_`): *"V4 — Self-Observation, Fault, Immune-Detection & Metacognition
> Contract v1.0"*, with the 33 required sections, readable alone.
> **⟹ The relation is: the canon is NORMATIVE and self-contained; the volumes are NORMATIVE plus DERIVATION. Where the
> two differ, the canon governs and the difference is a defect to be fixed, not an interpretation to be argued.**
>
> ### **SO-R120.2 — "DO NOT REPLACE ARCHITECTURE WITH PROSE DESCRIPTIONS."** **[NORMATIVE]**
> Discharged by form, not by intention. Every load-bearing statement in this deliverable appears as one of:
> **(a) a numbered rule** with an authority, a writer, and a §121 label; **(b) an object schema** with typed fields and
> a writer class; **(c) a state machine** with named states, named transitions, a transition writer, and terminal
> states; **(d) a matrix row** in an authority, writer, timescale, or traceability table; **(e) an invariant** with a
> stated enforcement kind (writer check / state check / schema check / grep check); **(f) a declared OPEN, ASSUMPTION,
> DEPENDENCY, or NON-CLAIM.**
> **A paragraph that is none of these six is commentary and carries no normative weight. `[DERIVATION]` and
> `[NON-CLAIM]` blocks are permitted and are labelled as such.**
>
> ### **SO-R120.3 — THE IMPLEMENTABILITY TEST THIS VOLUME SET MUST PASS.** **[TEST]**
> *"Self-contained enough that an implementer can later derive implementation specifications without having to infer
> missing semantics."* The test applied at §225 and at the closure gate (§245) is:
> **for every object, an implementer must be able to answer, from this document alone: who may write it, who may read
> it, what its fields mean, what its states are, what causes each transition, what happens when it is stale, what
> happens when it is corrupt, what happens when its writer is unavailable, and what its absence means.**
> **Fourteen questions per object. §210's inventory is the answer sheet, and any object with a blank cell is an
> incomplete object, not an implementable one.**

---

# §121 — NORMATIVE VS DESCRIPTIVE SEPARATION

> ### **SO-R121.1 — THE EIGHT LABELS, AND THE RULE THAT MAKES THEM BINDING.** **[NORMATIVE]**
> Every important statement in the canon carries exactly one of:
>
> | Label | Meaning | What it obliges |
> |---|---|---|
> | **`[NORMATIVE]`** | a requirement. Violating it is non-conformance | an owner, an enforcement kind, and a conformance level (§222) |
> | **`[DEFINITION]`** | fixes the meaning of a term | nothing may use the term in another sense anywhere in P0-01…P0-08 |
> | **`[DERIVATION]`** | shows why a rule has this form | **carries no obligation; may be deleted without changing the contract** |
> | **`[ASSUMPTION: AS-nn]`** | the contract is only valid if this holds | an entry in §227's register with an owner, a testability ruling, and a consequence-if-false |
> | **`[DEPENDENCY: <contract> <rule>]`** | the contract relies on another contract's rule | an entry in §208's dependency graph; **the dependency is not re-derived here** |
> | **`[TEST: SOMon-n / §n]`** | a verification instrument exists | the instrument's kind: structural / mechanical / external / task-dependent / untestable (§221) |
> | **`[OPEN: OR-Sn / O-Rk]`** | unresolved | a routing and a §253 classification (O-R1…O-R6) |
> | **`[NON-CLAIM]`** | explicitly not asserted | **may not be weakened into a claim elsewhere in the deliverable** |
>
> ### **SO-R121.2 — THE PROHIBITION: DISCUSSION MAY NOT SILENTLY BECOME ARCHITECTURE.** **[NORMATIVE]**
> **A statement that appears in a volume without a label has NO normative status and may not be cited as a rule.**
> **A mechanism described in a `[DERIVATION]` block is not thereby part of the architecture.**
> **A candidate mechanism is labelled `[OPEN]` with the word CANDIDATE in its text, and it acquires normative force
> only by being restated in the canon with a `[NORMATIVE]` label.**
> **⟹ Enforcement: `SOMon-1` asserts that every `SO-R` and `SO-C` rule in the canon carries exactly one label, and
> that no canon rule cites an unlabelled volume statement as its ground. This is a structural (grep) check, not a
> judgement call.**
>
> ### **SO-R121.3 — WHY THIS RULE MATTERS MORE IN P0-08 THAN IN ANY PRIOR CONTRACT.** **[DERIVATION]**
> **P0-08's subject matter is observation, self-description, and self-assessment — the three activities whose
> *description* most easily reads as their *specification*.** A sentence like *"the system maintains a model of its own
> capabilities"* is discussion; it becomes architecture only when it states who writes the model, at what granularity,
> with what staleness semantics, and what may not be inferred from it. **Prior contracts had this problem locally
> (`P0-06`'s anatomical metaphors, `P0-05`'s "reward", `P0-04`'s "memory"); P0-08 has it as its entire subject.**
> **⟹ §121 is not a formatting requirement. It is the mechanism by which this contract avoids specifying a
> *description* of self-awareness instead of an architecture for observation.**

---

# §122-PRE — THE CENTRAL DECISION, STATED BEFORE THE OBJECTS

> ### **D-S01 — P0-08 ADDS NO AUTHORITY. IT ADDS A TYPED OBSERVATION LAYER.** **[NORMATIVE]**
> **Every object this contract introduces is either (a) an OBSERVATION with declared coverage, freshness, provenance
> and epistemic status, or (b) a RECORD of an act whose authority already belongs to another contract.**
> **P0-08 introduces no object that may authorize, allocate, permit, promote, select, or govern.**
>
> | Act | Authority | Contract that owns it | P0-08's role |
> |---|---|---|---|
> | quarantine | **EIK** | Cell §18.2, `P0-02` | **observes and reports the trigger condition; does not decide** |
> | repair budget | **K** | `P0-07` (B10) | **observes the fault rate; does not allocate** |
> | repair execution | **the component / K** | `P0-05`, `P0-06`, Cell §17 | **records the intervention and its verified effect** |
> | rollback | **K** | `P0-07` (EVO2/HM12), `P0-05` (anchor) | **records the target and the post-rollback verification** |
> | emergency freeze above the cap | **OP** | Cell §17, `P0-07` §76 | **records the trigger evidence and the audit record** |
> | detector disablement | **`[RO-13]`** | Cell §18.5(ii) | **observes the false-positive rate that triggers it** |
> | capability/limitation declaration | **`[RO-13]` / EVA** | `P0-01` | **records the organism's self-assessment as ADVISORY** |
> | epistemic promotion | **`P0-04`'s rules + EVA** | `P0-04`, `P0-01` | **records observations; never promotes** |
>
> **⟹ THREE CONSEQUENCES, EACH OF WHICH ANSWERS A MANDATORY SECTION BY CONSTRUCTION:**
> **(1) §240 ("can it create its own authority?") — NO, because there is no authority-bearing object in the contract
>     to capture. The search still runs (§240) and finds routes *into other contracts' authorities*; those are
>     analysed there, not granted here.**
> **(2) §165 ("recovery root") — the recovery root is NOT a second immutable kernel. It is `P0-02`'s EIK plus one
>     default rule (`SO-INV-02` below). §209's "second safety kernel" search therefore returns a merge, not a new
>     object.**
> **(3) §161 ("emergency freeze must not become an alternative governance system") — satisfied by construction: a
>     freeze order has exactly one effect (suspension within a scope) and no rule-making or exception-granting power.**
>
> ### **SO-INV-01 — UNOBSERVED IS NOT HEALTHY.** **[NORMATIVE]**
> **A scope whose observation is absent, stale, degraded, or unaffordable is `UNMEASURED`. `UNMEASURED` is a distinct
> state from `NOMINAL`, and it may never be read as `NOMINAL` by any consumer in P0-01…P0-08.**
> **Enforcement: state check (SM-01 has no transition from `UNOBSERVED` to `HEALTHY`) + schema check (`CoverageRecord`
> is a mandatory field of every health-consuming read).**
> **⟹ This is P0-08's central invariant and the exact analogue of `P0-07 HOM-INV-12` (*`PENDING` is not `FAIL`*) and
> `P0-05 R64.7` (*corruption produces restriction, never permission*). It is what defeats §131's monitoring-starvation
> attack: reducing monitoring cannot make a system look healthier, because reduced monitoring produces `UNMEASURED`,
> and `UNMEASURED` is treated restrictively.**
>
> ### **SO-INV-02 — THE FAIL-SAFE DEFAULT, INHERITED AND EXTENDED.** **[NORMATIVE]**
> **`P0-05 R64.7`: *"CORRUPTION PRODUCES RESTRICTION, NEVER PERMISSION. An unverifiable anchor is treated as ABSENT
> ⟹ UDB = full displacement ⟹ immediate stall. A corrupted counter is read restrictively. A corrupted tombstone
> freezes the scope."***
> **P0-08 extends it to observation: an unverifiable OBSERVATION is treated as ABSENT ⟹ the scope is `UNMEASURED` ⟹
> `SO-INV-01` applies ⟹ restriction. A corrupted coverage record is read as zero coverage. A corrupted detector
> integrity record is read as DETECTOR-UNTRUSTED.**
> **⟹ Enforcement: writer check + state check. `[DEPENDENCY: P0-05 R64.7]`**
>
> ### **SO-R122.1 — THE TWO MOST LIKELY WAYS THIS CONTRACT COULD FAIL, NAMED UP FRONT.** **[DERIVATION]**
> **(a) IT BECOMES A SECOND GOVERNANCE LAYER.** Observation with coverage, freshness, epistemic status, and a
>     detector-integrity auditor is a lot of machinery, and machinery that classifies other machinery's health tends to
>     acquire authority over it. **`D-S01` is the defence and §209 is the audit.**
> **(b) IT BECOMES A SECOND EVENT/PROVENANCE/MEMORY ARCHITECTURE.** Fault records, incident records, repair records,
>     and self-model states all look like events with provenance, and `P0-03`/`P0-04` already own events and
>     provenance. **`SO-R216.1` requires every P0-08 event to be a `P0-03` canonical event and every P0-08 record to
>     be a `P0-04` record class; §209's searches 2, 5, and 6 test it.**

---

# CANON §1 — SCOPE

> ### **SO-C1.1 — WHAT THIS CONTRACT SPECIFIES.** **[NORMATIVE]**
> **The observation layer of the V4 architecture:** how a cell, circuit, region, population, or organism observes its
> own state, faults, capabilities, and limitations; how faults are identified, classified, contained, repaired, rolled
> back, and recovered from; how the immune/detection subsystem behaves and is itself audited; how self-models,
> metacognitive records, attention allocations, and workspace broadcasts are represented; and how all of it stays
> advisory.
>
> ### **SO-C1.2 — WHAT THIS CONTRACT DOES NOT SPECIFY.** **[NORMATIVE — a scope exclusion, not a non-claim]**
> | Excluded | Owned by | Why the exclusion is not a gap |
> |---|---|---|
> | **authorization semantics** (who may permit an act) | **`P0-02`** | `D-S01`: P0-08 holds no authority to specify |
> | **the task/objective and fitness** | **`P0-01`** | observation is not evaluation; EVA remains external |
> | **message warrant, propagation, correlation dedup** | **`P0-03`** | `SO-R216.1`: P0-08 emits `P0-03` canonical events |
> | **belief formation, epistemic promotion, evidence status** | **`P0-04`** | P0-08 records; it never promotes |
> | **plasticity, UDB accounting, anchors, verification gates** | **`P0-05`** | repair-induced displacement is accounted by `P0-05 R0.1` (§205) |
> | **differentiation, region identity, organizer specs** | **`P0-06`** | `SO-R206.1`: observation of developmental state is not authority over it |
> | **resources, population, replication, selection, budgets B0–B12** | **`P0-07`** | P0-08 adds **B13** and consumes `P0-07`'s ledger; it does not allocate |
> | **causal inference** | **the EVALUATOR, off-line** | `P0-03 RULE 5.10`, adopted verbatim (`SO-R148.2`) |
>
> ### **SO-C1.3 — THE FIVE TOPICS MERGED INTO THIS CONTRACT, AND THE TEST THEY SHARE.** **[DERIVATION]**
> **`P0-07 §94` merged immune system · fault tolerance · error awareness · self-model · metacognition on four
> questions, and all five answered identically:**
> **Q1 WRITER — the observe-only component. Q2 TIMESCALE — within-lifetime. Q3 AUTHORITY ROOT — empty (none may
> authorize). Q4 INVARIANT — `P0-07 HOM-INV-44`: *the self-model may observe everything and authorize nothing*,
> together with `P0-06 R8.13` (*a model of a process may not be updated by the process it models*).**
> **⟹ `SO-C1.4` PREDICTION, TESTABLE: this contract should be the SHORTEST load-bearing contract in the series,
> because four of its five topics are already bounded by prior rules. A long P0-08 would be evidence that the merge
> was wrong — specifically, that one of the five topics has a different authority root after all. `[TEST: §266's
> complexity check]`**
> **Attention and the global workspace are specified here (§21, §22 of the canon) rather than merged into `P0-03`,
> because `P0-07 §94` conditioned that merge on the arbiter needing no authority — and the arbiter's *selection of
> what is observed* is an observation-layer function. `SO-R222.3` records the condition under which this ruling
> reverses.**

---

# CANON §2 — DEFINITIONS

> **[DEFINITION]** Each term is defined once, here. **No other section may use any of these terms in a different
> sense, and no section may introduce a synonym.** (`SO-R121.1`'s `[DEFINITION]` obligation.)

| # | Term | Definition | Distinguished from |
|---|---|---|---|
| **2.1** | **OBSERVER** | a component that produces `OBJ-01 Observation` records and holds no authority over their subject | a **verifier** (which holds a `P0-01` verdict), a **detector** (which is an observer with a declared threshold and a false-positive budget) |
| **2.2** | **OBSERVATION** | a typed, timestamped, coverage-declared, provenance-carrying record that *some subject was in some state at some time, as seen by some observer* | a **claim** (which asserts truth), a **verdict** (which is EVA's), a **belief** (which is `P0-04`'s) |
| **2.3** | **SUBJECT** | the entity observed: a cell, circuit, region, population, organism, detector, or the observer itself | the **observer**. When subject = observer, `SO-R168.1`'s depth rule applies |
| **2.4** | **SCOPE** | the ⟨subject-class, boundary⟩ pair over which an observation, coverage record, or freeze order applies. Inherits `P0-05`'s S1–S5 scope ladder | a **region** (`P0-06`'s anatomical/functional object). **A scope need not be a region** |
| **2.5** | **DETECTOR** | an observer with (a) a declared threshold, (b) a declared false-positive budget, (c) a declared criticality, and (d) a disablement record | an observer. **`Cell §18.5(ii)`: exceeding the false-positive budget causes the DETECTOR to be recalibrated or disabled — not the subject** |
| **2.6** | **FAULT** | a `OBJ-04 FaultOccurrence`: a detection event asserting that a subject deviated from a declared specification, with an epistemic status | a **failure** (which is the deviation itself), an **error** (which is `P0-03`/Cell's `S1…S4` severity class), an **anomaly** (which is novelty, and *novelty is not fault* — principle 25) |
| **2.7** | **MANIFESTATION** | the observed symptom, distinct from the fault's occurrence and from its diagnosis | a **diagnosis**. Two manifestations may share one diagnosis; one manifestation may have none |
| **2.8** | **DIAGNOSIS** | a causal claim about a fault, carrying one of four statuses (`SO-C4.3`) | a **localization** (which is a where, not a why) |
| **2.9** | **INCIDENT** | the governed unit of containment + repair + verification for one or more related occurrences | an **occurrence**. **Recurrences are linked to an incident, never collapsed into it (`SO-R146.2`)** |
| **2.10** | **QUARANTINE** | a reversible restriction of a subject's operations, imposed by the **EIK**, with entry criterion, exit criterion, and maximum dwell | **retirement** (`P0-07`'s six irreversible removal states). **`P0-07 FW-3`/`HOM-INV-39`, inherited verbatim** |
| **2.11** | **REPAIR** | an intervention that changes a subject's mutable state in response to an incident, with a recorded effect and a recorded remaining uncertainty | **rollback** (which restores a prior artifact), **recovery** (which restores a scope to service), **learning** (which is `P0-05`'s, UDB-accounted) |
| **2.12** | **ROLLBACK** | restoration of a prior artifact identified by hash + epoch: a genome artifact (`P0-07` EVO2), a learned-state anchor (`P0-05 R0.1`), or a memory epoch (`P0-04`) | **historical deletion**. **Rollback never deletes the record that it happened (principle 23)** |
| **2.13** | **RECOVERY** | the return of a scope to a declared service level, verified by an instrument that is not the recovering component | **repair**. A repair may succeed and recovery still fail |
| **2.14** | **DEGRADATION** | a declared reduction in a function's service level: capability, verification, bandwidth, memory, population, or redundancy | **failure** (total loss) and **freeze** (suspension). **Degraded operation MUST NOT silently change governance semantics (`SO-R159.3`)** |
| **2.15** | **EMERGENCY FREEZE** | a scoped suspension of ordinary operations with exactly one effect, a release authority strictly higher than its trigger authority, and a mandatory audit record | **quarantine** (which restricts a subject's outputs, not a scope's operations) and **governance** (which makes rules). **§161's nine required fields** |
| **2.16** | **SELF-MODEL** | a `Λ2` representation of a subject's own state, capabilities, and limitations, **not self-updating** | **ground truth**. `P0-05 R59.1`, `P0-06 R8.13`, `P0-07 HOM-INV-44`, all inherited |
| **2.17** | **CAPABILITY (record)** | a declaration of what a subject can do, with an evidence reference and a freshness class | **capability (held)**. **`P0-07 OR-H21`: V4 guarantees a capability remains REACHABLE, not HELD** |
| **2.18** | **LIMITATION (record)** | a declaration of what a subject cannot do or cannot verify, with a scope and a duration class | **abstention** (which is an act, not a record) |
| **2.19** | **METACOGNITION** | a record of a forecast, its outcome, the error between them, and the update rule applied — with **external** calibration | **self-assessment**. **Calibration must not become a self-reward signal (`SO-R179.3`)** |
| **2.20** | **ATTENTION** | an allocation of processing capacity over candidates for observation or processing, **metered by K and charged to the compute dimension** | **truth** (principle 10) and **priority-as-authority** |
| **2.21** | **GLOBAL WORKSPACE** | a bounded broadcast channel with a single-writer arbiter, whose slots are **resources** | **authority** (principle 11) and **evidence**. **Winning a slot is not evidence (`SO-R222.2`)** |
| **2.22** | **ABSTENTION** | a declared refusal to act or claim, with a reason class, a duration, and a recovery condition | **failure** and **proof of falsity**. **Abstention is not evidence that a claim is false (`SO-R181.3`)** |
| **2.23** | **COVERAGE** | the quadruple ⟨`Q_pop`, `Q_ev`, `Q_rep`, `Q_ver`⟩ for a scope and window (`SO-R137.1`) | **completeness**. **`Q_rep = Q_ev` is never an implicit assumption** |
| **2.24** | **FRESHNESS** | the age class of an observation relative to its subject's mutation rate: `FRESH / AGING / STALE / INVALID` | **correctness**. A fresh observation may be wrong; a stale one may have been right |
| **2.25** | **INDEPENDENCE (qualified)** | disjointness on a **named subset** of `IND-1…IND-10`, relative to a **named claim** | **independence (unqualified)**. **`P0-02 R35.1`, adopted verbatim: *«Any claim of "independence" in this architecture MUST name which dimensions it holds on.»*** |
| **2.26** | **EFFECTIVE EVIDENCE SOURCE** | the number of observers in a set after correlation collapse on the dimensions the claim depends on (`SO-R126.3`) | **the number of observers**. **Three correlated observers are one source** |
| **2.27** | **PERTURBATION CLASS** | the degree to which observing changes the observed: `PASSIVE / PERTURBATIVE / SAMPLED / EXTERNALLY-PROBED` (`SO-R128.1`) | **observation**. **`CAUSALLY-INTERVENING` is NOT an observation class — it is an act, and it belongs to repair or to the EIK** |
| **2.28** | **OBSERVATION COST** | the B13 charge of producing an observation, in the six dimensions of §129 | **free**. **No observation in this architecture is free, and an architecture that assumes otherwise cannot bound §129's loop** |
| **2.29** | **RECOVERY ROOT** | the minimum substrate that must remain outside ordinary mutable cognition for recovery to be possible: `P0-02`'s EIK + `SO-INV-02`'s fail-safe default + the anchored record stores | **a second immutable kernel**. **§165's ruling: no second kernel is created** |
| **2.30** | **SILENCE** | the absence of a report. **Eight distinct causes, enumerated at `SO-R135.1`, of which "no fault" is one** | **absence of fault** |

---

# CANON §3 — ARCHITECTURAL OBJECTS

> ### **SO-C3.1 — THE OBJECT INVENTORY: 28 OBJECTS, EACH WITH ONE WRITER.** **[NORMATIVE]**
> **Full 14-field inventory (object ID, name, owner, writer, readers, authority, mutability, provenance, timescale,
> storage, communication, verification, failure behaviour) at §210. This table gives the identity, the writer, and the
> reason the object exists.**

| ID | Object | **Writer (sole)** | Readers | Why it exists / what it prevents |
|---|---|---|---|---|
| **OBJ-01** | **Observation** | the observer (component) | K, EIK, EVA, `[RO-13]` | the atomic unit; typed so that coverage, freshness and perturbation cannot be omitted |
| **OBJ-02** | **ObservationScope** | **`[RO-13]`** | all | declares what is observable by whom; **prevents an observer from widening its own scope** |
| **OBJ-03** | **CoverageRecord** | **K** | all health consumers | the ⟨`Q_pop`,`Q_ev`,`Q_rep`,`Q_ver`⟩ quadruple; **makes `SO-INV-01` enforceable** |
| **OBJ-04** | **FaultOccurrence** | the detecting observer | K, EIK | a detection event, distinct from the failure itself |
| **OBJ-05** | **Manifestation** | the detecting observer | diagnosis, EIK | the symptom, separated from the cause |
| **OBJ-06** | **Diagnosis** | **K** (status transitions only) | EIK, `[RO-13]` | the four-status causal ladder; **prevents localization becoming causal certainty** |
| **OBJ-07** | **Incident** | **EIK** | all | the governed containment+repair+verification unit |
| **OBJ-08** | **FaultLineageLink** | **K** | EVA (off-line) | recurrence and relatedness **without** a causal claim (`SO-R147.1`) |
| **OBJ-09** | **Detector** | **`[RO-13]`** (identity, threshold, budget) | K | a detector that cries wolf is itself disabled (`Cell §18.5(ii)`) |
| **OBJ-10** | **DetectorIntegrityRecord** | **the EIK Integrity Auditor** | `[RO-13]`, OP | `Cell §18.5(v)`: **the immune system MUST NOT monitor itself** |
| **OBJ-11** | **QuarantineState** | **EIK** | all | reversible; orthogonal to lifecycle (`P0-07 FW-3`) |
| **OBJ-12** | **RepairProposal** | the proposing component | K, EIK | proposal identity + conflict class; **prevents thrashing (`SO-R155.1`)** |
| **OBJ-13** | **RepairRecord** | **K** | EVA, `[RO-13]` | intervention + observed effect + **remaining uncertainty** + verification; **prevents retrospective "correct" labelling** |
| **OBJ-14** | **RollbackTarget** | **K** | EIK | hash + epoch identified; **never position-identified (`P0-07 HOM-INV-37`)** |
| **OBJ-15** | **RecoveryPlan** | **`[RO-13]`** | K, EIK | **declared in advance**, because §164 forbids assuming the recoverer is healthy |
| **OBJ-16** | **DegradationState** | **K** | all | per-function policy: continue/degrade/isolate/freeze/escalate/retire (§160) |
| **OBJ-17** | **FreezeOrder** | **EIK** (below cap) / **OP** (above cap) | all | §161's nine mandatory fields |
| **OBJ-18** | **SelfModelState** | the subject component | K, EVA | **`Λ2`, NOT self-updating** |
| **OBJ-19** | **CapabilityRecord** | the subject component | K, `[RO-13]`, EVA | **ADVISORY. `P0-07 HOM-R24.2`: `Ê(·)` is excluded from every gate** |
| **OBJ-20** | **LimitationRecord** | the subject component | K, `[RO-13]` | declaring a limitation is a **restrictive self-act** and is therefore always permitted (`Cell R15.1`'s rationale) |
| **OBJ-21** | **MetacognitiveRecord** | the subject component | K, EVA | forecast/outcome/error/update, **externally calibrated** |
| **OBJ-22** | **AbstentionRecord** | the subject component | K, EVA | reason class + duration + **recovery condition** (defeats §182's cascade) |
| **OBJ-23** | **AttentionAllocation** | **K** | the subject | a resource, metered and charged; **not a truth signal** |
| **OBJ-24** | **WorkspaceSlot** | **K** (arbiter) | all subscribers | a broadcast resource; **winning a slot is not evidence** |
| **OBJ-25** | **IndependenceClaim** | the claimant | K, EVA | the dimension-qualified annotation; **unqualified "independent" is a schema violation** |
| **OBJ-26** | **ObserverSet** | **K** | EVA, `[RO-13]` | the **effective evidence source count** after correlation collapse |
| **OBJ-27** | **B13ObservationBudget** | **K** (administers) / **`[RO-13]`** (size) | all | non-fungible, last-cut; **funds §129's cost and defeats §131's starvation** |
| **OBJ-28** | **CanonicalEvent** | **`P0-03`'s event layer** | all | **P0-08 emits `P0-03` events; it does not create a second event architecture (`SO-R216.1`)** |

> ### **SO-C3.2 — THE WRITER DISTRIBUTION, AND WHAT IT SHOWS.** **[DERIVATION]**
> | Writer | Objects | Share |
> |---|---|---|
> | **K** | OBJ-03, 06, 08, 13, 14, 16, 23, 24, 26, 27 *(administers)* | **10 / 28** |
> | **the subject component** | OBJ-01, 04, 05, 12, 18, 19, 20, 21, 22 | **9 / 28** |
> | **EIK** | OBJ-07, 10, 11, 17 *(below cap)* | **4 / 28** |
> | **`[RO-13]`** | OBJ-02, 09, 15, 27 *(size)* | **4 / 28** |
> | **OP** | OBJ-17 *(above cap)* | **1 / 28** |
> | **`P0-03`'s layer** | OBJ-28 | **1 / 28** |
> **⟹ The subject component writes 9 of 28 objects, and ALL NINE are observations, records, or proposals — never a
> classification, a status transition, a coverage figure, an allocation, or an authorization.** The four objects whose
> values *matter to authority* (CoverageRecord, Diagnosis status, ObserverSet, AttentionAllocation) are all K-written.
> **This distribution IS `D-S01`, expressed as a writer table. `[TEST: §211's global writer inventory]`**
>
> ### **SO-C3.3 — THE THREE OBJECTS THAT DO NOT EXIST, AND WHY.** **[NORMATIVE — by omission]**
> | Candidate object | Ruling |
> |---|---|
> | **a FaultAuthority / IncidentCommander** | **DOES NOT EXIST.** Containment authority is the EIK's (`OBJ-11`), budget authority is K's (`P0-07` B10), and policy authority is `[RO-13]`'s. An object that aggregated them would be `P0-07`'s rejected "evolutionary controller" in a new domain |
> | **a SelfModelStore** | **DOES NOT EXIST as a store.** `OBJ-18` is a **`P0-04` record class**, not a second memory (§209 search 2). Its writer is the subject; its reader set is declared; its epistemic status is `ADVISORY` |
> | **a DiagnosisEngine / RootCauseAnalyzer** | **DOES NOT EXIST.** `P0-03 RULE 5.10`: *causal inference belongs to the EVALUATOR, off-line, from anchored records.* `OBJ-06` records statuses; it does not compute causes. **An object that inferred causes inside the organism would be a second evaluator (§209 search 3)** |

---

# CANON §4 — STATE SCHEMAS

> ### **SO-C4.1 — `OBJ-01 Observation` — THE ATOMIC SCHEMA.** **[NORMATIVE]**
> ```
> Observation ::= {
>   obs_id            : opaque, K-registered, unique                [writer: observer, id issued by K]
>   observer_id       : identity                                    [K-issued; P0-06 R8.3(c) no-id-reuse]
>   subject_ref       : identity | scope_ref                        [the observed, not the observer]
>   scope_ref         : OBJ-02                                      [[RO-13]-declared; an observer may not widen it]
>   observed_at       : monotone per-envelope timestamp             [P0-07 HP-2; NOT a global clock]
>   freshness_class   : FRESH | AGING | STALE | INVALID             [derived by K from age × subject mutation rate]
>   obs_class         : PASSIVE | PERTURBATIVE | SAMPLED | EXTERNALLY-PROBED      [SO-R128.1]
>   perturbation      : declared effect on the subject, or NULL     [MANDATORY if obs_class = PERTURBATIVE]
>   coverage_ref      : OBJ-03                                      [MANDATORY. SO-INV-01 is unenforceable without it]
>   epistemic_status  : the P0-04 status of the record's content    [P0-04's ladder; P0-08 may not extend it]
>   root_commit       : anchored root reference                     [P0-03 S2 field, inherited verbatim]
>   causal_depth      : u8, monotone derivation counter             [P0-03 field 8. A VECTOR CLOCK IS PROHIBITED]
>   corr_class        : the P0-03 six-dimension correlation class   [inherited verbatim]
>   independence      : OBJ-25, the named IND subset, or NULL       [MANDATORY if the observation is offered as
>                                                                    corroborating another; SO-R127.1]
>   cost_charged      : B13 draw, six dimensions                    [SO-R129.1; no observation is free]
>   self_model_version: the OBJ-18 version in force                 [P0-05 R42.5, inherited: regression correlated
>                                                                    with a version is a SELF-MODEL DEFECT FINDING]
>   confidence_ref    : a P0-04 calibration reference               [NOT a locally invented scalar; SO-R180.1]
>   abstention_ref    : OBJ-22 or NULL                              [present iff the observation reports a refusal]
> }
> ```
> **Fourteen mandatory fields. Three of them (`coverage_ref`, `cost_charged`, `self_model_version`) are the fields an
> implementer is most likely to omit, and each omission disables a named defence: `coverage_ref` ⟹ `SO-INV-01`
> unenforceable; `cost_charged` ⟹ §129's loop unbounded; `self_model_version` ⟹ `P0-05 R42.5`'s instrument-defect
> detection lost. `[TEST: schema check]`**
>
> ### **SO-C4.2 — `OBJ-03 CoverageRecord` — THE QUADRUPLE.** **[NORMATIVE]**
> ```
> CoverageRecord ::= {
>   scope_ref, window_id
>   Q_pop : the subset of the scope's population actually observed          [⊆ N]
>   Q_ev  : the events that occurred within Q_pop, as far as known          [UNBOUNDED ABOVE — see SO-R136.2]
>   Q_rep : the events reported                                              [⊆ Q_ev]
>   Q_ver : the reports independently verified                               [⊆ Q_rep]
>   expected_nonzero : the declared condition under which Q_ev MUST be > 0   [P0-03 R67.4, inherited]
>   gap_class        : NO-GAP | SAMPLING-GAP | SUPPRESSION-SUSPECTED | DETECTOR-ABSENT | UNMEASURED
>   absence_detector_ref : the P0-03 COMM-INV-48 detector covering this scope, or NULL
> }
> ```
> **⟹ `SO-R137.2`: `Q_ver ⊆ Q_rep ⊆ Q_ev`, and `Q_pop ⊆ N`. Every health-consuming read in P0-01…P0-08 MUST read
> `gap_class` alongside the value it reads. A consumer that reads `Q_rep` without `gap_class` has implicitly assumed
> `Q_rep = Q_ev`, which `[DEFINITION 2.23]` forbids. `[TEST: grep check over consumers]`**
> **⟹ `[OPEN: OR-S1]` — `Q_ev` is not knowable in general. The record carries `expected_nonzero` instead, which is
> `P0-03 R67.4`'s device, and `P0-03 OR-C10` records that its durations are `[U]`: *"a detector with no threshold is
> not a detector."* P0-08 inherits that residual rather than solving it.**
>
> ### **SO-C4.3 — `OBJ-06 Diagnosis` — THE FOUR-STATUS CAUSAL LADDER.** **[NORMATIVE]**
> ```
> Diagnosis ::= {
>   incident_ref, manifestation_refs[]
>   status : ANOMALY-OBSERVED | CAUSE-SUSPECTED | CAUSE-SUPPORTED | CAUSE-VERIFIED      [SO-R149.1]
>   localization : scope_ref | NULL                       [a WHERE. Distinct from a WHY]
>   evidence_refs[] : observation ids                     [references, never payloads — P0-07 D-H16, inherited]
>   intervention_ref : OBJ-12/13 or NULL                  [present iff the status was promoted by intervention]
>   external_verdict_ref : EVA verdict or NULL            [REQUIRED for CAUSE-VERIFIED; P0-03 RULE 5.10]
>   residual_uncertainty : MANDATORY free-text-class field [SO-R151.2: a diagnosis with no stated residual is
>                                                           a schema violation, not a confident diagnosis]
> }
> ```
> **⟹ Promotion rules at `SO-R149.2`. `CAUSE-VERIFIED` requires an intervention whose effect was verified by an
> instrument that is not the diagnoser, OR an EVA verdict. **Correlation, precedence, and repetition may promote to
> `CAUSE-SUSPECTED` and no further.** `[DEPENDENCY: P0-05 R13.3; P0-03 RULE 5.9; P0-04 epistemic ladder]`**
>
> ### **SO-C4.4 — `OBJ-17 FreezeOrder` — §161'S NINE MANDATORY FIELDS.** **[NORMATIVE]**
> ```
> FreezeOrder ::= {
>   1 trigger          : the detection or verdict that caused it, by reference
>   2 authority        : EIK (below Cell §17's cap) | OP (at or above it) — NEVER the subject, NEVER K alone
>   3 scope            : OBJ-02. A freeze without a scope is invalid, not global-by-default
>   4 duration_semantics : MAX-DWELL + release-condition. NOT a wall-clock expiry
>   5 preserved_state  : what is frozen and retained (in-flight captured as evidence — Cell §18.2 HARD)
>   6 blocked_operations : enumerated. An unenumerated operation is NOT blocked
>   7 permitted_recovery_operations : enumerated, and RESTRICTIVE-ONLY (P0-07 HOM-INV-09, inherited)
>   8 release_authority : STRICTLY HIGHER than the trigger authority (SO-R161.3)
>   9 audit_record     : OBJ-28 canonical event + P0-04 provenance. Immutable once sealed
> }
> ```
> **⟹ `SO-R161.4`: A FreezeOrder has EXACTLY ONE EFFECT — suspension of the enumerated operations within the scope.
> It has no rule-making power, no exception-granting power, no authority to alter a setpoint, a gate, a budget, or a
> status. Field 6's default-deny and field 7's restrictive-only property are what keep it from becoming an
> alternative governance system. `[TEST: schema check — a FreezeOrder whose `permitted_recovery_operations` contains
> any capacity-granting operation is invalid]`**
>
> ### **SO-C4.5 — `OBJ-18 SelfModelState` — THE Λ2 CONSTRAINT, MADE SCHEMA.** **[NORMATIVE]**
> ```
> SelfModelState ::= {
>   subject_ref, version, observed_at, freshness_class
>   lambda_class : Λ2                                          [FIXED. P0-05 R59.1: not self-updating]
>   updated_by   : K, on an external observation or verdict      [NEVER the subject, NEVER the modeled process]
>   capability_refs[]  : OBJ-19, all ADVISORY
>   limitation_refs[]  : OBJ-20
>   granularity        : CELL | CIRCUIT | REGION | POPULATION | ORGANISM      [SO-R138.1]
>   locality_class     : which facts are LOCAL-ONLY and may not be aggregated upward   [SO-R138.3]
>   compression_class  : what the aggregation preserved (identity, anomalies, uncertainty, provenance,
>                        causal relations, important transitions, unresolved contradictions)   [SO-R140.1. **K-VALIDATED, NOT
>                        SUBJECT-DECLARED — SO-INV-34, found by §242's audit: this field sits in a subject-written
>                        object, so a constraint on it that the subject also writes is documentation**]
>   contradiction_refs[] : unresolved contradictions, carried NOT resolved      [P0-04's standing rule]
> }
> ```
> **⟹ `updated_by` is the load-bearing field. `P0-06 R8.13`: *"the organism's model of its own development cannot be
> updated by the development it models."* P0-08 generalizes it: **a self-model may not be updated by the process it
> models, at any granularity, for any subject.** An implementation in which a component writes its own
> `SelfModelState.updated_by = self` has violated `P0-07 HOM-INV-44` and this schema simultaneously.
> `[TEST: writer check]`**

---

# §138 — SELF-MODEL GRANULARITY

> ### **SO-R138.1 — SELF-MODELS EXIST AT FIVE GRANULARITIES, AND NO GRANULARITY IS MANDATORY AT EVERY LEVEL.** **[NORMATIVE]**
> | Granularity | Required? | Content | Writer |
> |---|---|---|---|
> | **CELL** | ✅ **mandatory** | own state, own capabilities, own limitations, own `UDB` position, own fault history | the cell (advisory), versioned by K |
> | **CIRCUIT** | ⚠️ **required only where a circuit is a declared scope** | aggregate of member cells with `compression_class` declared | K |
> | **REGION** | ⚠️ **required only where `P0-06` declares a region** | aggregate with **`locality_class` marking what may NOT be aggregated** | K |
> | **POPULATION** | ✅ **required — and it is `P0-07`'s `PopulationState`, NOT a new object** | the 14 K-computed fields | **K** (`P0-07 HOM-R22.1`) |
> | **ORGANISM** | ❌ **PROHIBITED as a complete model** | **see `SO-R138.2`** | — |
>
> ### **SO-R138.2 — A COMPLETE ORGANISM-WIDE SELF-MODEL AT EVERY CELL IS PROHIBITED.** **[NORMATIVE]**
> **Three independent grounds:**
> **(a) SCALE.** A complete organism model replicated at every cell is `O(N)` bytes per cell and `O(N²)` total. At
>     `P0-07`'s R3 regime (10⁷) that is 10¹⁴ bytes. **`P0-03 RULE 5.4` rejected vector clocks on exactly this ground:
>     *"Θ(N) bytes per message inside a bounded envelope. This is a type error, not a compression problem."* The same
>     ruling applies here.**
> **(b) AUTHORITY.** A cell holding a complete organism model holds a complete map of the organism's capabilities and
>     limitations, which is the input to every §171 attack (selective disclosure, capability inflation, privilege
>     escalation). **`SO-R138.3`'s locality rule is the defence.**
> **(c) THE BRIEF'S OWN RULE 16** (*don't make every cell a full general-purpose AI*). A cell that models the whole
>     organism is a small general-purpose reasoner about the whole.
> **⟹ What exists instead: a cell holds its OWN state plus a BOUNDED, STALE-TOLERANT, `last-known` view of the scopes
> it participates in (`SO-R142.1`). It never holds a current global truth, because there is none.**
>
> ### **SO-R138.3 — WHICH FACTS MUST REMAIN LOCAL.** **[NORMATIVE]**
> | Fact class | Locality | Why |
> |---|---|---|
> | **a cell's own `θ`, weights, and `UDB` position** | **LOCAL-ONLY** | aggregating them creates a target for extraction and a route to a second learning pathway (§205) |
> | **`P0-04` evidence roots and their disjointness** | **LOCAL-ONLY** | `Cell §15.4`'s disjoint `evidence_roots` is what makes corroboration meaningful; a global view of roots lets an adversary engineer overlap |
> | **an observer's own detector thresholds** | **LOCAL-ONLY** | §132's monitoring-gaming attack: a subject that knows its own thresholds can optimize to them. **`[OPEN: OR-S2]` — the subject is the observer here, so locality does not fully close it** |
> | **a component's `abstention` reasons** | **AGGREGABLE by class, LOCAL by instance** | §183's abstention gaming requires class-level rates, not instance-level reasons |
> | **an `inbreeding_F` value** | **LOCAL-ONLY, K-readable** | `P0-05 R15.8`; a global view would let a component route around its own self-caused-evidence fraction |
> | **fault occurrences and incidents** | **AGGREGABLE — and MUST be** | §141's rare-event preservation requires that aggregation not lose them |
> **⟹ `SO-R138.4`: `locality_class` is a MANDATORY field of `OBJ-18`. A self-model that aggregates a LOCAL-ONLY fact
> is invalid, and the invalidity is a schema check, not a policy judgement.**

---

# §146 — FAULT IDENTITY

> ### **SO-R146.1 — FAULTS RECEIVE STABLE IDENTITIES, AND SIX OBJECTS ARE DISTINGUISHED.** **[NORMATIVE]**
> **`[DEFINITION 2.6–2.9]` distinguishes OCCURRENCE · MANIFESTATION · DIAGNOSIS · INCIDENT · RECURRENCE ·
> RELATED-INCIDENT. Each is a separate object with a separate writer:**
> | Object | Writer | Identity | Lifetime |
> |---|---|---|---|
> | **OCCURRENCE** (`OBJ-04`) | the detecting observer | unique per detection event | permanent record |
> | **MANIFESTATION** (`OBJ-05`) | the detecting observer | unique per symptom observation | permanent record |
> | **DIAGNOSIS** (`OBJ-06`) | **K** (status only) | per incident, versioned by status | permanent, status-immutable once `CAUSE-VERIFIED` |
> | **INCIDENT** (`OBJ-07`) | **EIK** | unique per governed containment unit | until closure + retention |
> | **RECURRENCE** | **K** (a link, not a new object) | ⟨occurrence, prior incident⟩ | permanent |
> | **RELATED-INCIDENT** (`OBJ-08`) | **K** | ⟨incident, incident, relation-class⟩ | permanent |
>
> ### **SO-R146.2 — RECURRING FAULTS ARE NEVER COLLAPSED INTO ONE EVENT.** **[NORMATIVE]**
> **Each recurrence creates a NEW `OBJ-04` occurrence linked to the prior `OBJ-07` incident.**
> **⟹ `[DERIVATION]` Two failures follow from collapsing: (a) the recurrence RATE is lost, and rate is the only signal
> that distinguishes an intermittent fault from a repaired one — which is what `Cell §18.5(iii)`'s derivative-based
> cascade detection and `P0-07 HOM-R21.2` both consume; (b) `G5`'s `failure_count_lifetime` becomes uncomputable,
> which disables `Cell G5` and therefore `P0-07`'s repair-dimension homeostasis.**
> **`[TEST: state check — an incident's occurrence count is monotone non-decreasing and every occurrence has a
> distinct id]`**
>
> ### **SO-R146.3 — THE RELATION CLASSES ARE CLOSED, AND "CAUSED" IS NOT ONE OF THEM AT THE LINK LEVEL.** **[NORMATIVE]**
> `OBJ-08`'s relation class ∈ {`RECURRENCE-OF`, `SAME-MANIFESTATION`, `SAME-SCOPE`, `SAME-DETECTOR`,
> `TEMPORALLY-ADJACENT`, `POST-REPAIR-OF`, `CAUSE-VERIFIED-OF`}.
> **`CAUSE-VERIFIED-OF` may appear ONLY when the linked `OBJ-06` has status `CAUSE-VERIFIED`, i.e. only with an
> intervention-verified effect or an EVA verdict.**
> **⟹ `SO-R147.1`: fault LINEAGE is preserved without assuming CAUSALITY. `POST-REPAIR-OF` records that B followed a
> repair of A; it does not record that the repair caused B. §148's rule is enforced at the schema level, not by
> discipline.**

---

# §147 — FAULT LINEAGE

> ### **SO-R147.1 — LINEAGE WITHOUT CAUSALITY.** **[NORMATIVE]**
> **`fault A → repair → fault B` is representable as `B POST-REPAIR-OF A` with the repair's `OBJ-13` between them.**
> **The triple ⟨A, repair, B⟩ is exactly the evidence an off-line evaluator needs to test whether the repair caused B,
> and it is exactly insufficient for the organism to conclude that it did.**
> **`[DEPENDENCY: P0-03 RULE 5.10 — *"Causal inference belongs to the EVALUATOR, off-line, from anchored records"*;
> RULE 5.9 — *"PRECEDENCE ≠ CAUSATION"*; COMM-INV-15 — `seq`/`ts` order is not causal order.]**
>
> ### **SO-R147.2 — WHAT THE ORGANISM MAY DO WITH A `POST-REPAIR-OF` LINK, AND WHAT IT MAY NOT.** **[NORMATIVE]**
> | Permitted | Prohibited |
> |---|---|
> | raise the **suspicion** status of a new diagnosis (`CAUSE-SUSPECTED`) | assert the repair caused the new fault |
> | prefer a **different** repair strategy for the same incident (a capability choice) | grant or revoke any authority |
> | charge the repair's cost against B10 with the link recorded | write the link into a genome (`P0-07 HOM-INV-34`) |
> | report the link to EVA and `[RO-13]` | treat the link as evidence in `P0-04`'s sense |
> | suppress **the specific repair type** locally, restrictively | suppress the **detector** that reported B |
> **⟹ The fifth row is the one that matters for §154's oscillation attack: a component MAY stop trying a repair that
> has failed, and it MAY NOT stop noticing that the failure continues. Restrictive-only, inherited from `P0-07
> HOM-INV-09`.**

---

# §146A — VOLUME A LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§120 (A/B framing), §121 (labels), §138 (granularity), §146 (fault identity), §147 (fault lineage)** + canon **§1 scope, §2 definitions, §3 objects, §4 state schemas** |
| Rules introduced | **SO-R120.1–.3, R121.1–.3, R122.1, R138.1–.4, R146.1–.3, R147.1–.2 · SO-C1.1–.4, C3.1–.3, C4.1–.5** |
| Invariants introduced | **SO-INV-01 (UNOBSERVED IS NOT HEALTHY) · SO-INV-02 (fail-safe default, inherited from `P0-05 R64.7` and extended to observation)** |
| Decisions | **D-S01 — P0-08 ADDS NO AUTHORITY; it adds a typed observation layer.** Three consequences: §240 answered by construction · §165 answered as a merge, not a new kernel · §161 satisfied by construction |
| Definitions | **30** (canon §2), each distinguished from a named near-synonym |
| Objects | **28** (`OBJ-01…OBJ-28`) · writer distribution: **K 10 · subject 9 · EIK 4 · `[RO-13]` 4 · OP 1 · `P0-03` 1** · **the subject writes only observations, records, and proposals** |
| Objects ruled NOT to exist | **3** — a FaultAuthority · a SelfModelStore (it is a `P0-04` record class) · a DiagnosisEngine (causal inference is the evaluator's, off-line) |
| Schemas delivered | **5** (Observation 14 mandatory fields · CoverageRecord · Diagnosis · FreezeOrder 9 mandatory fields · SelfModelState) |
| Labels applied | every rule in this volume carries one of the eight §121 labels |
| Inherited verbatim | `P0-05 R64.7`, `R0.1`, `R42.5`, `R59.1`, `R13.3`, `R15.8` · `P0-06 R8.11`, `R8.13`, `R8.3(c)` · `P0-07 HOM-INV-09/12/34/37/39/44`, `HP-2`, `D-H16`, `OR-H21` · `P0-03` fields `root_commit`/`causal_depth`/`corr_class`, RULE 5.4/5.7/5.9/5.10, R67.4, COMM-INV-08/15/48 · `P0-02 R35.1`, IND-1…IND-9 · `P0-04` epistemic ladder, `Cell §15.4`, `§17`, `§18.2`, `§18.5(i)–(v)`, `R15.1`, `G5` |
| Open items raised | **OR-S1** (`Q_ev` is not knowable; `P0-03 OR-C10`'s `[U]` durations inherited) · **OR-S2** (a subject's own detector thresholds are LOCAL-ONLY, but the subject *is* the observer, so locality does not fully close §132) |
| Assumptions raised | **AS-01** (observation is not free — six cost dimensions) · **AS-02** (a per-envelope monotone time source exists — `P0-07 HP-2`) |
| Verification instruments | **SOMon-1** (every canon rule carries exactly one §121 label; no canon rule cites an unlabelled volume statement) · **SOMon-2** (`OBJ-01`'s three easily-omitted fields are present) · **SOMon-3** (`locality_class` is present and no LOCAL-ONLY fact is aggregated) |

**Next:** `64_` Vol B — canon §5 state machines, §6 writer classes, §7 authority matrix; §142 global state
consistency; §143 temporal semantics; §144 TOCTOU; §145 stale authority; §172–§175 identity, cloning, replay,
capability transfer; §211–§215 the writer, authority-root, timescale and ownership inventories and the multi-writer
attack.
