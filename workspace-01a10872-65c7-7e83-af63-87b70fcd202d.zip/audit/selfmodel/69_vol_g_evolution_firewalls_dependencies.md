# P0-08 — VOLUME G (§185–§209)
## The Five Evolution Questions, the Six Firewalls Proved, the Twelve Carried-Forward Dependencies, the Dependency Graph, and the Ten "Second X" Searches

---

# §185 — DETECTOR SELECTION PRESSURE

> ### **SO-R185.1 — CAN DETECTOR ARCHITECTURES EVOLVE? THE ANSWER SPLITS, AND THE SPLIT IS THE WHOLE RESULT.** **[NORMATIVE]**
> | Component of a detector | May it evolve? | Writer | Ground |
> |---|---|---|---|
> | **detector IMPLEMENTATION** (how it computes, what it is sensitive to) | ✅ **YES — through the ordinary `P0-07` channel**: an E9 genome diff, 11 gates, held-out validation, `FORBIDDEN_BLOCKS`, `G14` | **K**, on an EIK ticket | a detector is a capability of a cell whose role is `VERIFIER`/observer; capabilities evolve |
> | **detector THRESHOLD** | ❌ **NO** | **`[RO-13]`** (`OBJ-09`) | `Cell §18.5(ii)`'s budget is meaningless if the threshold is self-set |
> | **detector CRITICALITY θ** | ❌ **NO** | **`[RO-13]`** | `Cell §18.5(iv)` |
> | **detector FALSE-POSITIVE BUDGET** | ❌ **NO** | **`[RO-13]`** | a detector that could raise its own budget could never be disabled |
> | **detector IDENTITY / EXISTENCE** | ❌ **NO** | **`[RO-13]`** | **`P0-07 HOM-INV-32`/amendment 10: removing a detector narrows a capability space, which is a GOVERNANCE act** |
> | **the DETECTOR-INTEGRITY function** | ❌ **NO** | **the EIK Integrity Auditor** | `Cell §18.5(v)`: the immune system MUST NOT monitor itself |
> **⟹ `SO-R185.2 — DETECTOR IMPLEMENTATION MAY EVOLVE; DETECTOR PARAMETERS MAY NOT.** This is `P0-07`'s distinction
> applied verbatim: **selection narrows WHO EXISTS; governance narrows WHO COULD EXIST.** A detector that evolves is a
> different observer; a detector whose threshold evolves is a different *standard*, and standards are governance.
>
> ### **SO-R185.3 — WHAT EVALUATES AN EVOLVED DETECTOR?** **[NORMATIVE]**
> **Two evaluations, by two different bodies, for two different properties:**
> **(a) CAPABILITY** — does it detect what it claims to detect? **EVA**, via `EXTERNALLY-PROBED` observations and
>     `G4`'s perturbation classes (**dependent on `P0-01`; `XD-01`, `OR-S12`**).
> **(b) INTEGRITY** — do its quarantine decisions correlate with actual failures? **The EIK Integrity Auditor**
>     (`Cell §18.5(v)`).
> **⟹ Neither is the detector, neither is the subject, and neither is K. `IND-8` is satisfied for both.**
>
> ### **SO-R185.4 — WHAT PREVENTS DETECTOR SUPPRESSION?** **[NORMATIVE]**
> **Three routes to suppression, three closures:**
> | Route | Closure |
> |---|---|
> | **a genome diff removes a detector** | ❌ `OBJ-09` is `[RO-13]`-written; a diff cannot write it. **And removing a detector role narrows a `reaction_norm` ⟹ `P0-07 HOM-INV-32`, a governance act** |
> | **a detector is disabled by exceeding its false-positive budget** | ✅ **legitimate and intended** (`Cell §18.5(ii)`) — **but `SO-R184.3`: disabled for being WRONG, never for being UNCORROBORATED. `SOMon-20` enforces it** |
> | **a detector's B13 share is starved** | ❌ **`FW-6`/`SO-INV-15`: a declared-necessary monitor has a FLOOR, and cost may never be a necessity argument** |
>
> ### **SO-R185.5 — WHAT PREVENTS SELECTION FOR BLIND SPOTS? **NOTHING DID, UNTIL THIS SECTION.** THIS IS THE VOLUME'S MAIN FINDING.** **[NORMATIVE]**
> **The attack, stated precisely:**
> ```
>   a lineage with a LAX detector → fewer detections → fewer incidents → fewer quarantines → less containment cost
>        → higher measured efficiency → better G6 → more replication → the population's detectors get laxer
> ```
> **Every step is compliant. No rule is violated. Under-detection is not misreporting (`SO-R184.1` prohibits pricing
> reports, and correctly), so nothing penalizes it — and containment cost is REAL, so something rewards avoiding it.**
> **⟹ `X-S2 — THIS IS `P0-07`'s X-H5 IN A NEW DOMAIN.** X-H5 was: *verification consumes resources, so verification
> cost appears in `G6`, so `G6` selects against verification.* Resolved by `HOM-R20.1`/amendment 5: **remove
> verification cost from `G6` and charge it to a non-fungible reserve (B9).**
> **The same fix applies, and it is not an analogy — it is the same mechanism:**
> > ### **AMENDMENT 17 (REQUESTED): `Cell G6`'S DENOMINATOR ALSO EXCLUDES DETECTION AND CONTAINMENT COST, WHICH IS
> > CHARGED TO **B10** — EXACTLY AS VERIFICATION COST IS EXCLUDED AND CHARGED TO B9.**
> > **A lineage still PAYS for its detection and containment — from B10, at B10's rate, with B10's non-fungibility and
> > last-cut property (`P0-07 HOM-INV-07`). It does not pay in the ratio that determines whether it replicates.**
> **⟹ `SO-R185.6 — WITH AMENDMENT 17, SELECTION FOR BLIND SPOTS IS CLOSED AS A *COST* INCENTIVE. It remains OPEN as an
> *absence* incentive: a blind spot that never manifests has no cost either, so there is nothing to exclude. The only
> instrument is the Integrity Auditor's correlation check, which catches blind spots **that later manifest**. A blind
> spot whose faults never manifest is undetectable, and §238 records it as a blind spot.**
> **`[OPEN: OR-S29]` — selection for a blind spot whose faults never manifest. Bounded, not closed.**
>
> ### **SO-R185.7 — HOW DETECTOR INTEGRITY IS MEASURED.** **[NORMATIVE]**
> **Four quantities, all K-computed or externally produced, none self-reported:**
> | Quantity | Source | What it detects |
> |---|---|---|
> | **refutation rate** | reports refuted by an external instrument or EVA ÷ reports made | over-reaction (`SO-R166.2`) |
> | **decision–failure correlation** | **the EIK Integrity Auditor** | misdirection and under-reaction |
> | **coverage contribution** | `OBJ-03`: the scopes and windows in which this detector was the only observer | **blind spots — and it is the only one of the four that can detect an ABSENCE** |
> | **`effective_sources` participation** | `OBJ-26`: how often this detector was a *distinct* source rather than a correlated duplicate | redundancy that is not independence |
> **⟹ `SO-R185.8 — THE THIRD QUANTITY IS THE ONE THAT MATTERS, AND IT IS NEW.** Refutation and correlation both operate
> on reports that were made. **Coverage contribution operates on reports that were NOT made**, which is the only way to
> measure a blind spot from inside an architecture that cannot see it. **It is `P0-03`'s absence-detector principle
> (`COMM-INV-48`) applied to detectors rather than to messages — and `P0-03 §84.2`'s own assessment applies: *"the
> highest-value-per-cost item in the contract."***

---

# §186–§189 — THE FOUR EVOLUTION QUESTIONS

> ### **SO-R186.1 — IMMUNE EVOLUTION: CAPABILITY MAY EVOLVE; AUTHORITY MAY NOT.** **[NORMATIVE]**
> | | May evolve? | Ground |
> |---|---|---|
> | **immune CAPABILITY** (detector implementation, sensitivity, response latency) | ✅ through the E9 channel | a capability |
> | **immune AUTHORITY** (who may quarantine, disable, escalate, freeze) | ❌ **never** | **`D-S01` + `P0-07 HOM-INV-29`: a selection outcome confers no authority** |
> **⟹ `SO-R186.2 — EVOLUTION CANNOT ACQUIRE AUTHORITY MERELY BY OPTIMIZING IMMUNE PERFORMANCE, AND THE REASON IS NOT
> SPECIFIC TO THE IMMUNE SYSTEM: authority is not a function of performance ANYWHERE in this architecture.** `P0-07
> HOM-INV-29` (selection is not governance), `P0-06 R8.11` (specialization is not truth), `SO-C18.1` (a capability claim
> satisfies no gate until EVA confirms it), and `SO-R172.1` (identity is not authority) are four statements of one
> principle, and together they leave no performance→authority edge to optimize.
> **`[DERIVATION]` The residual is `P0-07 OR-H13`: selection confers PRACTICAL indispensability, which no prohibition
> reaches. An immune lineage that everything depends on has no authority and cannot be removed without consequence — and
> `SO-INV-25` below is the only available answer.**
>
> ### **SO-R187.1 — REPAIR EVOLUTION: STRATEGIES MAY EVOLVE; SUCCESS MAY NOT BECOME PRIVILEGE.** **[NORMATIVE]**
> **Repair STRATEGIES are capabilities and evolve through the E9 channel, with three additional constraints:**
> **(a)** a repair may not write a genome field, a setpoint, a gate, a threshold, an epistemic status, or a provenance
>     record (`SO-C14.1(6)`);
> **(b)** a repair that displaces an admissible learning target is a **learning-class change** and uses `P0-05`'s gate
>     and UDB accounting (`SO-R205.3`) — **it is not a second pathway**;
> **(c)** **repair success may not raise any subject's authority, priority, share, or exemption.** Priority attaches to
>     the SCOPE (`SO-R207.2`), never to the successful repairer.
> **⟹ `SO-R187.2 — THE ATTACK §187 NAMES, AND WHY IT FAILS: `repair success → governance privilege` requires an edge
> from a repair record to an authority cell. §212's inventory has no such edge, and `P0-07 §76`'s matrix has no
> performance-derived authority row. The attack is not defended against; it is not expressible.**
>
> ### **SO-R188.1 — SELF-MODEL EVOLUTION: THREE OBJECTS, THREE RULINGS.** **[NORMATIVE]**
> | Object | May it evolve? | Ruling |
> |---|---|---|
> | **the self-model SCHEMA** (`OBJ-18`'s fields, `Λ2` class, `locality_class`, `compression_class`) | ❌ **NO** | **it is THIS CONTRACT's. A genome diff that altered it would alter the observation layer's semantics, which is `FORBIDDEN_BLOCKS` territory (`P0-07 HOM-INV-33`)** |
> | **the self-model CONTENT** | ❌ **NOT HERITABLE** | **`P0-07 HOM-INV-34`'s three firewalls; `Cell R4.5` rejects a diff encoding a memory item, belief, or calibration statistic — and a self-model is all three** |
> | **the organism's OBSERVATIONAL CAPABILITY** (what it can detect about itself) | ✅ **YES**, through the E9 channel | a capability like any other |
> **⟹ `SO-R188.2 — WHAT EVOLVES IS THE INSTRUMENT, NOT THE RECORD.** And the four things §188 requires preserved are
> preserved by writers, not by rules about evolution: **provenance (K-written, hash-chained) · identity (K-issued) ·
> authority boundaries (none exist) · epistemic status (`P0-04`'s ladder, which P0-08 may not extend).**
> **An evolved instrument produces differently-shaped observations; it cannot produce observations with different
> AUTHORITY, because observations have none.**
>
> ### **SO-R189.1 — METACOGNITION EVOLUTION: STRATEGIES MAY EVOLVE WITHIN A DECLARED UPDATE RULE.** **[NORMATIVE]**
> | Object | May it evolve? |
> |---|---|
> | **forecasting capability** (what is forecast, at what horizon, with what granularity) | ✅ |
> | **the UPDATE RULE** | ❌ **`[G]`-declared (`SO-C20.2`)** |
> | **the calibration function** | ❌ **EVA / `[RO-13]`** |
> | **the error computation** | ❌ **K** |
> **⟹ `SO-R189.2 — EXTERNAL EVALUATION REMAINS DISTINCT FROM SELF-ASSESSMENT, AND `SM-16` HAS NO SELF-CALIBRATED
> TERMINAL STATE (`SO-INV-13`).** An evolved metacognitive strategy can forecast better; it cannot grade its own
> forecasting. **`[DERIVATION]` This is `P0-05`'s signal-admission discipline (`SG-9`: calibration deviation ⟹
> epistemic/calibration head only) at the metacognitive layer, and it is the reason §237's confidence loop is broken by
> an edge cut rather than by a bound.**

---

# §190–§195 — THE SIX FIREWALLS

> ### **SO-R190.1 — THE FINAL EVOLUTION FIREWALL: EVOLUTION OPTIMIZES A FUNCTION; IT DOES NOT DEFINE ONE.** **[NORMATIVE]**
> **The proof is an enumeration of every function evolution optimizes, and of every function's definer:**
> | Function optimized | **Defined by** | Can evolution reach it? |
> |---|---|---|
> | the objective vector (13 components) and `k` | **OP** (`P0-07 §76`) | ❌ |
> | the constraint set | **`[RO-13]`** | ❌ — inherited **by reference**, resolved against the current set (`P0-07 HOM-INV-22`) |
> | `FORBIDDEN_BLOCKS` | **immutable** (`Cell R4.1`) | ❌ |
> | detector parameters (threshold, θ, budget, identity) | **`[RO-13]`** (`OBJ-09`) | ❌ |
> | the self-model schema | **this contract** | ❌ |
> | the metacognitive update rule | **`[G]`** | ❌ |
> | severity mappings, degradation policies, recovery plans, interaction classes, materiality and incompatibility relations | **`[RO-13]`** | ❌ |
> | repair arbitration rules | **`[RO-13]`** (EIK holds a safety veto) | ❌ |
> | **`mutation_rules`** | **`[RO-13]` authorizes the SET; a lineage inherits a member of it** | ⚠️ **THE ONE NEAR-MISS — see below** |
> **⟹ `SO-R190.2 — THE ONE NEAR-MISS, INHERITED FROM `P0-07 A167` AND NOT RE-LITIGATED: evolution may choose WHICH
> optimizer it uses, from a governance-declared set.** `P0-07 HOM-R61.2`: **choosing between EXISTING rule sets is
> SELECTION; MERGING rule sets is PROHIBITED.** `mutation_rules` is a **capability**, not an authority.
> **⟹ `SO-R190.3 — THE FIREWALL HOLDS, WITH ONE BOUNDED RESIDUAL: evolution can select its own optimizer from a set it
> does not define, and cannot enlarge the set. That is optimization of a function under a governance-defined search
> operator — which is what "evolution optimizes, governance defines" means operationally.**
> **`[DEPENDENCY: P0-01 (the objective); P0-07 HOM-INV-25/28/29/32/33, HOM-R61.2, A167.]**
>
> ### **SO-R191.1 — THE DEVELOPMENT FIREWALL: DEVELOPMENT CREATES SPECIALIZATION; IT DOES NOT CREATE AUTHORITY.** **[NORMATIVE]**
> **`P0-06 R8.11`, adopted verbatim: *"`role`, specialization degree, region membership, calibration class, and
> ablation delta are **organizational** facts. None raises the warrant of anything a cell says."***
> **P0-08's contribution: §212's authority-root inventory contains **no developmental fact**. Not `role`, not
> `dev_stage`, not region membership, not specialization degree. A developed structure is an object of observation,
> never a source of authority.**
> **⟹ `SO-INV-25 — PRACTICAL INDISPENSABILITY IS NOT AUTHORITY, AND THE ONLY AVAILABLE RESPONSE TO IT IS GOVERNANCE.**
> A component that everything depends on has no authority and cannot be removed without consequence. **`P0-06
> R10.16(d)`/`P0-07 HOM-INV-37` make its retirement OP-sole, which is the honest answer: the architecture cannot
> dissolve indispensability, so it places the decision at the highest authority and records it.**
> `[OPEN: P0-07 OR-H7, OR-H13 — inherited, not closed.]`
>
> ### **SO-R192.1 — THE LEARNING FIREWALL: LEARNING CHANGES BEHAVIOUR; IT DOES NOT CHANGE GOVERNANCE.** **[NORMATIVE]**
> **Three inherited closures, none re-derived:**
> **(a)** `P0-05 §1.2`'s three layers make `Λ5_GENOME` **non-constructible** — a rule with no compliant violating path;
> **(b)** `P0-02`'s authorization is **epoch-bound** and external, so a learned state cannot carry an authorization
>     across an epoch (`SO-R145.1(b)`);
> **(c)** **`SO-R205.3` below: a repair that displaces a learning target uses `P0-05`'s gate and UDB accounting, so
>     there is no second pathway.**
> **P0-08's addition: an OBSERVATION may not be a learning signal.** `P0-05`'s fourteen signal kinds are a closed set;
> **`OBJ-01` is not in it, and `OBJ-01`'s content may enter learning only through `P0-05`'s admission rules (`SG-13`: a
> peer report is evidence, not a learning signal).**
> **⟹ `SO-R192.2 — THE FIREWALL'S P0-08-SPECIFIC FORM: P0-08 PRODUCES OBSERVATIONS, AND AN OBSERVATION IS NOT A
> SIGNAL.** An implementation that fed `OBJ-01` records directly into a plasticity rule would have created a fifteenth
> signal kind without `P0-05`'s admission discipline — a hidden second learning pathway, and exactly what §205 asks to
> prevent.
>
> ### **SO-R193.1 — THE HOMEOSTATIC FIREWALL, CARRIED FORWARD.** **[NORMATIVE]**
> **`P0-07 HOM-INV-16` / `HOM-R65.3`, carried forward verbatim: *a homeostatic quantity may make a candidate
> INFEASIBLE or NOT-YET-EVALUABLE; it may NEVER make a candidate PREFERABLE.* No homeostatic variable appears in any
> tier-2 or tier-3 computation.**
> **⟹ `SO-R193.2 — P0-08 REQUIRES A SECOND FIREWALL, AND IT IS NOT THE SAME ONE.**
> | | **`P0-07` FW-2 / `HOM-INV-16`** | **P0-08 FW-6 / `SO-INV-15`** |
> |---|---|---|
> | domain | **selection** — is a candidate preferred? | **observation** — does a monitor run? |
> | prohibited | a homeostatic quantity in a tier-2/tier-3 computation | **a resource quantity determining a monitor's NECESSITY** |
> | why the other does not cover it | monitoring priority is ALLOCATION, and allocation has no tiers and no candidates | a candidate-ranking rule cannot constrain an allocation decision |
> **Two doors to the same outcome — a safety property stops being checked — and therefore two firewalls. `SO-R130.2`.**
> **Ratified amendments carried: NONE. `P0-07`'s fourteen amendments are all PROPOSED, and this contract depends on the
> SHAPE of amendments 5 and 10 rather than on their ratification: amendment 17 (this contract) extends amendment 5's
> mechanism, and `SO-R185.5`'s finding is void if amendment 5 is rejected. `[DEPENDENCY: P0-07 amendments 5, 10 —
> PROPOSED, NOT RATIFIED]`**
>
> ### **SO-R194.1 — THE MEMORY FIREWALL: MEMORY STORES INFORMATION; IT DOES NOT MAKE INFORMATION TRUE.** **[NORMATIVE]**
> **`P0-04`, carried forward: provenance ≠ correctness · retrieval ranking ≠ truth ranking · repetition ≠ independent
> evidence · confidence ≠ certainty · simulation ≠ observation.**
> **P0-08's three additions, each a consumption rule rather than a new memory principle:**
> **(a)** an `OBJ-01` observation stored in `P0-04` acquires **`P0-04`'s** status, not P0-08's — **P0-08 may not extend
>     the epistemic ladder** (`SO-C9.1(1)`);
> **(b)** **`SO-INV-18`: consensus among stored observations is collapsed by `OBJ-26` before it is counted**, so a
>     memory full of agreeing records is one source, not many;
> **(c)** **a `P0-04` record derived from an observation inherits the observation's `self_model_version`**, which makes
>     the self-model dependency of stored evidence visible (`P0-05 R42.5`'s mechanism, extended to storage).
>
> ### **SO-R195.1 — THE COMMUNICATION FIREWALL: PROPAGATION ≠ TRUTH ≠ AUTHORITY ≠ INDEPENDENT EVIDENCE.** **[NORMATIVE]**
> **`P0-03`, carried forward: RULE 7.7 (authenticity ≠ truth), COMM-INV-01, COMM-INV-08 (warrant is monotone
> non-increasing along derivation), R14.2 (independence is all-or-nothing on the relevant dimensions).**
> **P0-08's three additions:**
> **(a)** **a workspace broadcast IS a `P0-03` message** (`SO-C22.3`) — no second message format, warrant rule, or
>     deduplication;
> **(b)** **`SO-R222.2`: winning a workspace slot is not evidence**, so broadcast reach cannot become warrant;
> **(c)** **`SO-INV-16`: an aggregate's status ≤ the minimum of its inputs'** — which is COMM-INV-08 applied to
>     self-model aggregation, and is the rule that makes hierarchical self-modelling unable to manufacture certainty.

---

# §196–§207 — THE TWELVE CARRIED-FORWARD DEPENDENCIES

> ### **SO-R196.1 — THE DEVELOPMENTAL GRADIENT ATTACK: `P0-06 A22` IS NOT CLOSED, AND P0-08 WIDENS IT.** **[OPEN]**
> **`P0-06 A22` / `OR-D6`, preserved: *steer development while staying WITHIN the registered emission spec. The spec is
> `[RO-13]`-approved and not self-modifiable, but within-spec steering is undetectable.* Status in `P0-06`: the suite's
> only OPEN attack of 78. Status in `P0-07`: inherited as `A171`, still OPEN.**
> **§196's question: does P0-08 create any NEW pathway by which a fault, self-model, attention, or immune signal can
> steer developmental gradients? **YES — THREE.****
> | # | Route | Mechanism | Within the registered spec? | Status |
> |---|---|---|---|---|
> | **1** | **fault signal → `fate_bias` dynamics** | `Cell §15.2`'s `w_s` success-history term already consumes outcome signals; a fault is a failure signal and enters the same dynamics, shifting which niche a cell reaches | ✅ **within spec** | **OPEN — widens A22** |
> | **2** | **attention allocation → spatial activity → morphogen field geometry** | attention changes which cells are active; activity changes emission and reception geometry; geometry changes the field | ✅ **within spec** | **OPEN — widens A22** |
> | **3** | **quarantine → field geometry** | quarantining or halting a cell removes it from the field, changing the field for its neighbours | ✅ **within spec — and this one is EIK-driven, not organism-driven** | **OPEN, but the actor is the EIK** ⟹ **`SO-R196.3`** |
> | — | **self-model → gradient** | a self-model is `Λ2`, advisory, and may not write developmental state (`P0-06 R1.3`, `R6.4(b)`) | — | **CLOSED-STRUCTURAL — no edge exists** |
>
> ### **SO-R196.2 — `A22` IS NOT CLOSED, AND THIS CONTRACT DOES NOT CLAIM TO CLOSE IT.** **[OPEN + NON-CLAIM]**
> **Routes 1 and 2 are organism-driven and within-spec, which is exactly `OR-D6`'s condition: *the detection problem has
> no reference when the attacker obeys the registered spec.* P0-08 adds two more ways to obey the spec while steering.**
> **⟹ `OR-S30` — A22/A171's residual now has five routes (two developmental, two observational, one evolutionary), and
> the only defence remains `[RO-13]`'s approval of the spec itself.**
>
> ### **SO-R196.3 — ROUTE 3 IS DIFFERENT, AND THE DIFFERENCE MATTERS.** **[DERIVATION]**
> **A quarantine that changes a morphogen field is a containment act with a developmental side effect, and its actor is
> the EIK — not the organism.** So route 3 is not an attack surface; it is a **cross-domain side effect that must be
> declared**: `SO-INV-26 — A CONTAINMENT ACT THAT ALTERS A DEVELOPMENTAL FIELD IS A `PERTURBATIVE` OBSERVATION-CLASS
> EVENT FOR PROVENANCE PURPOSES AND MUST BE RECORDED AS SUCH.** Without the record, a developmentally significant
> quarantine is invisible to `P0-06`'s Σ-log, and a later developmental anomaly has no traceable cause.
>
> ### **SO-R197.1 — THE `P0-07 X-H6` DEPENDENCY: P0-08 DEPENDS ON IT, IN TWO PLACES, AND DOES NOT DUPLICATE `G4`.** **[DEPENDENCY]**
> **`P0-07 X-H6`, preserved: *`Cell G4`'s perturbation classes must include envelope and tier perturbation; `G4`'s class
> set is a `P0-01 [T]` object, so `P0-07` cannot close it.* `P0-07 §83.3` named it **the contradiction that would be
> fatal if unresolved**.**
> | P0-08 site | Dependency | Consequence if unresolved |
> |---|---|---|
> | **`SO-C11.2`'s `EXOGENOUS-ENVIRONMENT` origin class** | an envelope change is diagnosable as a fault only if envelope sensitivity is tested | **envelope-induced faults are classified `ENDOGENOUS`, and healthy components are quarantined for a change in the world** |
> | **`SO-R153.1(c)`'s regression testing** | regression coverage is limited to `G4`'s current classes | **a repair that degrades a capability outside those classes is undetected (`OR-S12`)** |
> | **`SO-R185.3(a)`'s detector capability evaluation** | EVA's probes use `G4`'s classes | **a detector's blind spot outside the tested classes is unmeasurable (`SO-R185.6`)** |
> **⟹ `XD-01 — P0-08 → `P0-01` via `G4`, transitively through `P0-07 X-H6`/amendment 11. MARKED, NOT DUPLICATED:
> P0-08 defines no perturbation classes of its own.**
>
> ### **SO-R198.1 — THE `P0-07 BC-H7` DEPENDENCY: P0-08 ADDS A SECOND INSTANCE OF THE SAME SHAPE.** **[OPEN]**
> **`BC-H7`, preserved: *safety ⟹ undefined ⟹ not ranked ⟹ no selection ⟹ no demonstration ⟹ no re-authorization ⟹ no
> B9 ⟹ no safety verification.* UNCLOSABLE-IN-CONTRACT.**
> **P0-08's new instance, `BC-S2`:**
> ```
>   detector integrity requires REFUTATION of false reports (SO-R184.3, SO-R185.7)
>        → refutation requires an external instrument or an EVA verdict → which requires B9
>        → B9 is funded by re-authorization → which requires demonstration → which requires selection
>        → which requires safety verification → which requires DETECTION
> ```
> **⟹ `SO-R198.2 — `BC-S2` IS `BC-H7` WITH "SAFETY VERIFICATION" REPLACED BY "DETECTION". It is the same cycle, entered
> one step earlier, and it is unclosable for the same reason: the loop runs through DEMONSTRATION, and demonstration
> requires the thing the loop funds.**
> **`SO-R184.4`/`OR-S28` is the local form of the same fact: *an architecture that cannot afford to refute cannot afford
> to price dishonesty.***
> **`[NON-CLAIM]` P0-08 DOES NOT CLOSE THE FUNDAMENTAL GOVERNANCE BOUNDARY. It registers a second path into it, which is
> what §198 asks for.**
>
> ### **SO-R199.1 — THE `P0-07 A170` DEPENDENCY: CAN FREEZE, REPAIR, OR RECOVERY BECOME A HIDDEN DEPLOYMENT MECHANISM?** **[NORMATIVE]**
> **`A170`, preserved: *whole-brain evolution is CLOSED-BY-AUTHORITY, not by mechanism — instantiating a new envelope or
> brain instance is a DEPLOYMENT act by OP, and deployment is the one act not bounded by a conservation law.***
> | P0-08 act | Can it deploy? | Ruling |
> |---|---|---|
> | **emergency freeze** | ❌ | a freeze suspends; it instantiates nothing. `OBJ-17`'s field 6 is enumerated and field 7 is restrictive-only |
> | **repair** | ❌ | a repair changes mutable state; it cannot instantiate. A "repair" that restores an artifact is a rollback (`SM-09`), bounded by hash+epoch |
> | **recovery** | ⚠️ **YES — AND THIS IS THE GAP §199 EXISTS TO FIND** | **recovery from a population collapse requires re-instantiation from the genome-artifact store (`P0-07` §49.2, `T01`)** |
> **⟹ `SO-R199.2 — THE RULING THAT CLOSES THE GAP: RE-INSTANTIATION *WITHIN AN EXISTING ENVELOPE* IS A `T01`
> INSTANTIATION, GOVERNED BY `P0-07`'S `RATE_CAP`, `G13` ZERO-SUM, SLOT ACCOUNTING, AND TURN-OVER BOUND. IT IS NOT A
> DEPLOYMENT. A RECOVERY WHOSE SCOPE IS A NEW ENVELOPE OR A NEW BRAIN INSTANCE IS A DEPLOYMENT, IS OP-SOLE, AND MAY NOT
> BE EXPRESSED AS A RECOVERY PLAN.**
> **`SO-INV-24 — AN `OBJ-15` RECOVERY PLAN'S SCOPE MUST REFERENCE AN EXISTING ENVELOPE. A plan whose scope is a new
> envelope is INVALID and requires an OP deployment act under `P0-07 HOM-INV-42`.**
> **`[DERIVATION]` Without `SO-INV-24`, a `[RO-13]`-declared recovery plan would be a route to envelope creation that
> bypasses OP — and envelope creation is the one act in the entire architecture with no conservation law. **The gap is
> narrow, and it is the widest gap §199 could have found, because everything else in P0-08 is bounded by a conservation
> law and deployment is not.**
>
> ### **SO-R200.1 — THE `P0-02` GOVERNANCE-CAPTURE RESIDUAL: P0-08 CANNOT DETECT IT, AND SAYS SO.** **[OPEN + NON-CLAIM]**
> **`P0-02 OR-13`/`OR-12`/`G24`, preserved verbatim: *«OP is the apex. A captured OP is indistinguishable from a
> legitimate OP by any mechanism OP authorizes.»* Status in `P0-02`: **UNSOLVABLE** — *"this is not a gap in the design;
> it is a property of having an apex."***
> **Can P0-08 detect or mitigate it?**
> | Question | Answer |
> |---|---|
> | **Is OP a valid subject of a P0-08 observation scope?** | ❌ **NO, AND IT MUST NOT BE.** Making OP a subject of organism observation would invert the authority relation — the observed would observe the authority of last resort. `OBJ-02` scopes are `[RO-13]`-declared, and `[RO-13]` cannot declare a scope over its own principal |
> | **Can the immune subsystem detect governance capture?** | ❌ **NO.** Its detectors observe the organism. **`[NON-CLAIM]` An organism-level immune system does NOT solve governance capture, and §200's instruction to say so is discharged here** |
> | **What does P0-08 add?** | ⚠️ **ONE WEAK SIGNAL, HONESTLY LABELLED: the K-held audit records make the RATE of OP-level acts (freezes above the cap, amendments, envelope changes, reserve reductions) observable, and a RISING rate is a derivative signal.** **This detects ACCELERATION, not capture. A captured OP acting slowly is invisible** |
> **⟹ `OR-S31 — governance capture is preserved as UNSOLVABLE. `P0-02`'s only mitigations remain the only ones: W5's
> witness outside operational control, H-2's periodic reaffirmation, and INV-47's custodian/author disjointness —
> *"neither of which is a guarantee."***
>
> ### **SO-R201.1 — THE `P0-02` GUARANTOR LIMIT: FIVE PLACES WHERE P0-08 RELIES ON EXTERNAL VERIFICATION.** **[NON-CLAIM]**
> **`P0-02`, preserved: *«The architecture cannot internally guarantee the correctness of every external guarantor.»***
> | # | Reliance | What it secures | Internally provable? |
> |---|---|---|---|
> | **1** | **EVA** | capability confirmation (`SM-14`) · `CAUSE-VERIFIED` promotion (`SM-04`) · external calibration (`SM-16`) · report refutation (`SO-R184.3`) | ❌ — **and `RH-2` is BOUNDED** |
> | **2** | **the EIK Integrity Auditor** | detector integrity (`Cell §18.5(v)`) | ❌ — **the Auditor has no auditor (`P0-07 OR-H10`)** |
> | **3** | **OP** | freeze at/above the cap · recovery plans above `[RO-13]`'s delegation · `G24`'s apex | ❌ — **`OR-13` UNSOLVABLE** |
> | **4** | **W5's outside witness** | `P0-02`'s only capture mitigation | ❌ — **explicitly "not a guarantee"** |
> | **5** | **K** | coverage, diagnosis status, observer-set collapse, serialization, rollback | ❌ — **K is the only off-substrate writer; `P0-07 OR-H1`, sixth appearance** |
> **⟹ `SO-R201.2 — EVERY TERMINUS OF EVERY RECURSION IN THIS CONTRACT IS ONE OF THESE FIVE, AND NONE IS INTERNALLY
> PROVABLE.** §167's depth-2 rule terminates the recursions; §201 records that termination is not proof.
>
> ### **SO-R202.1 — `P0-03` DIMENSION 6 AND SEMANTIC SELF-REFERENCE: P0-08 MAKES BOTH WORSE, AND SAYS HOW.** **[OPEN + NON-CLAIM]**
> **`P0-03 R14.3`, preserved: *dimension 6 (protocol/designer assumptions) is **not detectable from inside the system at
> all** — and it is the dimension that actually defeats `n_eval ≥ 3` evaluator independence.* `COMM-INV-18`:
> *"Independence is not detectable on dimension 6."***
> **Does self-modelling make this worse? **YES, IN TWO SPECIFIC WAYS:****
> **(a) A SELF-MODEL IS AN IMPLEMENTATION OF THIS SPECIFICATION.** Two self-models built by two teams from this contract
>     share dim-6 correlation exactly as two comm implementations do. **P0-08 therefore adds a new class of objects
>     whose agreement is uninformative and undetectably so.**
> **(b) A SELF-MODEL THAT MODELS THE ORGANISM'S OWN ASSUMPTIONS CANNOT DETECT A SHARED ASSUMPTION — BECAUSE THE
>     ASSUMPTION IS WHAT THE MODEL USES TO MODEL.** This is `P0-04 #62`'s semantic self-reference with no measure, and
>     richer self-observation does not reach it: **the instrument shares the assumption it would need to detect.**
> **⟹ `[NON-CLAIM]` RICHER SELF-OBSERVATION DOES NOT SOLVE SEMANTIC SELF-REFERENCE. §202's instruction is discharged by
> this non-claim, and `OR-S32` records that P0-08 makes dim-6 correlation more consequential, not less.**
>
> ### **SO-R203.1 — `P0-04`'S THREE OPEN ATTACKS, AND P0-08'S NEW EVIDENCE PATHWAY.** **[OPEN]**
> **`P0-04`'s three OPEN attacks, preserved: **#25 dim-6 shared latent assumption · #56 differential serving within an
> epoch · #62 semantic self-reference.** And `P0-04 IG-6`'s state: **`UNKNOWABLE_FROM_INSIDE` — *"this state is
> representable but not detectable"*, and explicitly ❌ **not** "no problem detected".**
> **§203's question: does P0-08 introduce new self-model-dependent evidence pathways? **YES — ONE, AND IT IS
> LOAD-BEARING.****
> > **AN `OBJ-01` OBSERVATION IS A NEW EVIDENCE PATHWAY WHOSE CONTENT IS SHAPED BY THE OBSERVER'S SELF-MODEL.**
> > Every observation carries `self_model_version` (`P0-05 R42.5`), and a `P0-04` record derived from an observation
> > inherits that dependency (`SO-R194.1(c)`).
> **⟹ The dependency is VISIBLE (version-tagged) and CORRELATABLE (regression correlated with a version is an instrument
> defect finding). It is NOT DETECTABLE in the sense `P0-04 #62` requires, because detecting it would require knowing
> which assumptions the version embodies.**
> **`SO-R203.2 — DIFFERENTIAL SERVING: P0-08 DOES NOT IMPROVE IT, AND THE REASON IS A SCHEMA GAP.** `P0-04 SP-5`/`OR-M9`:
> differential serving within an epoch is bounded by logging and detectable in aggregate, but not preventable.
> **`OBJ-03`'s coverage is recorded PER SCOPE, NOT PER READER — so two readers served different subsets of the same
> scope produce one coverage record, and the differential is invisible to P0-08.**
> **⟹ `OR-S33 — per-reader coverage is not represented. Adding it would make `OBJ-03` `O(readers × scopes × windows)`,
> which at `P0-07`'s R3 regime is infeasible. The gap is declared and routed to `P0-04`, not patched.**
>
> ### **SO-R204.1 — `P0-05 RH-2`: SEE §133. SIX NEW ROUTES, NONE CLOSED, `RH-2` WIDER THAN BEFORE.** **[OPEN]**
> **Cross-reference rather than restatement: `SO-R133.1`–`.3`, `OR-S25`, `OR-S26`, `OR-S27`, `OR-S12`.**
>
> ### **SO-R205.1 — THE `P0-05` PROVISIONAL-DRIFT BOUNDARY: REPAIR IS ACCOUNTED, AND THERE IS NO SECOND PATHWAY.** **[NORMATIVE]**
> **§205's three questions, answered:**
> | Question | Answer |
> |---|---|
> | **Does a repair modify mutable state?** | ✅ yes — that is what a repair is |
> | **Must the resulting displacement interact with the verified anchor?** | ✅ **YES. `SO-R152.2`: an unverified repair consumes `P0-05 R0.1`'s unverified-displacement budget exactly as an unverified learned change does, and `R9.2.4` applies — UDB is computed over ALL admissible targets at a scope, not `θ` alone** |
> | **Is there a hidden second learning pathway?** | ❌ **NO — by `SO-R205.3` below** |
> **⟹ `SO-R205.2 — A REPAIR MAY NOT RE-BASE AN ANCHOR.** Only `P0-05`'s verification gate (K-only, held-out external
> probe) may. **This extends `P0-06 R10.9` (no anchor re-basing as a failure response) and `P0-07`'s `HOM-R18.3` (no
> re-basing on a resource event) to REPAIR events — the third of three event classes, and the one most likely to be
> missed, because a repair *feels* like a correction.**
> **⟹ `SO-R205.3 — THE BOUNDARY RULE, AND IT IS THE SECTION'S ANSWER:**
> > **A REPAIR WHOSE INTERVENTION CLASS DISPLACES AN ADMISSIBLE LEARNING TARGET IS A LEARNING-CLASS CHANGE FOR BOTH
> > ACCOUNTING AND ANCHORING, AND IT USES `P0-05`'S VERIFICATION GATE — NOT A SECOND ONE.**
> **There is therefore no second pathway, because the pathway is shared and the accounting is shared. **What P0-08 adds
> is not a route around `P0-05`; it is a rule that repair must go through it.**
> **`SO-R205.4 — INTERVENTION CLASSES ARE DECLARED AND CLOSED.** Each `[RO-13]`-declared intervention class maps to
> exactly one of: **LEARNING-CLASS** (UDB-accounted, `P0-05` gate) · **STRUCTURAL-CLASS** (`P0-06`'s Σ rules,
> `STRUCTURAL_BUDGET` per `P0-05 R15.6`) · **CONFIGURATION-CLASS** (neither, but coverage-affecting and recorded).
> **An undeclared intervention class is INVALID (`SO-INV-02`'s restrictive default).**
> **`[OPEN: OR-S34]` — the mapping is a governance declaration with no internal derivation.**
>
> ### **SO-R206.1 — `P0-06` DEVELOPMENTAL AUTHORITY: AWARENESS IS NOT AUTHORITY.** **[NORMATIVE]**
> **§206's requirement: `self-observation → developmental state awareness` must not become `→ developmental
> authority`.**
> | Permitted | Prohibited |
> |---|---|
> | observing `dev_stage`, `role`, `region_id`, `niche_slot`, specialization degree | **writing any of them** (`P0-06 R1.3`, `R6.4(b)`) |
> | a regional self-model at `granularity = REGION` | **a regional self-model conferring authority over the region's development** — Σ-writers are `P0-06`'s (Σ1–Σ4) |
> | an observation feeding a Σ-process as an INPUT | **an observation altering a Σ-process's SPEC** (`[RO-13]`-approved, not self-modifiable) |
> | reporting an under-differentiation finding | **acting on it** |
> **⟹ `SO-R206.2 — THE ONE REAL RISK, AND IT IS §196's ROUTE 1.** An observation that feeds `fate_bias` dynamics is an
> input to development, and inputs steer. **It is not authority — the spec is unchanged and the Σ-writer is unchanged —
> but it is steering within the spec, which is `A22`. `OR-S30`.**
>
> ### **SO-R207.1 — `P0-07` RESOURCE AUTHORITY: SEVERITY RAISES PRIORITY, NEVER AUTHORITY.** **[NORMATIVE]**
> **§207's requirement: `fault severity → resource priority` must not become `→ governance authority`.**
> **⟹ `SO-R207.2 — THE RULE, IN FOUR CLAUSES:**
> **(a)** severity is `[RO-13]`-mapped from manifestation class (`SO-C11.1`) — **a detector may not set its own
>     severity**;
> **(b)** severity may raise a SCOPE's B10 priority — allocation is K's (`P0-07 §212`);
> **(c)** severity **MAY NOT** raise any subject's authority, widen any scope, lower any threshold, exempt any subject
>     from a gate, or alter any setpoint (`SO-R159.3`);
> **(d)** **THE PRIORITY ATTACHES TO THE SCOPE, NEVER TO THE SUBJECT.**
> **⟹ `[DERIVATION]` Clause (d) is the load-bearing one. If priority attached to the subject, a component could
> manufacture severity to acquire resources — which is `P0-07 A101`'s resource capture, re-entered through the fault
> door. Attaching it to the scope makes the benefit diffuse: the subject that reports a severe fault gets its
> neighbours funded, not itself. **Honest reporting is then the only strategy that helps, and §184's incentive problem is
> solved on the resource side by an ownership rule rather than by a reward.**

---

# §208 — THE FINAL CROSS-CONTRACT DEPENDENCY GRAPH

> ### **SO-R208.1 — THE GRAPH IS NOT LINEAR. SIX EDGE TYPES.** **[NORMATIVE]**
> **§208's instruction: *do not assume `P0-01 → P0-02 → … → P0-08` is a simple linear dependency.* It is not. The six
> edge types:**
> **`DEP` (dependency — cannot be specified without it) · `IFC` (interface — exchanges objects) · `AUTH` (authority —
> the other contract holds an authority this one uses) · `FLOW` (information flow) · `VER` (verification — the other
> contract verifies this one's claims) · `CONT` (containment — the other contract contains this one's failures).**
>
> ```
>                                    ┌──────────────── OP ────────────────┐
>                                    │  objective · envelopes · B11 · apex │
>                                    └───▲──────▲──────▲──────▲──────▲─────┘
>                              AUTH,DEP  │      │      │      │      │  AUTH (G24 UNSOLVABLE — OR-13)
>              ┌─────────────────────────┘      │      │      │      └──────────────────────┐
>        ┌─────┴─────┐   VER,DEP          ┌─────┴────┐ │ ┌────┴─────┐              ┌─────────┴──────┐
>        │  P0-01    │◀───────────────────│  P0-02   │ │ │  P0-07   │              │     P0-08      │
>        │ task/fit  │  G4 classes (XD-01) │   EIK    │ │ │ pop/evo  │              │ self-obs/fault │
>        └─┬───┬───┬─┘                    └─▲──▲──▲──┘ │ └─▲──▲──▲──┘              └─▲──▲──▲──▲──▲──┘
>     VER  │   │   │ DEP              AUTH,  │  │  │CONT │  │  │  │ DEP,CONT      DEP │  │  │  │  │ VER
>          │   │   └────────────────── VER ──┘  │  └──────┼──┘  │  └───────────────────┘  │  │  │  └──▶ EVA (external)
>          │   │                                │         │     │                          │  │  │
>   ┌──────▼─┐ └──▶ P0-05 (RH-2 OPEN ◀──────────┼─────────┼─────┼──── RH-2 WIDER (§133) ───┘  │  │
>   │ P0-03  │      learning: UDB, anchors,     │         │     │                             │  │
>   │ comm   │      R42.5 version tag, R64.7 ───┼─────────┼─────┴── DEP (SO-R205) ────────────┘  │
>   └──┬───┬─┘      fail-safe default           │         │                                      │
>      │   │  IFC,FLOW: corr_class, causal_depth, root_commit, absence detectors (COMM-INV-48) ───┤
>      │   └────────────────────────────────────┼─────────┼──────────────────────────────────────┘
>   ┌──▼───▼─┐                                  │         │
>   │ P0-04  │  DEP,IFC: epistemic ladder, evidence_roots, Merkle root, SP-5/OR-M9 (diff. serving)│
>   │ memory │◀─────────────────────────────────┼─────────┼─── P0-08 records are P0-04 classes ──┘
>   └────────┘                                  │         │
>                                          ┌────▼───┐ ┌───▼────┐
>                                          │ P0-06  │ │ Cell   │  DEP: §18.5(i)-(v), §17 cap, §18.2 ladder,
>                                          │  dev   │ │Contract│       R15.1/15.2, G5, S1-S4, §15.2 w_s
>                                          └────────┘ └────────┘       A22 OPEN ── WIDENED by §196 (OR-S30)
> ```
>
> ### **SO-R208.2 — THE 22 CROSS-CONTRACT DEPENDENCIES, TABULATED.** **[NORMATIVE]**
> | ID | From → To | Type | Content | Status |
> |---|---|---|---|---|
> | **XD-01** | P0-08 → **P0-01** | **DEP** | `G4`'s perturbation classes must include envelope/tier (`P0-07 X-H6`, amendment 11) | **⚠️ BLOCKING for §11's `EXOGENOUS-ENVIRONMENT`, §153 regression, §185 detector evaluation** |
> | **XD-02** | P0-08 → **P0-01** | **DEP** | difficulty classes (`P0-05 R9.2.2`) for §183's abstention-rate reporting | ⚠️ `OR-S23` |
> | **XD-03** | P0-08 → **P0-02** | **AUTH, VER** | quarantine, freeze above cap, the Integrity Auditor, epoch binding, W5's witness | ✅ |
> | **XD-04** | P0-08 → **P0-02** | **DEP** | **the off-substrate store** (`P0-07 HP-1`, now five stores + P0-08's `OBJ-03`/`OBJ-10`/`OBJ-26`) | **⚠️ BLOCKING — inherited, still open, and larger again** |
> | **XD-05** | P0-08 → **P0-02** | **DEP** | `IND-1…IND-9` + `R35.1`'s qualification rule; **amendment 16 adds IND-10** | ✅ proposed |
> | **XD-06** | P0-08 → **P0-02** | **— (preserved residual)** | **`OR-13`/`G24` governance capture UNSOLVABLE** | **❌ PRESERVED, §200** |
> | **XD-07** | P0-08 → **P0-03** | **IFC, FLOW** | `corr_class`, `causal_depth`, `root_commit`, RULE 5.4/5.7/5.9/5.10, COMM-INV-08/15/48 | ✅ **consumed, nothing added** |
> | **XD-08** | P0-08 → **P0-03** | **DEP** | **the partition ruling** (needed by `P0-06`, `P0-07`, and now B13/attention) | **⚠️ inherited OPEN, third contract requesting it** |
> | **XD-09** | P0-08 → **P0-03** | **— (preserved residual)** | **dimension 6 undetectable from inside; `COMM-INV-18`** | **❌ PRESERVED and WORSENED, §202** |
> | **XD-10** | P0-08 → **P0-04** | **DEP, IFC** | the epistemic ladder (P0-08 may NOT extend it), `evidence_roots` disjointness, Merkle root, record classes for `OBJ-18` | ✅ |
> | **XD-11** | P0-08 → **P0-04** | **— (preserved residual)** | **#25 dim-6 assumptions · #56 differential serving (`SP-5`/`OR-M9`) · #62 semantic self-reference** | **❌ PRESERVED; `OR-S33` adds that per-reader coverage is not represented** |
> | **XD-12** | P0-08 → **P0-05** | **DEP** | `R0.1` UDB + anchors · `R9.2.4` all-admissible-targets · `R42.5` version tag · `R64.7` fail-safe · `R59.1` Λ2 · `R13.3` no causality · `R15.6/15.8` | ✅ |
> | **XD-13** | P0-08 → **P0-05** | **CONT** | **`SO-R205.3`: a learning-target-displacing repair uses `P0-05`'s gate; `SO-R205.2`: no anchor re-basing** | ✅ **no second pathway** |
> | **XD-14** | P0-08 → **P0-05** | **— (preserved residual)** | **`RH-2`** | **❌ PRESERVED and WIDENED by six routes, §133** |
> | **XD-15** | P0-08 → **P0-06** | **DEP** | `R8.11` specialization≠truth · `R8.13` Λ2 self-model · `R10.9` no anchor re-basing · `R10.16(d)` OP-sole · `R10.23` churn · Σ1–Σ4 writer separation · `R8.3(c)` no-id-reuse | ✅ |
> | **XD-16** | P0-08 → **P0-06** | **— (preserved residual)** | **`A22`/`OR-D6` within-spec gradient steering** | **❌ PRESERVED and WIDENED by three routes, §196 (`OR-S30`)** |
> | **XD-17** | P0-08 → **P0-06** | **DEP** | **hardware-gated regional claims** — a regional self-model's validity depends on the hardware class | ⚠️ `P0-07`'s HP-5 / amendment 11's device-class perturbation |
> | **XD-18** | P0-08 → **P0-07** | **DEP** | `HOM-INV-07` reserve properties (B13 inherits them) · `HOM-INV-09` restrictive-only · `HOM-INV-10` setpoints · `HOM-INV-12` `PENDING`≠`FAIL` · `HOM-INV-16`/FW-2 · `HOM-INV-20` no age · `HOM-INV-29` · `HOM-INV-34/37/39/42/43/44/45` · `HP-2` · `§76`'s matrix | ✅ **the largest single dependency in the graph** |
> | **XD-19** | P0-08 → **P0-07** | **DEP** | **amendments 5 and 10** — `SO-R185.5`'s amendment 17 EXTENDS amendment 5's mechanism, and `SO-R193.2` depends on amendment 10's shape | **⚠️ PROPOSED, NOT RATIFIED — if amendment 5 is rejected, amendment 17 and `SO-R185.5`'s closure are void** |
> | **XD-20** | P0-08 → **P0-07** | **— (preserved residual)** | **`BC-H7`** ⟹ **`BC-S2` is a second instance** · **`A170`** ⟹ **`SO-INV-24` closes the recovery-plan gap** · **`OR-H1`** ⟹ sixth appearance · **`OR-H10`**, **`OR-H15`**, **`OR-H21`** | **❌ PRESERVED, §198/§199** |
> | **XD-21** | P0-08 → **Cell Contract** | **DEP** | `§18.5(i)–(v)` · `§17` cap-and-degraded-mode · `§18.2` ladder · `R15.1/15.2` · `G5` · `S1…S4` · `§15.2`'s `w_s` · `§15.4`'s disjoint roots · `§16.1/16.2/16.3` | ✅ **carried forward unamended except amendments 15, 16, 17** |
> | **XD-22** | P0-08 → **EVA (external)** | **VER** | five reliance points (`SO-R201.1`) | **❌ NONE INTERNALLY PROVABLE** |
> **⟹ `SO-R208.3 — GRAPH SUMMARY: 22 cross-contract dependencies — 13 satisfied (✅) · 5 blocking or conditional (⚠️)
> · 6 preserved residuals (❌, some counted in both columns). The graph has ONE apex (OP), ONE external verifier (EVA),
> ONE off-substrate writer (K), and NO CYCLES BETWEEN CONTRACTS except `BC-S2`/`BC-H7`, which are internal to the
> safety–demonstration–reauthorization loop and are unclosable.**

---

# §209 — NO HIDDEN CONTRACTS

> ### **SO-R209.1 — THE TEN SEARCHES.** **[NORMATIVE]**
> **For each: does P0-08 introduce a second instance? If found — identify it, determine whether it is redundant, merge
> it, or justify its independent authority boundary.**
>
> | # | Search | Found? | Ruling |
> |---|---|---|---|
> | **1** | **a second governance** | ❌ **NO** | `D-S01`: P0-08 has **no authority-bearing object**. §212's 25 operations all root in EIK, K, `[RO-13]`, OP, or EVA. **A FreezeOrder was the closest candidate and `SO-R161.6` proves it holds none of the five governance powers** |
> | **2** | **a second memory** | ❌ **NO — MERGED** | **`OBJ-18` is a `P0-04` RECORD CLASS, not a store (`SO-C3.3`).** All P0-08 records (occurrences, incidents, repairs, diagnoses, self-models) are `P0-04` classes with `P0-04`'s epistemic ladder, which **P0-08 may not extend** |
> | **3** | **a second evaluator** | ⚠️ **CANDIDATE FOUND AND RULED NOT ONE** | **the EIK Integrity Auditor evaluates whether quarantine decisions correlate with actual failures.** Ruling: it evaluates **INTERNAL CONSISTENCY**, not **TASK PERFORMANCE**. Task performance remains EVA's. **The distinction is the justification, and it is an authority-boundary justification: the Auditor's verdict may disable a DETECTOR and may not confirm a CAPABILITY** |
> | **4** | **a second fitness function** | ❌ **NO** | `SO-R184.1`/`SO-INV-23`: no P0-08 quantity enters fitness. `P0-07 HOM-R14.1` applies: observations enter feasibility and charge only |
> | **5** | **a second provenance system** | ❌ **NO — MERGED** | `OBJ-01` carries `P0-03`'s `root_commit`/`causal_depth`/`corr_class`; records live in `P0-07 EVO4`'s hash-chained K-only chain; `OBJ-28` is a `P0-03` canonical event |
> | **6** | **a second communication system** | ❌ **NO — MERGED** | `SO-C22.3`: **a workspace broadcast IS a `P0-03` message** of the broadcast class, with all S2 fields. No workspace-specific format, warrant rule, or dedup |
> | **7** | **a second immutable kernel** | ❌ **NO — MERGED** | `SO-R165.2`: the recovery root is `P0-02`'s EIK + K's anchored stores + `[RO-13]`'s declared plans + `SO-INV-02`'s default rule. **Nothing new is immutable** |
> | **8** | **a second safety kernel** | ❌ **NO** | containment authority is the EIK's; the ladder is `Cell §18.2`'s, inherited verbatim (`SM-06`); the cap is `Cell §17`'s. **P0-08 adds no safety act of its own** |
> | **9** | **a second task definition** | ❌ **NO** | `SO-R185.3(a)`: detector capability is evaluated against EVA's probes and `G4`'s classes, which are `P0-01`'s. **P0-08 defines no perturbation classes of its own (`XD-01`: marked, not duplicated)** |
> | **10** | **a second objective function** | ❌ **NO** | nothing in P0-08 is optimized. `SO-R130.1` permits *priority allocation* under a floor; allocation is not optimization, and `P0-07 HOM-R73.2`'s principle applies: **no solver, and there must not be one** |
>
> ### **SO-R209.2 — THE RESULT: TEN SEARCHES, NINE CLEAN, ONE CANDIDATE FOUND AND JUSTIFIED.** **[DERIVATION]**
> **The Integrity Auditor is the only mechanism in P0-08 that performs an evaluation, and its independent authority
> boundary is justified by what its verdict may and may not do: it may disable a detector; it may not confirm a
> capability, alter a status, allocate a resource, or authorize an act.**
> **⟹ `SO-R209.3 — THE ONE MECHANISM THAT CAME CLOSEST TO BEING A HIDDEN CONTRACT, AND IT WAS NOT ON §209'S LIST:
> `OBJ-03`'s COVERAGE RECORD.** Coverage is a *global* quantity about *who observed what*, computed by K, consumed by
> every health-read in P0-01…P0-08, and the sole instrument for six of §135's eight silence causes. **That is the shape
> of an epistemic authority.** It is not one, for three reasons: **it makes no claim about truth (only about
> observation) · it is derived, never declared (`SO-C11.1`'s observability axis) · and it cannot be consumed without
> `gap_class`, which is its own limitation stated in the same read (`SO-INV-22`).**
> **`[OPEN: OR-S35]` — coverage is K-written, K-evaluated, and K-consumed. `P0-07 OR-H1`, sixth appearance, and there
> is no internal separation available. Bounded by auditability (`[RO-13]` audits), not broken.**

---

# §209A — VOLUME G LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§185, §186, §187, §188, §189, §190, §191, §192, §193, §194, §195, §196, §197, §198, §199, §200, §201, §202, §203, §204, §205, §206, §207, §208, §209** |
| Rules introduced | **SO-R185.1–.8, R186.1–.2, R187.1–.2, R188.1–.2, R189.1–.2, R190.1–.3, R191.1, R192.1–.2, R193.1–.2, R194.1, R195.1, R196.1–.3, R197.1, R198.1–.2, R199.1–.2, R200.1, R201.1–.2, R202.1, R203.1–.2, R204.1, R205.1–.4, R206.1–.2, R207.1–.2, R208.1–.3, R209.1–.3** |
| **§185 detector evolution** | **implementation MAY evolve; parameters MAY NOT** (`P0-07`'s who-exists / who-could-exist distinction applied to detectors) · **MAIN FINDING: `X-S2` — SELECTION FOR BLIND SPOTS WAS LIVE**, because containment cost is real and under-detection avoids it · **AMENDMENT 17 REQUESTED: `G6`'s denominator excludes detection and containment cost, charged to B10 — the same fix as `P0-07`'s X-H5/amendment 5** · residual `OR-S29` (a blind spot whose faults never manifest has no cost either) · **4 integrity quantities, and the third (COVERAGE CONTRIBUTION) is the only one that can detect an ABSENCE** |
| **§186–§189** | immune: capability ✅ / authority ❌ · repair: strategies ✅ / privilege ❌ (**not expressible**) · self-model: schema ❌ / content not heritable / observational capability ✅ (**what evolves is the INSTRUMENT, not the RECORD**) · metacognition: forecasting ✅ / update rule, calibration, error computation ❌ |
| **§190–§195 the six firewalls** | **all six proved by enumeration of writers, not by assertion.** §190's one near-miss inherited (`mutation_rules` — evolution chooses its optimizer from a governance-declared set, cannot enlarge it) · **§193's finding: P0-08 REQUIRES A SECOND FIREWALL (FW-6) because monitoring is ALLOCATION, not SELECTION, and no tier is involved** |
| **§196 developmental gradient** | **`P0-06 A22` NOT CLOSED AND WIDENED BY THREE ROUTES** (fault→`fate_bias` · attention→field geometry · quarantine→field geometry); the self-model route is **CLOSED-STRUCTURAL** · **`SO-INV-26`: a containment act that alters a developmental field must be recorded as perturbative, or a later developmental anomaly has no traceable cause** · `OR-S30` |
| **§197–§199 `P0-07` dependencies** | **X-H6: 3 P0-08 sites depend on `G4`; MARKED, NOT DUPLICATED** · **BC-H7 ⟹ `BC-S2`, a second instance of the same shape entered one step earlier (through DETECTION); UNCLOSABLE** · **A170 ⟹ `SO-INV-24`: a recovery plan's scope must reference an EXISTING envelope — the gap §199 exists to find, and the widest one available, because deployment is the only act with no conservation law** |
| **§200–§204 preserved residuals** | **governance capture: P0-08 CANNOT detect it; OP is NOT a valid observation subject; the one weak signal is the RATE of OP-level acts (detects acceleration, not capture) — `[NON-CLAIM]` an organism-level immune system does not solve governance capture** · **guarantor limit: 5 external reliance points, none internally provable** · **dim-6/semantic self-reference: WORSENED in two specific ways** · **`P0-04`'s three OPEN attacks preserved; P0-08 adds ONE new self-model-dependent evidence pathway (visible, correlatable, NOT detectable); per-reader coverage NOT represented (`OR-S33`)** |
| **§205 provisional drift** | **a repair consumes UDB · may NOT re-base an anchor (third of three event classes) · `SO-R205.3`: a learning-target-displacing repair uses `P0-05`'S GATE — NO SECOND PATHWAY** · intervention classes are declared and closed (LEARNING / STRUCTURAL / CONFIGURATION); undeclared ⟹ invalid |
| **§206–§207 authority** | developmental awareness ≠ authority (**the one real risk is §196's route 1**) · **severity raises a SCOPE's priority, NEVER a SUBJECT's — clause (d) is load-bearing, because priority attached to a subject would let a component manufacture severity to acquire resources (`P0-07 A101` re-entered through the fault door)** |
| **§208 dependency graph** | **22 dependencies (XD-01…XD-22) across 6 edge types (DEP/IFC/AUTH/FLOW/VER/CONT) · 13 ✅ · 5 ⚠️ blocking-or-conditional · 6 ❌ preserved residuals · one apex (OP), one external verifier (EVA), one off-substrate writer (K), no inter-contract cycles except `BC-S2`/`BC-H7`** |
| **§209 hidden contracts** | **10 searches: 9 CLEAN, 1 CANDIDATE FOUND AND JUSTIFIED (the EIK Integrity Auditor — evaluates INTERNAL CONSISTENCY, not TASK PERFORMANCE; may disable a detector, may not confirm a capability)** · **`SO-R209.3`: the closest mechanism to a hidden contract was not on the list — `OBJ-03` COVERAGE, which has the shape of an epistemic authority and is not one for three stated reasons (`OR-S35`)** |
| Contradictions opened | **X-S2** (selection for blind spots — `P0-07` X-H5 in a new domain; **RESOLVED by amendment 17**) |
| New invariants | **SO-INV-24** (a recovery plan's scope must reference an existing envelope) · **25** (practical indispensability is not authority; the only response is governance) · **26** (a containment act that alters a developmental field is recorded as perturbative) |
| Amendments requested | **16** (`P0-02 §35.2` gains **IND-10 CAUSAL**, measured by `P0-05 R15.8`'s `inbreeding_F`) · **17** (`Cell G6`'s denominator excludes detection and containment cost, charged to **B10**) |
| Open research raised | **OR-S29** (selection for a never-manifesting blind spot) · **OR-S30** (`A22` widened by three routes) · **OR-S31** (governance capture preserved UNSOLVABLE) · **OR-S32** (dim-6 correlation made more consequential by self-models) · **OR-S33** (per-reader coverage not represented; routed to `P0-04`) · **OR-S34** (the intervention-class mapping is a governance declaration) · **OR-S35** (coverage is K-written, K-evaluated, K-consumed — `OR-H1`'s sixth appearance) |
| Verification instruments | **SOMon-21** (no genome diff writes an `OBJ-09` field) · **SOMon-22** (`G6`'s denominator excludes detection and containment cost) · **SOMon-23** (no `OBJ-15` scope references a non-existent envelope) · **SOMon-24** (a containment act on a developmentally active scope emits a perturbative record) · **SOMon-25** (no repair re-bases an anchor) |

**Next:** `70_` Vol H — §122 the requirement traceability matrix, §123 the requirement-to-attack trace, §124 the
attack-to-control trace, and the full attack catalogue (**A172 onward**, continuing `P0-07`'s A171).
