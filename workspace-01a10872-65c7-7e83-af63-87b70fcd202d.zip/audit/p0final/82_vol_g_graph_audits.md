# P0 FINAL — VOLUME G (§35–§41)
## The Seven Graph Audits: Writer, Authority, Epistemic, Deontic, Learning, Evolution, Self-Model

---

# §35 — THE WRITER-SEPARATION AUDIT

> ### **PF-R35.1 — THE COMPLETE WRITER GRAPH FOR SECURITY-CRITICAL OBJECTS.** **[NORMATIVE]**
> **Seven attributes per object, as §35 requires: writer · validator · consumer · authority · storage location · mutation
> path · rollback path.**
>
> | Object | **Writer** | **Validator** | **Consumer** | **Authority** | **Storage** | **Mutation path** | **Rollback path** |
> |---|---|---|---|---|---|---|---|
> | **genome** | **K**, on an EIK ticket | **16 gates + `FORBIDDEN_BLOCKS`** | EVA, K | **EIK** | **off-substrate** | E9 diff only | **hash + epoch**, never position |
> | **genome artifact store** | **K** | hash chain | `P0-07 HM12` | **EIK** | **off-substrate** | append-only | `P0-07 HM12` |
> | **provenance chain** | **K ONLY** | hash chain, `SEALED` terminal | all | **K** | **off-substrate** | **NONE — append-only** | **NONE — a rollback is itself an event** |
> | **learned state θ** | the component, budgeted | **UDB (`P0-05 R0.1`)** | the component | `P0-05 §9` | on-substrate | Λ0/Λ1 within `Δ_MAX`/`DELTA_BUDGET` | **to `θ_anchor(S)`** |
> | **anchors `θ_anchor(S)`** | **K / EVA ONLY** | the verification gate | UDB computation | **EVA** | **off-substrate** | **only on `IMPROVED`/`NEUTRAL`** | n/a — it IS the rollback target |
> | **memory records + epistemic status** | **`P0-04`'s rules, K-administered** | Merkle root | all | `P0-04` | `P0-04`'s store | append; **no organism rewrite of historical evidence** | epoch restoration |
> | **evidence roots** | `P0-04` | **disjointness (`Cell §15.4`)** | corroboration | `P0-04` | `P0-04` | — | — |
> | **`PopulationState`** | **K** | 14-field schema | `P0-07` selection, `P0-08` | **K** | **off-substrate** | per generation | **`P0-07 HOM-INV-37`: a population is NEVER restored** |
> | **the ledger** | **K** | hash chain | all budget consumers | **K** | **off-substrate** | per window | — |
> | **reserve sizes B0…B13** | **`[RO-13]`** | — | K | **`[RO-13]`/OP** | governance record | **`[G]` declaration only** | — |
> | **detector parameters `OBJ-09`** | **`[RO-13]`** | — | K, the EIK | **`[RO-13]`** | governance record | **`[RO-13]` ONLY — `SOMon-21` asserts no genome diff writes them** | — |
> | **observation scope `OBJ-02`** | **`[RO-13]`** | — | all observers | **`[RO-13]`** | governance record | **an observer MAY NOT widen it** | — |
> | **`CoverageRecord OBJ-03`** | **K** | `OBJ-28` events | **every health consumer in all eight contracts** | **K** | **off-substrate** | per scope-window | **corrupt ⟹ read as ZERO coverage (`SO-INV-02`)** |
> | **`FaultOccurrence OBJ-04`** | **the observer — MULTI-WRITER BY DESIGN** | K's confirmation | K, EIK | this contract's rules | `P0-04` class | **append-only, never merged** | **never — `SO-R146.2`** |
> | **`Diagnosis OBJ-06` status** | **K** | `SO-C9.2`'s excluded drivers | EIK, `[RO-13]` | **K; EVA for `CAUSE-VERIFIED`** | `P0-04` | **monotone; `REJECTED` is a new status** | **never reverted** |
> | **`Incident OBJ-07`** | **EIK** | `SM-05` | all | **EIK** | `P0-04` | open→closed, many concurrent | — |
> | **`QuarantineState OBJ-11`** | **EIK** | `Cell §18.2`'s ladder | all | **EIK** | `P0-04` | rung transitions, one per interval | **EIK clears (`Cell R15.2`)** |
> | **`FreezeOrder OBJ-17`** | **EIK / OP** | nine mandatory fields | all | **EIK below cap; OP at or above** | **off-substrate, immutable once sealed** | issue only | **release by a STRICTLY HIGHER authority** |
> | **`RepairRecord OBJ-13`** | **K** | a non-repairer | EVA, `[RO-13]` | **K** | `P0-04` | append-only | — |
> | **`SelfModelState OBJ-18`** | **SPLIT: subject writes CONTENT; K writes version, freshness, status, `compression_class`** | `SO-INV-34` (K validates compression) · `SOMon-3` (locality) | K, EVA | **`P0-05 R59.1`** | **`P0-04` RECORD CLASS — not a store** | version increments, monotone | **a prior version is `SUPERSEDED` and RETAINED** |
> | **`CapabilityRecord OBJ-19`** | **SPLIT: subject claims; K status; EVA confirms** | `SM-14` | gates | **EVA** | `P0-04` | status transitions | **a rolled-back subject's capabilities are `STALE`** |
> | **`MetacognitiveRecord OBJ-21`** | **THREE-WAY SPLIT: subject forecasts; K computes error; EVA calibrates** | `SM-16` | K, EVA | **EVA** | `P0-04` | append per cycle | — |
> | **`ObserverSet OBJ-26`** | **K** | `SM-21` | EVA, `[RO-13]`, `SM-03`/`SM-04` | **K** | **off-substrate** | recomputed on membership or `corr_class` change | **uncomputable ⟹ `effective_sources = 1`** |
> | **`AttentionAllocation OBJ-23` / `WorkspaceSlot OBJ-24`** | **K** | `SM-18`/`SM-19` | the subject / subscribers | **K; `[RO-13]` declares the rule** | `P0-07`'s ledger | per window | — |
> | **identity (cell, lineage, circuit)** | **K** | no-reuse (`P0-06 R8.3(c)`) | all | **K** | **off-substrate** | **issued once, never reused** | **never — a replacement is a NEW identity** |
> | **authorization records** | **EIK** | **epoch binding** | enforcement | **EIK** | **off-substrate** | per epoch | **⚠️ `PF-D-18`: `PF-AM-26` required — a rollback must open a NEW epoch with EMPTY authorizations** |
> | **the objective vector** | **OP** | — | EVA, `P0-07` selection | **OP** | governance record | **OP ONLY** | — |
> | **setpoints, gates, thresholds** | **`[RO-13]` / OP** | — | K, the EIK | **`[RO-13]`/OP** | governance record | **`[G]` — `P0-07 HOM-INV-10`** | — |
> **⟹ `PF-R35.2 — GRAPH SUMMARY: 28 security-critical objects · **24 have a single writer or a declared disjoint
> field-group split** · 1 is deliberately multi-writer (`OBJ-04`, append-only, with single-writer interpretation) · 3 have
> an unresolved or defective rollback/epoch interaction (`PF-D-18`, `PF-D-19`, and `OBJ-03`'s dependence on K per
> `PF-CSC-24`).**
> **Storage: **11 objects are off-substrate** and depend on `XD-04`, which no contract provides. **That is the single
> largest structural dependency in the composed architecture and it has been open since `P0-06`.**
>
> ### **PF-R35.3 — THE SEARCH §35 REQUIRES: «SUBJECT-WRITTEN FIELD + SUBJECT-VALIDATED CONSTRAINT».** **[HIGH PRIORITY]**
> **Five instances exist in the corpus. Two were already found and fixed by `P0-08`'s own audits; one was already
> registered; **TWO ARE NEW AND ARE THIS AUDIT'S HIGHEST-PRIORITY WRITER FINDINGS.****
>
> | # | Object.field | **Who writes it** | **Who validates the constraint on it** | **Status** |
> |---|---|---|---|---|
> | **1** | `P0-08 OBJ-18.compression_class` | the subject *(originally)* | the subject *(originally)* | ✅ **FOUND AND FIXED BY `P0-08 §242` → `SO-INV-34`: moved to the K-written field group** |
> | **2** | **an intervention targeting an observer** | the repair proposer | the proposer's own classification of its target | ✅ **FOUND AND FIXED BY `P0-08 §239` → `SO-INV-33`: an observer-targeting intervention is NOT a repair; it is a `[RO-13]` detector change** |
> | **3** | `P0-06`'s organizer emission field | **the organizer cells generate it** | **K warrants it, but the SPEC is what bounds it — and `OR-D6` records that within-spec steering is undetectable** | ⚠️ **ALREADY REGISTERED as `P0-06 D-D05`, BROKEN-STRUCTURAL, residual `OR-D6`/`A22`. `P0-08 §196` widened it by three routes** |
> | **4** | **`P0-08 OBJ-18.locality_class`** | **THE SUBJECT** | **THE SUBJECT** | ❌ **NEW — `PF-D-20`, SEE BELOW** |
> | **5** | **`P0-08 OBJ-25 IndependenceClaim`** | **THE CLAIMANT** | **THE CLAIMANT** | ❌ **NEW — `PF-D-21`, SEE BELOW** |
>
> ### **PF-D-20 — `locality_class` IS THE SAME DEFECT AS `compression_class`, AND `SO-INV-34` FIXED ONLY ONE OF THEM.** **[HIGH PRIORITY]**
> **`P0-08 SO-C4.5` lists `locality_class` as a field of `OBJ-18`, whose CONTENT the subject writes. `SO-R138.4` states:
> *"`locality_class` is a MANDATORY field of `OBJ-18`. A self-model that aggregates a LOCAL-ONLY fact is invalid."***
> **⟹ THE CONSTRAINT IS ENFORCED AGAINST A FIELD THE CONSTRAINED PARTY WRITES. A subject may declare that a sensitive fact
> is NOT local-only, and then aggregate it — satisfying `SO-R138.4` literally while destroying the protection `SO-R138.3`
> exists to provide (own `θ` and `UDB` position · `P0-04` evidence roots and their disjointness · own detector thresholds ·
> `inbreeding_F`).**
> **`P0-08 §242` found exactly this shape for `compression_class` and fixed it with `SO-INV-34`; it did not check the
> adjacent field. `P0-08 SO-R242.3`'s own general lesson — *a constraint on a subject-written field must itself be validated by
> a non-subject writer, or it is documentation* — was stated and then not applied to the field beside the one it fixed.**
> **⟹ `PF-R35.4 — THE FIX IS THE SAME AND IS ONE LINE: `locality_class` MOVES TO THE K-WRITTEN FIELD GROUP OF `OBJ-18`,
> VALIDATED BY K AGAINST `SO-R138.3`'S TABLE.** Category: **PROPOSED AMENDMENT `PF-AM-27`**, affecting `P0-08` §138 and
> `SO-C4.5`. Security: **material and positive** — it closes an aggregation route for four LOCAL-ONLY fact classes,
> including `P0-04`'s evidence-root disjointness, whose exposure would let an adversary engineer overlap and manufacture
> corroboration. Scalability: none. Compatibility: additive. Ratification: required. **Changes an existing invariant: NO —
> it moves a field's writer.**
>
> ### **PF-D-21 — AN `IndependenceClaim` IS DECLARED BY THE PARTY THAT BENEFITS FROM THE DECLARATION.** **[HIGH PRIORITY]**
> **`P0-08 OBJ-25`'s writer is "the claimant", and `SO-INV-20` requires the claim to name its dimensions and claim-type.
> `P0-08 OR-S36` already records the residual: *"a claimant may omit a dimension it knows it shares."***
> **⟹ THIS AUDIT RECLASSIFIES IT: `OR-S36` IS NOT MERELY AN OPEN RESEARCH ITEM. IT IS THE FIFTH INSTANCE OF §35'S
> HIGH-PRIORITY PATTERN, AND UNLIKE THE OTHER FOUR IT HAS NO AVAILABLE FIX.**
> **Why no fix is available: the omitted dimension is, in the four checkable cases (`IND-1`, `IND-3`, `IND-4`, `IND-5`),
> detectable by K from the observers' identities, lineages, model classes and hardware classes — so K **can** validate
> those. **The undetectable case is `IND-6` (latent assumptions), which `P0-03 COMM-INV-18` establishes cannot be detected
> from inside the system at all.** A claimant that omits `IND-6` cannot be caught, because nobody can assess `IND-6`.**
> **⟹ `PF-R35.5 — THE PARTIAL FIX, AND ITS EXACT LIMIT: K MUST DERIVE AND OVERWRITE THE `IND-1/3/4/5/7` FIELDS OF EVERY
> `OBJ-25` FROM ITS OWN REGISTRIES, LEAVING THE CLAIMANT ONLY `IND-2` (data), `IND-6` (assumptions), `IND-9` (governance)
> AND `IND-10` (causal) TO SELF-DECLARE — AND EVERY SELF-DECLARED FIELD MUST BE MARKED `SELF-DECLARED` IN THE RECORD.**
> **The marking is the load-bearing part: it converts an unverifiable claim into a **labelled** unverifiable claim, which
> is what `P0-04 IG-6`'s `UNKNOWABLE_FROM_INSIDE` state does for memory, and `P0-04`'s own note applies verbatim: *"this
> state is representable but not detectable"* — and it is explicitly ❌ **not** "no problem detected".**
> **Category: **PROPOSED AMENDMENT `PF-AM-28`**, affecting `P0-08 OBJ-25` and `SO-INV-20`. Security: positive for four
> dimensions, **neutral for `IND-6`, which is preserved as undetectable**. Ratification: required. **Changes an existing
> invariant: NO — it changes a field's writer for five of ten dimensions.**

---

# §36 — THE AUTHORITY-GRAPH AUDIT

> ### **PF-R36.1 — THE COMPLETE AUTHORITY GRAPH.** **[NORMATIVE]**
> ```
>                                        ╔══════════╗
>                                        ║    OP    ║  ← THE APEX. objective · envelopes · B11 · deployment ·
>                                        ╚════╤═════╝    freeze above Cell §17's cap · FI retirement · ratification
>                              AUTHORIZES    │          ⚠ G24: a captured OP is indistinguishable from a legitimate
>                        ┌────────────────────┼───────────────────────┐     OP BY ANY MECHANISM OP AUTHORIZES
>                        ▼                    ▼                       ▼     (UNSOLVABLE — preserved, not mitigated)
>                 ╔════════════╗      ╔══════════════╗          ╔═══════════╗
>                 ║  [RO-13]   ║      ║     EIK      ║          ║    EVA    ║
>                 ║ POLICY     ║      ║ DEONTIC      ║          ║ MEASURES  ║
>                 ║ AUTHOR     ║      ║ AUTHORITY    ║          ║ — DOES NOT║
>                 ╚═════╤══════╝      ╚══════╤═══════╝          ║ AUTHORIZE ║
>      DECLARES         │            PERMITS │                  ╚═════╤═════╝
>   scopes·detectors·   │           quarantine·freeze·            VERDICTS│
>   severity·policies·  │           replication tickets·                │
>   plans·floors·       │           Λ3 structural change                │
>   mappings·classes    │                     │                         │
>                       └──────────┬──────────┴─────────────┬───────────┘
>                                  ▼                        ▼
>                          ╔═══════════════╗        ╔══════════════════╗
>                          ║       K       ║        ║  THE ORGANISM    ║
>                          ║ OFF-SUBSTRATE ║        ║  cells · circuits║
>                          ║ SINGLE WRITER ║        ║  regions · pops  ║
>                          ║ ⚠ OR-H1       ║        ║  ∅ AUTHORITY SET ║
>                          ╚═══════════════╝        ╚══════════════════╝
>                                  ▲                        │
>             ELEVEN SENSORS/SUBJECTS — NO AUTHORITY NODES ──┘
>   memory · learning · development · homeostasis · immune · self-model ·
>   metacognition · evolution · attention · workspace · observation
>   each may TRIGGER (supply evidence) and NONE may AUTHORIZE
> ```
>
> ### **PF-R36.2 — THE GRAPH'S FOUR PROPERTIES, EACH OF WHICH IS A RESULT.** **[DERIVATION]**
> **(a) EXACTLY THREE AUTHORITY NODES (OP, `[RO-13]`, EIK) AND ONE MEASUREMENT NODE (EVA).** `P0-02 R0.1`'s axis
>     separation is what keeps EVA out of the authority set: **KC does not measure, EVA does not permit.**
> **(b) ELEVEN SENSORS/SUBJECTS, NONE OF WHICH IS AN AUTHORITY NODE.** `PF-R8.1` tested all fourteen mechanisms §8 names
>     and found ten that cannot authorize and four that trigger, determine feasibility, or execute — and `PF-R8.6` states
>     the distinction: **the immune layer is a SENSOR in the deontic graph, not a node in it.**
> **(c) THE GRAPH IS A DAG WITH ONE APEX, AND IT HAS NO CYCLE.** Every cycle in the corpus (`BC-H7`, `BC-S2`, `HC-S1…S4`)
>     is a cycle in the *information* or *resource* graph, not in the authority graph. **⟹ Authority never flows back into
>     itself, which is why `PF-R240`'s twelve capability→authority routes are all closed or structurally absent.**
> **(d) NO BIOLOGICAL-ANALOGUE NAME APPEARS AS AN AUTHORITY NODE — AND THE CORPUS DELIBERATELY REFUSED TO CREATE THEM.**
>     `P0-07` rejected an **"evolutionary controller"** · `P0-06` rejected a **"giant developmental controller"** ·
>     `P0-08 SO-C3.3` ruled that a **FaultAuthority / IncidentCommander**, a **SelfModelStore**, and a
>     **DiagnosisEngine / RootCauseAnalyzer** DO NOT EXIST.
> **⟹ `PF-R36.3 — THE NAMING DISCIPLINE IS ITSELF A CONTROL, AND §36'S REQUIREMENT IS DISCHARGED BY IT.** A component
> named "controller", "monitor", "regulator", "selector" or "organ" acquires no authority in this architecture **because
> no such component was ever created** — the four candidate names above were proposed by their own contracts' analyses and
> rejected there. **Authority resides in three offices and one measurement body, all of which are governance or external,
> and the eleven biological analogues are sensors.**
> **⚠️ THE ONE RESIDUAL: `PF-R8.10`'s — allocation determines FEASIBILITY, and feasibility determines what survives to be
> authorized. Over many windows an allocator shapes the population's composition without ever authorizing anything.
> `P0-07 HOM-INV-19`'s share ceiling and its turnover bound are the instruments; `OR-H13`'s practical indispensability is
> the residual, and `P0-08 SO-INV-25` is `[DECLARATIVE]` with no instrument.**

---

# §37 — THE EPISTEMIC-GRAPH AUDIT

> ### **PF-R37.1 — THE COMPLETE EPISTEMIC FLOW, WITH AN OWNER PER STAGE.** **[NORMATIVE]**
> ```
>   OBSERVATION ──▶ EVIDENCE ──▶ WARRANT ──▶ BELIEF ──▶ CONFIDENCE ──▶ PREDICTION ──▶ OUTCOME ──▶ REVISION
>       │             │            │           │            │              │             │           │
>    P0-08         P0-04        P0-03       P0-04        P0-04          P0-05        P0-01 EVA    P0-05 +
>    OBJ-01      record +     root_commit  the ladder   calibration    the register   + the        P0-04
>    the observer  status     causal_depth               reference                  environment  re-statusing
>                             corr_class
>                             calib_ref
>       │                                                                    ▲
>       └────────── EXTERNAL GROUNDING ENTERS AT EXACTLY TWO POINTS ──────────┘
>                 (1) WARRANT's ROOT: the anchored registry (K-held, off-substrate)
>                 (2) OUTCOME: EVA's verdict — THE ONLY STAGE NOT PRODUCED INSIDE THE ORGANISM
> ```
> ### **PF-R37.2 — WHERE EXTERNAL GROUNDING ENTERS, AND WHY ONLY THERE.** **[DERIVATION]**
> **Six of the eight stages are internal. Two are not:**
> **(1) WARRANT's root** — a `root_commit` resolves against an **anchored registry** that K holds off-substrate. An
>     internally-fabricated root does not resolve, so the chain's base is external to the observer.
> **(2) OUTCOME** — **EVA's verdict is the only stage in the entire epistemic flow that is not produced inside the
>     organism.** `P0-05 R42.3`: *a simulated probe is not a probe.* `R48.1`: *self-generated data is SC-1, provisional
>     only — never anchors, never satisfies a probe, never contributes to fitness.*
> **⟹ `PF-R37.3 — AND REVISION DEPENDS ON OUTCOME, WHICH IS THE WHOLE STRUCTURE: `P0-05 R0.1` re-anchors ONLY on
> `IMPROVED` or `NEUTRAL` — never on `UNKNOWN`, never on `REGRESSED`. Since those verdicts are EVA's, **no revision of
> retained state occurs without external grounding.** The epistemic graph is open at exactly one place, and that place is
> load-bearing for the entire downstream chain.**
>
> ### **PF-R37.4 — CAN INTERNAL REPETITION CREATE EXTERNAL GROUNDING? ❌ NO, AND THE PROOF IS THREE RULES THAT ALL POINT THE SAME WAY.**
> | Rule | Contract | Effect on repetition |
> |---|---|---|
> | **warrant is monotone NON-INCREASING along derivation** | `P0-03 COMM-INV-08` | **every re-transmission, re-derivation, aggregation, or re-citation can only LOSE warrant. Repetition is derivation, so repetition strictly cannot add warrant** |
> | **repetition is not independent evidence** | `P0-04` | a repeated record does not raise a status |
> | **consensus is collapsed to `effective_sources` BEFORE it is counted** | `P0-08 SO-INV-18` / `OBJ-26` | N agreeing observers that share a relevant dimension count as ONE |
> **⟹ `PF-R37.5 — THE THREE RULES ARE NOT REDUNDANT; THEY OPERATE ON THREE DIFFERENT OBJECTS.** `COMM-INV-08` constrains
> the WARRANT of a message chain. `P0-04`'s rule constrains the STATUS of a record. `SO-INV-18` constrains the COUNT of a
> corroborating set. **An architecture with any one of the three alone would have a repetition→grounding route through the
> other two.**
> **⚠️ THE LIMIT, STATED SO THE PROOF IS NOT OVERCLAIMED: these three rules prevent repetition from creating GROUNDING.
> They do not prevent repetition from creating COHERENCE — and `P0-08 §233`/`OR-S39` is the construction in which a fully
> coherent, internally well-grounded, repeated, corroborated-by-correlated-observers belief is false. **Coherence is not
> correspondence, and no internal rule can bridge that, because bridging it requires comparing a belief to the world.**

---

# §38 — THE DEONTIC-GRAPH AUDIT

> ### **PF-R38.1 — THE COMPLETE DEONTIC FLOW.** **[NORMATIVE]**
> ```
>   POLICY ──▶ AUTHORIZATION ──▶ ENFORCEMENT ──▶ ACTION ──▶ AUDIT
>     │              │                │            │          │
>   OP / [RO-13]   EIK              EIK / K     the organism   K's records
>   objective·     epoch-bound·     gates·                   + OP's review
>   setpoints·     per-act·         quarantine·              + P0-04 provenance
>   scopes·        expiring         freeze·                  (append-only, SEALED)
>   mappings                        serialization
>     ▲                                                                    │
>     └────── THE ONLY EDGE FROM THE EPISTEMIC GRAPH INTO THIS ONE ────────┘
>                    IS *TRIGGER*, AND IT IS AN EVIDENCE EDGE, NOT AN AUTHORITY EDGE
> ```
> ### **PF-R38.2 — CAN AN EPISTEMIC PROCESS SILENTLY ENTER THE DEONTIC GRAPH? ❌ NO — AND THE TEST IS EXHAUSTIVE.**
> **Six epistemic objects could plausibly enter. Each is tested:**
> | Epistemic object | **May it enter the deontic graph?** | As what | Rule |
> |---|---|---|---|
> | **an observation** | ⚠️ **AS A TRIGGER ONLY** | evidence for an EIK decision | `P0-08 D-S01`: no field is an authority field |
> | **a diagnosis** | ⚠️ **AS A TRIGGER ONLY** | evidence | `SO-C9.2`: promotion requires a non-diagnoser or EVA |
> | **a capability claim** | ❌ **NO** | — | **`P0-07 HOM-R24.2`: `Ê(·)` is excluded from EVERY gate**; `CLAIMED` satisfies none |
> | **a confidence value** | ❌ **NO** | — | **`P0-08 SO-INV-19`**: confidence is not an input to arbitration, attention, promotion, scope, or gap class |
> | **a coverage figure** | ⚠️ **AS A TRIGGER ONLY** | evidence of a silence | `SO-INV-22`: it cannot be read without `gap_class` |
> | **a trust value** | ⚠️ **AS A DEONTIC QUANTITY, NOT AN ALETHIC ONE** | `Cell I-27`'s `Beta(α,β)` governs what a cell may be relied on to do | **`P0-02 R0.1`'s ALETHIC/DEONTIC split — and `PF-R19.3`: trust may rise with calibration, warrant may not** |
> **⟹ `PF-R38.3 — THE ENTRY POINT IS *TRIGGER*, AND `PF-R8.6` STATES WHY THAT IS NOT A VIOLATION: a sensor supplies
> evidence and an office decides. The EIK's decision is its own; the immune layer's detection is an input.**
> **⚠️ THE RESIDUAL IS THE ONE §38 EXISTS TO EXPOSE, AND IT IS NOT AN ENTRY INTO THE DEONTIC GRAPH — IT IS CONTROL OF ITS
> INPUTS: `OR-S41`. A component controls what it reports, and therefore controls the evidence on which the EIK, `[RO-13]`
> and OP decide. **A sensor that lies to a legitimate authority produces a legitimate decision on false inputs.**
> The bounds are `SO-INV-21` (occurrence and report are separate, so the gap is auditable), `SUPPRESSION-SUSPECTED` ⟹
> `[RO-13]`, `P0-03`'s absence detectors, and `SO-R185.7`'s coverage contribution. **The limit is `OR-S1`: the audit
> compares reports against DECLARED expectations, never against what happened.**
> **⟹ `PF-R38.4 — SO THE DEONTIC GRAPH HAS NO EPISTEMIC ENTRY, AND THE EPISTEMIC GRAPH HAS AN UNCLOSED INFLUENCE OVER
> THE DEONTIC GRAPH'S INPUTS. Those are different failures, and conflating them would either overclaim the closure or
> understate the residual.**

---

# §39 — THE LEARNING-GRAPH AUDIT

> ### **PF-R39.1 — THE COMPLETE LEARNING FLOW, WITH THE FOUR CONSTRAINT INTERSECTIONS MARKED.** **[NORMATIVE]**
> ```
>   EXPERIENCE ─▶ OBSERVATION ─▶ UPDATE PROPOSAL ─▶ AUTHORIZATION ─▶ PARAMETER CHANGE ─▶ VALIDATION ─▶ RETAINED STATE
>      │             │                 │                  │                 │                 │              │
>   the env.     P0-05's 14        LearnedChange      Λ-CLASS          Δ_MAX /           ★THE GATE★      θ_anchor(S)
>                SIGNAL KINDS      provisional=TRUE   DEPENDENT        DELTA_BUDGET /    K-only,          re-based ONLY
>                — A CLOSED SET                       Λ0/Λ1: none      Θ_MAX             held-out         on IMPROVED
>                ⟵ P0-08's OBJ-01                     Λ3: SEPARATE     + UDB (R0.1)      EXTERNAL PROBE    or NEUTRAL
>                  IS NOT IN IT                       authorization                                       — never UNKNOWN
>                  (SO-INV-27)                        + STRUCTURAL_                                        — never REGRESSED
>                                                     BUDGET (R15.6)
>      ▲              ▲                  ▲                 ▲                  ▲                 ▲
>      │              │                  │                 │                  │                 │
>   [EVIDENCE]     [GOVERNANCE]        [MEMORY]         [GOVERNANCE]        [RESOURCE]        [GOVERNANCE
>   the signal's   SG-14 governance   R47.1/           Λ3 requires an      B7's THREE         + EVIDENCE]
>   source_class   directives admit   MEM-INV-18:      EIK authorization   NON-FUNGIBLE       the probe is
>   (SC-1/SC-3)    CAPACITY ONLY      no memory→       and a separate      FLOORS + the       EVA's, and the
>   R48.5: external                   genome           budget              PROBE BUDGET       probe budget IS
>   ORIGIN is not                                                            is the           the learning rate
>   external EVALUATION                                                      learning rate
> ```
> ### **PF-R39.2 — THE FOUR INTERSECTIONS, AND WHAT EACH ONE CONTRIBUTES.**
> | Intersection | **What it constrains** | The rule |
> |---|---|---|
> | **GOVERNANCE** | **the CAPACITY to change, never the direction of change** | `SG-14`: a governance directive is a **capacity** signal only · `Λ3` requires EIK authorization + a separate `STRUCTURAL_BUDGET` · budgets are `[G]`-declared |
> | **EVIDENCE** | **the WARRANT of a signal, and therefore how far it may displace state** | `R48.5`: **external ORIGIN is not external EVALUATION** — corpus-derived signals are ruled PER ITEM · `R42.4`: SC-1 displacement is weighted HIGHER in UDB because it is unverified twice over · **`PF-R7.4.4` (`PF-D-12`): a `P0-03 ERROR` message is `SG-3` only if its `root_commit` is EXTERNAL to the learner** |
> | **MEMORY** | **what may NOT become heritable or permanent** | `R47.1`/`MEM-INV-18`: no acquired memory rewrites the genome · `PF-R12.1`'s three firewalls · records are `P0-04`'s and learning may not re-status them |
> | **RESOURCE** | **the RATE of change, and the terminal state when the rate cannot be sustained** | **B7's three non-fungible floors** (learn · vary · verify) · **`R0.1`'s UDB, whose exhaustion STALLS learning at that scope and below** · `R48.4`'s three classified `stall_reason`s |
> **⟹ `PF-R39.3 — THE PROPERTY THAT MAKES THE GRAPH SAFE, AND IT IS A CONSERVATION LAW RATHER THAN A BOUND:**
> > **`P0-05`: «`R0.1` + `R9.2.4` + `R15.4` + `R27.5` TOGETHER MAKE UNVERIFIED DISPLACEMENT **CONSERVED** UNDER EVERY
> > TRANSFORMATION THE LEARNING SUBSYSTEM CAN PERFORM. THAT CONSERVATION PROPERTY — NOT ANY INDIVIDUAL BOUND — IS THE
> > ACTUAL CONTENT OF THE FIX.»**
> **`PF-R39.4` confirms the conservation survives composition: `P0-08 SO-R152.2` makes an unverified REPAIR consume the
> same budget, `SO-INV-28` forbids a repair re-basing an anchor, and `SO-R205.3` routes a learning-target-displacing
> repair through `P0-05`'s own gate. **⟹ There is no second displacement channel, so the conservation law is not bypassed
> by the fault domain.** `PF-CSC-20` is the cascade that would have broken it, and it stops.**

---

# §40 — THE EVOLUTION-GRAPH AUDIT

> ### **PF-R40.1 — THE COMPLETE EVOLUTION FLOW, AND THE FIVE VERIFICATIONS §40 REQUIRES.** **[NORMATIVE]**
> ```
>   VARIATION ─▶ SANDBOX ─▶ EVALUATION ─▶ SELECTION ─▶ INHERITANCE ─▶ DEPLOYMENT ─▶ MONITORING
>      │            │           │            │             │              │             │
>   E9 diff      six non-    EVA, held-   THREE         16 gates +      OP SOLE      P0-08's
>   B7's         sharing     out probes   PARTIES:      FORBIDDEN_      — the one    observation
>   variation    require-    G4's         tier-1        BLOCKS +        act with     layer
>   floor        ments       classes      CONSTRAINT    hash-chained    NO
>                             ⚠ XD-01     tier-2 PARETO provenance     conservation
>                                         tier-3 sampl.  (references,   law
>                                         NO SCALAR      not payloads)
> ```
> | Verification | **Result** | Ground |
> |---|---|---|
> | **acquired state is not silently inherited** | ✅ **VERIFIED — THREE INDEPENDENT FIREWALLS, EACH SUFFICIENT** | `P0-05 §1.2` (`Λ5_GENOME` non-constructible) · `P0-04 R47.1`/`MEM-INV-18` · `Cell R4.5`/`P0-07 HOM-INV-34` (a diff encoding a memory item, belief, or calibration statistic is REJECTED). **And the one permitted channel states its own limit: `HOM-R64.3` — MOTIVATION IS RECORDED, WARRANT IS NOT INHERITED** |
> | **safety invariants remain external** | ✅ **VERIFIED** | `FORBIDDEN_BLOCKS` is immutable · **safety is a TIER-1 CONSTRAINT, never a tier-2 objective component** — an unsafe candidate is INFEASIBLE and never ranked · `P0-07 §83.3`: the objective, the constraint set and `FORBIDDEN_BLOCKS` are all external to the evolving substrate |
> | **evaluator manipulation remains explicitly residual** | ⚠️ **PRESERVED AS RESIDUAL — AND WIDENED** | **`P0-05 RH-2` → `P0-07 D-H17` split it three ways (world arrangement BOUNDED · exhaustion OPEN · context selection CLOSED) → `P0-07 A82/A83` → `P0-08 §133` added SIX routes (4 BOUNDED · 1 BOUNDED-BY-DESIGN · 1 CLOSED-CONDITIONAL). ⟹ `PF-R40.2`: `RH-2` IS WIDER AFTER EIGHT CONTRACTS THAN AFTER FIVE, and every contract that added a mechanism recorded the channel it added rather than claiming closure** |
> | **fitness does not become authority** | ✅ **VERIFIED** | **`P0-07 HOM-INV-29`** · `PF-R8.1`'s fourteen rows · `PF-R36.1`'s graph has no fitness→authority edge · `P0-08 SO-R187.2`: **the repair-success→privilege route is NOT EXPRESSIBLE** |
> | **resource economics cannot secretly become selection preference** | ⚠️ **VERIFIED IN TWO OF THREE DOMAINS; THE THIRD NEEDS AN UNRATIFIED AMENDMENT** | **`P0-07 HOM-INV-16`/FW-2 covers SELECTION** ✅ · **`P0-08 FW-6`/`SO-INV-15` covers OBSERVATION** ✅ · **`PF-AM-23`/FW-7 would cover PROCESSING (attention) — PROPOSED, NOT RATIFIED (`PF-D-14`)** ⚠️ · **and `P0-08` amendment 17 (detection/containment cost out of `G6`) is UNRATIFIED, so `PF-CSC-02`/`PF-CSC-21` are live (`PF-RK-02`)** |
> **⟹ `PF-R40.3 — THE EVOLUTION GRAPH'S ONE STRUCTURAL GAP, AND IT IS NOT IN THE GRAPH: IT IS IN THE FLOOR.**
> **`PF-D-15`/`PF-AM-24`: `P0-07`'s diversity floor is on `Ne`, a GENOMIC quantity, while `P0-06` supplies a mechanism
> (developmental bias) that maps diverse genomes onto similar phenotypes. **The graph can therefore run correctly — every
> gate passing, every firewall holding — while the population becomes phenotypically monocultural and `Ne` reports
> health.** `PF-CSC-12` is the cascade.**

---

# §41 — THE SELF-MODEL-GRAPH AUDIT

> ### **PF-R41.1 — THE COMPLETE SELF-MODEL FLOW.** **[NORMATIVE]**
> ```
>   OBSERVATION ─▶ SELF-STATE ─▶ CAPABILITY ESTIMATE ─▶ UNCERTAINTY ─▶ PREDICTION ─▶ ACTION PROPOSAL ─▶ OUTCOME ─▶ SELF-MODEL REVISION
>       │             │                 │                   │              │                │              │              │
>    OBJ-01        OBJ-18            OBJ-19              OBJ-03's       OBJ-21's         the component   EVA / the      K versions it
>    the observer  Λ2, NOT self-     CLAIMED —           gap_class +    forecast                          acts           environment    on an EXTERNAL
>                  updating          satisfies NO gate   P0-04's                                          (a proposal,   observation or verdict
>                  K versions it                         calibration                                      not an act)
>                                                        reference
>       ▲                                                                                                                    │
>       └────────────────────────── THE REVISION EDGE IS EXTERNAL: IT COMES FROM OUTCOME VIA K, NOT FROM THE MODEL ──────────┘
> ```
> ### **PF-R41.2 — THE FIVE LOOP ATTACKS §41 REQUIRES.**
> | Attack | **Verdict** | Where it is cut |
> |---|---|---|
> | **self-confirmation** | ⚠️ **BOUNDED** | **`SO-C21.1(d)`: a self-model state may NOT drive attention** — the model may not drive the observation that versions it. **`SO-INV-19`: confidence is not an input to any evidence-producing rule.** ⟹ **Residual `OR-S25`: a self-model is an input to its OWN SUBJECT'S BEHAVIOUR by construction, and making it advisory constrains what OTHERS may infer from it, not what the subject does with it** |
> | **false confidence** | ✅ **BROKEN — NOT MERELY BOUNDED** | **`P0-08 §237` verified the four-edge loop: `confidence → attention` CUT (`SO-INV-19`) · `performance → self-model` CUT (K versions on an EXTERNAL observation) · `self-model → confidence` CUT (confidence is a `P0-04` reference, not derived from the model). Only `attention → performance` survives, and it is legitimate. ⟹ External evidence is not brought in to break the loop — IT IS ALREADY INSIDE THE ONLY SURVIVING EDGE** |
> | **blind spots** | ⚠️ **PARTIALLY DETECTABLE** | **`SO-R185.7` quantity 3 (COVERAGE CONTRIBUTION) is the only instrument in the corpus that measures an ABSENCE.** `P0-03 COMM-INV-48`'s four absence detectors are consumed, not duplicated. ⟹ **`OR-S29`: a blind spot in a scope with no declared `expected_nonzero` condition, whose faults never manifest, is undetectable. `P0-08` amendment 18 removes the default-reachable `NO-GAP` resting state — UNRATIFIED** |
> | **evaluator manipulation** | ⚠️ **BOUNDED** | **`P0-08 §133` route 1: self-model → behaviour → outputs.** The self-model is `Λ2`, advisory, and satisfies no gate — **but it can still be read by the component's own policy, which `P0-08` does not and cannot forbid (`OR-S25`)** |
> | **circular calibration** | ✅ **CLOSED-STRUCTURAL** | **`SM-16` HAS NO SELF-CALIBRATED TERMINAL STATE.** `SO-R179.3`'s three prohibitions: the error term may not be a positive input to any budget, allocation or gate · a component may not update its own calibration statistic · a calibration improvement may not raise a capability status. **And `PF-R19.3`: calibration raises TRUST (deontic), never WARRANT (alethic)** |
> **⟹ `PF-R41.3 — TALLY: 2 ✅ (one BROKEN, one CLOSED-STRUCTURAL) · 3 ⚠️ BOUNDED, and all three bounded residuals are the
> SAME residual seen from three angles: `OR-S25`/`OR-S39` — **a self-model is an input to its own subject's behaviour, and
> a coherent self-model cannot be distinguished from a correct one from inside.****
> **⟹ `PF-R41.4 — THE GRAPH'S LOAD-BEARING PROPERTY, WHICH IS A WRITER PROPERTY RATHER THAN A RULE ABOUT CONTENT: THE
> REVISION EDGE IS EXTERNAL.** The subject writes `OBJ-18`'s CONTENT; K writes its VERSION, FRESHNESS, STATUS and (per
> `PF-AM-27`) its `locality_class` and (per `SO-INV-34`) its `compression_class`. **⟹ A self-model can be wrong and cannot
> be self-corrected — which is the right property, because a self-model that could correct itself could also excuse
> itself. Correction comes from a contradiction with K-held records (`SO-R174.1`'s fourth defence) or from an EVA verdict,
> and both are external.**
> **⚠️ AND THE LIMIT OF THAT PROPERTY, WHICH §41 EXISTS TO EXPOSE: the contradiction check works only when the K-held
> records contradict. `P0-08 §233`'s six-step construction is precisely a case in which they do not — the coverage record,
> the fault history and the observation log are all consistent with a false self-model, because they record OBSERVATION and
> the falsity is in INTERPRETATION.**

---

# §41A — VOLUME G LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§35, §36, §37, §38, §39, §40, §41** — all seven graph audits |
| Rules introduced | **PF-R35.1–.5, R36.1–.3, R37.1–.5, R38.1–.4, R39.1–.4, R40.1–.3, R41.1–.4** |
| **§35 writer graph** | **28 security-critical objects × 7 attributes, fully tabulated.** **24 have a single writer or a declared disjoint field-group split · 1 is deliberately multi-writer (`OBJ-04`, append-only with single-writer interpretation) · 3 have a defective rollback/epoch interaction.** **⟹ 11 OBJECTS ARE OFF-SUBSTRATE AND DEPEND ON `XD-04`, WHICH NO CONTRACT PROVIDES — the single largest structural dependency in the composed architecture, open since `P0-06`** |
| **§35 the high-priority search** | **«SUBJECT-WRITTEN FIELD + SUBJECT-VALIDATED CONSTRAINT»: 5 INSTANCES FOUND.** 2 already fixed by `P0-08`'s own audits (`SO-INV-34`, `SO-INV-33`) · 1 already registered (`P0-06 D-D05`/`OR-D6`) · **2 NEW: `PF-D-20` and `PF-D-21`** |
| **`PF-D-20`** | **`OBJ-18.locality_class` IS THE SAME DEFECT AS `compression_class`, AND `SO-INV-34` FIXED ONLY ONE OF THEM.** A subject may declare a sensitive fact NOT local-only and then aggregate it — satisfying `SO-R138.4` literally while destroying `SO-R138.3`'s protection for four fact classes including `P0-04`'s evidence-root disjointness. **`P0-08 §242` found the shape, stated the general lesson, and did not check the adjacent field.** ⟹ **`PF-AM-27`: `locality_class` moves to the K-written group** |
| **`PF-D-21`** | **AN `IndependenceClaim` IS DECLARED BY THE PARTY THAT BENEFITS FROM THE DECLARATION** — `P0-08 OR-S36` recorded the residual but not the defect class. **⟹ RECLASSIFIED, AND NO FULL FIX EXISTS: K can derive `IND-1/3/4/5/7` from its own registries, but `IND-6` (latent assumptions) is undetectable from inside (`P0-03 COMM-INV-18`). `PF-AM-28`: K derives and OVERWRITES five dimensions; the claimant self-declares four; **EVERY SELF-DECLARED FIELD IS MARKED `SELF-DECLARED` IN THE RECORD** — converting an unverifiable claim into a LABELLED unverifiable claim, exactly as `P0-04 IG-6`'s `UNKNOWABLE_FROM_INSIDE` does, which is explicitly ❌ not "no problem detected"** |
| **§36 authority graph** | **EXACTLY 3 AUTHORITY NODES (OP, `[RO-13]`, EIK) + 1 MEASUREMENT NODE (EVA, which does NOT authorize — `P0-02 R0.1`'s axis separation) + 11 SENSORS/SUBJECTS with no authority.** **A DAG WITH ONE APEX AND NO CYCLE** — every cycle in the corpus is in the information or resource graph, never in the authority graph |
| **§36 the naming result** | **`PF-R36.3` — NO BIOLOGICAL-ANALOGUE NAME APPEARS AS AN AUTHORITY NODE, BECAUSE NO SUCH COMPONENT WAS EVER CREATED: `P0-07` rejected an "evolutionary controller", `P0-06` rejected a "giant developmental controller", `P0-08 SO-C3.3` ruled that a FaultAuthority/IncidentCommander, a SelfModelStore and a DiagnosisEngine DO NOT EXIST. **THE NAMING DISCIPLINE IS ITSELF A CONTROL**** |
| **§37 epistemic graph** | **8 stages with an owner each; 6 internal, 2 external.** **EXTERNAL GROUNDING ENTERS AT EXACTLY TWO POINTS: warrant's root (K's anchored registry) and OUTCOME (EVA — the only stage not produced inside the organism).** **`PF-R37.3`: revision depends on outcome, and `R0.1` re-anchors only on `IMPROVED`/`NEUTRAL`, so NO REVISION OF RETAINED STATE OCCURS WITHOUT EXTERNAL GROUNDING** |
| **§37 the repetition proof** | **❌ INTERNAL REPETITION CANNOT CREATE EXTERNAL GROUNDING — and the proof is THREE rules operating on THREE DIFFERENT OBJECTS: `COMM-INV-08` (warrant, monotone NON-INCREASING along derivation) · `P0-04` (record status) · `SO-INV-18` (the count of a corroborating set). **An architecture with any one alone would have a route through the other two.** ⟹ Limit stated: the three prevent repetition creating GROUNDING; they do not prevent it creating COHERENCE (`OR-S39`)** |
| **§38 deontic graph** | **5 stages; 6 epistemic objects tested for entry: 1 ❌ NO (capability claim — `Ê(·)` excluded from every gate) · 1 ❌ NO (confidence — `SO-INV-19`) · 3 ⚠️ AS A TRIGGER ONLY (observation, diagnosis, coverage) · 1 ⚠️ as a DEONTIC quantity, not an alethic one (trust — `P0-02 R0.1`'s split).** **`PF-R38.4`: THE DEONTIC GRAPH HAS NO EPISTEMIC ENTRY, AND THE EPISTEMIC GRAPH HAS AN UNCLOSED INFLUENCE OVER THE DEONTIC GRAPH'S *INPUTS* (`OR-S41`) — different failures, and conflating them would either overclaim the closure or understate the residual** |
| **§39 learning graph** | **7 stages with 4 constraint intersections marked (GOVERNANCE constrains CAPACITY, never direction · EVIDENCE constrains WARRANT · MEMORY constrains what may become heritable · RESOURCE constrains RATE and supplies the terminal stall).** **`PF-R39.3`: the safety property is a CONSERVATION LAW, not a bound — `P0-05`'s own statement that UDB is conserved under every transformation the learning subsystem can perform** · **`PF-R39.4`: THE CONSERVATION SURVIVES COMPOSITION, because `SO-R152.2`/`SO-INV-28`/`SO-R205.3` ensure there is no second displacement channel. `PF-CSC-20` is the cascade that would have broken it, and it stops** |
| **§40 evolution graph** | **7 stages; 5 verifications: 3 ✅ · 2 ⚠️.** **`PF-R40.2`: `RH-2` IS WIDER AFTER EIGHT CONTRACTS THAN AFTER FIVE — and every contract that added a mechanism recorded the channel it added rather than claiming closure.** **`PF-R40.3`: THE GRAPH'S ONE STRUCTURAL GAP IS NOT IN THE GRAPH, IT IS IN THE FLOOR — `PF-D-15`: the graph can run correctly, every gate passing, while the population becomes phenotypically monocultural and `Ne` reports health** |
| **§41 self-model graph** | **8 stages; 5 loop attacks: 2 ✅ (false confidence BROKEN, circular calibration CLOSED-STRUCTURAL) · 3 ⚠️ BOUNDED — and all three bounded residuals are the SAME residual from three angles (`OR-S25`/`OR-S39`).** **`PF-R41.4`: THE LOAD-BEARING PROPERTY IS A WRITER PROPERTY — THE REVISION EDGE IS EXTERNAL. A self-model can be wrong and cannot be self-corrected, which is right, because a model that could correct itself could also excuse itself.** **⟹ AND ITS LIMIT: the contradiction check works only when K-held records contradict, and §233's construction is precisely a case where they do not** |
| Defects opened | **PF-D-20** (`locality_class`) · **PF-D-21** (`IndependenceClaim`) — **both instances of §35's high-priority pattern** |
| Amendments proposed | **PF-AM-27** (`locality_class` → K-written) · **PF-AM-28** (K derives five `IND-` dimensions; self-declared fields are labelled) |
| Cumulative defects | **PF-D-01 … PF-D-21** (21) |
| Cumulative amendments | **PF-AM-19 … PF-AM-28** (10 proposed by this audit) + 18 inherited-unratified = **28 unratified amendments in the corpus** |

**Next:** `83_` Vol H — §42 the compound adversarial attack suite: **48 new attacks, A264 … A311**, each involving ≥2
contracts, with ≥10 involving ≥3, ≥5 involving ≥4, and ≥2 involving ≥5.
