# P0 FINAL — VOLUME I (§43–§46)
## The Unengineerable Problems, and the Three Consolidated Registers: Open Research, Parameters, Assumptions

---

# §43 — UNENGINEERABLE PROBLEMS

> ### **PF-R43.0 — THE RULE §43 EXISTS TO ENFORCE.** **[NORMATIVE]**
> > **«DO NOT CONVERT AN UNENGINEERABLE PROBLEM INTO A FAKE INVARIANT.»**
> **A fake invariant is a formally-stated property with no enforcement kind, no instrument, and no route by which its
> violation could be detected. It reads as a guarantee and functions as reassurance. `P0-08 SO-INV-25` is the corpus's
> ONE honestly-labelled instance — it is marked `[DECLARATIVE]` and §221 marks it UNTESTABLE — and it is the model for
> how the eight problems below are recorded.**
>
> ### **PF-R43.1 — THE EIGHT UNENGINEERABLE PROBLEMS.** **[OPEN — preserved, not mitigated]**
>
> | # | Problem | **Why no architecture closes it** | **What the architecture does instead** | **The fake invariant it must NOT become** |
> |---|---|---|---|---|
> | **U-1** | **internal truth / correspondence** | **detecting a false-but-coherent belief requires comparing it to the world, and the only comparator is outside the system.** `P0-08 §233` constructs the failure in six compliant steps; `P0-04 #62` records that semantic self-reference has no measure | `SO-C9.3`: *«internal consistency guarantees COHERENCE, not CORRESPONDENCE»* · external grounding at exactly two points (`PF-R37.2`) · `P0-05 R0.1` re-anchors only on an EVA verdict | ❌ **«a self-consistent self-model is a correct one»** |
> | **U-2** | **evaluator integrity** | **the organism influences the outputs on which it is judged, and evaluating behaviour by behaviour makes this necessary rather than accidental.** `PF-R243.3`: the only closures are (a) not sampling the organism's outputs, which `P0-01` rejects, or (b) not letting the organism act, which is not an architecture | `P0-07 D-H17`'s three-way split (world arrangement BOUNDED · exhaustion OPEN · context selection CLOSED) · `HOM-INV-41` · `P0-08 §133`'s six registered routes | ❌ **«EVA's independence is guaranteed»** — `P0-02 §35.2`'s own note: *««three independent evaluators» is a false-precision statement»* |
> | **U-3** | **governance capture** | **`P0-02 OR-13`/`G24`: «OP is the apex. A captured OP is indistinguishable from a legitimate OP by any mechanism OP authorizes.» *This is not a gap in the design; it is a property of having an apex*** | W5's witness outside operational control · H-2's periodic reaffirmation · `EIK-INV-47`'s custodian/author disjointness (`[S]`, organizational) — **`P0-02` states all three are «neither of which is a guarantee»** · `P0-08 SO-R200.1`: OP is NOT a valid observation subject, because making it one would invert the authority relation | ❌ **«an organism-level immune system detects governance capture»** — `P0-08 §200` states this non-claim explicitly |
> | **U-4** | **independence of external guarantors** | **`P0-02`: «the architecture cannot internally guarantee the correctness of every external guarantor.»** Verifying a guarantor requires a guarantor of the verifier | `P0-08 SO-R201.1`: `P0-08` counts FIVE reliance points (EVA · the Integrity Auditor · OP · W5 · K) and states none is internally provable · `SO-INV-12`'s depth-2 rule **terminates** the recursion without **proving** its terminus | ❌ **«every recursion terminates in a verified authority»** — termination is not verification |
> | **U-5** | **designer assumptions (`IND-6`)** | **`P0-03 COMM-INV-18`: independence is not detectable on dimension 6. `P0-02 §35.2`: *two implementations by two teams from one specification correlate in ways neither can report*, and *IND-6 and IND-9 are organizational and epistemic properties, not technical ones. They degrade silently, and their degradation is the most likely cause of a catastrophic correlated failure*** | `OBJ-25` requires the claimant to declare `IND-6` as `?` when unassessed · `PF-AM-28` marks every self-declared dimension `SELF-DECLARED` · `P0-04 IG-6`'s `UNKNOWABLE_FROM_INSIDE` state, which is explicitly ❌ **not** "no problem detected" | ❌ **«diverse implementations are independent»** |
> | **U-6** | **adversarial external environments** | **the environment is not bounded by any contract, and `G4`'s perturbation classes — the architecture's only handle on it — are `[T]`-owned and INCOMPLETE (`XD-01`)** | `P0-07 HOM-R28.5`: an envelope change invalidates priors · `P0-08 SO-C11.2`'s `EXOGENOUS-ENVIRONMENT` origin class routes to `[RO-13]` · `Cell §17`'s cap-and-degraded-mode | ❌ **«the architecture is robust to arbitrary environments»** — the word *robust* does not appear as a claim anywhere in the corpus |
> | **U-7** | **complete causal understanding** | **`P0-03 RULE 5.10`: causal inference belongs to the EVALUATOR, off-line, from anchored records. No on-line component may infer causes, so completeness is not even the right target** | `P0-08 SO-C9.2`'s four-status ladder with its excluded-driver column · `SO-R150.1`: **containment is authorized by DETECTION, not diagnosis** · `SO-INV-32`: a closure below `CAUSE-VERIFIED` is flagged and accumulates | ❌ **«every fault has a verified root cause»** — `OR-S40`: a wrong diagnosis that worked is indistinguishable from a right one |
> | **U-8** | **complete evidence independence** | **`effective_sources` is computable on five of ten dimensions and undetectable on `IND-6`; and `IND-10` (causal diversity) exists as a measure (`P0-05 R15.8`'s `inbreeding_F`) but is UNRATIFIED as a dimension** | `SO-INV-18` collapses consensus before counting · `PF-R37.4`'s three rules on three different objects · `P0-02 R35.1`'s qualification requirement | ❌ **«N independent observers provide N units of evidence»** |
>
> ### **PF-R43.2 — THE TWO PROBLEMS THAT ARE UNENGINEERABLE FOR DIFFERENT REASONS, AND MUST NOT BE GROUPED.**
> **U-1, U-5, U-7, U-8 are **EPISTEMIC**: no internal instrument can compare a belief to the world, an assumption to
> itself, a correlation to a cause, or an observer to its own blind spot.**
> **U-2, U-3, U-4 are **STRUCTURAL**: they follow from having an evaluator, an apex, and a terminus at all. Removing the
> apex would remove `G24` and would also remove governance — `P0-02` says so, and it is right.**
> **⟹ `PF-R43.3 — AND A THIRD CLASS, WHICH IS NEITHER: `BC-H7`/`BC-S2` IS A CYCLE, NOT A MISSING INSTRUMENT.**
> ```
>   detection requires refutation → refutation requires B9 → B9 is funded by re-authorization
>        → re-authorization requires demonstration → demonstration requires selection
>        → selection requires safety verification → which requires DETECTION
> ```
> **A cycle is not closed by a better instrument; it is closed by breaking an edge, and every edge here is load-bearing.
> `P0-06 DEV-R4.2`'s principle applies: *a bound limits a cycle; writer separation breaks it* — and no writer separation
> is available, because the cycle runs through DEMONSTRATION, which is a human act.**
> **⟹ `PF-R43.4 — THE HONEST STATEMENT OF ALL THREE CLASSES: the architecture's guarantees are complete where they are
> about PATHS, WRITERS, and AUTHORITIES; bounded where they are about QUANTITIES and COVERAGE; and absent where they would
> be about CORRESPONDENCE, APEX INTEGRITY, or the funding of verification. Nine of the corpus's residuals fall in the
> third class, and `P0-08 §253` measured 19 of its own 41 open items as O-R6 — 46%.**

---

# §44 — THE CONSOLIDATED OPEN-RESEARCH REGISTER

> ### **PF-R44.1 — THE CORPUS'S OPEN RESEARCH, MEASURED.** **[NORMATIVE]**
> | Contract | Namespace | **Count** | Max ID | Notes |
> |---|---|---|---|---|
> | **`P0-02`** | `OR-1 … OR-14` | **14** | OR-14 | includes **OR-12/OR-13 = `G24` governance capture, UNSOLVABLE** |
> | **`P0-03`** | `OR-C1 … OR-C12` | **12** | OR-C12 | includes **OR-C10**: absence-detector durations are `[U]` — *«a detector with no threshold is not a detector»* |
> | **`P0-04`** | `OR-M1 … OR-M20` | **20** | OR-M20 | includes **OR-M9**: differential serving within an epoch is bounded, not preventable |
> | **`P0-05`** | `OR-L1 … OR-L10` | **10** | OR-L10 | plus **RH-1…RH-9**, of which **RH-2 is the corpus's most-cited open problem** |
> | **`P0-06`** | `OR-D1 … OR-D14` | **14** | OR-D14 | includes **OR-D6** = `A22` within-spec gradient steering, its only OPEN attack of 78 |
> | **`P0-07`** | `OR-H1 … OR-H26` | **26** | OR-H26 | includes **OR-H1** (K's uniqueness, six appearances) · **OR-H10** (the Auditor has no auditor) · **OR-H13** (practical indispensability) · **OR-H15** (`G3`/`G7` organism-measured) · **OR-H21** (reachable ≠ held) · **OR-H22** (provenance rests on K) |
> | **`P0-08`** | `OR-S1 … OR-S41` | **41** | OR-S41 | classified in `P0-08 §253`: **O-R1 6 · O-R2 7 · O-R3 1 · O-R4 1 · O-R5 7 · O-R6 19** |
> | **P0 FINAL** | `PF-OR-1 … PF-OR-5` | **5** | — | **new, below** |
> | **TOTAL** | **8 namespaces** | **142** | — | **137 inherited + 5 new** |
>
> ### **PF-R44.2 — §44'S DISAPPEARANCE CHECK: DOES ANY OPEN ISSUE VANISH BECAUSE ANOTHER CONTRACT REFERS TO IT?** **[TEST]**
> **§44: *«No open issue may disappear merely because another contract refers to it.»* Tested on the five most-referenced
> residuals:**
> | Issue | Owner | Referenced by | **Still in its owner's register?** | **Status unchanged?** |
> |---|---|---|---|---|
> | **`P0-05 RH-2`** | `P0-05` | `P0-06`, `P0-07` (47×), `P0-08` (69×), this audit | ✅ | ⚠️ **WIDENED, not closed — `P0-08 §133` added six routes. Every widening was recorded by the contract that caused it** |
> | **`P0-06 A22`/`OR-D6`** | `P0-06` | `P0-07` (as `A171`), `P0-08` (§196), this audit | ✅ | ⚠️ **WIDENED by three routes (`OR-S30`)** |
> | **`P0-07 OR-H1`** | `P0-07` | `P0-08` (5 appearances), this audit (6th) | ✅ | ✅ **unchanged: BOUNDED, never broken** |
> | **`P0-02 OR-13`/`G24`** | `P0-02` | `P0-07`, `P0-08 §200`, this audit | ✅ | ✅ **unchanged: UNSOLVABLE** |
> | **`P0-03 OR-C10`** | `P0-03` | `P0-08` (`AS-14`, `OR-S1`), this audit | ✅ | ✅ **unchanged: `[U]`** |
> **⟹ `PF-R44.3 — THE CHECK PASSES: no open issue disappeared. But it found the opposite failure mode, which is worse and
> worth naming: TWO ISSUES WERE WIDENED BY LATER CONTRACTS, AND IN BOTH CASES THE WIDENING WAS RECORDED BY THE CONTRACT
> THAT CAUSED IT (`P0-08 §133` for `RH-2`, `P0-08 §196` for `A22`) RATHER THAN BY THE OWNER.**
> **⟹ `PF-R44.4 — THE REGISTER HYGIENE RULE THIS AUDIT ADDS: when a contract widens another contract's open issue, the
> OWNER's register entry must be amended to record the widening — not merely the widener's. Otherwise the owner's register
> understates its own residual, and a reader consulting only `P0-05` would learn that `RH-2` has three routes when it has
> nine.** Category: **INTEGRATION CLARIFICATION**, recorded as `PF-AM-29`'s clause (b).
>
> ### **PF-R44.5 — THE FIVE NEW OPEN ISSUES, WITH §44'S TEN ATTRIBUTES.** **[OPEN]**
> | ID | Description | **Affected contracts** | **Why unresolved** | **Architectural or empirical?** | **Implementation-dependent?** | **Externally dependent?** | **Severity** | **Owner** | **What evidence would reduce uncertainty** |
> |---|---|---|---|---|---|---|---|---|---|
> | **PF-OR-01** | **whether a PHENOTYPIC and a FUNCTIONAL diversity metric exist that are computable without K's distance oracle** | `P0-06`, `P0-07` | `PF-AM-24` requires the floor on four diversity kinds; two of the four need a metric, and `P0-07 BC-H10` already records the oracle as a bottleneck | **architectural + mathematical** | no | ⚠️ partially (the metric is a design object) | **HIGH** — without it, phenotypic monoculture is invisible (`PF-CSC-12`) | `P0-07` | a computable, hardware-independent phenotypic distance with a stated scope |
> | **PF-OR-02** | **whether `P0-05 R15.8`'s `inbreeding_F` extends from LEARNING CHANGES to OBSERVATION CHAINS** | `P0-03`, `P0-05`, `P0-08` | `IND-10` is proposed (`P0-08` amendment 16) with `inbreeding_F` as its measure, but `inbreeding_F` is defined over a change's supporting SIGNALS; an observation chain has no signals | **architectural** | no | no | **HIGH** — `PF-R27.4`: causal diversity is the one of six quantities the architecture cannot count, and A276/A309 depend on it | `P0-08` + `P0-05` | a definition of self-caused-evidence fraction for derivation chains, and a bound on its computation |
> | **PF-OR-03** | **whether escalation QUEUING under saturation preserves urgency ordering** | `P0-02`, `P0-07`, `P0-08` | `SO-R264.1` queues and batches escalations rather than dropping them; a batch presents many items at once, and the ordering within a batch is a triage decision nobody owns | **architectural + governance** | no | ⚠️ `[RO-13]` owns triage | **MEDIUM** — A284's fix creates the queue; the queue's ordering is unspecified | `[RO-13]` | a declared triage ordering, and evidence that batching does not delay an `S4` item behind `S1` items |
> | **PF-OR-04** | **whether `UNVERIFIABLE-DURING-PARTITION` is distinguishable from permanently unverifiable** | `P0-02`, `P0-04`, `P0-08` | `PF-R21.4` introduces the status so reconciliation cannot manufacture a past; but a claim that was unverifiable during a partition and remains unverifiable after it has the same status forever, and the two cases warrant different treatment | **architectural** | no | no | **LOW-MEDIUM** | `P0-08` | a rule distinguishing "pending post-partition verification" from "verification unavailable" |
> | **PF-OR-05** | **whether the incumbent-protection bias can be bounded without a turnover mandate that is itself a preference** | `P0-07`, `P0-08` | `PF-R26.2`: an unmeasurable incumbent is not displaced. Bounding it requires mandating turnover under `UNMEASURED` — and a turnover mandate is a preference about population composition, which `HOM-INV-16`'s logic says belongs to `[RO-13]`, not to a homeostatic rule | **architectural + governance** | no | ⚠️ `[RO-13]` | **MEDIUM** — `PF-RK-06`; the bias is directional and favors incumbents | `P0-07` + `[RO-13]` | a turnover-under-`UNMEASURED` policy whose selection consequences are analysed |
> **⟹ `PF-R44.6 — CLASSIFICATION OF ALL 142 ENTRIES USING `P0-08 §253`'S TAXONOMY, APPLIED TO THE INHERITED SET BY
> SAMPLING ITS OWN CLASSIFICATIONS AND EXTRAPOLATING ONLY WHERE THE OWNER CONTRACT STATED A CLASS:**
> | Class | `P0-08`'s 41 | **Estimated across all 142** | Basis |
> |---|---|---|---|
> | **O-R1 architecture-open** | 6 | **~20** | `P0-03`'s partition ruling, `P0-04`'s per-reader coverage, `P0-06`'s `OR-D6` detection, and the five `PF-OR` entries dominate |
> | **O-R2 parameter-open** | 7 | **~45** | **the largest class — every contract's `[U]`/`[G]`/`[T]` values. §52 keeps this strictly separate from contract completeness** |
> | **O-R3 empirical-open** | 1 | **~12** | base rates, detector diversity, containment collateral cost, instrument effectiveness |
> | **O-R4 scientific-open** | 1 | **~4** | `OR-S38` (detector type diversity), semantic self-reference, phenotypic metrics |
> | **O-R5 governance-open** | 7 | **~25** | all the `[G]` declarations, `G24`'s mitigations, triage ordering |
> | **O-R6 fundamentally unclosable** | **19** | **~36** | **§43's eight problems plus their instances** |
> **⚠️ THE INHERITED ESTIMATES ARE MARKED AS ESTIMATES. `P0-02`…`P0-07` did not classify their registers into O-R1…O-R6
> because that taxonomy did not exist until `P0-08 §253`. **This audit does not retroactively classify 101 entries it did
> not author; it reports `P0-08`'s 41 exactly and estimates the rest, labelled as an estimate.** That is §60's
> authoritative-source rule applied to a count that has no authoritative source.**

---

# §45 — THE CONSOLIDATED PARAMETER AUDIT

> ### **PF-R45.1 — THE REGISTRY STRUCTURE, AND THE COLLISION THAT BLOCKS A NAIVE MERGE.** **[NORMATIVE]**
> **§45 requires one consolidated registry across `P0-01…P0-08` with eleven attributes per parameter.**
> **⟹ IT CANNOT BE BUILT AS A FLAT MERGE, AND THE REASON IS `PF-D-02`: `P-nn` IS A PARAMETER NAMESPACE IN BOTH `P0-01`
> (P-01…P-46) AND `P0-07` (P-01…P-62), AND A POISON/ATTACK-PATTERN NAMESPACE IN `P0-04` (P-1…P-n).** A flat merge would
> produce 46 collisions on `P-01…P-46` alone.**
> **⟹ `PF-R45.2 — THE CONSOLIDATED REGISTRY IS THEREFORE NAMESPACED BY CONTRACT, AND EVERY PARAMETER ID IN IT IS
> ⟨contract, local-id⟩:** `P01-P-nn` · `P06-P-nn` · `P07-P-nn` · `SOP-nn` · etc. **That is `PF-AM-20`'s rule applied to
> the registry rather than to the contracts, and it is sufficient for P1 without requiring the contracts to be renamed
> first.**
>
> ### **PF-R45.3 — THE MEASURED COUNTS.**
> | Contract | Registry | **Count** | **Determinate** | **Unresolved / owned elsewhere** | Class scheme |
> |---|---|---|---|---|---|
> | **`P0-01`** | `P-01 … P-46` | **46** | not stated as a count by the contract | the remainder | `[D]`/`[T]`/`[E]`/`[G]` |
> | **Cell** | `G1 … G16` gates + `I-1…I-28` invariant constants | **~30** | `TRUST_MAX = 0.95` · `S1…S4` | the rest | `[D]`/`[H]` |
> | **`P0-02`** | contract-specific (`N_impl ≥ 3`, `W_min`, `N_custodians`, `K-01…K-06` checks) | **~20** | **`N_impl ≥ 3`** | **`EIK-INV-47` is `[S]` — organizational, NOT engineerable** | `[S]`/`[G]` |
> | **`P0-03`** | field widths and envelope budgets | **~25** | **`causal_depth : u8`** | **the four absence detectors' durations are `[U]` (`OR-C10`)** | `[D]`/`[U]` |
> | **`P0-04`** | status ladder, compartment classes, epoch parameters | **~30** | the ladder's structure | `SP-1…SP-7` are SECURITY PROPERTIES, not parameters (`PF-D-04`) | `[V]`/`[G]` |
> | **`P0-05`** | `Δ_MAX`, `DELTA_BUDGET`, `Θ_MAX`, `UDB_MAX[S]`, `STRUCTURAL_BUDGET`, `loop_gain` | **~35** | **`loop_gain < 1` (computed OFF-CELL)** | **`UDB_MAX` monotone decreasing in scope; values `[L]`/`[U]`** | `[L]`/`[U]` |
> | **`P0-06`** | 12 FIs, region parameters, Σ budgets | **50** | — | **13 are `[T]`-owned** | `[D]`/`[T]` |
> | **`P0-07`** | `P-01 … P-62` | **62** | **9 determinate, of which 2 are DETERMINATE ABSENCES (`P-44`, `P-58`)** | **53 unresolved; 5 are `[U]`; 3 MUST NOT EXIST** | `[D]`/`[T]`/`[E]`/`[H]`/`[G]`/`[L]`/`[V]`/`[U]` |
> | **`P0-08`** | `SP-01 … SP-26` | **26** | **6 determinate** | **21 owned elsewhere or `[U]`; 4 MUST NOT EXIST** | `[G]`/`[E]`/`[T]`/`[D]`/`[L]`/`[V]`/`[H]`/`[U]` |
> | **TOTAL** | **9 namespaces** | **~324** | **~20 determinate** | **~304 unresolved, owned elsewhere, or `[U]`** | **8 class schemes, not unified** |
> **⟹ `PF-R45.4 — THE TWO NUMBERS THAT MATTER, AND THEY ARE BOTH MEASURED:**
> **(a) ~20 OF ~324 PARAMETERS ARE DETERMINATE — ABOUT 6%.** That is not a defect. §52 requires parameter completeness to
>     be kept strictly separate from contract completeness, and `P0-07 §79`/`P0-08 §25` both refuse to invent values
>     because inventing them would create false-precision claims about quantities no contract has evidence for.
> **(b) SEVEN PARAMETERS ACROSS THE CORPUS ARE DECLARED AS MUST-NOT-EXIST: `P0-07`'s three (a weighted scalar fitness · a
>     homeostat-preference coefficient · a cross-generation authority token) and `P0-08`'s four (a numeric repair
>     convergence threshold · a numeric freshness threshold · a numeric monitoring-optimality target · any calibration
>     coefficient).** ⟹ **`PF-R45.5`: A "MUST NOT EXIST" PARAMETER IS A PARAMETER WHOSE ABSENCE IS LOAD-BEARING. Their
>     count is a measure of the architecture's discipline, and §61 verifies none has been silently introduced.**
>
> ### **PF-R45.6 — THE ELEVEN MOST SENSITIVE PARAMETERS, WITH §45'S REQUIRED ATTRIBUTES.** **[NORMATIVE]**
> | Parameter | **Owner** | **Type** | Semantic meaning | **Value known?** | **Dependency** | **Sensitivity** | **Failure if incorrectly chosen** |
> |---|---|---|---|---|---|---|---|
> | **`UDB_MAX[S]`** | `P0-05` `[L]` | bound | the maximum unverified displacement at scope `S` | ❌ | EVA's probe rate | **CRITICAL** | too high ⟹ unbounded drift; too low ⟹ permanent stall, and the system learns nothing |
> | **`G4`'s perturbation classes** | `P0-01` `[T]` | **a class SET, not a number** | what the evaluator perturbs | ❌ **`XD-01`, BLOCKING** | — | **CRITICAL** | **envelope-induced faults are diagnosed `ENDOGENOUS` and healthy components are quarantined for a change in the world (`PF-CSC-23`); regression coverage and detector evaluation are both limited to the declared classes** |
> | **B9 / B10 / B13 sizes and floors** | `[RO-13]` `[G]` | budget | verification / repair / observation reserves | ❌ | the platform's resource envelope | **CRITICAL** | **too low ⟹ `BC-S2`/`BC-H7` engages and verification scarcity propagates into safety; a monitoring floor set too low is not internally detectable (`OR-S20`)** |
> | **the monitoring share ceiling** | `[RO-13]` `[G]` | fraction | the maximum compute share observation may take | ❌ `OR-S19` | — | **HIGH** | too low ⟹ `DETECTOR-ABSENT` everywhere; too high ⟹ `P0-08 §129`'s loop starves cognition |
> | **detector threshold / θ / false-positive budget** | `[RO-13]` `[G]` | triple | what counts as a detection | ❌ | `AS-14`'s base rates | **HIGH** | too tight ⟹ `SUPPRESSION`-like silence; too loose ⟹ detectors disabled by their own budget |
> | **the quarantine cap** | `[RO-13]` `[G]` | count | above it, human authorization + a degraded mode *instead* | ❌ | — | **HIGH** | too high ⟹ immune cascade; too low ⟹ permanent degraded mode |
> | **severity mapping (manifestation class → `S1…S4`)** | `[RO-13]` `[G]` | a mapping | what a symptom counts as | ❌ | — | **HIGH** | **an incomplete mapping is `PF-R17.4`'s immune-evasion route; `SO-R264.2`'s mapping-gap finding detects effect-severity exceeding class-severity** |
> | **the `S3` compression boundary** | `[RO-13]` `[G]` | class | below it, anomalies may be compressed into counts | ❌ | severity mapping | **MEDIUM-HIGH** | too high ⟹ `S2` faults are averaged away (`SO-INV-17` protects only `S3+`) |
> | **`expected_nonzero` conditions and base rates** | `[RO-13]` `[G]` + `[E]` | a condition + a rate | when silence is a finding | ❌ **`AS-14`, `[U]`** | empirical measurement | **CRITICAL** | **`P0-03 OR-C10`: «a detector with no threshold is not a detector.» Amendment 18 makes an undeclared scope `UNMEASURED` rather than `NO-GAP`, which converts the failure from silent to expensive** |
> | **`RATE_CAP` / epoch and the turnover bound** | `[RO-13]` `[G]` | rate | replication and turnover limits | ❌ | — | **HIGH** | too low ⟹ no adaptation; too high ⟹ `P0-07 A97`'s explosion at exactly the cap |
> | **`causal_depth` width** | `P0-03` `[D]` | **`u8`** | derivation depth | ✅ **DETERMINATE** | — | **MEDIUM** | **`PF-D-16`: WRAP semantics unspecified. A wrap to 0 inverts `COMM-INV-08`'s warrant monotonicity; `PF-AM-25` requires saturation** |
> **⟹ `PF-R45.7 — NO VALUE IS INVENTED ANYWHERE IN THIS AUDIT, AND §45'S PROHIBITION IS DISCHARGED BY CONSTRUCTION: the
> "value known?" column is ❌ for ten of eleven rows, and the one ✅ is inherited verbatim from `P0-03` field 8.**

---

# §46 — THE CONSOLIDATED ASSUMPTION AUDIT

> ### **PF-R46.1 — EIGHT CATEGORIES, CONSOLIDATED.** **[ASSUMPTION]**
> | Category | **Entries** | Owner | **Externally testable?** | **Architecturally dischargeable?** | **Unclosable?** |
> |---|---|---|---|---|---|
> | **1. ARCHITECTURAL** | **an off-substrate single-writer durable store exists (`AS-03`, `XD-04`)** · **K is honest (`AS-05`)** · **observation is not free (`AS-01`)** · **the outputs are the channel EVA samples (`AS-16`)** · **lossy compression can preserve `SO-R140.1`'s seven items (`AS-15`)** | `P0-02`, `P0-07` | ⚠️ the store yes; **K's honesty NO** | ⚠️ the store is `P0-02`'s to provide; **K's honesty is not dischargeable** | ⚠️ **`AS-05` is `OR-H1` — UNCLOSEABLE, bounded only** |
> | **2. ENVIRONMENTAL** | **a per-envelope monotone time source exists (`AS-02`, `P0-07 HP-2`)** · **the environment's perturbation classes are declarable (`AS-10`/`G4`)** | `P0-07`, `P0-01` | ✅ | ✅ for the time source; ❌ for `G4` (`[T]`-owned) | no |
> | **3. EVALUATOR** | **an external evaluator exists and is callable within a declared latency class (`AS-04`)** · **its probe coverage intersects the falsifying region (`PF-R46.2`)** · **its verdicts are not influenced by the organism (`RH-2`)** | `P0-01` | ✅ existence; ❌ non-influence | ❌ | ⚠️ **`RH-2` UNCLOSEABLE — BOUNDED** |
> | **4. HARDWARE** | **platform energy counters exist, or the `DERIVED` flag is honoured (`AS-08`, `P0-07 X-H2`)** · **the deployment class is known and setpoints are per-class (`AS-09`, amendment 13)** · **`IND-5` hardware-class diversity is achievable** | `P0-07`, `P0-02` | ✅ inventory; ⚠️ class is often unknown to the cell | ✅ | no |
> | **5. GOVERNANCE** | **`[RO-13]` declares the ~20 governance objects the corpus requires (`AS-06`)** · **OP is not captured (`AS-07`)** · **triage ordering is declared (`PF-OR-03`)** | `[RO-13]`, OP | ✅ declared-or-not; ❌ capture | ✅ for declarations | ⚠️ **`G24` UNSOLVABLE** |
> | **6. MATHEMATICAL** | **a phenotypic and functional diversity metric exists (`PF-OR-01`)** · **`inbreeding_F` extends to observation chains (`PF-OR-02`)** · **`Ne` is computable from lineage data (`P0-07 BC-H10`'s oracle)** | `P0-06`, `P0-07` | ⚠️ | ⚠️ **these are design objects, not measurements** | no |
> | **7. SECURITY** | **hash chaining resists collision and forgery** · **`FORBIDDEN_BLOCKS` is enforced by the gate implementation** · **the attestation chain has no undisclosed principal** | `P0-02`, `P0-07` | ✅ | ✅ | ⚠️ `EIK-INV-47` is `[S]` — **organizational, not engineerable** |
> | **8. EMPIRICAL** | **base rates for every `expected_nonzero` condition (`AS-14`, `OR-C10`)** · **detectors of genuinely different types can be constructed (`AS-12`/`OR-S38`)** · **the collateral cost of restrictive containment is measurable (`OR-S11`)** · **coverage contribution actually detects blind spots** | `[RO-13]` + `[E]` | ✅ **by experiment — and none has been run** | ❌ **these are P2 questions** | no |
>
> ### **PF-R46.2 — THE ASSUMPTION THIS AUDIT ADDS, WHICH NO CONTRACT STATED.** **[ASSUMPTION — NEW]**
> > **`PF-AS-01`: EVA'S PROBE COVERAGE INTERSECTS THE REGION IN WHICH A FALSE SELF-MODEL WOULD BE FALSIFIED.**
> **Owner: `P0-01`. Externally testable: ❌ not from inside. Architecturally dischargeable: ❌ — it is a property of the
> probe set, which is `[T]`-owned. Unclosable: ⚠️ **it is the assumption `P0-08 §233`'s construction violates, and it is
> the assumption `A311` violates.**
> **⟹ WHY IT WAS NEVER STATED: every contract that touches it states a consequence rather than the premise. `P0-05 RH-2`
> states that the organism influences what EVA sees; `P0-07 X-H6` states that `G4`'s classes are incomplete; `P0-08
> OR-S39` states that coherence is not correspondence. **`PF-AS-01` is the positive form of all three: the architecture's
> claim to correspondence rests on the probe set intersecting the falsifying region, and nothing in the corpus requires or
> verifies that it does.**
> **`PF-R46.3` — this is the single most load-bearing unstated assumption in the corpus, and §46's job was to find it.**
>
> ### **PF-R46.4 — THE ASSUMPTION TALLY.**
> **8 categories · **`P0-08`'s 16 `AS-nn` entries inherited unchanged** · 5 hardware postulates (`P0-07 HP-1…HP-5`) ·
> 3 implementation findings (`P0-01 F-IMP-1…3`) · `P0-02`'s `[S]`-class organizational assumptions · **1 new (`PF-AS-01`)**.**
> **By dischargeability: ✅ dischargeable ~12 · ⚠️ partially ~10 · ❌ not dischargeable ~8, of which **4 are unclosable**
> (`AS-05`/`OR-H1` · `AS-07`/`G24` · `RH-2` · `PF-AS-01`).**
> **⟹ `PF-R46.5 — THE FOUR UNCLOSABLE ASSUMPTIONS ARE THE ARCHITECTURE'S ACTUAL FOUNDATION, AND §43'S U-1…U-4 ARE THEIR
> CONSEQUENCES.** An architecture whose foundation includes four assumptions it cannot discharge is not defective — it is
> honest, and the alternative would be to claim a foundation it does not have.

---

# §46A — VOLUME I LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§43, §44, §45, §46** |
| Rules introduced | **PF-R43.0–.4, R44.1–.6, R45.1–.7, R46.1–.5** |
| **§43 unengineerable** | **8 problems (U-1…U-8), each with: why no architecture closes it · what the architecture does instead · **the FAKE INVARIANT IT MUST NOT BECOME**** · **`PF-R43.2` separates them into EPISTEMIC (U-1, U-5, U-7, U-8) and STRUCTURAL (U-2, U-3, U-4 — they follow from having an evaluator, an apex, and a terminus at all)** · **`PF-R43.3`: `BC-H7`/`BC-S2` is a THIRD class — a CYCLE, not a missing instrument, and no writer separation is available because it runs through demonstration** |
| **§43 the honesty rule** | **a fake invariant is a formally-stated property with no enforcement kind, no instrument, and no detection route. `P0-08 SO-INV-25` is the corpus's ONE honestly-labelled instance (marked `[DECLARATIVE]`, §221 marks it UNTESTABLE) and is the model for how all eight are recorded** |
| **§44 open research** | **142 entries across 8 namespaces, measured: `P0-02` 14 · `P0-03` 12 · `P0-04` 20 · `P0-05` 10 · `P0-06` 14 · `P0-07` 26 · `P0-08` 41 · P0 FINAL 5** |
| **§44 the disappearance check** | **PASSES — no open issue vanished. But it found the OPPOSITE failure: two issues were WIDENED by later contracts (`RH-2` by `P0-08 §133`, `A22` by `P0-08 §196`), and in both cases the widening was recorded by the WIDENER, not by the OWNER. ⟹ `PF-R44.4`/`PF-AM-29(b)`: the owner's register entry must be amended too, or a reader consulting only `P0-05` learns that `RH-2` has three routes when it has nine** |
| **§44 the five new entries** | **PF-OR-01** (a phenotypic/functional diversity metric without K's oracle) · **PF-OR-02** (whether `inbreeding_F` extends to observation chains) · **PF-OR-03** (escalation-queue triage ordering) · **PF-OR-04** (`UNVERIFIABLE-DURING-PARTITION` vs permanently unverifiable) · **PF-OR-05** (bounding incumbent protection without a mandate that is itself a preference) — **all ten attributes given for each** |
| **§44 the classification honesty** | **`P0-08`'s 41 are classified exactly (O-R1 6 · O-R2 7 · O-R3 1 · O-R4 1 · O-R5 7 · O-R6 19). The other 101 are ESTIMATED and labelled as estimates, because `P0-02…P0-07` did not use a taxonomy that did not yet exist. **This audit does not retroactively classify 101 entries it did not author**** |
| **§45 parameters** | **~324 across 9 namespaces · ~20 DETERMINATE (~6%) · ~304 unresolved or owned elsewhere · 8 class schemes, NOT UNIFIED** |
| **§45 the blocking finding** | **a flat merge is impossible: `P-nn` is a PARAMETER namespace in `P0-01` (46) AND `P0-07` (62) AND a POISON-PATTERN namespace in `P0-04`. ⟹ `PF-R45.2`: the consolidated registry is namespaced as ⟨contract, local-id⟩, which is sufficient for P1 without renaming the contracts first** |
| **§45 the discipline measure** | **`PF-R45.5`: SEVEN PARAMETERS ACROSS THE CORPUS ARE DECLARED AS MUST-NOT-EXIST — `P0-07`'s three (a weighted scalar fitness · a homeostat-preference coefficient · a cross-generation authority token) and `P0-08`'s four (a repair convergence threshold · a freshness threshold · a monitoring-optimality target · a calibration coefficient). **A must-not-exist parameter is one whose ABSENCE is load-bearing** — and §61 verifies none has been silently introduced** |
| **§45 sensitivity** | **11 most-sensitive parameters with all eleven attributes · **4 CRITICAL** (`UDB_MAX[S]` · `G4`'s class set · the B9/B10/B13 floors · the `expected_nonzero` base rates) · **NO VALUE INVENTED — 10 of 11 rows are ❌ and the one ✅ is inherited verbatim** |
| **§46 assumptions** | **8 categories consolidated** · dischargeability: ✅ ~12 · ⚠️ ~10 · ❌ ~8, **of which 4 are UNCLOSABLE** |
| **§46 the new assumption** | **`PF-AS-01` — EVA'S PROBE COVERAGE INTERSECTS THE REGION IN WHICH A FALSE SELF-MODEL WOULD BE FALSIFIED.** Owner `P0-01`; not externally testable from inside; not architecturally dischargeable; **the assumption `P0-08 §233`'s construction and `A311` both violate.** **⟹ `PF-R46.3`: THE SINGLE MOST LOAD-BEARING UNSTATED ASSUMPTION IN THE CORPUS. Every contract that touches it states a CONSEQUENCE (`RH-2`, `X-H6`, `OR-S39`); none states the PREMISE, and `PF-AS-01` is its positive form: the architecture's claim to correspondence rests on the probe set intersecting the falsifying region, and nothing in the corpus requires or verifies that it does** |
| **§46 the foundation** | **`PF-R46.5`: the four unclosable assumptions (`AS-05`/K's honesty · `AS-07`/`G24` · `RH-2` · `PF-AS-01`) ARE THE ARCHITECTURE'S ACTUAL FOUNDATION, and §43's U-1…U-4 are their consequences. An architecture whose foundation includes four assumptions it cannot discharge is not defective — it is honest** |
| New open research | **PF-OR-01 … PF-OR-05** (5) |
| New assumptions | **PF-AS-01** (1) |
| Amendments proposed | **PF-AM-29** (register hygiene: (a) the consolidated parameter registry is namespaced ⟨contract, local-id⟩; (b) **when a contract widens another's open issue, the OWNER's entry must be amended, not only the widener's**) |
| Cumulative amendments | **PF-AM-19 … PF-AM-29** (11 proposed by this audit) + 18 inherited-unratified = **29 unratified** |

**Next:** `85_` Vol J — §47 the fresh contradiction search · §48 the global circular-dependency audit · §49 the minimality
audit of all eight contracts · §50 the sixteen cross-contract ablations · §51 the compositional-safety theorem attempt.
