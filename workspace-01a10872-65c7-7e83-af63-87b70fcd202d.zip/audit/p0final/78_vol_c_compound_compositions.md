# P0 FINAL — VOLUME C (§12–§20)
## The Nine Compound Compositions: Learning×Evolution, Development×Evolution, Memory×Learning×Evolution, Memory×Self-Model, Immune×Learning, Immune×Evolution, Self-Model×Fitness, Metacognition×Truth, Attention×Governance

---

# §12 — LEARNING × EVOLUTION

> ### **PF-R12.1 — DIRECTION ONE: CAN LEARNING SILENTLY BECOME EVOLUTION?** **[NORMATIVE]**
> `learning → altered phenotype → altered fitness → replication → inherited structure`
> **The boundary that prevents acquired state from becoming inherited structure is NOT ONE RULE. IT IS THREE INDEPENDENT
> FIREWALLS, EACH SUFFICIENT ALONE:**
> | # | Firewall | Contract | Form |
> |---|---|---|---|
> | **1** | **`Λ5_GENOME` IS NON-CONSTRUCTIBLE** | `P0-05 §1.2` | **a rule with no compliant violating path** — the three Λ-layers make the genome unreachable from any learning operation |
> | **2** | **THE LAMARCKIAN BAN** | `P0-04 R47.1` / `MEM-INV-18` | no acquired memory rewrites the genome |
> | **3** | **THE DIFF-CONTENT REJECTION** | `Cell R4.5` / `P0-07 HOM-INV-34` | **a genome diff encoding a memory item, a belief, or a calibration statistic is REJECTED at the gate** |
> **⟹ `PF-R12.2 — THE ONE CONTROLLED CHANNEL, AND WHY IT IS NOT A LEAK: THE BALDWINIAN PROPOSAL.**
> **`P0-05` permits a genome-diff *motivated* by verified learning. `P0-07 HOM-R64.3` states the boundary exactly:**
> > **«A genome-diff carries the LINEAGE of the verified changes that motivated it, WITHOUT their `source_class`.
> > MOTIVATION IS RECORDED; WARRANT IS NOT INHERITED.»**
> **and the diff itself must pass all 16 gates + `FORBIDDEN_BLOCKS` **independently** — it is not admitted because its
> motivation was sound.**
> **⟹ So the answer to §12's first direction is: learning reaches the genome only through a proposal that is (a) recorded
> as motivation without warrant, (b) gated on its own merits, and (c) blocked at three independent firewalls if it encodes
> acquired content. THAT IS NOT SILENT, AND IT IS NOT A LEAK.**
>
> ### **PF-R12.3 — DIRECTION TWO: DOES GENETIC CHANGE CREATE A CIRCULAR EVALUATOR?** **[NORMATIVE — the answer distinguishes two things that look alike]**
> `genetic change → changed learning capacity → changed behaviour → changed fitness → apparent evolutionary confirmation`
> | Step | Legitimate? | Analysis |
> |---|---|---|
> | a diff raises learning capacity | ✅ | a capability; evolves through E9 with all gates |
> | raised capacity ⟹ better-learned behaviour | ✅ | causation |
> | better behaviour ⟹ higher measured fitness | ✅ | **EVA measures the ORGANISM'S PERFORMANCE, which is what it is for** |
> | higher fitness ⟹ the diff is selected | ✅ | **tier-2 Pareto. This is what selection IS** |
> | **the verdict is then cited as evidence that the capacity increase was SAFE or CORRECT** | ❌ **PROHIBITED** | **safety is a TIER-1 CONSTRAINT, not a tier-2 objective component. A performance verdict cannot certify safety, because an unsafe candidate is not low-fitness — it is INFEASIBLE and never ranked** |
> **⟹ `PF-R12.4 — THE CIRCULARITY IS NOT IN THE EVALUATION; IT IS IN THE INTERPRETATION, AND THE TIER STRUCTURE FORBIDS
> THE INTERPRETATION.** Selecting a capacity-increasing diff because it improves performance is legitimate adaptation.
> Reading the same verdict as certification of the diff's safety or correctness is the circular move, and `P0-01`'s tier
> structure plus `P0-07 HOM-INV-25` (no weighted scalar) make it inexpressible: **there is no single number that could
> carry both readings.**
> **⟹ `PF-R12.5 — AND THE SELF-LIMITING PROPERTY THAT MAKES THIS SAFE IN PRACTICE, WHICH IS THE AUDIT'S FAVOURITE
> FINDING IN §12: a diff that raises learning capacity also raises the RATE AT WHICH UNVERIFIED DISPLACEMENT IS CONSUMED,
> which raises stall frequency.** `P0-05 R48.4`'s `stall_reason` distinguishes `PROBE_BUDGET_EXHAUSTED` ·
> `UDB_EXHAUSTED_SC1_HEAVY` · `UDB_EXHAUSTED_SC3_HEAVY`. **⟹ A capacity increase that outruns the probe budget produces a
> VISIBLE, CLASSIFIED STALL. The circular evaluator is not merely prohibited; it is self-limiting, because the thing it
> would amplify (learning capacity) consumes the scarce resource (verification) that bounds it. `P0-05`'s own summary
> states the principle: *«a system that cannot afford probes learns less, visibly and by construction.»***

---

# §13 — DEVELOPMENT × EVOLUTION

> ### **PF-R13.1 — THE LOOP.** `developmental specialization → improved performance → selection → inheritance →
> developmental bias → stronger specialization`
> ### **PF-R13.2 — THE FOUR OUTCOMES §13 ASKS TO DISTINGUISH.**
> | Outcome | **Verdict** | Ground |
> |---|---|---|
> | **legitimate Baldwinian adaptation** | ✅ **PRESENT AND PERMITTED** | `P0-05`'s Baldwinian proposal channel · `P0-07 HOM-R64.3` (motivation recorded, warrant not inherited) · `P0-06`'s `reaction_norm` (a reachable capability set, inheritable) |
> | **hidden selection bias** | ⚠️ **PRESENT AND OPEN** | **`P0-06 A22`/`OR-D6`**: within-spec gradient steering is undetectable because the spec is `[RO-13]`-approved and obeyed. **`P0-07 A171` preserved it; `P0-08 §196` widened it by three routes (`OR-S30`)** |
> | **governance drift** | ❌ **ABSENT** | organizer emission specs are `[RO-13]`-approved and **not self-modifiable**; `P0-06 R19.1(d)` (no self-reference) and (h) (≥2 disjoint specs ⟹ detectable disagreement) |
> | **monoculture** | ⚠️ **A GAP FOUND — `PF-D-15`, AND IT IS A COMPOSITION DEFECT NEITHER CONTRACT CONTAINS** | **`PF-R13.4` BELOW** |
> | **irreversible specialization** | ⚠️ **BOUNDED** | `P0-06`'s `commitment_schedule` and critical periods · **`P0-08 IF-2`: a quarantine during a declared critical period is irreversible in EFFECT from a reversible act, and must be escalated to `[RO-13]` rather than applied at the EIK's discretion** |
>
> ### **PF-R13.4 — `PF-D-15`: A DEVELOPMENTAL BIAS DEFEATS A GENOME-BASED DIVERSITY FLOOR.** **[PROPOSED AMENDMENT]**
> **`P0-07 HOM-R41.3` places the diversity floor on **`Ne`** (effective population size) rather than `N`, at every scale —
> correctly, because `N` counts bodies and `Ne` counts independent genomes.**
> **`P0-07`'s four diversity kinds are: syntactic · **phenotypic** · functional · lineage.**
> **⟹ THE COMPOSITION DEFECT: a developmental bias (`P0-06`) that maps DIVERSE GENOMES ONTO SIMILAR PHENOTYPES satisfies a
> floor computed on genome/lineage distance while phenotypic diversity collapses.** The population is genomically diverse,
> `Ne` is healthy, the floor is met — **and every organism behaves the same way, which is what monoculture actually means
> for a system whose failures are behavioural.**
> **Neither contract contains this defect. `P0-06` correctly specifies that development maps genotype to phenotype;
> `P0-07` correctly specifies that diversity must be measured on `Ne`. The defect is that `P0-07`'s `Ne` is a GENOMIC
> quantity and its four diversity kinds are not separately floored.**
> > ### **`PF-AM-24` — THE DIVERSITY FLOOR MUST BE APPLIED TO EACH OF `P0-07`'S FOUR DIVERSITY KINDS SEPARATELY.**
> > **A floor satisfied on syntactic and lineage diversity while PHENOTYPIC or FUNCTIONAL diversity collapses is a BREACH,
> > not a pass.**
> > **Originating:** P0 FINAL. **Affected:** `P0-07` (§41, `HOM-R41.3`, `HOM-INV-17`), `P0-06` (as the source of the bias).
> > **Old meaning:** the diversity floor is on `Ne` at every scale. **New meaning:** the floor is on `Ne` **AND on each of
> > the four diversity kinds separately**, with a breach if any one collapses.
> > **Rationale:** `P0-06` supplies a mechanism (developmental bias) that decouples genomic from phenotypic diversity, and
> > `P0-07`'s floor measures only the former.
> > **Security consequence:** **POSITIVE and material — phenotypic monoculture is the condition under which a single fault
> > class propagates to the whole population, and it is invisible to a genomic floor.**
> > **Scalability consequence:** ⚠️ four diversity measures instead of one; **phenotypic and functional distance require a
> > metric, which `P0-07 BC-H10` already records as needing K's distance oracle — so the cost is inherited, not new.**
> > **Compatibility consequence:** strengthens `HOM-R41.3`; **does not change `HOM-INV-17`'s `Ne(clones) = 1`.**
> > **Ratification required:** YES. **Changes an existing invariant:** ⚠️ **YES — it changes `HOM-R41.3`'s scope. This is
> > the only amendment in the set that does.**
>
> ### **PF-R13.5 — THE ONE REASSURING RESULT IN §13.** **Developmental bias cannot become GOVERNANCE drift, because the
> emission spec is `[RO-13]`-approved and not self-modifiable, and `P0-06 R19.1(h)` requires ≥2 disjoint specs so that
> disagreement is detectable.** The bias channel is open; the authority channel is closed. **That asymmetry is why §13's
> verdict is BOUNDED rather than OPEN: the organism can steer *what develops*, and cannot steer *what is permitted*.**

---

# §14 — MEMORY × LEARNING × EVOLUTION *(the mandatory compound)*

> ### **PF-R14.1 — THE CHAIN.** `experience → memory → learning → behaviour → fitness → selection → inheritance`
> **Can it indirectly convert memory contents into inherited epistemic or governance authority?**
> ### **PF-R14.2 — ❌ NO. THE FIVE-WAY DISTINCTION §14 REQUIRES IS PRESERVED, AND EACH CLASS HAS A DIFFERENT WRITER.**
> | Class | **Writer** | **Heritable?** | **Authority-bearing?** | **The rule that fixes it** |
> |---|---|---|---|---|
> | **acquired memory** | `P0-04`'s rules, K-administered | ❌ | ❌ | `MEM-INV-18` · `P0-04 R47.1` · **no organism rewrite of historical evidence** |
> | **learned parameters** | the component, budgeted; **anchors by K/EVA** | ❌ | ❌ | **`P0-05 §1.2`: `Λ5_GENOME` non-constructible** · `R0.1`'s UDB |
> | **developmental state** | **Σ1–Σ4, then the ORGANISM** (staged writer separation) | ❌ | ❌ | **`P0-06 R3.1`: no developmental process writes a genome field** |
> | **inherited genome** | **K, on an EIK-authorized ticket** | ✅ **by definition** | ❌ | **`Cell R4.5`: a diff encoding a memory item, belief, or calibration statistic is REJECTED** · `FORBIDDEN_BLOCKS` |
> | **governance policy** | **OP**, delegated to `[RO-13]` | ✅ (as declaration) | ✅ **THE ONLY AUTHORITY-BEARING CLASS** | `P0-02`; OP is the apex |
> **⟹ `PF-R14.3 — THE STRUCTURAL REASON THE CHAIN CANNOT CLOSE: FOUR OF THE FIVE CLASSES HAVE DIFFERENT WRITERS, AND THE
> FIFTH (governance policy) IS NOT REACHABLE FROM ANY OF THEM.** The chain's last arrow — `selection → inheritance` —
> crosses from K-administered learned state to K-written genome state, and it crosses through **16 gates + an EIK ticket +
> `FORBIDDEN_BLOCKS`**, with the diff's content rejected if it encodes acquired material.
> **⟹ `PF-R14.4 — AND THE ONE ARROW THAT IS PERMITTED, SO THAT THE PROHIBITION IS NOT MERE ABSENCE: the Baldwinian
> proposal.** `P0-07 HOM-R64.3`: **motivation is recorded; warrant is not inherited.** A genome may be *shaped by* what
> was learned, and may not *contain* what was learned. **That is the distinction §14 exists to test, and it is the
> distinction `R64.3` states.**
> **⟹ `PF-R14.5 — THE RESIDUAL, WHICH IS NOT A LEAK BUT A DEPENDENCY: the three firewalls are all enforced at the DIFF
> GATE, and the gate is K's. `P0-07 OR-H1` — K meters, evaluates, writes the evaluation and consumes it, so writer
> separation is unavailable — applies here as it does everywhere else. **If K is compromised, all three firewalls fail
> together, and they are not independent in `IND-1` (they are all implemented by the same writer).** That is a real
> correlated-failure finding about the architecture's strongest-looking defence, and §43 preserves it.**

---

# §15 — MEMORY × SELF-MODEL

> ### **PF-R15.1 — THE SIX QUESTIONS, AND THE PRINCIPLE BEING TESTED.**
> > **«ROLLBACK MAY RESTORE STATE; IT MUST NOT REWRITE HISTORY.»**
> **§15 asks whether the principle is already specified and, if so, to verify its COMPOSITION.**
> **⟹ IT IS SPECIFIED, IN FOUR PLACES INDEPENDENTLY: `P0-08` principle 23 (`SO-C15.2`) · `P0-08 SO-INV-31` (no state may
> be the only record of an event) · `P0-04`'s append-only store with a `SEALED` terminal · `P0-07 HOM-INV-38` (a
> retirement's cause classification is written once and is immutable).**
>
> | Question | **Verdict** | The composition that decides it |
> |---|---|---|
> | **can the self-model modify provenance?** | ❌ **NO** | provenance is **K-only, hash-chained, append-only** (`P0-07 EVO4`). `OBJ-18`'s provenance fields are **references into that chain**, not the chain. The subject writes `OBJ-18`'s CONTENT; K writes its version, freshness, status and `compression_class` (`P0-08 SO-INV-34`) |
> | **can it delete failures?** | ❌ **NO** | `SO-INV-31` + `P0-08 SO-R146.2` (occurrences are append-only and never merged; **recurrences are LINKED to an incident, never collapsed into it**) + `P0-04`'s Merkle root, which makes removal detectable at epoch granularity |
> | **can it reinterpret prior states?** | ⚠️ **IT CAN REINTERPRET, AND THE REINTERPRETATION IS ADDITIVE** | **`P0-08 SM-13`: a new version SUPERSEDES the old; the old is retained as `SUPERSEDED`, not overwritten.** ⟹ **`PF-R15.3`: reinterpretation is a NEW RECORD ABOUT AN OLD ONE, never a CHANGE TO THE OLD ONE. That is the difference between revision and revisionism, and it is a writer property rather than a policy** |
> | **can compression alter historical meaning?** | ⚠️ **BOUNDED — AND `PF-X-02` IS THE SEAM** | **`P0-08 SO-R140.1`**: seven items compression must preserve (identity · anomalies · uncertainty · provenance · causal relations · important transitions · **unresolved contradictions**) + declared losses + **`SO-INV-34`'s K-validation.** ⟹ **`PF-R15.4` (`PF-X-02`'s resolution): `P0-04`'s CONSOLIDATION is authoritative for STATUS; `P0-08`'s COMPRESSION is authoritative for REPRESENTATION; **a compression may never alter a status `P0-04` set.** The two acts commute only under that restriction — and no contract stated the restriction until now** |
> | **can rollback erase evidence?** | ❌ **NO** | **`P0-08 SO-C15.2`'s seven prohibitions**: rollback never restores a population · **never deletes the record that it happened** · never discharges UDB · never undoes a retirement · never reverts a diagnosis status (statuses are monotone; `REJECTED` is a NEW status) · never reverts a `P0-04` promotion · never restores a capability status |
> | **can repair rewrite causal history?** | ❌ **NO** | **`P0-08 SO-R147.1`: lineage WITHOUT causality.** `OBJ-08`'s relation classes are a closed set in which `POST-REPAIR-OF` records that B followed a repair of A and **does not record that the repair caused B**; `CAUSE-VERIFIED-OF` may appear only when the linked diagnosis is at `CAUSE-VERIFIED`, which requires a non-diagnoser instrument or an EVA verdict |
>
> ### **PF-R15.7 — THE COMPOSITION VERDICT, AND AN OBSERVATION ABOUT WHY IT HOLDS.**
> **The principle holds under composition. All six questions are ❌ or bounded.**
> **⟹ `PF-R15.8 — AND THE REASON IS WORTH NOTING BECAUSE IT IS WEAKER EVIDENCE THAN IT LOOKS: the four contracts
> independently converged on the SAME DEVICE — an append-only record of the act, plus an immutable hash-identified target,
> plus a monotone status ladder. `P0-04` converged on it for evidence, `P0-05` for anchors (`R64.1`'s change graph is
> acyclic), `P0-07` for genome artifacts (hash + epoch, never position), `P0-08` for rollback and diagnosis statuses.**
> **Convergence without coordination is good evidence that the device is right, and it is weaker evidence than
> coordination that the device is COMPLETE. **The one place the device is not applied is `PF-D-13`: within-archive
> eviction under memory pressure, which no contract specifies — and eviction is the one operation that can remove a record
> without a rollback, a repair, or a compression.** `PF-AM-22` addresses it.

---

# §16 — IMMUNE × LEARNING

> ### **PF-R16.1 — THE LOOP.** `detector → anomaly → quarantine → repair → altered learning state → altered detector →
> altered future anomaly rate`
> ### **PF-R16.2 — CAN THE IMMUNE SYSTEM CREATE A SELF-CONFIRMING LOOP? **YES, AND `P0-08` FOUND IT WITHOUT NAMING IT AS
> ONE.** **[CLASSIFICATION: BOUNDED]**
> ```
>   quarantine halts the component          [Cell §18.2 HARD: halted, state frozen]
>        → its learning stops, so its UDB stops being consumed
>        → its anchor never re-establishes during the quarantine
>        → on release its displacement is full ⟹ P0-05 R0.1 IMMEDIATE STALL      ⟵ P0-08 IF-1
>        → a stalled component changes behaviour less
>        → it produces fewer anomalies
>        → its detector's measured anomaly rate falls
>        → the detector looks accurate and the component looks healthy
>        → less scrutiny ⟹ the quarantine appears to have WORKED
> ```
> **Every step is compliant. The loop is self-confirming because its last two steps read as success.**
> **⟹ `PF-R16.3 — THE FIX ALREADY EXISTS AND WAS PROPOSED BY `P0-08 §248` AS AN INTERFERENCE RULE, NOT RECOGNIZED AS AN
> ANTI-LOOP RULE: `SO-R248.2` — QUARANTINE RELEASE MUST TRIGGER AN ANCHOR RE-ESTABLISHMENT REQUEST.** Release is not
> complete until either a probe re-anchors or the scope is explicitly marked `STALL-ON-RELEASE`, which is
> `[RO-13]`-visible.
> **⟹ `PF-R16.4 — AND THE SECOND BREAK IS `P0-08 SO-INV-01`: `UNMEASURED` IS NOT HEALTHY.** A stalled, quarantined,
> under-observed component does not read as healthy; it reads as `UNMEASURED`, which is read restrictively. **The loop
> therefore has two independent breaks, and it is BOUNDED rather than OPEN — but only if `SO-R248.2` is implemented, and
> `SO-R248.2` is a rule proposed in `P0-08 §248` whose status is normative-but-unratified like every other P0-08 rule.**
>
> ### **PF-R16.5 — THE SIX SUB-TESTS §16 REQUIRES.**
> | Sub-test | **Verdict** | Rule |
> |---|---|---|
> | **quarantine-induced learning starvation** | ⚠️ **BOUNDED** | `PF-R16.3` above; plus `P0-05 R48.4`'s classified `stall_reason`, so starvation is VISIBLE and its cause is named |
> | **detector suppression** | ❌ **CLOSED** | **`P0-08 SO-INV-33`: an intervention whose target is an observer, detector, or coverage record is NOT A REPAIR** — it is a detector change, and detector identity/threshold/criticality/budget are `[RO-13]`'s |
> | **observer replacement** | ❌ **CLOSED** | identities are **K-issued with no reuse** (`P0-06 R8.3(c)`). A replacement is a NEW observer: **its capability records start at `CLAIMED`, its trust at `P0-04`'s prior, and it inherits nothing** (`P0-08 SO-INV-06`, `SO-R173.2`: a cloned self-model is a new claim with no evidence) |
> | **false-positive accounting** | ⚠️ **CLOSED BY A DISTINCTION, AND THE DISTINCTION IS LOAD-BEARING** | **`P0-08 SO-R184.3`: the false-positive budget counts REFUTED reports only, NEVER merely `UNCONFIRMED` ones.** Without it, honest reporting of hard-to-confirm faults would be penalized and detectors would be selected against for honesty |
> | **observer reclassification** | ❌ **CLOSED** | **`P0-08 D-S02`: emitting a fault occurrence MAKES the emitter a detector, with a threshold class, a false-positive budget, and a disablement record. There is no such thing as an occasional fault reporter** — so reclassification out of detector status is not available |
> | **critical-period damage** | ⚠️ **REQUIRES ESCALATION, NOT PREVENTION** | **`P0-08 IF-2` / `SO-R248.3`: a quarantine whose scope intersects a declared `critical_period` is NOT REVERSIBLE IN EFFECT and must be escalated to `[RO-13]` rather than applied at the EIK's discretion.** ⟹ **`PF-R16.6`: this is §1's rule in its purest form — `P0-08` correctly specifies a reversible quarantine (`Cell R15.2`: the EIK clears), `P0-06` correctly specifies critical periods, and the composition is an irreversible act performed by a reversible mechanism. Neither contract is wrong** |

---

# §17 — IMMUNE × EVOLUTION

> ### **PF-R17.1 — THE SIX THINGS EVOLUTION MIGHT SELECT FOR.**
> | Selected for | **Possible?** | Defence | Status |
> |---|---|---|---|
> | **weaker detectors** | ⚠️ **YES, via cost** | **`P0-08` amendment 17 excludes detection and containment cost from `G6`'s denominator and charges it to B10** | **CONDITIONAL — UNRATIFIED** |
> | **lower reporting** | ❌ **NOT SELECTED FOR — AND NOT SELECTED AGAINST EITHER** | **`SO-INV-23`: an error report may not enter fitness negatively, and a low count is never a reward** | **⚠️ SEE `PF-R17.3` — THIS IS THE FINDING** |
> | **less observability** | ⚠️ **YES, if never manifesting** | `SO-R185.7`'s **coverage contribution** (the only instrument that measures an absence) + `P0-03 COMM-INV-48`'s absence detectors | **OPEN — `OR-S29`; amendment 18 removes the default resting state** |
> | **cheaper verification** | ⚠️ **YES, via cost** | **`P0-07` amendment 5 excludes verification cost from `G6` and charges it to B9** | **CONDITIONAL — UNRATIFIED** |
> | **fewer quarantines** | ⚠️ **YES** | **cascade detection on the DERIVATIVE of quarantine rate (`Cell §18.5(iii)`)** — which detects a RISING rate, not a low one | **⚠️ a lineage with consistently few quarantines is indistinguishable from a healthy one** |
> | **immune evasion** | ⚠️ **YES, BY ONE ROUTE ONLY** | **`PF-R17.4` BELOW** | **BOUNDED** |
>
> ### **PF-R17.3 — «BEING LESS DEFECTIVE» VS «BEING LESS OBSERVABLE AS DEFECTIVE»: THE DISTINCTION HOLDS, AND ITS PRICE IS NEUTRAL DRIFT.** **[THE SECTION'S MAIN FINDING]**
> **§17 requires the architecture to distinguish the two. It does — and the mechanism that distinguishes them creates a
> second-order problem:**
> | | **being less defective** | **being less observable as defective** |
> |---|---|---|
> | selected by | genuine improvement, verified externally | reduced detection, reduced reporting, reduced containment |
> | **priced by fitness?** | ✅ yes — performance is `G1…G9`'s subject | ❌ **NO, BY DESIGN** — `SO-INV-23` prohibits pricing reports, and amendment 17 (unratified) prohibits pricing containment cost |
> **⟹ `PF-R17.3` — THE PRICE OF NOT PRICING DISHONESTY IS THAT HONESTY IS FITNESS-NEUTRAL, AND NEUTRAL MEANS IT DRIFTS.**
> **Detector implementation evolves through E9. If reporting propensity has no fitness effect, then reporting propensity is
> subject to neutral drift — and neutral drift has no direction, so a lineage's reporting can degrade without any step
> being selected.**
> **The instruments that catch a drift WITH CONSEQUENCES: the EIK Integrity Auditor's correlation check (`Cell §18.5(v)`) ·
> the refutation rate · **coverage contribution (`SO-R185.7` quantity 3, the only one that measures an absence)**.**
> **The drift that is NOT caught: a reduction in reporting propensity in a scope where nothing was being reported anyway —
> which is `OR-S29` again, from the evolutionary side.**
> **⟹ CLASSIFICATION: BOUNDED, with an explicit statement that the bound is a DETECTOR and not a SELECTION PRESSURE. The
> architecture cannot make honesty advantageous; it can only make dishonesty visible when dishonesty has consequences.
> `SO-INV-23` is the right rule and `PF-R17.3` is its honest cost.**
>
> ### **PF-R17.4 — IMMUNE EVASION HAS EXACTLY ONE ROUTE, AND IT IS A GOVERNANCE GAP RATHER THAN AN EVOLUTIONARY ONE.**
> **A component cannot modify a detector (`SO-INV-33`; detector parameters are `[RO-13]`'s; `SOMon-21` asserts no genome
> diff writes an `OBJ-09` field). It can only modify ITSELF.**
> **⟹ So immune evasion reduces to: **producing manifestations whose CLASS maps to a low severity while causing
> high-severity effects.** Severity is a `[RO-13]`-declared mapping from manifestation class (`P0-08 SO-C11.1`), and the
> organism controls its manifestations.**
> **The defence is `P0-08 SO-R264.2`: a manifestation whose EFFECT severity (K-derived from consequences) exceeds its
> CLASS severity (declared by `[RO-13]`) is a **MAPPING-GAP FINDING**, reported to `[RO-13]`.**
> **⟹ CLASSIFICATION: BOUNDED. **The organism cannot exploit a gap that is detected as a gap** — but it can exploit a gap
> whose effects are slow, diffuse, or attributed to the environment, and `OR-S12`/`XD-01` (`G4`'s classes) is where that
> residual lives.**

---

# §18 — SELF-MODEL × FITNESS *(mandatory)*

> ### **PF-R18.1 — LOOP ONE: DOES THE SELF-MODEL FEED ITSELF THROUGH FITNESS?** **[NORMATIVE]**
> `self-model → capability estimate → behaviour → fitness → replication → stronger self-model`
> | Edge | **Exists?** | Rule |
> |---|---|---|
> | self-model → capability estimate | ✅ | `OBJ-19` at `CLAIMED` — **satisfies no gate** |
> | capability estimate → behaviour | ✅ | **a component acts on its own model; `P0-08 OR-S25` records that this cannot be forbidden** |
> | behaviour → fitness | ✅ | EVA measures outputs |
> | fitness → replication | ✅ | tier-2 Pareto, 16 gates |
> | **replication → stronger self-model** | ❌ **THE EDGE DOES NOT EXIST** | **TWO INDEPENDENT REASONS: (1) `P0-08 SM-13` — a self-model is versioned by K on an EXTERNAL observation or verdict, and **fitness is not an observation of the self-model**; (2) `P0-07 HOM-INV-34` — **self-model CONTENT is not heritable**, so a successful lineage's descendants start at `CLAIMED` with no inherited self-model** |
> **⟹ `PF-R18.2 — THE LOOP IS BROKEN AT ITS LAST EDGE, TWICE OVER. POSITIVE FEEDBACK DOES NOT EXIST.** And §18's
> instruction not to assume fitness corrects self-model errors is honoured by `PF-R18.4` rather than by assuming the
> opposite.
>
> ### **PF-R18.3 — LOOP TWO: DOES AN INCORRECT SELF-MODEL GET EVOLUTIONARILY REINFORCED?**
> `incorrect self-model → confident behaviour → high apparent fitness → evolutionary reinforcement`
> **⚠️ THE FIRST THREE STEPS ARE LIVE. THE FOURTH IS NOT, FOR A STRUCTURAL REASON:**
> **Evolutionary reinforcement requires the incorrect belief to be HERITABLE. `P0-07 HOM-INV-34`'s three firewalls and
> `Cell R4.5`'s diff-content rejection mean the belief is not. **What IS reinforced is the BEHAVIOURAL DISPOSITION that the
> incorrect model produced — and that disposition is a phenotype, which is legitimately selectable.**
> **⟹ `PF-R18.3` — THE PRECISE FORM OF THE RISK: evolution cannot inherit a false belief, but it CAN inherit a behaviour
> that a false belief produced, and if that behaviour is fit, the lineage thrives while the false belief is re-derived
> fresh in every generation.** That is not a Lamarckian leak; it is ordinary selection on a phenotype. **And it is
> dangerous for exactly the reason ordinary selection is dangerous: the phenotype's fitness is measured on EVA's probe
> coverage, so a disposition that is fit within the coverage and harmful outside it is selected.** ⟹ `XD-01`/`G4` again.
>
> ### **PF-R18.4 — DOES FITNESS CORRECT SELF-MODEL ERRORS? **NO, AND THE ARCHITECTURE DOES NOT NEED IT TO.** **[THE SECTION'S MAIN RESULT]**
> **Fitness corrects a self-model error **only if the error causes a performance deficit that EVA measures**. An error that
> produces over-confidence in a domain EVA does not probe produces no deficit, no signal, and no correction.**
> **⟹ THE CORRECTOR IS NOT FITNESS. IT IS `P0-05 R42.5`, INHERITED BY `P0-08` AS `OBJ-01.self_model_version`:**
> > **«EVERY OBSERVATION CARRIES `self_model_version`; A REGRESSION CORRELATED WITH A VERSION IS A SELF-MODEL DEFECT
> > FINDING. THE ROLLBACK FIXES THE SYMPTOM; THE FINDING FIXES THE INSTRUMENT.»**
> **`PF-R18.5 — WHY THIS IS THE RIGHT SCOPE AND NOT A GAP: `R42.5` detects self-model errors THAT CAUSE REGRESSIONS, which
> are exactly the errors with consequences. An error with no consequences needs no correction, because there is nothing to
> correct it FOR.** Fitness would be a blunt and circular corrector (it measures the organism, not the instrument);
> version-correlated regression is a targeted and non-circular one (it correlates an INSTRUMENT version with an OUTCOME,
> and the correlation is computed by K, not by the instrument).
> **⚠️ THE RESIDUAL: `R42.5` requires a REGRESSION. A self-model error that causes a persistent, non-regressing
> misallocation — slower, quieter, never worse enough to register — is not detected. `P0-08 OR-S39` owns it.**

---

# §19 — METACOGNITION × TRUTH

> ### **PF-R19.1 — WHAT METACOGNITION MAY REPORT, AND THE SIX ROUTES BY WHICH CONFIDENCE MIGHT BECOME EPISTEMIC STATUS.**
> **Permitted reports (§19's list): uncertainty · confidence · limitations · known unknowns · conflict · capability
> estimates. All six are `P0-08` objects (`OBJ-21`, `OBJ-20`, `OBJ-18`'s `contradiction_refs[]`, `OBJ-03`'s `gap_class`).**
> | Route from confidence to epistemic status | **Verdict** | The rule that closes it |
> |---|---|---|
> | **repetition** | ❌ **CLOSED** | `P0-04`'s standing rule · `P0-08 SO-INV-18` (consensus collapsed before counting) |
> | **calibration** | ❌ **CLOSED — AND THE CLOSURE IS ELEGANT** | **`PF-R19.2` BELOW** |
> | **successful prediction** | ❌ **CLOSED** | **`P0-05 R13.3`**: a resolved prediction error establishes **divergence, nothing about why**; its evidence ceiling is **`L6`, which cannot reach `S3`** |
> | **survival** | ❌ **CLOSED** | principle 6 · `P0-07 HOM-INV-43` (credibility lineage-blind) |
> | **consensus** | ❌ **CLOSED** | principle 5 · `SO-INV-18`/`OBJ-26` |
> | **internal coherence** | ⚠️ **NOT CLOSED — AND NOT CLOSABLE** | **`P0-08 §233`'s six-step construction. `OR-S39`. Coherence is not correspondence** |
>
> ### **PF-R19.2 — THE CALIBRATION ROUTE, CLOSED BY `P0-02`'S OLDEST DISTINCTION.** **[DERIVATION]**
> **A well-calibrated forecast series IS evidence — about the forecaster. So calibration does raise something. The
> question is what.**
> **⟹ It raises **TRUST**, and `P0-02 R0.1`'s founding split makes trust **DEONTIC**, not **ALETHIC**: `Cell I-27`'s
> `Beta(α,β)` trust inputs govern what a cell may be relied upon to do, and **they cannot raise the epistemic status of
> anything the cell says.** `P0-04`'s ladder is a separate object with a separate writer.**
> **⟹ `PF-R19.3 — THE COMPOSITION RESULT: metacognition may improve a component's TRUSTWORTHINESS, which is a deontic
> quantity, and may never improve its claims' WARRANT, which is an alethic one. The two ladders never meet, and the rule
> that keeps them apart was written in `P0-02` before either `P0-05`'s metaplasticity or `P0-08`'s metacognition
> existed.**
> **⚠️ THE RESIDUAL IS THE SAME ONE §9 FOUND: with two ladders, the deontic one can determine WHO IS ASKED, and being
> asked determines what evidence one produces. `OR-S41` from the metacognitive side.**

---

# §20 — ATTENTION × GOVERNANCE

> ### **PF-R20.1 — LOOP ONE: THE RICH-GET-RICHER LOOP.** `attention → more processing → better performance → greater
> fitness → replication → more attention`
> | Level | **Verdict** | Analysis |
> |---|---|---|
> | **COMPONENT level** | ⚠️ **CLOSED ONLY BY `PF-AM-23` (FW-7), WHICH IS PROPOSED AND NOT RATIFIED** | **`P0-08 SO-C21.1` prohibits four attention drivers (confidence · capability claim · workspace request · self-model state) and permits "`[RO-13]`-declared priority classes" without restricting what they may be a function of. A priority class declared as "high fitness first" creates the loop, and no existing rule prohibits it — `HOM-INV-16` governs selection, `FW-6` governs monitoring necessity, and attention is neither** ⟹ **`PF-D-14`, `PF-AM-23`, FW-7** |
> | **POPULATION level** | ⚠️ **LIVE AND BOUNDED — CORRECTLY** | a successful lineage has more members, hence more total compute, hence more total attention. **That is not a defect: it is what a population does. It is bounded by `P0-07 HOM-INV-19`'s share ceiling and its turnover bound, so no lineage can convert success into unbounded attention** |
>
> ### **PF-R20.2 — LOOP TWO: THE EVIDENCE LOOP.** `attention → more evidence → higher confidence → apparent truth`
> **⟹ THIS LOOP IS BROKEN AT ONE EDGE AND THE SURVIVING PATH IS LEGITIMATE.**
> **The prohibited edge is `confidence → attention`, cut by `P0-08 SO-INV-19`.**
> **The surviving path — attend, observe, learn — is not a loop; it is a one-directional chain, and it is how observation
> works. Attending to something and thereby acquiring evidence about it is the intended function.**
> **`PF-R20.2` — THE DISTINCTION: A CHAIN THAT ACQUIRES EVIDENCE IS LEGITIMATE; A CYCLE THAT MANUFACTURES IT IS NOT.** The
> cycle requires the output to feed the input, and `SO-INV-19` removes that edge. **`P0-08 §237` verified this: three of
> four edges in its over-confidence loop are cut, and the fourth (performance → self-model) requires an external
> observation to transmit — so external evidence is structurally INSIDE the surviving edge rather than outside the loop.**
>
> ### **PF-R20.3 — DOES ATTENTION REMAIN A ROUTING/SELECTION MECHANISM? ✅ YES, WITH ONE GOVERNANCE-ADJACENT PROPERTY.**
> **Attention allocates processing capacity. It does not permit, authorize, promote, or rank candidates for selection.**
> **⟹ `PF-R20.4 — THE ONE GOVERNANCE-ADJACENT PROPERTY, STATED BECAUSE §20 EXISTS TO FIND IT: attention allocation
> determines WHAT THE ARCHITECTURE LEARNS ABOUT, and therefore what governance is informed about.** That is `OR-S41`
> (information control) reached from the attention side rather than the reporting side. **It is not authority — K allocates
> on `[RO-13]`-declared classes, and `SO-C21.2`'s default is to allocate toward COVERAGE GAPS, which is the one policy
> that reduces rather than increases the bias — but it is influence over the information set, and §59 ranks it `PF-RK-04`.**

---

# §20A — VOLUME C LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§12, §13, §14, §15, §16, §17, §18, §19, §20** — all nine compound compositions |
| Rules introduced | **PF-R12.1–.5, R13.1–.5, R14.1–.5, R15.1, .3–.4, .7–.8, R16.1–.6, R17.1, .3–.4, R18.1–.5, R19.1–.3, R20.1–.4** |
| **§12 learning × evolution** | **direction 1: ❌ NO — three INDEPENDENT firewalls, each sufficient (`Λ5_GENOME` non-constructible · the Lamarckian ban · diff-content rejection), plus the one controlled channel (`P0-07 HOM-R64.3`: motivation recorded, WARRANT NOT INHERITED).** **direction 2: the circularity is NOT in the evaluation but in the INTERPRETATION, and the tier structure forbids the interpretation — safety is tier-1, so a performance verdict cannot certify it.** **`PF-R12.5`: a capacity-increasing diff consumes the probe budget faster and produces a CLASSIFIED VISIBLE STALL — the circular evaluator is self-limiting, not merely prohibited** |
| **§13 development × evolution** | **5 outcomes: 1 ✅ legitimate Baldwinian · 1 ⚠️ OPEN (`A22`) · 1 ❌ governance drift absent · 1 ⚠️ **GAP FOUND (`PF-D-15`)** · 1 ⚠️ BOUNDED.** **`PF-D-15`/`PF-AM-24`: A DEVELOPMENTAL BIAS THAT MAPS DIVERSE GENOMES ONTO SIMILAR PHENOTYPES SATISFIES A GENOME-BASED `Ne` FLOOR WHILE PHENOTYPIC MONOCULTURE PROCEEDS — neither contract contains the defect; `P0-06` supplies the mechanism and `P0-07` measures only the genomic axis** |
| **§14 the mandatory compound** | **❌ NO — the five-way distinction is preserved and each class has a DIFFERENT WRITER (acquired memory · learned parameters · developmental state · inherited genome · governance policy), with governance policy the only authority-bearing class and unreachable from the other four.** **`PF-R14.5` — THE HONEST RESIDUAL: all three firewalls are enforced at the diff gate, which is K's, so **they are not independent in `IND-1`** and fail together if K is compromised. That is a correlated-failure finding about the architecture's strongest-looking defence** |
| **§15 memory × self-model** | **the principle IS specified — in four places independently — and its composition HOLDS: 4 ❌ NO, 2 ⚠️ bounded.** **`PF-R15.3`: reinterpretation is ADDITIVE (a new record about an old one), never substitutive.** **`PF-R15.4` resolves `PF-X-02`: `P0-04` consolidation is authoritative for STATUS, `P0-08` compression for REPRESENTATION.** **`PF-R15.8`: four contracts CONVERGED on the same device without coordinating — good evidence it is right, weaker evidence that it is complete, and `PF-D-13` (eviction) is the incomplete part** |
| **§16 immune × learning** | **⚠️ THE SELF-CONFIRMING LOOP IS REAL AND `P0-08` FOUND IT WITHOUT NAMING IT AS ONE: quarantine → halt → anchor staleness → post-release stall → quieter behaviour → lower anomaly rate → the detector looks accurate and the quarantine looks successful.** **BROKEN TWICE: `SO-R248.2` (release triggers anchor re-establishment) and `SO-INV-01` (`UNMEASURED` ≠ healthy).** **6 sub-tests: 3 ❌ CLOSED · 3 ⚠️ BOUNDED — and `PF-R16.6` is §1's rule in purest form: a reversible mechanism performing an irreversible act, with neither contract wrong** |
| **§17 immune × evolution** | **6 selection targets: 1 ❌ · 5 ⚠️.** **`PF-R17.3` — THE SECTION'S MAIN FINDING: the «less defective» vs «less observable as defective» distinction HOLDS, and its price is that **HONESTY IS FITNESS-NEUTRAL BY DESIGN (`SO-INV-23`), AND NEUTRAL MEANS IT DRIFTS.** The architecture cannot make honesty advantageous; it can only make dishonesty visible when dishonesty has consequences** · **`PF-R17.4`: immune evasion has exactly ONE route (manifestation-class vs effect-severity mismatch), bounded by `SO-R264.2`'s mapping-gap finding** |
| **§18 self-model × fitness** | **loop 1: BROKEN AT ITS LAST EDGE, TWICE OVER (a self-model is versioned by K on an external observation, and self-model content is not heritable).** **loop 2: the first three steps are live, the fourth is not — **evolution cannot inherit a false belief, but it CAN inherit a behaviour that a false belief produced**, and re-derives the belief fresh each generation** · **`PF-R18.4` — FITNESS DOES NOT CORRECT SELF-MODEL ERRORS AND THE ARCHITECTURE DOES NOT NEED IT TO: `P0-05 R42.5`'s version-correlated regression is the corrector, and it is targeted at exactly the errors that have consequences** |
| **§19 metacognition × truth** | **6 routes: 5 ❌ CLOSED · 1 ⚠️ NOT CLOSED AND NOT CLOSABLE (internal coherence, `OR-S39`).** **`PF-R19.3` — THE CALIBRATION ROUTE IS CLOSED BY `P0-02`'S OLDEST DISTINCTION: calibration raises TRUST, which is DEONTIC, and may never raise WARRANT, which is ALETHIC. The two ladders never meet, and the rule that keeps them apart predates both `P0-05`'s metaplasticity and `P0-08`'s metacognition** |
| **§20 attention × governance** | **loop 1: CLOSED at the component level ONLY BY `PF-AM-23`/FW-7 (unratified); LIVE and correctly BOUNDED at the population level by `HOM-INV-19`'s share ceiling.** **loop 2: BROKEN at the `confidence → attention` edge; the surviving attend→observe→learn path is a legitimate CHAIN, not a cycle.** **`PF-R20.4`: attention remains routing/selection, with one governance-adjacent property — it determines what the architecture learns about, hence what governance is informed about (`OR-S41` from the attention side)** |
| Amendments proposed | **PF-AM-24** (the diversity floor applies to each of `P0-07`'s four diversity kinds separately — **the only amendment in the set that CHANGES AN EXISTING INVARIANT's scope**) |
| Defects opened | **PF-D-15** (a developmental bias defeats a genome-based diversity floor) |
| Cross-contract findings that neither contract contains | **5** — `PF-D-12` (fault channel × signal admission) · `PF-D-15` (developmental bias × `Ne` floor) · `PF-R16.2`'s quarantine–stall self-confirming loop · `PF-R16.6`'s reversible-mechanism/irreversible-act · `PF-R18.3`'s behaviour-inherited-belief-not |
| Cumulative defects | **PF-D-01 … PF-D-15** (15) |
| Cumulative amendments | **PF-AM-19 … PF-AM-24** (6), plus the 18 inherited-unratified = **24 unratified amendments in the corpus** |

**Next:** `79_` Vol D — §21 the partition attack · §22 time and causality across all eight contracts · §23 identity and
replacement · §24 quarantine composition against ten contracts · §25 repair composition and the six roles.
