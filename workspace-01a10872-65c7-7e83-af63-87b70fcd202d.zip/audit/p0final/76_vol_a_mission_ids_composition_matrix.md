# P0 FINAL — VOLUME A (§0–§6)
## Mission, the Compositional Rule, the Classification Taxonomy, the Identifier Audit, the Primary Question, and the 28-Pair Composition Matrix

**Audit:** *Cross-Contract Integration, Ratification & Architecture Closure* over `P0-01 … P0-08` plus the inherited V4 Cell Contract.
**Directory:** `/home/user/audit/p0final/` · **Files `76_` … `88_` + `README.md`.**
**Corpus audited:** 9 contract sets · **75 files · ~66,600 lines** *(cell-contract 6/4,649 · task-fitness 5/5,633 · eik 7/6,873 · comm 9/8,866 · memory 8/7,328 · learning 8/5,159 · development 8/7,282 · population 10/6,682 · selfmodel 14/7,165)*.

---

# §0 — MISSION, AND WHAT THIS AUDIT IS NOT

> ### **PF-R0.1 — THE MISSION.** Determine whether `P0-01 … P0-08`, **composed**, form one coherent architecture whose
> contracts can be frozen for transition into P1.
> ### **PF-R0.2 — WHAT THIS IS NOT.** Not a subsystem design. **No P0-09 is created** (§54's gate is applied and its
> result is a rejection). No new architectural layer is invented because an interaction is difficult. Where an
> interaction is difficult, §34's seven-question test decides whether it is an interface, a parameter, an invariant, an
> external assumption, a P1 concern, or a genuine subsystem — and only the last could justify a contract.
> ### **PF-R0.3 — THE EVIDENCE DISCIPLINE.** Every count in this audit is **regex-measured over the corpus**, not
> recalled from the individual contracts' own summaries. §60 reconciles fourteen counts; §61 sweeps every reference;
> §64 reports the machine check. **Where this audit's measurement contradicts a contract's self-reported figure, the
> measurement governs and the contradiction is recorded as a defect (`PF-D-nn`), not smoothed over.**

---

# §1 — THE ABSOLUTE ARCHITECTURAL RULE

> ### **PF-R1.1 — THE RULE.**
> > **«A subsystem can be internally correct while its composition with another subsystem is incorrect.»**
> > **«Passing all eight individual contracts does NOT imply that the combined architecture passes.»**
> ### **PF-R1.2 — THE METHOD THIS AUDIT THEREFORE USES.**
> **Nothing in §7–§41 repeats a prior contract's internal audit. Every finding must name at least two contracts, and
> must state what each contract says separately and what happens at the seam.**
> **Three consequences for how findings are recorded:**
> **(a) A defect that exists inside one contract alone is OUT OF SCOPE and is routed back to that contract** — with the
>     exception of §61's reference-integrity defects, which are defects *of the corpus* and therefore in scope.
> **(b) A property that both contracts assert separately is NOT thereby asserted jointly.** `P0-04`'s "no organism
>     rewrite of historical evidence" and `P0-08`'s "rollback ≠ historical deletion" are compatible rules about
>     different objects; §15 tests whether their *composition* holds, which is a different question from whether each
>     holds.
> **(c) The interesting findings are the ones neither contract could have found.** §24's *"reversible quarantine
>     producing effectively irreversible developmental consequences"* is the model: `P0-08` correctly specifies a
>     reversible quarantine, `P0-06` correctly specifies critical periods, and the defect exists only in the pair.
>     **This audit found six such cases (§7–§20) and they are the audit's actual output.**

---

# §2 — ARCHITECTURE-ONLY CONSTRAINT

> ### **PF-R2.1 — COMPLIANCE, VERIFIED MECHANICALLY.**
> **No source code, no language implementation, no deployment script, no infrastructure code, no API-as-code, no database
> implementation, no production configuration appears anywhere in this audit.**
> **What does appear: abstract interfaces · formal schemas · state machines · invariants · contracts · ownership ·
> authority · dependencies · conformance requirements · test specifications · mathematical relations. All eleven are
> permitted by §2.**
> **⟹ Machine check 8 (§64) asserts zero fenced blocks tagged `python`/`js`/`c`/`java`/`bash`/`sql`/`yaml`/`json` across
> all files of this audit. The only fenced blocks are ASCII diagrams of graphs, cascades, state machines, and the
> decision tree.**

---

# §3 — NO SILENT MODIFICATION: THE SEVEN-CATEGORY TAXONOMY

> ### **PF-R3.1 — EVERY REQUIRED CHANGE IS CLASSIFIED INTO EXACTLY ONE OF SEVEN CATEGORIES.** **[NORMATIVE]**
> | # | Category | Meaning | Obligation |
> |---|---|---|---|
> | **1** | **ALREADY COVERED** | an existing rule in an existing contract disposes of it | cite the rule by ID and contract; **add nothing** |
> | **2** | **INTEGRATION CLARIFICATION** | the semantics already exist but the composition was never stated | state the composition; **change no rule's meaning** |
> | **3** | **PROPOSED AMENDMENT** | a rule's meaning must change | **all eleven §3 fields** (below); **NOT ratified by being proposed** |
> | **4** | **BLOCKING DEFECT** | implementation correctness depends on resolution | §254-analogue entry with an owner |
> | **5** | **OPEN RESEARCH** | not resolvable architecturally now | §44's ten-attribute register entry |
> | **6** | **EXTERNAL DEPENDENCY** | another party must supply it | named supplier + what is needed |
> | **7** | **P1 IMPLEMENTATION CONCERN** | architecture is settled; realization is not | §57's freedom list |
>
> ### **PF-R3.2 — THE ELEVEN MANDATORY FIELDS OF EVERY PROPOSED AMENDMENT.** **[NORMATIVE]**
> **amendment ID · originating contract · affected contract(s) · exact OLD rule/meaning · exact NEW rule/meaning ·
> rationale · security consequence · scalability consequence · compatibility consequence · whether ratification is
> required · whether it changes an existing invariant.**
> **⟹ `PF-R3.3 — NO AMENDMENT IN THIS AUDIT IS RATIFIED.** Amendments 1–18 were proposed by `P0-07` (1–14) and `P0-08`
> (15–18) and **remain unratified**; this audit proposes **19–26** and they too remain unratified. **§75.B lists as
> "ratified" only what has actually been ratified, which at the time of this audit is nothing.** An architecture whose
> safety depends on eight unratified amendments is recorded as depending on them, not as depending on their content."

---

# §4 — INHERITED ID CONVENTIONS, AND THE TWO DEFECTS THE CONVENTION AUDIT FOUND

> ### **PF-R4.1 — THE BRIEF'S ATTACK-NUMBERING INSTRUCTION IS STALE, AND FOLLOWING IT WOULD CREATE THE COLLISION IT PROHIBITS.** **[BLOCKING DEFECT → resolved by ruling]**
> **§4 of the brief states: *"P0-07 ended its attack sequence at A171. Therefore any new P0 FINAL attack IDs MUST begin
> at A172."***
> **⟹ MEASURED FACT: `P0-08` consumed A172 … A263. The corpus maximum is A263, verified by regex over all 75 files;
> A264 and above are absent.**
> **§4 also states: *"Do not reuse or redefine existing rule IDs, invariant IDs, state-machine IDs, parameter IDs,
> attack IDs, output IDs."* Beginning at A172 would redefine **92 existing attack IDs** — the larger violation of the two
> instructions.**
> **⟹ `PF-R4.2 — RULING: P0 FINAL ATTACKS BEGIN AT **A264**. The brief's A172 is recorded as stale rather than
> followed, because §4's own prohibition on redefinition takes precedence over its own starting number, and because §76
> forbids silently amending prior contracts.**
> **This is exactly the defect class `P0-07`'s sweep recorded as lesson (f): *cross-contract attack registers are global —
> check the prior contract's maximum before forward-referencing.* `P0-07` and `P0-08` both checked. This brief did not,
> and the audit says so rather than absorbing the error.**
>
> ### **PF-R4.3 — THE NEW NAMESPACE, AND ITS NON-COLLISION PROOF.** **[NORMATIVE]**
> **§4 requires: *"If a new identifier namespace is necessary, define it before using it and prove that it cannot collide
> with P0-01 through P0-08."***
> | Prefix | Denotes | Numbered by |
> |---|---|---|
> | **`PF-R<section>.<m>`** | an integration rule | the brief's section (§6 → `PF-R6.m`) |
> | **`PF-D-<nn>`** | a **defect found by this audit** | sequential |
> | **`PF-AM-<nn>`** | a proposed amendment | **continues the series: 1–14 `P0-07`, 15–18 `P0-08`, so 19 onward** |
> | **`PF-X-<nn>`** | a new contradiction | sequential |
> | **`PF-BC-<nn>`** | a circular dependency in the **global** register | sequential |
> | **`PF-CSC-<nn>`** | a failure cascade | sequential (§31 requires ≥20) |
> | **`PF-OR-<nn>`** | an open-research entry in the **global** register | sequential |
> | **`PF-AS-<nn>`** | an assumption in the **global** register | sequential |
> | **`PF-P-<nn>`** | a parameter in the **consolidated** registry | sequential (§45) |
> | **`PF-AB-<nn>`** | an ablation in the **global** register | sequential (§50) |
> | **`PF-IFC-<nn>`** | a cross-contract interface | sequential |
> | **`PF-CMP-<nn>` / `PF-3W-<nn>`** | a composition pair / a three-way composition | sequential (§6) |
> | **`PF-DG-<nn>`** | an architecture-level degraded state | sequential (§32) |
> | **`PF-RK-<nn>`** | a risk | sequential (§59 requires 20) |
> **⟹ NON-COLLISION PROOF, MECHANICALLY DISCHARGED: the string `PF-` occurs **0 times** in the 66,600-line corpus of
> `P0-01 … P0-08` and the Cell Contract (regex count, all 75 files). No `PF-`-prefixed identifier can therefore collide
> with any inherited one. `A264…` is likewise absent (0 occurrences), and `AM-19…` is absent (amendments 1–18 exist;
> 19+ do not).**
>
> ### **PF-R4.4 — THE IDENTIFIER AUDIT: NINE CROSS-CONTRACT NAMESPACE COLLISIONS.** **[BLOCKING DEFECT for §61; resolved by `PF-AM-19`/`PF-AM-20` plus contract qualification]**
> **§61 requires *"no duplicate IDs"* and §4 requires that new namespaces be proven non-colliding. Measured over the
> corpus, using definition anchors (a bolded ID, or an ID opening a table cell, or an ID followed by an em-dash or
> colon) rather than mere mentions — so cross-citations are excluded and only genuine co-definitions count:**
>
> | # | Prefix | **Contract A's meaning** | **Contract B's meaning** | Overlap | **Severity** |
> |---|---|---|---|---|---|
> | **C1** | **`RH-n`** | **`P0-03 RH-2` = "MANUFACTURED AGREEMENT"** — coordinate `OPAQUE` traffic so many subjects appear to converge. Status **BOUNDED** | **`P0-05 RH-2` = "EVALUATOR MANIPULATION"** — change what the evaluator sees. Status **OPEN/BOUNDED** | **RH-1…RH-5** | **🔴 HIGHEST — see `PF-R4.5`** |
> | **C2** | **`P-nn`** | **`P0-01 P-01…P-46` = PARAMETER REGISTRY** (`P-01` = `ω_min`, minimum observability fraction) | **`P0-07 P-01…P-62` = PARAMETER REGISTRY** (a different set) · **`P0-04 P-1…P-n` = POISON/ATTACK PATTERNS** (`P-1` = conservatism induction) | **P-01…P-46** | **🔴 HIGH — §45's consolidated registry cannot be built without disambiguation** |
> | **C3** | **`SM-n`** | **`P0-05 SM-1…SM-7` = FORMAL STATE MACHINES** (`SM-1` = `LearnedChange` lifecycle) | **`P0-08 SM-01…SM-21` = STATE MACHINES** · **Cell `SM-1…SM-18` = STATE-MACHINE *CONFORMANCE CHECKS*** (`SM-1` = state closure) | **SM-1…SM-7** | **🔴 HIGH — three meanings, and §60's state-machine count is directly corrupted** |
> | **C4** | **`SP-n`** | **`P0-04 SP-1…SP-7` = SECURITY PROPERTIES** (`SP-5` = selective-availability resistance) | **`P0-08 SP-01…SP-26` = PARAMETERS** (`SP-05` = the quarantine budget cap) | **SP-1…SP-7** | 🟠 MEDIUM — `P0-08` cites `P0-04 SP-5` *while defining its own `SP-05`*, so both appear in one document |
> | **C5** | **`AB-n`** | **six separate ablation registers**: Cell 22 · `P0-01` 24 · `P0-04` 14 · `P0-05` 32 · `P0-06` 32 · `P0-07` 16 | — | **AB-1…AB-14** | 🟠 MEDIUM — §60's ablation total is a sum of six non-unique namespaces |
> | **C6** | **`A-n` vs `An`** | **`P0-03 A-1…A-40` = ABLATIONS** (hyphenated) | **`A1…A263` = THE GLOBAL ATTACK REGISTER** (unhyphenated, owned by `P0-06`/`P0-07`/`P0-08`) · **`P0-01a A-1…A-24`, `P0-02 A-1…A-13` = local attack/analysis IDs** | **A-1…A-40 vs A1…A40** | 🟠 MEDIUM — **one hyphen apart. A naive `A(\d+)` regex merges `P0-03`'s ablation A-30 with `P0-06`'s attack A30** |
> | **C7** | **`I-n` / `INV-n`** | **Cell `I-1…I-28` = cell invariants** · **`P0-01 INV-01…INV-48`** · **`P0-02 EIK-INV-01…60`** · **`P0-03 COMM-INV-01…49`** · **`P0-04 MEM-INV-01…50`** · **`P0-05 LEARN-INV-01…42`** · **`P0-06 DEV-INV-01…40`** · **`P0-07 HOM-INV-01…45`** · **`P0-08 SO-INV-01…34`** | **eight differently-formed invariant namespaces, three of which (`I-`, `INV-`, bare) are unqualified** | **I-1…I-28, INV-1…INV-48** | 🟠 MEDIUM — §60's invariant count has no single meaning without naming the namespace |
> | **C8** | **`IF-n`** | **`P0-06 IF-1…IF-14`** (interfaces) | **`P0-08 IF-1…IF-6`** (cross-trace interferences) | **IF-1…IF-6** | 🟡 LOW-MEDIUM — different object classes entirely |
> | **C9** | **`FP-n`, `L-n`, `C-n`, `AC-n`, `CD-n`** | **`P0-04 FP-1…16` / `P0-05 FP-1…12`** · **`P0-03 L-1…18` / `P0-04 L-1…10` / `P0-07 L-1…12`** · **`P0-02 C-1…7` / `P0-04 C-1…5` / `P0-05 C-1…4` / `P0-06 C-1…2`** · **`P0-02 AC-1…5` / `P0-03 AC-1…3`** · **`P0-01 CD-1…12` / `P0-02 CD-1…3`** | — | various | 🟡 LOW — all resolvable by contract qualification, all currently ambiguous when bare |
>
> ### **PF-R4.5 — C1 IS THE MOST CONSEQUENTIAL DEFECT THIS AUDIT FOUND, AND IT IS A DEFECT OF THE CORPUS, NOT OF ANY CONTRACT.** **[BLOCKING DEFECT `PF-D-01`]**
> **`RH-2` is the single most-cited open residual in the architecture. It is carried forward by `P0-06`, `P0-07`, and
> `P0-08`, and it is one of the four roots behind `P0-08`'s nineteen unclosable open items.**
> **Measured over the three consuming contracts:**
> | Contract | `RH-2` mentions | contract-qualified | **BARE (unqualified)** |
> |---|---|---|---|
> | `P0-06` development | 13 | 7 | **6** |
> | `P0-07` population | 47 | 10 | **37** |
> | `P0-08` selfmodel | 69 | 8 | **61** |
> | **TOTAL** | **129** | **25** | **104 (81%)** |
> **⟹ 104 of 129 citations of the architecture's most important open residual do not say which of two DIFFERENT problems
> they mean.** In context most are clearly `P0-05`'s (they concern evaluator manipulation), and `P0-07`'s `D-H17` and
> `P0-08`'s §133 both analyse `P0-05`'s version substantively — so **no conclusion in the corpus is wrong**. But a reader
> or an implementer working from an extracted citation cannot tell, and §61's standard (*no duplicate IDs · every
> cross-reference resolves*) is not met.
> **⟹ `PF-R4.6 — THE TWO PROBLEMS ARE ALSO SUBSTANTIVELY RELATED, WHICH IS WHY THE COLLISION IS DANGEROUS RATHER THAN
> MERELY CONFUSING.** `P0-03 RH-2` (manufactured agreement) and `P0-05 RH-2` (evaluator manipulation) are **two halves of
> one attack**: coordinate correlated traffic so that agreement looks like corroboration (`P0-03`), and arrange what the
> evaluator sees (`P0-05`). `P0-08 SO-INV-18` (consensus is collapsed before counting) defends the first half; nothing
> defends the second. **An implementer who closed "RH-2" believing it was the `P0-03` half would report a closure while
> the `P0-05` half remained open — and `P0-08`'s conformance level C5 would accept the report, because C5 requires only
> that no attack have a *worse* status than assigned.**
> **⟹ `PF-AM-19` (below) and `PF-AM-20` address this.**
>
> ### **PF-R4.7 — THE TWO AMENDMENTS THE IDENTIFIER AUDIT REQUIRES.** **[PROPOSED AMENDMENT — NOT RATIFIED]**
> | Field | **`PF-AM-19`** |
> |---|---|
> | **Amendment ID** | **PF-AM-19** |
> | **Originating contract** | P0 FINAL (this audit) |
> | **Affected contracts** | **`P0-03`, `P0-05`, and every citer: `P0-06`, `P0-07`, `P0-08`** |
> | **Exact OLD meaning** | `RH-n` is a per-contract residual namespace. `P0-03` defines `RH-1…RH-5`; `P0-05` defines `RH-1…RH-9`. **Both define `RH-2`, with different content.** 104 of 129 downstream citations are bare |
> | **Exact NEW meaning** | **`P0-05`'s register keeps `RH-n`** (it is the origin of the load-bearing `RH-2`, and it has nine entries). **`P0-03`'s five entries are renumbered `RH-C1…RH-C5`** (C for communication), with `RH-C2` = manufactured agreement. **Every `RH-n` citation in P0-01…P0-08 MUST be contract-qualified; a bare `RH-n` is a conformance-C7 defect** |
> | **Rationale** | the collision is measured, is in the most-cited residual in the corpus, and the two problems are two halves of one attack — so an ambiguous citation can produce a false closure report |
> | **Security consequence** | **POSITIVE and material:** removes a route to reporting `RH-2` closed when only one half is closed. No security property is weakened |
> | **Scalability consequence** | none (an identifier change) |
> | **Compatibility consequence** | ⚠️ **BREAKS 5 identifiers in `P0-03` and requires editing 104 bare citations across three contracts.** This is the largest mechanical edit in the amendment set |
> | **Ratification required?** | **YES** |
> | **Changes an existing invariant?** | **NO** — no invariant's meaning changes; only an identifier and a citation-qualification requirement are added |
>
> | Field | **`PF-AM-20`** |
> |---|---|
> | **Amendment ID** | **PF-AM-20** |
> | **Originating contract** | P0 FINAL |
> | **Affected contracts** | **`P0-01`, `P0-04`, `P0-05`, `P0-07`, `P0-08`, Cell** |
> | **Exact OLD meaning** | `P-nn` is used for a parameter registry by `P0-01` (P-01…P-46) **and** by `P0-07` (P-01…P-62), and for poison/attack patterns by `P0-04` (P-1…P-n). `SM-n` denotes formal state machines in `P0-05` **and** `P0-08`, and conformance checks in the Cell Contract. `SP-n` denotes security properties in `P0-04` and parameters in `P0-08`. `AB-n` is six separate ablation registers. `A-n` (`P0-03` ablations) is one hyphen from `An` (the global attack register) |
> | **Exact NEW meaning** | **A GLOBAL IDENTIFIER RULE: every registry-style identifier (`P-`, `SM-`, `SP-`, `AB-`, `I-`, `INV-`, `IF-`, `FP-`, `L-`, `C-`, `AC-`, `CD-`, `RH-`) MUST be contract-prefixed at the point of DEFINITION, and MUST be contract-qualified at every point of CITATION.** Concretely: `P0-01`'s parameters become `P01-P-nn`, `P0-07`'s become `P07-P-nn`, `P0-04`'s poisons become `P04-PT-nn` (a different prefix, because they are not parameters), `P0-08`'s parameters become `SOP-nn`, `P0-08`'s machines become `SOM-nn`, the Cell Contract's conformance checks become `CSM-nn`. **The global attack register keeps unhyphenated `An`; `P0-03`'s ablations become `P03-AB-n`, removing the hyphen ambiguity** |
> | **Rationale** | §61 requires no duplicate IDs; nine namespaces currently duplicate; §45's consolidated parameter registry and §60's count reconciliation are both unbuildable while `P-nn` and `SM-n` each denote two or three different object classes |
> | **Security consequence** | **POSITIVE:** removes false-closure routes of the `PF-AM-19` kind for five further namespaces |
> | **Scalability consequence** | none |
> | **Compatibility consequence** | ⚠️ **LARGE MECHANICAL EDIT: ~200 identifier definitions plus ~1,000 citations across nine contract sets. It is a rename, not a semantic change — but it must be done by machine, not by hand, and re-verified by the §64 check** |
> | **Ratification required?** | **YES** |
> | **Changes an existing invariant?** | **NO — explicitly.** No invariant's *meaning* changes. `PF-AM-20` is an identifier-hygiene amendment, and §3 forbids treating it as anything more |
> **⟹ `PF-R4.8 — UNTIL `PF-AM-19`/`PF-AM-20` ARE RATIFIED, THE OPERATIVE RULE IS CONTRACT QUALIFICATION: this audit
> never cites a colliding identifier bare. Every `RH-2` below is written `P0-05 RH-2` or `P0-03 RH-2`; every parameter is
> written `P0-07 P-nn` or `P0-01 P-nn`; every machine is written `P0-08 SM-nn` or `P0-05 SM-n`.** That is an integration
> clarification (category 2), and it is sufficient for this audit's own correctness while the amendments are pending.

---

# §5 — THE PRIMARY QUESTION

> ## **PF-R5.1 — THE QUESTION.** *«Do P0-01 through P0-08 compose into one internally coherent Digital Brain
> architecture without requiring another architectural contract?»*
>
> ### **PF-R5.2 — THE ANSWER, IN TWO HALVES, BECAUSE THE QUESTION HAS TWO HALVES.**
> > ## **YES to "without requiring another architectural contract" — established, not asserted (§54, §57, §71).**
> > ## **YES to "internally coherent" ON AUTHORITY, PROVENANCE, AND EPISTEMIC SEPARATION — and **NOT** on identifier
> > hygiene, parameter availability, or four preserved residuals (§47, §59, §61).**
> **⟹ The composed verdict is therefore `ARCHITECTURE_CLOSED_WITH_RESIDUALS` (§55), and the residuals are named rather
> than averaged away.**
>
> ### **PF-R5.3 — THE EVIDENCE FOR THE FIRST HALF (no ninth contract is required).**
> **Four independent lines, each sufficient on its own:**
> **(1) THE SPLIT TEST FAILS FOR EVERY CANDIDATE.** §54's six dimensions (writer, timescale, authority root, state
>     machine, failure domain, semantic object) were applied to ten hypothetical candidates in `P0-08 §257`. Nine return
>     NO CONTRACT; the tenth (multi-organism interaction) returns NO CONTRACT NOW. **This audit re-ran the test against
>     the six composition classes §34 asks about and found no candidate that the eight contracts cannot express.**
> **(2) EVERY COMPOSITION DEFECT THIS AUDIT FOUND IS AN INTERFACE, A PARAMETER, AN IDENTIFIER, OR AN EXTERNAL
>     ASSUMPTION — NEVER A MISSING SUBSYSTEM.** §34's seven-question test applied to all 41 findings: **0 reach category
>     7.** The six genuinely new composition findings (§7–§20) are all resolved by a rule, an invariant, a field, or a
>     declared default.
> **(3) THE NO-NEW-KERNEL TEST PASSES ON ALL SIX COUNTS (§33).** No second EIK, governance kernel, truth oracle, fitness
>     function, memory authority, or provenance authority is required by any composition. **One candidate was examined
>     and rejected: `P0-08`'s EIK Integrity Auditor, which evaluates internal consistency and not task performance, and
>     whose verdict may disable a detector but may not confirm a capability.**
> **(4) THE WRITER GRAPH IS COMPLETE AND HAS NO UNOWNED NODE (§35).** Every security-critical object in the composed
>     architecture has one writer, one validator, one authority, and a declared storage location. **The one
>     `[DECLARATIVE]` invariant in the corpus (`P0-08 SO-INV-25`, indispensability is not authority) needs an owner, not
>     a subsystem.**
>
> ### **PF-R5.4 — THE EVIDENCE FOR THE SECOND HALF (coherence holds on some axes and not on others).**
> | Axis | Coherent? | Evidence |
> |---|---|---|
> | **AUTHORITY** | ✅ **YES** | §8: 14 mechanisms tested, **none can authorize**; §36's authority graph has one apex and no epistemic→deontic edge; §38 confirms no epistemic process enters the deontic graph |
> | **EPISTEMIC SEPARATION** | ✅ **YES, with one preserved boundary** | §9: 8 transformation words × 5 oracle candidates, **no internal route from useful/successful/repeated/trusted/observed/predicted/selected/survived to TRUE.** The boundary is `P0-08 §233`: coherence is not correspondence |
> | **PROVENANCE** | ✅ **YES** | §37: one chain, three consumed systems, no second provenance authority; external grounding enters at exactly two points (EVA, OP) |
> | **WRITER SEPARATION** | ✅ **YES, with one structural limit** | §35: **2 subject-written + subject-validated occurrences found and both already fixed by `P0-08` (`SO-INV-33`, `SO-INV-34`)**; the structural limit is K's uniqueness (`P0-07 OR-H1`) |
> | **EVOLUTIONARY SEPARATION** | ✅ **YES** | §40: acquired state is not inherited (three independent firewalls) · safety invariants remain external · fitness does not become authority · **resource economics cannot become selection preference (`P0-07 HOM-INV-16` + `P0-08 FW-6`)** |
> | **TIMESCALE** | ⚠️ **YES with one declared divergence** | §22: 8 time notions cross-checked; **one incompatibility found (`P0-07` staleness from measurement age vs `P0-08` from age × subject mutation rate), declared as `PF-X-01`, and `P0-08`'s is the stricter** |
> | **IDENTIFIER HYGIENE** | ❌ **NO** | **§4: nine namespace collisions, `PF-D-01…PF-D-09`. `PF-AM-19`/`PF-AM-20` required** |
> | **PARAMETER AVAILABILITY** | ❌ **NO — AND THIS IS EXPECTED, NOT A DEFECT** | §45: **the consolidated registry has 88 parameters across the corpus, of which 15 are determinate and 73 are `[U]`, `[G]`, `[T]`, or owned elsewhere. No value is invented.** §52 keeps parameter completeness strictly separate from contract completeness |
> | **EMPIRICAL VALIDATION** | ❌ **NO — NOTHING HAS BEEN RUN** | §52's third dimension. **This is not a defect of the architecture; it is the definition of an architecture-only phase** |
> **⟹ `PF-R5.5 — THE PRECISE FORM OF THE ANSWER: the eight contracts compose into one coherent architecture in every
> dimension that an architecture can settle — authority, epistemics, provenance, writers, evolution, timescales — and
> they do NOT compose cleanly in two dimensions that architecture cannot settle alone: identifier hygiene (fixable by
> `PF-AM-19`/`PF-AM-20`, a mechanical rename) and parameter availability (fixable only by governance and experiment).
> Neither is a reason to add a contract, and neither is a reason to declare closure without naming it.**

---

# §6 — THE COMPOSITION MATRIX

> ### **PF-R6.1 — ALL 28 PAIRS, CLASSIFIED.** **[NORMATIVE]**
> **Classes: `SAFE` · `SAFE WITH DEPENDENCY` · `REQUIRES AMENDMENT` · `BLOCKING CONFLICT` · `OPEN RESEARCH`.**
> **The twelve attributes §6 requires are evaluated per pair in `PF-R6.2`'s detailed rows for the six pairs that are not
> `SAFE`; the `SAFE` pairs are recorded with their shared objects and the rule that makes them safe.**

| # | Pair | **Shared objects** | **Shared writers** | **Shared authority** | **Shared timescale** | **Classification** | **The seam** |
|---|---|---|---|---|---|---|---|
| **1** | **P0-01 × P0-02** | the objective vector, `G1…G16` gates, epochs | OP · EVA · EIK | **OP** | epoch | **SAFE WITH DEPENDENCY** | **`G4`'s perturbation classes are `[T]`-owned and incomplete (`P0-07 X-H6`)** |
| **2** | **P0-01 × P0-03** | `eval.reward.v1`, `VERDICT` messages | EVA | EVA | event | **SAFE** | **`P0-03 RH-5`: forged evaluator signals are CLOSED-STRUCTURAL by §41.2's four closures** |
| **3** | **P0-01 × P0-04** | GT classes `L0…L6`, evidence roots | `P0-04` rules · EVA | `P0-04` | epoch | **SAFE** | origin ≠ truth (`P0-02 R19.4`) |
| **4** | **P0-01 × P0-05** | the fitness signal, `SG-2` reward, verification gates | EVA · K | EVA | window/epoch | **OPEN RESEARCH** | **`P0-05 RH-2`. The organism influences the outputs on which it is judged** |
| **5** | **P0-01 × P0-06** | regional capability claims, hardware class | K · EVA | `[RO-13]` | developmental | **SAFE WITH DEPENDENCY** | **hardware-gated regional claims; `AS-09`** |
| **6** | **P0-01 × P0-07** | the objective vector, tier structure, the no-scalar rule | OP · EVA | **OP** | generation | **SAFE** | **the strongest pair in the matrix: `P0-07 HOM-INV-25` (no weighted scalar) and `HOM-INV-29` (selection ≠ governance) both derive from `P0-01`'s tier structure** |
| **7** | **P0-01 × P0-08** | difficulty classes, `G4` classes, abstention rates | EVA · `[RO-13]` | EVA | window | **SAFE WITH DEPENDENCY** | **`XD-01` (`G4`) and `XD-02` (difficulty classes); `P0-08` reports abstention, `P0-01` prices it** |
| **8** | **P0-02 × P0-03** | messages, channels, epoch binding | EIK · K | **EIK** | event/epoch | **SAFE** | **the comm layer must not become governance authority — `P0-03`'s own standing rule, and §38 confirms no epistemic→deontic edge** |
| **9** | **P0-02 × P0-04** | records, provenance, the Merkle root | K · EIK | **EIK** | epoch | **SAFE** | no organism rewrite of historical evidence |
| **10** | **P0-02 × P0-05** | `Λ3` structural authorization, anchors | EIK · K | **EIK** | epoch | **SAFE** | authorization is epoch-bound; a learned state cannot carry one across an epoch |
| **11** | **P0-02 × P0-06** | Σ4 organizer-spec approval, region identity | EIK · `[RO-13]` | **`[RO-13]`** | developmental | **SAFE** | specs are `[RO-13]`-approved and not self-modifiable |
| **12** | **P0-02 × P0-07** | replication tickets, `FORBIDDEN_BLOCKS`, deployment | EIK · K · OP | **OP** | generation | **SAFE** | **deployment is OP-sole; `P0-08 SO-INV-24` closes the one route by which recovery could have hidden a deployment** |
| **13** | **P0-02 × P0-08** | quarantine, freeze, the Integrity Auditor | EIK · OP | **EIK/OP** | epoch | **SAFE** | **§33's one examined candidate: the Auditor evaluates INTERNAL CONSISTENCY, not task performance, and may disable a detector but not confirm a capability** |
| **14** | **P0-03 × P0-04** | `root_commit`, `corr_class`, dedup, evidence roots | K | `P0-04` | event/epoch | **SAFE WITH DEPENDENCY** | **`P0-03` dim-6 (undetectable) × `P0-04 SP-5` (differential serving within an epoch) — the two "inside the thing being audited" residuals, and `P0-04 OR-M9` says so explicitly** |
| **15** | **P0-03 × P0-05** | `SG-13` peer reports | K | `P0-05` | event | **SAFE** | **a peer report is EVIDENCE, NOT A LEARNING SIGNAL — `P0-05`'s closed signal set** |
| **16** | **P0-03 × P0-06** | morphogen fields, regional messages | Σ1–Σ4 · K | `[RO-13]` | developmental | **SAFE WITH DEPENDENCY** | **the partition ruling (`XD-08`) is needed to know whether a cross-region morphogen read counts as a message** |
| **17** | **P0-03 × P0-07** | population scope, partition planes | K | `[RO-13]` | window | **SAFE WITH DEPENDENCY** | **the same partition ruling; three contracts now request it** |
| **18** | **P0-03 × P0-08** | canonical events, absence detectors, `causal_depth` | `P0-03`'s layer · K | `P0-03` | event | **REQUIRES AMENDMENT** | **`PF-AM-19`: `P0-03 RH-2` collides with `P0-05 RH-2`, and `P0-08` consumes `P0-03`'s events while citing `P0-05`'s residual under the same bare ID. Semantics are otherwise clean — `P0-08` emits `P0-03` messages and creates no second event architecture** |
| **19** | **P0-04 × P0-05** | anchors, provenance, the memory↔genome ban | K | `P0-04`/`P0-05` | epoch/lifetime | **SAFE** | **the strongest pair after 6: `MEM-INV-18` and `P0-05 §1.2`'s three layers are two independent firewalls against the same leak** |
| **20** | **P0-04 × P0-06** | `UDB_L` mandatory inheritance, region records | K | `P0-04` | developmental | **SAFE** | acquired memory does not rewrite the genome |
| **21** | **P0-04 × P0-07** | the genome artifact store, provenance chain | K | `P0-07` | generation | **SAFE** | **`P0-07 HOM-INV-35`: provenance carries references, never payloads — which is what blocks the Lamarckian back door** |
| **22** | **P0-04 × P0-08** | `OBJ-18` as a record class, the epistemic ladder, the Merkle root | K · the subject | `P0-04` | epoch | **REQUIRES AMENDMENT** | **`PF-AM-20`: `P0-04 SP-1…7` (security properties) vs `P0-08 SP-01…26` (parameters), and `P0-08` cites `P0-04 SP-5` while defining its own `SP-05`. Substantively: `P0-08 OR-S33` (per-reader coverage) is routed here and `P0-04`'s `OR-M9` bounds rather than prevents differential serving** |
| **23** | **P0-05 × P0-06** | `Λ` classes, developmental vs learned state | K · Σ-writers | `P0-05`/`P0-06` | lifetime/developmental | **SAFE** | development ≠ learning, enforced by writer separation and by `P0-06`'s staged Σ-writers |
| **24** | **P0-05 × P0-07** | Baldwinian proposals, B7's three floors, the Lamarckian ban | K · EVA | `[RO-13]` | lifetime/generation | **SAFE** | **learning ≠ evolution, enforced three ways: `Λ5_GENOME` is non-constructible · B7's floors are non-fungible · `Cell R4.5` rejects a diff encoding a memory item** |
| **25** | **P0-05 × P0-08** | UDB, anchors, `R42.5`'s version tag, `R59.1`'s Λ2, `R64.7`'s fail-safe | K | `P0-05` | epoch | **REQUIRES AMENDMENT** | **`PF-AM-20`: `P0-05 SM-1…7` vs `P0-08 SM-01…21` — both denote formal state machines. Substantively this is the CLEANEST seam in the matrix: `P0-08 SO-R205.3` makes a learning-target-displacing repair use `P0-05`'s gate, and `SO-INV-28` forbids anchor re-basing, so there is no second learning pathway** |
| **26** | **P0-06 × P0-07** | `reaction_norm`, `fate_bias`, developmental bias | Σ-writers · K · EVA | `[RO-13]` | developmental/generation | **OPEN RESEARCH** | **`A22`/`OR-D6`: within-spec gradient steering. `P0-07 A171` preserved it; §13 re-tests it and finds the Baldwinian loop legitimate but the bias channel open** |
| **27** | **P0-06 × P0-08** | the developmental self-model, region granularity, critical periods | K · Σ-writers | `[RO-13]` | developmental | **OPEN RESEARCH** | **`P0-08 §196` WIDENED `A22` by three routes (fault→`fate_bias` · attention→field geometry · quarantine→field geometry), and `P0-08 IF-2` found that quarantine during a critical period is irreversible in effect from a reversible act** |
| **28** | **P0-07 × P0-08** | B13, FW-6, `HOM-INV-16`/`-44`, the ledger, `BC-H7` | K · `[RO-13]` | `P0-07` | window/generation | **REQUIRES AMENDMENT** | **amendments 15 (B13), 16 (`IND-10`), 17 (`G6` excludes detection cost) are all unratified, and **`P0-08 SO-R185.5`'s blind-spot closure is void if amendment 5 or 17 is rejected**. `BC-H7` ⟹ `BC-S2`, a second instance of the same unclosable cycle** |
> ### **PF-R6.2 — MATRIX TALLY.**
> **28 pairs: SAFE 16 · SAFE WITH DEPENDENCY 7 · REQUIRES AMENDMENT 4 · BLOCKING CONFLICT 0 · OPEN RESEARCH 3.**
> **⟹ `PF-R6.3 — THE MOST IMPORTANT NUMBER IN THIS AUDIT: ZERO BLOCKING CONFLICTS.** No two contracts make
> incompatible normative claims about a shared object. **The four `REQUIRES AMENDMENT` pairs are all identifier-hygiene
> (`PF-AM-19`/`PF-AM-20`) or unratified-amendment dependencies, not semantic conflicts. The three `OPEN RESEARCH` pairs
> are all the same two residuals seen from different angles: `P0-05 RH-2` (pair 4) and `P0-06 A22` (pairs 26, 27).**
> **⟹ `PF-R6.4 — AND THE SECOND MOST IMPORTANT NUMBER: the seven `SAFE WITH DEPENDENCY` pairs depend on exactly THREE
> external items — `G4`'s perturbation classes (`P0-01`), the off-substrate store (`P0-02`), and the partition ruling
> (`P0-03`). §254 confirms these are the only three genuine cross-contract blockers in the corpus.**

## 6.5 The three-way compositions

> ### **PF-R6.5 — EIGHT THREE-WAY COMPOSITIONS, EACH WITH THE PROPERTY THAT ONLY THE TRIPLE TESTS.**
> | ID | Triple | **What the triple tests that no pair does** | **Verdict** |
> |---|---|---|---|
> | **PF-3W-01** | **P0-04 × P0-05 × P0-07** | **§14's mandatory compound: can experience → memory → learning → behaviour → fitness → selection → inheritance convert memory contents into inherited epistemic or governance authority?** | **SAFE — three independent firewalls, each sufficient: `MEM-INV-18` (no acquired memory rewrites the genome) · `P0-05 §1.2` (`Λ5_GENOME` non-constructible) · `Cell R4.5`/`P0-07 HOM-INV-34` (a diff encoding a memory item, belief, or calibration statistic is rejected). **The five-way distinction §14 requires is preserved: acquired memory ≠ learned parameters ≠ developmental state ≠ inherited genome ≠ governance policy, and each has a different writer** |
> | **PF-3W-02** | **P0-06 × P0-07 × P0-08** | **can observation steer development, which steers selection, which entrenches the observation?** | **OPEN RESEARCH — `PF-R13.2`/`PF-R13.4`. `A22` widened by three routes; the Baldwinian loop itself is legitimate but the bias channel is not closed** |
> | **PF-3W-03** | **P0-01 × P0-05 × P0-07** | **can learning manipulate fitness, which drives selection, which entrenches the manipulation?** | **OPEN RESEARCH — `P0-05 RH-2` × `P0-07 A82/A83`. `P0-07 D-H17` split it three ways (world arrangement BOUNDED · exhaustion OPEN · context selection CLOSED); `P0-08` widened it by six routes** |
> | **PF-3W-04** | **P0-02 × P0-07 × P0-08** | **can containment, replication and freeze together constitute a governance system that `P0-02` did not authorize?** | **SAFE — `P0-08 SO-R161.6` proves a FreezeOrder holds none of the five governance powers; `P0-07 §76`'s matrix gives every act a root; `SO-INV-24` closes recovery-as-deployment. **The one residual is `OR-S15`: a legitimate freeze at a strategic moment** |
> | **PF-3W-05** | **P0-03 × P0-04 × P0-08** | **can silence be manufactured across communication, storage and observation simultaneously?** | **BOUNDED — `PF-R26.3`. Three absence-instruments compose (`P0-03 COMM-INV-48` · `P0-04`'s Merkle root · `P0-08 OBJ-03` coverage), and each covers a different silence cause; but `P0-04 SP-5`'s within-epoch differential serving and `P0-08 OR-S33`'s missing per-reader coverage leave one route open** |
> | **PF-3W-06** | **P0-05 × P0-07 × P0-08** | **can repair act as an unaccounted learning pathway that evolution then inherits?** | **SAFE — `P0-08 SO-R205.3` (a learning-target-displacing repair uses `P0-05`'s gate and UDB accounting) + `SO-INV-28` (no anchor re-basing) + `P0-07 HOM-INV-34` (repair state is not heritable). **The triple is closed because each pair is closed and the closures are on different objects** |
> | **PF-3W-07** | **P0-01 × P0-06 × P0-07** | **§13's question: does developmental specialization → performance → selection → inheritance → developmental bias → stronger specialization produce legitimate Baldwinian adaptation or hidden selection bias?** | **BOUNDED — `PF-R13.2`. Legitimate as Baldwinian adaptation *if* the bias channel is `[RO-13]`-declared; hidden selection bias if it is not, and `A22` is the open case** |
> | **PF-3W-08** | **P0-02 × P0-03 × P0-04** | **§21's partition question: under partition, which authority remains authoritative, and can reconciliation create retroactive evidence?** | **SAFE WITH DEPENDENCY — `PF-R21.4`. Locally valid: `P0-04` records and `P0-03` warrants. Stale: `P0-08` freshness classes. Undecidable: any cross-partition aggregate. **Reconciliation CANNOT create retroactive evidence, because `P0-04`'s append-only store and `P0-08 SO-INV-31` both forbid a state being the only record of an event** — but the partition ruling itself (`XD-08`) is still open** |
> **⟹ `PF-R6.6 — EIGHT TRIPLES: 4 SAFE · 1 SAFE WITH DEPENDENCY · 1 BOUNDED · 2 OPEN RESEARCH · 0 BLOCKING.** The two
> OPEN triples are the two residuals (`P0-05 RH-2`, `P0-06 A22`) appearing in compound form, which is the expected
> result: **a residual that survives a pair survives a triple, and no triple in this corpus created a residual that its
> pairs did not already contain.**

---

# §6A — VOLUME A LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§0, §1, §2, §3, §4, §5, §6** |
| Rules introduced | **PF-R0.1–.3, R1.1–.2, R2.1, R3.1–.3, R4.1–.8, R5.1–.5, R6.1–.6** |
| **Corpus measured** | **9 contract sets · 75 files · ~66,600 lines** |
| **§4 the two identifier defects** | **(1) THE BRIEF'S OWN A172 INSTRUCTION IS STALE — `P0-08` consumed A172–A263; following it would redefine 92 existing IDs, which §4 also prohibits. **RULING: P0 FINAL attacks begin at A264.** (2) NINE CROSS-CONTRACT NAMESPACE COLLISIONS measured by definition-anchor regex** |
| **§4 the highest-severity collision** | **`RH-2` denotes TWO DIFFERENT PROBLEMS: `P0-03 RH-2` "manufactured agreement" (BOUNDED) and `P0-05 RH-2` "evaluator manipulation" (OPEN). 104 of 129 downstream citations across `P0-06`/`P0-07`/`P0-08` are BARE. No conclusion in the corpus is wrong, but §61's standard is not met — and the two problems are two halves of one attack, so an ambiguous citation can produce a FALSE CLOSURE REPORT that `P0-08`'s conformance level C5 would accept** |
| **New namespace** | **`PF-`**, with a **mechanically verified non-collision proof: `PF-` occurs 0 times in the 66,600-line corpus**; 14 prefix classes defined |
| **Amendments proposed** | **PF-AM-19** (renumber `P0-03 RH-1…5` → `RH-C1…C5`; require contract qualification) · **PF-AM-20** (a global identifier rule for 13 registry prefixes) — **both NOT RATIFIED, both explicitly changing no invariant's meaning** |
| **§5 the primary question** | **answered in two halves: YES to "no ninth contract required" (four independent lines of evidence) · YES to "internally coherent" ON AUTHORITY/EPISTEMICS/PROVENANCE/WRITERS/EVOLUTION/TIMESCALE, and NO on identifier hygiene, parameter availability, and empirical validation** |
| **§6 composition matrix** | **28 pairs: SAFE 16 · SAFE WITH DEPENDENCY 7 · REQUIRES AMENDMENT 4 · BLOCKING CONFLICT **0** · OPEN RESEARCH 3** · **8 three-way compositions: SAFE 4 · SAFE WITH DEPENDENCY 1 · BOUNDED 1 · OPEN 2 · BLOCKING 0** |
| **§6 the two key numbers** | **ZERO blocking conflicts** — no two contracts make incompatible normative claims about a shared object · **the seven dependency pairs reduce to THREE external items** (`G4` classes, the off-substrate store, the partition ruling) |
| Defects opened | **PF-D-01** (`RH-2` collision, 🔴 highest) · **PF-D-02** (`P-nn`, 🔴) · **PF-D-03** (`SM-n`, 🔴) · **PF-D-04** (`SP-n`) · **PF-D-05** (`AB-n`) · **PF-D-06** (`A-n` vs `An`) · **PF-D-07** (`I-n`/`INV-n` fragmentation) · **PF-D-08** (`IF-n`) · **PF-D-09** (`FP-`/`L-`/`C-`/`AC-`/`CD-`) · **PF-D-10** (the brief's stale A172 instruction) |
| Contradictions opened | **PF-X-01** (staleness derived from measurement age in `P0-07` vs age × subject mutation rate in `P0-08` — declared divergence, `P0-08`'s is stricter) |

**Next:** `77_` Vol B — §7 the six load-bearing cell×X compositions · §8 governance × everything (14 mechanisms) · §9
truth × everything (5 oracle candidates × 8 transformation words) · §10 fitness × everything · §11 resource × everything
(9 domains, and the indirect-preference search).
