# P0 FINAL — VOLUME E (§26–§30)
## Observability Composition, Coverage × Independence, Verification Economics, Scalability Composition, and Hardware Portability

---

# §26 — OBSERVABILITY COMPOSITION

> ### **PF-R26.1 — ATTACK ONE: CAN `P0-07` RESOURCE SCARCITY FORCE BETTER APPARENT FITNESS THROUGH LOWER OBSERVABILITY?**
> ```
>   resource scarcity → lower observability → lower detected fault rate → better apparent fitness
> ```
> | Step | **Live?** | Ruling |
> |---|---|---|
> | scarcity → lower observability | ⚠️ **BOUNDED** | **B13 is non-fungible, LAST-CUT, FIRST-RESTORED (`P0-07 HOM-INV-07`), and `P0-08 FW-6`/`SO-INV-15` gives a declared-necessary monitor a FLOOR.** Residual: the floor's SIZE is `[G]`, and a floor set too low is not internally detectable (`OR-S20`) |
> | lower observability → lower detected fault rate | ✅ **LIVE** | `SO-INV-01` makes this read as `UNMEASURED`, **not as healthy** — but `UNMEASURED` does not manufacture detections |
> | **lower fault rate → better apparent fitness** | ❌ **BROKEN, AND BROKEN TWICE** | **(1) `P0-08 SO-INV-23`: an error report may not enter fitness NEGATIVELY, so there is no fault-rate penalty to avoid. (2) `P0-07 HOM-R14.1`: observations enter feasibility and charge, never the objective. **Fault rate is not a fitness component at all**** |
> **⟹ `PF-R26.1` — THE BRIEF'S PATHWAY IS BROKEN AT ITS LAST STEP. But §11 found the variant that is live, and it is worth
> restating here because §26 asks about observability specifically:**
> **`lower observability → fewer QUARANTINES → less containment COST → better G6 → better fitness`.** That step is live and
> is closed only by `P0-08` amendment 17 (`G6` excludes detection and containment cost, charged to B10) — **UNRATIFIED**.
> `PF-RK-02`.
>
> ### **PF-R26.2 — THE OBSERVABILITY FINDING THIS AUDIT ADDS: BEING UNMEASURABLE PROTECTS AN INCUMBENT.** **[NEW]**
> **Trace the consequence of `UNMEASURED` through `P0-07`'s selection rather than through its fitness:**
> ```
>   a scope becomes UNMEASURED  →  its gates cannot be evaluated  →  PENDING
>        →  P0-07 HOM-INV-12: PENDING IS NOT FAIL  →  the candidate is NOT RANKED
>        →  P0-07 HOM-INV-41: an ABORTED round produces NO ranking change and NO incumbency advantage
>        →  ⟹ THE INCUMBENT KEEPS ITS SLOT
> ```
> **⟹ `PF-R26.2` — `HOM-INV-41` CORRECTLY REMOVES THE *REWARD* FOR BEING UNMEASURABLE, AND CANNOT REMOVE THE
> *PRESERVATION OF THE STATUS QUO*, WHICH IS AN ADVANTAGE TO WHOEVER HOLDS IT.**
> **The bias is precise and asymmetric: an unmeasurable CANDIDATE cannot win (it is not ranked, so it gains no slot), while
> an unmeasurable INCUMBENT cannot lose (its slot is not contested). **⟹ Scarcity does not create new winners; it protects
> existing ones from displacement.**
> | Property | Verdict |
> |---|---|
> | Is it a preference creation under `HOM-INV-16`? | ❌ **NO** — nothing is made PREFERABLE; an unranked candidate is neither preferred nor disqualified |
> | Is it detectable? | ✅ **YES** — `UNMEASURED` is a state, `PENDING` is a status, and an aborted round is recorded |
> | Is it bounded? | ⚠️ **YES, by two instruments:** `P0-07`'s **turnover bound** and **`HOM-R41.5`'s retirement-cap degraded mode**, plus **`RATE_CAP`/epoch** |
> | Classification | **BOUNDED — and the bound is a TURNOVER requirement, not a measurement. A population whose incumbents cannot be measured must still turn over, and turnover under `UNMEASURED` is a governance decision** |
> **⟹ `PF-R26.3 — THE COMPOSITIONAL POINT, AND IT IS THE KIND §1 EXISTS TO FIND: `P0-08`'s `SO-INV-01` (unobserved is not
> healthy) and `P0-07`'s `HOM-INV-12` (`PENDING` is not `FAIL`) are BOTH CORRECT, BOTH RESTRICTIVE, AND TOGETHER THEY
> PROTECT INCUMBENTS.** Each rule refuses to convert ignorance into a negative verdict — which is right — and the
> consequence of refusing is that ignorance also prevents a positive displacement. **Neither contract could have found
> this alone: `P0-08` does not model selection, and `P0-07` does not model observability.**
>
> ### **PF-R26.4 — ATTACK TWO: CAN MORE OBSERVERS SELECT AGAINST EPISTEMIC DIVERSITY?**
> ```
>   more observers → more contradiction → lower confidence → lower apparent fitness
> ```
> | Step | **Live?** | Ruling |
> |---|---|---|
> | more observers → more contradiction | ✅ **LIVE AND INTENDED** | contradictions are **carried, not resolved** (`P0-04`'s standing rule; `P0-08 SO-R142.1`). Detecting more disagreement is the point of having more observers |
> | **more contradiction → lower confidence** | ⚠️ **PARTIALLY** | an unresolved contradiction caps a claim's status in `P0-04`. **But `P0-08 SO-R181.3`: an abstention is not evidence of falsity, and `SO-R180.2` lists what MUST leave confidence unchanged** |
> | **lower confidence → lower apparent fitness** | ❌ **BROKEN** | **confidence is not a fitness input.** `P0-07 HOM-R14.1` (observations enter feasibility and charge, never the objective) · `P0-08 SO-INV-19` (confidence is not an input to any evidence-producing rule) · `P0-07 HOM-R24.2` (`Ê(·)` excluded from every gate) |
> **⟹ `PF-R26.5 — THE BRIEF'S LOOP IS CLOSED AT STEP THREE. The live version is the COST loop, which is `P0-08 §129`'s:
> `more observers → more B13 spend → less compute for cognition → worse performance → lower fitness` — and it is
> TERMINATED (not balanced) by the monitoring share ceiling, whose breach produces `DETECTOR-ABSENT` and is therefore
> visible.**
> **⟹ `PF-R26.6 — CAN EVOLUTION SELECT AGAINST OBSERVER DIVERSITY ITSELF? ❌ NO — CLOSED-STRUCTURAL.** Detector
> **existence, identity, threshold, criticality and budget are `[RO-13]`'s** (`P0-08 OBJ-09`), and detector
> **implementation** evolves through E9 with all gates. **⟹ Evolution can change HOW a detector detects and cannot change
> HOW MANY detectors exist or WHAT they are required to detect.** A lineage cannot vote away its own observers, because
> observer count is a governance declaration rather than a phenotype.

---

# §27 — COVERAGE × INDEPENDENCE

> ### **PF-R27.1 — `P0-08 SO-R250.2`'S FINDING, PRESERVED VERBATIM.**
> > **«COVERAGE AND INDEPENDENCE COMPOSE IN OPPOSITE DIRECTIONS. Adding observers always improves coverage and may degrade
> > independence. An architecture that maximizes observer count maximizes coverage and can minimize evidence.»**
> **Coverage composes FAVOURABLY for `Q_pop`: a union of observed subsets is observed, and the blind spot shrinks to the
> intersection of the blind spots. Evidence composes UNFAVOURABLY: the same union may be one effective source.**
>
> ### **PF-R27.2 — DOES THE ARCHITECTURE DISTINGUISH §27'S SIX QUANTITIES? FIVE OF SIX YES, ONE NO.** **[NORMATIVE]**
> | Quantity | **Distinguished?** | By what | Owner |
> |---|---|---|---|
> | **observer count** | ✅ | `|S|`, trivially countable | `P0-08 OBJ-26` |
> | **evidence count** | ✅ | **`effective_sources(S, claim)`** = the number of equivalence classes under "shares a dimension the claim depends on" | **`P0-08 OBJ-26`, `SM-21`** |
> | **independent evidence** | ✅ | the same, **restricted to the NAMED dimensions** (`OBJ-25`, `P0-02 R35.1`) | `P0-02`/`P0-03`/`P0-08` |
> | **correlated evidence** | ✅ | **`|S| − effective_sources`** — computable, and `SO-R126.3(b)` states that a collapse to 1 is a **correct measurement, not a failure state** | `P0-08` |
> | **provenance diversity** | ✅ | the number of distinct `root_commit`s — `P0-03` dim 1, exact against the anchored registry | `P0-03` |
> | **CAUSAL diversity** | ❌ **NOT CURRENTLY** | **requires `IND-10`, which is `P0-08` amendment 16 — UNRATIFIED.** `P0-05 R15.8`'s `inbreeding_F` is the measure and it exists, but it is a learning-domain quantity and is not wired into `OBJ-25`'s dimension set | **`PF-R27.4` BELOW** |
>
> ### **PF-R27.3 — THE FOUR ADVERSARIAL CASES §27 REQUIRES.**
> | ID | Construction | **Coverage** | **Independence** | **Apparent consensus** | **Actual information gain** | Detected? |
> |---|---|---|---|---|---|---|
> | **AC-1** | **N observers, one genome, one hardware class** | **N× scopes** ✅ | **1** | **N-way agreement** | **1 unit** | ✅ **`OBJ-26` collapses on `IND-3`/`IND-5`; `P0-07 HOM-INV-17`'s `Ne(clones)=1` in the epistemic domain** |
> | **AC-2** | **N observers, DISTINCT implementations, ONE specification** | N× ✅ | **1 on `IND-6`** | N-way agreement | **1 unit** | ❌ **NOT DETECTABLE. `P0-03 R14.3`/`COMM-INV-18`: dimension 6 is not detectable from inside the system at all, and it is the dimension that defeats `n_eval ≥ 3`. `P0-02 §35.2`: two implementations by two teams from one specification correlate in ways neither can report** |
> | **AC-3** | **A → B → C, where each RE-ROOTS its output** | 3 scopes ✅ | **3 provenance roots, 1 causal source** | 3-way agreement | **1 unit** | ⚠️ **PARTIALLY. `P0-03 R14.1`'s own finding: *root-equality deduplication catches copies; it does not catch common causes — and re-rooting is not an attack, it is what a legitimate transformation does.* `IND-10`/`inbreeding_F` is the measure and it is not wired in** |
> | **AC-4** | **N observers over DISJOINT scopes, sharing ONE store** | **complete** ✅ | **1 on the shared-store dimension** | N-way agreement | **N units of coverage, 1 unit of assurance** | ⚠️ **`P0-08 OR-S24`: a shared store that biases retrieval WITHOUT being the root is not covered by `P0-03` dim 1** |
> **⟹ `PF-R27.4 — THE RESULT: FOUR ADVERSARIAL CASES, ONE FULLY DETECTED, ONE PARTIALLY, ONE PARTIALLY, ONE NOT AT ALL.**
> **And the three undetected-or-partially-detected cases share ONE ROOT: the architecture can count distinct PROVENANCE and
> cannot count distinct CAUSATION or distinct ASSUMPTIONS.**
> **`P0-03` identified this first and named it its most consequential defect (`X-C`, `R14.1`). `P0-08` proposed the measure
> (`IND-10`, amendment 16, using `P0-05`'s existing `inbreeding_F`). **Neither has been wired in, because neither has been
> ratified.** ⟹ `PF-RK-01` in §59's risk register: **the architecture's evidence-counting is exact on provenance and
> approximate-to-absent on causation and assumptions, and the two amendments that would improve it are pending.**
> **`[NON-CLAIM]` §27's instruction is honoured: this audit does NOT claim that observer diversity is verified. It claims
> that observer diversity is **countable on five of six dimensions, unratified on the sixth, and undetectable on `IND-6`
> by any internal means.**

---

# §28 — VERIFICATION ECONOMICS

> ### **PF-R28.1 — LOOP ONE: THE UNCERTAINTY LOOP.** **[CLASSIFICATION: CONTROLLED]**
> ```
>   more uncertainty → more verification → fewer resources → less computation → less verification → more uncertainty
> ```
> **⟹ IT TERMINATES IN A DEFINED, CLASSIFIED, VISIBLE STATE — A STALL — AND THAT IS WHY IT IS CONTROLLED RATHER THAN
> BOUNDED:**
> | Stage | Mechanism |
> |---|---|
> | more verification demand | anchors require held-out probes (`P0-05 R0.1`); repair and recovery require non-repairer verification (`P0-08 SO-R164.2`) |
> | fewer resources | **B9 is a FLOOR, non-fungible, LAST-CUT** (`P0-07 HOM-INV-07`) — so verification is the last thing reduced |
> | less verification | when B9 is exhausted, probes stop |
> | **⟹ TERMINATION** | **`P0-05 R0.1`: UDB exhausts and learning STALLS at that scope and below. `R48.4`: `stall_reason` distinguishes `PROBE_BUDGET_EXHAUSTED` · `UDB_EXHAUSTED_SC1_HEAVY` · `UDB_EXHAUSTED_SC3_HEAVY` — three stalls, three causes, three governance responses, one mechanism** |
> **⟹ `PF-R28.2 — `P0-05`'s own summary states why this is the right shape: *«a system that cannot afford probes learns
> less, visibly and by construction.»* The loop does not oscillate; it converges to a stall with a classified reason and an
> escalation path. NO NUMERICAL THRESHOLD IS INVOLVED AND NONE IS INVENTED.**
>
> ### **PF-R28.3 — LOOP TWO: THE OBSERVER LOOP.** **[CLASSIFICATION: BOUNDED — AND THE BOUND IS AN UNCLOSABLE CYCLE]**
> ```
>   more observers → more reports → more verification (refutation) → more cost → fewer observers → less detected failure
> ```
> | Stage | Ruling |
> |---|---|
> | more observers → more reports | ✅ correct and intended |
> | **more reports → more verification** | ⚠️ **ONLY DISPUTED REPORTS REQUIRE REFUTATION.** `P0-08 SO-R184.3`: the false-positive budget counts **REFUTED** reports, never merely `UNCONFIRMED` ones — so an honest high-volume reporter does not consume refutation capacity |
> | more cost → fewer observers | ❌ **B13 is last-cut with a floor (`FW-6`)** — **observers are the last thing reduced** |
> | **⟹ THE LIVE VERSION** | **`more reports → more refutation demand → B9 scarcity → refutation capacity falls → `SO-R184.3`'s pricing STOPS BITING → dishonesty becomes unpriced`.** That is `P0-08 OR-S28`, and it is the local form of **`BC-S2`** |
> **⟹ `PF-R28.4 — CLASSIFICATION: BOUNDED, AND THE BOUND IS NOT A THRESHOLD BUT A CYCLE THAT RUNS THROUGH A HUMAN.**
> **`P0-08 BC-S2`:**
> ```
>   detector integrity requires REFUTATION of false reports  →  refutation requires an external instrument or EVA
>        →  which requires B9  →  B9 is funded by re-authorization  →  which requires demonstration
>        →  which requires selection  →  which requires safety verification  →  which requires DETECTION
> ```
> **This is `P0-07 BC-H7` with "safety verification" replaced by "detection" — the same cycle entered one step earlier, and
> unclosable for the same reason: **the loop runs through DEMONSTRATION, and demonstration requires the thing the loop
> funds.** `PF-R48.3` preserves it in the global cycle register.**
> **⟹ `PF-R28.5 — THE SUMMARY §28 ASKS FOR: two loops, one CONTROLLED (it terminates in a classified stall) and one
> BOUNDED (it terminates in a human). Neither is DANGEROUS in the sense of unbounded, and neither is CLOSED. No numerical
> threshold is invented for either, and `PF-R28.5` records why inventing one would be wrong: a threshold on verification
> spending would be a preference about how much truth-seeking the system may do, and that is `[RO-13]`'s declaration, not
> an architectural constant.**

---

# §29 — SCALABILITY COMPOSITION

> ### **PF-R29.1 — FIVE SCALES, AND WHAT THE COMPOSED ARCHITECTURE ACTUALLY IS AT EACH.** **[NORMATIVE]**
> | Scale | **What the architecture is** | **Binding constraint** | **Claim** |
> |---|---|---|---|
> | **10 cells** | **one envelope, all aggregates trivial, and the fixed overhead exceeds the workload** | **`PF-R29.2` BELOW** | **ARCHITECTURALLY VALID, OPERATIONALLY ABSURD — and §29 asks for plausibility, not efficiency** |
> | **10³** | one envelope; every mechanism operates as specified | none | ✅ |
> | **10⁶** | one envelope; **`P0-07`'s R3 regime** — the regime the corpus actually validated against | `Q_pop` per scope; `OBJ-26` per claim | ✅ |
> | **10⁹** | **A SET OF ENVELOPES.** `P0-02`'s KC replicas scale here; **`P0-03 RULE 5.4` rejected vector clocks precisely because Θ(N) bytes per message at N=10⁹ is a type error**; **`P0-07 §80`: NO GLOBAL AGGREGATE EXISTS ABOVE 10⁸** | per-envelope everything | ⚠️ **PER-ENVELOPE ONLY** |
> | **10¹²** | **A SET OF ENVELOPES WITH NO RELATIONSHIP BETWEEN THEM.** `P0-07 §80`'s R5 regime: **only the firewalls survive** | — | ❌ **NOT CLAIMED. NO 10¹² GUARANTEE EXISTS ANYWHERE IN THE CORPUS, AND THIS AUDIT DOES NOT CREATE ONE** |
>
> ### **PF-R29.2 — THE SMALL-SCALE FINDING: THE ARCHITECTURE HAS NO MINIMUM CONFIGURATION.** **[P1 IMPLEMENTATION CONCERN]**
> **At N=10 the corpus requires: 28 `P0-08` objects · 21 state machines · 34 invariants · per-scope-per-window coverage
> records · per-claim `effective_sources` collapse · `P0-07`'s 13 homeostatic variables and 20 machines · `P0-05`'s UDB
> accounting · `P0-04`'s Merkle-rooted epochs.**
> **⟹ The FIXED overhead is not scale-invariant, and at N=10 it exceeds the workload. That is not an architectural defect
> — no invariant is violated and no authority is ambiguous — but it is a fact P1 must design against.**
> **⟹ `PF-R29.2`: **P1 MUST DEFINE A MINIMUM VIABLE CONFIGURATION: the subset of objects, machines, and invariants that
> preserves conformance levels C0+C1+C2+C3+C6+C7 at small N, and the subset that may be deferred.** Deferring an invariant
> is a semantic change and returns to architectural ratification (§57); deferring an OBJECT whose invariant is enforced
> elsewhere is not. **Category 7 — a P1 implementation concern, and the only one this audit raises.**
>
> ### **PF-R29.3 — THE TEN BOTTLENECK CLASSES §29 REQUIRES, SEARCHED.**
> | Class | **Present?** | Where, and with what scope |
> |---|---|---|
> | **asymptotic bottleneck** | ⚠️ **ONE** | **`P0-07 BC-H10`'s distance oracle** — phenotypic and functional diversity distances require a metric, and `PF-AM-24` would make four diversity kinds need one instead of two. **Scope: per envelope, per generation** |
> | **centralized dependency** | ⚠️ **THREE, ALL STRUCTURAL** | **K** — the single off-substrate writer for coverage, diagnosis status, observer-set collapse, serialization, rollback, allocation (`P0-07 OR-H1`, six appearances) · **EVA** — the sole external evaluator (`P0-05 RH-2`) · **OP** — the apex (`P0-02 G24`, UNSOLVABLE). **⟹ These are not bottlenecks to be removed; they are the architecture's grounding points, and §43 preserves all three** |
> | **global broadcast** | ❌ **NONE UNBOUNDED** | the workspace has **bounded slots with a single-writer arbiter** (`P0-08 SM-19`); a broadcast is a `P0-03` message with a bounded envelope |
> | **global scan** | ❌ **NONE** | **coverage is `O(scopes × windows)`, NOT `O(N)` — scopes are `[RO-13]`-declared, so their count is a governance choice.** `effective_sources` is **per claim**, `O(|S|² × dims)`, and `|S|` is small by construction (`Cell §18.5(iv)` asks for two) |
> | **global state** | ❌ **NONE ABOVE 10⁸** | **`P0-07 §80`: no global aggregate exists above 10⁸, and `P0-08 SO-R138.2` PROHIBITS a complete organism-wide self-model at every cell** (`O(N²)` total; `P0-03 RULE 5.4`'s type-error argument applies) |
> | **verification explosion** | ⚠️ **BOUNDED BY GOVERNANCE, NOT BY SCALE** | **`PF-R29.4` BELOW — the best result in this section** |
> | **provenance explosion** | ❌ **BOUNDED** | append-only, **references never payloads** (`P0-07 HOM-INV-35`/`D-H16`) ⟹ `O(events)`, and events scale with detections, not with `N` |
> | **memory explosion** | ⚠️ **ONE GAP** | `P0-04`'s archive compaction is OP-authorized (`P0-07 HOM-R51.4`); **`PF-D-13`: WITHIN-ARCHIVE EVICTION UNDER MEMORY PRESSURE IS SPECIFIED BY NO CONTRACT** ⟹ `PF-AM-22` |
> | **observer explosion** | ❌ **NONE** | `OBJ-26`'s collapse is **per claim**, never global. **A global collapse would be `O(N²)` and is NOT performed** (`P0-08 SO-R245.8`) |
> | **synchronization explosion** | ❌ **NONE** | **no global sync is required anywhere: `P0-03` rejects it explicitly, `P0-07 HP-2` provides a per-envelope monotone source, and `P0-08 SO-R142.3`'s consistency model is ANCHOR-CONSISTENT, not eventually consistent — it names a witness, an age, and an authority, and promises no convergence** |
>
> ### **PF-R29.4 — VERIFICATION DEMAND GROWS WITH THE NUMBER OF SCOPES, NOT WITH `N`. AND SCOPES ARE A GOVERNANCE CHOICE.** **[THE SECTION'S BEST RESULT]**
> **Verification is required per: anchor re-establishment (`P0-05`, per SCOPE `S`) · `CAUSE-VERIFIED` promotion (`P0-08`,
> per INCIDENT) · capability confirmation (`P0-08`, per RECORD) · repair verification (per REPAIR) · recovery verification
> (per PLAN) · detector capability evaluation (per DETECTOR).**
> **⟹ NONE OF THESE IS PER-CELL.** Scopes, detectors, and recovery plans are all `[RO-13]`-declared objects, and incidents
> and repairs scale with fault rate rather than with population.
> **⟹ `PF-R29.4`: THE VERIFICATION EXPLOSION IS BOUNDED BY A GOVERNANCE DECISION RATHER THAN BY AN ARCHITECTURAL ONE, AND
> THAT IS THE CORRECT PLACEMENT.** A governance body that declares 10⁵ scopes creates 10⁵ verification obligations; one
> that declares 10³ creates 10³. **The architecture does not force the choice, and it does not hide the cost — `P0-05`'s
> probe budget and `P0-07`'s B9 make it visible as a stall.**
>
> ### **PF-R29.5 — EVERY COMPLEXITY CLAIM IN THE CORPUS, WITH ITS SCOPE STATED.** **[§29's requirement: *every claimed
> O(1), O(log N), O(k) must have a stated scope*]**
> | Claim | Contract | **Scope** |
> |---|---|---|
> | `causal_depth` is `O(1)` bytes | `P0-03` | **per message, `u8` — and `PF-D-16`: saturation semantics unstated** |
> | coverage is `O(scopes × windows)` | `P0-08` | **per envelope, NOT `O(N)`** |
> | `effective_sources` collapse is `O(|S|² × dims)` | `P0-08` | **per claim, where `|S|` is the observer set for that claim** |
> | self-model aggregation is `O(depth × breadth)` | `P0-08` | **depth ≤ 4; breadth = scope membership** |
> | absence detectors are `O(R)` per epoch | `P0-03` | **per epoch; `P0-03 §84.2` calls this *"the highest value per unit cost in the contract"*** |
> | `PopulationState` is 14 fields, `O(1)` | `P0-07` | **per envelope; the computation over the population is K's and is not claimed to be `O(1)`** |
> | no `O(N²)` global learner | `P0-05` | **per scope; credit assignment is scope-local by construction** |
> | quarantine ladder is one transition per interval | Cell | **per subject** |
> **⟹ `PF-R29.6 — NO COMPLEXITY CLAIM IN THE CORPUS IS UNSCOPED, AND ONE IS OVERSTATED BY OMISSION: `P0-07`'s
> `PopulationState` is `O(1)` in SIZE and not `O(1)` in COMPUTATION. The corpus says the former and does not claim the
> latter, so this is a clarification rather than a defect — recorded because §29 requires every claim to carry its scope.**

---

# §30 — HARDWARE PORTABILITY

> ### **PF-R30.1 — THE EIGHT ASSUMPTIONS §30 NAMES, TESTED AGAINST THE COMPOSED ARCHITECTURE.** **[NORMATIVE]**
> | Assumed? | **Verdict** | Evidence |
> |---|---|---|
> | **one CPU** | ❌ **NOT ASSUMED** | no contract names an execution model; `P0-07 HP-3` records hardware-class heterogeneity as PARTIAL, not absent |
> | **shared memory** | ❌ **NOT ASSUMED — AND EXPLICITLY NOT REQUIRED** | `P0-07 HP-2`'s declaration list: **no shared memory**; `P0-08 SO-R245.9` repeats it |
> | **one clock** | ❌ **NOT ASSUMED** | **`P0-07 HP-2`: a per-envelope MONOTONE time source; NO global clock.** `P0-03 RULE 5.4` rejects Lamport, vector and hybrid-logical clocks |
> | **one address space** | ❌ **NOT ASSUMED** | `P0-07 HP-2`: no co-location requirement |
> | **one GPU** | ❌ **NOT ASSUMED** | **`P0-08 SO-R226.1`: no specific accelerator. And `P0-02 IND-1` REQUIRES distinct implementations, so naming a device class would defeat diverse replication** |
> | **one machine** | ❌ **NOT ASSUMED** | `P0-07 HP-2`: no global allocator |
> | **one network** | ⚠️ **PARTIALLY — AND THIS IS THE ONE REAL DEPENDENCY** | **`P0-03` assumes a message layer exists; `XD-08`'s partition ruling is open, so the architecture does not yet know whether a cross-region message during a partition is one message, two, or none** |
> | **one storage system** | ⚠️ **THE OPEN HANDOFF** | **`XD-04`: the off-substrate store is specified by `P0-02` and PROVIDED BY NOBODY — open since `P0-06`. `P0-08` added four more objects to it (`OBJ-03`, `OBJ-10`, `OBJ-14`, `OBJ-26`)** |
> **⟹ `PF-R30.2 — SIX OF EIGHT NOT ASSUMED; TWO ARE OPEN DEPENDENCIES RATHER THAN HIDDEN ASSUMPTIONS, AND BOTH ARE
> REGISTERED.** `P0-08 SO-R226.1` additionally rejects all seven implementation-specific assumptions §226 lists (language,
> framework, model family, database, accelerator, cloud provider, communication protocol), with **one declared near-miss:
> `causal_depth : u8` is retained because it is a SEMANTIC requirement — an unbounded width would be a vector clock by
> another name.**
>
> ### **PF-R30.3 — THE SEMANTIC / REALIZATION SEPARATION §30 REQUIRES.** **[DEFINITION]**
> | **SEMANTIC ARCHITECTURE** (fixed by P0; changing it returns to ratification) | **TRANSPORT / EXECUTION REALIZATION** (P1's and P3's freedom) |
> |---|---|
> | the 28 objects and their fields | how a field is encoded |
> | the 21 machines and their transition writers | how a transition is triggered |
> | the writer, authority, and timescale tables | how a writer is deployed (process, thread, service, enclave) |
> | the invariants and their enforcement KINDS | how an enforcement is implemented (a type, a check, a proof) |
> | **`causal_depth`'s width and saturation semantics** | **the counter's storage** |
> | **the requirement that a per-envelope monotone time source EXISTS** | **what provides it (a TSC, a logical clock, a sequencer)** |
> | **the requirement that the anchored store is OFF-SUBSTRATE and SINGLE-WRITER** | **what substrate it uses** |
> | **`IND-5` hardware-class diversity as a requirement for second detectors** | **which hardware classes** |
> | **`AS-08`: energy counters, or the `DERIVED` flag** | **how energy is measured** |
> | **`AS-09`: per-deployment-class setpoints** | **how a deployment class is detected** |
> **⟹ `PF-R30.4 — THE TEST THAT SEPARATES THE COLUMNS: a realization choice is P1's if every invariant, writer, authority
> root, and enforcement kind survives it unchanged. A choice that changes any of those is semantic and returns to
> ratification (§57).**
> **⚠️ THE ONE PLACE THE SEPARATION IS THIN, AND IT IS WORTH NAMING: `P0-07`'s amendment 13 (per-deployment-class
> setpoints) makes a SEMANTIC quantity — a homeostatic band — depend on a REALIZATION fact, namely which hardware the
> organism is running on. **That is not a leak; it is a necessary coupling, because `P0-07 HOM-R81.2` found that a single
> global setpoint table across heterogeneous hardware makes the architecture SELECT FOR HARDWARE, silently, with every
> metric on the fast device improving.** The coupling is declared (`AS-09`) rather than hidden, which is what §30 asks
> for.**

---

# §30A — VOLUME E LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§26, §27, §28, §29, §30** |
| Rules introduced | **PF-R26.1–.6, R27.1–.4, R28.1–.6, R29.1–.6, R30.1–.4** |
| **§26 observability** | **attack 1: the brief's pathway is BROKEN at its last step (fault rate is not a fitness component — `SO-INV-23` + `HOM-R14.1`), and the LIVE variant is the containment-cost step, closed only by UNRATIFIED amendment 17.** **attack 2: the brief's loop is CLOSED at step 3 (confidence is not a fitness input); the live version is `P0-08 §129`'s cost loop, TERMINATED by the monitoring share ceiling** |
| **§26 the new finding** | **`PF-R26.2` — BEING UNMEASURABLE PROTECTS AN INCUMBENT. `SO-INV-01` (unobserved ≠ healthy) and `HOM-INV-12` (`PENDING` ≠ `FAIL`) are BOTH CORRECT, BOTH RESTRICTIVE, AND TOGETHER THEY PREVENT DISPLACEMENT: an unmeasurable CANDIDATE cannot win and an unmeasurable INCUMBENT cannot lose. **Neither contract could have found this alone** — `P0-08` does not model selection and `P0-07` does not model observability. Classification: BOUNDED by the turnover requirement** |
| **§26 the structural closure** | **`PF-R26.6`: evolution CANNOT select against observer diversity, because detector EXISTENCE, identity, threshold, criticality and budget are `[RO-13]`'s — evolution can change HOW a detector detects and not HOW MANY exist. A lineage cannot vote away its own observers** |
| **§27 coverage × independence** | **`P0-08`'s opposite-directions finding preserved verbatim** · **6 quantities: 5 DISTINGUISHED, 1 NOT (causal diversity — requires `IND-10`, amendment 16, UNRATIFIED)** · **4 adversarial cases: 1 fully detected (AC-1 clones) · 2 partially (AC-3 re-rooting chains, AC-4 shared store) · 1 NOT AT ALL (AC-2 distinct implementations from one specification — `IND-6`, `P0-03 COMM-INV-18`)** |
| **§27 the root** | **`PF-R27.4` — THE ARCHITECTURE CAN COUNT DISTINCT PROVENANCE AND CANNOT COUNT DISTINCT CAUSATION OR DISTINCT ASSUMPTIONS. `P0-03` named this first as its most consequential defect (`X-C`, `R14.1`: *dedup catches copies, not common causes — and re-rooting is what a legitimate transformation does*); `P0-08` proposed the measure (`IND-10` via `P0-05`'s existing `inbreeding_F`); NEITHER IS WIRED IN BECAUSE NEITHER IS RATIFIED** ⟹ `PF-RK-01` |
| **§28 verification economics** | **2 loops: 1 CONTROLLED (the uncertainty loop TERMINATES in a classified stall — `P0-05 R0.1`/`R48.4`'s three `stall_reason`s) · 1 BOUNDED (the observer loop terminates in `BC-S2`, which is `P0-07 BC-H7` entered one step earlier through DETECTION instead of safety, and is unclosable because it runs through demonstration)** · **NO NUMERICAL THRESHOLD INVENTED, and `PF-R28.5` records why inventing one would be wrong: a threshold on verification spending is a preference about how much truth-seeking the system may do, which is `[RO-13]`'s** |
| **§29 scalability** | **5 scales characterized: 10 (valid but overhead-dominated) · 10³ ✅ · 10⁶ ✅ (`P0-07`'s R3) · 10⁹ ⚠️ PER-ENVELOPE ONLY (no global aggregate above 10⁸) · **10¹² ❌ NOT CLAIMED — no such guarantee exists anywhere in the corpus and this audit creates none**** |
| **§29 the ten bottleneck classes** | **1 asymptotic bottleneck (`P0-07 BC-H10`'s distance oracle, widened by `PF-AM-24`) · 3 STRUCTURAL centralized dependencies (K, EVA, OP — grounding points, not removable bottlenecks) · **0 unbounded global broadcasts · 0 global scans · 0 global state above 10⁸ · 0 observer explosion · 0 synchronization explosion** · 1 memory gap (`PF-D-13`) · verification explosion **BOUNDED BY GOVERNANCE, NOT BY SCALE** |
| **§29 the best result** | **`PF-R29.4` — VERIFICATION DEMAND GROWS WITH THE NUMBER OF SCOPES, NOT WITH `N`, AND SCOPES ARE A `[RO-13]` DECLARATION.** No verification obligation in the corpus is per-cell. **The architecture does not force the choice and does not hide the cost** |
| **§29 the complexity audit** | **8 claims, all scoped; ONE OVERSTATED BY OMISSION (`P0-07`'s `PopulationState` is `O(1)` in SIZE, not in COMPUTATION) — a clarification, not a defect** |
| **§29 the P1 concern** | **`PF-R29.2` — THE ARCHITECTURE HAS NO MINIMUM CONFIGURATION. At N=10 the fixed overhead exceeds the workload. **P1 MUST DEFINE A MINIMUM VIABLE CONFIGURATION preserving C0+C1+C2+C3+C6+C7; deferring an INVARIANT is a semantic change and returns to ratification, deferring an OBJECT whose invariant is enforced elsewhere is not.** The only category-7 item this audit raises** |
| **§30 hardware portability** | **8 assumptions: 6 ❌ NOT ASSUMED · 2 ⚠️ OPEN DEPENDENCIES (one network ⟹ `XD-08`'s partition ruling; one storage system ⟹ `XD-04`'s off-substrate store, open since `P0-06`)** · **all seven §226 implementation-specific assumptions rejected, with one declared near-miss (`causal_depth : u8`, retained because it is SEMANTIC)** |
| **§30 the separation** | **a 10-row semantic/realization table, with the test that separates the columns: *a realization choice is P1's if every invariant, writer, authority root, and enforcement kind survives it unchanged.* **The one thin place is named: `P0-07` amendment 13 makes a SEMANTIC band depend on a REALIZATION fact — a necessary coupling, because a single global setpoint table would make the architecture select for hardware silently, and it is DECLARED (`AS-09`) rather than hidden** |
| Defects opened | — *(none new in this volume; `PF-D-13` and `PF-D-16` are re-cited from Volumes B and D)* |
| New findings | **`PF-R26.2`** (unmeasurability protects incumbents) · **`PF-R27.4`** (provenance is countable, causation and assumptions are not) · **`PF-R29.2`** (no minimum configuration) · **`PF-R29.4`** (verification scales with scopes, not `N`) |
| Risks registered | **PF-RK-01** (evidence counting exact on provenance, approximate-to-absent on causation/assumptions; two amendments pending) · **PF-RK-02** (containment cost priced into `G6` until amendment 17) |

**Next:** `81_` Vol F — §31 twenty-or-more multi-stage failure cascades, each with the first contract boundary that should
stop it · §32 ten architecture-level degraded states · §33 the no-new-kernel test · §34 the no-new-subsystem test applied
to every finding in this audit.
