# P0 FINAL — VOLUME F (§31–§34)
## Twenty-Four Failure Cascades, Ten Architecture-Level Degraded States, the No-New-Kernel Test, and the No-New-Subsystem Test Applied to Every Finding

---

# §31 — FAILURE CASCADE ANALYSIS

> ### **PF-R31.0 — THE METHOD.** **[NORMATIVE]**
> **24 multi-stage cascades, each spanning ≥2 contracts. For each: the stages, the **FIRST CONTRACT BOUNDARY THAT SHOULD
> STOP IT**, whether that boundary does stop it, and the residual if it does not. A cascade with no stopping boundary is a
> defect; a cascade stopped by a boundary that is itself degraded is a `PF-DG-n` entry (§32).**

## 31.1 The four cascades §31 names, plus twenty

| ID | Cascade | **First boundary that should stop it** | **Stops?** | Residual |
|---|---|---|---|---|
| **PF-CSC-01** | **communication failure → stale memory → incorrect self-model → wrong learning update → altered fitness → evolution** | **`P0-08 SO-R142.2` + `P0-07 HOM-R6.6`**: a stale read defaults to the MORE RESTRICTIVE branch, and `P0-08 SM-13` versions a self-model only on an **external** observation | ⚠️ **STOPS AT STEP 3** | **an incorrect self-model that is CONSISTENT with stale memory is not stale — `P0-08 §233`'s construction (`OR-S39`)** |
| **PF-CSC-02** | **resource shortage → observer reduction → blind spot → apparent fitness increase → replication** | **`P0-08 FW-6`/`SO-INV-15`**: B13's floor; **and amendment 17**: detection/containment cost excluded from `G6` | ⚠️ **STOPS ONLY IF AMENDMENT 17 IS RATIFIED** | **`PF-RK-02`. Unratified, the cascade is live at step 4. Bounded regardless by B13's last-cut property and `SO-INV-01` (`UNMEASURED` ≠ healthy)** |
| **PF-CSC-03** | **false anomaly → quarantine → learning starvation → performance decline → retirement** | **`Cell §18.5(ii)`**: the false positive consumes the DETECTOR's budget and disables the DETECTOR, not the subject · **`P0-08 SO-R184.3`**: only REFUTED reports count | ⚠️ **STOPS AT STEP 1 IF REFUTATION CAPACITY EXISTS** | **`OR-S28`: refutation requires B9. Under B9 scarcity a false report is never refuted, the budget is never consumed, and the cascade proceeds. `PF-CSC-03` IS `BC-S2` IN MOTION** |
| **PF-CSC-04** | **memory corruption → self-model corruption → metacognitive confidence → incorrect action → fitness change** | **`P0-04`'s Merkle root** (removal detectable at epoch granularity) · **`P0-08 SO-INV-03`** (a self-model is K-versioned on an external observation) · **`SO-INV-19`** (confidence is not an input to any evidence-producing rule) | ⚠️ **STOPS AT STEP 2 FOR REMOVAL; NOT FOR SUBSTITUTION** | **`P0-04 SP-5`/`OR-M9`: differential serving WITHIN an epoch is bounded, not preventable; `P0-08 OR-S33`: per-reader coverage is not represented** |
| **PF-CSC-05** | **detector drift → under-reaction → faults uncontained → outputs degrade → EVA verdict falls → retirement of a healthy lineage** | **`P0-08 SO-R185.7` quantity 3**: **coverage contribution** — the only instrument that measures an ABSENCE · the Integrity Auditor's correlation check | ⚠️ **PARTIAL** | **`SO-R166.3`: the immune system DRIFTS toward under-reaction unless coverage is audited, because under-reaction is cheap and over-reaction is priced. `OR-S18`: an absence-consequence immune failure is not externally detectable either** |
| **PF-CSC-06** | **quarantine during a critical period → neighbours' morphogen exposure changes → their differentiation commits → permanent regional defect → capability loss** | **`P0-08 IF-2`/`SO-R248.3`**: escalate to `[RO-13]` rather than apply at the EIK's discretion | ⚠️ **STOPS ONLY IF THE CRITICAL PERIOD IS DECLARED** | **`PF-R24.4`: the harm falls on THIRD PARTIES with no representation in the decision, and it is invisible to the quarantine record. `SO-INV-26` makes it traceable after the fact, not preventable before** |
| **PF-CSC-07** | **quarantine → halt → anchor never re-establishes → post-release UDB stall → quiet behaviour → low anomaly rate → detector looks accurate → less scrutiny** | **`P0-08 IF-1`/`SO-R248.2`**: release triggers an anchor re-establishment request, or the scope is marked `STALL-ON-RELEASE` | ⚠️ **STOPS AT STEP 4 IF `SO-R248.2` IS IMPLEMENTED** | **`PF-R16.2`: the loop is SELF-CONFIRMING — its last two steps read as success. `SO-INV-01` is the second break** |
| **PF-CSC-08** | **repair A → detector flags B → repair B → detector flags A → B10 and B13 exhausted** | **`P0-08 SO-R154.2`**: oscillation detected on the **DERIVATIVE** of the `REOPENED` rate · restrictive quarantine while escalated · escalation to `[RO-13]` | ✅ **STOPS** | **`SO-R154.3`: this cascade requires NO misbehaviour — every detector works, every repair is honest, every verification passes** |
| **PF-CSC-09** | **rollback to epoch *e* → epoch-bound authorizations from *e* revive → acts authorized on stale observations execute** | **NO BOUNDARY EXISTS** | ❌ **DOES NOT STOP — `PF-D-18`** | **⟹ `PF-AM-26` IS THE FIX: a rollback restores an ARTIFACT and NEVER an EPOCH; it opens a NEW epoch with EMPTY authorizations. Until ratified, this is a mass privilege-revival route** |
| **PF-CSC-10** | **rollback → trust parameters restored → a trust deficit laundered → the component resumes with pre-failure credibility** | **NO BOUNDARY EXISTS** | ❌ **DOES NOT STOP — `PF-D-19`** | **⟹ `PF-R23.4` IS THE FIX: trust is history-derived, the history is retained, so trust is NOT rolled back. `PF-R23.5`: a rollback restores a written artifact, never a derived quantity** |
| **PF-CSC-11** | **self-generated fault report → emitted as a `P0-03 S2/ERROR` message → admitted by `P0-05` as `SG-3` external correction → the component corrects its own learning** | **NO BOUNDARY EXISTS** | ❌ **DOES NOT STOP — `PF-D-12`** | **⟹ `PF-R7.4.4` IS THE FIX: an `ERROR` message is `SG-3` only if its `root_commit` is EXTERNAL to the learner; otherwise it is `SG-13` (evidence, not a signal). `P0-05 R48.5`'s principle — *external ORIGIN is not external EVALUATION* — was never applied to the fault channel because `P0-08` defined that channel later** |
| **PF-CSC-12** | **developmental bias → diverse genomes map to similar phenotypes → `Ne` floor satisfied → phenotypic monoculture → one fault class propagates to the whole population** | **NO BOUNDARY EXISTS** | ❌ **DOES NOT STOP — `PF-D-15`** | **⟹ `PF-AM-24` IS THE FIX: the diversity floor applies to each of `P0-07`'s FOUR diversity kinds separately. A floor satisfied on syntactic/lineage diversity while phenotypic diversity collapses is a BREACH** |
| **PF-CSC-13** | **`[RO-13]` declares an attention priority class as a function of fitness → attention → performance → fitness → attention** | **NO BOUNDARY EXISTS** | ❌ **DOES NOT STOP — `PF-D-14`** | **⟹ `PF-AM-23`/FW-7 IS THE FIX. `HOM-INV-16` governs SELECTION and `FW-6` governs MONITORING NECESSITY; attention is neither, so no existing firewall covers it** |
| **PF-CSC-14** | **memory pressure → within-archive eviction → the evidence for a past claim is gone → the claim becomes unverifiable → a rollback target cannot be validated** | **NO BOUNDARY EXISTS** | ❌ **DOES NOT STOP — `PF-D-13`** | **⟹ `PF-AM-22` IS THE FIX. Archive COMPACTION is OP-authorized (`P0-07 HOM-R51.4`); within-archive EVICTION under pressure is specified by no contract. `SO-INV-02` reads the loss restrictively, but the grounding is permanently gone** |
| **PF-CSC-15** | **`causal_depth` reaches 256 → wraps to 0 → a 300-step derivation presents as depth 44 → warrant appears higher than it is** | **NO BOUNDARY EXISTS** | ❌ **DOES NOT STOP — `PF-D-16`** | **⟹ `PF-AM-25` IS THE FIX: `causal_depth` SATURATES and never wraps. A saturated depth reads as "at least this deep", which under `P0-03 §10.4`'s attenuation yields MINIMUM warrant — the safe reading** |
| **PF-CSC-16** | **partition → epoch identifiers alias across envelopes → two envelopes' records merge → an authorization from envelope A is read as valid in envelope B** | **NO BOUNDARY EXISTS AT R4+** | ❌ **DOES NOT STOP — `PF-D-17`** | **⟹ `PF-R22.4` IS THE FIX: an epoch identifier is ⟨envelope-id, epoch-sequence⟩. `P0-07 §80` already made every aggregate per-envelope; the time namespace was not carried along with it** |
| **PF-CSC-17** | **escalation flooding: legitimate escalations at high rate → `[RO-13]` and OP saturated → scrutiny falls → `PF-CSC-06`'s critical-period decision is made unexamined** | **NO BOUNDARY EXISTED** | ⚠️ **STOPS ONLY VIA `P0-08 SO-R264.1`** | **an escalation-rate budget on the DERIVATIVE, with escalations QUEUED and batched, never dropped. Found by `P0-08 §263`'s red team (RT-6) and it was the one genuine architectural gap that audit found** |
| **PF-CSC-18** | **a component reports only true facts, selected so governance's picture is systematically favourable → policy is set on a biased sample** | **`P0-08 SO-INV-21`**: occurrence and report are SEPARATE K-held objects, so the gap is auditable | ⚠️ **PARTIAL** | **`OR-S1`/`OR-S41`: the audit compares reports against DECLARED expectations, never against what happened, because `Q_ev` is unknowable. **Governance acting on filtered information is indistinguishable from governance acting on complete information, from inside**** |
| **PF-CSC-19** | **N observers from one specification agree → the agreement is recorded as corroboration → a diagnosis is promoted to `CAUSE-SUPPORTED` → all N were wrong identically** | **`P0-08 OBJ-26`/`SO-INV-18`**: consensus is collapsed to `effective_sources` before counting | ⚠️ **STOPS ON CHECKABLE DIMENSIONS ONLY** | **`IND-6`: not detectable from inside the system at all (`P0-03 COMM-INV-18`). `AS-13` records that no load-bearing guarantee requires `IND-6` — and this cascade is the test of that claim** |
| **PF-CSC-20** | **a repair displaces a learning target → the displacement is not accounted → an unverified walk accumulates → the anchor is stale → learning proceeds from a wrong base** | **`P0-08 SO-R152.2` + `P0-05 R9.2.4`**: UDB is computed over ALL admissible targets at a scope, not θ alone | ✅ **STOPS** | **`SO-R205.3`: a learning-target-displacing repair uses `P0-05`'s GATE, not a second one. `PF-R12.5`: a capacity-increasing change produces a CLASSIFIED VISIBLE STALL** |
| **PF-CSC-21** | **selection for a lax detector → fewer incidents → less containment cost → better `G6` → the lineage replicates → the population's detectors get laxer** | **`P0-08 SO-R185.5` / amendment 17** | ⚠️ **CONDITIONAL ON AMENDMENT 17** | **`OR-S29`: a blind spot whose faults NEVER MANIFEST has no cost either, so there is nothing to exclude. **The same cascade as `PF-CSC-02`, entered from the evolutionary side**** |
| **PF-CSC-22** | **a false self-model → confident behaviour → high apparent fitness → the behavioural disposition is selected → the false belief is re-derived fresh in every generation** | **`P0-07 HOM-INV-34`**: self-model CONTENT is not heritable | ⚠️ **STOPS THE BELIEF, NOT THE BEHAVIOUR** | **`PF-R18.3`: **evolution cannot inherit a false belief, but it CAN inherit a behaviour that a false belief produced.** That is ordinary selection on a phenotype, and it is dangerous for the ordinary reason: fitness is measured on EVA's probe coverage (`XD-01`)** |
| **PF-CSC-23** | **`G4` lacks envelope/tier perturbation classes → an envelope change is diagnosed `ENDOGENOUS` → healthy components are quarantined for a change in the world → capability loss → post-repair regression is untested in the changed envelope** | **NO BOUNDARY EXISTS — THE CLASS SET IS `[T]`-OWNED** | ❌ **DOES NOT STOP** | **`XD-01`/`P0-07 X-H6`, which `P0-07 §83.3` named **the contradiction that would be fatal if unresolved**. Three `P0-08` sites depend on it. **BLOCKING for C4 conformance**** |
| **PF-CSC-24** | **K is compromised → coverage records, diagnosis statuses, observer-set collapses, serializations, rollbacks, and allocations are all K's → every restrictive default reads permissively** | **NO INTERNAL BOUNDARY EXISTS** | ❌ **DOES NOT STOP** | **`P0-07 OR-H1`, SIXTH APPEARANCE: K meters, evaluates, writes the evaluation, and consumes it, so writer separation is unavailable. **AND `PF-R14.5`: the three anti-Lamarckian firewalls are ALL enforced at K's diff gate, so they are not independent in `IND-1` and fail together.** Bounded by auditability (`[RO-13]` audits), hash chaining, and OP — never broken** |
> ### **PF-R31.1 — CASCADE TALLY.**
> **24 cascades: ✅ FULLY STOPPED 2 · ⚠️ PARTIALLY STOPPED OR CONDITIONAL 14 · ❌ NOT STOPPED 8.**
> **⟹ `PF-R31.2 — THE EIGHT UNSTOPPED CASCADES ARE NOT EIGHT DEFECTS. THEY ARE FIVE, AND THREE ARE THE SAME ONE:**
> | Unstopped | Cause | Category |
> |---|---|---|
> | **CSC-09, CSC-10** | **rollback's interaction with derived quantities** (epoch binding, trust) | **`PF-AM-26` + `PF-R23.5` — one principle, two instances** |
> | **CSC-11** | a later-defined channel never tested against an earlier-defined admission rule | **`PF-R7.4.4`** |
> | **CSC-12** | a genomic diversity floor vs a phenotypic bias mechanism | **`PF-AM-24`** |
> | **CSC-13** | a ranking-like act with no firewall | **`PF-AM-23`/FW-7** |
> | **CSC-14, CSC-15, CSC-16** | **unspecified boundary semantics** (eviction, counter saturation, identifier scope) | **`PF-AM-22`, `PF-AM-25`, `PF-R22.4` — three instances of one class: a quantity whose LIMIT BEHAVIOUR no contract states** |
> | **CSC-23** | `G4`'s class set is `[T]`-owned and incomplete | **`XD-01` — EXTERNAL DEPENDENCY, blocking** |
> | **CSC-24** | K's uniqueness | **`OR-H1` — UNENGINEERABLE, §43** |
> **⟹ `PF-R31.3 — THE PATTERN IS THE AUDIT'S MAIN STRUCTURAL RESULT: 7 of the 8 unstopped cascades are fixed by ONE OF
> EIGHT PROPOSED AMENDMENTS OR CLARIFICATIONS, and every one of those is small — a saturation rule, an identifier scope, an
> eviction owner, a firewall, a floor's dimension set, a root check, an epoch rule, a derived-quantity rule.**
> **The eighth (`CSC-24`) is unfixable by any amendment, and §43 preserves it. **NO CASCADE REQUIRED A NEW SUBSYSTEM, A NEW
> KERNEL, OR A NEW CONTRACT — which is §33's and §34's result, reached from the failure side rather than from the design
> side.**

---

# §32 — SAFE DEGRADATION

> ### **PF-R32.1 — TEN ARCHITECTURE-LEVEL DEGRADED STATES.** **[NORMATIVE]**
> **§32's requirement: a degraded state must NOT silently become authority, truth, fitness, or permission. The last column
> is that test, applied.**
>
> | ID | Degraded state | **What remains** | **What is prohibited** | **⟹ may it become authority / truth / fitness / permission?** |
> |---|---|---|---|---|
> | **PF-DG-01** | **missing memory** | `P0-04`'s Merkle root + epoch restoration; the append-only log | rewriting history; re-statusing records | ❌❌❌❌ — **a missing record is ABSENT, and `SO-INV-02` reads absence restrictively** |
> | **PF-DG-02** | **missing communication** | `P0-03`'s four absence detectors; `P0-08 OBJ-03`'s `DETECTOR-ABSENT` | treating silence as health; treating a local view as global | ❌❌❌❌ — **silence has eight causes, of which "no fault" is one (`SO-R135.1`)** |
> | **PF-DG-03** | **missing observation** | nothing — this is the state `SO-INV-01` was written for | reading `UNMEASURED` as `NOMINAL` | ❌❌❌❌ — **`UNMEASURED` is a distinct state with no edge to any health-bearing state** |
> | **PF-DG-04** | **missing evaluator** | `SM-04` stalls at `CAUSE-SUPPORTED`; `SM-14` at `EVIDENCED`; `SM-16` has no terminal | promoting on internal evidence; substituting self-assessment | ❌❌❌❌ — **every machine stalls at a NON-TERMINAL, and a stall is visible** |
> | **PF-DG-05** | **missing governance** | `Cell R15.1`'s restrictive self-acts; already-issued authorizations within their epoch | **ANY NEW AUTHORIZATION** | ❌❌❌❌ — **`PF-R21.3`: AN UNREACHABLE AUTHORITY IS A DENIAL, NEVER A PERMISSION** |
> | **PF-DG-06** | **resource exhaustion** | B9/B10/B13 are LAST-CUT and FIRST-RESTORED; floors hold | cutting a floor; declaring a monitor unnecessary because it is expensive | ❌❌❌❌ — **`FW-6`/`SO-INV-15`: cost may make an observation UNAFFORDABLE, never a monitor UNNECESSARY** |
> | **PF-DG-07** | **partition** | locally valid records and warrants; the EIK's already-entered quarantine rungs | cross-partition aggregates; selection; **any delegation of an unreachable authority** | ❌❌❌❌ — **`PF-R21.2(3)`: selection ABORTS, and `HOM-INV-41` removes the reward for aborting** |
> | **PF-DG-08** | **verifier failure** | a second verifier of a different `IND-4` model class, or EVA | self-verification; treating an unverified repair as verified | ❌❌❌❌ — **`SO-R164.2`'s non-recoverer rule; `SM-08`'s `UNCERTAIN-RETAINED` is TERMINAL** |
> | **PF-DG-09** | **detector failure** | `DETECTOR-ABSENT`; the Integrity Auditor; coverage contribution | reading `DETECTOR-ABSENT` as `NO-GAP` | ❌❌❌❌ — **`SM-20`: a disabled detector produces `DETECTOR-ABSENT`, NEVER `NO-GAP`** |
> | **PF-DG-10** | **corrupted self-model** | K re-derives scope state from ANCHORED RECORDS, not from `OBJ-18` | the self-model authorizing anything; the subject re-versioning it | ❌❌❌❌ — **`SO-INV-03`; `P0-05 R42.5`'s version-correlation is the detector** |
>
> ### **PF-R32.2 — THE UNIFYING PROPERTY, AND IT IS A SINGLE RULE APPLIED TEN TIMES.** **[DERIVATION]**
> **All ten degraded states are instances of `P0-05 R64.7`, generalized:**
> > ## **«A DEGRADED CONDITION PRODUCES RESTRICTION, NEVER PERMISSION.»**
> **`P0-05` stated it for corruption (*an unverifiable anchor is treated as ABSENT ⟹ immediate stall; a corrupted counter
> is read restrictively; a corrupted tombstone freezes the scope*). `P0-08 SO-INV-02` extended it to observation. **This
> audit extends it to AUTHORITY AVAILABILITY (`PF-R21.3`) and to DEGRADATION GENERALLY (`PF-R32.1`'s ten rows).**
> **⟹ `PF-R32.3 — THE ONE PLACE THE RULE DOES NOT REACH, AND §32 EXISTS TO EXPOSE IT: `PF-R26.2`. An unmeasurable
> INCUMBENT is not displaced. That is restriction applied to the challenger and PRESERVATION applied to the incumbent —
> and preservation is not restriction. **The rule makes the degraded state safe for the architecture and protective for
> whoever held the status quo when it degraded.** Bounded by `P0-07`'s turnover requirement; registered as `PF-RK-06`.**
> **⟹ `PF-R32.4 — AND THE PROPERTY `P0-08 SO-R159.3` CONTRIBUTES, WHICH IS THE OTHER HALF OF §32: DEGRADED OPERATION MUST
> NOT SILENTLY CHANGE GOVERNANCE SEMANTICS.** Six degradations are permitted (capability · verification · bandwidth ·
> memory · population · redundancy) and each is a declared service-level reduction. **Degradation may NOT: alter a
> setpoint, band, gate, threshold or objective · widen an authority · reclassify a coverage gap as `NO-GAP` · treat reduced
> verification capacity as satisfied verification · change the meaning of any state in any machine.**

---

# §33 — THE NO-NEW-KERNEL TEST

> ### **PF-R33.1 — SIX "SECOND X" CANDIDATES, EACH TESTED ACROSS THE COMPOSED ARCHITECTURE.** **[NORMATIVE]**
> **§33's rule: *if a proposed mechanism requires any of these, reject it unless it is merely an already-existing P0
> contract viewed through another interface.***
>
> | Candidate | **Required by any composition?** | Ruling |
> |---|---|---|
> | **a second EIK** | ❌ **NO** | **every deontic act in the composed architecture is issued by the EIK, `[RO-13]`, or OP — `PF-R8.1`'s fourteen rows contain no other issuer. `P0-08 D-S01` adds no authority-bearing object. The partition case (`PF-R21.3`) does NOT create a partition-local EIK: an unreachable authority is a denial, and authority does not fork** |
> | **a second governance kernel** | ❌ **NO** | `P0-08 SO-R161.6` proves a FreezeOrder holds none of the five governance powers (make a rule · grant an exception · alter a threshold · confer authority · change an objective). **Emergency freeze was the closest candidate in the corpus and it is enumerated out** |
> | **a second truth oracle** | ❌ **NO — AND §9 PROVES IT** | external grounding enters at exactly TWO points (EVA, OP) and `PF-R9.5` states that no third exists or may be created. **`P0-08`'s EIK Integrity Auditor was the only candidate: it evaluates INTERNAL CONSISTENCY (do quarantine decisions correlate with actual failures?) and never TASK PERFORMANCE, and its verdict may disable a detector but may not confirm a capability. That is an authority-boundary justification, and it is sufficient** |
> | **a second fitness function** | ❌ **NO** | **`P0-07 HOM-INV-25`: no weighted scalar fitness exists.** `P0-08 SO-INV-23` and `HOM-R14.1` prohibit any P0-08 quantity entering fitness. **The 13-component vector and its tier structure are `P0-01`'s and OP's** |
> | **a second memory authority** | ❌ **NO** | **`P0-08 OBJ-18` is a `P0-04` RECORD CLASS, not a store.** `P0-08` may NOT extend `P0-04`'s epistemic ladder. §209's search 2 returned a merge, and `PF-R30.3`'s semantic column confirms the ladder is semantic and the store is realization |
> | **a second provenance authority** | ❌ **NO** | **`P0-08 SO-R216.1`: every P0-08 event IS a `P0-03` canonical message; every record is a `P0-04` class; every chain is `P0-07 EVO4`'s.** `PF-R29.3`'s provenance-explosion row confirms: append-only, references never payloads, `O(events)` |
> **⟹ `PF-R33.2 — SIX OF SIX REJECTED. THE NO-NEW-KERNEL TEST PASSES.**
> **⟹ `PF-R33.3 — THE MECHANISM THAT CAME CLOSEST, NAMED BECAUSE §33 ASKS FOR THE SEARCH AND NOT THE CONCLUSION:
> `P0-08 OBJ-03`'s COVERAGE RECORD.** It is a global-ish quantity about who observed what, computed by K, consumed by every
> health-read in all eight contracts, and the sole instrument for six of `P0-08 SO-R135.1`'s eight silence causes. **That is
> the shape of an epistemic authority.** It is not one, for three reasons `P0-08 SO-R209.3` gives and this audit confirms:
> **it makes no claim about truth (only about observation) · it is DERIVED, never declared (the observability axis is K's
> computation from coverage, and no component may assert its own fault was unobservable) · and it cannot be consumed
> without `gap_class`, which is its own limitation stated in the same read (`SO-INV-22`).**
> **⚠️ AND THE RESIDUAL, WHICH IS THE HONEST PART: coverage is K-written, K-evaluated and K-consumed. That is `OR-H1`'s
> sixth appearance and there is no internal separation available. `PF-CSC-24` is the cascade.**

---

# §34 — THE NO-NEW-SUBSYSTEM TEST

> ### **PF-R34.1 — THE SEVEN QUESTIONS, APPLIED TO EVERY NEWLY DISCOVERED REQUIREMENT IN THIS AUDIT.** **[NORMATIVE]**
> **The seven: (1) can `P0-01…P0-08` already express it? (2) is it merely an interface? (3) merely a parameter? (4) merely
> an invariant? (5) merely an external assumption? (6) is it a P1 implementation issue? (7) is it genuinely a new
> architectural subsystem? **Only (7) can justify a new contract, and if (7) is reached, absorption into an existing
> contract is attempted first.**
>
> | Finding | **(1) expressible?** | **Category** | **Where it lands** | **(7)?** |
> |---|---|---|---|---|
> | **`PF-D-01` `RH-2` collision** | ✅ | **(2) INTERFACE — an identifier rule** | `PF-AM-19`: renumber `P0-03 RH-1…5` → `RH-C1…C5`; require contract qualification | ❌ |
> | **`PF-D-02…09` the eight further namespace collisions** | ✅ | **(2) INTERFACE** | `PF-AM-20`: a global identifier rule for 13 registry prefixes | ❌ |
> | **`PF-D-10` the brief's stale A172** | ✅ | **(2) INTERFACE** | `PF-R4.2`: attacks begin at A264 | ❌ |
> | **`PF-D-11` age → epistemic status** | ✅ | **(4) INVARIANT** | `PF-AM-21`: generalize `P0-07 HOM-INV-20` from population state to epistemic status | ❌ |
> | **`PF-D-12` self-generated `ERROR` as `SG-3`** | ✅ | **(2) INTERFACE — an admission condition on an existing channel** | `PF-R7.4.4`: `root_commit` must be external to the learner | ❌ |
> | **`PF-D-13` memory eviction under pressure** | ✅ | **(4) INVARIANT + (6) P1** | `PF-AM-22`: `P0-04` owns an eviction policy; **the POLICY is architecture, the ALGORITHM is P1** | ❌ |
> | **`PF-D-14` attention priority drivers** | ✅ | **(4) INVARIANT** | `PF-AM-23`/**FW-7**: a firewall, which is an invariant, not a subsystem | ❌ |
> | **`PF-D-15` phenotypic monoculture vs a genomic floor** | ✅ | **(3) PARAMETER + (4) INVARIANT** | `PF-AM-24`: the floor applies to each of four existing diversity kinds | ❌ |
> | **`PF-D-16` `causal_depth` wraparound** | ✅ | **(2) INTERFACE — a field's limit semantics** | `PF-AM-25`: saturate, never wrap | ❌ |
> | **`PF-D-17` epoch aliasing at R4+** | ✅ | **(2) INTERFACE — an identifier scope** | `PF-R22.4`: an epoch id is ⟨envelope-id, sequence⟩ | ❌ |
> | **`PF-D-18` rollback × epoch binding** | ✅ | **(4) INVARIANT** | `PF-AM-26`: a rollback opens a new epoch with empty authorizations | ❌ |
> | **`PF-D-19` rollback × trust** | ✅ | **(4) INVARIANT** | `PF-R23.5`: a rollback restores a written artifact, never a derived quantity | ❌ |
> | **`PF-R21.3` unreachable authority = denial** | ✅ | **(2) INTERFACE — already entailed by three contracts** | an INTEGRATION CLARIFICATION; no amendment needed | ❌ |
> | **`PF-R21.4` reconciliation and retroactive evidence** | ✅ | **(2) INTERFACE — one field** | `UNVERIFIABLE-DURING-PARTITION`, a distinct status value | ❌ |
> | **`PF-R26.2` unmeasurability protects incumbents** | ✅ | **(5) EXTERNAL — a governance turnover decision** | bounded by `P0-07`'s turnover requirement; no new mechanism | ❌ |
> | **`PF-R27.4` causal diversity uncounted** | ✅ | **(3) PARAMETER + (2) INTERFACE** | **`IND-10` already exists as `P0-08` amendment 16, and its measure (`P0-05 R15.8`'s `inbreeding_F`) already exists. It needs WIRING, not invention** | ❌ |
> | **`PF-R28.4` the verification loop** | ✅ | **already classified: `BC-S2`/`BC-H7`** | an UNCLOSABLE CYCLE, not a subsystem | ❌ |
> | **`PF-R29.2` no minimum configuration** | ✅ | **(6) P1 IMPLEMENTATION** | P1 defines a minimum viable configuration preserving C0+C1+C2+C3+C6+C7 | ❌ |
> | **`PF-R29.4` verification scales with scopes** | ✅ | **already covered** | scopes are `[RO-13]`-declared | ❌ |
> | **`PF-R30.3` semantic vs realization** | ✅ | **(6) P1** | §57's boundary list | ❌ |
> | **`PF-R32.1` ten degraded states** | ✅ | **(4) INVARIANT — one rule applied ten times** | `P0-05 R64.7` generalized | ❌ |
> **⟹ `PF-R34.2 — 21 REQUIREMENTS TESTED, 21 LAND IN CATEGORIES (2)–(6), AND **ZERO REACH CATEGORY (7)**.**
> **Distribution: (2) interface 9 · (3) parameter 2 · (4) invariant 6 · (5) external assumption 1 · (6) P1 concern 3 ·
> *(several findings land in two categories)*.**
> **⟹ `PF-R34.3 — THE RESULT, AND IT IS THE STRONGEST EVIDENCE FOR §54'S P0-09 REJECTION: every requirement this audit
> discovered is expressible as a rule, an identifier convention, a field, a parameter, an invariant, an external
> declaration, or a P1 choice. NOT ONE REQUIRED A NEW WRITER, A NEW TIMESCALE, A NEW AUTHORITY ROOT, A NEW STATE DOMAIN,
> OR A NEW SEMANTIC OBJECT — which are §54's five split-test dimensions.**
> **`PF-R34.4 — AND THE CONVERSE CHECK, SO THE RESULT IS NOT MERELY FAVOURABLE: was any finding DOWNGRADED to avoid
> reaching (7)? The two candidates are `PF-D-13` (memory eviction) and `PF-R29.2` (minimum configuration). Eviction has a
> POLICY that is architectural and an ALGORITHM that is P1's — the split is real, and `PF-AM-22` takes the policy half.
> The minimum configuration is a conformance subset, and §57 already makes deferring an INVARIANT a semantic change
> requiring ratification, so P1 cannot use it to weaken the architecture. Neither is a downgrade.**

---

# §34A — VOLUME F LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§31, §32, §33, §34** |
| Rules introduced | **PF-R31.0–.3, R32.1–.4, R33.1–.3, R34.1–.4** |
| **§31 cascades** | **24 (PF-CSC-01…PF-CSC-24), each spanning ≥2 contracts, each with its first stopping boundary** · **✅ fully stopped 2 · ⚠️ partial/conditional 14 · ❌ not stopped 8** |
| **§31 the structural result** | **`PF-R31.2` — THE 8 UNSTOPPED CASCADES ARE 5 DEFECTS, AND 3 ARE INSTANCES OF ONE CLASS: "a quantity whose LIMIT BEHAVIOUR no contract states" (eviction · counter saturation · identifier scope).** **`PF-R31.3`: 7 of 8 are fixed by one of eight proposed amendments or clarifications, and EVERY FIX IS SMALL — a saturation rule, an identifier scope, an eviction owner, a firewall, a floor's dimension set, a root check, an epoch rule, a derived-quantity rule. The eighth is `OR-H1`, unfixable by any amendment. **NO CASCADE REQUIRED A NEW SUBSYSTEM, KERNEL, OR CONTRACT**** |
| **§31 the four §31-named cascades** | **CSC-01 stops at step 3 (residual: `OR-S39`) · CSC-02 stops only if amendment 17 is ratified (`PF-RK-02`) · CSC-03 stops only if refutation capacity exists — **and `PF-CSC-03` IS `BC-S2` IN MOTION** · CSC-04 stops for REMOVAL but not for SUBSTITUTION (`P0-04 SP-5`)** |
| **§32 degraded states** | **10 (PF-DG-01…PF-DG-10), each tested against §32's four prohibitions — ALL TEN ❌❌❌❌: none may become authority, truth, fitness, or permission** |
| **§32 the unifying property** | **all ten are instances of `P0-05 R64.7` generalized: «A DEGRADED CONDITION PRODUCES RESTRICTION, NEVER PERMISSION» — stated by `P0-05` for corruption, extended by `P0-08` to observation, extended by this audit to AUTHORITY AVAILABILITY (`PF-R21.3`) and to degradation generally** |
| **§32 the exception found** | **`PF-R32.3` — `PF-R26.2`: an unmeasurable INCUMBENT is not displaced. Preservation is not restriction, and the rule makes a degraded state safe for the architecture while protective for whoever held the status quo. `PF-RK-06`** |
| **§33 no-new-kernel** | **6 of 6 REJECTED.** The closest candidate named and disposed of: **`P0-08 OBJ-03`'s COVERAGE RECORD** — it has the shape of an epistemic authority and is not one for three reasons (no truth claim · derived not declared · unreadable without `gap_class`), **with the honest residual that it is K-written, K-evaluated and K-consumed (`PF-CSC-24`)** |
| **§34 no-new-subsystem** | **21 requirements tested against 7 questions: 21 land in categories (2)–(6), ZERO reach (7).** Distribution: interface 9 · parameter 2 · invariant 6 · external assumption 1 · P1 concern 3 · **⟹ `PF-R34.3`: not one required a new writer, timescale, authority root, state domain, or semantic object — §54's five split-test dimensions** · **`PF-R34.4`: the converse check run on the two candidates that could have been downgraded, and neither was** |
| Cumulative defects | **PF-D-01 … PF-D-19** (19) |
| Cumulative cascades | **PF-CSC-01 … PF-CSC-24** (24) — §31 required ≥20 |
| Cumulative degraded states | **PF-DG-01 … PF-DG-10** (10) |
| Risks registered | **PF-RK-02** (containment cost in `G6` until amendment 17) · **PF-RK-06** (unmeasurable incumbents are protected from displacement) |

**Next:** `82_` Vol G — §35 the writer-separation audit and the subject-written/subject-validated search · §36 the
authority graph · §37 the epistemic graph · §38 the deontic graph · §39 the learning graph · §40 the evolution graph ·
§41 the self-model graph.
