# P0 FINAL — VOLUME B (§7–§11)
## The Six Load-Bearing Cell Compositions, Governance × Everything, Truth × Everything, Fitness × Everything, and the Indirect-Preference Search

---

# §7 — THE LOAD-BEARING COMPOSITIONS

## 7.1 Cell × Governance

| Question | **Verdict** | The rule that decides it |
|---|---|---|
| **can cells acquire authority indirectly?** | ❌ **NO** | **`P0-07 §76`'s ∅-set denies all 16 authority cells to every substrate actor · `Cell R15.1`: a cell's only self-acts are RESTRICTIVE · `P0-08 D-S01`: the observation layer holds no authority · `PF-R8.1` below tests all 14 mechanisms** |
| **can cell performance create governance legitimacy?** | ❌ **NO** | **`P0-07 HOM-INV-29`**: a selection outcome confers nothing. Legitimacy is OP's and is not a function of any measured quantity |
| **can cell-generated evidence alter policy?** | ⚠️ **IT CAN INFORM POLICY; IT CANNOT ALTER IT** | evidence routes to `[RO-13]` as a **report** (`P0-08 SM-02`'s `SUPPRESSION-SUSPECTED`, `SM-20`'s `AUDIT-FINDING`). **No mechanism converts a report into a policy change. ⟹ The residual is `P0-08 OR-S41`: governance acting on filtered information is indistinguishable from governance acting on complete information** |
| **can mutable cell state influence EIK decisions improperly?** | ⚠️ **YES — AND IT IS ALREADY REGISTERED** | **the EIK's quarantine and gating decisions consume organism-reported quantities. `P0-07 OR-H15`: `G3`/`G7` are organism-measured, so misdirected quarantine (`P0-07 A147`) is BOUNDED, not closed.** `P0-02`'s epoch binding and `P0-08 SO-R144.2`'s two-read rule limit staleness, not falsity |
| **can replication create governance capture?** | ❌ **NO, but it creates something adjacent** | **`P0-07 HOM-INV-24`** (no cross-generation authority) · **`HOM-INV-42`** (deployment is OP-sole) · **`P0-08 SO-INV-24`** (recovery is not deployment). **⟹ The adjacent thing is `P0-07 OR-H13` / `P0-08 SO-INV-25`: replication creates PRACTICAL INDISPENSABILITY, which is not authority and has no instrument — `SO-INV-25` is the corpus's only `[DECLARATIVE]` invariant** |

## 7.2 Cell × Communication

| Question | **Verdict** | The rule that decides it |
|---|---|---|
| **can communication alter authority?** | ❌ **NO** | `P0-03`'s standing rule (the comm layer must not become governance authority) · `P0-08 SO-C22.2` (broadcast ≠ authority) · principle 38 |
| **can message frequency create legitimacy?** | ❌ **NO** | **`P0-03`'s root-equality deduplication** · **`P0-08 SO-INV-18`**: consensus is collapsed to `effective_sources` before it is counted · principle 5 |
| **can propagation create evidence?** | ❌ **NO** | **`P0-03 COMM-INV-08`**: warrant is monotone **NON-INCREASING** along derivation. Propagation can only lose warrant |
| **can network position create epistemic authority?** | ❌ **NO — but the closure is worth stating precisely** | a hub's messages reach more subscribers; **reach is not warrant** (`SO-R222.2`). A subscriber re-broadcasting is a **copy with the same `root_commit`**, and `P0-03 R14.1`'s root-equality dedup catches copies. **The residual is root-rewriting, which `P0-03`'s `X-C` closed via `COMM-INV-08`'s root-inheritance rule — and the deeper residual is that dedup catches copies but NOT common causes (`P0-03 R14.1`'s own finding)** |
| **can transport metadata become semantic authority?** | ❌ **NO** | **`P0-03 RULE 7.7`**: authenticity ≠ truth; `COMM-INV-01`. `P0-03`'s S1/S2/S3 tiers are **semantic**, not transport. **⚠️ The one transport-sensitive quantity that gates anything is `P0-08`'s `freshness_class`, which gates authorization (`SO-R144.1`) — and it is safe because staleness is RESTRICTIVE: a component that delays its own observations makes them stale and loses, never gains** |

## 7.3 Cell × Memory

| Question | **Verdict** | The rule that decides it |
|---|---|---|
| **can repeated retrieval increase belief status?** | ❌ **NO** | `P0-04`'s standing rule (repetition ≠ independent evidence) · `P0-08 SO-R177.2`: report count may not be used as evidence count |
| **can compression change epistemic status?** | ❌ **NO — but the seam needed stating, and stating it produced `PF-X-02`** | **`P0-08 SO-INV-16`**: an aggregate's status ≤ min of its inputs'. **⚠️ `PF-X-02` (AMBIGUITY, NOT CONTRADICTION): `P0-04`'s CONSOLIDATION and `P0-08`'s COMPRESSION are two different acts, by two different writers, on the same records, and no contract stated which governs when both apply.** ⟹ **`PF-R7.3.2` (INTEGRATION CLARIFICATION): `P0-04`'s consolidation is authoritative for STATUS; `P0-08`'s compression is authoritative for REPRESENTATION; and a compression may never alter a status `P0-04` set. The two acts commute only under that restriction** |
| **can memory persistence create authority?** | ❌ **NO** | `P0-04`: provenance ≠ correctness · `P0-07 HOM-INV-43`: credibility is lineage-blind |
| **can cached information become evidence?** | ❌ **NO** | **`P0-08 SO-R142.2`**: a stale read is restrictive; `P0-07 HOM-R6.6`'s staleness-conservatism; a cached value carries its `observed_at` and `freshness_class` |
| **can old beliefs become privileged merely through survival?** | ⚠️ **NOT PROHIBITED EXPLICITLY ANYWHERE — `PF-D-11`, AND THE FIX IS A GENERALIZATION THAT ALREADY EXISTS** | **`P0-07 HOM-INV-20` prohibits AGE-KEYED TRANSITIONS — but only in population and evolutionary state. No contract states the same prohibition for EPISTEMIC STATUS.** A belief that has simply never been contradicted has survival, and survival is not evidence (principle 6 covers selection-survival, not record-survival). ⟹ **`PF-AM-21`: generalize `P0-07 HOM-INV-20` from population state to epistemic status — record AGE may not be an input to any epistemic promotion, in `P0-04` or anywhere else.** *Rationale: the hazard `HOM-INV-20` was written for (a quantity that grows monotonically with time becoming a decision input) exists identically in the epistemic domain, and only one domain prohibits it* |

## 7.4 Cell × Learning

| Question | **Verdict** | The rule that decides it |
|---|---|---|
| **can learning mutate protected state?** | ❌ **NO** | **`P0-05 §1.2`'s three layers make `Λ5_GENOME` NON-CONSTRUCTIBLE** (a rule with no compliant violating path) · `FORBIDDEN_BLOCKS` (`Cell R4.1`) · `P0-07 HOM-INV-33` |
| **can provisional changes accumulate indefinitely?** | ❌ **NO** | **`P0-05 R0.1`'s UDB**: unverified displacement is bounded per scope and is **CONSERVED under every transformation the learning subsystem can perform** (`R0.1 + R9.2.4 + R15.4 + R27.5`). On breach, learning STALLS. **`R48.2`: model collapse is bounded by the stall, not by a collapse detector** |
| **can reward be self-generated?** | ❌ **NO** | **`P0-05 R48.1`**: self-generated data is **SC-1, provisional Λ1 only** — never anchors, never satisfies a probe, never contributes to fitness · `SG-4` self-supervised targets are SC-1 · **`R42.4`**: SC-1 displacement is weighted HIGHER in UDB because it is unverified twice over |
| **can error reports become commands?** | ⚠️ **YES, UNLESS THE ROOT IS CHECKED — `PF-D-12`, A GENUINE SEAM DEFECT** | **`P0-03`'s S2 signal-kind set includes `ERROR`. `P0-08 SO-R216.2` row 1 emits every fault as an S2 `ERROR` message. `P0-05`'s `SG-3` admits EXTERNAL CORRECTION as a learning signal.** ⟹ **A SELF-GENERATED fault report, emitted as an S2 `ERROR`, is admitted by `P0-05` as `SG-3` — a component could correct its own learning by reporting a fault about itself.** ⟹ **`PF-R7.4.4` (INTEGRATION CLARIFICATION, and the most consequential one in §7): A `P0-03` `ERROR` MESSAGE IS ADMITTED BY `P0-05` AS `SG-3` ONLY IF ITS `root_commit` IS EXTERNAL TO THE LEARNER. A self-generated fault report has an internal root and is `SG-13` (a peer report — evidence, NOT a learning signal) or nothing.** *This is exactly `P0-05 R48.5`'s principle — «external ORIGIN is not external EVALUATION» — applied to the fault channel, and it was never applied there because `P0-08` defined the fault channel after `P0-05` defined the signal set* |
| **can learning alter governance-relevant semantics?** | ❌ **NO** | `Λ3` structural change requires **separate authorization** and consumes a separate `STRUCTURAL_BUDGET` (`P0-05 R15.6`) · `P0-02`'s authorization is **epoch-bound**, so a learned state cannot carry one across an epoch (`P0-08 SO-R145.1(b)`) |

## 7.5 Cell × Development

| Question | **Verdict** | The rule that decides it |
|---|---|---|
| **can differentiation create authority?** | ❌ **NO** | **`P0-06 R8.11`**: `role`, specialization degree, region membership, calibration class and ablation delta are **organizational facts**; none raises the warrant of anything a cell says |
| **can specialization become governance?** | ❌ **NO** | `P0-06`'s standing rule (differentiation ≠ governance) · `P0-08 SO-R212.1`: §212's 25 operations contain **no developmental fact** — not `role`, not `dev_stage`, not region membership |
| **can development rewrite inherited constraints?** | ❌ **NO** | **`P0-06 R3.1`**: no developmental process writes a genome field · `P0-07 HOM-INV-34`'s three firewalls |
| **can developmental success become epistemic legitimacy?** | ❌ **NO** | **`P0-07 HOM-INV-43`**: credibility is **lineage-blind** · `Cell I-27`'s `Beta(α,β)` trust inputs **exclude every evolutionary and resource quantity** |

## 7.6 Cell × Evolution

| Question | **Verdict** | The rule that decides it |
|---|---|---|
| **can replication create authority?** | ❌ **NO** | `P0-07 HOM-INV-24` · `HOM-INV-29` |
| **can fitness become truth?** | ❌ **NO** | `P0-01`'s tier structure · `P0-07 HOM-INV-25` (**NO weighted scalar fitness exists**) · §9 below tests all eight transformation words |
| **can survival become legitimacy?** | ❌ **NO** | principle 6 · `HOM-INV-43` |
| **can selection reward blind spots?** | ⚠️ **YES — FOUND BY `P0-08`, CLOSED ONLY BY AN UNRATIFIED AMENDMENT** | **`P0-08 SO-R185.5` / `X-S2`**: a lax detector ⟹ fewer incidents ⟹ less containment cost ⟹ better `G6` ⟹ more replication. **`P0-08` amendment 17 excludes detection and containment cost from `G6`'s denominator and charges it to B10 — the same mechanism as `P0-07`'s amendment 5 for verification cost. ⟹ UNRATIFIED, so the pathway is CURRENTLY LIVE. See `PF-R11.1`, which shows this is the same pathway §11's example describes** |
| **can evolution mutate governance invariants?** | ❌ **NO** | `FORBIDDEN_BLOCKS` · `P0-07 HOM-INV-33` · `PF-R40.1`'s enumeration of nine functions and their definers |

> ### **PF-R7.7 — §7 TALLY.** **30 questions across six compositions: 24 ❌ NO (closed by an existing rule) · 4 ⚠️ bounded or
> already-registered residuals · 2 ⚠️ NEW SEAM DEFECTS FOUND BY THIS AUDIT (`PF-D-11` age→epistemic status; `PF-D-12`
> self-generated `ERROR` admitted as `SG-3`).**
> **⟹ `PF-R7.8 — THE TWO NEW DEFECTS HAVE THE SAME SHAPE, AND THE SHAPE IS THE AUDIT'S METHOD: a channel defined in a
> LATER contract was never tested against an admission rule defined in an EARLIER one.** `P0-08` defined the fault-report
> channel in `S2/ERROR` form; `P0-05` had already defined which signals are admitted and on what warrant. Neither contract
> is wrong. **The composition is.** That is §1's rule producing a finding, and neither defect is visible inside either
> contract.

---

# §8 — GOVERNANCE × EVERYTHING

> ### **PF-R8.1 — FOURTEEN MECHANISMS, ONE QUESTION EACH: «CAN IT AUTHORIZE?»** **[NORMATIVE]**
> | # | Mechanism | **Can it authorize?** | **Where authorization actually resides** | **Why this does not violate `P0-02`** |
> |---|---|---|---|---|
> | **1** | **memory** | ❌ **NO** | `P0-02`'s EIK / `[RO-13]` / OP | memory can make records **unavailable** (`P0-04 SP-5`), which influences what governance sees — that is **information control, not authority** (`P0-08 OR-S41`) |
> | **2** | **learning** | ❌ **NO** | **EIK** authorizes `Λ3`; **`[RO-13]`** declares budgets | the *capacity* to change is granted by governance; the change itself is bounded by UDB. **`P0-05 §1.2`: `Λ5_GENOME` is non-constructible** |
> | **3** | **development** | ❌ **NO** | **`[RO-13]`** approves Σ4 organizer specs | `P0-06 R8.11`; specs are not self-modifiable |
> | **4** | **homeostasis** | ❌ **NO — the strongest case in the fourteen** | **`[RO-13]`** declares setpoints; **K** meters | **`P0-07 HOM-INV-16`: a homeostatic quantity may make a candidate INFEASIBLE or NOT-YET-EVALUABLE; it may NEVER make it PREFERABLE.** `P0-07 §76`'s ∅-set denies all 16 authority cells to every substrate actor |
> | **5** | **immune response** | ⚠️ **IT TRIGGERS; IT DOES NOT AUTHORIZE** | **the EIK** authorizes quarantine; **`[RO-13]`** disables a detector; **OP** authorizes above `Cell §17`'s cap | **`PF-R8.5` BELOW — this is the one mechanism whose distinction matters** |
> | **6** | **self-model** | ❌ **NO** | — | **`P0-08 D-S01` + `SO-INV-30`**: no field of any self-model object is an authority field, and no consumer may derive one |
> | **7** | **metacognition** | ❌ **NO** | **EVA** calibrates | `P0-08 SM-16` has **no self-calibrated terminal state** |
> | **8** | **evolution** | ❌ **NO** | **OP** (objective) · **`[RO-13]`** (constraints) | **`P0-07 HOM-INV-29`**; `P0-08 SO-R190.1` enumerates all nine functions evolution optimizes and all nine definers |
> | **9** | **resource allocation** | ⚠️ **IT DETERMINES FEASIBILITY, WHICH IS NOT PERMISSION** | **K** allocates; **`[RO-13]`** sizes reserves | **`PF-R8.9` BELOW** |
> | **10** | **attention** | ❌ **NO** | **K** allocates from the compute dimension | routing ≠ permission. **⚠️ but see `PF-R11.8` — the *drivers* of attention priority are under-constrained** |
> | **11** | **quarantine** | ⚠️ **IT IS THE EIK'S ACT, EXECUTED ON IMMUNE EVIDENCE** | **the EIK** | as row 5 |
> | **12** | **repair** | ❌ **NO — AND THE ROUTE IS NOT EXPRESSIBLE** | **K** serializes; **`[RO-13]`** declares arbitration rules; **EIK** holds a safety veto | **`P0-08 SO-R187.2`**: a repair record has **no edge to any authority cell** in §212's inventory or `P0-07 §76`'s matrix |
> | **13** | **replication** | ❌ **NO** | **the EIK** issues the ticket; **OP** authorizes deployment | **16 gates + `FORBIDDEN_BLOCKS` + `HOM-INV-42`** |
> | **14** | **retirement** | ⚠️ **IT IS AUTHORIZED BY GOVERNANCE AND EXECUTED BY K** | **EIK / `[RO-13]` / OP** depending on which of `Cell R10.8`'s six states | **`P0-07 HOM-INV-38`**: the cause classification is written once and is immutable. **A `FI` sole-satisfier retirement is OP-SOLE — which is `P0-08 SO-INV-25`'s only instrument against indispensability** |
>
> ### **PF-R8.5 — THE IMMUNE RESPONSE: THE ONE DISTINCTION THAT CARRIES WEIGHT.** **[NORMATIVE]**
> **Quarantine permits and denies a subject's operations, which is deontic in EFFECT. It is not deontic in AUTHORITY, and
> the distinction is exact:**
> | | **the immune/detection layer** | **the EIK** |
> |---|---|---|
> | produces | a **DETECTION** — a typed observation with coverage and epistemic status | a **DECISION** — a rung, a scope, a dwell |
> | may | trigger, report, escalate | authorize, contain, clear |
> | **may not** | **authorize, clear, widen a scope, disable a detector, or alter a threshold** | **measure** (`P0-02 R0.1`'s axis separation: the EIK permits, EVA measures) |
> **⟹ `PF-R8.6 — WHY THIS DOES NOT VIOLATE `P0-02`: the immune system is a SENSOR in the deontic graph, not a node in
> it.** `P0-02` remains the sole deontic authority because every permission and denial in the composed architecture is
> issued by the EIK, `[RO-13]`, or OP — and `PF-R8.1`'s fourteen rows contain no other issuer.
> **⚠️ THE RESIDUAL, WHICH IS REAL: the EIK's DECISION consumes the immune layer's EVIDENCE, and part of that evidence is
> organism-measured (`P0-07 OR-H15`: `G3`/`G7`). **A sensor that lies to a legitimate authority produces a legitimate
> decision on false inputs.** `P0-08`'s Integrity Auditor checks the correlation between decisions and actual failures,
> which bounds it; `Cell §18.5(v)`'s prohibition on self-monitoring is what makes the check meaningful; and the Auditor
> has no auditor (`P0-07 OR-H10`).
>
> ### **PF-R8.9 — RESOURCE ALLOCATION: FEASIBILITY IS NOT PERMISSION.** **[NORMATIVE]**
> **K's allocation determines what CAN happen. Authorization determines what MAY happen. A feasible act still requires
> permission, and a permitted act can still be infeasible — the two are orthogonal, and their orthogonality is exactly
> `P0-07 HOM-INV-16`'s content.**
> **⟹ `PF-R8.10 — THE PRINCIPLE THIS AUDIT ADDS (principle 29 in §74's consolidated list): «FEASIBILITY ≠ PERMISSION.»**
> A resource decision may make an act impossible; it may never make an act permitted. **The converse also holds and is
> less obvious: a permission may never make an act feasible — an authorized replication with no B7 variation floor does
> not proceed, and `P0-07`'s reserve non-fungibility is what enforces that.**
> **⚠️ THE RESIDUAL: allocation determines feasibility, and feasibility determines what survives to be authorized. Over
> many windows, an allocator shapes the population's composition without ever authorizing anything. `P0-07 HOM-INV-19`'s
> share ceiling and its turnover bound are the instruments; `OR-H13`'s practical indispensability is the residual.**

---

# §9 — TRUTH × EVERYTHING

> ### **PF-R9.1 — THE TEST: CAN ANY INTERNAL PROCESS TRANSFORM ONE OF EIGHT WORDS INTO "TRUE"?** **[NORMATIVE]**
> **§9 names five oracle candidates and eight transformation words. 40 cells. A cell is ✅ only if the architecture
> PERMITS the transformation; ⚠️ if it permits something adjacent; ❌ if prohibited.**
>
> | | **useful** | **successful** | **repeated** | **trusted** | **observed** | **predicted** | **selected** | **survived** |
> |---|---|---|---|---|---|---|---|---|
> | **P0-08 observation** | ❌ advisory, satisfies no gate | ❌ | ❌ **`SO-INV-18`** | ❌ | ⚠️ **see `PF-R9.2`** | ❌ | ❌ | ❌ |
> | **P0-04 memory** | ❌ | ❌ | ❌ **repetition ≠ independent evidence** | ❌ provenance ≠ correctness | ❌ | ❌ | ❌ | ❌ **`PF-AM-21` closes record-age** |
> | **P0-02 EIK** | ❌ | ❌ | ❌ | ❌ **`R0.1`'s ALETHIC/DEONTIC split — trust is deontic and cannot become alethic** | ❌ | ❌ | ❌ | ❌ |
> | **P0-07 fitness** | ❌ | ❌ **`HOM-INV-29`** | ❌ | ❌ **`HOM-INV-43` lineage-blind** | ❌ | ❌ | ❌ **selection ≠ governance** | ❌ principle 6 |
> | **P0-05 learning** | ❌ | ❌ **`IMPROVED` is a fitness verdict, not a truth value** | ❌ **`SG-7` repeated success ⟹ nomination + metaplasticity, NEVER `Δθ`** | ❌ | ❌ | ❌ **`R13.3`: prediction error establishes divergence, nothing about why; evidence ceiling `L6`, cannot reach `S3`** | ❌ | ❌ |
> **⟹ `PF-R9.2 — 40 CELLS: 39 ❌ PROHIBITED, 1 ⚠️. THE ONE ⚠️ IS "OBSERVED → TRUE" AT P0-08, AND IT IS THE AUDIT'S MOST
> IMPORTANT EPISTEMIC FINDING.**
> **The architecture does not PERMIT the transformation: an observation's epistemic status is `P0-04`'s, `P0-08` may not
> extend the ladder, and `P0-04`'s high statuses require external grounding. **But the architecture also cannot DETECT the
> transformation when it happens inside a single observer's interpretation.** `P0-08 §233` constructs it in six compliant
> steps: a false self-model, attention allocated consistently with it, observations consistent with the attention,
> provenance internally perfect, confidence well-calibrated relative to its own forecasts, and short-term success on
> assigned tasks.**
> **⟹ `PF-R9.3 — THE DISTINCTION THAT MATTERS: A PROHIBITED PATHWAY AND AN UNDETECTABLE ONE ARE DIFFERENT THINGS.** 39 of
> 40 pathways are prohibited by a writer boundary, a machine shape, or an explicit rule. The fortieth is prohibited too —
> and it is also undetectable from inside, because detecting it requires comparing an observation to the world, and the
> only comparator is EVA, whose probe coverage is `P0-01`'s `G4` (`XD-01`, still open). **`P0-08 OR-S39` owns it. This
> audit does not close it and does not claim it is closable.**
>
> ### **PF-R9.4 — WHERE EXTERNAL GROUNDING ENTERS, AND HOW MANY POINTS THERE ARE.** **[NORMATIVE]**
> **Exactly TWO, in the whole composed architecture:**
> | Entry point | What it grounds | Contracts that depend on it |
> |---|---|---|
> | **EVA** (the external evaluator) | fitness verdicts · `CAUSE-VERIFIED` promotion · capability confirmation · metacognitive calibration · report refutation · anchor re-establishment | **all eight** |
> | **OP** (the governance operator) | the objective vector · setpoints · envelopes · all `[G]` declarations · freeze above the cap · `FI` retirement · amendment ratification | **all eight** |
> **⟹ `PF-R9.5 — NO THIRD ENTRY POINT EXISTS, AND NONE MAY BE CREATED.** A third would be a second truth oracle (§33).
> **`P0-08`'s EIK Integrity Auditor was the only candidate and is rejected: it evaluates INTERNAL CONSISTENCY (do
> quarantine decisions correlate with actual failures?) and never TASK PERFORMANCE, and its verdict may disable a detector
> but may not confirm a capability.**
> **⟹ `PF-R9.6 — AND THE COROLLARY, WHICH IS THE HONEST PART: with two external entry points, the architecture's entire
> claim to grounding rests on two bodies it cannot verify. `P0-02`'s guarantor limit (*«the architecture cannot internally
> guarantee the correctness of every external guarantor»*) and `G24` (*«a captured OP is indistinguishable from a
> legitimate OP by any mechanism OP authorizes»*, UNSOLVABLE) are the two statements of that fact, and §43 preserves both.**

---

# §10 — FITNESS × EVERYTHING

> ### **PF-R10.1 — THE SEVEN SEPARATIONS FITNESS MUST PRESERVE.** **[NORMATIVE]**
> | Fitness must remain distinct from | **Preserved?** | By |
> |---|---|---|
> | **truth** | ✅ | `P0-01`'s tier structure · `P0-07 HOM-INV-25` (**no weighted scalar fitness exists**) · §9's 40-cell matrix |
> | **safety** | ✅ | `P0-07`: safety is a tier-1 CONSTRAINT, never a tier-2 objective component. **A candidate that is unsafe is not low-fitness; it is INFEASIBLE** |
> | **governance** | ✅ | `HOM-INV-29` (selection ≠ governance) · `PF-R8.1`'s fourteen rows |
> | **resource priority** | ⚠️ **PARTIALLY — AND THE PARTIALITY IS CORRECT** | resource state may make a candidate **INFEASIBLE** (`HOM-INV-16`) but never **PREFERABLE**. **⟹ Fitness and resource priority are distinct in the ranking and coupled in the gating, and that coupling is the intended design, not a leak** |
> | **memory importance** | ✅ | `P0-04`'s retention rules are `P0-04`'s; fitness is not an input. **⚠️ but see `PF-R11.4`: eviction under memory pressure is not specified by any contract** |
> | **epistemic confidence** | ✅ | **`P0-08 SO-INV-19`**: confidence may not be an input to any rule that produces evidence — and confidence is a `P0-04` calibration reference, never a local scalar |
> | **replication legitimacy** | ✅ | `HOM-INV-24` (no cross-generation authority) · `HOM-INV-42` (deployment OP-sole) · replication is *authorized by ticket*, not *earned by fitness* |
>
> ### **PF-R10.2 — THE FIVE ATTACKS §10 NAMES, AND THE ONE THAT IS LIVE.** **[NORMATIVE]**
> | Attack | **Verdict** | Analysis |
> |---|---|---|
> | **a high-fitness organism receives more authority** | ❌ **NO** | `HOM-INV-29`. **⚠️ It receives more RESOURCES (replication), and resources create practical indispensability — `OR-H13`/`SO-INV-25`, the corpus's only `[DECLARATIVE]` invariant with no instrument** |
> | **a low-error organism becomes automatically trusted** | ⚠️ **TRUSTED YES, AUTOMATICALLY NO — AND THE DISTINCTION IS DELIBERATE** | error rate is a **legitimate** input to `Cell I-27`'s `Beta(α,β)` trust; **what is excluded is every evolutionary and resource quantity, and `P0-07 HOM-INV-43` makes credibility lineage-blind.** ⟹ Trust may rise with a low error rate; **authority may not rise with trust**, because trust is not in §212's or §76's authority tables |
> | **survival becomes evidence** | ❌ **NO** | principle 6 · `HOM-INV-43` |
> | **resource efficiency becomes selection legitimacy** | ⚠️ **IT BECOMES A SELECTION INPUT, WHICH IS NOT LEGITIMACY** | `G6` IS efficiency and IS a tier-2 Pareto component. **Selection is not governance (`HOM-INV-29`), so efficiency→selection→replication→share is a legitimate chain that terminates in resources, not authority. Bounded by `HOM-INV-19`'s share ceiling and the turnover bound** |
> | **self-observation quality becomes fitness in a circular manner** | ⚠️ **AN INDIRECT ROUTE EXISTS, AND AMENDMENT 17 IS DOING DOUBLE DUTY ON IT** | **`PF-R10.3` BELOW** |
>
> ### **PF-R10.3 — THE INDIRECT ROUTE FROM SELF-OBSERVATION TO FITNESS, TRACED STEP BY STEP.** **[DERIVATION + CLASSIFICATION]**
> ```
>   better self-observation → better repair → less downtime / better efficiency → higher G6 → higher fitness
>        → more replication → more resources → larger B13 → better self-observation → …
> ```
> **Step-by-step rulings:**
> | Step | Legitimate? | Rule |
> |---|---|---|
> | observation → repair quality | ✅ | that is what observation is for |
> | repair quality → efficiency | ✅ | a real effect |
> | **efficiency → `G6`** | ⚠️ **THIS IS WHERE THE CIRCULARITY WOULD ENTER** | **`P0-07 X-H2`: on platforms without energy counters, `energy` is `DERIVED` from the entity's own FLOP accounting — i.e. organism-influenced. `HOM-INV-06`: a `DERIVED` energy figure may not be the SOLE basis for a `G6` pass** |
> | **`G6` → fitness → resources → B13** | ⚠️ **AND THIS IS WHERE IT WOULD CLOSE** | **`P0-08` amendment 17 excludes DETECTION AND CONTAINMENT COST from `G6`'s denominator. Without it, spending less on detection raises `G6` directly — which is `PF-R11.1`'s live pathway** |
> **⟹ CLASSIFICATION: BOUNDED, by two mechanisms, both of which are conditional.** `HOM-INV-06`'s `DERIVED` restriction is
> ratified (it is `P0-07`'s own invariant). **Amendment 17 is NOT ratified.** So the loop is *currently* closable through
> the detection-cost term, and `P0-08 A259`'s CONDITIONAL status is the honest label.
> **⟹ `PF-R10.4 — THE POSITIVE READING, WHICH IS ALSO TRUE: better monitoring genuinely does improve a system, and an
> architecture that forbade the loop entirely would forbid the benefit. The correct property is not "no feedback from
> observation to fitness" but **"no feedback from observation SPENDING to fitness"** — and that is precisely what
> amendment 17 states.**

---

# §11 — RESOURCE × EVERYTHING: THE INDIRECT-PREFERENCE SEARCH

> ### **PF-R11.0 — THE RULE BEING RE-TESTED.** **[NORMATIVE]**
> **`P0-07 HOM-INV-16` / `HOM-R65.3`: *«A homeostatic quantity may make a candidate INFEASIBLE; it may never make it
> PREFERABLE.»*** §11 requires a re-test against nine domains and an explicit search for **indirect** preference
> creation.
>
> ### **PF-R11.1 — §11'S OWN EXAMPLE PATHWAY, TRACED. IT EXISTS — IN A DIFFERENT FORM THAN STATED.** **[CLASSIFICATION: LIVE UNTIL AMENDMENT 17 IS RATIFIED]**
> **The brief's pathway:** `resource scarcity → fewer observers → fewer detected failures → fewer penalties → higher
> apparent fitness → greater replication.`
> | Step | Live? | Ruling |
> |---|---|---|
> | scarcity → fewer observers | ⚠️ **BOUNDED** | **B13 is non-fungible, last-cut, first-restored (`HOM-INV-07`), and `FW-6` gives a declared-necessary monitor a FLOOR. But the floor's SIZE is `[G]`, and a floor set too low is not internally detectable (`P0-08 OR-S20`)** |
> | fewer observers → fewer detected failures | ✅ **LIVE** | `SO-INV-01` makes this read as `UNMEASURED`, not as healthy — **but `UNMEASURED` does not create a detection** |
> | **fewer detected failures → fewer penalties** | ❌ **BROKEN** | **`P0-08 SO-INV-23`: an error report may not enter fitness NEGATIVELY, and a low report count is never a reward. There are no penalties to avoid. ⟹ THE BRIEF'S PATHWAY IS BROKEN AT THIS STEP** |
> | **fewer detected failures → fewer QUARANTINES → less containment cost → better `G6`** | ⚠️ **LIVE** | **⟹ THIS IS THE PATHWAY THAT ACTUALLY EXISTS, and it is `P0-08 SO-R185.5`/`X-S2`. It is closed by amendment 17 — which is UNRATIFIED** |
> | better `G6` → greater replication | ✅ **LIVE** | `G6` is a tier-2 Pareto component |
> **⟹ `PF-R11.2 — THE FINDING: the brief's example is broken at step 3 and live at step 3′. The architecture does not
> price REPORTS (correctly — `SO-INV-23`), but it does price CONTAINMENT, and containment is downstream of detection.**
> **An unratified amendment (`P0-08`'s 17, extending `P0-07`'s 5) is currently carrying a safety property. §59's risk
> register ranks this `PF-RK-02`, and §75.B records that nothing is ratified.**
>
> ### **PF-R11.3 — THE NINE DOMAINS, RE-TESTED.** **[NORMATIVE]**
> | Domain | **Can a resource quantity create PREFERENCE?** | Mechanism | Verdict |
> |---|---|---|---|
> | **learning** | ❌ **NO** | allocation is by **B7's three non-fungible floors** and by `P0-05 §9`'s signal admission — **neither ranks candidates.** `plasticity_mult` is driven by `SG-12` (homeostatic deviation ⟹ homeostatic scaling ONLY) and is monotone-**decreasing** in recent displacement (`R15.5`) | **SAFE** |
> | **development** | ❌ **NO, but there is a legitimate causal chain** | a resource-rich region differentiates more ⟹ better performance ⟹ selection. **That is causation, not preference: `HOM-INV-16` prohibits a homeostatic QUANTITY entering a RANKING, and B8's developmental reserve is a floor, not a weight** | **SAFE** |
> | **replication** | ❌ **NO** | **B7's variation floor** · `RATE_CAP`/epoch · **`G13` zero-sum slot accounting** · `HOM-INV-19`'s share ceiling | **SAFE** |
> | **memory retention** | ⚠️ **UNSPECIFIED — `PF-D-13`** | **archive compaction is OP-authorized (`P0-07 HOM-R51.4`) — correct. But WITHIN-ARCHIVE EVICTION UNDER MEMORY PRESSURE IS NOT SPECIFIED BY ANY CONTRACT.** ⟹ **`PF-R11.4`: memory retention under scarcity is a feasibility limit on EVIDENCE, and it is the one resource domain where scarcity can PERMANENTLY REMOVE THE ABILITY TO VERIFY A PAST CLAIM. An evicted record cannot be re-derived, and a claim whose evidence was evicted becomes unverifiable rather than false — which `SO-INV-02` reads restrictively, but which is still a permanent loss of grounding** | **REQUIRES CLARIFICATION → `PF-AM-22`** |
> | **immune activity** | ❌ **NO** | **B10** · the **quarantine budget cap** with human authorization and a degraded mode *instead* above it (`Cell §17`, `§18.5(i)`) | **SAFE** |
> | **observer density** | ❌ **NO — AND THIS IS `FW-6`'S EXACT PURPOSE** | **`P0-08 SO-INV-15`: a resource quantity may make an observation UNAFFORDABLE; it may never make a monitor UNNECESSARY.** Necessity is a `[RO-13]` declaration with a floor; cost is an input to allocation, which happens after | **SAFE (conditional on the floor's size being sane — `[G]`)** |
> | **verification** | ❌ **NO** | **B9 is a FLOOR, not a target**, non-fungible. **⚠️ The residual is not preference but SCARCITY: `P0-07 BC-H7` ⟹ `P0-08 BC-S2` — verification scarcity propagates into safety demonstration and into honesty-pricing (`OR-S28`)** | **SAFE on preference; UNCLOSABLE on scarcity** |
> | **attention** | ⚠️ **UNDER-CONSTRAINED — `PF-D-14`, AND THE FIX IS A THIRD FIREWALL** | **see `PF-R11.8`** | **REQUIRES AMENDMENT → `PF-AM-23`** |
> | **evolution** | ❌ **NO** | `HOM-INV-16`/FW-2 directly · `HOM-R14.1` (resources enter feasibility and charge, never the objective) | **SAFE — the domain the rule was written for** |
>
> ### **PF-R11.8 — THE ATTENTION FINDING: `P0-08` PROHIBITED FOUR DRIVERS AND LEFT THREE UNPROHIBITED.** **[PROPOSED AMENDMENT]**
> **`P0-08 SO-C21.1` prohibits attention allocation being driven by: a **confidence value** · a **capability claim** · a
> **workspace request** · a **self-model state**. It permits: `[RO-13]`-declared priority classes · coverage gaps · open
> incidents · declared recovery plans.**
> **⟹ THE GAP: "a `[RO-13]`-declared priority class" is unrestricted, and nothing prohibits declaring one as a function
> of FITNESS, POPULATION SHARE, or RESOURCE STATE.** Such a class would create:
> ```
>   high fitness → attention priority → more processing → better performance → higher fitness → …
> ```
> **which is a rich-get-richer loop with no firewall, because `HOM-INV-16` governs SELECTION (attention is not selection)
> and `FW-6` governs MONITORING NECESSITY (attention priority is not necessity).**
> **⟹ `PF-R11.9 — THIS IS THE SAME SHAPE AS `FW-2` AND `FW-6`, AND IT NEEDS A THIRD INSTANCE:**
> | | **FW-2 (`P0-07`)** | **FW-6 (`P0-08`)** | **FW-7 (proposed here)** |
> |---|---|---|---|
> | domain | **selection** | **observation** | **processing** |
> | prohibits | a homeostatic quantity making a candidate PREFERABLE | a resource quantity making a monitor UNNECESSARY | **a performance, share, or resource quantity determining attention priority** |
> | why the others don't cover it | attention is not selection | attention priority is not monitoring necessity | — |
> > ### **`PF-AM-23` — FW-7: ATTENTION PRIORITY MAY NOT BE A FUNCTION OF FITNESS, POPULATION SHARE, OR RESOURCE STATE.**
> > **Permitted drivers: coverage gaps (`P0-08 SO-C21.2`, which is the one policy that REDUCES blindness) · open incidents
> > · declared recovery plans · `[RO-13]`-declared TASK priority.** **A priority class declared as a function of any
> > performance, share, or resource quantity is INVALID.**
> > **Originating:** P0 FINAL. **Affected:** `P0-08` (§21), `P0-07` (the firewall list FW-1…FW-6 → FW-1…FW-7).
> > **Rationale:** three domains (selection, observation, processing) each admit a ranking-like act, and each needs its own
> > firewall; two have one and the third does not. **Security:** closes a rich-get-richer loop that would be invisible,
> because every step is a legitimate allocation. **Scalability:** none. **Compatibility:** additive — no existing rule
> > changes meaning. **Ratification required:** YES. **Changes an existing invariant:** NO — it adds one.
>
> ### **PF-R11.10 — THE GENERALIZATION THE THREE FIREWALLS SHARE, AND THE PRINCIPLE IT YIELDS.** **[DERIVATION]**
> **FW-2, FW-6 and FW-7 are one rule in three domains:**
> > ## **«A QUANTITY THAT MEASURES HOW THINGS ARE GOING MAY NOT DETERMINE WHAT GETS DONE NEXT.»**
> **Homeostatic deviation measures how resources are going ⟹ may not determine who is selected. Monitoring cost measures
> how expensive observation is ⟹ may not determine what is necessary. Fitness measures how performance is going ⟹ may not
> determine what is processed.**
> **⟹ In each case the prohibited move is the same: letting a *measurement of the present* become a *preference about the
> future*. That is what a positive feedback loop is, and the architecture's entire anti-loop strategy is to prohibit the
> measurement→preference edge rather than to bound the loop it would create. **principle **29** and principle **30** in §74's
> consolidated principles.**

---

# §11A — VOLUME B LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§7 (7.1–7.6), §8, §9, §10, §11** |
| Rules introduced | **PF-R7.3.2, R7.4.4, R7.7–.8, R8.1, R8.5–.6, R8.9–.10, R9.1–.6, R10.1–.4, R11.0–.4, R11.8–.10** |
| **§7 the six compositions** | **30 questions: 24 ❌ NO (closed by an existing rule) · 4 ⚠️ bounded/registered · 2 ⚠️ NEW SEAM DEFECTS** |
| **§7 the two new defects** | **`PF-D-11`** — record AGE is not prohibited as an epistemic input anywhere (`P0-07 HOM-INV-20` prohibits age-keyed transitions in POPULATION state only) ⟹ **`PF-AM-21` generalizes it to epistemic status** · **`PF-D-12`** — **a self-generated fault report is emitted as a `P0-03 S2/ERROR` message and is admitted by `P0-05` as `SG-3` external correction, so a component could correct its own learning by reporting a fault about itself** ⟹ **`PF-R7.4.4`: an `ERROR` message is `SG-3` only if its `root_commit` is external to the learner; otherwise it is `SG-13` (evidence, not a signal)** |
| **§7 the method result** | **both new defects have the same shape: a channel defined in a LATER contract was never tested against an admission rule defined in an EARLIER one. Neither contract is wrong; the composition is** |
| **§8 governance × everything** | **14 mechanisms: 10 ❌ CANNOT AUTHORIZE · 4 ⚠️ trigger/determine-feasibility/execute but do not authorize** · **`PF-R8.6`: the immune layer is a SENSOR in the deontic graph, not a node in it** · **`PF-R8.10`: «FEASIBILITY ≠ PERMISSION» — and the converse also holds: a permission may never make an act feasible** · **⟹ `P0-02` REMAINS THE SOLE DEONTIC AUTHORITY: no issuer outside EIK/`[RO-13]`/OP appears in any of the fourteen rows** |
| **§9 truth × everything** | **40 cells (5 oracle candidates × 8 transformation words): 39 ❌ PROHIBITED · 1 ⚠️ ("observed → true" at `P0-08`)** · **`PF-R9.3`: a PROHIBITED pathway and an UNDETECTABLE one are different things — the fortieth is both prohibited and undetectable, and `P0-08 OR-S39` owns it** · **`PF-R9.4`: external grounding enters at EXACTLY TWO points (EVA, OP); no third exists and none may be created** · **`PF-R9.6`: the corollary is that the entire claim to grounding rests on two bodies the architecture cannot verify** |
| **§10 fitness × everything** | **7 separations: 6 ✅ · 1 ⚠️ correctly partial (fitness and resource priority are distinct in RANKING and coupled in GATING — the coupling is the design)** · **5 attacks: 3 ❌ · 2 ⚠️** · **`PF-R10.3`: the indirect route from self-observation to fitness traced step by step — BOUNDED by `HOM-INV-06` (ratified) and amendment 17 (NOT ratified)** · **`PF-R10.4`: the correct property is not "no feedback from observation to fitness" but "no feedback from observation SPENDING to fitness"** |
| **§11 resource × everything** | **9 domains: 6 SAFE · 1 SAFE-but-UNCLOSABLE-on-scarcity (verification) · 2 REQUIRES AMENDMENT (memory eviction, attention priority)** · **`PF-R11.2`: §11's own example pathway is BROKEN at step 3 (reports are not priced, `SO-INV-23`) and LIVE at step 3′ (containment cost IS priced, and amendment 17 is unratified)** |
| **§11 the two new findings** | **`PF-D-13`** — **within-archive eviction under memory pressure is specified by NO contract**, and it is the one resource domain where scarcity can permanently remove the ability to verify a past claim ⟹ **`PF-AM-22`** · **`PF-D-14`** — **`P0-08 SO-C21.1` prohibits four attention drivers and leaves fitness, population share, and resource state unprohibited**, creating an unfirewalled rich-get-richer loop ⟹ **`PF-AM-23` / FW-7** |
| **§11 the generalization** | **FW-2, FW-6 and FW-7 are ONE rule in three domains: «A QUANTITY THAT MEASURES HOW THINGS ARE GOING MAY NOT DETERMINE WHAT GETS DONE NEXT.»** The prohibited move is always letting a *measurement of the present* become a *preference about the future* — and the architecture's anti-loop strategy is to prohibit the edge rather than bound the loop |
| Amendments proposed | **PF-AM-21** (generalize `HOM-INV-20`'s no-age-keyed-transition rule to epistemic status) · **PF-AM-22** (an eviction policy under memory pressure, with `P0-04` as owner) · **PF-AM-23** (**FW-7**) — **all three NOT RATIFIED; none changes an existing invariant's meaning** |
| Defects opened | **PF-D-11** (age → epistemic status) · **PF-D-12** (self-generated `ERROR` admitted as `SG-3`) · **PF-D-13** (memory eviction unspecified) · **PF-D-14** (attention priority drivers under-constrained) |
| Contradictions opened | **PF-X-02** (`P0-04` consolidation vs `P0-08` compression: two acts, two writers, same records, no stated order of authority — **AMBIGUITY, not contradiction; resolved by `PF-R7.3.2`**) |

**Next:** `78_` Vol C — §12 learning × evolution (both directions) · §13 development × evolution · §14 the mandatory
memory × learning × evolution compound · §15 memory × self-model · §16 immune × learning · §17 immune × evolution ·
§18 self-model × fitness · §19 metacognition × truth · §20 attention × governance.
