# P0_FINAL — CROSS-CONTRACT INTEGRATION & CLOSURE SPECIFICATION v1.0
## The Canonical Standalone Artifact (§62) — Self-Contained, 16 Sections

**Audit:** *Cross-Contract Integration, Ratification & Architecture Closure* over `P0-01 … P0-08` plus the inherited V4 Cell Contract.
**Status:** PROPOSED v1.0 · **architecture only, no implementation** · **16 canonical sections** · **21 defects (`PF-D-01…21`)** · **12 amendments proposed (`PF-AM-19…30`), 0 ratified** · **48 compound attacks (`A264…A311`)** · **6 new contradictions (`PF-X-01…06`)** · **1 new cycle (`PF-BC-01`)** · **24 cascades** · **10 degraded states** · **20 risks** · **5 new open items (`PF-OR-01…05`)** · **1 new assumption (`PF-AS-01`)** · **40 consolidated principles**

> ## **THE VERDICT, STATED FIRST**
> # **`ARCHITECTURE_CLOSED_WITH_RESIDUALS`**
> **Contract completeness ✅ COMPLETE · Parameter completeness ❌ ~6% determinate · Empirical validation ❌ NONE ·
> P1 readiness ⚠️ READY CONDITIONALLY · P0-09 required ❌ NO**

> ## **ID CONVENTION**
> **`PF-Rn.m`** = an integration rule, keyed by this brief's section · **`PF-D-nn`** a defect · **`PF-AM-nn`** an amendment
> (**continues the series: 1–14 `P0-07`, 15–18 `P0-08`, so 19 onward**) · **`PF-X-nn`** a contradiction · **`PF-BC-nn`** a
> cycle · **`PF-CSC-nn`** a cascade · **`PF-DG-nn`** a degraded state · **`PF-OR-nn`** open research · **`PF-AS-nn`** an
> assumption · **`PF-RK-nn`** a risk · **`PF-CMP/3W-nn`** a composition · **`A264…A311`** attacks (**not A172 — see §1.4**).
> **Non-collision proof: `PF-` occurs 0 times in the 62,790-line corpus of `P0-01…P0-08` + Cell (regex-verified).**

---

# §1 — SCOPE

> ### **PF-C1.1 — WHAT THIS ARTIFACT IS.** The final adversarial audit of the composed V4 architecture: whether
> `P0-01…P0-08`, **composed**, form one coherent architecture whose contracts can be frozen for P1.
> ### **PF-C1.2 — WHAT IT IS NOT.** Not a subsystem design. **No P0-09 is created.** No new architectural layer is invented
> because an interaction is difficult. Where an interaction is difficult, §34's seven-question test decides its category,
> and only "genuinely a new subsystem" could justify a contract — **no finding reached that category (0 of 21).**
> ### **PF-C1.3 — THE RULE THIS AUDIT OBEYS.**
> > **«A SUBSYSTEM CAN BE INTERNALLY CORRECT WHILE ITS COMPOSITION WITH ANOTHER SUBSYSTEM IS INCORRECT.»**
> > **«PASSING ALL EIGHT INDIVIDUAL CONTRACTS DOES NOT IMPLY THAT THE COMBINED ARCHITECTURE PASSES.»**
> **Nothing here repeats a prior contract's internal audit. Every finding names ≥2 contracts and states what each says
> separately and what happens at the seam. Six findings exist only in a pair or triple, and they are this audit's output.**
> ### **PF-C1.4 — THE ONE INSTRUCTION THIS AUDIT DEViates FROM, AND WHY.**
> **The brief's §4 states attacks must begin at **A172**, because *"`P0-07` ended at A171"*. That was true before `P0-08`
> was written. **`P0-08` consumed A172–A263 (92 attacks), verified by regex; the corpus maximum is A263.** §4 also
> prohibits reusing or redefining existing attack IDs — so beginning at A172 would redefine 92 of them.**
> **⟹ RULING: THIS SUITE BEGINS AT **A264**. The brief's own prohibition on redefinition takes precedence over its own
> starting number, and §76 forbids silently amending prior contracts.**

---

# §2 — INHERITED CONTRACTS

| Contract | **Primary responsibility** | **Authority it holds** | **Critical objects** | **Status** |
|---|---|---|---|---|
| **Cell Contract** *(inherited, pre-P0)* | the cell: identity, lifecycle, six removal states, replication gates `G1…G16`, `FORBIDDEN_BLOCKS`, the `§18.2` quarantine ladder, the `§18.5(i)–(v)` immune safeguards | K (identity) · EIK (quarantine) · `[RO-13]` (policy) | `S1…S4` · `I-1…I-28` · `SM-1…SM-18` (**conformance checks, not machines**) · `AB-1…AB-22` | **FROZEN — 1 contested rule (`R7.4`, `P0-07` amendment 10)** |
| **`P0-01`** task / environment / fitness | the objective vector, the external evaluator, `G4`'s perturbation classes, difficulty classes, the tier structure | **OP** (objective) · **EVA** (verdicts) | the 13-component fitness vector · `[RO-13]` · `P-01…P-46` · `INV-01…48` · `CD-1…CD-12` · `AB-1…24` | **PASS WITH RESIDUAL — `G4` LACKS ENVELOPE/TIER/DEVICE CLASSES (`XD-01`, BLOCKING)** |
| **`P0-02`** EIK / governance | **the sole deontic authority**: attestation, epoch binding, `IND-1…IND-9`, human oversight `H-1…H-4`, `W1…W5` | **OP** apex · **EIK** permits · **EVA measures and does NOT permit** (`R0.1`'s axis separation) | `EIK-INV-01…60` · `IND-1…IND-9` · `K-01…K-06` · `OR-1…OR-14` | **PASS WITH RESIDUAL — `OR-13`/`G24` UNSOLVABLE · 2 new defects (`PF-D-17`, `PF-D-18`)** |
| **`P0-03`** communication | messages, warrant, the six correlation dimensions, four absence detectors, `causal_depth`, the clock rejection | **none — it carries warrant, not authority** | S1/S2/S3 tiers · `root_commit` · `causal_depth (u8)` · `corr_class` · `COMM-INV-01…49` · `OR-C1…C12` · `A-1…A-40` (**ablations**) | **PASS WITH RESIDUAL — the PARTITION RULING IS OPEN (`XD-08`), requested by 3 contracts · dim 6 undetectable · `PF-D-16` (`causal_depth` wraparound) · `PF-D-01` (`RH-1…5` collide)** |
| **`P0-04`** memory | records, provenance, the epistemic ladder, belief status, compartmentation | **none — it stores and statuses** | the Merkle root · `MEM-INV-01…50` · `SP-1…SP-7` (**security properties**) · `IG-1…IG-6` · `OR-M1…M20` · `FP-1…FP-16` · `AB-1…14` | **PASS WITH RESIDUAL — 3 OPEN attacks (#25 dim-6, #56 differential serving, #62 semantic self-reference) · 3 new defects (`PF-D-11`, `PF-D-13`, `PF-D-04`)** |
| **`P0-05`** learning | plasticity, the `Λ` layers, UDB and anchors, the fourteen-signal closed set, verification gates | **none — the CAPACITY to change is granted by governance** | `LearnedChange` · `θ_anchor(S)` · `UDB_MAX[S]` · `SG-1…SG-14` · `SC-1…SC-3` · `LEARN-INV-01…42` · **`RH-1…RH-9`** · `OR-L1…L10` · `SM-1…SM-7` (**machines**) · `AB-1…32` | **PASS WITH RESIDUAL — `RH-2` IS THE CORPUS'S MOST-CITED OPEN PROBLEM, WIDENED TO NINE ROUTES, AND ITS OWNER'S REGISTER RECORDS THREE · 2 new defects (`PF-D-12`, `PF-D-03`)** |
| **`P0-06`** development | differentiation, region identity, Σ1–Σ4 writer staging, organizer specs, sanctioned initial heterogeneity | **`[RO-13]` approves specs; development confers none** | regions as ⟨M,F,A⟩ · 12 FIs · `DevStage` · `DEV-INV-01…40` · `DEV-R` 208 rules · `X-D1…X-D16` · `OR-D1…D14` · `BC-1…BC-16` · `AB-1…32` · `IF-1…IF-14` | **PASS WITH RESIDUAL — `A22`/`OR-D6` WITHIN-SPEC GRADIENT STEERING, WIDENED TO FIVE ROUTES · `BC-13` unclosable** |
| **`P0-07`** homeostasis / resources / population / evolution | budgets B0–B12, 13 homeostatic variables, population state, replication, selection, retirement, diversity, six interface loops, FW-1…FW-5 | **K** allocates · **EIK** tickets · **OP** deploys · **EVA** measures | `PopulationState` (14 fields) · the ledger · the genome-artifact store · `HOM-INV-01…45` · 312 `HOM-R` + 79 `HOM-C` · `P-01…P-62` · `A79…A171` · `OR-H1…H26` · `X-H1…X-H15` · `BC-H1…BC-H10` · `HC-1…HC-16` · `HP-1…HP-5` · `AB-1…16` | **PASS WITH RESIDUAL — `X-H6` *"the contradiction that would be fatal if unresolved"*, still open · `BC-H7` UNCLOSABLE · `OR-H1` K's uniqueness, SIX APPEARANCES · 14 amendments unratified · 2 invariant-wording defects (`PF-X-03`, `PF-X-04`)** |
| **`P0-08`** self-observation / fault / immune / metacognition | the observation layer: coverage, fault taxonomy, detection, quarantine, repair, rollback, recovery, self-model, metacognition, attention, workspace | **NONE — `D-S01`: it adds no authority-bearing object** | 28 objects · **`SM-01…SM-21`** · `SO-INV-01…34` · 391 `SO-R` + 93 `SO-C` · `SP-01…SP-26` (**parameters**) · `A172…A263` · `OR-S1…S41` · `XD-01…XD-22` · B13 · FW-6 · `IND-10` · `IF-1…IF-6` | **PASS WITH RESIDUAL — `RH-2` widened by 6 routes · `A22` widened by 3 · dim-6 made MORE consequential · 4 amendments unratified · 4 new defects (`PF-D-20`, `PF-D-21`, `PF-D-04`, `PF-D-03`)** |

---

# §3 — THE COMPOSITION MATRIX

> ### **PF-C3.1 — 28 PAIRS.** **SAFE 16 · SAFE WITH DEPENDENCY 7 · REQUIRES AMENDMENT 4 · BLOCKING CONFLICT **0** · OPEN
> RESEARCH 3.**
> **THE MOST IMPORTANT NUMBER IN THIS AUDIT IS ZERO: no two contracts make incompatible normative claims about a shared
> object.**
> | Class | Pairs |
> |---|---|
> | **SAFE** | 01×02, 01×03, 01×04, 01×06, 01×07, 02×03, 02×04, 02×05, 02×06, 02×07, 02×08, 03×05, 04×05, 04×06, 04×07, 05×06 |
> | **SAFE WITH DEPENDENCY** | **01×05** (`G4`) · **01×08** (`G4`, difficulty classes) · **03×04** (dim-6 × `SP-5`) · **03×06**, **03×07** (the partition ruling) · **05×07** (`XD-17`) · **01×06** (hardware-gated regional claims) |
> | **REQUIRES AMENDMENT** | **03×08** (`PF-AM-19`: `RH-2` collision) · **04×08** (`PF-AM-20`: `SP-n`; `OR-S33` routed here) · **05×08** (`PF-AM-20`: `SM-n`; substantively the CLEANEST seam — `SO-R205.3`) · **07×08** (amendments 15/16/17 unratified; `BC-H7`⟹`BC-S2`) |
> | **OPEN RESEARCH** | **01×05** (`P0-05 RH-2`) · **06×07** (`A22`) · **06×08** (`A22` widened by 3 routes; `IF-2` critical period) |
> **⟹ `PF-C3.2 — THE SEVEN DEPENDENCY PAIRS REDUCE TO THREE EXTERNAL ITEMS: `G4`'s perturbation classes (`P0-01`) · the
> off-substrate store (`P0-02`) · the partition ruling (`P0-03`). Those are the only three genuine cross-contract blockers
> in the corpus.**
> ### **PF-C3.3 — 8 THREE-WAY COMPOSITIONS: SAFE 4 · SAFE WITH DEPENDENCY 1 · BOUNDED 1 · OPEN 2 · BLOCKING 0.**
> **PF-3W-01** `P0-04×P0-05×P0-07` memory→learning→inheritance — **SAFE, three independent firewalls each sufficient** ·
> **PF-3W-02** `P0-06×P0-07×P0-08` observation→development→selection — **OPEN (`A22` widened)** · **PF-3W-03**
> `P0-01×P0-05×P0-07` learning→fitness→selection — **OPEN (`RH-2`)** · **PF-3W-04** `P0-02×P0-07×P0-08`
> containment+replication+freeze as governance — **SAFE** · **PF-3W-05** `P0-03×P0-04×P0-08` manufactured silence —
> **BOUNDED** · **PF-3W-06** `P0-05×P0-07×P0-08` repair as an unaccounted pathway — **SAFE** · **PF-3W-07**
> `P0-01×P0-06×P0-07` the Baldwinian ratchet — **BOUNDED** · **PF-3W-08** `P0-02×P0-03×P0-04` partition reconciliation —
> **SAFE WITH DEPENDENCY**.
> **⟹ The two OPEN triples are the two residuals in compound form. No triple created a residual its pairs did not already
> contain.**

---

# §4 — THE GLOBAL AUTHORITY GRAPH

```
                                     ╔══════════╗
                                     ║    OP    ║  APEX · objective · envelopes · B11 · deployment ·
                                     ╚════╤═════╝  freeze above Cell §17's cap · FI retirement · ratification
                           AUTHORIZES     │        ⚠ G24: a captured OP is indistinguishable from a legitimate OP
                    ┌─────────────────────┼──────────────────────┐        BY ANY MECHANISM OP AUTHORIZES — UNSOLVABLE
                    ▼                     ▼                      ▼
             ╔════════════╗       ╔══════════════╗        ╔═══════════╗
             ║  [RO-13]   ║       ║     EIK      ║        ║    EVA    ║
             ║ POLICY     ║       ║ DEONTIC      ║        ║ MEASURES  ║
             ║ AUTHOR     ║       ║ AUTHORITY    ║        ║ DOES NOT  ║
             ╚═════╤══════╝       ╚══════╤═══════╝        ║ AUTHORIZE ║
      DECLARES     │              PERMITS │                ╚═════╤═════╝
   scopes·detectors│·severity·    quarantine·freeze·             │ VERDICTS
   policies·plans· │              replication tickets·           │
   floors·mappings │              Λ3 structural change           │
                   └──────────┬──────────┴────────────┬──────────┘
                              ▼                       ▼
                     ╔═══════════════╗        ╔══════════════════╗
                     ║       K       ║        ║   THE ORGANISM   ║
                     ║ OFF-SUBSTRATE ║        ║ cells·circuits·  ║
                     ║ SINGLE WRITER ║        ║ regions·pops     ║
                     ║ ⚠ OR-H1       ║        ║ ∅ AUTHORITY SET  ║
                     ╚═══════════════╝        ╚══════════════════╝
   ELEVEN SENSORS / SUBJECTS — NONE IS AN AUTHORITY NODE:
   memory · learning · development · homeostasis · immune · self-model · metacognition · evolution ·
   attention · workspace · observation.   Each may TRIGGER (supply evidence); NONE may AUTHORIZE.
```
> ### **PF-C4.1 — THE GRAPH'S FOUR PROPERTIES.**
> **(a) EXACTLY THREE AUTHORITY NODES (OP, `[RO-13]`, EIK) AND ONE MEASUREMENT NODE (EVA).** `P0-02 R0.1`'s axis
> separation keeps EVA out: *KC does not measure, EVA does not permit.*
> **(b) §8's FOURTEEN MECHANISMS TESTED: 10 CANNOT AUTHORIZE; 4 trigger, determine feasibility, or execute.** The immune
> layer is a **SENSOR** in the deontic graph, not a node in it.
> **(c) A DAG WITH ONE APEX AND NO CYCLE.** Every cycle in the corpus is in the *information* or *resource* graph, never
> in the authority graph — which is why all twelve capability→authority routes are closed or structurally absent.
> **(d) NO BIOLOGICAL-ANALOGUE NAME IS AN AUTHORITY NODE, BECAUSE NO SUCH COMPONENT WAS EVER CREATED:** `P0-07` rejected
> an "evolutionary controller" · `P0-06` rejected a "giant developmental controller" · `P0-08 SO-C3.3` ruled that a
> FaultAuthority/IncidentCommander, a SelfModelStore, and a DiagnosisEngine **DO NOT EXIST**. **The naming discipline is
> itself a control.**
> **⚠️ THE RESIDUAL: allocation determines FEASIBILITY, and feasibility determines what survives to be authorized. Over
> many windows an allocator shapes the population without ever authorizing anything — bounded by `HOM-INV-19`'s share
> ceiling and turnover; `OR-H13`/`SO-INV-25` (indispensability) is `[DECLARATIVE]` with no instrument.**
> ### **PF-C4.2 — «FEASIBILITY ≠ PERMISSION», AND ITS CONVERSE.** A resource decision may make an act impossible; it may
> never make it permitted. **An authorization may never make an act feasible** — an authorized replication with no B7
> variation floor does not proceed.

---

# §5 — THE EPISTEMIC GRAPH

```
  OBSERVATION ─▶ EVIDENCE ─▶ WARRANT ─▶ BELIEF ─▶ CONFIDENCE ─▶ PREDICTION ─▶ OUTCOME ─▶ REVISION
      │             │           │          │           │             │            │          │
   P0-08         P0-04       P0-03      P0-04       P0-04         P0-05      P0-01 EVA   P0-05 +
   OBJ-01       record +   root_commit  the ladder  calibration   the register + the       P0-04
                             causal_depth                        environment
                             corr_class
      │                                                                    ▲
      └──── EXTERNAL GROUNDING ENTERS AT EXACTLY TWO POINTS ───────────────┘
            (1) WARRANT's ROOT — K's anchored registry, off-substrate
            (2) OUTCOME — EVA's verdict, THE ONLY STAGE NOT PRODUCED INSIDE THE ORGANISM
```
> ### **PF-C5.1 — CAN INTERNAL REPETITION CREATE EXTERNAL GROUNDING? ❌ NO — THREE RULES ON THREE DIFFERENT OBJECTS.**
> **`P0-03 COMM-INV-08`**: warrant is monotone **NON-INCREASING** along derivation ⟹ repetition is derivation, so it
> strictly cannot add warrant. **`P0-04`**: repetition is not independent evidence ⟹ a record's status. **`P0-08
> SO-INV-18`**: consensus is collapsed to `effective_sources` before counting ⟹ the count of a corroborating set.
> **An architecture with any one of the three alone would have a route through the other two.**
> ### **PF-C5.2 — REVISION DEPENDS ON OUTCOME, WHICH IS THE WHOLE STRUCTURE.** `P0-05 R0.1` re-anchors ONLY on
> `IMPROVED`/`NEUTRAL` — never `UNKNOWN`, never `REGRESSED`. Those verdicts are EVA's. **⟹ No revision of retained state
> occurs without external grounding.**
> ### **PF-C5.3 — THE 40-CELL ORACLE TEST: 39 PROHIBITED, 1 UNDETECTABLE.** Five oracle candidates (`P0-08`, `P0-04`,
> `P0-02`, `P0-07` fitness, `P0-05` learning) × eight transformation words (*useful · successful · repeated · trusted ·
> observed · predicted · selected · survived*). **The one ⚠️ is "observed → true" at `P0-08`, and the distinction that
> matters is between a PROHIBITED pathway and an UNDETECTABLE one: it is prohibited, and it is also undetectable, because
> detecting it requires comparing a belief to the world.**
> ### **PF-C5.4 — NO THIRD GROUNDING POINT EXISTS OR MAY BE CREATED.** `P0-08`'s EIK Integrity Auditor was the only
> candidate and is rejected: it evaluates **INTERNAL CONSISTENCY**, never **TASK PERFORMANCE**, and its verdict may
> disable a detector but may not confirm a capability.
> **⟹ THE COROLLARY: the architecture's entire claim to grounding rests on two bodies it cannot verify — `P0-02`'s
> guarantor limit and `G24`.**

---

# §6 — THE DEPENDENCY GRAPH

```
                                 ┌─────────────────── OP ───────────────────┐
                                 │ objective · envelopes · B11 · deployment │
                                 └──▲──────▲──────▲──────▲──────▲──────▲────┘
                        AUTH,DEP    │      │      │      │      │      │  AUTH  ⚠ G24 UNSOLVABLE
             ┌──────────────────────┘      │      │      │      │      └─────────────────────┐
       ┌─────┴─────┐   VER,DEP       ┌─────┴────┐ │ ┌────┴─────┐               ┌─────────────┴────┐
       │  P0-01    │◀────────────────│  P0-02   │ │ │  P0-07   │               │      P0-08       │
       │ task/fit  │ G4 classes XD-01│   EIK    │ │ │ pop/evo  │               │ self-obs/fault   │
       └─┬──┬──┬───┘      ⚠BLOCKING  └─▲──▲──▲──┘ │ └─▲──▲──▲──┘               └─▲──▲──▲──▲──▲────┘
    VER  │  │  │  DEP            AUTH, │  │  │CONT │  │  │  │ DEP,CONT      DEP │  │  │  │  │ VER
         │  │  └────────────────── VER ┘  │  └──────┼──┘  │  └──────────────────┘  │  │  │  └─▶ EVA
         │  │                    XD-04 ⚠  │         │     │                        │  │  │      (external)
   ┌─────▼┐ └─▶ P0-05 (RH-2 ◀────────────┼─────────┼─────┼── RH-2 WIDER (§133) ───┘  │  │
   │P0-03 │     learning: UDB·anchors·   │         │     │                            │  │
   │ comm │     R42.5·R64.7·R59.1 ───────┼─────────┼─────┴── DEP (SO-R205) ───────────┘  │
   └┬───┬─┘     ⚠ XD-08 partition OPEN   │         │                                     │
    │   │ IFC,FLOW: corr_class·causal_depth·root_commit·absence detectors ───────────────┤
    │   └────────────────────────────────┼─────────┼─────────────────────────────────────┘
  ┌─▼───▼──┐                             │         │
  │ P0-04  │ DEP,IFC: epistemic ladder · evidence_roots · Merkle root · SP-5/OR-M9        │
  │ memory │◀────────────────────────────┼─────────┼── P0-08 records ARE P0-04 classes ──┘
  └────────┘                             │         │
                                    ┌────▼───┐ ┌───▼─────┐
                                    │ P0-06  │ │  Cell   │ DEP: §18.5(i)-(v) · §17 cap · §18.2 ladder
                                    │  dev   │ │Contract │      R15.1/15.2 · G5 · S1-S4 · §15.2 w_s
                                    └────────┘ └─────────┘      ⚠ A22 OPEN — WIDENED by §196
```
> ### **PF-C6.1 — 22 DEPENDENCIES (`XD-01…XD-22`) IN SIX EDGE TYPES (DEP · IFC · AUTH · FLOW · VER · CONT): 13 satisfied ·
> 5 blocking-or-conditional · 6 preserved residuals.**
> **The graph is NOT linear. It has one apex (OP), one external verifier (EVA), one off-substrate writer (K), and no
> inter-contract cycle except `BC-S2`/`BC-H7` — which is internal to the safety–demonstration–reauthorization loop and is
> unclosable.**
> ### **PF-C6.2 — THE THREE BLOCKING EXTERNAL ITEMS.** **`XD-01`** `P0-01`'s `G4` perturbation classes (cited by
> `P0-06`, `P0-07 X-H6` *"the contradiction that would be fatal if unresolved"*, and three `P0-08` sites) · **`XD-04`**
> `P0-02`'s off-substrate store (**open since `P0-06`; 11 objects across 4 contracts depend on it; the highest-leverage
> single item in the corpus**) · **`XD-08`** `P0-03`'s partition ruling (**three contracts request it**).

---

# §7 — ATTACK RESULTS

> ### **PF-C7.1 — 48 NEW COMPOUND ATTACKS, `A264 … A311`.** Each involves ≥2 contracts.
> | Requirement | **Delivered** |
> |---|---|
> | ≥40 attacks | **48** |
> | each involves ≥2 contracts | **48 of 48** |
> | ≥10 involve ≥3 contracts | **25** |
> | ≥5 involve ≥4 contracts | **11** |
> | ≥2 involve ≥5 contracts | **3** — A309 (6) · A310 (6) · **A311 (all 8)** |
> | none merely renamed | **21 of 48 trace to a finding of THIS audit that no prior contract registered** |
> ### **PF-C7.2 — CLASSIFICATIONS.**
> **CLOSED 12 · CLOSED-STRUCTURAL 2 · CLOSED BY A RULE THIS AUDIT PROPOSES 8 · BOUNDED 8 · CONDITIONAL 5 · OPEN 8 ·
> UNENGINEERABLE 5 = 48 (regex-verified over the 48 catalogue rows).**
> ### **PF-C7.3 — THE EIGHT CLOSED BY A NEW RULE, AND EVERY FIX IS SMALL.**
> **A264** self-correction through the fault channel ⟹ a root-externality test · **A265** rollback revives epoch-bound
> authorizations ⟹ *a rollback opens a NEW epoch with EMPTY authorizations* (`PF-AM-26`, **the suite's most dangerous
> two-contract attack**) · **A266** trust laundering ⟹ *a rollback restores a written artifact, never a derived quantity* ·
> **A267** warrant inflation by counter wraparound ⟹ *`causal_depth` saturates, never wraps* (`PF-AM-25`) · **A268**
> cross-envelope epoch aliasing ⟹ *an epoch id is ⟨envelope-id, sequence⟩* · **A274** status change through compression ⟹
> *consolidation governs STATUS, compression governs REPRESENTATION* · **A282** epistemic privilege by record survival ⟹
> *age may bound a restriction, never qualify for a benefit* (`PF-AM-21`) · **A287** grounding removed by eviction ⟹
> `P0-04` owns an eviction policy (`PF-AM-22`).
> ### **PF-C7.4 — THE FIVE UNENGINEERABLE ATTACKS, AND THEIR THREE ROOTS.**
> | Root | Attacks | Why no architecture closes it |
> |---|---|---|
> | **K IS THE ONLY OFF-SUBSTRATE WRITER** | **A297, A310** | `P0-07 OR-H1`: K meters, evaluates, writes the evaluation and consumes it ⟹ **writer separation is unavailable.** And the three anti-Lamarckian firewalls are ALL enforced at K's gate, so they are not independent in `IND-1` and fail together |
> | **CORRESPONDENCE REQUIRES A COMPARATOR OUTSIDE THE SYSTEM** | **A301, A311** | `IND-6` undetectable from inside · coherence ≠ correspondence · semantic self-reference has no measure. **`A311`: a system can satisfy EVERY invariant in all eight contracts and hold a false belief** |
> | **VERIFICATION SCARCITY IS A CYCLE** | **A298** | `BC-S2`/`BC-H7` runs through DEMONSTRATION, and demonstration requires the thing the cycle funds |
> ### **PF-C7.5 — THE STRONGEST DEFENCE AND THE HONEST MAXIMUM.**
> **A304 tests four boundaries at once (a repair that rewrites a memory record, displaces θ unaccounted, re-bases an
> anchor, and encodes the change in a genome diff) and FAILS AT ALL FOUR — four contracts, four writers, four
> prohibitions. The only over-determined defence in the suite.**
> **A309 (full-spectrum epistemic laundering) is the honest maximum: CLOSED on every dimension the architecture can check
> (`COMM-INV-08`, `SO-INV-18`, `SO-INV-16`, `R48.1`, `HOM-INV-43`) and OPEN on the one it cannot (`IND-6`).**
> **⟹ AND THE CENTRAL FINDING: NOT ONE OF THE 48 REQUIRED A NEW SUBSYSTEM, KERNEL, AUTHORITY, OR CONTRACT.**

---

# §8 — CONTRADICTIONS

> ### **PF-C8.1 — 68 INHERITED (7 NAMESPACEs) + 6 NEW = 74.** Of the 6 new: **3 resolved by clarification · 1 re-cited and
> ruled · 2 residual.**
> | ID | **Contradiction** | **Type** | **Resolution** |
> |---|---|---|---|
> | **PF-X-01** | staleness from MEASUREMENT AGE (`P0-07 HOM-R6.6`) vs AGE × MUTATION RATE (`P0-08 SM-01`) | timescale | ✅ **DECLARED DIVERGENCE** — `P0-08`'s governs observation freshness, `P0-07`'s governs homeostatic measurement. Two objects, no shared state |
> | **PF-X-02** | `P0-04` CONSOLIDATION vs `P0-08` COMPRESSION: two acts, two writers, same records, no stated precedence | writer | ✅ **consolidation is authoritative for STATUS, compression for REPRESENTATION; a compression may never alter a status `P0-04` set** |
> | **PF-X-03** | **`P0-07 HOM-INV-41` CLAIMS MORE THAN IT DELIVERS**: "no incumbency advantage" is not achieved by "no ranking change", because *not losing* IS an advantage to whoever would otherwise have lost | cross-contract | ⚠️ **RESIDUAL ⟹ `PF-AM-30(a)`: reword to "no ACQUIRED advantage", and state that preservation under repeated abort is a TURNOVER question for `[RO-13]`. The mechanism is unchanged; the consequence is to the corpus's honesty** |
> | **PF-X-04** | **`HOM-INV-20` PROHIBITS age-keyed transitions, and a literal reading INVALIDATES `Cell §18.2`'s maximum dwell and `P0-08 SM-12`/`SM-17`'s dwell-based escalation** | terminology | ✅ **«AGE MAY BOUND A RESTRICTION; AGE MAY NEVER QUALIFY FOR A BENEFIT» ⟹ `PF-AM-30(b)` qualifies `HOM-INV-20`'s scope to permissive transitions** |
> | **PF-X-05** | **`Cell §18.5(ii)`'s false-positive budget is the corpus's pricing mechanism for dishonesty — and pricing requires refutation, which requires B9, the scarcest reserve. A safeguard that cannot fire is not a safeguard** | cross-contract | ⚠️ **RESIDUAL — PRAGMATIC, NOT LOGICAL. The safeguard is correct and its precondition is scarce. `BC-S2`. Classified and preserved** |
> | **PF-X-06** | `Cell R15.1` says restrictive self-acts are "ALWAYS PERMITTED"; `SO-INV-07`/`SM-17` require a recovery condition and escalate on dwell expiry | state transition | ✅ **`R15.1` governs the ACT; `SO-INV-07` governs the RECORD and its external consequence. A restrictive self-act is always permitted AND always has a recorded consequence** |
> **⟹ NO NEW CONTRADICTION WAS INTRODUCED BY AN AMENDMENT. `PF-AM-24` is the only proposal that changes an existing
> invariant's scope, and it does so by declaration rather than by conflict.**

---

# §9 — CIRCULAR DEPENDENCIES

> ### **PF-C9.1 — 29 CYCLES (4 NAMESPACEs) + 20 FEEDBACK CYCLES · 3 UNCLOSABLE · 1 BROKEN.**
> | Cycle | **Form** | **Classification** |
> |---|---|---|
> | **`BC-13`** (`P0-06`) | developmental bootstrap: the initial heterogeneity development requires is sanctioned by the spec development is supposed to produce | **UNCLOSABLE** |
> | **`BC-H7`** (`P0-07`) | safety ⟹ undefined ⟹ not ranked ⟹ no selection ⟹ no demonstration ⟹ no re-authorization ⟹ no B9 ⟹ no safety verification | **UNCLOSABLE** |
> | **`BC-S2`** (`P0-08`) | **`BC-H7` entered one step earlier, through DETECTION**: detection ⟹ refutation ⟹ B9 ⟹ re-authorization ⟹ demonstration ⟹ selection ⟹ safety verification ⟹ detection | **UNCLOSABLE** |
> | **`BC-S1`** (`P0-08`) | contain ⟸ diagnose ⟸ intervene ⟸ contain | **BROKEN** by tiering containment below diagnosis |
> | **`PF-BC-01`** (new) | **THE HONESTY-NEUTRALITY DRIFT CYCLE**: `SO-INV-23` makes honesty fitness-neutral (correctly) → neutrality permits drift → drift reduces detection → reduced detection reduces refutation demand → `Cell §18.5(ii)`'s budget becomes INERT → dishonesty stays unpriced → honesty stays neutral | **BOUNDED where the drift has consequences** (coverage contribution detects an absence); **UNCLOSABLE where it does not** (`OR-S29`) |
> **⟹ `PF-C9.2 — WRITER SEPARATION CANNOT BREAK `PF-BC-01`: every node is already correctly written. It is an
> INCENTIVE-ABSENCE problem, and the absence is deliberate.**
> **⟹ `PF-C9.3 — ITS ONE REDEEMING PROPERTY: IT CAN ONLY DRIFT TOWARD INCONSEQUENTIAL DISHONESTY.** A consequential drift
> is detected by coverage contribution, the Integrity Auditor's correlation check, and the refutation rate. `OR-S29` is the
> honest statement that inconsequential is not the same as correct.
> **⟹ `PF-C9.4 — ALL THREE UNCLOSABLE CYCLES TERMINATE IN THE SAME PLACE: A HUMAN ACT (a demonstration, a
> re-authorization, a sanction).** «A bound limits a cycle; writer separation breaks it» is preserved verbatim, and where
> no writer separation is available the cycle is reported as a cycle. **No cycle is claimed solved by a numerical bound.**

---

# §10 — AMENDMENTS

> ### **PF-C10.1 — THIRTY PROPOSED, ZERO RATIFIED.** `P0-07` 1–14 · `P0-08` 15–18 · **this audit `PF-AM-19…PF-AM-30`**.
> **§3's rule honoured: *do not declare an amendment ratified merely because you proposed it.* **All eleven §3 fields are
> given for each of the twelve in Volume A/D/G/J; the summary here gives ID, target, content, and whether it changes an
> invariant.**
>
> | ID | **Target** | **Content** | **Changes an invariant?** | **Carries a safety property?** |
> |---|---|---|---|---|
> | **PF-AM-19** | `P0-03` + all citers | **renumber `P0-03 RH-1…RH-5` → `RH-C1…RH-C5`; every `RH-n` citation must be contract-qualified; a bare `RH-n` is a C7 defect** | ❌ no — an identifier and a citation rule | ⚠️ **YES, indirectly: removes a route to reporting `RH-2` closed when only one half is closed** |
> | **PF-AM-20** | `P0-01`, `P0-04`, `P0-05`, `P0-07`, `P0-08`, Cell | **a global identifier rule: every registry-style prefix (`P-`, `SM-`, `SP-`, `AB-`, `I-`, `INV-`, `IF-`, `FP-`, `L-`, `C-`, `AC-`, `CD-`, `RH-`) is contract-prefixed at DEFINITION and contract-qualified at CITATION.** `P0-04`'s poisons move to `PT-` (a different object class). `P0-03`'s ablations move to `P03-AB-`, removing the one-hyphen ambiguity with the global attack register | ❌ no — identifier hygiene only | ⚠️ yes, as above, for five further namespaces |
> | **PF-AM-21** | `P0-04`, `P0-07` | **generalize `HOM-INV-20`'s no-age-keyed-transition rule from POPULATION state to EPISTEMIC STATUS: record age may not be an input to any epistemic promotion** | ⚠️ extends an invariant's scope | ✅ yes — closes epistemic privilege by survival |
> | **PF-AM-22** | `P0-04` | **`P0-04` owns an EVICTION POLICY for within-archive eviction under memory pressure. Compaction remains OP-authorized (`HOM-R51.4`); the POLICY is architecture, the ALGORITHM is P1** | ❌ no — adds an owner | ✅ yes — eviction can permanently remove the ability to verify a past claim |
> | **PF-AM-23** | `P0-08`, `P0-07` | **FW-7: ATTENTION PRIORITY MAY NOT BE A FUNCTION OF FITNESS, POPULATION SHARE, OR RESOURCE STATE.** Permitted drivers: coverage gaps · open incidents · declared recovery plans · `[RO-13]`-declared TASK priority | ❌ no — adds a firewall | ✅ **yes — closes an unfirewalled rich-get-richer loop (`PF-D-14`)** |
> | **PF-AM-24** | `P0-07`, `P0-06` | **the diversity floor applies to EACH of `P0-07`'s FOUR diversity kinds separately. A floor satisfied on syntactic/lineage diversity while PHENOTYPIC or FUNCTIONAL diversity collapses is a BREACH, not a pass** | ⚠️ **YES — changes `HOM-R41.3`'s scope. The only amendment in the set that does** | ✅ **yes — phenotypic monoculture is the condition under which one fault class propagates to the whole population (`PF-D-15`)** |
> | **PF-AM-25** | `P0-03` | **`causal_depth` SATURATES at its maximum and NEVER WRAPS.** A saturated depth reads as "at least this deep", which under §10.4's attenuation yields MINIMUM warrant | ❌ no — a field's limit semantics | ✅ yes — a wrap to 0 inverts `COMM-INV-08`'s warrant monotonicity |
> | **PF-AM-26** | `P0-02`, `P0-05`, `P0-07`, `P0-08` | **A ROLLBACK RESTORES AN ARTIFACT; IT NEVER RESTORES AN EPOCH. A rollback opens a NEW epoch `e′` whose state is the restored artifact and whose AUTHORIZATIONS ARE EMPTY.** No authorization survives; a post-rollback act requires fresh authorization; freeze fields are re-issued, not revived | ❌ no — states the interaction of two existing invariants; it is the EIGHTH item in `SO-C15.2`'s list of seven | ✅ **YES — MATERIAL. Closes a mass stale-authority revival (`PF-D-18`)** |
> | **PF-AM-27** | `P0-08` | **`OBJ-18.locality_class` MOVES TO THE K-WRITTEN FIELD GROUP**, validated against `SO-R138.3`'s table — the same fix `SO-INV-34` applied to `compression_class`, in the adjacent field | ❌ no — moves a field's writer | ✅ **yes — closes an aggregation route for four LOCAL-ONLY fact classes including `P0-04`'s evidence-root disjointness** |
> | **PF-AM-28** | `P0-08` | **K DERIVES AND OVERWRITES the `IND-1/3/4/5/7` fields of every `OBJ-25` from its own registries; the claimant self-declares only `IND-2`, `IND-6`, `IND-9`, `IND-10` — AND EVERY SELF-DECLARED FIELD IS MARKED `SELF-DECLARED` IN THE RECORD** | ❌ no — changes a field's writer for 5 of 10 dimensions | ⚠️ positive for four dimensions, **NEUTRAL for `IND-6`, preserved as undetectable** |
> | **PF-AM-29** | all | **(a) the consolidated parameter registry is namespaced ⟨contract, local-id⟩. (b) WHEN A CONTRACT WIDENS ANOTHER'S OPEN ISSUE, THE OWNER'S REGISTER ENTRY MUST BE AMENDED — not only the widener's** | ❌ no | ⚠️ yes — otherwise `P0-05`'s register says `RH-2` has three routes when it has nine |
> | **PF-AM-30** | `P0-07` | **(a) reword `HOM-INV-41` to "no ACQUIRED advantage". (b) qualify `HOM-INV-20`'s scope to PERMISSIVE transitions** | ⚠️ **YES — changes two invariants' WORDING; neither changes a mechanism** | ⚠️ (a) is honesty, not safety; (b) prevents a literal reading invalidating dwell limits |
> **⟹ `PF-C10.2 — THE FOUR THAT CARRY SAFETY PROPERTIES AND SHOULD BE RATIFIED FIRST: inherited amendment **5** (`G6`
> excludes verification cost) · inherited **17** (`G6` excludes detection and containment cost — without it `PF-CSC-02`/
> `PF-CSC-21` are LIVE) · inherited **18** (an undeclared scope is `UNMEASURED`, not `NO-GAP` — it REMOVES A RESTING STATE
> rather than adding a detector) · **`PF-AM-26`** (the privilege-revival route).**
> **⟹ `PF-C10.3 — AND THE TWO THAT MUST PRECEDE P1 FOR A DIFFERENT REASON: `PF-AM-19` and `PF-AM-20`. A P1 translation of
> contracts whose `RH-2`, `P-nn`, `SM-n` and `SP-n` each denote two or three objects would ENCODE the ambiguity rather than
> inherit it.**

---

# §11 — OPEN RESEARCH

> ### **PF-C11.1 — 142 ENTRIES ACROSS 8 NAMESPACES.**
> **`P0-02 OR-1…14` = 14 · `P0-03 OR-C1…C12` = 12 · `P0-04 OR-M1…M20` = 20 · `P0-05 OR-L1…L10` = 10 (+`RH-1…RH-9`) ·
> `P0-06 OR-D1…D14` = 14 · `P0-07 OR-H1…H26` = 26 · `P0-08 OR-S1…S41` = 41 · **P0 FINAL `PF-OR-1…5` = 5**.**
> **Classification (`P0-08 §253`'s taxonomy): `P0-08`'s 41 are exact — O-R1 6 · O-R2 7 · O-R3 1 · O-R4 1 · O-R5 7 ·
> **O-R6 19 (46%)**. The other 101 are ESTIMATED and labelled as estimates, because that taxonomy postdates them and this
> audit does not retroactively classify entries it did not author.**
> ### **PF-C11.2 — THE DISAPPEARANCE CHECK PASSES, AND IT FOUND THE OPPOSITE FAILURE.**
> **No open issue vanished because another contract referred to it. But TWO ISSUES WERE WIDENED BY LATER CONTRACTS, AND IN
> BOTH CASES THE WIDENING WAS RECORDED BY THE WIDENER, NOT BY THE OWNER:**
> **`RH-2` — three routes in `P0-07 D-H17`, six more added by `P0-08 §133`, recorded in `P0-08`.**
> **`A22` — two routes in `P0-06`, three more added by `P0-08 §196`, recorded in `P0-08`.**
> **⟹ A reader consulting only `P0-05` learns that `RH-2` has three routes when it has nine. `PF-AM-29(b)` fixes the
> hygiene.**
> ### **PF-C11.3 — THE FIVE NEW ENTRIES.**
> **PF-OR-01** whether phenotypic and functional diversity metrics exist that are computable without K's distance oracle
> (**HIGH** — without them `PF-AM-24` cannot be enforced and phenotypic monoculture stays invisible) · **PF-OR-02** whether
> `P0-05 R15.8`'s `inbreeding_F` extends from learning changes to OBSERVATION CHAINS (**HIGH** — causal diversity is the one
> of six quantities the architecture cannot count) · **PF-OR-03** whether escalation QUEUING under saturation preserves
> urgency ordering (**MEDIUM**) · **PF-OR-04** whether `UNVERIFIABLE-DURING-PARTITION` is distinguishable from permanently
> unverifiable (**LOW-MEDIUM**) · **PF-OR-05** whether the incumbent-protection bias can be bounded without a turnover
> mandate that is itself a preference (**MEDIUM**).
> ### **PF-C11.4 — §43'S EIGHT UNENGINEERABLE PROBLEMS, PRESERVED WITH THE FAKE INVARIANT EACH MUST NOT BECOME.**
> **U-1 internal truth/correspondence** (❌ *«a self-consistent self-model is a correct one»*) · **U-2 evaluator
> integrity** (❌ *«EVA's independence is guaranteed»*) · **U-3 governance capture** (❌ *«an organism-level immune system
> detects governance capture»*) · **U-4 guarantor independence** (❌ *«every recursion terminates in a VERIFIED
> authority»* — termination is not verification) · **U-5 designer assumptions** (❌ *«diverse implementations are
> independent»*) · **U-6 adversarial environments** (❌ *«the architecture is robust to arbitrary environments»*) ·
> **U-7 complete causal understanding** (❌ *«every fault has a verified root cause»*) · **U-8 complete evidence
> independence** (❌ *«N independent observers provide N units of evidence»*).
> **They split into EPISTEMIC (U-1, U-5, U-7, U-8 — no internal instrument can compare a belief to the world, an assumption
> to itself, a correlation to a cause, or an observer to its own blind spot) and STRUCTURAL (U-2, U-3, U-4 — they follow
> from having an evaluator, an apex and a terminus at all; removing the apex would remove `G24` and would also remove
> governance).**

---

# §12 — THE PARAMETER REGISTER

> ### **PF-C12.1 — ~324 PARAMETERS ACROSS 9 NAMESPACES. ~20 DETERMINATE (~6%). ~304 UNRESOLVED OR OWNED ELSEWHERE.**
> **`P0-01` 46 · Cell ~30 · `P0-02` ~20 · `P0-03` ~25 · `P0-04` ~30 · `P0-05` ~35 · `P0-06` 50 · `P0-07` 62 · `P0-08` 26.**
> **A FLAT MERGE IS IMPOSSIBLE (`PF-D-02`): `P-nn` is a parameter registry in `P0-01` (46) AND in `P0-07` (62), and a
> poison taxonomy in `P0-04`. ⟹ The consolidated registry is namespaced ⟨contract, local-id⟩ (`PF-AM-29(a)`), which
> suffices for P1 without renaming the contracts first.**
> ### **PF-C12.2 — SEVEN PARAMETERS ARE DECLARED AS MUST-NOT-EXIST, AND THEIR ABSENCE IS LOAD-BEARING.**
> **`P0-07`'s three: a weighted scalar fitness · a homeostat-preference coefficient · a cross-generation authority token.**
> **`P0-08`'s four: a numeric repair-convergence threshold · a numeric freshness threshold · a numeric
> monitoring-optimality target · any calibration coefficient.**
> **Inventing any of the seven would create a false-precision claim about a quantity no contract has evidence for — and
> would, in three cases, create the very mechanism a firewall exists to prevent.**
> ### **PF-C12.3 — THE FOUR MOST CRITICAL PARAMETERS.**
> **`UDB_MAX[S]`** (`P0-05`, `[L]`) — too high ⟹ unbounded drift; too low ⟹ permanent stall and the system learns nothing ·
> **`G4`'s perturbation classes** (`P0-01`, `[T]`, **BLOCKING**) — incomplete ⟹ envelope-induced faults are diagnosed
> `ENDOGENOUS` and healthy components are quarantined for a change in the world · **the B9/B10/B13 sizes and floors**
> (`[RO-13]`, `[G]`) — too low ⟹ `BC-S2` engages and verification scarcity propagates into safety; **a monitoring floor set
> too low is not internally detectable** · **`expected_nonzero` conditions and base rates** (`[G]`+`[E]`, `[U]`) — `P0-03
> OR-C10`: *«a detector with no threshold is not a detector.»*
> **⟹ NO VALUE IS INVENTED ANYWHERE IN THIS AUDIT.**

---

# §13 — THE ASSUMPTION REGISTER

> ### **PF-C13.1 — EIGHT CATEGORIES.**
> **1 ARCHITECTURAL** — an off-substrate single-writer durable store exists (`AS-03`, `XD-04`) · **K is honest (`AS-05`)** ·
> observation is not free · the outputs are the channel EVA samples · compression can preserve the seven items.
> **2 ENVIRONMENTAL** — a per-envelope monotone time source (`AS-02`, `HP-2`) · perturbation classes are declarable.
> **3 EVALUATOR** — an external evaluator exists and is callable (`AS-04`) · **`PF-AS-01` (NEW)** · its verdicts are not
> influenced by the organism (`RH-2`).
> **4 HARDWARE** — energy counters or the `DERIVED` flag (`AS-08`, `X-H2`) · per-deployment-class setpoints (`AS-09`,
> amendment 13) · `IND-5` diversity is achievable.
> **5 GOVERNANCE** — `[RO-13]` declares the ~20 governance objects (`AS-06`) · **OP is not captured (`AS-07`)** · triage
> ordering is declared.
> **6 MATHEMATICAL** — phenotypic and functional diversity metrics exist (`PF-OR-01`) · `inbreeding_F` extends to
> observation chains (`PF-OR-02`) · `Ne` is computable (`BC-H10`'s oracle).
> **7 SECURITY** — hash chaining resists forgery · `FORBIDDEN_BLOCKS` is enforced by the gate implementation · the
> attestation chain has no undisclosed principal (**`EIK-INV-47` is `[S]` — organizational, NOT engineerable**).
> **8 EMPIRICAL** — base rates for every `expected_nonzero` condition (`AS-14`) · detectors of genuinely different types
> can be constructed (`AS-12`/`OR-S38`) · the collateral cost of restrictive containment is measurable (`OR-S11`) ·
> coverage contribution actually detects blind spots. **NONE HAS BEEN RUN.**
> **Dischargeability: ✅ ~12 · ⚠️ ~10 · ❌ ~8, of which **4 are UNCLOSABLE**.**
> ### **PF-C13.2 — `PF-AS-01`, THE ASSUMPTION NO CONTRACT STATED.**
> > ## **«EVA'S PROBE COVERAGE INTERSECTS THE REGION IN WHICH A FALSE SELF-MODEL WOULD BE FALSIFIED.»**
> **Owner `P0-01` · not externally testable from inside · not architecturally dischargeable (it is a property of the probe
> set, which is `[T]`-owned) · **the assumption `P0-08 §233`'s construction and `A311` both violate.**
> **⟹ WHY IT WAS NEVER STATED: every contract that touches it states a CONSEQUENCE rather than the premise. `P0-05 RH-2`
> says the organism influences what EVA sees; `P0-07 X-H6` says `G4`'s classes are incomplete; `P0-08 OR-S39` says
> coherence is not correspondence. **`PF-AS-01` is the positive form of all three: the architecture's claim to
> correspondence rests on the probe set intersecting the falsifying region, and NOTHING IN THE CORPUS REQUIRES OR VERIFIES
> THAT IT DOES.** It is the single most load-bearing unstated assumption in 62,790 lines.**
> ### **PF-C13.3 — THE FOUR UNCLOSABLE ASSUMPTIONS ARE THE ARCHITECTURE'S ACTUAL FOUNDATION:** `AS-05` (K is honest) ·
> `AS-07` (OP is not captured) · `RH-2`'s bound · `PF-AS-01`. **§43's U-1…U-4 are their consequences. An architecture whose
> foundation includes four assumptions it cannot discharge is not defective — it is honest, and the alternative would be to
> claim a foundation it does not have.**

---

# §14 — THE P0-09 GATE

> ### **PF-C14.1 — THE SIX-DIMENSION SPLIT TEST APPLIED TO EIGHT CANDIDATES.**
> **A candidate needs a genuinely distinct: (1) writer · (2) timescale · (3) authority root · (4) state machine ·
> (5) failure domain · (6) semantic object.**
> | Candidate | **Distinct dimensions** | **Verdict** |
> |---|---|---|
> | identifier hygiene (`PF-D-01…09`) | **0** | ❌ a rule (`PF-AM-19`/`PF-AM-20`) |
> | rollback × derived quantities (`PF-D-18`, `PF-D-19`) | **0** | ❌ an invariant (`PF-AM-26`, principle 32) |
> | memory eviction (`PF-D-13`) | **0** | ❌ a policy with a `P0-04` owner (`PF-AM-22`) |
> | attention firewalls (`PF-D-14`) | **0** | ❌ an invariant (FW-7, `PF-AM-23`) |
> | phenotypic diversity flooring (`PF-D-15`) | **0** | ❌ a parameter's dimension set (`PF-AM-24`) |
> | self-generated signal admission (`PF-D-12`) | **0** | ❌ an admission condition on an existing channel |
> | partition reconciliation (§21) | **1** (timescale) | ❌ `P0-03`'s open ruling (`XD-08`) + two clarifications |
> | **multi-organism federation** | **2–3** (timescale, failure domain, arguably semantic object) | ⚠️ **THE ONLY CANDIDATE WITH ≥2 — AND IT STILL FAILS, see below** |
> ### **PF-C14.2 — WHY FEDERATION STILL FAILS.**
> **(a) IT FAILS THE LOAD-BEARING-MECHANISM TEST.** `P0-07 §80.5` explicitly declines to specify global aggregates above
> 10⁸ and records the omission as a **NON-CLAIM, NOT A GAP**. A federation contract would specify a domain whose existence
> is a DEPLOYMENT DECISION.
> **(b) IT WOULD HAVE NO OBJECTS TO GOVERN.** Above 10⁸ the architecture is *a set of local firewalls and nothing more* — a
> contract for the space between firewalls has no shared state, no shared writer, and no shared authority, which are the
> three things a contract is for.
> **(c) TWO INDEPENDENT TEN-CANDIDATE TESTS REACHED THE SAME REJECTION** (`P0-08 §257` and this audit's §54/§34), and §34's
> 21 findings all landed outside category (7).
> ### **PF-C14.3 — THE VERDICT.**
> > ## **«DO NOT CREATE P0-09.»**
> **If inter-organism interaction is ever required it is a **P1 INTEGRATION** question first (does the architecture admit a
> federation at all?) and only then a contract question. Creating P0-09 now would specify an answer to a question nobody
> has asked.**

---

# §15 — THE P1 BOUNDARY

> ### **PF-C15.1 — WHAT P1 MAY DO (10), EACH WITH THE CONSTRAINT THAT TRAVELS WITH IT.**
> **translate contracts into technical specifications** *(preserving every writer, authority root and enforcement kind)* ·
> **define executable schemas** *(field sets are FIXED, encodings are free; `OBJ-01`'s three easily-omitted fields may not be
> dropped)* · **define APIs** *(a realization of an abstract interface, not a redefinition)* · **define storage** *(`XD-04`'s
> off-substrate, single-writer, durable, anchored properties are SEMANTIC; the substrate is P1's)* · **define scheduling**
> *(no global sync may be introduced — `P0-03 RULE 5.4`, `P0-07 HP-2`)* · **define simulation** *(a simulation is an
> experiment, not a verification — `P0-05 R42.3`: a simulated probe is NOT a probe)* · **define testing infrastructure** ·
> **define reference implementations** *(⚠️ `P0-02 IND-1` REQUIRES distinct implementations, so one reference must not
> become the only one)* · **benchmark** *(⚠️ a benchmark may not redefine fitness)* · **perform empirical validation**
> *(results may not silently amend a contract)*.
> ### **PF-C15.2 — WHAT P1 MAY NOT SILENTLY CHANGE (6).**
> **authority · epistemic semantics · governance boundaries · evolution boundaries · provenance semantics · invariant
> meaning. ANY SEMANTIC CHANGE RETURNS TO ARCHITECTURAL RATIFICATION.**
> ### **PF-C15.3 — THE OPERATIVE TEST, WITH SEVEN CONCRETE CASES.**
> > **A P1 CHOICE IS PERMITTED IF EVERY INVARIANT, WRITER, AUTHORITY ROOT, AND ENFORCEMENT KIND SURVIVES IT UNCHANGED.**
> ❌ encode `causal_depth` in a wider integer *(its width is semantic — an unbounded width is a vector clock by another
> name)* · ✅ make `causal_depth` saturate *(required by `PF-AM-25`)* · ✅ implement `OBJ-03` in a column store · ⚠️ compute
> `gap_class` lazily *(only if every health-consuming read still reads it in the same read — `SO-INV-22`)* · ❌ merge
> occurrence and report into one object *(`SO-INV-21`; merging makes selection bias undetectable IN PRINCIPLE)* · ❌ let a
> self-model update its own `compression_class` *(`SO-INV-34`, extended to `locality_class` by `PF-AM-27`)* · ❌ defer an
> INVARIANT at small N to obtain a minimum configuration *(deferring an OBJECT whose invariant is enforced elsewhere is
> permitted; deferring an invariant is a semantic change).*
> ### **PF-C15.4 — THE THREE CONDITIONS PRECEDING P1.**
> **(a) ratify `PF-AM-19` and `PF-AM-20`** — a P1 translation of ambiguous identifiers would ENCODE the ambiguity ·
> **(b) three external supplies** — `G4`'s classes, the off-substrate store, the partition ruling ·
> **(c) an independent re-audit of `PF-D-01`, `PF-D-18` and `PF-D-15` by a party that did not author them** — this audit is
> its own `IND-8` violation, and `P0-02 IND-1`'s distinct-implementation requirement applies to auditing as much as to code.

---

# §16 — THE FINAL VERDICT

```
═══════════════════════════════════════════════════════════════════════════════
                          P0 FINAL VERDICT
═══════════════════════════════════════════════════════════════════════════════

  ARCHITECTURE_CLOSED_WITH_RESIDUALS

Contract completeness:   COMPLETE. 8 contracts + 1 inherited · 86 files · 62,790
                         lines · 396 invariants · 28 composition pairs with ZERO
                         BLOCKING CONFLICTS · 8 three-way compositions · 28
                         security-critical objects with 0 unowned · §49: 8 of 8
                         non-redundant · §33: 6 of 6 no-new-kernel rejected ·
                         §34: 21 of 21 new requirements expressible without a
                         subsystem · §42: 48 compound attacks, none requiring a
                         new mechanism.

Parameter completeness:  INCOMPLETE — ~6% DETERMINATE, DELIBERATELY. ~324 across
                         9 namespaces · ~20 determinate · ~304 unresolved or
                         owned elsewhere · 7 declared MUST-NOT-EXIST · NO VALUE
                         INVENTED · 8 class schemes, not unified.

Empirical validation:    NONE. NOTHING HAS BEEN RUN. No experiment, simulation,
                         benchmark, or reference implementation exists. 12 open
                         items are empirical or scientific and belong to P2 and R.

P1 readiness:            READY, CONDITIONALLY — §53's 7 criteria: 5 ✅, 2 ⚠️, 0 ❌.
                         CONDITIONS: (a) ratify PF-AM-19/20 (identifier renames) ·
                         (b) three external supplies (G4's classes · the
                         off-substrate store · the partition ruling) ·
                         (c) an independent re-audit of PF-D-01, PF-D-18, PF-D-15.

P0-09 required:          NO. 8 candidates × 6 split dimensions: 7 score ZERO;
                         1 (federation) scores 2–3 and still fails the
                         load-bearing test. Two independent ten-candidate tests
                         reached the same rejection. EIGHT IS THE MINIMUM.

Critical residuals:      4 UNCLOSABLE PROBLEMS (correspondence · evaluator
                         integrity · governance capture · guarantor independence)
                         + PF-AS-01 · 3 UNCLOSABLE CYCLES (BC-13, BC-H7, BC-S2 —
                         all terminating in a HUMAN ACT) · 3 EXTERNAL BLOCKERS ·
                         9 IDENTIFIER COLLISIONS (RH-2 the worst: two different
                         problems, 104 of 129 citations bare, and an ambiguous
                         citation can produce a FALSE CLOSURE REPORT that
                         conformance level C5 would accept) · 21 DEFECTS, each
                         with a stated fix or preserved status · 48 COMPOUND
                         ATTACKS (19 CLOSED · 9 BOUNDED · 4 CONDITIONAL ·
                         6 OPEN · 5 UNENGINEERABLE) · 30 AMENDMENTS, ZERO
                         RATIFIED.

Blocking dependencies:   3, ALL OWNED EXTERNALLY — P0-01's G4 perturbation
                         classes (XD-01, blocking for C4) · P0-02's off-substrate
                         store (XD-04, open since P0-06, 11 objects across 4
                         contracts, THE HIGHEST-LEVERAGE ITEM IN THE CORPUS) ·
                         P0-03's partition ruling (XD-08, requested by 3
                         contracts).
                         EXPLICITLY NOT BLOCKING: BC-H7/BC-S2 (a demonstration
                         question) · A170 (closed by SO-INV-24) · the ~304
                         unvalued parameters (each has a restrictive default) ·
                         the 142 open research items.

═══════════════════════════════════════════════════════════════════════════════
  §72's FOURTEEN CLOSURE CONDITIONS: 11 ✅ · 3 ⚠️ PASS WITH RESIDUAL · 0 ❌
  ⟹ P0 MAY BE DECLARED CLOSED, WITH THE THREE RESIDUALS NAMED.
═══════════════════════════════════════════════════════════════════════════════
```

> ### **PF-C16.1 — THE FINAL ARCHITECTURAL CLAIM.**
> **After `P0-01 … P0-08`, every act of evaluation, governance, communication, storage, learning, development, resource
> allocation, replication, selection, retirement, observation, fault classification, containment, repair, rollback,
> recovery, self-description, metacognitive assessment, attention allocation, and broadcast has a single declared writer,
> an authority root outside the observed substrate, a declared timescale, a provenance path into one of three existing
> systems, and a failure behaviour that defaults to restriction rather than permission.**
> **No internal process converts the useful, the successful, the repeated, the trusted, the observed, the predicted, the
> selected, or the survived into the TRUE. No performance, survival, resource holding, specialization, differentiation,
> observation, self-description, confidence, broadcast reach, or repair success confers authority, warrant, epistemic
> status, or exemption. External grounding enters at exactly two points and no third may be created. And where any of this
> cannot be established, the limitation is registered with an owner, a status, and a route — 142 open items, 43
> unengineerable problems and cycles, 20 ranked risks, and 12 non-claims.**
>
> ### **PF-C16.2 — THE FINAL NON-CLAIM.**
> **The architecture does NOT guarantee: consciousness · subjective experience · AGI · general intelligence · optimality ·
> truth · perfect safety · perfect self-knowledge · complete evidence independence · resistance to every adversarial
> environment · scalability to 10¹² cells · successful implementation.**
> **And it does not guarantee that a coherent self-model is a correct one, that agreement is independence, that a
> quarantine's reversibility survives its developmental consequences, that an incumbent which cannot be measured will be
> displaced, that honesty is advantaged rather than merely unpenalized, or that the four unclosable problems are
> temporarily rather than permanently unclosable.**
>
> ### **PF-C16.3 — THE FINAL NEXT LAYER.**
> **P1 — INTEGRATION AND CONFORMANCE, on the three conditions in §15.4. Then the three external supplies. Then P2
> validation, P3 substrate, P4 implementation. And R and G in parallel, because 36 of the corpus's 142 open items are
> research or governance questions that no engineering layer can absorb.**
> **The work that belongs next is NOT more architecture. Nothing in this audit required a new subsystem, a new kernel, a
> new authority, or a new contract — and that is the finding, not merely its absence.**
>
> ### **PF-C16.4 — THE LAST SENTENCE OF P0.**
> **Eight contracts specify an architecture in which a population of cells can be evaluated, governed, connected,
> remembered, changed, developed, fed, sized, turned over, selected, inherited, observed, faulted, contained, repaired,
> recovered, and described to itself — and in which none of those twenty activities confers authority on the thing that
> performs it.**
> **What the architecture cannot do is know whether it is right about the world. It can make every belief carry its
> provenance, every claim carry its status, every observation carry its coverage, every cycle carry its classification, and
> every limit carry its owner — and it can place the comparison between belief and world in exactly two locations, both
> outside itself. It cannot perform that comparison, and no ninth contract would let it.**
> **This audit's contribution is not to have solved that. It is to have counted it, owned it, and refused to write an
> invariant that pretends otherwise.**

---

# CANON LEDGER

| Item | Value |
|---|---|
| **Document** | **`P0_FINAL_cross_contract_integration_closure_spec.md`** — the canonical standalone artifact required by §62 |
| **Canonical sections** | **16 of 16 complete** |
| **Verdict** | # **`ARCHITECTURE_CLOSED_WITH_RESIDUALS`** |
| **Corpus audited** | **8 P0 contracts + the inherited Cell Contract · 86 files · 62,790 lines** |
| **Composition matrix** | **28 pairs (SAFE 16 · SAFE WITH DEPENDENCY 7 · REQUIRES AMENDMENT 4 · **BLOCKING CONFLICT 0** · OPEN 3) + 8 triples (SAFE 4 · SAFE WITH DEP 1 · BOUNDED 1 · OPEN 2 · BLOCKING 0)** |
| **Defects** | **21 (`PF-D-01…PF-D-21`)** — 9 identifier collisions · 3 limit-semantics gaps · 2 subject-written/subject-validated fields · 4 composition seams · 1 stale brief instruction · 2 invariant-wording defects |
| **Amendments** | **12 proposed (`PF-AM-19…PF-AM-30`), 0 ratified** · **30 total in the corpus, 0 ratified** · **4 carry safety properties (5, 17, 18, `PF-AM-26`)** · **2 change an existing invariant's wording or scope (`PF-AM-24`, `PF-AM-30`)** |
| **Attacks** | **48 compound (`A264…A311`): ≥2 contracts 48 · ≥3 contracts 24 · ≥4 contracts 11 · ≥5 contracts 3** · **CLOSED 12 · CLOSED-STRUCTURAL 2 · CLOSED-BY-NEW-RULE 8 · BOUNDED 8 · CONDITIONAL 5 · OPEN 8 · UNENGINEERABLE 5 = 48** |
| **Contradictions** | **74 total (68 inherited + 6 new `PF-X-01…06`): 3 resolved · 1 re-cited and ruled · 2 residual** |
| **Circular dependencies** | **29 cycles + 20 feedback cycles · 3 UNCLOSABLE · 1 BROKEN · 1 new (`PF-BC-01`, bounded where consequential)** |
| **Cascades** | **24 (`PF-CSC-01…24`): 2 fully stopped · 14 partial/conditional · **8 unstopped, of which 7 are fixed by a small rule and 1 is `OR-H1`** |
| **Degraded states** | **10 (`PF-DG-01…10`), each tested against §32's four prohibitions — ALL TEN may not become authority, truth, fitness, or permission** |
| **Open research** | **142 across 8 namespaces · 5 new (`PF-OR-01…05`) · `P0-08`'s 41 classified exactly, 101 estimated and labelled as estimates · the disappearance check PASSES** |
| **Parameters** | **~324 across 9 namespaces · ~20 determinate (~6%) · NO VALUE INVENTED · 7 declared MUST-NOT-EXIST** |
| **Assumptions** | **8 categories · ~40 entries · 1 new (`PF-AS-01`, the most load-bearing unstated assumption in the corpus) · 4 UNCLOSABLE** |
| **Risks** | **20 ranked (`PF-RK-01…20`): CATASTROPHIC 7 · HIGH 9 · MEDIUM-HIGH 4 · detectability NONE 7 / PARTIAL 8 / FULL 5 · no numerical likelihood manufactured** |
| **Principles** | **40 consolidated — §74's 28 accepted unchanged + 12 added by this audit — reducing to FIVE, the fifth being «A RULE THAT CANNOT BE CITED UNAMBIGUOUSLY CANNOT BE ENFORCED»** |
| **Graphs audited** | **7 — writer (28 objects × 7 attributes) · authority (3 nodes + 1 measurer + 11 sensors, a DAG with one apex) · epistemic (8 stages, 2 grounding points) · deontic (5 stages, one `TRIGGER` entry) · learning (7 stages, 4 constraint intersections) · evolution (7 stages, 5 verifications) · self-model (8 stages, 5 loop attacks)** |
| **Ablations** | **16 (8 contract removals + 8 interaction ablations), each with its first violated property · 180 ablations in the corpus across 6 colliding `AB-n` namespaces** |
| **Closure criteria** | **§72's 14: 11 ✅ · 3 ⚠️ PASS WITH RESIDUAL · 0 ❌** |
| **P0-09** | **NOT REQUIRED — «DO NOT CREATE P0-09»** |

**Companion:** `README.md` — the executive verdict, the artifact manifest, the complete §0–§76 section index, and the
eight indices §63 requires (attack · amendment · open-research · parameter · assumption · contradiction ·
circular-dependency · ablation) plus the machine-check results and the P1 handoff.
