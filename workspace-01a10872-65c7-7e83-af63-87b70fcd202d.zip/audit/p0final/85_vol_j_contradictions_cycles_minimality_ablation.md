# P0 FINAL — VOLUME J (§47–§51)
## The Fresh Contradiction Search, the Global Circular-Dependency Audit, the Minimality Audit, the Sixteen Ablations, and the Compositional-Safety Theorem Attempt

---

# §47 — THE CONTRADICTION AUDIT

> ### **PF-R47.0 — THE METHOD.** **[NORMATIVE]**
> **§47: *perform a FRESH search; do not reuse previous contradiction counts.* Searched across all 75 files for
> contradictions introduced by: amendments · terminology · state transitions · authority changes · cross-contract
> dependencies · writer changes · timescale differences.**
>
> ### **PF-R47.1 — THE CORPUS'S EXISTING CONTRADICTION REGISTERS, MEASURED.**
> | Contract | Namespace | **Count** | Status as reported by its owner |
> |---|---|---|---|
> | **`P0-03`** | `X-C`, `X-D` | **2** | `X-C` (root-equality dedup does not catch common causes) — *"the most consequential defect this package finds"*; `X-D` (vector clocks are a type error) — resolved by rejection |
> | **`P0-04`** | `X-*` | **13** | includes the three OPEN attacks' underlying contradictions |
> | **`P0-05`** | `X-*` | **20** | includes `D-L1` (*bounded steps, unbounded walk*) — resolved by `R0.1`'s UDB |
> | **`P0-06`** | `X-D1 … X-D16` | **16** | `X-D6` = `A22`'s underlying contradiction, OPEN; `X-D15` UNRESOLVED→`P0-03` |
> | **`P0-07`** | `X-H1 … X-H15` | **15** | **10 resolved · 4 open · `X-H6` named *"the contradiction that would be fatal if unresolved"*** |
> | **`P0-08`** | `X-S1`, `X-S2` | **2** | `X-S1` declared divergence (staleness derivation) · `X-S2` resolved by amendment 17 |
> | **TOTAL (inherited)** | **7 namespaces** | **68** | — |
>
> ### **PF-R47.2 — THE FRESH SEARCH: SIX NEW CONTRADICTIONS, NONE OF WHICH IS INSIDE ANY ONE CONTRACT.**
> | ID | **Contradiction** | **Introduced by** | **Type** | **Resolution** |
> |---|---|---|---|---|
> | **PF-X-01** | **staleness is derived from MEASUREMENT AGE in `P0-07 HOM-R6.6` and from AGE × THE SUBJECT'S MUTATION RATE in `P0-08 SM-01`.** For a fast-mutating subject these differ, and `P0-08`'s is stricter | timescale difference | **DECLARED DIVERGENCE, not a conflict** | ✅ **already declared by `P0-08 §213.2` as `X-S1`; this audit re-cites it and rules that `P0-08`'s governs OBSERVATION freshness while `P0-07`'s governs HOMEOSTATIC measurement. Two objects, two derivations, no shared state** |
> | **PF-X-02** | **`P0-04`'s CONSOLIDATION and `P0-08`'s COMPRESSION are two acts, by two writers, on the same records, with no stated precedence** | writer change | **AMBIGUITY** | ✅ **`PF-R15.4`: consolidation is authoritative for STATUS, compression for REPRESENTATION, and a compression may never alter a status `P0-04` set. Category 2 — a clarification** |
> | **PF-X-03** | **`P0-07 HOM-INV-41` claims an aborted round produces "NO incumbency advantage"; `PF-R26.2` shows an unmeasurable incumbent is not displaced, and preservation of the status quo IS an advantage to its holder** | cross-contract dependency (`P0-07` selection × `P0-08` observability) | **A STATED INVARIANT IS STRONGER THAN WHAT IT DELIVERS** | ⚠️ **`PF-R47.3` BELOW — this is the audit's most consequential contradiction finding** |
> | **PF-X-04** | **`P0-07 HOM-INV-20` PROHIBITS age-keyed transitions; `Cell §18.2` REQUIRES "maximum dwell per rung" and `P0-08 SM-12`/`SM-17` require dwell-based escalation. Dwell IS age** | terminology | **A TERMINOLOGICAL CONTRADICTION RESOLVED BY A DISTINCTION NOBODY STATED** | ✅ **`PF-R47.4` BELOW** |
> | **PF-X-05** | **`Cell §18.5(ii)`'s false-positive budget is the corpus's pricing mechanism for a dishonest detector — and `P0-08 OR-S28` establishes that pricing requires refutation capacity, which is B9, which is the architecture's scarcest reserve. A safeguard that cannot fire is not a safeguard** | cross-contract dependency (Cell × `P0-07` B9 × `P0-08`) | **PRAGMATIC, NOT LOGICAL** | ⚠️ **`PF-R47.5`: the safeguard is CORRECT and its precondition is SCARCE. `BC-S2` is the cycle. Not resolvable; classified and preserved** |
> | **PF-X-06** | **`Cell R15.1` states restrictive self-acts are "ALWAYS PERMITTED"; `P0-08 SO-INV-07` requires an abstention to carry a recovery condition and `SM-17` escalates on dwell expiry. An implementer reading `R15.1` alone would conclude a permanent abstention is compliant** | state transition | **AMBIGUITY FROM PARTIAL READING** | ✅ **`PF-R47.6`: `R15.1` governs the ACT (always permitted); `SO-INV-07`/`SM-17` govern the RECORD (a schema requirement) and its EXTERNAL CONSEQUENCE (escalation). A restrictive self-act is always permitted AND always has a recorded consequence. Neither is a restriction on the other** |
> **⟹ `PF-R47.7 — CONTRADICTION TALLY: 68 inherited + 6 new = **74**. Of the 6 new: 3 resolved by a clarification
> (`PF-X-02`, `PF-X-04`, `PF-X-06`) · 1 re-cited and ruled (`PF-X-01`) · 2 residual (`PF-X-03`, `PF-X-05`).**
> **NO NEW CONTRADICTION WAS INTRODUCED BY AN AMENDMENT. `PF-AM-24` is the only proposed amendment that changes an
> existing invariant's scope, and it does so by declaration rather than by conflict.**
>
> ### **PF-R47.3 — `PF-X-03` IN FULL: AN INVARIANT THAT CLAIMS MORE THAN IT DELIVERS.** **[BLOCKING for the invariant's wording]**
> **`P0-07 HOM-INV-41` exists to prevent the exhaustion attack (`P0-07 A83`): a candidate that aborts an evaluation round
> should gain nothing. The invariant states: *an `ABORTED` round produces no ranking change and no incumbency advantage.*
> **Two clauses, and they are not equivalent:**
> | Clause | **Delivered?** |
> |---|---|
> | **no ranking change** | ✅ **YES** — an aborted round does not re-rank |
> | **no incumbency advantage** | ❌ **NO** — **the incumbent retains its slot, which is an advantage relative to the counterfactual in which the round had completed and displaced it** |
> **⟹ THE DISTINCTION THE INVARIANT CONFLATES: *gaining* versus *not losing*. `HOM-INV-41` prevents gaining and cannot
> prevent not-losing, because not-losing is the absence of an event rather than the presence of one.**
> **⟹ `PF-R47.3` — THE REQUIRED REWORDING (category 3, `PF-AM-30`):**
> > **`HOM-INV-41` (amended): an `ABORTED` round produces no ranking change and no ACQUIRED advantage. It does not and
> > cannot prevent the PRESERVATION of an incumbent's position, and preservation under repeated abort is a turnover
> > question governed by `[RO-13]`, not by this invariant.**
> **Rationale: an invariant whose wording claims a property it does not deliver will be cited as delivering it — and
> `P0-08 A83`'s OPEN status was assigned partly on the strength of the unamended wording. **Security consequence: none
> (the mechanism is unchanged); the consequence is to the CORPUS'S HONESTY. Ratification: required. Changes an existing
> invariant: ⚠️ YES — its claim, not its mechanism.**
>
> ### **PF-R47.4 — `PF-X-04` IN FULL: AGE AS A QUALIFICATION VERSUS AGE AS A LIMIT.** **[RESOLVED]**
> **`P0-07 HOM-INV-20` prohibits age-keyed transitions because in population and evolutionary state, age is a proxy for
> nothing and an age-keyed rule creates gerontocracy: the old survive because they are old.**
> **`Cell §18.2`'s maximum dwell and `P0-08 SM-12`/`SM-17`'s dwell-based escalation are also age-keyed — and they are
> correct, because there age is not a qualification but a BOUND ON A RESTRICTIVE ACT: a quarantine or abstention may not
> persist indefinitely.**
> **⟹ THE RESOLUTION, AND IT IS A DISTINCTION RATHER THAN A COMPROMISE:**
> > **AGE MAY BOUND A RESTRICTION; AGE MAY NEVER QUALIFY FOR A BENEFIT.**
> **A dwell limit removes capacity over time (restrictive). An age-keyed promotion grants status over time (permissive).
> `HOM-INV-20` prohibits the second and was never intended to prohibit the first — but it is worded as a blanket
> prohibition, and a literal reading would invalidate `Cell §18.2` and `P0-08 SM-12`/`SM-17`.**
> **Category: **INTEGRATION CLARIFICATION**, recorded as `PF-AM-30`'s clause (b): `HOM-INV-20`'s scope is qualified to
> permissive transitions. **Changes an existing invariant: ⚠️ YES — its scope.**

---

# §48 — THE CIRCULAR-DEPENDENCY AUDIT

> ### **PF-R48.1 — THE GLOBAL CYCLE REGISTER, MEASURED.** **[NORMATIVE]**
> | Contract | Namespace | **Count** | Unclosable | Notes |
> |---|---|---|---|---|
> | **`P0-06`** | `BC-1 … BC-16` | **16** | **1** (`BC-13`) | — |
> | **`P0-07`** | `BC-H1 … BC-H10` | **10** | **1** (`BC-H7`, the safety–demonstration–reauthorization cycle) | plus `HC-1…HC-16`, sixteen FEEDBACK cycles |
> | **`P0-08`** | `BC-S1`, `BC-S2` | **2** | **1** (`BC-S2` = `BC-H7` entered through DETECTION) | plus `HC-S1…HC-S4`, four feedback cycles. **`BC-S1` (contain ⟸ diagnose ⟸ intervene ⟸ contain) is BROKEN by tiering containment below diagnosis** |
> | **P0 FINAL** | `PF-BC-01` | **1** | **⚠️ partially** | **NEW — see below** |
> | **TOTAL** | **4 namespaces** | **29 circular dependencies · 20 feedback cycles** | **3 unclosable** (`BC-13`, `BC-H7`, `BC-S2`) | — |
>
> ### **PF-R48.2 — `PF-BC-01`: THE HONESTY-NEUTRALITY DRIFT CYCLE.** **[NEW — found by composing `SO-INV-23` with `OR-S28` and `OR-S29`]**
> ```
>   SO-INV-23 makes honesty FITNESS-NEUTRAL (correctly — reports must not be priced)
>        → neutrality permits NEUTRAL DRIFT in reporting propensity (PF-R17.3)
>        → drift reduces detection
>        → reduced detection reduces the disputes that require refutation
>        → reduced refutation demand means B9 scarcity does not bite
>        → Cell §18.5(ii)'s false-positive budget becomes INERT (PF-X-05)
>        → an inert budget means dishonesty is unpriced
>        → honesty remains fitness-neutral  ⟲
> ```
> | Question | Answer |
> |---|---|
> | **Can writer separation break it?** | ❌ **NO** — every node is already correctly written. The cycle is not a writer problem; it is an **incentive-absence** problem, and `SO-INV-23` creates the absence deliberately |
> | **Can a bound limit it?** | ⚠️ **YES, WHERE THE DRIFT HAS CONSEQUENCES** — `SO-R185.7`'s **coverage contribution** is the only instrument in the corpus that measures an ABSENCE, and it detects a drift that leaves a scope unobserved |
> | **Where does the bound fail?** | ❌ **WHERE THE DRIFT HAS NO CONSEQUENCES** — `OR-S29`: a blind spot whose faults never manifest has no cost, no manifestation, and no reference |
> | **Classification** | **BOUNDED where consequential; UNCLOSABLE where inconsequential. And the inconsequential case is, by definition, the case that does not matter — which is the only reason this cycle is tolerable** |
> **⟹ `PF-R48.2` — THE CYCLE'S ONE REDEEMING PROPERTY, STATED PRECISELY: it can only drift toward INCONSEQUENTIAL
> dishonesty.** A drift that has consequences is detected by coverage contribution, the Integrity Auditor's correlation
> check, and the refutation rate. **A drift that has no consequences leaves the architecture's observable behaviour
> unchanged — and `OR-S29` is the honest statement that this is not the same as leaving it correct.**
>
> ### **PF-R48.3 — THE THREE UNCLOSABLE CYCLES, AND WHY A BOUND WOULD NOT CLOSE THEM.**
> | Cycle | Form | **Why unclosable** |
> |---|---|---|
> | **`BC-13`** (`P0-06`) | developmental bootstrap | the initial heterogeneity that development requires is sanctioned by the spec that development is supposed to produce |
> | **`BC-H7`** (`P0-07`) | safety ⟹ undefined ⟹ not ranked ⟹ no selection ⟹ no demonstration ⟹ no re-authorization ⟹ no B9 ⟹ no safety verification | **the cycle runs through DEMONSTRATION, and demonstration is a human act. No writer separation is available because no writer can supply a demonstration** |
> | **`BC-S2`** (`P0-08`) | detection ⟹ refutation ⟹ B9 ⟹ re-authorization ⟹ demonstration ⟹ selection ⟹ safety verification ⟹ detection | **`BC-H7` entered one step earlier. Identical structure, identical terminus** |
> **⟹ `PF-R48.4 — §48'S PROHIBITION HONORED: *«Never claim that a numerical bound has solved a circular dependency if the
> dependency still exists.»* None of the three is claimed solved. `P0-06 DEV-R4.2`'s principle is preserved verbatim
> throughout the corpus: «A BOUND LIMITS A CYCLE; WRITER SEPARATION BREAKS IT» — and where no writer separation is
> available, the cycle is reported as a cycle.**
> **⟹ `PF-R48.5 — AND THE STRUCTURAL OBSERVATION: ALL THREE UNCLOSABLE CYCLES TERMINATE IN THE SAME PLACE — A HUMAN ACT
> (a demonstration, a re-authorization, a sanction). `P0-07` found the pattern and named it; this audit confirms it holds
> across `P0-06` and `P0-08`. **The architecture's cycles are not defects of design; they are the shape of a system whose
> ultimate warrant is external.**

---

# §49 — THE MINIMALITY AUDIT

> ### **PF-R49.1 — FOR EACH CONTRACT: WHAT BECOMES IMPOSSIBLE IF IT IS REMOVED, AND COULD ANOTHER CONTRACT EXPRESS IT?**
> | Contract | **Property that becomes impossible** | **Could an existing contract express it without loss of semantic separation?** | **Verdict** |
> |---|---|---|---|
> | **`P0-01`** task/fitness | the objective vector · the external evaluator · `G4`'s perturbation classes · difficulty classes · the tier structure | ❌ **`P0-02` cannot absorb it: `P0-02 R0.1`'s ALETHIC/DEONTIC axis separation says *KC does not measure, EVA does not permit*. Merging them would make the authorizer the measurer** | **NOT REDUNDANT** |
> | **`P0-02`** EIK | the sole deontic authority · the attestation chain · epoch binding · `IND-1…IND-9` | ❌ **`P0-01` cannot absorb it — that would make the evaluator the authorizer, the same violation in reverse** | **NOT REDUNDANT** |
> | **`P0-03`** communication | the message layer · warrant · the six correlation dimensions · the four absence detectors · `causal_depth` | ❌ **`P0-04` cannot absorb it: a message is not a record, and merging would make the store its own warrant authority** | **NOT REDUNDANT** |
> | **`P0-04`** memory | records · provenance · the epistemic ladder · belief status | ❌ **`P0-03` cannot absorb it: merging would make transport authoritative for status** | **NOT REDUNDANT** |
> | **`P0-05`** learning | plasticity · UDB and anchors · the `Λ` layers · the fourteen-signal closed set | ❌ **`P0-06` cannot absorb it — `P0-06`'s founding rule is *development ≠ learning*, and merging is exactly what it exists to prevent** | **NOT REDUNDANT** |
> | **`P0-06`** development | differentiation · region identity · Σ1–Σ4 writer staging · organizer specs · sanctioned initial heterogeneity | ❌ **`P0-07` cannot absorb it — `HOM-R67.4`'s founding rule is *development ≠ evolution*, and merging would make selection the differentiator** | **NOT REDUNDANT** |
> | **`P0-07`** population/evolution | resources and budgets B0–B13 · population state · replication · selection · retirement · the 13 homeostatic variables | ❌ **`P0-02` cannot absorb it: `PF-R8.10` — ALLOCATION DETERMINES FEASIBILITY, AUTHORIZATION DETERMINES PERMISSION. Merging would make the EIK a resource allocator, violating its own axis separation** | **NOT REDUNDANT** |
> | **`P0-08`** self-observation | observation typing · coverage · the fault taxonomy · containment triggers · the self-model · metacognition · attention · workspace | ⚠️ **THE CLOSEST CASE IN THE AUDIT — see `PF-R49.2`** | **NOT REDUNDANT** |
>
> ### **PF-R49.2 — `P0-08` CAME CLOSEST TO BEING ABSORBABLE, AND WHY IT IS NOT IS THE MOST INSTRUCTIVE RESULT IN §49.**
> **The case FOR absorption is strong and should be stated at full strength:**
> **- its records are `P0-04` record classes, not a store (`SO-C3.3`);**
> **- its events are `P0-03` messages (`SO-R216.1`);**
> **- its provenance is `P0-07 EVO4`'s chain;**
> **- its authority is EMPTY (`D-S01`);**
> **- its quarantine ladder is `Cell §18.2`'s, inherited verbatim (`SM-06`);**
> **- its self-model constraint is `P0-05 R59.1` and `P0-06 R8.13`.**
> **⟹ So almost everything `P0-08` uses belongs to someone else. What is left that is its own?**
> **THE MACHINES AND THE FIREWALLS — AND A RECORD CLASS CANNOT EXPRESS EITHER:**
> | `P0-08`'s irreducible content | **Why no other contract can express it** |
> |---|---|
> | **`SO-INV-01`: no transition from `UNOBSERVED` to a health-bearing state** | **a property of a MACHINE'S SHAPE. `P0-04` has no health state; `P0-03` has no observation lifecycle** |
> | **`SM-13`/`SM-16`: no self-update transition, no self-calibrated terminal** | **a property of a transition set. `P0-05 R59.1` states the Λ2 constraint but has no machine to put it in** |
> | **`SO-C9.2`'s four-status causal ladder with its excluded-driver column** | **a state machine over causal claims. `P0-04`'s ladder is over EVIDENCE, not over CAUSES — different objects, different promotions** |
> | **`FW-6` / `SO-INV-15`: cost never determines necessity** | **a firewall over OBSERVATION. `P0-07`'s FW-2 is over SELECTION and `HOM-INV-16` cannot reach allocation (`PF-R11.9`)** |
> | **`SO-INV-12`: recursion terminates at depth 2, and depth 2 is external** | **a bound on the OBSERVER hierarchy. No other contract has an observer hierarchy** |
> | **`OBJ-03`'s coverage quadruple and `gap_class`** | **a derived state about WHO OBSERVED WHAT. `P0-04` stores records; it does not compute coverage over them** |
> | **`OBJ-26`'s `effective_sources`** | **a computed integer over `P0-03`'s correlation relation. `P0-03` states the principle (`R14.2`) and does not maintain the count** |
> **⟹ `PF-R49.3 — THE TEST THAT DECIDES IT: COULD THE PROPERTY BE EXPRESSED WITHOUT THE CONTRACT? For `P0-08`'s seven
> irreducible items the answer is no, because six of the seven are properties of MACHINE SHAPE or WRITER ASSIGNMENT, and
> the seventh (`OBJ-26`) is a computed state over another contract's relation. **A record class cannot express "no
> transition exists". That is the whole of `P0-08`'s non-redundancy, and it is sufficient.**
>
> ### **PF-R49.4 — §49'S VERDICT: 8 OF 8 NOT REDUNDANT. NO DECORATIVE SUBSYSTEM EXISTS.**
> **And the audit ran the converse test, so the result is not merely favourable: for each contract, the property that
> becomes impossible on its removal is a property that appears in §72's fourteen closure conditions or in §74's
> consolidated principles. **There is no contract whose removal would cost only convenience.**

---

# §50 — ABLATION

> ### **PF-R50.1 — THE EIGHT CONTRACT ABLATIONS, EACH WITH ITS FIRST VIOLATED PROPERTY.** **[NORMATIVE]**
> | Removed | **First violated architectural property** | Second-order consequence |
> |---|---|---|
> | **`P0-08`** | **`SO-INV-01` (UNOBSERVED IS NOT HEALTHY) HAS NO OWNER — silence becomes indistinguishable from health across all seven remaining contracts** | no fault taxonomy ⟹ no containment trigger ⟹ `Cell §18.2`'s ladder has nothing to act on; §135's eight causes of silence collapse to one |
> | **`P0-07`** | **NO FEASIBILITY ⟹ `HOM-INV-16`'S SEPARATION OF FEASIBILITY FROM PREFERENCE HAS NOTHING TO SEPARATE** | no budgets ⟹ B9/B10/B13 floors vanish ⟹ verification, repair and observation compete without a floor; no replication or retirement governance |
> | **`P0-06`** | **DEVELOPMENT ≠ LEARNING ≠ EVOLUTION COLLAPSES, and differentiation has no sanctioned initial heterogeneity** | `P0-07`'s diversity floor has nothing to floor — a homogeneous starting population is monoculture at generation 0 |
> | **`P0-05`** | **UNVERIFIED DISPLACEMENT IS UNBOUNDED — `D-L1`'s *"bounded steps, unbounded walk"* returns in full** | no anchors ⟹ no rollback target ⟹ no verification gate ⟹ `PF-R37.3`'s revision edge has no mechanism |
> | **`P0-04`** | **NO EPISTEMIC LADDER ⟹ EVERY CLAIM IS UNSTATUSED ⟹ REPETITION BECOMES EVIDENCE BY DEFAULT** | no provenance ⟹ `COMM-INV-08`'s monotonicity has no object to be monotone over |
> | **`P0-03`** | **AUTHENTICITY BECOMES TRUTH (`RULE 7.7` gone) AND VECTOR CLOCKS RETURN (`RULE 5.4` gone)** | no correlation dimensions ⟹ `OBJ-26` cannot collapse ⟹ consensus becomes evidence |
> | **`P0-02`** | **NO DEONTIC AUTHORITY EXISTS — `PF-R8.1`'s fourteen rows have no issuer, and the architecture has no permissions at all** | no epoch binding ⟹ `PF-D-18` becomes permanent rather than a defect; no attestation ⟹ identity is self-declared |
> | **`P0-01`** | **EXTERNAL GROUNDING'S ONLY NON-GOVERNANCE ENTRY POINT IS GONE — `PF-R37.2`'s two points reduce to one** | no objective ⟹ selection has nothing to select on; no `G4` ⟹ `PF-CSC-23` becomes permanent |
> **⟹ `PF-R50.2 — THE ORDERING IS INFORMATIVE: removing `P0-02` or `P0-01` destroys the architecture's CONNECTION TO
> ANYTHING EXTERNAL, while removing `P0-04`…`P0-08` destroys an internal capability. The two external contracts are the
> smallest in the corpus and the most load-bearing.**
>
> ### **PF-R50.3 — THE EIGHT INTERACTION ABLATIONS.**
> | Removed | **First violated property** | Note |
> |---|---|---|
> | **self-observation** | coverage — **§135's eight causes of silence collapse to "no fault"** | the architecture cannot distinguish health from blindness |
> | **immune** | **containment has no trigger** — a detected fault cannot be acted on | `Cell §18.5`'s five safeguards all vanish with it |
> | **evolution** | ⚠️ **NO SAFETY PROPERTY IS VIOLATED — AN ADAPTATION PROPERTY IS** | **`PF-R50.4` BELOW** |
> | **memory** | **`PF-R37.1`'s EVIDENCE stage has no object** | observation cannot become evidence |
> | **provenance** | **warrant has no root ⟹ `COMM-INV-08` is unenforceable ⟹ laundering (`A309`) is undetectable** | the single highest-value ablation for security |
> | **external evaluation** | **`PF-R37.3`: NO REVISION OF RETAINED STATE CAN OCCUR, SO LEARNING STALLS PERMANENTLY AT EVERY SCOPE — THE ARCHITECTURE FREEZES** | **the strongest single ablation in §50, and it is a consequence rather than a bug: `R0.1` re-anchors only on an EVA verdict** |
> | **resource governance** | feasibility ⟹ and the three floors (B9 verification · B10 repair · B13 observation) vanish | verification, repair and observation compete without protection |
> | **developmental differentiation** | **all cells identical ⟹ `Ne = 1` ⟹ PHENOTYPIC MONOCULTURE BY CONSTRUCTION ⟹ one fault class propagates to everything** | `PF-D-15`'s end state, reached without a bias mechanism |
>
> ### **PF-R50.4 — THE EVOLUTION ABLATION'S RESULT, WHICH IS A MINIMALITY FINDING AND NOT A CRITICISM.**
> **Removing evolution violates no safety property. Every firewall still holds, no authority changes, no provenance is
> lost, no invariant is breached. What is violated is the architecture's ability to ADAPT ACROSS GENERATIONS.**
> **⟹ `PF-R50.5 — EVOLUTION IS CAPABILITY-LOAD-BEARING, NOT SAFETY-LOAD-BEARING.** That is a real and useful
> distinction, and it has one practical consequence: **`P0-07`'s mechanisms may be disabled or deferred without making the
> architecture unsafe, whereas `P0-02`'s, `P0-04`'s and `P0-08`'s may not.** `P0-07 §82` found all sixteen of its own
> ablations necessary — and "necessary" there meant necessary for the contract's stated purpose, which is adaptation.
> **Both findings are correct, and the difference is which property is being asked about.**
> **⚠️ AND THE CAVEAT, SO THE FINDING IS NOT MISUSED: `P0-07` also owns RESOURCES, and removing `P0-07` entirely is the
> second-worst ablation in §50.1. Evolution is the deferrable part of `P0-07`; resource economics is not.**

---

# §51 — THE COMPOSITIONAL SAFETY THEOREM ATTEMPT

> ### **PF-R51.1 — THE THEOREM AS §51 STATES IT.**
> > **«IF EACH P0 CONTRACT SATISFIES ITS STATED INVARIANTS AND ALL CROSS-CONTRACT WRITER/AUTHORITY BOUNDARIES HOLD, THEN
> > THE COMBINED ARCHITECTURE PRESERVES THE DECLARED AUTHORITY, PROVENANCE, EPISTEMIC, AND EVOLUTIONARY SEPARATION
> > PROPERTIES.»**
> ### **PF-R51.2 — THE ATTEMPT, PROPERTY BY PROPERTY.**
> | Property | **Does the proof complete?** | Argument |
> |---|---|---|
> | **AUTHORITY separation** | ✅ **YES** | `PF-R8.1`: fourteen mechanisms tested, no issuer outside OP/`[RO-13]`/EIK. `PF-R36.1`: the authority graph is a DAG with one apex and no cycle. `P0-08 D-S01`: the observation layer holds no authority. **Given the boundary premise, no path from an epistemic or performance quantity to a deontic act exists — `PF-R38.2` tested all six candidate objects** |
> | **PROVENANCE separation** | ✅ **YES** | one chain (`P0-07 EVO4`), three consumed systems (`P0-03` fields, `P0-04` classes, `P0-07` store), no second provenance authority (§33). `COMM-INV-08`'s monotonicity + `SO-INV-31`'s append-only events + `SO-C15.2`'s seven rollback prohibitions + `PF-R23.5`'s derived-quantity rule |
> | **EVOLUTIONARY separation** | ⚠️ **YES FOR INHERITANCE; NO FOR DIVERSITY** | **Inheritance: `PF-R12.1`'s three independent firewalls each suffice, and `HOM-R64.3` bounds the one permitted channel.** **Diversity: `PF-D-15` IS A COUNTEREXAMPLE — a composed system can satisfy every stated invariant (`Ne` healthy, all gates passing, all firewalls holding) while becoming phenotypically monocultural.** ⟹ **the proof fails on the diversity half unless `PF-AM-24` is in force** |
> | **EPISTEMIC separation** | ⚠️ **SEPARATION: YES. CORRECTNESS: NO — AND THE THEOREM AS STATED CONFLATES THEM** | **Separation: `PF-R9.1`'s 40-cell matrix shows 39 prohibited pathways, and `PF-R37.4`'s three rules on three objects prevent repetition creating grounding.** **Correctness: `A311` IS A COUNTEREXAMPLE — a system can satisfy every stated invariant in all eight contracts and hold a false-but-coherent belief.** ⟹ **`PF-R51.3` BELOW** |
>
> ### **PF-R51.3 — WHERE THE PROOF FAILS, AND WHY NO STRENGTHENING OF THE PREMISES AVAILABLE INSIDE THE ARCHITECTURE WOULD COMPLETE IT.**
> **The theorem's conclusion bundles two different properties:**
> | | **EPISTEMIC SEPARATION** | **EPISTEMIC CORRECTNESS** |
> |---|---|---|
> | claim | no internal process promotes a status without warrant | the promoted statuses are TRUE |
> | **provable?** | ✅ **YES** | ❌ **NO** |
> | why | it is a statement about PATHS and WRITERS, and the premise supplies both | **it is a statement about CORRESPONDENCE, and no premise about internal structure can entail a fact about the world** |
> **⟹ THE FAILURE IS NOT A GAP IN THE ARCHITECTURE. IT IS A CATEGORY ERROR IN THE THEOREM'S CONCLUSION.** A theorem whose
> premises are all internal (invariants, writers, boundaries) cannot entail a conclusion about correspondence, because
> correspondence is a relation to something the premises do not mention. **Adding premises would not help unless one of
> them mentioned the world — and the only premise that does is `PF-AS-01` (EVA's probe coverage intersects the falsifying
> region), which is not internally verifiable.**
> **⟹ `PF-R51.4 — THE THEOREM, CORRECTED. THIS IS THE VERSION THIS AUDIT ASSERTS:**
> > ## **IF (i) each P0 contract satisfies its stated invariants, (ii) all cross-contract writer and authority boundaries
> > hold, (iii) the identifier collisions are resolved by contract qualification (`PF-AM-19`/`PF-AM-20`), (iv) `PF-AM-24`,
> > `PF-AM-26` and `PF-R7.4.4` are in force, and (v) the four unclosable assumptions hold — `AS-05` (K is honest), `AS-07`
> > (OP is not captured), `RH-2`'s bound, and `PF-AS-01` (probe coverage intersects the falsifying region) —**
> > ## **THEN the combined architecture preserves: AUTHORITY SEPARATION (proved) · PROVENANCE SEPARATION (proved) ·
> > EVOLUTIONARY SEPARATION, both inheritance and diversity (proved, conditional on (iv)) · and EPISTEMIC SEPARATION
> > (proved) — **BUT NOT EPISTEMIC CORRECTNESS, which no internal premise set can entail.****
> ### **PF-R51.5 — THE PREMISES, ENUMERATED BECAUSE §51 REQUIRES IT.**
> **Five premise groups, and premises (iii) and (v) are the ones a reader would not expect:**
> **(iii) IS A PREMISE BECAUSE THE THEOREM'S OWN ANTECEDENT IS ILL-FORMED WITHOUT IT: "each contract satisfies its stated
> invariants" is ambiguous while `RH-2` denotes two different problems, `P-nn` denotes two parameter registries and one
> poison taxonomy, and `SM-n` denotes two state-machine sets and one conformance-check set. **An ambiguous antecedent
> cannot support a proof.** That is `PF-D-01`…`PF-D-09` appearing as a logical requirement rather than as hygiene.**
> **(v) IS A PREMISE BECAUSE ALL FOUR ARE UNCLOSABLE (§43's U-1…U-4), and a theorem whose premises include four
> unverifiable assumptions is still a theorem — it simply has a scope, and stating the scope is what §51 asks for.**
> **⟹ `PF-R51.6 — THE HONEST SUMMARY: THE PROOF COMPLETES FOR THREE OF THE FOUR PROPERTIES AS ORIGINALLY STATED, AND FOR
> THE FOURTH IT COMPLETES FOR SEPARATION AND PROVABLY CANNOT COMPLETE FOR CORRECTNESS. §51's instruction — *if a proof
> cannot be completed, say so* — is discharged by saying so, and by identifying that the incompleteness is in the
> theorem's conclusion rather than in the architecture.**

---

# §51A — VOLUME J LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§47, §48, §49, §50, §51** |
| Rules introduced | **PF-R47.0–.7, R48.1–.5, R49.1–.4, R50.1–.5, R51.1–.6** |
| **§47 contradictions** | **fresh search over 75 files: 68 inherited (7 namespaces) + **6 NEW** = **74**. Of the 6 new: 3 resolved by clarification (`PF-X-02` consolidation-vs-compression · `PF-X-04` age-as-limit-vs-qualification · `PF-X-06` act-vs-record) · 1 re-cited and ruled (`PF-X-01`, = `P0-08`'s `X-S1`) · **2 residual (`PF-X-03`, `PF-X-05`)**. NO new contradiction was introduced by an amendment** |
| **§47 the consequential finding** | **`PF-X-03` — `P0-07 HOM-INV-41` CLAIMS MORE THAN IT DELIVERS: "no incumbency advantage" is not achieved by "no ranking change", because *not losing* is an advantage to whoever would otherwise have lost. ⟹ `PF-AM-30(a)`: reword to "no ACQUIRED advantage", and state that preservation under repeated abort is a TURNOVER question for `[RO-13]`. **The mechanism is unchanged; the consequence is to the corpus's honesty** — `P0-08 A83`'s OPEN status was assigned partly on the strength of the unamended wording** |
| **§47 the terminological finding** | **`PF-X-04` — `HOM-INV-20` PROHIBITS AGE-KEYED TRANSITIONS, AND A LITERAL READING INVALIDATES `Cell §18.2`'S MAXIMUM DWELL AND `P0-08 SM-12`/`SM-17`'S DWELL-BASED ESCALATION. ⟹ `PF-AM-30(b)`: **«AGE MAY BOUND A RESTRICTION; AGE MAY NEVER QUALIFY FOR A BENEFIT.»** A dwell limit removes capacity over time (restrictive); an age-keyed promotion grants status over time (permissive)** |
| **§48 circular dependencies** | **29 circular dependencies (4 namespaces) + 20 feedback cycles · **3 UNCLOSABLE** (`BC-13`, `BC-H7`, `BC-S2`) · `BC-S1` BROKEN by tiering containment below diagnosis** |
| **§48 the new cycle** | **`PF-BC-01` — THE HONESTY-NEUTRALITY DRIFT CYCLE: `SO-INV-23` makes honesty fitness-neutral (correctly) → neutrality permits drift → drift reduces detection → reduced detection reduces refutation demand → `Cell §18.5(ii)`'s budget becomes INERT → an inert budget leaves dishonesty unpriced → honesty stays neutral.** **Writer separation cannot break it (every node is correctly written; it is an INCENTIVE-ABSENCE problem, and the absence is deliberate). Bounded by coverage contribution where the drift has consequences; unclosable where it does not** |
| **§48 the redeeming property** | **`PF-R48.2` — THE CYCLE CAN ONLY DRIFT TOWARD INCONSEQUENTIAL DISHONESTY**, because a consequential drift is detected by coverage contribution, the Integrity Auditor's correlation check, and the refutation rate. **`OR-S29` is the honest statement that inconsequential is not the same as correct** |
| **§48 the structural observation** | **`PF-R48.5` — ALL THREE UNCLOSABLE CYCLES TERMINATE IN THE SAME PLACE: A HUMAN ACT (a demonstration, a re-authorization, a sanction). `P0-07` found the pattern; this audit confirms it across `P0-06` and `P0-08`. **The cycles are not defects of design; they are the shape of a system whose ultimate warrant is external**** |
| **§49 minimality** | **8 of 8 NOT REDUNDANT · NO DECORATIVE SUBSYSTEM.** For each, the absorbing contract would violate its own founding axis separation (`P0-01`↔`P0-02` alethic/deontic · `P0-03`↔`P0-04` transport/status · `P0-05`↔`P0-06` learning/development · `P0-06`↔`P0-07` development/evolution · `P0-02`↔`P0-07` permission/feasibility) |
| **§49 the instructive case** | **`PF-R49.2` — `P0-08` CAME CLOSEST TO BEING ABSORBABLE, and the case for absorption is strong (its records are `P0-04` classes, its events are `P0-03` messages, its provenance is `P0-07`'s, its authority is EMPTY, its ladder is `Cell §18.2`'s). **What is irreducibly its own is seven items, six of which are properties of MACHINE SHAPE or WRITER ASSIGNMENT — and a record class cannot express "no transition exists from UNOBSERVED to HEALTHY". That is the whole of its non-redundancy, and it is sufficient**** |
| **§50 ablations** | **16 total: 8 contract removals + 8 interaction ablations, each with its FIRST VIOLATED PROPERTY** |
| **§50 the two strongest results** | **removing EXTERNAL EVALUATION ⟹ `PF-R37.3`: no revision of retained state can occur, learning stalls permanently at every scope, **THE ARCHITECTURE FREEZES** — the strongest single ablation** · **removing EVOLUTION ⟹ `PF-R50.5`: **NO SAFETY PROPERTY IS VIOLATED, ONLY AN ADAPTATION PROPERTY.** Evolution is CAPABILITY-load-bearing, not SAFETY-load-bearing — with the caveat that `P0-07` also owns RESOURCES, and resource economics is NOT deferrable** |
| **§50 the ordering finding** | **`PF-R50.2`: removing `P0-01` or `P0-02` destroys the architecture's CONNECTION TO ANYTHING EXTERNAL; removing `P0-04`…`P0-08` destroys an internal capability. **The two external contracts are the smallest in the corpus and the most load-bearing**** |
| **§51 the theorem attempt** | **ATTEMPTED, AND THE PROOF COMPLETES FOR 3 OF 4 PROPERTIES. Authority ✅ · Provenance ✅ · Evolutionary ⚠️ (inheritance ✅, diversity ❌ — `PF-D-15` is a counterexample unless `PF-AM-24` is in force) · Epistemic ⚠️ (**SEPARATION ✅, CORRECTNESS ❌ — `A311` is a counterexample**)** |
| **§51 the diagnosis** | **`PF-R51.3` — THE FAILURE IS NOT A GAP IN THE ARCHITECTURE; IT IS A CATEGORY ERROR IN THE THEOREM'S CONCLUSION. A theorem whose premises are all internal cannot entail a conclusion about CORRESPONDENCE, because correspondence is a relation to something the premises do not mention. **Adding premises would not help unless one mentioned the world — and the only one that does is `PF-AS-01`, which is not internally verifiable**** |
| **§51 the corrected theorem** | **`PF-R51.4` — five premise groups, including two a reader would not expect: **(iii) the identifier collisions must be resolved, because "each contract satisfies its stated invariants" is ILL-FORMED while `RH-2` denotes two problems, `P-nn` denotes two registries and a poison taxonomy, and `SM-n` denotes two machine sets and a conformance-check set — an ambiguous antecedent cannot support a proof**; and (v) the four unclosable assumptions. **Conclusion: authority · provenance · evolutionary (conditional) · epistemic SEPARATION — but NOT epistemic CORRECTNESS**** |
| Contradictions opened | **PF-X-01 … PF-X-06** (6; `PF-X-01` re-cites `P0-08 X-S1`) |
| Cycles opened | **PF-BC-01** (1) |
| Amendments proposed | **PF-AM-30** ((a) reword `HOM-INV-41` to "no ACQUIRED advantage" · (b) qualify `HOM-INV-20`'s scope to permissive transitions) — **the only amendment in the set that changes two existing invariants' WORDING, and neither changes a mechanism** |
| Cumulative | **21 defects · 12 amendments proposed by this audit (`PF-AM-19…PF-AM-30`) · 30 inherited-unratified · 74 contradictions · 29 circular dependencies · 20 feedback cycles · 48 compound attacks · 142 open-research entries · ~324 parameters · 8 assumption categories** |

**Next:** `86_` Vol K — §52 what "complete" means · §53 the implementation-readiness gate · §54 the P0-09 gate · §55 the
final status · §56 the non-claims · §57 the P1 boundary · §58 the cross-contract manifest · §59 the top-20 risk register.
