# P0 FINAL — VOLUME D (§21–§25)
## The Partition Attack, Time and Causality Across Eight Contracts, Identity and Replacement, Quarantine Composition, and Repair Composition

---

# §21 — THE PARTITION ATTACK

> ### **PF-R21.0 — THE CONSTRAINT THIS SECTION WORKS UNDER.** **[NORMATIVE]**
> **`P0-03`'s partition ruling is STILL OPEN (`XD-08`) and is now requested by three contracts (`P0-06`, `P0-07`, `P0-08`).
> §21 must therefore determine what can be settled WITHOUT the ruling, and must not invent a consensus mechanism.**
> **⟹ `PF-R21.1 — NOTHING IS INVENTED, AND THE REASON NONE IS NEEDED: the composed architecture has NO SPLIT-BRAIN, BECAUSE
> IT HAS NO SECOND BRAIN.** Every global state object in `P0-01…P0-08` is written by **K**, which is a single off-substrate
> writer (`P0-07 OR-H1` records that this uniqueness is a limit, and here it is an asset). **A partition therefore has
> exactly three forms, and none of them is a conflict of values:**
> | Partition form | What happens |
> |---|---|
> | **K is in partition A; region R is in partition B** | **R's writes are PENDING, not conflicting.** R continues to emit observations locally; anything requiring K (coverage computation, diagnosis status, serialization, allocation, freshness derivation) **stops**, so R becomes `UNMEASURED` and is read restrictively (`P0-08 SO-INV-01`/`SO-INV-02`) |
> | **K is unreachable from all partitions** | **nothing is written anywhere.** Every scope becomes `UNMEASURED`. Restriction is total and safe |
> | **K is duplicated** | **PROHIBITED — and this is the only form that could produce conflicting values. `P0-07 OR-H1`'s uniqueness of K is what excludes it** |
>
> ### **PF-R21.2 — §21'S SIX QUESTIONS, ANSWERED.** **[NORMATIVE]**
> | # | Question | **Answer** |
> |---|---|---|
> | **1** | **what remains locally valid?** | **`P0-04` records within the partition** (append-only, Merkle-rooted per epoch) · **`P0-03` warrants for messages whose `root_commit` is inside the partition** · **`P0-08 OBJ-04/05` occurrences** (append-only, multi-writer by design — `SO-R214.3`) · **`Cell §18.2`'s quarantine rungs already entered** (the EIK's local decision stands) · **`P0-05` provisional changes within their UDB budget** |
> | **2** | **what becomes stale?** | **every cross-partition `last-known` state** · **`P0-08` freshness classes** (`FRESH → AGING → STALE → INVALID` by age × the subject's mutation rate) · **attention allocations and workspace slots** (per-window, and the window cannot close without K) · **`P0-07`'s `PopulationState`** (K-computed over the whole population) |
> | **3** | **what cannot be decided?** | **any cross-partition aggregate: `Ne` · the four diversity kinds · tier-2 Pareto ranking · any global coverage figure · any retirement cause classification · any replication ticket.** ⟹ **AND SELECTION DOES NOT PROCEED: `P0-07 HOM-INV-41` — an `ABORTED` round produces NO ranking change and NO incumbency advantage. A partition aborts the round, which is the correct behaviour and is already specified** |
> | **4** | **how does reconciliation occur?** | **AS A LOG MERGE, NOT A STATE RESOLUTION.** (a) K re-derives global state from both partitions' anchored records — **each is append-only and hash-chained, so their union is well-defined and requires no conflict resolution**; (b) where values genuinely conflict, **the conflict is CARRIED, not resolved** (`P0-04`'s standing rule; `P0-08 SO-R142.1`); (c) freshness classes are recomputed by K; (d) **no consensus protocol, no voting, no quorum, no leader election is introduced — none is required, because the single-writer design means there is nothing to vote about** |
> | **5** | **which authority remains authoritative?** | **OP and the EIK — they are off-substrate and external to the organism, so their authority is unaffected by a partition of the organism.** ⚠️ **They may be UNREACHABLE, and ⟹ `PF-R21.3` BELOW** |
> | **6** | **can reconciliation create retroactive evidence?** | **❌ NO — and ⟹ `PF-R21.4` BELOW states the precise mechanism** |
>
> ### **PF-R21.3 — AN UNREACHABLE AUTHORITY IS A DENIAL, NEVER A PERMISSION.** **[NORMATIVE — the section's load-bearing rule]**
> **Authority does not transfer, delegate, or expire during a partition. An act requiring an unreachable authority is
> BLOCKED.**
> **⟹ This is `P0-05 R64.7`'s fail-safe principle (`corruption produces restriction, never permission`), extended by
> `P0-08 SO-INV-02` to observation, and extended here to **AUTHORITY AVAILABILITY**: an unverifiable authorizer is treated
> as ABSENT, and absent means denied.**
> **The consequences, which are all restrictive and therefore all safe:** no replication ticket · no freeze above the cap ·
> no `Λ3` structural change · no anchor re-basing · no retirement · no detector disablement · no recovery-plan trigger that
> requires `[RO-13]`. **What remains permitted is exactly `Cell R15.1`'s class: RESTRICTIVE SELF-ACTS — self-suspension,
> self-abstention, declaring a limitation, emitting an observation.**
> **⟹ `PF-R21.3` IS ALREADY IMPLIED BY THREE CONTRACTS AND STATED BY NONE. It is recorded here as an INTEGRATION
> CLARIFICATION (category 2), not as an amendment, because it changes no rule's meaning — it states what three rules
> jointly entail.**
>
> ### **PF-R21.4 — RECONCILIATION CANNOT CREATE RETROACTIVE EVIDENCE, AND THE MECHANISM IS A FIELD.** **[NORMATIVE]**
> **A reconciled record carries its ORIGINAL `observed_at` and `root_commit`. Reconciliation adds a MERGE EVENT; it does
> not re-date the record.**
> **⚠️ THE SUBTLE CASE: a partition-local record that was unverifiable during the partition becomes verifiable after it.
> Admitting it then is legitimate — it was always evidence. The danger is admitting it with the status it could not have
> held during the partition.**
> **⟹ THE RULE: a reconciled record's epistemic status is computed from its ORIGINAL provenance and the POST-reconciliation
> verification, AND its status DURING the partition is recorded as `UNVERIFIABLE-DURING-PARTITION` — a distinct value that
> is never overwritten by the later status.**
> **So a claim made during a partition and verified after it has TWO recorded statuses, at two times, and no consumer may
> read the later one as the earlier one. **That is `P0-08 SO-R217.1`'s event-vs-state distinction applied to time-travelling
> evidence, and it is why reconciliation cannot manufacture a past.**
>
> ### **PF-R21.5 — THE SEVEN PARTITION CONSEQUENCES §21 NAMES, EACH WITH ITS RULING.**
> | Consequence | Ruling |
> |---|---|
> | **regional self-model divergence** | ✅ **PERMITTED AND CORRECT.** `P0-08 SO-R138.2` prohibits a complete organism-wide model, so divergence is the designed state; `SO-R142.1`'s six representations (local · last-known · observed-at · freshness · confidence · conflict) are exactly the vocabulary for it |
> | **inconsistent memory** | ⚠️ **BOUNDED.** Each partition's store is Merkle-rooted per epoch; the roots differ and the difference is detectable at merge. **`P0-04 SP-5`/`OR-M9`: differential serving WITHIN an epoch is bounded, not preventable — a partition widens the window in which it is undetectable** |
> | **divergent quarantine state** | ⚠️ **BOUNDED.** Quarantine is the EIK's; if the EIK is reachable from one partition only, that partition's quarantine stands and the other's is `UNMEASURED`. **No quarantine is silently lifted by a partition, because lifting requires the EIK (`Cell R15.2`)** |
> | **conflicting repair decisions** | ⚠️ **BOUNDED.** `P0-08 SM-07`'s serialization is K's; without K, no proposal is ACCEPTED, so **repairs proceed only within already-accepted proposals and no new conflict can be created** |
> | **divergent developmental state** | ⚠️ **BOUNDED.** `P0-06`'s Σ-writers are staged and Σ-tombstones are append-only; a partition halts stage transitions rather than diverging them |
> | **divergent evolutionary observations** | ✅ **CORRECT AND EXPECTED.** `P0-07 §80`'s R4/R5 regimes already establish that **no global aggregate exists above 10⁸**; a partition is that regime reached by failure rather than by scale |
> | **the partition ruling itself** | ❌ **STILL OPEN — `XD-08`.** What this section settles is the ORGANISM-SIDE behaviour under partition; what remains open is `P0-03`'s question of whether a cross-region message during a partition is one message, two, or none — and `P0-08`'s B13 charging and `P0-06`'s morphogen reads both depend on the answer |

---

# §22 — TIME AND CAUSALITY

> ### **PF-R22.1 — THE EIGHT TIME NOTIONS, CROSS-CHECKED ACROSS ALL EIGHT CONTRACTS.** **[NORMATIVE]**
> | Notion | Owner of the semantics | Where else it appears | **Compatible?** |
> |---|---|---|---|
> | **epoch** | **`P0-02`** (authorization binding) | `P0-07` (`RATE_CAP`/epoch) · `P0-08` (`OBJ-06`, `OBJ-17` validity) | ✅ **all three mean the same governance-declared interval** — `P0-08 SO-R213.2` verified this |
> | **window** | **`P0-07`** (ledger allocation) | `P0-08` (coverage, B13) | ✅ same window; B13 is a line in the same ledger |
> | **timestamp** | **`P0-07 HP-2`** — monotone **per envelope**, never global | `P0-08 OBJ-01.observed_at` · `P0-03`'s `ts` | ✅ **and `P0-03 COMM-INV-15`/RULE 5.7: `ts` order is NOT causal order** |
> | **causal depth** | **`P0-03` field 8** — `u8`, a monotone derivation counter, **replaces the vector clock** | `P0-04`'s records · `P0-08 OBJ-01` | ⚠️ **`PF-D-16` — WRAPAROUND UNSPECIFIED, see below** |
> | **generation** | **`P0-07 D-H08`** — a generation is a **store write**, not a wall-clock interval | `P0-08`: unused (no P0-08 object crosses a generation boundary) | ✅ |
> | **developmental stage** | **`P0-06`** (`DevStage`) | `Cell`'s critical periods | ✅ |
> | **learning step** | **`P0-05`** | — | ✅ **no shared object with any other notion** |
> | **replication event** | **`P0-07`** (`T01`, gated) | `P0-08 SO-INV-24` (recovery ≠ deployment) | ✅ |
> **⟹ `PF-R22.2 — THE SIX DEFECT CLASSES §22 ASKS FOR, SEARCHED:**
> | Defect class | **Found?** | Detail |
> |---|---|---|
> | **incompatible clocks** | ❌ **NONE** | one time source (`P0-07 HP-2`), per envelope, and **no cross-envelope comparison is claimed** (`P0-07 §80`'s R4/R5 regimes) |
> | **stale state** | ❌ **NONE unhandled** | `P0-08 SO-R142.2` + `P0-07 HOM-R6.6`'s staleness-conservatism (default to the MORE RESTRICTIVE branch) |
> | **causal inversion** | ❌ **NONE** | `P0-08 SO-R220.1`: a recovery is ordered by **incident-id reference, not time comparison**; a forecast recorded after its outcome is a schema violation |
> | **wraparound** | ⚠️ **`PF-D-16`** | **see below** |
> | **epoch aliasing** | ⚠️ **`PF-D-17`** | **see below** |
> | **rollback-time ambiguity** | ⚠️ **`PF-D-18`** | **see below — and it is the most dangerous of the three** |
>
> ### **PF-D-16 — `causal_depth` IS A `u8` AND NO CONTRACT STATES ITS WRAPAROUND SEMANTICS.** **[BLOCKING DEFECT for C3 conformance]**
> **`P0-03` field 8: `causal_depth : u8`, *"replaces the vector clock"*, with §10.4's attenuation. A `u8` saturates or
> wraps at 256 derivations.**
> **⟹ IF IT WRAPS TO 0, A DEEPLY-DERIVED MESSAGE APPEARS FRESHLY ROOTED — and `COMM-INV-08`'s warrant-monotonicity would
> be violated by the counter that is supposed to express it. A 300-step derivation chain would present as depth 44.**
> **⟹ `PF-R22.3 — THE RULING REQUIRED: `causal_depth` SATURATES AT ITS MAXIMUM AND NEVER WRAPS. A saturated depth is
> read as "at least this deep", which is restrictive: `P0-03 §10.4`'s attenuation means a saturated counter yields minimum
> warrant, and minimum warrant is the safe reading.**
> **Whether 256 derivations is reachable in practice is `[E]`/`[U]` and is NOT assumed here — the point is that the
> semantics must be stated, because a wrap and a saturation produce opposite warrant readings from the same field.**
> **Category: **PROPOSED AMENDMENT (`PF-AM-25`) to `P0-03` field 8.** Security: positive (removes a warrant-inflation
> route). Scalability: none. Compatibility: changes a field's semantics at its boundary — **ratification required, and it
> changes no invariant.**
>
> ### **PF-D-17 — EPOCH IDENTIFIER UNIQUENESS SCOPE IS NOT STATED, AND AT R4+ IT ALIASES.** **[INTEGRATION CLARIFICATION]**
> **`P0-02`'s epochs are governance-declared and K-issued. `P0-07 §80`'s R4/R5 regimes establish that above 10⁸ the
> architecture is **per-envelope** — multiple envelopes, no global aggregate.**
> **⟹ AN EPOCH IDENTIFIER THAT IS UNIQUE WITHIN AN ENVELOPE BUT NOT ACROSS ENVELOPES ALIASES WHEN TWO ENVELOPES' RECORDS
> MEET — in a reconciliation (`PF-R21.4`), in an archive, or in an off-line evaluation.**
> **⟹ `PF-R22.4 — THE CLARIFICATION: an epoch identifier is ⟨envelope-id, epoch-sequence⟩, and a bare epoch-sequence is
> not a valid reference outside its envelope.** This is `P0-08 SO-R175.1`'s hardware-class rule and `P0-07`'s cohort
> stamping applied to time, and it is a clarification rather than an amendment because `P0-07 §80` already made every
> aggregate per-envelope.
>
> ### **PF-D-18 — ROLLBACK AND EPOCH BINDING COMPOSE INTO A STALE-AUTHORITY REVIVAL, AND NO CONTRACT PREVENTS IT.** **[BLOCKING DEFECT — the section's most dangerous finding]**
> **The composition:**
> ```
>   P0-02: an authorization issued in epoch e is NOT valid in epoch e+1     [epoch binding]
>   P0-05/P0-07: a rollback restores the artifact identified by (hash, epoch e)
>   ⟹ QUESTION NO CONTRACT ANSWERS: after a rollback to epoch e, IS THE CURRENT EPOCH e, OR A NEW EPOCH e′ ?
> ```
> **⟹ IF THE CURRENT EPOCH BECOMES `e` AGAIN, THEN EVERY AUTHORIZATION ISSUED IN `e` REVIVES — including any that were
> consumed, superseded, or revoked between `e` and the rollback. That is a stale-authority revival on a mass scale, and it
> is exactly what `P0-08 SO-R145.1(b)` (*authority is epoch-bound; an observation from epoch e cannot revalidate an
> authorization in epoch e+1*) exists to prevent — but `SO-R145.1` reasons forward in time and never considered a rollback
> moving the epoch label backward.**
> **⟹ `PF-R22.5 — THE RULING REQUIRED, AND IT IS NOT OPTIONAL:**
> > ## **A ROLLBACK RESTORES AN ARTIFACT; IT NEVER RESTORES AN EPOCH. A ROLLBACK OPENS A NEW EPOCH `e′` WHOSE
> > STATE IS THE RESTORED ARTIFACT AND WHOSE AUTHORIZATIONS ARE EMPTY.**
> **Corollaries, all restrictive: no authorization survives a rollback · a post-rollback act requires fresh authorization ·
> `P0-08 SO-C4.4`'s freeze fields are re-issued, not revived · `P0-05`'s anchors are re-established by a probe, not
> restored by the rollback (**which `SO-INV-28` already requires**).**
> **⟹ `PF-R22.6 — WHY THIS DEFECT WAS INVISIBLE TO ALL THREE CONTRACTS THAT COULD HAVE FOUND IT: `P0-02` specified epoch
> binding without considering rollback (which it does not own); `P0-05` and `P0-07` specified rollback without considering
> epoch binding (which they do not own); and `P0-08` specified `SO-R145.1`'s forward-direction rule without considering
> that its own `SM-09` moves backward.** **This is §1's rule producing its clearest finding: three internally correct
> contracts, one incorrect composition, and the incorrect composition is a privilege-revival route.**
> **Category: **PROPOSED AMENDMENT (`PF-AM-26`) affecting `P0-02`, `P0-05`, `P0-07`, `P0-08`.** **Security consequence:
> MATERIAL AND POSITIVE — it closes a mass stale-authority revival. Ratification: REQUIRED. Changes an existing invariant:
> NO — it states the interaction between two existing invariants (`P0-02`'s epoch binding and `P0-08 SO-C15.2`'s rollback
> prohibitions), and `SO-C15.2` already lists seven things rollback never does; this is the eighth.**

---

# §23 — IDENTITY AND REPLACEMENT

> ### **PF-R23.1 — THE NINE IDENTITY KINDS, THEIR ISSUER, AND THEIR UNIQUENESS SCOPE.** **[NORMATIVE]**
> | Identity kind | **Issuer** | **Reuse permitted?** | **Uniqueness scope** | Contract |
> |---|---|---|---|---|
> | **cell** | **K**, at `T01` | ❌ **NEVER** (`P0-06 R8.3(c)`) | envelope | `P0-01`/`P0-06` |
> | **lineage** | **K** (Registrar-issued lineage certificates) | ❌ | **global** (`P0-07 A118`'s closure) | `P0-02`/`P0-07` |
> | **genome** | **hash + generation** | n/a — content-addressed | global | `P0-07` (`HOM-INV-37`) |
> | **phenotype** | derived; **`Cell §17.4`'s identity-preservation conditions** | n/a | per hardware class | Cell |
> | **circuit** | **K** | ❌ | envelope | `P0-06` |
> | **region** | **`P0-06`** — **functional, not anatomical** (principle **33**) | ❌ | envelope | `P0-06` |
> | **organism** | **OP** (an envelope is a deployment act) | ❌ | global | `P0-01`/`P0-07` |
> | **replacement** | **K — A NEW IDENTITY** | n/a | envelope | `PF-R23.2` |
> | **restored** | **the ORIGINAL identity, in a NEW epoch** | n/a | envelope | **`PF-R23.3`** |
>
> ### **PF-R23.2 — WHAT A REPLACEMENT INHERITS: NOTHING.** **[NORMATIVE]**
> | Property | **Inherited by a replacement?** | Rule |
> |---|---|---|
> | **authority** | ❌ | `P0-08 SO-R172.1` (identity ≠ authority) · `P0-07 §76`'s ∅-set |
> | **trust** | ❌ | **`Cell I-27`'s `Beta(α,β)` is per-identity; a new identity starts at the prior** |
> | **epistemic status** | ❌ | `P0-08 SO-R173.2`: **a cloned self-model is a NEW CLAIM WITH NO EVIDENCE**; every status must be re-earned through `SM-14`/`SM-16`/`SM-04` |
> | **historical credit** | ❌ | `P0-08 SO-INV-06`: capability evidence is not transferable |
> | **evolutionary fitness** | ❌ | **a new genome artifact must be evaluated; `P0-07 HOM-INV-24` (no cross-generation authority)** |
> | **governance permissions** | ❌ | `P0-02`'s epoch binding — **and `PF-D-18` shows this is where the danger was** |
> **⟹ `PF-R23.2` IS THE CLEANEST RESULT IN THIS VOLUME: SIX PROPERTIES, SIX ❌, AND EACH CLOSED BY A DIFFERENT CONTRACT'S
> RULE.** A replacement is a new entity with no history, and the architecture has no mechanism by which history could
> attach to it.
>
> ### **PF-R23.3 — A RESTORATION IS NOT A REPLACEMENT, AND THE DIFFERENCE HAS ONE UNSPECIFIED CONSEQUENCE.** **[BLOCKING DEFECT `PF-D-19`]**
> **A rollback restores an ARTIFACT under the SAME identity (`PF-R23.1`'s last row), in a NEW epoch (`PF-R22.5`). So a
> restored entity keeps its identity — and identity is what trust, capability records, and historical credit attach to.**
> **⟹ `PF-D-19: WHETHER A ROLLBACK RESTORES A COMPONENT'S TRUST PARAMETERS IS STATED BY NO CONTRACT.**
> | If it does | If it does not |
> |---|---|
> | **a component could launder a trust deficit by rolling back** — incur distrust through failures, roll back to a pre-failure artifact, and resume with restored trust | **a legitimately rolled-back component is unfairly distrusted** — it is penalized twice, once by the incident and once by the restoration |
> **⟹ `PF-R23.4 — THE RULING, AND IT FOLLOWS FROM PRINCIPLE 23 RATHER THAN FROM CONVENIENCE:**
> > ## **TRUST PARAMETERS ARE NOT ROLLED BACK. TRUST IS A HISTORY-DERIVED QUANTITY, THE HISTORY IS RETAINED
> > (`SO-INV-31`, `P0-04`'s append-only store), AND ROLLING BACK A HISTORY-DERIVED QUANTITY WHILE RETAINING THE HISTORY
> > WOULD BE REWRITING HISTORY BY ARITHMETIC.**
> **The incident that caused the rollback remains in the record; the trust computed over that record therefore remains
> correct. **What the rollback restores is the ARTIFACT — the weights, the genome, the configuration — and what it does not
> restore is anything derived from what happened since.**
> **⟹ `PF-R23.5 — THE GENERAL RULE THIS INSTANCE REVEALS, AND IT IS WORTH STATING BECAUSE IT APPLIES TO FIVE OBJECTS:**
> > **A ROLLBACK RESTORES A WRITTEN ARTIFACT. IT NEVER RESTORES A DERIVED QUANTITY.**
> **The five derived quantities this excludes: **trust** (`Cell I-27`) · **capability status** (already excluded by
> `P0-08 SO-C15.2(g)`: capabilities become `STALE`) · **coverage history** (`OBJ-03` is append-only per window) ·
> **`effective_sources`** (`OBJ-26` is recomputed, not restored) · **calibration** (`OBJ-21`'s error series is K-computed
> over history).**
> **`P0-08 SO-C15.2` lists seven things rollback never does and gets all seven right; **it never states the principle that
> generates the list, and `PF-D-19` is the eighth item that the missing principle would have caught.**

---

# §24 — QUARANTINE COMPOSITION

> ### **PF-R24.1 — QUARANTINE AGAINST TEN CONTRACTS.** **[NORMATIVE]**
> | Against | **Interaction** | **Ruling** | Status |
> |---|---|---|---|
> | **memory** | a quarantined component's records remain readable; its writes are restricted by rung (`SOFT`: outputs discounted to trust 0; `HARD`: halted, state frozen) | **records are never quarantined — only their PRODUCER is.** `P0-04`'s store is append-only and quarantine does not delete or re-status anything in it | **SAFE** |
> | **learning** | **`SOFT`/`HARD` halts learning ⟹ UDB stops being consumed ⟹ the anchor never re-establishes ⟹ post-release stall** | **⚠️ `P0-08 IF-1`/`SO-R248.2`: RELEASE MUST TRIGGER AN ANCHOR RE-ESTABLISHMENT REQUEST, or the scope is marked `STALL-ON-RELEASE` (`[RO-13]`-visible).** **AND `PF-R16.2`: without it the composition is a SELF-CONFIRMING LOOP in which quarantine makes a component quieter and quiet looks healthy** | **REQUIRES AMENDMENT (already proposed in `P0-08`, unratified)** |
> | **development** | **a quarantine during a declared `critical_period` alters differentiation PERMANENTLY** | **⚠️ `P0-08 IF-2`/`SO-R248.3`: NOT REVERSIBLE IN EFFECT; must be ESCALATED TO `[RO-13]` rather than applied at the EIK's discretion.** **`PF-R16.6`: §1's rule in purest form — a reversible mechanism performing an irreversible act, with neither contract wrong** | **REQUIRES AMENDMENT** |
> | **communication** | `SOFT`: cannot initiate connections · `HARD`: halted ⟹ **emissions stop** | **emissions stopping is a SILENCE, and silence has eight causes (`P0-08 SO-R135.1`). ⟹ `SO-INV-08`: containment writes a coverage gap (`DETECTOR-ABSENT`/`MASKED`), never `NO-GAP`** | **SAFE — and this is the composition that makes masking visible rather than silent** |
> | **evolution** | a quarantined component does not replicate; a quarantine EVENT on an ancestral line is a **`G16` input** | **⚠️ `P0-07 HOM-INV-38`'s cause-written-once rule exists precisely because a quarantine event becomes evolutionary evidence. ⟹ A quarantine is not guilt (`P0-08 SO-C13.2`: no blame field), but its OCCURRENCE is a fact selection may consume — and `P0-07` already ruled that the cause classification is written once and is immutable so it cannot be reinterpreted later** | **SAFE — with the interpretation risk already closed** |
> | **homeostasis** | a quarantined component consumes no resources and produces no output | **⚠️ `P0-07 HOM-R6.5`: THROTTLED COMPONENTS ARE EXCLUDED FROM `G1`/`G6`/`G9`.** **Without the exclusion, quarantining half the population would raise measured per-capita efficiency — a quarantine would look like an improvement** | **SAFE — the exclusion already exists** |
> | **self-model** | a quarantined component's self-model stops being versioned (no new external observations) | **it goes `STALE`, and `STALE` is restrictive (`SO-R142.2`, `P0-07 HOM-R6.6`). ⟹ A quarantine cannot preserve a favourable self-model by freezing it, because freezing makes it stale** | **SAFE** |
> | **attention** | a quarantined scope still has coverage gaps | **⚠️ `P0-08 IF-5`/`SO-R248.6`: A FROZEN SCOPE IS EXCLUDED FROM ATTENTION ALLOCATION, AND ITS GAP IS `FREEZE-INDUCED`, A DISTINCT SUBCLASS.** Without the subclass, a freeze-induced gap is routed to `SUPPRESSION-SUSPECTED` — accusing the freeze of suppression | **REQUIRES AMENDMENT** |
> | **replication** | a quarantined component is ineligible | **`P0-07`'s eligibility gates already exclude quarantined subjects; a quarantine is restrictive-only so it cannot *grant* eligibility** | **SAFE** |
> | **retirement** | **the two must not be conflated** | **`P0-07 FW-3`/`HOM-INV-39`: quarantine is REVERSIBLE (the EIK clears) and retirement is IRREVERSIBLE (six `R10.8` states). `P0-08 SO-R163.2` adds the third distinction: quarantine restricts a SUBJECT's outputs; freeze suspends a SCOPE's operations** | **SAFE — three-way distinction, disjoint machines** |
> **⟹ `PF-R24.2 — TALLY: 10 compositions — 6 SAFE · 4 REQUIRES AMENDMENT, and all four amendments were already proposed by
> `P0-08 §248` as interference rules. NONE IS NEW TO THIS AUDIT.**
> **⟹ `PF-R24.3 — AND THE FINDING THAT MATTERS: `P0-08 §248` found four of the five quarantine compositions that needed a
> rule, without knowing it was auditing quarantine. It labelled them "cross-trace interferences" (IF-1, IF-2, IF-5) and
> "an inherited exclusion" (`HOM-R6.5`). **§24's value is not that it found new defects; it is that it confirms the four
> are load-bearing for QUARANTINE specifically, and therefore that leaving them unratified leaves quarantine's composition
> with four known holes.** That reclassifies them from "interference rules" to **`PF-RK-03` in §59's risk register.**
>
> ### **PF-R24.4 — §24'S REQUIRED EXPLICIT ANALYSIS: «REVERSIBLE QUARANTINE PRODUCING EFFECTIVELY IRREVERSIBLE DEVELOPMENTAL CONSEQUENCES.»**
> **The mechanism, stated exactly:**
> ```
>   Cell §18.2 SOFT/HARD  →  the component halts
>   P0-06 critical_period →  during this window, differentiation is committed by exposure to the morphogen field
>   the halted component is absent from the field  →  its neighbours' exposure changes  →  their differentiation changes
>   the EIK clears the quarantine (Cell R15.2)  →  the component resumes
>   ⟹ THE COMPONENT IS RESTORED. ITS NEIGHBOURS ARE NOT, AND THEY WERE NEVER QUARANTINED.
> ```
> **⟹ THREE PROPERTIES MAKE THIS WORSE THAN AN ORDINARY SIDE EFFECT:**
> **(a) THE HARM FALLS ON THIRD PARTIES who were not the subject of any decision and had no representation in it.**
> **(b) IT IS INVISIBLE TO THE QUARANTINE RECORD**, which describes the quarantined component and says nothing about the
>     field. **`P0-08 SO-INV-26` requires that a containment act altering a developmental field be RECORDED as
>     perturbative — which makes it traceable after the fact but not preventable before.**
> **(c) THE REVERSIBILITY CLAIM IS TRUE OF THE ACT AND FALSE OF ITS EFFECT**, so every rule keyed to reversibility
>     (`Cell R15.2`'s EIK clearance, `P0-07 FW-3`'s quarantine≠retirement, the EIK's discretion to quarantine) is keyed to
>     the wrong property in this case.
> **⟹ `PF-R24.5 — THE RESOLUTION IS ESCALATION, NOT PREVENTION, AND THAT IS THE CORRECT ANSWER.** `SO-R248.3` moves the
> decision to `[RO-13]`, which can weigh a containment benefit against a developmental cost. **No mechanism inside the
> organism can make that trade, because the trade is between two incommensurable goods and incommensurable trades are
> governance.** `P0-07 BC-H7`'s lesson applies: the cycle terminates in a human, and so does this one.
> **Classification: **BOUNDED, with the bound being an escalation requirement rather than a prevention mechanism.** Residual:
> **`PF-R24.6` — escalation requires `[RO-13]` to be reachable and attentive, and `PF-R263`'s RT-6 (escalation flooding)
> is the attack on exactly that precondition.**

---

# §25 — REPAIR COMPOSITION

> ### **PF-R25.1 — SEVEN TRANSITIONS, SIX ROLES EACH.** **[NORMATIVE]**
> **§25's requirement: for every transition identify who requests · authorizes · executes · records · verifies · releases
> it. And: *no role may gain authority merely because it executes the repair.***
>
> | Transition | **Requests** | **Authorizes** | **Executes** | **Records** | **Verifies** | **Releases / closes** |
> |---|---|---|---|---|---|---|
> | **REPAIR** (mutable state) | the component | **K** serializes · **`[RO-13]`** declares the arbitration rule · **EIK** may veto on safety | the component / K | **K** (`OBJ-13`) | **a NON-REPAIRER** (`SO-R164.2`) | **K**, on `VERIFIED-EFFECT` |
> | **ROLLBACK** (a prior artifact) | the component / K | **K** | **K** | **K** (`OBJ-14`) | **a non-rollbacker** | **K**, on `POST-VERIFIED` |
> | **REPLACEMENT** (a new identity) | the component / `[RO-13]` | **`[RO-13]`** | **K** (`T01`) | **K** | **EVA** (a new identity must be re-evidenced) | **`[RO-13]`** |
> | **SUPPRESSION** (a detector or report) | — | **`[RO-13]` ONLY** | K | K (`OBJ-09`'s disablement record) | **the EIK Integrity Auditor** | **`[RO-13]`** |
> | **QUARANTINE** (a subject's outputs) | the detector (a trigger, not a request) | **EIK** | **EIK** | **K** (`OBJ-11`) | the EIK's own rung monitoring | **EIK clears** (`Cell R15.2`) |
> | **RETIREMENT** (irreversible removal) | K / `[RO-13]` | **EIK / `[RO-13]` / OP by `R10.8` state** — **`FI` sole-satisfier is OP-SOLE** | K | K (**cause written once, immutable**) | `[RO-13]` | **NOBODY — IT IS IRREVERSIBLE** |
> | **EVOLUTION** (a genome diff) | the lineage (a proposal) | **EIK** (the ticket) + **16 gates** | **K** | **K** (hash-chained provenance, references not payloads) | **EVA** (held-out) | **OP** for deployment |
>
> ### **PF-R25.2 — THE SEVEN TRANSITIONS ARE DISTINGUISHED BY THEIR REVERSIBILITY, AND REVERSIBILITY DETERMINES AUTHORITY.** **[DERIVATION]**
> | Transition | Reversible? | **Authority level required** |
> |---|---|---|
> | repair | ✅ | K |
> | quarantine | ✅ | EIK |
> | rollback | ✅ (forward-restorable) | K |
> | suppression of a detector | ✅ (re-enableable) | **`[RO-13]`** |
> | replacement | ⚠️ the identity is not recoverable | **`[RO-13]`** |
> | retirement | ❌ | **EIK / `[RO-13]` / OP by state** |
> | evolution (a committed diff) | ⚠️ rollbackable as an artifact, **not as a population** (`HOM-INV-37`) | **EIK + gates; OP for deployment** |
> **⟹ THE ORDERING IS MONOTONE: AUTHORITY LEVEL RISES WITH IRREVERSIBILITY, AND NOT WITH MAGNITUDE, COST, OR URGENCY.**
> **This is `P0-05`'s founding principle — *«its authority scales with irreversibility rather than magnitude»* — and §25's
> seven-row table confirms that all eight contracts obey it. **It is the single most consistently applied principle in the
> corpus, and principle **31** records it as a principle in its own right.**
>
> ### **PF-R25.3 — DOES ANY ROLE GAIN AUTHORITY BY EXECUTING? ❌ NO, AND THE TEST IS MECHANICAL.**
> **§25's prohibition, tested against all seven transitions: the EXECUTES column contains the component (repair), K
> (rollback, replacement, suppression, retirement) and K (evolution). **In no row does the executor also appear in the
> AUTHORIZES column for the same transition, except K's rollback — and K authorizes rollback because K owns the artifact
> store, not because K executes the restoration.**
> **⟹ `PF-R25.4 — THE ONE ROW WHERE THE DISTINCTION IS THIN, STATED SO IT IS NOT MISSED: ROLLBACK. K requests (as
> meter-holder), authorizes, executes, records, and is the only party positioned to verify — the VERIFIES column says "a
> non-rollbacker", and `P0-08 OR-S4` records that when K is the recoverer there is no internal non-recoverer.** So rollback
> is the one transition in which four of six roles collapse onto one party, and it is `P0-07 OR-H1`'s fifth appearance.
> **`PF-R25.5`: rollback is therefore the transition to audit hardest in P1, and §59 ranks it `PF-RK-05`.**
>
> ### **PF-R25.6 — THE TRANSITION THAT DOES NOT EXIST, AND WHY ITS ABSENCE IS A RESULT.**
> **There is no "SUPPRESSION OF A REPORT" transition.** `P0-08 SO-INV-21` makes occurrence and report separate objects with
> separate writers, `SO-INV-23` prohibits pricing reports, and `SO-R136.1` makes threshold-crossing reports MANDATORY.
> **⟹ A component may be silenced (quarantine) and a detector may be disabled (`[RO-13]`, on a refuted-report budget), but
> an individual REPORT may not be suppressed by anyone — including K, including the EIK, including `[RO-13]`.** The only
> route to non-reporting is non-detection, which is `OR-S29`'s blind spot rather than a suppression mechanism.
> **That is a stronger property than "reports are auditable", and no single contract states it: it is the composition of
> `SO-INV-21` + `SO-INV-23` + `SO-R136.1`.**

---

# §25A — VOLUME D LEDGER

| Item | Count / value |
|---|---|
| Brief sections discharged | **§21, §22, §23, §24, §25** |
| Rules introduced | **PF-R21.0–.5, R22.1–.6, R23.1–.5, R24.1–.6, R25.1–.6** |
| **§21 partition** | **`PF-R21.1` — THE COMPOSED ARCHITECTURE HAS NO SPLIT-BRAIN BECAUSE IT HAS NO SECOND BRAIN: K is a single off-substrate writer, so a partition has exactly three forms and none is a conflict of values.** **6 questions answered · 7 consequences ruled (2 ✅ correct-by-design · 4 ⚠️ bounded · 1 ❌ still open = `XD-08`)** · **NO CONSENSUS MECHANISM INVENTED — reconciliation is a LOG MERGE over append-only hash-chained records, with genuine conflicts CARRIED not resolved** |
| **§21 the two load-bearing rules** | **`PF-R21.3` — AN UNREACHABLE AUTHORITY IS A DENIAL, NEVER A PERMISSION** (implied by three contracts, stated by none; a clarification, not an amendment) · **`PF-R21.4` — reconciliation cannot create retroactive evidence, via a distinct `UNVERIFIABLE-DURING-PARTITION` status that is never overwritten** |
| **§22 time and causality** | **8 time notions cross-checked: 7 ✅ compatible, 1 ⚠️ (`causal_depth`)** · **6 defect classes searched: 3 ❌ absent (incompatible clocks, stale state, causal inversion) · 3 ⚠️ FOUND** |
| **§22 the three defects** | **`PF-D-16`** — `causal_depth : u8` **WRAPAROUND SEMANTICS UNSPECIFIED**; a wrap to 0 makes a 300-step chain present as depth 44 and inverts `COMM-INV-08`'s warrant monotonicity ⟹ **must SATURATE (`PF-AM-25`)** · **`PF-D-17`** — **epoch identifier uniqueness scope unstated; at R4+ a bare epoch-sequence ALIASES across envelopes** ⟹ an epoch id is ⟨envelope-id, sequence⟩ · **`PF-D-18`** — **ROLLBACK × EPOCH BINDING = MASS STALE-AUTHORITY REVIVAL, prevented by no contract** ⟹ **`PF-AM-26`: a rollback restores an ARTIFACT and NEVER an EPOCH; it opens a new epoch with EMPTY authorizations** |
| **§22 the method result** | **`PF-D-18` was invisible to all three contracts that could have found it: `P0-02` specified epoch binding without rollback; `P0-05`/`P0-07` specified rollback without epoch binding; `P0-08` specified the forward-direction staleness rule without noticing its own `SM-09` moves backward. **Three internally correct contracts, one incorrect composition, and the composition is a privilege-revival route**** |
| **§23 identity** | **9 identity kinds with issuers and uniqueness scopes** · **`PF-R23.2`: a replacement inherits NOTHING — 6 properties, 6 ❌, each closed by a different contract** |
| **§23 the finding** | **`PF-D-19` — WHETHER A ROLLBACK RESTORES TRUST IS STATED BY NO CONTRACT.** If yes: a trust deficit is launderable by rollback. If no: a legitimate rollback is doubly penalized. **⟹ `PF-R23.4`: TRUST IS NOT ROLLED BACK, because trust is history-derived and the history is retained — rolling back a derived quantity while retaining its history is rewriting history by arithmetic.** **`PF-R23.5` — THE GENERAL RULE: A ROLLBACK RESTORES A WRITTEN ARTIFACT; IT NEVER RESTORES A DERIVED QUANTITY (5 quantities excluded: trust · capability status · coverage history · `effective_sources` · calibration). `P0-08 SO-C15.2` lists seven correct prohibitions but never states the principle that generates them, and `PF-D-19` is the eighth item the missing principle would have caught** |
| **§24 quarantine** | **10 compositions: 6 SAFE · 4 REQUIRES AMENDMENT** — and **all four amendments were already proposed by `P0-08 §248`** (IF-1 anchor re-establishment · IF-2 critical-period escalation · IF-5 `FREEZE-INDUCED` gap subclass · plus `P0-07 HOM-R6.5`'s throttled-component exclusion). **⟹ §24's value is not new defects but RECLASSIFICATION: the four move from "interference rules" to load-bearing holes in quarantine's composition (`PF-RK-03`)** |
| **§24 the required explicit analysis** | **the reversible-quarantine/irreversible-development composition traced in five steps, with three properties that make it worse than an ordinary side effect: (a) the harm falls on THIRD PARTIES who were never the subject of any decision · (b) it is INVISIBLE TO THE QUARANTINE RECORD, which describes the component and not the field · (c) THE REVERSIBILITY CLAIM IS TRUE OF THE ACT AND FALSE OF ITS EFFECT, so every rule keyed to reversibility is keyed to the wrong property.** **⟹ The resolution is ESCALATION, not prevention: the trade is between two incommensurable goods, and incommensurable trades are governance** |
| **§25 repair** | **7 transitions × 6 roles, fully tabulated** · **`PF-R25.2`: authority level rises MONOTONICALLY WITH IRREVERSIBILITY across all seven, and not with magnitude, cost, or urgency — `P0-05`'s founding principle obeyed by all eight contracts** · **`PF-R25.3`: NO role gains authority by executing** |
| **§25 the two results** | **`PF-R25.5` — ROLLBACK IS THE ONE TRANSITION WHERE FOUR OF SIX ROLES COLLAPSE ONTO K**, and it is `P0-07 OR-H1`'s fifth appearance ⟹ the transition to audit hardest in P1 (`PF-RK-05`) · **`PF-R25.6` — THERE IS NO "SUPPRESSION OF A REPORT" TRANSITION, AND NOBODY MAY SUPPRESS AN INDIVIDUAL REPORT — not the component, not K, not the EIK, not `[RO-13]`. A stronger property than auditability, and one no single contract states: it is the composition of `SO-INV-21` + `SO-INV-23` + `SO-R136.1`** |
| Defects opened | **PF-D-16** (`causal_depth` wraparound) · **PF-D-17** (epoch aliasing at R4+) · **PF-D-18** (**rollback × epoch binding = stale-authority revival — the volume's most dangerous finding**) · **PF-D-19** (rollback and trust) |
| Amendments proposed | **PF-AM-25** (`causal_depth` saturates, never wraps) · **PF-AM-26** (**a rollback opens a NEW epoch with EMPTY authorizations**) |
| Cumulative defects | **PF-D-01 … PF-D-19** (19) |
| Cumulative amendments | **PF-AM-19 … PF-AM-26** (8 proposed here) + 18 inherited-unratified = **26 unratified amendments in the corpus** |

**Next:** `80_` Vol E — §26 observability composition · §27 coverage × independence · §28 verification economics ·
§29 scalability composition at five scales · §30 hardware portability.
