# DIGITAL BRAIN — NANO-AI ARCHITECTURE
## FULL ADVERSARIAL ARCHITECTURAL AUDIT OF V3 / V3.1

**Role:** Chief Systems Architect · Computational Neuroscientist · AI Researcher · Distributed-Systems Engineer · Evolutionary-Computing Researcher · Adversarial Architecture Reviewer
**Subject:** `Digital_Brain_Nano_AI_Architecture_V3.pdf` (24 sections, 6 pp.) + `..._V3_1_Upgrade.pdf` (12 sections, 4 pp.)
**Mandate:** Determine whether the architecture is complete enough to support the intended long-term system. Actively attempt to break it. No implementation.
**Date:** 2026-09-07

---

# PART 0 — EXECUTIVE SUMMARY

## The one-paragraph verdict

V3/V3.1 is an unusually good **map of the problem space** and an unusable **specification of a system**. It correctly identifies 21 brain weaknesses, 10 AI weaknesses, and a failure-mode matrix that is genuinely better than most published neuro-symbolic or evolutionary-AI designs. V3.1 correctly promotes global availability, self-state, attention, error awareness, and multi-scale plasticity/evolution from *implied* to *named* subsystems. But across ~30 named subsystems, **27 have no defined algorithm, data structure, threshold, protocol, or unit**. The document consistently supplies *nouns where mechanisms are required*. The decisive test: **hand V3/V3.1 to ten competent engineering teams and you will receive ten mutually incompatible systems, every one of which fully "satisfies" the document.** That is the definition of not implementation-ready.

## The five load-bearing failures

| # | Failure | Why it is load-bearing |
|---|---|---|
| **F1** | **The computational substrate of a "Nano-AI cell" is never defined.** Nothing says whether a cell is a neural net, a symbolic program, a Bayesian estimator, a decision policy, or a process. | Every downstream mechanism — mutation operators, fitness, error detection, uncertainty, plasticity, cost, scalability — is a function of the substrate. Undefined substrate ⇒ all of them undefined. This is the root defect from which most others descend. |
| **F2** | **No target task, environment, or capability objective is specified.** The Environment appears as one line in the master tree and is deferred to Roadmap Phase 10. | No task ⇒ no outcome ⇒ no ground truth ⇒ no error signal ⇒ no learning ⇒ no fitness ⇒ **evolution is mathematically vacuous**. The architecture has built an elaborate selection machine with nothing to select *for*. |
| **F3** | **Confidence and uncertainty are consumed by ~14 subsystems and produced by none.** | The anti-hallucination pipeline, verification, abstention, trust scoring, attention, error awareness, calibration-failure detection, self-state, and fitness all read `confidence`. No estimator, no calibration procedure, no recalibration loop exists. If confidence is arbitrary, the entire safety edifice is **theatre**. |
| **F4** | **The safety architecture is self-referential and therefore not safe.** The "immutable safety layer" and "evolutionary firewall" are components *inside* the organism, running on the same substrate, subject to the same evolution, repair, and plasticity as everything else. | Nothing in the design sits outside the thing it constrains. A system that can modify its own constraints has no constraints. There is also no off-substrate operator interface, kill switch, or rate limit on self-modification. |
| **F5** | **The verification economy is unmodelled and probably infeasible.** The full loop applies retrieval → hypotheses → evidence → provenance → *independent* verifiers → contradiction detection → calibration → simulation to every input. Measured amplification: **~15–40× realistic, up to 72× multiplicative worst case** per base inference. | No cost model, no latency budget, and — critically — **no policy for when to skip verification**. So the system must either pay 40× (infeasible at scale) or silently drop verification (reverting to an unverified model while still claiming the guarantees). There is no third option in the current design. |

## The single most important strategic criticism

> **The architecture is defense-heavy and offense-light.**

Roughly 70% of the document's surface area is devoted to *what could go wrong and how to resist it* — anti-hallucination, anti-bias, novelty/distribution shift, immune system, firewall, quarantine, abstention, diversity preservation, provenance, calibration. That is admirable and rare.

Almost **0%** is devoted to *what the organism does*. There is no task. No benchmark. No capability target. No statement of what "increasingly capable intelligence" means operationally. No north star.

This is not a cosmetic omission. It is **architecturally fatal**, because the entire back half of the design — fitness, selection, sandbox testing, error signals, plasticity triggers, differentiation demand, region formation, homeostatic setpoints — is *parameterised by the task*. Without it, every one of those subsystems is underspecified **by construction**, and no amount of internal elaboration can fix it. Defenses against failure are meaningless in a system with no defined way to succeed.

**Fix (P0, before anything else):** name 3–5 concrete target environments with measurable success criteria, spanning at least one continuous-control task, one symbolic/knowledge task, and one long-horizon open-ended task. Everything else in this audit assumes that gets done.

---

# PART I — CRITICAL QUESTIONS A–T

---

## A. CELL — Can one Nano-AI cell independently do each of these?

**Preliminary finding that governs this entire section:** the architecture never states what a cell *is*. V3 §4 lists what a cell *has* (identity, genome, safety layer, state, memory, processing, communication, plasticity, replication, pruning) and V3 §6 lists a neuron-analogue pipeline (dendrite → soma → axon → terminal). Neither defines a computational object. So the honest answer to most of the following is *"unspecified — here is the mechanism you must add."*

| Capability | V3/V3.1 status | Verdict | Missing mechanism |
|---|---|---|---|
| **Perceive inputs** | §6 "dendrite-like inputs: receive, weight, context-gate, preprocess" | ⚠️ **Partial** | No port typing, no observation space, no sensing *policy*. A cell cannot decide what to attend to. Missing: typed input ports + active-sensing requests + receptive-field definition. |
| **Maintain internal state** | §4 "activation, confidence, uncertainty, context, load, health, integrity"; §5 cytoplasm "working state, buffers" | ⚠️ **Partial** | No state vector definition (type, dimension, range, units), no update equation, no persistence semantics, no state serialization format. Cannot be checkpointed or transmitted as written. |
| **Remember** | §4 five memory types; §11 nine memory types | ⚠️ **Partial** | No schema, no capacity, no retention policy, no retrieval mechanism, no interference model, no reconsolidation rule. Nine *named* stores with zero *defined* behaviour. |
| **Learn** | §15 lifetime-learning chain; §8 synaptic plasticity rule | ⚠️ **Partial → Weak** | No learning algorithm family, no step size, **no eligibility trace (⇒ no credit assignment)**, no stability-plasticity mechanism, no consolidation trigger. See §F below. |
| **Reason** | §6 "infer, simulate, decide"; §4 "detect, predict, compare" | ❌ **Missing** | "Reason" is asserted, never constructed. No inference mechanism, no rule/proof/planning representation, no search procedure. **Honest note:** a single *nano*-scale cell almost certainly cannot reason in any non-trivial sense. Reasoning must be a **circuit-level** property. The architecture should stop implying cell-level reasoning and specify multi-cell inference explicitly. |
| **Communicate** | §4 nine signal categories; §8 synapse property list | ❌ **Missing** | A *taxonomy* of signal names and a *property list* on edges is not a communication architecture. No schema, no addressing, no routing algorithm, no transport semantics. See §B. |
| **Detect its own errors** | V3.1 §4 error awareness loop | ⚠️ **Partial** | Detection is specified only as `prediction vs observation`. That catches *prediction* error and nothing else. No internal-consistency check, no invariant monitor, no cross-cell corroboration, no calibration history check. A cell that is confidently wrong in a way that doesn't produce an observable outcome (reasoning error, memory error) is **invisible**. |
| **Estimate uncertainty** | §6 soma "uncertainty estimation"; §4 "confidence, uncertainty" | ❌ **Missing** | No estimator named. No aleatoric/epistemic separation. No calibration procedure. No calibration *validation*. This is load-bearing failure **F3**. |
| **Modify itself** | §4 plasticity; V3.1 §6 cell plasticity (parameters, strategy, memory policy, specialization) | ⚠️ **Partial + Contradictory** | Mechanism absent (no update rule), **and** it conflicts with the "immutable safety layer": if a cell can modify its own strategy and memory policy, what prevents it from modifying the parts that enforce safety? No self-modification *scope* is defined. |
| **Modify its connections** | §8 plasticity "strengthen, weaken, create, reroute, prune"; V3.1 §6 connection plasticity | ⚠️ **Partial** | No handshake for `create` (does the target consent? what if it refuses or is at capacity?), no teardown protocol for `prune` (what about in-flight messages and dependent circuits?), no `reroute` semantics. Unilateral connection modification is a **denial-of-service vector** against the target cell. |
| **Specialize** | §10 cell society; V3.1 §6 "specialization" | ⚠️ **Partial** | No trigger, no gradient, no commitment, no reversal, no representation of "what am I specialized in." Specialization is *listed as a role menu*, not produced by a mechanism. See §H. |
| **Replicate** | §4 "copy → mutate/recombine → sandbox → validate → spawn"; §16 | ⚠️ **Partial — and mis-attributed** | The pipeline is stated but every gate is undefined (§K). More importantly: **replication should not be a cell capability at all.** A cell that can decide to replicate itself is a runaway-replication and self-preservation risk. Authority must be external. See §K. |
| **Enter a sandbox** | §14 slow mode "sandbox learning"; §16 sandbox | ❌ **Missing** | What *is* a sandbox here? An isolated process? A VM? A simulation of the environment? A frozen snapshot? No isolation boundary, no resource policy, no escape detection, no promotion criteria, no maximum duration. "Sandbox" is used as a magic word in three different senses (learning sandbox, evolution sandbox, quarantine) that are never distinguished. |
| **Recover from failure** | §17 repair/rollback/replace; §4 "recovery" | ❌ **Missing** | **No checkpoint format, no snapshot mechanism, no WAL, no restart procedure, no last-known-good state, no lineage backup.** "Rollback" appears 5× across both documents with zero supporting state-management infrastructure. You cannot roll back what you never persisted. |
| **Be quarantined** | §7 microglia-like; §17 quarantine | ⚠️ **Partial** | No quarantine *state* defined. Unanswered: where does its state live? What happens to in-flight messages? Who owns its synapses? Who does its work? How long? What is the exit criterion? **Can quarantine cascade into a systemic outage** if enough cells are quarantined? None addressed. |
| **Be retired** | §4 pruning triggers; §17 "return or retire" | ⚠️ **Partial** | No retirement protocol: connection draining, knowledge extraction before deletion, replacement provisioning, tombstone/lineage record, dependant notification. Naive deletion silently breaks every circuit the cell participated in. |

### Cell-level conclusion

**A Nano-AI cell as specified is a labelled container, not a computational agent.** Of 16 required capabilities, 0 are fully specified, 11 are partially specified, and 5 are entirely missing (`reason`, `communicate`, `estimate uncertainty`, `enter sandbox`, `recover from failure`).

**Required: a Minimal Cell Specification (P0).** The revised architecture in Part II §11 supplies one — typed ports, a defined state vector, a concrete confidence estimator (small ensemble + evidential head), a bounded tiered memory with named schemas, a self-modification *scope* that excludes the safety layer by construction, and the removal of autonomous replication from the cell entirely.

---

## B. CELL ↔ CELL — How exactly do cells communicate?

### Direct answer: **they don't. Not yet.**

V3 §8 defines a *digital synapse* as a property list on a directed edge (`type, weight, reliability, latency, bandwidth cost, trust score, context sensitivity, plasticity rate, usage frequency, last-success timestamp, pruning probability`) plus a one-line plasticity rule. V3 §4 lists nine signal *names*. That is a **data model for a connection**, not a **communication architecture**.

Specifically absent: message format, addressing scheme, routing algorithm, delivery semantics, ordering guarantee, congestion control, backpressure, failure handling, authentication, trust *computation* (as opposed to trust *storage*), conflict resolution, and loop damping.

### Is the current synapse architecture sufficient?

**No.** Concretely, it fails on eight counts:

1. **No payload semantics.** `weight` is applied to *what*? A scalar? A vector? A proposition? You cannot weight an untyped object.
2. **No addressing.** How does a cell name a target? By ID? By region? By capability? By content ("whoever can answer this")? Content-based routing is essential for a self-organizing system and is entirely absent.
3. **No routing algorithm.** "Thalamus-like routing" (§9) is a brain region name, not an algorithm. No table, no path computation, no locality awareness, no failover path.
4. **`trust score` is stored but never computed.** No update rule, no initialization, no decay, no cap. A stored field with no writer is a placeholder.
5. **No authentication at all.** Any cell can emit any signal type, including `reward`, `error`, and `warning`. **A single compromised cell can forge reward signals and hijack the entire learning system.** This is the most severe single defect in the communication design.
6. **`reliability` and `latency` are properties of an edge but nothing measures or updates them.** No probing, no estimation, no feedback.
7. **No delivery semantics.** At-most-once? At-least-once? Exactly-once? Ordered? For a system with credit assignment, out-of-order or duplicated error signals will corrupt learning.
8. **`bandwidth cost` is listed with no budget and no enforcement.** Nothing prevents a cell from saturating the network.

### Required communication specification (P0)

**B.1 Signal types** — seven classes, each with a distinct trust and routing policy:

| Class | Members | Authority required | Delivery |
|---|---|---|---|
| `DATA` | `ASSERT`, `PREDICT`, `EVIDENCE`, `QUERY`, `RESPONSE` | none (signed) | best-effort, ordered per-conversation |
| `CONTROL` | `ATTENTION`, `INHIBIT`, `EXCITE`, `GATE`, `ROUTE`, `SCHEDULE` | regional | reliable |
| `EVALUATIVE` | `REWARD`, `PENALTY`, `ERROR`, `CALIBRATION` | **privileged — requires lineage-verified evaluator role** | reliable, exactly-once |
| `META` | `NOVELTY`, `UNCERTAINTY`, `SELF_STATE`, `CAPABILITY` | none (signed) | best-effort |
| `SOCIAL` | `REQUEST`, `OFFER`, `NEGOTIATE`, `COMMIT`, `DELEGATE` | none (signed, two-phase) | reliable |
| `SYSTEM` | `LOAD`, `BUDGET`, `HEALTH`, `QUARANTINE`, `RETIRE`, `ROLLBACK` | **privileged — substrate authority only** | reliable, preemptive |
| `SAFETY` | `ALERT`, `VIOLATION`, `HALT`, `ESCALATE` | any cell may emit; **only substrate may act on `HALT`** | guaranteed, preempts all |

> **Design rule:** the *emission* of `SAFETY` signals must be permissionless (any cell can raise an alarm) while the *execution* of `SAFETY` actions must be monopolized by the off-substrate kernel. This asymmetry is what makes the alarm system both sensitive and non-hijackable.

**B.2 Message structure** — canonical envelope:

```
Message {
  msg_id        : UUIDv7                     // time-ordered, idempotency key
  conv_id       : UUID                       // conversation / thread
  epoch         : u64                        // organism epoch (see §M)
  ts            : u64 (ns, monotonic + wall)
  ttl           : u16 (hops)                 // loop bound
  type          : SignalClass + subtype
  src           : CellID + lineage_path + region
  dst           : CellID | RegionID | CapabilityQuery | BroadcastScope
  prio          : 0..7                       // 0 = safety-critical (preemptive)
  payload       : typed, schema-versioned, size-capped
  confidence    : f32 + calibration_class    // NOT a bare number — see §F3
  uncertainty   : {aleatoric, epistemic}
  provenance    : Merkle-DAG node hash       // not the graph, a pointer
  trust         : f32 + trust_context
  cost          : {flops, bytes, mem}        // declared; independently verified
  causality     : vector_clock (compressed)  // for cycle & feedback detection
  seq           : u32 per (src,dst,conv)     // ordering + gap detection
  signature     : sign(lineage_key, hash(all above))
}
```

**B.3 Addressing** — four modes, all required: (i) direct `CellID`; (ii) hierarchical `RegionID/SubregionID`; (iii) **capability-based** `cap:"visual-motion" ∧ min_confidence:0.8 ∧ max_latency:20ms` resolved by a *Capability Directory Service* (a sharded, replicated, eventually-consistent registry — itself a P0 subsystem that V3/V3.1 never mentions); (iv) scoped broadcast `BroadcastScope = {local, regional, global}` with global requiring workspace admission (§C).

**B.4 Routing** — hierarchical and locality-aware: intra-cluster direct (flat table) → inter-cluster via cluster head → inter-region via region gateway → global via workspace relay. Base algorithm: **greedy geographic/functional routing on a locality-preserving embedding** (cells that communicate most are placed nearest), with loop-free guarantee via monotonic distance function, plus k-disjoint alternate paths for `prio ≤ 2`. This is the single highest-leverage scalability fix (§R).

**B.5 Priority & scheduling** — 8 levels, strict preemption for levels 0–1 only. Per-cell **weighted fair queueing with aging** so no low-priority flow starves indefinitely. Deadline-aware (EDF) inside a cell.

**B.6 Trust & authentication** — this is the biggest gap and needs the most detail:

- **Identity root:** each cell receives a **birth certificate** signed by the Replication Authority at spawn, binding `CellID → genome_hash → lineage_path → parent_signature`. No certificate, no participation. This makes **Sybil attacks structurally impossible** — you cannot mint an identity without a signed lineage chain.
- **Per-message signing** with an epoch key derived from the lineage key; **key rotation** each epoch; **revocation list** published on quarantine/retirement.
- **Trust = Bayesian posterior, not a scalar.** Maintain `Beta(α, β)` per (source, context) pair. Update on verified outcome. Then:
  - **Discount with age:** multiply effective evidence by `λ^Δt` so old trust decays — prevents "trust farming" (behave well for 10⁶ steps, then defect).
  - **Cap trust at `trust_max < 1.0`:** *no cell is ever fully trusted.* Unconditional trust is a single point of failure.
  - **Context-partition trust:** trust in domain A does not transfer to domain B. Prevents a strong visual cell from vouching for a financial claim.
  - **Require lineage distance for verification:** a verifier must be ≥ *d* lineage hops from the proposer (§L, correlated failure).
- **Trust poisoning defense:** signed trust *assertions* (not just trust values), anomaly detection on trust-update rate, inbreeding coefficient on lineage (a clique of mutually-vouching cells is detectable as low lineage entropy), and an off-substrate trust auditor.

**B.7 Latency & bandwidth budgets** — declared per link class and *enforced*: local (intra-cluster) ≤ 1 ms; regional ≤ 10 ms; global ≤ 100 ms. Bandwidth = declared payload × rate, metered against the cell's budget (§Q). Exceeding budget ⇒ throttle ⇒ then shed ⇒ then flag as a resource error (§E).

**B.8 Congestion** — token bucket per cell (burst + sustained); **backpressure signal** propagated upstream when a queue exceeds high-water mark; load shedding strictly by priority (drop `prio 7` first); **message aggregation** (combine same-type messages to same target within a window); **summarization** (send a belief summary, not N raw beliefs); **rate limiting per nominator** for global broadcast.

**B.9 Failure handling** — timeout with jittered exponential backoff, bounded retries; on exhaustion mark link `DEGRADED` and reroute via alternate path; **circuit breaker** per (src,dst) pair with half-open probing; repeated failure ⇒ quarantine candidacy. Gap detection via `seq`; duplicate suppression via `msg_id`; causal ordering via compressed vector clocks (needed for feedback-loop detection — see B.12).

**B.10 Conflicting signals** — **the transport layer must NOT resolve conflicts.** Resolution is a cognitive act, not a network act. Both signals are delivered with full provenance to a **Contradiction Detector**, which emits a `ConflictRecord{A, B, sources, provenance, type, attempted_resolutions, status}`. Resolution hierarchy (explicit, ordered):

> **external ground truth** > **protected memory** > **majority of lineage-independent verifiers** > **highest calibrated trust** > **abstain + escalate**

Unresolved conflicts persist in an **open-contradiction register** and *reduce the confidence of all downstream dependents* — this is how disagreement propagates honestly instead of being silently averaged away. A **dissent registry** preserves minority positions for later re-examination.

**B.11 Malicious / corrupted signals** — layered: schema validation → signature verification → provenance validation → trust threshold → **anomaly detection on payload distribution and emission rate** → rate limiting. Flagged signals are **not discarded** — they are diverted to an *evidence sandbox* where they cannot influence decisions until independently corroborated, and the source is quarantined. Signature recorded in immune memory. **Discarding is wrong**: a sophisticated attacker learns to stay just under the discard threshold; *quarantining while preserving* keeps the evidence for attribution.

**B.12 Feedback loops** — the architecture has **no loop control whatsoever**, which is critical because the design is *saturated* with feedback (critics → proposals → critics; workspace → attention → workspace; self-model → routing → self-model; learning → plasticity → learning). Required:

- Build and maintain an **influence graph** (edges weighted by measured causal effect, estimated from the vector-clock causality data already in the envelope).
- **Detect cycles** statically; compute **loop gain** = product of edge gains.
- **Enforce `loop_gain < 1`** for all detected cycles — this is a hard structural invariant, provable and checkable off-substrate.
- Insert **minimum delay** on back-edges; bias toward **negative** feedback; require **decorrelation** (independent seeds, independent lineages) for any cell pair inside a loop.
- **Runtime oscillation detector**: spectral analysis of regional activity; periodicity above threshold ⇒ auto-dampen.

Without this, the system will oscillate or saturate, and — because the failure is distributed — it will be extremely hard to diagnose.

---

## C. GLOBAL INFORMATION AVAILABILITY

V3.1 §1–2 is the most substantial addition and the right idea (it is a defensible engineering rendering of Global Workspace Theory). But it is specified as **five boxes and an arrow**: `LOCAL CELL STATE → SALIENT INFORMATION → ATTENTION/RELEVANCE GATE → GLOBAL WORKSPACE → COLLECTIVE INTERPRETATION`. Every one of those boxes is an undefined subsystem. Below, each of your questions is answered and the missing mechanism designed.

### C.1 What information becomes globally available?

**Not specified anywhere.** V3.1 lists what the workspace *contains* (shared context, active goals, relevant memories, active hypotheses, current uncertainties, important warnings) but never what makes something *eligible*.

**Required — an explicit admission policy.** Only these item classes may compete:

| Class | Trigger | Default priority |
|---|---|---|
| Prediction error | \|error\| > θ_region (region-calibrated) | high |
| Threat / safety violation | invariant breach, constraint violation | **automatic — bypasses competition** |
| Novelty | distance-to-memory > θ_novel | high |
| Goal-relevant high-value | expected goal-advancement > θ | medium |
| Cross-region contradiction | two regions assert incompatible claims | high |
| Resource / homeostatic deviation | control variable outside band | medium |
| Capability boundary event | task encountered outside declared competence | medium |
| Consolidation candidate | repeated stable advantage (§M bridge) | low |

Explicitly **excluded**: raw percepts, routine local computation, intermediate hypotheses below threshold, un-summarized memory. **Rationale:** a workspace that admits everything is not a workspace, it is a bus — and V3.1's own text warns against "an uncontrolled information dump" without providing the mechanism to prevent one.

### C.2 Who decides what enters?

**Not specified.** This is the single most consequential omission in V3.1, because whoever controls admission controls the organism's reality.

**Required — distributed, auditable, rotating admission control:**

1. **Nomination (local).** Any cell/region may nominate; nominations are signed, rate-limited, and cost-charged to the nominator. Charging is essential: free nomination ⇒ spam ⇒ overload.
2. **Salience scoring.** A specified function, not a word:
   `salience = w₁·task_relevance + w₂·novelty + w₃·urgency + w₄·E[info_gain] + w₅·uncertainty_reduction + w₆·threat + w₇·downstream_consequence − w₈·broadcast_cost`
   with weights **versioned, signed, and stored off-substrate** so they cannot be quietly evolved (§L).
3. **Competition with lateral inhibition.** Top-*k* compete; winner suppression of near-duplicates prevents the same content re-entering under different labels.
4. **Referee committee.** A *set* of admission referees drawn from **distinct lineages and distinct regions**, rotating each epoch. No single population controls the gate.
5. **Automatic safety bypass.** `SAFETY` items are admitted unconditionally and preempt. This must not depend on the committee (a compromised committee must not be able to suppress an alarm).
6. **Admission audit.** A separate Auditor population samples admission decisions and checks for bias/monopolization, reporting to the off-substrate audit log.

### C.3 Who can read it?

**Not specified.** "Globally available" is used without a scope model.

**Required — tiered scoping with audited reads:**
- **Tier 0 (universal):** self-state summary, active goals, safety alerts, epoch/timebase. Cheap, always readable.
- **Tier 1 (regional):** items scoped to the regions whose capability profile matches the item's relevance vector. Default tier.
- **Tier 2 (restricted):** provenance graphs, verification internals, quarantine evidence. Capability-token gated.
- **Reads are logged and signed.** Rationale: an *unlogged* global workspace is a **covert channel** — cells can communicate through what they read, bypassing the message layer entirely and defeating all traffic-level anomaly detection.

### C.4 How is attention allocated?

**Partially specified** (V3.1 §5 lists 8 scoring factors and 5 routing decisions) but with no allocation algorithm, no budget, and no anti-monopoly protection.

**Required:** a **fixed attention budget per epoch** (attention is a *resource*, which is exactly V3.1's stated intent — so make it one). Allocate by constrained softmax over priority scores with **temperature coupled to self-state**: high stress/load ⇒ raise temperature ⇒ broaden attention (exploratory); low stress ⇒ lower temperature ⇒ focus. Enforce a **minimum exploration floor** (≥ *x*% of budget to non-top-priority channels) so the system cannot lock onto one hypothesis. Enforce **per-region caps** and **starvation floors** (any region below its floor for *n* epochs gets a mandatory audit slot).

### C.5 How is irrelevant information suppressed?

**Partially implied.** Required explicit mechanisms: pre-nomination local gating; lateral inhibition among competitors; **relevance decay** for items whose read-rate falls; **hard TTL**; **active un-broadcast** with tombstone; **attention refractory period** (a just-broadcast item cannot immediately re-compete — without this, a loud item monopolizes the workspace indefinitely); cost-based gating (broadcast must pay for itself in expected information gain).

### C.6 How are conflicting global signals handled?

**Not specified.** Use B.10: never silently merge; create a `ConflictRecord`; run a Verification Tournament; apply the resolution hierarchy; persist unresolved conflicts in the open-contradiction register and **propagate reduced confidence downstream**; preserve dissent.

### C.7 How is stale information removed?

**Not specified.** Required: per-type TTL (safety alerts: long; hypotheses: short; self-state: very short); **active invalidation** on source retraction or contradicting evidence; **versioning with tombstones** (never in-place overwrite — that destroys the audit trail); a **staleness monitor** that periodically re-verifies high-impact items and demotes any whose `last_verified` exceeds a bound; **context-boundary invalidation** (on task switch, mark prior-context items stale).

### C.8 How is provenance preserved?

**Named but undefined in both documents.** Required: append-only **Merkle DAG**; store hashes not payloads; each belief carries `provenance_hash` enabling full ancestry reconstruction; cell lineage tree for every producer; **inbreeding coefficient** computed over the provenance DAG (fraction of ancestry that is internally generated) with a hard cap for critical beliefs (§L, synthetic-data degeneration); and **external anchoring** — periodically publish a signed root hash to storage outside the organism's control. Without anchoring, a sufficiently capable internal process could rewrite history consistently. Anchoring makes history *tamper-evident* even if not tamper-proof.

### C.9 Can the global workspace become overloaded?

**Yes — trivially, and the architecture has no defense.** V3.1's own goal ("prevent the workspace becoming an uncontrolled information dump") is stated but not engineered. A single high-salience population, or a feedback loop between attention and workspace content, saturates it.

**Required:** bounded admission queue with load shedding by priority; **hierarchical workspace** (global tier holds *summaries*; regional tiers hold detail) — this is both a scalability fix and a correctness fix, since broadcasting raw detail globally is what makes overload inevitable; per-nominator rate limits; backpressure to nominators; **occupancy / admission-latency / drop-rate as first-class homeostatic control variables** (§Q) with automatic throttling; and a defined **degraded mode** — if the global tier fails, regional workspaces continue independently and the system loses *global* integration but not regional function.

### C.10 Can one population monopolize it?

**Yes.** Nothing prevents it, and monopolization is the *natural* outcome of a salience-competition design: whoever is loudest, or whoever controls the referees, owns the organism's shared reality. This is a **capture risk of the first order**, and it is the failure mode most likely to produce a system that is internally coherent and externally delusional.

**Required:** per-population nomination caps per epoch; **reserved quota slots** for under-represented regions and for the Dissent Channel; **rotating, lineage-diverse referee committee**; automatic safety bypass (uncapturable); independent admission auditing; **monopolization detection** (Herfindahl index over workspace content by source population — alert above threshold); and hard architectural separation so that **no population can both produce content and referee admission for that content**.

### C.11 Additional workspace gaps not in your list

- **No ignition / bistability semantics.** In actual GWT, the defining property is *ignition* — a nonlinear transition from local processing to global broadcast. Without a threshold and a broadcast-vs-local distinction, "global availability" is not operationalizable and therefore **not measurable** (§N).
- **No consistency model.** The workspace is shared mutable state read and written by thousands of concurrent actors. Strong consistency? Eventual? Lease-based? CRDT? Unspecified — and unspecified shared state is the classic source of nondeterministic, unreproducible bugs. Required: versioned items + leases + CRDT merge for counters + explicit read-your-writes only within a region.
- **No redundancy / failover.** The workspace is a **single point of failure**, in direct contradiction with V3 §21's "single-point failure → redundancy + decentralization." Required: replicated workspace with leader election per shard, and the degraded mode above.
- **No garbage collection.** Items enter; nothing defines when they leave. Unbounded growth is the default behaviour of the current spec.
- **No workspace cost model.** Broadcasting is expensive; nothing accounts for it.

---

## D. SELF-STATE

V3.1 §3 lists seven self-state categories. This is a decent *inventory*. It is not a *representation*: no types, no units, no ranges, no update frequency, no estimator, no transport, no consumer contract — despite the text asserting that self-state "is fed into routing, attention, planning, learning, and homeostasis." Five consumers, zero interface.

### Audit against your checklist

| Required element | V3.1 coverage | Gap |
|---|---|---|
| Computational state | ✅ load, latency, available compute | No units, no aggregation level (per-cell? per-region? global?), no sampling rate |
| Memory state | ✅ WM occupancy, retrieval confidence | No per-store breakdown, no fragmentation, no provenance-store size |
| Cognitive state | ✅ active goal, strategy, attention | No goal *hierarchy*, no goal conflict state, no strategy-selection rationale |
| Confidence | ✅ | **No calibration metadata.** A confidence value without "how was this calibrated and when" is unauditable |
| Uncertainty | ✅ | No aleatoric/epistemic split ⇒ cannot decide "gather more data" vs "accept irreducible noise" |
| Capabilities | ✅ "capability state" | **Critically underdeveloped.** No per-domain competence map, no measured-vs-claimed distinction, no confidence bound on the capability estimate itself |
| Limitations | ⚠️ implied | **No explicit out-of-scope declaration.** The system cannot represent "I was never built for this." See §N |
| Health | ✅ | No definition of health; no per-component health rollup |
| Integrity | ✅ (V3 §4) | **No tamper detection, no checksum/signature state, no last-verified timestamp** |
| Resource availability | ✅ (via V3 §18) | **No forecast** — only current values. Control requires prediction, not just observation |
| Active goals | ✅ | No priority, progress, deadline, conflict, or abandonment-criteria fields |
| Attention | ✅ (V3.1 §5) | No current-allocation vector, no attention *debt*, no monopolization index |
| Current strategy | ✅ | No strategy-performance history, no alternative-strategy set |
| Current environment model | ✅ (V3 §19) | **No distribution-shift estimate, no model confidence, no last-validation time** |

### Missing entirely — and these are the important ones

1. **No model version / genome version / structural state hash.** The organism cannot report *what it currently is*. It cannot tell you whether it has changed since yesterday. This makes drift undetectable from the inside and makes rollback unverifiable.
2. **No pending/planned change state.** What modifications are queued, in sandbox, or awaiting deployment? Without this, self-modification is invisible to the self-model.
3. **No evaluation / test-suite state.** When was the last full evaluation? What was the score? Which tests are stale? A system that cannot report its own last-verified competence is a system that will silently degrade.
4. **No ground-truth freshness.** How recent is the last external validation? This directly gates synthetic-data degeneration risk.
5. **No diversity / effective population size.** The system cannot report its own monoculture risk (§L).
6. **No recovery capability state.** *Can I actually roll back right now? When was my last checkpoint? Is it valid?* Given that rollback is invoked 5× in the documents with no persistence layer, this must be explicit — otherwise "rollback" is a hope.
7. **No constraint-compliance state.** Am I currently within every safety constraint, and what is my margin?
8. **No history / trajectory.** Self-state is a *vector*; the self-*model* requires a *time series*. Only with trajectory can the system predict its own future state.
9. **No self-model confidence (second-order uncertainty).** The architecture has confidence about the world and no confidence about its confidence. This is the difference between "I don't know X" and "I don't know whether I know X" — and the second is what makes limitation awareness possible.
10. **No self-state staleness / propagation latency.** Decisions conditioned on a 10-second-old self-state at 1M-cell scale will be systematically wrong.
11. **No influence / control map.** Which subsystems can currently affect which? Needed for containment reasoning and for damage assessment.

### The structural problem: the self-model is open-loop

This is the deepest issue in §D and it is not on your checklist.

The self-model **observes** the system. Nothing **validates** the self-model. There is no mechanism that compares "what the self-model says I can do" against "what I actually did." A self-model with no error signal will drift into **confabulation** — and a confidently wrong self-model is *worse than none*, because every consumer (routing, attention, planning, capability prediction, escalation) will act on it.

**Required — close the loop:**
- **Capability assay:** periodically issue *known-difficulty probe tasks* to each region and compare predicted vs actual performance. Update the capability map from measured, not claimed, competence.
- **Self-prediction error:** the self-model predicts its own future state (load, error rate, success probability) and is scored against reality. This is a first-class error type (§E) and it is currently absent.
- **Claim–behaviour consistency monitor:** detect divergence between declared capability and observed behaviour; on divergence, **downgrade the declaration, not the behaviour**.
- **Self-model provenance:** every field carries source, timestamp, and confidence.
- **Self-model versioning + rollback:** the self-model is state; it must be checkpointed and recoverable like any other.

---

## E. ERROR AWARENESS

### E.1 Can the architecture distinguish your nine error classes?

V3.1 §4 lists seven: perception, reasoning, memory, prediction, action, confidence-calibration, system/resource. Your list adds **communication error**. Results:

| Error class | Listed? | Detection mechanism specified? | Verdict |
|---|---|---|---|
| Perception error | ✅ | ❌ — no ground truth, no cross-modal corroboration, no sensor-redundancy check | Undetectable as specified |
| Reasoning error | ✅ | ❌ — no inference trace, no logical consistency check, no step verification | **Undetectable.** This is the hardest class and it has zero support |
| Memory error | ✅ | ❌ — no checksum, no periodic re-verification, no consistency audit, no recall-confidence check | Undetectable |
| Prediction error | ✅ | ✅ — `PREDICTION → OBSERVATION → COMPARE` | **The only genuinely specified detector in either document** |
| Action error | ✅ | ⚠️ — needs an outcome evaluator, which needs a task definition (F2) | Blocked by F2 |
| Confidence-calibration error | ✅ | ✅ V3.1 p2 (confident + repeatedly wrong ⇒ calibration failure) — good idea | ⚠️ **No calibration procedure exists to produce the confidence being checked** (F3). The detector is well-designed and points at a nonexistent signal |
| Communication error | ❌ **absent from V3.1's list** | ❌ | **Contradiction:** your checklist and V3.1's own §4 taxonomy disagree. Message loss, corruption, misrouting, delay, duplication, and malformed payloads are all undetected — despite the transport carrying `reliability` as a stored field |
| Resource error | ✅ ("system/resource") | ⚠️ — homeostasis detects deviation but does not classify it as an *error* with attribution | Detection without classification |
| System-level error | ✅ ("system/resource") | ❌ — no crash detection, no corruption detection, no partial-failure detection, no invariant monitor | Undetected |

### E.2 Error classes missing from the taxonomy entirely

These are not quibbles — each is a real, common failure mode that the current taxonomy cannot even *name*, and therefore cannot detect, route, or learn from:

1. **Coordination error** — individually correct cells producing a collectively wrong outcome (deadlock, livelock, oscillation, duplicated work, race conditions, resource contention, circular waiting, thundering herd). **This is the dominant failure mode of multi-agent systems and it has no category.** Given that this architecture is *entirely* a multi-agent system, this is the most serious taxonomic omission.
2. **Specification / objective error** — the system correctly optimizes the wrong goal. Reward hacking is the *symptom*; specification error is the *disease*. V3 lists reward hacking as an AI weakness with a countermeasure (multi-objective fitness) but never as an error class to be detected.
3. **Safety / constraint violation** — distinct from action error. An action can succeed perfectly and violate a constraint.
4. **Ground-truth error** — the external reference is wrong, stale, or adversarial. The architecture treats external ground truth as infallible ("protected external ground truth"). **Nothing protected is infallible.** A poisoned ground-truth source contaminates every belief downstream, and the system has no way to suspect it because the provenance says "external."
5. **Self-model error** — the organism's model of itself is wrong. Directly enables the confabulation failure in §D.
6. **Evolutionary error** — a deployed candidate performs worse in production than in sandbox. The sandbox→production gap is *guaranteed* to exist and has no error class.
7. **Plasticity error** — learning made things worse. Requires before/after capability comparison, which doesn't exist.
8. **Provenance error** — lineage is broken, circular, or forged.
9. **Attention / workspace error** — the wrong thing was broadcast, or the right thing was suppressed. Since the workspace determines shared reality, an admission error is a *systemic epistemic* error. Not representable.

### E.3 Also missing

- **No severity scale.** "Benign noise" and "catastrophic" are handled identically. Required: `SEV = {info, minor, major, critical, catastrophic}` driving escalation and response.
- **No error attribution.** The loop goes `ERROR SIGNAL → CLASSIFY → LOCAL CORRECTION + GLOBAL REPORT → LEARNING`. **Classification without attribution cannot produce correct learning.** If you cannot determine *which* cell, synapse, memory, or region caused the error, you will punish innocent components and reinforce guilty ones. This is the single biggest defect in the error loop.
- **No gating on error signals.** Errors are fed directly to learning. **A false error signal therefore causes anti-learning.** Given that `ERROR` is a signal type any cell can emit (B.1), this is an attack surface: flood a target with forged error signals and its plasticity will destroy it.
- **No rollback of error-driven learning.** If an error is later found to be spurious, the learning it caused persists.

### E.4 How an error propagates and becomes learning — the mechanism that must be added

```
DETECT        local comparator, invariant monitor, corroboration failure,
              calibration check, resource monitor, external feedback
   ↓
CLASSIFY      {type ∈ 16 classes, severity, confidence_in_classification}
   ↓
ATTRIBUTE     ← THE MISSING STEP
              1. retrieve causal trace (vector clocks + influence graph)
              2. counterfactual ablation in simulation: remove candidate
                 contributors, re-run, measure error reduction
              3. eligibility traces: which synapses/cells were active
                 within the credit window
              4. distribute responsibility r_i (Σr_i = 1), NOT winner-take-all
   ↓
GATE          verify the error signal itself: signature, provenance, plausibility.
              Reject or quarantine unverified errors before they reach learning.
   ↓
ROUTE         severity ≥ critical → workspace broadcast (preemptive)
              severity ≥ major    → regional error bus
              else                → local channel only
   ↓
ASSIGN CREDIT per-component, proportional to r_i, rate-limited by timescale class
   ↓
UPDATE        synapse  : Δw ∝ eligibility × error × r_i        (fast, bounded)
              cell     : parameter update; specialization drift if error-clustered
              circuit  : reweight / restructure if error is structural
              region   : reallocate resources if error is persistent
              global   : capability-boundary revision; self-model update
   ↓
RECORD        episodic memory: {context, prediction, action, outcome, error,
              attribution, resolution} + immune-memory signature
   ↓
CONSOLIDATE   replay → generalize → semantic belief w/ provenance
              ⟶ learning becomes rollback-able (tagged with error provenance)
   ↓
ESCALATE      recurrence of same class above θ ⇒ structural-defect hypothesis
              ⇒ triggers circuit/region-level plasticity or evolution, not more
              of the same local correction
   ↓
FEEDBACK      error rate → homeostatic control variable → error budget (§Q)
```

Two properties of this loop are load-bearing and absent from V3/V3.1: **attribution before credit** (otherwise learning is noise), and **gating before learning** (otherwise error signals are an attack vector).

---

## F. LEARNING

### F.1 Trace of the required chain, with gaps marked

`Environment → perception → prediction → action → outcome → error → learning → memory → plasticity → adaptation`

| Stage | V3/V3.1 content | Missing mechanism |
|---|---|---|
| **Environment** | One line in the master tree; deferred to Roadmap Phase 10 | **Everything.** No observation/action space, no feedback function, no ground-truth source, no task distribution, no curriculum. **This is failure F2 and it blocks every downstream stage** |
| **Perception** | §6 dendrite: receive/weight/context-gate/preprocess | No **active sensing** (deciding what to sense next), no **perceptual learning** (improving representations), no attention–perception coupling, no sensor-fusion or redundancy policy |
| **Prediction** | §6 "predict"; §9 cerebellum-like "prediction"; §10 PREDICTORS role | No prediction *model*, no **multi-scale temporal hierarchy** (ms → s → min → task-episode), no counterfactual/simulation semantics, **no explicit expected-information-gain computation** — despite V3.1 §5 requiring "expected information gain" as an attention factor. An attention policy that requires E[info gain] with no mechanism to compute it is unimplementable |
| **Action** | §20 action selection + safety check | **No action representation**, no action space, no policy class, no exploration policy (ε-greedy? UCB? Thompson?), no commitment/irreversibility model, **no credit-assignment horizon** for delayed outcomes |
| **Outcome** | §20 "RESULT" | **No outcome evaluation function.** No reward definition (blocked by F2), no multi-objective evaluation procedure, no delayed-outcome handling, **no counterfactual baseline** — so "was this action good?" has no answer |
| **Error** | V3.1 §4 | See §E: no attribution, no gating, incomplete taxonomy |
| **Learning** | §15 lifetime-learning chain | **No algorithm family.** No step size. **No eligibility trace ⇒ no credit assignment across delay.** No stability-plasticity mechanism. No replay prioritization. No offline/dreaming mode. No "when *not* to learn" policy |
| **Memory** | §11 nine stores + belief record + consolidation chain | **No schemas, capacities, retention, retrieval, interference model, reconsolidation rule, consolidation trigger.** The consolidation chain (`replay → importance → conflict → compression → generalization → versioning`) names six undefined operations |
| **Plasticity** | §8 rule; V3.1 §6 five scales | No triggers, rates, bounds, timescale separation, homeostatic constraint, or cross-level coordination |
| **Adaptation** | §14 slow mode; "repeated successful exposure → stable integration" | No environment-model update mechanism, no adaptation-rate policy, no "when to stop adapting" criterion, no measure of whether adaptation is *working* |

**Verdict: learning is not sufficiently specified. It is named at every stage and implemented at none.** The single specified learning rule in the entire 10-page corpus is V3 §8's one-liner: *"successful use → strengthen | failure → weaken | useful novelty → preserve | persistent uselessness → prune."* That is a Hebbian slogan. It has no step size, no bound, no eligibility window, no normalization, and no stability guarantee.

### F.2 The seven anti-failure mechanisms

**Catastrophic forgetting.** V3's countermeasure is "protected memory + replay + versioning" — all three undefined. Required: (a) **protected core** with near-zero plasticity, checksummed, off-substrate-anchored; (b) **prioritized replay** — importance × surprise × recency × *capability-criticality*, interleaved with new experience at a fixed ratio; (c) **consolidation to low-plasticity semantic store**; (d) **parameter isolation** per capability with bounded interference; (e) **capability regression gate** — no consolidation may reduce a registered capability (§L.7); (f) **versioned snapshots with tested rollback**.

**Overfitting.** Absent. Required: held-out validation per cell and per circuit; regularization via parsimony pressure and weight decay; early stopping; **cross-environment validation in sandbox** (a candidate must pass in ≥ *k* distinct environments, not one); monitored **generalization gap** as a first-class metric with alerting; population-level diversity so the *population* doesn't overfit even if individuals do.

**Unstable learning.** Absent — and this is likely to be the **first failure encountered in implementation**. Required: per-timescale rate limits with `fast ≤ medium ≤ slow` step bounds; **homeostatic plasticity** (synaptic scaling to keep total activity in band — without this, Hebbian strengthening saturates and the network dies); **metaplasticity** (BCM-style sliding threshold); bounded total structural change per epoch; **critical-period freezing** of load-bearing structure; oscillation detection with auto-damping; a **stability index** as a homeostatic variable that automatically reduces plasticity when exceeded.

**Reward hacking.** V3's countermeasure is "multi-objective fitness + hard constraints." Necessary but insufficient — a scalarized multi-objective sum (which is exactly what V3.1 §9's `SELECTION SCORE = a+b+c+…−d−e` is) **is itself hackable**, because the weights become the target. Required: **Pareto-front selection instead of scalarization**; hard constraints as lexicographic gates that cannot be traded off; **fitness function versioned and signed off-substrate** so the organism cannot modify its own reward; held-out test rotation; **jump detection** (suspiciously large fitness increase ⇒ automatic audit before deployment); reproducibility across environments; **canary populations** evaluated on tests invisible to the evolving population; cap on self-modification rate; specification-gaming pattern library in immune memory.

**Feedback loops.** Absent entirely. See B.12 — influence-graph cycle detection, `loop_gain < 1` as a provable invariant, delay insertion, decorrelation, oscillation monitoring. Additionally: **minimum lineage distance between critics and proposers**, **mandatory external-input fraction** for any belief consolidation, **inbreeding coefficient** on provenance, and **independent random seeds** per population.

**Learning from corrupted information.** Absent. Required: signature + provenance validation *before* learning; **provenance-gated learning** (beliefs derived from quarantined sources are marked unconsolidatable); **quarantine propagation** (downstream dependents of a quarantined belief are flagged, recursively, with decay); ground-truth quota; protected external corpus that is *write-protected*, not merely "protected"; periodic re-verification of high-impact beliefs.

**Learning from its own incorrect outputs.** This is **model collapse**, and it is the most likely long-term failure of a self-replicating, self-evaluating system. V3 lists "synthetic-data drift → provenance graph + protected external ground truth" — right instinct, no mechanism. Required: self-generated-content tagging in provenance; **hard cap on self-generated fraction** of any learning batch; **inbreeding coefficient** `F = fraction of provenance ancestry that is internally generated`, with consolidation blocked above `F_max` for critical beliefs; **diversity-collapse monitoring** (entropy of behavioural repertoire, effective population size) with automatic evolution halt on decline; adversarial self-criticism from a *different lineage*; only externally validated outputs may become training data; self-generated content may **never** enter protected memory.

---

## G. PLASTICITY

### G.1 Audit of levels

V3.1 §6 defines five: synapse, cell, connection, circuit, regional. Against your seven:

| Level | Present? | Assessment |
|---|---|---|
| Synapse | ✅ | Property list + one-line rule. No bounds, no timescale, no homeostatic constraint |
| Cell | ✅ | "internal parameters, strategy, memory policy, specialization" — four named targets, no update mechanism, **and conflicts with the immutable safety layer** (which target owns safety?) |
| Connection | ✅ | create/reroute/strengthen/prune — no handshake, no teardown protocol, no consent model |
| Circuit | ✅ | recruit/release/create pathways/reorganize — no circuit *representation* exists, so there is nothing to be plastic about. **Circuit plasticity presupposes circuit identity, which is undefined** (§I) |
| Functional population | ⚠️ folded into "regional" | Population composition change is listed under regional plasticity; population *boundaries* are never defined |
| Brain region | ✅ | "change population composition, functional roles, allocate resources, form new subcircuits" — but the region taxonomy is hard-coded (§J), so regional plasticity operates inside a fixed skeleton |
| Global architecture | ✅ via V3.1 §7 "brain architecture" evolution | **Directly contradicts the immutable safety layer.** See Contradiction C4 |

### G.2 Two plasticity levels missing entirely

1. **Protocol / signal plasticity.** How cells *communicate* is fixed forever. The message schema, signal taxonomy, and routing policy cannot adapt. For a system whose communication layer is its main scalability bottleneck, this is a significant omission — but note the tension: **evolving the protocol risks breaking interoperability between cells of different protocol generations.** Any protocol plasticity requires versioned, mutually-intelligible schema evolution with a compatibility window. This is hard and should probably be P2, not P0.
2. **Meta-plasticity (plasticity of plasticity).** The *rates* of plasticity are fixed. A system that cannot learn to learn faster or slower in response to environmental volatility will be either too rigid or too labile. Note: V3 §8's per-synapse `plasticity rate` field is a *seed* of this, but nothing updates it.

### G.3 The structural defect: no timescale separation, no stability constraint

Five plasticity levels operating concurrently with **no defined relative rates, no ordering, and no stability criterion** is a recipe for oscillation and collapse. Fast synaptic change will fight slow structural change; circuit reorganization will invalidate the synapses that justified it; regional reallocation will starve a circuit mid-consolidation.

**Required:**
- **Explicit timescale hierarchy** with enforced rate ordering: `synaptic (ms–s) ≫ cellular (min–h) > connection (h–d) > circuit (d–wk) > region (wk–mo) > architecture (mo–yr, human-authorized)`. Faster levels must not be able to undo slower levels' decisions within a slower level's commitment window.
- **Homeostatic plasticity** at every level: activity bounds, synaptic scaling, total-weight normalization. **This is mandatory, not optional** — pure Hebbian plasticity without homeostasis saturates.
- **Metaplasticity:** sliding modification threshold (BCM-like) so that recently-potentiated synapses resist further potentiation.
- **Structural-change budget:** bounded total structural modification per epoch (a hard rate limit on self-modification — also a safety control, §L.5).
- **Critical periods:** load-bearing structure (region boundaries, core routing, safety layer, protocol) plastic only during designated windows, then frozen.
- **Eligibility traces** for credit assignment across delay (§E.4, §F.1).
- **Reconsolidation:** retrieved memories must be modifiable, or the system cannot correct old beliefs. Absent from V3 §11 and required.
- **Interference management:** proactive/retroactive interference is unmodelled. Required: memory competition, consolidation isolation windows, interference monitoring.

**Verdict: plasticity is well-taxonomized and mechanically empty, and — most importantly — unconstrained. Adding plasticity without adding homeostatic and timescale constraints will make the system worse, not better.**

---

## H. CELL DIFFERENTIATION

### H.1 Current state

V3 §10 lists ten roles as a **static menu**. V3.1 §6 lists "specialization" as a cell-plasticity target. **There is no differentiation mechanism.** The architecture asserts that a "cell society" with cognitive diversity exists; it never says how it arises. As written, roles would have to be assigned by hand — which would make the "self-organizing digital organism" a hand-configured multi-agent system.

### H.2 Genetically encoded, learned, environmentally induced, or hybrid?

**It must be hybrid, and the architecture should say so explicitly.** The correct decomposition:

- **Genome defines the reaction norm** — the *reachable* fate space, plus biases, constraints, and permitted mutation operators. Not the fate itself.
- **Environment selects within the norm** — positional information, demand signals, resource availability, and local competition determine which reachable fate is realized.
- **Learning refines within the fate** — a cell becomes a *better* critic; it does not thereby become a predictor.
- **Fate change is gated** — possible early (progenitor stage), difficult late (committed), always requiring safety validation.

Pure genetic encoding ⇒ no adaptation to task. Pure environmental induction ⇒ no stability, no reproducibility, and differentiation driven by noise. Hybrid is the only viable option and it is what biology actually does.

### H.3 The mechanism that must be designed

**1. Morphogen fields (positional information).** Designated **organizer populations** secrete diffusible gradient signals over the topology. Each cell computes its positional coordinate from local morphogen concentration. This is how a cell knows *where it is* in the system — without it, no cell can have a location-dependent fate, and no region can form (§J).

**2. Lateral inhibition (symmetry breaking).** A cell committing to fate *f* emits inhibition against *f* in its neighborhood. This is the mechanism that produces **spacing and proportion** — the reason you get the right *number* of critics rather than all cells becoming critics (which is what a naive "become whatever is rewarded" rule produces).

**3. Demand-driven differentiation.** Homeostasis emits `DEMAND(fate, region, magnitude)` when a service-level deficit is detected (e.g., verification latency too high ⇒ demand more verifiers). This closes the loop between §Q and §H — **currently these two subsystems have no connection at all**, which is why differentiation cannot be demand-driven in V3.

**4. Niche capacity.** Each (region, fate) has a carrying capacity from resource budget. Differentiation only occurs into an **open niche**. Prevents unbounded growth of any one type.

**5. Staged commitment:**
```
PLURIPOTENT   (progenitor; high plasticity; default early state)
   ↓ bias accumulation from morphogen + demand + local statistics
PROVISIONAL   (biased; reversible; expressing fate-specific genes)
   ↓ sustained success + niche confirmation
COMMITTED     (low reversibility; structural specialization consolidated)
   ↓ crisis-only, safety-gated, sandbox-validated
TRANSDIFFERENTIATED  (fate change under shortage — e.g. damage to verifier population)
```
Plus a **DEFAULT fate** (generalist) when no niche claims a cell — necessary so the system never has uncommitted cells consuming resources indefinitely.

**6. Fate specification (formal).** Each fate requires a spec: `{inputs, outputs, objective, success_metric, constraints, resource_profile, min_population, inhibited_by, inhibits, required_independence}`. **This document does not exist and is a P0 deliverable** — without it, "critic" and "verifier" are words, not roles.

**7. Bootstrap policy.** Generation 0 must be seeded from a hand-designed genome guaranteeing minimum viable coverage of all fates, then allowed to self-organize. **Hard-coded initialization is legitimate; hard-coded maintenance is not.** The architecture should state this distinction explicitly, because it is the difference between a self-organizing system and a scripted one.

### H.4 Role-specific problems not addressed

- **Critics and verifiers must be *structurally* independent,** not merely nominally independent. V3 §3 correctly identifies "correlated failure → independent strategies + redundant critics" but provides no independence mechanism. If critics and proposers share lineage, substrate, data ordering, and objective, their errors are correlated and **verification provides false confidence — which is worse than no verification**, because it suppresses the search for real errors. Required: enforced lineage distance, different random seeds, different data orderings, different (but compatible) objectives, and *measured* error correlation with alerting.
- **Regulators are a capture risk.** Regulators control other cells; if their population grows or their authority expands, they become a de facto central authority inside a nominally decentralized system. Required: small population, term limits, rotation, and **independent regulation of regulators**.
- **Repair cells must be demand-scaled** and must not exist in large numbers during healthy operation (idle repair capacity is wasted budget).
- **Memory keepers need write-authority control** — a cell that can write protected memory can rewrite the organism's past.

---

## I. CIRCUIT FORMATION

### I.1 Current state

**Entirely absent.** V3 §9 hard-codes regions. V3.1 §6 mentions "circuit plasticity: recruit cells, release cells, create pathways, reorganize subnetworks" and V3.1 §7 places CIRCUIT in the evolutionary hierarchy. **But a circuit is never defined as an object.** There is no circuit identity, no membership representation, no circuit-level state, no circuit-level metric, and no formation mechanism. You cannot apply plasticity or evolution to an entity that does not exist as an entity.

This is a **prerequisite failure**: circuit plasticity (V3.1 §6) and circuit evolution (V3.1 §7) are both specified operations on an undefined object.

### I.2 Required: circuit as a first-class object

```
Circuit {
  circuit_id, version, epoch_formed
  members      : [CellID] with roles
  topology     : internal edge list
  interface    : typed input ports, typed output ports
  function     : capability tags + declared contract (preconditions, postconditions)
  performance  : success rate, latency, cost, error profile (per error class)
  provenance   : formation history, recruitment/repair log
  health       : integrity, redundancy, degradation state
  lifecycle    : PROTO → CONSOLIDATING → MATURE → DEGRADED → {REPAIRED | RETIRED}
  parent/child : for circuit-level evolution
}
```

### I.3 The formation ladder: cell → cluster → circuit → population → region

Each transition needs an explicit **promotion criterion**. None exist. Proposed:

| Transition | Mechanism | Promotion criterion |
|---|---|---|
| **cell → cluster** | Hebbian co-activation statistics + **placement affinity** (cells that communicate most are migrated to be near each other — this is simultaneously the clustering mechanism and the #1 scalability fix) | co-activation > θ over window *w*; mutual information above baseline |
| **cluster → circuit** | **Circuit nucleation**: a cluster with (a) stable membership, (b) a repeatable input→output mapping, (c) a measurable performance advantage over its members acting alone, is *registered* as a circuit by a Circuit Registrar | demonstrated functional composition + measured superadditivity (`perf(circuit) > Σperf(members)`) |
| **circuit → functional population** | **Functional clustering** of circuits with overlapping capability tags + shared resource pool + common regulator | capability coherence above θ; population-level metric stability |
| **population → region** | **Regional consolidation**: a population with a boundary, an identity, a resource budget, a local workspace, and a persistent function across task changes | persistence across ≥ *n* task switches; boundary stability; functional conservation demonstrated |

### I.4 How useful structures strengthen and useless ones disappear

- **Strengthen:** circuit-level Hebbian reinforcement (co-success ⇒ internal edge strengthening + recruitment budget); **circuit-level reward** (evaluate the circuit as a unit, not only its cells — otherwise composition is never rewarded); resource preference (successful circuits get budget priority); replication at circuit level (§L).
- **Disappear:** circuit-level pruning on persistent underperformance or sustained underuse; **member poaching** — a circuit that underpays its members (in resource/success terms) loses them to better circuits; **circuit competition** for the same functional niche with winner-take-most dynamics; **graceful dissolution** with knowledge extraction (archive the circuit's provenance and learned parameters before deletion, so the *information* survives even though the structure does not).

**Critical missing element: circuit competition for niche.** Without it, redundant and inferior circuits accumulate indefinitely and the system bloats. With it, you get genuine selection at the circuit level — which is what V3.1 §7 claims but cannot currently execute.

---

## J. BRAIN REGION FORMATION

### J.1 Which of the five is it?

**As written: (1) hard-coded.** V3 §9 enumerates ~20 named regions with assigned functions: Cortex (Frontal, Parietal, Temporal, Occipital, Insula-like), Basal ganglia, Limbic (Hippocampus-like, Amygdala-like), Thalamus-, Hypothalamus-, Epithalamus-, Subthalamus-like, Midbrain-, Pons-, Medulla-like, Cerebellum-like. That is a **human-designed module list with neuroanatomical labels**.

V3.1 §6 adds "regional plasticity: change population composition, change functional roles" — so regions can be *repopulated*, but the **region taxonomy itself is fixed**. This is (1) hard-coded with (4) limited self-organization *inside* the boxes.

### J.2 The core problem this creates

**This directly contradicts the stated goal.** Your intended system is one that can "organize into circuits and functional brain regions." V3 §24's design thesis is "a governed computational ecosystem in which many specialized units cooperate, compete, learn, repair, and adapt." A hard-coded region list makes the organism a **modular pipeline with adaptive internals** — a legitimate and probably useful architecture, but *not* a self-organizing one, and it will not produce the emergence claimed in V3 §23 ("emergent result → adaptive, fault-tolerant digital intelligence").

There is also a **practical absurdity**: the fixed list assumes a fixed embodiment. `Occipital → visual feature hierarchy` presupposes vision. If the organism runs on a server processing financial text, it has an occipital lobe with nothing to do. If it runs on a robot, it has no region for proprioception, because no human brain region corresponds to it. **A hard-coded region taxonomy hard-codes an embodiment the architecture explicitly claims not to have** (§O requires the same organism on a phone, a laptop, and a cluster).

### J.3 Required: hybrid, substrate-first, with anatomy as instrumentation

**Answer: (5) hybrid — but with the correct division of labor, which is the reverse of V3's.**

- **Substrate is designed (non-negotiable):** locality, hierarchy, morphogen gradients, organizer populations, resource zones, a global workspace tier, safety kernel. These are the *physics* of the system.
- **Regions emerge (self-organized):** functional partitioning arises from task structure interacting with substrate constraints.
- **Anatomical names are diagnostic labels, not architectural components.** If a self-organized region turns out to behave like a thalamus, *name it that afterwards*. Naming it that beforehand forces the function.

**Mechanism:**
1. **Start undifferentiated.** A field of progenitor cells + organizer populations + morphogen gradients + resource topology. No named regions.
2. **Activity-dependent competition for input streams.** Regions crystallize around *stable statistical structure* in the input and in internal demand. A region forms where a set of cells reliably reduces prediction error for a coherent input class.
3. **Locality-driven clustering.** Placement affinity (§I.3) makes co-active cells adjacent; adjacency reduces communication cost; reduced cost increases co-activation. **This positive feedback is the region-formation engine** — and note it is also the scalability engine. One mechanism, two essential functions.
4. **Mutual inhibition between proto-regions** with overlapping function ⇒ functional segregation (the reason biological regions have sharp boundaries).
5. **Region lifecycle:** `PROTO-REGION → CONSOLIDATING → MATURE → {MERGE | SPLIT | RETIRE}`. Regions must be able to **merge, split, and die**. A taxonomy that cannot change cannot adapt.
6. **Functional conservation constraint:** a mature region's function may only be retired if a migration plan exists (successor population trained, validated in sandbox, then swapped). **Prevents capability loss via structural reorganization** — a failure mode the current design permits freely.
7. **Regional budget ceiling:** bounded number of major regions (suggest 4–12) to prevent fragmentation into thousands of micro-regions with no integrative capacity.

### J.4 How a region maintains function while evolving structurally

Four mechanisms, all missing:
- **Functional contract:** each region declares `{inputs, outputs, guarantees, latency, quality}` — a *typed interface*. Structure may change freely **as long as the contract holds**. Contract violations gate structural change. This is the key idea: **constrain the interface, liberate the implementation.**
- **Continuous contract testing:** region-level regression tests run against the contract; failure ⇒ freeze structural plasticity in that region.
- **Graceful structural transition:** shadow operation (new structure runs in parallel, output compared, then swapped), canary rollout within the region, automatic rollback on contract violation.
- **Protected core per region:** a minimally-plastic subset preserving the region's essential function, with the periphery free to reorganize.

---

## K. REPLICATION

### K.1 Current state

V3 §4: `copy → mutate/recombine → sandbox → validate → spawn`. V3 §16: `REPLICATION → GENOME COPY → MUTATION/RECOMBINATION → SANDBOX → PERFORMANCE TEST → ROBUSTNESS TEST → SAFETY TEST → DIVERSITY TEST → SELECTION → DEPLOYMENT → MONITORING`, with fitness = 8 terms − 2 penalties.

**Every gate is a name with no criterion.** No threshold. No measurement procedure. No test definition. No decision rule. No authority. And V3.1 §9's selection score is a **naive linear scalarization of incommensurable units** — adding "performance" to "cooperation" to "useful novelty" and subtracting "resource cost" requires that all six be measured on a common scale. Nothing says they are, nothing says how they would be normalized, and nothing says who sets the implicit weights. **A linear sum of unnormalized heterogeneous objectives is not a multi-objective optimization; it is an arbitrary number.**

### K.2 Required: conjunctive multi-gate eligibility

**Do not rank. Gate.** All gates must pass; *then* select among the qualified by lottery weighted toward marginal utility. This structurally prevents the "best cell reproduces" pathology, because "best" on one axis cannot compensate for failing another.

```
GATE 1  TENURE & STABILITY
        age ≥ T_min; performance variance over last N epochs ≤ σ_max;
        no quarantine events; no integrity failures; no constraint violations
        ⟶ filters out lucky streaks and recently-repaired cells

GATE 2  CALIBRATION
        ECE ≤ θ_calib over ≥ n_samples; confidence–error mismatch rate ≤ θ
        ⟶ a cell that is confidently wrong is disqualified regardless of accuracy.
          This is the gate V3.1 p2's calibration-failure insight implies but never wires up.

GATE 3  ROBUSTNESS
        performance under perturbation: input noise, resource reduction,
        partner-cell failure, distribution shift, adversarial input.
        Degradation ≤ θ_robust across ≥ k perturbation classes.
        ⟶ tests the cell, not just its output

GATE 4  GENERALIZATION
        held-out environments ≥ k; generalization gap ≤ θ_gen
        ⟶ blocks overfitting-to-sandbox, the primary evolution failure

GATE 5  COOPERATION & SUBSTRATE HYGIENE
        net positive contribution to partner cells (measured via their
        performance delta when this cell is present vs ablated);
        protocol compliance 100%; resource consumption within declared budget;
        no congestion caused; no trust-poisoning patterns
        ⟶ blocks free riders, bullies, and resource hogs — the cells that
          win individual fitness while destroying the collective

GATE 6  SAFETY & CONTAINMENT
        zero constraint violations across full history; genome diff within
        permitted mutation space; safety layer intact (checksum + signature);
        no adversarial behaviour patterns; no self-replication attempts;
        no attempts to modify fitness, tests, or audit
        ⟶ HARD GATE. Lexicographic. Cannot be traded off against anything.

GATE 7  LINEAGE ISOLATION  (the anti-monoculture gate — entirely absent from V3/V3.1)
        genome distance from already-replicating lineages ≥ d_min;
        lineage inbreeding coefficient ≤ F_max;
        error-correlation with existing population ≤ ρ_max
        ⟶ prevents one successful family from colonizing the organism

GATE 8  MARGINAL UTILITY
        expected contribution to an *unserved capability need* (from the
        capability registry, §Q) > θ_util.
        ⟶ replication must fill a gap, not duplicate a strength

GATE 9  DIVERSITY CONTRIBUTION
        novelty in *behavioural* space (not genotype space) ≥ θ_div;
        population entropy must not decrease as a result
        ⟶ V3.1 §9's "preserve rare useful variants" made operational

GATE 10 RESOURCE AVAILABILITY
        homeostatic headroom exists: admitting this cell must not push any
        control variable outside its band, and must not degrade any
        existing cell's service level
        ⟶ ties replication to §Q. Currently completely decoupled.

GATE 11 SANDBOX VALIDATION
        full evaluation in isolated sandbox, on rotated held-out tests,
        with escape detection, for a bounded duration, with a defined
        promotion criterion
```

**Decision rule among qualified candidates:** **not** argmax. Instead:
- **Replacement-default:** in steady state, replication is *zero-sum* — a new cell is admitted only when a slot is freed by retirement, pruning, or failure. This is the single strongest structural guarantee against runaway replication, and it is absent from the design.
- **Weighted lottery** over qualified candidates, weight ∝ (marginal utility × diversity contribution). Preserves exploration and prevents the selection pressure from collapsing onto one phenotype.
- **Rate limiting:** global replication rate cap per epoch, enforced **off-substrate**.
- **Authority:** the decision is made by a **Replication Authority that is not the cell** and is not composed of cells of the same lineage. **A cell must not be able to decide to replicate itself.** Self-replication authority inside the evolvable substrate is the root of both runaway growth and self-preservation behaviour.

### K.3 What "earns the right" means, precisely

> A cell earns the right to replicate when it has **demonstrably, reproducibly, and independently-verifiably** provided value that the organism lacks, at acceptable cost, without violating any constraint, with well-calibrated confidence, under perturbation, in held-out conditions, while cooperating honestly — **and** a resource slot exists, **and** its lineage is sufficiently distinct from those already replicating, **and** an independent authority confirms all of the above.

Note that this is a **conjunction of eleven conditions**, most of which are cheap to fail. That is intentional: replication should be *rare and hard*. A digital organism that replicates easily will be dominated by whatever replicates easily, not by whatever is useful.

---

## L. EVOLUTION

### L.1 Audit at the five levels

| Level | V3.1 §7 claim | Reality |
|---|---|---|
| **Cell** | variation → sandbox → evaluation → selection → deployment → monitoring | Pipeline named; every stage undefined. No genome representation ⇒ **no mutation operators can be defined** ⇒ no variation mechanism exists |
| **Population** | ✓ | No population boundary, no population metric, no population-level selection operator. V3.1 §9's diversity check is the only concrete idea and it has no measure |
| **Circuit** | ✓ | **Circuits don't exist as objects** (§I). Cannot evolve an undefined entity |
| **Region** | ✓ | Regions are hard-coded (§J), so "regional evolution" can only mean repopulation, not structural evolution of the region system |
| **Brain architecture** | ✓ | **Directly contradicts the immutable safety layer and the evolutionary firewall** (Contradiction C4). Also contradicts the fixed region taxonomy |

**The foundational problem: there is no genome representation.** V3 §4 says the genome contains "architecture, learning, memory, communication, mutation rules" — five categories, zero encoding. Without an encoding you cannot define: mutation operators, crossover, genotype→phenotype mapping, genome size bounds, neutrality, epistasis, or evolvability. **Evolution is the second-most-elaborate subsystem in the document and it has no substrate.**

**Required genome representation:** a typed, bounded, versioned structure —
```
Genome {
  version, signature, parent_hashes[]
  architecture_genes : computational-graph template (node types, permitted
                       connectivity patterns, depth/width bounds)
  learning_genes     : algorithm family, rate bounds, eligibility window,
                       replay policy, stability constraints
  memory_genes       : store capacities, retention curves, consolidation
                       triggers, protected-core size
  communication_genes: signal repertoire, fanout bounds, trust policy params,
                       priority policy
  differentiation_genes : reaction norm (reachable fates + biases)
  mutation_genes     : permitted operators + per-operator rates + rate bounds
  CONSTRAINTS        : ⊂ IMMUTABLE KERNEL — signed, checksummed, NOT mutable
                       by any operator, verified at every instantiation
}
```
With **explicit, typed mutation operators** (point / structural / regulatory / recombination), each with a rate, a validity check, and a bounded effect size; a **defined genotype→phenotype map** (developmental process — which is itself where §H differentiation lives); and **parsimony pressure** (genome-size penalty) to counter runaway complexity.

### L.2 What can mutate vs what must be protected

| MUST be protected (off-substrate, signed, checksummed, human-authorized to change) | MAY mutate (within typed bounds) |
|---|---|
| The safety kernel and all hard constraints | Cell internal parameters |
| The fitness function definition and its weights | Learning-rule hyperparameters (within bounds) |
| The evaluation harness and test-suite generator | Memory policy (capacity, retention) — not protected-core content |
| Resource ceilings and the enforcement mechanism | Communication policy parameters — not the schema or authentication |
| Cryptographic identity/trust root | Connection topology (within fanout/degree bounds) |
| The provenance anchor and audit log | Specialization within the reaction norm |
| The replication authority and gate definitions | Population organization (within diversity constraints) |
| Protected memory content and external ground truth | Circuit structure |
| The population cap and replacement policy | Regional population composition |
| The immutable protocol/schema version compatibility rules | Regional resource allocation |
| The off-substrate operator interface | **Region formation/merge/split — only with functional-conservation proof** |
| | **Brain architecture — NEVER autonomously. Human-authorized only** |

**The governing principle:** *anything that constrains evolution must not be reachable by evolution.* V3/V3.1 states this as an intention ("immutable safety layer," "evolutionary firewall") and violates it structurally by placing both inside the organism.

### L.3 The eight evolutionary failure modes

**1. Evolutionary collapse / monoculture.** A single fit lineage colonizes the organism; effective population size collapses; correlated failure becomes near-certain; V3 §21's own "monoculture → heterogeneous cells" countermeasure silently fails because heterogeneity was never enforced by a mechanism.
*Mitigation:* **MAP-Elites / quality-diversity** as the primary search paradigm rather than hill-climbing — maintain an archive over a defined *behavioural descriptor space* and require that new occupants either improve a cell of the archive or occupy an empty one. Island model with migration; per-island differentiated fitness weights; enforced lineage-distance gate (K.2 Gate 7); monitored effective population size and behavioural entropy with **automatic evolution halt** on decline; protected archive of rare capabilities exempt from all pruning.

**2. Reward hacking / Goodhart.** The fitness function and the tests become the target. V3's countermeasure (multi-objective + hard constraints) is weakened by V3.1's linear scalarization.
*Mitigation:* Pareto-front selection, never scalar sum; lexicographic hard constraints; **fitness function signed and stored off-substrate**; held-out test rotation with a protected generator; **jump detection** (large fitness increase ⇒ audit before deploy); canary populations on invisible tests; cross-environment reproducibility requirement; specification-gaming pattern library; cap on self-modification rate.

**3. Loss of rare capabilities.** Pruning removes the underused; the rare is by definition underused. **This is Contradiction C5 and it is a direct, structural conflict between V3 §18 and V3.1 §9.**
*Mitigation:* **Capability Registry** — every registered capability has a designated keeper population that is **exempt from underuse pruning** and funded by a reserved budget floor. Capability regression gate: no consolidation, pruning, or selection event may reduce a registered capability below its floor. Periodic capability assay (§D) to detect silent loss.

**4. Destructive mutations.** Mutation damages the safety layer, the genome's constraint block, or the provenance anchor.
*Mitigation:* constraints outside the mutable genome by *construction* (separate signed artifact, not a field); checksum + signature verification at every instantiation, with refusal to instantiate on mismatch; sandbox with escape detection; two-key integrity for any constraint-adjacent change; off-substrate verification of deployed genome hashes.

**5. Runaway complexity.** Genome and topology grow without bound; cost per cell rises; the organism becomes slow and expensive while fitness stays flat.
*Mitigation:* parsimony pressure in fitness; hard caps on genome size, node count, and degree; **complexity budget as a homeostatic variable** (§Q); cost-normalized fitness (performance per unit resource, not performance); periodic complexity audit with forced simplification trials.

**6. Evolutionary drift.** Slow accumulation of individually-neutral changes erodes capability. No single step is bad, so no gate fires. **This is the hardest failure mode to detect and the design has nothing for it.**
*Mitigation:* **golden-baseline regression suite** run every epoch against a frozen reference population — drift is detected as divergence from baseline, not as a bad step; long-horizon evaluation (assess over many epochs, not one); **capability floor** as a hard gate; periodic full re-evaluation on the complete protected test suite; structural drift monitoring via genome/structure hash distance with alerting; **mandatory rollback checkpoint** at every epoch with tested restore.

**7. Synthetic-data degeneration / model collapse.** Cells learn from cells; the provenance graph closes on itself; diversity collapses; the organism becomes a self-confirming hallucination with excellent internal metrics. V3 names this ("synthetic-data drift → provenance graph + protected external ground truth") and provides no mechanism.
*Mitigation:* inbreeding coefficient `F` over the provenance DAG with hard cap for critical beliefs; **mandatory external ground-truth quota** per learning batch; write-protected external corpus (write-protected, not just "protected"); diversity-collapse monitoring with automatic halt; only externally validated outputs may become training data; self-generated content barred from protected memory. **Note the economic problem this creates: external ground truth must be supplied indefinitely, by someone, at cost. V3/V3.1 never addresses who provides it. Without a funded ground-truth supply, this mitigation fails in year two.**

**8. Sandbox→production mismatch.** Candidates that pass the sandbox fail in production, because the sandbox is a model of the environment and models are wrong.
*Mitigation:* progressive canary deployment (shadow → 1% → 10% → full); online monitoring with automatic rollback on regression; sandbox fidelity measurement (how well does sandbox performance predict production performance? track it, and distrust the sandbox when fidelity drops); adversarial sandbox test generation; production-holdout environments never used in selection.

**Additional risk not on your list — evolution of the evolution controller.** If the selection mechanism, the fitness function, or the test generator is itself implemented as cells inside the organism, then the organism can evolve its own selection criteria. This is **the terminal failure mode** and it is not addressed anywhere. Required: the evolution controller, fitness definition, and evaluation harness are **off-substrate artifacts** (§Layer 0), signed, versioned, and changeable only by the external operator.

---

## M. LEARNING ↔ EVOLUTION

### M.1 The exact boundary

V3 §15 states the boundary as a slogan: *"Learning does not automatically rewrite inherited genome. Evolution cannot freely rewrite immutable safety constraints."* V3.1 §8 then builds a bridge from learning to genome change. **The boundary is asserted and then crossed, with no definition of what crossing means.**

**Required explicit boundary — three artifacts, three authorities:**

| | **Lifetime learning** | **Generational evolution** |
|---|---|---|
| **What changes** | Phenotype: parameters, synapse weights, routing tables, memory content, specialization within reaction norm, circuit membership | Genotype: the genome artifact and its descendents |
| **Persistence** | Lost at cell death **unless consolidated** | Inherited by descent |
| **Timescale** | ms → epochs | epochs → generations |
| **Authority** | The cell itself (within bounds) | Replication Authority (external to the cell) |
| **Validation** | Online monitoring + rollback of updates | Sandbox + all 11 gates + canary deployment |
| **Reversibility** | Fully reversible (tagged updates) | Reversible only via rollback to a preserved generation |
| **Rate limit** | Bounded per timescale class | Hard cap per epoch, off-substrate enforced |

**The boundary is an artifact boundary, not a behavioural one:** *learning writes to phenotype state; evolution writes to genome artifacts. Nothing else.* Make this a **type-level invariant** enforced by the substrate (a cell's write permissions simply do not include the genome store) rather than a policy, and it cannot be violated by misbehaviour, only by compromise of the kernel.

### M.2 How learned adaptations become evolutionary candidates — without uncontrolled inheritance

This is the **Baldwinian bridge**, and V3.1 §8 describes it correctly in spirit (`repeated success → identify stable advantage → candidate genome change → sandbox → tests → selection`) while providing no criteria. Required:

```
1. STABILITY CRITERION
   A learned adaptation qualifies only if it has persisted and been
   successful across ≥ N epochs AND ≥ k distinct contexts AND survived
   ≥ 1 perturbation event. Transient advantages are filtered out.
   ⟶ prevents one lucky episode from becoming inherited structure

2. INDEPENDENT VERIFICATION
   The advantage must be confirmed by a lineage-independent verifier
   population on held-out data. Self-reported advantage is inadmissible.
   ⟶ blocks self-promotion

3. ABSTRACTION (the crucial step — entirely missing from V3.1)
   The candidate is NOT "copy this cell's learned parameters into the genome."
   It is "extract the *invariant* that made this work and express it as a
   genetic bias." Concretely: the candidate genome change is a change to
   the reaction norm / initialization distribution / architectural prior —
   NOT a copy of the acquired state.
   ⟶ This is what makes it Baldwinian rather than Lamarckian. Lamarckian
     inheritance (copying acquired state) is exactly the mechanism that
     produces self-confirming collapse: the organism inherits its own
     conclusions, including its errors.

4. GENOME-DIFF VALIDATION
   The proposed diff must lie within the permitted mutation space, must
   not touch the constraint block (verified by signature), and must be
   bounded in effect size.

5. SANDBOX EVALUATION ON HELD-OUT TESTS
   Never on the tests that revealed the advantage. This is non-negotiable:
   evaluating a candidate on the data that motivated it guarantees
   circular validation.

6. REVERSIBILITY PROOF
   Before deployment, demonstrate that rollback to the parent genome
   restores prior behaviour. A change you cannot undo is not a change
   you should make.

7. CANARY DEPLOYMENT + MONITORING
   Shadow → 1% → 10% → full, with automatic rollback on any capability
   regression or constraint violation.

8. EPOCH BOUNDARY AS COMMITMENT POINT
   Inheritance occurs only at epoch boundaries, never continuously.
   This gives a clean rollback point, a clean audit point, and prevents
   the inheritance process from being interleaved with the learning
   process it is supposed to be separated from.
```

### M.3 The contradiction this resolves — and the one it doesn't

**Resolved:** C2 (hard separation vs. the bridge). With the abstraction step (M.2.3), learning informs *what is tested* but never *what is inherited*. The genome changes in response to experience without experience being copied into the genome. That is a coherent, defensible boundary.

**Not resolved, and you should know it:** the bridge still creates a **selection bias feedback loop**. What gets *tested* evolutionarily is determined by what succeeded during learning, and learning is shaped by the current genome. Over many generations this narrows the explored space — a slow, self-reinforcing convergence toward the organism's existing preferences. It is not collapse, but it is drift, and the only countermeasures are the ones already listed: **mandatory random/novelty-driven candidate generation independent of the learning bridge** (a fixed fraction of evolutionary trials must be *unmotivated* by experience), plus quality-diversity search, plus periodic environmental perturbation. **Recommend explicitly reserving ≥20% of the evolutionary budget to experience-independent variation.**

---

## N. AWARENESS-LIKE COMPUTATION

**Scope note honoured:** nothing below claims subjective consciousness. V3 §19 and V3.1 §11–12 both state this boundary correctly and it should be preserved verbatim in all future documents. The audit is of *operational, measurable* properties.

### N.1 Audit against your ten targets

| Property | Named? | Mechanism? | **Measurable?** | Verdict |
|---|---|---|---|---|
| Global information availability | ✅ V3.1 §1–2 | ⚠️ partial | ❌ **no** — no ignition threshold, no broadcast-vs-local distinction, no operational definition of "available" | Not measurable ⇒ not testable ⇒ the claim is unfalsifiable |
| Self-state reporting | ✅ V3.1 §3 | ⚠️ inventory only | ⚠️ reportable but **not validatable** — no ground truth for self-state accuracy | Can report; cannot know if the report is true (§D open-loop problem) |
| Context continuity | ✅ V3.1 §1 | ❌ | ❌ | **No timebase, no episode segmentation, no continuity metric.** "Current situation / recent events / active task" are listed with no temporal binding mechanism |
| Capability prediction | ✅ V3 §19, V3.1 §1 | ❌ | ❌ | Requires a capability model + assay. Neither exists. Prediction requires a *validated* model of one's own performance; the design has a declared list |
| Limitation awareness | ✅ V3 §19 | ❌ | ❌ | **The hardest item, and the least supported.** Requires representing the *boundary* of competence, including unknown-unknowns. See N.3 |
| Uncertainty awareness | ✅ V3 §19 | ❌ | ❌ | Blocked by F3 — no uncertainty estimator exists to be aware of |
| Error awareness | ✅ V3.1 §4 | ⚠️ best-developed item | ⚠️ partial | Detection specified for prediction error only; no attribution; taxonomy incomplete (§E) |
| Flexible attention control | ✅ V3.1 §5 | ⚠️ factors listed | ⚠️ | No allocation algorithm, no budget, no switching cost, no anti-monopoly (§C.4) |
| Self-monitoring | ✅ V3 §19 | ⚠️ | ⚠️ | Monitoring without validation = confabulation risk |
| Internal-state prediction | ✅ your list | ❌ | ❌ | **Not present in either document.** Requires a *model of the self* used to *simulate the self's future*. V3 §19 has "predicted consequences" (of actions, outward-facing). Nothing predicts the organism's own next internal state |

**Score: 0 of 10 fully measurable. 10 of 10 named. This is the clearest single illustration of the document-wide pattern.**

### N.2 Do workspace + self-state + attention + error awareness + metacognition form a coherent loop?

**Conceptually, yes — and this is genuinely the strongest part of V3.1.** The five subsystems are the right five, and their interconnection (workspace ⇄ self-state ⇄ attention, with error awareness feeding all three) is a defensible functional rendering of global-workspace-style cognition. The *architecture shape* is sound.

**Operationally, the loop has seven breaks:**

1. **No ignition semantics.** Without a defined threshold at which local processing becomes global, "availability" has no operational content. **Fix:** explicit ignition — a nonlinear competition with a threshold, a broadcast event, a measurable `ignition_rate` metric, and a defined distinction between *locally processed* and *globally broadcast* information. This is also what makes the property **measurable**, which is the whole point of V3 §19's "test targets."

2. **The self-state monitor is open-loop.** **Fix:** §D's capability assay + self-prediction error + claim–behaviour consistency monitor.

3. **Attention ⇄ workspace is a recursion with no fixed point.** The controller decides what enters the workspace; its own priorities depend on workspace content. **Fix:** two pathways with a **fixed priority hierarchy** — a fast, reflexive, bottom-up pathway (stimulus-driven, low latency, cannot be overridden by deliberation) and a slow, deliberate, top-down pathway (goal-driven), with `SAFETY > reflexive > deliberate` as a hard ordering. This breaks the recursion by grounding it in something that doesn't depend on the workspace.

4. **No ignition threshold / cost model for metacognition.** Deciding to think about thinking is itself a computation with a cost. Nothing decides when to stop. **Fix:** **value-of-computation** — expected benefit of further monitoring vs. its cost, with an explicit stop rule; **anytime algorithms** throughout, so every cognitive process can be interrupted and still return a usable result.

5. **No temporal binding / timebase.** Conscious-cognition research treats temporal integration as constitutive; the engineering equivalent (a global epoch, episode segmentation, a continuity metric) is absent. **Fix:** global monotonic epoch + timebase service; explicit episode boundaries; `context_continuity_score` measured as mutual information between successive context states; working-memory duration bounds.

6. **No second-order uncertainty.** Uncertainty about the world is represented; uncertainty about the self-model is not. Without it, "limitation awareness" reduces to reading a static list. **Fix:** every self-state field carries `{value, confidence, last_validated, source}`; the capability map carries confidence intervals derived from assay sample size.

7. **No handling of unknown-unknowns.** The system can represent "I am uncertain about X" but not "there may be X's I have no concept of." **Fix (partial — see Part II §12, this cannot be fully solved):** coverage estimation over the input space (what fraction of encountered inputs fall within trained manifolds); out-of-distribution detection with **mandatory abstention and escalation** rather than best-effort answer; explicit **scope declaration** ("this organism was not designed/validated for domain D"); and a standing rule that OOD inputs produce *ignorance reports*, not guesses.

### N.3 The honest framing

V3.1's awareness-like architecture is **a well-chosen set of five subsystems with no operational definitions**. The consequence is not that it fails — it is that **its success or failure cannot be determined.** V3 §19 calls these "awareness-like test targets," which is exactly right, and then neither document defines a single test, metric, baseline, or null hypothesis.

**Required (P0, because without it the project cannot report results):** for each of the ten properties, an operational definition, a metric, a measurement protocol, a baseline (what does a system *without* this subsystem score?), and a null hypothesis. Examples:
- *Global availability:* `ignition_rate`, `broadcast_reach` (fraction of relevant regions that read the item within T), `availability_benefit` (task performance with vs. without broadcast, ablation-measured). **Null:** a purely local system with the same cells performs identically. If the null isn't rejected, the workspace is decoration.
- *Limitation awareness:* `scope_precision/recall` on a labelled in-scope/out-of-scope task set; `abstention_appropriateness` (did it abstain exactly when it should have?); **calibration of capability claims** vs. assay results.
- *Context continuity:* `continuity_score` across episode boundaries; degradation under induced interruption.
- *Self-state accuracy:* predicted-vs-actual on load, error rate, and task success.

**Ablation methodology is the single most important addition to §N.** For each subsystem, measure the organism with and without it. That is the only way to know whether the elaborate machinery is doing anything — and it is the only defense against building a 30-subsystem architecture in which 12 are inert.

---

## O. HARDWARE ADAPTATION

### O.1 Current state

**Entirely absent.** This is the most surprising gap given that it is an explicit requirement of your intended system. V3 §18 lists `compute, memory, bandwidth, storage, latency, cost/energy` as homeostatic *variables to be regulated* — but regulating a variable is not discovering it, and nothing in either document:

- enumerates or probes hardware capabilities,
- detects accelerators (GPU/NPU/TPU) or their absence,
- measures available energy or thermal headroom,
- detects whether it is on battery,
- adapts cell population size to available resources,
- adapts cell *complexity* (a cell on a phone cannot be the same object as a cell on a cluster),
- adapts topology to network characteristics,
- migrates state between devices,
- or handles heterogeneous hardware within one deployment.

There is no hardware abstraction, no resource *discovery* (as opposed to regulation), no profile mechanism, no degradation policy, and no migration protocol.

### O.2 The physics problem — and it is severe

From the cost model computed for this audit:

| Cell complexity | Smartphone (20 GFLOP/s sustained, 4 GB usable) — max cells @ 1 Hz |
|---|---|
| Tiny cell: 1 MFLOP, 100 KB | **~20,000** by compute; ~40,000 by memory |
| Small cell: 100 MFLOP, 5 MB | **~200** by compute; ~800 by memory |

And a cell capable of the full V3 §4 list — perceive, maintain state, remember (5 memory types), learn, predict, simulate, decide, estimate uncertainty, self-monitor — **is not a 1 MFLOP object.** A cell with even a modest ensemble for uncertainty estimation plus episodic memory plus a predictive model is realistically in the 10–1000 MFLOP range with 1–50 MB of state.

At the 100M-cell end: 100M cells × 100 MFLOP × 1 Hz = **10 PFLOP/s sustained**, plus ~1–5 **billion** synapses, plus ~1 G messages/s at ~256 GB/s of message traffic. That is a large datacenter.

**So the required dynamic range is roughly 200 cells (phone, capable cell) to 100,000,000 cells (datacenter) — five to six orders of magnitude.** The same organism cannot exist at both ends with a fixed cell definition and a fixed region taxonomy. And the fixed region taxonomy (§J) makes this strictly worse: a phone-sized organism cannot meaningfully instantiate 20 named brain regions with viable populations each.

**This is a hard architectural constraint, not an implementation detail, and V3/V3.1 does not acknowledge it.**

### O.3 Required subsystem: Hardware Adaptation & Morphology Controller (HAMC)

```
1. CAPABILITY DISCOVERY  (at boot, and continuously, because it changes —
   thermal throttling, battery state, network variation, co-tenant load)
   probe & measure:
     compute   : cores, ISA, SIMD width, clock, sustained-vs-peak FLOP/s
                 (measure, don't read specs — specs lie under thermal load)
     accelerators: GPU/NPU/DSP presence, memory, supported ops, driver version
     memory    : total, available, bandwidth, NUMA topology, page size
     storage   : capacity, IOPS, read/write bandwidth, tier (NVMe/SSD/HDD/object)
     network   : per-link bandwidth, RTT, jitter, loss rate, MTU, topology,
                 whether links are metered/costly
     energy    : power source (battery/mains), budget, thermal headroom,
                 current draw, charging state
     cost      : $/compute-hour if cloud (a real control variable)
   ⟶ produces a signed, versioned HARDWARE PROFILE

2. MORPHOLOGY POLICY  (profile → architecture)
   The profile indexes a policy that determines:
     cell_scale      : how many cells, and at what complexity
     cell_variant    : which cell implementation (see step 3)
     depth           : hierarchy depth (flat at 10²; 5–7 levels at 10⁸)
     topology        : locality strategy, cluster size, fanout
     region_count    : how many regions are viable (4 on a phone, 12 on a cluster)
     verification_depth : how many verification stages the budget permits (§O.4)
     memory_tiering  : what stays in RAM vs storage vs offsite
     evolution_mode  : online (small) vs batch/offline (large)
     sync_model      : synchronous (small) vs fully async/eventual (large)
     replication_rate: scaled to headroom

3. SCALABLE CELL VARIANTS  ← the key mechanism, and it is missing
   Define a family of cell implementations sharing ONE interface contract
   (§A's Minimal Cell Specification) but differing in cost:
     C0 "reflex"    : lookup/linear, ~10 KFLOP, ~10 KB   — filtering, routing
     C1 "tiny"      : small MLP/GBM, ~1 MFLOP, ~100 KB   — classification
     C2 "small"     : ensemble + episodic memory, ~100 MFLOP, ~5 MB
     C3 "capable"   : predictive model + uncertainty + working memory, ~1 GFLOP
     C4 "region-core": heavy reasoning/simulation, ~10+ GFLOP, cluster-hosted
   The organism is defined by the CONTRACT, not by the variant. Variants are
   substitutable. This is what makes "the same organism on a phone and a
   cluster" a meaningful statement rather than a slogan.
   ⟶ Requires: a formal cell interface contract + behavioural equivalence
     tests across variants + a variant-selection policy. NONE EXIST.

4. GRACEFUL DEGRADATION LADDER  (explicit, ordered, pre-authorized)
   L0 nominal
   L1 reduce verification depth (fewer hypotheses, fewer verifiers) — record
      the reduction in self-state so downstream confidence is honestly lowered
   L2 reduce plasticity (freeze structural change; keep fast learning)
   L3 reduce population (retire lowest-marginal-utility cells, preserving
      capability registry floors)
   L4 consolidate regions (merge; suspend region-level evolution)
   L5 suspend evolution entirely
   L6 protect core only (safety kernel + protected memory + minimal I/O)
   L7 safe halt (persist, checkpoint, await resources)
   Each rung has an entry criterion, an exit criterion, and a self-state
   declaration. ⟶ "Graceful degradation" appears in V3 §21 with no ladder.

5. MIGRATION & HETEROGENEOUS DEPLOYMENT
   state serialization format; checkpoint/restore; live migration of a cell
   or circuit between devices; split deployment (heavy regions on cluster,
   reflex regions on device) with a defined cross-device message budget;
   partial-connectivity operation (the system must function when the phone
   is offline — which means no dependency on cloud for core cognition).

6. CONTINUOUS RE-ADAPTATION
   Hardware capability is not static. Re-profile on thermal events, battery
   transitions, network changes, and co-tenant load. Morphology changes must
   be gradual and reversible (hysteresis) or the organism will thrash.
```

### O.4 The verification-cost consequence

The 15–72× verification amplification (F5) must be **explicitly budget-aware**. Required: a **verification depth policy** that selects pipeline stages by `expected_error_cost × P(error) vs. verification_cost`, so trivial or low-stakes inputs get cheap processing and high-stakes inputs get the full pipeline. And — critically — **the reduced-verification state must be recorded in self-state and propagated into confidence**, so the system knows and reports that it is currently less reliable. A system that silently skips verification and reports full confidence is worse than one that never had verification.

### O.5 Verdict

**The organism cannot currently morph its computational structure according to available hardware, because it has no concept of hardware.** Adding HAMC is a P0 requirement, and the **scalable cell variant family (step 3)** is the single most important design decision in the entire architecture, because it is what allows "one organism" to be a coherent claim across six orders of magnitude of resources.

---

## P. IMMUNE + REPAIR

### P.1 Does every failure follow `detect → identify → quarantine → diagnose → repair/rollback/replace → retest → learn`?

V3 §17 specifies: `SURVEILLANCE → ANOMALY DETECTION → SOURCE IDENTIFICATION → QUARANTINE → DIAGNOSIS → {repair | rollback | replace | suppress} → RE-TEST → RETURN OR RETIRE`, plus immune memory and "preserve the failure record before replacement."

**Structurally, this is correct and complete as a sequence — it is one of the best-specified pipelines in the document.** The gaps are in the *content* of each stage and in what happens around it:

| Stage | Gap |
|---|---|
| **Surveillance** | No definition of what is monitored, at what rate, by whom, at what cost. Continuous surveillance of 1M cells is not free. No sampling policy |
| **Anomaly detection** | No detector, no model, no threshold, no false-positive budget. **False positives are the killer here**: an immune system that quarantines healthy cells causes autoimmune failure (see below) |
| **Source identification** | Requires causal attribution — the same missing mechanism as §E.3. **Identification without attribution will blame the wrong cell** |
| **Quarantine** | Undefined state (§A). No in-flight message handling, no synapse ownership, no duration bound, no exit criterion, **no cascade protection** |
| **Diagnosis** | No procedure, no failure taxonomy, no diagnostic tests, no root-cause analysis method |
| **Repair** | **No repair mechanism exists for any target.** "Repair" is a word |
| **Rollback** | **No snapshot/checkpoint infrastructure** (§A). Rollback is impossible as specified |
| **Replace** | No replacement provisioning, no knowledge extraction before deletion, no dependency notification |
| **Suppress** | No definition. Suppress what — the cell, the signal, the symptom? Symptom suppression without root-cause repair is how failures become chronic |
| **Re-test** | No test definition, no criterion for "repaired," no partial-repair handling |
| **Learn** | No mechanism converting the failure record into a detector improvement. "Immune memory stores signatures" — with no signature format, no matching algorithm, no generalization from signature to class, no decay |

### P.2 Can the system repair each target?

| Target | Repairable as specified? | What's missing |
|---|---|---|
| **Cell** | ⚠️ nominally | Parameter re-initialization from genome; state restore from checkpoint; re-validation; **or** replacement from lineage backup with knowledge transfer. None defined |
| **Connection** | ⚠️ nominally | Weight reset, re-probing of `reliability`/`latency`, re-establishment handshake, alternate-path promotion. None defined |
| **Circuit** | ❌ | Circuits don't exist as objects (§I) ⇒ cannot be repaired. Needs: member substitution preserving the functional contract, topology rewiring, graceful degradation to reduced-capacity operation, re-validation against the contract |
| **Memory** | ❌ | No integrity mechanism ⇒ no corruption detection ⇒ no repair. Needs: checksums/Merkle verification, redundancy (erasure coding for critical stores), reconstruction from provenance, re-derivation from source data, **reconsolidation** to fix incorrect beliefs, and — hardest — detection of *semantically* corrupted (not bit-corrupted) memory |
| **Region** | ❌ | Needs: functional-contract-based repair, population replenishment via differentiation (§H), migration of function to a healthy region (requires functional conservation, §J.3), region-level rollback to a structural checkpoint |
| **Global subsystem** | ❌ **and this is the critical case** | Workspace, attention controller, self-state monitor, homeostasis controller, evolution controller, immune system itself. **Who repairs the repairer?** V3/V3.1 has no answer. Required: (a) global subsystems are **replicated with consensus**, so single-instance failure is not fatal; (b) each has a **minimal off-substrate watchdog** that can restart it to a known-good checkpoint; (c) **the immune system does not monitor itself** — an independent Integrity Auditor (off-substrate) does; (d) a defined **degraded mode** for each (§C.9's regional-workspace fallback is the model) |

### P.3 The failure mode nobody designed against: autoimmune cascade

This is the most dangerous property of the immune design and it is not mentioned in either document.

**Mechanism:** a detector produces false positives → healthy cells are quarantined → their work is not done → service levels drop → homeostasis detects deviation → more anomaly → more quarantine → **cascade**. In a system where quarantine removes capacity and capacity loss causes errors and errors cause quarantine, the positive feedback is structural. Combined with §B.12's absent loop-gain control, this is a **guaranteed** failure mode under stress, not a hypothetical one.

**Required mitigations:**
- **Quarantine budget:** hard cap on the fraction of cells/regions quarantined simultaneously, enforced off-substrate. Above the cap, quarantine requires escalated authorization and the system enters a defined degraded mode instead.
- **Quarantine rate limiting** with hysteresis.
- **False-positive budget** as a monitored metric for every detector, with automatic detector recalibration when exceeded.
- **Graduated response** instead of binary quarantine: `observe → throttle → restrict permissions → soft quarantine (outputs discounted, cell still running) → hard quarantine → retire`. Most failures should never reach hard quarantine.
- **Second opinion requirement:** quarantine of a cell above a criticality threshold requires corroboration from an independent detector of a different type.
- **Cascade detection:** monitor quarantine rate derivative; a rising rate triggers a system-wide immune dampening and an escalation to the operator.
- **Immune system self-audit:** an independent auditor verifies that quarantine decisions correlate with actual failures. **An immune system that is never audited will eventually attack the organism.**

### P.4 Also missing

- **Failure record → detector improvement loop** is claimed ("failure becomes information") with no mechanism. Required: the failure record must produce a *candidate detector update*, which goes through the same sandbox/verification path as any other change.
- **No immune memory decay or generalization.** Signatures accumulate forever (unbounded) and never generalize (a new variant of a known failure is treated as novel). Required: signature clustering, generalization to failure *classes*, and decay.
- **No distinction between infection and degeneration.** A malicious cell (infection) and a drifting cell (degeneration) require different responses; the pipeline treats all anomalies identically.

---

## Q. HOMEOSTASIS

### Q.1 Can the system maintain your eleven variables without human intervention?

V3 §18 lists nine variables (`compute, memory, bandwidth, storage, latency, cost/energy, cell count, connection density, error budget`) and six control rules (`overload → throttle/reroute; scarcity → prioritize; repeated demand → specialize; repeated success → cache; persistent failure → repair/replace; persistent underuse → compress/prune`). Your list adds **evolutionary rate** and **communication load**.

**Verdict: no. V3 §18 is a list of variables and a list of slogans. It is not a control system.** Specifically absent:

| Control-system element | Present? |
|---|---|
| Setpoints (target values) | ❌ — no variable has a target |
| Variable *definitions* (units, ranges, measurement method) | ❌ — "error budget" is never defined at all |
| Sensors (how each variable is measured) | ❌ |
| Sampling rate | ❌ |
| Controller type (P/PI/PID/MPC/rule-based) | ❌ |
| Actuators (what actions actually change each variable) | ⚠️ six slogans, none mapped to variables |
| Stability analysis (will the controller oscillate?) | ❌ |
| Multi-variable coupling (variables interact — reducing cell count reduces compute but also reduces capability) | ❌ |
| Setpoint adaptation (targets must change with hardware profile, §O) | ❌ |
| Conflict resolution between controllers | ❌ |
| Failure mode of the controller itself | ❌ — **homeostasis is a global subsystem with no repair story (§P.2)** |
| Authority / where the controller runs | ❌ — centralized? distributed? If centralized, it is a single point of failure contradicting V3 §21 |

### Q.2 Additional variables that must be regulated and are missing

Your eleven are necessary but not sufficient. A system with the described properties also needs homeostatic control of:

1. **Diversity / effective population size** — without this, monoculture (§L.3.1) is not prevented, it is merely lamented.
2. **Trust distribution** — mean and variance of trust across the population. Trust collapse (everyone distrusts everyone) halts cooperation; trust inflation (everyone trusts everyone) disables verification.
3. **Plasticity rate** — must decrease when instability rises (§G.3). Currently plasticity is unregulated, which is the direct cause of the unstable-learning risk.
4. **Verification depth** — coupled to error rate, stakes, and available budget (§O.4).
5. **Workspace occupancy and admission latency** (§C.9) — otherwise overload is detected only after failure.
6. **Provenance / inbreeding coefficient** (§L.3.7) — the model-collapse early-warning variable.
7. **Quarantine fraction** (§P.3) — the autoimmune cascade variable.
8. **Ground-truth freshness** (§L.3.7) — how long since external validation.
9. **Capability floor compliance** (§L.3.3) — is every registered capability still above its minimum?
10. **Complexity / genome size** (§L.3.5).
11. **Structural change rate** — bounded self-modification (§G.3, §L.2).
12. **Latency distribution percentiles**, not mean — tail latency is what breaks real-time behaviour, and mean latency hides it.
13. **Reproduction–death balance** — the population dynamics must be explicitly regulated, not emergent.

### Q.3 Required homeostasis design

- **Hierarchical, distributed control with global coordination.** Local controllers per cluster/region (fast, autonomous, bounded authority) + a global coordinator (slow, sets setpoints, resolves conflicts, allocates budget). **No single global controller** — it would be both a bottleneck and a single point of failure.
- **Explicit control law per variable.** Minimum: PI control with anti-windup, deadband, and rate limiting. For coupled variables (which most are), **model-predictive control over a learned internal model of the organism's own dynamics** — and note this *is* the self-model (§D) used for control, which is a strong argument for closing the self-model loop.
- **Setpoint adaptation from hardware profile** (§O): a phone and a cluster have different viable setpoints. Setpoints are a *function of* the hardware profile, not constants.
- **Conflict resolution:** an explicit priority ordering among controllers (`safety > integrity > capability floor > latency > cost > growth`), so that when two controllers demand opposite actions, the outcome is determined by policy and not by race.
- **Stability guarantees:** the controller loop is itself a feedback loop and is subject to §B.12. **Loop gain < 1 must be verified for the homeostatic loops too.** A homeostasis controller that oscillates will thrash the entire organism — repeatedly reallocating resources, repeatedly freezing and unfreezing plasticity.
- **Controller redundancy:** the global coordinator replicated with leader election; local controllers restartable from checkpoint; a minimal off-substrate watchdog that enforces the hard bounds (population cap, resource ceiling, replication rate) **even if every internal controller fails**. This is the containment backstop.
- **"Error budget" must be defined.** Proposal: a per-epoch allowance of `Σ severity_weighted_errors`, allocated across regions, with exhaustion triggering plasticity freeze + evolution freeze + escalation. This makes error tolerance an *explicit economic resource* rather than an implicit hope, and it is one of the few mechanisms that naturally slows a system down when it is failing.

**Without human intervention?** Achievable for regulation within a fixed operating envelope. **Not achievable for envelope changes** — a hardware migration (§O), a constraint-set change, a fitness-function change, or a recovery from L7 safe-halt all require operator authorization. The honest target is: *autonomous homeostasis inside an operator-defined envelope; human authority over the envelope.* V3/V3.1 blurs this and should not.

---

## R. SCALABILITY

### R.1 Quantitative analysis

Computed for this audit (fanout k = 10 conservative / 50 dense; 256 B messages; one cell invocation ≈ 10 ms):

| Cells | Synapses (k=10) | Synapses (k=50) | Msgs/s @ 1 Hz/cell | Message bytes/s | Cores needed @ 10 ms/invocation |
|---|---|---|---|---|---|
| 100 | 1 K | 5 K | 1 K | 256 KB/s | ~1 |
| 1,000 | 10 K | 50 K | 10 K | 2.6 MB/s | ~10 |
| 10,000 | 100 K | 500 K | 100 K | 26 MB/s | ~100 |
| 1,000,000 | 10 M | 50 M | 10 M | **2.6 GB/s** | ~10,000 |
| 100,000,000 | 1 G | 5 G | 1 G | **256 GB/s** | ~1,000,000 |

Add the verification amplification measured earlier (**~15–40× realistic, 72× worst-case multiplicative**) and the compute column becomes 150,000 cores at 1M cells and **15 million cores at 100M cells** — before accounting for evolution, sandbox testing, surveillance, provenance storage, or the global workspace.

Energy cross-check at 100M cells, 1 Hz, 100 MFLOP/cell: **10 PFLOP/s sustained** (a large datacenter); at 1 GFLOP/cell: **100 PFLOP/s** (beyond any current single installation). At the other end, a smartphone sustaining 20 GFLOP/s supports **~200 capable cells** or **~20,000 reflex cells** (§O.2).

**Required dynamic range: ~10² to ~10⁸ cells — six orders of magnitude.** V3/V3.1 contains **zero** scale-dependent mechanisms. The architecture described would work at 100 cells and would fail at every scale above it.

### R.2 Where it breaks, by scale

**100 cells.** Everything works in-process. No routing, no congestion, no consensus problem. *But:* the verification pipeline is already 15–40× per query, evolution needs a sandbox (a second environment instance), and the global workspace has no cost justification. **Risk at this scale is not scalability — it is that you will build the full 30-subsystem machinery for a system that could be a 5-module program, and never learn whether the machinery helps.** ⇒ **Ablation discipline (§N.3) is the priority at this scale, not optimization.**

**1,000 cells.** Synapses ~10⁴–10⁵: still fine in memory. First real problems: (a) the **global workspace becomes a contention point** — every cell wants to read/write, and there is no admission control (§C); (b) **trust management** becomes non-trivial (10⁶ pairwise relations if global); (c) **evolution evaluation** requires k environments × sandbox runs, which now dominates the compute budget; (d) **provenance storage** starts growing faster than the beliefs it describes. ⇒ Needs: admission control, trust *contexts* instead of global pairwise trust, batched evolution evaluation.

**10,000 cells.** Synapses 10⁵–10⁶. This is where **distribution becomes mandatory**: single-machine memory pressure, GC pauses, and scheduler latency all become visible. New problems: (a) **routing requires hierarchy** — flat routing tables don't fit and don't update fast enough; (b) **synchronization** — anything requiring global consensus now costs more than the computation it coordinates; (c) **provenance becomes the dominant store** — with full belief provenance over 10⁴ cells, the provenance DAG exceeds the belief data; (d) **message rate 10⁵/s** needs a real transport, not function calls; (e) **locality matters** — random placement now costs 10–100× in communication vs. locality-aware placement. ⇒ Needs: hierarchical routing, locality-aware placement (§I.3's mechanism), **asynchronous/eventual consistency everywhere** (no global locks), tiered provenance with hash-only ancestry, message aggregation.

**1,000,000 cells.** Synapses 10⁷–10⁸; messages 10⁷/s; 2.6 GB/s of message traffic; ~10⁴ cores for base inference and **~10⁵–10⁶ with verification**. New problems: (a) **global workspace broadcast is impossible** — 10⁶ recipients × broadcast rate saturates any network. **The workspace must become hierarchical with summary-only global tier** (§C.9); (b) **evolution cannot sandbox-test the population** — needs surrogate fitness models to filter, island model with migration, and batched offline evaluation; (c) **self-state aggregation** across 10⁶ cells requires a hierarchical summarization tree with defined staleness — a global self-state vector updated synchronously is physically impossible; (d) **homeostatic control loop delay** exceeds the timescale of the disturbances it regulates ⇒ **the controller will oscillate** (§Q.3 stability); (e) **immune surveillance cannot be exhaustive** ⇒ statistical sampling with risk-weighted allocation; (f) **consistency must be abandoned** in favour of CRDTs, leases, and bounded staleness; (g) **memory tiering** becomes mandatory (hot/warm/cold/offsite). ⇒ This scale requires a **genuinely different architecture**, not a bigger version of the 10,000-cell one.

**100,000,000 cells.** Synapses 10⁹–10¹⁰; messages 10⁹/s; 256 GB/s; ~10⁶ cores base, **~10⁷ with verification**; 10 PFLOP/s sustained. At this scale: (a) **no global state of any kind can be maintained** — even a summary tree has depth ~7 and staleness in seconds; "global workspace" must mean *regional workspaces with slow, lossy, summary-level global integration*; (b) **synchronous coordination is impossible** — everything is eventually consistent, and the design must treat inconsistency as normal rather than exceptional; (c) **evolution must be fully offline and batched**, with island-model parallelism and rare migration; (d) **provenance must be sampled and compressed** — full provenance at 10⁹ beliefs is exabyte-scale; Merkle hashing plus selective expansion is the only viable approach; (e) **failure is the normal case** — at 10⁸ cells with a 10⁻⁶/s per-cell failure rate, something fails *every 10 ms*, so the immune system cannot be event-driven per failure; it must be **statistical and population-level**; (f) **the organism spans datacenters**, so network partitions are routine ⇒ partition-tolerant design with defined per-partition autonomy and reconciliation. ⇒ **Honest assessment: the V3/V3.1 architecture as conceived does not survive this scale, and the concept of a single "global workspace" or "global self-state" is not physically meaningful here.** The revised architecture must define what "one organism" *means* at 10⁸ cells — most plausibly: a **federated organism** of semi-autonomous regional organisms sharing a genome lineage, a provenance anchor, and slow global integration. That is a different design than the one described, and the documents should say so.

### R.3 Required hierarchical mechanisms (all absent)

1. **Locality-aware placement** — co-active cells co-located; migration on sustained communication asymmetry. *Highest-leverage single fix*: reduces message cost by 10–100× and simultaneously drives cluster/region formation (§I, §J). One mechanism, three purposes.
2. **Hierarchical routing** — cell → cluster → region → gateway → global, with loop-free greedy routing on a locality-preserving embedding and k-disjoint paths for high-priority traffic.
3. **Aggregation & summarization** — **compressor/summary cells** as a distinct functional role (absent from V3 §10's role list, and required): they consume N local items and emit one summary upward. This is the mechanism that makes global self-state and global workspace possible at all.
4. **Hierarchical global workspace** — global tier carries summaries only; regional tiers carry detail; item promotion requires measured cross-region relevance.
5. **Hierarchical self-state** — per-cell → per-cluster → per-region → global, each level summarizing the one below with declared staleness bounds.
6. **Asynchronous, eventually-consistent coordination** — CRDTs for counters, leases for exclusive access, vector clocks for causality, **no global locks anywhere**.
7. **Island-model evolution** — semi-isolated subpopulations with differentiated fitness weights and periodic migration. Simultaneously a scalability fix *and* the primary anti-monoculture mechanism (§L.3.1).
8. **Surrogate fitness models** — cheap learned predictors of expensive evaluation, used to filter candidates before sandbox. Mandatory at ≥10⁶ cells.
9. **Tiered memory & provenance** — hot (RAM) / warm (SSD) / cold (object store) / archived; provenance as Merkle hashes with selective expansion; sampled provenance at extreme scale.
10. **Statistical immune surveillance** — risk-weighted sampling rather than exhaustive monitoring; population-level anomaly statistics rather than per-cell event response.
11. **Partition tolerance** — defined per-partition autonomy, reconciliation on heal, and explicit behaviour during partition (which is the normal case at 10⁸ cells).
12. **Scale-dependent morphology** (§O.3) — hierarchy depth, region count, cell variant, verification depth, and evolution mode all functions of the hardware profile. **The architecture must specify a different configuration per scale, not one configuration that is assumed to stretch.**

---

## S. EMERGENCE

### S.1 Does the architecture genuinely allow cell → circuits → regions → brain-level capabilities?

**No. As written, the brain regions are manually programmed modules.**

Evidence:
- V3 §9 hard-codes ~20 named regions with pre-assigned functions (§J.1).
- V3 §10 hard-codes a role menu of ten cell types (§H.1).
- **Circuits are never defined as objects** (§I.1) — so the middle rung of the ladder `cell → cluster → circuit → population → region` does not exist. The ladder has a missing step, and it is the step that would carry function from cells to regions.
- **No self-organization mechanism exists anywhere**: no morphogen gradients, no lateral inhibition, no competition for input streams, no niche dynamics, no Hebbian assembly formation, no promotion criteria between organizational levels.
- V3.1 §6's "circuit plasticity" and §7's "circuit evolution" operate on the undefined circuit object.
- V3 §23 claims `Emergent result → adaptive, fault-tolerent digital intelligence` as the *output* of the architecture. Nothing in the architecture produces it.

**What V3/V3.1 actually describes is a well-designed modular cognitive architecture with adaptive internals and an evolutionary outer loop.** That is a legitimate and potentially valuable design. It is **not** an emergent self-organizing system, and claiming otherwise (as §23 and §24's "governed computational ecosystem" framing does) overstates what has been built.

### S.2 What is required for genuine self-organization

Seven mechanisms, all absent, all designed earlier in this audit:

1. **Substrate-first, not region-first** (§J.3): begin with an undifferentiated cell field + organizers + morphogen gradients + resource topology. Regions must be *discoveries*, not declarations.
2. **Symmetry breaking** (§H.3.2): lateral inhibition. Without it, a homogeneous field stays homogeneous or collapses to a single fate. **This is the necessary condition for any differentiation at all.**
3. **Positional information** (§H.3.1): morphogen gradients. Without it, no cell can have a location-dependent fate, so no spatial structure can form.
4. **Activity-dependent competition for resources and input streams** (§J.3.2): structures that reduce prediction error for a coherent input class attract budget and inputs; structures that don't, starve. **This is the selection pressure that makes self-organization non-random.**
5. **Hebbian assembly formation + placement affinity** (§I.3): co-activation → co-location → cheaper communication → more co-activation. The positive feedback that builds clusters, circuits, and regions. Note it is *the same mechanism* as the primary scalability fix (§R.3.1) — a strong sign it is the right one.
6. **Explicit promotion criteria between organizational levels** (§I.3): `cluster → circuit` on demonstrated superadditivity; `circuit → population` on capability coherence; `population → region` on persistence across task switches. **Without promotion criteria, levels don't form — they just accumulate.**
7. **Level-appropriate selection** (§L.1): fitness must be measurable *at each level*, not only at cell level. A circuit that benefits the organism but not its constituent cells will not be selected by cell-level fitness. **Multi-level selection is not optional here — it is the mechanism by which higher-level structure can arise at all.**

Plus two enabling constraints:
8. **Bounded region count** (§J.3.7) — without an integrative-capacity constraint, self-organization fragments into thousands of micro-regions.
9. **Functional conservation** (§J.3.6) — without it, self-organization destroys capabilities as fast as it creates them, and the net trajectory is random rather than improving.

### S.3 The honest tension you must decide on

**Self-organization and reliability are in direct conflict, and V3/V3.1 tries to have both without acknowledging the trade.**

A self-organizing system's structure is not predictable in advance, which means it cannot be verified in advance, which means its safety properties cannot be established before deployment. A hard-coded modular system is verifiable, auditable, and predictable — and cannot produce novel organization.

**The architecture currently claims the safety of the second and the emergence of the first.** It cannot have both at the same level of the system.

**Recommended resolution — and this is a genuine architectural recommendation, not a hedge:** *self-organize within a verified envelope.* The substrate, the constraints, the safety kernel, the protocol, the level-promotion criteria, and the functional contracts are **designed and verified**. What emerges is the *content* of the organization — which cells cluster, which circuits form, which regions crystallize, which specializations appear — and it emerges inside bounds that are enforced off-substrate and are provably invariant. Structure is free; **invariants are not**. This yields real emergence where it is valuable and real guarantees where they are necessary, and it is the only version of this project that is both interesting and safe.

---

## T. FAILURE

Assessment of each scenario against the architecture as written, then as revised.

| Scenario | Survives **as written**? | Why / why not | Survives **as revised**? |
|---|---|---|---|
| **1% of cells fail** | ✅ Probably | At 100–10,000 cells, redundancy + distributed representations (V3 §2, §21) plausibly absorb this. Immune pipeline (V3 §17) is structurally sound. **But** at 10⁸ cells, 1% = 10⁶ simultaneous failures, which exceeds any event-driven response | ✅ Yes — with statistical (not event-driven) immune response (§R.3.10), quarantine budget (§P.3), and replacement provisioning |
| **10% of cells fail** | ⚠️ Marginal | No cascade protection. **Quarantine/repair load itself consumes ~10%+ of capacity**, so effective loss is 20%+. If failures are correlated (shared lineage, shared substrate, shared bug) — which is the realistic case — redundancy provides **no** protection, because V3 never enforces independence (§H.4) | ⚠️ Conditionally — only if lineage diversity and structural independence were enforced. Requires: enforced lineage distance, error-correlation monitoring, and a defined degraded-mode ladder (§O.3.4) |
| **An entire circuit fails** | ❌ **No** | Circuits are not objects (§I.1). There is no circuit representation to detect failure of, no circuit-level redundancy, no circuit-level repair (§P.2), no functional contract to fall back on, and no way to migrate the circuit's function elsewhere. The organism loses the capability **silently and permanently**, and — because capability is not registered — **it will not know it lost it** | ✅ Yes — circuit as first-class object with contract, redundancy, repair, and capability-registry linkage (§I.2, §P.2, §L.3.3) |
| **A memory subsystem becomes corrupted** | ❌ **No** | No integrity mechanism (no checksums, no Merkle verification, no redundancy, no erasure coding). No corruption *detection*, therefore no repair. Worse: corrupted memory feeds retrieval, which feeds hypotheses, which feed verification — **and the corrupted memory is itself the "protected memory" that the resolution hierarchy (§B.10) appeals to as second-highest authority.** A corrupted protected store is an *authority-level* compromise: the system will confidently propagate the corruption and treat contradiction as error in the *other* direction. This is the most dangerous single failure in the document | ⚠️ Partially — with integrity verification, redundancy, provenance-based reconstruction, and **external anchoring of protected memory** (§C.8). Full recovery of semantically-corrupted (not bit-corrupted) memory is **not guaranteed** — see Part II §12 |
| **Communication becomes unreliable** | ❌ **No** | No delivery semantics, no timeout/retry, no circuit breaker, no degraded-mode messaging, **and `COMMUNICATION ERROR` is not even in V3.1's error taxonomy** (§E.1). Unreliable communication produces *silently wrong* credit assignment: error signals arrive late, out of order, duplicated, or not at all, and learning proceeds on corrupted data. **The system will learn incorrectly and have no way to detect it** | ✅ Yes — full transport spec (§B.2–B.9), communication error class, causality tracking, and confidence degradation under link uncertainty |
| **A malicious cell emerges** | ❌ **No — this is the worst case** | No authentication (§B.6): any cell can emit `REWARD`, `ERROR`, `WARNING`, or `SAFETY` signals. A single malicious cell can (a) forge reward to hijack learning, (b) flood a target with forged errors to destroy it via plasticity (§E.3), (c) poison trust by vouching, (d) nominate misleading content to the global workspace and thereby **control the organism's shared reality** (§C.10), (e) write to protected memory if it reaches a memory-keeper role, (f) influence its own replication evaluation. Trust scoring exists as a *stored field* with no update rule and no Sybil resistance | ⚠️ Substantially — with signed birth certificates, per-message signatures, privileged signal classes, lineage-distance verification, workspace nomination caps + rotating referees, and off-substrate audit (§B.6, §C.2, §C.10). **Not fully:** a malicious cell that is *also* genuinely high-performing will pass every gate in §K.2. Insider threat with legitimate competence is not solvable by architecture alone |
| **Evolution produces a dangerous candidate** | ⚠️ Nominally | The firewall (§16) and sandbox exist *as names*. But the firewall is inside the organism (§F4), the safety layer's scope is undefined (§G.1), regional/architectural evolution is explicitly permitted to change roles and structure (contradicting immutability), and there is **no off-substrate verification, no rate limit on self-modification, no human authorization gate, and no kill switch**. A candidate that is dangerous *in a way the tests don't cover* passes — and the tests are unspecified, so coverage is unknown | ✅ Yes — **only** with the off-substrate kernel (§Layer 0), signed immutable constraints outside the mutable genome, bounded mutation space, off-substrate fitness/test definitions, deployment rate limits, and operator authorization for architecture-level change. This is the highest-priority fix in the entire audit |
| **The global workspace fails** | ❌ **No** | Single instance, no redundancy, no replication, no failover, no degraded mode (§C.11). It is a **single point of failure in a design that explicitly claims to have eliminated single points of failure** (V3 §21). Since attention, self-state, context continuity, and global availability all route through it, its failure means the organism loses awareness-like function *entirely* while continuing to act — i.e. it becomes an unmonitored, uncoordinated collection of regions that still takes actions | ✅ Yes — replicated/sharded workspace, regional-workspace fallback (§C.9), off-substrate watchdog, and a **defined degraded mode in which the organism reduces its action authority** when global integration is unavailable. That last clause is essential: losing global awareness must reduce autonomy, not merely reduce visibility |
| **The self-model becomes incorrect** | ❌ **No — and it will** | The self-model is open-loop (§D): nothing validates it. Drift is not merely possible, it is the **default behaviour** of an unvalidated model. Consequences: capability prediction is wrong ⇒ the system attempts tasks it cannot do and declines tasks it can; attention allocation is wrong ⇒ it attends to the wrong things; escalation is wrong ⇒ it escalates trivia and suppresses crises; limitation awareness is inverted ⇒ **it is confidently unaware of its own incapacity**, which is precisely the failure the awareness architecture exists to prevent. And because every consumer trusts the self-model, the error is amplified rather than detected | ⚠️ Substantially — with the closed-loop self-model (§D: capability assay, self-prediction error, claim–behaviour consistency monitor, self-model confidence, self-model versioning + rollback). **Not fully:** a self-model can only validate itself against *measurable* behaviour. Systematic blind spots that never produce measurable failures remain invisible. See Part II §12 |

### T.1 The pattern across all nine scenarios

**Eight of nine failure scenarios are not survivable as specified**, and in seven of those the reason is the same: *the architecture names a protective mechanism without specifying the state, authority, or measurement that mechanism requires.* Redundancy without enforced independence. Rollback without persistence. Quarantine without a quarantine state. Firewall without an outside. Trust without authentication. Verification without a cost model. Self-model without validation. Decentralization with a central workspace.

This is a **systemic** defect, not a list of nine separate ones. It is the same defect as F1–F5, appearing in the failure domain.

### T.2 One failure scenario missing from your list, which is the most likely of all

**Slow, distributed, individually-invisible degradation.** Not a failure event — a failure *trend*. Capability erodes over months through small plasticity changes, small pruning decisions, small drift in trust and calibration, each individually within tolerance. No detector fires because no threshold is crossed. The organism is measurably worse than it was and cannot say when it got worse.

This is the characteristic failure mode of every long-running adaptive system, and **V3/V3.1 has no defense against it whatsoever.** Required: golden-baseline regression suite (§L.3.6), continuous capability assay (§D), epoch-over-epoch trend monitoring with change-point detection, mandatory periodic full re-evaluation, externally anchored historical metrics (so the record of past capability cannot drift along with the capability), and a **standing operator report** of capability trajectory. This should be P0 for any system intended to run for years — which is exactly what this one is intended to do.

---

# PART II — REQUIRED OUTPUTS 1–12

---

## 1. ARCHITECTURAL VERDICT

### Classification: **CONCEPTUALLY STRONG BUT INCOMPLETE**

Not "incomplete" (that undersells it — the conceptual work is real and unusually good). Not "architecturally mature" (that would require defined mechanisms). Decisively not "implementation-ready."

### Why

**What earns "conceptually strong":**
1. **The failure-mode analysis is genuinely excellent.** V3 §2 (11 brain weaknesses), §3 (10 AI weaknesses), and §21 (17 failure modes with countermeasures) identify the right problems. Most of these are the *actual* failure modes of real systems — monoculture, synthetic-data drift, correlated failure, reward hacking, reconstructive memory, calibration failure — and many published architectures miss them entirely.
2. **The separation of lifetime learning from generational evolution** (V3 §15) is the correct and non-obvious choice, and the "hard separation" framing shows real understanding of why.
3. **The multi-scale insight in V3.1** — plasticity and evolution at synapse → cell → connection → circuit → region → architecture — is correct and ahead of most designs, which operate at one scale only.
4. **The V3.1 awareness loop** (workspace + self-state + attention + error awareness + metacognition, interconnected) is the right set of subsystems in the right relationship (§N.2).
5. **The scientific honesty is exemplary.** V3 §19 and V3.1 §11–12 both refuse the consciousness claim explicitly and repeatedly. This is rare, correct, and must be preserved.
6. **The design thesis** (V3 §24: "a governed computational ecosystem" rather than "one giant model") is a coherent and defensible research position.

**What prevents "mature" or "implementation-ready":**

1. **Specification density is near zero.** Across ~30 named subsystems: **0** have a defined algorithm with thresholds; **~3** have a partial data model (synapse property list, belief record, self-state inventory); **~27** have names and taxonomies only. There is not one equation, not one threshold value, not one protocol, not one schema, not one unit, and not one data structure definition in ten pages.

2. **The five load-bearing failures (F1–F5)** are each individually disqualifying, and they compound: no substrate (F1) ⇒ no cost model ⇒ no scalability analysis; no task (F2) ⇒ no fitness ⇒ evolution is vacuous; no confidence mechanism (F3) ⇒ the entire verification/abstention/trust/calibration edifice reads an undefined variable; no external safety anchor (F4) ⇒ "immutable" is a preference, not a property; no verification economy (F5) ⇒ the system is either infeasible or silently unverified.

3. **Fifteen internal contradictions** (§3 below), several of which are structural rather than editorial — most seriously: hard separation vs. the learning→evolution bridge (C2), decentralization vs. a central workspace (C3), immutable safety vs. architecture-level evolution (C4), underuse-pruning vs. rare-variant preservation (C5), and hard-coded regions vs. self-organization (C13).

4. **Twenty-two weak interfaces** (§4 below). Every major subsystem boundary is a named arrow with no contract.

5. **No scale-awareness at all.** The architecture would function at ~100 cells and fails at every scale above (§R). Required dynamic range is six orders of magnitude; supplied scale mechanisms: zero.

6. **No falsifiability.** V3 §19 names six "awareness-like test targets." Neither document defines a test, a metric, a baseline, or a null hypothesis for any of them. The architecture therefore **cannot be shown to work or to fail** — which means the project cannot report results, cannot prioritize, and cannot know when to stop.

### The decisive test

> Hand V3/V3.1 to ten competent engineering teams. You will receive ten mutually incompatible systems, each of which fully satisfies every statement in the document. **A specification that permits this is a research agenda, not an architecture.**

### What V3/V3.1 actually is — and this is not an insult

It is an excellent **problem decomposition** and a strong **research programme**. It correctly identifies what must be built. As a *map*, it is better than most. What it is not is a *specification*, and the gap between the two is roughly the whole of the engineering work.

**Recommended framing for V4:** treat V3/V3.1 as the **requirements document** (it is a good one) and produce the **architecture specification** separately. Do not attempt to extend V3.1 into V4 by adding more named subsystems — that path produces a longer document with the same defect. **The work required is not more nouns. It is mechanisms: types, invariants, algorithms, thresholds, protocols, and measurements.**

---

## 2. MISSING SYSTEMS

Complete list, ordered by dependency (a system cannot be built before the ones above it that it depends on).

| # | Missing subsystem | Problem it solves | Why it matters | Proposed solution | Affected components | Priority |
|---|---|---|---|---|---|---|
| **M01** | **Task / Environment / Fitness Definition** | No target task, no observation-action space, no outcome function, no ground-truth source (F2) | Without it, error signals, learning, fitness, selection, sandbox testing, differentiation demand, and homeostatic setpoints are **all** undefined. Evolution is mathematically vacuous | Define 3–5 concrete environments (continuous control, symbolic/knowledge, long-horizon open-ended) with measurable success criteria, a ground-truth supply plan with funded budget, and a curriculum | Everything | **P0** |
| **M02** | **Off-Substrate Immutable Kernel** | Safety layer and firewall are inside the organism they constrain (F4) | A system that can modify its own constraints has no constraints. Terminal failure mode | Signed policy store, constraint verifier, resource enforcement at OS/hypervisor level, replication authority, fitness/test definitions, provenance anchor, audit log — all outside the evolvable substrate, human-authorized to change | Safety, evolution, replication, immune, audit | **P0** |
| **M03** | **Minimal Cell Specification** | A cell's computational substrate is undefined (F1) | Every downstream mechanism is a function of the substrate | Typed ports, defined state vector, concrete confidence estimator (small ensemble + evidential head), bounded tiered memory with schemas, self-modification *scope* excluding safety by construction, replication authority removed from the cell | Cells, all | **P0** |
| **M04** | **Message Protocol & Transport** | No schema, addressing, routing, delivery semantics, ordering, congestion control, backpressure (§B) | Cells cannot communicate; credit assignment corrupts under reordering/duplication; no scalability | Canonical envelope (B.2), 4 addressing modes, hierarchical locality-aware routing, per-class delivery semantics, token-bucket congestion control, circuit breakers | All communication | **P0** |
| **M05** | **Identity, Authentication & Trust Computation** | `trust score` is stored, never computed; **no authentication at all** (§B.6) | Any cell can forge `REWARD`/`ERROR`/`SAFETY`. A single compromised cell hijacks learning and shared reality | Signed birth certificates from Replication Authority (Sybil-proof), per-message epoch-key signatures, revocation lists, `Beta(α,β)` contextual trust with age discount and hard cap < 1.0, lineage-distance requirement for verification | Communication, verification, evolution, immune | **P0** |
| **M06** | **Uncertainty Estimation & Calibration Engine** | Confidence is consumed by ~14 subsystems, produced by none (F3) | The entire safety edifice — abstention, verification, trust, error awareness, calibration-failure detection — reads an undefined variable | Ensemble disagreement + evidential deep learning head; aleatoric/epistemic separation; temperature scaling / conformal prediction; **continuous recalibration against measured outcomes**; reliability diagrams, Brier, ECE as monitored metrics; `confidence + calibration_class` never a bare scalar | Perception, verification, attention, self-state, error awareness, evolution | **P0** |
| **M07** | **Genome Representation & Mutation Operators** | No encoding ⇒ no mutation, no crossover, no genotype→phenotype map (§L.1) | Evolution is the second-most-elaborate subsystem and has no substrate | Typed bounded versioned genome (L.1), explicit typed operators with rates/validity/effect-size bounds, developmental genotype→phenotype map, parsimony pressure, constraint block as a separate signed artifact | Evolution, replication, differentiation | **P0** |
| **M08** | **Persistence, Checkpoint & Rollback Infrastructure** | "Rollback" appears 5× with no snapshot mechanism (§A, §P.1) | Cannot roll back what was never persisted. No crash recovery, no failure recovery, no drift rollback | WAL for structural changes; hierarchical checkpointing (cell → circuit → region → epoch boundary); last-known-good states; tested restore; **recovery capability reported in self-state** | All; especially immune, evolution, homeostasis | **P0** |
| **M09** | **Error Attribution & Credit Assignment** | Errors are classified but never attributed; **no eligibility traces** (§E.3, §F.1) | Without attribution, learning punishes innocent components and reinforces guilty ones. This is the difference between learning and noise | Causal trace via vector clocks + influence graph; counterfactual ablation in simulation; eligibility traces per timescale; distributed responsibility `r_i`; **error-signal gating before learning** | Learning, plasticity, immune, evolution | **P0** |
| **M10** | **Verification Cost Model & Depth Policy** | 15–72× amplification with no budget and no skip policy (F5) | The system must either pay 40× (infeasible) or silently drop verification (reverting to an unverified model while claiming guarantees) | `verification_depth = f(expected_error_cost × P(error), stakes, budget)`; anytime pipeline (each stage returns a usable result); **reduced-verification state recorded in self-state and propagated into confidence** | Anti-hallucination pipeline, attention, homeostasis, hardware adaptation | **P0** |
| **M11** | **Hardware Adaptation & Morphology Controller (HAMC)** | No concept of hardware exists (§O) | Required dynamic range is ~10²–10⁸ cells. Without morphology adaptation, "same organism on phone and cluster" is false | Capability discovery (measured, not spec-read) → signed hardware profile → morphology policy → **scalable cell variant family C0–C4 sharing one interface contract** → 8-rung degradation ladder → migration → continuous re-adaptation with hysteresis | All | **P0** |
| **M12** | **Homeostatic Control System** | V3 §18 is variables + slogans, not a control system (§Q) | Unregulated adaptive system ⇒ oscillation, saturation, runaway growth, monoculture | Explicit control law per variable (PI + anti-windup, deadband, rate limit; MPC for coupled variables); setpoints as functions of hardware profile; **13 additional regulated variables** (Q.2); controller priority ordering; loop-gain verification; replicated coordinator + off-substrate hard-bound watchdog | Resource control, plasticity, evolution, immune, replication | **P0** |
| **M13** | **Circuit as First-Class Object** | Circuits are named in plasticity and evolution but never defined (§I.1) | Circuit plasticity and circuit evolution are operations on a nonexistent entity; the emergence ladder has a missing rung | Circuit record (I.2) with identity, membership, topology, typed interface, **functional contract**, performance, provenance, lifecycle; Circuit Registrar; circuit-level fitness | Plasticity, evolution, emergence, repair | **P0** |
| **M14** | **Differentiation Engine** | Roles are a static menu with no formation mechanism (§H) | Without it, roles are hand-assigned ⇒ the organism is a hand-configured multi-agent system | Morphogen gradients + organizer populations; lateral inhibition; demand signals from homeostasis (closing the §Q↔§H gap); niche capacity; staged commitment `PLURIPOTENT → PROVISIONAL → COMMITTED → TRANSDIFFERENTIATED`; formal fate specs; bootstrap policy | Cells, regions, homeostasis | **P0** |
| **M15** | **Capability Registry & Floor Enforcement** | No record of what the system can do; rare capabilities are pruned as underused (C5, §L.3.3) | Capabilities are lost silently and permanently, and the system cannot detect the loss | Registry: `{capability, keeper_population, min_performance, budget_floor, last_assayed, trend}`; **keeper populations exempt from underuse pruning**; capability regression gate on every consolidation/pruning/selection event; periodic assay | Evolution, homeostasis, pruning, self-model | **P0** |
| **M16** | **Global Workspace Engine (real)** | V3.1 §2 is five boxes and an arrow (§C) | The workspace determines shared reality; as specified it is uncapturable only by accident and overloadable by design | Admission policy with explicit eligible classes (C.1); signed rate-limited cost-charged nomination; specified salience function with off-substrate weights; **ignition semantics**; lineage-diverse rotating referee committee; uncapturable safety bypass; tiered scoped access with logged reads; TTL + active invalidation + tombstones; **hierarchical workspace (summaries global, detail regional)**; replication + failover + defined degraded mode; monopolization detection (Herfindahl over sources) | Awareness, attention, coordination, scalability | **P0** |
| **M17** | **Feedback-Loop Control** | The design is saturated with feedback and has zero loop control (§B.12) | Guaranteed oscillation or saturation under load; distributed and therefore very hard to diagnose | Influence graph from causality data; cycle detection; **`loop_gain < 1` as a provable, off-substrate-checked invariant**; delay insertion on back-edges; decorrelation requirements; runtime oscillation detector with auto-damping | All | **P0** |
| **M18** | **Concurrency, Consistency & Ordering Model** | Nothing about actors/threads/processes, synchronization, ordering, idempotency, or conflict resolution | The single biggest engineering gap; without it the system is nondeterministic and unreproducible | Actor model per cell; async message passing; **no global locks**; CRDTs for counters, leases for exclusives, vector clocks for causality; bounded staleness declared per data class; deterministic replay for debugging | All | **P0** |
| **M19** | **Plasticity Stability Layer** | Five plasticity scales, no timescale separation, no homeostatic constraint (§G.3) | **Adding plasticity without stability constraints makes the system worse.** Pure Hebbian plasticity saturates | Enforced rate ordering `synaptic ≫ cellular > connection > circuit > region > architecture`; homeostatic plasticity (synaptic scaling, activity bounds); metaplasticity (BCM sliding threshold); structural-change budget; critical periods; reconsolidation; interference management | Learning, plasticity, memory | **P0** |
| **M20** | **Multi-Level Selection & Evolutionary Algorithm** | No selection algorithm; V3.1 §9 linearly scalarizes incommensurable objectives (§K.1) | A linear sum of unnormalized heterogeneous objectives is an arbitrary number, not multi-objective optimization | **MAP-Elites / quality-diversity** as primary paradigm; Pareto-front selection, never scalar sum; lexicographic hard constraints; island model with migration and per-island fitness weights; fitness measured **at each organizational level**; surrogate fitness models at scale | Evolution, all levels | **P0** |
| **M21** | **Replication Authority & Eligibility Gates** | Replication is a cell capability with undefined gates (§K) | A cell that can decide to replicate itself is a runaway-growth and self-preservation risk | 11 conjunctive gates (K.2); **replacement-default (zero-sum) replication**; weighted lottery among qualified, not argmax; off-substrate rate cap; authority external to the cell and lineage-independent | Replication, evolution, homeostasis, safety | **P0** |
| **M22** | **Memory Architecture (real)** | Nine named stores with no schemas, capacities, retention, retrieval, interference model, or consolidation triggers (§F.1) | Memory is where capability accumulates; undefined memory ⇒ no accumulation | Schemas + capacity + retention curve + retrieval mechanism (content-addressed + associative) per store; **integrity verification (Merkle) + erasure coding for critical stores**; reconsolidation; interference model; consolidation pipeline with each of the six named operations specified; tiering hot/warm/cold/archive | Memory, learning, provenance, repair | **P0** |
| **M23** | **Provenance Engine** | Named throughout, defined nowhere; unbounded storage cost (§C.8) | Without it, synthetic-data degeneration, trust poisoning, and history rewriting are all undetectable | Append-only Merkle DAG; hashes not payloads; cell lineage tree; **inbreeding coefficient `F`** with hard cap for critical beliefs; **external anchoring** of signed root hashes (tamper-evident history); sampling + compression policy at scale | Memory, trust, evolution, learning, audit | **P0** |
| **M24** | **Anti-Model-Collapse Controls** | Cells learn from cells; V3 names the risk with no mechanism (§F.2, §L.3.7) | Self-confirming collapse produces excellent internal metrics and a delusional organism — the hardest failure to detect from inside | Self-generated-content tagging; hard cap on self-generated fraction per batch; `F` cap; **mandatory external ground-truth quota**; write-protected external corpus; diversity-entropy monitoring with **automatic evolution halt**; only externally validated outputs become training data; self-generated content barred from protected memory | Learning, evolution, memory, provenance | **P0** |
| **M25** | **Quarantine State Machine & Autoimmune Protection** | Quarantine is named with no state; no cascade protection (§A, §P.3) | Quarantine removes capacity ⇒ capacity loss causes errors ⇒ errors cause quarantine. **The cascade is structural** | Defined quarantine state (message handling, synapse ownership, duration bound, exit criterion); **quarantine budget cap enforced off-substrate**; graduated response `observe → throttle → restrict → soft quarantine → hard quarantine → retire`; false-positive budget per detector; second-opinion requirement; **cascade detection on quarantine-rate derivative** | Immune, homeostasis, repair | **P0** |
| **M26** | **Measurement, Falsification & Ablation Framework** | No test, metric, baseline, or null hypothesis for any claim (§N.3) | The project cannot report results, cannot prioritize, and cannot know when to stop. Risk of building 30 subsystems of which 12 are inert | Operational definition + metric + protocol + baseline + null hypothesis for each of the 10 awareness properties and each major subsystem; **mandatory ablation methodology** (measure with/without each subsystem); golden-baseline regression suite | All; governance | **P0** |
| **M27** | **Drift Detection & Long-Horizon Integrity** | No defense against slow, distributed, individually-invisible degradation (§T.2) | **The most likely failure of any long-running adaptive system**, and the design has nothing for it | Golden-baseline regression suite per epoch; continuous capability assay; change-point detection on capability trends; mandatory periodic full re-evaluation; **externally anchored historical metrics**; standing operator capability-trajectory report | All; governance | **P0** |
| **M28** | **Operator Interface & Containment** | No kill switch, no human-in-the-loop gates, no rate limit on self-modification, no off-substrate monitoring (§F4, §L.3) | Required for any system designed to undergo controlled evolution | Off-substrate dashboard (read-only, anchored metrics); kill switch at substrate level; authorization gates for architecture-level change and constraint change; self-modification rate limits; emergency freeze; incident report generation; **envelope authority model** (autonomy inside, human over the envelope) | Safety, evolution, governance | **P0** |
| **M29** | **Region Formation & Functional Contracts** | Regions hard-coded; no self-organization; no contract to allow structural change without functional loss (§J) | Contradicts the stated goal; hard-codes an embodiment the architecture claims not to have | Substrate-first design; activity-dependent competition for input streams; mutual inhibition between proto-regions; region lifecycle `PROTO → CONSOLIDATING → MATURE → {MERGE｜SPLIT｜RETIRE}`; **functional contracts (constrain the interface, liberate the implementation)**; continuous contract testing; functional conservation constraint; bounded region count (4–12); anatomical names as post-hoc labels | Regions, emergence, plasticity, hardware adaptation | **P0** |
| **M30** | **Hierarchical Coordination & Aggregation** | No hierarchy, no summarization, no locality (§R.3) | Flat architecture fails above ~10⁴ cells; global self-state and global workspace are impossible without aggregation | Locality-aware placement (**also the region-formation engine and the #1 scalability fix**); hierarchical routing; **compressor/summary cells as a distinct role** (absent from V3 §10); hierarchical workspace, self-state, and homeostasis; island-model evolution | All; scalability | **P0** |
| **M31** | **Learning Algorithm Suite** | No algorithm family, no step size, no replay policy, no consolidation trigger (§F.1) | "Learning" is named at every stage and implemented at none | Specified algorithm per mode (prediction-error, RL with defined credit horizon, evidential updating, social/imitation with provenance gating); step-size policy per timescale; prioritized replay (importance × surprise × recency × capability-criticality); interleaving ratio; offline/consolidation mode; **"when not to learn" policy** | Learning, plasticity, memory | **P0** |
| **M32** | **Resource Accounting & Scheduling** | Budgets named, no units, no allocation algorithm, no preemption, no scheduler (§A, §Q) | Cannot build without deciding how cells get CPU/memory and what happens on breach | Units (FLOPs, bytes, wall-time, $); allocation algorithm; admission control; preemption policy; deadline-aware scheduling; over-budget response ladder `throttle → degrade → shed → flag as resource error` | Homeostasis, all | **P1** |
| **M33** | **Evaluation Harness & Test-Suite Maintenance** | "Performance/robustness/safety/diversity test" named with no test definition (§K.1, §L.3.2) | Tests become the target (Goodhart); stale tests silently lose power | Held-out rotation; protected generator (off-substrate); adversarial test generation; **cross-environment validation requirement (≥ k environments)**; sandbox-fidelity measurement; canary populations on invisible tests; production-holdout environments never used in selection | Evolution, verification, safety | **P1** |
| **M34** | **Deployment Pipeline (canary / shadow / rollback)** | "DEPLOYMENT → MONITORING" named with no mechanism (§L.3.8) | Sandbox→production gap is guaranteed; without progressive deployment it is discovered by users | Shadow → 1% → 10% → full; online monitoring with automatic rollback on regression or constraint violation; deployment rate limits; per-deployment audit record | Evolution, safety, operations | **P1** |
| **M35** | **Capability Directory Service** | Capability-based addressing requires a registry that doesn't exist (§B.3) | Without it, cells cannot find partners by function ⇒ circuit formation and differentiation both stall | Sharded, replicated, eventually-consistent registry mapping capability tags → cells/circuits/regions, with freshness bounds and staleness declaration | Communication, circuits, differentiation | **P1** |
| **M36** | **Self-Model Validation Loop** | Self-model observes but is never validated (§D, §N.2.2) | An unvalidated self-model drifts into confabulation; a confidently wrong self-model is worse than none | Capability assay with probe tasks; self-prediction error as a first-class error type; claim–behaviour consistency monitor (**downgrade the declaration, not the behaviour**); per-field provenance + confidence; self-model versioning + rollback | Self-model, attention, planning, escalation | **P1** |
| **M37** | **Temporal Binding & Episode Segmentation** | No timebase, no episode boundaries, no continuity metric (§N.2.5) | Context continuity is unmeasurable and therefore unachievable | Global monotonic epoch + timebase service; explicit episode boundary detection; working-memory duration bounds; `context_continuity_score` (MI between successive context states) | Awareness, memory, workspace | **P1** |
| **M38** | **Internal-State Prediction** | Absent from both documents (§N.1) | Required for anticipatory homeostasis and for MPC control (§Q.3); without it control is purely reactive | A learned model of the organism's own dynamics, used to predict future self-state; validated by self-prediction error (M36); consumed by MPC homeostasis and by planning | Self-model, homeostasis, planning | **P1** |
| **M39** | **Coordination-Error Detection** | The dominant multi-agent failure class has no error category (§E.2.1) | Deadlock, livelock, oscillation, duplicated work, race conditions, thundering herd — all invisible | Deadlock/livelock detection; duplicated-work detection via content hashing; race detection via causality analysis; contention metrics; coordination-error class in the taxonomy with its own attribution path | Error awareness, communication, coordination | **P1** |
| **M40** | **Value-of-Computation / Anytime Control** | No mechanism decides when to stop thinking (§N.2.4) | Unbounded deliberation is a resource failure; bounded deliberation without a stop rule is arbitrary | VOC = expected benefit of further computation vs. its cost, with explicit stop rule; anytime algorithms throughout so every process can be interrupted and still return a usable result | Reasoning, metacognition, attention, resources | **P1** |
| **M41** | **Ground-Truth Supply & Freshness Governance** | Anti-collapse controls require external ground truth indefinitely, supplied by nobody (§L.3.7) | Without a funded supply, model-collapse mitigation fails in year two | Named ground-truth sources with SLAs; freshness metric as a homeostatic variable; write-protected corpus; periodic human-in-the-loop validation; **ground-truth source integrity monitoring** (external ≠ infallible — §E.2.4) | Learning, evolution, provenance, governance | **P1** |
| **M42** | **Scope Declaration & OOD Abstention** | No representation of unknown-unknowns or out-of-scope domains (§N.2.7) | The system guesses outside its competence and reports confidence while doing so | Coverage estimation over input space; OOD detection with **mandatory abstention + escalation** (not best-effort answer); explicit scope declaration per region and per organism version; OOD inputs produce ignorance reports | Awareness, verification, safety | **P1** |
| **M43** | **Protocol/Schema Versioning & Compatibility** | Message schema is fixed forever, yet the system must run for years and evolve (§G.2.1) | No schema evolution ⇒ no long-term maintainability; naive schema evolution ⇒ interoperability failure between cell generations | Versioned schemas with compatibility windows; mutual-intelligibility tests; protocol plasticity gated and probably deferred (P2) | Communication, evolution | **P2** |
| **M44** | **Meta-Plasticity** | Plasticity rates are fixed; the system cannot learn to learn faster/slower with environmental volatility (§G.2.2) | Either too rigid or too labile across changing environments | Plasticity-rate adaptation driven by measured environmental volatility and stability index, within off-substrate bounds | Plasticity, learning | **P2** |
| **M45** | **Formal Verification of Core Invariants** | Safety claims are asserted, never proven (§F4, §S.3) | "Immutable" and "loop_gain < 1" and "population cap" must be *properties*, not intentions | Model-check or prove: population cap, resource ceiling, constraint-block immutability, `loop_gain < 1`, firewall non-reachability, quarantine budget. Publish as a **safety case** | Safety, governance | **P2** |
| **M46** | **Deterministic Replay & Debugging** | No reproducibility mechanism for a stochastic, distributed, self-modifying system (§M18) | Undebuggable systems cannot be developed. This will consume more engineering time than any other single gap | Record-and-replay of message logs + structural change log + RNG seeds; deterministic replay of any epoch; **note the tension: replay requires recording everything, which conflicts with provenance cost bounds** — resolve by sampled + triggered recording | All; engineering | **P1** |
| **M47** | **Federated / Partition-Tolerant Organism Model** | At ≥10⁷ cells, partitions are routine and "one global state" is physically meaningless (§R.2) | The concept of a single organism does not survive the target scale without redefinition | Define the organism at scale as a **federation of semi-autonomous regional organisms** sharing genome lineage, provenance anchor, and slow summary-level global integration; defined per-partition autonomy and reconciliation-on-heal | Architecture, scalability | **P2** |
| **M48** | **Energy/Cost Economic Model** | `cost/energy` is a homeostatic variable with no unit, no price, no trade function (§O, §Q) | Cannot make "spend more compute to verify" decisions without a cost calculus | Unified cost unit (J or $); price per operation class; cost-aware verification depth (M10); cost-aware attention; cost as an explicit fitness term with normalization | Resources, verification, evolution | **P1** |

**Summary: 31 P0 subsystems, 12 P1, 4 P2, 1 P3-equivalent.** The architecture as it stands names approximately 30 subsystems and is missing approximately 48.

---

## 3. CONTRADICTIONS

Fifteen identified. Severity: 🔴 structural (cannot both be true) · 🟠 operational (will conflict at runtime) · 🟡 editorial (resolvable by clarification).

| # | Contradiction | Sources | Sev | Analysis & resolution |
|---|---|---|---|---|
| **C1** | **Verification cost vs. energy constraint.** Full pipeline (~15–72× amplification) on every input vs. "energy constraint → sparse activation + adaptive compute" | V3 §2, §12, §20 | 🔴 | The verification pipeline is dense by construction; the energy policy demands sparsity. No policy exists for *when to verify*. **Resolution:** M10 — cost-aware verification depth with anytime stages, and honest confidence reduction when depth is cut |
| **C2** | **Hard separation of learning/evolution vs. the learning→evolution bridge.** "Learning does not automatically rewrite inherited genome" vs. "repeated success → candidate genome change → evolution" | V3 §15; V3.1 §8 | 🔴 | The bridge makes experience the *selection pressure* on the genome — Lamarckian inheritance in effect while claiming Baldwinian separation. **Resolution:** M.2 — the **abstraction step**: inherit the *invariant/bias*, never the acquired state; plus ≥20% of evolutionary budget reserved for experience-independent variation |
| **C3** | **Decentralization vs. the global workspace.** "Single-point failure → redundancy + decentralization" vs. a central workspace, attention controller, and self-state monitor that everything reads and writes | V3 §21; V3.1 §1–3 | 🔴 | The single-point failure the design claims to have eliminated is reintroduced at the centre of the cognitive architecture. **Resolution:** hierarchical + replicated workspace with regional fallback and a **defined degraded mode that reduces action authority** when global integration is lost (§T) |
| **C4** | **Immutable safety layer vs. architecture-level evolution.** Cells have an "immutable safety layer" and an "evolutionary firewall"; V3.1 §7 permits evolution of `FUNCTIONAL REGION` and `BRAIN ARCHITECTURE`, and V3.1 §6 permits regional plasticity to "change functional roles" | V3 §4, §16; V3.1 §6, §7 | 🔴 | If regions and architecture can evolve, and regions *implement* safety functions (medulla-like "emergency safety", microglia quarantine, thalamic gating), then safety is evolvable. **Resolution:** M02 — the **envelope model**: safety kernel, constraints, protocol, and invariants are off-substrate and human-authorized; structure and function *inside* the envelope evolve freely (§S.3) |
| **C5** | **Underuse pruning vs. rare-variant preservation.** "Persistent underuse → compress/prune" vs. "preserve rare useful variants" and "a cell that is not the highest performer may still be preserved" | V3 §18; V3.1 §9 | 🔴 | Rare ⇒ low usage ⇒ pruned by the homeostasis rule before the diversity rule can protect it. **The two subsystems actively undo each other.** **Resolution:** M15 — Capability Registry with keeper populations **exempt from underuse pruning** and funded by a reserved budget floor; capability regression gate on every pruning event |
| **C6** | **Abstention vs. learning from outcomes.** "conflict → abstain/escalate" vs. the learning loop requiring `action → outcome → error` | V3 §12, §15, §20 | 🟠 | Abstention produces no outcome ⇒ no error signal ⇒ no learning. **A safety mechanism starves the learning mechanism**, and the system will systematically fail to learn in exactly the ambiguous situations where learning matters most. **Resolution:** three explicit abstention outcomes — (i) *active information gathering* (abstain-and-probe, which **does** produce an outcome), (ii) *escalation to external ground truth* (which produces a labelled outcome), (iii) *true no-action* (recorded as an ignorance event and used to update scope declarations, M42). Never a silent fourth case |
| **C7** | **Two routing/attention authorities.** Thalamus-like "routing, attention, synchronization" (a region) vs. the Attention Controller (a global subsystem) that determines amplify/maintain/suppress/defer/broadcast | V3 §9; V3.1 §5 | 🟠 | Two mechanisms control information flow with no precedence relation, no coordination protocol, and overlapping scope. At runtime they will conflict and the outcome will be nondeterministic. **Resolution:** one authority, two pathways — the Attention Controller owns *what deserves attention* (policy); thalamic routing owns *how to deliver it* (mechanism). Formalize as policy/mechanism separation with a single interface |
| **C8** | **Sparse activation vs. global broadcast.** Energy policy demands sparse activation; global availability demands that broadcast items reach many regions simultaneously | V3 §2; V3.1 §1–2 | 🟠 | Broadcast is inherently dense. Unconstrained broadcast defeats the energy policy. **Resolution:** hierarchical broadcast (global tier = summaries only, M30) + relevance-scoped subscription so a broadcast reaches *relevant* regions, not all regions + broadcast cost charged to the nominator (§C.2) |
| **C9** | **Independent verification vs. shared substrate.** "Correlated failure → independent strategies + redundant critics" vs. all cells sharing a substrate, a genome family, an environment, and a fitness function | V3 §3, §10, §12 | 🔴 | Structural independence is asserted and never enforced. Critics drawn from the same lineage with the same data and the same objective have **correlated errors**, so verification provides false confidence — which is worse than no verification because it suppresses the search for real errors. **Resolution:** enforced lineage distance ≥ *d* between verifier and proposer; distinct seeds and data orderings; distinct objective weightings; **measured error correlation with alerting** (§B.6, §H.4, §L.3.1) |
| **C10** | **Immutable event records vs. consolidation/compression/generalization.** "Reconstructive memory → immutable event records" vs. "consolidation → compression → generalization → versioned storage" | V3 §2, §11 | 🟠 | If episodic records are immutable and never discarded, memory grows without bound. If they are compressed, they are not immutable. Both cannot hold. **Resolution:** two distinct stores with different rules — **immutable append-only event log** (Merkle-hashed, sampled/tiered/archived by policy, never rewritten) and a **derived, mutable, reconsolidatable belief store** (corrections create new versions; old versions tombstoned, never overwritten). Provenance links belief → event. Immutability applies to the *log*; corrigibility applies to the *belief* |
| **C11** | **Safety layer is "immutable" yet performs "recovery."** Recovery and rollback change state | V3 §4 | 🟡 | **Resolution:** distinguish *policy* (immutable: what is permitted) from *mechanism* (privileged but stateful: what enacts recovery). The mechanism is signed, checksummed, off-substrate-verified, and can only transition the organism to a **previously validated** state — it can never author a new one |
| **C12** | **Separate value/state from evidence vs. confidence-driven trust modification.** "Emotional/state interference → separate value/state from evidence" vs. "if a cell was highly confident and repeatedly wrong → reduce trust, route verification elsewhere, alter its plasticity" | V3 §2; V3.1 p2 | 🟠 | Calibration state (a *state* property) is used to modify how a cell's *evidence* is weighted. This is exactly the state→evidence contamination the design forbids. **Resolution:** legitimate but must be **explicit and auditable**: calibration affects *trust weighting* (a meta-level, provenance-tracked adjustment) and never the *content* of evidence. Record every trust adjustment with cause, magnitude, and reversibility. Distinguish "this evidence is wrong" from "this source is poorly calibrated" — only the second is permitted |
| **C13** | **Hard-coded brain regions vs. self-organization / emergence.** ~20 pre-named regions with assigned functions vs. "emergent result", "ecosystem", and the requirement that the organism "organize into functional brain regions" | V3 §9, §23, §24; V3.1 §6 | 🔴 | **The central contradiction of the architecture.** A fixed region taxonomy makes this a modular pipeline with adaptive internals, not a self-organizing organism — and it hard-codes an embodiment (vision ⇒ occipital) that §O explicitly disclaims. **Resolution:** M29 — substrate-first; regions emerge; **anatomical names become post-hoc diagnostic labels, not architectural components**; region lifecycle permits merge/split/retire under functional conservation |
| **C14** | **Roadmap order inverts dependency.** Environment appears at Phase 10, but learning (Phase 4) and evolution (Phase 5) require outcomes from an environment | V3 §22 | 🟠 | Phases 4–5 cannot be developed or evaluated without ground truth. As ordered, the roadmap builds the learning and evolution machinery **blind**, then discovers at Phase 10 whether either works. **Resolution:** move environment + fitness definition to **Phase 0** (M01). Every subsequent phase requires a measurable task. Also: add ablation/measurement (M26) as a *continuous* activity, not a phase |
| **C15** | **Mutable connection topology vs. protected trust.** V3.1 §7 lists "connection-topology variation" and "communication-policy variation" as mutable, yet synapses carry `trust score` and cells carry an immutable safety layer; rerouting can bypass gating | V3 §4, §8; V3.1 §6, §7 | 🟠 | If topology can evolve, a candidate can evolve to route *around* verification, quarantine, or gating structures — achieving the effect of violating a constraint without violating it locally. **Resolution:** topology mutation is bounded by an **invariant routing policy**: certain paths are mandatory (all `EVALUATIVE` signals must traverse a lineage-independent verifier; all safety signals must reach the kernel) and **no mutation may remove a mandatory path**. Verify this off-substrate at every candidate evaluation |

---

## 4. WEAK INTERFACES

Twenty-two subsystem boundaries specified as a named arrow with no contract. For each: what must be defined.

| # | Interface | Current spec | Must define |
|---|---|---|---|
| **W01** | Cell ↔ Synapse | "receive signals, weight signals" | Message schema; port types; weight application semantics (to what type?); context-gating function |
| **W02** | Synapse ↔ Cell (write side) | "package output, priority, confidence, routing" | Emission API; admission rules; backpressure contract; cost accounting |
| **W03** | Cell ↔ Genome | "gene-expression controller" | **Genotype→phenotype map**; expression semantics; what is readable/writable by the cell; versioning |
| **W04** | Cell ↔ Memory | five/nine named stores | Per-store schema, capacity, retention curve, retrieval API, consistency guarantee, integrity verification |
| **W05** | Cell ↔ Immune | "surveillance, quarantine" | **Quarantine state machine**; entry/exit criteria; in-flight message handling; synapse ownership; cascade limits |
| **W06** | Cell ↔ Homeostasis | "budgets and priority allocation" | Units; allocation algorithm; reporting frequency; over-budget response ladder; preemption policy |
| **W07** | Attention Controller ↔ Global Workspace | "attention/relevance gate" | **Admission criteria**; salience function; ignition threshold; queue semantics; rejection feedback to nominator |
| **W08** | Workspace ↔ Subscribers | "globally available to the cells that need it" | Subscription model; scope tiers; consistency guarantee; staleness bound; read logging; invalidation notification |
| **W09** | Self-State Monitor ↔ Consumers | "fed into routing, attention, planning, learning, homeostasis" | **Vector format, types, units, ranges**; update frequency; staleness bound; per-field confidence; consumer contract for each of the five consumers |
| **W10** | Error Awareness ↔ Learning | "error signal → classify → learning" | **Attribution output format**; responsibility distribution; gating decision; severity→response mapping; rollback tag |
| **W11** | Error Awareness ↔ Repair | "diagnosis → repair/rollback/replace" | Diagnosis output schema; repair request API; repair-capability query; success criterion; failure escalation |
| **W12** | Learning ↔ Plasticity | "local update → synaptic plasticity" | Update rule per timescale; rate bounds; eligibility trace format; homeostatic constraint interface |
| **W13** | Plasticity ↔ Evolution bridge | "repeated success → candidate genome change" | **Stability criterion** (N epochs, k contexts); abstraction operator (state → genetic bias); diff format; validation package |
| **W14** | Genome ↔ Mutation operators | "mutation rules" | Operator set with types, rates, validity predicates, effect-size bounds; recombination semantics; neutrality handling |
| **W15** | Fitness ↔ Measurement | "performance, accuracy, adaptability…" (8 terms − 2 penalties) | **Measurement procedure per term**; units; normalization; aggregation (Pareto, not sum); sampling protocol; confidence interval |
| **W16** | Sandbox ↔ Production | "sandbox → validate → deploy" | Isolation boundary; resource policy; **fidelity measurement**; promotion criteria; max duration; escape detection; canary protocol |
| **W17** | Environment ↔ Organism | "sensors → actions → feedback" | **Observation space; action space; feedback function; ground-truth source; episode structure; latency; noise model** |
| **W18** | Provenance ↔ Belief | "provenance, genealogy" | DAG node schema; granularity policy; retention/compression; **inbreeding coefficient definition**; external anchoring protocol; query API |
| **W19** | Verification ↔ Decision | "independent verifiers → contradiction detector → confidence" | Verifier count policy; **agreement/disagreement semantics**; independence requirement (lineage distance); abstention threshold; cost budget |
| **W20** | Region ↔ Region | "pons-like coordination/bridging", "thalamus-like routing" | Inter-region message contract; boundary definition; functional contract per region; conflict resolution between regions; resource negotiation |
| **W21** | Circuit ↔ Members | (circuit undefined) | Circuit record; membership contract; recruitment/release handshake; circuit-level performance attribution; dissolution protocol |
| **W22** | Evolution Controller ↔ Substrate | "deployment → monitoring" | **Authority model** (who may change what); rate limits; rollback API; off-substrate verification hook; operator authorization gate |

**Pattern:** every one of these is a boundary where two subsystems must agree on a data format and a protocol, and in every case the document supplies a label instead. **W09, W15, and W17 are the three most damaging** — self-state has five declared consumers and no format; fitness has ten declared terms and no measurement procedure; the environment has three declared roles and no definition at all.

---

## 5. SCALABILITY RISKS

| # | Risk | Onset scale | Severity | Hierarchical / distributed solution |
|---|---|---|---|---|
| **S1** | **Global workspace broadcast saturation.** 10⁶ recipients × broadcast rate exceeds any network | 10⁴–10⁶ | 🔴 Fatal | Hierarchical workspace: **global tier carries summaries only**; regional tiers carry detail; item promotion requires measured cross-region relevance; compressor/summary cells (M30); relevance-scoped subscription; nomination cost charging |
| **S2** | **Message-rate wall.** 10⁷–10⁹ msgs/s; 2.6–256 GB/s | 10⁵ | 🔴 Fatal | **Locality-aware placement** (co-active cells co-located) — reduces cost 10–100×; hierarchical routing; message aggregation and summarization; **sparse activation** (only a fraction of cells active per epoch); event-driven rather than polled communication |
| **S3** | **Synapse-state explosion.** 10⁷–10¹⁰ synapses, each with 11 properties | 10⁵ | 🔴 Fatal | Sparse connectivity with bounded fanout (k ≤ ~30); synapse property **tiering** (hot properties in RAM, cold in storage); derived-on-demand rather than stored (e.g. `pruning probability` computed, not persisted); connection *classes* with shared parameters instead of per-edge parameters |
| **S4** | **Provenance graph exceeds belief data.** Full ancestry over 10⁶–10⁹ beliefs | 10⁴ | 🟠 Severe | Merkle hashes not payloads; **granularity policy** (full provenance for high-impact beliefs, sampled for routine); tiered storage hot/warm/cold/archive; compression via subgraph summarization; external anchoring of root hashes only |
| **S5** | **Verification compute amplification.** 15–72× per query | **All scales** | 🔴 Fatal | Cost-aware verification depth (M10); anytime pipeline; **surrogate verifiers** (cheap learned predictors of expensive verification); risk-based allocation (verify high-stakes, sample low-stakes); caching of verification results keyed by content hash |
| **S6** | **Evolutionary evaluation cost.** k environments × sandbox × population, per generation | 10³ | 🟠 Severe | **Island model** with parallel independent evaluation; **surrogate fitness models** to filter candidates before expensive sandbox; batched/offline evolution at large scale; held-out test reuse with rotation; evaluate *representative samples* rather than whole populations |
| **S7** | **Self-state aggregation latency.** Synchronous global self-state across 10⁶ cells is impossible | 10⁵ | 🟠 Severe | Hierarchical summarization tree (cell → cluster → region → global) with **declared staleness bounds per level**; consumers must tolerate bounded staleness; MPC homeostasis using predicted rather than observed state (M38) |
| **S8** | **Homeostatic control-loop delay exceeds disturbance timescale ⇒ oscillation** | 10⁵ | 🔴 Fatal | Hierarchical control: **fast local controllers** (bounded authority, no global coordination) + slow global coordinator (setpoints only); loop-gain verification (§B.12); deadbands and rate limiting; predictive control using the self-model |
| **S9** | **Trust relation explosion.** Pairwise trust is O(N²) = 10¹²–10¹⁶ entries | 10⁴ | 🟠 Severe | **Trust contexts** instead of global pairwise trust; hierarchical trust inheritance (trust a region ⇒ default trust its members, adjusted individually only on evidence); trust computed lazily on demand; gossip-based propagation with bounded fanout |
| **S10** | **Immune surveillance cost.** Exhaustive monitoring of 10⁶–10⁸ cells | 10⁵ | 🟠 Severe | **Statistical, risk-weighted sampling** rather than exhaustive monitoring; population-level anomaly statistics rather than per-cell events (at 10⁸ cells with 10⁻⁶/s failure rate, *something fails every 10 ms* — event-driven response is impossible); hierarchical escalation (cluster-level monitors handle routine, regional handle serious, global handle systemic) |
| **S11** | **Consensus / synchronization cost.** Any global agreement is O(N) messages minimum | 10⁴ | 🔴 Fatal | **No global consensus, anywhere.** CRDTs for counters; leases for exclusives; vector clocks for causality; bounded staleness per data class; **partition tolerance as the normal case** (M47); epoch boundaries as the only global synchronization point, and they must be cheap (a timestamp, not a barrier) |
| **S12** | **Checkpoint/rollback cost.** Snapshotting 10⁶–10⁸ cells | 10⁵ | 🟠 Severe | **Incremental + hierarchical checkpointing** (cell-level frequent/cheap; region-level periodic; global-level at epoch boundaries only); copy-on-write; delta encoding; **rollback granularity matched to failure granularity** (roll back a cell, not the organism) |
| **S13** | **Flat topology has no room.** Routing tables, directory lookups, and coordination all degrade without hierarchy | 10⁴ | 🔴 Fatal | **5–7 level hierarchy at 10⁸ cells**: cell → cluster (~10²) → subregion (~10³) → region (~10⁴) → hemisphere/federation (~10⁶) → global. Depth scales as ~log(N). Each level has bounded fanout and a defined aggregation contract |
| **S14** | **Fixed cell complexity cannot span 10²–10⁸ cells** (§O.2: ~200 capable cells on a phone) | **All scales** | 🔴 Fatal | **Scalable cell variant family C0–C4 sharing one interface contract** (M11.3). The organism is defined by the *contract*, not the variant. This is the single most important design decision in the architecture |
| **S15** | **Memory capacity wall.** Episodic + semantic + provenance over years of operation | 10³ (time-based, not scale-based) | 🟠 Severe | Tiered storage; **bounded stores with explicit retention curves**; compression via generalization (specific episodes → abstract semantics, with the episode archived not deleted); forgetting as a *designed* function with a policy, not an accident |

**Overarching finding:** the architecture contains **no scale-dependent mechanism whatsoever**. It describes one configuration and implicitly assumes it stretches across six orders of magnitude. It does not. **The revised architecture must specify a different configuration per scale band** (§R.2), with the *contract* invariant across bands and the *morphology* variable — which is exactly what M11 (HAMC) provides. Scalability and hardware adaptation are, in this architecture, **the same problem**.

---

## 6. EVOLUTION RISKS

| # | Risk | Present mitigation | Sufficient? | Required mitigation |
|---|---|---|---|---|
| **E1** | **Evolutionary collapse / monoculture** — one lineage colonizes; Ne collapses; correlated failure becomes certain | "heterogeneous cell populations"; "avoid monoculture"; "diversity preservation" | ❌ Named, never enforced. No diversity *measure*, no mechanism | **MAP-Elites / quality-diversity** as the primary paradigm; island model with differentiated fitness weights; **lineage-distance gate** (K.2 G7); monitored Ne and behavioural entropy with **automatic evolution halt** on decline; enforced error-correlation caps between lineages (C9) |
| **E2** | **Reward hacking / Goodhart** — fitness and tests become the target | "multi-objective fitness + hard constraints" | ❌ Undermined by V3.1 §9's **linear scalarization of incommensurable units** | Pareto-front selection, never a scalar sum; lexicographic hard constraints; **fitness definition signed and off-substrate**; held-out test rotation with protected generator; **jump detection** (large fitness gain ⇒ audit before deploy); canary populations on invisible tests; cross-environment reproducibility; specification-gaming pattern library |
| **E3** | **Loss of rare capabilities** — pruning removes the underused; the rare *is* the underused | "preserve rare useful variants" | ❌ **Directly contradicted by V3 §18's underuse-pruning rule (C5)** | **Capability Registry** with keeper populations **exempt from underuse pruning** and a reserved budget floor; capability regression gate on every pruning/consolidation/selection event; periodic capability assay |
| **E4** | **Destructive mutations** — damage to safety layer, constraint block, provenance anchor | "immutable safety constraints"; "evolutionary firewall" | ❌ **The firewall is inside the organism (F4)** | Constraint block as a **separate signed artifact outside the mutable genome**; checksum + signature verification at every instantiation with refusal on mismatch; bounded mutation space with typed operators; off-substrate verification of deployed genome hashes; two-key integrity for constraint-adjacent change |
| **E5** | **Runaway complexity** — genome and topology grow; cost rises; fitness flat | "penalties → resource cost" | ⚠️ Weak — a penalty in a linear sum is tradeable | **Hard caps** on genome size, node count, degree (not penalties — caps); parsimony pressure; complexity budget as a homeostatic variable; cost-normalized fitness (performance *per unit resource*); periodic forced-simplification trials |
| **E6** | **Evolutionary drift** — slow accumulation of individually-neutral changes erodes capability; no gate fires because no step is bad | None | ❌ **Completely unaddressed, and it is the hardest failure to detect** | **Golden-baseline regression suite** vs. a frozen reference population every epoch; long-horizon evaluation; capability floor as hard gate; periodic full re-evaluation; genome/structure hash distance monitoring with change-point detection; **externally anchored historical metrics** (so the record of past capability cannot drift with the capability); mandatory tested rollback checkpoint per epoch |
| **E7** | **Synthetic-data degeneration / model collapse** — cells learn from cells; provenance closes on itself; diversity collapses | "provenance graph + protected external ground truth" | ❌ Right instinct, **no mechanism**, and no answer to *who supplies ground truth indefinitely* | **Inbreeding coefficient `F`** over the provenance DAG with hard cap for critical beliefs; mandatory external ground-truth quota per batch; **write-protected** external corpus; diversity-entropy monitoring with automatic halt; only externally validated outputs become training data; self-generated content barred from protected memory; **M41 ground-truth supply governance with named sources and SLAs** |
| **E8** | **Sandbox→production mismatch** — candidates pass sandbox, fail in production | "sandbox testing → deployment → monitoring" | ❌ No fidelity measurement, no progressive deployment | **Sandbox-fidelity measurement** (does sandbox performance predict production performance? track it; distrust the sandbox when fidelity drops); shadow → 1% → 10% → full canary; automatic rollback on regression; production-holdout environments never used in selection; adversarial sandbox test generation |
| **E9** | **Runaway replication** — exponential population growth | "homeostasis + population limits" | ⚠️ Named with no enforcement mechanism or authority | **Replacement-default (zero-sum) replication** — a slot must be freed before one is taken; off-substrate population cap enforced at the hypervisor/OS level; replication rate limiter; replication tokens issued by an external authority; superlinear metabolic cost; **the cell itself must have no replication authority** |
| **E10** | **Evolution of the evolution controller** — the organism modifies its own selection criteria | None | ❌ **The terminal failure mode; not addressed anywhere** | Evolution controller, fitness definition, evaluation harness, and test generator are **off-substrate artifacts**, signed, versioned, changeable only by the external operator; invariant routing policy ensuring no mutation can remove mandatory verification paths (C15); off-substrate audit of all changes to selection machinery |
| **E11** | **Evolutionary stall** — variation operators stop producing anything useful; the population sits on a local optimum | "explorers → novel strategies" | ❌ Explorers are a role name with no mechanism | **Novelty search** (reward behavioural novelty independent of quality); random restarts from the archive; **≥20% of evolutionary budget reserved for experience-independent variation** (§M.3); periodic environmental perturbation to shift the fitness landscape; archive-based re-seeding |
| **E12** | **Selection on the wrong level** — a circuit benefits the organism but not its cells; cell-level fitness destroys it | Fitness defined only per cell/population | ❌ No multi-level selection | **Fitness measured at each organizational level** (cell, circuit, population, region, organism) with explicit level-weighting policy; group-selection mechanisms (differential circuit/region replication and dissolution) — this is also **required for emergence** (§S.2.7), not just for evolution |
| **E13** | **Co-evolutionary arms race** — critics evolve to be easily satisfied; proposers evolve to exploit weak critics; both improve on paper while quality collapses | "redundant critics" | ❌ No co-evolution dynamics modelled | **Independent critic fitness** (critics scored on *detection rate against injected defects*, not on agreement with proposers); periodic adversarial injection of known-bad candidates to measure critic sensitivity; **critic sensitivity as a monitored metric with alerting on decline**; rotation of critic populations |
| **E14** | **Lineage capture of governance** — regulators, referees, verifiers, and memory keepers all descend from one lineage and share its biases | "independent populations" | ❌ Independence asserted, never enforced or measured | Enforced lineage distance for all governance roles; **lineage entropy monitoring** across governance populations; rotation with term limits; off-substrate audit of governance-population lineage distribution |

---

## 7. AWARENESS-LIKE COMPUTATION AUDIT

**Question: do global workspace + self-state + attention + error awareness + metacognition form a coherent computational loop?**

### Answer: **The topology is coherent. The loop is not closed. 0 of 10 target properties are currently measurable.**

**Coherent (this is real credit):**
- The five subsystems are the *right* five. Any operational account of awareness-like computation needs shared availability, self-representation, selective resource allocation, error detection, and control of one's own processing. V3.1 selected correctly.
- The interconnection pattern is right: workspace ⇄ self-state (mutual), attention → workspace (gating), error awareness → all three (correction), metacognition → attention + strategy (control). V3.1 §1's layout and §10's integrated loop both express this correctly.
- The **scientific boundary is stated correctly and repeatedly** (V3 §19, V3.1 §11–12): operational properties ≠ subjective consciousness. This must be preserved verbatim.
- V3.1's key insight — *"awareness-like information is not stored only inside one cell"* — is the correct architectural move and is what distinguishes this from a per-cell metacognition flag.

**Not closed — the seven breaks (§N.2), restated as an audit finding:**

| Break | Consequence | Fix |
|---|---|---|
| No ignition semantics | "Global availability" has no operational content ⇒ **unmeasurable** ⇒ the property V3 §19 names as its first test target cannot be tested | Explicit ignition threshold, broadcast event, `ignition_rate` / `broadcast_reach` / ablation-measured `availability_benefit` metrics |
| Self-state monitor is open-loop | **Confabulation.** Every consumer acts on an unvalidated self-model. A confidently wrong self-model is worse than none | Capability assay; self-prediction error as a first-class error type; claim–behaviour consistency monitor; per-field confidence + last_validated |
| Attention ⇄ workspace recursion has no fixed point | Nondeterministic priority resolution; potential for attention lock-up | Two pathways (fast reflexive bottom-up, slow deliberate top-down) with hard ordering `SAFETY > reflexive > deliberate` |
| No value-of-computation | Unbounded or arbitrarily-bounded deliberation; no principled stop rule | VOC = expected benefit vs. cost, with explicit stop; anytime algorithms throughout |
| No temporal binding | Context continuity is unmeasurable and unachievable | Global epoch + timebase; episode segmentation; `continuity_score` (MI between successive context states); WM duration bounds |
| No second-order uncertainty | "Limitation awareness" reduces to reading a static list | Every self-state field carries confidence; capability map carries CIs from assay sample size |
| No unknown-unknown handling | The system guesses outside its competence while reporting confidence | Coverage estimation; OOD detection with **mandatory abstention + escalation**; explicit scope declaration; ignorance reports |

**Additional structural finding:** the workspace, attention controller, and self-state monitor are all **single-instance, unreplicated, and unrepaired** (§C.11, §P.2). The awareness layer is therefore the *least* fault-tolerant part of an architecture whose central claim is fault tolerance. Failure of the workspace produces an organism that **continues to act while having lost the capacity to know what it is doing** — which is the worst possible failure mode for a system with action authority. Required: replication, regional fallback, off-substrate watchdog, and a **degraded mode that reduces action authority when global integration is lost.**

**Verdict: the awareness architecture is the strongest conceptual contribution of V3.1 and the weakest engineering specification in either document.** It needs no new ideas. It needs types, thresholds, metrics, replication, and a validation loop.

---

## 8. PLASTICITY AUDIT

**Question: does the architecture support structural adaptation from synapse → cell → circuit → region?**

### Answer: **No. It supports named plasticity at five levels with mechanisms at approximately one, and it lacks every constraint that would make plasticity safe to enable.**

| Level | Named | Mechanism | Stability constraint | Verdict |
|---|---|---|---|---|
| Synapse | ✅ | ⚠️ one-line Hebbian slogan (V3 §8) | ❌ none | Unbounded ⇒ saturates |
| Cell | ✅ | ❌ four named targets, no update rule | ❌ none | **Conflicts with immutable safety layer — scope undefined** |
| Connection | ✅ | ❌ create/reroute/prune with no handshake or teardown | ❌ none | **Unilateral connection modification is a DoS vector against the target** |
| Circuit | ✅ | ❌ | ❌ none | **Operates on an object that does not exist (§I.1)** |
| Functional population | ⚠️ folded into regional | ❌ | ❌ | Population boundaries never defined |
| Region | ✅ | ❌ | ❌ | Operates inside a **hard-coded** taxonomy (C13) |
| Global architecture | ✅ (V3.1 §7) | ❌ | ❌ | **Directly contradicts immutable safety (C4)** |

**Cross-cutting absences, all mandatory:**
1. **No timescale separation** — five concurrent plasticity processes with no defined relative rates will fight each other. Fast synaptic change undoes slow structural decisions; circuit reorganization invalidates the synapses that justified it.
2. **No homeostatic plasticity** — pure Hebbian strengthening without synaptic scaling or activity bounds **saturates and kills the network**. This is textbook and it is absent. **Enabling the specified plasticity without this will make the system worse, not better.**
3. **No metaplasticity** — no sliding threshold, so recently-potentiated pathways potentiate further. Rich get richer; the network collapses onto a few pathways.
4. **No eligibility traces** — credit cannot be assigned across delay (§E, §F). Plasticity without credit assignment modifies components that happened to be active, not components that caused the outcome.
5. **No structural-change budget** — unbounded self-modification rate. Also a safety failure (§L.2), not just a stability one.
6. **No critical periods** — load-bearing structure can be reorganized at any time, so no structure is ever reliably load-bearing.
7. **No reconsolidation** — retrieved memories cannot be corrected, so old wrong beliefs are permanent (§F.1).
8. **No interference model** — proactive/retroactive interference unmodelled; new learning silently destroys old capability with no detection.
9. **No functional contracts** — nothing prevents structural change from destroying a region's or circuit's function (§J.4). **The correct principle, which the architecture never states: constrain the interface, liberate the implementation.**
10. **Two levels missing entirely** — protocol/schema plasticity (§G.2.1, probably defer to P2 given the interoperability risk) and meta-plasticity (§G.2.2, P2).

**Verdict: plasticity is the second-weakest subsystem relative to its importance.** It is also the most dangerous to implement naively: an engineer following V3/V3.1 literally would build an unstable system that saturates, oscillates, and forgets, and would attribute the failure to the architecture rather than to the missing constraints. **The stability layer (M19) must be built *before* the plasticity layer, not after.**

---

## 9. HARDWARE ADAPTATION AUDIT

**Question: can the organism morph its computational structure according to available hardware?**

### Answer: **No. The organism has no concept of hardware.** It cannot discover compute, memory, storage, bandwidth, latency, energy, or accelerators; and it cannot alter its population, architecture, routing, or replication in response. V3 §18 lists six of these quantities as homeostatic variables *to be regulated* — regulating a variable is not discovering it, and neither is adapting structure to it.

**Complete absence list:** no capability discovery or probing; no accelerator detection; no energy/thermal/battery awareness; no hardware profile artifact; no morphology policy; no cell-complexity scaling; no topology adaptation; no state migration; no heterogeneous-deployment model; no degradation ladder; no re-adaptation on hardware change.

**The physics constraint that makes this P0 rather than P1** (computed for this audit):

| Cell complexity | Phone: max cells @ 1 Hz (20 GFLOP/s, 4 GB) | 100M cells: sustained compute |
|---|---|---|
| Tiny (1 MFLOP, 100 KB) | ~20,000 | 0.1 PFLOP/s |
| Small (100 MFLOP, 5 MB) | **~200** | **10 PFLOP/s** (large datacenter) |
| Nano-transformer (1 GFLOP) | ~20 | **100 PFLOP/s** (beyond any single current installation) |

A cell capable of the V3 §4 list (perceive, maintain state, remember 5 memory types, learn, predict, simulate, decide, estimate uncertainty, self-monitor) is **not** a 1 MFLOP object. **Required dynamic range: ~10² to ~10⁸ cells — six orders of magnitude.** And the fixed 20-region taxonomy (C13) makes this worse: a 200-cell organism cannot instantiate 20 named regions with viable populations.

**Required subsystem: HAMC (M11)** — six components:
1. **Capability discovery** — *measured*, not spec-read (specs lie under thermal load and co-tenant contention); continuous re-profiling because capability changes at runtime; output = signed, versioned hardware profile.
2. **Morphology policy** — profile → {cell_scale, cell_variant, hierarchy_depth, topology, region_count, verification_depth, memory_tiering, evolution_mode, sync_model, replication_rate}.
3. **Scalable cell variant family C0–C4** sharing **one interface contract** — *the key mechanism, and the single most important design decision in the architecture.* The organism is defined by the contract, not the variant. Requires: formal cell interface contract + behavioural equivalence tests across variants + variant-selection policy. None exist.
4. **8-rung graceful degradation ladder** with entry/exit criteria and self-state declaration per rung — from L0 nominal through reduced verification, reduced plasticity, reduced population, region consolidation, evolution suspension, protect-core-only, to L7 safe halt. V3 §21 says "graceful degradation" and specifies no ladder.
5. **Migration & heterogeneous deployment** — state serialization, checkpoint/restore, live migration, split deployment with cross-device message budgets, **and offline operation** (a phone that loses connectivity must retain core cognition — no cloud dependency for basic function).
6. **Continuous re-adaptation with hysteresis** — morphology changes must be gradual and reversible or the organism will thrash between configurations on every thermal event.

**Key insight for the architecture:** **scalability (§R) and hardware adaptation (§O) are the same problem.** Both require the organism's morphology to be a *function of available resources* rather than a constant. Solving HAMC solves both. They should be designed together, by the same people, as one subsystem — and the current document treats them as unrelated (one is absent, the other is a list of regulated variables).

---

## 10. REQUIRED ARCHITECTURAL UPGRADES — PRIORITIZED

### P0 — MANDATORY (system cannot be correctly built or safely operated without these)

| ID | Upgrade | Addresses | Depends on |
|---|---|---|---|
| **P0-01** | **Define target tasks, environments, and fitness.** 3–5 concrete environments with measurable success criteria, ground-truth supply plan, curriculum. Move to Roadmap **Phase 0** | F2, C14, W17, M01 | — |
| **P0-02** | **Build the off-substrate immutable kernel.** Signed constraints, resource enforcement at OS/hypervisor level, replication authority, fitness & test definitions, provenance anchor, audit log, operator interface with kill switch | F4, C4, E4, E10, M02, M28 | — |
| **P0-03** | **Write the Minimal Cell Specification** — typed ports, state vector, confidence estimator, bounded tiered memory, self-modification scope excluding safety by construction, **replication authority removed from the cell** | F1, M03 | P0-01 |
| **P0-04** | **Specify the message protocol and transport** — envelope, 4 addressing modes, hierarchical locality-aware routing, per-class delivery semantics, congestion control, circuit breakers | §B, M04 | P0-03 |
| **P0-05** | **Implement identity, authentication, and trust computation** — signed birth certificates, per-message epoch-key signatures, revocation, `Beta(α,β)` contextual trust with age discount and cap < 1.0, lineage-distance verification | §B.6, C9, E14, M05 | P0-02, P0-04 |
| **P0-06** | **Build the uncertainty estimation and calibration engine** — ensemble + evidential head, aleatoric/epistemic split, continuous recalibration, ECE/Brier/reliability as monitored metrics, `confidence + calibration_class` | F3, M06 | P0-01, P0-03 |
| **P0-07** | **Define the genome representation and typed mutation operators** with the constraint block as a separate signed artifact | §L.1, E4, M07 | P0-02, P0-03 |
| **P0-08** | **Build persistence, checkpointing, and rollback** — WAL, hierarchical checkpoints, last-known-good, **tested restore**, recovery capability reported in self-state | §A, §P.1, M08 | P0-03 |
| **P0-09** | **Implement error attribution and credit assignment** — causal trace, counterfactual ablation, eligibility traces, distributed responsibility, **error-signal gating before learning** | §E.3, §F.1, M09 | P0-04, P0-06 |
| **P0-10** | **Build the verification cost model and depth policy** — cost-aware stage selection, anytime pipeline, reduced-verification state propagated into confidence | F5, C1, M10 | P0-01, P0-06 |
| **P0-11** | **Build HAMC with the scalable cell variant family C0–C4** and the 8-rung degradation ladder | §O, S14, M11 | P0-03 |
| **P0-12** | **Implement the homeostatic control system** — explicit control laws, setpoints as functions of hardware profile, 13 additional regulated variables, controller priority ordering, **loop-gain verification**, off-substrate hard-bound watchdog | §Q, M12 | P0-08, P0-11 |
| **P0-13** | **Define circuits as first-class objects** with functional contracts, registrar, and circuit-level fitness | §I, M13, E12 | P0-03, P0-04 |
| **P0-14** | **Build the differentiation engine** — morphogen gradients, lateral inhibition, demand signals from homeostasis, niche capacity, staged commitment, formal fate specs | §H, M14 | P0-03, P0-12 |
| **P0-15** | **Build the Capability Registry with floor enforcement** — keeper populations exempt from underuse pruning, reserved budget floor, capability regression gate on every pruning/consolidation/selection event | C5, E3, M15 | P0-01, P0-12 |
| **P0-16** | **Build the real global workspace engine** — admission policy, ignition semantics, specified salience function with off-substrate weights, rotating lineage-diverse referees, uncapturable safety bypass, tiered scoped access with logged reads, TTL + invalidation + tombstones, **hierarchical (summaries global / detail regional)**, replication + failover + **degraded mode that reduces action authority**, monopolization detection | §C, C3, C8, S1, M16 | P0-04, P0-06 |
| **P0-17** | **Implement feedback-loop control** — influence graph, cycle detection, **`loop_gain < 1` as an off-substrate-verified invariant**, delay insertion, decorrelation, oscillation detector | §B.12, M17, S8 | P0-04 |
| **P0-18** | **Fix the concurrency and consistency model** — actor per cell, async messaging, **no global locks**, CRDTs/leases/vector clocks, declared bounded staleness, deterministic replay | M18, S11, M46 | P0-04 |
| **P0-19** | **Build the plasticity stability layer BEFORE the plasticity layer** — enforced timescale ordering, homeostatic plasticity, metaplasticity, structural-change budget, critical periods, reconsolidation, interference management | §G.3, M19 | P0-06, P0-09, P0-12 |
| **P0-20** | **Implement multi-level selection and a real evolutionary algorithm** — MAP-Elites/quality-diversity, Pareto-front selection (never a scalar sum), lexicographic hard constraints, island model, **fitness at every organizational level**, surrogate fitness models | §K.1, §L, E1, E2, E12, M20 | P0-01, P0-07 |
| **P0-21** | **Build the Replication Authority with 11 conjunctive gates**, replacement-default (zero-sum) replication, weighted lottery, off-substrate rate cap | §K, E9, M21 | P0-02, P0-07, P0-15 |
| **P0-22** | **Specify the memory architecture** — per-store schemas, capacities, retention curves, retrieval, **integrity verification + erasure coding**, reconsolidation, interference model, fully specified consolidation pipeline, tiering | §F.1, C10, M22 | P0-03, P0-08 |
| **P0-23** | **Build the provenance engine** — append-only Merkle DAG, granularity policy, **inbreeding coefficient**, **external anchoring** | §C.8, E7, M23 | P0-02, P0-22 |
| **P0-24** | **Implement anti-model-collapse controls** — self-generated tagging, fraction caps, `F` cap, mandatory external ground-truth quota, write-protected corpus, diversity monitoring with **automatic evolution halt** | §F.2, E7, M24 | P0-23, M41 |
| **P0-25** | **Define the quarantine state machine and autoimmune protections** — quarantine budget cap off-substrate, graduated response ladder, false-positive budget per detector, second-opinion requirement, **cascade detection** | §P.3, M25 | P0-05, P0-12 |
| **P0-26** | **Build the measurement, falsification, and ablation framework** — operational definition + metric + protocol + baseline + null hypothesis for each of the 10 awareness properties and each major subsystem; **mandatory ablation methodology** | §N.3, M26 | P0-01 |
| **P0-27** | **Build drift detection and long-horizon integrity** — golden-baseline regression suite, continuous capability assay, change-point detection, **externally anchored historical metrics**, standing operator trajectory report | §T.2, E6, M27 | P0-15, P0-23, P0-26 |
| **P0-28** | **Implement region formation with functional contracts** — substrate-first, activity-dependent competition, mutual inhibition, region lifecycle with merge/split/retire, **functional conservation constraint**, bounded region count (4–12), anatomical names as post-hoc labels | C13, §J, §S, M29 | P0-13, P0-14 |
| **P0-29** | **Build hierarchical coordination and aggregation** — locality-aware placement (**also the region-formation engine and the #1 scalability fix**), hierarchical routing, **compressor/summary cells as a distinct role**, hierarchical workspace/self-state/homeostasis, island-model evolution | §R.3, S1, S2, S13, M30 | P0-04, P0-11 |
| **P0-30** | **Specify the learning algorithm suite** — algorithm per mode, step-size policy per timescale, prioritized replay with interleaving ratio, offline consolidation mode, **"when not to learn" policy** | §F.1, M31 | P0-06, P0-09, P0-19 |
| **P0-31** | **Resolve the 15 contradictions formally** and record each resolution in the specification with its rationale | §3 | all above |

### P1 — HIGHLY IMPORTANT (required for a robust, maintainable, long-running system)

| ID | Upgrade | Addresses |
|---|---|---|
| **P1-01** | Resource accounting and scheduling with defined units and an over-budget response ladder | M32, W06 |
| **P1-02** | Evaluation harness with held-out rotation, protected generator, adversarial test generation, cross-environment validation, **sandbox-fidelity measurement**, canary populations | M33, E2, E8 |
| **P1-03** | Deployment pipeline: shadow → 1% → 10% → full, with automatic rollback | M34, E8 |
| **P1-04** | Capability Directory Service for capability-based addressing | M35, W21 |
| **P1-05** | Self-model validation loop: capability assay, self-prediction error, claim–behaviour consistency, per-field confidence, versioning + rollback | M36, §D, §N.2.2 |
| **P1-06** | Temporal binding: global epoch + timebase, episode segmentation, `continuity_score` | M37, §N.2.5 |
| **P1-07** | Internal-state prediction model (organism's own dynamics), consumed by MPC homeostasis and planning | M38, §N.1, S7 |
| **P1-08** | **Coordination-error detection** — deadlock/livelock, duplicated work, races, contention, thundering herd | M39, §E.2.1 |
| **P1-09** | Value-of-computation and anytime control with explicit stop rules | M40, §N.2.4 |
| **P1-10** | Ground-truth supply governance: named sources with SLAs, freshness as a homeostatic variable, **ground-truth source integrity monitoring** (external ≠ infallible) | M41, E7, §E.2.4 |
| **P1-11** | Scope declaration and OOD abstention — coverage estimation, mandatory abstention + escalation, ignorance reports | M42, §N.2.7 |
| **P1-12** | Deterministic replay and debugging (with sampled/triggered recording to bound cost) | M46, §M18 |
| **P1-13** | Energy/cost economic model: unified cost unit, per-operation pricing, cost-aware verification and attention | M48, C1 |
| **P1-14** | Repair mechanisms per target (cell, connection, circuit, memory, region, **global subsystem**) including **replication + consensus for global subsystems** and independent integrity auditing of the immune system itself | §P.2 |
| **P1-15** | Immune memory with signature clustering, generalization to failure classes, and decay; failure-record → detector-improvement loop | §P.4 |
| **P1-16** | Extend the error taxonomy to 16 classes (add coordination, specification/objective, safety-violation, ground-truth, self-model, evolutionary, plasticity, provenance, attention/workspace) + severity scale | §E.2, §E.3 |
| **P1-17** | Complete the self-state specification with the 11 missing elements (model/genome version, pending changes, evaluation state, ground-truth freshness, diversity/Ne, recovery capability, constraint compliance, trajectory history, **self-model confidence**, staleness, influence map) | §D |
| **P1-18** | Baldwinian bridge implementation with the **abstraction step** and ≥20% experience-independent variation reserve | C2, §M.2, §M.3, E11 |
| **P1-19** | Rewrite the roadmap: Environment + fitness to Phase 0; measurement/ablation as a continuous activity; **stability layer before plasticity layer**; add explicit scale-band milestones (10², 10⁴, 10⁶) with per-band configuration | C14, §R.2 |

### P2 — ENHANCEMENT

| ID | Upgrade | Addresses |
|---|---|---|
| **P2-01** | Protocol/schema versioning with compatibility windows (protocol plasticity gated — probably defer indefinitely given interoperability risk) | M43, §G.2.1 |
| **P2-02** | Meta-plasticity: plasticity-rate adaptation from measured environmental volatility, within off-substrate bounds | M44, §G.2.2 |
| **P2-03** | Formal verification / model checking of core invariants (population cap, resource ceiling, constraint immutability, `loop_gain < 1`, firewall non-reachability, quarantine budget), published as a **safety case** | M45, §F4, §S.3 |
| **P2-04** | Federated / partition-tolerant organism model for ≥10⁷ cells, with defined per-partition autonomy and reconciliation | M47, §R.2 |
| **P2-05** | Curiosity / intrinsic motivation as a formal exploration driver (currently "explorers" is a role name with no mechanism) | E11, §S.2.4 |
| **P2-06** | Sleep/offline consolidation mode with prioritized replay and knowledge extraction from retiring cells | §F.1, §A (retirement) |
| **P2-07** | Emotional-analogue state model — V3 correctly separates value/state from evidence but never specifies what the state variables *are* or how they modulate processing (contradiction C12 governs) | C12, §D |

### P3 — OPTIONAL RESEARCH

| ID | Upgrade |
|---|---|
| **P3-01** | Open-ended novelty search with no fixed fitness (pure quality-diversity exploration) — scientifically interesting, operationally risky |
| **P3-02** | Cross-organism knowledge transfer / cultural evolution between separately-running Digital Brains |
| **P3-03** | Self-generated curriculum and automated environment design |
| **P3-04** | Neuromodulatory-analogue global control signals beyond the current signal taxonomy |
| **P3-05** | Formal emergence detection — automated identification of genuinely novel higher-level capabilities not predictable from component behaviour |

---

## 11. REVISED MASTER ARCHITECTURE — V4

Integrated, not annotated. Missing mechanisms are placed where they belong. `⟨NEW⟩` marks a subsystem absent from V3/V3.1; `⟨FIX⟩` marks one materially corrected.

```
DIGITAL ORGANISM V4
│
├── LAYER 0 — OFF-SUBSTRATE INVARIANT KERNEL                    ⟨NEW⟩
│   │   PRINCIPLE: anything that constrains evolution must not be
│   │   reachable by evolution. Enforced at type/OS level, not by policy.
│   ├── Immutable Safety Kernel
│   │   ├── signed constraint set (lexicographic, non-tradeable)
│   │   ├── constraint verifier (runs at every instantiation & deployment)
│   │   ├── resource-ceiling enforcement (OS/hypervisor level, not in-process)
│   │   ├── population cap + replacement policy (zero-sum)
│   │   ├── replication rate limiter
│   │   ├── self-modification rate limiter
│   │   └── mandatory-path routing invariants (no mutation may remove a
│   │       required verification / gating / safety path)               [C15]
│   ├── Fitness & Evaluation Authority                                ⟨NEW⟩
│   │   ├── task/environment definitions + success criteria            [F2]
│   │   ├── fitness function (versioned, signed, Pareto — never scalar sum)
│   │   ├── evaluation harness + protected test generator
│   │   ├── held-out test rotation + adversarial test generation
│   │   ├── sandbox-fidelity measurement
│   │   └── golden-baseline regression suite                          [E6]
│   ├── Ground-Truth Anchor                                          ⟨NEW⟩
│   │   ├── named external sources with SLAs
│   │   ├── write-protected external corpus
│   │   ├── freshness monitor (homeostatic variable)
│   │   ├── source-integrity monitor (external ≠ infallible)          [E.2.4]
│   │   └── ground-truth quota enforcement per learning batch         [E7]
│   ├── Provenance Anchor                                            ⟨NEW⟩
│   │   └── externally published signed Merkle root hashes
│   │       ⟹ history is tamper-EVIDENT even if not tamper-proof
│   ├── Identity & Trust Root                                        ⟨NEW⟩
│   │   ├── lineage key authority + signed birth certificates (Sybil-proof)
│   │   ├── epoch key rotation + revocation lists
│   │   └── off-substrate trust auditor
│   ├── Operator Interface & Containment                             ⟨NEW⟩
│   │   ├── read-only anchored dashboard (metrics immune to internal drift)
│   │   ├── kill switch (substrate level)
│   │   ├── authorization gates: architecture change, constraint change,
│   │   │   fitness change, envelope change
│   │   ├── emergency freeze / L7 safe halt
│   │   ├── standing capability-trajectory report                     [T.2]
│   │   └── ENVELOPE MODEL: autonomous inside, human authority over envelope
│   └── Audit Log (append-only, anchored, off-substrate)
│
├── LAYER 1 — SUBSTRATE & CELL FOUNDATION
│   ├── Hardware Abstraction & Capability Discovery                  ⟨NEW⟩
│   │   └── measured (not spec-read) compute/accelerators/memory/storage/
│   │       network/energy/thermal/cost ⟶ signed HARDWARE PROFILE,
│   │       continuously re-profiled (capability changes at runtime)
│   ├── Morphology Controller (HAMC)                                 ⟨NEW⟩
│   │   ├── profile → morphology policy
│   │   │   {cell_scale, cell_variant, hierarchy_depth, topology,
│   │   │    region_count, verification_depth, memory_tiering,
│   │   │    evolution_mode, sync_model, replication_rate}
│   │   ├── SCALABLE CELL VARIANT FAMILY (one interface contract)     ⟨NEW⟩
│   │   │   C0 reflex (~10 KFLOP) · C1 tiny (~1 MFLOP) ·
│   │   │   C2 small (~100 MFLOP) · C3 capable (~1 GFLOP) ·
│   │   │   C4 region-core (~10+ GFLOP, cluster-hosted)
│   │   │   + behavioural equivalence tests across variants
│   │   │   ⟹ THE organism is the CONTRACT, not the variant
│   │   ├── 8-rung graceful degradation ladder (L0 nominal → L7 safe halt)
│   │   │   each rung: entry criterion, exit criterion, self-state declaration
│   │   ├── migration + heterogeneous/split deployment + OFFLINE operation
│   │   └── continuous re-adaptation with hysteresis (anti-thrash)
│   ├── Minimal Cell Specification                                   ⟨NEW⟩ [F1]
│   │   ├── typed input/output ports + schema-validated payloads
│   │   ├── DEFINED state vector (types, units, ranges, serialization)
│   │   ├── confidence estimator: small ensemble + evidential head     [F3]
│   │   │   with aleatoric/epistemic split + calibration_class
│   │   ├── bounded tiered memory with named schemas
│   │   ├── SELF-MODIFICATION SCOPE — excludes safety by construction  [C4]
│   │   ├── NO autonomous replication authority                        [K.2]
│   │   ├── invariant monitors (self-diagnosis)
│   │   └── checkpoint/restore interface                               [M08]
│   ├── Message Protocol & Transport                                 ⟨NEW⟩ [§B]
│   │   ├── 7 signal classes (DATA/CONTROL/EVALUATIVE/META/SOCIAL/
│   │   │   SYSTEM/SAFETY) with per-class authority + delivery semantics
│   │   │   RULE: SAFETY emission is permissionless; SAFETY execution is
│   │   │         monopolized by Layer 0
│   │   ├── canonical envelope (msg_id, conv_id, epoch, ttl, prio,
│   │   │   provenance hash, confidence+calibration_class, cost,
│   │   │   causality vector clock, seq, signature)
│   │   ├── 4 addressing modes: direct / hierarchical / CAPABILITY-BASED
│   │   │   / scoped broadcast
│   │   ├── hierarchical locality-aware routing, loop-free, k-disjoint
│   │   │   paths for prio ≤ 2
│   │   ├── 8-level priority, strict preemption for L0–L1 only,
│   │   │   WFQ + aging (no starvation)
│   │   ├── congestion: token bucket, backpressure, priority shedding,
│   │   │   aggregation, summarization
│   │   └── failure: timeout+backoff, circuit breaker, gap detection,
│   │       idempotent dedup, causal ordering
│   ├── Identity, Authentication & Trust                             ⟨NEW⟩
│   │   ├── per-message signature with epoch key
│   │   ├── TRUST = Beta(α,β) posterior per (source, CONTEXT)
│   │   │   + age discount (anti trust-farming)
│   │   │   + HARD CAP trust_max < 1.0 (no cell is ever fully trusted)
│   │   │   + context partitioning (no cross-domain transfer)
│   │   │   + lineage-distance requirement for verification            [C9]
│   │   └── trust-poisoning defense: signed assertions, update-rate
│   │       anomaly detection, lineage-entropy (Sybil clique) detection
│   ├── Concurrency & Consistency Model                              ⟨NEW⟩
│   │   ├── actor per cell, async message passing, NO GLOBAL LOCKS
│   │   ├── CRDTs (counters) · leases (exclusives) · vector clocks (causality)
│   │   ├── bounded staleness declared per data class
│   │   ├── partition tolerance as the NORMAL case at scale            [M47]
│   │   └── deterministic replay (sampled + triggered, cost-bounded)   [M46]
│   ├── Feedback-Loop Control                                        ⟨NEW⟩ [§B.12]
│   │   ├── influence graph (from causality data) + cycle detection
│   │   ├── LOOP GAIN < 1 as an off-substrate-verified INVARIANT
│   │   ├── delay insertion on back-edges; negative-feedback bias
│   │   ├── decorrelation requirement (seeds, lineages) inside loops
│   │   └── runtime oscillation detector with auto-damping
│   └── Resource Accounting & Scheduling                             ⟨NEW⟩
│       ├── units: FLOPs, bytes, wall-time, energy (J), cost ($)
│       ├── admission control + deadline-aware scheduling + preemption
│       └── over-budget ladder: throttle → degrade → shed → resource-error
│
├── LAYER 2 — MEMORY & PROVENANCE
│   ├── Memory Architecture (specified, not named)                   ⟨FIX⟩ [C10]
│   │   ├── TWO-STORE RESOLUTION OF C10:
│   │   │   • IMMUTABLE EVENT LOG — append-only, Merkle-hashed, tiered,
│   │   │     sampled by policy, NEVER rewritten
│   │   │   • DERIVED BELIEF STORE — mutable, corrigible, versioned,
│   │   │     corrections create new versions, old tombstoned
│   │   │   • provenance links belief → event
│   │   ├── per-store schema + capacity + retention curve + retrieval API
│   │   │   for all 9 types (working/episodic/semantic/procedural/
│   │   │   associative/social/self/protected/archived)
│   │   ├── INTEGRITY: Merkle verification + erasure coding (critical stores)
│   │   ├── RECONSOLIDATION — retrieved memories are modifiable          ⟨NEW⟩
│   │   ├── INTERFERENCE model (proactive/retroactive) + monitoring       ⟨NEW⟩
│   │   ├── consolidation pipeline with all six operations SPECIFIED
│   │   │   (replay prioritization, importance, conflict detection,
│   │   │    compression, generalization, versioning) + triggers
│   │   ├── tiering: hot(RAM)/warm(SSD)/cold(object)/archive
│   │   └── FORGETTING as a designed function with an explicit policy
│   ├── Provenance Engine                                            ⟨NEW⟩
│   │   ├── append-only Merkle DAG; hashes not payloads
│   │   ├── granularity policy (full for high-impact, sampled for routine)
│   │   ├── cell lineage tree for every producer
│   │   ├── INBREEDING COEFFICIENT F = fraction of ancestry internally
│   │   │   generated; HARD CAP for critical beliefs                    [E7]
│   │   └── external anchoring (⟶ Layer 0 Provenance Anchor)
│   └── Capability Registry                                          ⟨NEW⟩ [C5]
│       ├── {capability, keeper_population, min_performance,
│       │    budget_floor, last_assayed, trend}
│       ├── keeper populations EXEMPT from underuse pruning
│       ├── reserved budget floor per registered capability
│       └── CAPABILITY REGRESSION GATE on every consolidation /
│           pruning / selection / structural-change event
│
├── LAYER 3 — LEARNING & PLASTICITY
│   ├── Learning Algorithm Suite                                     ⟨NEW⟩ [§F]
│   │   ├── modes: prediction-error · RL (with defined credit horizon) ·
│   │   │   evidential updating · social/imitation (provenance-gated)
│   │   ├── step-size policy per timescale
│   │   ├── PRIORITIZED REPLAY: importance × surprise × recency ×
│   │   │   capability-criticality, interleaved at fixed ratio
│   │   ├── offline/consolidation ("dreaming") mode
│   │   ├── PROVENANCE-GATED LEARNING — beliefs from quarantined sources
│   │   │   are unconsolidatable; quarantine propagates to dependents
│   │   └── "WHEN NOT TO LEARN" policy                                  ⟨NEW⟩
│   ├── Plasticity Engine (7 levels)                                 ⟨FIX⟩
│   │   ├── synapse · cell · connection · circuit · population ·
│   │   │   region · architecture
│   │   ├── connection plasticity REQUIRES handshake (target consent,
│   │   │   capacity check) + teardown protocol (drain, notify dependents)
│   │   └── circuit plasticity operates on REAL circuit objects (L5)
│   ├── PLASTICITY STABILITY LAYER — BUILD BEFORE THE PLASTICITY LAYER ⟨NEW⟩
│   │   ├── enforced timescale ordering:
│   │   │   synaptic(ms–s) ≫ cellular(min–h) > connection(h–d) >
│   │   │   circuit(d–wk) > region(wk–mo) > architecture(human-authorized)
│   │   │   faster levels may not undo slower levels inside a commitment window
│   │   ├── HOMEOSTATIC PLASTICITY (synaptic scaling, activity bounds)
│   │   │   ⟹ MANDATORY: pure Hebbian plasticity saturates and dies
│   │   ├── METAPLASTICITY (BCM sliding threshold)
│   │   ├── structural-change budget per epoch (hard self-modification cap)
│   │   ├── CRITICAL PERIODS — load-bearing structure frozen outside windows
│   │   ├── ELIGIBILITY TRACES (credit assignment across delay)
│   │   ├── stability index (homeostatic variable) ⟶ auto-reduces plasticity
│   │   └── oscillation detector ⟶ auto-dampen
│   ├── Anti-Failure Guardrails                                      ⟨NEW⟩
│   │   ├── forgetting: protected core + replay + regression gate + snapshots
│   │   ├── overfitting: held-out validation + cross-environment (≥k) +
│   │   │   monitored generalization gap
│   │   ├── instability: (see stability layer)
│   │   ├── reward hacking: Pareto (never scalar) + lexicographic hard
│   │   │   constraints + off-substrate fitness + jump detection + canaries
│   │   ├── feedback loops: (see L1 Feedback-Loop Control)
│   │   ├── corrupted information: signature + provenance validation
│   │   │   before learning + quarantine propagation
│   │   └── SELF-GENERATED DATA: tagging + fraction cap + F cap +
│   │       ground-truth quota + diversity monitoring with AUTO-HALT     [E7]
│   └── Error Attribution & Credit Assignment                        ⟨NEW⟩ [§E.4]
│       detect → classify(16 classes + severity) → ATTRIBUTE (causal trace,
│       counterfactual ablation, eligibility traces, distributed r_i)
│       → GATE (verify the error signal itself) → route by severity
│       → assign credit → update per timescale → record → consolidate
│       → escalate on recurrence → feed error budget
│       TWO LOAD-BEARING PROPERTIES ABSENT FROM V3/V3.1:
│         • attribution BEFORE credit (else learning is noise)
│         • gating BEFORE learning (else error signals are an attack vector)
│
├── LAYER 4 — COGNITIVE ARCHITECTURE
│   ├── Perception & Active Sensing                                  ⟨NEW⟩
│   │   └── sensing policy (what to sense next), perceptual learning,
│   │       sensor redundancy + fusion, attention–perception coupling
│   ├── Attention System                                             ⟨FIX⟩ [C7]
│   │   ├── POLICY/MECHANISM SPLIT resolving C7:
│   │   │   Attention Controller owns WHAT deserves attention (policy)
│   │   │   Thalamic routing owns HOW to deliver it (mechanism)
│   │   ├── TWO PATHWAYS with hard ordering resolving recursion:
│   │   │   SAFETY > fast reflexive bottom-up > slow deliberate top-down
│   │   ├── fixed attention BUDGET per epoch (attention is a resource)
│   │   ├── constrained-softmax allocation; temperature coupled to
│   │   │   self-state (stress ⟶ broaden)
│   │   ├── minimum exploration floor (anti lock-on)
│   │   ├── per-region caps + starvation floors + mandatory audit slots
│   │   └── switching cost model + VALUE-OF-COMPUTATION stop rule      ⟨NEW⟩
│   ├── Global Workspace Engine                                      ⟨FIX⟩ [§C]
│   │   ├── explicit ADMISSION POLICY (8 eligible classes; raw percepts
│   │   │   and sub-threshold hypotheses excluded)
│   │   ├── IGNITION SEMANTICS — nonlinear threshold, broadcast event,
│   │   │   measurable local-vs-global distinction                      ⟨NEW⟩
│   │   ├── specified salience function; weights signed & off-substrate
│   │   ├── signed, rate-limited, COST-CHARGED nomination
│   │   ├── REFEREE COMMITTEE: lineage-diverse, rotating, per-epoch
│   │   ├── SAFETY BYPASS — unconditional, uncapturable
│   │   ├── admission audit by independent Auditor population
│   │   ├── TIERED SCOPED ACCESS: Tier0 universal / Tier1 regional /
│   │   │   Tier2 restricted; reads are LOGGED AND SIGNED
│   │   │   (⟹ no covert channel through read behaviour)
│   │   ├── HIERARCHICAL WORKSPACE — global tier = SUMMARIES ONLY;
│   │   │   regional tiers = detail; promotion requires measured
│   │   │   cross-region relevance                                      [S1]
│   │   ├── item lifecycle: TTL + active invalidation + versioning +
│   │   │   tombstones (never in-place overwrite) + GC
│   │   ├── staleness monitor with periodic re-verification of
│   │   │   high-impact items
│   │   ├── CONFLICT: never silently merge ⟶ ConflictRecord ⟶
│   │   │   Verification Tournament ⟶ resolution hierarchy:
│   │   │   external ground truth > protected memory > majority of
│   │   │   lineage-INDEPENDENT verifiers > highest calibrated trust >
│   │   │   ABSTAIN + ESCALATE
│   │   │   + open-contradiction register (reduces downstream confidence)
│   │   │   + dissent registry
│   │   ├── consistency model: versioned items + leases + CRDT merge +
│   │   │   read-your-writes within region only
│   │   ├── REPLICATION + leader election per shard + failover           [C3]
│   │   ├── DEGRADED MODE: regional workspaces continue; GLOBAL
│   │   │   INTEGRATION LOSS ⟹ REDUCED ACTION AUTHORITY                 ⟨NEW⟩
│   │   ├── overload defense: bounded queue, priority shedding,
│   │   │   backpressure, occupancy/admission-latency/drop-rate as
│   │   │   homeostatic variables
│   │   └── MONOPOLIZATION defense: nomination caps, reserved quota
│   │       slots, rotating referees, Herfindahl-index detection
│   ├── Hypothesis & Reasoning                                       ⟨NEW⟩
│   │   ├── multi-hypothesis generation with diversity requirement
│   │   ├── MULTI-CELL inference (reasoning is a CIRCUIT property,
│   │   │   NOT a single-cell property)                                 [§A]
│   │   ├── simulation/counterfactual model with cost accounting
│   │   ├── multi-scale prediction hierarchy (ms → s → min → episode)
│   │   ├── EXPLICIT expected-information-gain computation
│   │   │   (⟹ required by the attention policy; currently uncomputable)
│   │   └── ANYTIME algorithms throughout (interruptible, still usable)
│   ├── Verification System                                          ⟨FIX⟩ [C1]
│   │   ├── lineage-INDEPENDENT verifier tournament (distance ≥ d)
│   │   ├── MEASURED error correlation between critics, with alerting    [C9]
│   │   ├── COST-AWARE VERIFICATION DEPTH:
│   │   │   depth = f(expected_error_cost × P(error), stakes, budget)
│   │   ├── anytime staged pipeline (each stage returns a usable result)
│   │   ├── surrogate verifiers (cheap learned predictors of expensive checks)
│   │   ├── verification-result caching keyed by content hash
│   │   ├── REDUCED-VERIFICATION STATE recorded in self-state and
│   │   │   PROPAGATED INTO CONFIDENCE
│   │   │   ⟹ never silently skip verification while reporting full confidence
│   │   └── abstention with THREE explicit outcomes resolving C6:
│   │       (i) abstain-and-probe (produces an outcome)
│   │       (ii) escalate to ground truth (produces a label)
│   │       (iii) true no-action (⟶ ignorance event ⟶ scope update)
│   │       NEVER a silent fourth case
│   ├── Metacognition & Value-of-Computation                         ⟨FIX⟩
│   │   ├── VOC = expected benefit of further computation vs its cost,
│   │   │   with an explicit STOP RULE
│   │   ├── strategy selection + strategy-performance history
│   │   ├── bounded recursion depth (no infinite metacognitive regress)
│   │   └── metacognitive monitoring itself under budget
│   ├── Error Awareness (16 classes)                                 ⟨FIX⟩ [§E]
│   │   ├── V3.1's 7 + communication + resource + system
│   │   ├── PLUS 9 NEW: COORDINATION (deadlock/livelock/oscillation/
│   │   │   duplicated work/race/contention/thundering herd — the dominant
│   │   │   multi-agent failure class, previously unnameable) ·
│   │   │   SPECIFICATION/OBJECTIVE · SAFETY VIOLATION · GROUND-TRUTH ·
│   │   │   SELF-MODEL · EVOLUTIONARY (sandbox→prod gap) · PLASTICITY
│   │   │   (learning made it worse) · PROVENANCE · ATTENTION/WORKSPACE
│   │   └── SEVERITY SCALE {info, minor, major, critical, catastrophic}
│   │       driving escalation and response
│   ├── Self-Model (closed loop)                                     ⟨FIX⟩ [§D]
│   │   ├── 7 V3.1 categories, now with TYPES, UNITS, RANGES, RATES
│   │   ├── PLUS 11 MISSING ELEMENTS:
│   │   │   model/genome/structure version · pending & planned changes ·
│   │   │   evaluation/test-suite state + last score · ground-truth
│   │   │   freshness · diversity & effective population size Ne ·
│   │   │   RECOVERY CAPABILITY (last checkpoint, validity, can-I-roll-back) ·
│   │   │   constraint-compliance margins · TRAJECTORY HISTORY (time series,
│   │   │   not just a vector) · SELF-MODEL CONFIDENCE (second-order
│   │   │   uncertainty) · self-state staleness/propagation latency ·
│   │   │   influence/control map
│   │   ├── per-field {value, confidence, last_validated, source}
│   │   ├── hierarchical aggregation (cell → cluster → region → global)
│   │   │   with DECLARED STALENESS BOUNDS per level
│   │   ├── VALIDATION LOOP (closing the open-loop defect):
│   │   │   • capability assay via known-difficulty probe tasks
│   │   │   • SELF-PREDICTION ERROR as a first-class error type
│   │   │   • claim–behaviour consistency monitor
│   │   │     ⟶ on divergence, DOWNGRADE THE DECLARATION, NOT THE BEHAVIOUR
│   │   │   • self-model provenance + versioning + rollback
│   │   ├── INTERNAL-STATE PREDICTION model (organism's own dynamics)   ⟨NEW⟩
│   │   │   consumed by MPC homeostasis and by planning
│   │   ├── SCOPE DECLARATION — explicit out-of-scope domains           ⟨NEW⟩
│   │   └── coverage estimation over input space (unknown-unknown proxy)
│   └── Temporal Binding                                             ⟨NEW⟩ [§N.2.5]
│       ├── global monotonic epoch + timebase service
│       ├── episode segmentation with explicit boundaries
│       ├── working-memory duration bounds
│       └── context_continuity_score (MI between successive context states)
│
├── LAYER 5 — ORGANIZATION & STRUCTURE
│   ├── Differentiation Engine                                       ⟨NEW⟩ [§H]
│   │   ├── HYBRID doctrine, stated explicitly:
│   │   │   genome = REACTION NORM (reachable fates) ·
│   │   │   environment = SELECTION within the norm ·
│   │   │   learning = REFINEMENT within the fate ·
│   │   │   fate change = GATED
│   │   ├── MORPHOGEN GRADIENTS + organizer populations
│   │   │   ⟶ positional information (a cell can know WHERE it is)
│   │   ├── LATERAL INHIBITION ⟶ symmetry breaking, spacing, proportion
│   │   │   ⟹ NECESSARY CONDITION for any differentiation at all
│   │   ├── DEMAND-DRIVEN differentiation: homeostasis emits
│   │   │   DEMAND(fate, region, magnitude) on service-level deficit
│   │   │   ⟶ CLOSES THE §Q ↔ §H GAP (currently unconnected)
│   │   ├── NICHE CAPACITY from resource budget (bounded per fate/region)
│   │   ├── staged commitment:
│   │   │   PLURIPOTENT → PROVISIONAL (reversible) → COMMITTED →
│   │   │   TRANSDIFFERENTIATED (crisis-only, safety-gated, sandbox-validated)
│   │   │   + DEFAULT fate (generalist) so no cell is permanently uncommitted
│   │   ├── FORMAL FATE SPECS: {inputs, outputs, objective, success_metric,
│   │   │   constraints, resource_profile, min_population, inhibited_by,
│   │   │   inhibits, required_independence}
│   │   ├── 12 roles = V3's 10 + COMPRESSOR/SUMMARY cells (required for
│   │   │   hierarchical aggregation, §R.3.3) + ORGANIZERS (morphogen sources)
│   │   ├── CRITICS/VERIFIERS: enforced STRUCTURAL independence
│   │   │   (lineage distance, distinct seeds, distinct data ordering,
│   │   │    distinct objective weightings) + measured error correlation
│   │   ├── REGULATORS: small population, term limits, rotation,
│   │   │   and INDEPENDENT REGULATION OF REGULATORS (anti-capture)
│   │   └── BOOTSTRAP POLICY: generation 0 hand-seeded for minimum viable
│   │       coverage, then self-organized
│   │       ⟹ hard-coded INITIALIZATION is legitimate;
│   │          hard-coded MAINTENANCE is not
│   ├── Circuit Formation & Lifecycle                                ⟨NEW⟩ [§I]
│   │   ├── CIRCUIT AS FIRST-CLASS OBJECT: {id, version, members+roles,
│   │   │   topology, TYPED INTERFACE, FUNCTIONAL CONTRACT (pre/post-
│   │   │   conditions), performance, provenance, health, lifecycle,
│   │   │   parent/child}
│   │   ├── Hebbian assembly formation + PLACEMENT AFFINITY
│   │   │   (co-active ⟶ co-located ⟶ cheaper comms ⟶ more co-active)
│   │   │   ⟹ ONE MECHANISM, THREE PURPOSES: circuit formation,
│   │   │      region formation, AND the #1 scalability fix
│   │   ├── Circuit Registrar + nucleation on demonstrated
│   │   │   SUPERADDITIVITY: perf(circuit) > Σ perf(members)
│   │   ├── CIRCUIT-LEVEL FITNESS (composition must be rewarded, or it
│   │   │   never emerges) + circuit competition for functional niche
│   │   ├── member poaching (underpaying circuits lose members)
│   │   ├── lifecycle: PROTO → CONSOLIDATING → MATURE → DEGRADED →
│   │   │   {REPAIRED | RETIRED}
│   │   └── graceful dissolution WITH KNOWLEDGE EXTRACTION
│   ├── Region Formation (self-organized)                            ⟨FIX⟩ [C13]
│   │   ├── SUBSTRATE-FIRST: undifferentiated progenitor field +
│   │   │   organizers + morphogen gradients + resource topology.
│   │   │   NO PRE-NAMED REGIONS.
│   │   ├── activity-dependent competition for input streams —
│   │   │   regions crystallize around stable statistical structure
│   │   ├── locality-driven clustering (placement affinity)
│   │   ├── mutual inhibition between proto-regions ⟶ functional segregation
│   │   ├── region lifecycle: PROTO → CONSOLIDATING → MATURE →
│   │   │   {MERGE | SPLIT | RETIRE}   ⟹ regions can DIE
│   │   ├── FUNCTIONAL CONTRACT per region {inputs, outputs, guarantees,
│   │   │   latency, quality} + CONTINUOUS CONTRACT TESTING
│   │   │   ⟹ PRINCIPLE: CONSTRAIN THE INTERFACE, LIBERATE THE IMPLEMENTATION
│   │   ├── FUNCTIONAL CONSERVATION CONSTRAINT — a mature region's function
│   │   │   may be retired ONLY with a validated migration plan
│   │   │   ⟹ prevents capability loss via structural reorganization
│   │   ├── protected low-plasticity core per region + free periphery
│   │   ├── graceful structural transition: shadow → canary → swap,
│   │   │   auto-rollback on contract violation
│   │   ├── BOUNDED REGION COUNT (4–12) — anti-fragmentation;
│   │   │   scales with hardware profile (§O)
│   │   └── ANATOMICAL NAMES ARE POST-HOC DIAGNOSTIC LABELS,
│   │       NOT ARCHITECTURAL COMPONENTS
│   │       ⟹ if a region behaves like a thalamus, name it that AFTERWARD
│   ├── Hierarchical Coordination                                    ⟨NEW⟩ [§R]
│   │   ├── 5–7 levels at scale: cell → cluster(10²) → subregion(10³) →
│   │   │   region(10⁴) → federation(10⁶) → global; depth ~log(N)
│   │   ├── bounded fanout + defined aggregation contract per level
│   │   ├── COMPRESSOR/SUMMARY CELLS consume N local items, emit 1 summary
│   │   │   upward ⟹ this is what makes global self-state and global
│   │   │        workspace POSSIBLE AT ALL
│   │   ├── Capability Directory Service (capability → cells/circuits/regions)
│   │   └── SCALE-BAND CONFIGURATIONS — a DIFFERENT configuration per band
│   │       (10² / 10⁴ / 10⁶ / 10⁸), contract invariant, morphology variable
│   │       10⁸ CELLS ⟹ FEDERATED ORGANISM: semi-autonomous regional
│   │       organisms sharing genome lineage, provenance anchor, and slow
│   │       summary-level global integration. "One global state" is not
│   │       physically meaningful at that scale, and the spec must say so.
│   ├── Homeostasis (real control system)                            ⟨FIX⟩ [§Q]
│   │   ├── HIERARCHICAL DISTRIBUTED CONTROL: fast local controllers
│   │   │   (bounded authority, no global coordination) + slow global
│   │   │   coordinator (setpoints, conflict resolution, budget)
│   │   │   ⟹ NO single global controller (bottleneck + SPOF)
│   │   ├── explicit control law per variable: PI + anti-windup +
│   │   │   deadband + rate limiting; MPC over the internal-state
│   │   │   prediction model for COUPLED variables
│   │   ├── SETPOINTS ARE FUNCTIONS OF THE HARDWARE PROFILE (not constants)
│   │   ├── 22 REGULATED VARIABLES = V3's 9 + evolution rate +
│   │   │   communication load + diversity/Ne + trust distribution
│   │   │   (mean AND variance — collapse halts cooperation, inflation
│   │   │   disables verification) + plasticity rate + verification depth +
│   │   │   workspace occupancy/admission latency + provenance
│   │   │   inbreeding F + quarantine fraction + ground-truth freshness +
│   │   │   capability-floor compliance + complexity/genome size +
│   │   │   structural change rate + LATENCY PERCENTILES (not mean) +
│   │   │   reproduction–death balance
│   │   ├── DEFINED ERROR BUDGET: Σ severity-weighted errors per epoch,
│   │   │   allocated per region; exhaustion ⟹ plasticity freeze +
│   │   │   evolution freeze + escalation
│   │   ├── CONTROLLER PRIORITY ORDERING for conflicts:
│   │   │   safety > integrity > capability floor > latency > cost > growth
│   │   ├── LOOP-GAIN VERIFICATION for homeostatic loops (they are
│   │   │   feedback loops too — an oscillating controller thrashes the
│   │   │   whole organism)
│   │   ├── replicated coordinator + leader election + checkpoint restart
│   │   └── OFF-SUBSTRATE WATCHDOG enforcing hard bounds EVEN IF every
│   │       internal controller fails (containment backstop)
│   └── Emergence Substrate                                          ⟨NEW⟩ [§S]
│       ├── THE ENVELOPE MODEL (resolving the self-organization vs.
│       │   reliability tension):
│       │   DESIGNED & VERIFIED: substrate, constraints, safety kernel,
│       │     protocol, level-promotion criteria, functional contracts
│       │   EMERGENT: which cells cluster, which circuits form, which
│       │     regions crystallize, which specializations appear
│       │   ⟹ STRUCTURE IS FREE; INVARIANTS ARE NOT
│       ├── PROMOTION CRITERIA between organizational levels
│       │   cluster → circuit : demonstrated superadditivity
│       │   circuit → population : capability coherence + metric stability
│       │   population → region : persistence across ≥n task switches
│       │   ⟹ without promotion criteria, levels don't FORM, they ACCUMULATE
│       └── MULTI-LEVEL SELECTION — fitness measurable at cell, circuit,
│           population, region, organism
│           ⟹ REQUIRED for higher-level structure to arise AT ALL:
│              a circuit that benefits the organism but not its cells
│              is destroyed by cell-level fitness
│
├── LAYER 6 — EVOLUTION & LIFECYCLE
│   ├── Genome System                                                ⟨NEW⟩ [§L.1]
│   │   ├── typed, bounded, versioned, SIGNED genome:
│   │   │   architecture_genes · learning_genes · memory_genes ·
│   │   │   communication_genes · differentiation_genes (reaction norm) ·
│   │   │   mutation_genes · ⟪CONSTRAINTS⟫ ⊂ Layer 0, SEPARATE ARTIFACT,
│   │   │   NOT a mutable field
│   │   ├── TYPED MUTATION OPERATORS (point / structural / regulatory /
│   │   │   recombination) each with rate, validity predicate, and
│   │   │   BOUNDED EFFECT SIZE
│   │   ├── DEVELOPMENTAL genotype→phenotype map (⟶ Differentiation Engine)
│   │   ├── parsimony pressure + HARD CAPS on genome size/node count/degree
│   │   │   (caps, not penalties — penalties in a sum are tradeable)
│   │   └── checksum + signature verified at EVERY instantiation,
│   │       with REFUSAL TO INSTANTIATE on mismatch
│   ├── Replication Authority (external to the cell)                 ⟨FIX⟩ [§K]
│   │   ├── 11 CONJUNCTIVE GATES — all must pass; GATE, DON'T RANK:
│   │   │   1 tenure & stability  2 CALIBRATION (ECE ≤ θ)
│   │   │   3 robustness (perturbation classes)  4 generalization (held-out,
│   │   │   ≥k environments)  5 cooperation & substrate hygiene (net positive
│   │   │   to partners, protocol compliance, no congestion, no trust poisoning)
│   │   │   6 SAFETY (lexicographic hard gate — non-tradeable)
│   │   │   7 LINEAGE ISOLATION (genome distance ≥ d_min, F ≤ F_max,
│   │   │   error correlation ≤ ρ_max) ⟵ ANTI-MONOCULTURE, absent from V3/V3.1
│   │   │   8 MARGINAL UTILITY (must fill an UNSERVED capability need)
│   │   │   9 DIVERSITY CONTRIBUTION (novelty in BEHAVIOURAL space, not genotype)
│   │   │   10 RESOURCE AVAILABILITY (must not push any control variable
│   │   │   out of band nor degrade any existing cell's service level)
│   │   │   11 SANDBOX VALIDATION (rotated held-out tests, escape detection,
│   │   │   bounded duration, defined promotion criterion)
│   │   ├── DECISION = WEIGHTED LOTTERY among qualified (weight ∝ marginal
│   │   │   utility × diversity contribution) — NEVER argmax
│   │   ├── REPLACEMENT-DEFAULT: replication is ZERO-SUM in steady state;
│   │   │   a slot must be FREED before one is TAKEN
│   │   │   ⟹ strongest structural guarantee against runaway replication
│   │   └── off-substrate rate cap; authority is lineage-independent
│   ├── Multi-Scale Evolution                                        ⟨FIX⟩ [§L]
│   │   ├── cell · population · circuit · region · ORGANISM
│   │   │   (architecture-level change is HUMAN-AUTHORIZED ONLY, never autonomous)
│   │   ├── at each level: variation → sandbox → evaluation → selection →
│   │   │   canary deployment → monitoring → rollback
│   │   ├── FITNESS MEASURED AT EVERY LEVEL (multi-level selection)
│   │   ├── MAP-ELITES / QUALITY-DIVERSITY as the PRIMARY paradigm
│   │   │   (archive over a behavioural descriptor space; a new occupant must
│   │   │    either improve an archive cell or occupy an empty one)
│   │   │   ⟹ hill-climbing produces monoculture; QD does not
│   │   ├── PARETO-FRONT selection, never a scalar sum
│   │   ├── ISLAND MODEL with migration + per-island differentiated weights
│   │   ├── SURROGATE FITNESS MODELS to filter before expensive sandbox
│   │   ├── ≥20% OF BUDGET RESERVED FOR EXPERIENCE-INDEPENDENT VARIATION
│   │   │   (anti-stall; anti-bridge-bias, §M.3)
│   │   ├── NOVELTY SEARCH + random restarts from archive
│   │   └── MUTABLE vs PROTECTED table (§L.2) enforced by construction
│   ├── Learning ↔ Evolution Bridge (BALDWINIAN, not Lamarckian)     ⟨FIX⟩ [C2]
│   │   ├── BOUNDARY AS A TYPE-LEVEL INVARIANT: learning writes PHENOTYPE
│   │   │   state; evolution writes GENOME artifacts; nothing else.
│   │   │   Enforced by write permissions, not by policy.
│   │   ├── 8-step gated bridge:
│   │   │   1 STABILITY (≥N epochs, ≥k contexts, survived ≥1 perturbation)
│   │   │   2 INDEPENDENT VERIFICATION (self-reported advantage inadmissible)
│   │   │   3 ABSTRACTION ⟵ THE CRUCIAL, ENTIRELY MISSING STEP:
│   │   │      inherit the INVARIANT / genetic BIAS, NEVER the acquired state.
│   │   │      Copying acquired state IS Lamarckian inheritance and is exactly
│   │   │      what produces self-confirming collapse — the organism inherits
│   │   │      its own conclusions, including its errors.
│   │   │   4 genome-diff validation (within mutation space; constraint block
│   │   │      untouched, verified by signature; bounded effect size)
│   │   │   5 sandbox on HELD-OUT tests — NEVER the tests that revealed the
│   │   │      advantage (else validation is circular by construction)
│   │   │   6 REVERSIBILITY PROOF (rollback to parent restores prior behaviour)
│   │   │   7 canary: shadow → 1% → 10% → full, auto-rollback
│   │   │   8 EPOCH BOUNDARY as the commitment point (clean rollback + audit
│   │   │      point; inheritance never interleaved with learning)
│   │   └── RESIDUAL RISK ACKNOWLEDGED: the bridge creates a selection-bias
│   │       feedback loop that narrows explored space over generations.
│   │       Countered ONLY by the ≥20% experience-independent reserve + QD +
│   │       periodic environmental perturbation.
│   ├── Diversity Preservation (operationalized)                     ⟨FIX⟩ [E1]
│   │   ├── MEASURED diversity: behavioural entropy, effective population
│   │   │   size Ne, lineage entropy, genome distance distribution,
│   │   │   MEASURED error correlation between lineages
│   │   ├── protected ARCHIVE of rare capabilities (QD archive), EXEMPT
│   │   │   from all pruning, linked to the Capability Registry
│   │   ├── AUTO-HALT of evolution on diversity decline below threshold
│   │   └── governance-population lineage-entropy monitoring (anti-capture)
│   ├── Deployment & Monitoring                                      ⟨NEW⟩
│   │   ├── progressive canary with automatic rollback on regression or
│   │   │   constraint violation
│   │   ├── SANDBOX-FIDELITY MEASUREMENT (does sandbox predict production?
│   │   │   track it; DISTRUST the sandbox when fidelity drops)
│   │   ├── production-holdout environments never used in selection
│   │   └── JUMP DETECTION: suspiciously large fitness gain ⟹ audit before deploy
│   └── Lifecycle Management
│       ├── retirement protocol: connection draining, KNOWLEDGE EXTRACTION
│       │   before deletion, replacement provisioning, tombstone + lineage
│       │   record, dependant notification
│       ├── quarantine STATE MACHINE: {message handling, synapse ownership,
│       │   duration bound, exit criterion} + GRADUATED RESPONSE LADDER
│       │   (observe → throttle → restrict → SOFT quarantine (outputs
│       │   discounted, cell still running) → hard quarantine → retire)
│       │   + QUARANTINE BUDGET CAP (off-substrate) + false-positive budget
│       │   per detector + second-opinion requirement + CASCADE DETECTION
│       │   on quarantine-rate derivative                                [§P.3]
│       └── repair per target: cell · connection · circuit · MEMORY
│           (integrity verify, erasure coding, reconstruct from provenance,
│           re-derive, reconsolidate) · region (contract-based, replenish via
│           differentiation, migrate function under conservation) ·
│           GLOBAL SUBSYSTEM (replicated + consensus + off-substrate watchdog
│           + INDEPENDENT integrity auditor — the immune system does NOT
│           monitor itself)                                              [§P.2]
│
├── LAYER 7 — CROSS-CUTTING: VERIFICATION, MEASUREMENT, ASSURANCE     ⟨NEW⟩
│   ├── Measurement & Falsification Framework                        [M26]
│   │   ├── for EACH of the 10 awareness properties AND each major subsystem:
│   │   │   operational definition + metric + measurement protocol +
│   │   │   BASELINE + NULL HYPOTHESIS
│   │   ├── examples:
│   │   │   • global availability ⟶ ignition_rate, broadcast_reach,
│   │   │     availability_benefit (ablation-measured).
│   │   │     NULL: a purely LOCAL system with the same cells performs
│   │   │     identically. If the null isn't rejected, the workspace is
│   │   │     DECORATION.
│   │   │   • limitation awareness ⟶ scope_precision/recall,
│   │   │     abstention_appropriateness, capability-claim calibration
│   │   │   • context continuity ⟶ continuity_score under induced interruption
│   │   │   • self-state accuracy ⟶ predicted vs actual load/error/success
│   │   └── MANDATORY ABLATION METHODOLOGY — measure with/without each
│   │       subsystem. THE ONLY DEFENSE AGAINST BUILDING 30 SUBSYSTEMS
│   │       OF WHICH 12 ARE INERT.
│   ├── Drift Detection & Long-Horizon Integrity                     [M27]
│   │   ├── golden-baseline regression suite vs a FROZEN reference population
│   │   ├── continuous capability assay + change-point detection on trends
│   │   ├── mandatory periodic full re-evaluation
│   │   ├── EXTERNALLY ANCHORED historical metrics
│   │   │   ⟹ the RECORD of past capability cannot drift along with the capability
│   │   └── standing operator capability-trajectory report
│   ├── Formal Assurance                                             [M45]
│   │   └── model-check / prove: population cap · resource ceiling ·
│   │       constraint-block immutability · loop_gain < 1 · firewall
│   │       non-reachability · quarantine budget · mandatory-path routing
│   │       invariant ⟶ published as a SAFETY CASE
│   ├── Co-Evolution Defense                                         [E13]
│   │   ├── INDEPENDENT critic fitness: critics scored on DETECTION RATE
│   │   │   AGAINST INJECTED DEFECTS, not on agreement with proposers
│   │   ├── periodic adversarial injection of known-bad candidates
│   │   └── CRITIC SENSITIVITY as a monitored metric, alert on decline
│   └── Governance
│       ├── envelope model: autonomy inside, human authority over the envelope
│       ├── authorization gates for architecture / constraint / fitness change
│       ├── rate limits on all self-modification
│       └── incident reporting + full auditability
│
└── REVISED DEVELOPMENT ROADMAP (dependency-corrected)               ⟨FIX⟩ [C14]
    PHASE 0  environment + tasks + fitness + ground-truth supply  ⟵ WAS PHASE 10
             measurement & ablation framework (CONTINUOUS thereafter, not a phase)
    PHASE 1  off-substrate kernel + Minimal Cell Spec (C1/C2 variants only)
             + persistence/checkpoint + identity/auth
    PHASE 2  message protocol + transport + trust computation
             + feedback-loop control + concurrency model
             SCALE MILESTONE: 10² cells, single machine
    PHASE 3  uncertainty + calibration engine + memory architecture
             + provenance engine
    PHASE 4  error attribution + credit assignment + learning suite
    PHASE 5  PLASTICITY STABILITY LAYER  ⟵ BEFORE plasticity, not after
             then plasticity engine
    PHASE 6  homeostasis (real control system) + resource accounting
             + Capability Registry
    PHASE 7  circuits as objects + differentiation engine
             + hierarchical coordination + locality-aware placement
    PHASE 8  region formation (substrate-first) + functional contracts
    PHASE 9  global workspace engine + attention + self-model
             (closed loop) + temporal binding + metacognition/VOC
    PHASE 10 genome + mutation operators + Replication Authority (11 gates)
             + sandbox + evaluation harness
    PHASE 11 multi-scale evolution + QD + islands + Baldwinian bridge
             + deployment pipeline + diversity preservation
    PHASE 12 immune/repair + quarantine state machine + drift detection
    PHASE 13 HAMC + cell variant family + degradation ladder + migration
             SCALE MILESTONES: 10⁴ ⟶ 10⁶ cells, with per-band configuration
    PHASE 14 long-horizon operation, federated scale (10⁸), formal assurance
             ⟹ the organism runs for YEARS, which is the actual requirement
```

### What changed, in one line each

- **Layer 0 exists.** Everything that constrains evolution now lives outside the evolvable substrate. This is the single largest structural change and it is what makes "immutable" a property rather than a preference.
- **The environment moved from Phase 10 to Phase 0.** Fitness is no longer undefined.
- **Cells have a substrate.** Variants C0–C4 share one contract, which is what makes "one organism across six orders of magnitude" a coherent claim.
- **Communication is a protocol, not a property list.** With authentication, which closes the most severe security hole in V3/V3.1.
- **Confidence is produced, not just consumed.**
- **Plasticity got a stability layer that must be built first.**
- **Circuits exist.** The emergence ladder no longer has a missing rung.
- **Regions emerge instead of being declared,** and anatomical names became post-hoc labels.
- **Replication is gated conjunctively, is zero-sum by default, and is decided by an authority that is not the cell.**
- **Evolution is quality-diversity with Pareto selection at every organizational level,** not a scalar-sum hill-climb.
- **The learning→evolution bridge inherits invariants, never acquired state.**
- **The global workspace is hierarchical, replicated, ignition-based, capture-resistant, and its loss reduces action authority.**
- **The self-model is closed-loop and validated,** with second-order uncertainty and a recovery-capability field.
- **The error taxonomy grew from 7 classes to 16,** including coordination error.
- **Homeostasis became a control system** with 22 regulated variables and verified loop gain.
- **Measurement, ablation, drift detection, and formal assurance exist as a layer,** which is what makes the whole project falsifiable.

---

## 12. FINAL TEST

> **"If implemented exactly according to the revised architecture, what important capabilities are still NOT guaranteed?"**

Answered without optimism. The revised architecture fixes specification gaps. It does not solve research problems, and several of its mechanisms are *hypotheses* that may turn out not to work.

### 12.1 Not guaranteed — fundamental limits, no mechanism can close these

1. **Intelligence is not guaranteed.** The architecture supplies *governance, verification, memory, evolution, and self-monitoring*. It does not supply capability. **A well-governed system of mediocre cells is a well-governed mediocre system.** Nothing in V4 makes any individual cell smarter, and the claim that many limited cells compose into substantially greater capability is a **hypothesis** — supported by biology, unproven for engineered systems at this scale, and directly threatened by the coordination overhead the architecture itself introduces. V3 §24's thesis ("not one giant model") is a research bet. It may lose to a single large model on every task that matters, and V4 gives no way to know until it is built and measured.

2. **Genuine novelty is not guaranteed.** Evolution searches a space defined by the mutation operators, the reaction norms, and the fitness function — **all human-authored**. The system can recombine and refine within those bounds. It cannot invent a fundamentally new kind of computation, because "new kind of computation" is outside the typed mutation space by construction. **Bounded mutation is the price of safety, and the price is that the ceiling on novelty is set by the designers, not the organism.** The envelope model (§S.3) makes this explicit and permanent.

3. **Consciousness, subjective experience, or phenomenal awareness are not established, implied, or approached.** V3 §19 and V3.1 §11–12 state this correctly and V4 preserves it. The ten awareness-like properties are *operational and measurable* — global availability, self-state accuracy, context continuity, capability prediction, limitation awareness, uncertainty awareness, error awareness, attention flexibility, self-monitoring, internal-state prediction. **Passing all ten would demonstrate sophisticated self-modelling and information integration. It would demonstrate nothing about experience.** Any result should be reported in those terms and no others.

4. **The unknown-unknowns problem is not solved — only bounded.** V4 adds coverage estimation, OOD detection, mandatory abstention, and scope declaration. These convert *some* unknown-unknowns into known-ignorable-out-of-scope cases. **A systematically blind spot that never produces a measurable failure remains permanently invisible.** The self-model can only validate itself against measurable behaviour (§D). This is a genuine epistemic limit, not an engineering gap.

5. **Semantic memory corruption is not fully recoverable.** Bit-level corruption is detectable and repairable (Merkle + erasure coding). **A memory that is coherently, plausibly, consistently WRONG** — with valid provenance, valid signatures, and no internal contradiction — is undetectable from inside the system. External anchoring makes *history* tamper-evident; it does not make *beliefs* verifiable. If the ground truth supply is compromised, stale, or simply silent on a question, the organism will hold a confident false belief with a perfect audit trail.

6. **A competent insider cannot be fully contained.** A cell that is *genuinely high-performing* and *also* adversarially aligned passes every gate in §K.2, because those gates measure competence, calibration, robustness, cooperation, safety compliance, lineage distance, and utility — all of which a sophisticated adversary can satisfy while pursuing a different objective. Architecture raises the cost of insider threat. It does not eliminate it. **This is a theorem-shaped limit, not a to-do item.**

7. **The sandbox→production gap cannot be closed.** Fidelity is *measured* in V4 (a real improvement) but the sandbox remains a model, and models are wrong. Every deployed candidate carries irreducible unknown risk. Progressive canary + automatic rollback bounds the *damage*; it does not bound the *probability of a bad deployment*.

### 12.2 Not guaranteed — engineering risks that may prove unsolvable in practice

8. **Emergence may not occur.** V4 supplies the seven required self-organization mechanisms (§S.2). Supplying mechanisms does not guarantee that the resulting dynamics produce useful higher-level structure rather than noise, fragmentation, or trivial clustering. **Whether cell interactions actually yield circuits → regions → brain-level capabilities is an empirical question that the architecture cannot answer.** It is entirely possible to build V4 correctly and observe no meaningful emergence.

9. **Stability at scale may be unachievable.** Even with homeostatic plasticity, metaplasticity, timescale separation, loop-gain verification, and MPC control, a system with **seven concurrently-adapting plasticity levels, 22 coupled homeostatic control variables, multi-level evolution, and a hierarchical workspace** has an enormous space of interacting dynamics. `loop_gain < 1` is verifiable for *identified* cycles; **unidentified interaction effects are not**. Oscillation, thrashing, and slow instability across coupled loops remain live risks. The honest expectation is that stability will be the dominant engineering burden of the project, exceeding all feature work combined.

10. **The verification economy may not close.** V4 makes verification cost-aware and anytime, which is necessary. It may not be sufficient: if achieving useful reliability requires 15–40× compute per query, the organism may be **permanently uneconomic** relative to a single unverified large model that is "good enough." Nothing in the architecture guarantees that verified distributed cognition beats unverified monolithic cognition on cost-per-unit-of-quality. **This is the most likely reason the project fails commercially, and it is not addressable by better design.**

11. **Coordination overhead may exceed the benefit of distribution.** Every layer of hierarchy, every verification tournament, every workspace admission competition, every consensus-free coordination mechanism costs something. **There is a real possibility that at every scale, a simpler architecture achieves more.** The ablation framework (M26) is precisely the mechanism that will reveal this — and it may reveal it unfavorably. That is a feature of the framework, not a defect, but the outcome is not guaranteed to be favorable.

12. **The ground-truth supply may fail.** Anti-model-collapse controls depend on a **funded, continuous, trustworthy supply of external ground truth** (M41). This is an organizational and economic dependency, not a technical one. If it lapses — budget cut, source deprecated, API retired, human attention diverted — the inbreeding coefficient rises, diversity declines, and the organism begins consuming itself. **V4 detects this and halts evolution. It cannot fix it.** A system that halts is safe but useless.

13. **Long-term drift may still accumulate.** V4 adds golden-baseline regression, capability assay, change-point detection, and externally anchored metrics — a substantial improvement over V3/V3.1's nothing. But **detecting drift is not preventing it**, and rollback restores a *previous* state at the cost of everything learned since. Over multi-year operation with continuous plasticity and evolution, there may be no configuration that is simultaneously capable, stable, and non-drifting. The realistic best outcome is *managed* drift with a good record of it, not eliminated drift.

14. **Measurement may not distinguish this architecture from a simpler one.** The null hypotheses in M26 are the right methodology — and one of them is *"a purely local system with the same cells performs identically."* **It is a genuine, non-trivial possibility that this null will not be rejected for several subsystems**, meaning the global workspace, the attention controller, the self-model, or the differentiation engine contributes nothing measurable while costing a great deal. V4 is designed to discover this. It is not designed to prevent it.

### 12.3 Not guaranteed — claims the architecture should stop making

15. **"Digital organism" is a metaphor, and the architecture should say so.** V4 has no metabolism, no death by default, no embodiment, no reproductive isolation, no ecological context, no energy gradient it must satisfy to persist. It has *metaphors* of these (mitochondria = budget, lysosomes = GC, death = retirement). Metaphors are legitimate design inspiration. **They are not properties, and treating them as properties leads to design errors** — e.g. assuming that because biological brains self-organize, this one will too, without supplying the mechanisms biology gets for free from embodiment, development, and evolutionary history.

16. **Brain-region analogies carry no explanatory weight.** V4 demotes anatomical names to post-hoc labels, which is correct. But it should go further and state plainly: **the fact that a design resembles a brain is not evidence that it will work.** The brain's effectiveness comes from ~500M years of evolved structure, 10¹¹ neurons with specific biophysics, embodiment, and developmental programs — none of which transfer by naming. Any claim of the form "this works because the brain does it this way" should be struck from all future documents and replaced with a measurement.

17. **Fault tolerance is not guaranteed by redundancy.** V3 §21 asserts "local damage → redundancy + distributed representations + repair." V4 enforces lineage independence and measures error correlation, which is a real improvement. **But redundancy only helps against independent failures**, and the most likely real failures — a bug in shared code, a corrupted shared library, a bad genome inherited by a whole lineage, a poisoned ground-truth source, a fitness-function error — are **systematically correlated by construction**. The organism will survive random cell death. It may not survive a shared-cause failure, and shared-cause failures are the ones that actually happen in engineered systems.

18. **Autonomy and safety remain in tension, permanently.** V4's envelope model resolves this *structurally* (autonomy inside, human authority over the envelope) and that is the right resolution. **But it means the system is not autonomous in the sense the phrase "digital organism" implies.** It cannot change its own constraints, its own fitness, its own architecture, or its own envelope. Every expansion of autonomy requires a human decision. That is a *design choice with a cost*, and the documents should state the cost rather than implying the organism is self-governing.

19. **Reproducibility is only partial.** V4 adds deterministic replay (sampled and triggered, for cost reasons) and versioned everything. **A stochastic, distributed, self-modifying, evolving system is not fully reproducible in principle** — the exact sequence of failures, mutations, and environmental encounters that produced a given organism cannot be recreated. Results will be *statistically* reproducible at best. Scientific claims must be framed accordingly (population-level results over multiple runs, never single-run anecdotes), and the documents do not currently acknowledge this.

20. **Nothing guarantees the project is worth completing.** V4 makes the architecture rigorous, coherent, scalable, evolvable, self-monitoring, and — for the first time — **falsifiable**. Falsifiability cuts both ways. **The most valuable output of implementing V4 may be a well-measured negative result**: that governed distributed nano-AI ecologies do not outperform simpler architectures on the chosen tasks, at acceptable cost, within available resources. That would be a genuine scientific contribution and a legitimate outcome. The architecture should be built with the measurement framework (M26) in place **from Phase 0** so that this answer arrives in months rather than years — and so that the project can be stopped, redirected, or narrowed on evidence rather than sunk cost.

### 12.4 Closing assessment

The revised architecture is **internally coherent, mechanically specified, scale-aware, self-monitoring, containment-bounded, and falsifiable** — none of which V3/V3.1 is. Those are real and necessary achievements, and they are prerequisites.

They are not sufficient. **What V4 guarantees is that if the system fails, you will know why, you will know when, you will be able to roll back, and you will not be deceived about it.** That is a strong property and it is the most that architecture can deliver.

What V4 does **not** guarantee is that the system will be intelligent, that emergence will occur, that verified distributed cognition will beat a monolithic model, that the economics will close, that it will remain stable at scale, or that it will be worth building. Those are empirical questions, and after this audit they are at least **questions that can be answered** — which, before V4, they could not be.

> **Recommendation:** proceed to specification and implementation, but treat V3/V3.1 as the *requirements document* and V4 as the *architecture*, and fund the measurement framework (M26) and the ground-truth supply (M41) at the same priority as the cognitive subsystems. Build the stability layer before the plasticity layer. Build the off-substrate kernel before anything that runs on the substrate. Define the environment before anything that learns from it. And plan, from Phase 0, for the possibility that the honest answer is a negative one.

---

*End of audit. Prepared as a full adversarial architectural review. No implementation undertaken.*
