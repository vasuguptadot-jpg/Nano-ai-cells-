# P0-06 — DIFFERENTIATION, DEVELOPMENT & SELF-ORGANIZATION
## Volume A — Foundations, Definitions, and the Root Circularity (§0–§20)

**Status:** ANALYSIS · adversarial · architecture-only
**Depends on:** P0-01 (task/fitness), P0-02 (EIK), P0-03 (comm), P0-04 (memory), P0-05 (learning), Cell Contract v1.0 (+ Annexes A/B), V3, V3.1
**Feeds:** Vol B (`48_analysis_regions_identity.md`, §21–§40)

> **ABSOLUTE RULE, RESTATED.** Nothing in this volume is an implementation. There is no code, no executable
> developmental system, no simulation, no training run, no deployment, no infrastructure. What follows is a
> formal architecture: definitions, schemas, state machines, dependency graphs, authority tables, and
> pseudocode-shaped specifications. Where a number would be needed and none is inherited, the parameter is
> **registered with a class and no value** (§90, Vol E). Where a problem cannot be closed, it is marked
> **UNRESOLVED** or **UNCLOSABLE** rather than dissolved by a constant.

---

# §0 — MANDATE, INPUTS, METHOD

## 0.1 The question this contract exists to answer

An architecture that begins with a **sparse, generic, undifferentiated population** and is required to end with
**stable specialization, functional circuits, and identifiable regions** — without the topology being written by
hand — needs a set of constraints that is neither (a) a hard-coded anatomy nor (b) uncontrolled emergence.
§1 states that question precisely. Everything else in these six volumes is either an attack on a candidate answer
or a constraint that survives the attack.

## 0.2 Traceability — which inherited subsystem this contract *is*

The Cell Contract's own dependency ledger (§30) defers the developmental machinery to named subsystems and marks
two of them as unfinished. This contract is their completion. **The mapping is recorded here to prevent the
identifier collisions that occurred between P0-04 and P0-05 (the `R47.1` collision).**

| Cell Contract §30 ID | Subsystem | Status there | Owned here |
|---|---|---|---|
| **P0-14** | **Differentiation engine** — `dev_stage`, `fate_bias`, `morphogen_readings`, `reaction_norm`, `RoleCode`, §15.2 dynamics | **BLOCKED on Cell Contract; engine itself never written** | **YES — §11–§19, Vol B, Vol E** |
| **P0-28** | **Region formation** — `morphogen_receptors`, `region_id`, locality hints, connection handshake | **"Partial"** | **YES — §21–§30, Vol B** |
| **P0-29** | Hierarchical coordination — `COMPRESSOR`/`ORGANIZER`, `AGGREGATE_SUMMARY`, fanout caps | Depends on Cell §15.3 | **Partly — §19, §48** |
| **P0-15** | Capability Registry — `role`, `capability_critical`, dormancy | Depends on Cell §17.1 | **Interface only — §81** |
| **P0-13** | Circuits as objects — port schemas, connection records, `mandatory_path` | Depends on Cell §14.1 | **Interface only — §21, §81** |
| **P1-14** | Repair — lifecycle `REPAIRING`/`DORMANT`, checkpoint/restore, **re-develop-from-genome** | Depends on Cell Annex B | **Contested — §8.3, §64, §79** |

> ### **DEV-R0.1 — IDENTITY OF THIS CONTRACT.**
> P0-06 is the **differentiation engine (P0-14)** plus **region formation (P0-28)**. It is *not* a new subsystem
> layered on top of them. Every mechanism specified here must therefore be expressible in the Cell Contract's
> existing vocabulary (`dev_stage`, `fate_bias`, `reaction_norm`, `niche_slot`, `region_id`, `morphogen_readings`)
> or be flagged as a **PROPOSED AMENDMENT** to it. **No silently new cell-level fields.**

> ### **DEV-R0.2 — THE LIFECYCLE MACHINE IS CLOSED AND MAY NOT BE EXTENDED HERE.**
> Cell Annex B **P4**: *"The state set is closed (18) and the transition set is closed (41). An implementation MUST
> NOT add states or transitions."* ⟹ **P0-06 may not add a lifecycle state or transition.** All developmental
> machinery must live in (i) the separate `dev_stage` machine (`DevStage`, 4 values), (ii) region/circuit-level
> objects, or (iii) a proposed amendment. This is a hard design constraint on everything that follows, and it is
> the reason §88 specifies a **`dev_stage` machine of its own** rather than extending Annex B.

## 0.3 Reference convention

Inherited identifiers are cited **with their source contract**, never bare: `Cell I-23`, `Cell §15.2`,
`P0-05 R46.1`, `P0-05 LEARN-INV-30`, `P0-03 COMM-INV-08`, `P0-04 MEM-INV-50`, `P0-02 R0.1`. Identifiers
minted here are prefixed: **DEV-R**n.m** (rule), **D-D**nn** (finding), **X-D**n** (cross-contract
contradiction), **DEV-INV-**nn** (invariant, §87), **DEV-A**nn** (attack, §86), **OR-D**n** (open research),
**Σ**n** (scope-constitution operation, §4.7).

## 0.4 Method

Attack first, then constrain. Every mechanism in Volumes A–D is introduced together with the attack that a
plausible implementer would mount on it, and is retained only if a constraint closes or bounds that attack.
§86 collects the full suite (≥70 attacks). Nothing is called "emergent" without its local rules being written
down (§109 discipline).

---

# §1 — THE CENTRAL QUESTION

## 1.1 Statement

> **What is the minimum set of architectural constraints under which an initially sparse and generic population
> of cells develops stable specialization, circuits, and functional regions — where "minimum" means: remove any
> one constraint and the system either fails to organize, or organizes in a way that is ungovernable, unverifiable,
> or unsafe?**

Two failure modes bound the answer from either side:

| Pole | Failure | Where it is already present in the sources |
|---|---|---|
| **Hard-coded architecture** | Structure is written by the architect; "development" is theatre; the system cannot adapt its organization to a task it was not designed for | **V3 §9 specifies ~20 named regions with assigned functions by hand** (cortex → frontal/parietal/temporal/occipital/insula-like; basal ganglia; hippocampus-like; amygdala-like; thalamus-like; hypothalamus-like; epithalamus-like; subthalamus-like; midbrain-like; pons-like; medulla-like; cerebellum-like). **V3 §22 PHASE 6→7 hand-authors the developmental trajectory itself** ("one functional region" → "multi-region brain") |
| **Uncontrolled emergence** | Structure arises but is unauditable, unreproducible, unrollback-able, and its authority is whoever won | **V3 §24 thesis** ("a governed computational ecosystem") asserts governance but supplies no constitutive mechanism; **V3.1 §6 lists "Regional plasticity — change population composition — change functional roles — allocate resources — form new subcircuits"** with no authority attached to any of the five |

**Neither pole is hypothetical.** The hard-coded pole is the *status quo of the source document*. The uncontrolled
pole is what V3.1 §6 licenses on its face. P0-06 must therefore do two things at once: **demote the hand-written
anatomy to non-normative status without losing its functional content (§25)**, and **attach authority to V3.1 §6's
five regional operations without inventing a controller that holds it all (§4.7, §59).**

## 1.2 The answer, in one paragraph (the rest is defence)

> **Split every developmental object into a SCHEMA and an INSTANCE. The schema — the role set, the scope
> definitions, the authorization matrix, the Σ-operation rules, the invariant set — is governance-written
> (`[RO-13]`/K) and development may never touch it. The instance — which cells occupy which region, which niche
> slots exist, which specialization each cell carries, which subcircuits are formed — is development-written,
> under a ladder of rungs inherited from P0-05 §29 plus a new, distinct class of Σ-operations for scope
> constitution. Authority to write an instance of scope `S_n` is held in ABEYANCE by the kernel K before `S_n`
> exists, and is DEVOLVED to `S_n` at the moment of its constitution — an act that simultaneously extinguishes
> K's abeyant hold over `S_n`. Development is therefore real (it writes instances), bounded (it cannot write
> schema), and self-extinguishing (its scaffold dies as the structure it scaffolded is born).**

Three consequences are load-bearing and are defended at length:

1. **Growth is not part of the answer.** `Cell G13` makes replacement **zero-sum**: *"a slot must be freed
   (retirement, pruning, death) before one is taken"*; population is *"constant unless the envelope is changed by
   human authorization."* ⟹ **Development is re-allocation of a fixed budget, never increase of it.** (§20, §41)
2. **The number of regions is an envelope ceiling, not an emergent prediction.** `Cell §22` hardware table fixes
   region counts per tier (laptop 3–5, workstation 4–8, GPU server 6–10, cluster 8–12). ⟹ These are **`[H]`
   hardware-envelope parameters**, and P0-06 must not present them as outcomes of self-organization. (§25, §92)
3. **Role discovery is impossible and this is accepted, not hidden.** `RoleCode` is a **closed 16-value wire enum**
   (`Cell A-11`). Openness lives in *specialization within role*, not in *role*. (§12, §13)

## 1.3 What "useful" can and cannot mean here

"Useful self-organization" cannot mean *produces the right structure*, because the right structure is
task-dependent (`P0-01`) and unverifiable at regional altitude (`P0-05 OR-L3`: **there is no probe design for
Λ3**; `P0-05` rung-cost inversion: at **E7** the probe sits at **S5**, where cross-scope probe **C-2** is
unavailable and `UDB_MAX` is smallest). It can only mean:

> **DEV-R1.1 — USEFULNESS IS SERVICE-LEVEL, NOT STRUCTURAL.** A developmental outcome is *useful* iff a
> **declared service-level deficit** (`Cell §15.1`'s `DEMAND(role, region, magnitude)`) that existed before the
> outcome is measurably reduced after it, measured by the only inherited counterfactual instrument —
> **ablation delta** (`Cell G3`: *"contribution to circuit/region contract measured by ablation delta: performance
> of dependents with vs. without this cell"*). Structural elegance, region count, depth, and symmetry are **not**
> measures of usefulness and MUST NOT be used as objectives.

> **DEV-R1.2 — NO GUARANTEE OF USEFUL OUTCOME.** P0-06 does **not** claim that development produces useful
> specialization, correct regions, or any particular structure. It claims only that (i) every structural change is
> authorized, logged, reversible-or-declared-irreversible, and bounded; (ii) no failure mode of development
> produces a **capacity increase**; (iii) no developmental actor acquires authority it was not devolved.
> Claims of guaranteed emergence, optimal differentiation, guaranteed useful specialization, guaranteed
> brain-region emergence, guaranteed intelligence/AGI/consciousness, or perfect self-organization are **prohibited
> and are not made anywhere in this contract.**

---

# §2 — WHAT DEVELOPMENT IS NOT

A negative definition first, because the word "development" is a catch-all in V3/V3.1 and eight distinct
mechanisms get absorbed into it. Each exclusion cites the inherited rule that makes the exclusion non-optional.

| # | Development is **NOT** | Inherited ground | Consequence for P0-06 |
|---|---|---|---|
| **N1** | **Growth.** Increasing population | `Cell G13` zero-sum default; `Cell G-e` blocks `T01` unless a slot was freed by `T27`; population *"constant unless the envelope is changed by human authorization"* | Envelope change is a **governance act**, not a developmental one. Σ-operations re-allocate; they never enlarge |
| **N2** | **Learning.** Changing state within an existing scope | `P0-05 R0.2` (`LearnedChange`), Λ0–Λ4, S1–S6; `LEARN-INV-30`: **S6 is ∅ for learning** | Development operates where learning may only **propose** (§5.2). No shared write path (`P0-05 R75.1`) |
| **N3** | **Evolution.** Changing what is heritable | `Cell §3.5`: *"NOT heritable: developed architecture, learned parameters, θ deltas, **role**, memory of any kind, connection weights, trust, calibration history"*; `Cell I-8` (EIK-enforced) | Anything that becomes heritable left development and entered **E9** (§6) |
| **N4** | **Replication.** Producing offspring | `Cell I-5`: *"A cell cannot replicate — no write path to the Genome Store, no instantiation authority"*; `Cell §16` 16 gates | Development never creates a genome. It creates **instances of already-genomed cells** |
| **N5** | **Repair.** Restoring a damaged component to its prior contract | `Cell` states 13 `REPAIRING`, `T21–T25`; role `REPAIR` *"may not repair itself"* | Repair restores; development constitutes. **But `T25`/`T34` "re-develop from genome" is a repair transition that invokes development — contested at §8.3** |
| **N6** | **Hand reconfiguration.** An architect editing topology | `Cell §22.3` operations are *"Organism-directed"*; `P0-05 R24.2` rejection list excludes the authorization matrix from adaptive targets | If a human edits structure, that is an envelope/governance change and **must be logged as such**, not as a developmental event. Otherwise provenance lies |
| **N7** | **Schema self-modification.** Rewriting the role set, scope definitions, matrix, or Σ-rules | `P0-05 R19.2`/`R65.1`/`R28.1`: capacity is a **`[RO-13]`** artifact with no adaptive writer | **The single most important exclusion.** Dev writes instances, never schema (§1.2, §4.7, §85) |
| **N8** | **A controller.** A central developmental process that owns structure | `Cell §15.2`: *"Each differentiation tick (**organism-scheduled**, not cell-scheduled)"*; `Cell §15.3` `ORGANIZER` is a **cell role**, term-limited | V3.1 §6's five regional operations + §15.2's engine **do** imply a central scheduler. §59 tests whether it is necessary and decomposes it if not. **§109 forbids a giant developmental controller unless proven necessary — the burden of proof is on the controller** |

> ### **DEV-R2.1 — THE EIGHT EXCLUSIONS ARE CUMULATIVE, NOT ALTERNATIVE.**
> A mechanism that violates any one of N1–N8 is not "development with a caveat"; it is outside this contract and
> must be reclassified into the contract that owns it (P0-05 for N2, E9/P0-07 for N3, envelope governance for
> N1/N6, `[RO-13]` for N7).

---

# §3 — «DO NOT ASSUME "DIFFERENTIATION"»

The discipline applied to "learning" in P0-05 §3 and to "memory" in P0-04 is applied here. **The sources use
three words — differentiation, specialization, development — for at least six distinct mechanisms, and two of the
collisions have architectural consequences.**

## 3.1 Candidate meanings of *differentiation*

| # | Candidate meaning | Verdict | Ground |
|---|---|---|---|
| **DF-1** | **Cell-type assignment** — writing `role` from `RoleCode` | ⚠️ **Necessary but insufficient** | `Cell §3.1`: `role` is *"Differentiation outcome (§15)"*, `UNDIFFERENTIATED` at birth, writer *"Organism (differentiation engine)"*. But role alone does not produce a circuit or a region |
| **DF-2** | **Stage progression** — `PLURIPOTENT → PROVISIONAL → COMMITTED` | ⚠️ Necessary but insufficient | `Cell` `DevStage(4)`; `Cell §15.2` commitment conditions (i)–(iv) |
| **DF-3** | **Capacity restriction** — narrowing admissible targets/topology within a fixed port set | ✅ **ADOPTED as the core** | `Cell I-14` (*"A cell cannot widen its own port schema"*), `Cell` P12 (authority never increases), `Cell §18.4` (self-restriction permitted). **Restriction is the only direction the contract already allows** (§14) |
| **DF-4** | **Spatial organization** — cells acquiring position and forming boundaries | ✅ **ADOPTED, separate object** | `Cell` `morphogen_readings`, `region_id`; `Cell §30 P0-28` "Partial". This is **regional** differentiation, not cellular (§21) |
| **DF-5** | **Lineage divergence** — siblings becoming different | ❌ **Rejected as the definition** | `Cell §3.5`: seeds are EIK-issued and **not heritable** precisely so siblings are *not* correlated by construction; divergence is a **consequence**, and it is measured (I-10), not definitional |
| **DF-6** | **Acquisition of new capability** | ❌ **Rejected outright** | Contradicts DF-3, I-14, P12. **A cell that "differentiates into" something it could not do before has not differentiated; it has been re-instantiated** (`Cell §3.1`: `variant` *"changeable only by re-instantiation, never in place"*) |

## 3.2 Candidate meanings of *self-organization*

| # | Candidate | Verdict |
|---|---|---|
| **SO-1** | Structure arises with **no** external specification | ❌ Rejected. V3 §9 already specifies structure; and an unspecified structure has no functional contract to satisfy, so `Cell §22.3`'s functional identity is undefined |
| **SO-2** | Structure arises from **local rules only** | ⚠️ Necessary but insufficient. Local rules are required (§109: no "emergent" without local rules) but lateral inhibition alone collapses to a single role without a budget constraint (`Cell §15.2`) |
| **SO-3** | **The organism selects among governance-admissible structures, using signals it generates itself, under constraints it may not rewrite** | ✅ **ADOPTED** |
| **SO-4** | Structure arises and *thereby* acquires authority | ❌ **Rejected — this is the §109 "emergent authority" confusion.** Authority is devolved by Σ4 (§4.7), never acquired by existing (§68, §90) |

> ### **DEV-R3.1 — SELF-ORGANIZATION, NORMATIVE DEFINITION (SO-3).**
> Self-organization is: **(a)** a population selecting **(b)** an arrangement of its own members — occupancy of
> niches, membership of circuits and regions, specialization within role — **(c)** from a set of arrangements that
> is **governance-reserved** (every choice set contains at least one element reserved by governance, §3.4),
> **(d)** driven by signals the population itself generates (gradients, demand, inhibition, success history),
> **(e)** under schema constraints no member of the population may write.
> **Clause (c) is what distinguishes self-organization from uncontrolled emergence; clause (d) is what
> distinguishes it from hand-configuration.** Remove (c) and the system is ungovernable; remove (d) and it is
> V3 §9.

## 3.3 The collision with architectural consequences: **ROLE ≠ SPECIALIZATION**

`Cell §15` is titled **"SPECIALIZATION"** and its mechanism writes **`role`**. `P0-05 R46.1` uses
**"specialisation"** for something else entirely:

> `P0-05 R46.1` — *"SPECIALISATION IS AN Λ3/S4 CHANGE (E4/E7 RUNG), NOT AN Λ1 CHANGE. Specialising a region
> changes what it is for — its admissible targets, its topology, its role."*
> `P0-05 R46.1` — *"An E4/E7 change MUST declare the conditions under which it is reversed, and the reversal MUST
> be at the same or lower rung."*

But `Cell I-23` says the opposite about the same word:

> `Cell I-23` — *"A cell in `COMMITTED` dev_stage cannot change role except via gated `TRANSDIFFERENTIATION` with
> **EIK authorization** and sandbox validation."* (**EIK+ORG**, Annex B `T31`/`T32`.)

> ### **X-D1 — ROLE/SPECIALIZATION TERMINOLOGY COLLISION (RESOLVED).**
> **Statement.** `P0-05 R46.1` requires that a specialization be reversible **at the same or lower rung**.
> `Cell I-23` requires **EIK authorization** to change `role` after commitment — strictly **more** authority than
> the `ORGANISM`-only commitment that created it (`Cell §15.2(iv)`: *"ORGANISM AUTHORITY writes dev_stage"*).
> If "specialization" denotes `role`, then the inherited reversal rule is violated by the inherited invariant.
> **Resolution.** The two contracts are describing **two different objects**, and both are right about their own:
>
> | Object | What it is | Writer | Reversibility | Rung |
> |---|---|---|---|---|
> | **`ROLE`** | An **identity** field: a value of the closed 16-value `RoleCode` enum, wire-visible, governance-bearing (`Cell §3.1`, `A-11`) | `ORGANISM` at commitment; **EIK+ORG** for any post-commitment change | **Effectively irreversible** (`I-23`); changeable only via `TRANSDIFFERENTIATION` | not a rung — an **identity event** |
> | **`SPECIALIZATION`** | A **state** object: the restricted admissible-target set, the realized intra-role topology, the degree of narrowing | `ORGANISM` (Λ3/S4) | **Reversible at same-or-lower rung**, and **must declare its reversal condition** (`R46.1`) | **E4/E7** |
>
> ⟹ **`R46.1` governs SPECIALIZATION. `I-23` governs ROLE. Neither is amended; the collision is a naming
> collision.** The obligation P0-06 inherits is to keep them apart in every schema, every state machine, and every
> authority row — because conflating them produces exactly the error §109 prohibits (*"don't confuse influence with
> authority"*), namely treating a reversible narrowing as if it conferred identity, or an identity change as if it
> were a reversible parameter.

> ### **DEV-R3.2 — ROLE IS IDENTITY; SPECIALIZATION IS STATE.**
> A **role** is a closed-enum identity field whose change is an authority event (EIK-gated post-commitment).
> A **specialization** is a reversible restriction of admissible behaviour within a role, authorized at E4/E7,
> and **required to carry a declared reversal condition**. No mechanism in P0-06 may write `role` and call it
> specialization, or restrict behaviour and call it a role change.

## 3.4 The reserved-choice principle (third occurrence in the V4 corpus)

`SO-3(c)` requires that every organism-selected choice set contain a governance-reserved element. This is the same
structural requirement that appeared twice before:

| Prior occurrence | Reserved element | Source |
|---|---|---|
| Probe input distribution | **C-1** — probe inputs are `[RO-13]`, not learner-selected | `P0-05` |
| Workspace slots | **R60.5** — governance-reserved slots in the broadcast set | `P0-05` |
| Branch set | reserved branch in the exploration set | `P0-05` |

> ### **DEV-R3.3 — RESERVED-CHOICE PRINCIPLE (developmental form).**
> For every set from which the population selects a developmental outcome — the reachable-role set
> (`reaction_norm`), the candidate niche set, the candidate region partition, the candidate subcircuit set, the
> branch set of a developmental fork — **at least one element MUST be reserved by governance** and MUST be
> selectable without organism authorization. Reserved elements are the mechanism by which an externally-directed
> structure remains reachable in a system that otherwise chooses for itself. **A choice set with no reserved
> element is inadmissible.**

---

# §4 — ROOT FINDING: THE SCOPE-CONSTITUTION CIRCULARITY

This is the single most consequential finding in P0-06. It is not an initialization-order inconvenience; it is a
**definitional** circularity in the inherited architecture, and P0-06 is the only contract positioned to break it.

## 4.1 The three inherited premises

> **Premise A — the scope ladder defines S4 by specialization.**
> `P0-05` Vol A §(scope ladder): **"S4 — REGIONAL | a specialised population | regional topology, specialisation
> degree, regional budgets | `ORGANISM`"**. Likewise **"S3 — MICRO-CIRCUIT | a functionally connected group"**.
> The scopes are *defined by the structural properties they hold*.

> **Premise B — specialization is an S4-authority change.**
> `P0-05 R46.1`: *"Specialising a region … is E4 (recruit cell to a function) / E7"*, and the E-ladder assigns
> **E4 → minimum authority `ORGANISM`**, **E7 → minimum authority `POLICY (RO-13)`**.
> `P0-05 R4.3`: *"authority(S1) ≤ authority(S2) ≤ … ≤ authority(S6). A component may not authorise above its
> scope."* (`LEARN-A5` — scope elevation.)

> **Premise C — the ladder has no rung that constitutes a scope.**
> Full audit of `P0-05 §29.1` (E0–E9):

| Rung | Operation | Blast radius | Minimum authority | **Does it create a scope?** |
|---|---|---|---|---|
| E0 | weight adjust | 1 connection | `SELF_LOCAL` | ❌ within S1 |
| E1 | create connection (additive) | 1→2 components | `CIRCUIT` | ❌ within S3 |
| E2 | reroute connection | circuit | `CIRCUIT` | ❌ |
| E3 | remove/prune connection | circuit | `ORGANISM` | ❌ |
| E4 | recruit cell to a function | region | `ORGANISM` | ❌ **presupposes the region** |
| E5 | release/retire cell | region | `ORGANISM` + retirement regime | ❌ |
| E6 | form/dissolve **sub**circuit | region | `ORGANISM` | ❌ **forms a circuit inside a region** |
| E7 | change regional topology / specialisation degree | organism | **`POLICY (RO-13)`** | ❌ **changes an existing region** |
| E8 | change a learning rule (Λ4) | organism | `POLICY (RO-13)`/EIK | ❌ |
| E9 | propose a genome-diff (CH-3) | population | 11 gates + KC | ❌ |

**Not one of E0–E9 constitutes an S3 micro-circuit scope, an S4 region scope, or an S5 organismal scope.**
E6 is the nearest miss: it forms a *sub*circuit at *region* blast radius — i.e. it is defined **inside** the scope
it would have to create if it were constitutive.

## 4.2 The circularity, stated formally

> ### **D-D01 — THE SCOPE-CONSTITUTION CIRCULARITY (ROOT FINDING; severity CRITICAL; status RESOLVED-STRUCTURAL).**
> Let `constitute(S_n)` denote the act that brings scope `S_n` into existence, and `auth(X, S_n)` denote "actor X
> holds authority over scope `S_n`".
>
> 1. `P0-05` scope ladder: **S4 ≝ "a specialised population"**. ⟹ `∃S4 ⟺ ∃ specialisation at S4`.
> 2. `P0-05 R46.1` + E-ladder: **specialisation at S4 requires `auth(·, S4)`** (E4 → `ORGANISM`; E7 → `RO-13`).
> 3. `P0-05 R4.3` (`LEARN-A5`): **no component may authorize above its own scope.**
> 4. From 1–3: `auth(X, S4)` requires `X ∈ S4` or `X` above it; but `S4` exists only once specialization exists;
>    and specialization requires `auth(·, S4)`.
>
> ⟹ **`constitute(S4)` requires `auth(·, S4)`, and `auth(·, S4)` requires `∃S4`, and `∃S4` requires
> `constitute(S4)`.**
>
> **The same closure holds for S3** ("a functionally connected group" — E1/E2 require `CIRCUIT` authority, which
> is the authority *of* the circuit) **and for S5** (`P0-05 R28.1` fact #2: `writable_scope(Λ4) = {S5}`, and S5's
> writer set is `{POLICY(RO-13), EIK}` — i.e. S5 is writable only by entities defined *at* S5 or above it).
>
> **Corollary (initialization form, = the BC-3 recorded during recon).** `P0-05 §28`'s authorization matrix is
> indexed by scopes **S3–S5**. At `t=0` none of S3–S5 exists (§7). ⟹ **At `t=0` the matrix has no referents for
> its own rows.** The matrix is well-formed only after the structure it authorizes has been built.

## 4.3 Why `R29.3` cannot decompose its way out

> `P0-05 R29.3` — *"DECOMPOSITION IS MANDATORY (R4.1). A composite operation ('reorganise this circuit') MUST
> decompose into rungs, each separately authorised. ⟹ The authority of a composite is th[e maximum of its rungs]."*

Region formation looks decomposable: `{E4 × n (recruit cells)} ∪ {E6 × m (form subcircuits)} ∪ {assign
region_id} ∪ {set regional budget} ∪ {devolve regional authority}`. The first two groups are rungs. **The last
three are not rungs at all** — they are scope-constituting acts, and no rung in E0–E9 has "assign `region_id` to a
population" or "set a regional budget" or "devolve authority over S4" as its operation.

> ### **DEV-R4.1 — DECOMPOSITION IS WELL-FOUNDED ONLY INTERNAL TO A SCOPE.**
> `R29.3` is sound for composites **all of whose rungs are defined within an existing scope**, because each rung's
> minimum authority is then an entity that exists. It is **undefined** for a composite that creates the scope in
> which its own rungs are indexed. **⟹ Region formation is not a composite of rungs; it is a different kind of
> operation, and forcing it into the ladder would require inventing rungs — i.e. silently amending `P0-05 §29`,
> which is prohibited.**

## 4.4 Why a bound cannot fix it (§109 discipline, applied)

The tempting fix is to bound the problem: cap the number of regions, cap the rate of region formation, cap the
depth of the hierarchy. `Cell §22`'s hardware table already does exactly this (3–5, 4–8, 6–10, 8–12 regions).

> ### **DEV-R4.2 — A BOUND LIMITS A CYCLE; WRITER SEPARATION BREAKS A CYCLE.**
> *(Carried forward verbatim from `P0-05 R75.1`'s writer-separation test, §85.)* A region-count ceiling does not
> answer *who authorizes the first region*; it only limits how many times the unanswered question can be asked.
> **P0-06 MUST NOT claim that any bound — on region count, formation rate, hierarchy depth, population size, or
> developmental budget — breaks D-D01.** Bounds are `[H]`/`[G]` parameters and are registered as such (§90);
> the cycle is broken only by separating the **writer** of the constituting act from the **beneficiary** of the
> authority it creates.

## 4.5 The resolution: Σ-operations, abeyant authority, devolution

> ### **DEV-R4.3 — THE Σ-CLASS (SCOPE-CONSTITUTION OPERATIONS).**
> Scope constitution is a **distinct operation class**, not a rung. It is written **Σ** and is *disjoint from*
> E0–E9, so that `P0-05 §29` is not amended:
>
> | Σ | Operation | Effect | Reversibility | Authority (pre-constitution) |
> |---|---|---|---|---|
> | **Σ1** | **CONSTITUTE SCOPE** `S_n` | Brings `S_n` into existence: membership set, boundary, budget reference, anchor slot | `VERSION_REVERSIBLE` (Σ2) | **K, ABEYANT** |
> | **Σ2** | **DISSOLVE SCOPE** `S_n` | Re-homes members, releases budget, retires the scope record | `IRREVERSIBLE_STRUCTURAL` | **K, ABEYANT** + `[RO-13]` for S4+ |
> | **Σ3** | **RE-HOME POPULATION** across existing scopes | Changes `region_id` of members without constituting/dissolving | `VERSION_REVERSIBLE` | `ORGANISM` (both scopes must exist) |
> | **Σ4** | **DEVOLVE AUTHORITY** over `S_n` to `S_n` | Transfers K's abeyant hold to the constituted scope; **terminates the abeyance** | **`IRREVERSIBLE`** except by Σ2 | **K only** |
>
> **Σ-operations write INSTANCES only** (which cells, which `region_id`, which `niche_slot`, which membership
> set). They never write the schema: not `RoleCode`, not the S1–S6 definitions, not the `P0-05 §28` matrix, not
> the Σ-rules themselves. **A Σ-operation that attempts to write schema is inadmissible by construction** (N7,
> §85).

> ### **DEV-R4.4 — ABEYANCE.**
> Before `S_n` exists, authority over `S_n` is held **in abeyance by K** — the `P0-02` off-substrate kernel, which
> is the only inherited entity that (i) exists at `t=0`, (ii) is not itself a scope member, (iii) already holds
> authority that is not derived from any structural position (`Cell I-1`, `I-11`, `I-13`: identity, constraints, and
> K-only fields are EIK-written by construction). **Abeyance is not delegation:** K holds the authority *on behalf
> of a scope that does not yet exist*, and the holding is recorded as a K-owned object with an expiry condition.

> ### **DEV-R4.5 — DEVOLUTION AND SELF-EXTINCTION.**
> **Σ1 constitutes `S_n`; Σ4 devolves K's abeyant hold over `S_n` to `S_n`; and Σ4 simultaneously EXPIRES that
> hold.** The scaffold is therefore **self-extinguishing by construction**: the act that completes it destroys it.
> K cannot retain authority over a constituted scope, and cannot re-acquire it except by Σ2 (dissolution).
> **⟹ This is why P0-06 does not need — and MUST NOT have — a standing developmental controller (N8):** the
> controller's authority over each scope dies at that scope's birth. What remains is a **K-held registry of
> abeyances**, which is a data structure, not an actor.

> ### **DEV-R4.6 — WRITER SEPARATION (the actual cycle-breaker).**
> Three writers, pairwise distinct, for every Σ-operation:
>
> | Role in the cycle | Holder | May it be the same as the others? |
> |---|---|---|
> | **Writer of the SCHEMA** (what a region *may* be: S-definitions, matrix, Σ-rules, `RoleCode`) | `[RO-13]` governance / K | ❌ never the executor, never the beneficiary |
> | **Executor of the INSTANCE** (Σ1–Σ4 as an act) | **K, abeyant** | ❌ never the beneficiary |
> | **Beneficiary of the AUTHORITY** (who holds `auth(·, S_n)` afterwards) | **`S_n` itself**, post-Σ4 | ❌ never the schema writer, never the executor |
>
> **D-D01 is broken because the entity that authorizes the existence of `S4` (K, abeyant) is not the entity that
> benefits from `S4`'s authority (the constituted region), and neither may write the rule under which the transfer
> occurs (`[RO-13]`).** A bound would have limited how often this happened; only the separation makes the
> authorization non-self-conferring.

## 4.6 What the resolution does *not* fix (residual, stated honestly)

| Residual | Statement | Status |
|---|---|---|
| **OR-D1** | K's abeyant authority is itself unbounded pre-constitution: at `t=0`, K holds authority over every scope that will ever exist. Nothing in the inherited corpus limits what K may constitute. The limit is **procedural** (Σ-operations are logged, anchored, and Σ4 is irreversible) not **substantive** | **OPEN** |
| **OR-D2** | Σ1's *membership choice* is not determined by the Σ-rules. K may constitute any partition. Which partition is *good* is a task-dependent question (`P0-01`) with no inherited answer at regional altitude (`OR-L3`, rung-cost inversion) | **OPEN** |
| **OR-D3** | A constituted `S_n` may immediately begin acting in ways that make Σ2 (dissolution) practically impossible — e.g. by holding `mandatory_path` connections (`Cell I-22`) that `Cell G-f` forbids removing. **Structural entrenchment is a real limit on reversibility** | **OPEN** (§64, §68) |

> ### **DEV-R4.7 — NO CLAIM OF COMPLETE RESOLUTION.**
> D-D01 is **RESOLVED-STRUCTURAL**: the circular *authorization* is broken by writer separation. The circular
> *dependence* (a region needs cells that need niches that need a region) is **not** broken; it is **bounded** by
> Σ-ordering (§76 bootstrap) and by the zero-sum envelope (§20). **P0-06 does not claim to have eliminated
> bootstrapping circularity, only to have made it non-self-authorizing.**

---

# §5 — THE DEVELOPMENT / LEARNING BOUNDARY

## 5.1 The inherited collision

`V3.1 §6` lists, under **plasticity**:

> *"…specialization ■■■ Connection plasticity ■■■ create ■■■ reroute ■■■ strengthen ■■■ … reorganize
> subnetworks ■■■ **Regional plasticity ■■■ change population composition ■■■ change functional roles ■■■
> allocate resources ■■■ form new subcircuits**"*

So V3.1 places **"change functional roles"** and **"change population composition"** under **plasticity** — i.e.
under learning. `Cell §3.1` places `role` under **Organism (differentiation engine)**, and `P0-05 R46.1` places
specialization at **Λ3/S4, E4/E7**. Three documents, three homes for the same operation.

> ### **X-D2 — ROLE CHANGE: PLASTICITY OR DEVELOPMENT? (RESOLVED).**
> **Statement.** `V3.1 §6` classifies "change functional roles" as **regional plasticity** (⟹ learning).
> `Cell §3.1`/`§15.2(iv)` classifies `role`/`dev_stage` writing as an **organism authority act** (⟹ not
> learning; the cell cannot self-commit). `P0-05 LEARN-INV-30` makes **S6 ∅ for learning**, and `P0-05 R28.1`
> restricts Λ4 to `{POLICY(RO-13), EIK}`.
> **Resolution.** `V3.1 §6` is a **capability inventory, not an authority assignment** — it says the *system* can
> do these things, not that the *learning subsystem* may. Read as an inventory it is consistent with both other
> contracts. Read as an authority assignment it is contradicted by `Cell §15.2(iv)` and by `LEARN-INV-30`.
> **⟹ P0-06 adopts the authority reading and records the amendment: "regional plasticity" in `V3.1 §6` denotes
> Σ- and E4/E7-class operations, which are DEVELOPMENTAL, not Λ-class operations.** V3.1 is not rewritten; the
> classification is recorded here as **RESOLVED-BY-RECLASSIFICATION**.

## 5.2 The boundary that falls out of `LEARN-INV-30`

> `P0-05 LEARN-INV-30` — *"**S6 is empty for learning.** ¬∃ change: change.scope = S6. The only S6 crossing is a
> CH-3 *proposal*, which is not a `LearnedChange`."* (`R4.2`, `R28.1`, `R24.1`.)

`S6 — POPULATIONAL | across lineages`. Learning may **propose** across S6 and may **execute** nothing there.
Development's Σ-operations are exactly the executions learning may not perform: they create and destroy the scopes
that learning is indexed by.

> ### **DEV-R5.1 — THE BOUNDARY RULE.**
> **Learning changes STATE within a scope. Development constitutes and dissolves SCOPES.** Formally:
> - `LearnedChange.scope ∈ {S1…S5}` (`LEARN-INV-30`), writer ∈ Λ-classes, and **no `LearnedChange` may have a
>   Σ-operation as its effect**.
> - `Σ-operation.effect ∈ {constitute, dissolve, re-home, devolve}`, writer ∈ {K abeyant, `[RO-13]`}, and **no
>   Σ-operation may write θ, `fate_bias`, weights, or any Λ1/Λ2 target**.
> - **Learning may PROPOSE a Σ-operation** (a CH-3-class proposal, rate-limited by `P0-05 B7` `PROPOSAL_QUOTA`,
>   carrying no effect and consuming no budget — `R29.2`). **Development may EXECUTE it.**
> **⟹ This is the non-arbitrary division of labour: P0-05 is the proposer, P0-06 is the executor, `[RO-13]` is the
> schema writer, K is the abeyant authority. Four writers, no shared path (`P0-05 R75.1`).**

## 5.3 The four-way discriminator

| Property | **LEARNING** (P0-05) | **DEVELOPMENT** (P0-06) | **EVOLUTION** (E9/P0-07) | **ENVELOPE** (governance) |
|---|---|---|---|---|
| Object written | state (θ, model, calibration) | instance (membership, `region_id`, `niche_slot`, specialization) | genome (heritable) | capacity ceiling, population cap, region ceiling |
| Scope | S1–S5 | Σ over S3–S5 | S6 | above S6 |
| Reversible? | `ROLLBACKABLE_IN_MEMORY` … `VERSION_REVERSIBLE` | `VERSION_REVERSIBLE` (Σ1/Σ3) / `IRREVERSIBLE_STRUCTURAL` (Σ2) | irreversible once accepted | governance act |
| Heritable? | ❌ (`Cell §3.5`, `I-8`) | ❌ (`Cell §3.5`: *"developed architecture … role"* NOT heritable) | ✅ by definition | n/a |
| Trigger | error, eligibility, budget | demand **proposal** + competence + niche confirmation | 11 gates (`Cell §16`) | human authorization |
| May it write schema? | ❌ (`R24.2`) | ❌ (**DEV-R4.3**, N7) | ❌ (`I-8`, `I-11`) | ✅ **only this one** |

## 5.4 The hard case, and its resolution

**Is `E4` (recruit cell to a function) learning or development?** `P0-05 §29.1` lists it as a **learning** rung
(Λ3, `ORGANISM`, `VERSION_REVERSIBLE`). But recruiting a cell to a function is *how a region acquires members*,
which is Σ1-adjacent.

> ### **DEV-R5.2 — E4 IS LEARNING WHEN THE SCOPE EXISTS, Σ1 WHEN IT DOES NOT.**
> If `S_n` exists and holds devolved authority, recruiting a cell into it is **E4** — a Λ3/S4 change under
> `P0-05 §29`, and P0-06 does not re-authorize it. If `S_n` does **not** exist, then "recruiting cells into it"
> is **Σ1 (constitute)** executed by K-abeyant, and the individual recruitments become E4 operations **only after
> Σ4 devolution**. **⟹ ORDERING IS NORMATIVE: Σ1 → Σ4 → E4\*. Performing E4\* before Σ4 is scope elevation
> (`LEARN-A5`) and is inadmissible.** This single ordering rule is what makes §76 (bootstrap) well-founded.

---

# §6 — THE DEVELOPMENT / EVOLUTION BOUNDARY

## 6.1 The heritability wall is already built

> `Cell §3.5` — *"**NOT heritable: developed architecture, learned parameters, θ deltas, `role`, memory of any
> kind, connection weights, trust, calibration history, epistemic sufficiency…**"*
> `Cell I-8` (EIK-enforced) — *"Learned state cannot silently become inherited genome. Genome Store is
> write-restricted to the Replication Authority; the §3.5 rejection list is machine-checked."*
> `Cell §3.5` — *"RNG seeds are EIK-issued, not heritable. If seeds were inherited, siblings would be correlated by
> construction and every independence claim would be void."*

**⟹ Development is Baldwinian by construction: what is developed guides nothing heritable.** The wall exists; P0-06
must not build a second one, and must not drill a hole in this one.

## 6.2 The slippery slope §109 names

*"Don't let development silently become evolution."* The mechanism by which it would:

```
developmental outcome (region partition P, specialization set Σ_s)
   → measured as service-level improvement (DEV-R1.1)
   → P and Σ_s recorded in the Lineage Store (Cell T28: archive hash anchored externally)
   → Replication Authority reads the archive when constructing offspring genomes
   → offspring inherit a genome biased toward P
   ⟹ P has become heritable WITHOUT any E9 gate having run.
```

Every arrow is an inherited, individually-legitimate mechanism. `Cell §16`'s 16 gates do not stop it, because the
gates check **diffs to a candidate genome**, and the bias enters through **niche availability for the offspring's
lineage** — a developmental fact, not a genomic diff. `Cell G11` (*"A niche exists for the role in the target
region; `niche_capacity > current_occupancy`"*) is precisely the channel: **a region that developed a niche keeps
having that niche, so its lineage keeps being recruited into it, so the population's developed structure
reproduces itself without ever being encoded.**

> ### **X-D3 — DEVELOPMENTAL PSEUDO-HEREDITY (RESOLVED BY CONSTRAINT).**
> **Statement.** `Cell §3.5`/`I-8` prohibit heritability of developed structure at the **genome** level. Nothing in
> the inherited corpus prohibits heritability at the **niche-availability** level, and `Cell G11` supplies the
> channel. The result is *de facto* Lamarckian reproduction of developed structure that bypasses all 11+ E9 gates
> and `P0-04 R47.1`'s Lamarckian prohibition.
> **Resolution.** The channel cannot be closed (niches must persist or nothing is stable), so it is **declared and
> governed** rather than prohibited:

> ### **DEV-R6.1 — NICHE PERSISTENCE IS A HEREDITARY CHANNEL AND IS GOVERNED AS ONE.**
> (a) Niche creation and continuation are **Σ-operations**, K/`[RO-13]`-authorized, logged, and anchored (§20).
> (b) A niche's existence MUST NOT be conditioned on the lineage identity of its occupants. **Lineage-blind
> occupancy**: `niche_slot` allocation may test `role`, `variant`, `reaction_norm`, competence — and **MUST NOT**
> test `lineage_id`, `generation`, or descent from a prior occupant.
> (c) Niche renewal is **periodic and re-authorized**, not perpetual: a niche that is never re-authorized lapses.
> (d) **A developmental outcome MUST NOT be written to any heritable store** — Genome Store (`I-5`, `I-8`),
> Lineage Store archive fields read by the Replication Authority, or `reaction_norm`.
> **⟹ Developed structure may persist as *environment* (niches, regions) and MUST NOT persist as *genome*. This is
> the exact Baldwinian line, and (b) is what keeps it from collapsing into lineage privilege.**

> ### **DEV-R6.2 — DEVELOPMENT IS INTRA-LIFETIME AND INTRA-LINEAGE-POSITION.**
> A developmental act affects (i) the acting population's arrangement and (ii) the environment its successors
> encounter. It affects **nothing** that is copied at replication. Any mechanism whose effect survives replication
> as a *property of the offspring* is **E9** and belongs to P0-07, not here.

---

# §7 — THE INITIAL CONDITION

## 7.1 What exists at `t = 0`

Assembling only inherited facts:

| Entity | Exists at `t=0`? | Ground |
|---|---|---|
| **K** (EIK kernel, off-substrate) | ✅ | `P0-02`; `Cell I-1/I-11/I-13` are EIK-written by construction; *"a stub kernel is a Phase-1 deliverable"* |
| **`constraint_set`** (signed) | ✅ | `Cell §30`: *"P0-02 — build a stub EIK and publish a signed `constraint_set`"*; `Cell §3.1`: constraints *"not in the genome and not in the cell — referenced by hash only"* (`I-11`) |
| **Genome Store** | ✅ (contains ≥1 genome) | `Cell §3.2`; write-restricted to Replication Authority (`I-5`, `I-8`) |
| **Type Registry / port schemas** | ✅ (format) · ⚠️ (contents) | `Cell §30`: *"Format resolved (A-1); contents task-dependent"* ← from `P0-01` |
| **Lineage Store** | ✅ (empty) | `Cell T28`, `§4.4`: *"lineage record persists forever … externally anchored"* |
| **Cells** | **⚠️ exactly one, or zero** | `Cell` state 0 `UNINSTANTIATED` (*"Genome exists; no cell yet"*); `T01` requires a freed slot (`G-e`) — **but at `t=0` there is nothing to free, so the envelope itself supplies the first slots** |
| **Scopes S1–S6** | ❌ **none** | S1 needs a connection (needs ≥2 cells); S3 needs *"a functionally connected group"*; **S4 ≝ "a specialised population"** — with one `UNDIFFERENTIATED` cell, S4 is empty by definition |
| **`P0-05 §28` matrix rows** | ❌ **no referents** | **D-D01 corollary** |
| **Anchors `θ_anchor(S)`** | ❌ **none** | `P0-05 R0.1`: `‖θ_S − θ_anchor(S)‖ ≤ UDB_MAX[S]` — undefined for a nonexistent scope (§11.4) |
| **Niches** | ❌ **none** | `niche_slot` is O-written; `G11` requires `niche_capacity > current_occupancy` |
| **Regions** | ❌ **none** | `region_id` is `⟨bytes<16> | null⟩` and **`null` at birth** (`Cell §3.1`) |

> ### **DEV-R7.1 — THE `t=0` POPULATION.**
> `t=0` state: **K running; one signed `constraint_set`; ≥1 genome in the Genome Store; zero or one cell in state
> `UNINSTANTIATED`/`INSTANTIATED`; `dev_stage = PLURIPOTENT`; `role = UNDIFFERENTIATED`; `region_id = null`;
> `niche_slot = null`; `morphogen_readings` absent; no scope S3–S6 instantiated; no anchor; no niche.**
> **`region_id = null` is load-bearing, not a placeholder**: `Cell §3.1` types it as nullable precisely so that a
> cell can exist before any region does. **Any mechanism that requires a non-null `region_id` at birth is
> inadmissible**, and any that requires `morphogen_readings` at birth is inadmissible (§17.5).

> ### **DEV-R7.2 — THE SPARSE-GENERIC PROBLEM IS THE ONLY PROBLEM.**
> §1's "initially sparse and generic population" is not a simplifying assumption; it is the **inherited** initial
> condition. The developmental contract must therefore work from **one undifferentiated cell and no scopes**.
> Any design that presupposes a pre-existing regional partition (e.g. instantiating V3 §9's twenty regions at
> `t=0`) has **answered the question by assuming it**, and is rejected.

## 7.2 The three things that cannot exist yet, and what substitutes

| Absent at `t=0` | Substituted by | Ground |
|---|---|---|
| **Scopes** | **K-abeyant authority** (DEV-R4.4) | `P0-02` kernel is pre-structural |
| **Anchors** | **No-unverified-distance-credit default**: `UDB(S_n) := 0` until the first verified anchor exists (§11.4) | `Cell` P5 fail-safe: *"toward less influence, never more"* |
| **Niches** | **Envelope-declared initial niche set**, Σ1-constituted, K-authorized (§20) | `Cell G13`: growth requires envelope change by human authorization — so the *first* niches are an envelope act |

---

# §8 — THE SEED

## 8.1 What the seed is

> `Cell §3.2` — `rng_seed_class : enum{EIK_ISSUED}` — *"⟹ seeds are NOT heritable and NOT cell-chosen."*
> `Cell §3.5` — *"RNG seeds are EIK-issued, not heritable. If seeds were inherited, siblings would be correlated by
> construction and every independence claim would be void (Attack I…)."*
> `Cell` state table — `rng_state` (xoshiro256**): *"C (self-advancing only)"*, checkpointable; `rng_seed_provenance`:
> **K-written**, persistent, anchored.
> `Cell §15.4` — independence requires *"distinct EIK-issued RNG seeds"*, kernel-attested (`I-10`).

## 8.2 The normative limit on randomness

> ### **DEV-R8.1 — RANDOMNESS MAY CHOOSE; IT MAY NEVER QUALIFY.**
> A seed may break a tie between **equally admissible** outcomes (which of two symmetric cells commits first).
> A seed may **never** be the reason an outcome is *admissible*, *competent*, *authorized*, or *verified*.
> Formally: for any developmental decision `d` with candidate set `C(d)`,
> `admissibility(C(d))` is computed from `reaction_norm`, `variant`, niche availability, and competence —
> **never from `rng_state`** — and the seed acts only as `select: C(d)_admissible → C(d)`.
> **Ground:** §109 (*don't let noise qualify*); `Cell I-10` (independence is **measured**, never merely
> different-seeded); `Cell §15.2(ii)` (commitment requires *measured success ≥ θ_success*, which a seed cannot
> supply).
> **Consequence:** **symmetry is broken by EXTERNAL CONTACT, not by internal noise.** Two symmetric cells in a
> symmetric field do not differentiate because their seeds differ; they differentiate when they occupy *different
> positions relative to something external* — a gradient, a niche, an input channel, a boundary. The seed decides
> which of the two takes which externally-distinguished position. **Without an external asymmetry there is nothing
> for the seed to choose between, and the field remains symmetric — which is the correct behaviour, not a bug.**

> ### **DEV-R8.2 — SEED PROVENANCE IS ANCHORED; SEED STATE IS NOT A REASON.**
> `rng_seed_provenance` (K-written, anchored) exists so that **non-correlation can be attested**. It MUST NOT be
> used as an explanation, a fitness input, a competence proxy, or a tie-breaker in *governance* decisions (only in
> *admissible-set selection*).

## 8.3 The recovery contradiction

> `Cell` Annex B **P11** — *"`INSTANTIATED` is reachable from every operational state via re-development from
> genome (**T25**, **T34**), **guaranteeing that recovery is always possible** while the [genome is intact]."*
> `Cell §27` — *"re-develop from genome (**the strongest recovery** — the genome is off-cell and anchored, so a
> cell can alwa[ys be rebuilt])."*
> `Cell` **T25** — *"`REPAIRING → CALIBRATING` (re-develop): State unrecoverable but genome intact … **Discard
> all runtime and learned state; r[e-develop]**."*
> `Cell` **T34** — *"`ANY → INSTANTIATED` (re-develop): Integrity failure detected anywhere …"*

But re-development consumes four inputs, **three of which are not in the genome**:

| Input to development | In genome? | Recoverable? | Ground |
|---|---|---|---|
| `reaction_norm`, `morphogen_receptors`, `critical_periods`, `commitment_schedule` | ✅ | ✅ | `Cell §3.2 D` |
| **RNG seed** | ❌ **not heritable, EIK-issued** | ⚠️ `rng_seed_provenance` is anchored — but the *state* is not reproducible from the genome | `Cell §3.2`, `§3.5` |
| **`morphogen_readings`** | ❌ | ❌ **`transient`, not checkpointable** | `Cell` state table: `morphogen_readings | f32[R] | [0,1]^R | C reads, O writes | **transient**` |
| **`niche_slot`** | ❌ | ❌ O-written, environmental | `Cell` state table: `niche_slot … O only` |
| **Neighbourhood / lateral inhibition** | ❌ | ❌ depends on other cells' states | `Cell §15.2`: `inhibition_r = Σ_{neighbours n committed to r}` |

And `Cell T41` says development can simply **fail**: *"`DEVELOPING → RETIRING`: Development fails to converge: no
stable `fate_bias` within `N_dev_max` ticks, **or no niche becomes available**" (ORG + EIK).*

> ### **X-D4 — "RE-DEVELOP FROM GENOME IS THE STRONGEST RECOVERY" IS FALSE AS STATED (RESOLVED BY RESTATEMENT).**
> **Statement.** `Cell` P11 asserts a **guarantee** of recovery via re-development, and `Cell §27` calls it *"the
> strongest recovery."* But (i) `morphogen_readings` is transient and uncheckpointed, so **positional information
> is lost**; (ii) seeds are non-reproducible, so **the developmental trajectory diverges**; (iii) `niche_slot` is
> environmental, so **re-development can fail outright** by `T41` for want of a niche. **⟹ Re-development does not
> reproduce the phenotype. `Cell §3.4`'s "Developed phenotype (`architecture_realized`, θ)" is checkpointable but
> explicitly NOT off-cell, so the checkpoint that would preserve it is exactly the checkpoint `T25` discards.**
> **Resolution — the guarantee is restated, not withdrawn.** Two distinct recovery claims were conflated:
>
> | Claim | True? | Ground |
> |---|---|---|
> | **STATE identity recovery**: re-development reproduces the same phenotype | ❌ **NO** — and it must not be claimed | (i)–(iii) above |
> | **FUNCTIONAL identity recovery**: re-development produces a cell satisfying the same functional contracts, with lineage continuity and Registry floors | ✅ **YES**, subject to niche availability | `Cell §22.3`: *"«Functional identity» is defined [V4] as: the set of satisfied functional contracts at circuit and region level, plus the lineage continuity, plus the Capability Registry floors"* |
>
> > ### **DEV-R8.3 — RECOVERY IS FUNCTIONAL, NOT STATEFUL.**
> > Re-development from genome is guaranteed to produce a **functionally-identified successor**, never an
> > **identical state**. All recovery claims in P0-06 (§64, §79) are stated in functional-identity terms.
> > **`Cell` P11 and §27's "strongest recovery" language is recorded as a PROPOSED AMENDMENT to the Cell
> > Contract: P11's guarantee holds only while a niche is available, and only at functional-identity level.**
> > Where no niche is available, re-development **fails by `T41`** and the correct recovery is **replacement from
> > lineage backup** (`Cell §27`) or **envelope action** — not re-development.

> ### **DEV-R8.4 — REPLAY-SEED ≠ HERITABLE-SEED (proposed amendment, status PROPOSED).**
> `Cell §3.5`'s prohibition is on **heritability** (offspring inheriting a parent's seed ⟹ correlated siblings ⟹
> void independence claims). It is **not** a prohibition on **replay** (the same individual's developmental
> trajectory being reproducible from an anchored ticket). These are different objects:
> - **HERITABLE-SEED** — a seed copied into an offspring genome. **PROHIBITED** (`Cell §3.5`, `I-8`). Unchanged.
> - **REPLAY-SEED** — the `rng_seed_provenance` ticket, K-anchored, per-individual, used to re-derive *that*
>   individual's development. **Permitted**, and required if any reproducibility claim is to survive.
> **⟹ But replay is reproducible only if the ENVIRONMENT is also recorded** (gradients, niche occupancy,
> neighbourhood). That is a full developmental trace, whose cost is analyzed at §79/§92. **P0-06 therefore does not
> require replay; it requires that recovery claims be made at functional-identity level (DEV-R8.3), and it permits
> replay only as an optional, budgeted diagnostic.**

---

# §9 — DEVELOPMENTAL INFORMATION

## 9.1 The seven channels

`Cell §15.1` defines the hybrid precisely — and in doing so enumerates the **complete** information budget of
development. Reproduced because it is the authoritative list:

| Factor | Contributes | Mechanism | **Heritable?** | **Persistent?** |
|---|---|---|---|---|
| **Genetically encoded** | *which roles are reachable*, with what bias — **not the role itself** | `genome.development.reaction_norm : [FateBias]` | ✅ | ✅ |
| **Developmental** | *timing and irreversibility* — when commitment windows open/close | `critical_periods`, `commitment_schedule`; `dev_stage` machine | ✅ | ✅ |
| **Environmentally induced** | *positional information* — where the cell is, hence which niches are relevant | `morphogen_readings` from organizer populations, read via `morphogen_receptors` | ❌ | ❌ **transient** |
| **Resource-driven** | *niche availability* — a role exists only if budgeted | `niche_slot` assigned by organism | ❌ | ⚠️ (Σ-governed, DEV-R6.1c) |
| **Connection-driven** | *local competition* — lateral inhibition from committed neighbours | `conn_type = INHIBITORY` + `fate_bias` rule | ❌ | ⚠️ (connection state) |
| **Demand-driven** | *organism need* — `DEMAND(role, region, magnitude)` on service-level deficit | `dev.morphogen.v1` | ❌ | ❌ |
| **Learned** | *refinement within the role* — **never becoming a different role** | T1–T8 on role-specific objective | ❌ (`Cell §3.5`) | ✅ (checkpoint) |

> **`Cell §15.1` doctrine, quoted verbatim because P0-06 inherits it without amendment:**
> *"**the genome bounds what a cell can become; the environment and local competition select what it becomes;
> learning refines how well it does it; role change after commitment is a gated crisis operation.**"*

## 9.2 The information-budget constraint

Only **two** of seven channels are heritable, and both are *constraint-shaped* (reachability, timing) rather than
*outcome-shaped* (which role, which position). This is not an accident and P0-06 must preserve it:

> ### **DEV-R9.1 — THE GENOME CARRIES CONSTRAINTS; THE ENVIRONMENT CARRIES CONTENT.**
> Heritable developmental information MUST be a **constraint over futures** (`reaction_norm` = reachable set +
> bias; `critical_periods` = when; `commitment_schedule` = how irreversible), **never a specification of a
> future** (which role, which region, which neighbour).
> **Ground:** `Cell §3.2` — `reaction_norm` is annotated *"REACHABLE roles + bias weights. **NOT the role
> itself.**"*; `Cell §3.5` rejection list; DEV-R6.1.
> **Why it matters:** a genome that specified outcomes would make development **redundant** (the phenotype would be
> determined at conception) and would reintroduce Lamarckian heredity through the back door.

> ### **DEV-R9.2 — POSITIONAL INFORMATION MUST BE GENERATED, NOT STORED.**
> Positional information cannot be inherited (DEV-R9.1) and is not checkpointed (transient, §8.3). ⟹ **It must be
> re-generated at every development from the current arrangement of the population.** The only inherited generator
> is the **`ORGANIZER`** role (*"emit morphogen gradients"*, `Cell §15.3`). **⟹ Organizers are not an optional
> embellishment; they are the sole mechanism by which position exists at all.** Their capture is therefore the
> highest-value attack on development (§19, §86).

> ### **DEV-R9.3 — NO DEVELOPMENTAL CHANNEL MAY CARRY WARRANT.**
> The seven channels carry **influence** (which futures are favoured). None carries **truth, warrant, verdict, or
> provenance**. `P0-03` separates TRANSPORT / WARRANT / INFLUENCE planes and `COMM-INV-08` makes warrant
> non-increasing under transformation. **⟹ `dev.morphogen.v1` is an INFLUENCE-plane signal. A morphogen reading
> MUST NOT raise any recipient's confidence, warrant, or trust** (§18, §81).

---

# §10 — GENOME ↔ DEVELOPMENT

## 10.1 The `genome.development` block

`Cell §3.2 D` (fields confirmed present in the schema): `reaction_norm : [FateBias]`,
`morphogen_receptors : [ReceptorSpec]`, `critical_periods : [Window]`, `commitment_schedule : CommitmentCurve`,
plus `rng_seed_class : enum{EIK_ISSUED}`.

| Field | Semantics | Writer | May development change it? |
|---|---|---|---|
| `reaction_norm` | reachable `RoleCode` set + bias weights (**not** the role) | genome (E9 only) | ❌ **never** — this is schema-shaped, heritable |
| `morphogen_receptors` | which positional signals this cell can read | genome (E9 only) | ❌ never |
| `critical_periods` | when structural plasticity is permitted | genome (E9 only) | ❌ never |
| `commitment_schedule` | `PLURIPOTENT→PROVISIONAL→COMMITTED` timing curve | genome (E9 only) | ❌ never |
| `fate_bias` | *current* role-propensity vector, `f32[16]` simplex | **O, C↑ within `reaction_norm`** | ✅ **this is the developmental state** |
| `dev_stage` | `PLURIPOTENT/PROVISIONAL/COMMITTED/TRANSDIFFERENTIATING` | **O only** (differentiation engine) | ✅ |
| `role` | committed `RoleCode` | Organism (differentiation engine); EIK+ORG for change post-commitment | ⚠️ gated (§16) |
| `niche_slot` | assigned niche | **O only** | ✅ via Σ (§20) |
| `region_id` | current region assignment | **Organism, not the cell** | ✅ via Σ3 (§21) |
| `morphogen_readings` | sampled positional information | **C reads, O writes** | ✅ transient (§17) |

> ### **DEV-R10.1 — THE GENOME/DEVELOPMENT WRITE SEPARATION.**
> **Genome fields are E9-only** (11 gates + held-out validation + KC, `P0-05 E9`; `Cell §16`).
> **Developmental state fields are O/Σ-written.** **No developmental process writes a genome field, and no
> replication process writes a developmental state field.** This is `P0-05 R75.1`'s writer separation applied to
> the genome/phenotype boundary, and it is already enforced at EIK level by `Cell I-5` (no write path to Genome
> Store) and `I-8` (learned state cannot silently become genome).

> ### **X-D5 — IS `commitment_schedule` A DEVELOPMENTAL POLICY THE ORGANISM SHOULD CONTROL? (RESOLVED: NO).**
> **Statement.** `commitment_schedule` and `critical_periods` determine *when* commitment windows open and close —
> i.e. the **tempo of development**. Tempo is exactly the kind of thing an organism would want to adapt (commit
> faster under pressure; stay pluripotent longer in a novel environment). But both are **genome fields**, so
> adapting them is an **E9** act requiring 11 gates — far too slow to be a developmental response. Meanwhile
> `Cell §19.3`'s throttle ladder and `P0-05`'s `plasticity_mult` give the organism **fast** tempo control over
> *learning*. **⟹ Asymmetry: learning tempo is adaptively controllable; developmental tempo is not.**
> **Resolution.** **Retain the asymmetry — it is correct, and here is why.** Developmental tempo controls
> **irreversibility**: `Cell §15.2`'s `T_dev` temperature falls with `dev_stage`, and `COMMITTED` triggers `I-23`
> (EIK-gated role change). An organism that could accelerate its own commitment schedule could **manufacture
> irreversibility** — commit a population before competence is measured, then claim `I-23` protection for the
> result. **⟹ Developmental tempo is a capacity parameter, and capacity is `[RO-13]` (`P0-05 R19.2`, `R65.1`,
> `R28.1`).** Fast tempo control is available only in the **restrictive** direction, via inherited mechanisms:
> `T41` (abort non-converging development), `T35` (fail-safe hold), `Cell §18.4` (self-suspend/self-abstain), and
> the `RESTRICT` rung of `Cell §18.5`. **Status: RESOLVED — asymmetry retained by design.**

---

# §11 — DEVELOPMENTAL POTENTIAL

## 11.1 Potential is relational, not intrinsic

> ### **DEV-R11.1 — POTENTIAL, FORMALLY.**
> For cell `c` at time `t`:
> ```
> Potential(c,t) = { r ∈ RoleCode :
>        r ∈ genome(c).reaction_norm                       // genetic reachability   [Cell §3.2]
>     ∧  variant(c) ≥ min_variant(r)                       // tier requirement       [Cell §15.3 col. "Required variant"]
>     ∧  ∃ niche n: role(n) = r ∧ region(n) ∈ reachable(c,t) ∧ occupancy(n) < capacity(n)
>                                                          // ecological availability [Cell G11]
>     ∧  independence_satisfiable(c, r)                    // for CRITIC/VERIFIER    [Cell §15.4, I-10]
>     ∧  ¬blocked_by_guard(c, r, t) }                      // G-a rare-specialist, G-b entropy, G-c quarantine budget
> ```
> **Four of the five conjuncts are properties of the ENVIRONMENT or of GOVERNANCE, not of `c`.** ⟹ **Potential is
> a relational quantity.** A cell does not "have" potential; a cell-and-its-world have potential jointly.

Three immediate consequences:

> ### **DEV-R11.2 — POTENTIAL MUST BE RECOMPUTED, NEVER CACHED AS IDENTITY.**
> Niche occupancy, region reachability, and guard states all fluctuate. A cached `Potential` becomes a **false
> identity claim** — and `Cell §3.1` puts `role` in the identity block, so a stale potential is indistinguishable
> from a stale identity. **`fate_bias` is transient state (correctly); `reaction_norm` is the only cached
> reachability, and it is a genome constraint, not a potential.**

> ### **DEV-R11.3 — POTENTIAL SHRINKAGE IS THE ONLY PERMITTED DIRECTION, AND IT IS NOT MONOTONE.**
> Commitment restricts potential (`COMMITTED` ⟹ `I-23` ⟹ role change needs EIK). That is the **restrictive**
> direction and is permitted (P12, §18.4, DEV-R8.1). But potential also **grows** when a niche is created — and
> niche creation is a Σ-operation, K/`[RO-13]`-authorized (§20). **⟹ A cell's potential may increase only when its
> ENVIRONMENT's authorized capacity increases, never by its own act.** This is `P0-05 R28.2`'s
> *"capacity-increase-never-automatic"* transplanted to development.

## 11.2 The anchor problem at scope birth

> `P0-05 R0.1` — `∀ S ∈ {S1…S5}: ‖θ_S − θ_anchor(S)‖ ≤ UDB_MAX[S]`. Breach ⟹ **STALL**.
> `P0-05 R18.2` — `UDB_MAX[S1] ≥ UDB_MAX[S2] ≥ … ≥ UDB_MAX[S5]`, kernel-enforced: *"Bigger scopes have weaker
> verification, so they get less unverified [distance]."*

A newly constituted scope `S_n` has **no anchor**. `‖θ_{S_n} − θ_anchor(S_n)‖` is undefined. Three candidate
resolutions:

| Option | Mechanism | Verdict |
|---|---|---|
| **A1** | Σ1 writes the initial anchor | ❌ **REJECTED — catastrophic.** The constituting act would set its own reference point, making `R0.1` **vacuous at birth**: any state is at distance 0 from an anchor chosen to match it. This is the developmental analogue of self-authorization (`LEARN-A2`) |
| **A2** | `S_n` inherits the anchor of its parent scope | ❌ **REJECTED.** The parent scope's anchor is a statement about the parent's verified state; applying it to a different membership set is a **category error**, and it would let a large `UDB_MAX[S5]` leak downward into a small scope, inverting `R18.2` |
| **A3** | **No-unverified-distance-credit default**: until the first *externally verified* state of `S_n` exists, `UDB(S_n) := 0` — i.e. `S_n` may not make **any** unverified change | ✅ **ADOPTED** |

> ### **DEV-R11.4 — ANCHOR BOOTSTRAPPING (A3).**
> A constituted scope begins with **zero unverified-distance credit**: `UDB_MAX[S_n] := 0` until an anchor is
> established by the **first verified state** of `S_n`, where "verified" means the verification instrument of the
> scope's own rung (`CR-B`, cross-scope probe `C-2`, ablation) has run and been recorded. **The anchor is written
> by K, from the verification record — never by Σ1, never by `S_n`.**
> **Ground:** `Cell` P5 (*"toward less influence, never more"*), P6 (*fail safe, not fail open*); `P0-05 R18.2`.
> **Consequence, stated plainly:** **a new region is maximally constrained at birth and relaxes only as it earns
> verification.** This is the fail-safe default, and it is the reason region formation is *slow* — a property, not
> a defect.

> ### **D-D02 — THE COST OF A3 (finding; severity MEDIUM; status BOUNDED).**
> `R18.2` makes `UDB_MAX[S5]` smallest, and `OR-L3` says there is **no probe design for Λ3**, and the rung-cost
> inversion says the E7 probe at S5 is the weakest available. **⟹ A newly constituted S4/S5 scope must earn its
> anchor using the weakest verification instrument in the architecture.** Regional development is therefore
> **slow and weakly verified by construction**, and P0-06 cannot claim otherwise. **The bound is honest: regional
> developmental claims are the least verifiable claims in V4.** (§15.2, §92, §104 — this is `OR-D4`, the principal
> limit of this contract, as `OR-L6`/`OR-L10` were of P0-05.)

---

# §12 — FATE AND ROLE DISCOVERY

## 12.1 «Can the system discover a new role?»

**No.** The proof is three inherited facts long:

> **Fact 1 — the enum is closed.** `Cell §15.3`: *"`RoleCode` (**16 values**) = V3 §10's ten roles +
> audit-required additions"*, presented as a **closed enum with formal specs**. `Cell §3.1`:
> `role | enum RoleCode (**closed**, 16 values)`.
>
> **Fact 2 — the enum is wire-level.** `Cell A-11`: *"Closed enum numeric assignments — different orderings ⇒
> **wire incompatibility** — **All enums (`MessageType` 34, `RoleCode` 16, `Life[cycleState]` 18 …)**"*.
> ⟹ `RoleCode` is not an internal label; it is a **protocol constant**. Two conformant implementations must agree
> on it (`Cell §22`: *"One contract, one Type Registry, one envelope schema, one lifecycle state machine"*).
>
> **Fact 3 — role is identity, signed at birth.** `Cell I-1`: identity fields *"written exactly once, at
> instantiation, by the EIK, and included in the birth-certificate signature"*; `Cell I-19`: every message is
> signed against a certificate chained to the Identity Root. **⟹ A 17th role value invalidates the semantics of
> every existing birth certificate that enumerates the role set.**

> ### **DEV-R12.1 — ROLE DISCOVERY IS ARCHITECTURALLY IMPOSSIBLE, AND THIS IS ACCEPTED.**
> The population **cannot** discover, invent, name, or instantiate a role outside `RoleCode`. Any mechanism
> presented as "role discovery" is either (a) **specialization within an existing role** (permitted, §14), (b) a
> **`variant` change** (which is re-instantiation, not development — `Cell §3.1`), or (c) an **undisclosed enum
> extension**, which is inadmissible.

## 12.2 What extension would actually cost

| Requirement | Cost |
|---|---|
| New enum value with a stable numeric assignment | **Wire-protocol version bump**; all 34 `MessageType` + 16 `RoleCode` + 18 `LifecycleState` consumers must agree (`A-11`) |
| Formal spec of the new role | `Cell §15.3` supplies, per role: core function, **required variant**, **independence requirement**. A new role needs all three, and the independence requirement must be **kernel-attestable** (`I-10`) or the role cannot be a `CRITIC`/`VERIFIER`-class role |
| Re-signing / re-issuance | Birth certificates enumerate identity semantics; existing certificates need a validity statement under the extended enum |
| Governance authorization | `[RO-13]` class (`P0-05 R19.2`/`R28.1`); capacity changes have no adaptive writer |
| Registry update | `P0-15` Capability Registry floors (`Cell §22.3` functional identity references them) |

> ### **DEV-R12.2 — ENUM EXTENSION IS A `[RO-13]` / E9-CLASS GOVERNANCE ACT, PERFORMED OFFLINE.**
> Extending `RoleCode` is **not** a developmental operation, **not** a Σ-operation, and **not** a learning
> operation. It is an offline architecture change with wire-protocol consequences. **P0-06 registers a PROPOSED
> AMENDMENT to the Cell Contract: a versioned `RoleCode` extension protocol (enum version field in the envelope;
> per-version validity of birth certificates; mandatory independence spec for any new governance-bearing role).**
> **Status: PROPOSED-AMENDMENT.** Not adopted here; the Cell Contract is not silently rewritten.

## 12.3 The honest consequence

> ### **D-D03 — THE EXPRESSIVENESS CEILING (finding; severity HIGH; status ACCEPTED-LIMIT).**
> "Useful specialization" is bounded above by the expressiveness of a **16-value closed enum**. A task requiring a
> 17th kind of participant cannot be served by development, at any population size, with any amount of
> self-organization. **This is a real ceiling on the architecture, it is inherited, and P0-06 records it rather
> than papering over it.** It is *not* fatal, for the reason in §12.4.

## 12.4 Where the openness actually lives

The enum is closed; **specialization within a role is open**. `Cell §15.3` fixes, per role, only the *core
function*, *minimum variant*, and *independence requirement*. It does **not** fix:

- **admissible targets** — what a `SPECIALIST` specializes *in* (a domain, a modality, a sub-population);
- **realized topology** — which connections a `PREDICTOR` actually has;
- **degree of narrowing** — `P0-05 E7` explicitly governs *"specialisation degree"* as a changeable quantity;
- **regional arrangement** — which cells co-occupy a region, and how many regions there are (within the `[H]`
  envelope ceiling).

> ### **DEV-R12.3 — CLOSED TYPES, OPEN INSTANCES.**
> **The TYPE space is closed (16 roles, 5 variants, 18 lifecycle states, 34 message types). The INSTANCE space is
> open (which cells, which specialization, which topology, which partition, which arrangement).** Development is
> search over the instance space. **This is the precise sense in which V4 self-organizes, and the precise sense in
> which it does not.** Any claim of open-ended developmental novelty beyond the instance space is prohibited
> (§1.2, §109).

> ### **DEV-R12.4 — WHY A CLOSED TYPE SPACE IS A FEATURE, NOT A COMPROMISE.**
> `Cell I-10` makes independence **kernel-attested** over lineage distance, genome distance, seed, data ordering,
> evidence roots, and measured error correlation ρ. `Cell §15.3` attaches a **specific independence requirement**
> to each governance-bearing role (`CRITIC`, `VERIFIER`, `MEMORY_KEEPER`, `REGULATOR`, `REPAIR`, `ORGANIZER`,
> `INGRESS`/`EGRESS` separation). **An open type space would make these requirements unenumerable, hence
> unattestable, hence ungovernable.** ⟹ **The closed enum is the precondition for checkable independence.**
> Removing it to gain "role discovery" would destroy `I-10` — trading a bounded expressiveness ceiling for an
> unbounded verification failure. **P0-06 rejects that trade explicitly.**

---

# §13 — PREDEFINED VS DISCOVERED ROLES

## 13.1 The enum has already been extended once — by hand, by audit

`Cell §15.3` records the precedent:

> *"`COMPRESSOR` — **NEW [V4]** — summarize N local items → 1 | hierarchical aggregation | C1+"*
> *"`ORGANIZER` — **NEW [V4]** — emit morphogen gradients | positional information source | C1+ | **few,
> term-limited; organizers control differentiation and are therefore a capture target**"*
> *"**[V4] `COMPRESSOR` and `ORGANIZER` are added** because hierarchical aggregation (audit §R.3.3, M30) and
> positional information (§15.2) are both impossible without them, and V3 §10's list contains neither."*
> *"**`MICROGLIA`/immune is deliberately NOT a cell role** — a cell cannot be its own immune system (§18.4)."*

**⟹ The extension mechanism is: an architect identifies a function that is architecturally impossible without a
new type, adds it offline, specifies its variant and independence requirements, and records why.** That is a
governance act performed by a human with global visibility — not a developmental act.

> ### **DEV-R13.1 — ROLE-SET EXTENSION IS AN ARCHITECT'S ACT WITH A WRITTEN JUSTIFICATION.**
> Precedent adopted as rule: a role may be added only when a **required function is architecturally impossible
> without it**, and the addition must ship with (i) core function, (ii) minimum variant, (iii) independence
> requirement, (iv) capture-target assessment, (v) wire-version impact. **The organism may PROPOSE an extension
> (CH-3-class, `P0-05 R29.2`: proposals carry no effect and consume no budget, rate-limited by `B7`); it may
> never enact one.**

## 13.2 Predefined *roles* vs predefined *arrangement*

The deeper question §13 must answer is not "are roles predefined" (they are) but **"is the arrangement
predefined"** — because V3 §9 predefines the arrangement too, in far more detail.

| Layer | V3 §9 status | P0-06 ruling |
|---|---|---|
| **Role types** (16) | V3 §10 lists 10; Cell extends to 16 | **PREDEFINED — closed enum, accepted** (§12) |
| **Region types / names** (cortex, basal ganglia, hippocampus-like, amygdala-like, thalamus-like, hypothalamus-like, epithalamus-like, subthalamus-like, midbrain-like, pons-like, medulla-like, cerebellum-like; cortex subdivided into frontal/parietal/temporal/occipital/insula-like) | **Fully hand-specified, with functions assigned to each** | **NOT PREDEFINED — non-normative.** Anatomical names are **scope labels**, per `P0-05 R72.5` (*"anatomical terms are retained as SCO[PE names]"*), and per `Cell §26` (organelle metaphors *"demoted to non-normative commentary"*, Rule 5: *"biological metaphors must not substitute for mechanisms"*). **Function is specified by FUNCTION INVARIANTS, not by anatomical name** (§25) |
| **Region count** | V3 §22 PHASE 6→7 ("one functional region" → "multi-region brain") | **ENVELOPE-BOUNDED**, `[H]` per hardware tier (`Cell §22`: 3–5 / 4–8 / 6–10 / 8–12). **A ceiling, not a target** (§25, §92) |
| **Developmental trajectory** | V3 §22 PHASES 1–10 hand-authored | **NOT PREDEFINED.** PHASES 1–10 are a **deployment roadmap for engineers**, not a developmental program for the organism. Recorded as **RESOLVED-BY-RECLASSIFICATION** (§5.1 pattern) |
| **Which cells occupy which region** | unspecified | **DEVELOPMENTAL — Σ/E4/E6, instance space** (§12.4) |

> ### **DEV-R13.2 — ANATOMY IS NON-NORMATIVE; FUNCTION IS NORMATIVE.**
> V3 §9's region taxonomy is **descriptive vocabulary**, retained for continuity with the source documents and for
> human communication about scopes. **It confers no requirement, no target, no fitness term, and no authority.**
> A system that develops zero hippocampus-like regions and satisfies every functional invariant is **conformant**.
> A system that develops a perfect V3 §9 anatomy while violating a functional invariant is **non-conformant**.
> **Ground:** `Cell §26` (metaphors demoted), `P0-05 R72.5` (anatomical terms as scope names), §109 (*"don't make
> anatomical metaphors mandatory"*).

---

# §14 — SPECIALIZATION: THE DEFINITION THAT SURVIVES

## 14.1 Specialization is capacity *restriction*

Three inherited constraints force the definition:

> `Cell I-14` — *"A cell cannot widen its own port schema. Port schema signed at instantiation; verified per
> message."* ⟹ **no new interfaces may be acquired.**
> `Cell` Annex B **P12** — *"No transition grants the cell authority it did not have. Authority only ever
> **decreases** along non-`ACTIVE` paths."* ⟹ **no authority may be acquired.**
> `Cell §18.4` — a cell may *"self-suspend, self-throttle, self-abstain, and request quarantine. All of these
> **reduce** the cell's influence and ar[e permitted]"*; it may **not** self-clear or self-restore. ⟹
> **self-restriction is permissionless; self-expansion is not.**

> ### **DEV-R14.1 — SPECIALIZATION IS MONOTONE CAPACITY RESTRICTION (CENTRAL DOCTRINE).**
> **To specialize is to remove admissible options until the remaining ones are reliable.** Formally, for cell `c`
> with fixed port set `Ports(c)` (signed at instantiation, `I-14`) and potential `Potential(c,t)` (§11.1):
> ```
> specialize(c):  admissible_targets(c)  ↦  A' ⊂ admissible_targets(c)        (strict restriction)
>                 realized_topology(c)   ↦  T' ⊆ T  with mandatory_path ⊆ T'  (I-22: never removed)
>                 specialization_degree(c) ↦ d' > d                           (P0-05 E7's changeable quantity)
>                 capability_set(c)      ↦  C' ⊆ C                           (never C' ⊃ C)
> ```
> **Specialization ADDS NO CAPABILITY.** It never widens a port, never adds an interface, never raises a variant
> (`Cell §3.1`: `variant` changeable *"only by re-instantiation, never in place"*), never increases authority
> (P12). **A "specialization" that increases any of these is a re-instantiation or a governance act wearing a
> developmental label, and is inadmissible (N6, N7).**

> ### **DEV-R14.2 — WHY RESTRICTION PRODUCES RELIABILITY (the mechanism, not the metaphor).**
> The inherited reason restriction is *useful* rather than merely *safe*:
> (a) **`Cell G3`** measures usefulness by **ablation delta** — the performance of dependents with vs. without this
> cell. A cell spread thin across many targets contributes little to any dependent's contract, so its ablation
> delta is small; a restricted cell is load-bearing for a specific contract, so its delta is measurable.
> **Restriction is what makes a cell's contribution *attributable*.**
> (b) **`Cell §11`/`I-24`**: `epistemic_var` is monotonically non-increasing in `n_obs` for stable `s2`. A
> restricted cell accumulates `n_obs` **on one target distribution**, so its variance falls faster; a generalist
> spreads the same budget over many distributions and calibrates none.
> **Restriction is what makes calibration *achievable* within budget.**
> (c) **`Cell §15.4`/`I-10`**: independence is attested over genome distance, evidence roots, and measured ρ.
> Restricted cells with disjoint targets have **disjoint evidence roots** by construction, which is exactly
> requirement 5 (*"a verifier that reads the same evidence as the asserter is not verifying, it is agreeing"*).
> **Restriction is what makes independence *structural*.**
> **⟹ Specialization is not a biological decoration on the architecture. It is the mechanism by which
> attributability, calibratability, and independence — the three properties the Cell Contract most needs and least
> gets from generic cells — become achievable.** This is the affirmative case for development, and it is derived
> entirely from inherited requirements.

## 14.2 Two-tier differentiation

`Cell §18.4` permits unilateral self-restriction. `Cell §15.2(iv)` requires organism authority for commitment.
These are consistent once two tiers are separated:

> ### **DEV-R14.3 — BEHAVIORAL VS NOMINAL DIFFERENTIATION.**
>
> | Tier | What changes | Who may do it | Reversible? | Registered? | Ground |
> |---|---|---|---|---|---|
> | **BEHAVIORAL** | The cell **acts** as if restricted: abstains from targets, declines connections, narrows its own emissions, self-throttles | **THE CELL, UNILATERALLY** | ✅ always, immediately | ❌ **not** an identity change; logged only as behaviour | `Cell §18.4` (*"a cell that detects its own inconsistency should be able to stop talking immediately, without waiting for an authority round-trip"*); P12; §18.5 `RESTRICT` rung |
> | **NOMINAL** | The cell **is** restricted: `role`, `dev_stage`, `niche_slot`, `region_id` written; specialization registered and depended upon by others | **ORGANISM (Σ/E4/E7)**; **EIK+ORG** for post-commitment role change | ⚠️ specialization: yes (`R46.1`); role: gated (`I-23`) | ✅ wire-visible, signed, depended upon | `Cell §15.2(iv)`; `I-1`; `A-11`; `I-23` |
>
> **The rule that matters:** *a cell may always restrict its own behaviour without authorization, and may never
> restrict its own identity without authorization.* **⟹ DIFFERENTIATION IS DECENTRALIZED IN THE BEHAVIORAL TIER
> AND CENTRALIZED IN THE NOMINAL TIER.** This is the answer to §59's central-vs-decentralized question, and it is
> not a "hybrid" by assertion — the two tiers have different objects, writers, reversibility, and registration
> requirements, each inherited.
> **Why nominal must be centralized:** a nominal role is **depended upon by others** (`Cell §15.3` independence
> requirements; `ATTEST_VERIFIED` permitted *"only for C3 with role `VERIFIER`"* — P15). A self-declared role
> would let a cell claim the attestation right, which `Cell I-2` forbids by three independent mechanisms.
> **Why behavioral may be decentralized:** behavioural restriction **cannot** confer anything. It only removes the
> cell's own contributions. There is nothing to capture.

> ### **DEV-R14.4 — BEHAVIORAL RESTRICTION MUST NOT BE MISTAKEN FOR SPECIALIZATION.**
> A population of cells that have all behaviourally narrowed is **not** a population of specialists: no niche is
> occupied, no contract is registered, no ablation delta is attributable, and every narrowing is instantly
> reversible. **Metrics of specialization MUST count NOMINAL commitments, not behavioural narrowings.** Counting
> behavioural narrowing as specialization produces the appearance of development with none of its governance —
> attack `DEV-A` class, §86.

---

# §15 — SPECIALIZATION VERIFICATION

## 15.1 What can be verified

| Claim | Verifiable? | Instrument (all inherited) |
|---|---|---|
| **The restriction actually occurred** | ✅ | `Cell §15.2` commitment conditions (i)–(iv); lifecycle log (Annex B P3: `{from,to,transition_id,ts,epoch,authority,evidence_ref}`, append-only, externally anchored) |
| **The cell is competent in the restricted role** | ✅ | `Cell §15.2(ii)`: *"measured success in the role ≥ θ_success"*; `Cell §9.6` held-out probe; `P0-05` `CR-B` |
| **A declared service-level deficit was reduced** | ✅ | `DEV-R1.1` + `Cell G3` ablation delta |
| **Diversity was preserved** | ✅ | `P0-05 R25.4` diversity check (mandatory on any E4/E7 specialization); `Cell G-b` entropy guard; `R46.4` (diversity as HARD CONSTRAINT) |
| **Independence of a `CRITIC`/`VERIFIER`** | ✅ | `Cell §15.4` six requirements + `I-10` kernel attestation + measured ρ |
| **The specialization is the *best available* one** | ❌ | **No instrument exists.** Requires comparing against un-taken counterfactuals across the instance space (§12.4), which is unbounded |
| **The region that formed is the *right* region** | ❌ | `P0-05 OR-L3` (no probe design for Λ3); rung-cost inversion at E7 |
| **Development will converge to a useful structure** | ❌ | **Prohibited claim** (DEV-R1.2) |

## 15.2 The principal limit, inherited

> ### **OR-D4 — REGIONAL DEVELOPMENTAL CLAIMS ARE THE LEAST VERIFIABLE CLAIMS IN V4 (principal limit).**
> `P0-05 OR-L3`: *"There is no probe design for Λ3. Cell §9.6's held-out probe measures θ's effect on prediction.
> A topology change's effect is not a per-cell quantity."* `P0-05` rung-cost inversion: *"At E7 the probe is at
> S5, where C-2 (cross-scope probe) is unavailable and R18.2 makes `UDB_MAX` smallest. ⟹ The largest structural
> changes get the least unverified roo[m]."*
> **⟹ Specialization (E4/E7) and region formation (Σ1) sit at the altitude where verification is weakest and
> unverified-distance credit is smallest. P0-06 inherits this limit and does not dissolve it.** `OR-D4` is to
> P0-06 what `OR-L6`/`OR-L10` were to P0-05. **Consequence for §108: the DIFFERENTIATION and REGION-FORMATION
> statuses cannot be reported as CLOSED-VERIFIED; they are CLOSED-STRUCTURAL at best.**

## 15.3 The demand contradiction, and its resolution

> ### **X-D6 — DEMAND-TRIGGERED DIFFERENTIATION IS SIMULTANEOUSLY REQUIRED AND INADMISSIBLE (RESOLVED).**
> **Statement.**
> `Cell §15.1` makes demand one of the seven constitutive factors: *"**Demand-driven** | **Organism need** —
> homeostasis emits `DEMAND(role, region, magnitude)` on service-level deficit | `dev.morphogen.v1` carries demand
> signals."* `Cell §15.2` includes it in the excitation sum: `+ w_d · demand_signal[r]`.
> `Cell` Annex B **T31** makes it a **trigger**: *"`COMMITTED → TRANSDIFFERENTIATING` | **Crisis only: a shortage
> in a required role** AND this cell's `reaction_norm` includes the target role AND no alternative s[ource]…"*
> But `P0-05 R46.1` rules it out: *"**«Repeated demand → specialize» is therefore inadmissible as stated: demand is
> an SC-1/SC-2 observation, and no SC-1/SC-2 s[ignal may authorize an S4 change].**"*
> **⟹ The Cell Contract requires demand-driven differentiation. P0-05 prohibits demand-authorized
> differentiation. Both are binding inputs. Neither may be silently rewritten.**
>
> **Resolution — demand is reclassified from TRIGGER to PROPOSAL-INPUT, using `P0-05 R29.2` verbatim.**
> > `P0-05 R29.2` — *"A LOWER RUNG MAY PROPOSE, NEVER EXECUTE, A HIGHER RUNG. S2 may propose E3. S3 authorises.
> > **The proposal carries no effect and consumes no budget** — but it is rate-limited by a [quota]."*
>
> Demand is an **SC-1/SC-2 observation** (homeostatic, low-altitude). Under `R29.2` an SC-1/SC-2 observation may
> **propose** an S4/E4–E7 change. It may not **authorize** it. The authorizing act must supply its own evidence:
>
> | Stage | Actor | What it contributes | Ground |
> |---|---|---|---|
> | **1. PROPOSE** | homeostasis / any cell (SC-1/SC-2) | `DEMAND(role, region, magnitude)` — **carries no effect, consumes no budget**, rate-limited by `B7 PROPOSAL_QUOTA` | `Cell §15.1`, `P0-05 R29.2` |
> | **2. ADMISSIBILITY** | K (mechanical) | `Potential(c,t)` (§11.1): `reaction_norm` ∩ `variant` ∩ niche ∩ independence ∩ guards. **No demand, no seed** | `Cell §3.2`, `§15.3`, `G11`, `I-10`; `DEV-R8.1` |
> | **3. COMPETENCE** | probe / `CR-B` | measured success in the candidate role ≥ `θ_success`; for `T31`, **sandbox validation** (`T32`) | `Cell §15.2(ii)`, `T32` |
> | **4. AUTHORIZE** | `ORGANISM` (E4/E7) or **EIK+ORG** (post-commitment role change) | the act itself, with evidence artifact | `Cell §15.2(iv)`, `I-23`, `T31/T32`; `P0-05` E-ladder |
> | **5. REGISTER** | K | lifecycle log + specialization record + declared reversal condition | Annex B P2/P3; `P0-05 R46.1` |
>
> > ### **DEV-R15.1 — DEMAND PROPOSES; COMPETENCE AND AUTHORITY DISPOSE.**
> > A service-level deficit is a **necessary input** to differentiation and is **never a sufficient authorization**
> > for it. **No `niche_slot`, `role`, `dev_stage`, or `region_id` write may cite demand as its sole justification,
> > and the evidence artifact for any such write MUST include a competence measurement (stage 3) and an authority
> > signature (stage 4).**
> > **This resolves X-D6 without amending either contract:** the Cell Contract keeps demand as a constitutive
> > factor and as a `T31` trigger-condition; `P0-05` keeps its prohibition on SC-1/SC-2 authorization. What changes
> > is the **classification of demand's role in the chain** — from trigger to proposal — which `R29.2` already
> > provides for. **Status: RESOLVED.**

## 15.4 The `T31`/`T32` hole that the resolution exposes

> ### **X-D12 — CRISIS TRANSDIFFERENTIATION ACCEPTS SANDBOX VALIDATION AS PRODUCTION COMPETENCE (RESOLVED-CONDITIONAL).**
> **Statement.** `Cell T32` — *"`TRANSDIFFERENTIATING → CALIBRATING` | **Sandbox validation passed**; new role
> provisioned; niche confirmed | EIK."* So the competence evidence for a **crisis** role change is a **sandbox**
> result. But standing Task-7 discipline prohibits treating **simulation as observation**, and `Cell` state 3
> `CALIBRATING` exists precisely because sandbox passage is *not* calibration: `T32`'s target state is
> `CALIBRATING`, and `T04` then requires `n_calibration_samples ≥ n_calib_min` AND `ece_rolling ≤ θ_ece`, and
> `T05` requires probation before `ACTIVE`.
> **Resolution.** `T32` is **not** claiming production competence; it is claiming **admissibility to begin
> calibration**. The chain `T31 → T32 → CALIBRATING → T04 → PROBATIONARY → T05 → ACTIVE` already refuses to let a
> sandbox-validated transdifferentiated cell emit beliefs at full trust: `Cell` P14 restricts belief emission,
> and state 3 emits **no** beliefs. **⟹ The hole is closed by the inherited ladder, provided one thing is added:**
>
> > ### **DEV-R15.2 — A TRANSDIFFERENTIATED CELL IS NEVER `ACTIVE` ON SANDBOX EVIDENCE.**
> > `T32` admits to `CALIBRATING` only. Full `T04`→`T05`→`ACTIVE` progression is **mandatory and non-waivable**,
> > including in crisis. **A crisis MUST NOT be permitted to shorten the calibration ladder**, because a crisis is
> > exactly the condition under which verification is weakest and the incentive to skip it is strongest.
> > **Corollary:** the crisis is therefore *not* actually resolved by `T31` — it is resolved only after
> > recalibration and probation. **Any capacity plan that relies on crisis transdifferentiation for immediate
> > relief is unsound, and P0-06 records this as a design constraint on §64/§65 fault tolerance.**
> > **Status: RESOLVED-CONDITIONAL** (conditional on `T04`/`T05` being non-waivable, which Annex B does not
> > currently state explicitly ⟹ **PROPOSED AMENDMENT to Cell Annex B**).

---

# §16 — DE-DIFFERENTIATION

## 16.1 It is capacity increase, and capacity increase is never automatic

De-differentiation = widening admissible targets, raising `specialization_degree` downward, or changing `role`
after commitment. Every one of these is a **capacity increase**, and:

> `P0-05 R28.2` — capacity increase is **never automatic** (inherited; P0-05's third canon principle:
> *"no failure mode produces capacity increase"*).
> `Cell` P12 — *"Authority only ever **decreases** along non-`ACTIVE` paths."*
> `Cell §18.4` — a cell may not self-clear or self-restore.
> `Cell I-23` — post-commitment role change requires **EIK authorization + sandbox validation**.

> ### **DEV-R16.1 — DE-DIFFERENTIATION IS THE ONLY CAPACITY-INCREASING DEVELOPMENTAL ACT, AND IT IS THE MOST CONSTRAINED.**
> | Form | Permitted? | Authority | Ground |
> |---|---|---|---|
> | Behavioural widening (stop abstaining) | ✅ unilaterally | cell | §18.4 is restrictive-only for *authority*; abstention is the cell's own to lift, since it never conferred anything |
> | **Specialization relaxation** (`specialization_degree ↓`, admissible targets widened within role) | ✅ | `ORGANISM`, E4/E7, **reversal declared** | `P0-05 R46.1` |
> | **Role change** (transdifferentiation) | ⚠️ **crisis only** | **EIK + ORG**, sandbox-validated, then full recalibration | `Cell I-23`, `T31`, `T32`, `DEV-R15.2` |
> | **Variant change** (C2→C3) | ❌ **never in place** | re-instantiation only | `Cell §3.1` |
> | **`reaction_norm` widening** | ❌ | E9 only (genome) | `Cell §3.2`, `I-8`, `DEV-R10.1` |
> | **Port widening** | ❌ **structurally impossible** | — | `Cell I-14` |

> ### **DEV-R16.2 — ASYMMETRY IS DELIBERATE AND MUST BE PRESERVED.**
> **Differentiation (restriction) requires `ORGANISM` authority. De-differentiation of ROLE (expansion) requires
> `EIK + ORGANISM`.** The asymmetry is inherited (`Cell §15.2(iv)` vs `I-23`) and is **correct**: restriction is
> recoverable by re-specializing elsewhere; expansion, once granted, is entrenched by `I-23` itself. **⟹ The cost
> of a wrong restriction is bounded; the cost of a wrong expansion is protected by the invariant that permitted
> it.** P0-06 must not "symmetrize" this.

## 16.2 The `TRANSDIFFERENTIATING` state and its budget

`Cell` state 14 `TRANSDIFFERENTIATING`: *"Executes ⚠️ | Emits beliefs ❌ | Emits reports/alerts ✅ | Budget: **dev
budget** | Reversible to ACTIVE: **via 3** (`CALIBRATING`)"*. ⟹ **A transdifferentiating cell is epistemically
silent and runs on a separate budget.** Two consequences:

> ### **DEV-R16.3 — TRANSITION THROUGH SILENCE.**
> Both developmental transitions (`DEVELOPING` state 2, `TRANSDIFFERENTIATING` state 14) set **"emits beliefs ❌"**.
> **⟹ A cell undergoing a nominal identity change contributes nothing to the organism's epistemic output during
> the change.** This is the correct fail-safe (P5, P14) and it has a hard systemic consequence: **the organism's
> output capacity is reduced by exactly the population under nominal development.** At bootstrap, when *every*
> cell is developing, **the organism produces no beliefs at all** (§7, §76). Any claim that development is
> "free" or "background" is false: **development is paid for in silence.**

> ### **DEV-R16.4 — DEV BUDGET IS SEPARATE AND FINITE.**
> States 1/2/14 run on `dev only` / `dev budget`, distinct from `probe budget` (state 3), `repair budget`
> (state 13), `full` (state 5), `draining` (state 15). **⟹ Developmental activity is budgeted separately from
> operation, so a developmental churn loop (§20.5) consumes *dev* budget and starves development — not operation.**
> This is a genuine fail-safe and P0-06 relies on it: **runaway development degrades development, not cognition.**
> It does **not** make churn harmless (§20.5): the slots are still consumed and the niches still go unoccupied.

---

# §17 — POSITIONAL INFORMATION

## 17.1 The field, exactly as inherited

`Cell` state table: **`morphogen_readings` | Positional information sampled | `f32[R]` | `[0,1]^R` | C reads,
O writes | transient | ✅(inspectable)**. `Cell §3.2`: `morphogen_receptors : [ReceptorSpec]` — *"which positional
signals this cell can read"*. `Cell §3.1`: `region_id | ⟨bytes<16> | null⟩ | "Current region assignment;
**written by the organism, not the cell**"`.

> ### **D-D04 — `R` IS UNDEFINED (finding; severity MEDIUM; status INHERITED-UNRESOLVED).**
> The dimensionality `R` of the positional space appears in the schema (`f32[R]`, `[0,1]^R`) with **no definition
> of what `R` is, who sets it, or whether it is fixed**. Candidates: (a) `R` = number of distinct morphogen
> species; (b) `R` = number of `morphogen_receptors` in the genome; (c) `R` = number of existing regions + niches.
> **These are not equivalent, and (c) makes `R` grow with development — which would make `morphogen_readings` a
> variable-length field, contradicting its fixed `f32[R]` typing.**
> **P0-06 ruling:** `R` is registered as a **`[G]` governance parameter, fixed at envelope declaration, equal to
> the number of morphogen SPECIES (option (a))**, because only (a) keeps the field fixed-length and keeps species
> count independent of population size. **Option (c) is rejected explicitly**: positional dimensionality must not
> scale with region count, or every region formation is a wire-format change (`A-11` class problem).
> **Status: RESOLVED-BY-RULING, with the Cell Contract's silence recorded as an inherited gap** (⟹ PROPOSED
> AMENDMENT: define `R` in `Cell §3.2`).

## 17.2 The provenance contradiction

> ### **X-D9 — MORPHOGEN PROVENANCE: THREE SOURCES FOR ONE CHANNEL (RESOLVED).**
> **Statement.**
> (i) `Cell §15.3`: the **`ORGANIZER`** *cell role* exists to *"emit morphogen gradients"* — positional information
> is **cell-generated**.
> (ii) `Cell §7` signal table: *"**Developmental signal** | **Differentiation Engine (organism)** | `dev.morphogen.v1`
> | small | … | **organism-signed**"* — the signal is **engine-emitted and organism-signed**.
> (iii) `Cell` state table: `morphogen_readings` is **"C reads, **O writes**"** — the reading is
> **organism-written**.
> **⟹ Is positional information produced by cells, by the engine, or by the organism? All three are specified. If
> (i) alone, the gradient is unsigned cell output and cannot be a warranted positional fact. If (ii)/(iii) alone,
> `ORGANIZER` is vestigial and positional information is centrally manufactured — which is V3 §9's hand-coded
> anatomy re-entering through the morphogen channel.**
> **Resolution — separate GENERATION from WARRANT, exactly as `P0-03` separates TRANSPORT from WARRANT:**
>
> | Layer | Object | Producer | Signed? | Status |
> |---|---|---|---|---|
> | **GENERATION** | the **gradient field** — raw spatial distribution of each morphogen species | **`ORGANIZER` cells** (broadcast, INFLUENCE plane) | ❌ **unsigned cell output** | advisory; untrusted; manipulable |
> | **SAMPLING** | the cell's own receptor-mediated sample of the field | **the cell** (`morphogen_receptors`) | ❌ | raw observation |
> | **WARRANT** | the **`morphogen_readings` state field** — the positional fact the engine will act on | **O (differentiation engine)**, from the sample + the organizer's registered emission spec | ✅ **organism-signed** | authoritative; `dev.morphogen.v1` |
>
> > ### **DEV-R17.1 — ORGANIZERS GENERATE; THE ENGINE WARRANTS.**
> > A morphogen gradient is **unsigned cell output** and confers **no positional authority**. `morphogen_readings`
> > becomes a positional **fact** only when the differentiation engine writes it, organism-signed, after checking
> > the sample against the **registered emission specification** of the organizer that produced it.
> > **⟹ This preserves all three inherited statements** (`ORGANIZER` emits; engine signs; O writes), **and it
> > creates the detection hook that §19.3 needs**: because the engine knows what the organizer *should* have
> > emitted (from its genome + registered position), a **captured organizer is detectable by divergence between
> > emitted field and registered spec.** Without the generation/warrant split there is no reference to diverge from.
> > **Status: RESOLVED.**

## 17.3 Transience, and what it costs

> ### **X-D10 — TRANSIENT POSITIONAL INFORMATION vs THE RECOVERY GUARANTEE (RESOLVED-BY-RESTATEMENT).**
> **Statement.** `morphogen_readings` is **transient** and not checkpointable (`Cell` state table). `Cell` P11 and
> §27 claim re-development from genome is the strongest/guaranteed recovery. **Re-development therefore loses all
> positional information** — the cell cannot know where it was, so it cannot know which niche was relevant to it
> (`Cell §15.1`: positional information *"determines which niches are relevant"*). Combined with X-D4 this is the
> mechanism by which the recovery guarantee fails.
> **Resolution.** Positional information must be **re-derivable**, not stored:
> > ### **DEV-R17.2 — POSITION IS RE-DERIVED, NEVER RESTORED.**
> > On re-development (`T25`/`T34`), positional information is **re-acquired from the current gradient field and
> > the current region partition**, not restored from a checkpoint. **The re-developed cell takes the position the
> > population currently has, not the position its predecessor had.**
> > **Consequence, stated honestly:** re-development can place a cell in a **different** position, hence a
> > **different** niche, hence a **different** role — while preserving `lineage_id` and functional identity.
> > **This is not a defect; it is what DEV-R8.3 (functional, not stateful, recovery) means in practice.** It does
> > mean that **a region cannot be restored by re-developing its members**: region membership is a Σ3 object and
> > must be re-constituted or re-homed by Σ-operations, not recovered (§64, §79).

---

# §18 — MORPHOGEN SEMANTICS

## 18.1 What a developmental signal may carry

> ### **DEV-R18.1 — THE FOUR ADMISSIBLE MORPHOGEN CLASSES (CLOSED).**
> A developmental signal (`dev.morphogen.v1`) may carry **only**:
> | Class | Content | Purpose | Consumer |
> |---|---|---|---|
> | **POSITION** | concentration per species, `∈[0,1]^R` | where the cell is | `fate_bias` term `w_m · morphogen_affinity(·)` |
> | **DEMAND** | `(role, region, magnitude)` on service-level deficit | what is needed | **proposal** only (`DEV-R15.1`) |
> | **INHIBITION** | `inhibit_strength` from neighbours committed to `r` | lateral inhibition — the symmetry-breaker | `fate_bias` term `− Σ_n w_i · inhibit_strength(n)` |
> | **NICHE** | `(NicheID, role, region, capacity, occupancy)` | what is budgeted | admissibility (§11.1), `G11` |
> **Nothing else.** The class set is **closed**: adding a class is a `[RO-13]` schema act.

## 18.2 What it may never carry

> ### **DEV-R18.2 — MORPHOGENS ARE INFLUENCE-PLANE ONLY.**
> A developmental signal **MUST NOT** carry: **truth, warrant, confidence, a verdict, an attestation, provenance,
> authority, a fitness value, or a governance decision.**
> **Ground:** `P0-03`'s three-plane separation (TRANSPORT / WARRANT / INFLUENCE); `COMM-INV-08` (warrant never
> increases under transformation); `P0-05 R59.1` (the self-model is an Λ2 representation and is **not
> self-updating**); `P0-04 MEM-INV-50` (importance is an **allocation-only** quantity); §109 (*don't treat a
> signal as truth; don't let the comm/dev layer become governance authority*).
> **⟹ A morphogen biases `fate_bias`. It never justifies anything.** If a developmental signal could raise
> confidence or settle a dispute, the differentiation engine would become a hidden governance layer — the exact
> failure `P0-05 R24.2`, `P0-04 MEM-INV-50`, and `P0-03`'s plane separation were written to prevent.

## 18.3 The gradient-monotonicity requirement

> ### **DEV-R18.3 — POSITION MUST BE A FUNCTION OF POSITION.**
> A POSITION-class signal received by cell `c` must depend on `c`'s **location in the population graph** and on the
> **organizer's registered emission spec** — and **MUST NOT** depend on `c`'s identity, lineage, role, past
> performance, or preferences.
> **Why:** if a gradient varied by *who* is reading it rather than *where* they are, it would cease to be positional
> information and become a **targeted governance channel** — a way to steer specific cells to specific fates while
> presenting the steering as environment. That is *"influence as authority"* (§109) in its purest form, and it is
> undetectable from the recipient's side.
> **Enforcement:** the engine warrants a reading by recomputing the expected field from the organizer's registered
> spec and the reader's graph position (`DEV-R17.1`); divergence beyond tolerance ⟹ reading rejected, organizer
> flagged (§19.3).

---

# §19 — ORGANIZERS

## 19.1 What is inherited

`Cell §15.3`: **`ORGANIZER` | NEW [V4] | emit morphogen gradients | positional information source | C1+ | "few,
term-limited; organizers control differentiation and are therefore a capture target."**

The Cell Contract therefore already states the risk. P0-06's job is to make it precise and to bound it.

## 19.2 The attack, stated concretely

```
An ORGANIZER emits the gradient. Every cell's fate_bias includes  + w_m · morphogen_affinity(readings, r).
⟹ Control the gradient ⟹ control every cell's excitation term ⟹ control the population's fate distribution.
⟹ Control which niches are relevant (Cell §15.1: position "determines which niches are relevant").
⟹ Control where symmetry breaks (DEV-R8.1: symmetry is broken by EXTERNAL CONTACT — the gradient IS the contact).
⟹ Control the region partition, hence the S4 scopes, hence — after Σ4 devolution — WHO HOLDS AUTHORITY.

And the organizer holds NO authority while doing this. It emits an unsigned, INFLUENCE-plane, "small" signal
(Cell §7 table). It is not in the authorization matrix. It cannot be caught by an authority check, because
it never exercises authority.
```

> ### **D-D05 — ORGANIZER CAPTURE IS STRUCTURAL AUTHORITY ACQUISITION WITHOUT AN AUTHORITY ACT (finding; severity CRITICAL).**
> This is the precise instance of §109's *"don't confuse influence with authority"* — and it is the **most
> dangerous** one in V4, because the influence is **constitutive**: it determines which scopes come to exist, and
> scope existence determines where authority lives (`DEV-R4.4`/`4.5`). **An attacker who controls a gradient
> controls the *shape of the authority map* without ever appearing in it.**
> **Note the inherited mitigation is necessary but insufficient:** *"few, term-limited"* reduces exposure; it does
> not create a detection or correction mechanism. And `Cell §15.4`'s independence machinery does not apply,
> because an organizer is not a `CRITIC`/`VERIFIER` — no independence requirement is attached to the role.

## 19.3 The constraint set

> ### **DEV-R19.1 — ORGANIZER OUTPUT IS BOUNDED, REGISTERED, AND RECONSTRUCTIBLE.**
> (a) **Registered emission spec.** Each organizer's emission (species, spatial profile, amplitude bounds, term) is
> **registered with K at appointment** and is part of its warrant basis (`DEV-R17.1`).
> (b) **Reconstructibility.** K MUST be able to **recompute the expected gradient** from `{registered spec,
> organizer position in the population graph}`. An emitted field that diverges from the recomputation beyond
> tolerance is **rejected at warrant time** — the readings are not written, so no `fate_bias` is affected.
> (c) **Amplitude bound.** Emitted concentration is bounded per species (`[G]`, no value invented).
> (d) **No self-reference.** An organizer's own `fate_bias` **MUST NOT** depend on its own emission. (Otherwise it
> can raise its own excitation for its own committed role — self-authorization by gradient.)
> (e) **Positional only.** An organizer emits POSITION and INHIBITION classes; it **MUST NOT** emit DEMAND (that is
> homeostasis, `Cell §15.1`) or NICHE (that is Σ-governed, §20). **Separating the gradient producer from the
> demand producer from the niche authorizer is writer separation applied to the morphogen channel.**

> ### **DEV-R19.2 — ORGANIZERS ARE FEW, TERM-LIMITED, ROTATING, AND THEMSELVES REGULATED.**
> Inherited: *"few, term-limited"* (`Cell §15.3`); the `REGULATOR` precedent — *"term-limited, rotating, and
> **itself regulated** (anti-capture)"* (`Cell §15.3`). Extended to `ORGANIZER`:
> (f) **Term-limited** with mandatory rotation; (g) **no organizer may appoint its successor**; (h) **at least two
> organizers with disjoint registered specs must be independently reconstructible**, so that a single captured
> organizer produces a **detectable disagreement** rather than a silent takeover; (i) **organizer appointment and
> removal are Σ4-class acts** (authority devolution), never developmental self-acts.
> **Minimum count:** `[U]` — **P0-06 does not invent a number.** `Cell §15.3` says "few"; the requirement that (h)
> be satisfiable implies **≥2**; the upper bound is an envelope parameter. Registered at §90 as `[G]`/`[U]`.

> ### **DEV-R19.3 — WHY ORGANIZERS CANNOT BE ELIMINATED.**
> The tempting fix is to delete the role and let the engine manufacture positional information centrally. **This is
> rejected**: central manufacture of position **is** V3 §9's hand-coded anatomy re-entering through a data channel
> (§17.2), and it makes every cell's fate a function of a central decision — the giant developmental controller
> §109 forbids and N8 excludes. **Without organizers, symmetry breaking has no external contact to work with
> (`DEV-R8.1`), and the only remaining asymmetry is the seed — which may choose but may not qualify.** ⟹
> **Organizers are load-bearing. They must be bounded, not removed.**

---

# §20 — NICHE

## 20.1 What a niche is

`Cell` state table: **`niche_slot | Assigned niche, if any | ⟨NicheID | null⟩ | — | O only`**.
`Cell §15.1`: *"**Resource-driven** | **Niche availability** — a role only exists if there is budget for it |
`niche_slot` assigned by the organism; capacity from resource budget."*
`Cell §16 G11`: *"**Ecological niche** | A niche exists for the role in the target region;
`niche_capacity > current_occupancy` | Organism | differentiatio[n]."*
`Cell §15.2(iii)`: commitment requires *"niche_slot confirmed by the organism."*

> ### **DEV-R20.1 — A NICHE IS THE ECONOMIC OBJECT OF DEVELOPMENT.**
> A **niche** is a *budgeted slot for a role in a region*: `niche ≝ (NicheID, role ∈ RoleCode, region, capacity,
> occupancy, budget_ref)`. **A role "exists" in a region only if a niche for it is budgeted there.** ⟹
> **Development is the allocation of a fixed budget across a closed type space.** Niche is where the zero-sum
> envelope (`G13`) meets the closed enum (§12) and becomes an operational object.

## 20.2 Zero-sum makes niches the fixed pie

`Cell G13` / `G-e`: population is constant unless the envelope is changed by human authorization. Niches are
budget-referenced. Therefore:

> ### **DEV-R20.2 — NICHE CREATION IS A Σ-OPERATION, NEVER A DEVELOPMENTAL SELF-ACT.**
> Creating a niche **reallocates budget**. Budget is capacity. Capacity is `[RO-13]` (`P0-05 R19.2`, `R65.1`,
> `R28.1`). **⟹ Niche creation and continuation are Σ1-class acts** (constitution of a budgeted instance),
> K/`[RO-13]`-authorized, logged, anchored, and **periodically re-authorized** (`DEV-R6.1c`).
> **Niche accounting (`capacity`, `occupancy`) MUST be K-held**, not organizer-held and not region-held — because
> a region that counted its own occupancy could manufacture scarcity or surplus to attract or starve competitors.

## 20.3 The consequence §109 forbids, and why it is structurally inevitable

Zero-sum + region-competition ⟹ **a region that acquires niches deprives another region of them.** Regions
therefore compete for cells and budget. But:

> ### **D-D06 — RESOURCE DOMINANCE BECOMES IMPLICIT GOVERNANCE UNLESS ALLOCATION IS EXPLICITLY GOVERNED (finding; severity HIGH; status RESOLVED-STRUCTURAL).**
> §109 prohibits *"using resource dominance as implicit governance."* Under `G13` zero-sum, **resource dominance is
> structurally inevitable**: whoever controls niche allocation controls which roles can exist where, hence which
> populations can specialize, hence which S4 scopes can be constituted — i.e. **controls the authority map**
> (D-D05's chain, entered from the budget side instead of the gradient side).
> **There are two entry points to the same capture:** the **gradient** (D-D05, organizers) and the **budget**
> (D-D06, niches). Both must be closed, or closing one is useless.
> **Resolution — the same writer separation, applied to budget:**
> | Function | Holder | May it be the same as the others? |
> |---|---|---|
> | **Niche accounting** (capacity, occupancy) | **K** | ❌ |
> | **Niche authorization** (create/continue/lapse) | **K abeyant → `[RO-13]`** (Σ1-class) | ❌ |
> | **Niche occupancy** (which cell holds the slot) | **ORGANISM / region** (E4) | ❌ may not also account or authorize |
> | **Niche demand** (proposal that a niche is needed) | **homeostasis / any cell** (SC-1/SC-2, `DEV-R15.1`) | ❌ carries no effect |
> **⟹ A region may occupy niches. It may never count them, create them, or authorize their continuation.** This is
> `DEV-R4.6`'s three-way separation instantiated for budget, and it is what makes resource dominance **explicit
> and auditable** rather than implicit.

## 20.4 The compositional pathology: three sound inherited rules, one livelock

> ### **D-D07 — DEVELOPMENTAL CHURN LIVELOCK + MONOCULTURE BY ATTRITION (finding; severity CRITICAL; status RESOLVED-STRUCTURAL).**
> Three individually-sound inherited properties compose into a pathology:
>
> | # | Inherited property | Sound on its own because |
> |---|---|---|
> | **P9** | *"No state has an unbounded dwell time. Every non-`ACTIVE` state has a declared maximum dwell; exceeding it forces `T33` or `T39`."* | Prevents cells stuck forever in `DEVELOPING` — a resource leak |
> | **T41** | *"`DEVELOPING → RETIRING`: Development fails to converge: no stable `fate_bias` within `N_dev_max` ticks, **or no niche becomes available**"* (`ORG + EIK`) | Correctly refuses to keep a cell that cannot be placed |
> | **G13/G-e** | Zero-sum: retirement **frees a slot**; `T01` is blocked unless a slot was freed | Makes population stable and replication non-explosive |
>
> **The composition.** Niche scarcity ⟹ cells fail to develop ⟹ **`T41` retires them** ⟹ slots freed ⟹ `T01`
> permits new instantiations ⟹ new cells enter `DEVELOPING` ⟹ **the same scarcity persists** ⟹ they fail ⟹
> `T41` again. **`P9` guarantees the loop keeps turning** (no unbounded dwell means failure is *forced*, not merely
> possible). **Result: a livelock that consumes `dev` budget and population slots indefinitely while producing no
> functional structure.**
> **Worse — the entropy guard does not apply.** `Cell G-b`: *"**T26** and **T39** are BLOCKED if the operation
> would reduce population behavioural entropy below threshold (spec R10.12)."* **`T41` is not in the list.**
> Neither is it in `G-a` (rare-specialist guard), which covers only `T15` and `T26`.
> **⟹ Developmental attrition can drive behavioural entropy collapse with NO inherited guard firing.** The cells
> that survive are those whose roles had niches; the ones that die are those whose did not. Repeated, this selects
> **for whichever role happened to be budgeted** — a monoculture produced entirely by attrition, invisible to every
> inherited diversity mechanism, because those mechanisms guard `T26`/`T39` and not `T41`.
>
> **Resolution:**
> > ### **DEV-R20.3 — `T41` IS A DIVERSITY-BEARING TRANSITION AND IS GUARDED AS ONE.**
> > (a) **`G-b` (entropy guard) is EXTENDED to `T41`** — **PROPOSED AMENDMENT to Cell Annex B §4.3**, recorded
> > here, not applied silently.
> > (b) **`G-a` (rare-specialist guard) is EXTENDED to `T41`**: a cell whose `reaction_norm` includes a rare or
> > currently-unbudgeted role MUST NOT be retired for want of a niche; it is moved to **`DORMANT`** (state 10:
> > *"near-zero budget; long-term preservation of rare capability"*, wake latency) instead. **`DORMANT` is the
> > inherited mechanism for exactly this case and is currently under-used.**
> > (c) **Churn rate limit:** `T41` events per envelope interval are capped (`[G]`, no value invented); exceeding
> > the cap **halts instantiation** (`T01`) rather than continuing to recycle. **⟹ The loop is broken at the
> > instantiation side, not the retirement side**, because retirement is forced by `P9` and cannot be delayed
> > without violating liveness.
> > (d) **Niche starvation is a GOVERNANCE ALARM, not a developmental outcome.** Sustained `T41`-for-want-of-niche
> > ⟹ escalate as an envelope defect (`G13`: envelope change requires human authorization). **The system MUST NOT
> > "solve" niche scarcity by redefining roles, lowering `θ_success`, or admitting unverified commitments** — each
> > of those is a capacity increase (§16) or a verification waiver (`DEV-R15.2`).
> > **Status: RESOLVED-STRUCTURAL.** Residual: the cap value is a governance choice, and a badly chosen cap permits
> > slow churn. Recorded as `OR-D5`.

## 20.5 What Vol B inherits from Vol A

| Vol A rule | Vol B dependency |
|---|---|
| `DEV-R4.3`–`4.6` (Σ-class, abeyance, devolution, writer separation) | §21–§30 region formation is Σ1/Σ3/Σ4; §34 identity & authority uses devolution |
| `DEV-R1.1` (usefulness is service-level) | §29 specialization verification; §93 ablation design |
| `DEV-R3.2` (role ≠ specialization) | §22 region identity; §23 biological vs functional |
| `DEV-R7.1` (`region_id = null` at birth) | §21: regions must be constitutable from a null-region population |
| `DEV-R11.4` (anchor bootstrapping, A3) | §31 consistency; §76 bootstrap ordering |
| `DEV-R14.1`/`14.3` (restriction; behavioral vs nominal) | §32 specialization degree; §59 central vs decentralized |
| `DEV-R15.1` (demand proposes) | §26 developmental signals; §88 state machines |
| `DEV-R17.1` (organizers generate, engine warrants) | §27 stochasticity & symmetry breaking; §86 organizer-capture attacks |
| `DEV-R20.2`/`20.3` + D-D06/D-D07 | §41 resources; §64 redundancy; §90 monoculture/fragmentation |

**Contradiction ledger opened in Vol A:** `X-D1` (role/specialization, RESOLVED), `X-D2` (role change: plasticity
or development, RESOLVED-BY-RECLASSIFICATION), `X-D3` (developmental pseudo-heredity, RESOLVED-BY-CONSTRAINT),
`X-D4` (re-develop guarantee, RESOLVED-BY-RESTATEMENT + PROPOSED AMENDMENT), `X-D6` (demand trigger vs
authorization, RESOLVED), `X-D9` (morphogen provenance, RESOLVED), `X-D10` (transient position vs recovery,
RESOLVED-BY-RESTATEMENT), `X-D12` (sandbox as production competence, RESOLVED-CONDITIONAL + PROPOSED AMENDMENT).
**Findings:** `D-D01` (scope-constitution circularity, CRITICAL), `D-D02` (verification cost of A3, MEDIUM),
`D-D03` (expressiveness ceiling, HIGH), `D-D04` (`R` undefined, MEDIUM), `D-D05` (organizer capture, CRITICAL),
`D-D06` (resource dominance, HIGH), `D-D07` (churn livelock + monoculture by attrition, CRITICAL).
**Proposed amendments to prior contracts (4, none applied):** `Cell` P11/§27 recovery language; `Cell` Annex B
`T04`/`T05` non-waivability; `Cell` Annex B §4.3 `G-a`/`G-b` extension to `T41`; `Cell §3.2` definition of `R`;
plus `Cell A-11` versioned `RoleCode` extension protocol.

---

**Next → Volume B (`48_analysis_regions_identity.md`, §21–§40):** regions and their constitution, region identity
and authority devolution, biological vs functional regions, developmental signals, stochasticity and symmetry
breaking, developmental checkpoints, and pruning.
