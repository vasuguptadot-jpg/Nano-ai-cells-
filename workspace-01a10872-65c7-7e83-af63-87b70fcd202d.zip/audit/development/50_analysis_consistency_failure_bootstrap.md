# P0-06 — DIFFERENTIATION, DEVELOPMENT & SELF-ORGANIZATION
## Volume D — Consistency, Merge/Split/Failure, Redundancy, Fault Tolerance, Migration, Compression, Bootstrap, Branching, Fitness (§61–§80)

**Status:** ANALYSIS · adversarial · architecture-only
**Depends on:** Vols A–C
**Feeds:** Vol E (`51_analysis_attacks_invariants_authority.md`, §81–§92)

---

# §61 — CONSISTENCY BETWEEN STRUCTURE AND CELL STATE

## 61.1 The two records that must agree

Every structural fact is recorded **twice**, at two altitudes:

| Fact | Cell-side record | K-side record (§46) | Authoritative writer |
|---|---|---|---|
| membership | `region_id` (`Cell §3.1`) | `RegionRecord.membership` | **Organism** (cell field) / **K** (Σ-log) |
| role | `role` (`Cell §3.1`, identity block) | `StructuralProvenance.authorization` | **Organism**; EIK+ORG post-commitment (`I-23`) |
| niche | `niche_slot` (`O only`) | **K niche ledger** (`DEV-R20.2`) | **O** (cell field) / **K** (ledger) |
| stage | `dev_stage` (`O only`) | Σ-log + `dev_stage` machine (§88) | **O** |
| integrity | `integrity_checksum` — *"Rolling BLAKE3 over canonical serialization of protected identity+state blocks. **Cell computes, EIK verifies**"* | Anchor | **Cell computes / EIK verifies** |

**⟹ Dual recording is required** (a cell must act on its own `region_id` without a K round-trip) **and is therefore
a divergence risk.**

## 61.2 The inherited detector

`Cell` Annex B **T34** — *"`ANY → INSTANTIATED` (re-develop): **Integrity failure detected anywhere: checksum
mismatch, Merkle mismatch, `state_consistency_flag = MISMATCH`, identity/birth-[certificate mismatch]**."*
So a `state_consistency_flag` with value `MISMATCH` already exists, and its inherited response is **re-development**.

> ### **D-D21 — `T34` APPLIED TO A STRUCTURAL INCONSISTENCY AMPLIFIES IT (finding; severity CRITICAL; status RESOLVED).**
> **The loop.** Suppose `RegionRecord.membership` and the members' `region_id` fields disagree (a Σ3 re-homing
> partially applied, a lost write, a malicious `region_id` claim).
> ```
> 1. state_consistency_flag = MISMATCH on some cell c
> 2. T34 fires: ANY → INSTANTIATED (re-develop)      [Cell Annex B]
> 3. Re-development re-derives positional information from
>    "the current gradient field and the current region partition"   [DEV-R17.2]
> 4. The current region partition IS THE CORRUPT RECORD
> 5. ⟹ c re-develops against the corrupt partition, commits to a niche
>    implied by the corrupt record, and writes a FRESH, SELF-CONSISTENT
>    state that AGREES WITH THE CORRUPTION
> 6. The inconsistency is no longer detectable by checksum: c is now internally
>    consistent with a wrong structure.
> ```
> **⟹ The inherited recovery mechanism converts a detectable inconsistency into an undetectable one.** This is the
> developmental form of `P0-04`'s prohibition on rewriting historical evidence, arrived at by accident: the *evidence
> of the mismatch* is destroyed by the *repair*.
> **Resolution:**
> > ### **DEV-R61.1 — TWO CLASSES OF INCONSISTENCY, TWO RESPONSES, AND `T34` IS FORBIDDEN FOR THE SECOND.**
> > | Class | Examples | Response | Authority |
> > |---|---|---|---|
> > | **I-a CELL-LOCAL** | checksum mismatch, Merkle mismatch, birth-certificate mismatch, K-only field tampering (`Cell I-13`), port-schema widening (`I-14`) | **`T34` re-develop** — correct, because the genome is intact and the cell's own state is the corrupt object | EIK |
> > | **I-b STRUCTURAL** | `region_id` vs `membership` divergence; `niche_slot` vs K ledger divergence; `role` vs Σ-log divergence; `dev_stage` vs §88 machine divergence; boundary not enumerated (`DEV-R23.1`) | **QUIESCE, DO NOT RE-DEVELOP.** Cell moves to **fail-safe hold** (`Cell T35` pattern: *"cease belief emission, hold state, no learning, no connection changes"*), and **K reconciles the two records from the anchored Σ-log** | **K** |
> >
> > **Why quiesce rather than repair-in-place:** the cell cannot know which record is wrong, and neither record is
> > self-authenticating. **The anchored Σ-log is the only externally-validated source** (`DEV-R44.3`, `Cell T28`:
> > *"Archive hash anchored externally"*), so reconciliation must be K's act, from the log, **while the cell
> > contributes nothing.** `Cell` P5/P6 supply the pattern: fail **safe**, not open.
> > **Why `T34` is forbidden for I-b:** step 3–5 above. **Re-development reads the structure it is supposed to be
> > repairing.**
> > **Status: RESOLVED.** Corollary recorded as **PROPOSED AMENDMENT to `Cell` Annex B `T34`**: `T34`'s trigger list
> > must exclude structural-record divergence, which requires a distinct response.

> ### **DEV-R61.2 — THE Σ-LOG IS THE SOLE RECONCILIATION SOURCE.**
> Where cell-side and K-side records disagree, **the anchored Σ-log wins, unconditionally.** Not the cell's
> checksum (which the cell computes — `Cell §3.1`), not the region's record (which the region may have influenced via
> E4), not majority vote among members (which would make consistency a consensus property, and `P0-03` forbids
> treating *"consensus as independent evidence"*). **⟹ One writer, one anchor, one truth for structure.** This is
> `DEV-R46.1`'s store, exercised.

## 61.3 What consistency does NOT require

> ### **DEV-R61.3 — NO GLOBAL SYNCHRONOUS CONSISTENCY.**
> `P0-03` discipline: *"DO NOT require perfect global sync."* `P0-04`: no global strong consistency mandate.
> **⟹ P0-06 requires:** (a) **eventual** agreement between cell-side and K-side records, bounded by a declared
> reconciliation interval (`[G]`, no value invented); (b) **quiescence** of any cell whose records disagree, so that
> divergence never produces *action* on a wrong structure; (c) **no** requirement that all cells agree at an
> instant. **(b) is what makes (a) safe**: a divergent cell that cannot act cannot cause damage while reconciliation
> is pending. **Strong consistency is bought with availability; quiescence-on-divergence buys the same safety
> without the coordination cost** — and at `Cell §22`'s cluster tier (10⁶–10⁷ cells) the coordination cost of strong
> structural consistency is prohibitive (`DEV-R59.1`).

---

# §62 — STRUCTURAL MONITORING

> ### **DEV-R62.1 — MONITORS OBSERVE CORRELATION, NEVER CONTENT.**
> `P0-05 §63`'s pattern, inherited: monitors *"observe cross-scope correlation of stall/verdict/envelope states
> without observ[ing content]"*. Applied to development, K7 (`DEV-R55.1`) monitors:
> | Monitor | Observes | Detects | Ground |
> |---|---|---|---|
> | **M-Σ1** **Churn** | `T41` rate per envelope interval | **D-D07** livelock | `DEV-R20.3(c)` |
> | **M-Σ2** **Entropy trend** | population behavioural entropy (`Cell R10.12`) | monoculture by attrition | `Cell G-b`, extended to `T41` |
> | **M-Σ3** **Sole-satisfier** | count of regions satisfying each FI | **D-D12** entrenchment; SPOF (`V3 §21`) | `DEV-R48.1(c)` |
> | **M-Σ4** **Anchor debt** | `UDB(S_n)` per scope vs `UDB_MAX[S_n]` | approaching STALL; laundering attempts | `P0-05 R0.1`, `DEV-R39.1` |
> | **M-Σ5** **Overlap drift** | Σ3 membership deltas vs Σ-tombstones | **`OR-D8`** gradual laundering | `DEV-R39.1(a)` |
> | **M-Σ6** **Organizer divergence** | emitted field vs registered spec | **D-D05**/EA-2 capture | `DEV-R19.1(b)`, `DEV-R51.2` |
> | **M-Σ7** **Niche ledger vs occupancy** | K ledger vs `niche_slot` fields | **D-D06** budget capture; I-b inconsistency | `DEV-R61.1` |
> | **M-Σ8** **Abeyance age** | open abeyances vs `max_open_duration` | **`OR-D1`** unbounded K power | `DEV-R27.4` |
> | **M-Σ9** **Demand/proposal ratio** | B7 consumption by class | demand flooding suppressing E9 proposals | `DEV-R42.1` |
>
> **⟹ Nine monitors, all structural, all K-side, none reading message content.** A monitor that read content would be
> a governance layer inspecting belief — prohibited by `P0-03` (*"DO NOT make EIK inspect every synaptic
> operation"*) and by `P0-05`'s discipline against hidden governance.

---

# §63 — REGION MERGE

## 63.1 What merge does to each component of the triple

`⟨M, F, A⟩` → merging `r₁ = ⟨M₁,F₁,A₁⟩` and `r₂ = ⟨M₂,F₂,A₂⟩` into `r' = ⟨M',F',A'⟩`:

| Component | Candidate rule | Verdict |
|---|---|---|
| **M'** | `M₁ ∪ M₂` | ✅ only if `mandatory_path_closure(M')` holds and density predicate still satisfied (`DEV-R21.2`) — **a union can fail the density test**, in which case it is not a region |
| **F'** | `F₁ ∪ F₂` | ⚠️ **Must be re-declared, not unioned.** A contract satisfied by `M₁` may not be satisfied by `M'` (different internal topology), and `Cell §22.3`'s functional identity is *"the set of **satisfied** functional contracts"* — satisfaction must be re-established, not inherited |
| **A'** | `A₁ ∪ A₂` | ❌ **FORBIDDEN** — see `DEV-R63.1` |
| **anchor / UDB** | either, or fresh | ❌ **FORBIDDEN** — see `DEV-R63.2` |

> ### **DEV-R63.1 — MERGE NEVER UNIONS AUTHORITY.**
> `A' ⊆ A₁ ∩ A₂` **by default.** Any rung in `A' \ (A₁ ∩ A₂)` requires **fresh Σ4 devolution from K**, with its own
> evidence and its own enumerated grant.
> **Proof of necessity.** Suppose `A₁ = {E0,E1,E4}` and `A₂ = {E0,E1,E4,E7}`. Union gives `r'` **E7** (change
> regional topology / specialization degree, blast radius *organism*, `POLICY(RO-13)`-class authority). **Every
> member of `M₁` — which never held E7 — is now inside a scope that holds it.** That is an authority increase for
> `M₁` effected by a merge, violating `Cell` P12 (*"No transition grants the cell authority it did not have"*),
> `DEV-R29.1` (no structural fact confers authority), and `P0-05 R29.1` (no batch authority). **⟹ Merge is an
> authority-CONCENTRATION event: the same rungs now cover more cells. Concentration without union is already a
> governance-relevant change, which is why merge is Σ2+Σ1-class (dissolve both, constitute the union) and requires
> K + `[RO-13]`.**

> ### **DEV-R63.2 — MERGE INHERITS THE WORST ANCHOR DEBT.**
> `UDB(r') := max(UDB(r₁), UDB(r₂))`, and `anchor(r') := ⊥` (requiring re-establishment) **unless** both anchors are
> compatible, in which case the **more constraining** one is retained.
> **Proof of necessity.** Otherwise merge is a **laundering route**: two regions, one near STALL, merge into a fresh
> scope with `UDB := 0` (`DEV-R11.4` A3). **This is D-D17's attack with Σ2+Σ1 replaced by merge**, and it is easier
> to execute because merge looks like consolidation rather than dissolution. `DEV-R39.1(a)`'s overlap test would
> catch it if the merge were implemented as dissolve+constitute; **implementing merge as a primitive operation
> without debt inheritance would bypass that test entirely.** ⟹ **Debt inheritance must be stated for merge
> explicitly, not derived from Σ-cycling rules.**

> ### **DEV-R63.3 — MERGE IS Σ2 ×2 THEN Σ1, AND IS CHARGED AS SUCH.**
> There is no "merge" primitive in the Σ-class. **Merge = `Σ2(r₁)` + `Σ2(r₂)` + `Σ1(r')` + `Σ4(A')`.** Consequences:
> (i) both Σ-tombstones are written (`DEV-R39.1(b)`), so the merge is permanently auditable; (ii) **B8 is charged
> for `Σ1(r')`** but **not** for the two Σ2 (`DEV-R42.2`); (iii) both `dissolution_cond`s must already exist
> (`DEV-R22.2`) and must be *executed* — the re-homing plan for `r₁`'s members is "into `r'`", which must be
> declared **at `r₁`'s constitution**, i.e. **before anyone knew `r₂` existed**. **⟹ A region can only merge into a
> successor it could not have anticipated, so its `dissolution_cond` must be generic ("re-home to a scope satisfying
> contracts ≈ F") rather than specific.** That is a real constraint on `DEV-R22.2` and is recorded as a refinement:
> **`dissolution_cond` specifies a CONTRACT-PRESERVATION requirement, not a named successor.**

---

# §64 — REGION SPLIT

> ### **DEV-R64.1 — SPLIT IS Σ1 ×2 THEN Σ2, WITH THREE NON-NEGOTIABLE CONDITIONS.**
> Splitting `r = ⟨M,F,A⟩` into `r₁ = ⟨M₁,F₁,A₁⟩`, `r₂ = ⟨M₂,F₂,A₂⟩` with `M₁ ⊎ M₂ = M`:
> **(a) BOTH children must independently satisfy `DEV-R21.2`.** In particular each needs a non-empty contract set
> with a **measurable ablation delta**. **A split where one half satisfies nothing is an AMPUTATION, not a split** —
> and amputation is `Σ2` on that half (dissolution + re-homing), which is a different operation with different
> evidence.
> **(b) Both children inherit the parent's anchor debt:** `UDB(r_i) := UDB(r)`, `anchor(r_i) := anchor(r)` restricted
> to `M_i` — **neither child starts at zero credit.**
> **(c) `A_i ⊆ A` for both.** No rung may appear in a child that the parent did not hold.
>
> **Proof of (b)'s necessity — split is the laundering route *par excellence*.** A region near STALL splits into two
> half-sized regions. Each has half the members, half the accumulated displacement, and — if A3's zero-credit default
> applied — **no anchor debt at all**. Repeat and any region can reset its `R0.1` debt by successive bisection, with
> each step looking like healthy hierarchical refinement (`Cell §22`'s tier table *rewards* depth: cluster
> *"Depth 5"*). **⟹ Without (b), `P0-05 R0.1` is defeatable by a mechanism that the architecture actively
> encourages.** This is the strongest form of D-D17 and is why `DEV-R39.1`'s debt-inheritance rule is stated over
> *membership and contract overlap* rather than over *`region_id` identity*.

> ### **D-D22 — FI SATISFACTION IS NOT SPLIT-CLOSED (finding; severity HIGH; status RESOLVED).**
> A contract satisfied by `M` need not be satisfied by `M₁` or `M₂`. Concrete: **FI-05 (independent verification)**
> requires `Cell §15.4`'s six conditions including **lineage distance ≥ `d_min`** and **disjoint `evidence_roots`**
> between verifier and asserter. Splitting a region along lineage lines can place all verifiers in `M₁` and all
> asserters in `M₂` — which *looks* like improved independence — or can place a verifier and its asserter in the
> same child, **destroying the `d_min` separation that the region boundary was maintaining.**
> **⟹ Splitting along the wrong axis silently destroys independence, and independence is kernel-attested only
> pairwise (`Cell I-10`), so the destruction is detectable only if K re-runs attestation after the split.**
> **Resolution:** **`DEV-R64.2` — a split MUST re-run `Cell §15.4` independence attestation for every
> verifier/asserter pair whose members are re-partitioned, BEFORE Σ4 devolution to either child.** A split that
> cannot satisfy FI-05 post-partition is inadmissible. **Same rule for FI-01 (ingress/egress separation): a split
> must not place `INGRESS` and `EGRESS` cells that were separated into a child where they are the only members of a
> sensorimotor loop** (`Cell §15.3`: separation *"prevents self-confirming sensorimotor loops"*).

---

# §65 — REGION FAILURE

## 65.1 What "failure" means

> ### **DEV-R65.1 — REGION FAILURE IS CONTRACT FAILURE, DETECTABLE WITHOUT THE COMPLEMENT.**
> `r` has failed iff some `F ∈ contracts(r)` is no longer satisfied, **and** the failure is detectable from
> observations internal to `M` or from the dependents' declared contracts — **not** from a global assessment.
> `DEV-R21.1.2` requires this property at constitution (*"degradation of `M` detectable without reference to `Mᶜ`"*);
> `DEV-R65.1` is the same property at failure time. **⟹ A region whose failure can only be diagnosed by global
> inspection was never a region — it fails `DEV-R21.2` retroactively, and that is itself a finding (M-Σ3).**

## 65.2 The response ladder

Inherited ladders, applied in order:

| Level | Inherited mechanism | Developmental application |
|---|---|---|
| **L0 OBSERVE** | `Cell §18.5` *"increase monitoring frequency; no functional change"* | raise M-Σ1…M-Σ9 sampling for `r` |
| **L1 THROTTLE** | `Cell §19.3` throttle ladder (*"deterministic, ordered, no crash"*); `Cell` state 8 | reduce `r`'s budget_ref draw; members self-throttle unilaterally (`Cell §18.4`) |
| **L2 RESTRICT** | `Cell §18.5` *"revoke specific permissions (lose `ATTEST_VERIFIED`, lose protected-memory write, lose `PROPOSE_REPLICATION`)"* | **revoke rungs from `A(r)`** — the developmental form of RESTRICT. **Revocation is restrictive ⟹ permitted without K** by `Cell` P12's direction rule; **but `DEV-R27.3` says devolution is irreversible except by dissolution** ⟹ **see `DEV-R65.2`** |
| **L3 QUARANTINE** | `Cell` states 11/12; **`Cell §17`: *"Quarantine budget cap — max fraction of cells/**regions** quarantined simultaneously, enforced off-substrate. Above the cap, escalation requ[ires OP]"*** | **regional quarantine exists and is capped**; `Cell G-c` blocks `T17`/`T19`/`T38` at the cap |
| **L4 DEGRADE / RE-HOME** | `P0-05 R66` degradation ladder; `Cell T33`/`T39` | Σ3 re-homing of members to surviving scopes |
| **L5 DISSOLVE** | **Σ2** | execute `dissolution_cond`; drain `mandatory_path` last (`Cell G-f`); release niches to K ledger |

> ### **DEV-R65.2 — RUNG REVOCATION IS THE ONE RETRACTION THAT DOES NOT REQUIRE DISSOLUTION.**
> `DEV-R27.3` makes Σ4 devolution irreversible except by Σ2. **That is too coarse for L2.** Resolution:
> **`devolved_authority` is a SET, and K may REMOVE elements from it (restrictive retraction) without dissolving the
> scope. K may never ADD elements except by fresh Σ4.**
> **Why this is consistent:** `Cell` P12's principle is directional — *"Authority only ever **decreases** along
> non-`ACTIVE` paths"* — and `Cell §18.5`'s RESTRICT rung already revokes specific permissions. **Irreversibility of
> devolution means K cannot *re-grant*; it never meant K cannot *revoke*.** `DEV-R27.3` is hereby **clarified**:
> *Σ4 is irreversible in the additive direction; retractive amendment is permitted and is the L2 instrument.*
> **⟹ This matters operationally: a failing region can be defanged without destroying it, which preserves lineage
> continuity, `mandatory_path`s, and the possibility of recovery — all of which Σ2 destroys.**

> ### **DEV-R65.3 — FAILURE MUST NOT PRODUCE CAPACITY INCREASE.**
> `P0-05`'s third canon principle, applied to development. Prohibited responses to regional failure:
> ❌ enlarging `A(r)` to let it "fix itself"; ❌ creating new niches for `r` without Σ1 authorization;
> ❌ waiving `θ_success` for `r`'s members; ❌ admitting `r`'s members to `ACTIVE` without `T04`/`T05`
> (`DEV-R15.2`); ❌ extending a critical period (`DEV-R37.3`); ❌ re-basing `r`'s anchor (`DEV-R44.4(d)`,
> `DEV-R39.1`).
> **⟹ Every admissible response to failure is restrictive or dissipative (throttle, restrict, quarantine, re-home,
> dissolve). None is expansive.** This is the single most important safety property of the developmental contract,
> and it is inherited rather than invented.

---

# §66 — REDUNDANCY

> ### **DEV-R66.1 — REDUNDANCY IS AN EPISTEMIC REQUIREMENT, NOT ONLY A RELIABILITY ONE.**
> `DEV-R48.1`: ablation delta is informative **only where a redundant alternative exists**. `V3 §21`:
> *"Single-point failure → redundancy + decentralization + graceful degradation."* `V3 §3`: *"Correlated failure →
> **independent strategies + redundant critics**."*
> **⟹ Combining these: without redundancy, a region's usefulness is UNMEASURABLE (`ablation_delta = UNSUPPORTED`),
> and an unmeasurable region is both unverifiable (D-D13) and a coercion vector (D-D12). Redundancy is therefore
> required for three independent reasons — fault tolerance, verification, and anti-coercion — and P0-06 treats the
> third as the binding one, because it is the only one that cannot be traded against cost.**

> ### **DEV-R66.2 — REDUNDANCY-MANDATORY FUNCTION INVARIANTS.**
> | FI | Redundancy requirement | Reason |
> |---|---|---|
> | **FI-05** independent verification | **≥2 satisfiers, pairwise independent per `Cell §15.4`** | Inherent: `Cell §15.3` *"redundant critics"*; one verifier is a SPOF for every attestation |
> | **FI-10** emergency core regulation | **K-held** ⟹ trivially outside the substrate | `Cell §18.4`, `I-21`; FI-10 is EXTERNAL (§31) |
> | **FI-01** ingress/egress separation | **≥1 each, disjoint** — separation *is* the redundancy | `Cell §15.3` |
> | **FI-02** routing | **≥2 OR declared degradation** | A sole router is a total SPOF for attention allocation and a trivial capture target (FI-02 is allocation-only per `MEM-INV-50`, so capture yields attention control) |
> | **FI-03** homeostasis | **≥2 OR declared degradation**; each `REGULATOR` *"term-limited, rotating, and itself regulated"* | `Cell §15.3` anti-capture |
> | **FI-04** positional information | **≥2 organizers with disjoint specs** | `DEV-R19.2(h)` — required for divergence detection |
> | **FI-06 / FI-07 / FI-08 / FI-09** | **≥1, with `dissolution_cond` declaring degradation behaviour** | Single satisfier permitted, but the SPOF must be **declared and alarmed** (M-Σ3), not silent |
>
> **⟹ Four FIs have hard redundancy minima (FI-01, FI-04, FI-05, FI-10); four have redundancy-or-declared-degradation
> (FI-02, FI-03, FI-06…FI-09).** The minima are **structural**, not numeric: "≥2 pairwise-independent" is a
> predicate, and no count beyond 2 is invented.

> ### **D-D23 — REDUNDANCY AND SPECIALIZATION COMPETE FOR THE SAME ZERO-SUM SLOTS (finding; severity HIGH; status BOUNDED).**
> `Cell G13` zero-sum ⟹ a redundant satisfier of FI-06 occupies a slot that a specialist in some other role does not.
> **⟹ Redundancy is purchased with specialization, and both are purchased from the same fixed `N`.** An envelope
> that is too small cannot have both: at `Cell §22`'s smartphone tier (~200 C2, *"flat hierarchy"*, no C4 ⟹ no
> region-core ⟹ D-D10), **four hard redundancy minima plus FI-02/03 degradation declarations may consume a large
> fraction of the population.**
> **Bound (not resolution):** (a) redundancy minima are **structural predicates**, so they can be satisfied by
> *small* sets — two C3 verifiers satisfy FI-05, and `Cell §22` permits *"rare C3"* even on smartphone;
> (b) `Cell §22` already declares tier-appropriate degradation (*"shallow verification"* on laptop) — **⟹ the
> inherited tier table IS the redundancy/specialization trade schedule, and P0-06 adopts it as `[H]` rather than
> inventing one**; (c) where the trade cannot be made, the honest outcome is **envelope insufficiency**, escalated to
> governance (`DEV-R20.3(d)`), not silent degradation of an FI.
> **Status: BOUNDED.** Residual: the trade schedule's adequacy at each tier is a `P0-01` question (task-dependent)
> and is **UNRESOLVED** here.

---

# §67 — FAULT TOLERANCE

> ### **DEV-R67.1 — WHAT SURVIVES ANY REGION LOSS.**
> | Survives | Because |
> |---|---|
> | **FI-10 emergency core regulation** | K-held, EXTERNAL (§31), off-substrate (`Cell` Rule 19) |
> | **`mandatory_path` semantics** | `Cell I-22`/`G-f`: never removed; drained last and recorded for successors |
> | **The Σ-log, tombstones, provenance, anchors, niche ledger** | K-held structural store (§46), anchored externally (`Cell T28`) |
> | **Genomes** | Genome Store, off-cell, write-restricted (`Cell I-5`, `I-8`); *"the genome is off-cell and anchored"* (`Cell §27`) |
> | **Lineage records** | Lineage Store, permanent (`Cell §4.4`) |
> | **The FI set, scope definitions, rung definitions, Σ-rules, `RoleCode`** | Schema — `[RO-13]`/K, unreachable by any developmental act (N7, `DEV-R4.3`, `DEV-R28.2`) |
> | **Authority over unconstituted scopes** | K abeyance (`DEV-R4.4`), which does not depend on any region existing |
>
> **⟹ The fault-tolerance argument is not "regions are redundant." It is: everything that must survive region loss
> is either K-held or schema.** `V3 §21`'s *"Single-point failure → redundancy + decentralization + graceful
> degradation"* is satisfied by **off-substrate placement of the irreplaceable**, which is stronger than redundancy
> — a redundant pair on the same substrate shares a cause (`Cell §15.4`'s honest residual: *"genuinely independent
> cells can still be correlated by a **shared-cause failure** — a common library bug, a common data-source error, a
> common fitness-function flaw"*).

> ### **DEV-R67.2 — GRACEFUL DEGRADATION MUST BE PRE-DECLARED.**
> `Cell §22`'s tier table already declares degradation per tier (*"shallow verification"*, *"batched evolution"*).
> `DEV-R22.2` requires `dissolution_cond` at constitution. **⟹ Combined rule: every `RegionRecord` declares, at
> constitution, what happens to each of its contracts on its own dissolution — satisfied elsewhere, degraded to a
> named lower level, or WAIVED by governance.** An undeclared degradation is a silent capability loss, and
> `P0-04`/`P0-05` both prohibit silent loss (provenance completeness; `P0-05 R66` degradation ladder with
> *"entry/exit criteria"*).

> ### **DEV-R67.3 — DEVELOPMENT MUST CONTINUE DURING PARTIAL FAILURE.**
> `Cell T35`: on **EIK unavailability**, the cell fails safe — *"cease belief emission, hold state, **no learning, no
> connection changes**"*. **Note what `T35` does NOT say: it does not say "no development."** But development
> requires K for warrant, accounting, admissibility, authorization, anchoring, and guarding (K1–K6). **⟹ On K
> unavailability, ALL Σ-operations and all commitments are impossible, and the population freezes at its current
> structure.** That is the correct fail-safe, and P0-06 states it as a rule rather than leaving it implicit:
> **K unavailability ⟹ developmental freeze, not developmental fallback.** A "fallback" would mean cells or regions
> committing without authorization — `Cell §15.2(iv)`'s prohibition (*"The cell cannot self-commit"*), EA-1, and
> `LEARN-A2` simultaneously. **Behavioural self-restriction (L7) remains available during a freeze** (`Cell §18.4`
> needs no authority round-trip — that is its stated purpose), so the population can still *stop doing harm* while
> frozen. **⟹ The freeze is restrictive-only, which is exactly P5's requirement.**

---

# §68 — HARDWARE MIGRATION

> ### **DEV-R68.1 — MIGRATION IS Σ3-CLASS PLACEMENT RE-HOMING, NEVER Σ2+Σ1.**
> `DEV-R25.2`: functional identity survives migration; locality does not. **⟹ Moving a region between hosts is a
> placement change: `region_id`, `contracts`, `devolved_authority`, `anchor`, `UDB`, and `version` are all
> PRESERVED.** Dissolving and reconstituting to move a region would (i) launder the anchor (`D-D17`), (ii) break
> lineage continuity (`DEV-R26.1`), (iii) reset `version` history, and (iv) charge B8 for a non-constitutional act.
> **All four are prohibited.**

> ### **DEV-R68.2 — MIGRATION IS CONSTRAINED BY `mandatory_path` TOPOLOGY.**
> `Cell §22.3`: changing communication density is ✅ via *"locality-aware re-placement; **Routing invariants;
> mandatory paths preserved**"*. `Cell I-22`/`G-f`: mandatory paths are never removed or rerouted.
> **⟹ A region containing one endpoint of a `mandatory_path` whose other endpoint is immobile cannot be migrated
> without either (a) co-migrating the other endpoint, or (b) accepting a cross-host mandatory path.** Option (b) is
> permitted — `mandatory_path` is a **logical** invariant, not a locality one — but it changes the path's latency and
> therefore its behaviour.
> **Consequence, stated honestly:** **`mandatory_path` density is a constraint on placeability.** A region heavily
> bound by mandatory paths to immobile components (notably K-adjacent and FI-10 functions) is **effectively
> immobile**. This is another route to D-D12's entrenchment, entered from the placement side: **a region that
> accumulates mandatory paths to immobile components becomes unmigratable, hence un-dissolvable in practice, hence
> entrenched.** Recorded as **`OR-D10`**; mitigated by `DEV-R21.1.1` (mandatory paths must be region-internal at
> constitution) which bounds the initial exposure but not the accumulated one.

> ### **D-D24 — CROSS-TIER MIGRATION CHANGES ADMISSIBILITY (finding; severity HIGH; status RESOLVED).**
> `Cell §22`'s ceilings are **tier-indexed**: region count (3–5 / 4–8 / 6–10 / 8–12), depth (2–3 / 3 / 4 / 5),
> variants (C0–C2 / C0–C3 / C0–C4 / all), verification depth (*"shallow verification"* → *"full verification
> dept[h]"*).
> **⟹ Upward migration (laptop → cluster) is permissive: previously inadmissible structures become admissible.**
> **⟹ Downward migration (cluster → laptop) is DESTRUCTIVE: a constitution legal at 8–12 regions and depth 5 is
> illegal at 3–5 regions and depth 2–3.** Specifically:
> - Regions above the new ceiling must be **dissolved** (Σ2) or **merged** (§63) — and both require re-homing plans.
> - Depth above the new ceiling must be **flattened**, which breaks `parent_scope` chains and therefore breaks
>   `DEV-R26.1`'s version-reachability clause for nested regions.
> - **C4 cells cannot exist on a laptop tier (`C0–C3`)** ⟹ region-cores are impossible ⟹ **regional verification
>   authority cannot be held** (D-D10) ⟹ every region's `devolved_authority` must be reduced to self-local-verified
>   rungs.
> - Cell counts above the tier's capacity (~2,000 C2 on laptop vs ~10⁶–10⁷ on cluster) require **compression** (§71).
>
> **Resolution:**
> > ### **DEV-R68.3 — DOWNWARD MIGRATION IS A GOVERNANCE EVENT, NOT A RUNTIME EVENT.**
> > A tier decrease is an **envelope change** (`Cell G13`: envelope changes require human authorization) and
> > therefore triggers: (i) recomputation of all `[H]` ceilings; (ii) a **mandatory Σ2/merge plan** for every region
> > above the new ceiling, executed **before** migration completes; (iii) **reduction of `devolved_authority`**
> > wherever the new tier cannot support its verification (retractive, hence permitted under `DEV-R65.2`);
> > (iv) **compression** per §71; (v) **explicit FI-waiver declarations** for any FI that becomes unsatisfiable
> > (§73). **⟹ Downward migration cannot be a transparent runtime operation. An implementation that performs it
> > silently produces a population whose structure is illegal under its own envelope — and `DEV-R21.2` makes that an
> > integrity failure, so every affected region would quiesce (`DEV-R61.1` I-b), i.e. the organism would freeze.**
> > **The freeze is the correct behaviour; the silent migration is the bug.**
>
> **Upward migration** requires no dissolution but **does** require: recomputation of ceilings; and a rule that
> **newly admissible structure is not thereby authorized** — raising a ceiling does not devolve authority
> (`DEV-R29.1`: no structural fact confers authority). **⟹ An envelope increase creates *room*, not *permission*.**

> ### **DEV-R68.4 — MIGRATION CHANGES THE VALIDITY OF THE VERIFICATION INSTRUMENT.**
> `CR-B`, cross-scope probe `C-2`, and ablation all measure dependents' behaviour **with and without** the object,
> over a measurement window. **Migration changes latency, and latency changes what a window contains.** ⟹ An
> ablation delta measured before migration is **not** a valid measurement after it.
> **Rule:** **`DEV-R68.4` — cross-tier or cross-host migration invalidates prior `CR-B`/ablation evidence for the
> migrated scope, and the scope's anchor must be RE-ESTABLISHED (not reset) post-migration.**
> **Critical distinction:** re-establishment means running the instrument again and writing a **new** anchor from the
> new verification record (`DEV-R11.4`: anchors are written by K from verification records). It does **NOT** mean
> `UDB := 0`. **Accumulated debt survives migration; only the reference point is refreshed, and only by a fresh
> measurement.** Without this rule, migration is a laundering route (`D-D17`) that requires no Σ-operation at all —
> just a host change. **⟹ This is the subtlest of the four laundering routes (Σ-cycling, merge, split, migration)
> and the only one that involves no structural operation whatsoever.**

---

# §69 — PLACEMENT AND LOCALITY

> ### **DEV-R69.1 — PLACEMENT OPTIMIZES COST; IT NEVER DETERMINES STRUCTURE.**
> `Cell §30 P0-28` lists *"locality hints"* as a region-formation input. `DEV-R25.3` makes them advisory and makes
> independence dominate them. **⟹ The full rule: placement may minimize boundary traffic and latency, subject to
> (i) `Cell §15.4` independence requirements, (ii) `mandatory_path_closure`, (iii) FI separation constraints
> (FI-01, FI-05, FI-11), (iv) tier ceilings. Where locality and any of (i)–(iv) conflict, locality loses.**
> **The concrete trap:** locality optimization naturally co-locates high-traffic pairs. The highest-traffic pair in a
> verification architecture is **verifier and asserter** — they exchange claims and attestations constantly.
> **⟹ Naive locality optimization systematically co-locates verifiers with the cells they verify, degrading lineage
> distance, `evidence_roots` disjointness, and measured ρ — i.e. it systematically destroys FI-05.** This is not a
> hypothetical; it is what a cost-minimizing placer does. **`DEV-R25.3`'s dominance rule exists precisely to prevent
> it, and §86 records the attack.**

---

# §70 — COMPRESSION

> ### **DEV-R70.1 — THE INHERITED COMPRESSION REPERTOIRE.**
> `Cell §22.3`: *"**Compress** (fewer, cheaper cells) | ✅ | Downgrade variants via re-instantiation; merge cells;
> reduce connection density; quantize | [preserved by] **Functional contracts** at circuit and region level."*
> Plus: *"**Change precision** | ✅ | Kernel-directed quantization + **equivalence test** + `epistemic_var`
> recomputation"*; *"**Merge cells** | ⚠️ | §21.5; requires **contract preservation + knowledge extraction**"*;
> *"**Split cells** | ⚠️ | §21.5; **not a replication bypass (G13 applies)**"*; *"**Change memory representation** |
> ✅ | Tiering hot/warm/cold; format migration with schema versioning | **Provenance continuity; Merkle root
> preserved across format change**."*

> ### **DEV-R70.2 — COMPRESSION ORDER IS NORMATIVE.**
> Compression must proceed **least-destructive first**, because each step destroys a different kind of evidence:
> ```
> C-1  reduce connection density      → destroys topology evidence; reversible via E1 (additive)
> C-2  quantize precision             → requires equivalence test + epistemic_var recomputation  [Cell §22.3]
> C-3  tier memory hot→warm→cold      → preserves Merkle root and provenance                     [Cell §22.3]
> C-4  merge cells (N→1)              → requires contract preservation + knowledge extraction    [Cell §21.5]
> C-5  downgrade variants             → RE-INSTANTIATION (Cell §3.1: variant never changes in place)
>                                      ⟹ destroys the individual; lineage continues
> C-6  dissolve regions (Σ2)          → destroys the scope, its anchor, and its devolved authority
> C-7  reduce population (retirement) → terminal (Cell §4.4); requires T26/T27 protocol
> ```
> **⟹ C-5 and C-6 are not compressions of a thing; they are replacements and destructions respectively.** An
> implementation that reports "compressed 10⁶ cells to 2,000" by C-5/C-6 has **reconstituted** the organism, and
> `DEV-R26.1`'s version-reachability clause means the resulting regions are **new regions**, not compressed ones.
> **The claim must be reported as reconstitution, not compression.**

> ### **DEV-R70.3 — COMPRESSION MUST NOT WAIVE AN FI SILENTLY.**
> Each compression step must be accompanied by an **FI-satisfaction re-declaration**: for each of FI-01…FI-12, state
> whether it remains satisfied, by which `M`, or is **WAIVED**. **Waiver is a `[RO-13]` governance act, logged and
> anchored, never a runtime consequence.** **⟹ A compression that silently drops FI-05 (independent verification)
> has silently removed the organism's only defence against correlated failure (`V3 §3`) — and it would look like a
> successful resource optimization.**

---

# §71 — EXPANSION

> ### **DEV-R71.1 — EXPANSION IS ENVELOPE-GATED AND ORDER-INVERTED.**
> `Cell §22.3`: *"**Expand** | ✅ | Upgrade variants; split cells; increase density; **subject to G13**."* And
> `G13`/`G-e` require a freed slot for any new cell, with population constant absent envelope change.
> **⟹ Expansion proper requires an envelope increase (human authorization, `DEV-R43.1`).** Within a fixed envelope,
> "expansion" means only **reallocation** — more cells in one region, fewer in another (Σ3), or upgrading variants by
> re-instantiation (which is slot-neutral).
> **Order inversion:** compression proceeds least-destructive first (`DEV-R70.2`); **expansion must proceed
> most-verifiable first** — establish anchors and verification capability before adding structure, because
> `DEV-R11.4` gives a new scope zero unverified-distance credit and `OR-D4` makes regional verification the weakest
> available. **⟹ Add capacity to verify before adding capacity to act.** The inverse order produces a population
> with more structure than it can warrant, which is the definition of ungovernable emergence (§1.1).

---

# §72 — THE INHERITED `[U]`: FUNCTIONAL IDENTITY ACROSS A 50,000× CHANGE

`Cell §22.3` records, verbatim: *"**[U] UNRESOLVED:** whether functional identity can be *preserved* across a
50,000× population change, or only *approximated*. Compressing 10⁷ cells to 200 necessarily loses capability."*

> ### **X-D14 — THE 50,000× QUESTION IS MISPOSED (RESOLVED-BY-RECLASSIFICATION).**
> **Statement.** The inherited `[U]` asks whether functional identity survives a scale change. But functional
> identity is *"the set of **satisfied** functional contracts at circuit and region level, plus the lineage
> continuity, plus the **Capability Registry floors**"* (`Cell §22.3`). **Two of the three terms are
> scale-independent and one is task-dependent:**
> - **lineage continuity** — survives compression by `Cell §27`'s *"replace from lineage backup"*, provided
>   replacement proceeds through lineage (`DEV-R26.1`, D-D11). Scale-independent.
> - **the contract set** — a *set*, so it is preserved iff every member is still satisfied. Whether a member *can*
>   be satisfied at 200 cells depends on the contract, not on the number 200: FI-05 needs ≥2 pairwise-independent
>   verifiers (`DEV-R66.2`) — satisfiable at 200; `DEV-R21.1`'s `|M| ≥ 2` for verification authority — satisfiable;
>   depth-5 hierarchy — **not** satisfiable at 200 (`Cell §22`: smartphone is *"flat hierarchy"*).
> - **Capability Registry floors** — `P0-15`, and **task-dependent** (`P0-01`; `Cell §30`: Type Registry *"contents
>   task-dependent"*).
>
> **⟹ The question is not "does identity survive 50,000× compression?" It is "are the declared Registry floors
> satisfiable at the target scale?" — which is a `P0-01` question, answerable per task, and NOT answerable by P0-06.**
> **Resolution:**
> > ### **DEV-R72.1 — FUNCTIONAL IDENTITY IS PRESERVED IFF THE DECLARED CONTRACT SET AND REGISTRY FLOORS ARE
> > SATISFIABLE AT THE TARGET SCALE, AND EVERY UNSATISFIABLE ELEMENT IS EXPLICITLY WAIVED.**
> > (a) Recompute FI satisfaction at the target scale (`DEV-R70.3`).
> > (b) For each FI or Registry floor that is **not** satisfiable: governance issues an **explicit WAIVER**, logged
> > and anchored. **Silent loss is prohibited.**
> > (c) If lineage continuity cannot be maintained (e.g. C-5 re-instantiation at a scale where no backup exists),
> > the operation is **not a compression** — it is a **reconstitution**, and must be reported as one (`DEV-R70.2`).
> > (d) **A waiver of FI-05, FI-10, or FI-11 is not a compression decision; it is a decision to operate without
> > independent verification, without emergency regulation, or with self-immunity — each of which `V3 §3` and
> > `Cell §18.4` identify as a named AI failure mode.** **⟹ These three waivers MUST require OP (human)
> > authorization, following `Cell G-g`'s precedent (*"`T29` … requires **OP** authorization for C3+ and governance
> > roles"*).**
> **Status: RESOLVED-BY-RECLASSIFICATION.** The inherited `[U]` is closed on the P0-06 side (the criterion is now
> precise) and **handed to `P0-01`** on the task side (whether floors are satisfiable at a given scale is
> task-dependent). **P0-06 does not claim that 10⁷→200 preserves identity; it states exactly what would have to be
> true, and who must waive what if it is not.**

---

# §73 — BOOTSTRAP: THE ORDERING PROBLEM

## 73.1 The circularities to discharge

Seven distinct circular dependencies block a naive bootstrap:

| # | Circularity | Where | Discharged by |
|---|---|---|---|
| **BC-1** | Scope authority requires the scope | **D-D01** | K abeyance + Σ4 devolution (`DEV-R4.4`/`4.5`) |
| **BC-2** | The first verifier cannot be verified | **D-D19** | external evaluator (`P0-01`), then `CR-B` at S3, then C-2 at S4 |
| **BC-3** | Anchors require verified states; verified states require anchors | `DEV-R11.4` | A3: zero credit at birth; anchor written by K from the first verification record |
| **BC-4** | Niches require envelope authorization; envelope authorization requires a functioning organism to authorize for | `DEV-R20.2`, `G13` | **the initial niche set is an envelope declaration — a human/K act at `t=0`, not a developmental one** |
| **BC-5** | Competence requires probe budget; `DEVELOPING` has only `dev` budget | `DEV-R41.1`, `DEV-R16.4` | **ordering**: `DEVELOPING`→`PROVISIONAL` on stability+niche only (`Cell T03`), then `CALIBRATING` on probe budget, then commitment (§88) |
| **BC-6** | **Organizers emit the gradients that commitment needs; organizers are committed cells** | `Cell §15.3`, `§15.2`, `DEV-R36.1` | **§73.2 — the first symmetry break is ECONOMIC, not spatial** |
| **BC-7** | `P0-05 §28`'s matrix is indexed by scopes that do not exist at `t=0` | D-D01 corollary | Σ-class matrix (`DEV-R28.1`) is separate and K-indexed; `P0-05 §28` becomes referentially valid only after Σ1 |

## 73.2 BC-6, the deepest one

> ### **D-D25 — THE ORGANIZER BOOTSTRAP PARADOX (finding; severity CRITICAL; status RESOLVED).**
> **Statement.** `DEV-R36.1`: symmetry breaking requires an **external asymmetry**, and the primary one is the
> **positional gradient**. Gradients come from `ORGANIZER` cells (`Cell §15.3`, `DEV-R19.3`: *"organizers are
> load-bearing"*). **`ORGANIZER` is a `RoleCode` value**, so an organizer is a **committed** cell
> (`dev_stage = COMMITTED`, `role = ORGANIZER`). Commitment requires a stable `argmax fate_bias`
> (`Cell §15.2(i)`), which requires the excitation sum, whose `w_m` term requires `morphogen_readings` — **which do
> not exist until an organizer emits them.**
> **⟹ No organizer can be positioned, because positioning requires an organizer. And without an organizer there is
> no spatial asymmetry, so `DEV-R36.1` says the field cannot differentiate at all.**
> **Resolution — the first symmetry break is ECONOMIC, not spatial:**
> `Cell §15.2`'s excitation sum has **five** terms: `w_g` (genetic), `w_m` (positional), `w_d` (demand),
> `w_s` (success history), `w_n` (niche availability). **`DEV-R55.1` L1 already supplies the fail-safe branch:
> `m_c ← ⊥ ⟹ positional term contributes 0`.** So commitment can proceed on **four** terms. Of those four:
> - `w_n` **niche availability** is an external asymmetry that requires **no gradient** — it comes from the K niche
>   ledger (`DEV-R20.2`), whose initial contents are an envelope declaration (BC-4).
> - `w_g` **genetic reachability** differs across cells if their genomes differ (`reaction_norm` heterogeneity —
>   `DEV-R55.2`'s division-of-labour condition).
> - `w_d` demand and `w_s` success are initially absent/zero (no operation has occurred).
>
> > ### **DEV-R73.1 — THE FIRST SYMMETRY BREAK IS ECONOMIC; SPATIAL INFORMATION IS SECOND-ORDER.**
> > **Bootstrap differentiation proceeds on `w_g` (genetic heterogeneity) and `w_n` (envelope-declared niche
> > availability), with `w_m ≡ 0`.** Positional information enters **only after** the first organizers are committed
> > and appointed. **⟹ The ordering is:**
> > ```
> > t=0   envelope declares initial niche set (K/human)            [BC-4]
> >       ⟹ niche asymmetry exists; gradient does not
> >  1    cells commit on w_g + w_n, with w_m = 0                  [L1 fail-safe branch]
> >       admissibility: reaction_norm ∩ variant ∩ niche ∩ guards   [§11.1]
> >       competence: via T03 → CALIBRATING → probe budget          [BC-5]
> >  2    K appoints the first ORGANIZERs by Σ4-class act           [DEV-R19.2(i)]
> >       ⟹ appointment is an AUTHORITY act, not a gradient outcome
> >       ⟹ the first organizers are positioned BY K, not by position
> >  3    gradients exist ⟹ w_m becomes non-zero ⟹ subsequent
> >       differentiation is spatially grounded                    [DEV-R36.1]
> >  4    density cuts become measurable ⟹ Σ1 constitutes first S3  [DEV-R21.2]
> >  5    Σ4 devolves ⟹ E4/E6 available inside S3                   [DEV-R5.2]
> >  6    S3 groups + measurable ablation ⟹ Σ1 constitutes first S4
> >  7    Σ4 devolves S4 ⟹ P0-05 §28 matrix becomes referentially
> >       valid for its S4 row                                     [BC-7]
> >  8    P0-05 E4/E7 specialization operates normally
> > ```
> > **⟹ The paradox is resolved by observing that `Cell §15.2`'s five-term excitation sum is REDUNDANT by design:
> > any one external asymmetry suffices to break symmetry, and the niche ledger is available before the gradient
> > is.** The architecture already contained the escape; it was never stated. **Status: RESOLVED.**
> >
> > **Corollary (important, and a constraint on envelope design):** **the initial niche set must be heterogeneous.**
> > An envelope declaring one undifferentiated niche for `UNDIFFERENTIATED` cells produces `w_n` symmetry, `w_m ≡ 0`,
> > and — absent genetic heterogeneity — **no symmetry break at all**, which is `DEV-R36.2`'s admissible
> > no-differentiation outcome. **⟹ Bootstrap requires either genetic heterogeneity in `reaction_norm` or niche
> > heterogeneity in the envelope declaration, and P0-06 records this as a REQUIREMENT ON THE `t=0` ENVELOPE, not on
> > the organism.** It is the one thing development cannot supply for itself.

---

# §74 — BOOTSTRAP: WHAT MAY NOT HAPPEN

> ### **DEV-R74.1 — BOOTSTRAP PROHIBITIONS.**
> ❌ **Instantiating V3 §9's regions at `t=0`.** That answers §1's question by assuming it (`DEV-R7.2`). The
> anatomical taxonomy is non-normative (`DEV-R30.1`, `DEV-R32.1`).
> ❌ **Executing any E-rung before Σ4** (`DEV-R5.2`) — scope elevation, `LEARN-A5`.
> ❌ **Writing an anchor at Σ1** (`DEV-R11.4` A1) — makes `R0.1` vacuous at birth.
> ❌ **Committing without competence evidence** (`DEV-R15.1` stage 3; BC-5's ordering is mandatory).
> ❌ **Appointing organizers by gradient** — circular (D-D25); appointment is Σ4-class.
> ❌ **Creating niches developmentally** (`DEV-R20.2`) — the initial set is an envelope act (BC-4).
> ❌ **Granting `devolved_authority` by default** (`DEV-R27.1`) — enumeration is mandatory, and at bootstrap the
> enumerated set should be **minimal** (D-D08: no verification authority for `|M| < 2`).
> ❌ **Claiming the bootstrap succeeded** — `DEV-R49.1`: process is verifiable, quality is not. A completed bootstrap
> is one in which every act was authorized and logged; whether the resulting structure is good is `OR-D9`.
> ❌ **Seeding the population from a pre-developed snapshot** to "skip" bootstrap. This would import developed
> structure without provenance (`DEV-R44.3`), without anchors (`DEV-R11.4`), and without dissolution conditions
> (`DEV-R22.2`) — i.e. it would create exactly the entrenched, unauditable structure that Σ-class governance exists
> to prevent. **A snapshot restore is permitted only as `Cell §27`'s *"restore from last validated checkpoint"*,
> which carries its own provenance.**

---

# §75 — DEVELOPMENTAL BRANCHING

## 75.1 What branching is, and what it is not

A **developmental branch** is the parallel exploration of two or more candidate structures (partitions, commitment
assignments, subcircuit formations) with a later **join** that selects one and discards the rest.

> ### **DEV-R75.1 — BRANCHING IS A SANDBOX OPERATION, NOT A SUBSTRATE OPERATION.**
> `Cell G13` zero-sum ⟹ a branch that instantiates real cells must retire real cells elsewhere (`G-e`). **⟹
> Substrate branching competes directly with operation, and at any meaningful branch factor it consumes the
> population.** `Cell §16` already requires *"sandbox → validate"* before spawn (`V3 §4`: *"Replication: copy →
> mutate/recombine → **sandbox → validate** → spawn"*), and `Cell T32` accepts sandbox validation as admissibility
> evidence. **⟹ Branches are evaluated in sandbox; only the selected branch is constituted on the substrate by
> Σ-operations.**

> ### **DEV-R75.2 — SANDBOX SELECTION IS NOT PROMOTION.**
> `X-D12`/`DEV-R15.2`: sandbox results are **admissibility** evidence, never **production competence** evidence.
> **⟹ A branch that wins in sandbox is admitted to `Σ1` candidacy; its members still traverse
> `CALIBRATING → T04 → PROBATIONARY → T05 → ACTIVE`.** Branch promotion is therefore **slow**, and that is correct:
> **the join selects a candidate, it does not certify an outcome.**

> ### **DEV-R75.3 — THE RESERVED BRANCH (fourth occurrence of `DEV-R3.3`).**
> Every branch set MUST contain a **governance-reserved branch** — at minimum, the **null branch** (constitute
> nothing; leave the population undifferentiated). **Ground:** `DEV-R3.3`; `DEV-R36.2` (no-differentiation is
> admissible); `DEV-R1.2` (no guarantee of useful outcome). **⟹ A branching mechanism that must select a non-null
> branch is a mechanism that must produce structure whether or not structure is warranted — and that is the
> hard-coded pole (§1.1) implemented as a forced choice.** The null branch is what keeps branching honest.

> ### **DEV-R75.4 — BRANCHES ARE BUDGETED BY B8 AND BY SILENCE.**
> Each candidate branch that reaches Σ1 candidacy consumes **B8** (`DEV-R35.1`, non-accumulable). Each branch whose
> members are on the substrate consumes **silence** (`DEV-R16.3`, `DEV-R41.1`). **⟹ Branch factor is bounded by B8
> and by the organism's tolerance for output loss, and both bounds are `[G]`/envelope parameters with no values
> invented here.** A branching mechanism with unbounded factor is a B8 bypass, since sandbox evaluation is free
> while Σ1 candidacy is not — **so the bound must be on *candidacy*, not on sandbox exploration.** Sandbox
> exploration is bounded by `dev`/compute budget instead (`Cell §4.1.5`, `I-4`).

---

# §76 — THE FITNESS INTERACTION

## 76.1 The channel that must not exist

`P0-01 §14` defines FITNESS as a **13-component vector, `[RO-13]`** — governance-written, not adaptive.
`P0-03`: *"don't let comm-derived performance redefine fitness."* `P0-05`: same discipline for learning.
`Cell §16 G3`: *"Usefulness — contribution to circuit/region contract measured by **ablation delta**"* is a
**replication gate input**. `DEV-R1.1`: ablation delta is P0-06's **only** usefulness measure.

> ### **D-D26 — DEVELOPMENTAL FITNESS GAMING VIA INDISPENSABILITY (finding; severity CRITICAL; status RESOLVED).**
> **The channel.** `Cell G3`'s ablation delta feeds `Cell §16`'s replication gates. `DEV-R1.1` makes ablation delta
> the developmental usefulness measure. **⟹ A lineage whose members arrange themselves to be load-bearing — sole
> satisfiers of a contract, holders of `mandatory_path`s, maximal ablation delta — maximizes both (i) its
> replication eligibility and (ii) its governance leverage (D-D12: indispensable components resist dissolution).**
> **The same property buys reproductive advantage and coercive immunity.** And `DEV-R48.1` shows the measurement
> cannot distinguish them: for a sole satisfier, ablation delta is **maximal and uninformative**.
> **⟹ Left unclosed, development selects for indispensability, and indispensability is precisely the structure that
> cannot be governed.** This is `V3 §3`'s *"Reward hacking → multi-objective fitness + hard constraints"* reappearing
> at the structural level, where the hard constraints are weaker (`OR-D4`).
> **Resolution:**
> > ### **DEV-R76.1 — INDISPENSABILITY EARNS NOTHING.**
> > (a) **`ablation_delta = UNSUPPORTED` for a sole satisfier** (`DEV-R48.1(b)`) and **contributes ZERO to every
> > replication gate that consumes G3.** **⟹ You cannot gain replication eligibility by becoming irreplaceable.**
> > (b) **Sole-satisfier status is a governance ALARM** (M-Σ3, `DEV-R48.1(c)`), so the arrangement that would have
> > been rewarded is instead reported as a defect.
> > (c) **Where redundancy exists, ablation delta is computed against the redundant alternative**, so it measures
> > *marginal* contribution, not indispensability (`DEV-R48.1`).
> > (d) **`mandatory_path` accumulation is monitored** as an entrenchment indicator (`OR-D10`, `DEV-R68.2`), and a
> > region whose mandatory-path share exceeds a declared fraction fails `DEV-R21.2`'s independent-failure clause at
> > the next Σ-audit.
> > (e) **Development contributes NO fitness component** (`DEV-R41.3`). The 13-component vector is `[RO-13]`;
> > P0-06 adds nothing to it and reads nothing from it except through `P0-01`'s own gates.
> > **Status: RESOLVED.** Residual: a lineage can become *nearly*-sole-satisfier, keeping a token redundant
> > alternative alive to make the delta measurable. Detection requires the redundant alternative to be genuine,
> > which is `Cell §15.4`'s independence problem again — **recorded as `OR-D11`.**

> ### **DEV-R76.2 — FITNESS MAY NOT TRIGGER A DEVELOPMENTAL ACT.**
> A high or low fitness value is a **performance fact** about the organism under `P0-01`'s task suite. **It MUST NOT
> appear in:** `fate_bias` excitation (`Cell §15.2`'s five terms contain no fitness term — inherited correctly);
> admissibility (§11.1); Σ-admissibility (`DEV-R21.2`); branch selection (`DEV-R75.2`: sandbox validation, not
> fitness ranking); or authority (`DEV-R29.1`).
> **Ground:** §109 (*"don't confuse performance with legitimacy"*); `P0-03` (*"don't let comm-derived performance
> redefine fitness"* — and its converse); `Cell I-12` (*"A cell cannot set, change, or abandon its own
> objective"*).
> **⟹ Fitness selects LINEAGES (via `Cell §16`'s gates, E9). It does not select STRUCTURES.** Structure is selected
> by Σ-authorization against service-level deficits (`DEV-R1.1`). **Keeping these two selection processes on
> different objects, with different authorities and different timescales, is what prevents development from becoming
> evolution (§6) and prevents evolution from becoming a structural optimizer it cannot verify (`OR-D4`).**

---

# §77–§79 — CROSS-CUTTING CONSTRAINTS CARRIED INTO VOL E

> ### **DEV-R77.1 — EVERY IRREVERSIBLE ACT HAS A PRE-COMMITTED REVERSAL PLAN.**
> `DEV-R22.2` (`dissolution_cond`), `P0-05 R46.1` (declared reversal condition), `Cell G-f` (mandatory-path drain
> recorded for successors), `Cell T27`'s 7-step retirement protocol (*"NOTICE · DRAIN · EXTRACT · PROVISION ·
> ARCHIVE · TOMBSTONE · RELEASE"*). **⟹ The pattern is inherited and consistent: irreversibility is permitted only
> where the *plan for its consequences* was written while the act was still reversible.** P0-06 applies it to Σ2,
> Σ4, merge, split, and downward migration (`DEV-R68.3`).

> ### **DEV-R78.1 — NO DEVELOPMENTAL MECHANISM MAY BE ITS OWN WATCHDOG.**
> Instances: organizer spec may not be self-modified (`DEV-R51.2`); ablation may not be self-scheduled
> (`DEV-R48.3`); anchors may not be self-written (`DEV-R11.4`); niche occupancy may not be self-counted
> (`DEV-R20.2`); consistency may not be self-adjudicated (`DEV-R61.2`); `dev_stage` may not be self-committed
> (`Cell §15.2(iv)`); a region may not dissolve or constitute itself (`DEV-R27.2`); `REPAIR` *"may not repair
> itself"* (`Cell §15.3`); a cell *"cannot verify itself"* (`Cell §15.3`, `I-2`).
> **⟹ Nine independent instances of one principle, eight of them inherited. P0-06 adds the ninth (consistency
> adjudication) and states the principle:** **the writer of a structural fact may never be the validator of that
> fact.** This is `P0-05 R75.1`'s writer separation, and §85 tests it.

> ### **DEV-R79.1 — DEVELOPMENTAL TIME IS NOT WALL-CLOCK TIME.**
> `Cell §15.2` counts in **developmental ticks**; `Cell` `T03` counts `N_stable` **dev ticks**; `Cell` P9 bounds
> dwell in **epochs**; `Cell T36` uses `uptime_epochs`; `P0-02`/`Cell A-4` supply a **timebase service**.
> **⟹ Three clocks coexist: dev ticks, epochs, wall-clock.** A developmental rule stated in one and enforced in
> another is untestable. **P0-06's rule: `dev_stage` transitions and `fate_bias` stability are measured in DEV
> TICKS; dwell limits, quarantine maxima, and recalibration intervals are measured in EPOCHS; Σ-operation budgeting
> (B8) is measured per ENVELOPE INTERVAL.** Each is registered with its clock at §90. **Mixing them is a
> conformance defect**, because a cell could satisfy `N_stable` dev ticks in an arbitrarily short epoch span (or the
> reverse), making `T03` and P9 mutually unsatisfiable.

---

# §80 — VOLUME D LEDGER

## 80.1 Rules minted in Vol D

`DEV-R61.1`–`61.3` (**two inconsistency classes; `T34` forbidden for structural**; Σ-log is sole reconciliation
source; no global sync) · `DEV-R62.1` (nine structural monitors, correlation not content) ·
`DEV-R63.1`–`63.3` (**merge never unions authority**; merge inherits worst anchor debt; merge is Σ2×2+Σ1) ·
`DEV-R64.1`–`64.2` (**split inherits debt; both children must satisfy the predicate; independence re-attestation
mandatory**) · `DEV-R65.1`–`65.3` (failure is contract failure; the six-level ladder; **rung revocation is the L2
instrument**; failure never produces capacity increase) · `DEV-R66.1`–`66.2` (**redundancy is epistemic**;
redundancy-mandatory FIs) · `DEV-R67.1`–`67.3` (what survives region loss; pre-declared degradation;
**K unavailability ⟹ developmental freeze**) · `DEV-R68.1`–`68.4` (migration is Σ3; mandatory-path constraint;
**downward migration is a governance event**; **migration invalidates verification and re-establishes — never
resets — the anchor**) · `DEV-R69.1` (placement optimizes cost, never determines structure) ·
`DEV-R70.1`–`70.3` (compression repertoire; **normative order C-1…C-7**; no silent FI waiver) ·
`DEV-R71.1` (expansion is envelope-gated; **most-verifiable-first**) · `DEV-R72.1` (**the 50,000× `[U]` resolved by
reclassification; waivers explicit; FI-05/10/11 waivers need OP**) · `DEV-R73.1` (**the first symmetry break is
ECONOMIC; the 8-step bootstrap order**) · `DEV-R74.1` (nine bootstrap prohibitions) ·
`DEV-R75.1`–`75.4` (branching is sandbox; selection ≠ promotion; **the reserved null branch**; B8-bounded
candidacy) · `DEV-R76.1`–`76.2` (**indispensability earns nothing**; fitness may not trigger development) ·
`DEV-R77.1` (pre-committed reversal plans) · `DEV-R78.1` (**no mechanism is its own watchdog — nine instances**) ·
`DEV-R79.1` (three clocks, each registered).

## 80.2 Findings

| ID | Finding | Severity | Status |
|---|---|---|---|
| **D-D21** | **`T34` re-development amplifies structural inconsistency — the repair destroys the evidence of the fault** | **CRITICAL** | RESOLVED (+ PROPOSED AMENDMENT to `Cell` `T34`) |
| **D-D22** | FI satisfaction is not split-closed; splitting can silently destroy `Cell §15.4` independence | HIGH | RESOLVED (`DEV-R64.2`) |
| **D-D23** | Redundancy and specialization compete for the same zero-sum slots | HIGH | BOUNDED (tier table as `[H]` trade schedule) |
| **D-D24** | Cross-tier migration changes admissibility; downward migration makes structure illegal | HIGH | RESOLVED (`DEV-R68.3`) |
| **D-D25** | **The organizer bootstrap paradox — no organizer can be positioned, because positioning requires an organizer** | **CRITICAL** | RESOLVED (`DEV-R73.1`: economic break precedes spatial) |
| **D-D26** | **Developmental fitness gaming via indispensability — the same property buys replication advantage and coercive immunity** | **CRITICAL** | RESOLVED (`DEV-R76.1`) |

## 80.3 Contradictions

**X-D14** — the inherited `Cell §22.3` `[U]` on 50,000× functional identity: **RESOLVED-BY-RECLASSIFICATION**,
criterion supplied by P0-06, satisfiability handed to `P0-01`.
**Cumulative contradiction count: 14** (X-D1…X-D14). Statuses: 8 RESOLVED, 3 RESOLVED-BY-RESTATEMENT/
RECLASSIFICATION, 1 RESOLVED-BY-CONSTRAINT, 1 RESOLVED-CONDITIONAL, 1 RESOLVED (P0-06 side) + PROPOSED-AMENDMENT
(Cell side). **None silently rewritten; none left hidden.**

## 80.4 Proposed amendments (cumulative 13; none applied)

(1) `Cell` P11/§27 recovery language · (2) `Cell` `T04`/`T05` non-waivability · (3) `Cell` §4.3 `G-a`/`G-b` →
`T41` · (4) `Cell §3.2` define `R` · (5) `Cell A-11` versioned `RoleCode` extension · (6) `Cell §7` NICHE
retryability · (7) `Cell` `T41` asymmetry qualifier · (8) `P0-05 §30` budget class **B8** · (9) `Cell I-22`
enumerate developmental reorganization · (10) `P0-02` K-held structural store + abeyance registry + organizer spec
registry · (11) `Cell §15.2` clarify "differentiation tick" as async-partial · **(12) `Cell` Annex B `T34` exclude
structural-record divergence** [D-D21] · **(13) `Cell §22.3` restate the `[U]` per `DEV-R72.1`** [X-D14].

## 80.5 Open research opened in Vol D

**`OR-D10`** — mandatory-path accumulation as an entrenchment and immobility route (BOUNDED, not closed).
**`OR-D11`** — near-sole-satisfier gaming with a token redundant alternative (OPEN).
**Carried:** `OR-D1`…`OR-D9`.

## 80.6 Handoff to Vol E

| Vol D output | Vol E use |
|---|---|
| D-D05, D-D06, D-D07, D-D12, D-D17, D-D21, D-D25, D-D26, `OR-D8`, `OR-D10`, `OR-D11` | **§86 attack suite (≥70)** — the seed attacks |
| `DEV-R61.1`, `DEV-R63.1`/`63.2`, `DEV-R64.1`, `DEV-R65.2`/`65.3`, `DEV-R68.4`, `DEV-R76.1`, `DEV-R78.1` | **§87 DEV-INV invariants** |
| D-D16 (`DevStage` has no machine), `DEV-R73.1` ordering, `DEV-R37.1` conjuncts | **§88 state machines** |
| `DEV-R27.2`, `DEV-R28.1`, `DEV-R65.2`, `DEV-R76.2` | **§89 authority matrix** |
| all `[G]`/`[H]`/`[U]`/`[D]`/`[T]`/`[E]`/`[L]`/`[V]` mentions | **§90 parameter registry** |
| `DEV-R59.1`/`59.2`, D-D23, D-D24, `DEV-R68.3` | **§92 scalability 10…10¹²** |

---

**Next → Volume E (`51_analysis_attacks_invariants_authority.md`, §81–§92):** interfaces, self-reference, the
writer-separation test, the attack suite (≥70), DEV-INV invariants, state machines (including the `DevStage` machine
that D-D16 shows does not exist), the authority matrix, the parameter registry, parameter dependencies, and
scalability from 10 to 10¹² cells.
