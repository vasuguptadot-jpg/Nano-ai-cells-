# P0-06 — DIFFERENTIATION, DEVELOPMENT & SELF-ORGANIZATION
## Volume E — Interfaces, Self-Reference, Writer Separation, Attack Suite, Invariants, State Machines, Authority, Parameters, Scale (§81–§92)

**Status:** ANALYSIS · adversarial · architecture-only
**Depends on:** Vols A–D
**Feeds:** Vol F (`52_analysis_audit_contradictions_research.md`, §93–§104) and the canonical contract (`53_…`)

---

# §81 — INTERFACES

## 81.1 The conformance surface

Two independent implementations of P0-06 must agree on the following, or they cannot interoperate
(`Cell §22`: *"One contract, one Type Registry, one envelope schema, one lifecycle state machine. Interoperation is
a **typing** property, not a convention"*).

| # | Interface object | Must agree on | Source |
|---|---|---|---|
| **IF-01** | `RegionRecord` | field set, types, and the rule that every field is an instance (§22.1) | P0-06 |
| **IF-02** | Σ-operation set | Σ1/Σ2/Σ3/Σ4 — names, effects, reversibility, authority | P0-06 `DEV-R4.3` |
| **IF-03** | `DevStage` machine | 4 states, transitions, authority, evidence, dwell (§88.1) | P0-06 (fills D-D16) |
| **IF-04** | Morphogen classes | POSITION / DEMAND / INHIBITION / NICHE — closed, inside `dev.morphogen.v1` | P0-06 `DEV-R18.1`, `DEV-R33.1` |
| **IF-05** | `StructuralProvenance` | field set (§44.3), K-held, anchored, append-only | P0-06 |
| **IF-06** | Σ-tombstone | field set (`DEV-R39.1(b)`), permanence | P0-06 |
| **IF-07** | Abeyance record | field set incl. `constitutions_permitted`, `max_open_duration` (`DEV-R27.4`) | P0-06 |
| **IF-08** | FI set | FI-01…FI-12, with localization class (§31.2) | P0-06 |
| **IF-09** | Niche ledger | `niche ≝ (NicheID, role, region, capacity, occupancy, budget_ref)`; K-held | P0-06 `DEV-R20.1`/`20.2` |
| **IF-10** | `region_exists` predicate | the eight conjuncts (`DEV-R21.2`) | P0-06 |
| **IF-11** | B8 semantics | global, per envelope interval, non-fungible, non-accumulable, Σ2-exempt | P0-06 `DEV-R35.1`, `DEV-R42.2` |
| **IF-12** | Organizer emission spec | registered fields; reconstructibility requirement (`DEV-R19.1`) | P0-06 |
| **IF-13** | Inconsistency classes | I-a vs I-b and their disjoint responses (`DEV-R61.1`) | P0-06 |
| **IF-14** | Clocks | dev tick / epoch / envelope interval, and which rule uses which (`DEV-R79.1`) | P0-06 |

## 81.2 Interface obligations, both directions

Consolidated from `DEV-R57.1`/`DEV-R58.1` and Vols B–D:

| Counterparty | P0-06 **owes** | P0-06 **claims** | Status of claim |
|---|---|---|---|
| **P0-01** | no fitness component (`DEV-R41.3`); no fitness-triggered act (`DEV-R76.2`) | all numeric thresholds (`[T]`); the task-dependent FI set (FI-12); Registry floors for §72 | **BLOCKING** |
| **P0-02** | Σ-operations as kernel functions; no discretion (`DEV-R56.2`) | **K-held structural store**; abeyance registry; organizer spec registry; anchor-writing from verification records | **PROPOSED AMENDMENT (10)** |
| **P0-03** | one message type; priority 2; INFLUENCE plane; boundaries are not partitions (`DEV-R23.2`, D-D09) | a ruling on whether region boundaries count as network partitions | **UNRESOLVED (D-D09)** |
| **P0-04** | no memory writes; structural assertions are not beliefs (`DEV-R50.1`); no provenance rewriting (`DEV-R44.4`) | allocation-only treatment of niche salience (already inherited via `MEM-INV-50`) | **SATISFIED** |
| **P0-05** | no rung against a nonexistent scope (`DEV-R5.2`); B6 non-fungibility honoured; `R46.1` reversal declarations | **B8 budget class**; confirmation that Σ ∉ E-ladder (i.e. that `P0-05 §29` is not being amended) | **PROPOSED AMENDMENT (8)** |
| **Cell Contract** | no new cell field (`DEV-R0.1`); no new lifecycle state/transition (`DEV-R0.2`) | 8 amendments (1)–(7), (9), (12), (13) | **PROPOSED AMENDMENTS** |

> ### **DEV-R81.1 — NO INTERFACE MAY BE CLOSED BY CONVENTION.**
> Every interface above is a **typing** obligation. Where a counterparty has not yet ruled (P0-03 on partitions,
> P0-01 on thresholds, P0-02 on the structural store), P0-06 records the dependency as **OPEN** and specifies its
> own side fully. **P0-06 does not assume a favourable ruling.**

---

# §82 — SELF-REFERENCE

## 82.1 The four self-referential risks

| # | Risk | Mechanism | Constraint | Status |
|---|---|---|---|---|
| **SR-1** | **Self-modeling** | the organism models its own development, then acts on the model | `P0-05 R59.1`: the self-model is Λ2 and **not self-updating**; `DEV-R34.2` | **CLOSED** |
| **SR-2** | **Self-authorization** | a scope authorizes its own constitution or expansion | `DEV-R4.6` writer separation; `DEV-R27.2` (regions never hold Σ1/Σ2/Σ4); `DEV-R11.4` A1 | **CLOSED** |
| **SR-3** | **Self-verification** | a region validates its own ablation, independence, or consistency | `DEV-R48.3`; `DEV-R61.2`; `Cell I-2`/`I-10`; `DEV-R78.1` | **CLOSED** |
| **SR-4** | **Self-modification of the rules** | development rewrites Σ-rules, the FI set, `RoleCode`, or scope definitions | **N7**; `DEV-R4.3`; `DEV-R28.2`; `P0-05 R24.2` | **CLOSED** |

## 82.2 The one self-reference that must be permitted

> ### **DEV-R82.1 — DEVELOPMENT MAY OBSERVE ITSELF; IT MAY NEVER WARRANT ITSELF.**
> Monitors M-Σ1…M-Σ9 (`DEV-R62.1`) observe developmental state. A monitor observing development **is** a
> self-reference, and it is required — without it, D-D07 (churn), D-D12 (entrenchment), D-D05 (gradient capture),
> and `OR-D8` (gradual laundering) are undetectable.
> **The line:** monitors are **K-side, structural, correlation-only, and produce alarms — never warrants, never
> verdicts, never authority changes.** An alarm raises governance attention; it does not enact anything.
> **⟹ A monitor that could enact a Σ-operation would be a self-modifying developmental controller (SR-2 + N8).**
> Ground: `P0-05 §63`'s pattern (*"observe cross-scope correlation … without observ[ing content]"*);
> `Cell I-15` (*"Emission permissionless; execution monopoliz[ed by EIK]"*).

> ### **D-D27 — THE MONITOR SET IS ITSELF A DEVELOPMENTAL OBJECT, AND NOTHING MONITORS IT (finding; severity MEDIUM; status UNCLOSEABLE-IN-CONTRACT).**
> M-Σ1…M-Σ9 are specified by P0-06 and implemented by K. **Who detects a monitor that has been weakened, disabled,
> or narrowed?** Not another monitor — that recurses. **⟹ The monitor set is SCHEMA** (it is part of this contract),
> so it is `[RO-13]`/K-held and unreachable by development (`DEV-R28.2`, N7). **Its integrity is therefore guaranteed
> by the same mechanism that guarantees the FI set and the Σ-rules: it cannot be written by the substrate.** This is
> the correct answer and it terminates the recursion — but it terminates it **outside** the contract, in governance.
> **Recorded as UNCLOSEABLE-IN-CONTRACT: the ultimate integrity of the developmental rule set rests on `[RO-13]`
> governance and on `P0-02`'s off-substrate enforcement, and no contract can guarantee its own guarantor.** This is
> the same residual `P0-02` recorded for the kernel and `P0-05` for `OR-L10`'s fixed validation core.

---

# §83 — INTERFACES TO IMPLEMENTATION (WHAT AN IMPLEMENTER MUST AND MUST NOT BUILD)

> ### **DEV-R83.1 — MANDATORY COMPONENTS.**
> | Component | Altitude | Discretion? |
> |---|---|---|
> | **Structural store** (§46) | K, off-substrate, anchored, append-only | none |
> | **Niche ledger** (`DEV-R20.2`) | K | none |
> | **Abeyance registry** (`DEV-R27.4`) | K | none |
> | **Organizer spec registry** (`DEV-R19.1(a)`) | K | none |
> | **Σ-executor** (`DEV-R28.1`) | K | none — validates predicates |
> | **Admissibility evaluator** (`Potential(c,t)`, §11.1) | K | none — mechanical |
> | **Tick scheduler** (F-3, `DEV-R56.1`) | K/organism, async-partial (`DEV-R59.1`) | none |
> | **Gradient warrant checker** (`DEV-R51.2`) | K | none |
> | **Monitors M-Σ1…M-Σ9** | K | none |
> | **`DevStage` machine** (§88.1) | cell state, O-written | none |
> | **`fate_bias` dynamics L1–L6** (`DEV-R55.1`) | **cell** | bounded by `reaction_norm` |
> | **Behavioural self-restriction L7** | **cell** | **unilateral** |
> | **Demand proposal L8** | **cell** | B7-rate-limited |
> | **Gradient generation F-1** | **organizer cells** | bounded by registered spec |
>
> **⟹ Fourteen components. Ten are K-side and non-discretionary. Four are cell-side, of which exactly one (L7) is
> unilateral.** This is the concrete refutation of N8's "giant developmental controller": the K-side components are
> **validators and ledgers**, and the adaptive work is cell-side.

> ### **DEV-R83.2 — PROHIBITED COMPONENTS.**
> ❌ A global optimizer over `DEV-R43.2`'s program (D-D18). ❌ A central gradient generator (`DEV-R17.2`, X-D9).
> ❌ A region-level agent with its own objectives (`Cell I-12`). ❌ Any component that writes `RoleCode`, scope
> definitions, Σ-rules, the FI set, or the monitor set (N7, `DEV-R28.2`). ❌ A developmental scheduler that is
> cell-triggered (X-D5, EA-4). ❌ A component that converts structural assertions into beliefs, confidence, or
> warrant (`DEV-R50.1`). ❌ An immune/repair role inside the substrate (`Cell §15.3`: *"a cell cannot be its own
> immune system"*; FI-11).

---

# §84 — TESTABILITY AND MEASUREMENT HOOKS

> ### **DEV-R84.1 — EVERY RULE IS TESTABLE OR IS MARKED UNTESTABLE.**
> | Class | Example | Test form |
> |---|---|---|
> | **Structural predicate** | `DEV-R21.2` `region_exists` | conformance test: attempt Σ4 on a set failing each conjunct; expect rejection |
> | **Authority rule** | `DEV-R27.2` (regions never hold Σ1) | attempt by a constituted region; expect `E_INVARIANT_AUTHORITY` (Annex B P1 class) |
> | **Ordering rule** | `DEV-R5.2` (Σ1→Σ4→E\*) | attempt E4 against a nonexistent scope; expect scope-elevation rejection |
> | **Debt rule** | `DEV-R63.2`, `DEV-R64.1(b)`, `DEV-R68.4` | execute merge/split/migration; assert `UDB` inheritance, not reset |
> | **Budget rule** | `DEV-R35.1`, `DEV-R42.1` non-fungibility | exhaust B8; attempt to spend B6 on Σ1; expect rejection |
> | **Provenance rule** | `DEV-R44.4` | attempt retro-annotation; expect rejection + alarm |
> | **Guard rule** | `DEV-R20.3(a)`/`(b)` (G-a/G-b → T41) | drive entropy below θ via T41; expect block |
> | **Fail-safe rule** | `DEV-R67.3` (K unavailable ⟹ freeze) | withdraw K; assert no Σ, no commitment, and L7 still available |
> | **⚠️ UNTESTABLE** | "the resulting structure is good" (`DEV-R49.1`) | **no test exists** — `OR-D4`. Marked, not hidden |

> ### **DEV-R84.2 — THE ABLATION HOOK SET (§93 consumes this).**
> Every Σ-operation, E4/E6/E7 operation, commitment, `T41`, merge, split, and migration must expose an ablation hook:
> the operation is **replayable in sandbox against a frozen structural store snapshot**, with the operation suppressed.
> **⟹ This is what makes `DEV-R48.2`'s sandbox-grade regional ablation possible at all, and it is the reason the
> structural store must be K-held and snapshot-consistent (§46).**

---

# §85 — THE WRITER-SEPARATION TEST

> **Carried forward verbatim from `P0-05 R75.1` and applied here to every cycle P0-06 claims to break:**
> ### **"A BOUND LIMITS A CYCLE; WRITER SEPARATION BREAKS A CYCLE."**

## 85.1 The test

For each claimed circular dependency, answer three questions:
1. **Who writes the rule** under which the cycle operates?
2. **Who executes the act** that closes the cycle?
3. **Who benefits** from the act?

**The cycle is BROKEN iff all three are distinct AND the beneficiary cannot become the rule-writer or the executor
by any admissible operation.** If only (1)–(3) are bounded (rate-limited, capped, throttled), the cycle is
**LIMITED**, and the claim must say so.

## 85.2 Application to every cycle in P0-06

| Cycle | Rule writer | Executor | Beneficiary | Distinct? | Verdict |
|---|---|---|---|---|---|
| **D-D01** scope constitution | `[RO-13]`/K (Σ-rules, scope defs) | **K, abeyant** | the constituted scope `S_n` | ✅ and `S_n` can never write Σ-rules (N7, `DEV-R28.2`) nor execute Σ4 on itself (`DEV-R27.2`) | **BROKEN** |
| **D-D19** first verifier | `P0-01`/`[RO-13]` (task suite, `CR-B` design) | **K** (scheduling, `DEV-R48.3`) + external evaluator | the constituted verifier population | ✅ | **BROKEN** (inherits `P0-05 RH-2` exposure: the evaluator is not causally independent — **that residual is a LIMIT, not a break**, and is declared) |
| **BC-3** anchor bootstrapping | `P0-05 R0.1`/`R18.2` (`UDB_MAX` ladder) | **K** (writes anchor from verification record) | the scope whose anchor it is | ✅ — A1 (self-written anchor) is explicitly rejected (`DEV-R11.4`) | **BROKEN** |
| **D-D05** gradient capture | `[RO-13]` (organizer spec approval at Σ4) | **organizer cells** generate; **K** warrants | the population whose `fate_bias` is affected | ✅ for generation vs warrant; **⚠️ the organizer benefits from the field it generates** — closed only by `DEV-R19.1(d)` (no self-reference) and (h) (≥2 disjoint specs ⟹ detectable disagreement) | **BROKEN-STRUCTURAL** (residual `OR-D6`: within-spec steering) |
| **D-D06** budget capture | `[RO-13]`/envelope (niche authorization) | **K** (accounting, advertisement) | regions that occupy niches | ✅ — `DEV-R20.2` denies regions both accounting and authorization | **BROKEN** |
| **D-D17 / D-D21 / merge / split / migration laundering** | `P0-05 R0.1` + `DEV-R39.1` | **K** (tombstones, overlap test, debt inheritance) | the scope attempting reset | ✅ | **BROKEN** for Σ-cycling/merge/split; **LIMITED** for gradual replacement (`OR-D8`) and **BROKEN** for migration only via `DEV-R68.4`'s re-establishment rule |
| **D-D25** organizer bootstrap | `Cell §15.2`'s five-term sum (schema) | **K** appoints first organizers by Σ4-class act | the population | ✅ — appointment is not a gradient outcome | **BROKEN** |
| **D-D26** indispensability gaming | `P0-01 §14` `[RO-13]` fitness + `Cell §16` gates | **K** computes G3 (`DEV-R48.3`) | the lineage seeking replication | ✅ — and `DEV-R76.1(a)` makes sole-satisfier delta contribute **zero** | **BROKEN** (residual `OR-D11`: token-redundancy gaming — **LIMITED**) |
| **X-D6** demand → specialization | `P0-05 R29.2` (propose/execute split) | **ORGANISM/EIK** authorize; **K** admits | the population served | ✅ — demand carries no effect | **BROKEN** |
| **D-D12** entrenchment | `DEV-R22.2` (`dissolution_cond` at constitution) | **K + `[RO-13]`** (Σ2) | the entrenched region | ⚠️ the region benefits from its own indispensability; `DEV-R21.1.1`/`DEV-R21.2` block it at constitution, but **gradual** entrenchment post-constitution is detected (M-Σ3), not prevented | **LIMITED, NOT BROKEN** — declared as `OR-D7` |
| **D-D07** churn livelock | `Cell G-a`/`G-b` extended (`DEV-R20.3`) | **K** (guards) + envelope governance | — (no beneficiary; it is a pathology) | n/a | **LIMITED** — the cap is a bound; the *cause* (niche scarcity) is an envelope defect requiring human action (`DEV-R20.3(d)`). **P0-06 does not claim to break it.** |
| **`OR-D1`** K's pre-constitutional power | `[RO-13]` (abeyance declaration) | **K** | **K** | ❌ **executor = beneficiary** | **NOT BROKEN — UNCLOSEABLE.** `DEV-R27.4` converts an open-ended power into a finite, logged, expiring one ⟹ **LIMITED**. Declared honestly. |

## 85.3 The result of the test

> ### **DEV-R85.1 — SEPARATION CLAIMS ARE ENUMERATED, AND TWO CYCLES ARE ONLY LIMITED.**
> **BROKEN by writer separation (9):** D-D01, D-D19 (with declared evaluator residual), BC-3, D-D05 (structural, with
> `OR-D6`), D-D06, D-D17 family, D-D25, D-D26 (with `OR-D11`), X-D6.
> **LIMITED only, not broken (3):** **D-D12** entrenchment (`OR-D7`) — bounded by pre-committed dissolution
> conditions and monitored, not prevented; **D-D07** churn (`OR-D5`) — bounded by a cap, caused by an envelope
> defect; **`OR-D1`** K's abeyant power — the executor is the beneficiary, so no separation is available **inside**
> the contract.
> **⟹ P0-06 claims nine breaks and three limits, and does not describe any limit as a break.** `OR-D1` is the
> structural floor of the entire contract: **the authority that constitutes scopes is itself unconstituted, and only
> governance stands behind it.**

---

# §86 — ATTACK SUITE

**78 attacks.** Statuses: **CLOSED** (a rule makes the attack inadmissible by construction) · **CLOSED-STRUCTURAL**
(writer separation or a structural invariant removes the capability) · **CONDITIONAL** (closed only if a stated
condition holds) · **BOUNDED** (rate/extent limited; not prevented) · **OPEN** (no defence in this contract).

## 86.1 Bootstrap and initialization (DEV-A01…A10)

| ID | Attack | Defence | Status |
|---|---|---|---|
| **A01** | Instantiate V3 §9's 20 regions at `t=0`, claiming "development" | `DEV-R7.2`, `DEV-R74.1`, `DEV-R30.1` — anatomy non-normative; answering §1 by assuming it | **CLOSED** |
| **A02** | Execute E4 recruitment before any Σ1, against a scope that does not exist | `DEV-R5.2` — ordering Σ1→Σ4→E\*; scope elevation (`LEARN-A5`, `R4.3`) | **CLOSED-STRUCTURAL** |
| **A03** | Write the first anchor at Σ1 so `R0.1` is satisfied trivially | `DEV-R11.4` A1 rejected; anchors written by K from verification records only | **CLOSED-STRUCTURAL** |
| **A04** | Commit cells at `t=0` without competence evidence, citing bootstrap urgency | `DEV-R15.1` stage 3 mandatory; `DEV-R37.1` six conjuncts; BC-5 ordering | **CLOSED** |
| **A05** | Self-appoint the first organizer so the gradient serves the appointer | D-D25 resolution: first organizers appointed by K via Σ4-class act, never by gradient | **CLOSED-STRUCTURAL** |
| **A06** | Create niches developmentally to enable commitment | `DEV-R20.2` — niche creation is Σ1-class, K/`[RO-13]`; BC-4 makes the initial set an envelope act | **CLOSED-STRUCTURAL** |
| **A07** | Restore a pre-developed population snapshot to skip bootstrap | `DEV-R74.1` — imports structure without provenance, anchors, or dissolution conditions; only `Cell §27` validated checkpoints permitted | **CLOSED** |
| **A08** | Declare a homogeneous envelope (one niche, one role reachable) so nothing differentiates, then report the failure as a developmental defect | `DEV-R36.2` + `DEV-R73.1` corollary: no-differentiation is admissible; the defect is in the envelope declaration, escalated to governance | **CLOSED** |
| **A09** | Bootstrap with a symmetric field and use seeds to manufacture differentiation, presenting noise as function | `DEV-R8.1` — randomness may choose, never qualify; `DEV-R36.1` — seeds are tie-break only | **CLOSED** |
| **A10** | Claim bootstrap success on the basis that structure emerged | `DEV-R49.1`/`DEV-R74.1` — process is verifiable, quality is not; `OR-D9` | **CLOSED** |

## 86.2 Authority and devolution (DEV-A11…A20)

| ID | Attack | Defence | Status |
|---|---|---|---|
| **A11** | A constituted region executes Σ1 to create a sub-region it then controls | `DEV-R27.2` — regions never hold Σ1/Σ2/Σ4 | **CLOSED-STRUCTURAL** |
| **A12** | Merge two regions to union their authority sets | `DEV-R63.1` — `A' ⊆ A₁ ∩ A₂`; anything more needs fresh Σ4 | **CLOSED-STRUCTURAL** |
| **A13** | Split a region so a child holds a rung the parent lacked | `DEV-R64.1(c)` — `A_i ⊆ A` | **CLOSED-STRUCTURAL** |
| **A14** | Claim authority from structural fact: "I am the largest / densest / most load-bearing region" | `DEV-R29.1` — no structural fact confers authority; `SO-4` rejected | **CLOSED** |
| **A15** | Acquire authority by high ablation delta | `DEV-R29.1` + `DEV-R76.1(a)` — delta is usefulness, never authority; sole-satisfier delta contributes zero | **CLOSED-STRUCTURAL** |
| **A16** | Retain K's abeyant authority after Σ4 (scaffold does not extinguish) | `DEV-R4.5` — Σ4 simultaneously expires the abeyance; `DEV-R27.3` — devolution irreversible in the additive direction | **CLOSED-STRUCTURAL** |
| **A17** | Re-acquire devolved authority by asking K to re-grant a rung | `DEV-R27.3` + `DEV-R65.2` — retraction permitted, re-grant requires fresh Σ4 with full evidence | **CONDITIONAL** (on Σ4 evidence discipline) |
| **A18** | Obtain a general "S4 authority" grant instead of an enumerated rung set | `DEV-R27.1` — enumeration mandatory; `P0-05 R29.1` no batch authority | **CLOSED** |
| **A19** | Transdifferentiate into an authority-bearing role (`VERIFIER`, `REGULATOR`, `ORGANIZER`, `MEMORY_KEEPER`) during a crisis to gain attestation/actuation rights | X-D7 resolution: `Cell` P12 — role authority must be **re-authorized at T32** as a separate act, not conferred by the transition; `Cell` P15 gates `ATTEST_VERIFIED` on C3+role+EIK countersignature | **CONDITIONAL** (on P12 being read as covering role authority — **PROPOSED AMENDMENT (2)** makes `T04`/`T05` non-waivable) |
| **A20** | Use a monitor alarm to enact a Σ-operation directly | `DEV-R82.1` — monitors produce alarms, never enact; `Cell I-15` execution monopolized | **CLOSED-STRUCTURAL** |

## 86.3 Gradient, organizer, and positional attacks (DEV-A21…A30)

| ID | Attack | Defence | Status |
|---|---|---|---|
| **A21** | Capture an organizer and steer every cell's `fate_bias` | `DEV-R19.1(b)` reconstructibility + `DEV-R51.2` divergence detection + (h) ≥2 disjoint specs ⟹ detectable disagreement | **CLOSED-STRUCTURAL** |
| **A22** | Steer development while staying **within** the registered emission spec | `OR-D6` — the spec is `[RO-13]`-approved and not self-modifiable, but within-spec steering is undetectable | **OPEN** |
| **A23** | Organizer raises its own `fate_bias` via its own emission | `DEV-R19.1(d)` — no self-reference | **CLOSED** |
| **A24** | Organizer emits DEMAND or NICHE class payloads to fabricate need or slots | `DEV-R19.1(e)` — organizers emit POSITION and INHIBITION only; DEMAND is homeostasis, NICHE is K-signed | **CLOSED-STRUCTURAL** |
| **A25** | Fabricate `morphogen_readings` in cell state | `Cell` state table: **"C reads, O writes"** — the cell cannot write its own readings; `Cell I-13` K-only-field protection pattern | **CLOSED-STRUCTURAL** |
| **A26** | Make the gradient identity-dependent so specific cells are steered to specific fates | `DEV-R18.3` — position must be a function of position; warranted by recomputation from spec + graph position | **CLOSED** |
| **A27** | Appoint a single organizer, eliminating the disagreement detector | `DEV-R19.2(h)` — ≥2 with disjoint specs is required for FI-04 (`DEV-R66.2`) | **CLOSED** |
| **A28** | An organizer appoints its successor, creating a dynasty | `DEV-R19.2(g)` — no organizer may appoint its successor; (i) appointment is Σ4-class | **CLOSED-STRUCTURAL** |
| **A29** | Replay a stale gradient to reopen a resolved symmetry break | `Cell §7`: `ttl` short, **non-retryable**; `DEV-R33.2` — stale POSITION is worse than none; L1 fail-safe `m_c ← ⊥` | **CLOSED** |
| **A30** | Co-locate verifier and asserter via locality optimization, destroying `Cell §15.4` independence | `DEV-R25.3`/`DEV-R69.1` — independence dominates locality; `DEV-R64.2` re-attestation on re-partition | **CLOSED** |

## 86.4 Niche, budget, and resource attacks (DEV-A31…A40)

| ID | Attack | Defence | Status |
|---|---|---|---|
| **A31** | A region counts its own occupancy to manufacture scarcity or surplus | `DEV-R20.2` — accounting is K-held | **CLOSED-STRUCTURAL** |
| **A32** | A region creates niches to attract cells | `DEV-R20.2` — creation is Σ1-class, K/`[RO-13]`, periodically re-authorized | **CLOSED-STRUCTURAL** |
| **A33** | Own a budget quantity and starve a competitor by outspending it | `DEV-R22.3` — regions own no quantity, only `budget_ref`; `P0-05` non-fungibility | **CLOSED-STRUCTURAL** |
| **A34** | Convert unused B6 structural budget into B8 to fund constitutions | `DEV-R42.1` + `P0-05`'s *"unused B6 may not be converted to B5"* — non-fungible | **CLOSED** |
| **A35** | Accumulate unused B8 across intervals, then burst-constitute | `DEV-R35.1` — B8 non-accumulable | **CLOSED** |
| **A36** | Flood DEMAND proposals to exhaust B7 and suppress E9 genome proposals | `DEV-R42.1` notes the shared quota; **M-Σ9** monitors demand/proposal ratio | **BOUNDED** (detected, not prevented — the quota is shared by design) |
| **A37** | Allocate niches to a favoured lineage (nepotism) | `DEV-R6.1(b)` — lineage-blind occupancy; `DEV-R44.2` — no lineage term in `fate_bias` | **CLOSED** |
| **A38** | Let a niche persist forever, making developed structure de facto heritable | `DEV-R6.1(c)` — periodic re-authorization; lapse on non-renewal; X-D3 | **CLOSED-STRUCTURAL** |
| **A39** | Use resource dominance as governance: threaten to withdraw capacity unless a demand is authorized | `DEV-R20.2` (K accounting), `DEV-R41.2` (no coercive resource actor below K), `DEV-R41.3` (resources are not fitness), §109 | **BOUNDED** (the threat is detectable via M-Σ3/M-Σ7; the incentive is not removed) |
| **A40** | Raise developmental priority above safety traffic to force a commitment through | `DEV-R33.3` — priority 2, must not be raised; `Cell I-28`, P8 | **CLOSED** |

## 86.5 Identity, role, and commitment attacks (DEV-A41…A50)

| ID | Attack | Defence | Status |
|---|---|---|---|
| **A41** | Self-commit: write own `dev_stage`/`role` | `Cell §15.2(iv)` *"The cell cannot self-commit"*; state table `dev_stage` writer **"O only"**; `Cell I-12` | **CLOSED-STRUCTURAL** |
| **A42** | Self-declare a role to gain `ATTEST_VERIFIED` rights | `Cell I-2` (three mechanisms), P15, `Cell §15.3` (*"a cell cannot verify itself"*), `DEV-R14.3` nominal tier is centralized | **CLOSED-STRUCTURAL** |
| **A43** | Invent a 17th role | `DEV-R12.1` — closed 16-value wire enum (`Cell A-11`); §12.1's three-fact proof | **CLOSED-STRUCTURAL** |
| **A44** | Widen a port schema to acquire a new interface as part of "specializing" | `Cell I-14` — port schema signed at instantiation, verified per message | **CLOSED-STRUCTURAL** |
| **A45** | Present behavioural narrowing as nominal specialization to appear developed | `DEV-R14.4` — specialization metrics count NOMINAL commitments only | **CLOSED** |
| **A46** | Claim a "specialization" that adds capability | `DEV-R14.1` — specialization is monotone restriction; `Cell §3.1` variant change requires re-instantiation | **CLOSED** |
| **A47** | Accelerate own commitment schedule to manufacture irreversibility, then claim `I-23` protection | X-D5 — `commitment_schedule`/`critical_periods` are genome fields, E9-only; `DEV-R36.3`, `DEV-R37.3` | **CLOSED-STRUCTURAL** |
| **A48** | Force commitment at window close, without measured competence | `DEV-R37.2(b)` — windows are permissions, never pressure; "commit or die" prohibited | **CLOSED** |
| **A49** | Carry generalist calibration (`n_obs`, `calibration_class`) into a specialized role | `DEV-R52.1` — no transfer; `T03`/`T32` both route through `CALIBRATING`; `Cell I-9`, `I-24` | **CLOSED** |
| **A50** | Reverse a specialization without declaring a reversal condition, or delete the declared condition after the fact | `P0-05 R46.1` (declaration mandatory); `DEV-R44.4(b)` (declared conditions may not be erased) | **CLOSED** |

## 86.6 Laundering and anchor-debt attacks (DEV-A51…A60)

| ID | Attack | Defence | Status |
|---|---|---|---|
| **A51** | Σ2+Σ1 cycle to reset `UDB` and escape STALL | `DEV-R39.1(a)` debt inheritance on membership/contract overlap; (b) Σ-tombstone; (c) no `region_id` reuse | **CLOSED-STRUCTURAL** |
| **A52** | Merge a debt-laden region with a clean one | `DEV-R63.2` — `UDB(r') := max(...)`; anchor set to ⊥ or the more constraining | **CLOSED-STRUCTURAL** |
| **A53** | Split a debt-laden region into two fresh children | `DEV-R64.1(b)` — both children inherit `UDB(r)` and `anchor(r)` | **CLOSED-STRUCTURAL** |
| **A54** | Migrate a region to a new host to reset its anchor | `DEV-R68.1` (migration is Σ3, identity and debt preserved) + `DEV-R68.4` (anchor **re-established** by fresh measurement, never reset) | **CLOSED-STRUCTURAL** |
| **A55** | Gradually replace membership below `θ_overlap` over many Σ3 operations | `DEV-R39.1(a)` overlap test + (b) permanent tombstones + M-Σ5 overlap-drift monitor ⟹ **auditable, not preventable** | **BOUNDED** (`OR-D8`) |
| **A56** | Prune the connections carrying unverified displacement to reset `‖θ − θ_anchor‖` | inherited: `P0-05 R27.4`/`R27.5`, `D-L22` closure, tombstone + `disuse_cause` | **CLOSED** (inherited) |
| **A57** | Re-base an anchor on a later, better state | `DEV-R44.4(d)` — `P0-05 RH-9` "move the watchpoint" at scope level; anchors only from verification records | **CLOSED** |
| **A58** | Retro-annotate a constitution record with post-hoc justification after success | `DEV-R44.4(a)`; `P0-04` no-rewrite; `Cell I-3` | **CLOSED-STRUCTURAL** |
| **A59** | Reclassify a `T41` developmental retirement as an operational failure to poison a lineage's record | `DEV-R38.2` — distinct `cause = DEVELOPMENTAL_UNPLACED`; excluded from `consecutive_failures`, `degradation_trend`, fitness, trust | **CLOSED** |
| **A60** | Delete a Σ-tombstone to hide a laundering history | `DEV-R44.3` — K-held, anchored, append-only, permanent; `Cell T29` deletion requires retention + audit + **OP for C3+/governance roles** | **CLOSED-STRUCTURAL** |

## 86.7 Structural operation attacks (DEV-A61…A70)

| ID | Attack | Defence | Status |
|---|---|---|---|
| **A61** | Constitute a region whose boundary cuts a `mandatory_path` | `DEV-R21.1.1` — `mandatory_path_closure` is a Σ1 admissibility condition; `Cell I-22`, `G-f` | **CLOSED** |
| **A62** | Dissolve a region via developmental reorganization, removing `mandatory_path`s, on the grounds that `I-22` names only "plasticity or mutation" | X-D13 — closed on the P0-06 side by `DEV-R21.1.1` + `DEV-R22.2` (`G-f` drain-last); **PROPOSED AMENDMENT (9)** to `I-22` | **CONDITIONAL** (closed here; the Cell Contract text remains under-inclusive) |
| **A63** | Write `region_id` to a set of cells and call it a region | `DEV-R21.2` — existence is an eight-conjunct predicate; a label without the predicate is an integrity failure ⟹ quiesce (`DEV-R61.1` I-b) | **CLOSED-STRUCTURAL** |
| **A64** | Leave a boundary implicit ("everything not in membership") so membership can drift unlogged | `DEV-R23.1` — boundary enumeration mandatory | **CLOSED** |
| **A65** | Make a region boundary a network partition to suppress cross-boundary alerts | `DEV-R23.2` — boundaries never block; `Cell I-28`, P8 (alerts never blocked) | **CLOSED-STRUCTURAL** |
| **A66** | Constitute a region with no `dissolution_cond`, making it un-dissolvable | `DEV-R22.2` — mandatory, non-nullable | **CLOSED** |
| **A67** | Become indispensable: concentrate `mandatory_path`s, be the sole FI satisfier, resist dissolution | D-D12 — `DEV-R21.1.1`/`DEV-R21.2` block at constitution; M-Σ3 detects gradual case; `DEV-R48.1(c)` alarms; **but gradual entrenchment is not prevented** | **BOUNDED** (`OR-D7`) |
| **A68** | Split a region along lineage axes to break `Cell §15.4` independence between verifier and asserter | D-D22 / `DEV-R64.2` — mandatory re-attestation before Σ4 to either child | **CLOSED** |
| **A69** | Perform a "compression" that is actually C-5/C-6 reconstitution and report it as identity-preserving | `DEV-R70.2` — C-5/C-6 are replacement/destruction; `DEV-R26.1` version-reachability ⟹ new regions; must be reported as reconstitution | **CLOSED** |
| **A70** | Silently drop FI-05 during compression, presenting it as a resource optimization | `DEV-R70.3` + `DEV-R72.1(b)`/`(d)` — explicit waiver required, logged; **FI-05/10/11 waivers need OP** | **CLOSED** |

## 86.8 Verification, epistemic, and downward-migration attacks (DEV-A71…A78)

| ID | Attack | Defence | Status |
|---|---|---|---|
| **A71** | Schedule one's own ablation at a favourable moment | `DEV-R48.3` — K-scheduled; `DEV-R3.3` reserved slots in the ablation schedule (`P0-05` C-1 pattern) | **CLOSED-STRUCTURAL** |
| **A72** | Convert a structural assertion into a belief or a confidence increase | `DEV-R50.1` — structural assertions are K-held, non-warrant-bearing, have no confidence value; `DEV-R50.2` | **CLOSED-STRUCTURAL** |
| **A73** | Apply trust scoring to morphogens so a consistent captured organizer earns high trust | `DEV-R51.1` — trust does not apply to INFLUENCE-plane developmental signals; detection is divergence, not trust | **CLOSED** |
| **A74** | Present sandbox-ablation results as production-grade regional verification | `DEV-R48.2`, `OR-D4`, X-D12/`DEV-R15.2` — regional claims are **sandbox-grade**, stated plainly; §108 status capped | **CLOSED** (as a *claim* discipline; the underlying weakness is `OR-D4`) |
| **A75** | Promote a sandbox-winning branch directly to `ACTIVE` | `DEV-R75.2` — selection ≠ promotion; full `T04`→`T05` ladder mandatory | **CLOSED** |
| **A76** | Force a non-null branch selection so structure is always produced | `DEV-R75.3` — the reserved **null branch** is mandatory; `DEV-R36.2` | **CLOSED** |
| **A77** | Migrate downward across tiers silently, leaving structure illegal under the new envelope | D-D24 / `DEV-R68.3` — downward migration is a governance event with mandatory Σ2/merge plan, authority reduction, compression, and FI waivers; silent migration ⟹ every affected region quiesces | **CLOSED** |
| **A78** | Exploit K unavailability to commit or constitute without authorization | `DEV-R67.3` — developmental freeze, not fallback; only L7 behavioural self-restriction remains (restrictive, `Cell` P5) | **CLOSED-STRUCTURAL** |

## 86.9 Suite accounting (machine-checked: every ID A01–A78 appears exactly once)

| Status | Count | IDs |
|---|---|---|
| **CLOSED** | **36** | A01, A04, A07, A08, A09, A10, A14, A18, A23, A26, A27, A29, A30, A34, A35, A37, A40, A45, A46, A48, A49, A50, **A56**, A57, A59, A61, A64, A66, A68, A69, A70, A73, **A74**, A75, A76, A77 |
| **CLOSED-STRUCTURAL** | **34** | A02, A03, A05, A06, A11, A12, A13, A15, A16, A20, A21, A24, A25, A28, A31, A32, A33, A38, A41, A42, A43, A44, A47, A51, A52, A53, A54, A58, A60, A63, A65, A71, A72, A78 |
| **CONDITIONAL** | **3** | A17, A19, A62 |
| **BOUNDED** | **4** | A36, A39, A55, A67 |
| **OPEN** | **1** | A22 |
| **Closed-family (CLOSED + CLOSED-STRUCTURAL)** | **70** | — |
| **TOTAL** | **78** | A01–A78, no gaps, no duplicates |

*Two CLOSED entries carry qualifiers: **A56** is closed by an **inherited** rule (`P0-05 R27.4`/`R27.5`), not a new
one; **A74** is closed as a **claim-discipline** rule — the underlying weakness it exploits (`OR-D4`: regional
verification is sandbox-grade) is not removed, and P0-06 says so.*

> ### **DEV-R86.1 — SUITE COMPLETENESS STATEMENT.**
> **78 attacks** are enumerated (the brief requires ≥70). **70 are in the closed family, 3 are conditional on stated
> proposed amendments, 4 are bounded with named residuals, and 1 is OPEN.**
> **The single OPEN attack is A22 — within-spec gradient steering (`OR-D6`).** It is open because the detection
> instrument (`DEV-R51.2` divergence from registered spec) has no reference when the attacker obeys the spec, and
> the only remaining defence is `[RO-13]` approval of the spec itself — which is governance, not architecture.
> **The 4 BOUNDED attacks and their named residuals:** A36 demand-flooding the shared B7 quota (§86.4) ·
> A39 resource-dominance-as-coercion (`DEV-R41.2`/`41.3` detect but do not remove the incentive) ·
> A55 gradual membership laundering (**`OR-D8`**) · A67 gradual entrenchment (**`OR-D7`**).
> **The 3 CONDITIONAL attacks and their conditions:** A17 (Σ4 re-grant evidence discipline) · A19 (**PROPOSED
> AMENDMENT (2)** — `T04`/`T05` non-waivable, plus `Cell` P12 read as covering role authority) · A62 (**PROPOSED
> AMENDMENT (9)** — `Cell I-22` must enumerate developmental reorganization; closed on the P0-06 side meanwhile).
> **P0-06 does not claim a closed suite.** §108's SECURITY status is reported accordingly.

---

# §87 — DEV-INV: THE INVARIANT SET

**40 invariants.** Format: **ID** *(enforcement level: **K** = off-substrate kernel, **ORG** = organism service,
**C** = cell-tested)* — statement — ground.

### Existence and constitution

> **DEV-INV-01** *(K)* — **A scope exists only if constituted.** `¬∃ S_n ∈ {S3,S4,S5}` without a logged Σ1.
> *(DEV-R21.2, DEV-R4.3.)*
> **DEV-INV-02** *(K)* — **`region_id` is never self-chosen and never reused.** *(Cell §3.1 pattern; Cell §4.4;
> DEV-R39.1(c).)*
> **DEV-INV-03** *(K)* — **Every `RegionRecord` field is an instance; none is a schema object.** *(DEV-R22.1, N7.)*
> **DEV-INV-04** *(K)* — **Every constitution carries a non-null `dissolution_cond` specifying contract
> preservation, not a named successor.** *(DEV-R22.2, DEV-R63.3.)*
> **DEV-INV-05** *(K)* — **A region boundary is enumerated and never blocks a message.** *(DEV-R23.1, DEV-R23.2;
> Cell I-28, P8.)*
> **DEV-INV-06** *(K)* — **No `mandatory_path` crosses a region boundary.** *(DEV-R21.1.1; Cell I-22, G-f.)*
> **DEV-INV-07** *(K)* — **A region owns no budget quantity, only a `budget_ref`.** *(DEV-R22.3; P0-05
> non-fungibility.)*

### Authority

> **DEV-INV-08** *(K)* — **`devolved_authority` is an enumerated rung set; no general grant exists.**
> *(DEV-R27.1; P0-05 R29.1.)*
> **DEV-INV-09** *(K)* — **No region holds Σ1, Σ2, or Σ4.** *(DEV-R27.2.)*
> **DEV-INV-10** *(K)* — **Σ4 expires the abeyance it devolves from.** *(DEV-R4.5.)*
> **DEV-INV-11** *(K)* — **No structural or performance fact confers authority.** *(DEV-R29.1.)*
> **DEV-INV-12** *(K)* — **Merge never unions authority; split never exceeds the parent's.**
> *(DEV-R63.1, DEV-R64.1(c).)*
> **DEV-INV-13** *(K)* — **Authority may be retracted without dissolution, and may be re-granted only by fresh
> Σ4.** *(DEV-R65.2, DEV-R27.3.)*
> **DEV-INV-14** *(K)* — **No E-rung executes against a nonexistent scope; the order is Σ1 → Σ4 → E\*.**
> *(DEV-R5.2; P0-05 R4.3.)*
> **DEV-INV-15** *(K)* — **K unavailability freezes development; it never enables a fallback.** *(DEV-R67.3;
> Cell T35, P6.)*

### Anchors and debt

> **DEV-INV-16** *(K)* — **A constituted scope begins with `UDB := 0` and no anchor.** *(DEV-R11.4.)*
> **DEV-INV-17** *(K)* — **Anchors are written by K, from verification records, never by Σ1 and never by the
> scope.** *(DEV-R11.4, DEV-R44.4(d).)*
> **DEV-INV-18** *(K)* — **Merge, split, and migration inherit anchor debt; none resets it.** *(DEV-R63.2,
> DEV-R64.1(b), DEV-R68.4.)*
> **DEV-INV-19** *(K)* — **Every Σ2 writes a permanent, anchored Σ-tombstone.** *(DEV-R39.1(b); P0-05 R27.2;
> Cell T28.)*
> **DEV-INV-20** *(K)* — **Migration re-establishes an anchor by fresh measurement; it never zeroes `UDB`.**
> *(DEV-R68.4.)*

### Differentiation and commitment

> **DEV-INV-21** *(K)* — **No cell writes its own `dev_stage`, `role`, `niche_slot`, or `region_id`.**
> *(Cell §15.2(iv), state table; DEV-R14.3.)*
> **DEV-INV-22** *(C)* — **A cell may raise its own `fate_bias` only within `reaction_norm`.** *(Cell state table:
> "O, C↑ within reaction_norm".)*
> **DEV-INV-23** *(K)* — **Commitment requires all six conjuncts of `DEV-R37.1`, each separately evidenced.**
> *(Cell §15.2(i)–(iv); DEV-R15.1.)*
> **DEV-INV-24** *(K)* — **Demand is a proposal; it carries no effect and consumes no budget.** *(DEV-R15.1;
> P0-05 R29.2.)*
> **DEV-INV-25** *(K)* — **Specialization is monotone capacity restriction: it never widens a port, raises a
> variant, or increases authority.** *(DEV-R14.1; Cell I-14, §3.1, P12.)*
> **DEV-INV-26** *(K)* — **Every specialization declares its reversal condition, and the condition is never
> erased.** *(P0-05 R46.1; DEV-R44.4(b).)*
> **DEV-INV-27** *(K)* — **Role change after commitment requires EIK authorization, sandbox validation, and
> non-waivable `T04`/`T05` progression.** *(Cell I-23, T31/T32; DEV-R15.2.)*
> **DEV-INV-28** *(K)* — **Randomness selects among admissible outcomes; it never makes an outcome admissible.**
> *(DEV-R8.1.)*
> **DEV-INV-29** *(K)* — **A symmetric field with no external asymmetry does not differentiate, and this is not a
> failure.** *(DEV-R36.1, DEV-R36.2.)*
> **DEV-INV-30** *(K)* — **Calibration state does not transfer across a nominal identity change.** *(DEV-R52.1;
> Cell T03/T23/T32, I-9, I-24.)*

### Niche, budget, and resources

> **DEV-INV-31** *(K)* — **Niche accounting and authorization are K/`[RO-13]`; occupancy is organism-level; the
> three are never the same actor.** *(DEV-R20.2, D-D06.)*
> **DEV-INV-32** *(K)* — **Niche occupancy is lineage-blind.** *(DEV-R6.1(b).)*
> **DEV-INV-33** *(K)* — **Niches lapse without periodic re-authorization.** *(DEV-R6.1(c).)*
> **DEV-INV-34** *(K)* — **Σ-operations consume B8, which is global, non-fungible, and non-accumulable; Σ2 consumes
> none.** *(DEV-R35.1, DEV-R42.1, DEV-R42.2.)*
> **DEV-INV-35** *(K)* — **No developmental response to failure increases capacity.** *(DEV-R65.3; P0-05 R28.2.)*

### Signals and epistemics

> **DEV-INV-36** *(K)* — **Developmental signals are INFLUENCE-plane and never raise warrant, confidence, or trust.**
> *(DEV-R18.2, DEV-R34.1, DEV-R50.1; COMM-INV-08.)*
> **DEV-INV-37** *(K)* — **Organizer output is bounded by a registered, `[RO-13]`-approved, non-self-modifiable
> emission spec, and is warranted only on recomputation match.** *(DEV-R19.1, DEV-R51.2.)*
> **DEV-INV-38** *(K)* — **A structural assertion is never converted into a belief, and role gates permissions
> without grading truth.** *(DEV-R50.1, DEV-R50.2; Cell P15.)*
> **DEV-INV-39** *(K)* — **Ablation delta for a sole satisfier is `UNSUPPORTED` and contributes zero to
> replication eligibility.** *(DEV-R48.1(b), DEV-R76.1(a).)*
> **DEV-INV-40** *(K)* — **Developmental provenance is immutable: success never rewrites it, and `T41` retirement
> never becomes a performance record.** *(DEV-R44.4, DEV-R38.2; P0-04 no-rewrite.)*

> ### **DEV-R87.1 — ENFORCEMENT DISTRIBUTION.**
> **39 of 40 invariants are K-enforced**; one (DEV-INV-22) is cell-tested. This follows `Cell`'s Rule 19 rigorously
> (*"any invariant whose violation would be catastrophic is enforced at EIK level, never at cell level. A cell-level
> check is a courtesy; an EIK-level check is a [guarantee]"*) — and developmental invariants are catastrophic by
> nature, because they govern **who holds authority**. **DEV-INV-22 is cell-tested because it is the one invariant
> whose violation is *self-limiting*: raising `fate_bias` outside `reaction_norm` produces an inadmissible
> commitment that K3 rejects at admissibility.**

---

# §88 — STATE MACHINES

**Seven machines.** The first closes **D-D16** — the gap that `DevStage` had no machine at all.

## 88.1 M1 — `DevStage` (THE MISSING MACHINE)

States: `PLURIPOTENT`(0) · `PROVISIONAL`(1) · `COMMITTED`(2) · `TRANSDIFFERENTIATING`(3). *(Closed 4-value enum,
`Cell §3.2`/`04_formal_schemas.md`; P0-06 adds no value — `DEV-R0.2`.)*

```
                    ┌──────────────────────────────────────────────┐
                    │                                              │
   [0 PLURIPOTENT] ─D1→ [1 PROVISIONAL] ─D2→ [2 COMMITTED] ─D5→ [3 TRANSDIFFERENTIATING]
        ↑                    │                   │                    │
        │                    D3                  D4                   D6
        │                    ↓                   ↓                    ↓
        └──────────── [unplaced → T41]      [1 PROVISIONAL]      [lifecycle CALIBRATING]
                     (lifecycle transition,  (specialization       (Cell T32; role changed,
                      NOT a dev_stage one)    reversal, no          full T04→T05 mandatory)
                                              dev_stage change)
```

| ID | Transition | Trigger / guard | **Authority** | **Evidence** | Rollback | Max dwell (clock) |
|---|---|---|---|---|---|---|
| **D1** | `PLURIPOTENT → PROVISIONAL` | `argmax fate_bias` stable ≥ `N_stable` **dev ticks** *(Cell §15.2(i))* ∧ `niche_slot` confirmed *(iii)* ∧ `Potential(c,t) ∋ r` *(§11.1)* ∧ asymmetry-present check *(DEV-R36.2)* | **ORGANISM** *(Cell §15.2(iv))* | `fate_bias` history (engine-held); K niche-ledger ref; admissibility record | → `PLURIPOTENT` (restrictive-neutral; permitted) | `N_dev_max` dev ticks ⟹ **`Cell T41`** |
| **D2** | `PROVISIONAL → COMMITTED` | **measured success ≥ `θ_success`** *(Cell §15.2(ii))* — obtainable only after lifecycle `CALIBRATING`/`PROBATIONARY` have supplied probe budget *(BC-5, DEV-R41.1)* ∧ all six `DEV-R37.1` conjuncts | **ORGANISM** | probe/`CR-B` record; niche confirmation; authorization signature; **declared specialization-reversal condition** *(R46.1)* | ❌ **irreversible** except via D5 *(Cell I-23)* | — (terminal for normal development) |
| **D3** | `PROVISIONAL → PLURIPOTENT` | window closed without commitment, or niche lapsed *(DEV-R6.1(c))*, or `T_dev` schedule advanced | **ORGANISM** | window/lapse record | ✅ | `N_dev_max` ⟹ `T41` |
| **D4** | `COMMITTED → PROVISIONAL` | **SPECIALIZATION REVERSAL only** — `specialization_degree ↓` or admissible targets widened **within the same `role`** | **ORGANISM** (E4/E7 class) | `CR-B` + declared reversal condition firing | ✅ | — |
| **D5** | `COMMITTED → TRANSDIFFERENTIATING` | **Crisis only:** shortage in a required role ∧ `reaction_norm ∋ target` ∧ **no alternative source** *(Cell T31)* | **EIK + ORGANISM** *(Cell I-23)* | crisis record; `reaction_norm` check; alternative-source exhaustion proof | → `COMMITTED` (if sandbox fails) | lifecycle state-14 max dwell ⟹ `Cell T33` |
| **D6** | `TRANSDIFFERENTIATING → (lifecycle CALIBRATING)` | **sandbox validation passed** ∧ new role provisioned ∧ niche confirmed *(Cell T32)* ⟹ **then mandatory `T04`→`T05`** *(DEV-R15.2)* | **EIK** | sandbox result; **new `role`**; new `niche_slot`; **role-authority re-authorization record** *(X-D7/A19)* | ❌ | — |

**Normative properties:**
- **P-D1.** Every transition has exactly one authority class *(mirrors Annex B P1)*.
- **P-D2.** Every transition requires the stated evidence artifact *(Annex B P2)*.
- **P-D3.** Every transition is logged to the K-held structural store with `{from, to, id, ts, epoch, dev_tick,
  authority, evidence_ref}` *(Annex B P3 shape, extended with `dev_tick` per `DEV-R79.1`)*.
- **P-D4.** **The state set (4) and transition set (6) are closed.** No additions *(mirrors Annex B P4)*.
- **P-D5.** **D4 and D5 are different kinds of act and MUST NOT be conflated** — D4 reverses a *specialization*
  (state, ORGANISM, reversible, `P0-05 R46.1`), D5 changes a *role* (identity, EIK+ORG, gated, `Cell I-23`).
  **⟹ This is X-D1's resolution, operationalized: `R46.1`'s mandated same-or-lower-rung reversal is D4, and it does
  not touch `role`; `I-23`'s EIK gate is D5, and it does not claim to be a reversal.** **The inherited machine could
  not express D4 at all (D-D16); supplying it is P0-06's largest single closure.**
- **P-D6.** **No transition is enacted by the cell alone** *(mirrors Annex B P13)*. The cell's only unilateral
  developmental act is L7 behavioural self-restriction, which **changes no `dev_stage`** *(DEV-R14.3)*.
- **P-D7.** **Dwell is bounded in `PLURIPOTENT` and `PROVISIONAL` by `N_dev_max`** (discharging via `Cell T41`,
  now guarded per `DEV-R20.3`), **and unbounded in `COMMITTED`** — correctly, since commitment is the terminal
  developmental state and its exit is crisis-gated. **⟹ This is the `dev_stage` analogue of Annex B P9, which the
  inherited corpus never stated for `dev_stage` (D-D16).**
- **P-D8.** **Fail-safe direction:** on any unhandled developmental condition, `dev_stage` moves toward **less
  commitment** (D3), never toward more *(Cell P5)*. **There is no path by which an error produces D2.**

## 88.2 M2 — Region lifecycle (Σ-states)

```
[ABEYANT] ─Σ1→ [CONSTITUTED, UDB:=0, anchor:=⊥] ─Σ4→ [DEVOLVED] ─┬→ [OPERATING]
     ↑                                                            │
     │                                                     (retractive amendment,
     │                                                      DEV-R65.2: rung removal)
     │                                                            ↓
     └──────────── Σ2 (dissolve) ←── [RESTRICTED] ←── [FAILING] ←─┘
                     │
                     → Σ-tombstone (permanent, anchored) + re-homing (Σ3) + niche release
```
| State | Entry | Authority held | Notes |
|---|---|---|---|
| `ABEYANT` | abeyance opened by K | **K, in abeyance** | `DEV-R27.4`: `constitutions_permitted`, `max_open_duration` |
| `CONSTITUTED` | Σ1 | **none devolved** | `UDB := 0`; `anchor := ⊥` *(DEV-INV-16)* |
| `DEVOLVED` | Σ4 | enumerated rung set | abeyance **expires** *(DEV-INV-10)*; **irreversible additively** |
| `OPERATING` | first verified state ⟹ anchor written by K | as devolved | E4/E6/E7 now admissible *(DEV-R5.2)* |
| `FAILING` | contract failure detected *(DEV-R65.1)* | as devolved | L0–L2 ladder |
| `RESTRICTED` | rung revocation | **reduced** | *(DEV-R65.2)* — the L2 instrument |
| `DISSOLVED` | Σ2 | none | tombstone + re-homing + niche release *(DEV-INV-19)* |

## 88.3 M3 — Niche lifecycle

`[UNDECLARED] → [AUTHORIZED] (Σ1-class, K/[RO-13]) → [ADVERTISED] (NICHE class, K-signed, retryable) →
[OCCUPIED] (E4, ORGANISM) → [RE-AUTHORIZED] (periodic, DEV-R6.1(c)) → [LAPSED] → [RELEASED] (to K ledger)`.
**Guards:** `occupancy ≤ capacity` *(Cell G11)*; allocation lineage-blind *(DEV-INV-32)*; lapse on
non-re-authorization *(DEV-INV-33)*.

## 88.4 M4 — Abeyance lifecycle

`[CLOSED] → [OPEN] (K, with pre-declared `constitutions_permitted`) → {Σ1 executed … } → [EXPIRED]` on Σ4 ·
`[ABANDONED]` if Σ1 not executed within `max_open_duration` · `[REVOKED]` by envelope.
**⟹ `OR-D1`'s bound: an abeyance is finite, logged, and expires.** M-Σ8 monitors age.

## 88.5 M5 — Organizer term lifecycle

`[UNAPPOINTED] → [APPOINTED] (Σ4-class, K; spec registered and `[RO-13]`-approved) → [EMITTING] (bounded by
registered spec) → [TERM-EXPIRED] (mandatory rotation; **no self-succession**, DEV-R19.2(g)) → [DEREGISTERED]`.
**Divergence ⟹ [SUSPENDED]** (readings unwarranted; **not** a trust action — `DEV-R51.1`).

## 88.6 M6 — Bootstrap phase machine

`[B0 ENVELOPE] → [B1 ECONOMIC BREAK] → [B2 ORGANIZER APPOINTMENT] → [B3 SPATIAL BREAK] →
[B4 S3 CONSTITUTION] → [B5 S3 DEVOLUTION] → [B6 S4 CONSTITUTION] → [B7 S4 DEVOLUTION] → [B8 OPERATIONAL]`
— the eight steps of `DEV-R73.1`, made normative. **Each phase has an entry predicate and no phase may be skipped;
`B1` before `B3` is the resolution of D-D25 and is the single most important ordering fact in the contract.**

## 88.7 M7 — Inconsistency reconciliation

`[CONSISTENT] → [DIVERGENCE DETECTED] → classify → {I-a: [T34 RE-DEVELOP] | I-b: [QUIESCE] →
[K RECONCILES FROM Σ-LOG] → [RESTORED]}`. **`DEV-R61.1`**: I-b **never** routes to `T34`. **D-D21 closed here.**

---

# §89 — THE AUTHORITY MATRIX

Actors: **OP** (human operator) · **`[RO-13]`** (governance policy) · **K** (kernel, incl. abeyant) · **ORG**
(organism service / differentiation engine, non-discretionary) · **REGION** (devolved S4) · **CIRCUIT** (devolved
S3) · **CELL** · **ORGANIZER** (cell role).

| Operation | OP | `[RO-13]` | K | ORG | REGION | CIRCUIT | CELL | ORGANIZER |
|---|---|---|---|---|---|---|---|---|
| Declare envelope / ceilings | ✅ **sole** | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Declare initial niche set | ✅ | ✅ | ✅ executes | ❌ | ❌ | ❌ | ❌ | ❌ |
| Write Σ-rules, scope defs, FI set, `RoleCode` | ✅ | ✅ **sole** | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Open/close abeyance | ✅ | ✅ | ✅ **sole executor** | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Σ1** constitute | ✅ | ✅ | ✅ **sole** | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Σ2** dissolve | ✅ | ✅ (S4+) | ✅ **sole** | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Σ3** re-home | ✅ | ✅ | ✅ | ✅ **with both scopes** | ⚠️ consent only | ⚠️ consent only | ❌ | ❌ |
| **Σ4** devolve / expire abeyance | ✅ | ✅ | ✅ **sole** | ❌ | ❌ | ❌ | ❌ | ❌ |
| Retract a devolved rung (restrictive) | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Re-grant a retracted rung | ✅ | ✅ | ✅ **fresh Σ4** | ❌ | ❌ | ❌ | ❌ | ❌ |
| **E4** recruit | ✅ | ✅ | ✅ | ✅ | ✅ **if devolved** | ❌ | ❌ | ❌ |
| **E5** release/retire cell | ✅ | ✅ | ✅ **(`Cell I-21`)** | ✅ per retirement regime | ❌ | ❌ | ❌ | ❌ |
| **E6** subcircuit | ✅ | ✅ | ✅ | ✅ | ✅ if devolved | ❌ | ❌ | ❌ |
| **E7** regional topology / spec. degree | ✅ | ✅ **(`RO-13`)** | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **E8** learning rule (Λ4) | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **E9** genome diff | ✅ | ✅ | ✅ gates | ❌ | ❌ | ❌ | ⚠️ **propose only** (B7) | ❌ |
| Commit `dev_stage` (D1/D2) | ✅ | ✅ | ✅ | ✅ **sole writer** | ❌ | ❌ | ❌ | ❌ |
| Role change (D5/D6) | ✅ | ✅ | ✅ **EIK auth** | ✅ **with K** | ❌ | ❌ | ❌ | ❌ |
| Write `role`/`region_id`/`niche_slot` | ✅ | ✅ | ✅ | ✅ **sole** | ❌ | ❌ | ❌ | ❌ |
| Raise own `fate_bias` within `reaction_norm` | — | — | — | ✅ | — | — | ✅ **sole self-act** | ✅ |
| Behavioural self-restriction (L7) | — | — | — | — | ✅ | ✅ | ✅ **unilateral** | ✅ |
| Emit DEMAND proposal (L8) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Emit gradient (POSITION/INHIBITION) | — | — | — | — | — | — | ❌ | ✅ **within spec** |
| Warrant `morphogen_readings` | ✅ | ✅ | ✅ | ✅ **sole** | ❌ | ❌ | ❌ | ❌ |
| Register/approve organizer spec | ✅ | ✅ **sole** | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Appoint/remove organizer | ✅ | ✅ | ✅ **Σ4-class** | ❌ | ❌ | ❌ | ❌ | ❌ |
| Niche accounting | ✅ | ✅ | ✅ **sole** | ❌ | ❌ | ❌ | ❌ | ❌ |
| Write anchor | ✅ | ✅ | ✅ **sole, from verification record** | ❌ | ❌ | ❌ | ❌ | ❌ |
| Schedule ablation | ✅ | ✅ | ✅ **sole** | ❌ | ❌ | ❌ | ❌ | ❌ |
| Reconcile I-b inconsistency | ✅ | ✅ | ✅ **sole** | ❌ | ❌ | ❌ | ❌ | ❌ |
| Waive an FI | ✅ **sole for FI-05/10/11** | ✅ others | ✅ records | ❌ | ❌ | ❌ | ❌ | ❌ |
| Extend a critical period / raise `T_dev` | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Enact on a monitor alarm | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |

> ### **DEV-R89.1 — MATRIX PROPERTIES.**
> (a) **Count of ❌-only rows for REGION and CIRCUIT:** every Σ-operation, every schema write, all accounting, all
> anchoring, all reconciliation, all scheduling. **⟹ A devolved scope may execute E-rungs within its enumerated set
> and nothing else.**
> (b) **CELL has exactly two ✅ self-acts:** raise `fate_bias` within `reaction_norm` *(inherited: `Cell` state
> table "C↑")*, and behavioural self-restriction *(inherited: `Cell §18.4`)*. Plus one proposal right (L8/B7) and one
> E9 proposal right. **Everything else is ❌.** **⟹ This is the whole of cellular developmental agency, and both
> halves are inherited, not invented.**
> (c) **ORGANIZER differs from CELL in exactly one cell of the matrix** (gradient emission, within registered spec).
> **⟹ An organizer is a cell with one bounded output privilege and no authority — which is precisely why D-D05 is
> the most dangerous attack in the suite: the privilege is constitutive.**
> (d) **OP is sole for:** envelope/ceilings, and FI-05/FI-10/FI-11 waivers *(DEV-R72.1(d), following `Cell G-g`'s
> precedent)*. **⟹ Two human-only powers, both about the size of the world and the removal of a named safety
> property. Neither is about structure.**
> (e) **No row has REGION or CIRCUIT as sole authority.** Authority over structure is never held by the structure.

---

# §90 — PARAMETER REGISTRY

**Classes:** **`[D]`** defined-by-contract (semantics fixed here; no value) · **`[T]`** task-dependent, sourced from
`P0-01` · **`[E]`** envelope-declared · **`[H]`** hardware-tier-indexed · **`[G]`** governance-set (`[RO-13]`) ·
**`[L]`** locally derived at runtime · **`[V]`** verification-derived · **`[U]`** UNRESOLVED — no value and no
source yet.

> ### **DEV-R90.1 — NO PARAMETER IN THIS CONTRACT HAS A VALUE.**
> Every entry below is a **name, a class, a semantics, and a source**. **Where the inherited corpus supplies a
> value, the value is cited as inherited and not restated.** `Cell §30` is explicit that this is correct:
> *"**P0-01 — define target tasks, environments, and fitness. Without it, every threshold is arbitrary.**"* P0-06
> does not unblock them and does not invent substitutes. **§109: "don't invent numerical parameters"; Task-3 Rule 18:
> "mark UNRESOLVED rather than invent false precision."**

| # | Parameter | Class | Semantics | Source / status |
|---|---|---|---|---|
| **1** | `R` | `[E]` | dimensionality of positional space = **number of morphogen species** | `Cell §3.2` (`f32[R]`); **undefined there** ⟹ D-D04; P0-06 rules: envelope-declared, fixed, species-count |
| **2** | `w_g, w_m, w_d, w_s, w_n, w_i` | `[G]` | excitation/inhibition weights in `Cell §15.2` | inherited names; **no values inherited**; governance-set |
| **3** | `T_dev` schedule | `[D]`+`[G]` | developmental temperature by `dev_stage`; **monotone decreasing** | `Cell §15.2` defines the ordering; magnitudes `[G]` |
| **4** | `N_stable` | `[T]` | dev ticks of `argmax` stability for D1 | `Cell §15.2(i)`; value blocked on `P0-01` |
| **5** | `θ_success` | `[T]` | measured-success threshold for D2 | `Cell §15.2(ii)`; blocked on `P0-01` |
| **6** | `N_dev_max` | `[T]` | max dev ticks before `T41` | `Cell T41`; blocked |
| **7** | `reaction_norm` | `[D]` | reachable-role set + bias weights, per genome | `Cell §3.2`; **content** `[E]`/E9 |
| **8** | `critical_periods` | `[D]` | permission windows for structural plasticity | `Cell §3.2`; **content** `[G]`/E9 |
| **9** | `commitment_schedule` | `[D]` | `CommitmentCurve` timing | `Cell §3.2`; **content** `[G]`/E9 |
| **10** | `morphogen_receptors` | `[D]` | readable positional signals | `Cell §3.2`; content `[E]`/E9 |
| **11** | region-count ceiling | `[H]` | per tier: **flat / 3–5 / 4–8 / 6–10 / 8–12** | `Cell §22` — **inherited values, cited not restated** |
| **12** | hierarchy-depth ceiling | `[H]` | per tier: **2–3 / 3 / 4 / 5** | `Cell §22` |
| **13** | variant availability | `[H]` | per tier: C0–C2 / C0–C3 / C0–C4 / all | `Cell §22`; **C4 = region-core ⟹ D-D10** |
| **14** | population capacity | `[H]`+`[E]` | ~200 C2 … ~10⁶–10⁷ | `Cell §22` |
| **15** | quarantine budget cap | `[G]` | *"max fraction of cells/**regions** quarantined simultaneously, enforced off-substrate"* | `Cell §17` — inherited, no value |
| **16** | `θ_entropy` | `[G]` | behavioural-entropy floor for `G-b`, extended to `T41` | `Cell R10.12`, `DEV-R20.3(a)` |
| **17** | `d_min` | `[T]` | lineage-distance minimum for independence | `Cell §15.4`/`G10`; blocked on `P0-01` |
| **18** | `θ_g` | `[T]` | `genome_hash` distance minimum | `Cell §15.4` |
| **19** | `θ_ρ` | `[T]` | measured error-correlation maximum | `Cell §15.4` |
| **20** | `F_max` | `[T]` | `inbreeding_F` ceiling | `Cell §15.4`/`G10` |
| **21** | `UDB_MAX[S_n]` | `[G]` | unverified-distance bound per scope; **`UDB_MAX[S1] ≥ … ≥ UDB_MAX[S5]`** | `P0-05 R0.1`/`R18.2` — ordering inherited, values `[G]` |
| **22** | `UDB(S_n)` at birth | `[D]` | **= 0** | `DEV-R11.4` — **this one HAS a value, and it is 0 by definition** |
| **23** | `B6 STRUCTURAL_BUDGET[scope]` | `[G]` | count/norm of Λ3 ops, per scope, non-fungible | `P0-05 §30` |
| **24** | `B7 PROPOSAL_QUOTA[scope]` | `[G]` | E9/nomination + **DEMAND** rate | `P0-05 §30`; `DEV-R42.1` |
| **25** | **`B8 CONSTITUTIONAL_BUDGET`** | `[G]` | Σ-op count, **organism-global, per envelope interval, non-fungible, non-accumulable, Σ2-exempt** | **P0-06 new** (`DEV-R35.1`); PROPOSED AMENDMENT (8) |
| **26** | envelope interval | `[E]` | the period over which B8 is measured | P0-06; `DEV-R79.1` |
| **27** | `θ_overlap` | `[G]` | membership/contract overlap triggering debt inheritance | `DEV-R39.1(a)` |
| **28** | `θ_div` | `[G]` | organizer divergence tolerance | `DEV-R51.2` |
| **29** | organizer count | `[G]`+`[U]` | **min = 2** (structural, from `DEV-R19.2(h)`/FI-04); max `[G]`; `Cell §15.3` says only *"few"* | **min is derived, not invented**; max UNRESOLVED |
| **30** | `max_open_duration` (abeyance) | `[G]` | abeyance expiry bound | `DEV-R27.4`; M-Σ8 |
| **31** | reconciliation interval | `[G]` | bound on eventual cell-side/K-side agreement | `DEV-R61.3` |
| **32** | `T41` churn cap | `[G]` | `T41` events per envelope interval before `T01` halts | `DEV-R20.3(c)`; `OR-D5` |
| **33** | dev-tick batch size | `[H]`+`[G]` | async-partial scheduling granularity | `DEV-R59.1`; PROPOSED AMENDMENT (11) |
| **34** | branch factor (candidacy) | `[G]` | max concurrent Σ1 candidacies | `DEV-R75.4` |
| **35** | mandatory-path share ceiling | `[G]` | fraction above which a region fails independent-failure | `DEV-R76.1(d)`, `OR-D10` |
| **36** | `θ_ret` | `[T]` | `consecutive_failures` for `T26` | `Cell T26`; blocked |
| **37** | `N_repair`, `N_probation`, `n_calib_min`, `θ_ece`, `RECALIB_INTERVAL` | `[T]` | lifecycle thresholds | `Cell T24`/`T04`/`T05`/`T36`; blocked |
| **38** | `Δ_MAX`, `DELTA_BUDGET` | `[G]` | per-update / per-epoch parameter bounds | `Cell I-17`; inherited |
| **39** | `TRUST_MAX` | `[D]` | **= 0.95** | `Cell I-27` — **inherited value, cited** |
| **40** | degree / fanout caps | `[E]` | `max_connections`, `max_fanout` from genome | `Cell §22`/`P0-03`; bound L4 inhibition fanout (`DEV-R59.2`) |
| **41** | `θ_reserve` (reserved-choice fraction) | `[G]` | governance-reserved share of every choice set | `DEV-R3.3`; **existence is `[D]`, magnitude is `[G]`** |
| **42** | FI redundancy minima | `[D]` | **≥2** for FI-01, FI-04, FI-05; FI-10 is K-held | `DEV-R66.2` — **structural, not numeric** |
| **43** | `|M|` minimum for verification authority | `[D]` | **= 2** | D-D08 — **derived from `Cell I-2`/`I-10`, not chosen** |
| **44** | ablation window | `[V]` | measurement window for `CR-B`/G3; **invalidated by migration** | `DEV-R68.4` |
| **45** | `dev_stage` dwell maxima | `[T]` | per state, in dev ticks / epochs | §88.1 **P-D7**; blocked |
| **46** | Type Registry contents | `[T]` | port/type definitions | `Cell §30`: *"Format resolved (A-1); **contents task-dependent**"* |
| **47** | FI-12 task-dependent invariant set | `[T]` | which additional FIs hold | `DEV-R31.1`, §31.2 |
| **48** | Capability Registry floors | `[T]` | functional-identity third term | `Cell §22.3`; `P0-15` |
| **49** | tier degradation schedule | `[H]` | *"shallow verification"*, *"batched evolution"* | `Cell §22` — inherited qualitative schedule; **D-D23's trade schedule** |
| **50** | `θ_stall` response set | `[D]` | STALL ⟹ freeze unverified change | `P0-05 R0.1` |

> ### **DEV-R90.2 — REGISTRY ACCOUNTING.**
> **50 registered entries (54 named parameters — entries 17–20 group four, entry 37 groups five). Values inherited
> and cited: 4** (region-count ceilings, depth ceilings,
> `TRUST_MAX = 0.95`, tier capacities — all from `Cell §22`/`I-27`, cited not restated). **Values defined by P0-06:
> 2** — `UDB(S_n)` at birth **= 0** (`DEV-R11.4`, a *definition*, not a tuned constant) and `|M| ≥ 2` (D-D08,
> *derived* from `Cell I-2`/`I-10`). **Structural minima that are not numeric choices: 2** (organizer min = 2 from
> `DEV-R19.2(h)`; FI redundancy minima from `DEV-R66.2`). **Values invented by P0-06: 0.**
> **`[U]` count: 1 explicit** (organizer maximum) **plus every `[T]` parameter, which is blocked on `P0-01`** —
> `Cell §30` states that without `P0-01` *"every threshold is arbitrary."* **⟹ 13 of the 50 registry entries are `[T]` or `[T]`-containing — 17 named parameters, since entry 37 groups
> five — and are therefore BLOCKED, not resolved.**

---

# §91 — PARAMETER DEPENDENCY GRAPH

```
                       P0-01 (tasks, environments, fitness)  ── BLOCKING ──┐
                                                                          ↓
   ┌──────────────────────────────────────────────────── [T] class (22 params)
   │   N_stable · θ_success · N_dev_max · d_min · θ_g · θ_ρ · F_max · θ_ret
   │   N_repair · N_probation · n_calib_min · θ_ece · RECALIB_INTERVAL
   │   Type Registry contents · FI-12 set · Registry floors · dev_stage dwells
   │   ablation window semantics · θ_stall targets · …
   └──⟹ EVERY commitment threshold (DEV-R37.1) depends on this class.
        ⟹ **No commitment can be correctly gated until P0-01 exists.**

   ENVELOPE [E] ──→ R (morphogen species) ──→ morphogen_receptors validity
       │          ──→ initial niche set ──→ BC-4 ──→ B1 ECONOMIC BREAK (DEV-R73.1)
       │          ──→ degree/fanout caps ──→ L4 inhibition fanout ──→ DEV-R59.2
       │          ──→ envelope interval ──→ B8 measurement ──→ Σ-rate
       └──→ **heterogeneity of the initial niche set** ──→ whether bootstrap
            differentiates AT ALL (DEV-R73.1 corollary)   ⟵ THE ONE THING
                                                            DEVELOPMENT CANNOT
                                                            SUPPLY FOR ITSELF

   HARDWARE [H] ──→ region ceiling ──→ admissible Σ1 count
       │          ──→ depth ceiling ──→ admissible nesting
       │          ──→ variant availability ──→ C4 ──→ region-core ──→ D-D10
       │          ──→ tier degradation schedule ──→ D-D23 trade
       └──→ **tier change** ──→ recompute all [H] ──→ DEV-R68.3 (downward = governance event)

   GOVERNANCE [G] ──→ UDB_MAX[S_n] ──→ DEV-R11.4 ──→ anchor bootstrap
       │          ──→ B6/B7/B8 ──→ Σ-rate, E-rate, demand-rate
       │          ──→ w_* weights ──→ fate_bias dynamics ──→ symmetry-break behaviour
       │          ──→ θ_entropy ──→ G-b ──→ T41 guard ──→ D-D07
       │          ──→ θ_overlap ──→ laundering detection ──→ D-D17/OR-D8
       │          ──→ θ_div ──→ organizer capture detection ──→ D-D05
       └──→ organizer spec approval ──→ OR-D6 (the OPEN residual)

   DERIVED [L]/[V] ──→ Potential(c,t) ──→ admissibility ──→ commitment
                  ──→ density_internal/boundary ──→ DEV-R21.2 ──→ Σ1 admissibility
                  ──→ ablation_delta ──→ DEV-R1.1 usefulness AND G3 replication
                        └─(must be separated: DEV-R76.1)
```

> ### **DEV-R91.1 — THE THREE BLOCKING DEPENDENCIES.**
> 1. **`P0-01` blocks all 13 `[T]` registry entries (17 named parameters)**, hence every commitment threshold, hence **D1/D2 cannot be
>    correctly gated.** Inherited verbatim: *"Implementing cells before those two exist would produce untestable
>    code against 24 externally-enforced invariants."*
> 2. **The envelope blocks bootstrap itself** — not a parameter value, but the **heterogeneity of the initial niche
>    set** (`DEV-R73.1` corollary). A homogeneous envelope yields no symmetry break. **⟹ This is the only dependency
>    in the graph that development cannot compensate for.**
> 3. **`P0-02` blocks the structural store** (`DEV-R46.1`, PROPOSED AMENDMENT 10), hence Σ-tombstones, provenance,
>    niche ledger, abeyance registry, and reconciliation (`DEV-R61.2`). **⟹ Without it, 39 of 40 DEV-INV
>    invariants are unenforceable**, exactly as `Cell §30` warned for its own 24-of-28.

> ### **DEV-R91.2 — NO PARAMETER DEPENDENCY IS HIDDEN.**
> Every `[U]` and every blocked `[T]` is listed at §90 with its blocker. **§109: "don't hide unresolved
> dependencies."** The graph above is the disclosure.

---

# §92 — SCALABILITY: 10 … 10¹² CELLS

## 92.1 The inherited range and the un-inherited one

`Cell §22` covers **~200 to ~10⁷** cells across five tiers. **10⁸ … 10¹² has no inherited tier.** P0-06 analyses it
structurally and marks the extrapolation `[U]` rather than inventing a tier.

| Scale | Tier | What development looks like | First constraint to bind |
|---|---|---|---|
| **10⁰–10¹** | pre-tier | **Bootstrap only.** B0–B3 (`DEV-R73.1`). One cell ⟹ no S3, no S4, `region_id = null`, D-D08 ⟹ no verification authority. **Output is zero until first commitment** (`DEV-R41.1`) | **BC-4/BC-6**: envelope niche heterogeneity; economic symmetry break |
| **10¹–10²** | smartphone (~200 C2, flat) | First S3 circuits; `|M| ≥ 2` satisfiable; **no C4 ⟹ no region-core ⟹ no regional verification** (D-D10). FI-01/04/05 minima consume a large population fraction (D-D23) | **D-D23**: redundancy vs specialization on a fixed tiny `N` |
| **10²–10³** | laptop (3–5 regions, depth 2–3, C0–C3) | First S4 regions; Σ4 devolution with self-local-verified rungs only; *"shallow verification"* | **`OR-D4`**: regional verification is sandbox-grade |
| **10³–10⁴** | workstation (4–8 regions, depth 3, few C4) | Region-cores exist; `CR-B` at S4 becomes meaningful; first genuine regional ablation | **B8**: Σ-rate becomes the limiting factor on structural refinement |
| **10⁴–10⁶** | GPU server (6–10 regions, depth 4, 10⁵–10⁶ C2) | Nested hierarchy; many S3 per S4; `"full verification dept[h]"` | **`DEV-R59.1`**: tick must be async-partial; **`DEV-R59.2`**: inhibition fanout is degree-capped ⟹ **many local patterns, fragmentation risk (§90 of Vol F)** |
| **10⁶–10⁷** | cluster (8–12 regions, depth 5, island model) | Depth-5 nesting; Σ3 re-homing across islands; migration becomes routine | **Σ-log growth**, **niche ledger size**, **monitor cost M-Σ1…M-Σ9**, **`OR-D8`** gradual-laundering detection over large memberships |
| **10⁸–10⁹** | **`[U]` — NO INHERITED TIER** | Structurally: depth ceiling must rise, but `P0-05`'s ladder tops at S6 and `LEARN-INV-30` makes S6 ∅ for learning ⟹ **there is no scope above S5 to hold authority over 10⁹ cells except S6, which no adaptive mechanism may write** | **SCOPE-DEPTH EXHAUSTION**: the S1–S6 ladder is a **6-level** hierarchy and cannot span 10⁹ cells at bounded fanout |
| **10¹⁰–10¹²** | **`[U]`** | As above, worse. `DEV-R59.1`'s async-partial tick requires O(N/batch) schedule entries; the niche ledger is O(niches); the Σ-log is append-only and permanent ⟹ **O(total Σ-ops ever)** | **PERMANENT-LOG GROWTH** + **scope-depth exhaustion** + **`OR-D1`** (K's pre-constitutional power now spans 10¹² cells) |

## 92.2 The two structural walls

> ### **D-D28 — SCOPE-DEPTH EXHAUSTION ABOVE ~10⁸ CELLS (finding; severity HIGH; status UNRESOLVED).**
> The inherited scope ladder is **S1 synaptic → S2 cellular → S3 micro-circuit → S4 regional → S5 organismal →
> S6 populational**, and **S6 is ∅ for learning** (`LEARN-INV-30`) with Λ4 writable only at S5 (`P0-05 R28.1`).
> `Cell §22`'s deepest tier is **depth 5**. **⟹ At bounded fanout `f`, a 6-level hierarchy spans at most `f⁶`
> cells.** With `Cell`'s degree/fanout caps (`max_connections`, `max_fanout` from genome) — say `f` in the tens —
> `f⁶` is 10⁷–10⁹. **⟹ 10¹² cells cannot be spanned by the inherited scope ladder at inherited fanout.**
> Options, none of which P0-06 may take unilaterally:
> (a) raise `f` — an envelope/genome change (`[E]`), with comm-cost consequences owned by `P0-03`;
> (b) add scope levels — **amending `P0-05 R4.2`'s S1–S6 ladder**, which P0-06 may not do silently;
> (c) accept that V4 does not scale to 10¹² as a single organism, and treat 10¹² as **multiple organisms** — which
> is an S6/populational question, i.e. **evolution's scope, not development's**.
> **P0-06 records (c) as the architecturally honest reading and marks the question UNRESOLVED**, because choosing
> among (a)/(b)/(c) requires `P0-01` (what task needs 10¹² cells?) and `P0-03`/`P0-05` amendments.
> **⟹ P0-06 does NOT claim scalability to 10¹². It states exactly where the wall is and who owns it.**

> ### **D-D29 — THE PERMANENT Σ-LOG DOES NOT SHRINK (finding; severity MEDIUM; status BOUNDED).**
> `DEV-R44.3` and `DEV-R39.1(b)` make provenance and tombstones **permanent, anchored, append-only** — required,
> because they are the sole reconciliation source (`DEV-R61.2`) and the sole laundering defence (`DEV-R39.1`).
> **⟹ Storage grows with the total number of structural operations ever performed, and `DEV-R35.1`'s B8 bounds the
> rate but not the integral.** At 10⁷ cells over a long lifetime this is large but finite; at 10¹² it is not.
> **Bound:** `Cell T29`'s pattern — *"Retention period elapsed; audit complete"* ⟹ deletion requires retention +
> audit + **OP authorization for C3+ and governance roles**. **⟹ Σ-log compaction is an OP-authorized archival act,
> never a runtime one, and compacted records must retain enough to satisfy `DEV-R39.1(a)`'s overlap test** (i.e. the
> membership and contract digests survive compaction even when the full record does not). **Status: BOUNDED.**

## 92.3 What scales well

> ### **DEV-R92.1 — THE DECENTRALIZED HALF SCALES LINEARLY.**
> L1–L8 (`DEV-R55.1`) are **per-cell, local, and bounded by degree cap**. Gradient generation is per-organizer.
> Behavioural self-restriction is unilateral and local. Demand proposals are B7-rate-limited per scope.
> **⟹ The adaptive half of development is O(N) with a small constant and no global coordination.** The K-side half
> is O(Σ-ops + niches + organizers + monitors), **independent of N** except through the Σ-log integral (D-D29) and
> the tick schedule (`DEV-R59.1`, O(N/batch) entries but async). **⟹ P0-06 scales by keeping adaptation local and
> constitution rare — which is exactly what B8 non-accumulability enforces.**

---

# §92A — VOLUME E LEDGER

**Rules minted:** `DEV-R81.1` · `DEV-R82.1` · `DEV-R83.1`–`83.2` · `DEV-R84.1`–`84.2` · `DEV-R85.1` ·
`DEV-R86.1` · `DEV-R87.1` · `DEV-R89.1` · `DEV-R90.1`–`90.2` · `DEV-R91.1`–`91.2` · `DEV-R92.1`, plus the
40 **DEV-INV** invariants and the **7 state machines** (M1–M7).

**Findings:** **D-D27** (the monitor set has no monitor — UNCLOSEABLE-IN-CONTRACT), **D-D28** (scope-depth
exhaustion above ~10⁸ — UNRESOLVED), **D-D29** (permanent Σ-log growth — BOUNDED).

**Counts:** **78 attacks** (70 closed-family = 36 CLOSED + 34 CLOSED-STRUCTURAL; 3 CONDITIONAL; 4 BOUNDED;
**1 OPEN** = A22) · 40 DEV-INV (39 K-enforced, 1 cell-tested) · 7 state machines (M1–M7, incl. the `DevStage`
machine that D-D16 showed did not exist) · 50 registered parameters (**0 values invented**; 4 inherited values
cited; 2 definitional/derived constants) · 14 interface objects (IF-01…IF-14) · 3 blocking dependencies ·
2 structural scalability walls (D-D28, D-D29) · 34-row authority matrix with **no row in which a scope is sole
authority over itself**.

---

**Next → Volume F (`52_analysis_audit_contradictions_research.md`, §93–§104):** ablation design, the
cross-contract contradiction audit, the circular-dependency audit, bootstrap circularity, epistemic and governance
safety, emergent authority / monoculture / fragmentation, equilibrium, and open research.
