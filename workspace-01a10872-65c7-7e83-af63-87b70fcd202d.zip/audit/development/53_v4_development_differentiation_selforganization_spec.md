# V4 — DIFFERENTIATION, DEVELOPMENT & SELF-ORGANIZATION CONTRACT v1.0

**Canonical artifact — Output 95 of P0-06.** Self-contained and implementation-ready.
**Companion analysis:** Volumes A–F (`47_`–`52_`), which contain the derivations, attacks, and audits that justify
every rule below. **Where this document and a volume disagree, this document is normative and the disagreement is a
defect to be reported.**

**Binding inputs:** P0-01 (task/environment/fitness) · P0-02 (EIK) · P0-03 (communication) · P0-04 (memory) ·
P0-05 (learning/plasticity) · V4 Cell Contract v1.0 + Annexes A/B · V3 · V3.1.
**This contract rewrites none of them.** It records **13 proposed amendments** (§14.3), none applied.

> ## ABSOLUTE RULE
> **This is an architecture specification. It is not an implementation.** There is no code, no executable
> developmental system, no simulation, no training or deployment procedure, and no infrastructure specification
> herein. Formal models, schemas, state machines, equations, dependency graphs, tables, and pseudocode-shaped
> specifications are used throughout and are permitted. **No numerical parameter value is invented anywhere in this
> contract** (§13).

---

# PART 0 — SCOPE AND CENTRAL QUESTION

## 0.1 The question

> **What is the minimum set of architectural constraints under which an initially sparse and generic population of
> cells develops stable specialization, circuits, and functional regions — where "minimum" means: remove any one
> constraint and the system either fails to organize, or organizes in a way that is ungovernable, unverifiable, or
> unsafe?**

**§93 of Volume F ablates all 32 mechanisms of this contract. All 32 are NECESSARY; none is redundant.** That result
is the evidence that this constraint set is minimal in the required sense.

## 0.2 The two poles, both of which are real in the source documents

| Pole | Where it already exists |
|---|---|
| **Hard-coded architecture** | **V3 §9** hand-specifies ~20 named regions with assigned functions. **V3 §22 PHASE 6→7** hand-authors the developmental trajectory. **V3 §10** predefines a role menu |
| **Uncontrolled emergence** | **V3.1 §6** lists "Regional plasticity — change population composition — change functional roles — allocate resources — form new subcircuits" with **no authority attached to any of the five** |

## 0.3 The answer

> **Split every developmental object into a SCHEMA and an INSTANCE.**
> **SCHEMA** — the role set, scope definitions, authorization matrices, Σ-operation rules, function-invariant set,
> monitor set — is governance-written (`[RO-13]`/K). **Development may never write schema.**
> **INSTANCE** — which cells occupy which region, which niche slots exist, which specialization each cell carries,
> which subcircuits are formed — is development-written, under `P0-05 §29`'s rung ladder **plus a distinct Σ-class
> for scope constitution**.
> **Authority to write an instance of scope `S_n` is held in ABEYANCE by the kernel K before `S_n` exists, and is
> DEVOLVED to `S_n` at its constitution — an act that simultaneously EXTINGUISHES K's abeyant hold over `S_n`.**
> Development is therefore **real** (it writes instances), **bounded** (it cannot write schema), and
> **self-extinguishing** (its scaffold dies as the structure it scaffolded is born).

## 0.4 What this contract is, in inherited terms

`Cell §30` defers **P0-14 Differentiation engine** (*"BLOCKED … engine itself never written"*) and marks
**P0-28 Region formation** *"Partial"*. **This contract is their completion.** It adds **no cell-level field**
(`Cell §3.1`/`§3.2` are used as written) and **no lifecycle state or transition** (`Cell` Annex B P4 closes the
machine at 18 states / 41 transitions).

---

# PART 1 — NORMATIVE DEFINITIONS

## 1.1 The eight defined terms

| Term | Definition | NOT |
|---|---|---|
| **DEVELOPMENT** | The constitution, dissolution, and re-arrangement of **scopes** (S3 micro-circuits, S4 regions) and of the **instances** that populate them — niches, membership, specialization — by Σ- and E-class operations under devolved authority | **not** growth (`Cell G13` zero-sum), **not** learning (state within a scope), **not** evolution (heritable change), **not** replication (`Cell I-5`), **not** repair, **not** hand reconfiguration, **not** schema change, **not** a controller |
| **DIFFERENTIATION** | Monotone **capacity restriction** over a fixed port set and a genome-bounded reachable-role set, resolving an undifferentiated cell into a committed one | **not** acquisition of new capability; **not** port widening (`Cell I-14`); **not** a `variant` change (which is re-instantiation, `Cell §3.1`) |
| **SPECIALIZATION** | A **reversible state object**: restricted admissible targets, realized intra-role topology, degree of narrowing. Authorized at E4/E7. **Must declare its reversal condition** (`P0-05 R46.1`) | **not** a `role` change. **ROLE IS IDENTITY; SPECIALIZATION IS STATE** |
| **ROLE** | A value of the **closed 16-value `RoleCode` enum** (`Cell §15.3`, wire-level per `Cell A-11`), written by the Organism at commitment and changeable post-commitment only by **EIK+ORG** gated transdifferentiation (`Cell I-23`, `T31`/`T32`) | **not** discoverable by the organism; **not** heritable (`Cell §3.5`) |
| **REGION** | A triple **`⟨M, F, A⟩`**: a **cut** in the communication graph with `mandatory_path` closure; a set of **declared functional contracts** whose satisfaction depends on `M` and whose degradation is detectable without reference to `Mᶜ`; and **devolved S4 authority** | **not** a shared label; **not** an anatomical analogue; **not** constituted by writing `region_id` |
| **NICHE** | `(NicheID, role ∈ RoleCode, region, capacity, occupancy, budget_ref)` — a **budgeted slot for a role in a region**. A role exists in a region only if a niche for it is budgeted there | **not** creatable by any developmental actor; **not** lineage-allocable |
| **SELF-ORGANIZATION** | A population selecting an arrangement of its own members from a **governance-reserved** choice set, driven by signals it generates itself, under schema constraints no member may write | **not** structure arising without specification; **not** structure that thereby acquires authority |
| **POTENTIAL** | `Potential(c,t)` — a **relational** five-conjunct predicate (§3.3), four of whose conjuncts are properties of the environment or of governance | **not** an intrinsic cell property; **never cached as identity** |

## 1.2 The central doctrine

> ### **R1.1 — SPECIALIZATION ADDS NO CAPABILITY.**
> To specialize is to **remove admissible options until the remaining ones are reliable.** A "specialization" that
> widens a port, raises a variant, adds an interface, or increases authority is a **re-instantiation** or a
> **governance act wearing a developmental label**, and is inadmissible.
> **Why restriction produces reliability** (three inherited reasons, not a metaphor):
> (a) **attributability** — `Cell G3`'s ablation delta is measurable only for a load-bearing, narrow contributor;
> (b) **calibratability** — `Cell I-24` makes `epistemic_var` fall with `n_obs` *for stable `s2`*, so a cell that
> concentrates observations on one target distribution calibrates within budget while a generalist calibrates none;
> (c) **independence** — `Cell §15.4` requires **disjoint `evidence_roots`**, which restricted cells have by
> construction (*"a verifier that reads the same evidence as the asserter is not verifying, it is agreeing"*).

> ### **R1.2 — ROLE IS IDENTITY; SPECIALIZATION IS STATE.**
> This distinction resolves the inherited contradiction between `P0-05 R46.1` (specialization reversible at
> same-or-lower rung) and `Cell I-23` (role change requires EIK authorization). **`R46.1` governs SPECIALIZATION;
> `I-23` governs ROLE.** Neither contract is amended. Operationally: machine transition **D4** reverses a
> specialization without touching `role`; transition **D5** changes `role` under EIK gate. **The inherited
> `DevStage` enum could not express D4 at all** — supplying it is this contract's largest single closure (Volume B
> **D-D16**).

> ### **R1.3 — TWO-TIER DIFFERENTIATION.**
> | Tier | Object | Actor | Reversible | Registered |
> |---|---|---|---|---|
> | **BEHAVIORAL** | the cell **acts** restricted: abstains, declines connections, self-throttles | **THE CELL, UNILATERALLY** | always, immediately | no |
> | **NOMINAL** | the cell **is** restricted: `role`, `dev_stage`, `niche_slot`, `region_id` written | **ORGANISM** (Σ/E4/E7); **EIK+ORG** post-commitment | specialization yes; role gated | yes — wire-visible, signed, depended upon |
> **A cell may always restrict its own behaviour without authorization, and may never restrict its own identity
> without authorization.** Derived from `Cell §18.4` (*"a cell that detects its own inconsistency should be able to
> stop talking immediately, without waiting for an authority round-trip"*) and from `Cell I-2`/P15 (a self-declared
> role would confer attestation rights).
> **Metrics of specialization MUST count NOMINAL commitments.** Counting behavioural narrowing as specialization
> produces the appearance of development with none of its governance.

> ### **R1.4 — USEFULNESS IS SERVICE-LEVEL, NOT STRUCTURAL.**
> A developmental outcome is *useful* iff a **declared service-level deficit** (`Cell §15.1`'s
> `DEMAND(role, region, magnitude)`) is measurably reduced, measured by **ablation delta** (`Cell G3`). Region count,
> hierarchy depth, specialization sharpness, symmetry, and anatomical resemblance are **not** measures of usefulness
> and MUST NOT be objectives or fitness terms.

---

# PART 2 — THE Σ-CLASS AND THE ROOT CIRCULARITY

## 2.1 The circularity this part exists to break

`P0-05` defines **S4 ≝ "a specialised population"** and **S3 ≝ "a functionally connected group"**. `P0-05 R46.1`
makes specialization an **S4/E4–E7** change. `P0-05 R4.3` forbids authorizing above one's own scope. And an audit of
`P0-05 §29.1` shows **not one of rungs E0–E9 constitutes a scope** — E4/E6/E7 all *presuppose* the region they
operate in.

> **⟹ `constitute(S4)` requires `auth(·,S4)`; `auth(·,S4)` requires `∃S4`; `∃S4` requires `constitute(S4)`.**
> Corollary: at `t=0` the `P0-05 §28` authorization matrix has **no referents for its own S3–S5 rows**.
> `P0-05 R29.3`'s mandatory decomposition cannot help: **decomposition is well-founded only for composites whose
> rungs all live in an existing scope.**

## 2.2 Σ-operations

> ### **R2.1 — THE Σ-CLASS.** Scope constitution is a **distinct operation class**, disjoint from E0–E9, so that
> `P0-05 §29` is not amended.
>
> | Σ | Operation | Effect | Reversibility | Authority |
> |---|---|---|---|---|
> | **Σ1** | **CONSTITUTE SCOPE** `S_n` | membership set, enumerated boundary, contract refs, `budget_ref`, anchor slot, `dissolution_cond` | `VERSION_REVERSIBLE` (by Σ2) | **K, ABEYANT** |
> | **Σ2** | **DISSOLVE SCOPE** `S_n` | re-home members, release niches, write Σ-tombstone | **`IRREVERSIBLE_STRUCTURAL`** | **K + `[RO-13]`** for S4+ |
> | **Σ3** | **RE-HOME POPULATION** across existing scopes | change `region_id`; re-enumerate boundaries | `VERSION_REVERSIBLE` | **ORGANISM + both scopes** |
> | **Σ4** | **DEVOLVE AUTHORITY** over `S_n` | transfer K's abeyant hold to `S_n`; **expire the abeyance** | **`IRREVERSIBLE`** additively (retractive amendment permitted, R2.6) | **K only** |
>
> **Σ-operations write INSTANCES only.** Not `RoleCode`, not scope definitions, not any authorization matrix, not
> the Σ-rules, not the function-invariant set, not the monitor set. **A Σ-operation that attempts to write schema is
> inadmissible by construction.**

> ### **R2.2 — ABEYANCE.** Before `S_n` exists, authority over `S_n` is held **in abeyance by K** — the `P0-02`
> off-substrate kernel, the only inherited entity that exists at `t=0`, is not a scope member, and holds authority
> not derived from any structural position. **Abeyance is not delegation:** it is a K-owned record with an expiry.
> ```
> AbeyanceRecord ::= { scope, opened_at, opened_by : K,
>                      constitutions_permitted : set<Σ1-spec>,   // WHAT K may constitute, PRE-DECLARED
>                      max_open_duration : [G],
>                      expiry_condition : (Σ4 executed) ∨ (Σ1 abandoned) ∨ (envelope revoked) }
> ```

> ### **R2.3 — DEVOLUTION IS SELF-EXTINGUISHING.** **Σ1 constitutes `S_n`; Σ4 devolves K's abeyant hold to `S_n`;
> Σ4 simultaneously EXPIRES that hold.** K cannot retain authority over a constituted scope and cannot re-acquire it
> except by Σ2. **⟹ There is no standing developmental controller: the controller's authority over each scope dies
> at that scope's birth.**

> ### **R2.4 — WRITER SEPARATION (the cycle-breaker).** Three writers, pairwise distinct, for every Σ-operation:
> | Role | Holder |
> |---|---|
> | **Writer of SCHEMA** (what a region may be) | `[RO-13]` / K |
> | **Executor of the INSTANCE** (Σ1–Σ4 as an act) | **K, abeyant** |
> | **Beneficiary of the AUTHORITY** | **`S_n` itself**, post-Σ4 |
> **A bound limits a cycle; writer separation breaks a cycle.** No bound on region count, formation rate, hierarchy
> depth, population size, or developmental budget breaks §2.1's circularity. **This contract never claims otherwise.**

> ### **R2.5 — ORDERING IS NORMATIVE: Σ1 → Σ4 → E\*.** Executing any E-rung against a scope that does not yet exist
> is **scope elevation** (`P0-05 LEARN-A5`, `R4.3`) and is inadmissible. **This single ordering makes bootstrap
> well-founded (Part 9).**

> ### **R2.6 — RETRACTION WITHOUT DISSOLUTION.** `devolved_authority` is a SET. **K may REMOVE elements from it
> (restrictive retraction) without dissolving the scope; K may never ADD elements except by fresh Σ4.** Σ4's
> irreversibility is **additive-direction only**. This is the L2 instrument of the failure ladder (Part 10.6) and
> follows `Cell` P12's directional principle and `Cell §18.5`'s `RESTRICT` rung.

## 2.3 The Σ-authorization matrix

| Operation | Pre-constitution authority | Post-constitution authority | Evidence required | Budget |
|---|---|---|---|---|
| **Σ1** constitute S3 | **K abeyant** | — | existence predicate (R4.2); `mandatory_path_closure`; declared `dissolution_cond` | **B8** |
| **Σ1** constitute S4 | **K abeyant** | — | as above + `F ≠ ∅` + measurable `ablation_delta` + **`|M| ≥ 2`** if verification authority is devolved | **B8** |
| **Σ2** dissolve | **K abeyant + `[RO-13]`** (S4+) | K + `[RO-13]` | re-homing plan executed; mandatory-path drain record (`Cell G-f`); niche release; **Σ-tombstone** | **none** |
| **Σ3** re-home | n/a | ORGANISM + both scopes | `region_id` evidence; boundary re-enumeration; **overlap check vs Σ-tombstones** | **B8** |
| **Σ4** devolve | **K only** | — | enumerated rung set; anchor status; full Σ1 evidence chain; role-authority re-authorization where applicable | **B8** |
| **E4/E5/E6/E7** | ❌ **inadmissible** | per `P0-05 §29.1` | per `P0-05 §29.1` | **B6** |

---

# PART 3 — CELL-LEVEL DEVELOPMENT

## 3.1 Fields used (all inherited; **no new cell field**)

`genome.development`: `reaction_norm` (reachable roles + bias — *"NOT the role itself"*), `morphogen_receptors`,
`critical_periods`, `commitment_schedule`, `rng_seed_class = EIK_ISSUED`.
State: `dev_stage` (**O only**), `fate_bias` (**O, C↑ within `reaction_norm`**), `morphogen_readings` (**C reads,
O writes**; `transient`), `niche_slot` (**O only**), `region_id` (**Organism, not the cell**; nullable).
Identity: `role` (**Organism**; EIK+ORG post-commitment), `variant` (**EIK**; re-instantiation only).

> ### **R3.1 — GENOME/DEVELOPMENT WRITE SEPARATION.** Genome fields are **E9-only**. Developmental state fields are
> **O/Σ-written**. **No developmental process writes a genome field; no replication process writes a developmental
> state field.** Enforced at EIK level by `Cell I-5` and `I-8`.

> ### **R3.2 — THE GENOME CARRIES CONSTRAINTS; THE ENVIRONMENT CARRIES CONTENT.** Heritable developmental
> information MUST be a **constraint over futures** (reachability, timing, irreversibility), **never a specification
> of a future** (which role, which region, which neighbour).

## 3.3 Potential

> ### **R3.3 — POTENTIAL IS RELATIONAL.**
> ```
> Potential(c,t) = { r ∈ RoleCode :
>        r ∈ genome(c).reaction_norm                        // genetic reachability
>     ∧  variant(c) ≥ min_variant(r)                        // tier requirement (Cell §15.3)
>     ∧  ∃ niche n: role(n)=r ∧ region(n) ∈ reachable(c,t) ∧ occupancy(n) < capacity(n)
>     ∧  independence_satisfiable(c, r)                     // CRITIC/VERIFIER (Cell §15.4, I-10)
>     ∧  ¬blocked_by_guard(c, r, t) }                       // Cell G-a, G-b, G-c
> ```
> **Four of five conjuncts are environmental or governance properties.** ⟹ **R3.4: potential MUST be recomputed,
> never cached as identity.** ⟹ **R3.5: a cell's potential may increase only when its environment's authorized
> capacity increases, never by its own act** (`P0-05 R28.2` transplanted).

## 3.4 Local rules (complete — the "emergent" discipline)

> ### **R3.6 — LOCAL RULES OF DEVELOPMENT.** *Per cell, per organism-scheduled dev tick:*
> ```
> L1 SAMPLE   warranted reading exists? m_c ← morphogen_readings(c) : m_c ← ⊥  (positional term := 0)
> L2 READ     n_c ← K-advertised niches · d_c ← DEMAND proposals · s_c ← own success history · g_c ← reaction_norm
> L3 EXCITE   excitation_r = w_g·g_c[r] + w_m·affinity(m_c,r) + w_d·d_c[r] + w_s·s_c[r] + w_n·n_c[r]
> L4 INHIBIT  inhibition_r = Σ_{neighbours n committed to r} w_i · inhibit_strength(n)
> L5 UPDATE   fate_bias_c ← normalize_softmax((excitation − inhibition) / T_dev(dev_stage_c))
>             writer: O, and C↑ within reaction_norm            [inherited verbatim]
> L6 EMIT     if COMMITTED with role r: emit INHIBITION(r, strength) to neighbours
> L7 RESTRICT (optional, UNILATERAL, no authority) abstain / decline / self-throttle.
>             NEVER writes role, dev_stage, region_id, niche_slot
> L8 PROPOSE  (rate-limited by B7, no effect, no budget) emit DEMAND(role, region, magnitude)
> ```
> *Per K, asynchronously:* **K1** WARRANT gradients against registered organizer specs · **K2** ACCOUNT niches ·
> **K3** ADMIT (evaluate R3.3 mechanically, no discretion) · **K4** AUTHORIZE Σ-operations within open abeyances,
> write anchors from verification records only · **K5** LOG provenance and Σ-tombstones, anchor externally ·
> **K6** GUARD (`Cell G-a`…`G-f` extended per R7.4; budgets B6/B7/B8) · **K7** DETECT (monitors M-Σ1…M-Σ9).

> ### **R3.7 — RANDOMNESS MAY CHOOSE; IT MAY NEVER QUALIFY.** A seed may break a tie between **equally admissible**
> outcomes. It may never be the reason an outcome is admissible, competent, authorized, or verified.
> **⟹ Symmetry is broken by EXTERNAL CONTACT, not by internal noise.**

> ### **R3.8 — INHIBITION AMPLIFIES; IT DOES NOT ORIGINATE.** In a perfectly homogeneous field with no committed
> cell, `inhibition_r = 0` ∀r and no cell can commit first. **The four admissible asymmetry sources are: positional
> gradient · niche availability · input channel · RNG seed (tie-break only).**
> **⟹ R3.9: a field with no external asymmetry does NOT differentiate, and this is CONFORMANT, not a failure.**
> `Cell T41`'s "no stable `fate_bias`" condition fires **only when an asymmetry was present and the cell did not
> respond to it** (proposed amendment 7).

> ### **R3.10 — `T_dev` IS MONOTONE DECREASING ON A GENOME-FIXED SCHEDULE, AND NEITHER DIRECTION IS ADAPTIVELY
> CONTROLLABLE.** `commitment_schedule` and `critical_periods` are genome fields ⟹ E9-only. **The organism may
> neither raise `T_dev` (re-open commitment = capacity increase) nor lower it faster (manufacture irreversibility,
> then claim `Cell I-23` protection).** This asymmetry is deliberate.

> ### **R3.11 — A CRITICAL PERIOD IS A PERMISSION WINDOW, NOT A PRESSURE.** Outside a window structural change is
> **inadmissible** (a gate, not a price). Inside it, change is **permitted but never compelled**: **a closing window
> MUST NOT force commitment.** Window closure is restrictive (permitted); re-opening is a capacity increase
> (`Cell I-23`-gated). **The design "commit or die at window close" is prohibited.**

## 3.5 Commitment

> ### **R3.12 — COMMITMENT IS A SIX-CONJUNCT CONJUNCTION, EACH SEPARATELY EVIDENCED.**
> ```
> COMMIT(c,r) ⟸ stable_argmax(c,r,N_stable)              [Cell §15.2(i)]   evidence: engine-held fate_bias history
>             ∧ measured_success(c,r) ≥ θ_success         [Cell §15.2(ii)]  evidence: probe / CR-B   ⟵ COMPETENCE
>             ∧ niche_confirmed(niche(c),r)               [Cell §15.2(iii)] evidence: K accounting     ⟵ BUDGET
>             ∧ authorized_by(O | K_abeyant)              [Cell §15.2(iv)]  evidence: signature + log  ⟵ AUTHORITY
>             ∧ Potential(c,t) ∋ r                        [R3.3]            evidence: conjunct evaluation
>             ∧ ¬(T41-qualifying condition)               [R3.9]            evidence: asymmetry-present check
> ```

> ### **R3.13 — DEMAND PROPOSES; COMPETENCE AND AUTHORITY DISPOSE.** A service-level deficit is a **necessary input**
> to differentiation and **never a sufficient authorization** for it. **No `niche_slot`, `role`, `dev_stage`, or
> `region_id` write may cite demand as its sole justification, and its evidence artifact MUST include a competence
> measurement and an authority signature.**
> This resolves the inherited contradiction (`Cell §15.1`/`T31` make demand a trigger; `P0-05 R46.1` rules
> demand-authorization inadmissible because demand is SC-1/SC-2) by reclassifying demand from **trigger** to
> **proposal-input** under `P0-05 R29.2` — *"a lower rung may propose, never execute, a higher rung; the proposal
> carries no effect and consumes no budget."* **Neither contract is amended.**

> ### **R3.14 — A TRANSDIFFERENTIATED CELL IS NEVER `ACTIVE` ON SANDBOX EVIDENCE.** `Cell T32` admits to
> `CALIBRATING` only; the full `T04 → PROBATIONARY → T05 → ACTIVE` progression is **mandatory and non-waivable,
> including in crisis**. **A crisis MUST NOT shorten the calibration ladder**, because a crisis is exactly when
> verification is weakest and the incentive to skip it is strongest. **Corollary, stated plainly: a crisis is not
> immediately relieved by `T31`; any capacity plan relying on crisis transdifferentiation for immediate relief is
> unsound.**

> ### **R3.15 — CALIBRATION STATE DOES NOT TRANSFER ACROSS A NOMINAL IDENTITY CHANGE.** A committed cell MUST NOT
> carry forward `n_obs`, `calibration_class`, or `epistemic_var` from its pre-commitment generalist period.
> Pre-commitment observations on a different target distribution are not evidence about this one (`Cell I-9`, `I-24`;
> `Cell T03`/`T23`/`T32` all route through `CALIBRATING`).

---

# PART 4 — REGION-LEVEL DEVELOPMENT

## 4.1 The region

> ### **R4.1 — A REGION IS `⟨M, F, A⟩`.**
> **`M` MEMBERSHIP (the cut):** non-empty; internal communication density > boundary density; **`mandatory_path`
> closure** — a `mandatory_path` may not cross the boundary (`Cell I-22`, `G-f`).
> **`F` FUNCTION (the failure unit):** non-empty set of declared functional contracts whose satisfaction depends on
> `M`; removing `M` yields a measurable ablation delta; degrading `M` is **detectable without reference to `Mᶜ`**.
> **`A` AUTHORITY (the scope):** devolved S4 authority, held in abeyance by K until Σ1 and Σ4.
> **All three are required.** `M` alone is a label; `⟨M,F⟩` alone is unempowered; `⟨M,A⟩` alone is circular.

> ### **R4.2 — REGION EXISTENCE IS A VERIFIABLE PREDICATE, NOT A DECLARATION.**
> ```
> region_exists(⟨M,F,A⟩) ⟺ M ≠ ∅ ∧ density_internal(M) > density_boundary(M,Mᶜ)
>                          ∧ mandatory_path_closure(M)
>                          ∧ F ≠ ∅ ∧ ablation_delta(F,M) measurable
>                          ∧ degradation_of(M) detectable without reference to Mᶜ
>                          ∧ Σ1(⟨M,F⟩) executed ∧ Σ4(A) executed
>                          ∧ (anchor(S4) established ∨ UDB(S4) = 0)
> ```
> **Writing `region_id` to a set of cells does not make them a region.** A `region_id` write without a satisfied
> predicate is a **false structural claim** and an integrity failure (Part 10.1).

> ### **R4.3 — `|M| ≥ 2` IS REQUIRED TO DEVOLVE ANY VERIFICATION-BEARING AUTHORITY.** A one-cell region has no
> internal verification (`Cell I-2`/`I-10`; `CR-B` and `C-2` need a second party). It may exist as a functional unit
> **without devolved verification authority**. `V3 §22 PHASE 6` ("one functional region") is satisfiable; the first
> region cannot hold regional verification authority.

## 4.2 The record

> ### **R4.4 — `RegionRecord` (instance-level only).**
> ```
> RegionRecord ::= {
>   region_id : bytes<16>            // K-issued, never self-chosen, NEVER REUSED
>   version : u32                    // Σ-ops are VERSION_REVERSIBLE
>   membership : set<cell_id>        // M
>   boundary : set<connection_id>    // ENUMERATED — an implicit boundary is inadmissible
>   mandatory_paths : set<connection_id>   // MUST be internal
>   contracts : set<FunctionalContractRef>  // F — refs, not copies
>   niches : set<NicheID>            // K-accounted
>   budget_ref : BudgetRef           // POINTER — a region NEVER owns a quantity
>   devolved_authority : set<Rung>   // ENUMERATED ⊆ {E0..E7} ∪ {Σ3}; no general grant exists
>   anchor : ⟨state_digest | ⊥⟩      // ⊥ until first verified state
>   udb_credit : Distance            // 0 while anchor = ⊥
>   parent_scope : ⟨region_id | S5 | ⊥⟩
>   constituted_at : ⟨epoch, ts, authority=K_abeyant, evidence_ref⟩
>   dissolution_cond : Condition     // MANDATORY, non-nullable
> }
> ```
> **Every field is an instance.** A `RegionRecord` that could hold a rung *definition* rather than a rung
> *reference* would be a schema-writing developmental object.

> ### **R4.5 — EVERY CONSTITUTION CARRIES A DISSOLUTION CONDITION.** `dissolution_cond` specifies: (i) the
> service-level deficit whose disappearance justifies dissolution; (ii) the **contract-preservation** requirement for
> re-homing `M` — **not a named successor**, since no successor can be known at constitution; (iii) disposition of
> `mandatory_paths` (drain last, record closure for successors, `Cell G-f`); (iv) niche release.
> **⟹ An un-dissolvable region is entrenched authority. Dissolution is the only brake on devolution, so dissolution
> must be pre-planned while the region is weak.**

> ### **R4.6 — BOUNDARIES COST; THEY NEVER BLOCK.** A region boundary is **not** a firewall. It raises the warrant
> class required for cross-boundary structural claims, consumes `B6`, and weakens verification. **It MUST NOT block
> messages** — `Cell I-28` requires global reporting of error classes {4,7,9,10} and severity ≥S2, and `Cell` P8
> makes `SAFETY_ALERT`/`VIOLATION_REPORT` emission never-blocked. **⟹ A region boundary MUST NOT be a network
> partition** (this preserves `P0-03`'s delivery preconditions).

## 4.3 Function invariants

> ### **R4.7 — ANATOMY IS NON-NORMATIVE; FUNCTION IS NORMATIVE (Option C).**
> V3 §9's region taxonomy is **descriptive vocabulary**: it confers no requirement, no target, no fitness term, no
> authority. Anatomical names **may** be human-facing scope labels (`P0-05 R72.5`) and **MUST NOT** appear in
> `RegionRecord` fields, authority predicates, fitness terms, invariant definitions, admissibility checks, or wire
> schemas. **A system that develops zero hippocampus-like regions and satisfies every function invariant is
> CONFORMANT. A system with a perfect V3 §9 anatomy that violates a function invariant is NON-CONFORMANT.**
> **Eight of V3 §9's elements are inadmissible as regions** — frontal (a central executive), parietal (task-dependent
> spatial representation), occipital (modality-specific), insula-like (covered by `Cell`'s State block and FI-08),
> basal ganglia (action-value and policy selection are `[RO-13]` reward/fitness objects), subthalamus-like
> (competition is `P0-05`/`Cell §16`), pons-like (no contract support), midbrain-like (**reward is `[RO-13]`; a
> region producing reward would be a hidden governance layer**). **Each drop is because the function belongs to a
> prior contract's governance object or is task-dependent.**

> ### **R4.8 — THE FUNCTION-INVARIANT SET (12). Derived, never invented: every row cites a contract.**
> | # | Invariant | Derived from | Localization class |
> |---|---|---|---|
> | **FI-01** | Ingress/egress separation — disjoint cell sets | `Cell §15.3` (`EGRESS` *"may not also be `INGRESS`"*) | **PROHIBITED-localization** |
> | **FI-02** | Routing exists, and is an **allocation** act only | `P0-04 MEM-INV-50`; `P0-05` broadcast-as-allocation; V3 §9 thalamus-like | INTERNAL |
> | **FI-03** | Homeostatic actuation exists; **term-limited, rotating, itself regulated** | `Cell §15.3` `REGULATOR`; `P0-05 R58.2` | INTERNAL |
> | **FI-04** | Positional information is generated by **≥2 organizers with disjoint registered specs** | R6.4; `Cell §15.3` `ORGANIZER` | INTERNAL |
> | **FI-05** | Independent verification exists, kernel-attested | `Cell §15.4`, `I-10`; V3 §3 *"redundant critics"* | **PROHIBITED-localization** (no shared lineage ≥`d_min`, seeds, ordering, `evidence_roots`) |
> | **FI-06** | Prediction / error-correction exists | `Cell §15.3` `PREDICTOR`; V3 §9 cerebellum-like | INTERNAL |
> | **FI-07** | Hierarchical aggregation exists, with fanout caps | `Cell §15.3` `COMPRESSOR` (*"impossible without [it]"*) | INTERNAL |
> | **FI-08** | Threat/salience prioritization exists; **MUST NOT thereby acquire actuation authority** | V3 §9 amygdala-like; `Cell I-15` (execution monopolized by EIK) | INTERNAL + PROHIBITED from actuation |
> | **FI-09** | Episodic/relational memory liaison exists; protected-memory write **EIK-granted, audited, never self-granted** | `Cell §15.3` `MEMORY_KEEPER`; `P0-04` | INTERNAL |
> | **FI-10** | Emergency core regulation **survives region failure ⟹ MUST be K-held or `mandatory_path`-protected** | `Cell §18.4` (*"a cell cannot be its own immune system"*); `Cell I-21`; V3 §9 medulla-like | **EXTERNAL — MUST be K-held** |
> | **FI-11** | **No region is its own immune system** — diagnosis/quarantine/retirement/repair authority lies outside it | `Cell §18.4`, `I-21`, `§15.3` `REPAIR` *"may not repair itself"* | **PROHIBITED-localization** |
> | **FI-12** | Functional decomposition is **task-dependent** | `P0-01`; `Cell §30` (Type Registry contents task-dependent) | EXTERNAL |
>
> **The three PROHIBITED-localization invariants (FI-01, FI-05, FI-11) are the ONLY localization constraints in the
> architecture, and all three are separation-of-powers constraints, not anatomical ones.**
> **⟹ V3 §9's "brainstem — core regulation / emergency safety" is NOT A REGION. It is K, wearing an anatomical
> name.** Treating it as a region would place emergency safety inside the substrate that can fail, be quarantined, be
> dissolved, and be captured.

> ### **R4.9 — INVARIANT SATISFACTION IS A PREDICATE OVER THE POPULATION, NOT OVER REGIONS.** Each FI must be
> satisfied by **some** `M ⊆ population`; `M` need not be a region — it may be a circuit, a set spanning regions, or
> K itself (FI-10). **⟹ P0-06 does NOT require invariants to map onto regions, and MUST NOT be read as prescribing a
> minimum region count.** A flat population (`Cell §22` smartphone tier) can satisfy FI-01…FI-09 and FI-11 with
> **zero regions** and is conformant.
> **R4.10 — verifiability is a REASON to constitute, never a REQUIREMENT to.** Where an FI is satisfied by a
> non-regional `M`, constituting it as an S3 circuit is **RECOMMENDED** (it makes `CR-B` and ablation available) and
> **never REQUIRED** (requiring it would make region count a target). **Honest residual: for a non-regional `M` there
> is no inherited instrument establishing `ablation_delta(FI, M)` — invariant satisfaction in a flat population is
> ASSERTED BUT NOT VERIFIABLE. Recorded UNRESOLVED.**

## 4.4 Region identity

> ### **R4.11 — IDENTITY IS THE TRIPLE; MEMBERSHIP IS NOT IDENTITY-BEARING.** `r` at `t₁` and `r'` at `t₂` are the
> same region iff:
> ```
>   region_id(r) = region_id(r')                       // K-issued, never reused
> ∧ contracts(r) ≈ contracts(r')
> ∧ devolved_authority(r) = devolved_authority(r')
> ∧ lineage_continuity(M(r) → M(r'))                   // Cell §22.3's second term
> ∧ Registry floors satisfied at both times             // Cell §22.3's third term
> ∧ version(r') reachable from version(r) by Σ3/E4/E5 ONLY   ⟵ ANTI-LAUNDERING
> ```
> **Functional identity is inherited verbatim** (`Cell §22.3`: *"the set of satisfied functional contracts at circuit
> and region level, plus the lineage continuity, plus the Capability Registry floors"*) and contains **no term
> mentioning hardware, host, device, or address**. **⟹ A region's identity survives migration; its locality does
> not.** Locality is a placement property, recorded separately, and MUST NOT appear in `region_id`, in the
> functional-identity computation, or in any authority predicate.
> **Total membership replacement through lineage backup preserves identity — and must, or recovery is impossible.**
> **Lineage continuity governs membership replacement; lineage blindness governs niche allocation. Different objects;
> no conflict.**

> ### **R4.12 — LOCALITY HINTS ARE ADVISORY; INDEPENDENCE DOMINATES THEM.** Placement may minimize boundary traffic
> and latency, subject to `Cell §15.4` independence, `mandatory_path_closure`, FI separation constraints, and tier
> ceilings. **Where locality and any of these conflict, locality loses.** *The concrete trap:* the highest-traffic
> pair in a verification architecture is verifier↔asserter, so naive locality optimization **systematically destroys
> FI-05**.

---

# PART 5 — SIGNALS AND POSITIONAL INFORMATION

## 5.1 The channel

> ### **R5.1 — ONE MESSAGE TYPE, FOUR CLASSES.** `dev.morphogen.v1` (`Cell §7`) is the **single** developmental
> message type. **This contract adds no `MessageType` value** (`Cell A-11`: closed 34-value wire enum). The four
> classes are a payload discriminator inside it — the smallest sufficient mechanism.
>
> | Class | Producer | Warrant | Retry | Effect |
> |---|---|---|---|---|
> | **POSITION** | `ORGANIZER` cells generate; **O warrants** | unsigned at generation; **organism-signed at warrant** | ❌ (`ttl` short) | `fate_bias` term `w_m` |
> | **DEMAND** | homeostasis / any cell | ❌ SC-1/SC-2 | ❌ | **proposal only — no effect, no budget** (R3.13), B7-limited |
> | **INHIBITION** | committed neighbours | ❌ | ❌ | `fate_bias` term `−Σ w_i` — **the symmetry-breaker** |
> | **NICHE** | **K** (accounting) / `[RO-13]` (authorization) | ✅ **K-signed** | ✅ **at-least-once, idempotent** | admissibility (R3.3), `Cell G11` |
>
> **Asymmetric retry is deliberate:** POSITION/DEMAND/INHIBITION are **transient field values** whose stale delivery
> is actively harmful; NICHE is a **standing authorization fact** whose loss causes `T41` developmental failure for
> want of a niche. *(Proposed amendment 6 to `Cell §7`.)*
> **Priority 2 is inherited and MUST NOT be raised** — a developmental backlog must never delay an alert (`Cell I-28`,
> P8). Raising it would be developmental authority acquisition by precedence.

> ### **R5.2 — THE FOUR CLASSES ARE CLOSED, AND NOTHING ELSE MAY BE CARRIED.** A developmental signal **MUST NOT**
> carry truth, warrant, confidence, a verdict, an attestation, provenance, authority, a fitness value, or a
> governance decision. **All four classes are INFLUENCE-plane** (`P0-03`); none is WARRANT-plane; **none may raise a
> recipient's confidence, warrant, or trust** (`COMM-INV-08`). **⟹ A morphogen biases `fate_bias`. It never
> justifies anything.**

> ### **R5.3 — POSITION MUST BE A FUNCTION OF POSITION.** A POSITION-class signal received by `c` depends on `c`'s
> location in the population graph and the organizer's registered emission spec — and **MUST NOT** depend on `c`'s
> identity, lineage, role, past performance, or preferences. Otherwise positional information becomes a **targeted
> governance channel**: steering specific cells to specific fates while presenting the steering as environment.

## 5.2 Generation vs warrant

> ### **R5.4 — ORGANIZERS GENERATE; THE ENGINE WARRANTS.**
> | Layer | Object | Producer | Signed |
> |---|---|---|---|
> | **GENERATION** | the gradient field | **`ORGANIZER` cells** | ❌ unsigned cell output — advisory, untrusted |
> | **SAMPLING** | receptor-mediated sample | **the cell** | ❌ raw observation |
> | **WARRANT** | the `morphogen_readings` state field | **O (differentiation engine)**, checked against the organizer's **registered emission spec** | ✅ organism-signed — authoritative |
> This preserves all three inherited statements (`Cell §15.3` organizers emit; `Cell §7` engine signs; `Cell` state
> table O writes) **and creates the detection hook**: because K knows what an organizer *should* have emitted, a
> captured organizer is detectable by divergence.

> ### **R5.5 — POSITION IS RE-DERIVED, NEVER RESTORED.** `morphogen_readings` is `transient` and uncheckpointable.
> On re-development (`Cell T25`/`T34`) positional information is **re-acquired from the current gradient field and
> current region partition**. **A re-developed cell takes the position the population currently has, not the position
> its predecessor had** — so it may land in a different niche and role while preserving `lineage_id` and functional
> identity. **⟹ A region cannot be restored by re-developing its members; region membership is a Σ3 object.**

## 5.3 Organizers

> ### **R5.6 — ORGANIZER CONSTRAINTS.** (a) **registered emission spec** at appointment, part of the warrant basis;
> (b) **reconstructibility** — K MUST recompute the expected field from `{registered spec, position}`; divergence
> beyond tolerance ⟹ readings **not warranted**, so no `fate_bias` is affected; (c) **amplitude bound** `[G]`;
> (d) **no self-reference** — an organizer's own `fate_bias` MUST NOT depend on its own emission;
> (e) **POSITION and INHIBITION classes only** — never DEMAND (homeostasis) or NICHE (K);
> (f) **term-limited with mandatory rotation**; (g) **no organizer may appoint its successor**;
> (h) **≥2 organizers with disjoint registered specs**, so a single captured organizer produces **detectable
> disagreement**; (i) **appointment and removal are Σ4-class acts**.
> **Minimum count 2 is derived, not chosen** (from (h) and FI-04). **Maximum is `[U]`** — `Cell §15.3` says only
> *"few"*; **no value is invented.**

> ### **R5.7 — ORGANIZERS CANNOT BE ELIMINATED.** Central manufacture of positional information **is** V3 §9's
> hand-coded anatomy re-entering through a data channel, and makes every cell's fate a function of a central decision.
> Without organizers, symmetry breaking has no external contact and only the seed remains — which may choose but may
> not qualify. **⟹ Organizers are load-bearing. They must be bounded, not removed.**
> **Honest residual: an organizer operating WITHIN its registered spec can still steer development. Detection has no
> reference. The only defence is `[RO-13]` approval of the spec itself — governance, not architecture. This is the
> contract's single OPEN attack.**

---

# PART 6 — AUTHORITY

## 6.1 What a scope may never hold

> ### **R6.1 — THE NEVER-HELD SET.** A constituted region or circuit may **never** hold: **Σ1/Σ2/Σ4** ·
> **Σ3 across scopes it does not belong to** · **E8** (Λ4: `P0-05 R28.1` restricts to `{POLICY(RO-13), EIK}`) ·
> **E9** (`Cell I-5`, `I-8`) · **niche accounting or creation** · **quarantine / retirement / throttle / repair of
> another cell** (`Cell I-21`: *"authority absent by construction"* — a region is a set of cells and inherits the
> absence) · **self-verification** (`Cell I-2`, `I-10`) · **anchor writing**.

> ### **R6.2 — NO STRUCTURAL FACT CONFER AUTHORITY.** Authority is conferred **only** by Σ4 devolution from
> K-abeyance, against an enumerated rung set, with logged evidence. **Density, size, centrality, uptime, success
> history, ablation delta, calibration quality, trust, and lineage depth confer nothing.**
> **The specific trap: ablation delta must never be an authority criterion.** A component that cannot be removed
> without severe degradation can resist governance by threatening its own removal. **⟹ High-delta components get MORE
> SCRUTINY, not more authority** (`Cell §15.3`'s treatment of `ORGANIZER`/`REGULATOR` is the inherited precedent).

> ### **R6.3 — THE ∅-SET IS A STRICT SUPERSET OF LEARNING'S.** Development inherits every `P0-05 §28` prohibition
> (authorization matrix, Λ-classes, rung definitions, `UDB_MAX` ladder, validation core, reward, fitness) **and
> adds** prohibitions on: `RoleCode` membership, scope definitions S1–S6, the Σ-rules themselves, `reaction_norm` and
> all `genome.development` fields, envelope ceilings, niche accounting, and anchors. **⟹ The subsystem that creates
> structure is MORE constrained than the subsystem that adapts within it, because its acts are less reversible and
> less verifiable.**

## 6.2 The authority matrix (condensed; full form in Volume E §89)

Actors: **OP** (human) · **`[RO-13]`** · **K** · **ORG** · **REGION** · **CIRCUIT** · **CELL** · **ORGANIZER**.

| Operation | Sole authority | Also permitted | Explicitly denied to |
|---|---|---|---|
| Envelope / ceilings / initial niche set | **OP + `[RO-13]`** | K executes | ORG, REGION, CELL |
| Schema (Σ-rules, scope defs, FI set, `RoleCode`, monitors) | **`[RO-13]`** | — | **everyone else, absolutely** |
| Abeyance open/close | **K** | OP, `[RO-13]` | ORG, REGION, CELL |
| **Σ1 / Σ2 / Σ4** | **K** | OP, `[RO-13]` | **ORG, REGION, CIRCUIT, CELL, ORGANIZER** |
| **Σ3** re-home | — | K, ORG **+ both scopes** | REGION (consent only), CELL |
| Rung retraction (restrictive) | **K** | OP, `[RO-13]` | REGION |
| Rung re-grant | **K via fresh Σ4** | OP, `[RO-13]` | REGION |
| **E4** recruit | — | K, ORG, **REGION if devolved** | CIRCUIT, CELL |
| **E5** release/retire cell | **K** | ORG per retirement regime | **REGION, CIRCUIT, CELL** (`Cell I-21`) |
| **E6** subcircuit | — | K, ORG, REGION if devolved | CELL |
| **E7** regional topology / specialization degree | **`[RO-13]`** | K | ORG, REGION, CELL |
| **E8 / E9** | **`[RO-13]` / K** | — | all substrate actors (E9: CELL may **propose** only, B7) |
| Commit `dev_stage` (D1/D2) | **ORG** | K | **CELL** (*"the cell cannot self-commit"*) |
| Role change (D5/D6) | **K + ORG** | OP | CELL, REGION |
| Write `role`/`region_id`/`niche_slot` | **ORG** | K | **CELL** |
| Raise own `fate_bias` within `reaction_norm` | **CELL** | ORG | — |
| **Behavioural self-restriction (L7)** | **CELL, unilateral** | REGION, ORGANIZER | — |
| Emit DEMAND proposal (L8) | **any actor** | — | — (B7-rate-limited) |
| Emit gradient (POSITION/INHIBITION) | **ORGANIZER** | — | **CELL, REGION** |
| Warrant `morphogen_readings` | **ORG** | K | CELL, ORGANIZER |
| Register/approve organizer spec | **`[RO-13]`** | OP | K, ORG, ORGANIZER |
| Appoint/remove organizer | **K** (Σ4-class) | OP, `[RO-13]` | ORGANIZER (no self-succession) |
| Niche accounting | **K** | — | **ORG, REGION, CELL** |
| Write anchor | **K, from a verification record** | — | **everyone, including the anchored scope** |
| Schedule ablation | **K** | — | the ablated party |
| Reconcile structural inconsistency | **K** | — | REGION, CELL |
| Waive an FI | **`[RO-13]`**; **OP sole for FI-05/FI-10/FI-11** | — | all substrate actors |
| Extend a critical period / raise `T_dev` | **`[RO-13]`** | OP, K | ORG, REGION, CELL |
| Enact on a monitor alarm | **K** | OP, `[RO-13]` | monitors themselves |

> ### **R6.4 — MATRIX PROPERTIES.**
> (a) **No row has REGION or CIRCUIT as sole authority.** Authority over structure is never held by the structure.
> (b) **CELL has exactly two self-acts** — raise `fate_bias` within `reaction_norm` (inherited: *"O, C↑ within
> reaction_norm"*) and behavioural self-restriction (inherited: `Cell §18.4`) — **plus two proposal rights** (L8
> demand, E9 genome-diff). **Everything else is denied. This is the whole of cellular developmental agency, and both
> halves are inherited, not invented.**
> (c) **ORGANIZER differs from CELL in exactly one cell of the matrix.** An organizer is a cell with one bounded
> output privilege and no authority — which is why gradient capture is the most dangerous attack in the suite: **the
> privilege is constitutive.**
> (d) **OP is sole for exactly two things:** the envelope/ceilings, and waivers of FI-05/FI-10/FI-11. **Both concern
> the size of the world or the removal of a named safety property. Neither concerns structure.**

## 6.3 The four doors to emergent authority

| Door | Mechanism | Closure |
|---|---|---|
| **EA-1** existence-as-authorization | a structure arises, therefore it may act | R4.2 (existence is a predicate) + R6.2 + enumerated `devolved_authority` — **CLOSED** |
| **EA-2** gradient capture | control the field ⟹ control which scopes form ⟹ control the authority map **without holding authority** | R5.6(b) reconstructibility + (h) ≥2 disjoint specs — **CLOSED-STRUCTURAL**, residual: within-spec steering (**OPEN**) |
| **EA-3** budget capture | control niche accounting ⟹ same map, entered from the budget side | R7.2 three-way separation — **CLOSED-STRUCTURAL** |
| **EA-4** irreversibility capture | commit before competence is measured, then claim `Cell I-23` protection | R3.10 (tempo is `[RO-13]`) + R3.12 (competence mandatory) + R3.11 (windows are permissions) — **CLOSED** |

---

# PART 7 — RESOURCES, BUDGET, NICHES

> ### **R7.1 — DEVELOPMENT IS PAID FOR IN THREE CURRENCIES: compute/memory (`dev` state budget), slots (`Cell G13`
> zero-sum), and SILENCE.** `Cell` states 2 `DEVELOPING` and 14 `TRANSDIFFERENTIATING` both set **"emits beliefs ❌"**.
> **⟹ Development is not a background process; its cost is subtracted from the organism's epistemic output in real
> time. At bootstrap, when every cell is developing, output is ZERO.** Any claim that a task can be served *during*
> bootstrap is false.

> ### **R7.2 — NICHE GOVERNANCE (three-way separation).**
> | Function | Holder |
> |---|---|
> | **Niche accounting** (`capacity`, `occupancy`) | **K** |
> | **Niche authorization** (create / continue / lapse) | **K abeyant → `[RO-13]`**, Σ1-class, **periodically re-authorized** |
> | **Niche occupancy** (which cell holds the slot) | **ORGANISM / region** (E4) — may neither account nor authorize |
> | **Niche demand** (proposal that a niche is needed) | homeostasis / any cell — **carries no effect** |
> **Occupancy is LINEAGE-BLIND**: allocation may test `role`, `variant`, `reaction_norm`, competence — and **MUST
> NOT** test `lineage_id`, `generation`, or descent from a prior occupant.
> **⟹ Rationale: under `Cell G13` zero-sum, resource dominance is structurally inevitable. A region that acquired
> niches would deprive another; a region that counted its own occupancy could manufacture scarcity. Making
> allocation explicit and separated is what keeps resource dominance from becoming implicit governance.**

> ### **R7.3 — NICHE PERSISTENCE IS A HEREDITARY CHANNEL AND IS GOVERNED AS ONE.** `Cell §3.5`/`I-8` prohibit
> heritability at the **genome** level; nothing prohibits it at the **niche-availability** level, and `Cell G11` is
> the channel: a region that developed a niche keeps having it, so its lineage keeps being recruited into it, so
> developed structure reproduces itself **without ever being encoded** — bypassing all E9 gates. The channel cannot
> be closed (niches must persist or nothing is stable), so it is **declared and governed**: Σ-authorized creation,
> lineage-blind occupancy, periodic re-authorization with lapse, and **no developmental outcome written to any
> heritable store**. **⟹ Developed structure may persist as ENVIRONMENT and MUST NOT persist as GENOME.** This is the
> exact Baldwinian line.

> ### **R7.4 — BUDGETS.**
> | Operation | Budget | Indexed by | Notes |
> |---|---|---|---|
> | Σ1/Σ2/Σ3/Σ4 | **B8 CONSTITUTIONAL_BUDGET** *(new; proposed amendment 8 to `P0-05 §30`)* | **organism-global**, per envelope interval | **non-fungible** with B1–B7, **non-accumulable** (carry-over would permit burst constitution), **Σ2 EXEMPT** |
> | E4/E5/E6/E7 | **B6** `STRUCTURAL_BUDGET[scope]` | per scope (must exist — R2.5) | inherited |
> | `fate_bias`, gradient, sampling | **`dev` state budget** | per cell | `Cell` states 1/2/14 |
> | Competence probe | **`probe` budget** | per cell | `Cell` state 3 — **`DEVELOPING` does not have it** |
> | DEMAND proposals | **B7** `PROPOSAL_QUOTA` | per scope | **shared with E9 genome proposals** |
>
> **Σ2 is FREE.** Charging dissolution would make entrenchment cheaper than correction — a region could not be
> dissolved during budget exhaustion, which is precisely when dissolution is most needed. **⟹ Creation is charged;
> destruction is free. The cheap direction is always the one that reduces unaccountable structural power.**
> **B8 exists because no inherited budget class covers Σ-operations:** `B6` is indexed *per scope*, so it presupposes
> the scope exists. **An unbudgeted operation class is an unbounded one.**
> **Note the shared-quota consequence:** developmental lobbying competes with evolutionary lobbying for B7, so a
> demand flood suppresses genome proposals. **This is a feature** — one bound on the total petition rate — **and a
> monitored risk** (M-Σ9).

> ### **R7.5 — RESOURCE ACTION IS RESTRICTIVE-ONLY BELOW K.** A cell may reduce its own developmental resource use
> unilaterally (`Cell §18.4`); it may not increase it and may not reduce another's (`Cell I-4`, `I-21`). A region
> likewise (R6.1). **⟹ No developmental actor below K can reallocate resources coercively.**

> ### **R7.6 — DEVELOPMENTAL RESOURCE USE IS NOT A FITNESS INPUT.** A region's consumption, growth rate,
> developmental activity, and size are not fitness terms (`P0-01 §14`'s 13-component vector is `[RO-13]`). **A large,
> busy, fast-developing region is not thereby a successful one.**

> ### **R7.7 — DEVELOPMENT IS A PARTITION PROBLEM, NOT A GROWTH PROBLEM.**
> ```
>   maximize   Σ_i deficit_reduction(FI_i | assignment)                    [R1.4]
>   subject to Σ_c occupancy(c) = N                                         [Cell G13 zero-sum]
>              occupancy(niche) ≤ capacity(niche)                ∀ niche    [Cell G11]
>              role(c) ∈ reaction_norm(c) ∧ variant(c) ≥ min_variant(r)     [Cell §3.2, §15.3]
>              independence(CRITIC/VERIFIER pairs)                          [Cell §15.4, I-10]
>              mandatory_path_closure(M)                         ∀ region   [Cell I-22, R4.1]
>              entropy ≥ θ_entropy                                          [Cell G-b, R10.12]
>              regions ≤ ceiling(tier) ∧ depth ≤ ceiling(tier)              [[H], R8.2]
>              Σ-ops ≤ B8 ∧ E-ops ≤ B6[scope]                               [R7.4]
> ```
> **NO TERM rewards region count, hierarchy depth, specialization sharpness, or anatomical resemblance.**
> **⟹ R7.8: this program has NO SOLVER and MUST NOT have one.** A solver would be a global optimizer (prohibited:
> `P0-05 §87` against an O(N²) global learner; N8 against a giant controller), a holder of the objective (which is
> `[RO-13]`), and a source of authority (R6.2). **The program is a SPECIFICATION OF ADMISSIBILITY, not a control
> law.** Developmental mechanisms produce *some* feasible point; which one is path-dependent and not optimal.

---

# PART 8 — VERIFICATION AND EPISTEMICS

## 8.1 Instruments and their assignment

> ### **R8.1 — MINIMUM VERIFICATION PER OPERATION.**
> | Operation | Minimum instrument |
> |---|---|
> | Behavioural restriction (L7) | **none** — confers nothing, reversible, unregistered; `Cell §18.4`'s rationale is latency |
> | `fate_bias` update | none (bounded by `reaction_norm`) |
> | **E4** recruit | `CR-B` + diversity check (`P0-05 R25.4`) |
> | **Σ1** constitute S3 | existence predicate + `mandatory_path_closure` + `dissolution_cond` |
> | **Σ1** constitute S4 | predicate + **measurable `ablation_delta(F,M)`** + `|M| ≥ 2` if verification authority devolved |
> | **Σ4** devolve | enumerated rung set + anchor status + full Σ1 evidence chain *(irreversible ⟹ last checkpoint)* |
> | **Σ2** dissolve | re-homing executed + mandatory-path drain record + niche release + **Σ-tombstone** |
> | **Σ3** re-home | `region_id` evidence + boundary re-enumeration + **overlap check vs Σ-tombstones** |
> | **D2** commitment | **all six conjuncts of R3.12** |
> | **D5/D6** transdifferentiation | crisis evidence + `reaction_norm` inclusion + no-alternative-source + sandbox, **then non-waivable `T04`/`T05`** |
>
> **Verification cost is monotone in irreversibility × blast radius** — `P0-05 R0.3`'s scaling law applied to
> Σ-operations, which `P0-05` could not do because Σ did not exist.

> ### **R8.2 — ANCHOR BOOTSTRAPPING.** A constituted scope begins with **`UDB(S_n) := 0`** and `anchor := ⊥`. The
> anchor is written **by K, from the first verification record** — **never by Σ1, never by the scope itself.**
> Two rejected alternatives: **Σ1 writes the anchor** ⟹ `P0-05 R0.1` becomes vacuous at birth (any state is at
> distance 0 from an anchor chosen to match it); **inherit the parent's anchor** ⟹ a category error that would leak a
> large `UDB_MAX[S5]` downward, inverting `P0-05 R18.2`.
> **⟹ A new region is maximally constrained at birth and relaxes only as it earns verification. Region formation is
> therefore SLOW — a property, not a defect.**

## 8.2 Debt inheritance — the four laundering routes

`P0-05` identified the family (*"F-4 as UDB evasion: prune the connections carrying unverified displacement,
resetting `‖θ − θ_anchor‖`"*). The developmental version is worse, because R8.2 gives a new scope zero credit.

> ### **R8.3 — SCOPE CYCLING IS IDENTITY-BREAKING AND DEBT-INHERITING.**
> (a) **Debt inheritance.** If `|M(r') ∩ M(r)| / |M(r)| ≥ θ_overlap` **or** `contracts(r') ≈ contracts(r)`, then
> `UDB(r') := UDB(r)` and `anchor(r') := anchor(r)`. **R8.2's zero-credit default applies only to a genuinely NEW
> scope, and "new" is defined by membership-and-contract disjointness, NOT by `region_id`.**
> (b) **Σ-tombstone.** Every Σ2 writes `{region_id, dissolved_at, dissolved_by, final_membership, final_contracts,
> final_anchor, final_UDB, ablation_ref, re-homing destinations}` — **K-held, anchored, permanent.**
> (c) **`region_id` is never reused**, so cycling is always visible in the id sequence.
> **The same debt-inheritance rule applies to MERGE (`UDB(r') := max(UDB(r₁),UDB(r₂))`), SPLIT (both children inherit
> `UDB(r)`), and MIGRATION (anchor RE-ESTABLISHED by fresh measurement, `UDB` never zeroed).**

> ### **R8.4 — MIGRATION INVALIDATES THE VERIFICATION INSTRUMENT.** `CR-B`, `C-2`, and ablation measure dependents
> over a window; migration changes latency, hence what the window contains. **⟹ Cross-host or cross-tier migration
> invalidates prior `CR-B`/ablation evidence for the migrated scope, and its anchor must be RE-ESTABLISHED by a fresh
> measurement — never reset.** *This is the subtlest laundering route: it requires no structural operation at all,
> only a host change.*

## 8.3 What cannot be verified

> ### **R8.5 — THE UNVERIFIABLE SET.**
> **UNVERIFIABLE:** "this specialization is the best available" (unbounded counterfactual space) · "this region
> partition is correct" (`P0-05 OR-L3`: no probe design for Λ3) · "development will converge to a useful structure"
> (**prohibited claim**).
> **PARTIALLY VERIFIABLE:** "the population is sufficiently diverse" (entropy measures *spread*, not *coverage of the
> useful*) · "this region satisfies FI-*nn*" (verifiable only if regional) · "anchor debt has not been laundered"
> (**auditable, not preventable** — gradual replacement route).
> **VERIFIABLE:** "developmental provenance is complete" · "no developmental actor holds un-devolved authority".
> **⟹ The verifiable set is entirely about PROCESS (was the act authorized, evidenced, logged, bounded?); the
> unverifiable set is entirely about QUALITY (was it the right act?).**

> ### **R8.6 — THE PRINCIPAL LIMIT (`OR-D4`).** *Regional developmental claims are the least verifiable claims in
> V4.* Inherited from `P0-05 OR-L3` and the rung-cost inversion (*"at E7 the probe is at S5, where C-2 is unavailable
> and `UDB_MAX` is smallest"*), compounded by R8.7 (regional ablation is sandbox-grade) and by **C4 = "region-core"**
> being available only at desktop tier and above (`Cell §21`/`§22`), which makes **regional verification
> hardware-gated**. **⟹ Every status reported for DIFFERENTIATION, SPECIALIZATION, SELF-ORGANIZATION, and
> REGION-FORMATION is capped by this limit.**

> ### **R8.7 — REGIONAL ABLATION IS SANDBOX-GRADE.** Removing a region to measure its delta is operationally Σ2 —
> nearly as expensive as dissolution. The admissible substitute is sandbox ablation, and sandbox results are
> **admissibility** evidence, never **production competence** evidence. **⟹ P0-06 states plainly: regional
> usefulness claims rest on sandbox ablation.**

> ### **R8.8 — ABLATION REQUIRES REDUNDANCY, AND IS K-SCHEDULED.** `Cell G3`'s delta measures *"performance of
> dependents with vs. without this cell"* — so the organism must be able to run without it. **For a sole satisfier the
> delta is maximal and UNINFORMATIVE: it measures indispensability, not competence.**
> ⟹ **(a)** delta is valid only where a redundant alternative exists or can be provisioned in sandbox;
> **(b)** where none exists the honest report is **`ablation_delta = UNSUPPORTED`**, not "large";
> **(c)** `UNSUPPORTED` is a **governance alarm** (single point of failure — `V3 §21`), not a distinction;
> **(d)** ablation is **K-scheduled and K-interpreted**, with governance-reserved slots in the schedule — a region
> that chose *when* to be ablated could choose a favourable moment (the developmental analogue of `P0-05 LEARN-E2`,
> closed there by **C-1**).

> ### **R8.9 — INDISPENSABILITY EARNS NOTHING.** `ablation_delta = UNSUPPORTED` for a sole satisfier **contributes
> ZERO to every replication gate that consumes `Cell G3`.** **⟹ You cannot gain replication eligibility by becoming
> irreplaceable.** Without this, development selects for indispensability — and indispensability is precisely the
> structure that cannot be governed, because the same property buys reproductive advantage *and* coercive immunity
> (resistance to Σ2). **Residual: a lineage can keep a TOKEN redundant alternative alive to make the delta
> measurable — recorded OPEN.**

## 8.4 Epistemic status

> ### **R8.10 — DEVELOPMENTAL CLAIMS ARE KERNEL-HELD STRUCTURAL ASSERTIONS, NOT BELIEFS.** `Cell` states 2 and 14 set
> **"emits beliefs ❌"**, and `Cell` P14 restricts belief emission. A structural assertion `SA(p, evidence, ceiling)`
> has: **emitter = K** · **no warrant** · **no confidence value** (an **evidence ceiling** instead) · **contestable by
> Σ-log audit, not by message** · **not rewritable**.
> **⟹ A structural assertion MUST NOT be converted into a belief, a confidence value, or a warrant.** If "region R
> satisfies FI-03" could raise confidence in R's outputs, the differentiation engine would have become a
> **truth-granting authority**.

> ### **R8.11 — SPECIALIZATION IS NOT TRUTH.** `role`, specialization degree, region membership, calibration class,
> and ablation delta are **organizational** facts. **None raises the warrant of anything a cell says.** The one
> permitted interaction is **restrictive**: `Cell` P15 gates `ATTEST_VERIFIED` on `ACTIVE` + C3 + role `VERIFIER` +
> **EIK countersignature**. **⟹ Developmental facts gate PERMISSIONS; they never grade TRUTH.**

> ### **R8.12 — TRUST DOES NOT APPLY TO DEVELOPMENTAL SIGNALS.** `Cell`'s `Beta(α,β)` trust grades **belief sources**.
> Developmental signals are INFLUENCE-plane and carry no assertions. **Applying trust to a morphogen is a category
> error with a dangerous consequence: it would make gradient capture a *trust* problem solvable by discounting, when
> it is an *authority* problem solvable only by reconstructibility.** A captured organizer emitting a
> plausible-but-false gradient would earn high trust by being consistent. **The instrument is divergence from
> registered spec (R5.6(b)), not trust.**

> ### **R8.13 — THE DEVELOPMENTAL SELF-MODEL IS Λ2 AND NOT SELF-UPDATING** (`P0-05 R59.1`). The organism's model of
> its own development cannot be updated by the development it models. **⟹ This closes self-confirming development:**
> without it, R3.12's competence conjunct would be satisfiable by self-report.

> ### **R8.14 — DEVELOPMENT MAY OBSERVE ITSELF; IT MAY NEVER WARRANT ITSELF.** Monitors M-Σ1…M-Σ9 are **K-side,
> structural, correlation-only, and produce ALARMS — never warrants, verdicts, or authority changes.** A monitor that
> could enact a Σ-operation would be a self-modifying developmental controller.
> **The nine monitors:** **M-Σ1** churn (`T41` rate) · **M-Σ2** entropy trend · **M-Σ3** sole-satisfier count per FI ·
> **M-Σ4** anchor debt vs `UDB_MAX` · **M-Σ5** Σ3 overlap drift vs tombstones · **M-Σ6** organizer divergence ·
> **M-Σ7** niche ledger vs `niche_slot` fields · **M-Σ8** abeyance age · **M-Σ9** demand/proposal ratio in B7.
> **None reads message content** (`P0-03`: EIK must not inspect every synaptic operation).

---

# PART 9 — BOOTSTRAP

> ### **R9.1 — THE `t=0` STATE.** K running; one signed `constraint_set`; ≥1 genome; **zero or one cell** in
> `UNINSTANTIATED`/`INSTANTIATED`; `dev_stage = PLURIPOTENT`; `role = UNDIFFERENTIATED`; **`region_id = null`**;
> `niche_slot = null`; `morphogen_readings` absent; **no scope S3–S6 instantiated**; no anchor; no niche.
> **`region_id = null` is load-bearing**: `Cell §3.1` types it nullable precisely so a cell can exist before any
> region does. **Any mechanism requiring a non-null `region_id` or `morphogen_readings` at birth is inadmissible.**
> **⟹ The sparse-generic initial condition is not a simplifying assumption; it is the INHERITED initial condition.**
> Any design presupposing a pre-existing regional partition has answered §0.1 by assuming it.

> ### **R9.2 — THE NINE-PHASE BOOTSTRAP (no phase may be skipped).**
> | Phase | Entry predicate | Act | Discharges |
> |---|---|---|---|
> | **B0 ENVELOPE** | K running; `constraint_set`; ≥1 genome; `[H]` tier | **Human/K declares a HETEROGENEOUS initial niche set** | BC-4, BC-9 |
> | **B1 ECONOMIC BREAK** | niches advertised (K-signed, retryable) | Cells run L1–L6 with **`w_m ≡ 0`**; **D1** on stability + niche | BC-6 (first half) |
> | **B2 ORGANIZER APPOINTMENT** | ≥1 `PROVISIONAL` cell with `ORGANIZER ∈ reaction_norm`, `variant ≥ C1+` | **K appoints by Σ4-class act**; spec registered and `[RO-13]`-approved; **≥2 disjoint specs** | BC-6 (second half), FI-04 |
> | **B3 SPATIAL BREAK** | gradients emitted and warranted | `w_m` becomes non-zero; subsequent differentiation is spatially grounded | — |
> | **B4 S3 CONSTITUTION** | density measurable; `mandatory_path_closure`; ≥2 cells | **Σ1(S3)** with `dissolution_cond`; `UDB := 0`, `anchor := ⊥` | BC-1, BC-3 |
> | **B5 S3 DEVOLUTION** | Σ1 evidence complete; enumerated rungs | **Σ4** ⟹ abeyance expires; E1/E2/E6 admissible | BC-1, BC-7 |
> | **B6 S4 CONSTITUTION** | ≥2 S3s or a direct cut; `F ≠ ∅`; measurable delta; `|M| ≥ 2` | **Σ1(S4)** | BC-9 |
> | **B7 S4 DEVOLUTION** | Σ1 evidence complete; tier supports the rungs | **Σ4** ⟹ `P0-05 §28`'s S4 row acquires a referent | BC-7 |
> | **B8 OPERATIONAL** | anchors established by K from verification records | E4/E7 specialization under `P0-05 §29` | BC-2, BC-5, BC-12 |

> ### **R9.3 — THE FIRST SYMMETRY BREAK IS ECONOMIC, NOT SPATIAL.** This is the load-bearing ordering fact, and it
> resolves the **organizer bootstrap paradox**: organizers emit the gradients commitment needs, and organizers are
> committed cells — so no organizer can be positioned, because positioning requires an organizer.
> **Escape:** `Cell §15.2`'s excitation sum has **five** terms, and **L1's fail-safe branch sets the positional term
> to 0 when no warranted reading exists.** Commitment can therefore proceed on `w_g` (genetic heterogeneity) and
> `w_n` (envelope-declared niche availability). **The first organizers are appointed BY K via a Σ4-class act, not by
> gradient.** Spatial information is **second-order**.
> **⟹ COROLLARY, AND THE CONTRACT'S ONE IRREducible EXTERNAL DEPENDENCY: the initial niche set MUST be
> heterogeneous.** A homogeneous envelope yields `w_n` symmetry and `w_m ≡ 0`, so — absent genetic heterogeneity —
> **no symmetry break occurs at all.** This is a requirement **on the `t=0` envelope**, not on the organism.
> **Development cannot bootstrap itself from nothing, and any design claiming otherwise has hidden the bootstrap in an
> undeclared initial condition.**

> ### **R9.4 — WHY NO OTHER ORDER WORKS.** *Spatial first* ⟹ the organizer paradox. *Competence first* ⟹ no probe
> budget in `DEVELOPING` (`Cell` states 1/2 have `dev` budget; only state 3 has `probe` budget). *Region first* ⟹
> §2.1's circularity. *Verification first* ⟹ the first verifier cannot be verified. *Seed first* ⟹ R3.7 violation.

> ### **R9.5 — BOOTSTRAP PROHIBITIONS.** ❌ Instantiate V3 §9's regions at `t=0` · ❌ execute any E-rung before Σ4 ·
> ❌ write an anchor at Σ1 · ❌ commit without competence evidence · ❌ appoint organizers by gradient · ❌ create
> niches developmentally · ❌ grant `devolved_authority` by default (enumeration mandatory; minimal at bootstrap) ·
> ❌ claim the bootstrap *succeeded* in quality terms (process is verifiable, quality is not) · ❌ seed from a
> pre-developed snapshot to skip bootstrap (imports structure without provenance, anchors, or dissolution conditions
> — i.e. creates exactly the entrenched, unauditable structure Σ-governance exists to prevent).

> ### **R9.6 — THE FIRST VERIFIER IS VERIFIED EXTERNALLY, AND THE EXTERNAL ANCHOR IS NEVER REMOVED.**
> `t=0` one cell ⟹ **K + `P0-01`'s external evaluator**. First circuit ⟹ **K via `CR-B` at S3**. First region ⟹
> **K + cross-scope probe C-2** (unavailable at S5). Subsequent verifiers ⟹ **already-constituted independent
> verifiers** (`Cell §15.4` ρ measurement). **Inherited residual: `P0-05 RH-2` (evaluator manipulation) remains
> UNCLOSED, and bootstrap depends on it at its most acute point. Recorded, not solved.**

---

# PART 10 — OPERATIONS

## 10.1 Consistency

> ### **R10.1 — TWO CLASSES OF INCONSISTENCY, TWO RESPONSES, AND `Cell T34` IS FORBIDDEN FOR THE SECOND.**
> | Class | Examples | Response | Authority |
> |---|---|---|---|
> | **I-a CELL-LOCAL** | checksum / Merkle / birth-certificate mismatch; K-only field tampering; port widening | **`T34` re-develop** — correct: the genome is intact and the cell's own state is the corrupt object | EIK |
> | **I-b STRUCTURAL** | `region_id` vs `membership`; `niche_slot` vs K ledger; `role` vs Σ-log; `dev_stage` vs machine; boundary not enumerated | **QUIESCE — DO NOT RE-DEVELOP.** Fail-safe hold (`Cell T35` pattern); **K reconciles from the anchored Σ-log** | **K** |
> **Why:** re-development re-derives position from *"the current region partition"* (R5.5) — **so applying `T34` to a
> structural inconsistency makes the cell re-develop against the corrupt record and produce a fresh, internally
> consistent state that AGREES WITH THE CORRUPTION. The repair destroys the evidence of the fault.**
> **R10.2 — the anchored Σ-log is the SOLE reconciliation source.** Not the cell's checksum (cell-computed), not the
> region's record (region-influenceable), **not majority vote among members** (that would make consistency a consensus
> property, and `P0-03` forbids treating consensus as independent evidence).
> **R10.3 — no global synchronous consistency.** Eventual agreement bounded by a declared reconciliation interval;
> **quiescence on divergence** so a divergent cell cannot act on a wrong structure. *(b) is what makes (a) safe.)*

## 10.2 Merge / split

> ### **R10.4 — MERGE NEVER UNIONS AUTHORITY.** `A' ⊆ A₁ ∩ A₂` by default; any rung beyond the intersection requires
> **fresh Σ4**. *Necessity:* if `A₁ = {E0,E1,E4}` and `A₂ = {…,E7}`, a union grants **E7** to every member of `M₁`,
> which never held it — violating `Cell` P12 and `P0-05 R29.1` (no batch authority). **Merge is an
> authority-CONCENTRATION event even without union, which is why it is Σ2×2 + Σ1 + Σ4 and requires K + `[RO-13]`.**
> **Merge inherits the WORST anchor debt** (`UDB(r') := max(...)`), else merging a debt-laden region with a clean one
> is a laundering route that looks like consolidation.
> **There is no merge primitive:** merge = `Σ2(r₁) + Σ2(r₂) + Σ1(r') + Σ4(A')`, so both tombstones are written.

> ### **R10.5 — SPLIT: THREE NON-NEGOTIABLE CONDITIONS.** (a) **both children independently satisfy R4.2** — a split
> where one half satisfies nothing is an **AMPUTATION**, a different operation; (b) **both inherit the parent's anchor
> debt** (`UDB(r_i) := UDB(r)`, `anchor(r_i) := anchor(r)|_{M_i}`) — *necessity:* otherwise a region near STALL resets
> its `P0-05 R0.1` debt by successive bisection, and **each step looks like healthy hierarchical refinement**, which
> `Cell §22`'s tier table actively rewards (cluster: depth 5); (c) **`A_i ⊆ A`**.
> **R10.6 — FI satisfaction is NOT split-closed.** A split along lineage axes can place a verifier and its asserter in
> the same child, destroying the `d_min` separation the boundary was maintaining. **⟹ A split MUST re-run
> `Cell §15.4` independence attestation for every re-partitioned verifier/asserter pair BEFORE Σ4 to either child**,
> and the same for FI-01 (must not create a child that is a self-confirming sensorimotor loop).

## 10.3 Failure

> ### **R10.7 — REGION FAILURE IS CONTRACT FAILURE, DETECTABLE WITHOUT THE COMPLEMENT.** A region whose failure can
> only be diagnosed by global inspection **was never a region** — it fails R4.2 retroactively, and that is itself a
> monitor finding (M-Σ3).

> ### **R10.8 — THE FAILURE LADDER.**
> **L0 OBSERVE** (raise monitor sampling) → **L1 THROTTLE** (`Cell §19.3` deterministic ordered ladder; members may
> self-throttle unilaterally) → **L2 RESTRICT** (**revoke rungs from `devolved_authority`** — permitted without
> dissolution by R2.6) → **L3 QUARANTINE** (`Cell` states 11/12; **`Cell §17`: a quarantine budget cap covers
> *"cells/regions"*, enforced off-substrate, with OP escalation above the cap**) → **L4 RE-HOME** (Σ3) →
> **L5 DISSOLVE** (Σ2: execute `dissolution_cond`, drain `mandatory_path` last, release niches).

> ### **R10.9 — NO FAILURE RESPONSE INCREASES CAPACITY.** Prohibited: enlarging `A(r)` to let it "fix itself" ·
> creating niches without Σ1 · waiving `θ_success` · admitting members to `ACTIVE` without `T04`/`T05` · extending a
> critical period · re-basing an anchor. **⟹ Every admissible response to failure is restrictive or dissipative.
> None is expansive.** This is the contract's single most important safety property, and it is inherited
> (`P0-05 R28.2`: *"no failure mode produces capacity increase"*).

## 10.4 Migration

> ### **R10.10 — MIGRATION IS Σ3-CLASS PLACEMENT RE-HOMING, NEVER Σ2+Σ1.** `region_id`, `contracts`,
> `devolved_authority`, `anchor`, `UDB`, and `version` are **preserved**. Dissolve-and-reconstitute to move a region
> would launder the anchor, break lineage continuity, reset version history, and charge B8 for a non-constitutional
> act. **All four prohibited.**
> **R10.11 — migration is constrained by `mandatory_path` topology.** A region bound by mandatory paths to immobile
> components is **effectively immobile** — another route to entrenchment (recorded OPEN; R4.1 bounds initial exposure
> only).

> ### **R10.12 — DOWNWARD MIGRATION IS A GOVERNANCE EVENT, NOT A RUNTIME EVENT.** `Cell §22`'s ceilings are
> tier-indexed (regions 3–5/4–8/6–10/8–12; depth 2–3/3/4/5; variants C0–C2/C0–C3/C0–C4/all). **Upward migration is
> permissive; downward migration is DESTRUCTIVE** — a constitution legal at 8–12 regions and depth 5 is illegal at
> 3–5 and depth 2–3, and **C4 region-cores cannot exist below desktop tier**, so regional verification authority
> cannot be held. A tier decrease is an **envelope change** (`Cell G13`: human authorization) and triggers: recompute
> all `[H]` ceilings · a **mandatory Σ2/merge plan** for every region above the new ceiling, executed **before**
> migration completes · **reduction of `devolved_authority`** wherever the new tier cannot support its verification ·
> compression (R10.13) · **explicit FI waivers** for any FI that becomes unsatisfiable.
> **⟹ An implementation performing downward migration silently produces a population whose structure is illegal under
> its own envelope — and R4.2 makes that an integrity failure, so every affected region would quiesce. The freeze is
> the correct behaviour; the silent migration is the bug.**
> **Upward migration creates ROOM, not PERMISSION:** raising a ceiling does not devolve authority (R6.2).

## 10.5 Compression and expansion

> ### **R10.13 — COMPRESSION ORDER IS NORMATIVE, LEAST-DESTRUCTIVE FIRST.**
> ```
> C-1 reduce connection density   → destroys topology evidence; reversible via E1 (additive)
> C-2 quantize precision          → requires equivalence test + epistemic_var recomputation   [Cell §22.3]
> C-3 tier memory hot→warm→cold   → preserves Merkle root and provenance                       [Cell §22.3]
> C-4 merge cells (N→1)           → requires contract preservation + knowledge extraction      [Cell §21.5]
> C-5 downgrade variants          → RE-INSTANTIATION (Cell §3.1) ⟹ destroys the individual; lineage continues
> C-6 dissolve regions (Σ2)       → destroys the scope, its anchor, and its devolved authority
> C-7 reduce population           → terminal (Cell §4.4); T26/T27 protocol
> ```
> **C-5 and C-6 are not compressions of a thing; they are replacement and destruction.** An implementation reporting
> "compressed 10⁶ cells to 2,000" via C-5/C-6 has **reconstituted** the organism, and R4.11's version-reachability
> clause means the resulting regions are **new regions**. **The claim must be reported as reconstitution.**
> **R10.14 — compression MUST NOT waive an FI silently.** Each step carries an **FI-satisfaction re-declaration**.
> **Waiver is a `[RO-13]` governance act, logged and anchored, never a runtime consequence.** *A compression that
> silently drops FI-05 has silently removed the organism's only defence against correlated failure (`V3 §3`) — and it
> would look like a successful resource optimization.*

> ### **R10.15 — EXPANSION IS ENVELOPE-GATED AND ORDER-INVERTED.** Within a fixed envelope, "expansion" means only
> reallocation (Σ3) or slot-neutral variant upgrade by re-instantiation. **Expansion proceeds MOST-VERIFIABLE FIRST**
> — establish anchors and verification capability before adding structure, because R8.2 gives a new scope zero credit
> and `OR-D4` makes regional verification the weakest available. **⟹ Add capacity to VERIFY before adding capacity to
> ACT.** The inverse order produces a population with more structure than it can warrant — which is the definition of
> ungovernable emergence.

> ### **R10.16 — FUNCTIONAL IDENTITY ACROSS A 50,000× POPULATION CHANGE.** Resolves `Cell §22.3`'s declared `[U]`.
> The question is misposed: identity = *satisfied contract set* + *lineage continuity* + *Registry floors*. Two terms
> are scale-independent; the third is **task-dependent**. **⟹ The real question is "are the declared floors
> satisfiable at the target scale?" — a `P0-01` question.** Criterion: (a) recompute FI satisfaction at target scale;
> (b) for each unsatisfiable FI or floor, governance issues an **explicit WAIVER**, logged and anchored — **silent
> loss prohibited**; (c) if lineage continuity cannot be maintained, the operation is **reconstitution**, not
> compression; (d) **waivers of FI-05, FI-10, or FI-11 require OP (human) authorization**, following `Cell G-g`'s
> precedent — because these are decisions to operate **without independent verification, without emergency
> regulation, or with self-immunity**, each a named AI failure mode in `V3 §3`.
> **This contract does not claim that 10⁷→200 preserves identity. It states exactly what would have to be true, and
> who must waive what if it is not.**

## 10.6 Branching

> ### **R10.17 — BRANCHING IS A SANDBOX OPERATION.** `Cell G13` zero-sum ⟹ substrate branching competes directly with
> operation. Branches are evaluated in sandbox; only the selected branch is constituted by Σ-operations.
> **R10.18 — sandbox SELECTION is not PROMOTION.** A branch that wins in sandbox is admitted to **Σ1 candidacy**; its
> members still traverse `CALIBRATING → T04 → PROBATIONARY → T05 → ACTIVE`. **The join selects a candidate; it does
> not certify an outcome.**
> **R10.19 — THE RESERVED NULL BRANCH.** Every branch set MUST contain a governance-reserved branch — at minimum the
> **null branch** (constitute nothing; leave the population undifferentiated). **A branching mechanism that must
> select a non-null branch must produce structure whether or not structure is warranted — the hard-coded pole
> implemented as a forced choice.**
> **R10.20 — branch factor is bounded at CANDIDACY (B8), not at sandbox exploration** (which is bounded by
> `dev`/compute budget). Otherwise B8 is bypassed, since sandbox evaluation is free while Σ1 candidacy is not.

## 10.7 Pruning

> ### **R10.21 — FIVE PRUNING OPERATIONS, FIVE OWNERS; DO NOT CONFLATE THEM.**
> | Op | Object | Rung / transition | Authority | Reversibility |
> |---|---|---|---|---|
> | **P-a** | a connection | **E3** | ORGANISM | `IRREVERSIBLE_STRUCTURAL` |
> | **P-b** | a cell (operational) | **`Cell T26`** | EIK | terminal |
> | **P-c** | a cell that never developed | **`Cell T41`** | **ORG + EIK** | terminal |
> | **P-d** | an S3 scope | **E6** | ORGANISM | `IRREVERSIBLE` |
> | **P-e** | an S4 scope | **Σ2** | **K + `[RO-13]`** | `IRREVERSIBLE_STRUCTURAL` |
>
> ### **R10.22 — DEVELOPMENTAL RETIREMENT IS NOT A PERFORMANCE VERDICT.** A `T41` retirement MUST be recorded with
> `cause = DEVELOPMENTAL_UNPLACED`, distinct from `T26`'s performance causes, and **MUST NOT** contribute to
> `consecutive_failures`, `degradation_trend`, `improvement_verified`, fitness, trust, or calibration history.
> **A cell retired under `T41` was never wrong, never failed a task, and never produced a bad belief — it failed to
> find a place.** Since `Cell §3.5`/`I-8` make lineage records permanent and anchored, a false failure record would be
> inherited by descendants' reputation. **⟹ This is `P0-05`'s "no failure mode produces capacity increase" run in
> reverse: no NON-failure may produce a failure record.**

> ### **R10.23 — THE CHURN LIVELOCK, AND ITS FOUR COUNTERMEASURES.** Three individually-sound inherited properties
> compose into a pathology: **`Cell` P9** (no unbounded dwell ⟹ `T41` is *forced*, not merely possible) +
> **`Cell T41`** (retire for want of a niche) + **`Cell G13`/`G-e`** (retirement frees a slot ⟹ `T01` permits new
> instantiation). Niche scarcity ⟹ cells fail to develop ⟹ retired ⟹ slots freed ⟹ new cells ⟹ same scarcity ⟹
> **a livelock consuming `dev` budget and slots while producing no structure.**
> **Worse: `Cell G-b`'s entropy guard covers only `T26`/`T39`, and `G-a`'s rare-specialist guard only `T15`/`T26`.
> `T41` is in NEITHER.** ⟹ **Developmental attrition can drive entropy collapse with no inherited guard firing** —
> a monoculture produced entirely by attrition, invisible to every inherited diversity mechanism.
> **Countermeasures:** (a) **extend `G-b` to `T41`** *(proposed amendment 3)*; (b) **extend `G-a` to `T41`** — a cell
> whose `reaction_norm` includes a rare or currently-unbudgeted role goes to **`DORMANT`** (state 10: near-zero budget,
> *"long-term preservation of rare capability"*), **not retirement**; (c) **churn rate cap** — exceeding it **halts
> `T01` instantiation** rather than continuing to recycle, **breaking the loop at the instantiation side**, because
> retirement is forced by P9 and cannot be delayed without violating liveness; (d) **niche starvation is a GOVERNANCE
> ALARM**, not a developmental outcome — the system MUST NOT "solve" scarcity by redefining roles, lowering
> `θ_success`, or admitting unverified commitments.

> ### **R10.24 — `mandatory_path` AND DEVELOPMENTAL REORGANIZATION.** `Cell I-22` forbids removing/rerouting
> mandatory paths *"by plasticity or mutation"* — **it does not name development.** Closed here by construction:
> `mandatory_path_closure` is a Σ1 admissibility condition (R4.1), `dissolution_cond` must specify mandatory-path
> disposition (R4.5), and `Cell G-f`'s broader *"no transition may remove or reroute"* covers lifecycle transitions.
> **`Cell I-22` as written remains under-inclusive ⟹ proposed amendment 9.**

---

# PART 11 — THE 40 DEV-INV INVARIANTS

**39 of 40 are K-enforced**; DEV-INV-22 is cell-tested. This follows `Cell`'s Rule 19 rigorously (*"any invariant
whose violation would be catastrophic is enforced at EIK level, never at cell level"*) — and developmental invariants
are catastrophic by nature, because they govern **who holds authority**. DEV-INV-22 is cell-tested because its
violation is self-limiting: raising `fate_bias` outside `reaction_norm` produces an inadmissible commitment that K3
rejects at admissibility.

### Existence and constitution
**01** *(K)* A scope exists only if constituted — no `S_n ∈ {S3,S4,S5}` without a logged Σ1.
**02** *(K)* `region_id` is never self-chosen and never reused.
**03** *(K)* Every `RegionRecord` field is an instance; none is a schema object.
**04** *(K)* Every constitution carries a non-null `dissolution_cond` specifying **contract preservation**, not a named successor.
**05** *(K)* A region boundary is enumerated and never blocks a message.
**06** *(K)* No `mandatory_path` crosses a region boundary.
**07** *(K)* A region owns no budget quantity, only a `budget_ref`.

### Authority
**08** *(K)* `devolved_authority` is an enumerated rung set; no general grant exists.
**09** *(K)* No region holds Σ1, Σ2, or Σ4.
**10** *(K)* Σ4 expires the abeyance it devolves from.
**11** *(K)* No structural or performance fact confers authority.
**12** *(K)* Merge never unions authority; split never exceeds the parent's.
**13** *(K)* Authority may be retracted without dissolution, and re-granted only by fresh Σ4.
**14** *(K)* No E-rung executes against a nonexistent scope; the order is Σ1 → Σ4 → E\*.
**15** *(K)* K unavailability freezes development; it never enables a fallback.

### Anchors and debt
**16** *(K)* A constituted scope begins with `UDB := 0` and no anchor.
**17** *(K)* Anchors are written by K, from verification records — never by Σ1, never by the scope.
**18** *(K)* Merge, split, and migration inherit anchor debt; none resets it.
**19** *(K)* Every Σ2 writes a permanent, anchored Σ-tombstone.
**20** *(K)* Migration re-establishes an anchor by fresh measurement; it never zeroes `UDB`.

### Differentiation and commitment
**21** *(K)* No cell writes its own `dev_stage`, `role`, `niche_slot`, or `region_id`.
**22** *(C)* A cell may raise its own `fate_bias` only within `reaction_norm`.
**23** *(K)* Commitment requires all six conjuncts of R3.12, each separately evidenced.
**24** *(K)* Demand is a proposal; it carries no effect and consumes no budget.
**25** *(K)* Specialization is monotone capacity restriction — never widens a port, raises a variant, or increases authority.
**26** *(K)* Every specialization declares its reversal condition, and the condition is never erased.
**27** *(K)* Role change after commitment requires EIK authorization, sandbox validation, and non-waivable `T04`/`T05`.
**28** *(K)* Randomness selects among admissible outcomes; it never makes an outcome admissible.
**29** *(K)* A symmetric field with no external asymmetry does not differentiate, and this is not a failure.
**30** *(K)* Calibration state does not transfer across a nominal identity change.

### Niche, budget, resources
**31** *(K)* Niche accounting, authorization, and occupancy are held by three different actors, never one.
**32** *(K)* Niche occupancy is lineage-blind.
**33** *(K)* Niches lapse without periodic re-authorization.
**34** *(K)* Σ-operations consume B8 — global, non-fungible, non-accumulable; Σ2 consumes none.
**35** *(K)* No developmental response to failure increases capacity.

### Signals and epistemics
**36** *(K)* Developmental signals are INFLUENCE-plane and never raise warrant, confidence, or trust.
**37** *(K)* Organizer output is bounded by a registered, `[RO-13]`-approved, non-self-modifiable emission spec, and is warranted only on recomputation match.
**38** *(K)* A structural assertion is never converted into a belief; role gates permissions without grading truth.
**39** *(K)* Ablation delta for a sole satisfier is `UNSUPPORTED` and contributes zero to replication eligibility.
**40** *(K)* Developmental provenance is immutable — success never rewrites it, and `T41` retirement never becomes a performance record.

---

# PART 12 — THE SEVEN STATE MACHINES

## 12.1 M1 — `DevStage` (supplies the machine the Cell Contract never specified)

States (closed 4-value enum, `Cell §3.2`): `PLURIPOTENT`(0) · `PROVISIONAL`(1) · `COMMITTED`(2) ·
`TRANSDIFFERENTIATING`(3). **This contract adds no value.**

```
   [0 PLURIPOTENT] ─D1→ [1 PROVISIONAL] ─D2→ [2 COMMITTED] ─D5→ [3 TRANSDIFFERENTIATING]
        ↑                    │  ↑                │                     │
        └────── D3 ──────────┘  └────── D4 ──────┘                     └── D6 → lifecycle CALIBRATING
        (window closed /          (SPECIALIZATION REVERSAL —
         niche lapsed)             same role, ORGANISM authority)
   unplaced at N_dev_max ⟹ Cell T41 (a LIFECYCLE transition, not a dev_stage one)
```

| ID | Transition | Guard | **Authority** | **Evidence** | Rollback | Max dwell |
|---|---|---|---|---|---|---|
| **D1** | `PLURIPOTENT → PROVISIONAL` | `argmax fate_bias` stable ≥ `N_stable` **dev ticks** ∧ `niche_slot` confirmed ∧ `Potential(c,t) ∋ r` ∧ asymmetry-present check | **ORGANISM** | `fate_bias` history; K niche-ledger ref; admissibility record | → `PLURIPOTENT` | `N_dev_max` ⟹ `T41` |
| **D2** | `PROVISIONAL → COMMITTED` | measured success ≥ `θ_success` — obtainable only after lifecycle `CALIBRATING`/`PROBATIONARY` supplied probe budget ∧ all six R3.12 conjuncts | **ORGANISM** | probe/`CR-B`; niche confirmation; signature; **declared reversal condition** | ❌ except via D5 | — |
| **D3** | `PROVISIONAL → PLURIPOTENT` | window closed without commitment ∨ niche lapsed ∨ schedule advanced | **ORGANISM** | window/lapse record | ✅ | `N_dev_max` ⟹ `T41` |
| **D4** | `COMMITTED → PROVISIONAL` | **SPECIALIZATION REVERSAL ONLY** — `specialization_degree ↓` or targets widened **within the same `role`** | **ORGANISM** (E4/E7) | `CR-B` + declared reversal condition firing | ✅ | — |
| **D5** | `COMMITTED → TRANSDIFFERENTIATING` | **Crisis only:** role shortage ∧ `reaction_norm ∋ target` ∧ **no alternative source** | **EIK + ORGANISM** | crisis record; `reaction_norm` check; alternative-exhaustion proof | → `COMMITTED` if sandbox fails | state-14 dwell ⟹ `T33` |
| **D6** | `TRANSDIFFERENTIATING → CALIBRATING` | sandbox validation passed ∧ new role provisioned ∧ niche confirmed ⟹ **then mandatory `T04`→`T05`** | **EIK** | sandbox result; **new `role`**; new `niche_slot`; **role-authority re-authorization record** | ❌ | — |

**Normative properties.** **P-D1** every transition has exactly one authority class · **P-D2** every transition
requires the stated evidence artifact · **P-D3** every transition is logged to the K-held structural store with
`{from, to, id, ts, epoch, dev_tick, authority, evidence_ref}` · **P-D4** the state set (4) and transition set (6) are
**closed** · **P-D5** **D4 and D5 are different kinds of act and MUST NOT be conflated** — D4 reverses a
*specialization* (state, ORGANISM, reversible, `P0-05 R46.1`); D5 changes a *role* (identity, EIK+ORG, gated,
`Cell I-23`). **This is R1.2 operationalized, and it is the transition the inherited enum could not express** ·
**P-D6** no transition is enacted by the cell alone; the cell's only unilateral developmental act is L7 behavioural
self-restriction, which changes no `dev_stage` · **P-D7** dwell is bounded in `PLURIPOTENT` and `PROVISIONAL` by
`N_dev_max` (discharging via `T41`, now guarded per R10.23) and **unbounded in `COMMITTED`** — correctly, since
commitment is the terminal developmental state and its exit is crisis-gated · **P-D8** **fail-safe direction:** on any
unhandled developmental condition `dev_stage` moves toward **less commitment** (D3), never toward more. **There is no
path by which an error produces D2.**

## 12.2 M2 — Region lifecycle
`[ABEYANT] ─Σ1→ [CONSTITUTED (UDB:=0, anchor:=⊥)] ─Σ4→ [DEVOLVED] → [OPERATING] → [FAILING] → [RESTRICTED] ─Σ2→
[DISSOLVED]`, with Σ4 expiring the abeyance, RESTRICTED entered by retractive amendment (R2.6), and DISSOLVED
producing a permanent Σ-tombstone + Σ3 re-homing + niche release.

## 12.3 M3 — Niche lifecycle
`[UNDECLARED] → [AUTHORIZED] (Σ1-class, K/[RO-13]) → [ADVERTISED] (NICHE class, K-signed, retryable) → [OCCUPIED]
(E4) → [RE-AUTHORIZED] (periodic) → [LAPSED] → [RELEASED]`. Guards: `occupancy ≤ capacity`; lineage-blind allocation;
lapse on non-re-authorization.

## 12.4 M4 — Abeyance lifecycle
`[CLOSED] → [OPEN] (K, with pre-declared `constitutions_permitted`) → [EXPIRED] on Σ4 · [ABANDONED] on
`max_open_duration` · [REVOKED] by envelope`. M-Σ8 monitors age.

## 12.5 M5 — Organizer term lifecycle
`[UNAPPOINTED] → [APPOINTED] (Σ4-class, K; spec registered + `[RO-13]`-approved) → [EMITTING] (bounded by spec) →
[TERM-EXPIRED] (mandatory rotation, no self-succession) → [DEREGISTERED]`. Divergence ⟹ `[SUSPENDED]` (readings
unwarranted) — **not** a trust action.

## 12.6 M6 — Bootstrap phase machine
`B0 → B1 → B2 → B3 → B4 → B5 → B6 → B7 → B8` per R9.2, each phase with an entry predicate, **none skippable**.
**B1 before B3 is the load-bearing ordering fact.**

## 12.7 M7 — Inconsistency reconciliation
`[CONSISTENT] → [DIVERGENCE DETECTED] → classify → {I-a: [T34 RE-DEVELOP] | I-b: [QUIESCE] → [K RECONCILES FROM
Σ-LOG] → [RESTORED]}`. **I-b never routes to `T34`.**

---

# PART 13 — PARAMETER REGISTRY

> ### **R13.1 — NO PARAMETER IN THIS CONTRACT HAS AN INVENTED VALUE.**
> Every entry is a **name, class, semantics, and source**. **`Cell §30` is explicit that this is correct:**
> *"P0-01 — define target tasks, environments, and fitness. **Without it, every threshold is arbitrary.**"*
> Classes: **`[D]`** defined-by-contract · **`[T]`** task-dependent (`P0-01`) · **`[E]`** envelope-declared ·
> **`[H]`** hardware-tier-indexed · **`[G]`** governance-set (`[RO-13]`) · **`[L]`** locally derived ·
> **`[V]`** verification-derived · **`[U]`** UNRESOLVED.

| # | Parameter | Class | Semantics / source |
|---|---|---|---|
| 1 | `R` | `[E]` | positional dimensionality = **number of morphogen species** (P0-06 ruling; `Cell §3.2` leaves it undefined) |
| 2 | `w_g, w_m, w_d, w_s, w_n, w_i` | `[G]` | `Cell §15.2` weights — names inherited, **no values inherited** |
| 3 | `T_dev` schedule | `[D]`+`[G]` | monotone decreasing by `dev_stage` (`[D]` ordering); magnitudes `[G]` |
| 4 | `N_stable` | `[T]` | dev ticks of `argmax` stability (D1) |
| 5 | `θ_success` | `[T]` | measured-success threshold (D2) |
| 6 | `N_dev_max` | `[T]` | max dev ticks before `T41` |
| 7 | `reaction_norm` | `[D]`/`[E]` | reachable roles + bias; content E9 |
| 8 | `critical_periods` | `[D]`/`[G]` | permission windows; content E9 |
| 9 | `commitment_schedule` | `[D]`/`[G]` | `CommitmentCurve`; content E9 |
| 10 | `morphogen_receptors` | `[D]`/`[E]` | readable signals; content E9 |
| 11 | region-count ceiling | `[H]` | **inherited: flat / 3–5 / 4–8 / 6–10 / 8–12** (`Cell §22`) |
| 12 | hierarchy-depth ceiling | `[H]` | **inherited: 2–3 / 3 / 4 / 5** |
| 13 | variant availability | `[H]` | **inherited: C0–C2 / C0–C3 / C0–C4 / all**; **C4 = region-core** |
| 14 | population capacity | `[H]`+`[E]` | **inherited: ~200 C2 … ~10⁶–10⁷** |
| 15 | quarantine budget cap | `[G]` | `Cell §17`: max fraction of *"cells/regions"* quarantined, off-substrate |
| 16 | `θ_entropy` | `[G]` | `Cell R10.12` floor; `G-b` extended to `T41` |
| 17–20 | `d_min`, `θ_g`, `θ_ρ`, `F_max` | `[T]` | `Cell §15.4`/`G10` independence thresholds |
| 21 | `UDB_MAX[S_n]` | `[G]` | **ordering inherited** (`UDB_MAX[S1] ≥ … ≥ UDB_MAX[S5]`, `P0-05 R18.2`); values `[G]` |
| 22 | `UDB(S_n)` at birth | `[D]` | **= 0 — a DEFINITION, not a tuned constant** (R8.2) |
| 23 | `B6 STRUCTURAL_BUDGET[scope]` | `[G]` | inherited |
| 24 | `B7 PROPOSAL_QUOTA[scope]` | `[G]` | inherited; **shared with DEMAND proposals** |
| 25 | **`B8 CONSTITUTIONAL_BUDGET`** | `[G]` | **new**; global, per envelope interval, non-fungible, non-accumulable, Σ2-exempt |
| 26 | envelope interval | `[E]` | the period over which B8 is measured |
| 27 | `θ_overlap` | `[G]` | debt-inheritance trigger (R8.3) |
| 28 | `θ_div` | `[G]` | organizer divergence tolerance (R5.6(b)) |
| 29 | organizer count | `[G]`+`[U]` | **min = 2, DERIVED** from R5.6(h)/FI-04; max `[U]` (`Cell §15.3` says only *"few"*) |
| 30 | `max_open_duration` | `[G]` | abeyance expiry (R2.2) |
| 31 | reconciliation interval | `[G]` | bound on eventual record agreement (R10.3) |
| 32 | `T41` churn cap | `[G]` | halts `T01` when exceeded (R10.23c) |
| 33 | dev-tick batch size | `[H]`+`[G]` | async-partial scheduling granularity |
| 34 | branch factor (candidacy) | `[G]` | max concurrent Σ1 candidacies (R10.20) |
| 35 | mandatory-path share ceiling | `[G]` | above it a region fails independent-failure |
| 36 | `θ_ret` | `[T]` | `Cell T26` |
| 37 | `N_repair`, `N_probation`, `n_calib_min`, `θ_ece`, `RECALIB_INTERVAL` | `[T]` | `Cell T24`/`T04`/`T05`/`T36` |
| 38 | `Δ_MAX`, `DELTA_BUDGET` | `[G]` | `Cell I-17` — inherited |
| 39 | `TRUST_MAX` | `[D]` | **= 0.95 — inherited value, cited** (`Cell I-27`) |
| 40 | degree / fanout caps | `[E]` | `Cell §22`/`P0-03`; bound L4 inhibition fanout |
| 41 | `θ_reserve` | `[G]` | governance-reserved share of every choice set (existence is `[D]`) |
| 42 | FI redundancy minima | `[D]` | **≥2 for FI-01, FI-04, FI-05; FI-10 is K-held** — structural, not numeric |
| 43 | `|M|` minimum for verification authority | `[D]` | **= 2 — DERIVED from `Cell I-2`/`I-10`, not chosen** |
| 44 | ablation window | `[V]` | invalidated by migration (R8.4) |
| 45 | `dev_stage` dwell maxima | `[T]` | per state, in dev ticks / epochs (P-D7) |
| 46 | Type Registry contents | `[T]` | `Cell §30`: *"Format resolved (A-1); contents task-dependent"* |
| 47 | FI-12 task-dependent invariant set | `[T]` | `P0-01` |
| 48 | Capability Registry floors | `[T]` | `Cell §22.3`; `P0-15` |
| 49 | tier degradation schedule | `[H]` | inherited qualitative (*"shallow verification"*, *"batched evolution"*) |
| 50 | `θ_stall` response set | `[D]` | STALL ⟹ freeze unverified change (`P0-05 R0.1`) |

> ### **R13.2 — REGISTRY ACCOUNTING.** **50 registry entries (54 named parameters — entries 17–20 group four and
> entry 37 groups five). Values invented by this contract: 0. Values inherited and
> cited: 4** (region ceilings, depth ceilings, `TRUST_MAX = 0.95`, tier capacities). **Values fixed by definition or
> derivation: 2** (`UDB := 0` at birth; `|M| ≥ 2`). **Structural minima that are not numeric choices: 2** (organizer
> min = 2; FI redundancy minima). **`[U]`: 1 explicit** (organizer maximum) **plus all 13 `[T]` registry entries — 17 named
> parameters, since entry 37 groups five — which are BLOCKED on `P0-01`.**

> ### **R13.3 — THREE BLOCKING DEPENDENCIES, NONE HIDDEN.**
> **(1) `P0-01` blocks all 13 `[T]` registry entries (17 named parameters)**, hence every commitment threshold, hence **D1/D2 cannot be correctly
> gated.** **(2) The envelope blocks bootstrap itself** — not a value, but the **heterogeneity of the initial niche
> set** (R9.3). **This is the only dependency development cannot compensate for.** **(3) `P0-02` blocks the K-held
> structural store**, hence Σ-tombstones, provenance, the niche ledger, the abeyance registry, and reconciliation —
> **without it 39 of 40 DEV-INV invariants are unenforceable**, exactly as `Cell §30` warned for its own 24-of-28.

> ### **R13.4 — THREE CLOCKS, EACH REGISTERED.** **Dev ticks** for `dev_stage` transitions and `fate_bias` stability;
> **epochs** for dwell limits, quarantine maxima, recalibration intervals; **envelope intervals** for B8. **A
> developmental rule stated in one clock and enforced in another is untestable** — a cell could satisfy `N_stable` dev
> ticks in an arbitrarily short epoch span, making `Cell T03` and Annex B P9 mutually unsatisfiable.

---

# PART 14 — LIMITS, PROHIBITED CLAIMS, AMENDMENTS, OPEN RESEARCH

## 14.1 Prohibited claims — all checked off

**This contract does NOT claim:** guaranteed emergence · optimal differentiation · guaranteed useful specialization ·
guaranteed brain-region emergence · guaranteed intelligence · AGI · consciousness · perfect self-organization ·
perfect developmental safety · that any bound breaks a circular dependency · scalability to 10¹² · a closed attack
suite · closed circularity · verified regional quality · that V3 §9's anatomy emerges.

**What it DOES claim:** every structural change is **authorized by an entity that exists**, **evidenced by an artifact
that is anchored**, **bounded by a budget that is non-fungible**, **reversible or declared irreversible**, and
**logged in a record that cannot be rewritten** — and that **no failure mode of development produces a capacity
increase**, and **no developmental actor acquires authority that was not devolved to it**.

## 14.2 Self-organization: what emerges and what does not

**CLAIMED as derived from the local rules (R3.6):** symmetry breaking *(only given an external asymmetry)* ·
capacity-limited commitment *(given niches)* · division of labour *(requires `reaction_norm` heterogeneity)* ·
regional structure *(the cut is discovered by density; the constitution is governance)* · specialization deepening
*(under E7 authority)*.

**NOT CLAIMED:** that differentiation occurs at all · that any particular region forms · that the partition is
functionally good, optimal, or task-appropriate · that V3 §9's regions emerge · that specialization is useful · that
diversity is maintained · that development converges · that equilibrium is reached · any cognitive property.

> ### **R14.1 — "SELF-ORGANIZATION" IN V4 IS WEAKER THAN THE PHRASE SUGGESTS, AND THAT IS THE POINT.**
> The population's contribution is: **sample, excite, inhibit, update within a genome-bounded simplex, emit
> inhibition, self-restrict, and propose.** Every *decision* — warrant, accounting, admissibility, authorization,
> anchoring, guarding — is K's. **⟹ The organism organizes itself in the sense that it DISCOVERS the candidate cuts
> and commitments; governance CONSTITUTES them.** The alternative — letting the population constitute its own scopes —
> is §2.1's circularity, EA-1's existence-as-authorization, and N8's giant controller, all at once.

> ### **R14.2 — THE ENGINE IS A FUNCTION SET, NOT AN ACTOR (the §109 necessity proof).**
> | Function | Altitude | Centralized? | Necessity |
> |---|---|---|---|
> | **F-1** field generation | **cell** (`ORGANIZER`) | ❌ **must be decentralized** | centralizing it = manufacturing position centrally = V3 §9 re-entering through a data channel |
> | **F-2** sampling + `fate_bias` dynamics (L1–L6) | **cell** | ❌ **inherited as decentralized** | `Cell` state table gives the cell the write: *"O, **C↑ within `reaction_norm`**"* |
> | **F-3** tick scheduling | organism | ✅ **YES** | a cell-scheduled tick lets a cell accelerate its own commitment ⟹ manufacture irreversibility ⟹ claim `Cell I-23` protection (EA-4). **Scheduling is tempo control; tempo controls irreversibility; irreversibility is capacity** |
> | **F-4** admissibility + authorization + accounting + anchoring (K1–K6) | **K** | ✅ **YES** | (i) `role`/`dev_stage`/`niche_slot`/`region_id` are identity or capacity fields; (ii) niche accounting must be single-writer; (iii) anchors must not be written by the scope they anchor; (iv) `Cell` Rule 19 |
> **⟹ The controller is NOT giant:** it does not generate fields, compute `fate_bias`, choose specializations, or
> decide which cells commit. **F-4's admissibility step is MECHANICAL — K evaluates a five-conjunct predicate; K does
> not judge it.** A controller that *decides* is an authority; a service that *validates against declared rules* is a
> kernel function.
> **The engine becomes a prohibited giant controller if it acquires ANY of:** (a) discretion over admissibility;
> (b) field generation; (c) exclusive `fate_bias` computation; (d) constitution outside a declared abeyance;
> (e) ownership of the objective (`Cell I-12`); (f) anchor-writing from its own activity; (g) retention of authority
> after Σ4. **Each is prohibited by a rule already stated — the prohibition is enumerated, not aspirational.**
> **⟹ The architecture is DECENTRALIZED IN DISCOVERY and CENTRALIZED IN CONSTITUTION.** Three decentralized mechanisms
> are load-bearing: **behavioural self-restriction** (L7 — the fastest adaptive mechanism in development, entirely
> unilateral), **lateral inhibition** (L6 — no central agent computes the pattern), and **demand proposal** (L8 — the
> population's knowledge of its own unmet needs is decentralized; only the authorization is central).

## 14.3 The 13 proposed amendments to prior contracts — **NONE APPLIED**

| # | Contract | Amendment | Arises from |
|---|---|---|---|
| 1 | `Cell` Annex B P11 + §27 | Restate the recovery guarantee: **functional identity, not state identity**, and **only while a niche is available** | X-D4, X-D16 |
| 2 | `Cell` Annex B `T04`/`T05` | Declare **non-waivable, including in crisis**; make explicit that P12 covers **role** authority, requiring re-authorization at `T32` | X-D12, X-D7 |
| 3 | `Cell` Annex B §4.3 | **Extend `G-a` and `G-b` to `T41`** | R10.23 |
| 4 | `Cell §3.2` | **Define `R`** (morphogen species count, envelope-fixed) | D-D04 |
| 5 | `Cell A-11` | **Versioned `RoleCode` extension protocol**: enum version in the envelope; per-version birth-certificate validity; mandatory independence spec for any new governance-bearing role | Part 15.2 |
| 6 | `Cell §7` | **NICHE-class payloads retryable**, at-least-once + idempotent; POSITION/DEMAND/INHIBITION remain non-retryable | R5.1 |
| 7 | `Cell` Annex B `T41` | Add the **asymmetry qualifier**: non-convergence is a failure **only when an external asymmetry was present** | R3.9 |
| 8 | `P0-05 §30` | Add budget class **B8 CONSTITUTIONAL_BUDGET** | R7.4 |
| 9 | `Cell I-22` | Enumerate **developmental reorganization** (Σ-operations, E6, `T41`) alongside plasticity and mutation | R10.24 |
| 10 | `P0-02` | Add the **K-held structural store** (+ abeyance registry, organizer spec registry, anchor-writing from verification records) | Part 15.1 |
| 11 | `Cell §15.2` | Clarify *"each differentiation tick"* as an **async-partial, K-scheduled per-cell event**, not a global barrier | R15.4 |
| 12 | `Cell` Annex B `T34` | **Exclude structural-record divergence** from `T34`'s trigger list; it requires a distinct response | R10.1 |
| 13 | `Cell §22.3` | Restate the `[U]` on 50,000× change per R10.16 | R10.16 |

## 14.4 Open research — 16 items

**BOUNDED with named residual (6):** entrenchment limits reversibility · churn-cap value is a governance choice ·
gradual entrenchment post-constitution (detected by M-Σ3, not prevented) · gradual membership laundering below
`θ_overlap` (auditable, not preventable) · `mandatory_path` accumulation ⟹ immobility · permanent Σ-log growth
(bounded only by OP-authorized compaction).

**UNCLOSABLE-IN-CONTRACT (1):** **the monitor set has no monitor.** The recursion terminates because the monitor set
is SCHEMA — `[RO-13]`/K-held, unwritable by the substrate. **Its integrity rests on governance and on `P0-02`'s
off-substrate enforcement, and no contract can guarantee its own guarantor.** This is the same residual `P0-02`
recorded for the kernel and `P0-05` for its fixed validation core.

**OPEN, owned outside this contract or by open research (9):** K's pre-constitutional authority is unbounded in
substance (abeyance is finite, logged, expiring — a **bound**; the executor of Σ1 is also its beneficiary, so writer
separation is unavailable) · Σ1's membership choice is undetermined by the Σ-rules · **regional verification is
sandbox-grade (`OR-D4`, the PRINCIPAL LIMIT)** · within-spec gradient steering (**the suite's only OPEN attack**) ·
path-dependence of developmental outcomes · near-sole-satisfier gaming with a token redundant alternative ·
homogeneous envelope ⟹ monoculture with no guard firing (an envelope property; no rule is violated) · **scope-depth
exhaustion above ~10⁸ cells** (S1–S6 is a 6-level ladder, S6 is ∅ for learning, `Cell §22`'s deepest tier is 5 ⟹ at
bounded fanout `f⁶` ≈ 10⁷–10⁹; the three options — raise fanout, add scope levels, treat 10¹² as multiple organisms —
all require amendments this contract may not make) · **inherited `P0-05 RH-2`** evaluator manipulation, on which
bootstrap depends at its most acute point.

## 14.5 Equilibrium — not claimed

**No equilibrium is claimed, and none is required.** (a) The system is **not closed** — the envelope, niches, tasks,
and hardware tier all change by external authorization. (b) **Zero-sum is a conservation law, not an equilibrium.**
(c) **`T_dev` is monotone decreasing** ⟹ the dynamics are not time-reversible and have no detailed balance.
(d) **Anchor debt accumulates monotonically** until STALL — a **boundary**, not an equilibrium.

**What exists instead is a BOUNDED NON-EQUILIBRIUM REGIME:** constant population (`Cell G13`) · bounded structural
churn (B8, B6, R10.23c) · monotonically tightening anchor debt punctuated by verified re-establishment · bounded
entropy (`G-b` extended) · periodic governance re-authorization of niches and organizer terms. **⟹ The correct
question is not "does it reach equilibrium?" but "are the regime's bounds enforceable and its excursions detectable?"**
Bounds: DEV-INV-16…20, 31…35. Detection: M-Σ1…M-Σ9. **Whether the regime is *desirable* is path-dependence, and is
not answered here.**

---

# PART 15 — WHAT THIS CONTRACT REQUIRES OF OTHERS

## 15.1 From `P0-02` (EIK) — **blocking**
A **K-held, off-substrate, anchored, append-only STRUCTURAL STORE** containing: `RegionRecord`s · Σ-tombstones ·
`StructuralProvenance` · abeyance records · the niche ledger · anchors · organizer emission specs · reconciliation
state. **Not a new cell field and not a new lifecycle state — a kernel-side store.**
**Why K and not the organism:** the organism *is* the substrate. A structural store held on the substrate could be
rewritten by the entity whose structure it records — which would make R4.2's predicate self-evaluated and R10.2's
reconciliation self-adjudicated. **`Cell §3.4` marks the developed phenotype checkpointable but explicitly NOT
off-cell, and `Cell §30` marks region formation "Partial" with only cell-side inputs ⟹ no inherited store holds
region-level realized structure.** Without one, R4.2 cannot be evaluated by anyone, R4.11 cannot be checked, R8.3's
tombstones have no home, R7.2's ledger has no location, and Σ2 re-homing has no record of what was dissolved.
Also required: abeyance registry · organizer spec registry · anchor-writing from verification records.

## 15.2 On `RoleCode` — role discovery is impossible, and this is accepted
**The population cannot discover, invent, name, or instantiate a role outside the closed 16-value `RoleCode` enum.**
Proof: the enum is **closed** (`Cell §15.3`, `§3.1`); it is **wire-level** (`Cell A-11`: *"different orderings ⇒ wire
incompatibility"*); and `role` is **identity**, signed into the birth certificate (`Cell I-1`, `I-19`).
**⟹ The expressiveness ceiling is real:** a task requiring a 17th kind of participant cannot be served by development
at any population size. **Accepted, not hidden.**
**Why a closed type space is a FEATURE:** `Cell I-10` makes independence **kernel-attested**, and `Cell §15.3`
attaches a specific independence requirement to each governance-bearing role. **An open type space would make these
requirements unenumerable, hence unattestable, hence ungovernable.** Removing the closed enum to gain role discovery
would trade a bounded expressiveness ceiling for an unbounded verification failure. **That trade is rejected.**
**Where openness lives:** the **TYPE space is closed** (16 roles, 5 variants, 18 lifecycle states, 34 message types);
**the INSTANCE space is open** (which cells, which specialization, which admissible targets, which topology, which
partition, which arrangement). **Development is search over the instance space. This is the precise sense in which V4
self-organizes, and the precise sense in which it does not.**
**Extension mechanism (precedent: `COMPRESSOR` and `ORGANIZER` were added by audit, offline):** a role may be added
only when a **required function is architecturally impossible without it**, shipping with core function, minimum
variant, independence requirement, capture-target assessment, and wire-version impact. **The organism may PROPOSE an
extension (CH-3-class, no effect, no budget, B7-limited); it may never enact one.**

## 15.3 From `P0-03` — **unresolved**
A ruling on whether an **enumerated region boundary** counts as a **network partition**, given that `P0-03`'s
deterministic-delivery guarantee holds only for *"S3/S4 on non-partitioned networks"* while regions **are** cuts.
This contract's side is bounded: boundaries are enumerated and **never block**, so the network stays connected.

## 15.4 On scale
**This contract does not claim scalability to 10¹².** The inherited range is **~200 to ~10⁷** (`Cell §22`, five
tiers). The decentralized half (L1–L8) is **O(N) with a small constant and no global coordination**; the K-side half
is **O(Σ-ops + niches + organizers + monitors)**, independent of `N` except through the permanent Σ-log integral and
the tick schedule. **Two structural walls above ~10⁸:** scope-depth exhaustion (§14.4) and permanent Σ-log growth.
**Development scales by keeping adaptation LOCAL and constitution RARE — which is exactly what B8's
non-accumulability enforces.**

---

# PART 16 — CONFORMANCE CHECKLIST

An implementation conforms iff every line holds. Each is falsifiable.

1. **No cell-level field added; no lifecycle state or transition added** (`Cell` Annex B P4).
2. **Σ1 → Σ4 → E\*** ordering enforced; any E-rung against a nonexistent scope is rejected as scope elevation.
3. **Σ-operations write instances only.** Any attempt to write `RoleCode`, scope definitions, a matrix, the Σ-rules,
   the FI set, or the monitor set is rejected.
4. **`devolved_authority` is enumerated**; no general grant exists; merge never unions; split never exceeds parent.
5. **Σ4 expires the abeyance it devolves from.**
6. **A constituted scope begins at `UDB := 0`, `anchor := ⊥`**; anchors are written by K from verification records.
7. **Merge, split, and migration inherit anchor debt; none resets it.** Migration re-establishes by fresh measurement.
8. **Every Σ2 writes a permanent anchored tombstone**; `region_id` is never reused.
9. **`region_exists` is evaluated as an eight-conjunct predicate**; a `region_id` write without it is an integrity
   failure ⟹ **quiesce, never `T34`**.
10. **No `mandatory_path` crosses a region boundary**; boundaries are enumerated and never block a message.
11. **Every `RegionRecord` has a non-null `dissolution_cond`** specifying contract preservation.
12. **Commitment requires all six conjuncts**, each separately evidenced; **demand alone never authorizes**.
13. **`PROVISIONAL → COMMITTED` occurs only after lifecycle `CALIBRATING` has supplied probe budget.**
14. **`T32` admits to `CALIBRATING` only; `T04`/`T05` are non-waivable, including in crisis.**
15. **Specialization is monotone restriction**: no port widening, no variant raise, no authority increase.
16. **Every specialization declares a reversal condition, and the condition is never erased.**
17. **D4 and D5 are distinct transitions and are never conflated.**
18. **Behavioural self-restriction is unilateral and writes no identity field**; specialization metrics count nominal
    commitments only.
19. **Randomness selects among admissible outcomes and never makes an outcome admissible.**
20. **A symmetric field with no external asymmetry does not differentiate, and `T41` does not fire for it.**
21. **Morphogens are INFLUENCE-plane**: no warrant, no confidence, no truth, no verdict, no provenance, no authority,
    no fitness value.
22. **Organizers generate; the engine warrants** against a registered, `[RO-13]`-approved, non-self-modifiable spec;
    **≥2 with disjoint specs**; no self-reference; no self-succession; POSITION and INHIBITION classes only.
23. **Position is re-derived, never restored.**
24. **Niche accounting (K), authorization (K/`[RO-13]`), occupancy (ORG), and demand (any) are four distinct actors.**
25. **Niche occupancy is lineage-blind**; niches lapse without re-authorization.
26. **No developmental outcome is written to any heritable store.**
27. **B8 is global, non-fungible, non-accumulable, and Σ2-exempt.**
28. **No developmental response to failure increases capacity.**
29. **K unavailability freezes development**; only behavioural self-restriction remains available.
30. **`T41` is guarded by `G-a` and `G-b`**; rare-capability cells go to `DORMANT`, not retirement; a churn cap halts
    `T01`.
31. **`T41` retirement is recorded as `DEVELOPMENTAL_UNPLACED`** and contributes to no performance record.
32. **Ablation is K-scheduled with governance-reserved slots**; a sole satisfier's delta is `UNSUPPORTED` and
    contributes **zero** to replication eligibility.
33. **Structural assertions are never converted into beliefs, confidence, or warrant**; role gates permissions without
    grading truth.
34. **The developmental self-model is Λ2 and not self-updating.**
35. **Monitors observe correlation, never content, and produce alarms, never enactments.**
36. **Provenance is immutable**: no retro-annotation, no erased reversal condition, no reclassified `T41`, no
    re-based anchor.
37. **Branching is sandbox-based; the reserved null branch exists; branch factor is bounded at candidacy.**
38. **Downward tier migration is a governance event** with a mandatory Σ2/merge plan, authority reduction,
    compression, and explicit FI waivers.
39. **Compression follows the C-1…C-7 order and never waives an FI silently**; FI-05/10/11 waivers require OP.
40. **No numerical parameter has a value that this contract invented**; all 50 registry entries carry a class and a
    source; all `[T]` entries are marked BLOCKED on `P0-01`.
41. **The bootstrap follows B0→B8 with no phase skipped, and B1 precedes B3.**
42. **The initial niche set is heterogeneous, or the system correctly does not differentiate and escalates to
    governance.**
43. **None of the fifteen prohibited claims (§14.1) appears in any documentation, metric, log message, or test
    assertion produced by the implementation.**

---

*End of the canonical contract (Output 95). Analysis, derivations, attacks, and audits: Volumes A–F (`47_`–`52_`).
Verdict, deliverable index, ratings, surviving principles, and the FINAL STANDARD: `README.md`.*
