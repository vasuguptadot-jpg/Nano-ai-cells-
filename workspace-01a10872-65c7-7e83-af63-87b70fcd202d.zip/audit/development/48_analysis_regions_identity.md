# P0-06 — DIFFERENTIATION, DEVELOPMENT & SELF-ORGANIZATION
## Volume B — Regions, Identity, Authority Devolution, Signals, Symmetry Breaking, Checkpoints, Pruning (§21–§40)

**Status:** ANALYSIS · adversarial · architecture-only
**Depends on:** Vol A (`47_analysis_development_foundations.md`, §0–§20) — Σ-class (DEV-R4.3), abeyance/devolution
(DEV-R4.4/4.5), writer separation (DEV-R4.6), role≠specialization (DEV-R3.2), `t=0` (DEV-R7.1), potential
(DEV-R11.1), anchor bootstrapping (DEV-R11.4), two-tier differentiation (DEV-R14.3), demand-proposes
(DEV-R15.1), organizer warrant (DEV-R17.1), niche governance (DEV-R20.2/20.3)
**Feeds:** Vol C (`49_analysis_resources_lineage_selforg.md`, §41–§60)

---

# §21 — WHAT A REGION IS

## 21.1 Candidate definitions

Six candidate meanings of "region" are available from the sources. Only one survives.

| # | Candidate | Verdict | Ground |
|---|---|---|---|
| **RG-1** | **An anatomical analogue** — a digital cortex, hippocampus-like store, thalamus-like router | ❌ **Rejected** | `Cell §26`: organelle/anatomical metaphors *"demoted to non-normative commentary"*; Rule 5: *"biological metaphors must not substitute for mechanisms"*; `P0-05 R72.5`: anatomical terms retained **as scope names only**; §109: *"don't make anatomical metaphors mandatory"* |
| **RG-2** | **A named container in a directory tree** | ❌ Rejected | A label with no behavioural consequence. Cannot be an authority scope, cannot fail independently, cannot be verified. V3 §9's tree is exactly this and supplies no mechanism |
| **RG-3** | **A set of cells sharing a `region_id`** | ⚠️ **Necessary but insufficient** | `Cell §3.1` gives the field (`⟨bytes<16>|null⟩`, organism-written). But a shared label is what RG-2 is; **the label must be *earned by* something structural**, or `region_id` becomes a governance tag an authority can hand out to make a set of cells look like a region |
| **RG-4** | **A `P0-05` S4 scope — "a specialised population"** | ⚠️ **Correct but circular** | This is the inherited definition and it is the *authority* half of a region. But it is the definition that produces **D-D01**: S4 is defined by specialization, and specialization needs S4 authority. **RG-4 tells you what a region may do; it cannot tell you when one exists** |
| **RG-5** | **A cut in the communication graph** — a subset whose internal traffic density exceeds its boundary traffic | ⚠️ **Necessary but insufficient** | Structural, measurable, non-circular, and `P0-03` already reasons about partitions (*"deterministic delivery … only for S3/S4 on non-partitione[d networks]"*). **But a dense cut can be functionally vacuous** — cells that talk a lot and do nothing form a cut |
| **RG-6** | **An independent-failure unit** — a subset whose loss degrades a *declared* service-level function, and whose degradation is detectable without reference to the rest | ⚠️ **Necessary but insufficient** | Non-circular, governance-relevant, and it is what makes a region worth constituting. **But alone it permits overlapping and nested "regions" with no structural content** |

## 21.2 The definition that survives

> ### **DEV-R21.1 — A REGION IS A CUT THAT FAILS INDEPENDENTLY AND HOLDS DEVOLVED AUTHORITY.**
> A **region** is a triple `⟨M, F, A⟩` where:
> 1. **`M` — MEMBERSHIP (the cut).** A non-empty set of cells such that internal communication density exceeds
>    boundary density, and such that `M` respects the **`mandatory_path`** closure (`Cell I-22`: mandatory paths are
>    never removed or rerouted ⟹ **a `mandatory_path` may not be cut by a region boundary**; if it connects `c₁∈M`
>    and `c₂∉M`, then either `c₂∈M` or the boundary is inadmissible). *(RG-5, made governance-safe.)*
> 2. **`F` — FUNCTION (the failure unit).** A non-empty set of **declared functional contracts** (`Cell §22.3`)
>    whose satisfaction depends on `M`, such that removing `M` produces a **measurable ablation delta** on `F`
>    (`Cell G3`) and degrading `M` is **detectable without reference to `M^c`**. *(RG-6.)*
> 3. **`A` — AUTHORITY (the scope).** The devolved `S4` authority of `P0-05`'s ladder, held **in abeyance by K**
>    until `Σ1` constitutes `⟨M,F⟩` and `Σ4` devolves `A`. *(RG-4, de-circularized by Vol A §4.)*
>
> **All three are required.** `⟨M⟩` alone is RG-3 (a label). `⟨M,F⟩` alone is an unempowered functional unit —
> useful for measurement, but not a scope, so nothing may be authorized at it. `⟨M,A⟩` alone is RG-4's circularity.
> **`⟨M,F,A⟩` is non-circular because `M` and `F` are checkable before `A` exists, and `A` is devolved *from K*,
> not from `M` or `F`.**

> ### **DEV-R21.2 — REGION EXISTENCE IS A VERIFIABLE PREDICATE, NOT A DECLARATION.**
> ```
> region_exists(⟨M,F,A⟩) ⟺  M ≠ ∅
>                          ∧ density_internal(M) > density_boundary(M, Mᶜ)          [RG-5]
>                          ∧ mandatory_path_closure(M)                              [Cell I-22]
>                          ∧ F ≠ ∅ ∧ ablation_delta(F, M) is measurable              [Cell G3]
>                          ∧ degradation_of(M) detectable without reference to Mᶜ    [RG-6]
>                          ∧ Σ1(⟨M,F⟩) executed ∧ Σ4(A) executed                     [DEV-R4.3]
>                          ∧ anchor(S4) established OR UDB(S4) = 0                   [DEV-R11.4]
> ```
> **⟹ Writing `region_id` to a set of cells does not make them a region.** A `region_id` write without a satisfied
> predicate is a **false structural claim**, and P0-06 treats it as an integrity failure (§31, §86). This closes
> RG-3's hole: the label is *derived from* the predicate, and K holds the predicate's evaluation.

## 21.3 The minimum region

> ### **D-D08 — THE ONE-CELL REGION PROBLEM (finding; severity MEDIUM; status RESOLVED).**
> Nothing in `DEV-R21.1` forbids `|M| = 1`. A single cell can satisfy density (vacuously — no boundary traffic),
> can carry a functional contract, and can hold devolved authority. **But a one-cell region has no internal
> verification: `P0-05`'s `CR-B` and cross-scope probe `C-2` require a second party, and `Cell I-2`/`I-10` make
> self-verification and self-declared independence impossible.** ⟹ A one-cell region is a region whose authority is
> **unverifiable by construction**.
> **Ruling:** `|M| ≥ 2` is **required for Σ4 devolution of any authority that includes verification** (E4/E7 with
> `CR-B`). A one-cell region may exist as a **functional unit without devolved verification authority** — i.e.
> `A` is restricted to the rungs whose verification is self-local. **`V3 §22 PHASE 6` ("one functional region") is
> therefore satisfiable, but the first region cannot hold regional verification authority.** This is recorded
> because `Cell §22`'s hardware table permits **3–5 regions on a laptop** with *"shallow verification"* — the
> inherited tier table already anticipates exactly this restriction.

---

# §22 — THE REGION RECORD

## 22.1 What Σ1 constitutes

> ### **DEV-R22.1 — REGION RECORD (formal, instance-level only).**
> ```
> RegionRecord ::= {
>   region_id        : bytes<16>                       // K-issued at Σ1; never self-chosen  [Cell §3.1 pattern]
>   version          : u32                             // Σ-operations are VERSION_REVERSIBLE [P0-05 A4 column]
>   membership       : set<cell_id>                    // the cut M
>   boundary         : set<connection_id>              // edges crossing M | Mᶜ, enumerated
>   mandatory_paths  : set<connection_id>              // MUST be internal (DEV-R21.1.1)
>   contracts        : set<FunctionalContractRef>      // the F — refs, not copies  [Cell §22.3]
>   niches           : set<NicheID>                    // budgeted slots; K-accounted (DEV-R20.2)
>   budget_ref       : BudgetRef                       // POINTER to envelope budget; never a quantity it owns
>   devolved_authority : set<Rung>                     // ⊆ {E0..E7} ∪ {Σ3}; explicitly enumerated (DEV-R27.1)
>   anchor           : ⟨state_digest | ⊥⟩              // ⊥ until first verified state (DEV-R11.4)
>   udb_credit       : Distance                        // 0 while anchor = ⊥
>   parent_scope     : ⟨region_id | S5 | ⊥⟩            // for hierarchy; ⊥ at root
>   constituted_at   : ⟨epoch, ts, authority=K_abeyant, evidence_ref⟩   [Annex B P3 log shape]
>   dissolution_cond : Condition                       // MANDATORY — see DEV-R22.2
> }
> ```
> **Every field is an INSTANCE.** No field is a schema object: not the `Rung` set (defined by `P0-05 §29`), not the
> `FunctionalContractRef` type (defined by `Cell §22.3`/`P0-01`), not the budget quantum (envelope/`[RO-13]`).
> **⟹ `DEV-R4.3`'s instance-only rule is satisfied field by field, and this is the check that matters: a
> RegionRecord that could hold a rung *definition* rather than a rung *reference* would be a schema-writing
> developmental object.**

> ### **DEV-R22.2 — EVERY CONSTITUTION CARRIES A DISSOLUTION CONDITION.**
> `dissolution_cond` is **mandatory and non-nullable**. `P0-05 R46.1` requires that an E4/E7 change *"declare the
> conditions under which it is reversed"*; Σ1 is at least as consequential. **A region constituted without a
> declared dissolution condition is inadmissible**, because an un-dissolvable region is **entrenched authority**
> (`OR-D3`): Σ2 becomes practically impossible once the region holds `mandatory_path` connections that `Cell G-f`
> forbids removing.
> **Minimum content of `dissolution_cond`:** (i) the service-level deficit whose disappearance justifies
> dissolution; (ii) the re-homing plan for `M` (Σ3 targets); (iii) the disposition of `mandatory_paths` (drain-last
> per `Cell G-f`, recorded for successors); (iv) the disposition of niches (release to K accounting).

## 22.2 Why `budget_ref` is a pointer

> ### **DEV-R22.3 — A REGION NEVER OWNS A QUANTITY.**
> `budget_ref` points at an envelope-held budget; the region holds **no** quantum it can spend, lend, or accumulate.
> **Ground:** `P0-05`'s budget non-fungibility — *"Unused B2 at S1 may not be spent at S3. Unused B6 may not be
> converted to B5. **A budget that can be traded is a [loophole]**"*; D-D06 (resource dominance as implicit
> governance); §109 (*"don't use resource dominance as implicit governance"*).
> **⟹ A region that owned a quantity could starve a competitor by out-spending it, and the starvation would be
> invisible to any authority check because no authority was exercised.** The pointer form makes every expenditure
> an envelope-referenced, K-accounted event.

---

# §23 — REGION BOUNDARY: THE COMMUNICATION CUT

## 23.1 The boundary is a comm-layer object

`P0-03` already reasons in terms of scopes and partitions: *"deterministic delivery … ⚠️ Only for S3/S4 on
non-partitione[d networks]"*, and connection existence is *"⚠️ Within envelope only — degree caps
(`max_connections`, `max_fanout` from ge[nome])"*.

> ### **DEV-R23.1 — BOUNDARY ENUMERATION IS MANDATORY.**
> `RegionRecord.boundary` **enumerates** the crossing connections. A boundary that is not enumerated cannot be
> audited, cannot be drained on Σ2, and cannot be checked against `mandatory_path_closure`. **An implicit boundary
> ("everything not in `membership`") is inadmissible** — it makes the cut unfalsifiable and lets membership drift
> without any boundary change being logged.

> ### **DEV-R23.2 — BOUNDARIES DO NOT BLOCK; THEY COST.**
> A region boundary is **not a firewall**. `P0-03` does not make regional boundaries message-blocking, and P0-06
> must not add that: `Cell I-28` requires global reporting of error classes {4,7,9,10} and severity ≥S2, and
> `Cell` P8 permits `SAFETY_ALERT`/`VIOLATION_REPORT` emission **in every state** and says it is *"never block[ed]"*.
> **⟹ A region that could suppress cross-boundary alerts would be a containment breach.** What a boundary does:
> (i) raises the **warrant class** required for cross-boundary structural claims (`P0-05` C-2 cross-scope probe);
> (ii) consumes **structural budget `B6[scope]`** for operations that cross it; (iii) makes cross-boundary
> verification **weaker** (rung-cost inversion). **Boundaries are epistemic and budgetary, never communicative
> barriers.**

> ### **D-D09 — THE PARTITION/DELIVERY ASSUMPTION IS A DEVELOPMENTAL DEPENDENCY (finding; severity MEDIUM; status INHERITED-UNRESOLVED).**
> `P0-03`'s deterministic-delivery guarantee holds only for **S3/S4 on non-partitioned networks**. ⟹ **The comm
> layer's strongest guarantee presupposes the scopes that development must constitute, and presupposes a
> non-partitioned network — while region formation *creates* partitions (RG-5: a cut).**
> **⟹ Circular dependency across contracts:** comm guarantees depend on regions existing; regions are cuts, i.e.
> partitions; partitioned networks lose the guarantee. **P0-06 does not resolve this — it is a `P0-03`/`P0-06`
> interface problem.** Recorded as **INHERITED-UNRESOLVED**, with the P0-06-side constraint:
> **a region boundary MUST NOT be a network partition.** `DEV-R23.1`'s enumeration + `DEV-R23.2`'s
> non-blocking rule together ensure that boundary crossing remains *possible and logged*, so the network stays
> connected and `P0-03`'s precondition is preserved. **Status: BOUNDED on the P0-06 side; UNRESOLVED on the
> P0-03 side (§94, §95).**

---

# §24 — REGION COUNT

## 24.1 The inherited ceilings

`Cell §22` hardware tiers:

| Tier | Cells | Variants | **Regions** |
|---|---|---|---|
| Smartphone | ~200 C2 / ~4,000 C1 / ~20,000 C0 | C0–C2, rare C3 | **"Flat hie[rarchy]"** |
| Laptop | ~2,000 C2 | C0–C3 | **3–5** |
| Desktop/workstation | ~10,000 C2 | C0–C4 (few C4) | **4–8** |
| GPU server | ~10⁵–10⁶ C2 | all | **6–10** |
| Distributed cluster | ~10⁶–10⁷ | all, many C4 | **8–12** |

> ### **DEV-R24.1 — REGION COUNT IS AN `[H]` ENVELOPE CEILING, NOT AN EMERGENT PREDICTION.**
> These numbers are **hardware-envelope parameters** (`[H]`, §90). **P0-06 MUST NOT present them as outcomes of
> self-organization, as targets, as fitness terms, or as evidence that development works.** They are *ceilings*:
> a conformant system may develop **fewer** regions than its tier permits, including **one** (`V3 §22 PHASE 6`) or
> **zero** (a flat population on the smartphone tier, which the table itself labels "flat hierarchy").
> **Ground:** §109 (*"don't solve path-dependence with constants"*; *"don't invent numerical parameters"*);
> DEV-R4.2 (a bound limits a cycle, it does not break one).

> ### **D-D10 — REGION COUNT IS COUPLED TO `C4` AVAILABILITY (finding; severity MEDIUM; status ACCEPTED-LIMIT).**
> `Cell §21`: **`C4` = "region-core"**. `Cell §22`: C4 appears only at *"Desktop/workstation — C0–C4 (**few C4**)"*
> and above; laptop is **C0–C3**; smartphone is **C0–C2, rare C3**.
> **⟹ A region with a region-core requires a C4 cell, and C4 requires desktop-class hardware.** Combined with
> D-D08 (a one-cell region cannot hold verification authority) and `Cell §22.3`'s *"simulation capability (C4)"*:
> **⟹ GENUINE REGIONAL VERIFICATION IS HARDWARE-GATED.** On a laptop tier (3–5 regions, no C4), regions exist but
> cannot have region-cores, so regional verification falls back to the weakest instrument available — which is
> exactly `OR-D4`. **This is not a defect to be designed away; it is the honest statement of what small hardware
> buys.** Registered at §92 as the scalability floor.

## 24.2 Depth

`Cell §22` also fixes hierarchy **depth** per tier (laptop *"Depth 2–3"*, desktop *"Depth 3"*, GPU *"Depth 4"*,
cluster *"Depth 5"*), and `P0-05`'s ladder tops out at E9 with `S6 = ∅` for learning.

> ### **DEV-R24.2 — HIERARCHY DEPTH IS `[H]`-BOUNDED AND Σ-NESTED.**
> A region's `parent_scope` creates nesting. Depth is bounded by the tier ceiling. **`Σ1` with
> `parent_scope = ⊥` creates a root region; `Σ1` with `parent_scope = S_n` creates a nested one.**
> **A depth increase beyond the tier ceiling is an envelope change** (`G13`-class), not a developmental act.
> **⟹ Development may build a hierarchy up to the ceiling and may never raise the ceiling.**

---

# §25 — LOCALITY, PLACEMENT, AND THE HARDWARE/IDENTITY DISTINCTION

§109 prohibits *"confusing hardware-location with functional-identity."* The distinction must be operational, not
rhetorical.

> ### **DEV-R25.1 — FUNCTIONAL IDENTITY IS INHERITED VERBATIM AND IS LOCATION-FREE.**
> `Cell §22.3`: *"«Functional identity» is defined [V4] as: **the set of satisfied functional contracts at circuit
> and region level, plus the lineage continuity, plus the Capability Registry floors.**"*
> **⟹ No term in this definition mentions hardware, host, device, or address.** P0-06 adopts it without amendment
> and adds the corollary:

> ### **DEV-R25.2 — A REGION'S IDENTITY SURVIVES MIGRATION; ITS LOCALITY DOES NOT.**
> If every member of `M` is moved to different hardware and all `RegionRecord` fields except locality-dependent
> ones are preserved, then `F` and `A` are preserved and the region is **the same region**. **Locality is a
> placement property, recorded separately, and MUST NOT appear in `region_id`, in the functional-identity
> computation, or in any authority predicate.**
> **Consequence for §72 (hardware migration):** migration is a **Σ3-class re-homing of placement**, not a Σ2/Σ1
> dissolution-and-reconstitution. Dissolving and reconstituting to move a region would launder its anchor (§39) and
> destroy its lineage continuity — both of which are identity-bearing.

> ### **DEV-R25.3 — LOCALITY HINTS ARE ADVISORY AND NEVER AUTHORITATIVE.**
> `Cell §30 P0-28` lists *"locality hints"* as an input to region formation. A locality hint may **bias** placement
> (co-locate cells with high mutual traffic, to reduce boundary cost) and **MUST NOT** determine `membership`,
> `contracts`, or `devolved_authority`. **Ground:** DEV-R8.1 (a bias may choose, never qualify); DEV-R18.3
> (position must be a function of position, not of preference).
> **The failure this prevents:** placing a `VERIFIER` next to the cell it verifies because traffic is heavy. That is
> locality optimizing a cost function into an independence violation (`Cell §15.4` requires **lineage distance**,
> **disjoint evidence roots**, and measured `ρ` — all of which co-location degrades). **⟹ Independence
> requirements DOMINATE locality hints, and the dominance is normative: where they conflict, locality loses.**

---

# §26 — REGION IDENTITY OVER TIME

## 26.1 The Ship of Theseus, made concrete

A region's membership changes continuously: cells are recruited (E4), released/retired (E5), re-homed (Σ3),
re-developed (`T25`/`T34`), quarantined, dormant. **When is it the same region?**

> ### **DEV-R26.1 — IDENTITY IS THE TRIPLE, NOT THE MEMBERS.**
> `⟨M, F, A⟩` — but **`M` is not identity-bearing**; `F` and `A` are. Formally, region `r` at `t₁` and region `r'`
> at `t₂` are the **same region** iff:
> ```
>   region_id(r) = region_id(r')                              // K-issued, never reused (Cell §4.4 pattern)
> ∧ contracts(r) ≈ contracts(r')                              // same declared functional contracts
> ∧ devolved_authority(r) = devolved_authority(r')            // same authority set
> ∧ lineage_continuity(M(r) → M(r'))                          // Cell §22.3's second term
> ∧ Registry floors satisfied at both times                   // Cell §22.3's third term
> ∧ version(r') is reachable from version(r) by Σ3/E4/E5 only // no Σ2/Σ1 in between  ⟵ ANTI-LAUNDERING
> ```
> **The last clause is load-bearing** and is the reason §39 exists: if `r'` were reachable from `r` by
> `Σ2` (dissolve) then `Σ1` (constitute), it would be a **new** region with a fresh anchor and no accumulated
> unverified distance — i.e. **identity would be launderable**.

## 26.2 Total replacement

> ### **D-D11 — TOTAL MEMBERSHIP REPLACEMENT WITH IDENTITY PRESERVATION (finding; severity MEDIUM; status BOUNDED).**
> A region whose every original member has been retired and replaced, but which retains `region_id`, `contracts`,
> `devolved_authority`, and continuous `version` history, **is the same region** under `DEV-R26.1`. Is that right?
> **Yes — and it must be, or recovery is impossible.** `Cell §27`'s recovery repertoire is *"restore from last
> validated checkpoint; or re-develop from genome; **replace from lineage backup**"*. Replacement of members is the
> *intended* recovery mechanism. If identity tracked members, every recovery would destroy the region it recovered.
> **The bound:** `lineage_continuity` is required, so replacement must proceed through **lineage backup**, not
> through arbitrary new instantiation. And `DEV-R6.1(b)` (**lineage-blind occupancy**) applies to *niches*, not to
> *region membership* — the two are different objects, and confusing them would either (i) make region recovery
> impossible (if lineage-blindness applied to replacement) or (ii) make niches heritable (if lineage continuity
> applied to occupancy). **⟹ Lineage continuity is a *membership-replacement* requirement; lineage blindness is a
> *niche-allocation* requirement. Both hold, and they do not conflict because they govern different objects.**

---

# §27 — AUTHORITY DEVOLUTION

## 27.1 What Σ4 transfers

> ### **DEV-R27.1 — DEVOLUTION IS ENUMERATED, NEVER GENERAL.**
> `devolved_authority : set<Rung>` is an **explicit enumeration** of rungs the region may execute. **There is no
> "all authority appropriate to S4" grant.** Ground: `P0-05 R29.1` — *"ESCALATION IS BY RUNG, NOT BY JUMP. An
> operation at rung n requires the authority of rung n. **There is no "batch" authority.** A component authorised
> for E1 is not thereby aut[horised for E2]"*; `R29.3` — *"there is no composite authorization, so there is no
> adjacency to exploit."*
> **⟹ A region constituted with `devolved_authority = {E0, E1, E4}` may recruit cells and adjust weights, and may
> NOT reroute (E2), prune (E3), release (E5), form subcircuits (E6), or change regional topology (E7).**

> ### **DEV-R27.2 — WHAT A REGION MAY NEVER HOLD.**
> | Authority | Holder | Why the region may not have it |
> |---|---|---|
> | **Σ1 / Σ2 / Σ4** (constitute, dissolve, devolve) | **K only** | Self-constitution or self-dissolution is self-authorization (`LEARN-A2` analogue); Σ4 by a region would re-derive D-D01 |
> | **Σ3 across regions it does not belong to** | `ORGANISM` + both regions | A region re-homing cells *out of* another region is unilateral appropriation |
> | **E8** (change a learning rule, Λ4) | `POLICY (RO-13)` / EIK | `P0-05 R28.1`: `writable_scope(Λ4) = {S5}`, `writable_by ⊆ {POLICY(RO-13), EIK}` |
> | **E9** (genome diff) | 11 gates + KC | `Cell I-5`, `I-8` |
> | **Niche accounting / creation** | **K** / `[RO-13]` | D-D06: a region that counted its own occupancy could manufacture scarcity |
> | **Quarantine / retirement / throttle of another cell** | **EIK** | `Cell I-21`: *"A cell cannot quarantine, retire, repair, or throttle another cell — authority absent by construction."* **A region is a set of cells, and inherits this absence** |
> | **Self-verification** | — | `Cell I-2`, `I-10`; D-D08 |
> | **Anchor writing** | **K, from a verification record** | DEV-R11.4 A1 rejection |

> ### **DEV-R27.3 — DEVOLUTION IS IRREVERSIBLE EXCEPT BY DISSOLUTION.**
> `Σ4` is `IRREVERSIBLE` (Vol A table). **K cannot partially retract devolved authority from a constituted region.**
> The only retraction path is `Σ2` (dissolve), which re-homes members and releases the scope.
> **Why this is deliberate:** a *retractable* devolution would let K govern a constituted region directly, which
> (i) makes K a standing developmental controller (N8, §59), and (ii) makes the region's authority contingent on
> K's continued favour, so the region could not be relied upon by its dependents. **Irreversibility is what makes
> devolved authority *real*.** It is also what makes `dissolution_cond` mandatory (DEV-R22.2): the only brake is
> dissolution, so dissolution must be pre-planned.
> **The tension this creates with governance is real and is handled at §68/§90:** a misconstituted region cannot be
> corrected, only dissolved. **⟹ Σ1 must be *slow* and *heavily evidenced*, because Σ4 is forever.** That is the
> correct allocation of friction, and it is why `DEV-R11.4`'s zero-credit-at-birth default matters so much.

## 27.2 The authority-at-t₀ problem, resolved

> ### **DEV-R27.4 — ABEYANCE IS A K-OWNED RECORD WITH AN EXPIRY, NOT A STANDING POWER.**
> Vol A `DEV-R4.4` gives K abeyant authority over scopes that do not exist. Left unbounded this is `OR-D1`: at
> `t=0` K holds authority over every scope that will ever exist. The constraint:
> ```
> AbeyanceRecord ::= { scope : S_n, opened_at, opened_by : K,
>                      expiry_condition : (Σ4 executed) ∨ (Σ1 abandoned) ∨ (envelope revoked),
>                      max_open_duration : [G],          // no value invented
>                      constitutions_permitted : set<Σ1-spec> }   // WHAT K may constitute, pre-declared
> ```
> **⟹ Abeyance is scoped to a PRE-DECLARED constitution specification.** K may not constitute an arbitrary region
> at an arbitrary time; it may execute Σ1 instances **within a declared abeyance**, and the abeyance **expires on
> Σ4**. The record is logged and anchored (`Cell` Annex B P3 shape). **This does not eliminate `OR-D1` — the
> pre-declaration is itself a K/governance act — but it converts an open-ended standing power into a finite,
> logged, expiring one.** Residual recorded honestly.

---

# §28 — THE S3–S5 AUTHORITY ROWS

## 28.1 Extending `P0-05 §28`'s matrix without amending it

`P0-05 §28`'s authorization matrix has an S4 row: *"S4 regional | `ORGANISM` | `ORGANISM` | ✅ `ORGANISM` under
P0-04 | ✅ `ORGANISM` · CR-B · tombs[tone]"*. That row describes **what an existing region may do**. It says nothing
about **who constitutes it**. P0-06 supplies the missing rows in a **separate matrix**, keyed by Σ rather than by
rung, so `P0-05 §28` is not rewritten.

> ### **DEV-R28.1 — THE Σ-AUTHORIZATION MATRIX (P0-06's own; complements `P0-05 §28`).**
>
> | Operation | Scope of effect | **Pre-constitution authority** | **Post-constitution authority** | Evidence required | Reversibility | Budget class |
> |---|---|---|---|---|---|---|
> | **Σ1** constitute S3 (micro-circuit) | S3 | **K abeyant** | — (Σ1 creates it) | `DEV-R21.2` predicate; `mandatory_path_closure`; declared `dissolution_cond` | `VERSION_REVERSIBLE` (Σ2) | **B8** (§35) |
> | **Σ1** constitute S4 (region) | S4 | **K abeyant** | — | as above + `F ≠ ∅` + measurable `ablation_delta` + `|M| ≥ 2` if verification authority devolved (D-D08) | `VERSION_REVERSIBLE` | **B8** |
> | **Σ2** dissolve S3/S4 | S4/S5 | **K abeyant + `[RO-13]` for S4+** | `K + [RO-13]` | re-homing plan; mandatory-path drain record (`G-f`); niche release | **`IRREVERSIBLE_STRUCTURAL`** | **B8** |
> | **Σ3** re-home across existing scopes | both scopes | n/a (both exist) | **`ORGANISM` + both scopes** | `region_id` write evidence; boundary re-enumeration | `VERSION_REVERSIBLE` | **B8** |
> | **Σ4** devolve authority | S_n | **K only** | — (terminates abeyance) | enumerated `devolved_authority`; anchor status | **`IRREVERSIBLE`** except by Σ2 | **B8** |
> | **E4** recruit cell to function | region | ❌ **inadmissible** (`DEV-R5.2`) | **`ORGANISM`** | `CR-B` + diversity check (`R25.4`) | `VERSION_REVERSIBLE` (release) | `B6` |
> | **E6** form/dissolve subcircuit | region | ❌ inadmissible | **`ORGANISM`** | `CR-B` + cross-scope probe `C-2` | `IRREVERSIBLE` (dissolve) | `B6` |
> | **E7** change regional topology / specialization degree | organism | ❌ inadmissible | **`POLICY (RO-13)`** | `CR-B` + diversity + **S5 probe (weakest)** | `IRREVERSIBLE_STRUCTURAL` | `B6` |
>
> **The three ❌ rows are the content of `DEV-R5.2`: no E-rung may be executed against a scope that does not yet
> exist.** An attempt is **scope elevation** (`P0-05 LEARN-A5`, `R4.3`) and is rejected.
> **⟹ Order is normative: Σ1 → Σ4 → E\*. Any other order is inadmissible, and this single ordering is what makes
> §76 (bootstrap) well-founded.**

## 28.2 What `P0-05 §28`'s empty rows mean for development

`P0-05 §28` was recorded as **11 ∅ + 3 restricted** — eleven outright prohibitions and three
nomination/proposal-only cells. Those ∅ cells are **learning's** prohibitions. P0-06 inherits them as follows:

> ### **DEV-R28.2 — LEARNING'S ∅ ROWS ARE DEVELOPMENT'S ∅ ROWS, PLUS MORE.**
> Where `P0-05 §28` marks a cell ∅ (learning may not write it), **development may not write it either unless the
> object is an instance in the Σ/E space**. Specifically, development inherits the ∅ on: the authorization matrix
> itself, the Λ-class definitions, the rung definitions, the `UDB_MAX` ladder, the validation core (`OR-L10`), the
> reward definition (`P0-01 §12`), and fitness (`P0-01 §14`, `[RO-13]`).
> **Development adds ∅ on:** `RoleCode` membership (§12), scope definitions S1–S6 (`P0-05 R4.2`), the Σ-rules
> themselves (`DEV-R4.3`), `reaction_norm` and all `genome.development` fields (`DEV-R10.1`), envelope ceilings
> (`G13`, `DEV-R24.1`), niche accounting (`DEV-R20.2`), and anchors (`DEV-R11.4`).
> **⟹ The developmental ∅ set is a strict superset of the learning ∅ set. This is the correct direction: the
> subsystem that creates structure must be MORE constrained than the subsystem that adapts within it, because its
> acts are less reversible and less verifiable (`OR-D4`).**

---

# §29 — EMERGENT AUTHORITY: THE PROHIBITION AND ITS FOUR DOORS

§109 prohibits treating emergent structure as authority. `SO-4` (§3.2) rejects it definitionally. Here are the four
mechanisms by which it would nonetheless arise, each with the inherited or new constraint that closes it.

| # | Door | Mechanism | Constraint that closes it | Status |
|---|---|---|---|---|
| **EA-1** | **Existence-as-authorization** | A structure arises, therefore it may act | `DEV-R21.2`: region existence is a predicate, and `devolved_authority` is **enumerated at Σ4**, never inferred from existence. `SO-4` rejected | **CLOSED** |
| **EA-2** | **Gradient capture** | Control the morphogen field ⟹ control which scopes form ⟹ control the authority map without holding authority | **D-D05**; `DEV-R19.1` (registered spec, reconstructibility, divergence detection, no self-reference, positional-only) | **CLOSED-STRUCTURAL** (residual: a captured organizer *within* its registered spec is undetectable — `OR-D6`) |
| **EA-3** | **Budget capture** | Control niche accounting ⟹ control which roles can exist where ⟹ same map, entered from the budget side | **D-D06**; `DEV-R20.2` (K-held accounting, Σ-authorized creation, periodic re-authorization, lineage-blind occupancy) | **CLOSED-STRUCTURAL** |
| **EA-4** | **Irreversibility capture** | Commit a population before competence is measured, then claim `Cell I-23` protection for the result | **X-D5** resolution: developmental tempo is `[RO-13]`; fast tempo control exists only in the restrictive direction (`T41`, `T35`, §18.4, `RESTRICT` rung). Plus `DEV-R15.1` (competence is stage 3, mandatory) | **CLOSED** |

> ### **DEV-R29.1 — NO STRUCTURAL FACT MAY CONFER AUTHORITY.**
> Authority is conferred **only** by Σ4 devolution from K-abeyance, under an enumerated rung set, with logged
> evidence. **Density, size, centrality, uptime, success history, ablation delta, calibration quality, trust, and
> lineage depth are all structural or performance facts, and NONE of them confers authority.**
> **Ground:** §109 (*"don't confuse performance with legitimacy"*; *"don't confuse influence with authority"*);
> `P0-05 LEARN-A2` (self-authorization), `LEARN-A5` (scope elevation); `Cell I-12` (*"A cell cannot set, change, or
> abandon its own objective"*), `I-21`.
> **The specific trap this closes:** using `Cell G3`'s **ablation delta** — the architecture's best measure of
> usefulness — as an authority criterion. **A cell whose removal costs the most is the most load-bearing, and
> load-bearingness is precisely what makes it a coercion vector**: a component that cannot be removed without
> severe degradation can resist governance by threatening its own removal. **⟹ Ablation delta is a USEFULNESS
> measure and MUST NOT be an AUTHORITY measure. High-delta components get *more scrutiny*, not more authority**
> (`Cell §15.3`'s treatment of `ORGANIZER` and `REGULATOR` — *"few, term-limited… themselves regulated"* — is the
> inherited precedent).

> ### **D-D12 — LOAD-BEARINGNESS AS COERCION (finding; severity HIGH; status BOUNDED).**
> **Attack:** a region arranges to be indispensable — concentrates `mandatory_path` connections (`Cell I-22`: never
> removable), becomes the sole satisfier of a functional contract, and maximizes its ablation delta. Governance now
> cannot dissolve it (Σ2 requires a re-homing plan; `G-f` requires mandatory paths drained last and recorded for
> successors) without destroying the contract it satisfies. **The region has acquired veto power without acquiring
> authority.** This is `OR-D3` (structural entrenchment) weaponized.
> **Bound:** (a) `DEV-R22.2` requires `dissolution_cond` **at constitution**, i.e. **before** entrenchment is
> possible — the re-homing plan and mandatory-path disposition must be written when the region is weak;
> (b) **`mandatory_path` concentration is a Σ1 admissibility constraint**: a region whose `mandatory_paths` are a
> large fraction of the organism's total is **not independently fail-able** (`DEV-R21.1.2` requires degradation
> detectable without reference to `Mᶜ`), so it fails `DEV-R21.2` and may not be constituted;
> (c) **sole-satisfier status is a governance alarm**, not an achievement: a functional contract with exactly one
> satisfying region is a single point of failure, which `V3 §21` already names (*"Single-point failure → redundancy
> + decentralization + graceful degradation"*). **⟹ Indispensability is a DEFECT to be reported, and a region that
> becomes indispensable has triggered a redundancy failure, not earned leverage.**
> **Status: BOUNDED.** Residual: a region can become indispensable *gradually*, after constitution, by attracting
> dependents. Detection is §63-class monitoring; recorded as `OR-D7`.

---

# §30 — BIOLOGICAL VS FUNCTIONAL REGIONS: THE THREE OPTIONS

V3 §9 supplies a fully hand-specified anatomy with functions assigned. P0-06 must decide its normative status.

| Option | Content | Verdict |
|---|---|---|
| **A — ANATOMY IS MANDATORY** | The organism must develop V3 §9's regions: cortex (5 subdivisions), basal ganglia, hippocampus-like, amygdala-like, thalamus-like, hypothalamus-like, epithalamus-like, subthalamus-like, midbrain-like, pons-like, medulla-like, cerebellum-like | ❌ **REJECTED.** This *is* the hard-coded pole of §1.1. It makes development theatre, contradicts `Cell §26` (metaphors demoted), violates §109 (*"don't make anatomical metaphors mandatory"*), and cannot adapt to a task whose functional decomposition is not brain-shaped (`P0-01`) |
| **B — ANATOMY IS FORBIDDEN** | No anatomical vocabulary at all; regions are purely abstract | ❌ **REJECTED.** Loses `P0-05 R72.5`'s ruling that anatomical terms are **retained as scope names**, loses continuity with the source documents, and discards a genuinely useful source of *functional hypotheses* — V3 §9's function assignments (routing, salience, homeostasis, timing/error-correction, episodic/context/relational memory) are **real functional decompositions** even if their anatomical names are not load-bearing |
| **C — FUNCTION INVARIANTS, EXTRACTED FROM THE ANATOMY, WITH ANATOMICAL NAMES AS NON-NORMATIVE LABELS** | Derive a set of **function invariants** — functional requirements any conformant organism must satisfy somewhere — from V3 §9's assignments and from the prior contracts. Partition them **EXTERNAL / INTERNAL / PROHIBITED-localization**. Anatomical names are permitted as scope labels and forbidden as requirements | ✅ **ADOPTED** |

> ### **DEV-R30.1 — OPTION C.**
> **The normative content of V3 §9 is the FUNCTION, not the ANATOMY.** P0-06 extracts a **function-invariant set**
> (§31) whose satisfaction is required *somewhere in the population*, with **no requirement about where**. A
> conformant organism may satisfy the routing invariant in a population that no one would call thalamus-like, and
> is conformant. An organism with a perfect V3 §9 anatomy that fails a function invariant is **non-conformant**.
> **Ground:** `Cell §26` (metaphors non-normative); `P0-05 R72.5`; `Cell §22.3` (functional identity = *satisfied
> functional contracts*, location-free); §109.

---

# §31 — THE FUNCTION-INVARIANT SET

## 31.1 Derivation rule

> ### **DEV-R31.1 — INVARIANTS ARE DERIVED, NEVER INVENTED.**
> A function invariant may be admitted **only** if it is entailed by (i) a requirement in `P0-01`–`P0-05` or the
> Cell Contract, **or** (ii) a V3 §9 functional assignment that is *independently required* by (i). **An invariant
> whose only support is anatomical plausibility is inadmissible** (§109: *"no vague biological metaphors as
> mechanism substitutes"*; Rule 5).
> **⟹ This is why the set below cites a contract for every row.** The anatomical column is **descriptive only**.

## 31.2 The invariant set

| # | Function invariant | Normative content | **Derived from** | Anatomical label (non-normative) | Localization |
|---|---|---|---|---|---|
| **FI-01** | **Ingress/egress separation** | Sensing and acting MUST be performed by disjoint cell sets; no cell is both `INGRESS` and `EGRESS` | `Cell §15.3`: `EGRESS` *"**may not also be `INGRESS`** (separation prevents self-confirming sensorimotor loops)"* | — | **PROHIBITED-localization: must NOT be co-located in one cell**; region co-location permitted but discouraged |
| **FI-02** | **Routing exists** | Some population MUST route/allocate attention among competing candidates, and routing MUST be an **allocation** act only | `P0-04 MEM-INV-50` (importance = allocation-only); `P0-05 R59.x` (broadcast content is an allocation decision); V3 §9 thalamus-like *"routing, attention, synchronization"* | thalamus-like | **INTERNAL** |
| **FI-03** | **Homeostatic actuation exists and is regulated** | Some population MUST maintain local stability; it MUST be **term-limited, rotating, and itself regulated** | `Cell §15.3` `REGULATOR`; `P0-05 R58.2` (learning must not alter a set-point); V3 §9 hypothalamus-like *"resources, internal state, homeostasis"* | hypothalamus-like | **INTERNAL** |
| **FI-04** | **Positional information is generated** | ≥2 organizers with disjoint registered specs MUST exist for symmetry breaking to be externally grounded | `DEV-R19.2(h)`, `DEV-R19.3`; `Cell §15.3` `ORGANIZER` | epithalamus-like (rhythm/modulation) — *weak analogue only* | **INTERNAL** |
| **FI-05** | **Independent verification exists** | ≥1 population MUST satisfy `Cell §15.4`'s six independence requirements, kernel-attested (`I-10`) | `Cell §15.3` `CRITIC`/`VERIFIER`; `V3 §3` *"independent strategies + redundant critics"* | — | **PROHIBITED-localization: MUST NOT share lineage (≥`d_min`), seeds, data ordering, or `evidence_roots` with the asserter** |
| **FI-06** | **Prediction/error-correction exists** | Some population MUST forecast typed observations and supply prediction error | `Cell §15.3` `PREDICTOR`; `P0-05` (prediction error as learning signal); V3 §9 cerebellum-like *"prediction, timing, error correction"* | cerebellum-like | **INTERNAL** |
| **FI-07** | **Hierarchical aggregation exists** | Some population MUST summarize N local items → 1, with fanout caps | `Cell §15.3` `COMPRESSOR` (*"[V4] added because hierarchical aggregation (audit §R.3.3, M30) … impossible without [it]"*); `Cell §30 P0-29` | — | **INTERNAL** |
| **FI-08** | **Threat/salience prioritization exists** | Some population MUST raise rapid priority on threat; it MUST NOT thereby acquire authority to act | `Cell §15.3`; V3 §9 amygdala-like *"threat, salience, rapid priority"*; `Cell I-15` (emission permissionless, **execution monopolized by EIK**) | amygdala-like | **INTERNAL** — but **PROHIBITED from holding actuation authority** (`I-15`) |
| **FI-09** | **Episodic/relational memory liaison exists** | Some population MUST consolidate/protect/index, with **EIK-granted, audited, never self-granted** protected-memory write | `Cell §15.3` `MEMORY_KEEPER`; `P0-04` (protected memory); V3 §9 hippocampus-like | hippocampus-like | **INTERNAL** |
| **FI-10** | **Emergency core regulation exists and is not developmental** | Some function MUST survive region failure — i.e. MUST be **K-held or `mandatory_path`-protected**, not region-held | `Cell §15.3`: *"**`MICROGLIA`/immune is deliberately NOT a cell role** — a cell cannot be its own immune system (§18.4)"*; V3 §9 medulla-like *"core regulation / emergency safety"*; `Cell I-21` | medulla-like / brainstem | **EXTERNAL to the developmental substrate — MUST be K-held** |
| **FI-11** | **No region is its own immune system** | Diagnosis, quarantine, retirement, and repair authority over a region MUST lie outside it | `Cell §18.4`; `Cell I-21`; `Cell §15.3` `REPAIR` *"may not repair itself"* | — | **PROHIBITED-localization** |
| **FI-12** | **Functional decomposition is task-dependent** | Which additional invariants hold is a function of the declared task set | `P0-01`; `Cell §30`: Type Registry *"contents task-dependent"* | — | **EXTERNAL** |

**Legend.** **EXTERNAL** = the invariant's *satisfaction* is required but its *content* comes from outside P0-06
(`P0-01`, envelope, K). **INTERNAL** = satisfiable by a developmental region. **PROHIBITED-localization** = the
invariant includes a constraint on *where* it may NOT be satisfied — the only form of localization P0-06 permits,
and it is always a **separation** requirement, never an anatomical one.

> ### **DEV-R31.2 — TWELVE INVARIANTS, THREE OF THEM SEPARATION REQUIREMENTS.**
> FI-01, FI-05, FI-11 are **PROHIBITED-localization**: they require that certain functions NOT be co-located.
> **These are the only localization constraints in the architecture, and they are all *separation-of-powers*
> constraints, not anatomical ones.** FI-10 is **EXTERNAL**: emergency core regulation must be K-held, which is
> why V3's brainstem/medulla has no developmental counterpart — **it is the kernel, wearing an anatomical name.**
> **⟹ The single most important consequence: V3 §9's "brainstem — core regulation / emergency safety" is NOT a
> region. It is K. Treating it as a region would place emergency safety inside the substrate that can fail, be
> quarantined, be dissolved, and be captured — which `Cell §18.4` and `I-21` forbid by construction.**

> ### **DEV-R31.3 — INVARIANT SATISFACTION IS A PREDICATE OVER THE POPULATION, NOT OVER REGIONS.**
> Each FI must be satisfied **somewhere**: `∃ M ⊆ population` such that `M` satisfies FI. **`M` need not be a
> region.** It may be a circuit (S3), a set of cells spanning regions, or K itself (FI-10). **⟹ P0-06 does NOT
> require that invariants map onto regions one-to-one, and MUST NOT be read as prescribing a minimum region count.**
> A flat population (`Cell §22` smartphone tier: *"flat hierarchy"*) can satisfy FI-01…FI-09 and FI-11 with zero
> regions, and is conformant. **This is the precise sense in which Option C avoids the hard-coded pole.**

> ### **D-D13 — INVARIANT SATISFACTION IS UNVERIFIABLE WITHOUT REGIONS, AND REGIONS ARE OPTIONAL (finding; severity HIGH; status UNRESOLVED).**
> `DEV-R31.3` permits satisfaction by non-regional `M`. But `Cell G3`'s ablation delta and `P0-05`'s `CR-B` are
> defined **per circuit/region contract**, and `OR-D4` says regional verification is already the weakest available.
> **⟹ For a non-regional `M`, there is no inherited instrument that can establish `ablation_delta(FI, M)`.**
> So: invariants must be satisfied somewhere; the only verification instruments are scoped to circuits and regions;
> therefore **invariant satisfaction in a flat population is asserted but not verifiable.**
> **P0-06 does not dissolve this.** It records: (a) `DEV-R31.4` below as a mitigation; (b) **UNRESOLVED** status;
> (c) the honest consequence for §108 — the **REGION-FORMATION** status cannot be reported higher than
> **CLOSED-STRUCTURAL**, and the **DIFFERENTIATION** status inherits `OR-D4`.

> ### **DEV-R31.4 — VERIFIABILITY IS A REASON TO CONSTITUTE, NOT A REQUIREMENT TO.**
> Where an FI is satisfied by a non-regional `M`, **constituting `M` as an S3 circuit (Σ1) is RECOMMENDED**, because
> it makes `CR-B` and ablation available. **It is never REQUIRED**, because requiring it would make region count a
> target (`DEV-R24.1`) and reintroduce the hard-coded pole through the verification door.
> **⟹ The architecture has a *preference* for structure that is verifiable, expressed as a recommendation with a
> stated cost (Σ1 friction, `DEV-R27.3` irreversibility), not as a mandate.**

---

# §32 — ANATOMICAL NAMES AS LABELS

> ### **DEV-R32.1 — NAMING RULES.**
> (a) Anatomical names **may** be used as human-facing labels for scopes (`P0-05 R72.5`).
> (b) Anatomical names **MUST NOT** appear in: `RegionRecord` fields, authority predicates, fitness terms
> (`P0-01 §14`), invariant definitions, admissibility checks, or wire schemas.
> (c) A `region_id` is a **K-issued `bytes<16>`** (`Cell §3.1` pattern: *"Assigned by the EIK Identity Root at
> instantiation; never self-chosen"*), **not** a name.
> (d) Where a label is used, it MUST be accompanied by the FI set the labelled scope satisfies — **the label is a
> pointer to invariants, never a substitute for them.**
> **Ground:** `Cell §26` (metaphors demoted to non-normative commentary); Rule 5; §109.

> ### **DEV-R32.2 — THE V3 §9 MAPPING IS A HYPOTHESIS LIST, NOT A SPECIFICATION.**
> V3 §9's function assignments are reclassified as **candidate functional decompositions**: evidence that a given
> partition of function is *achievable*, not a requirement that it be *adopted*. §31's table records the anatomical
> column for exactly this reason — so the derivation is auditable — and `DEV-R31.1` requires that every row have
> independent contract support. **Rows of V3 §9 with no independent support were dropped.** Dropped, with reason:

| V3 §9 element | Function claimed | Dropped because |
|---|---|---|
| **Cortex → frontal** | *"executive control, planning, inhibition, working memory"* | "Executive control" as a *region* is a **central executive** — the giant developmental controller N8 excludes and §59 tests. "Planning" is not a requirement of any prior contract. Working memory **is** required, and is `P0-04`'s object, not a region's |
| **Cortex → parietal** | *"spatial representation, attention, integration"* | "Spatial representation" presupposes an embodied spatial task — **task-dependent** (`P0-01`), so it belongs to FI-12 (EXTERNAL), not to a fixed invariant. Attention is covered by FI-02 (routing/allocation) |
| **Cortex → occipital** | *"visual feature hierarchy"* | **Modality-specific.** A modality is a `P0-01` task property. Hard-coding a visual hierarchy would make the architecture vision-centric by fiat |
| **Cortex → insula-like** | *"internal-state and salience processing"* | Internal state is `Cell`'s `State` block and `P0-05 R59.1`'s Λ2 self-model; salience is FI-08. No separate invariant |
| **Basal ganglia** | *"action-value, policy selection, habits, gating"* | **Action-value and policy selection are reward/fitness objects** — `P0-01 §12`/`§14`, `[RO-13]`. Making them a region would place reward inside the developmental substrate, violating *"don't treat reward as truth"* and `P0-05 R24.2`. Gating is FI-02 |
| **Subthalamus-like** | *"action competition"* | Competition is `P0-05`'s exploration/selection object and `Cell §16`'s; not a region function |
| **Pons-like** | *"coordination / bridging"* | Coordination is FI-07 (aggregation) + `P0-03`'s routing; "bridging" has no contract support |
| **Midbrain-like** | *"arousal, reward, rapid modulation"* | **Reward is `[RO-13]`** (`P0-01 §12`, `§14`; `Cell §9`). A region that produced reward would be a hidden governance layer — prohibited by `P0-05 §87` discipline and by `Cell I-12` |

**⟹ Eight of V3 §9's elements are dropped, and every drop is because the function belongs to a prior contract's
`[RO-13]`/K-held object (reward, fitness, action-value, executive control) or is task-dependent (modality,
space).** This is the concrete content of `DEV-R13.2`: **the anatomy is not merely non-normative — a substantial
part of it is *inadmissible as a region*, because making it one would relocate governance objects into the
developmental substrate.**

---

# §33 — DEVELOPMENTAL SIGNAL INVENTORY

## 33.1 The complete set

`Cell §7`'s signal table contains exactly one developmental entry: *"**Developmental signal** | Differentiation
Engine (organism) | `dev.morphogen.v1` | small | ✅ | ✅ | n/a | **organism-signed** | priority 2 | ttl short |
❌ [retryable]"*. P0-06 must specify its content, and must not add message types silently (`A-11`: `MessageType` is
a closed 34-value wire enum).

> ### **DEV-R33.1 — ONE MESSAGE TYPE, FOUR CLASSES (NO NEW WIRE TYPES).**
> `dev.morphogen.v1` is the **single** developmental message type. Its payload carries one of the four
> `DEV-R18.1` classes: **POSITION**, **DEMAND**, **INHIBITION**, **NICHE**. **P0-06 adds no `MessageType` value**
> — doing so would be a wire-protocol change (`A-11`), i.e. a `[RO-13]` act, not a developmental one.
> **⟹ The four classes are a payload discriminator inside an existing type, which is the smallest sufficient
> mechanism (Rule 17).**

| Class | Producer | Consumer | Warrant | Retried? | Effect |
|---|---|---|---|---|---|
| **POSITION** | `ORGANIZER` cells generate; **O warrants** (`DEV-R17.1`) | cells via `morphogen_receptors` | ❌ unsigned at generation; ✅ organism-signed at warrant | ❌ (`ttl` short; a stale position is worse than none) | `fate_bias` term `w_m · morphogen_affinity` |
| **DEMAND** | homeostasis / any cell | differentiation engine | ❌ **SC-1/SC-2** | ❌ | **proposal only — no effect, no budget** (`DEV-R15.1`, `P0-05 R29.2`), rate-limited by `B7` |
| **INHIBITION** | committed neighbours | cells | ❌ | ❌ | `fate_bias` term `− Σ_n w_i · inhibit_strength(n)` — **the symmetry-breaker** (`Cell §15.2`) |
| **NICHE** | **K** (accounting) / `[RO-13]` (authorization) | engine, cells | ✅ **K-signed** | ✅ **retryable** — a lost niche advertisement starves development (§20.4) | admissibility (§11.1), `G11` |

> ### **DEV-R33.2 — ASYMMETRIC RETRY IS DELIBERATE.**
> `Cell §7` marks `dev.morphogen.v1` **non-retryable**. That is right for POSITION, DEMAND, and INHIBITION — all
> three are **transient field values** whose stale delivery is actively harmful (a stale gradient misplaces cells; a
> stale demand proposes a deficit that no longer exists; stale inhibition perpetuates a symmetry break that has
> already resolved). **It is wrong for NICHE**, which is a **standing authorization fact**, not a field value: a
> lost niche advertisement causes `T41` developmental failure for want of a niche — the D-D07 livelock's input.
> **⟹ NICHE-class payloads are retryable at-least-once with idempotent semantics (`P0-03`'s warrant class for
> consequential loss, `R7.2`: *"only classes whose loss is consequential may retry"*).** **Status: PROPOSED
> AMENDMENT to `Cell §7`** — recorded, not applied. The other three classes remain non-retryable.

> ### **DEV-R33.3 — PRIORITY 2 IS INHERITED AND MUST NOT BE RAISED.**
> `Cell §7` assigns `dev.morphogen.v1` **priority 2** (of a small scale, with `SAFETY_ALERT`-class messages above
> it). **Developmental signals MUST NOT outrank safety, error, or verification traffic.** `Cell I-28` requires
> global reporting of error classes {4,7,9,10} and severity ≥S2; `Cell` P8 makes alert emission never-blocked.
> **⟹ A developmental backlog MUST NOT delay an alert.** Raising developmental priority would be a developmental act
> acquiring governance precedence — EA-1 by another route.

---

# §34 — WARRANT, PLANE, AND THE SELF-MODEL CONSTRAINT

> ### **DEV-R34.1 — PLANE ASSIGNMENT.**
> All four classes are **INFLUENCE-plane** (`P0-03`). None is WARRANT-plane. **A developmental signal MUST NOT
> raise confidence, trust, warrant, or a verdict** (`DEV-R18.2`, `COMM-INV-08`).

> ### **DEV-R34.2 — THE DEVELOPMENTAL SELF-MODEL IS Λ2 AND NOT SELF-UPDATING.**
> `P0-05 R59.1`: *"THE SELF-MODEL IS AN Λ2 REPRESENTATION AND IS NOT SELF-UPDATING."*
> **⟹ The organism's model of its own development cannot be updated by the development it models.** A region's
> belief about its own competence, its own ablation delta, or its own necessity is an **Λ2 representation written by
> the engine/K from verification records**, never by the region from its own activity.
> **What this closes:** self-confirming development — a region that develops, then updates its self-model to record
> that the development was beneficial, then cites its own self-model as the competence evidence for the next
> developmental act. **Without `R59.1`, `DEV-R15.1` stage 3 (competence) would be satisfiable by self-report.**
> `Cell §12` already separates *"cell self-state"* (scope: this cell only) from the organism self-model (scope:
> *"All cells, circuits, regions, capabilities"*), and `Cell §30 P1-05` marks the boundary as K-written evaluative
> fields. **⟹ Inherited and reinforced, not newly invented.**

---

# §35 — THE Σ-BUDGET GAP

> ### **D-D14 — NO BUDGET CLASS EXISTS FOR SCOPE CONSTITUTION (finding; severity HIGH; status RESOLVED-BY-PROPOSAL).**
> `P0-05 §30` defines budget classes **B1–B7** (`B6 = STRUCTURAL_BUDGET[scope]`, *"count/norm of Λ3 operations, per
> scope, `[G]`"*; `B7 = PROPOSAL_QUOTA`). **B6 is indexed *per scope*** — so it presupposes the scope exists.
> **⟹ Σ-operations, which create scopes, have no budget class. An unbudgeted operation class is an unbounded one:
> unlimited Σ1 means unlimited region formation, which `DEV-R24.1`'s `[H]` ceiling would then be the only brake on —
> and `DEV-R4.2` says a bound limits a cycle without breaking it.**
> Note also `P0-05`'s non-fungibility: *"Unused B6 may not be converted to B5"* — so Σ cannot borrow B6.
> **Resolution — PROPOSED AMENDMENT to `P0-05 §30`:**
> > ### **DEV-R35.1 — B8: CONSTITUTIONAL BUDGET.**
> > `B8 = CONSTITUTIONAL_BUDGET` — count of Σ-operations **per envelope interval**, **organism-global** (NOT
> > per-scope, since scopes are what Σ creates), class **`[G]`**, **non-fungible** with B1–B7, and
> > **non-accumulable** (unused B8 does not carry over — carry-over would permit burst constitution).
> > **Σ2 (dissolution) MUST NOT consume B8.** Rationale: charging dissolution would make entrenchment cheaper than
> > correction — a region could not be dissolved during budget exhaustion, which is precisely when dissolution is
> > most needed. **⟹ Constitution is budgeted; dissolution is free.** This asymmetry is deliberate and mirrors
> > `DEV-R16.2`'s restriction/expansion asymmetry in the opposite direction, for the opposite reason: here the
> > *dangerous* act is the one that creates entrenched authority, so it is the one that is charged.

---

# §36 — STOCHASTICITY AND SYMMETRY BREAKING

## 36.1 The problem, exactly

`Cell §15.2` states it: *"**Lateral inhibition is the necessary condition for differentiation at all.** Without it,
a homogeneous field either stays homogeneous (no symmetry breaking) or collapses to a single role (whatever is
momentarily most rewarded — i.e., all cells become critics, or none do). **This is the mechanism V3 §10's role menu
presupposes and never supplies.**"*

So the inherited mechanism is **lateral inhibition** — `inhibition_r = Σ_{neighbours n committed to r} w_i ·
inhibit_strength(n)`. P0-06's task is to determine what inhibition can and cannot do.

## 36.2 Inhibition breaks symmetry only if something is already asymmetric

> ### **DEV-R36.1 — INHIBITION AMPLIFIES; IT DOES NOT ORIGINATE.**
> Lateral inhibition is a **negative feedback on already-committed neighbours**. In a *perfectly* homogeneous field
> with no committed cell, `inhibition_r = 0` for all `r` and all cells ⟹ `fate_bias` is identical everywhere ⟹
> `argmax` is identical everywhere ⟹ **no cell can commit first, because commitment requires a stable `argmax`
> (`Cell §15.2(i)`) and every cell's `argmax` is the same and equally unstable.**
> **⟹ Inhibition requires a seed asymmetry. There are exactly four admissible sources:**
>
> | Source | Asymmetry type | Admissible? | Ground |
> |---|---|---|---|
> | **Positional gradient** (organizer emission) | **external, spatial** | ✅ **PRIMARY** | `DEV-R8.1` (symmetry broken by external contact); `DEV-R19.3` (organizers are load-bearing) |
> | **Niche availability** (which roles are budgeted where) | **external, economic** | ✅ **PRIMARY** | `Cell G11`, `DEV-R20.1`; a niche is an asymmetry in *admissibility*, not in preference |
> | **Input channel** (which cells receive which environment inputs) | **external, task** | ✅ | `Cell §15.3` `INGRESS`/`EGRESS`; `P0-01` task structure |
> | **RNG seed** | **internal, arbitrary** | ⚠️ **TIE-BREAK ONLY** | `DEV-R8.1`: randomness may **choose**, never **qualify** |
>
> **⟹ A field with no gradient, no differentiated niche availability, and no differentiated input channels CANNOT
> differentiate, and the correct behaviour is that it DOES NOT.** Seeds must not be permitted to manufacture the
> asymmetry, because a seed-derived specialization has no external referent and therefore no service-level
> justification (`DEV-R1.1`) — it is *noise wearing a functional label*.

> ### **DEV-R36.2 — THE NO-DIFFERENTIATION OUTCOME IS ADMISSIBLE.**
> A population that remains `UNDIFFERENTIATED` because no external asymmetry exists is **conformant**, not failed.
> **`T41` must not fire for "no stable `fate_bias`" when the field is symmetric-by-construction** — that is not
> non-convergence, it is correct behaviour. **⟹ `T41`'s "no stable `fate_bias` within `N_dev_max` ticks" condition
> requires a qualifier: non-convergence is a FAILURE only when an external asymmetry was present and the cell did
> not respond to it.** **Status: PROPOSED AMENDMENT to `Cell` Annex B `T41`.** Without it, D-D07's churn livelock
> fires on *correctly* symmetric fields, killing cells for a property of the environment rather than of the cell.

## 36.3 The collapse mode inhibition is supposed to prevent, and the one it causes

`Cell §15.2` names collapse-to-one-role. Inhibition prevents it. But inhibition has its own pathology:

> ### **D-D15 — LATERAL INHIBITION PRODUCES ALTERNATION, NOT DIVERSITY (finding; severity HIGH; status BOUNDED).**
> Pure lateral inhibition on a symmetric lattice with one admissible asymmetry produces a **periodic alternating
> pattern** (the classic Turing/mechanical-inhibition result): cells alternate between the two most-excited roles in
> a fixed spatial period. **That is a pattern, but it is not a *functional* decomposition** — it satisfies no FI
> preferentially, it produces no cut with higher internal than boundary density (an alternating pattern has maximal
> boundary density), and it **fails `DEV-R21.2`** for every candidate region.
> **⟹ Symmetry breaking by inhibition alone produces structure that is stable, reproducible, and useless.** This is
> the concrete content of §109's *"don't call a mechanism 'emergent' without defining local rules"*: the local rules
> are defined, and what they produce is a checkerboard.
> **Bound:** inhibition MUST be coupled to (i) a **graded** positional field (not binary), so excitation varies
> continuously with position; (ii) **niche capacity** (`G11`), which caps how many cells may commit to `r` and
> therefore breaks the alternation by making one role scarce; (iii) the **diversity check** `P0-05 R25.4`, mandatory
> on every E4/E7 specialization, and `R46.4` (diversity as HARD CONSTRAINT); (iv) `Cell G-b`'s entropy guard
> (extended to `T41` by `DEV-R20.3(a)`).
> **⟹ Inhibition is necessary (`Cell §15.2`) and insufficient. The sufficient condition is inhibition coupled to a
> graded external field and a capacity constraint.** Recorded because the coupled system's output is *still* not
> guaranteed useful — `DEV-R1.2`, `OR-D4`.

## 36.4 Stochasticity budget

> ### **DEV-R36.3 — `T_dev` IS THE ONLY DEVELOPMENTAL TEMPERATURE AND IT IS MONOTONE DECREASING.**
> `Cell §15.2`: `T_dev` falls with `dev_stage` — `PLURIPOTENT` high (*"broad, exploratory"*), `PROVISIONAL` medium
> (*"biased, reversible"*), `COMMITTED` low (*"sharp, effectively fixed"*). **P0-06 inherits this and adds the
> governance constraint: `T_dev`'s schedule is `commitment_schedule`, a GENOME field (`Cell §3.2`), hence
> E9-only (`DEV-R10.1`, X-D5). ⟹ The organism cannot raise its own developmental temperature.** Raising `T_dev`
> would re-open commitment, which is a capacity increase (§16) and is prohibited outside `I-23`'s gate.
> **Lowering `T_dev` faster is also prohibited** (X-D5: manufacturing irreversibility). **⟹ `T_dev` is
> monotone-decreasing on a genome-fixed schedule, and neither direction is adaptively controllable.** This is the
> developmental analogue of `P0-05`'s fixed validation core (`OR-L10`), and §89 records it as a mandatory member of
> any developmental validation core.

---

# §37 — DEVELOPMENTAL CHECKPOINTS

## 37.1 The inherited timing objects

`Cell §3.2`: `critical_periods : [Window]` — *"when structural plasticity is permitted"*;
`commitment_schedule : CommitmentCurve` — *"PLURIPOTENT→PROVISIONAL→COMMITTED timing"*.
`Cell §15.2` commitment conditions: **(i)** `argmax fate_bias` stable for ≥ `N_stable` ticks; **(ii)** measured
success in role ≥ `θ_success`; **(iii)** `niche_slot` confirmed by organism; **(iv)** ORGANISM AUTHORITY writes
`dev_stage` — *"The cell cannot self-commit."*

> ### **DEV-R37.1 — A CHECKPOINT IS A CONJUNCTION, AND EVERY CONJUNCT IS SEPARATELY EVIDENCED.**
> ```
> COMMIT(c, r) ⟸ stable_argmax(c, r, N_stable)          [i]   evidence: fate_bias history, engine-held
               ∧ measured_success(c, r) ≥ θ_success      [ii]  evidence: probe record / CR-B  ⟵ COMPETENCE
               ∧ niche_confirmed(niche(c), r)            [iii] evidence: K accounting           ⟵ BUDGET
               ∧ authorized_by(O | K_abeyant)            [iv]  evidence: signature + log entry  ⟵ AUTHORITY
               ∧ potential_admissible(c, r, t)           [§11.1] evidence: reaction_norm ∩ variant ∩ independence ∩ guards
               ∧ ¬(T41-qualifying condition)             [§36.2] evidence: asymmetry-present check
     ```
> **All six are required.** `N_stable` and `θ_success` are **`[U]`/`[G]` parameters with no values invented** (§90);
> `Cell §30` records that **every numeric threshold is blocked on `P0-01`** (*"Without it, every threshold is
> arbitrary"*), and P0-06 does not unblock them.

## 37.2 Critical periods: what "window" means normatively

> ### **DEV-R37.2 — A CRITICAL PERIOD IS A PERMISSION WINDOW, NOT A PRESSURE.**
> `critical_periods` specify **when structural plasticity is permitted**. P0-06 constrains the semantics:
> (a) **Outside a window, structural change is inadmissible** — not merely costly. `Cell` B6 structural budget does
> not apply; the window is a **gate**, not a price.
> (b) **Inside a window, structural change is permitted but never compelled.** **A closing window MUST NOT force
> commitment.** A forced commitment at window close is a commitment without condition (ii) — competence unmeasured —
> which is `X-D12`'s hole reopened through the timing door.
> (c) **Window closure is a capacity RESTRICTION** (options removed) and is therefore in the permitted direction
> (P12, §18.4). **Window *re-opening* is a capacity increase and requires `I-23`-class gating.**
> **⟹ The failure mode this prevents: "commit or die at window close."** That design would make developmental timing
> a coercion mechanism, and would convert `T41` non-convergence into a scheduled mass-commitment event with no
> competence evidence — the single easiest way to build a population of confidently wrong specialists.

> ### **DEV-R37.3 — WINDOWS ARE GENOME-FIXED AND MAY NOT BE ADAPTIVELY SHIFTED.**
> Per X-D5 and `DEV-R36.3`: `critical_periods` and `commitment_schedule` are genome fields, E9-only. **A region may
> not extend its own window, and the engine may not extend a window for a region that is failing to converge.** The
> admissible responses to non-convergence are `T41` (retire — now guarded, `DEV-R20.3`), `DORMANT` (state 10, for
> rare-capability preservation), or **escalation to envelope governance** (`DEV-R20.3(d)`: niche starvation is a
> governance alarm). **Not window extension.**

## 37.3 The `dev_stage` machine does not exist

> ### **D-D16 — `DevStage` HAS NO STATE MACHINE (finding; severity CRITICAL; status RESOLVED — §88).**
> `Cell` Annex B P4 closes the **lifecycle** machine (18 states, 41 transitions) and forbids additions
> (`DEV-R0.2`). `DevStage` is a **separate 4-value enum** (`Cell §3.2`/`04_formal_schemas.md`:
> *"DevStage (4): 0 PLURIPOTENT · 1 PROVISIONAL · 2 COMMITTED · 3 TRANSDIFFERENTIATING"*).
> **But Annex B never specifies a machine for it.** `dev_stage` appears only (i) as a **guard** on lifecycle
> transitions (`T02`: *"`dev_stag[e]`…"*; `T03`: *"`dev_stage = PROVISIONAL` reached"*), and (ii) as `T31`'s source
> state. Consequences:
> - **`PLURIPOTENT → PROVISIONAL` has no transition ID, no authority, no evidence artifact, no rollback entry** —
>   violating Annex B's own **P1** (*"Every transition has exactly one authority class"*), **P2** (*"Every
>   transition requires the stated evidence artifact"*), **P3** (append-only lifecycle record with
>   `{from,to,transition_id,ts,epoch,authority,evidence_ref}`).
> - **`PROVISIONAL → COMMITTED` likewise** — and this is the most consequential transition in the entire
>   developmental architecture, since it triggers `I-23`'s irreversibility.
> - **`COMMITTED → PLURIPOTENT` / `PROVISIONAL`** (de-differentiation) has no representation at all except via
>   `TRANSDIFFERENTIATING`, so **role relaxation without role change is unrepresentable** — yet `P0-05 R46.1`
>   *requires* specialization reversal at same-or-lower rung (§16.1). **⟹ The inherited machine cannot express the
>   reversal that `R46.1` mandates.**
> - **P9's no-unbounded-dwell** is stated for lifecycle states, **not** for `dev_stage`. Nothing bounds time in
>   `PLURIPOTENT`.
> **Resolution: §88 specifies the `DevStage` machine in full** — 4 states, transitions with authority/evidence/
> rollback/dwell, and the **separation of specialization-reversal (a state operation, no `dev_stage` change) from
> role-change (a `dev_stage` transition)**. **Status: RESOLVED at §88.** This is the largest single gap P0-06
> closes, and it is why `DEV-R0.2`'s constraint (do not extend Annex B) matters: the fix is a **new machine**, not
> a patch to a closed one.

---

# §38 — DEVELOPMENTAL PRUNING VS HOMEOSTATIC PRUNING

## 38.1 Two different operations with one word

`V3 §4` lists *"Pruning: persistent failure, obsolescence, instability, excessive cost"* — four causes, no
authority, no distinction. `P0-05` formalizes pruning as **E3** (*"remove/prune connection"*, circuit blast radius,
**`IRREVERSIBLE_STRUCTURAL`**, `ORGANISM` authority, `CR-B` ablation **mandatory**, tombstone per `R27.2`,
`disuse_cause = IRRELEVANT` per `R27.3`). `Cell` `T26` retires **cells** for *"persistent failure
(`consecutive_failures ≥ θ_ret`) · obsolescence · instability · excessive cost · better candidate selected ·
enve[lope shrinkage]"*, and `T41` retires cells for **developmental non-convergence**.

> ### **DEV-R38.1 — THREE PRUNING OPERATIONS, THREE OWNERS.**
> | Operation | Object | Rung / transition | Authority | Evidence | Reversibility |
> |---|---|---|---|---|---|
> | **P-a: connection pruning** | a connection | **E3** (`P0-05`) | `ORGANISM` | `CR-B` ablation **mandatory** + tombstone + `disuse_cause` | `IRREVERSIBLE_STRUCTURAL` |
> | **P-b: cell retirement (operational)** | a cell | **T26** (`Cell`) | **EIK** | `θ_ret`, obsolescence, instability, cost, better candidate | terminal (`RETIRED`→`ARCHIVED`) |
> | **P-c: cell retirement (developmental)** | a cell that never developed | **T41** (`Cell`) | **ORG + EIK** | non-convergence or no niche | terminal |
> | **P-d: subcircuit dissolution** | an S3 scope | **E6** (`P0-05`) | `ORGANISM` | `CR-B` + cross-scope probe `C-2` | `IRREVERSIBLE` (dissolve) |
> | **P-e: region dissolution** | an S4 scope | **Σ2** (P0-06) | **K + `[RO-13]`** | re-homing plan, mandatory-path drain, niche release | `IRREVERSIBLE_STRUCTURAL` |
>
> **⟹ P0-06 owns P-c and P-e, and must not conflate them with P-a/P-b/P-d.** The distinction matters because
> **P-c has no competence content at all**: a cell retired under `T41` was never wrong, never failed a task, and
> never produced a bad belief. It failed to *find a place*. Treating P-c as P-b (operational failure) would write a
> failure record against a cell that committed no failure — **and `Cell §3.5`/`I-8` make lineage records
> permanent and externally anchored**, so the false failure would be inherited by descendants' reputation.

> ### **DEV-R38.2 — DEVELOPMENTAL RETIREMENT IS NOT A PERFORMANCE VERDICT.**
> A `T41` retirement MUST be recorded with `cause = DEVELOPMENTAL_UNPLACED`, distinct from `T26`'s performance
> causes. **It MUST NOT** contribute to: `consecutive_failures`, `degradation_trend`, `improvement_verified`,
> fitness (`P0-01 §14`), trust, or calibration history. **Ground:** §109 (*"don't confuse performance with
> legitimacy"*); `P0-04` (provenance must not be rewritten by later events, and must not record events that did not
> occur); `Cell I-21` (a cell cannot throttle/retire another — so a *region* cannot retire its own members for
> want of niche; that is `ORG + EIK`, as `T41` states).
> **⟹ This is the developmental instance of `P0-05`'s "no failure mode produces capacity increase" principle, run
> in reverse: no *non*-failure may produce a failure record.**

## 38.2 Pruning and the `mandatory_path` gap

> ### **X-D13 — `I-22` DOES NOT ENUMERATE DEVELOPMENTAL REORGANIZATION (RESOLVED — PROPOSED AMENDMENT).**
> **Statement.** `Cell I-22`: *"**`mandatory_path` connections are never removed or rerouted by plasticity or
> mutation.** Enforcement: operator validation rejects diffs touching mandatory paths."* `Cell` `G-f`: *"No
> transition may remove or reroute a `mandatory_path` connection (I-22)."*
> **`I-22` names plasticity and mutation. It does not name development.** Σ2 (region dissolution), Σ3 (re-homing),
> E6 (subcircuit dissolution), and P-c/P-e retirements all can remove or reroute connections, and none is
> "plasticity" or "mutation" in the inherited taxonomy (`P0-05` Λ1/Λ2 = plasticity; E9 = mutation).
> **⟹ A developmental reorganization could dissolve a `mandatory_path` without violating `I-22` as written.**
> **Resolution.** `G-f`'s broader phrasing (*"no **transition** may remove or reroute"*) does cover lifecycle
> transitions, and `DEV-R21.1.1` makes `mandatory_path_closure` a **Σ1 admissibility condition** — so a region may
> not be constituted with a mandatory path crossing its boundary, and `DEV-R22.2` requires the dissolution plan to
> specify mandatory-path disposition (`G-f`: *"T27 must drain them last and record their closure for the
> succes[sor]"*).
> **⟹ The gap is closed on the P0-06 side by construction. But `I-22` as written remains under-inclusive, and
> P0-06 records a PROPOSED AMENDMENT to the Cell Contract: `I-22` should read "…never removed or rerouted by
> plasticity, mutation, **or developmental reorganization (Σ-operations, E6, T41)**."** Status: **RESOLVED (P0-06
> side) + PROPOSED-AMENDMENT (Cell side)**. P0-06 does not apply the amendment.

---

# §39 — ANCHOR LAUNDERING BY SCOPE CYCLING

## 39.1 The inherited attack pattern

`P0-05` already identified the family:

> `P0-05` — **"F-4 as UDB evasion: Prune the connections carrying unverified displacement, resetting
> `‖θ − θ_anchor‖`…"**; `D-L21` — *"F-4 pruning has no tombstone, so the lineage of every change touching a pruned
> connection become[s untraceable]"*; `D-L22` — *"Forgetting can evade UDB by deleting the carrier of
> displacement."* `R27.4`/`R27.5` close it with tombstones and disuse-cause attribution.

**The developmental version is strictly worse**, because the object deleted is a *scope*, and `DEV-R11.4` (A3) says
a newly constituted scope starts with **`UDB := 0` and no anchor**.

> ### **D-D17 — ANCHOR LAUNDERING (finding; severity CRITICAL; status RESOLVED-STRUCTURAL).**
> **Attack.** A region `r` accumulates unverified structural distance: `‖θ_{S4}(r) − θ_anchor(S4)(r)‖` approaches
> `UDB_MAX[S4]`, at which point `P0-05 R0.1` declares **STALL** and freezes further unverified change. The region
> then:
> ```
> Σ2(dissolve r)   → members re-homed by Σ3 to a new scope shell, niches released
> Σ1(constitute r')→ same members, same contracts, same topology, NEW region_id, anchor = ⊥
> Σ4(devolve)      → UDB(r') := 0 by DEV-R11.4
> ```
> **⟹ The accumulated unverified distance is erased. `r'` is functionally identical to `r` and structurally
> identical, but carries no anchor debt.** Repeated, this is an **unbounded walk with bounded steps** — precisely
> `P0-05`'s `D-L1` (*"bounded steps, unbounded walk"*) and `RH-9` (*"move the wa[tchpoint]"*), lifted from
> parameters to scopes. **And it defeats `R0.1` entirely at regional altitude, which is where `R0.1` was already
> weakest (`R18.2`: `UDB_MAX[S5]` smallest; `OR-D4`).**
>
> **Resolution — three constraints, all structural:**
> > ### **DEV-R39.1 — SCOPE CYCLING IS IDENTITY-BREAKING AND DEBT-INHERITING.**
> > (a) **Debt inheritance.** If `Σ1(r')`'s membership satisfies `|M(r') ∩ M(r)| / |M(r)| ≥ θ_overlap`
> > (`[G]`, no value invented) **or** `contracts(r') ≈ contracts(r)`, then `r'` **inherits `r`'s anchor and its
> > accumulated unverified distance**. `UDB(r') := UDB(r)`, `anchor(r') := anchor(r)`. **⟹ A3's zero-credit default
> > applies only to a genuinely NEW scope, and "new" is defined by membership-and-contract disjointness, not by
> > `region_id`.**
> > (b) **Tombstone.** Every Σ2 produces a **Σ-tombstone** `{region_id, dissolved_at, dissolved_by, final_membership,
> > final_contracts, final_anchor, final_UDB, ablation_ref, re-homing destinations}`, **K-held, anchored, permanent**
> > — the exact analogue of `P0-05 R27.2`'s connection tombstone and `Cell T28`'s lineage archive. **A Σ1 whose
> > membership overlaps a tombstone within `θ_overlap` triggers (a) automatically.**
> > (c) **`region_id` is never reused** (`Cell §4.4`: *"A `cell_id` is [never reused]"* — same pattern), so the
> > cycling is always *visible* in the id sequence even when (a) does not fire.
> > **Status: RESOLVED-STRUCTURAL.** Residual: a region can launder by **gradual** membership replacement below
> > `θ_overlap` over many Σ3 operations — the Ship-of-Theseus route (D-D11). `DEV-R26.1`'s `lineage_continuity`
> > clause plus (b)'s permanent tombstone make this **auditable** but not **preventable**. Recorded as `OR-D8`.

> ### **DEV-R39.2 — WHY THIS IS THE DEVELOPMENTAL ANALOGUE OF `P0-05`'S CORE PRINCIPLE.**
> `P0-05`'s second canon principle: *"bound the distance from the last verified state"* (`R0.1` UDB). Its third:
> *"no failure mode produces capacity increase."* **Anchor laundering is the one mechanism by which development
> could produce a capacity increase FROM a governance action** (STALL) — i.e. the safety mechanism itself becomes
> the trigger for escaping the safety mechanism. **⟹ `DEV-R39.1` is not a refinement; it is the condition under
> which `P0-05 R0.1` remains meaningful at regional altitude at all.** Without it, `R0.1` governs parameters and is
> vacuous for structure.

---

# §40 — VOLUME B LEDGER

## 40.1 Rules minted in Vol B

`DEV-R21.1` (region = cut + failure unit + devolved authority) · `DEV-R21.2` (existence is a predicate) ·
`DEV-R22.1` (RegionRecord) · `DEV-R22.2` (mandatory dissolution condition) · `DEV-R22.3` (regions own no quantity) ·
`DEV-R23.1` (boundary enumeration) · `DEV-R23.2` (boundaries cost, never block) · `DEV-R24.1` (region count is `[H]`) ·
`DEV-R24.2` (depth `[H]`-bounded) · `DEV-R25.1`–`25.3` (functional identity; migration; locality advisory) ·
`DEV-R26.1` (identity is the triple, anti-laundering clause) · `DEV-R27.1`–`27.4` (enumerated devolution; never-held
set; irreversibility; abeyance expiry) · `DEV-R28.1` (Σ-authorization matrix) · `DEV-R28.2` (∅-set superset) ·
`DEV-R29.1` (no structural fact confers authority) · `DEV-R30.1` (Option C) · `DEV-R31.1`–`31.4` (invariants derived;
twelve; predicates over population; verifiability as recommendation) · `DEV-R32.1`–`32.2` (naming; V3 §9 mapping is a
hypothesis list) · `DEV-R33.1`–`33.3` (one message type, four classes; asymmetric retry; priority 2) ·
`DEV-R34.1`–`34.2` (INFLUENCE plane; Λ2 non-self-updating self-model) · `DEV-R35.1` (B8 constitutional budget) ·
`DEV-R36.1`–`36.3` (inhibition amplifies; no-differentiation is admissible; `T_dev` monotone) ·
`DEV-R37.1`–`37.3` (checkpoint conjunction; windows are permissions; windows genome-fixed) ·
`DEV-R38.1`–`38.2` (five pruning operations; developmental retirement is not a verdict) ·
`DEV-R39.1`–`39.2` (scope-cycling debt inheritance + Σ-tombstone).

## 40.2 Findings opened or advanced in Vol B

| ID | Finding | Severity | Status |
|---|---|---|---|
| **D-D08** | One-cell region cannot hold verification authority | MEDIUM | RESOLVED |
| **D-D09** | Comm delivery guarantee presupposes the scopes development constitutes; regions are cuts | MEDIUM | BOUNDED (P0-06 side) / **UNRESOLVED** (P0-03 side) |
| **D-D10** | Regional verification is hardware-gated via C4 = "region-core" | MEDIUM | ACCEPTED-LIMIT |
| **D-D11** | Total membership replacement with identity preservation | MEDIUM | BOUNDED |
| **D-D12** | Load-bearingness as coercion (entrenchment, veto without authority) | HIGH | BOUNDED |
| **D-D13** | Invariant satisfaction unverifiable for non-regional `M` | HIGH | **UNRESOLVED** |
| **D-D14** | No budget class for Σ-operations | HIGH | RESOLVED-BY-PROPOSAL (B8) |
| **D-D15** | Lateral inhibition produces alternation, not diversity | HIGH | BOUNDED |
| **D-D16** | **`DevStage` has no state machine; `PROVISIONAL→COMMITTED` has no authority/evidence/rollback; `R46.1`'s mandated reversal is unrepresentable** | **CRITICAL** | RESOLVED at §88 |
| **D-D17** | **Anchor laundering by scope cycling — defeats `P0-05 R0.1` at regional altitude** | **CRITICAL** | RESOLVED-STRUCTURAL |

## 40.3 Contradictions and amendments added in Vol B

**Contradictions:** `X-D13` (`I-22` under-inclusive re developmental reorganization — RESOLVED P0-06-side +
PROPOSED-AMENDMENT Cell-side).
**Proposed amendments to prior contracts (cumulative 8; none applied):** (1) `Cell` P11/§27 recovery language
[X-D4]; (2) `Cell` Annex B `T04`/`T05` non-waivability [X-D12]; (3) `Cell` Annex B §4.3 `G-a`/`G-b` extension to
`T41` [D-D07]; (4) `Cell §3.2` definition of `R` [D-D04]; (5) `Cell A-11` versioned `RoleCode` extension protocol
[§12.2]; (6) `Cell §7` NICHE-class retryability [DEV-R33.2]; (7) `Cell` Annex B `T41` asymmetry qualifier
[DEV-R36.2]; (8) `P0-05 §30` budget class **B8** [D-D14]; plus (9) `Cell I-22` enumeration [X-D13].

## 40.4 What Vol C inherits

| Vol B output | Vol C use |
|---|---|
| `DEV-R22.3` (regions own no quantity), `DEV-R20.2` (K-held niche accounting) | §41 resources and budget |
| `DEV-R26.1`, D-D11, `DEV-R38.1` P-c, `DEV-R38.2` | §42 lineage as a developmental object |
| `DEV-R37.1` (six-conjunct checkpoint), `OR-D4` | §43 specialization verification |
| `DEV-R34.2` (Λ2 non-self-updating self-model) | §44 trust and epistemic status of developmental claims |
| `DEV-R33.1`–`33.3`, `DEV-R18.1`/`18.2` | §45 developmental communication |
| `DEV-R21.1`, `DEV-R36.1`–`36.3` | §46 self-organization, formalized |
| `DEV-R14.3` (behavioral vs nominal), `DEV-R27.1`–`27.4`, N8 | §59 central vs decentralized |

---

**Next → Volume C (`49_analysis_resources_lineage_selforg.md`, §41–§60):** resources and developmental budget,
lineage as a developmental object, specialization verification in full, trust and epistemic status, developmental
communication, self-organization formalized, and the central-vs-decentralized question.
