# P0-06 — DIFFERENTIATION, DEVELOPMENT & SELF-ORGANIZATION
## Volume C — Resources, Lineage, Verification, Epistemic Status, Communication, Self-Organization, Central-vs-Decentralized (§41–§60)

**Status:** ANALYSIS · adversarial · architecture-only
**Depends on:** Vol A (§0–§20), Vol B (§21–§40)
**Feeds:** Vol D (`50_analysis_consistency_failure_bootstrap.md`, §61–§80)

---

# §41 — THE DEVELOPMENTAL RESOURCE PROBLEM

## 41.1 Development is paid for in three currencies

| Currency | Inherited object | Consumed by | Exhaustion behaviour |
|---|---|---|---|
| **Compute/memory** | `Cell §4.1.5` `budget`/`consumed`/`utilization`; states 1/2/14 run on **`dev only`** / **`dev budget`** | every developmental tick, gradient emission, `fate_bias` update, probe | `Cell §19.3` **throttle ladder** — *"a deterministic, ordered ladder — not an error, not a crash"* |
| **Slots** | `Cell G13` zero-sum; `G-e` blocks `T01` unless `T27` freed a slot | Σ1 membership, E4 recruitment, instantiation | population constant; **envelope change required** (human authorization) |
| **Silence** | `Cell` states 2/14: **"emits beliefs ❌"**; `DEV-R16.3` | every cell under nominal development | **organism output capacity falls by exactly the developing population** |

> ### **DEV-R41.1 — THE THIRD CURRENCY IS THE ONE THAT IS ALWAYS FORGOTTEN.**
> `DEV-R16.3`: a cell in `DEVELOPING` or `TRANSDIFFERENTIATING` emits no beliefs. **⟹ Development is not a
> background process. Its cost is subtracted from the organism's epistemic output in real time.** At bootstrap
> (§76) **every** cell is developing, so **output is zero** until the first commitments complete.
> **Consequence, stated as a design constraint:** any claim that a task can be served *during* bootstrap is false.
> `Cell §22`'s tier table is consistent with this — the smartphone tier is *"flat hierarchy"* with ~200 C2 cells,
> i.e. **small enough that bootstrap silence is short**. **⟹ Bootstrap duration is a first-order scalability
> parameter, and it is bounded below by the time needed to measure competence (`Cell §15.2(ii)` `θ_success`) on a
> probe budget that `DEVELOPING` does not have** (`DEV-R16.4`: states 1/2 have `dev` budget; only state 3
> `CALIBRATING` has `probe` budget).
> **⟹ Therefore the commitment chain must be ordered: `DEVELOPING` establishes `PROVISIONAL` (stability + niche,
> `Cell T03`) → `CALIBRATING` measures competence on probe budget → `PROBATIONARY` → `ACTIVE`, and only then can
> `PROVISIONAL → COMMITTED` fire with condition (ii) satisfied.** This ordering is **not** in `Cell` Annex B
> (D-D16) and is supplied at §88.

## 41.2 What development may not do with resources

> ### **DEV-R41.2 — RESOURCE ACTION IS RESTRICTIVE-ONLY AT CELL LEVEL.**
> Inherited: `Cell §18.4` — a cell may **self-throttle** and **self-suspend**; `Cell §18.5` `THROTTLE` and
> `RESTRICT` rungs; `Cell I-4` — *"A cell cannot exceed authorized resource limits"* (cgroup-enforced, off-process);
> `Cell I-21` — a cell cannot throttle another cell.
> **⟹ A cell may reduce its own developmental resource use unilaterally. It may not increase it, and it may not
> reduce another's.** A **region** likewise: `DEV-R27.2` denies regions throttle/quarantine/retirement authority over
> cells. **⟹ There is no developmental actor below K that can reallocate resources coercively.** Reallocation is
> Σ-class (`DEV-R20.2`) or envelope-class (`G13`).

> ### **DEV-R41.3 — DEVELOPMENTAL RESOURCE USE MUST NOT BE A FITNESS INPUT.**
> `P0-03` discipline: *"don't let comm-derived performance redefine fitness."* Applied here: a region's resource
> consumption, its growth rate, its developmental activity level, and its size are **not** fitness terms
> (`P0-01 §14`'s 13-component vector is `[RO-13]`). **Ground:** §109 (*"don't use resource dominance as implicit
> governance"*); D-D06. **⟹ A large, busy, fast-developing region is not thereby a successful one. The only success
> measure is `DEV-R1.1`'s service-level deficit reduction via ablation delta.**

---

# §42 — BUDGET CLASSES

## 42.1 The inherited set, and development's place in it

`P0-05 §30`: **B1–B7**, non-fungible (*"Unused B2 at S1 may not be spent at S3. Unused B6 may not be converted to
B5. A budget that can be traded is a [loophole]"*). Development-relevant: **B6** `STRUCTURAL_BUDGET[scope]`
(*"count/norm of Λ3 operations, per scope, `[G]`"*), **B7** `PROPOSAL_QUOTA` (E9/nomination rate, per scope, `[G]`),
plus `Cell §7`'s per-state budgets (`dev only`, `probe budget`, `repair budget`, `full`, `reduced`, `draining`,
`near-zero`, `minimal`).

> ### **DEV-R42.1 — BUDGET MAP FOR DEVELOPMENTAL OPERATIONS.**
> | Operation | Budget class | Indexed by | Non-fungible with |
> |---|---|---|---|
> | Σ1/Σ2/Σ3/Σ4 | **B8** (new — D-D14, `DEV-R35.1`) | **organism-global**, per envelope interval | B1–B7 |
> | E4 recruit / E5 release / E6 subcircuit / E7 regional topology | **B6** | **per scope** (must exist — `DEV-R5.2`) | B8, B5, B2 |
> | `fate_bias` update, gradient emission, sampling | **`dev` state budget** (`Cell` states 1/2/14) | per cell | probe, repair, full |
> | Competence probe for commitment (ii) | **`probe` budget** (state 3) | per cell | dev |
> | DEMAND proposals | **B7** `PROPOSAL_QUOTA` | per scope | B6, B8 |
>
> **⟹ Two consequences.** (a) **Σ is charged globally and E is charged per-scope**, so a region cannot fund its own
> constitution — the constitution budget is not in its possession (D-D06, `DEV-R22.3`). (b) **A demand proposal is
> charged to B7, the same quota as E9 genome proposals** (`P0-05 B7`: *"E9 / nomination rate"*). **⟹ Developmental
> lobbying competes with evolutionary lobbying for the same quota.** That is a **feature**: it makes the total rate
> at which the population can petition for structural change bounded by one number, so an attacker cannot open a
> second, unbudgeted petition channel. Recorded because it also means **a demand flood suppresses genome
> proposals** — attack class at §86.

> ### **DEV-R42.2 — Σ2 IS FREE (REPEATED, WITH REASON).**
> `DEV-R35.1`: dissolution consumes no B8. **Dissolution is the only brake on entrenchment (`D-D12`, `OR-D3`) and
> the only retraction path for devolved authority (`DEV-R27.3`).** Charging it would make correction unavailable
> exactly when the budget is exhausted — and budget exhaustion correlates with structural churn, which correlates
> with entrenchment risk. **⟹ The asymmetry is: creation is charged, destruction is free.** Opposite in direction to
> `DEV-R16.2` (restriction cheap, expansion expensive), same in principle: **the cheap direction is always the one
> that reduces unaccountable structural power.**

---

# §43 — ZERO-SUM AND THE ENVELOPE

> ### **DEV-R43.1 — THE ENVELOPE IS THE ONLY SOURCE OF INCREASE.**
> `Cell G13`: *"**ZERO-SUM DEFAULT:** a slot must be **freed** (retirement, pruning, death) before one is taken.
> Population growth r[equires envelope change]"*; `Cell §16` commentary: *"Population is constant unless the
> **envelope** is changed by **human authorization**"*; `Cell §16`: *"**Superlinear resource cost** — the marginal
> cost of the Nth cell rises with N (homeostatic headroom requirement in G13), so growth is self-limiting."*
> **⟹ Three inherited brakes on growth: zero-sum replacement, human-authorized envelope, superlinear marginal cost.**
> P0-06 adds none and removes none.

> ### **DEV-R43.2 — DEVELOPMENT IS A PARTITION PROBLEM, NOT A GROWTH PROBLEM.**
> Given a constant population `N` and a fixed niche budget, development is: **assign `N` cells to a set of niches
> and a partition of scopes, such that the FI set (§31) is satisfied and declared service-level deficits are
> reduced.** Formally:
> ```
>   maximize   Σ_i  deficit_reduction(FI_i | assignment)                 [DEV-R1.1]
>   subject to Σ_c occupancy(c) = N                                       [G13 zero-sum]
>              occupancy(niche) ≤ capacity(niche)            ∀ niche      [Cell G11]
>              role(c) ∈ reaction_norm(c) ∧ variant(c) ≥ min_variant      [Cell §3.2, §15.3]
>              independence(CRITIC/VERIFIER pairs)                        [Cell §15.4, I-10]
>              mandatory_path_closure(M)                     ∀ region     [Cell I-22, DEV-R21.1.1]
>              entropy ≥ θ_entropy                                        [Cell G-b, R10.12]
>              regions ≤ ceiling(tier) ∧ depth ≤ ceiling(tier)            [[H], DEV-R24.1/24.2]
>              Σ-ops ≤ B8 ∧ E-ops ≤ B6[scope]                             [DEV-R42.1]
> ```
> **This is the whole of development, and it is a constrained re-assignment problem — not an optimization over
> architecture.** P0-06 states it this way deliberately: **the "emergent structure" question (§57) is a question
> about which feasible point of this program the population reaches, given local rules and no global optimizer.**
> **⟹ Note what is absent: no term rewards region count, hierarchy depth, specialization sharpness, or
> anatomical resemblance. `DEV-R1.1` and `DEV-R41.3` exclude them, and their absence is what keeps §109's
> performance/legitimacy confusion out of the objective.**

> ### **D-D18 — THE PARTITION PROBLEM HAS NO SOLVER, AND MUST NOT (finding; severity HIGH; status ACCEPTED-LIMIT).**
> `DEV-R43.2` is written as a constrained program. **Nothing in V4 solves it, and nothing may.** A solver would be
> (i) a global optimizer over the whole population — `P0-05 §87` prohibits *"an O(N²) global learner merely to solve
> credit assignment"*, and §109 prohibits a giant developmental controller (N8); (ii) a holder of the objective —
> but the objective is `P0-01 §14`'s `[RO-13]` fitness vector, which no adaptive mechanism may write
> (`P0-05 R24.2`); (iii) a source of authority — `DEV-R29.1`.
> **⟹ The program is a SPECIFICATION OF ADMISSIBILITY, not a control law.** Developmental mechanisms (§57's local
> rules) produce *some* feasible point; which one is path-dependent and not optimal. **P0-06 makes no optimality
> claim (`DEV-R1.2`) and records path-dependence as `OR-D9` rather than resolving it with a constant** (§109: *"don't
> solve path-dependence with constants"*).

---

# §44 — LINEAGE AS A DEVELOPMENTAL OBJECT

## 44.1 What lineage is, inherited

`Cell §3.1`: `lineage_id`, `generation` — identity fields, EIK-written, immutable (`I-1`). `Cell §4.4`: *"the lineage
record persists forever in the EIK Lineage Store, externally anchored"*; `T28`: *"Archive hash anchored externally"*;
`T29`: deletion requires retention elapsed + audit + **OP authorization for C3+ and governance roles**.
`Cell §16 G10`: **lineage-distance gate** `d_min`; `inbreeding_F ≤ F_max`. `Cell §15.4`: independence requires
**lineage distance ≥ `d_min`** — *"Siblings are not independent."* `Cell §27`: recovery may *"replace from lineage
backup."*

## 44.2 Lineage's three developmental uses — and they conflict

| Use | Requires | Source |
|---|---|---|
| **U-L1: independence** | lineage **distance** between verifier and asserter ≥ `d_min` | `Cell §15.4`, `G10`, `I-10`, FI-05 |
| **U-L2: region identity** | lineage **continuity** across membership replacement | `DEV-R26.1`, D-D11, `Cell §22.3` |
| **U-L3: niche allocation** | lineage **blindness** | `DEV-R6.1(b)` |

> ### **DEV-R44.1 — THE THREE USES ARE COMPATIBLE BECAUSE THEY GOVERN DIFFERENT OBJECTS.**
> - **U-L1** constrains **who may evaluate whom** — a relation between two *cells*.
> - **U-L2** constrains **how a region's membership may be replaced** — a relation between two *membership sets*
>   across time.
> - **U-L3** constrains **who may occupy a niche** — a relation between a *cell* and a *budget slot*.
> **⟹ No conflict.** The apparent conflict ("continuity requires lineage; blindness forbids it") dissolves once the
> objects are separated: **lineage continuity is about the *succession of members* of a region; lineage blindness is
> about the *eligibility of a candidate* for a slot.** A region may replace members from its lineage backup
> (continuity) while every individual slot allocation ignores descent (blindness). Recorded explicitly because
> conflating them is the easiest way to break either D-D11's recovery path or X-D3's Baldwinian wall.

> ### **DEV-R44.2 — LINEAGE MUST NOT BE A DEVELOPMENTAL PREFERENCE.**
> Beyond U-L3, lineage **MUST NOT** appear in: `fate_bias` excitation terms (`Cell §15.2`'s five terms are
> `w_g` genetic, `w_m` positional, `w_d` demand, `w_s` success history, `w_n` niche availability — **no lineage
> term**), admissibility (§11.1), Σ1 membership selection, or authority predicates (`DEV-R29.1`).
> **Note `w_g` is genetic, not genealogical:** `reaction_norm` is a genome field, and genomes are constructed by the
> Replication Authority under `Cell §3.5`'s rejection list. **⟹ A cell's reachable-role set is a property of its
> genome, and using it is not nepotism; using its `lineage_id` directly would be.** The distinction is thin and is
> the reason `DEV-R6.1(b)` exists: X-D3's pseudo-heredity channel works precisely by making `w_g` correlate with
> descent through niche persistence.

## 44.3 Genealogy of structure

> ### **DEV-R44.3 — EVERY STRUCTURAL OBJECT HAS A PROVENANCE CHAIN, AND IT IS IMMUTABLE.**
> `P0-04` establishes `evidence_roots`, `derivation_depth`, `self_ref`, Anchor resolution (`Cell I-3`: *"A cell
> cannot manufacture provenance — every `evidence_root` must resolve in the Anchor"*), and the prohibition on
> rewriting historical evidence. Applied to development:
> ```
> StructuralProvenance(Σ-op | E4..E7) ::= {
>   op_id, epoch, ts, authority, evidence_ref                 [Annex B P3 log shape]
>   proposals        : set<DEMAND proposal ids>               [stage 1, DEV-R15.1]
>   admissibility    : Potential evaluation record            [stage 2, §11.1]
>   competence       : probe / CR-B / sandbox record refs     [stage 3]
>   authorization    : signature(s)                           [stage 4]
>   niche_auth       : K accounting ref                       [DEV-R20.2]
>   predecessor      : ⟨Σ-tombstone ref | ⊥⟩                  [DEV-R39.1(b)]
>   anchor_state     : ⟨digest | ⊥⟩                           [DEV-R11.4]
> }
> ```
> **K-held, anchored, append-only, permanent.**

> ### **DEV-R44.4 — DEVELOPMENTAL SUCCESS MUST NOT REWRITE PROVENANCE.**
> §109: *"don't let dev success rewrite provenance."* Concretely prohibited:
> (a) A region that later performs well **may not** retro-annotate its constitution record with post-hoc
> justification. The record states the evidence available **at the time** (stage 3's probe result as it was).
> (b) A specialization whose declared reversal condition (`P0-05 R46.1`) never fired **may not** have that condition
> deleted or weakened on the grounds that reversal proved unnecessary. **The declared condition is part of the
> authorization; erasing it erases the terms under which authority was granted.**
> (c) A `T41` developmental retirement **may not** be reclassified as an operational failure (`DEV-R38.2`), nor the
> converse.
> (d) **An anchor may not be re-based on a later, better state** — that is `P0-05`'s `RH-9` (*"move the
> watchpoint"*) at scope level, and `DEV-R39.1` closes the cycling route to it.
> **Ground:** `P0-04` (organism may not rewrite historical evidence); `Cell I-3`; `Cell §3.5`.

---

# §45 — INDEPENDENCE, AND WHY DEVELOPMENT IS THE ONLY WAY TO GET IT

> ### **DEV-R45.1 — INDEPENDENCE IS A DEVELOPMENTAL ACHIEVEMENT, NOT A GENOMIC ONE.**
> `Cell §15.4`'s six requirements: **lineage distance ≥ `d_min`** · **distinct EIK-issued RNG seeds** · **distinct
> data ordering** · **distinct genome (`genome_hash` distance ≥ θ_g)** · **disjoint `evidence_roots`** ·
> **measured error correlation ρ ≤ θ_ρ**. `Cell I-10`: *"A cell cannot establish independence merely by having a
> different `cell_id`."*
> Three of the six are **developmental**:
> - **lineage distance** — a property of the *population arrangement*, produced by replication history and Σ3
>   re-homing;
> - **distinct data ordering** — *"enforced by the evaluation harness, not by the cell"* ⟹ an **allocation**
>   decision (`P0-04 MEM-INV-50` pattern), i.e. a Σ/E4-class placement act;
> - **disjoint `evidence_roots`** — *"where possible"* ⟹ requires that verifiers and asserters be **specialized on
>   different targets**, which is `DEV-R14.1`'s restriction.
> **⟹ Independence cannot be instantiated at `t=0`.** At `t=0` there is one cell (§7). **A population of
> undifferentiated generalists reading the same inputs has `evidence_roots` in common, high ρ, and no lineage
> distance. It has no independent verification, and cannot acquire any except by DEVELOPING.**
> **This is the affirmative architectural case for P0-06's existence:** `V3 §3` requires *"independent strategies +
> redundant critics"* against correlated failure, and `Cell §15.4` supplies the criteria — but **the only mechanism
> that can satisfy those criteria is differentiation.** Without development, `V3 §3`'s correlated-failure defence is
> a declaration with no implementation path.

> ### **D-D19 — THE BOOTSTRAP PARADOX OF INDEPENDENCE (finding; severity HIGH; status RESOLVED-STRUCTURAL).**
> **Statement.** Independent verification requires ≥2 sufficiently distant cells (FI-05, `Cell I-2` — a cell cannot
> verify itself; `Cell §15.3` — *"verification is a role performed in circuits with independence requirements —
> §15.4; a cell cannot verify itself"*). But commitment requires measured competence (`Cell §15.2(ii)`), and
> competence measurement at regional altitude requires `CR-B`, and `CR-B` requires... verification. **⟹ The first
> verifier cannot be verified.**
> **Resolution — the verification of the first verifier is EXTERNAL, and that is the only admissible answer:**
> | Stage | Who verifies | Ground |
> |---|---|---|
> | **t=0, one cell** | **K + external evaluator** (`P0-01`'s held-out task suite, `[RO-13]`) | `Cell §30`: *"P0-01 — define target tasks, environments, and fitness"* is the **first** upstream dependency; `Cell §9.6` held-out probe |
> | **first circuit (S3)** | **K, via `CR-B` at S3** — `P0-05` E1/E2 require *"probe at S3"*, E3 requires *"CR-B ablation MANDATORY"* | `P0-05 §29.1` |
> | **first region (S4)** | **K + cross-scope probe C-2**, but **C-2 is unavailable at S5** (`P0-05` rung-cost inversion) | `OR-D4` |
> | **subsequent verifiers** | **already-constituted independent verifiers** (`Cell §15.4` ρ measurement) | FI-05 |
> **⟹ Verification bootstraps from EXTERNAL to INTERNAL, and the external anchor is never removed.** `P0-01`'s
> protected external ground truth (`V3 §3`: *"Synthetic-data drift → provenance graph + **protected external ground
> truth**"*) is what makes the first step non-circular. **Status: RESOLVED-STRUCTURAL.** Residual: the external
> evaluator is not causally independent of the organism it evaluates — `P0-05`'s **RH-2 (evaluator manipulation)
> remains UNCLOSED**, and P0-06 inherits that exposure at its most acute point, because the bootstrap depends on it.
> **Recorded, not solved** (§96, §104).

---

# §46 — THE GENEALOGY OF STRUCTURE AND THE TWO STORES

`P0-04` distinguishes stores by writability and permanence; `Cell §3.4` distinguishes genome / learned state /
developed phenotype / K-written fields. Development's objects must be assigned:

| Developmental object | Store | Writable by | Heritable | Checkpointable | Off-cell |
|---|---|---|---|---|---|
| `reaction_norm`, `critical_periods`, `commitment_schedule`, `morphogen_receptors` | **Genome Store** | Replication Authority only (`Cell I-5`, `I-8`) | ✅ | ✅ | ✅ |
| `fate_bias`, `dev_stage` | **Cell `DevelopmentalState`** | **O, C↑ within `reaction_norm`** | ❌ | ✅ | ❌ |
| `role`, `niche_slot`, `region_id` | **Cell identity/state block** | **Organism** (`Cell §3.1`); `role` change post-commitment: **EIK+ORG** (`I-23`) | ❌ (`Cell §3.5`) | ✅ | ❌ |
| `morphogen_readings` | **Cell state, `transient`** | **C reads, O writes** | ❌ | ❌ **transient** | ❌ |
| `architecture_realized`, θ | **Cell `Phenotype` block** | Cell within kernel bounds | ❌ | ✅ | ❌ (`Cell §3.4`) |
| **`RegionRecord`, Σ-tombstones, `StructuralProvenance`, abeyance records, niche accounting, anchors** | **K-held structural store (NEW)** | **K** | ❌ | ✅ **must be** | ✅ **must be** |

> ### **DEV-R46.1 — THE K-HELD STRUCTURAL STORE IS REQUIRED, AND ITS ABSENCE IS THE P0-28 GAP.**
> `Cell §3.4` marks the developed phenotype checkpointable but **NOT off-cell**. That is correct for a *cell's*
> phenotype. **But a `RegionRecord` is not a cell's phenotype — it is a population-level object with no cell owner.**
> `Cell §30 P0-28` marks region formation **"Partial"** and lists only cell-side inputs (`morphogen_receptors`,
> `region_id`, locality hints, connection handshake). **⟹ No inherited store holds region-level realized
> structure.** Without one: `DEV-R21.2`'s predicate cannot be evaluated by anyone; `DEV-R26.1`'s identity clause
> cannot be checked; `DEV-R39.1(b)`'s tombstones have no home; `DEV-R20.2`'s K-held niche accounting has no ledger;
> and Σ2 re-homing has no record of what was dissolved.
> **⟹ P0-06 requires a K-held, off-substrate, anchored, append-only STRUCTURAL STORE.** This is **not** a new cell
> field (DEV-R0.1) and **not** a new lifecycle state (DEV-R0.2); it is a **kernel-side store**, which `P0-02` is the
> contract for. **Status: PROPOSED AMENDMENT to `P0-02`** (a sixth kernel store alongside Identity Root, Genome
> Store, Lineage Store, Anchor, constraint_set). P0-06 specifies its **contents and access rules**; `P0-02` owns its
> enforcement.
> **Why K and not the organism:** the organism is the substrate. A structural store held on the substrate could be
> rewritten by the entity whose structure it records — which is `DEV-R44.4`'s prohibition and `P0-04`'s
> no-rewriting-historical-evidence rule, and it would make `DEV-R21.2` self-evaluated. **`Cell` Rule 19 applied
> rigorously: *"any invariant whose violation would be catastrophic is enforced at EIK level, never at cell level. A
> cell-level check is a courtesy; an EIK-level check is a [guarantee]"*.**

---

# §47 — SPECIALIZATION VERIFICATION: THE INSTRUMENTS

## 47.1 Inventory

| Instrument | Inherited from | Measures | Available at | Cost |
|---|---|---|---|---|
| **Held-out probe** | `Cell §9.6`; `P0-05` E0 | θ's effect on prediction | S1, per cell | low |
| **`CR-B` ablation** | `P0-05` E2/E3/E4/E6/E7 | effect of removing the object | S3+ | **high** — requires running dependents with and without |
| **Cross-scope probe `C-2`** | `P0-05` E6 | effect across a scope boundary | S3, S4 — **NOT S5** | high |
| **Ablation delta (`Cell G3`)** | `Cell §16 G3` | *"performance of dependents with vs. without this cell"* | circuit/region | **high** |
| **Diversity check** | `P0-05 R25.4`, mandatory on E4/E7 and on any `param_init` selection | behavioural/genomic diversity preserved | S4+ | moderate |
| **Entropy guard** | `Cell G-b`, `Cell R10.12` | population behavioural entropy | organism | low |
| **Independence attestation** | `Cell I-10`, §15.4's six + measured ρ | non-correlation of a verifier/asserter pair | K | moderate, ongoing |
| **`DEV-R21.2` predicate** | P0-06 | region existence | K | low (structural check) |
| **Sandbox validation** | `Cell T32`, `Cell §16` | candidate viability **off-line** | K/ORG | moderate — **and is NOT observation** (X-D12) |

## 47.2 The instrument-to-operation assignment

> ### **DEV-R47.1 — MINIMUM VERIFICATION PER DEVELOPMENTAL OPERATION.**
> | Operation | Minimum instrument | Why not less |
> |---|---|---|
> | **Behavioural restriction** (`DEV-R14.3` tier 1) | **none** | Confers nothing; reversible; unregistered. Requiring verification would make self-restriction costly, and `Cell §18.4`'s rationale is **latency** (*"stop talking immediately, without waiting for an authority round-trip"*) |
> | **`fate_bias` update** | none (bounded by `reaction_norm`) | Cell-computed within a genome constraint; no structural effect |
> | **E4 recruit** | **`CR-B` + diversity check** | `P0-05 §29.1` mandates it |
> | **Σ1 constitute S3** | `DEV-R21.2` predicate + `mandatory_path_closure` + declared `dissolution_cond` | A circuit is small; full `CR-B` on an empty contract is meaningless — there is no `F` yet |
> | **Σ1 constitute S4** | predicate + **measurable `ablation_delta(F, M)`** + `|M| ≥ 2` if verification authority devolved | `DEV-R21.1.2` requires `F` be measurable; D-D08 |
> | **Σ4 devolve** | **enumerated rung set + anchor status + full Σ1 evidence chain** | Irreversible (`DEV-R27.3`); this is the last checkpoint before authority exists |
> | **Σ2 dissolve** | re-homing plan executed + mandatory-path drain record + niche release + **Σ-tombstone** | `Cell G-f`; `DEV-R39.1(b)` |
> | **Σ3 re-home** | `region_id` write evidence + boundary re-enumeration + **overlap check vs Σ-tombstones** | `DEV-R39.1(a)` — this is where gradual laundering would occur |
> | **`PROVISIONAL→COMMITTED`** | **all six conjuncts of `DEV-R37.1`** | Triggers `I-23` irreversibility |
> | **`T31` transdifferentiation** | crisis evidence + `reaction_norm` inclusion + **no alternative source** + sandbox | `Cell T31`/`T32`; then `DEV-R15.2`'s non-waivable `T04`/`T05` |

> ### **DEV-R47.2 — VERIFICATION IS CHEAPEST WHERE THE ACT IS CHEAPEST.**
> `P0-05`'s fifth canon principle: *"the cheapest signal needs no attribution, the dearest verifies."* Development
> inherits it exactly: behavioural restriction (free, unregistered) needs no verification; Σ4 devolution
> (irreversible, creates authority) needs the whole evidence chain. **⟹ The verification cost curve is monotone in
> the irreversibility × blast-radius product** — which is `P0-05 R0.3`'s own scaling law (*"authority scales with
> irreversibility × blast radius, not magnitude"*). **P0-06 adds no new principle here; it applies the inherited one
> to Σ-operations, which `P0-05` could not because Σ did not exist.**

---

# §48 — ABLATION DESIGN FOR STRUCTURAL CLAIMS

> ### **DEV-R48.1 — ABLATION IS COUNTERFACTUAL AND THEREFORE REQUIRES REDUNDANCY.**
> `Cell G3`'s ablation delta measures *"performance of dependents with vs. without this cell"*. **To measure
> "without", the organism must be able to run without it.** For a cell that is the **sole satisfier** of a contract,
> running without it means the contract fails — so the delta is maximal and **uninformative about quality**: it
> measures indispensability, not competence.
> **⟹ Ablation is informative only where redundancy exists.** This produces a hard tension with D-D12: **the more
> indispensable a component, the less its ablation tells you, and the more coercion leverage it has.** Both effects
> come from the same property.
> **Ruling:** (a) ablation delta is a **usefulness** measure under `DEV-R1.1` and is **only valid where a redundant
> alternative exists or can be provisioned in sandbox**; (b) where no redundancy exists, the honest report is
> **`ablation_delta = UNSUPPORTED`**, not "large"; (c) **`UNSUPPORTED` is a governance alarm** (single point of
> failure — `V3 §21`: *"Single-point failure → redundancy + decentralization + graceful degradation"*), **not a
> distinction**.

> ### **DEV-R48.2 — ABLATION OF A REGION IS A Σ-CLASS EXPERIMENT.**
> Removing a region to measure its delta is operationally **Σ2** (dissolve) — irreversible, `IRREVERSIBLE_STRUCTURAL`,
> requiring a re-homing plan. **⟹ Genuine regional ablation is nearly as expensive as regional dissolution.**
> The admissible substitute is **sandbox ablation**: run the dependents in a sandbox with the region's contributions
> suppressed. **But `X-D12`'s discipline applies: sandbox results are admissibility evidence, never production
> competence evidence.** **⟹ Regional usefulness claims rest on sandbox ablation, and P0-06 states this plainly:
> regional developmental verification is SANDBOX-GRADE.** This is the operational content of `OR-D4` and it is the
> reason §108 cannot report DIFFERENTIATION or REGION-FORMATION as CLOSED-VERIFIED.

> ### **DEV-R48.3 — ABLATION MAY NOT BE USED AS A SELECTION SIGNAL BY THE ABLATED.**
> `Cell G3`'s delta feeds `Cell §16`'s replication gates. A cell/region whose ablation delta is measured **must not
> be the party that schedules, scopes, or interprets the measurement.** Ground: `Cell I-2` (no self-verification),
> `Cell §15.3` `REPAIR` *"may not repair itself"*, `P0-05 R59.1` (self-model not self-updating), `DEV-R34.2`.
> **⟹ Ablation is K-scheduled and K-interpreted.** A region that could choose *when* to be ablated could choose a
> favourable moment — the developmental analogue of `P0-05 LEARN-E2` (*"probe gaming by input selection"*), closed
> there by **C-1** (probe input distribution is `[RO-13]`). **P0-06 applies the same reserved-choice principle
> (`DEV-R3.3`) to ablation scheduling: the ablation schedule contains governance-reserved slots.**

---

# §49 — WHAT CANNOT BE VERIFIED

> ### **DEV-R49.1 — THE UNVERIFIABLE SET, STATED EXPLICITLY.**
> | Claim | Status | Reason |
> |---|---|---|
> | "This specialization is the best available" | **UNVERIFIABLE** | Requires comparing un-taken counterfactuals over an unbounded instance space (§12.4) |
> | "This region partition is correct" | **UNVERIFIABLE** | `OR-L3`: no probe design for Λ3; no external referent for a partition |
> | "Development will converge to a useful structure" | **PROHIBITED CLAIM** | `DEV-R1.2` |
> | "The population is sufficiently diverse" | ⚠️ **PARTIALLY VERIFIABLE** | Entropy (`Cell R10.12`) and `P0-05 R25.4` measure *spread*, not *coverage of the useful* |
> | "This region satisfies FI-*nn*" | ⚠️ **VERIFIABLE ONLY IF REGIONAL** | D-D13: non-regional satisfiers have no instrument |
> | "Developmental provenance is complete" | ✅ **VERIFIABLE** | `DEV-R44.3`'s record is K-held, anchored, append-only |
> | "No developmental actor holds un-devolved authority" | ✅ **VERIFIABLE** | `DEV-R27.1`'s enumeration is checkable against the Σ-log |
> | "Anchor debt has not been laundered" | ⚠️ **AUDITABLE, NOT PREVENTABLE** | `DEV-R39.1` + `OR-D8` (gradual replacement route) |
>
> **⟹ The verifiable set is entirely about PROCESS (was the act authorized, evidenced, logged, bounded?), and the
> unverifiable set is entirely about QUALITY (was it the right act?).** This is not a deficiency of P0-06's design;
> it is the inherited shape of the architecture (`OR-L3`, `OR-D4`, `P0-05`'s rung-cost inversion), and P0-06 reports
> it rather than claiming more.

> ### **DEV-R49.2 — PROCESS VERIFICATION IS THE CONTRACT; QUALITY VERIFICATION IS THE RESEARCH PROBLEM.**
> **P0-06's guarantee is: every structural change is authorized by an entity that exists, evidenced by an artifact
> that is anchored, bounded by a budget that is non-fungible, reversible or declared irreversible, and logged in a
> record that cannot be rewritten.** It does **not** guarantee that the resulting structure is good. **Any
> implementation that presents regional quality metrics as verification is misrepresenting sandbox-grade evidence
> (`DEV-R48.2`) as production-grade, which is X-D12's failure at the level of the whole architecture.**

---

# §50 — EPISTEMIC STATUS OF DEVELOPMENTAL CLAIMS

## 50.1 What kind of object is "region R satisfies FI-03"?

`Cell` state 2 `DEVELOPING` and state 14 `TRANSDIFFERENTIATING` both set **"emits beliefs ❌"**. `Cell` P14
restricts belief emission to `ACTIVE`/`LEARNING_CONSOLIDATING`(reduced)/`DEGRADED`(reduced)/`THROTTLED`(reduced).
**⟹ A developmental claim is NOT a belief, and cannot be emitted as one.** It is a different object:

> ### **DEV-R50.1 — DEVELOPMENTAL CLAIMS ARE KERNEL-HELD STRUCTURAL ASSERTIONS.**
> A structural assertion `SA(p, evidence, ceiling)` is: a predicate `p` over the structural store (§46), an evidence
> reference set, and an **evidence ceiling** inherited from the instrument that produced it (`DEV-R47.1`, `P0-05`'s
> evidence-ceiling discipline — e.g. *"error_class = PREDICTION ⟹ evidence ceiling = L6 ⟹ ¬reaches S3"*).
> | Property | Belief (`ASSERT`/`PREDICT`) | **Structural assertion** |
> |---|---|---|
> | Emitter | a cell in `ACTIVE` | **K** |
> | Warrant | per `P0-03` WARRANT plane; `COMM-INV-08` non-increasing | **not warrant-bearing at all** |
> | Confidence | `≤ TRUST_MAX = 0.95` (`Cell I-27`), calibrated (`Cell §11`, `I-24`) | **no confidence value** — it has an evidence ceiling instead |
> | Contestable | yes (`Cell §7.3` contest) | **yes, by Σ-log audit, not by message** |
> | Rewritable | no (`P0-04`) | **no** (`DEV-R44.4`) |
>
> **⟹ The critical prohibition:** a structural assertion **MUST NOT** be converted into a belief, a confidence
> value, or a warrant. If "region R satisfies FI-03" could raise some cell's confidence in R's outputs, the
> differentiation engine would have become a **truth-granting authority** — the exact confusion §109 forbids
> (*"don't treat specialization as truth"*) and the exact failure `P0-04 MEM-INV-50` and `P0-03`'s plane separation
> were built to prevent.

> ### **DEV-R50.2 — SPECIALIZATION IS NOT TRUTH.**
> A cell's `role`, its specialization degree, its region membership, its calibration class, and its ablation delta
> are **all** non-epistemic facts about *organization*. **None of them raises the warrant of anything the cell
> says.** Warrant comes only from `P0-03`'s WARRANT plane and `P0-04`'s provenance/verification machinery.
> **The one permitted interaction is restrictive:** `Cell` P15 — *"`ATTEST_VERIFIED` is permitted only in `ACTIVE`,
> only for C3 with role `VERIFIER`, and only with an EIK countersignature."* **⟹ Role gates the *permission to
> attest*; it never raises the *warrant of an attestation*.** Attestation warrant still requires the EIK
> countersignature and `Cell §15.4`'s independence. This is the correct pattern and P0-06 generalizes it:
> **developmental facts gate permissions; they never grade truth.**

---

# §51 — TRUST AND DEVELOPMENTAL SIGNALS

> ### **DEV-R51.1 — TRUST DOES NOT APPLY TO DEVELOPMENTAL SIGNALS.**
> `Cell` trust (`Beta(α,β)`, `TRUST_MAX = 0.95`, `I-27`) is a **belief-source** property: it grades how much a
> receiver should weight an assertion. Developmental signals are INFLUENCE-plane (`DEV-R34.1`) and carry no
> assertions. **⟹ Applying trust to a morphogen is a category error with a dangerous consequence: it would make
> gradient capture a *trust* problem, solvable by discounting, when it is an *authority* problem, solvable only by
> reconstructibility (`DEV-R19.1(b)`).** A captured organizer emitting a plausible-but-false gradient would earn
> high trust by being consistent.

> ### **DEV-R51.2 — WHAT DOES APPLY: RECONSTRUCTIBILITY DIVERGENCE.**
> The detection instrument for developmental signals is **not** trust but **divergence from registered spec**
> (`DEV-R19.1`). Formally: for organizer `o` with registered emission spec `spec(o)` and position `pos(o)`,
> K recomputes `expected_field(spec(o), pos(o))` and compares to the observed field.
> `divergence > θ_div` ⟹ **readings not warranted** (no `fate_bias` effect), organizer flagged, and — because
> `DEV-R19.2(h)` requires ≥2 organizers with disjoint specs — **the disagreement is itself the detector.**
> **Residual (`OR-D6`):** an organizer operating **within** its registered spec can still steer development, because
> the spec itself determines the field. **⟹ The registered spec is therefore a governance object: it is
> `[RO-13]`-approved at appointment (Σ4-class, `DEV-R19.2(i)`), and an organizer's spec may not be self-modified.**
> This bounds EA-2 without closing it, and P0-06 says so.

---

# §52 — CONFIDENCE, CALIBRATION, AND DEVELOPMENT

> ### **DEV-R52.1 — DEVELOPMENT MUST NOT ALTER CALIBRATION STATE EXCEPT BY RE-CALIBRATION.**
> `Cell I-24`: `epistemic_var` monotonically non-increasing in `n_obs` for stable `s2`; `Cell §11` supplies `g`,
> conjugate families, `calibration_class`. A developmental act changes `s2`'s **referent**: a cell that commits to a
> narrower target distribution is now calibrated *with respect to a different distribution*.
> **⟹ Its accumulated `n_obs` does not transfer.** `Cell` handles this correctly and P0-06 inherits it: `T03`
> (`DEVELOPING → CALIBRATING`) and `T32` (`TRANSDIFFERENTIATING → CALIBRATING`) both route through **`CALIBRATING`**,
> and `T23` (`REPAIRING → CALIBRATING`) states *"Full recalibration required be[fore return]"*.
> **Rule:** **any nominal identity change forces `CALIBRATING`, and `CALIBRATING` resets the calibration baseline.**
> `Cell` **T36** makes recalibration periodic and mandatory (`RECALIB_INTERVAL`), and **P10** guarantees
> `CALIBRATING` is reachable from every operational state. **⟹ The inherited machine already enforces this; P0-06
> adds only the prohibition on *partial* transfer:**
> **A committed cell MUST NOT carry forward `n_obs`, `calibration_class`, or `epistemic_var` from its
> pre-commitment generalist period into its specialized role.** Doing so would grant a specialist the confidence of a
> generalist's broader sample — the developmental form of `P0-05`'s *"don't treat repetition as evidence
> independence"* and `Cell I-9`'s confidence-monotonicity requirement, which permits increase only on *"new,
> resolvable, non-self-referential external evidence."* **Pre-commitment observations on a different target
> distribution are not evidence about this one.**

---

# §53 — DEVELOPMENTAL COMMUNICATION REQUIREMENTS

> ### **DEV-R53.1 — WHAT DEVELOPMENT NEEDS FROM `P0-03`, AND WHAT IT MUST NOT ASK FOR.**
> | Need | `P0-03` provision | Constraint P0-06 accepts |
> |---|---|---|
> | Gradient broadcast to many cells | `Cell §7`: `dev.morphogen.v1`, *"small"*, priority 2, **`ttl` short**, non-retryable | Must not raise priority (`DEV-R33.3`); must tolerate loss (a lost POSITION reading means no warrant, hence no effect — fail-safe) |
> | Niche advertisement | same message type, **NICHE class** | **PROPOSED: retryable, idempotent** (`DEV-R33.2`) |
> | Lateral inhibition between neighbours | `INHIBITORY` `conn_type` (`Cell §14.1`, `§15.2`) | `P0-03`: *"warrant class becomes per-message only"* at connection level ⟹ inhibition carries no warrant, correctly |
> | Σ-operation logging | **not a comm function** — K-held structural store (§46) | **Σ-operations MUST NOT be enacted by message.** A message may *propose* (B7); only K may enact |
> | Cross-boundary structural claims | `P0-05` C-2 cross-scope probe | Unavailable at S5 (`OR-D4`) |
>
> **⟹ The most important prohibition: development is not a protocol.** `P0-03` discipline: *"don't let emergent
> protocols bypass governance."* A population that negotiated its own partition by message exchange, without
> Σ-authorization, would produce structure with no provenance, no anchor, no budget accounting, and no dissolution
> condition. **`DEV-R21.2` closes this: `region_exists` requires Σ1 and Σ4 execution, and both are K acts, not
> message effects.**

> ### **DEV-R53.2 — DEVELOPMENTAL EVENTS ARE NOT GLOBALLY VISIBLE, BUT THEY ARE GLOBALLY AUDITABLE.**
> `P0-03` discipline: *"DO NOT make every comm event globally visible."* Applied: **the gradient field, `fate_bias`
> updates, and sampling are LOCAL and not broadcast globally** — broadcasting every developmental tick at 10⁷ cells
> is O(N) traffic per tick for zero governance value.
> **But every Σ-operation, every commitment, every `T41`, and every ablation result is logged to the K-held
> structural store, anchored, and permanently auditable** (`DEV-R44.3`, Annex B P3).
> **⟹ The distinction P0-06 relies on: VISIBILITY (real-time broadcast) is minimized; AUDITABILITY (permanent,
> anchored, retrievable record) is maximized.** These are different properties with different costs, and conflating
> them is how architectures either drown in telemetry or lose their audit trail.

---

# §54 — DEVELOPMENT AND THE GLOBAL WORKSPACE

`P0-05 R60.5` reserves governance slots in the workspace broadcast set; `Cell §30 P0-16` lists the nomination
interface, `evidence_roots`, salience inputs, and abstention as **Partial** dependencies.

> ### **DEV-R54.1 — DEVELOPMENTAL STATE MAY BE NOMINATED; IT MAY NOT DOMINATE.**
> A region's service-level deficit (the DEMAND proposal) is a legitimate salience input — it is exactly what
> `Cell §15.1`'s demand-driven factor describes. **But `P0-04 MEM-INV-50`'s pattern applies: nomination and salience
> are ALLOCATION decisions, never truth decisions.** A developmental deficit that wins workspace broadcast has won
> **attention**, not **correctness**.
> **⟹ Reserved-slot requirement (`DEV-R3.3`, fourth occurrence):** the workspace broadcast set must contain
> governance-reserved slots so that a population experiencing intense developmental churn cannot crowd out
> non-developmental content. **Without this, a churn livelock (D-D07) would also be an attention livelock: the
> organism's workspace would fill with unmet demands, and every other claim would be starved.** Recorded as the
> reason D-D07's severity is CRITICAL rather than HIGH — **it is not only a resource leak, it is a cognitive
> capture.**

---

# §55 — SELF-ORGANIZATION, FORMALIZED

§109: *"don't call a mechanism 'emergent' without defining local rules."* Here they are, in full.

## 55.1 The local rule set (complete)

> ### **DEV-R55.1 — LOCAL RULES OF DEVELOPMENT.**
> **For each cell `c`, at each developmental tick (organism-scheduled — `Cell §15.2`), in this order:**
> ```
> L1  SAMPLE.   If c has morphogen_receptors and a warranted reading exists (DEV-R17.1):
>                   m_c ← morphogen_readings(c)                      ∈ [0,1]^R
>               Else: m_c ← ⊥   ⟹ positional term contributes 0 (fail-safe, not fail-open)
>
> L2  READ.     n_c ← K-advertised niches reachable from position(m_c)      [NICHE class, K-signed]
>               d_c ← DEMAND proposals in scope                              [B7-rate-limited, no effect]
>               s_c ← c's own measured success history per role              [Cell §15.2 w_s]
>               g_c ← genome(c).reaction_norm                                [E9-only, immutable to c]
>
> L3  EXCITE.   excitation_r = w_g·g_c[r] + w_m·affinity(m_c, r) + w_d·d_c[r]
>                            + w_s·s_c[r] + w_n·n_c[r]                        [Cell §15.2, verbatim]
>
> L4  INHIBIT.  inhibition_r = Σ_{neighbours n committed to r} w_i·inhibit_strength(n)
>
> L5  UPDATE.   fate_bias_c ← normalize_softmax((excitation − inhibition) / T_dev(dev_stage_c))
>               **Writer: O, and C↑ within reaction_norm**  [Cell state table — the cell may raise
>               its own fate_bias only inside its genome's reachable set]
>
> L6  EMIT.     If dev_stage_c = COMMITTED with role r: emit INHIBITION(r, strength) to neighbours.
>               ⟵ the only developmental output a cell produces, and it is INFLUENCE-plane
>
> L7  SELF-RESTRICT (optional, unilateral, no authority needed):
>               c may abstain from targets outside its current argmax, decline connections, self-throttle.
>               [Cell §18.4; DEV-R14.3 tier 1]  ⟹ NEVER writes role/dev_stage/region_id/niche_slot.
>
> L8  PROPOSE (rate-limited, no effect, no budget):
>               c may emit DEMAND(role, region, magnitude) if it observes a service-level deficit.
>               [B7; DEV-R15.1 stage 1]
> ```
> **For K, asynchronously and not on the cell tick:**
> ```
> K1  WARRANT.  Recompute expected gradient field from registered organizer specs + positions;
>               warrant or reject readings (DEV-R17.1, DEV-R19.1(b), DEV-R51.2).
> K2  ACCOUNT.  Maintain niche capacity/occupancy ledger (DEV-R20.2); advertise NICHE class.
> K3  ADMIT.    Evaluate Potential(c,t) for every commitment candidate (§11.1) — mechanical, no discretion.
> K4  AUTHORIZE. Execute Σ-operations within open abeyances (DEV-R27.4); enforce DEV-R21.2 predicate;
>               write anchors from verification records only (DEV-R11.4).
> K5  LOG.      Append StructuralProvenance and Σ-tombstones; anchor externally (DEV-R44.3, DEV-R39.1(b)).
> K6  GUARD.    Enforce G-a/G-b/G-c/G-e/G-f, extended to T41 (DEV-R20.3); enforce B6/B7/B8.
> K7  DETECT.   Monitor divergence, churn rate, sole-satisfier status, entrenchment (D-D12, OR-D7).
> ```

## 55.2 What emerges from these rules — and what does not

> ### **DEV-R55.2 — EMERGENT PROPERTIES (CLAIMED).**
> From L1–L8 + K1–K7, the following are **derived**, not assumed:
> | Property | Derivation | Guaranteed? |
> |---|---|---|
> | **Symmetry breaking** | L4's inhibition + an external asymmetry (gradient, niche, input channel) ⟹ a cell that commits first raises neighbours' inhibition for its role ⟹ neighbours' `argmax` shifts ⟹ alternation begins | ⚠️ **Only if an external asymmetry exists** (`DEV-R36.1`). With none: no differentiation, correctly (`DEV-R36.2`) |
> | **Capacity-limited commitment** | L2's `n_c` + `Cell G11` (`occupancy < capacity`) ⟹ once a niche is full, `w_n` term falls ⟹ further cells are pushed to other roles | ✅ **Given niches exist.** If none: `T41` (D-D07) |
> | **Division of labour** | inhibition + niche capacity + `reaction_norm` heterogeneity ⟹ different cells reach different `argmax` | ⚠️ **Requires `reaction_norm` heterogeneity across the population.** A genetically homogeneous population with homogeneous reachability can only alternate (D-D15) |
> | **Regional structure** | Σ1 on cuts satisfying `DEV-R21.2` ⟹ density-based grouping with declared function | ⚠️ **Σ1 is K-authorized, not emergent.** The *cut* is discovered by density; the *constitution* is governance |
> | **Specialization deepening** | `P0-05 E7` "specialisation degree" + `DEV-R14.1` restriction ⟹ monotone narrowing within role | ✅ under E7 authority (`POLICY (RO-13)`) |
>
> ### **DEV-R55.3 — PROPERTIES THAT ARE **NOT** CLAIMED (PROHIBITED CLAIMS, ENUMERATED).**
> The local rules do **NOT** guarantee, and P0-06 does **NOT** claim:
> ❌ that differentiation occurs at all (a symmetric field correctly does not differentiate);
> ❌ that any particular region forms, or that region count approaches the `[H]` ceiling;
> ❌ that the resulting partition is functionally good, optimal, or task-appropriate (D-D18, `OR-D9`);
> ❌ that V3 §9's anatomical regions emerge (`DEV-R30.1`, `DEV-R32.2` — eight of them are inadmissible as regions);
> ❌ that specialization is useful (`OR-D4`: regional claims are sandbox-grade);
> ❌ that diversity is maintained (D-D15: inhibition produces alternation; guards bound but do not ensure);
> ❌ that development converges (`T41` exists precisely because it may not);
> ❌ that the population reaches equilibrium (§91);
> ❌ emergence of intelligence, AGI, consciousness, or any cognitive property;
> ❌ perfect self-organization or perfect developmental safety.

> ### **D-D20 — "SELF-ORGANIZATION" IN V4 IS WEAKER THAN THE PHRASE SUGGESTS, AND THAT IS THE POINT (finding).**
> Under `DEV-R55.1`, the population's contribution is: **sample, excite, inhibit, update within a genome-bounded
> simplex, emit inhibition, self-restrict, and propose.** Every *decision* — warrant, accounting, admissibility,
> authorization, anchoring, guarding — is K's. **⟹ The organism organizes itself in the sense that it *discovers
> the candidate cuts and commitments*; governance *constitutes* them.** This is `SO-3` (§3.2) exactly, and it is a
> **much weaker** property than "self-organization" connotes. **P0-06 states this plainly rather than letting the
> vocabulary oversell the mechanism.** The alternative — letting the population constitute its own scopes — is
> D-D01's circularity, EA-1's existence-as-authorization, and N8's giant controller, all at once.

---

# §56 — THE CENTRAL VS DECENTRALIZED QUESTION

## 56.1 The question, precisely

`Cell §15.2`: *"Each differentiation tick (**organism-scheduled, not cell-scheduled**)."* `Cell §3.1`: `role`
writer = *"Organism (**differentiation engine**)"*. `Cell §7`: `dev.morphogen.v1` from *"**Differentiation Engine
(organism)**"*. **⟹ The Cell Contract specifies a central engine.** §109 forbids *"a giant developmental controller
unless proven necessary"*, and N8 records that **the burden of proof is on the controller.**

## 56.2 Decomposition: the "engine" is four functions at three altitudes

> ### **DEV-R56.1 — THE DIFFERENTIATION ENGINE IS A FUNCTION SET, NOT AN ACTOR.**
> | Function | Altitude | Must it be centralized? | **Proof** |
> |---|---|---|---|
> | **F-1 Field generation** (emit gradients) | **cell** | ❌ **NO — must be decentralized** | `Cell §15.3` `ORGANIZER` is a **cell role**. Centralizing generation = manufacturing position centrally = V3 §9 re-entering through a data channel (`DEV-R17.2`, X-D9) |
> | **F-2 Field sampling + `fate_bias` dynamics** (L1–L6) | **cell** | ❌ **NO — inherited as decentralized** | `Cell` state table: `fate_bias` writer = **"O, C↑ within `reaction_norm`"**; `04_formal_schemas.md`: *"fate_bias: f32[16] (simplex; **O + C↑** within reaction_norm)"*. **⟹ The Cell Contract already gives the cell the write, bounded by its genome.** Centralizing F-2 would *remove* an inherited cell capability |
> | **F-3 Tick scheduling** | **organism** | ✅ **YES** | `Cell §15.2`: *"organism-scheduled, **not cell-scheduled**"*. **Necessity proof:** a cell-scheduled tick lets a cell accelerate its own commitment ⟹ manufacture irreversibility ⟹ claim `I-23` protection (X-D5, EA-4). **Scheduling is tempo control, and tempo controls irreversibility, and irreversibility is capacity** |
> | **F-4 Admissibility + commitment authorization + niche accounting + anchoring** (K1–K6) | **K** | ✅ **YES** | Four independent necessity proofs: **(i)** `role`/`dev_stage`/`niche_slot`/`region_id` are **identity or capacity** fields — `Cell §3.1`, `I-12`, `I-1`, and `P0-05 R19.2`/`R28.1` (`[RO-13]`); a decentralized writer of identity fields permits self-declared roles, which `Cell I-2`'s three mechanisms exist to prevent. **(ii)** Niche accounting must be single-writer or a region can manufacture scarcity (D-D06). **(iii)** Anchors must not be written by the scope they anchor (`DEV-R11.4` A1 rejection). **(iv)** `Cell` Rule 19: catastrophic-violation invariants are EIK-enforced, *"never at cell level"* |
>
> **⟹ NECESSITY ESTABLISHED FOR F-3 AND F-4 ONLY.** The controller is **not** giant: it does not generate fields,
> does not compute `fate_bias`, does not choose specializations, does not decide which cells commit. It **schedules
> ticks and executes authorized acts against a K-held ledger.** Everything adaptive is at cell level (F-2, L7, L8) or
> at organizer-cell level (F-1).

> ### **DEV-R56.2 — THE ENGINE HAS NO DISCRETION.**
> F-4's admissibility step (K3) is **mechanical**: `Potential(c,t)` is a five-conjunct predicate over genome,
> variant, niche ledger, independence attestation, and guard states (§11.1). **K evaluates it; K does not judge
> it.** Authorization (K4) requires evidence artifacts, not judgment. **⟹ The engine is a *validation and
> bookkeeping* service with a scheduler, not a decision-maker.** This is what distinguishes it from the prohibited
> "giant developmental controller": **a controller that decides is an authority; a service that validates against
> declared rules is a kernel function.** `P0-02` is the contract for kernel functions, and F-3/F-4 belong there.
> **Status of §109's prohibition: SATISFIED — the controller is proven necessary in two of four functions, and those
> two are non-discretionary.**

> ### **DEV-R56.3 — WHAT WOULD MAKE IT GIANT, AND IS PROHIBITED.**
> The engine becomes a prohibited giant controller if it acquires **any** of: (a) discretion over admissibility
> (judgment instead of predicate); (b) field generation (F-1 centralization); (c) `fate_bias` computation exclusive
> of the cell's inherited `C↑` write; (d) authority to constitute scopes outside a declared abeyance
> (`DEV-R27.4`); (e) ownership of the objective (`Cell I-12`); (f) the ability to write anchors from its own
> activity rather than from verification records (`DEV-R11.4`); (g) retention of authority after Σ4
> (`DEV-R27.3`'s irreversibility, which is what makes the scaffold self-extinguishing).
> **Each of (a)–(g) is prohibited by a rule already stated. ⟹ The prohibition is not aspirational; it is
> enumerated.**

## 56.3 The decentralization that remains

> ### **DEV-R56.4 — THREE DECENTRALIZED MECHANISMS ARE LOAD-BEARING.**
> 1. **Behavioural self-restriction (L7)** — unilateral, permissionless, unregistered, and the reason a cell can
>    stop contributing to a failing specialization **without waiting for an authority round-trip** (`Cell §18.4`'s
>    latency rationale). **This is the fastest adaptive mechanism in development and it is entirely decentralized.**
> 2. **Lateral inhibition (L6)** — cell-to-cell, local, INFLUENCE-plane. **No central agent computes the pattern.**
>    The alternation/patching behaviour (D-D15) is a genuine local-rule outcome.
> 3. **Demand proposal (L8)** — any cell may observe a deficit and propose. **The population's knowledge of its own
>    unmet needs is decentralized**, and only the *authorization* is central (`DEV-R15.1`).
> **⟹ The architecture is decentralized in DISCOVERY and centralized in CONSTITUTION.** That is the precise hybrid,
> defined — as Rule 17 and the standing instruction require — by naming its components, their writers, and their
> altitudes, rather than by asserting "hybrid".

---

# §57–§58 — INTERFACE SUMMARY TO `P0-03`, `P0-04`, `P0-05`

> ### **DEV-R57.1 — INTERFACE OBLIGATIONS P0-06 OWES.**
> | To | Obligation |
> |---|---|
> | **`P0-03`** | Use `dev.morphogen.v1` only; add no `MessageType`; keep priority 2; keep INFLUENCE plane; never make a boundary a network partition (D-D09); accept that cross-boundary delivery guarantees are weaker |
> | **`P0-04`** | Write no memory object; treat structural assertions as non-beliefs (`DEV-R50.1`); never rewrite provenance (`DEV-R44.4`); respect `MEM-INV-50`'s allocation-only pattern for niche salience |
> | **`P0-05`** | Execute no rung against a nonexistent scope (`DEV-R5.2`); accept B6 non-fungibility and propose B8 (`DEV-R35.1`); honour `R46.1`'s declared-reversal requirement for specializations; never write Λ4 (`DEV-R27.2`); treat demand as proposal per `R29.2` |
> | **`P0-02`** | Require the K-held structural store (`DEV-R46.1` — **PROPOSED AMENDMENT**); require abeyance records (`DEV-R27.4`); require organizer spec registration (`DEV-R19.1(a)`) |
> | **`P0-01`** | Take all numeric thresholds from it (`Cell §30`: without `P0-01` *"every threshold is arbitrary"*); contribute no fitness term (`DEV-R41.3`); treat the task set as the source of FI-12 (EXTERNAL invariants) |
> | **Cell Contract** | Add no cell field (`DEV-R0.1`); add no lifecycle state/transition (`DEV-R0.2`); supply the `DevStage` machine as a **separate** normative annex (§88, D-D16) |

> ### **DEV-R58.1 — INTERFACE OBLIGATIONS P0-06 CLAIMS FROM OTHERS.**
> | From | Claim | Status |
> |---|---|---|
> | `P0-02` | K-held structural store; abeyance registry; organizer spec registry; anchor writing from verification records | **PROPOSED AMENDMENT** |
> | `P0-05` | B8 budget class | **PROPOSED AMENDMENT** |
> | Cell Contract | `T41` guards (G-a/G-b extension); `T41` asymmetry qualifier; `T04`/`T05` non-waivability; `I-22` enumeration; `R` definition; NICHE retryability; `RoleCode` versioning; P11/§27 recovery restatement | **8 PROPOSED AMENDMENTS** |
> | `P0-03` | A statement of whether region boundaries count as network partitions | **UNRESOLVED (D-D09)** |
> | `P0-01` | Every numeric threshold; the task-dependent FI set (FI-12) | **BLOCKING** |

---

# §59 — SCALABILITY PREVIEW: WHAT BREAKS FIRST

Full treatment at §92. The preview, because it constrains Vol A–C design:

> ### **DEV-R59.1 — THE FIRST THING THAT BREAKS IS THE TICK.**
> F-3 is centralized scheduling (`DEV-R56.1`). At `Cell §22`'s cluster tier (**10⁶–10⁷ cells**), a synchronous
> organism-wide developmental tick is O(N) coordination per tick. **⟹ The tick must be ASYNCHRONOUS AND PARTIAL**:
> K schedules **batches**, and a cell's `fate_bias` is updated on its own batch's tick. **This does not decentralize
> F-3** (the schedule is still K's, so EA-4 stays closed) **but it removes the synchrony requirement.**
> **Constraint inherited:** `P0-03` — *"DO NOT require perfect global sync."* **⟹ `Cell §15.2`'s "each
> differentiation tick" must be read as a *per-cell scheduled event drawn from a K-held schedule*, not a global
> barrier.** Recorded as a **clarification of `Cell §15.2`, PROPOSED AMENDMENT**, because the difference is
> load-bearing at 10⁷ cells and the source text does not distinguish them.

> ### **DEV-R59.2 — THE SECOND THING THAT BREAKS IS INHIBITION FANOUT.**
> L4 sums over **committed neighbours**. `Cell §22`/`P0-03` impose **degree caps** (`max_connections`, `max_fanout`
> from genome) and `P0-29` imposes **fanout caps**. **⟹ Inhibition is bounded by degree cap, so a cell's view of
> the committed-field is LOCAL and SAMPLED.** Consequence: **symmetry breaking is local**, so large populations
> develop **many local patterns** rather than one global one — which is *fragmentation risk* (§90), not a bug.
> **⟹ Region formation is the mechanism that gives local patterns global structure, and Σ1 is
> budget-limited (B8), so the number of local patterns that can be constituted is bounded.** This is the honest
> scalability story: **development does not scale by becoming global; it scales by constituting a bounded number of
> local structures and letting the hierarchy nest (`DEV-R24.2`, depth ≤ tier ceiling).**

---

# §60 — VOLUME C LEDGER

## 60.1 Rules minted in Vol C

`DEV-R41.1`–`41.3` (three currencies; restrictive-only resource action; resources are not fitness) ·
`DEV-R42.1`–`42.2` (budget map; Σ2 free) · `DEV-R43.1`–`43.2` (envelope is the only increase; development is a
partition problem) · `DEV-R44.1`–`44.4` (three lineage uses; lineage is not a preference; structural provenance;
success never rewrites provenance) · `DEV-R45.1` (independence is a developmental achievement) · `DEV-R46.1`
(**K-held structural store required**) · `DEV-R47.1`–`47.2` (minimum verification per operation; cost monotone in
irreversibility × blast radius) · `DEV-R48.1`–`48.3` (ablation needs redundancy; regional ablation is
sandbox-grade; ablation is K-scheduled) · `DEV-R49.1`–`49.2` (the unverifiable set; process vs quality) ·
`DEV-R50.1`–`50.2` (structural assertions; specialization is not truth) · `DEV-R51.1`–`51.2` (trust does not apply;
reconstructibility divergence does) · `DEV-R52.1` (no calibration transfer across commitment) ·
`DEV-R53.1`–`53.2` (comm needs; visibility vs auditability) · `DEV-R54.1` (workspace reserved slots) ·
`DEV-R55.1`–`55.3` (**the complete local rule set**; emergent properties claimed; prohibited claims enumerated) ·
`DEV-R56.1`–`56.4` (**engine = 4 functions, 2 necessarily central, no discretion**; the seven ways it would become
giant; three load-bearing decentralized mechanisms) · `DEV-R57.1`, `DEV-R58.1` (interface obligations both ways) ·
`DEV-R59.1`–`59.2` (tick must be async-partial; inhibition fanout is degree-capped).

## 60.2 Findings

| ID | Finding | Severity | Status |
|---|---|---|---|
| **D-D18** | The partition program has no solver and must not have one | HIGH | ACCEPTED-LIMIT |
| **D-D19** | Bootstrap paradox of independence — the first verifier cannot be verified | HIGH | RESOLVED-STRUCTURAL (external evaluator; inherits `P0-05 RH-2` exposure) |
| **D-D20** | "Self-organization" in V4 is discovery-decentralized, constitution-centralized — weaker than the phrase suggests | — | **STATED** (honesty requirement) |

## 60.3 Amendments proposed in Vol C (cumulative)

**New:** (10) `P0-02` — K-held structural store + abeyance registry + organizer spec registry [`DEV-R46.1`,
`DEV-R27.4`, `DEV-R19.1(a)`]; (11) `Cell §15.2` — clarify "differentiation tick" as async-partial [`DEV-R59.1`].
**Carried:** (1)–(9) from Vol A/B.
**Total proposed amendments to prior contracts: 11. None applied. All logged at §94.**

## 60.4 Handoff to Vol D

| Vol C output | Vol D use |
|---|---|
| `DEV-R42.1`, `DEV-R43.1`–`43.2`, D-D18 | §61–§62 consistency and resource equilibrium |
| `DEV-R46.1` (structural store), `DEV-R44.3` | §63–§65 region merge / split / failure |
| `DEV-R48.1`–`48.3`, D-D19 | §66 redundancy, §67 fault tolerance |
| `DEV-R25.1`–`25.3` | §68 hardware migration |
| `DEV-R43.2` (partition program), `Cell §22.3` [U] on 50,000× change | §79–§80 compression / expansion |
| `DEV-R5.2` (Σ1→Σ4→E\* ordering), `DEV-R11.4`, D-D19 | §76 bootstrap |
| `DEV-R55.1`–`55.3` | §77 branching, §91 equilibrium |
| `DEV-R41.3`, `DEV-R1.1` | §80 fitness interaction |

---

**Next → Volume D (`50_analysis_consistency_failure_bootstrap.md`, §61–§80):** consistency between structure and
cell state, region merge / split / failure, redundancy, fault tolerance, hardware migration, compression and
expansion, bootstrap ordering, developmental branching, and the fitness interaction.
