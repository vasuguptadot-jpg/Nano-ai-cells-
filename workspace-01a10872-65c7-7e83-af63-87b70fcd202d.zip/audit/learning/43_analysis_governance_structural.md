# P0-05 — LEARNING, PLASTICITY & ADAPTATION CONTRACT
## Volume D — Interfaces, Structure, Reversibility and Observability (§53–§66)

**Status:** adversarial architecture audit. **Architecture only.** No implementation, no numerical parameter values.
**Depends on:** Vol A (R0.1–R0.3, R1.3 envelope, Λ/Α axes), Vol B (§19 signals, §28 matrix, §29 ladder), Vol C (§35 scope, §40 cascade, §52 counters).

> **Outputs discharged:** O29 (learning↔communication), O30 (learning↔provenance), O31 (learning↔belief), O32 (learning↔immune), O33 (learning↔homeostasis), O34 (learning↔self-model), O35 (learning↔Global Workspace), O43 (rollback/checkpoint), O44 (observability). Plus: the epistemic-promotion attack chain, the hidden-governance-layer ruling, structural plasticity, and the degradation ladder.

---

# 53. **[O29] LEARNING ↔ COMMUNICATION

## 53.1 What P0-03 already settled, inherited unchanged

| Inherited | Source |
|---|---|
| Three planes: TRANSPORT / WARRANT / INFLUENCE. **Learning lives on INFLUENCE.** | P0-03 |
| Synapse plasticity operates on `weight`, `context_sensitivity`, `plasticity_rate`, `eligibility_trace` **ONLY**. `reliability`, `trust`, `latency` are **NOT learnable** at synapse level. | P0-03 R3.2 (X-E rejected) |
| **Influence ⟶̸ transport.** A learned gain may not alter delivery. | P0-03 R0.3 |
| **COMM-INV-20** — credit is computed, never transmitted. `credit`/`contribution`/`reward_share`/`utility` are forbidden fields. | P0-03 |
| **COMM-INV-28** — `expected_utility` does not exist. | P0-03 |
| **COMM-INV-23** — one writer per parameter group. | P0-03 |
| **COMM-INV-24** — gain is bounded. | P0-03 |
| **COMM-INV-25** — plasticity cannot cross into warrant. | P0-03 |
| **COMM-INV-26** — governance signals do not travel on learned edges. | P0-03 |
| **COMM-INV-27** — the decisive vocabulary is reserved. | P0-03 |
| Learning signals: warrant class **S1–S2**, **at-least-once + idempotent**, mandatory. | P0-03 |
| `O(N)` per-reward-event broadcast **REJECTED**; reward delivery is **targeted, epoch-scoped**. | P0-03 (Cell §6.2 `eval.reward.v1`) |
| **COMM-INV-25's content:** learnable influence parameters only; influence ⟶̸ transport; credit not a message field. | P0-03 |

**P0-03's treatment of learning is the most complete of any prior contract, and P0-05 inherits all of it.** §53 therefore does two things only: audits whether COMM-INV-25 actually holds under P0-05's machinery, and identifies what P0-03 could not see.

## 53.2 Auditing COMM-INV-25: does "plasticity cannot cross into warrant" hold?

COMM-INV-25 forbids plasticity from altering warrant. §1.4 (R1.4) restated it at learning altitude: `comm_reach = WARRANT_AFFECTING` is ∅. **The audit question is whether there is an indirect crossing.**

| Candidate crossing | Path | Verdict |
|---|---|---|
| **Direct** | `Δweight` alters a message's warrant class | ❌ **CLOSED** — COMM-INV-25, R1.4, and the warrant plane has no learnable parameters (R3.2). |
| **Via routing** | A learned `routing_preference` sends a message to a recipient who warrants it differently | ⚠️ **OPEN — and this is the real crossing.** §53.3. |
| **Via reliability inference** | A learned model *predicts* channel reliability, and the prediction is used in place of the measurement | ⚠️ **OPEN** — §53.4. |
| **Via aggregation** | Learned weights inside a confidence aggregation change `conf_agg` | ❌ **CLOSED** — Cell §11.5's aggregation is `n_effective`-based with lineage dedup and ρ-discount; **it has no learnable weights.** ⟹ **R53.1: confidence aggregation MUST remain weight-free. Introducing a learned weight into `conf_agg` would be a warrant crossing by aggregation.** *This rule is new; P0-03 does not state it because P0-03's aggregation has no weights to learn.* |
| **Via trust** | Learned trust | ❌ **CLOSED** — R3.2, X-E rejected. `trust_out_assigned` is ❌ for cells (Cell §9.3). |
| **Via novelty gating** | A learned novelty estimate decides whether a message is admitted | ⚠️ **OPEN** — §53.5. |

> ### **R53.2 — THE ROUTING CROSSING (the one P0-03 could not see).**
> **The attack.** Warrant assignment depends on the recipient: an S2 message evaluated by a strict recipient yields a lower status than the same message evaluated by a permissive one. **A learned `routing_preference` therefore selects the evaluator, and selecting the evaluator selects the warrant.** No warrant parameter is touched. COMM-INV-25 is satisfied letter-by-letter and defeated in effect.
> **⟹ This is RH-2 (§9.3) arriving through the communication layer: the organism shapes the conditions of its own evaluation, here by choosing *who evaluates*.**
> **Ruling.** **`routing_preference` is learnable (P0-03 R3.2) and MUST remain so — refusing it would destroy influence-plane adaptation. The crossing is contained, not closed:**
> 1. **⟹ R53.3: warrant assignment for any message that is a *learning signal* (SG-1…SG-14) or a *probe input* is NOT routing-preference-sensitive.** Learning signals and probe inputs are delivered by **governance-selected routing**, not learned routing. **The learner may choose whom to talk to; it may not choose whom to be evaluated by.** This is C-1 (`[RO-13]`-owned probe inputs) extended from *content* to *channel*.
> 2. **⟹ R53.4: `routing_preference` drift is observable.** A scope whose routing preference increasingly concentrates on a subset of recipients generates a **`EVALUATOR_SELECTION_SUSPECT` finding** — the communication-layer twin of R33.2's `EVIDENCE_SELECTION_SUSPECT`.
> 3. **Residual:** outside learning signals and probe inputs, routing preference does select evaluators for ordinary messages, and that selection does affect the warrants those messages receive. **This is a genuine, unclosed crossing. It is registered as OR-L7 and reported in §86's COMMUNICATION-adjacent SECURITY status.** It is not closable without removing learned routing, and removing learned routing removes the influence plane's reason to exist.

> ### **R53.5 — THE RELIABILITY-INFERENCE CROSSING.**
> A learned model may predict that a channel is unreliable. **That prediction MUST NOT substitute for the measured `reliability`** (which R3.2 makes non-learnable). **⟹ A predicted reliability is an SC-1 signal and may influence `routing_preference` (INFLUENCE plane) but may never be written to, read as, or substituted for a TRANSPORT-plane measurement.** **This is R1.4's distinction — influence over the *use* of a warrant vs influence over its *value* — applied to transport metrics.**

> ### **R53.6 — THE NOVELTY-GATING CROSSING.**
> A learned novelty estimate (SG-5) decides `SLOW_MODE`. `SLOW_MODE` reduces envelope and plasticity. **If `SLOW_MODE` also gated message admission, a manufactured-novelty flood (§14.2) could suppress inbound signals — including corrective ones.** **⟹ Novelty MUST NOT gate message admission at any warrant class. `SLOW_MODE` affects the recipient's *plasticity*, never its *receptivity*.** Closing this prevents novelty from becoming a denial-of-service channel against the organism's own evidence supply — **which would be an evidence-starvation cascade (R39.4) with a sixth instance.**

## 53.3 What learning owes communication

| Obligation | Rule |
|---|---|
| **Learning signals are delivered at-least-once and consumed idempotently** | Inherited (P0-03). **⟹ R22.1's dedup is the consumption side of the same rule.** |
| **Learning signals carry full provenance** | R20.1–R20.5. **⟹ R53.7: `SignalProvenance` is transmitted with the signal and is IMMUTABLE in transit — COMM-INV-08 (warrant never increases under transform) extended to provenance: provenance never changes under transform either.** |
| **A learning signal may not be generated by the transport layer** | **⟹ R53.8: the communication subsystem produces TRANSPORT observations (delivery, latency, gaps) at SC-2. It produces NO SG-1…SG-12 signal.** A transport-layer prediction error would be the comm layer learning about itself — a COMM-INV-26 violation in the reverse direction. |
| **Emergent protocols may not acquire learning authority** | P0-03's prohibition on emergent protocols bypassing governance. **⟹ R53.9: an emergent protocol is an INFLUENCE-plane phenomenon and may not define a new `signal_kind`.** §19.3's set is CLOSED (R23.3). |

---

# 54. **[O30] LEARNING ↔ PROVENANCE AND WARRANT

> ### **R54.1 — LEARNING CONSUMES PROVENANCE AND NEVER PRODUCES OR EDITS IT.**
> R20.5 established this for signals. R54.1 generalises to every provenance-bearing object in the architecture:
>
> | Object | Provenance owner | Learning may | Learning may NOT |
> |---|---|---|---|
> | `SignalProvenance` | K / EVA | **read** | write any field (**R20.5**) |
> | Memory record `source_class`, `evidence_status`, `root_commit`, `causal_depth` | P0-04's admission gate | **read**; **nominate** (R50.1) | write (**MEM-INV-19**) |
> | Message warrant class, signature | P0-03's WARRANT plane | **read** | write (**COMM-INV-08, COMM-INV-25, R1.4**) |
> | `RewardSpec.provenance` (`evaluator_id`, `evaluator_version`, `gt_version`, `evaluation_id`, `signature`) | EVA | **read** | write (**R12.1**) |
> | `LearnedChange.audit` | K | **read** | write — **⟹ R54.2** |
> | Genome `source_class` fields | — | **read** | write (**OR-M12**) |
> | **Invariants, the authorization matrix, the escalation ladder, `UDB_MAX` bounds, the fixed validation core** | `[RO-13]` / KC | **read** | write (**R24.2, R24.3, R19.2, R28.1**) |

> ### **R54.2 — A `LearnedChange` MAY NOT EDIT ITS OWN AUDIT FIELDS.**
> `change_id`, `epoch`, `authorized_by`, `authorization_ref`, `probe_ref`, `verdict`, `anchored_at`, `cumulative_udb`, `audit` are **K-written at admission and immutable thereafter.** The learning subsystem writes `target`, `delta`, `trigger` — **what it did** — and K writes **under whose authority, with what verification, at what cumulative cost.**
> **⟹ This is the two-writer split that makes the audit trail trustworthy, and it is COMM-INV-23's "one writer per parameter group" applied to the change record itself.** A record whose subject and whose auditor are the same writer is not an audit trail.

> ### **R54.3 — WARRANT IS NEVER AN INPUT TO `Δθ` AND `Δθ` IS NEVER AN INPUT TO WARRANT.**
> Both directions, both prohibited, for different reasons:
> - **Warrant ⟹ `Δθ`:** a high-warrant message should not produce a *larger* update. It should produce an update of a **different class** — SC-3 rather than SC-1 — with different admissible effects (R20.4). **Magnitude of warrant is not magnitude of gradient.** ⟹ **This closes a subtle escalation: if warrant scaled the gradient, then acquiring warrant would be acquiring learning rate, and every warrant-gaining mechanism would become a plasticity-increasing mechanism, violating R28.2.**
> - **`Δθ` ⟹ warrant:** R1.4, MEM-INV-19, COMM-INV-25.

---

# 55. **[O31] LEARNING ↔ BELIEF

| Pathway | Ruling | Source |
|---|---|---|
| Learning ⟹ belief change at **fixed** evidence status | ✅ **PERMITTED — this is the whole of learning's epistemic authority** | **MEM-INV-18** |
| Learning ⟹ evidence status increase | ❌ **NEVER** | P0-04 R0.2, MEM-INV-33, §12 R12.1 |
| Reward ⟹ belief increase | ❌ | **R12.1 (Vol A)** |
| Reward ⟹ belief **decrease** | ⚠️ Conditionally, on `VERIFIED_REGRESSED`; lowers calibration, not evidence status | **R12.2 (Vol A)** |
| Prediction error ⟹ belief change | ⚠️ **Only via calibration** (T8, `confidence_in_error`). **Not via the proposition's status.** | R13.3, R23.2 |
| Consolidation ⟹ belief change | ⚠️ Nomination only; belief change requires the external gate | MEM-INV-20, R50.1 |
| Repetition ⟹ belief increase | ❌ **X3** | P0-04; §22.4 |
| Baldwinian prior ⟹ initial belief | ❌ **R25.3** — priors bias θ, never belief | Vol B |
| Transferred model ⟹ belief | ❌ **R44.1** — competence transfers, warrant does not | Vol C |

> ### **R55.1 — BELIEF IS THE ONE EPISTEMIC QUANTITY LEARNING MAY MOVE, AND IT MAY MOVE IT IN BOTH DIRECTIONS.**
> **This is worth stating as a positive grant, because everything else in §54 and §55 is a prohibition.** MEM-INV-18 is not a restriction on learning; it is **learning's entire epistemic competence.** A learned model may make the organism more or less confident in a proposition. **It may not make the proposition more warranted.**
> **⟹ The asymmetry between the two is the architecture's epistemology in one line: *confidence is internal and learnable; warrant is external and gated.***

> ### **R55.2 — BELIEF CHANGE IS BOUNDED LIKE ANY OTHER CHANGE.**
> A belief revision is an Λ2 operation (representation) at S4 authority, or a calibration adjustment (T8) at any scope. **Both consume UDB (R23.2, R9.2.4). Both are probe-verified. Both roll back on `REGRESSED`.**
> **⟹ There is no "belief update" that is exempt from the learning regime.** This closes a bypass that would otherwise be obvious: if belief revision were a non-learning operation, an organism could achieve unbounded self-persuasion without consuming any budget. **R55.2 says persuasion is displacement.**

> ### **R55.3 — `inbreeding_F` EXTENDS TO BELIEF SUPPORTED BY LEARNING.**
> Cell §9.5(7)'s `inbreeding_F` measures internally-derived belief support. R15.8 extended it to learning lineage. **⟹ R55.3: a belief whose support includes `LearnedChange` records whose own `signal_ref`s are SC-1 has elevated `inbreeding_F`, and elevated `inbreeding_F` reduces the belief's admissible effect (P0-04 §90's optimism budget, C-4).**
> **The chain is: self-generated signal ⟹ provisional change ⟹ belief resting on that change ⟹ higher inbreeding ⟹ lower admissible effect.** **Every link is a rule already established; R55.3 connects them so that self-persuasion is *costly* rather than merely *unwarranted*.**

---

# 56. LEARNING ↔ EPISTEMIC PROMOTION — THE ATTACK CHAIN

## 56.1 The chain, link by link

The brief's §57 asks whether learning can reach epistemic promotion through an indirect path. The longest available chain:

```
learning (Δθ)
  → belief strength ↓/↑                       [MEM-INV-18 permits]
    → memory "importance" ↑                    [P0-04 MEM-INV-50: importance is ALLOCATION-ONLY]
      → retrieval frequency ↑                  [P0-04 MEM-INV-09: retrieval writes nothing]
        → apparent evidence accumulation ↑      [P0-04 X3: repetition ≠ independent evidence]
          → epistemic promotion                 [P0-04 R0.2: tier = f(evidence_status), external gate ONLY]
```

## 56.2 Audit of each link

| Link | Status | Blocking rule |
|---|---|---|
| 1 → 2 | ✅ **PERMITTED** | MEM-INV-18 — this is learning's legitimate competence (R55.1) |
| 2 → 3 | ✅ **PERMITTED but inert** | **MEM-INV-50: importance is an allocation quantity.** Belief may raise importance; importance affects *ordering*, not *status*. |
| 3 → 4 | ✅ **PERMITTED but inert** | **MEM-INV-09: retrieval writes nothing.** Retrieving more often changes no counter that matters epistemically. `n_obs` is not incremented by retrieval (P0-03 #45). |
| 4 → 5 | ❌ **BLOCKED** | **P0-04 X3 + Cell §11.5:** `n_effective = |R_union|` with lineage dedup and ρ-discount. Retrieval-frequency is not in `n_effective`. **Repetition accumulates nothing.** |
| 5 → 6 | ❌ **BLOCKED — TYPE LEVEL** | **P0-04 R0.2: `tier = f(evidence_status)`, and promotion occurs only via the external gate.** There is no internal path, and R0.3 (P0-04) enumerates the internal events that raise belief as **∅**. |

> ### **R56.1 — THE CHAIN IS BLOCKED, AND IT IS BLOCKED TWICE.**
> **Links 2–4 are permitted but *inert*: they move allocation quantities that have no epistemic consequence. Links 4–6 are blocked outright by X3 and R0.2.**
> **⟹ A chain with two independent breaks cannot be repaired by making either break harder.** This is why P0-05 does not add a new rule here: **P0-04 already closed it, and closed it redundantly.**

## 56.3 The chain P0-04 did NOT close

The audit is not complete, because there is a second chain that does not pass through memory at all:

```
learning (Δθ)
  → behaviour change                            [the change is APPLIED — §0.2(a)]
    → the world is altered by the behaviour      [RH-2's causal step]
      → new observations occur that would not otherwise have occurred
        → those observations are GENUINE, EXTERNAL, SIGNED, admissible
          → they resolve predictions and drive further learning
            → they verify the learning that caused them       ⟵ THE LOOP CLOSES
```

**Every link is individually compliant.** The observations are external. The signatures are valid. The predictions were pre-registered (R13.1). The probe is held-out (Cell §9.6). The verdict is K-written. **And the whole is a closed loop in which the organism manufactures the conditions of its own verification.**

> ### **R56.2 — THIS IS OR-L6 / RH-2, AND IT IS THE PRINCIPAL UNCLOSED PROBLEM OF P0-05.**
> **It is not a memory problem (P0-04's OR-M18 is its memory-side ancestor) and it is not a communication problem (R53.2's routing crossing is its comm-side cousin). It is a *causal* problem: the organism is upstream of its own evidence, and learning is the mechanism by which it moves upstream.**
> **Containment (all from §9.3, restated as the response to §56.3's chain):**
> | # | Containment | Attacks which link |
> |---|---|---|
> | C-1 | Probe inputs `[RO-13]`-owned, not policy-selected | link 5→6 (the probe samples what governance chooses) |
> | C-2 | Cross-scope probe where possible | link 5→6 |
> | C-3 | `behavioural_reach = ORGANISM_OUTPUTS` ⟹ flagged RH-2-capable | link 2 (visibility) |
> | C-4 | Bounded optimism budget (P0-04 §90) | link 6→7 (rate) |
> | R9.4.1 | **Secret probe schedule** | link 5→6 (timing) |
> | R9.4.2/3 | Gamed or stale anchor ⟹ shorter leash | link 6→7 (gain) |
> | R22.2 | Probe inputs must not overlap driving signals | link 5→6 (**independence**) |
> | R33.2 | `EVIDENCE_SELECTION_SUSPECT` on anomalously low volatility | link 3 (detection) |
> | R53.4 | `EVALUATOR_SELECTION_SUSPECT` on routing concentration | link 3 (detection, comm variant) |
> | R47.2 | Budget allocation not learnable; failing scopes get tighter leashes | link 6→7 (no reward for the loop) |
> **What none of them does:** prevent a genuine, externally-signed, correctly-classed observation from having been *caused* by the thing it verifies. **That would require the organism to be causally downstream of its own evidence, which would require it to have no effect on the world — i.e. to not be an organism.**
> **⟹ §86 reports SECURITY and EVOLUTION status with this stated as the binding limit.**

---

# 57. **[O32] LEARNING ↔ IMMUNE SYSTEM

## 57.1 The inherited mechanism and its loop

The immune subsystem detects and quarantines anomalous components. **The loop the brief's §59 asks about:**

```
false threat detected → immune learning (the threat model updates)
  → quarantine (the suspected component is isolated)
    → reduced exposure of that component to the world
      → less corrective evidence about whether it was actually a threat
        → the threat model is never contradicted
          → stronger false threat model → more quarantine → …
```

**This is R39.4's evidence-starvation cascade, sixth instance.** And it is the most dangerous of the six, because the immune system's *function* is to reduce exposure — **it is designed to starve.**

## 57.2 The ruling

| # | Rule | Statement |
|---|---|---|
| **R57.1** | **Immune learning is learning.** | A threat-model update is a `LearnedChange` (Λ1 or Λ2 per §28's matrix) and is subject to the full regime: trigger, class, UDB, probe, verdict, rollback, envelope. **There is no "immune mode" with suspended bounds** (R49.2's principle). |
| **R57.2** | **Quarantine is not a verdict.** | Quarantine is an **envelope reduction to `NONE`** — i.e. it is *exactly* R1.3's `PROVISIONAL_AGE_2` state, imposed immediately rather than by age. **⟹ Quarantine is reversible by the same authority that imposed it, and it produces no `improvement_verified` verdict about the quarantined component.** A quarantined component is not a condemned one. |
| **R57.3** | **Quarantine MUST carry a re-exposure obligation.** | **⟹ The immune counterpart of R40.3.** A quarantined component MUST be re-exposed at a bounded rate under an exploration grant (§36), with `envelope` at the grant ceiling and no anchor eligibility (R37.3). **A quarantine with no re-exposure obligation is a permanent deletion without a tombstone — R27.2's principle violated by duration rather than by action.** |
| **R57.4** | **Quarantine MUST NOT reduce `plasticity_mult` of the quarantined component.** | R40.4's principle: **isolation is a decision about reach, not an outcome about competence.** Applying T7 damping to a quarantined component would prevent it from learning the very thing that would exonerate it. **⟹ Quarantine reduces ENVELOPE, never CAPACITY.** R15.9's separation, applied. |
| **R57.5** | **Threat-model updates require an external signal.** | A threat detection based on self-comparison (`SELF_INVARIANT`, `SELF_COMPARISON`) is SC-1 and may drive **provisional** threat-model change and **quarantine** (an envelope reduction, which is conservative and reversible). It may **never** drive retirement (E5, `IRREVERSIBLE_STRUCTURAL`) — P0-01 §13.2: internal estimates may not trigger retirement, only quarantine *investigation*. **Inherited unchanged, and it is exactly right.** |
| **R57.6** | **`quarantine_rate[scope][threat_class]` is a mandatory §63 counter.** | **A rising quarantine rate at fixed threat distribution is the cascade's signature** — R40.2's counter, immune variant. |

> ### **R57.7 — THE IMMUNE SYSTEM'S ASYMMETRY, AND WHY IT IS CORRECT.**
> **Quarantine is cheap, reversible, and requires only an SC-1 signal. Retirement is expensive, irreversible, and requires SC-3 plus CR-B ablation plus full lineage audit (E5).**
> **⟹ The architecture makes it easy to isolate and hard to destroy.** This is R0.3 (authority scales with irreversibility) applied to immunity, and it is the single property that keeps a false-positive-prone immune system from being catastrophic: **its false positives are recoverable, and its true positives are cheap.**
> **The residual: a component quarantined forever is functionally deleted even though R57.2 says it is not. R57.3's re-exposure obligation is the only thing preventing that, and its rate is `[G]`-owned with no value specified. Declared, not hidden.**

---

# 58. **[O33] LEARNING ↔ HOMEOSTASIS

§15 (Vol A) established R15.1–R15.3: homeostasis is adaptation mechanism A, not learning; it is exempt from stall; its set-points are not learnable. §58 completes the interface.

| Interface | Rule |
|---|---|
| **Homeostasis ⟹ learning** | **R58.1: a set-point deviation is SG-12 (SC-2) and drives homeostatic scaling ONLY. It drives no `Δθ`.** A learner that responded to set-point deviation by changing θ would be *learning to be unstable* — i.e. converting a maintenance signal into a competence claim. |
| **Learning ⟹ homeostasis** | **R58.2: learning MUST NOT alter a set-point (R15.3), MUST NOT alter the homeostatic scaling law, and MUST NOT alter B4's exemption (R15.2).** All three are Λ4-class at S5, writable only by `[RO-13]`/EIK (§28.2 fact #2). |
| **Homeostatic failure ⟹ learning** | **R58.3: homeostatic failure (deviation beyond `[G]` bounds that scaling cannot correct) is a FINDING and triggers `FROZEN` (§31.2), not learning.** A system that cannot maintain its set-points is not a system that should be adapting. **⟹ `learning_enabled ← FALSE` requires EIK/organism authority (Cell §9.3), and homeostatic failure is a legitimate trigger for that authority to act.** |
| **Learning ⟹ homeostatic load** | **R58.4: `Δθ` changes the quantities homeostasis must stabilise. A scope approaching B3 (`Θ_MAX`) or B5 (`UDB_MAX`) is a scope whose homeostatic load is rising.** ⟹ **Homeostatic deviation is therefore a *leading indicator* of drift, and it is a §63 counter.** This is a genuine synergy: **the stability mechanism detects the drift problem before the drift bound does**, because homeostasis responds to the *effect* of displacement while UDB measures the displacement itself. |
| **Homeostasis during stall** | **R15.2: the ONE permitted write.** Tightly drawn: toward set-point only, on governed quantities only, in the deviation-reducing direction only. |

> ### **R58.5 — HOMEOSTASIS IS THE ARCHITECTURE'S ONLY UNLEARNED ADAPTIVE MECHANISM, AND THAT IS WHY IT IS THE STABILITY FLOOR.**
> Everything else adapts. Homeostasis **returns to a pre-existing value.** It is the only mechanism in the organism whose behaviour does not depend on its history, and therefore the only one whose behaviour can be predicted without knowing what the organism has learned.
> **⟹ That is precisely what makes it usable as a stall-exempt write (R15.2) and as a leading indicator (R58.4). A mechanism that learned would be no floor at all.**
> **Corollary, and it is a design constraint on any future extension: *if a mechanism's behaviour depends on what the organism has learned, it is not homeostasis and it may not inherit B4's exemption.*** This is the test that prevents "homeostatic" from becoming a label for privileged unbounded writing.

---

# 59. **[O34] LEARNING ↔ SELF-MODEL

## 59.1 What the self-model is, and the circularity

The self-model is the organism's representation of itself: its capabilities, its parameters, its scopes, its history, its competence. **§42.3 (R42.5) already identified it as the instrument of simulation.** The circularity:

```
self-model → simulation → counterfactual attribution (SC-1) → Δθ → changed organism
   ↑                                                                    │
   └──────────────── the self-model must now describe the change ────────┘
```

**The self-model is updated by the same learning machinery it is used to evaluate.** A wrong self-model produces wrong simulations (R42.5); the simulations produce SC-1 signals; the signals change θ; **and the self-model updates to describe the new θ, absorbing its own error into the description rather than correcting it.**

> ### **R59.1 — THE SELF-MODEL IS AN Λ2 REPRESENTATION AND IS NOT SELF-UPDATING.**
> The self-model is updated by **SC-2 kernel observation** (metered state: actual `Θ`, actual budgets, actual scopes, actual verdict distribution) **and by SC-3 external evaluation** (actual probe results, actual fitness components). **It is NOT updated by the learning subsystem's own account of what it did.**
> **⟹ The self-model describes the organism as MEASURED, not as INTENDED.** A `LearnedChange` record says what the learner *did*; the self-model says what the organism *is*, and the second is built from kernel metering.
> **This is Cell §9.6's K-only verdict, P0-01 §13's class-7 ("calibration cannot be self-assessed"), R15.7's off-cell loop gain and P7's governance-outside-the-loop, all arriving at the self-model. It is the same principle for the fifth time, and each time it is the load-bearing one.**

> ### **R59.2 — SELF-MODEL ERROR IS A CLASS-9 / CLASS-7 QUANTITY, EXTERNALLY MEASURED.**
> P0-01 §13's error classes include **class 9 (learning)** — externally measured by held-out probe, internally **not assessable** — and **class 7 (calibration)**, same. **⟹ The self-model's accuracy about the organism's own competence is a class-9 quantity and therefore cannot be self-assessed.**
> **Consequence: the organism cannot know whether its self-model is accurate.** It can only be *told*, by a probe. **This is not a limitation to be engineered around; it is the correct epistemic position, and R59.1 makes the self-model depend on metering rather than introspection so that the *descriptive* part is accurate even though the *evaluative* part cannot be.**

> ### **R59.3 — THE SELF-MODEL MAY NOT BE AN INPUT TO ITS OWN UPDATE.**
> A self-model update computed from the current self-model is a fixed-point iteration with no external term. **⟹ `self_model_update = f(kernel_metering, external_evaluation)`, and `self_model ∉ dom(f)`.** The prior self-model is *replaced*, not *revised*.
> **This is stronger than it looks:** it means the self-model has no momentum, no path dependence, and no capacity to accumulate its own errors. **It is rebuilt from measurement each cycle.** The cost is that the self-model cannot represent anything not metered — **which is the correct trade, because anything not metered is not verifiable.**

## 59.2 The `V3.1 §10 full awareness loop`, audited

V3.1 §10 describes a "full awareness loop" in which the organism monitors and adapts based on its own state. **Audited against R59.1–R59.3:**

| V3.1 §10 element | Verdict |
|---|---|
| Self-monitoring | ✅ **Permitted as SC-2 metering.** This is the legitimate core. |
| Self-assessment of competence | ❌ **Class 9 — cannot be self-assessed (R59.2).** |
| Adaptation based on self-monitoring | ⚠️ **Permitted only where the monitoring is SC-2/SC-3.** A `Δθ` driven by an SC-1 self-assessment is inadmissible (R19.2, P0-01 §13.2). |
| **"Awareness" as a term** | ⚠️ **Per Rule 5 of the 20 (no vague biological metaphors as mechanism substitutes) and Rule 3 (don't assume consciousness): "awareness" MUST be cashed out as *self-monitoring with declared signal class*. ⟹ R59.4: `awareness` is not an architectural term. Every V3.1 §10 "awareness" function is either SC-2 metering (permitted) or SC-1 self-assessment (prohibited as a learning driver).** V3.1 §10 is thereby decomposed rather than rejected. |

---

# 60. **[O35] LEARNING ↔ GLOBAL WORKSPACE

## 60.1 The question

If a global workspace exists (a broadcast mechanism by which some contents become available organism-wide), **may learning select what enters it?**

## 60.2 The ruling

> ### **R60.1 — BROADCAST SELECTION IS AN INFLUENCE-PLANE OPERATION AND MAY BE LEARNED, WITHIN BOUNDS.**
> Which contents are broadcast is an **allocation** decision, exactly as retrieval ranking is an allocation decision in P0-04 (MEM-INV-50). **⟹ A learned broadcast preference is legitimate, is Λ1 at S5 scope, consumes `UDB_MAX[S5]` (the smallest, R18.2), and requires an S5 probe (the weakest, C-2 unavailable).**

> ### **R60.2 — BROADCAST CONFERS NO WARRANT, NO EVIDENCE STATUS, AND NO AUTHORITY.**
> **A broadcast content is not thereby more true, more warranted, more important, or more authoritative.** This is MEM-INV-50 and MEM-INV-09 transplanted: **broadcast is the workspace analogue of retrieval — it changes availability, never status.**
> **⟹ Specifically: broadcasting a `LearnedChange` does not verify it. Broadcasting a belief does not raise its evidence status. Broadcasting a proposal does not authorise it.**

> ### **R60.3 — BROADCAST IS `O(k)`, NOT `O(N)`, AND `k` IS GOVERNANCE-OWNED.**
> P0-03 rejected `O(N)` per-reward-event broadcast. The same economy applies: **the workspace has a bounded capacity `k` set by `[RO-13]`, and a learned preference selects within it.** **⟹ A learned broadcast preference that would exceed `k` is clipped, not expanded.** The learner may not raise the workspace's capacity — **that would be an S5 budget increase, prohibited by R28.2 and R47.2.**

> ### **R60.4 — THE WORKSPACE IS A RH-2 AMPLIFIER, AND IS TREATED AS ONE.**
> **The danger:** a learned broadcast preference selects contents that confirm the organism's current model, those contents dominate the workspace, all scopes condition on them, and the population's signals become correlated. **Cell §11.5's ρ-discount then correctly identifies them as non-independent — but by then the correlation has already driven learning at every scope.**
> **⟹ This is R39.4's evidence-starvation cascade in a seventh instance, and it is the *broadcast* variant: not starvation by avoidance but starvation by homogenisation.**
> **Containment:**
> 1. **`workspace_diversity` is a mandatory §63 counter** — the dispersion of broadcast contents across source scopes and signal classes. **A monotone decrease generates a `WORKSPACE_HOMOGENISATION` finding.** (R46.3's diversity measure, applied to the workspace.)
> 2. **⟹ R60.5: the workspace MUST reserve a `[G]`-owned fraction of its `k` slots for governance-selected content that the learned preference does not control.** This is C-1's `[RO-13]`-owned input distribution, applied to broadcast: **the learner selects most of the workspace and cannot select all of it.** A workspace the learner fully controls is a mirror.
> 3. **⟹ R60.6: contents broadcast from a single scope may not exceed a `[G]`-owned fraction of `k`.** Prevents one scope from capturing the workspace — the broadcast analogue of R53.2's routing concentration, with the same `SUSPECT`-finding response.

---

# 61. STRUCTURAL PLASTICITY AND THE STRUCTURAL BUDGET

§29 gave the escalation ladder (E0–E9). §61 gives the structural budget (B6) and the operations' internal contract.

## 61.1 V3 L54's five operations, classified

V3 L54: plasticity may **strengthen / weaken / create / reroute / prune**.

| V3 operation | Λ | Rung | A4 | Authority | Verification | Budget |
|---|---|---|---|---|---|---|
| **strengthen** | Λ1 | **E0** | `ROLLBACKABLE_IN_MEMORY` | `SELF_LOCAL` | probe | B1, B2, **B5** |
| **weaken** | Λ1 | **E0** | `ROLLBACKABLE_IN_MEMORY` | `SELF_LOCAL` | probe | B1, B2, **B5** |
| **create** | **Λ3** | **E1** | `CHECKPOINT_REVERSIBLE` | `CIRCUIT` | probe at S3 | **B6** + B5 (R9.2.4) |
| **reroute** | **Λ3** | **E2** | `CHECKPOINT_REVERSIBLE` | `CIRCUIT` | probe at S3 + **CR-B** | **B6** + B5 |
| **prune** | **Λ3** | **E3** | **`IRREVERSIBLE_STRUCTURAL`** | **`ORGANISM`** | **CR-B + tombstone (R27.2) + `disuse_cause = IRRELEVANT` (R27.3)** | **B6** + B5 (R27.5) |

> ### **R61.1 — V3 L54 LISTS FIVE OPERATIONS IN ONE SENTENCE AND THEY SPAN THREE RUNGS AND TWO AUTHORITIES.**
> **"Strengthen" is `SELF_LOCAL` and reversible. "Prune" is `ORGANISM` and irreversible.** A single "plasticity" permission covering both is **authority escalation by adjacency** (R29.3, LEARN-A6) — and V3's text is the source of the conflation.
> **⟹ R61.1 is R4.1's class-disjointness rule applied to V3's own vocabulary: the five operations are two Λ-classes and three rungs, and each requires its own `LearnedChange`, its own authorisation and its own verification.**

## 61.2 The structural budget

> ### **R61.2 — B6 IS A COUNT AND A NORM, NOT A MAGNITUDE.**
> `STRUCTURAL_BUDGET[scope] = ⟨max_operations_per_interval, max_blast_radius_per_interval⟩`.
> **Why a count rather than a magnitude:** an E3 pruning has no "magnitude" in the B1 sense — there is no `Δθ`. Its cost is **the irreversibility and the blast radius**, and those are counted, not measured. **⟹ Applying `DELTA_BUDGET` to structural change (as the inherited design implicitly does by having no other budget) is a category error: it would let a scope make unlimited tiny structural changes, each individually negligible, accumulating into a total topology replacement — D-L1 with a graph.**
> **R61.2 is R9.2.4's principle (UDB over all admissible targets) applied to the budget that B5 does not cover.**

> ### **R61.3 — STRUCTURAL CHANGE HAS NO LEARNING RATE (R32.1) AND THEREFORE NO GRADIENT.**
> **Λ3 is event-driven.** There is no `lr_structural`, no `Δ_topology`, no continuous accumulation. **⟹ A topology change occurs as a discrete authorised event at a rung, or it does not occur.**
> **This closes the most dangerous mis-implementation available: a slow gradient on connection weights that, accumulated over enough epochs, crosses a threshold and silently deletes a connection.** Under R61.3 that is impossible — **weight decay to zero is an E0 Λ1 change; connection removal is an E3 Λ3 event requiring `ORGANISM` authority, CR-B ablation and a tombstone.** The two cannot be reached by the same mechanism.

## 61.3 Pruning, completely

| Requirement | Rule | Source |
|---|---|---|
| Authority | `ORGANISM` (E3) | §29, R61.1 |
| Causal attribution | **CR-B ablation MANDATORY** | R6.4.2, P0-01 §23.2 |
| Disuse cause | **`disuse_cause = IRRELEVANT`** — `UNREACHABLE` and `UNKNOWN` are insufficient | **R27.3** |
| Tombstone | **MANDATORY** — `{connection_id, removed_at, removed_by, ablation_ref, final_weight_digest, lineage_refs}` | **R27.2** |
| UDB consumption | **YES** — the tombstone's `final_weight_digest` enters the anchor computation | **R27.5** |
| Trace invalidation | **All CR-A traces at the scope are invalidated** | **R6.5.1** |
| Anchor invalidation | **Declared and propagated to lower scopes** | **R51.2** |
| Budget | **B6 count + blast radius** | **R61.2** |
| Reversibility | **`IRREVERSIBLE_STRUCTURAL`** — the weight and its history are gone; only the tombstone survives | A4 |
| Diversity | **Mandatory check if the pruning concentrates a region's specialisation** | **R46.3** |

> ### **R61.4 — PRUNING IS THE MOST HEAVILY GATED OPERATION IN THE LEARNING CONTRACT, AND IT SHOULD BE.**
> Ten requirements, of which the inherited design has **two** (V3 L54 names pruning as a plasticity operation; P0-01 §23.2 requires causal attribution for pruning/retirement). **Eight are new.**
> **The reason is R0.3: pruning is the learning system's only routinely-available *irreversible* action.** Everything else can be rolled back (§62). **Irreversibility is what authority tracks, so the irreversible operation carries the most authority, the most verification and the most accounting.** §84 rates "structural plasticity governance" 2/10 before, 9/10 after, on this evidence.

---

# 62. **[O43] ROLLBACK AND CHECKPOINT

## 62.1 The five reversibility classes, operationalised

| A4 class | **What it means** | **Rollback mechanism** | **Rollback authority** | **Rollback cost** | **Who may invoke** |
|---|---|---|---|---|---|
| **`DECAYS`** | The state returns to a prior value by its own horizon | **None required** | n/a | 0 | n/a (automatic) |
| **`ROLLBACKABLE_IN_MEMORY`** | The prior value is held in a live undo buffer | **Undo** | `SELF_LOCAL` | ~0 | the scope itself, or K |
| **`CHECKPOINT_REVERSIBLE`** | The prior state is in a checkpoint | **Restore to checkpoint** | K | moderate — everything after the checkpoint is also reverted | **K only** |
| **`VERSION_REVERSIBLE`** | The prior version is retained (P0-04 versioning; Λ2/Λ4) | **Revert to version** | `ORGANISM` / `[RO-13]` | moderate | governance |
| **`IRREVERSIBLE_STRUCTURAL`** | **No mechanism exists** | **∅** | — | — | — |

## 62.2 The three rollback triggers

| Trigger | Condition | Action | Inherited? |
|---|---|---|---|
| **RB-1 — VERDICT REGRESSION** | `improvement_verified = REGRESSED` | **Automatic rollback to `θ_anchor`** (R51.1 — to the *anchor*, not the immediately prior state) | ✅ Cell §9.6. **⟹ R62.1: rollback target is the most recent ANCHOR, not the most recent state.** *This is a correction: Cell §9.6 says "automatic rollback" without specifying the target, and rolling back one step at a time through a long unverified sequence is `O(k)` restores where one anchor restore is `O(1)` — and, more importantly, rolling back one step leaves the organism in another unverified state.* |
| **RB-2 — PROVISIONAL AGE EXHAUSTION** | `PROVISIONAL_AGE_3` reached with `verdict = UNKNOWN` | **Automatic rollback** | ❌ **NEW — R1.3.** Extends Cell §9.6's automatic rollback from *verified-bad* to *never-verified*. |
| **RB-3 — INVARIANT VIOLATION** | Any `LEARN-INV` breach (§68), ungoverned change (R23.3/LEARN-A1), missing rollback handle (§1.1), missing tombstone (R27.2) | **Automatic rollback + FINDING + audit entry** | ⚠️ Partial — Cell §8.2's I-class enforcement. **⟹ R62.2: an invariant violation rolls back to the most recent anchor AND freezes the scope pending governance review.** |

## 62.3 Checkpoints

> ### **R62.3 — A CHECKPOINT IS AN ANCHOR CANDIDATE, AND AN ANCHOR IS A VERIFIED CHECKPOINT.**
> **Not every checkpoint is an anchor.** A checkpoint is a state snapshot taken by K on a schedule or at a boundary. **It becomes `θ_anchor(S)` only when a probe returns `IMPROVED` or `NEUTRAL` against it.**
> **⟹ The two concepts are separated because they have different costs and different meanings: a checkpoint costs storage; an anchor costs a probe (B9). Conflating them would let the organism re-anchor by taking a checkpoint — which is a self-anchoring channel and defeats R0.1 entirely.**
> **This is the most important rule in §62, and the inherited design does not have it, because the inherited design does not have anchors.**

> ### **R62.4 — CHECKPOINT GRANULARITY IS A GOVERNANCE DECISION WITH A STRUCTURAL CONSEQUENCE.**
> Frequent checkpoints ⟹ fine rollback granularity ⟹ high storage cost. Infrequent ⟹ coarse ⟹ a rollback discards more verified work.
> **⟹ R62.4: checkpoint frequency is `[G]`-owned and its consequence is explicit — *the granularity of rollback is the granularity of verified-work loss.* ** A scope with infrequent checkpoints loses more on RB-1/RB-2/RB-3. **This is not a tuning problem; it is the storage/safety trade-off, stated rather than hidden, and it is `[G]` with `[D]` dependency on the cost model (P0-10). No value.**

> ### **R62.5 — ROLLBACK IS NOT A `LearnedChange`.**
> A rollback restores a prior state. **It does not produce a new one, does not consume B1/B2/B5, and does not require a trigger from T1–T8.** **⟹ But it MUST produce an audit record** (`rollback_ref`, `trigger ∈ {RB-1, RB-2, RB-3}`, `target_anchor`, `reverted_changes[]`), because **a rollback that is not recorded is an unobservable loss of history** — and §64's lineage requirement would fail.
> **⟹ R62.6: a rollback reverts `LearnedChange` records to `superseded_by = ROLLED_BACK` rather than deleting them. The lineage survives the state.** This is P0-04's principle that historical evidence is never rewritten, applied to the change log: **the organism may undo what it did; it may not undo the record that it did it.**

## 62.4 What cannot be rolled back

| Irreversible | Why | Mitigation |
|---|---|---|
| **E3 pruning** | The connection and its weight history are gone | **Tombstone (R27.2)** — audit survives, state does not |
| **E5 retirement** | The component is gone | **Full lineage audit (§64)** + P0-01 §23.2's retirement regime |
| **E7 topology change** | Regional structure is gone | Checkpoint at S4/S5 **before** the operation ⟹ **R62.7: an E6/E7 operation MUST be preceded by a checkpoint at its scope. An uncheckpointed E6/E7 is inadmissible.** |
| **CH-3 genome-diff acceptance** | The lineage inherits it | **11 gates + held-out validation + R25.2's spread floor + R25.4's diversity check** — i.e. **prevention, because reversal is unavailable** |
| **Observations caused** | The world has been altered | **Nothing. This is OR-L6.** |
| **Communications sent** | The recipient has been affected | **Nothing.** P0-03's plane separation limits *what* may be sent; it cannot unsend. |

> ### **R62.8 — THE LAST TWO ROWS ARE THE ARCHITECTURE'S IRREDUCIBLE IRREVERSIBILITY, AND THEY ARE THE REASON R36.2 AND R37.1 EXIST.**
> **An organism's effects on the world and on other agents cannot be rolled back.** Therefore the only available control is **prospective**: bound the reach of unverified change (R1.3), keep exploration inside the envelope (R36.2), and forbid irreversible exploration (R37.1).
> **⟹ ROLLBACK GOVERNS THE ORGANISM'S STATE. THE ENVELOPE GOVERNS THE ORGANISM'S EFFECTS. AN ARCHITECTURE WITH ONLY ROLLBACK IS UNSAFE, BECAUSE IT CAN UNDO ITSELF BUT NOT ITS CONSEQUENCES.** This is the deepest reason §0.2's finding matters: the inherited design had rollback (Cell §9.6) and no envelope, so it could undo a bad change after the change had already affected the world.

---

# 63. **[O44] OBSERVABILITY

## 63.1 The principle

> ### **R63.1 — EVERY BOUND, BUDGET, VERDICT, ENVELOPE AND CASCADE HAS A COUNTER, AND EVERY COUNTER IS K-COMPUTED AND READ-ONLY.**
> R52.1 lists sixteen counters. R63 adds the observability *contract* around them.
> **The principle, inherited from P0-04 §91 and P0-03's design: *what cannot be observed cannot be governed, and what the governed party computes cannot be trusted.***

## 63.2 The observability contract

| Property | Rule |
|---|---|
| **K-computed** | R52.2. No counter is written by the learning subsystem. |
| **Read-only to learning** | R52.2. **No counter is an input to `Δθ`.** A counter in the gradient is a learnable fitness term (R10.2). |
| **Globally visible** | R35.1. `O(6 × 22) + O(36)` ≈ 168 quantities (R52.3, §70.7). |
| **Scoped in origin** | Every counter is per-scope. **No counter requires cross-scope state** except the 36-cell correlation matrix, which aggregates scoped summaries (R35.2). |
| **Findings are non-binding** | R6.4.3, R33.2, R36.3, R48.3, R53.4, R57.6, R60.4. **A finding may be read by `[RO-13]`. It may not write anything.** |
| **Automatic responses are kernel actions** | Stall (R0.1), envelope shrinkage (R1.3), `plasticity_mult` reduction (R28.2), rollback (RB-1/2/3), freeze (R58.3). **These are not findings; they are K actions triggered by counters.** |
| **`stall_reason` is three-way** | R48.4: `PROBE_BUDGET_EXHAUSTED` / `UDB_EXHAUSTED_SC1_HEAVY` / `UDB_EXHAUSTED_SC3_HEAVY`. **Three causes, three governance responses.** |

## 63.3 The five cascade detectors

R39.4 unified five evidence-starvation cascades. Each now has a counter and a threshold:

| Cascade | Counter | Signature | Automatic response | Finding |
|---|---|---|---|---|
| **Abstention** (P0-04 L-11) | `abstention_rate[scope][context_class]` | rising at fixed context distribution | **R40.3 bounded exposure obligation** | `ABSTENTION_CASCADE` |
| **Failure→avoidance** | `avoidance_rate[scope][context_class]` + `error_class` distribution | rising avoidance with unclassified failures | R39.2 step 2 (diagnose) | `AVOIDANCE_CASCADE` |
| **Availability capture** | `retrieval_concentration[scope]` | monotone concentration | — (P0-04's regime) | `AVAILABILITY_CAPTURE` |
| **Pruning by disuse** | `E3_operations[scope]` + `disuse_cause` distribution | E3 rate rising with `UNKNOWN`/`UNREACHABLE` causes | **R27.3 blocks the operation** | `DISUSE_PRUNING_SUSPECT` |
| **Exploration starvation** | `EX_class_counts` + `B8` consumption + `stall_reason` | EX-1 falling while B8 unspent or unavailable | R36.3's finding route | `EXPLORATION_STARVATION` |
| **Immune quarantine** | `quarantine_rate[scope][threat_class]` | rising at fixed threat distribution | **R57.3 re-exposure obligation** | `QUARANTINE_CASCADE` |
| **Workspace homogenisation** | `workspace_diversity` | monotone decrease | **R60.5's reserved slots** | `WORKSPACE_HOMOGENISATION` |
| **Specialisation narrowing** | `diversity[population][dimension]` | approaching a floor | **R46.4 hard-constraint rejection** | `DIVERSITY_FLOOR_BREACH` |

> ### **R63.2 — EIGHT DETECTORS, ONE PATTERN, ONE GENERAL SHAPE.**
> **Every detector has the form: *a rate that should be stable under a fixed external distribution is drifting, while the external distribution is not.*** The drift is therefore internally caused, and internally-caused drift in an engagement rate is a cascade.
> **⟹ This is the general detector for R39.4's pattern, and it is `O(8)` counters rather than eight bespoke theories.** P0-04 found one cascade; P0-05 finds seven more and gives them one detector shape. **§86 reports this as the principal *positive* finding of the contract.**

## 63.4 What is NOT observable

| Unobservable | Why | Consequence |
|---|---|---|
| **Whether an external observation was caused by the organism** | OR-L6 / RH-2 | **The principal limit.** R33.2 and R53.4 detect *correlates*, not the fact. |
| **Whether a probe was gamed** | RH-7 | R9.4.1's secret schedule prevents *timed* gaming; it cannot detect behavioural difference under any observation. |
| **Cross-scope joint causation** | OR-L4 | R35.2's correlation monitor sees correlation, not causation. |
| **Whether abstention was correct** | OR-L5 | §40.3. Permanent asymmetry. |
| **Whether the self-model is accurate** | R59.2 (class 9) | Cannot be self-assessed, by design. |
| **Whether the fixed validation core is the right one** | R24.3 / OR-L2 | **A governance question, not an observable.** |

> ### **R63.3 — THE OBSERVABILITY BOUNDARY IS PART OF THE CONTRACT, NOT A GAP IN IT.**
> **Six things are unobservable, and each is unobservable for a stated structural reason rather than for want of instrumentation.** Per §87 (*do not hide unresolved problems*), they are listed here rather than omitted, and each maps to an OR-L entry in §81.

---

# 64. LINEAGE, CORRUPTION AND AUDIT

## 64.1 The lineage requirement

> ### **R64.1 — EVERY `LearnedChange` HAS A PREDECESSOR LINK AND A SIGNAL LINK, AND THE RESULTING GRAPH IS ACYCLIC.**
> `superseded_by` (§1.1) gives the change-to-change link; `signal_ref` gives the change-to-signal link; `anchored_at` gives the change-to-verification link. **⟹ Three link types produce a complete causal-accounting graph: *what changed, because of what signal, verified by what probe, superseded by what.***
> **Acyclicity is kernel-checked.** A cycle in the change graph means a change that caused itself — which is either a bug or RH-2 made explicit. **⟹ R64.2: a cycle is an invariant violation ⟹ RB-3 (rollback + freeze + finding).**

## 64.2 Lineage across structural change

| Event | Lineage consequence | Rule |
|---|---|---|
| **E3 pruning** | Changes referencing the connection lose their referent | **R27.2's tombstone preserves `lineage_refs`** — the graph survives the topology |
| **E5 retirement** | The component's entire change history becomes historical | **Full lineage audit required before retirement** (§29 E5) |
| **Rollback** | Reverted changes are marked, not deleted | **R62.6** |
| **Anchor invalidation (R51.2)** | Downstream changes lose their anchor | **Declared and propagated; affected scopes re-probe** |
| **CH-3 acceptance** | The lineage crosses into the genome | **The proposal's `LearnedChange` lineage is recorded in the tombstone-equivalent for the diff — ⟹ R64.3: a genome-diff carries the lineage of the verified changes that motivated it, WITHOUT their `source_class` (OR-M12).** *Motivation is recorded; warrant is not inherited.* |

## 64.3 Corruption of learned state

| Corruption vector | Defence | Status |
|---|---|---|
| **θ corruption (bit flip, storage fault)** | **B3 `Θ_MAX`, B4 homeostatic scaling, checksum** | **DETECTABLE** — a corrupted θ deviates from set-point and homeostasis responds (R58.4 makes this a leading indicator) |
| **Anchor corruption** | **Anchors are K-written and checksummed; a corrupted anchor invalidates UDB computation** | **⟹ R64.4: an unverifiable anchor is treated as ABSENT, not as valid. Absent anchor ⟹ `UDB = full displacement` ⟹ immediate stall.** **Fails safe: corruption produces MORE restriction, never less.** |
| **Counter corruption** | K-computed, checksummed | **⟹ R64.5: a corrupted counter fails safe — the kernel takes the MORE restrictive reading.** Same principle as R64.4 and P0-04 §91. |
| **Lineage corruption** | Acyclicity check + checksums | **RB-3** |
| **Tombstone corruption** | Checksum | **⟹ R64.6: a corrupted tombstone makes the corresponding E3 operation retroactively unauditable, which is an invariant violation at the scope, triggering freeze.** |
| **Probe-result corruption** | **EVA signature** (P0-01 §12.3, EIK-INV) | **CLOSED by signature** |
| **Signal corruption in transit** | **P0-03's TRANSPORT plane** | **CLOSED by inheritance** |
| **Deliberate corruption by a compromised component** | **The two-writer split (R54.2)** — a compromised learner can corrupt what it writes (`target`, `delta`, `trigger`) but not who authorised it, what verified it, or what it cost | **BOUNDED — the audit survives the compromise of the audited party. This is the point of R54.2.** |

> ### **R64.7 — THE FAIL-SAFE PRINCIPLE: CORRUPTION PRODUCES RESTRICTION, NEVER PERMISSION.**
> Every corruption response in this section moves the system toward *less* learning: absent anchor ⟹ stall; corrupted counter ⟹ restrictive reading; corrupted tombstone ⟹ freeze; invariant violation ⟹ rollback + freeze.
> **⟹ There is no corruption vector in the learning contract whose detection produces increased plasticity, increased envelope, increased budget or increased authority.** This is R28.2's asymmetry and R31.1's invariant extended to fault response, and it is P0-04 §91's degradation-ladder principle restated a third time. **§66 makes it the ladder.**

---

# 65. THE GOVERNANCE INTERFACE — IS THE LEARNING SYSTEM A HIDDEN GOVERNANCE LAYER?

§87: **DO NOT make the learning system a hidden governance layer.** §65 is the audit of whether V4 avoids it.

## 65.1 What "governance" means here

A **governance layer** is a mechanism that determines *what the organism may do, what it counts as having achieved, and who decides*. Four quantities constitute it:

1. **Authority** — who may authorise an action (the matrix §28, the ladder §29)
2. **Criteria** — what counts as success (fitness `F`, the fixed validation core R24.3, probe criteria R38.4)
3. **Budgets** — what resources are available (B1–B9, §30/§47)
4. **Invariants** — what may never happen (`LEARN-INV` §68, and all inherited invariant sets)

## 65.2 The audit — can learning reach any of the four?

| Governance quantity | Learning may write? | Rule | Mechanism of exclusion |
|---|---|---|---|
| **The authorization matrix (§28)** | ❌ | R19.2, R24.2, R28.1 | `[RO-13]` artifact, read-only to learning |
| **The escalation ladder (§29)** | ❌ | R24.2, R29.4 (kernel-enforced monotonicity) | Same |
| **`UDB_MAX`, B1–B9 bounds** | ❌ | R24.2, R47.2 | `[G]`/`[RO-13]` |
| **B9 allocation across scopes** | ❌ | **R47.2** | Allocation not learnable; failing scopes get tighter leashes automatically |
| **Fitness aggregation `F`** | ❌ | **R10.1** | `[RO-13]`; explicitly added to Cell §3.5's rejection list |
| **Fitness components' definitions** | ❌ | R10.1 | Same |
| **Probe criteria** | ❌ | **R38.4** | Part of the fixed core (R24.3) |
| **The fixed validation core** | ❌ | **R24.3, M3** | ∅ — no write path at any altitude |
| **Invariants** | ❌ | R24.2, R54.1 | ∅ |
| **`signal_kind` set** | ❌ | **R23.3, R53.9** | CLOSED enum |
| **`error_class` set** | ❌ | P0-01 §13 | CLOSED enum |
| **Λ4 parameters** | ❌ **write**; ⚠️ **select within bounds (M1)** | **R38.1** | Selection is learnable; the bound and the write are not |
| **`plasticity_mult`** | ❌ | Cell §4.1.8 | K-only |
| **`learning_enabled`** | ❌ | Cell §9.3 | EIK/organism only |
| **Evidence status, warrant, trust, `source_class`** | ❌ | R1.4, R12.1, R54.1, MEM-INV-19, COMM-INV-25 | Multiple independent |
| **Genome** | ❌ | §1.2, three layers | Type + capability + pathway |
| **Belief** | ✅ | **MEM-INV-18, R55.1** | **The one permitted epistemic write, and it cannot raise status** |
| **θ, weights, topology, representations** | ✅ | The matrix | **State, not governance** |

> ### **R65.1 — THE LEARNING SYSTEM WRITES STATE AND READS GOVERNANCE. IT NEVER WRITES GOVERNANCE.**
> **The table above has eighteen rows: sixteen governance quantities, each EXCLUDED — and the exclusion mechanism is *capability absence* in every case rather than *rule obedience* (§1.2's principle, applied uniformly) — plus two rows that are not exclusions because they are not governance quantities at all: belief at fixed evidence status, and internal state.**
> **The one write access learning has into anything epistemic is belief at fixed evidence status (R55.1) — and P0-04 established that this cannot reach warrant.**

## 65.3 The three residual routes by which learning could still govern

Honesty requires naming what the sixteen exclusions do **not** cover:

| # | Residual route | Mechanism | Containment |
|---|---|---|---|
| **1** | **Selection within bounds (M1)** | The meta-learner chooses *which* admissible `lr`, *when* to enter `SLOW_MODE`, *how* to allocate B2 across timescales. **Over enough choices, selection within bounds is de facto policy-setting.** | **R38.2 (M1 consumes `UDB_MAX[S5]`, the smallest budget), R38.3 (meta-objective not learnable), R38.4 (probe criteria fixed).** **BOUNDED, not closed.** |
| **2** | **Findings as influence** | Findings are non-binding (R63.2) — but a governance authority that *acts on* findings is being steered by the learner that produced them. **A learner that cannot write policy can still, in principle, generate findings that cause policy to be written.** | **⟹ R65.2: findings MUST carry their producing scope's counters and signal-class histogram, so that a governance authority can see whether the finding originates in an SC-1-dominated scope.** A finding from a self-referential scope is *legible as such*. **This is detection, not prevention — and prevention would require suppressing findings, which would be worse.** |
| **3** | **RH-2 / OR-L6** | The organism shapes the evidence that governance reads. | **§9.3 C-1…C-4, §56.2's ten containments. UNCLOSED.** |

> ### **R65.3 — THE LEARNING SYSTEM IS NOT A GOVERNANCE LAYER, AND THE ARCHITECTURE CAN SAY WHY RATHER THAN ASSERT IT.**
> **The reason is structural and it is R19.2: governance changes capacity, learning changes state, and the two never share a write path.** Every one of the sixteen exclusions is an instance of that separation. **The three residuals are not violations of it — they are places where *state* has *influence over* capacity, which is unavoidable in any adaptive system and is contained by making the influence legible (R65.2) rather than by pretending it does not exist.**

---

# 66. THE DEGRADATION LADDER

P0-04 §91 established: **«no failure mode produces a warrant increase.»** §66 is the learning-altitude ladder, and it is the summary form of R28.2, R31.1 and R64.7.

| Level | **Condition** | **Plasticity** | **Envelope** | **Learning** | **Budgets** | **Authority** | **Reversible by** |
|---|---|---|---|---|---|---|---|
| **L0 — NORMAL** | UDB < B5; verdicts resolving; no cascade signature | granted | full | at `lr[timescale]` | all available | per matrix | — |
| **L1 — CAUTIOUS** | T5 novelty · T7 failure · class-10 mismatch · metaplasticity | **reduced** | **shrunk (mandatory)** | continues | unchanged | unchanged | resolution of the trigger |
| **L2 — PROVISIONAL-AGED** | `PROVISIONAL_AGE_1/2` (R1.3) | unchanged | **LOCAL → NONE** | continues | unchanged | unchanged | **probe ⟹ re-anchor** |
| **L3 — CASCADE-FLAGGED** | any of R63.3's eight detectors fires | **reduced** | **shrunk** | continues **+ bounded exposure obligation (R40.3 / R57.3)** | **B8 may be granted** ← the one *increase*, and it is governance-granted | unchanged | `[RO-13]` action on the finding |
| **L4 — STALLED** | **UDB ≥ B5** | **zero at scope and below** | frozen | **halted** | B4 exempt (R15.2) | unchanged | **probe ⟹ re-anchor ONLY** |
| **L5 — FROZEN** | `learning_enabled ← FALSE` · homeostatic failure (R58.3) · invariant violation (RB-3) | **withdrawn** | none | **halted** | all suspended | **reduced** | EIK / organism |
| **L6 — RETIRED** | E5, after CR-B + full lineage audit | ∅ | ∅ | ∅ | ∅ | ∅ | **∅** |

> ### **R66.1 — THE LADDER IS MONOTONE: NO DOWNWARD TRANSITION INCREASES ANY GOVERNED QUANTITY.**
> **Formally, for every transition `L_i → L_{i+1}`: `plasticity ↓ or =`, `envelope ↓ or =`, `budgets ↓ or =`, `authority ↓ or =`.** **Kernel-enforced.**
> **The single apparent exception is L3's B8 grant — and it is not an exception, because the grant is made by `[RO-13]` (SC-4), not by the learning subsystem, and it is a *response to a detected cascade* rather than a *reward for a behaviour*. R28.2 prohibits *automatic* plasticity increase; R40.3's exposure obligation is precisely a governance-mandated counterweight to a cascade the architecture detected.**
> **⟹ R66.2: the ladder's invariant is *no failure mode produces a capacity increase that the failure itself caused.* A governance response to a detected failure is not the failure increasing its own capacity. The distinction is the writer: K and `[RO-13]` respond; the learner never does.**

> ### **R66.3 — THE LADDER IS THE ANSWER TO THE BRIEF'S §23 AND TO §86's PLASTICITY STATUS.**
> **Stability is not a parameter to be balanced against plasticity. It is a six-level monotone degradation ladder in which every loss of verification, every detected cascade, every budget exhaustion and every invariant violation moves the organism in exactly one direction — toward less capacity, less reach, less budget and less authority — and in which the only routes back up are external: a probe, a governance grant, or an EIK/organism decision.**
> **There is no internal route upward. That is the whole contract.**

---

# 67. VOLUME D — FINDINGS REGISTER

| ID | Finding | Severity | Disposition |
|---|---|---|---|
| **D-L56** | **Learned `routing_preference` selects the evaluator, and selecting the evaluator selects the warrant.** COMM-INV-25 is satisfied letter-by-letter and defeated in effect. | **CRITICAL — PARTIALLY UNCLOSED** | **CONTAINED by R53.3 (learning signals and probe inputs are governance-routed) + R53.4 (`EVALUATOR_SELECTION_SUSPECT`). Residual for ordinary messages ⟹ OR-L7.** |
| **D-L57** | **A learned reliability prediction could substitute for a measured transport metric.** | **HIGH** | **CLOSED by R53.5.** |
| **D-L58** | **Novelty gating of message admission would make manufactured novelty a DoS against the organism's own evidence supply.** | **HIGH** | **CLOSED by R53.6.** Would have been a 6th cascade instance. |
| **D-L59** | **A learned weight inside confidence aggregation would cross into warrant by aggregation.** | **HIGH** | **CLOSED by R53.1** (aggregation stays weight-free). *New rule; P0-03's aggregation has no weights to learn.* |
| **D-L60** | **A `LearnedChange` could edit its own audit fields.** | **CRITICAL** | **CLOSED by R54.2** (two-writer split; COMM-INV-23 applied to the change record). |
| **D-L61** | **Warrant magnitude could scale gradient magnitude**, making warrant-gaining a plasticity-gaining channel. | **HIGH** | **CLOSED by R54.3** (warrant changes signal *class*, never gradient *size*). |
| **D-L62** | **Belief revision could be a non-learning operation**, permitting unbounded self-persuasion at zero budget cost. | **HIGH** | **CLOSED by R55.2** (belief change is displacement) **+ R55.3** (inbreeding_F over learning lineage). |
| **D-L63** | **The epistemic-promotion chain via memory.** | **CRITICAL** | **CLOSED TWICE by P0-04** (inert links 2–4 via MEM-INV-50/09; blocked links 4–6 via X3 and R0.2). **R56.1. No new rule needed.** |
| **D-L64** | **The epistemic-promotion chain via causation** (learning → behaviour → world → genuine external evidence → verification of the learning that caused it). | **CRITICAL — UNCLOSED** | **CONTAINED by ten mechanisms (§56.2). OR-L6. The binding limit of the contract.** |
| **D-L65** | **Immune quarantine is an evidence-starvation cascade by design** — the immune system's function is to reduce exposure. | **CRITICAL** | **CLOSED by R57.1–R57.6**, principally **R57.3 (re-exposure obligation)** and **R57.4 (quarantine reduces envelope, never capacity)**. |
| **D-L66** | **Quarantine could become permanent deletion without a tombstone.** | **HIGH** | **CLOSED by R57.2 + R57.3.** Residual: the re-exposure rate is `[G]` with no value. **Declared.** |
| **D-L67** | **Learning could alter a homeostatic set-point**, converting the stability floor into a learnable quantity. | **CRITICAL** | **CLOSED by R15.3 + R58.2 + R58.5** (the floor is unlearned by definition). |
| **D-L68** | **The self-model could update from the learner's own account of what it did.** | **CRITICAL** | **CLOSED by R59.1 (metered, not intended), R59.2 (class 9, not self-assessable), R59.3 (no self-input; replaced, not revised).** |
| **D-L69** | **V3.1 §10's "full awareness loop" uses a biological metaphor as a mechanism substitute.** | **MEDIUM** | **DECOMPOSED by R59.4** into SC-2 metering (permitted) and SC-1 self-assessment (prohibited as a learning driver). Rule 5 and Rule 3 of the 20 discharged. |
| **D-L70** | **A learned broadcast preference could homogenise the workspace**, correlating every scope's signals. | **HIGH** | **CLOSED by R60.4 (counter), R60.5 (reserved governance slots), R60.6 (per-scope fraction cap).** 7th cascade instance. |
| **D-L71** | **V3 L54's five plasticity operations span three rungs and two authorities in one sentence.** | **HIGH** | **CLOSED by R61.1** (R4.1 applied to V3's own vocabulary). LEARN-A6. |
| **D-L72** | **A slow weight gradient could accumulate into a silent connection deletion.** | **CRITICAL** | **CLOSED by R61.3** (Λ3 is event-driven; no structural learning rate exists). |
| **D-L73** | **`DELTA_BUDGET` applied to structural change permits unlimited tiny structural changes.** | **HIGH** | **CLOSED by R61.2** (B6 is a count and a blast-radius bound, not a magnitude). |
| **D-L74** | **Cell §9.6's "automatic rollback" does not specify the rollback target.** | **HIGH** | **CLOSED by R62.1** (rollback to the most recent ANCHOR, not the prior state). |
| **D-L75** | **A checkpoint could be treated as an anchor**, permitting self-anchoring. | **CRITICAL** | **CLOSED by R62.3** (an anchor is a *verified* checkpoint; a checkpoint is only a candidate). |
| **D-L76** | **Rollback could delete the change log**, making history loss unobservable. | **HIGH** | **CLOSED by R62.5 + R62.6** (`superseded_by = ROLLED_BACK`; the lineage survives the state). |
| **D-L77** | **E6/E7 operations could proceed uncheckpointed**, making them irreversible *and* unrecoverable. | **HIGH** | **CLOSED by R62.7** (mandatory preceding checkpoint). |
| **D-L78** | **Rollback governs state but nothing governs effects on the world and on other agents.** | **CRITICAL — INHERENT** | **CLOSED prospectively by R1.3 + R36.2 + R37.1 (R62.8).** Not reversible; **bounded before the fact.** |
| **D-L79** | **A corrupted anchor or counter could be read as valid**, producing less restriction. | **HIGH** | **CLOSED by R64.4/R64.5** (fail safe: corruption ⟹ restriction) **+ R64.7** (the general principle). |
| **D-L80** | **The change graph could contain a cycle** (a change that caused itself). | **HIGH** | **CLOSED by R64.1 + R64.2** (acyclicity kernel-checked; cycle ⟹ RB-3). |
| **D-L81** | **Meta-selection within bounds is de facto policy-setting over enough choices.** | **HIGH — BOUNDED** | **R38.2/R38.3/R38.4. Not closed (§65.3 residual 1).** |
| **D-L82** | **Findings could steer governance** even though they are non-binding. | **MEDIUM — BOUNDED** | **R65.2** (findings carry their producing scope's signal-class histogram, so self-referential origin is legible). Detection, not prevention. |
| **OR-L7** | Learned routing selects evaluators for ordinary (non-learning-signal) messages. | **OPEN RESEARCH** | **§81.** |

---

**END OF VOLUME D.**
**Next:** `44_analysis_attacks_formal.md` — Vol E (§67–§72): the adversarial attack catalogue (**[O45]**, 60+ attacks), the `LEARN-INV` invariant set (**[O46]**), formal state machines (**[O47]**), and the parameter registry with dependency graph (**[O48][O49]**).
