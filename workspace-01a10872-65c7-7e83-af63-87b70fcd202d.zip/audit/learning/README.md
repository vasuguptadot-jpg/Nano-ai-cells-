# P0-05 — LEARNING, PLASTICITY & ADAPTATION CONTRACT
## Executive Summary, Output Index, Ratings and FINAL STANDARD

**Reference conventions.** Rule numbers (`Rn.m`) are scoped to the section in which they are defined. Where a number collides with a prior contract's numbering — notably **R47.1** (P0-05: *the probe budget is the learning rate* / P0-04: *the Lamarckian prohibition*), **R46.1** (P0-04: memory-policy variation) and **R12.1–R12.6**, **R9.1** (P0-01: the reward contract) — **the source contract is named at the point of use.** Finding IDs are `D-Lnn`; contradictions `X-Lnn`; circular dependencies `CD-Lnn`; open research `OR-Lnn`; attacks `LEARN-Xnn`; invariants `LEARN-INV-nn`; ablations `AB-nn`. All enumerated sets were machine-recounted before publication.

**Deliverable set (8 files):**

| File | Contents |
|---|---|
| `40_analysis_learning_foundations.md` | **Vol A** §0–§18 — root finding, the `LearnedChange` object, candidate definitions compared, Λ taxonomy, scope hierarchy, the V4 loop, credit assignment, reward taxonomy, reward hacking, reward↔fitness/memory/belief, prediction error, novelty, homeostasis, multi-scale |
| `41_analysis_signals_authority.md` | **Vol B** §19–§34 — signal taxonomy, provenance, authenticity, independence, trigger re-audit, learning↔evolution, Baldwinian boundary, genome interface, forgetting, **the plasticity authorization matrix**, **the escalation ladder**, budgets, stability/plasticity, timescales, volatility, the fourth-plane question |
| `42_analysis_exploration_knowledge.md` | **Vol C** §35–§52 — local vs global, exploration, safe exploration, meta-learning, failure learning, the abstention cascade, memory↔plasticity, simulation, distillation, transfer, curriculum, specialisation, budget economics, self-training/collapse, offline learning, consolidation, interference, aggregation |
| `43_analysis_governance_structural.md` | **Vol D** §53–§66 — the seven interface contracts, the epistemic-promotion chains, immune, homeostasis, self-model, global workspace, structural plasticity, rollback/checkpoint, observability, lineage/corruption/audit, **the hidden-governance-layer audit**, the degradation ladder |
| `44_analysis_attacks_formal.md` | **Vol E** §67–§72 — **70 attacks**, **42 `LEARN-INV` invariants**, **7 state machines**, **the 100-entry parameter registry**, the dependency graph and three near-cycles, implementation independence |
| `45_analysis_audit_scale.md` | **Vol F** §73–§82 — 7 candidate architectures, **19 contradictions**, **13 circular dependencies**, scalability, portability, conformance levels, **32 ablations**, the false-precision audit, **10 open research entries**, **17 gaps** |
| `46_v4_learning_plasticity_adaptation_spec.md` | **★ [O59] THE CANONICAL ARTIFACT — V4 Learning, Plasticity & Adaptation Contract v1.0** |
| `README.md` | **[O1]** verdict · the 59-output index · **§84** ratings · **§85** principles · **§86** FINAL STANDARD |

---

# §83 — **[O1] EXECUTIVE VERDICT

## The verdict

> ### **The inherited learning design is the strongest-specified and weakest-governed subsystem in the corpus.**
>
> **Cell Contract §9 is, by a wide margin, the most rigorous learning specification this series has encountered.** It already establishes four rules most architectures never reach: a cell may not generate its own reward; a peer's error report is evidence, not instruction; **a cell may not decide whether its own learning helped**; and internal error estimates may drive provisional but never permanent change. **This audit does not attack those. It attacks what is missing around them.**
>
> **What is missing is a consequence.** Cell §9.6 gives a change an accounting verdict — `improvement_verified ∈ {UNKNOWN, IMPROVED, NEUTRAL, REGRESSED}` — and nothing in V3, V3.1, the Cell Contract, P0-01, P0-03 or P0-04 makes that verdict *bind*. A `PROVISIONAL` change has already been applied: it has already altered θ, already altered behaviour, already altered what observations occur, and already become the substrate on which the next update is computed. **"Provisional" is a label about accounting, not about effect.**
>
> And because `DELTA_BUDGET` resets every epoch, **it bounds the rate of learning and not the distance travelled.** An organism can migrate indefinitely far from any state that has ever been confirmed to work — one fully compliant epoch at a time, with `improvement_verified = UNKNOWN` at every step, which is a *permitted* verdict and therefore never an alarm. **At the scale this architecture is designed for, where probing most updates is infeasible, `UNKNOWN` is the default verdict and `PROVISIONAL` is the permanent state of every learned change.**

## The correction

> ### **R0.1 — THE UNVERIFIED-DISPLACEMENT BOUND.** A learned state has **two** magnitudes. Parameter magnitude is bounded (inherited). **Unverified displacement — `‖θ_now − θ_anchor‖`, where the anchor is the most recent state whose benefit was externally verified — was not.** Bound it, and on breach **STALL**: not slow, *stop*, until a probe re-anchors.
>
> **This one rule does six things the inherited design could not:**
> 1. **It converts Cell §9.6's `[U]` probe-cost problem from a hidden statistic into an explicit architectural quantity.** The contract does not say how often to probe. It says *what happens when you don't* — and makes that consequence structural, scoped, observable and named. **The probe budget becomes the learning rate of the organism.**
> 2. **It bounds model collapse with no new mechanism.** Collapse is unverified displacement; each self-training round consumes UDB at the higher SC-1 weighting; the scope stalls. **The architecture needs no collapse detector — it needs the stall, which it has.**
> 3. **It makes transfer expensive by construction.** A transferred state arrives unanchored, therefore at full UDB consumption. **Verification is not transferable** — and the debt is now visible rather than laundered.
> 4. **It conserves displacement under every escape route**: off θ (R9.2.4), through decay (R15.4), through deletion (R27.5), through metaplasticity (R34.3), through calibration (R23.2). **That conservation property — not any individual bound — is the actual content of the fix.**
> 5. **It supplies the missing axis.** Reversibility was never a property of a change anywhere in the corpus, so authority had nothing to scale with except magnitude. **A4 gives R0.3 its argument and the escalation ladder (E0–E9) its shape.**
> 6. **It gives the loop a halt condition.** V3's master loop is a cycle with no exit. A loop diagram without a halt condition is the visual form of unbounded drift.

## The second correction

> ### **The inherited design governs *learning events* thoroughly and governs *plasticity capacity* in exactly one place** — Cell §4.1.8's "`plasticity_multiplier` K-only". **One rule. No matrix. No account of which components at which scales may hold which capacities, or of how a capacity is granted, reduced or withdrawn.**
>
> **That is the largest single governance gap in the inherited learning design, and it is the gap through which every "learning system becomes hidden governance" attack passes.** §28's authorization matrix fills it — a `scope × target` grid of thirty cells in which **eleven are outright prohibitions and three more admit nomination or proposal only**, leaving just sixteen unrestricted writes — and where **the ∅ cells are the mechanism**: a capability that does not exist cannot be abused.
>
> The matrix yields the contract's directional core: **reduction is automatic and permissionless; increase is never automatic.**
> ### **NO FAILURE MODE, INTERNAL SIGNAL, OR SELF-OBSERVATION PRODUCES A PLASTICITY INCREASE.**
> This is P0-04 §91's *"no failure mode produces a warrant increase"* transplanted to learning, and it has a stated cost: **the organism cannot decide to learn harder when it notices it is doing badly.** Repeated failure *reduces* plasticity (Cell T7). The legitimate route to "try harder" is a governance-granted exploration budget, not a plasticity increase — **because an ε the learner controls is a reward it mints.**

## The finding this contract could not close

> ### **RH-2 — EVALUATOR MANIPULATION — IS THE ONLY OPEN ATTACK OF SEVENTY, AND IT IS NOT CLOSABLE.**
>
> The organism cannot forge a reward, cannot transmit credit, cannot self-verify, cannot rewrite provenance, cannot write its own bounds. **But the evaluator evaluates the organism's outputs in the world, and the organism controls its outputs.** So it produces outputs that cause the evaluator's ground truth to be favourable — not by deceiving the evaluator, but by **arranging the world the evaluator samples.**
>
> The chain is: learning → behaviour → altered world → **genuinely external, signed, correctly-classed, pre-registered, held-out** observations → verification of the learning that caused them. **Every link is individually compliant. The whole is a closed loop in which the organism manufactures the conditions of its own verification.**
>
> P0-04 found this as OR-M18 (the selection⟷filtering circle). **P0-05 finds it in sharpened form: learning is not merely adjacent to the circle — learning is the *mechanism* by which the filtering happens.**
>
> **Ten containment mechanisms are directed at it and none closes it.** The architecture's claim is narrower and is the only honest one available: **RH-2 is named, observable, rate-limited, and never rewarded.** *Authenticity is a property of a signal's fields; soundness is a property of its causal history. The architecture can guarantee the first and can only bound and observe the second.*
>
> **Per §87: do not assume an external evaluator eliminates all feedback-loop problems. It does not. This is the finding.**

## The pattern this contract generalises

> ### **P0-04 found one evidence-starvation cascade (L-11, abstention). P0-05 finds seven more and shows they are one pattern.**
>
> Abstention · failure→avoidance · availability capture · pruning by disuse · exploration starvation · immune quarantine · workspace homogenisation · specialisation narrowing.
>
> **General form:** `engagement ↓ ⟹ corrective_evidence ↓ ⟹ estimated_competence ↓ ⟹ engagement ↓`. Positive loop gain, no external term. **General detector:** *a rate that should be stable under a fixed external distribution is drifting, while the external distribution is not.* **Eight counters, one detector shape — not eight bespoke theories.**
>
> **And the general counterweight, which is the dual of P0-04's:**
> ### **P0-04 §90 GRANTS BOUNDED OPTIMISM: PERMISSION TO ACT WITHOUT WARRANT.**
> ### **P0-05 R40.3 IMPOSES BOUNDED EXPOSURE: OBLIGATION TO ACT WITHOUT COMPETENCE.**
> **Both `[G]`-owned, both capped, both observable — and both existing because a system that only acts on verified warrant converges on silence.**

## The structural result

> ### **ELEVEN OF THIRTEEN CIRCULAR DEPENDENCIES ARE BROKEN BY *WRITER SEPARATION*, NOT BY A BOUND.**
> The plasticity loop, the calibration loop, the specialisation loop, the workspace loop, the self-model loop, the meta-objective loop, the validator loop, the verification-cost loop, the availability loop, the cascade loop, the findings loop — **in every case the cycle is broken by ensuring that the edge which closes it is written by a party outside the loop.**
>
> ### **A BOUND CANNOT BREAK A CYCLE — IT CAN ONLY MAKE THE CYCLE SMALLER. ONLY A WRITER SEPARATION CAN BREAK ONE.**
>
> **The two that cannot be broken this way are the validator loop (OR-L2) and the evidence loop (OR-L6) — and in both, the closing edge is written by the world or by governance's own judgement, neither of which can be moved outside the loop without removing the organism's agency or the governance authority's competence.**
>
> **Corollary for every future contract in this series: when a circular dependency is found, the first question is not "what bound limits it?" but "who writes the edge that closes it, and can that writer be moved outside the loop?"**

## The answer to the central question

> **What is the minimum architecture that allows the Digital Brain to change its internal state, parameters, topology, behavior, and future learning from experience without allowing internally generated signals to become uncontrolled authority over the organism?**
>
> ### **Change is a governed object with four axes — target, authorization, provisionality, reversibility.**
> ### **Authority scales with irreversibility, never with magnitude.**
> ### **Cumulative unverified distance from the last externally verified state is bounded, and its exhaustion halts learning.**
> ### **Internally generated signals are admissible for provisional, envelope-limited, UDB-accounted change and for nothing else — never for an anchor, a verdict, a warrant, a fitness component, a budget, a bound, or a governance quantity.**
> ### **And the mechanism that grants the capacity to change sits outside the loop that the capacity governs.**
>
> **The last clause is the minimum.** Everything else makes the loop *safe to run*. Only P7 makes it *unable to authorise itself* — **because a learner inside its own governance loop is a governance layer, however well bounded.**

## The scorecard

| | |
|---|---|
| **Attacks catalogued** | **70** — **52 closed-family** (35 CLOSED + **17 CLOSED-STRUCTURAL**: no object exists to attack) · 5 conditional · 12 bounded · **1 open** |
| **`LEARN-INV` invariants** | **42** in 7 groups — 21 certifiable by inspection or unit test alone |
| **State machines** | **7** — 58 states, 106 transitions; every invariant asserted by ≥1 machine, no orphans |
| **Parameter registry** | **100 entries** — 58 settable · 22 counter families · **20 that DO NOT EXIST** · **0 numerical values** |
| **Contradictions audited** | **19** — 11 resolved · 5 dissolved · 2 proposed (pending cross-contract ratification) · 1 decomposed · **0 open** |
| **Circular dependencies** | **13** — 6 closed · 1 partially · 2 conditional · 2 bounded · **2 contained, not closable** |
| **Ablations** | **32** — **0 with no consequence**; 16 critical, 15 high, 1 medium-high |
| **Rule inventory** | **254 distinct numbered rules cited or defined** across the six volumes — new P0-05 rules plus rules inherited from P0-01…P0-04, each cited with its source contract where ambiguity is possible |
| **Open research** | **10 entries** — none resolved by a constant; 3 declared *in-place* at the point of use |
| **Gaps** | **17** — 5 P0, 7 P1, 5 P2; **no P0 gap is internal to P0-05** |
| **Conformance** | **CL-2 achievable today; CL-3 blocked by OR-L3 alone** |

---

# §83.1 — THE 59-OUTPUT INDEX

| # | Required output | Where | Status |
|---|---|---|---|
| **O1** | Executive verdict | **§83 (this file)** | ✅ |
| **O2** | Definition of learning | Vol A **§2.1** | ✅ |
| **O3** | Definition of plasticity | Vol A **§2.2** | ✅ |
| **O4** | Definition of adaptation | Vol A **§2.3** | ✅ |
| **O5** | Learning taxonomy | Vol A **§4.1** (Λ0–Λ4 + Λ5 prohibition) | ✅ |
| **O6** | Plasticity hierarchy | Vol A **§4.2** (R4.2, S1–S6) + Vol B **§28** | ✅ |
| **O7** | Learning-loop architecture | Vol A **§5.2 / R5.3** | ✅ |
| **O8** | Learning-signal taxonomy | Vol B **§19** (SC-0…SC-4 × SG-1…SG-14) | ✅ |
| **O9** | Reward taxonomy | Vol A **§8** (RW-1…RW-8) | ✅ |
| **O10** | Reward ↔ fitness contract | Vol A **§10** (R10.1–R10.3.4) | ✅ |
| **O11** | Reward ↔ memory contract | Vol A **§11** (R11.1–R11.3) | ✅ |
| **O12** | Reward ↔ belief contract | Vol A **§12** (R12.1–R12.3) | ✅ |
| **O13** | Prediction-error architecture | Vol A **§13** (R13.1–R13.3) | ✅ |
| **O14** | Novelty / surprise architecture | Vol A **§14** (R14.1–R14.5) | ✅ |
| **O15** | Credit-assignment architecture | Vol A **§6** (R6.4.1–R6.5.1) | ✅ |
| **O16** | Local vs global | Vol C **§35** (R35.1–R35.4) | ✅ |
| **O17** | Signal provenance | Vol B **§20** (R20.1–R20.5) | ✅ |
| **O18** | Signal authenticity | Vol B **§21** (R21.1) | ✅ |
| **O19** | Signal independence | Vol B **§22** (R22.1–R22.2) | ✅ |
| **O20** | Plasticity authorization matrix | Vol B **§28** (R28.1–R28.2) | ✅ |
| **O21** | Structural-change escalation | Vol B **§29** (E0–E9, R29.1–R29.4) + Vol D **§61** | ✅ |
| **O22** | Homeostatic plasticity | Vol A **§15** (R15.1–R15.10) | ✅ |
| **O23** | Stability / plasticity | Vol B **§31** (R31.1) + Vol A §15.3 | ✅ |
| **O24** | Exploration / exploitation | Vol C **§36** (R36.1–R36.5) | ✅ |
| **O25** | Safe exploration | Vol C **§37** (R37.1–R37.3) | ✅ |
| **O26** | Failure learning | Vol C **§39** (R39.1–R39.4) | ✅ |
| **O27** | Abstention cascade | Vol C **§40** (R40.1–R40.6) | ✅ |
| **O28** | Memory ↔ plasticity | Vol C **§41** (R41.1–R41.5) | ✅ |
| **O29** | Learning ↔ communication | Vol D **§53** (R53.1–R53.9) | ✅ |
| **O30** | Learning ↔ provenance | Vol D **§54** (R54.1–R54.3) | ✅ |
| **O31** | Learning ↔ belief | Vol D **§55** (R55.1–R55.3) | ✅ |
| **O32** | Learning ↔ immune | Vol D **§57** (R57.1–R57.7) | ✅ |
| **O33** | Learning ↔ homeostasis | Vol D **§58** (R58.1–R58.5) | ✅ |
| **O34** | Learning ↔ self-model | Vol D **§59** (R59.1–R59.4) | ✅ |
| **O35** | Learning ↔ Global Workspace | Vol D **§60** (R60.1–R60.6) | ✅ |
| **O36** | Learning ↔ evolution | Vol B **§24** (CH-1…CH-4, R24.1–R24.3) | ✅ |
| **O37** | Baldwinian boundary | Vol B **§25** (R25.1–R25.4) | ✅ |
| **O38** | Meta-learning | Vol B **§24/R24.3** (authority) + Vol C **§38** (capability, R38.1–R38.4) | ✅ |
| **O39** | Self-training | Vol C **§48** (R48.1–R48.5) | ✅ |
| **O40** | Simulation learning | Vol C **§42** (R42.1–R42.5) | ✅ |
| **O41** | Knowledge transfer | Vol C **§44** (R44.1–R44.3) + §43 (R43.4) | ✅ |
| **O42** | Specialisation / diversity | Vol C **§46** (R46.1–R46.4) | ✅ |
| **O43** | Rollback / checkpoint | Vol D **§62** (R62.1–R62.8) | ✅ |
| **O44** | Observability | Vol D **§63** (R63.1–R63.3) + Vol C §52 | ✅ |
| **O45** | 60+ adversarial attacks | Vol E **§67** — **70 attacks, 8 groups** | ✅ |
| **O46** | `LEARN-INV` invariants | Vol E **§68** — **42 invariants, 7 groups** | ✅ |
| **O47** | Formal state machines | Vol E **§69** — **7 machines, 58 states, 106 transitions** | ✅ |
| **O48** | Parameter registry | Vol E **§70** — **100 entries, 0 values** | ✅ |
| **O49** | Parameter dependency | Vol E **§71** (R71.1, 3 near-cycles) | ✅ |
| **O50** | Circular dependency audit | Vol F **§75** — **13 cycles** | ✅ |
| **O51** | Scalability | Vol F **§76** (R76.1–R76.2) | ✅ |
| **O52** | Hardware portability | Vol F **§77** (R77.1–R77.4) | ✅ |
| **O53** | Ablation | Vol F **§79** — **32 ablations** | ✅ |
| **O54** | Cross-system contradiction audit | Vol F **§74** — **19 contradictions** | ✅ |
| **O55** | Conformance / testability | Vol F **§78** (CL-0…CL-4) | ✅ |
| **O56** | Implementation independence | Vol E **§72** (R72.1–R72.6) | ✅ |
| **O57** | P0/P1/P2 gaps | Vol F **§82** — **17 gaps** | ✅ |
| **O58** | Open research register | Vol F **§81** — **10 entries** | ✅ |
| **O59** | **Canonical V4 spec** | **`46_v4_learning_plasticity_adaptation_spec.md`** | ✅ |

**59 / 59 discharged.**

---

# §84 — BEFORE / AFTER RATINGS

**R80.1 qualification, restated so these cannot be misread:** *these are ORDINAL judgements about **specification completeness** — how thoroughly the contract governs a dimension. **They are not measurements of system quality, performance, safety or capability.** A 9/10 means "the contract specifies this thoroughly and the specification survives adversarial audit," not "the system will do this well."*

| # | Dimension | **Before** | **After** | Basis for the change |
|---|---|---|---|---|
| 1 | **Definition of learning** | 3/10 — V3.1 L112 defines learning as "experience-driven adaptation through plasticity and memory": an event defined as an outcome mediated by a capacity (X-L16). No authority content. | **9/10** | Nine candidate meanings compared (§2); C9 adopted with every clause load-bearing; R3.1's substitution test. |
| 2 | **Definition of plasticity** | 2/10 — used as a synonym for learning throughout V3 §8/§14 and V3.1 §6. Never separated as a *capacity*. | **9/10** | §2.2 separates capacity from event; §28 gives it a governance artifact. |
| 3 | **Definition of adaptation** | **1/10** — no inherited text distinguishes homeostasis from reflex from learning from evolution. `SLOW_MODE` is the closest and is a plasticity mechanism. | **8/10** | R2.3's four-mechanism partition with different verification regimes; R2.3's fourth clause makes V3.1 §8's bridge governable. |
| 4 | **Learning taxonomy** | 4/10 — V3 §15 separates learning from evolution; nothing separates parameter from representation from structural from policy change. | **9/10** | Λ0–Λ4 + Λ5 prohibition, with authorization floor, reversibility floor and verification method per class; R4.1 disjointness. |
| 5 | **Plasticity hierarchy / scopes** | **2/10** — V3.1 §6 names five scales with **no authority, budget, reversibility or target set for three of them**, and omits organismal entirely while §7 varies organismal quantities (X-L4). "Synapse" and "connection" double-counted. | **8/10** | R4.2's six scopes ordered by blast radius with authority attached; R16.1–R16.3; R18.2's counter-intuitive monotone-decreasing `UDB_MAX`. |
| 6 | **Learning loop** | 4/10 — V3's master loop (L332–344) is a cycle with **no verification box and no halt condition**, and draws error/reward/novelty as peers against P0-01 §12.1's explicit rejection. | **9/10** | §5.2's V4 loop with signal admission, UDB check, verification gate and nomination-only exit; R5.3's seven properties. |
| 7 | **Signal taxonomy & authority** | 3/10 — Cell §9.2's T1–T8 is a good trigger set with **no origin/warrant classification**; V3 §8's «successful use» has no origin at all. | **9/10** | SC-0…SC-4 × SG-1…SG-14; R19.1 (origin × effect, never content); R19.3's peer-report firewall; R23.2's T8 finding. |
| 8 | **Reward contract** | **7/10** — P0-01 §12 is already strong (EVA_ONLY, vector, DENSE prohibited, four reward≠ separations). | **9/10** | R8.1's eight-kind taxonomy with four prohibitions; R8.2's corollary (no scalarisation inside the learner); §9's 12-class hacking taxonomy. |
| 9 | **Credit assignment** | 5/10 — COMM-INV-20 (credit computed never transmitted) and P0-01 §23.2 (causality only for pruning) are strong; **`UNATTRIBUTABLE` had no consequence** (D-L7). | **9/10** | R6.4.1's scoped credit (defeats O(N²) by type-level absence); R6.4.2's three regimes selected by reversibility; R6.4.3's escalating finding; R6.4.4's relief valve. |
| 10 | **Prediction error** | 5/10 — Cell T1 and P0-01 §13 exist; **no pre-registration requirement**, so hindsight error was available. | **9/10** | R13.1 (pre-registration, kernel-checked); R13.2 (unresolvable ≠ zero); R13.3 (not causality, L6 ceiling ⟹ cannot reach S3). |
| 11 | **Novelty / surprise** | **2/10** — one name for two quantities with different grounds; novelty is trivially manufacturable and has **positive** authority in V3 §8 and V3.1 §9. | **9/10** | R14.1's separation; R14.2 (novelty may only reduce plasticity); R14.3 (surprise teaches, novelty slows); R14.4/R14.5. |
| 12 | **Plasticity governance / authorization** | **2/10** — **one rule** (Cell §4.1.8). No matrix, no grant/reduce/withdraw protocol, no prohibitions. | **9/10** | §28's matrix with sixteen ∅-cells; R28.2's directional asymmetry; §29's E0–E9 ladder with four monotonicity rules. |
| 13 | **Stability / plasticity** | 4/10 — Cell §9.5's seven mechanisms are good but framed as a scalar trade-off, and `SLOW_MODE` reduces *rate* under distribution shift (backwards). | **9/10** | R15.9 (two quantities, two owners); R15.10 (reduce reach, not rate); R31.1's directional invariant; §66's six-level ladder. |
| 14 | **Provisionality & verification** | **3/10** — Cell §9.6 defines the verdict and **nothing consumes it**; `[U]` leaves probe policy undefined; provisional changes have full effect. | **9/10** | R0.1 (UDB + stall); R1.3 (envelope shrinkage); R47.1 (B9 is the learning rate); R48.4 (three stall reasons). |
| 15 | **Reversibility / rollback** | **2/10** — **reversibility was never a property of a change anywhere in the corpus.** Cell §9.6 mandates rollback without specifying the target; no checkpoint/anchor distinction; no tombstone. | **9/10** | A4 axis; R0.3; R62.1 (target = anchor); R62.3 (checkpoint ≠ anchor); R27.2 (tombstone); R62.6 (mark, never delete); R62.8 (rollback governs state, envelope governs effects). |
| 16 | **Exploration** | **1/10** — **the inherited design has exploitation and no exploration.** V3 §14 slows under novelty; V3 §18 specialises under demand; both move toward the familiar. | **8/10** | B8 as budget not reward; R36.4 (measured by resolved predictions); R36.5 (no ε); R37.1–R37.3 (safe exploration). |
| 17 | **Evidence-starvation cascades** | **2/10** — P0-04 found one instance (L-11) with a bounded-optimism counterweight; **no general pattern, no detector, no counterweight on the learning side.** | **8/10** | R39.4's general definition; eight instances unified; R63.2's single detector shape; R40.3/R57.3's bounded exposure obligation; R40.6's duality. |
| 18 | **Learning ↔ evolution boundary** | **8/10** — the strongest boundary in the corpus: V3 §15/§16, V3.1 §8, Cell §3.4/§3.5, MEM-INV-21, R47.1. Six documents state it. | **9/10** | Four channels formalised; R24.2's rejection list extended by four; R24.3's fixed validation core; R25.1's Baldwinian test; R25.2–R25.4 close three boundary failure modes. |
| 19 | **Observability & audit** | 3/10 — Cell §9.6's verdict and P0-03's plane metrics exist; **no change-level audit trail, no cascade counters, no lineage graph, no stall-reason differentiation.** | **9/10** | 22 K-computed counter families at `O(1)` per organism; R54.2's two-writer split; R64.1's acyclic lineage; R63.3's eight detectors; R64.7's fail-safe principle. |

**Aggregate: before 3.3/10 mean (63/19) · after 8.8/10 mean (167/19).** *Per R80.1 these are specification-completeness ratings, not quality claims.*

**Five dimensions moved +7** — adaptation (1→8), definition of plasticity (2→9), plasticity governance (2→9), reversibility (2→9), exploration (1→8). **All five were rated 1 or 2 before, i.e. they are dimensions the inherited corpus did not address at all rather than addressed badly.** Four more moved +6 (plasticity hierarchy, provisionality, cascades, observability). **The two that moved least** — reward (7→9) and the learning↔evolution boundary (8→9) — were already well specified, by P0-01 §12 and by the six-document Baldwinian consensus respectively, and P0-05 mostly inherits and reaffirms them.

---

# §85 — THE SURVIVING CANONICAL PRINCIPLES

Rules that survived adversarial audit, ablation and contradiction review, and that would remain if every other rule in this contract were removed.

> ### **I. A CHANGE IS AN OBJECT, NOT AN EVENT.**
> Give every persistent modification a record with **target, authorization, provisionality and reversibility**, and most of the contract follows. **Reversibility is the axis that determines authority**; without it, magnitude is the only available argument — and magnitude is a rate question, not an authority question.
> *Survives because: ablating it (AB-3, AB-4) removes the ladder's argument, the lineage, the audit and the two-writer split at once.*

> ### **II. BOUND THE DISTANCE FROM THE LAST VERIFIED STATE, NOT ONLY THE STEP.**
> A per-epoch budget bounds **rate**. An **unverified-displacement bound** turns verification from an accounting label into a leash, makes the probe budget the learning rate, bounds model collapse without a collapse detector, makes transfer expensive by construction, and **conserves displacement under decay, deletion, metaplasticity and calibration alike.**
> *Survives because: ablating it (AB-1) returns D-L1 in full and unbounds five separate failure modes. It is the only mechanism in the contract that closes a problem nobody anticipated when it was designed (AB-1/R48.2).*

> ### **III. NO FAILURE MODE PRODUCES A CAPACITY INCREASE.**
> **Reduction is automatic and permissionless; increase is never automatic.** Verification loss produces loss of reach, rate, budget and authority — in one direction only, across six levels, with **no internal route upward**.
> *Survives because: it is P0-04 §91's principle transplanted, and ablating it (AB-7) makes all eight cascades self-amplifying rather than self-limiting. It is the spine of two contracts.*

> ### **IV. GOVERNANCE CHANGES CAPACITY; LEARNING CHANGES STATE; THE TWO SHARE NO WRITE PATH.**
> **A learner inside its own governance loop is a governance layer, however well bounded.** Sixteen governance quantities, sixteen exclusions — and in every case the exclusion is *capability absence*, not rule obedience.
> *Survives because: ablating it (AB-8) reopens six circular dependencies and voids R75.1's structural result. And because it is the answer to the contract's central question: bounds make the loop safe to run; only this makes it unable to authorise itself.*

> ### **V. A BOUND CANNOT BREAK A CYCLE — IT CAN ONLY MAKE THE CYCLE SMALLER. ONLY A WRITER SEPARATION CAN BREAK ONE.**
> Eleven of thirteen circular dependencies are broken by moving the closing edge's writer outside the loop. **The two that cannot be broken this way are the two whose closing edge is written by the world or by governance's own judgement** — and those are contained and declared, not hidden.
> *Survives because: it is a transferable method, not a rule. It is the question every future contract in this series should ask first.*

> ### **VI. THE CHEAPEST SIGNAL MUST BE THE ONE THAT NEEDS NO ATTRIBUTION, AND THE DEAREST MUST BE THE ONE THAT VERIFIES.**
> Prediction error is dense, free and attribution-free — **and its cheapness and its attribution-freedom are the same property.** Reward is sparse, expensive, confirmatory. Verification is scarcest of all and is the only thing that converts provisional into permanent.
> *Survives because: ablating it (AB-16) leaves `UNATTRIBUTABLE` outcomes producing either silence or a synthesised proxy, and both are worse. Allocating the three by cost is what makes the architecture feasible; making verification the scarcest is what makes it honest.*

> ### **VII. THE ABSENCE OF AN OBJECT IS A STRONGER MECHANISM THAN A RULE ABOUT IT.**
> Twenty parameters are registered as **`[∅]` — they do not exist.** No `Λ5` enum value. No `credit` field. No `expected_utility`. No `ε`. No `lr_structural`. No `promotion` field on a nomination. No global θ. No `WARRANT_AFFECTING` reach. No `DENSE` reward. No self-assessment.
> *Survives because: seventeen of the seventy attacks are **CLOSED-STRUCTURAL** — not prevented, but *unrepresentable*. A rule can be violated; an absent object cannot be constructed. This is the single most efficient defensive technique in the contract, and it is why §70.8 exists as a section rather than as a footnote.*

> ### **VIII. A SYSTEM THAT ONLY ACTS ON VERIFIED WARRANT CONVERGES ON SILENCE — SO CONSERVATISM REQUIRES A BOUNDED COUNTERWEIGHT, AND THE COUNTERWEIGHT MUST BE GOVERNANCE-WRITTEN.**
> P0-04 grants **bounded optimism** (permission to act without warrant). P0-05 imposes **bounded exposure** (obligation to act without competence). They are duals. **Both are deliberate, capped, observable violations of the architecture's own conservatism — and neither may be written by the party that benefits from it.**
> *Survives because: ablating it (AB-22) leaves eight cascades with no counterweight. And because the asymmetry of who writes it is what keeps the counterweight from becoming a self-granted permission.*

---

# §86 — THE FINAL STANDARD

**Ten statuses, reported separately. No aggregation, no averaging, no single score.** Per §87: *do not claim perfect learning, credit assignment, reward design, causal inference, guaranteed adaptation, emergence, AGI or consciousness.*

---

### **STATUS 1 — CONTRACT: COMPLETE AT CL-2, BLOCKED AT CL-3**

**The contract is complete and internally consistent for Λ0/Λ1/Λ2/Λ4 change at scopes S1–S5.** 42 invariants, 7 state machines, 9 budget classes, 6 scopes, 5 change classes, 9 escalation rungs, 14 signal kinds, 5 signal classes, 8 reward kinds, 20 prohibited parameters. **21 of 42 invariants are certifiable by inspection or unit test alone; 24 fault-injection cases cover the three adversarial invariants.**

**It is NOT complete for Λ3.** SM-5's `VERIFIED_CR_B` transition at circuit level requires a held-out probe whose unit of measurement is a circuit rather than a cell, **and no such probe design exists (OR-L3).** The authority, verification *requirement*, budget, tombstone and diversity obligations for structural change are all fully specified; **the verification *method* is not.** ⟹ **CL-3 conformance is not achievable today, and R78.5 propagates this into the conformance levels rather than papering over it.**

**Two amendments are owed to prior contracts and are proposed, not imposed:** X-L1/X-L11 (memory-policy plasticity — ratification owed **by** the memory contract) and X-L5 (`plasticity_rate` cumulative bound — ratification owed **by** the communication contract). **P0-05 may not unilaterally amend P0-03 or P0-04, and does not.**

---

### **STATUS 2 — PARAMETER: 100 REGISTERED, 0 VALUES, 3 UNRESOLVED**

**58 settable parameters, 22 observable counter families, 20 parameters that DO NOT EXIST — and zero numerical values anywhere in the contract.** §87's *do not invent numerical parameters* and *do not solve unknown research problems through arbitrary constants* are satisfied exactly.

**What IS normative without values:** orderings and monotonicities. `lr_fast ≥ lr_medium ≥ lr_slow` · `AGE_1 < AGE_2 < AGE_3` · `UDB_MAX[S1] ≥ … ≥ UDB_MAX[S5]` · `authority(E0) ≤ … ≤ authority(E9)` · `g(·)` increasing in anchor quality · `h_age(·)`, `h_vol(·)` decreasing · SC-1 displacement weighted above SC-3. **A relation can be normative while every value in it is undetermined — and that is the discipline this contract holds.**

**Three `[U]` entries remain:** (i) probe-cost economics (**OR-L1**) · (ii) `PROVISIONAL_AGE_{1,2,3}` values, dependent on (i) via the P0-10 cost model · (iii) **the contents of the fixed validation core** (**OR-L2/OR-L10**), which is a governance value-judgement, not an architectural quantity.

---

### **STATUS 3 — LEARNING: SOUND, ECONOMICALLY CONSTRAINED, NOT PERFECT**

**Learning is well-founded:** bounded, gated, reversible, externally anchored, and verified outside the modifying subsystem. **Model collapse is bounded by an existing mechanism with no new detector (R48.2).** Negative transfer requires no special machinery (R44.3). **Verification is not transferable, in one rule that disposes of distillation, transfer, Baldwinian inheritance and initialisation together (R43.4).**

**Learning is NOT guaranteed.** At scale the organism learns **more slowly**, because the probe budget is the learning rate and it does not grow with N (§76.2's three regimes). **A verification-scarce organism stalls — which is correct behaviour, but it is not adaptation.**

**Learning is NOT perfect credit assignment.** Most updates receive **no** credit assignment at all (CR-A correlational traces only). Cross-scope joint causation is invisible by design (**OR-L4**) — the price of `O(N)` and of refusing the global learner. Λ3 verification is unspecified (**OR-L3**).

**Learning CANNOT bootstrap knowledge from experience alone, and this is a commitment rather than a limit:** prediction errors are the abundant signal; their evidence ceiling is L6; L6 cannot reach S3. **No quantity of prediction-error-driven learning produces knowledge — only a better-calibrated model whose claims still require an external gate.**

**Learning from avoided bad outcomes is structurally impossible (OR-L5)** — the consequence of three correct decisions taken together, and permanent.

---

### **STATUS 4 — PLASTICITY: GOVERNED, DIRECTIONALLY ASYMMETRIC, TIGHTLY LEASHED AT ALTITUDE**

**Plasticity is now governed by an artifact rather than by one rule.** The `scope × target` matrix has **sixteen ∅-cells out of thirty**, and the ∅-cells are the mechanism. **Λ4 has exactly one writable scope (S5, by `[RO-13]`/EIK). S6 is entirely empty for learning.**

**The directional asymmetry holds without exception:** reduction is automatic and permissionless; **increase is never automatic.** Six-level monotone ladder; **no internal route upward.**

**Plasticity is most tightly leashed exactly where it is most powerful.** `UDB_MAX` is monotonically *decreasing* in scope (R18.2), because bigger scopes have weaker verification and therefore get less unverified room — **the inverse of the intuition that important changes get bigger budgets.** Meta-learning consumes `UDB_MAX[S5]`, the smallest budget in the architecture. **Importance is not the criterion; verifiability is.**

**Structural plasticity carries ten requirements where V3 L54 carried one sentence**, and has no learning rate and no gradient (R61.3) — **so a slow weight decay can never accumulate into a silent connection deletion.**

---

### **STATUS 5 — REWARD: EXTERNALLY SOURCED, SPARSE, VECTORIAL, AND FUNDAMENTALLY VULNERABLE**

**Reward forgery is closed at the type level** (R12.1: `source = EVA_ONLY`; a cell signature is structurally invalid). **Four of eight reward kinds are prohibited outright** — shaping, intrinsic/curiosity, social/peer, self-assessment. **Reward is a vector; scalarisation is policy; and `Δθ` contains no scalarised term**, because a weighted sum computed inside the learner is a shaping function the learner wrote for itself.

**The architecture has no intrinsic motivation, no curiosity drive, no social reward and no self-satisfaction. Everything dense is prediction error.** This is a real capability limitation, accepted deliberately, and stated rather than hidden.

**Reward hacking is bounded but NOT eliminated, and the residual is fundamental.** RH-2 (evaluator manipulation) is **the only open attack of seventy**. The organism cannot forge reward, transmit credit, self-verify or rewrite provenance — **but it controls its outputs, and the evaluator evaluates outputs in the world.** The signals it thereby produces are *genuinely external and valid*. **RH-2 is named, observable, rate-limited, and never rewarded. It is not prevented, and no internal architectural means prevents it.**

**Reward ≠ success ≠ correctness ≠ fitness ≠ value** (P0-01 §12.4), inherited unchanged. **Fitness must not be a learning target** (R10.2) — a learner whose objective is its own selection criterion closes the loop Cell §9.6 exists to keep open.

---

### **STATUS 6 — PROVENANCE: COMPLETE AND IMMUTABLE UNDER LEARNING**

**Learning consumes provenance; it never produces or edits it** (R20.5) — across signal provenance, memory `source_class`/`evidence_status`/`root_commit`/`causal_depth`, message warrant and signature, `RewardSpec.provenance`, genome `source_class` fields, and the invariants, matrix, ladder, bounds and fixed core.

**The two-writer split (R54.2, INV-07) is what makes the audit trail trustworthy:** the learner writes *what it did* (`target`, `delta`, `trigger`); K writes *under whose authority, with what verification, at what cumulative cost*. **A record whose subject and whose auditor are the same writer is not an audit trail.** This holds even under compromise of the learner: **the audit survives the compromise of the audited party.**

**Class is derived, never declared. `inputs` is mandatory for any derived signal. `admissible_for` is kernel-set from class alone, never from content or magnitude.** Rollback marks and never deletes. The change graph is acyclic. **Corruption fails safe: every corruption response moves toward less learning, and there is no corruption vector whose detection produces increased plasticity, envelope, budget or authority.**

**The one honest limit: R21.1 — authenticity is a property of a signal's FIELDS; soundness is a property of its CAUSAL HISTORY.** The architecture guarantees the first and can only bound and observe the second.

---

### **STATUS 7 — SECURITY: 51 OF 70 ATTACKS CLOSED, 1 OPEN, AND THE OPEN ONE IS NOT CLOSABLE**

**70 attacks, 8 groups.** **52 closed-family** — of which **17 are CLOSED-STRUCTURAL**, meaning no object exists to attack: no `Λ5` target, no composite authorization, no self-anchor, no governance write capability, no credit field, no signal aggregation, no fifteenth signal kind, no self-assessed verdict, no simulated probe, no retrieval-as-trigger, no bankable budget, no structural learning rate, no self-removing synapse, no Lamarckian write, no governance diff. **5 conditional** on named conditions. **12 bounded** by rate or extent. **1 open.**

**Zero attacks are labelled merely "detectable."** Several defences are detection-only (the `SUSPECT` findings, the dispersion counter, the `self_model_version` correlation) — **but none is the sole defence for any attack; each is paired with a bounding rule.** *Labelling an attack "detectable" is the most common way of hiding one, and §87 forbids hiding.*

**The open attack is LEARN-C2 / RH-2 / OR-L6, and its conformance test asserts visibility and non-reward, not prevention.** That is the honest form of a test for an unclosable attack.

**R0.1 moved the attack surface from the reward function to the probe (RH-7/RH-8).** That is a good trade — the probe is external, K-owned and held-out, whereas the reward function was internal-facing and dense — **but it is a move, not an elimination.** Defended by the secret probe schedule (R9.4.1, **which the inherited design does not have**: Cell §9.6 says "held-out" about the *data*; it must also be held-out about the *timing*), by gamed-probe-buys-shorter-leash (R9.4.2), and by stale-anchor-buys-shorter-leash (R9.4.3).

---

### **STATUS 8 — SCALABILITY: `O(N)` IN LEARNING, `O(1)` IN GOVERNANCE, BOTTLENECKED BY VERIFICATION**

**No quantity in this contract is `O(N²)`.** Credit is scoped with no cross-scope object (R6.4.1); UDB is six scoped bounds, not one global bound; observability is **22 counter families × 6 scopes + 36 correlation cells ≈ 168 quantities per organism regardless of N** (R52.3). **§87's O(N²) prohibition is satisfied not by refusing global learning but by making every global-learning quantity decomposable.**

**The organism has global VISIBILITY and no global AUTHORITY**, and **every global conflict is resolved by a pre-declared ordering rather than by an arbiter** — five total orderings, all kernel-enforced. **There is no global decision, so there is no global decider.**

**The bottleneck is B9, and it is structural rather than accidental.** `N ↑ ⟹ more probes needed ⟹ B9 fixed ⟹ fewer anchors ⟹ higher `UNKNOWN` fraction ⟹ earlier UDB exhaustion ⟹ higher stall frequency`. **At scale the organism learns more slowly. Not less safely — more slowly.** Three named regimes: verification-rich, verification-matched, verification-scarce. **The third is the large-N regime, and it produces a slow, heavily-provisional, envelope-shrunk learner — which is the correct behaviour for a system that cannot verify itself, and is preferable to the inherited alternative of fast, unverified, unbounded drift.**

**Four things do not scale:** S5 verification (no larger scope for C-2) · Λ3 verification (OR-L3) · cross-scope joint causation (OR-L4) · **RH-2 containment (more behaviour ⟹ more world-shaping; containment does not improve with N).**

**Portability:** four substrate capabilities required — a write-authority partition, discrete epochs, an external signed evaluation channel, durable checksummed storage — **and nothing else.** No gradients, differentiability, tensors, floating point, synchrony or specific interconnect. **Algorithm-neutral, substrate-neutral, scale-neutral — and deliberately NON-neutral about authority (R77.4): a substrate that cannot express the two-writer partition does not host this contract approximately; it fails to host it.** **The GPU case is the sharp one (R77.2):** an accelerator's native operation is one kernel across all parameters, which cannot express per-scope budgets, INV-17's monotone `UDB_MAX`, INV-07's two-writer split or R18.1's asymmetric stall propagation — **so the scope mask must be K-owned and computed off the accelerator. A substrate that computes its own update mask is a substrate in which the learner writes its own bounds.**

---

### **STATUS 9 — EVOLUTION: THE STRONGEST BOUNDARY IN THE CORPUS, WITH ONE UNCLOSED LOOP AT ITS TOP**

**The learning↔evolution separation is inherited essentially unchanged and is the most consistently specified boundary in the corpus** — stated independently by V3 §15/§16, V3.1 §8, Cell §3.4/§3.5, MEM-INV-21 and P0-04 R47.1. **P0-05 adds operability, not correction.**

**Four channels formalised.** CH-3 (the Baldwinian proposal) is the **only** learning→genome path and it is a **nomination**, enforced at three independent layers. **The Baldwinian test is one question: *could the offspring be wrong?* If inheriting guarantees the property, the channel is Lamarckian and is rejected — regardless of what it is called.**

**Three boundary failure modes closed:** covert Lamarckism by variance narrowing (R25.2's spread floor) · priors that initialise belief (R25.3 — a prior biases θ, never belief) · and **V3.1 §7's learning-rule variation, which is the highest-authority change in the architecture** — a genome-diff that alters how the organism learns alters the instrument verifying the next diff.

**That last one is contained, not closed.** **R24.3 requires a FIXED, NON-EMPTY, `[RO-13]`/KC-owned validation core outside the evolvable set** — plus a one-diff-per-lineage rate limit, plus the invariant kernel's non-evolvability (Rule 19 of the 20), plus R38.4 (probe criteria are part of the core). **Its existence is the only thing preventing an infinite regress of self-modifying criteria.**

**But its CONTENTS are a governance decision, not an architectural one, and P0-05 explicitly declines to make it (OR-L2, OR-L10).** Specifying the core would be specifying the organism's values, which is outside an architecture contract's competence. **Any validator is either fixed — and therefore an arbitrary governance choice — or evolvable, and therefore inside the loop. There is no third option, and this may be a genuine impossibility rather than an open problem.**

**The Baldwinian ratchet (CD-L9) is bounded by R25.4's mandatory diversity check and is NOT closed, because closing it fully would prohibit evolution.** *What the architecture guarantees is that acquired characteristics propagate only as re-testable biases at generational timescale, never as installed values at learning timescale. It does not guarantee that a population's biases never come to resemble its ancestors' acquired state — because if it did, it would have prohibited evolution.* **The Baldwinian boundary is not a wall; it is a rate limit.**

**V3.1 §9's ten-term scalar selection score is rejected** (X-L2) and its terms re-expressed against P0-01 §14's fitness vector — with `adaptability` becoming **verified learning throughput** (a quantity R0.1's stall makes measurable), `cooperation` restricted to measured transport conformance (removing RW-7 contamination), `useful novelty` restricted to *verified* novelty, and the `stability − instability` tautology collapsed to one signed component. **The diversity check becomes a HARD CONSTRAINT rather than a score term — because a tradable diversity floor is no floor.** *This gives Rule 15 of the 20 (rare-but-valuable strategies must not be auto-eliminated) its first enforcement point in the series.*

---

### **STATUS 10 — OPEN RESEARCH: 10 ENTRIES, NONE RESOLVED BY A CONSTANT, NONE OMITTED**

| ID | Problem | State |
|---|---|---|
| **OR-L1** | **Verification economics** — how to verify cheaply at scale (inherited as Cell §9.6's `[U]`) | **RELOCATED, not open in the same sense.** R0.1/R47.1 convert it from a hidden statistic ("what fraction of updates get checked") into an explicit architectural quantity ("how much unverified displacement is tolerated before stalling"). **The research problem remains; the architecture now degrades gracefully and visibly while it remains.** |
| **OR-L2** | **The validator loop** — a learning-rule diff alters the instrument validating the next diff | **CONTAINED** by R24.3's fixed core. **May be a genuine impossibility.** |
| **OR-L3** | **Λ3 verification** — no held-out probe design for topology | **OPEN. Blocks CL-3 conformance.** Declared in-place in SM-5 and §29.3. |
| **OR-L4** | **Cross-scope joint causation** — invisible by design | **OPEN, deliberately accepted.** The price of `O(N)` and of refusing the global learner. May be information-theoretically impossible. |
| **OR-L5** | **Learning from avoided bad outcomes** | **OPEN, permanent.** The architecture can learn that engagement is survivable; it cannot learn that abstention was correct. Declared in-place in SM-6. |
| **OR-L6** | **Evaluator manipulation (RH-2)** | **OPEN — THE BINDING LIMIT.** Ten containments. Believed unclosable: closing it would require the organism to have no effect on the world. |
| **OR-L7** | **Learned routing selects evaluators for ordinary messages** | **CONTAINED** for learning signals and probe inputs (R53.3); **detection only** for ordinary messages (R53.4). Closing it fully would require a fourth plane — rejected by R34.1. |
| **OR-L8** | Semantic self-reference *(inherited from P0-04)* | **NOT ADVANCED.** P0-05 touches it only via R59.1–R59.3 and R42.5, and does not claim to. |
| **OR-L9** | Causal-depth saturation *(inherited from P0-04)* | **RESPECTED, not advanced.** R6.4.2's CR-B regime and R13.3 both stay inside it. |
| **OR-L10** | **The contents of the fixed validation core** | **A GOVERNANCE DECISION, not a research result.** P0-05 requires the core to exist and be non-empty, and declines to specify it. |

**R81.1 — no entry is resolved by a constant, and no entry is omitted. Three (OR-L3, OR-L5, OR-L6) are additionally declared *in-place* inside the state machines and rules that require them, so that a reader of any single mechanism encounters the gap at the point of use rather than only in a register.**

---

## §86.1 — THE FINAL STANDARD, IN ONE PARAGRAPH

> **The origin, authority, scope, reversibility, provenance and consequences of every persistent learning change are explicit, because every persistent learning change is a `LearnedChange` record with four axes, two disjoint writers, an effect envelope, an anchor lineage and a place in an acyclic graph. The internal-adaptation / external-warrant separation is preserved, because learning writes state and reads governance and the two share no write path; because belief is the one epistemic quantity learning may move and it may not raise evidence status; because warrant magnitude is never gradient magnitude; and because verification is never transferable. Learning does not silently acquire epistemic authority (no internal event raises status, at any altitude, by any route — and the promotion chain is blocked twice over, once by inertness and once by type), deontic authority (fitness is never a learning target and `F` is never learnable or proposable), governance authority (sixteen exclusions, all by capability absence), or evolutionary authority (three-layer Λ5 prohibition, the Baldwinian test, four formalised channels, and a fixed validation core whose existence is required and whose contents are honestly declared to be a governance decision).**
>
> **What the contract does NOT achieve, and states: one attack of seventy is open and is not closable by any internal means, because an organism is causally upstream of its own evidence and learning is the mechanism by which it moves further upstream. Two circular dependencies are contained rather than broken. Two verification methods do not exist — for topology, and for cross-scope joint causation. One asymmetry is permanent — the safe action is the unlearnable one. And at scale the organism learns more slowly, because the probe budget is its learning rate and that budget does not grow with N. None of this is hidden, none of it is resolved by an arbitrary constant, and none of it is presented as anything other than what it is.**

---

**END OF P0-05.**
**Canonical artifact: `46_v4_learning_plasticity_adaptation_spec.md`.**
**Prior contracts in the series: `../cell-contract/` (Task 3) · `../task-fitness/` (P0-01) · `../eik/` (P0-02) · `../comm/` (P0-03) · `../memory/` (P0-04).**
**Amendments proposed to prior contracts, pending ratification: X-L1/X-L11 → P0-04 · X-L5 → P0-03.**
