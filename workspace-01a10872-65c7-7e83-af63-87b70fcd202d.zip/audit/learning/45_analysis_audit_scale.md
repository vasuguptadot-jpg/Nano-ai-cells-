# P0-05 — LEARNING, PLASTICITY & ADAPTATION CONTRACT
## Volume F — Alternatives, Contradictions, Scale, Testability, Open Research (§73–§82)

**Status:** adversarial architecture audit. **Architecture only.** No implementation, no numerical parameter values.
**Depends on:** Volumes A–E in full.

> **Outputs discharged:** O50 (circular dependency audit), O51 (scalability), O52 (hardware portability), O53 (ablation), O54 (cross-system contradiction audit), O55 (conformance/testability), O57 (P0/P1/P2 gaps), O58 (open research register). Plus: the candidate-architecture comparison and the false-precision audit.

---

# 73. CANDIDATE LEARNING ARCHITECTURES COMPARED

§2 compared candidate *meanings* of "learning." §73 compares candidate *architectures* — because §87's discipline (*DO NOT ASSUME "LEARNING"*) requires that the adopted design be shown to be a choice among alternatives rather than a default.

## 73.1 The seven candidates

| # | **Architecture** | **Core commitment** | **Authority model** | **Rejected / adopted?** | **Decisive reason** |
|---|---|---|---|---|---|
| **AR-1** | **Global reinforcement learner** | One agent, one scalar reward, one policy, global credit assignment | Centralised | ❌ **REJECTED** | **§87 explicitly prohibits it.** `O(N²)` attribution; a single scalar reward requires scalarisation inside the learner (R8.2 corollary forbids); the global learner *is* the hidden governance layer (§65). Also economically infeasible: P0-01 §12.2's 15–40× verification amplification × global scope. |
| **AR-2** | **Purely local Hebbian** | Every component adapts from co-activity; no external signal | Fully distributed, no authority | ❌ **REJECTED** | V3 §8's «successful use → strengthen» is this, and §2.4 shows why it fails: **"whose success?"** Local Hebbian has no external term, so it cannot distinguish competence from self-reinforcement. It is D-L1 with no anchor available at all — UDB cannot be defined because no verdict can exist. **Also: Hebbian co-activity is exactly the multiplicatively unstable process that R15.1's mandatory homeostasis exists to bound, and V3 has no homeostasis.** |
| **AR-3** | **Supervised-only** | All learning from external corrections (RW-3) | External | ❌ **REJECTED** | Economically infeasible: corrections are HIGH-cost (§8, RW-3), and P0-01 §12.2's entire argument is that learning cannot require evaluation at every step. **Also creates RH-C2 (correction capture) as the *primary* channel rather than a residual one.** |
| **AR-4** | **Reward-maximising (dense shaping)** | A dense shaped reward drives a gradient | External reward, internal shaping function | ❌ **REJECTED** | **R12.4 prohibits DENSE reward** because a shaping function is a hand-authored proxy that gets optimized — the canonical specification-gaming target. This is AR-1's reward model with RH-1 maximised. |
| **AR-5** | **Bayesian / probabilistic inference** | Learning is posterior update over a model space | Internal, evidence-weighted | ⚠️ **PARTIALLY ADOPTED as C5** | §2's C5: correct for Λ1 on external data, **wrong for Λ4** (changing the inference procedure is not inference) and **wrong for self-generated data** (§48). **⟹ Adopted as the *semantics* of `confidence_in_error` and of P0-04's belief update; rejected as the *architecture* of learning, because it has no account of structural change, no account of authority, and — decisively — a Bayesian update on self-generated data is model collapse with a likelihood function.** |
| **AR-6** | **Evolutionary / population-based only** | All adaptation by selection over variants; no ontogenetic learning | Selection | ❌ **REJECTED** | Timescale mismatch: evolution is generational (R2.3 mechanism D), and a system with no ontogenetic learning cannot adapt within a lifetime. **V3 §15's hard separation exists precisely to prevent this collapse in the other direction.** Also: selection requires a fitness signal, which requires evaluation, which is the expensive thing. |
| **AR-7** | **Prediction-error-driven, sparsely reward-confirmed, scoped, externally anchored, provisionality-bounded** | Dense cheap error + sparse expensive confirmation; six scopes; UDB; `LearnedChange` | **Distributed state, centralised governance** | ✅ **ADOPTED** | The only candidate that satisfies P0-01 §12.2's economics, Cell §9.6's anti-self-deception, P0-04's admission principle, COMM-INV-25's plane separation, and §87's O(N²) prohibition **simultaneously**. |

## 73.2 Why AR-7 is not merely "the hybrid"

**Rule from Task 3, still binding: *"Do NOT simply say 'hybrid' unless you define exactly what the hybrid consists of."***

> ### **R73.1 — AR-7 IS NOT A HYBRID. IT IS A SPECIFIC ALLOCATION OF ONE RESOURCE (EXTERNAL VERIFICATION) ACROSS THREE FUNCTIONS.**
> | Function | Signal used | Cost | Attribution requirement | Authority |
> |---|---|---|---|---|
> | **Learning how the world works** | **Prediction error (SG-1)** | ~0 (a comparison) | **NONE** (R6.4.4) | `SELF_LOCAL`, provisional |
> | **Confirming whether the task succeeded** | **Sparse reward (SG-2, RW-1)** | HIGH (15–40× amplification) | **CR-A correlational** | SC-3, anchor-eligible |
> | **Deciding whether the change helped** | **Held-out probe** | HIGH, budgeted (B9) | **CR-B where irreversible** | **K only** |
> **The three functions use three different signals at three different costs with three different authorities.** That is not a blend of AR-2 and AR-3; it is a decomposition that neither contains. **AR-2 has function 1 without an external term; AR-3 has function 2 without an economic basis; no candidate has function 3 at all except AR-7, which inherits it from Cell §9.6.**
> **⟹ The genuinely novel element of AR-7 relative to every candidate is FUNCTION 3 — external verification of improvement — and R0.1 (UDB) is what gives it architectural force.** Without R0.1, function 3 is a label (Cell §9.6's `improvement_verified` records a verdict that nothing consumes). With R0.1, it is a **leash**.

## 73.3 What AR-7 gives up

Per §87 (*do not hide unresolved problems*) and Rule 20 (*be adversarial against your own choice*):

| Given up | Consequence | Where it shows |
|---|---|---|
| **Intrinsic motivation** | No curiosity, no open-ended self-directed goal generation. Everything dense is prediction error. | R8.1, R36.1 |
| **Fast global adaptation** | No global learner ⟹ no coordinated organism-wide reorganisation in response to a single event. Six scoped bounds instead. | R35.1, OR-L4 |
| **Cross-scope credit** | Two scopes jointly causing an outcome is invisible to both. | R6.4.1, OR-L4 |
| **Learning from avoidance** | The safe action is the unlearnable one. | OR-L5, §40.3 |
| **Self-directed plasticity increase** | The organism cannot decide to learn harder when it is doing badly. T7 says the opposite. | R28.2, R31.1 |
| **Cheap structural change** | E3+ requires ablation, tombstone, `ORGANISM` authority, B6 budget. Ten requirements where V3 had one sentence. | R61.4 |
| **Fast learning under verification scarcity** | **R0.1 makes the probe budget the learning rate.** An organism that cannot afford probes learns slowly and *visibly stalls*. | R47.1, OR-L1 |
| **Immunity to RH-2** | The organism shapes its own evidence and no internal mechanism prevents it. | OR-L6, §56.2 |

> **The last row in the "given up" table is the one that should be read carefully, because it is not a trade-off — it is a fact.** Every other row is something AR-7 chose not to have. **RH-2 is something no architecture can choose not to have**, and AR-7's contribution is to make it *named, bounded, observable and never rewarded* rather than *solved*. §86 reports it accordingly.

---

# 74. **[O54] CROSS-SYSTEM CONTRADICTION AUDIT

**Method (§87: *do not silently resolve contradictions*):** every contradiction is stated with both sides, its class, and a disposition of **RESOLVED** (a rule decides it), **PROPOSED** (P0-05 proposes a resolution it may not impose), **DISSOLVED** (the contradiction rests on a conflation that the audit separates), or **OPEN** (no resolution available).

| ID | **Contradiction** | Side A | Side B | Class | **Disposition** |
|---|---|---|---|---|---|
| **X-L1** | **Memory-policy plasticity** | Cell §9.3: memory policy params (`τ`, `θ_write`, `θ_recall`) ✅ cell-plastic at **C3+** | P0-04 **X-M1**: memory policy ❌ cell-plastic for **E2+** records (cell may vary only WM utilisation, local eviction order, retrieval weights) | **One name, two altitudes** | **PROPOSED — R41.2 / R11.3.** Split by **blast radius**: `θ_write_local` / `θ_recall_local` / `τ_local` (cell-plastic, `SELF` radius) vs `θ_write_shared` / cross-store retrieval / shared retention (`[RO-13]`). **Both inherited texts are then correct at their altitudes. PENDING RATIFICATION BY THE MEMORY CONTRACT — P0-05 may not unilaterally amend P0-04.** |
| **X-L2** | **Scalar selection score vs vector fitness** | V3.1 §9: `SELECTION SCORE` = a **ten-term sum** (performance + accuracy + adaptability + efficiency + cooperation + robustness + useful novelty + stability − resource cost − instability) | P0-01 §14: fitness is a **vector / Pareto** object with 13 components and mandatory uncertainty; R12.2: scalarisation happens in *selection policy*, never in the signal | **Direct conflict** | **RESOLVED — R10.3.** The scalar is **rejected**; the ten terms are re-expressed as P0-01 §14.4 components (R10.3.1–.4: `adaptability` → verified learning throughput; `cooperation` → measured transport conformance only; `useful novelty` → verified novelty only; `stability − instability` → one signed component). The sum survives **only** as a named `[RO-13]` selection policy with declared weights. |
| **X-L3** | **Peer assessment in fitness** | V3.1 §9's `cooperation` term imports peer assessment into selection | P0-01 §13.2: `PEER_REPORT` is a **hypothesis** — may not contribute to fitness, replication gates or retirement | **Direct conflict** | **RESOLVED — R10.3.2.** `cooperation` enters fitness **only** through externally measured transport/protocol conformance (P0-03's TRANSPORT plane), **never** through peer assessment of cooperativeness. Closes LEARN-C7's fitness residual. |
| **X-L4** | **S5 authority with no S5 governance** | V3.1 §7 varies **learning rules** (an S5/Λ4 quantity) through evolution | V3.1 §6 names **five** plasticity scales and **omits organismal entirely** — so an S5 quantity is varied with no S5 scope, budget, authority or verification | **Omission creating a conflict** | **RESOLVED — R4.2 / R16.2 / R28.1 / §29 E8.** S5 is added as a scope with `POLICY(RO-13)` authority, the smallest `UDB_MAX` (R18.2), no C-2 cross-scope probe available (declared), and E8 rung requiring a meta-probe under the fixed core (R24.3). |
| **X-L5** | **`plasticity_rate` learnable with no cumulative bound** | P0-03 R3.2: `plasticity_rate` **is** in the learnable synapse parameter set | P0-05 R0.1: cumulative unverified displacement must be bounded — and `plasticity_rate` is a **gain on the gain**, so its drift is unbounded displacement invisible to `Δ_MAX` | **Gap in a prior contract** | **RESOLVED — R34.3. P0-05 AMENDS P0-03.** `plasticity_rate` remains learnable at S1 **within `[G]` bounds**, and its cumulative drift **consumes S1 UDB** (LEARN-INV-18). Closes LEARN-D3. **This is the one place P0-05 amends rather than inherits a prior contract, and it is recorded as such rather than absorbed.** |
| **X-L6** | **Novelty: gate or trigger?** | V3 §8: «useful novelty → **preserve**» reads as a positive plasticity response; V3 §14: `NOVELTY → SLOW MODE` reads as a negative one | Cell T5: novelty ⟹ `SLOW_MODE`, **reduced** plasticity, **not** learning | **Ambiguity within V3** | **DISSOLVED — R14.1 / R14.2 / R14.3.** V3 uses one name for two quantities: **novelty** (distance from memory — internal, ungrounded, manufacturable) and **surprise** (pre-registered prediction violated — partially grounded). **Novelty slows; surprise teaches.** «Preserve» is correct as *preservation by inaction* under a quota; «novelty strengthens» is not a permitted reading. |
| **X-L7** | **Repetition: integration or nomination?** | V3 §14: «Repeated successful exposure → **stable integration**» | P0-04 X3: repetition is not accumulation of independent evidence; MEM-INV-20: consolidation is **nomination**, not promotion | **Direct conflict** | **RESOLVED — §22.4 / R50.1–R50.3.** Repetition **may** raise consolidation nomination priority, lower `plasticity_mult` (metaplasticity), lower `lr`. Repetition **may not** produce `Δθ` (SG-7), re-anchor (R0.1 requires an SC-3 probe), convert `PROVISIONAL → VERIFIED`, or raise evidence status. **"Stable integration" is nomination plus reduced plasticity — never promotion.** |
| **X-L8** | **Pruning: plasticity operation or structural event?** | V3 L54 lists **prune** among five plasticity operations in one sentence, with «persistent uselessness → prune» (V3 §18) as an automatic rule | P0-01 §23.2 requires **causal attribution** for pruning/retirement; R0.3 requires authority to scale with irreversibility | **Category conflation** | **RESOLVED — R61.1 / R27.3 / §29 E3 / R61.4.** Pruning is **E3/Λ3/`IRREVERSIBLE_STRUCTURAL`**, requiring `ORGANISM` authority, **CR-B ablation**, a **tombstone**, `disuse_cause = IRRELEVANT`, B6 budget, trace invalidation, anchor-invalidation declaration, and a diversity check. **Ten requirements; V3 had one sentence.** |
| **X-L9** | **Failure: learn more or learn less?** | Naive reading of V3 §18 «persistent failure → repair/replace» implies *act on* failure | Cell T7: repeated failure ⟹ `plasticity_mult` **REDUCTION**, not more learning | **Apparent conflict** | **DISSOLVED — R39.1.** They operate at different altitudes: **T7 is a plasticity response** (K, automatic, SC-2, immediate); **V3 §18 is a structural response** (E3/E5 rung, `ORGANISM`+, governed, escalated). **Both are correct; V3's defect is listing the structural response with no authority attached.** |
| **X-L10** | **`SLOW_MODE`: reduce rate or reduce reach?** | V3 §14: `NOVELTY → SLOW MODE`, read as reduced learning rate | R15.9/R15.10: stability and plasticity are two quantities with two owners; under distribution shift, learning is *needed*, so reducing rate is backwards | **Design error in the inherited reading** | **RESOLVED — R15.10.** `SLOW_MODE` reduces `effect_envelope` **mandatorily** and `lr` **optionally**. A `SLOW_MODE` that zeroes `lr` while leaving envelope unchanged is a mis-specification; envelope→`NONE` with `lr` unchanged is the safe default. |
| **X-L11** | **Cell §9.1 includes memory-policy parameters in the definition of cell learning** | Cell §9.1: cell learning = modification of θ, connection weights, **AND memory policy parameters** | P0-04 X-M1/X-M2: memory policy is not cell-plastic for shared records | **Same root as X-L1** | **PROPOSED — subsumed by X-L1's resolution.** Cell §9.1's definition stands for local policy; P0-04's rejection stands for shared policy. **PENDING RATIFICATION.** |
| **X-L12** | **Reward and error as peers** | V3 §15's chain lists `error/reward/novelty` as co-equal learning inputs | P0-01 §12.1: **they are not peers** — error is dense/cheap/primary, reward is sparse/expensive/confirmatory, novelty is a gate | **Direct conflict, already ruled by P0-01** | **RESOLVED — inherited.** P0-01 §12.1 governs; §5.1 defect #1 records that **V3's master-loop diagram still teaches the conflation P0-01 unteaches**, and §5.2's V4 loop redraws it. |
| **X-L13** | **`last-success timestamp`** | V3 §8's synapse has a `last-success timestamp` field | P0-04's rejection of `last_verification`: a recency stamp decays into apparent staleness and can be manufactured by producing *any* success | **Same defect class, different contract** | **RESOLVED — §2.4.** `last_success` **MUST carry the `signal_ref`** of the success it records. A timestamp without a referenced admissible signal is **NULL, not stale.** |
| **X-L14** | **`usage_frequency` as plasticity input** | V3 §8 uses `usage_frequency` in the plasticity rule | P0-04 MEM-INV-50: importance/frequency are **allocation-only**, never epistemic | **Ambiguity** | **DISSOLVED — §2.4.** `usage_frequency` **MAY** modulate `plasticity_mult` and pruning candidacy (allocation). It **MAY NOT** enter any warrant, confidence, belief or evidence computation. |
| **X-L15** | **Eligibility traces: causal or not?** | V3 §8's synapse carries `eligibility_trace` alongside `plasticity_rate` and `last-success`, reading as a causal-credit mechanism | P0-03: traces are **local, per-connection, λ-decayed, and NOT causal claims**; COMM-INV-20 forbids transmitted credit | **Ambiguity** | **DISSOLVED — R6.4.1 / R6.4.2.** Traces support **CR-A (correlational)** only. **Causality requires CR-B (ablation), which is mandatory only at E3+.** A trace is *recent activity*, not *responsibility*. |
| **X-L16** | **Learning ⊂ adaptation, or adaptation ⊂ learning?** | V3.1 L112–115: "learning = experience-driven **adaptation** through plasticity and memory" — learning defined as a kind of adaptation | R2.3: adaptation partitions into A/B/C/D, of which **learning is one (C)** | **Definitional inversion** | **RESOLVED — R2.3 / R3.1.** Adaptation is the superset; learning is mechanism C. **V3.1's sentence defines an event as an outcome mediated by a capacity, which R3.1 identifies as uninformative about authority — and that is exactly why nothing in V3 says who grants plasticity or who verifies adaptation.** |
| **X-L17** | **"Full awareness loop"** | V3.1 §10 describes self-monitoring-driven adaptation as an "awareness loop" | Rules 3 and 5 of the 20: don't assume consciousness; no vague biological metaphors as mechanism substitutes | **Metaphor as mechanism** | **DECOMPOSED — R59.4.** Every V3.1 §10 "awareness" function is either **SC-2 metering** (permitted, and the legitimate core) or **SC-1 self-assessment** (prohibited as a learning driver; P0-01 §13 class 7/9 cannot be self-assessed). **`awareness` is not an architectural term.** |
| **X-L18** | **Is the Baldwinian bridge a learning mechanism or an evolutionary one?** | V3.1 §8: «learning → plasticity → evolution bridge, deliberately gated» — placed between the two | R2.3: mechanism C (learning) and mechanism D (evolution) have different verification regimes, timescales, reversibility and budgets, and **no shared budget exists** | **Boundary ambiguity** | **DISSOLVED — R2.3's fourth clause / §24 / SM-7.** A bridge crossing is an **atomic change of mechanism class from C to D**, changing verification regime, timescale, reversibility and budget consumption at once, at a gate. **There is no state in which a change is partly learning and partly evolution, because there is no shared budget for it to be partly drawn from.** |
| **X-L9b** | **Does quarantine reduce plasticity?** | The intuitive reading: an isolated component should stop adapting | R40.4 / R57.4: isolation reduces **envelope**, never **capacity** — otherwise the component cannot learn what would exonerate it | **Design error in the intuitive reading** | **RESOLVED — R57.4.** R15.9's separation applied: **quarantine is an envelope operation.** |

## 74.1 Contradiction reconciliation

| Disposition | Count | IDs |
|---|---|---|
| **RESOLVED** | **11** | X-L2, X-L3, X-L4, X-L5, X-L7, X-L8, X-L9b, X-L10, X-L12, X-L13, X-L16 |
| **DISSOLVED** | **5** | X-L6, X-L9, X-L14, X-L15, X-L18 |
| **PROPOSED (pending ratification)** | **2** | **X-L1, X-L11** |
| **DECOMPOSED** | **1** | X-L17 |
| **OPEN** | **0** | — |
| **TOTAL REGISTERED** | **19** | X-L1 … X-L18 plus X-L9b |

> **⟹ RECONCILIATION: 19 contradictions registered — 11 + 5 + 2 + 1 + 0 = 19 ✓.** 11 RESOLVED · 5 DISSOLVED · 2 PROPOSED (X-L1, X-L11 — pending ratification by the memory contract) · 1 DECOMPOSED (X-L17) · **0 OPEN**.
>
> ### **R74.1 — THE DOMINANT CONTRADICTION CLASS IS "ONE NAME, TWO ALTITUDES."**
> **Six of nineteen** (X-L1, X-L5, X-L6, X-L11, X-L14, X-L16) are instances of a single name covering two altitudes with different authorities. This series has now found the same defect as **X-E** (P0-03 trust), **X-G** (P0-02), **X-M1** and **X-M2** (P0-04), and **X-L1/X-L5/X-L11** here.
> **⟹ R74.2 — STANDING RESOLUTION SCHEMA, PROPOSED FOR ALL FUTURE CONTRACTS:**
> **Before ruling on whether a quantity is learnable, writable, gated or bounded, determine its BLAST RADIUS. A quantity with two blast radii is two quantities, and each is governed at its own altitude.**
> `LearnedChange.blast_radius` (§1, A2 field) is the instrument. **P0-05 is the first contract in the series to have blast radius as a first-class field, which is why it can state the schema rather than only apply it.**

---

# 75. **[O50] CIRCULAR DEPENDENCY AUDIT

§71.3 identified three near-cycles in the parameter graph. §75 widens to all circular dependencies, architectural and contractual.

## 75.1 The register

| ID | **Circular dependency** | **Form** | **Closable?** | **Resolution / containment** |
|---|---|---|---|---|
| **CD-L1** | **The plasticity loop** | `plasticity_mult → Δθ → activity → plasticity_mult` | ✅ **CLOSED** | Four independent breaks (§71.3 NCY-1): off-cell `loop_gain < 1` (R15.7) · K-only writer (Cell §4.1.8) · monotone-decreasing feedback (R15.5) · non-learnable set-point (R15.3, R58.5). |
| **CD-L2** | **The calibration loop** | `confidence_in_error → Δθ gain → behaviour → calibration measurement → confidence_in_error` | ✅ **CLOSED — by a NEW rule** | **R23.2**: T8 consumes UDB and requires probe verification. **Open in the inherited design; this is P0-05's most consequential cycle closure (D-L15/D-L85).** |
| **CD-L3** | **The validator loop** | learning-rule diff → alters validation rules → validates the next diff | ❌ **NOT CLOSABLE ARCHITECTURALLY** | **CONTAINED — R24.3**: a FIXED, NON-EMPTY, `[RO-13]`/KC-owned validation core outside the evolvable set + one-diff-per-lineage rate limit + non-evolvable invariant kernel (Rule 19). **The core's CONTENTS are a governance decision P0-05 cannot make. OR-L2.** |
| **CD-L4** | **The evidence loop (RH-2)** | learning → behaviour → world → external evidence → verifies the learning | ❌ **NOT CLOSABLE** | **CONTAINED — §56.2's ten mechanisms.** The organism is causally upstream of its own evidence. **OR-L6. The binding limit.** |
| **CD-L5** | **The verification-cost loop** | probes cost B9 ⟹ B9 limits anchors ⟹ anchors limit UDB ⟹ UDB limits learning ⟹ **less learning means less need for probes means less B9 justification** | ⚠️ **PARTIALLY CLOSED** | **R10.3.1 makes `adaptability` = verified learning throughput**, so a starved scope's *low throughput* is a fitness-visible quantity rather than a silence. **⟹ The loop is broken on the justification side: low throughput argues FOR budget, not against it.** Residual: allocation is `[RO-13]`'s decision (R47.2) and P0-05 cannot compel it. |
| **CD-L6** | **The specialisation loop** | specialise → ↑ throughput → ↑ measured demand → ↑ specialisation | ✅ **CLOSED** | **R46.1** (demand may propose, not write — specialisation is E4/E7) + **R46.2** (mandatory de-specialisation path) + **R46.4** (diversity as a hard constraint). V3 §18's loop had no external term; R46.4 supplies one that cannot be traded against. |
| **CD-L7** | **The availability-capture loop** | rarely retrieved → rarely used → appears useless → deprioritised **or pruned** | ⚠️ **CONDITIONAL** | **R27.3** (`disuse_cause = IRRELEVANT` mandatory; `UNREACHABLE` insufficient) closes the *pruning* arm. The *deprioritisation* arm is P0-04 §26.3's and remains under X-L1's **pending ratification** for the retrieval-weight half. |
| **CD-L8** | **The cascade loop (general)** | reduced engagement → reduced corrective evidence → reduced estimated competence → reduced engagement | ⚠️ **BOUNDED, NOT CLOSED** | **R39.4 names it; R40.3/R57.3 impose bounded exposure obligations; R63.3's eight detectors observe it; SM-6 formalises it.** **Not closed because the obligation's rate is `[G]` with no value, and because OR-L5 means the architecture cannot determine whether the reduced engagement was correct.** |
| **CD-L9** | **The Baldwinian ratchet** | selection favours matching priors → population priors converge on ancestral acquired state | ⚠️ **BOUNDED — INHERENT** | **R25.4** (mandatory diversity check with per-dimension `[G]` floors, hard-constraint enforcement). **Not closed because closing it fully would prohibit evolution.** |
| **CD-L10** | **The workspace-homogenisation loop** | learned broadcast preference → confirming content broadcast → all scopes condition on it → signals correlate → preference reinforced | ✅ **CLOSED** | **R60.5** (`[G]`-reserved governance slots the learned preference does not control) + **R60.6** (per-scope fraction cap) + **R60.4** (counter). **C-1's principle applied to broadcast.** |
| **CD-L11** | **The self-model loop** | self-model → simulation → SC-1 attribution → Δθ → changed organism → self-model update | ✅ **CLOSED** | **R59.1** (metered, not intended) + **R59.3** (the self-model is not an input to its own update; it is *replaced*, not *revised*). **The loop is broken by removing the self-referential edge.** |
| **CD-L12** | **The meta-objective loop** | meta-learner optimises the criterion by which its selections are judged | ✅ **CLOSED** | **R38.3** (the meta-objective is not learnable) + **R38.4** (probe criteria are part of the fixed core). **R10.2's principle at M1 altitude.** |
| **CD-L13** | **The findings-as-influence loop** | learner generates findings → governance acts → policy changes → learner's environment changes → learner generates findings | ⚠️ **BOUNDED, NOT CLOSED** | **R65.2**: findings carry their producing scope's counters and signal-class histogram, so a self-referential origin is **legible**. **Detection, not prevention — and prevention would require suppressing findings, which would be worse (§65.3 residual 2).** |

## 75.2 Reconciliation and the structural result

| Status | Count | IDs |
|---|---|---|
| **CLOSED** | **6** | CD-L1, CD-L2, CD-L6, CD-L10, CD-L11, CD-L12 |
| **PARTIALLY CLOSED** | **1** | CD-L5 |
| **CONDITIONAL** | **2** | CD-L7 (pending X-L1 ratification), CD-L9 (bounded-inherent) |
| **BOUNDED, NOT CLOSED** | **2** | CD-L8, CD-L13 |
| **CONTAINED, NOT CLOSABLE** | **2** | **CD-L3 (OR-L2), CD-L4 (OR-L6)** |
| **TOTAL** | **13** | |

> ### **R75.1 — ELEVEN OF THIRTEEN CIRCULAR DEPENDENCIES ARE BROKEN BY *WRITER SEPARATION*, NOT BY A BOUND.**
> CD-L1 (K writes `plasticity_mult`) · CD-L2 (external calibration writes `confidence_in_error`) · CD-L6 (`[RO-13]` writes specialisation) · CD-L10 (`[RO-13]` reserves slots) · CD-L11 (K meters the self-model) · CD-L12 (`[RO-13]` owns the meta-objective) · CD-L3 (`[RO-13]`/KC owns the core) · CD-L5 (fitness policy owns throughput's meaning) · CD-L7 (governance owns `disuse_cause` adjudication) · CD-L8 (`[RO-13]` grants B8) · CD-L13 (governance reads the histogram).
> **In every case the cycle is broken by ensuring that the edge which closes the loop is written by a party outside the loop.**
> **⟹ THIS IS THE CENTRAL STRUCTURAL RESULT OF P0-05, AND IT GENERALISES:**
> ### **A BOUND CANNOT BREAK A CYCLE — IT CAN ONLY MAKE THE CYCLE SMALLER. ONLY A WRITER SEPARATION CAN BREAK ONE.**
> **Corollary for future contracts: when a circular dependency is found, the first question is not "what bound limits it?" but "who writes the edge that closes it, and can that writer be moved outside the loop?"** Cell §9.6's K-only verdict, P0-04's external admission gate, P0-03's plane separation and P0-02's signature-proves-origin are all instances of the same move, and R75.1 states it as a principle.
>
> **The two that cannot be broken by writer separation are CD-L3 and CD-L4 — and in both, the closing edge is written by the *world* or by *governance's own judgement*, neither of which can be moved outside the loop without removing the organism's agency or the governance authority's competence. They are contained and declared (§87).**

---

# 76. **[O51] SCALABILITY

## 76.1 The cost table

| Operation | Cost per event | Cost per organism per epoch | Scales? |
|---|---|---|---|
| `Δθ` at a component | `O(1)` | `O(N)` | ✅ |
| UDB check | `O(|S|)` at scope S | `O(N)` total across the partition | ✅ |
| Credit assignment (CR-A) | `O(|S|)` | `O(N)` | ✅ **R6.4.1 — no cross-scope credit object exists** |
| Credit assignment (CR-B, ablation) | **expensive — an intervention** | `O(E3+ operations)` ≤ B6 | ✅ **because B6 is a count budget** |
| Learning-signal delivery | `O(1)` targeted, epoch-scoped | `O(signals)` | ✅ **P0-03 rejected `O(N)` broadcast; Cell §6.2's `eval.reward.v1` is targeted** |
| Probe | **expensive** | `O(B9)` | ⚠️ **THE BOTTLENECK — §76.2** |
| Accounting / observability | — | **`O(6 × 22) + O(36)` ≈ 168** | ✅ **`O(1)` per organism, independent of N (R52.3)** |
| Cross-scope correlation monitor | — | `O(36)` | ✅ |
| Matrix / ladder publication | — | `O(1)` read-only | ✅ |
| Baldwinian proposal evaluation | **expensive (11 gates + validation)** | `O(B7)` | ✅ **quota-bounded** |

> ### **R76.1 — THE ARCHITECTURE IS `O(N)` IN LEARNING AND `O(1)` IN GOVERNANCE ACCOUNTING.**
> **No quantity in this contract is `O(N²)`.** The three places a global quantity could have appeared — credit (R6.4.1), UDB (R4.3/R18), observability (R52.3) — are all scoped or counter-based. **§87's O(N²) prohibition is satisfied not by refusing global learning but by making every global-learning quantity decomposable.**

## 76.2 The bottleneck, honestly

> ### **R76.2 — SCALABILITY IS LIMITED BY B9, THE PROBE BUDGET, AND THE LIMITATION IS STRUCTURAL RATHER THAN ACCIDENTAL.**
> **The chain:** `N ↑ ⟹` more scopes and more changes `⟹` more probes needed to anchor `⟹` B9 is fixed by `[RO-13]` allocation `⟹` anchors per change fall `⟹` the fraction of changes reaching a verdict falls `⟹` `verdict_distribution[UNKNOWN] ↑` `⟹` UDB exhausts sooner relative to learning demand `⟹` **stall frequency rises.**
> **⟹ AT SCALE, THE ORGANISM LEARNS MORE SLOWLY. NOT LESS SAFELY — MORE SLOWLY.**
> **This is R0.1's designed behaviour and R47.1's stated consequence, and it is the honest answer to §87's "do not claim perfect learning."** The architecture does not degrade into unsafety at scale; it degrades into **stalling**, which is observable (`stall_reason`, `verdict_distribution`), named, and governable (allocate more B9, or accept slower learning).
>
> **Three scaling regimes, and which governs each:**
> | Regime | Condition | Behaviour |
> |---|---|---|
> | **Verification-rich** | B9 ≫ demand | Most changes reach a verdict; anchors are fresh; UDB rarely binds. **The inherited Cell §9.6 picture.** |
> | **Verification-matched** | B9 ≈ demand | UDB binds occasionally; stalls are transient; `verdict_distribution[UNKNOWN]` is moderate. **The intended operating point.** |
> | **Verification-scarce** | B9 ≪ demand (**the large-N regime**) | UDB binds constantly; most changes are `PROVISIONAL` permanently; R1.3 ages them out; **effective learning rate ≈ B9 / (cost per anchor)**. **The organism becomes a slow, heavily-provisional, envelope-shrunk learner — which is the correct behaviour for a system that cannot verify itself, and is preferable to the inherited alternative (D-L1: fast, unverified, unbounded).** |

## 76.3 What does NOT scale

| Does not scale | Why | Consequence |
|---|---|---|
| **S5 verification** | C-2 (cross-scope probe) is unavailable at S5 — there is no larger scope | **R18.2: `UDB_MAX[S5]` is smallest. Organismal-level learning is the most tightly leashed and will stall first.** Deliberate. |
| **Λ3 verification** | **OR-L3 — no probe design exists for topology** | E3+ operations require CR-B ablation, which is a *causal* check on the removed component, not a *held-out* check on the resulting circuit. **The architecture requires verification it cannot yet specify.** |
| **Cross-scope joint causation** | **OR-L4** | Distributed failures whose parts are each locally compliant are invisible. `O(36)` correlation monitor sees correlation, not causation. |
| **RH-2 containment** | **OR-L6** | Ten containment mechanisms, none of which closes it. At scale, more behaviour ⟹ more world-shaping ⟹ more contamination. **Containment does not improve with N.** |

---

# 77. **[O52] HARDWARE PORTABILITY

## 77.1 What the contract requires of a substrate

> ### **R77.1 — FOUR CAPABILITIES, AND NOTHING ELSE.**
> Any substrate supporting P0-05 must provide:
> 1. **Addressable mutable state** with a **distinguished write-authority partition** (INV-07's two-writer split; R19.2's governance/state separation). **This is the only hard requirement, and it is a *security* requirement, not a performance one.**
> 2. **Discrete epochs** (EIK-INV-14 binding; `epoch` on every `LearnedChange` and `SignalProvenance`).
> 3. **An external signed evaluation channel** (EVA signatures; R12.1; `probe_ref`).
> 4. **Durable, checksummed storage for anchors, checkpoints, tombstones and the change log** (SM-3, R62.3, R27.2, INV-38).
>
> **Nothing else.** No requirement for: differentiability, gradients, backpropagation, floating point, tensor operations, a specific memory hierarchy, a specific interconnect, synchrony, or a specific concurrency model. *(R72.1's substrate neutrality, restated as a portability requirement.)*

## 77.2 Portability audit across substrate classes

| Substrate | (1) write partition | (2) epochs | (3) signed external channel | (4) durable checksummed storage | **Portable?** |
|---|---|---|---|---|---|
| **CPU / general-purpose** | ✅ process/privilege separation | ✅ | ✅ | ✅ | ✅ **Yes** |
| **GPU / accelerator (differentiable)** | ⚠️ **the hard one — see R77.2** | ✅ | ✅ | ✅ | ⚠️ **Conditional** |
| **Neuromorphic / spiking** | ⚠️ | ⚠️ **epochs vs event-driven time** | ✅ | ✅ | ⚠️ **Conditional** |
| **FPGA / reconfigurable** | ✅ configuration vs data path | ✅ | ✅ | ✅ | ✅ **Yes** |
| **Distributed / multi-node** | ✅ | ⚠️ **epoch agreement across nodes** | ✅ | ✅ | ⚠️ **Conditional** |
| **In-memory / volatile** | ✅ | ✅ | ✅ | ❌ **anchors and tombstones must survive** | ❌ **No — fails (4)** |
| **Analogue / non-digital** | ⚠️ | ⚠️ | ⚠️ | ❌ **checksums require discrete state** | ❌ **No** |

> ### **R77.2 — THE GPU PROBLEM: A SUBSTRATE WHOSE NATURAL OPERATION IS A GLOBAL WRITE.**
> A differentiable accelerator's native operation is a **single kernel applying one update rule across all parameters simultaneously**. P0-05 requires:
> - **per-scope budgets** (B2, B5, B6 are scope-indexed) — a uniform kernel applies one bound everywhere;
> - **per-parameter clips** (B1) with **scope-varying** `UDB_MAX` (INV-17);
> - **a two-writer split** (INV-07) where K writes some fields and the learner writes others;
> - **stall propagation downward only** (R18.1), which is an *asymmetric* scope relation, not a uniform mask.
> **⟹ None of this is impossible; all of it requires that the update be MASKED PER SCOPE and that the mask be K-owned rather than kernel-owned.**
> **Ruling: a differentiable substrate is portable IFF the scope mask and the budget accounting are computed OFF the accelerator and applied as an externally-supplied, K-signed mask. A substrate that computes its own update mask is a substrate in which the learner writes its own bounds — an INV-06/R54.2 violation.**
> **⟹ This is a genuine portability constraint and it is the one most likely to be silently violated by an implementation optimised for throughput. Declared, not hidden.**

> ### **R77.3 — THE EPOCH PROBLEM ON EVENT-DRIVEN AND DISTRIBUTED SUBSTRATES.**
> Spiking/neuromorphic substrates have no natural epoch; distributed substrates have no natural *agreement* on epochs. **Every `LearnedChange`, `SignalProvenance` and `Prediction` carries an `epoch`, and EIK-INV-14's replay defence depends on epochs being globally meaningful.**
> **⟹ Ruling: an epoch is a K-declared logical boundary, not a substrate clock tick. A substrate without a natural epoch requires K to declare one; a distributed substrate requires epoch agreement, which is P0-03's/EIK's problem, not P0-05's.** **P0-05 does not solve distributed epoch agreement and does not claim to; it requires that an epoch exist and be K-declared.**

> ### **R77.4 — PORTABILITY IS NEUTRAL WITH RESPECT TO LEARNING ALGORITHM AND NON-NEUTRAL WITH RESPECT TO AUTHORITY.**
> **Any learning mathematics ports. Not every authority model ports.** A substrate that cannot express "these fields are writable only by a party outside the process performing the write" cannot host this contract, regardless of how good its gradients are. **⟹ The binding portability requirement is (1), the write-authority partition — and it is a *security* property, so a substrate that approximates it does not host the contract approximately; it fails to host it.**

---

# 78. **[O55] CONFORMANCE AND TESTABILITY

## 78.1 What "conformant" means

> ### **R78.1 — A SYSTEM CONFORMS TO P0-05 IFF EVERY `LEARN-INV` HOLDS, EVERY STATE MACHINE ADMITS ONLY ITS DECLARED TRANSITIONS, AND EVERY `[∅]` PARAMETER IS ABSENT.**
> Conformance is **not** a performance claim, not a capability claim, and not a safety claim. **A conformant system may still learn badly, stall constantly, and be wrong about everything.** Conformance means the *governance of change* is as specified. **This distinction is the whole of §87's "do not claim perfect learning."**

## 78.2 Testability classification of the 42 invariants

| Class | Meaning | Count | Invariants |
|---|---|---|---|
| **T-STATIC** | Checkable by type/enum/schema inspection, no execution | **9** | 02 (Λ5 ∉ enum), 03 (single target), 08 (closed kind set), 12 (admissible reward kinds), 14 (forbidden fields absent), 21 (`lr_structural` absent), 27 (Λ4 writable scope), 30 (S6 empty), 32 (no internal event raises status) |
| **T-UNIT** | Checkable on a single record/transition | **12** | 01, 04, 05, 06, 07, 09, 10, 11, 13, 15, 19, 38 |
| **T-SCOPE** | Checkable within one scope over a window | **11** | 16, 17, 18, 20, 22, 23, 24, 25, 26, 33, 34 |
| **T-SYSTEM** | Requires cross-scope or cross-contract observation | **7** | 28, 29, 31, 35, 36, 37, 39 |
| **T-ADVERSARIAL** | Requires an adversary to attempt a violation | **3** | 40 (corruption fails safe), 41 (no failure mode increases capacity), 42 (ladder monotone) |
| **TOTAL** | | **42** ✓ | |

> ### **R78.2 — 21 OF 42 INVARIANTS ARE CHECKABLE WITHOUT EXECUTION OR WITH UNIT-SCOPE TESTS.**
> **T-STATIC (9) + T-UNIT (12) = 21.** This is the conformance floor: **a system can be certified against half the invariant set by inspection and unit test alone**, which is what makes the contract auditable rather than merely aspirational.
> **The three T-ADVERSARIAL invariants are the ones that matter most and are the hardest to test** — 41 and 42 are the directional invariants (R28.2, R66.1), and testing them requires *inducing* every failure mode and confirming no capacity increase. **⟹ R78.3: the T-ADVERSARIAL invariants are tested by FAULT INJECTION over the §66 ladder's six downward transitions × the four governed quantities (plasticity, envelope, budget, authority) = 24 cases, each asserting monotonicity.** That is a finite, enumerable test suite, not an open-ended one.

## 78.3 Testability of the 70 attacks

| Disposition | Testable how | Count |
|---|---|---|
| **CLOSED-STRUCTURAL** | **By inspection** — the object does not exist | **12** (A3, A6, A8, B1, B5, B9, C4, C5, C6, D7, D8, E5, E7, F1, F3, H1, H4 → *recount below*) |
| **CLOSED** | **By adversarial unit test** — attempt the violation, assert rejection | 40 |
| **CONDITIONAL** | **By test of the named condition** | 5 |
| **BOUNDED** | **By rate/extent measurement over a window** | 12 |
| **OPEN** | **NOT testable as a defence; testable only as a DETECTOR** | 1 |

**CLOSED-STRUCTURAL recount:** A3, A6, A8 (3) · B1, B5, B9 (3) · C4, C5, C6 (3) · D7, D8 (2) · E5, E7 (2) · F1, F3 (2) · H1, H4 (2) = **17**.
**⟹ CORRECTED: 17 CLOSED-STRUCTURAL, 34 CLOSED (51 total closed − 17 structural), 5 CONDITIONAL, 12 BOUNDED, 1 OPEN, 1 detection-augmented = 70.** ✓

> ### **R78.4 — THE ONE OPEN ATTACK IS TESTABLE ONLY AS A DETECTOR, AND THE TEST ASSERTS DETECTION, NOT PREVENTION.**
> **LEARN-C2 / RH-2 / OR-L6:** the conformance test asserts that (a) `EVIDENCE_SELECTION_SUSPECT` fires under a constructed evidence-shaping scenario (R33.2), (b) `EVALUATOR_SELECTION_SUSPECT` fires under routing concentration (R53.4), (c) `behavioural_reach = ORGANISM_OUTPUTS` changes are flagged (C-3), and (d) **no rule converts any of these into a warrant, fitness, verification or authority increase** (R9.3, P0-04 §91).
> **The test does NOT assert that the attack fails. It asserts that the attack is visible and unrewarded.** **⟹ This is the honest form of a conformance test for an unclosable attack, and §87's "do not claim perfect learning/causal inference" requires exactly this framing.**

## 78.4 Conformance levels

| Level | Requirement | Meaning |
|---|---|---|
| **CL-0** | All `[∅]` parameters absent (20, §70.8) | **The floor. A system with a `credit` field, a `Λ5` target, an `ε`, or a scalar `SELECTION_SCORE` is not a P0-05 system at any level.** |
| **CL-1** | CL-0 + all T-STATIC and T-UNIT invariants (21) | **Certifiable by inspection and unit test.** |
| **CL-2** | CL-1 + all T-SCOPE invariants (11) + SM-1…SM-4 transition conformance | **Certifiable by scoped integration test.** |
| **CL-3** | CL-2 + all T-SYSTEM invariants (7) + SM-5…SM-7 | **Certifiable by cross-scope test. Requires OR-L3's Λ3 probe — ⟹ CL-3 IS NOT FULLY CERTIFIABLE TODAY, and this is declared.** |
| **CL-4** | CL-3 + all T-ADVERSARIAL invariants (3) via the 24-case fault-injection suite (R78.3) | **Full conformance.** |

> ### **R78.5 — CL-3 IS BLOCKED BY OR-L3, AND THE CONTRACT SAYS SO.**
> SM-5's `VERIFIED_CR_B` transition at circuit level has no specified probe design (OR-L3). **⟹ A system cannot be certified at CL-3 for Λ3 operations, because the certification criterion does not exist.** **This is not a gap in the test suite; it is a gap in the architecture, correctly propagated into the conformance levels rather than papered over.** §82 records it as a **P0 gap**.

---

# 79. **[O53] ABLATION — WHAT BREAKS IF A MECHANISM IS REMOVED

**Method:** for each mechanism P0-05 adds or inherits, state what becomes possible if it is removed. **An ablation whose consequence is "nothing measurable" is a mechanism that should not exist (Rule 17: smallest sufficient mechanism).**

| # | **Mechanism** | **If removed** | **Consequence class** | **Verdict** |
|---|---|---|---|---|
| **AB-1** | **R0.1 UDB + stall** | **D-L1 returns in full.** Bounded steps, unbounded walk. The organism migrates arbitrarily far from any verified state, compliantly. **Also: model collapse (R48.2) becomes unbounded; RH-8 anchor laundering becomes free; the probe budget stops being the learning rate and becomes a decorative statistic.** | **CRITICAL** | **Load-bearing. The single most consequential mechanism in the contract.** |
| **AB-2** | **R1.3 envelope shrinkage** | **§0.2(a) returns: "provisional" is an accounting label with no effect.** An unverified change has full behavioural reach forever. **Also: R36.2's exploration ceiling, R57.2's quarantine-as-envelope, and R15.10's `SLOW_MODE` correction all lose their instrument.** | **CRITICAL** | **Load-bearing.** |
| **AB-3** | **R0.2 `LearnedChange` object** | **A4 (reversibility) has no home ⟹ R0.3 cannot operate ⟹ §29's ladder has no argument ⟹ INV-01/03/04/07 fail.** Also: no lineage (R64.1), no audit (R54.2), no decomposition (R29.3). | **CRITICAL** | **Load-bearing. Everything in Vol D/E depends on it.** |
| **AB-4** | **A4 reversibility axis** | **Authority has nothing to scale with except magnitude ⟹ R0.3 collapses ⟹ E0 and E3 get the same authority ⟹ LEARN-A6 and LEARN-F1 succeed.** | **CRITICAL** | **Load-bearing.** |
| **AB-5** | **§28 authorization matrix** | **D-L5 returns: plasticity capacity governed by one rule.** Sixteen ∅-cells become permissions. **LEARN-A2, A5, A8 succeed.** | **CRITICAL** | **Load-bearing.** |
| **AB-6** | **§29 escalation ladder** | **D-L19 returns.** No authority ordering for structural change. **LEARN-A6, F2, F4, F7, F8 succeed.** | **CRITICAL** | **Load-bearing.** |
| **AB-7** | **R28.2 directional asymmetry / INV-41** | **A failure mode could increase capacity.** Every cascade (R39.4's eight) becomes self-amplifying rather than self-limiting. **The §66 ladder becomes bidirectional.** | **CRITICAL** | **Load-bearing. This is the contract's spine.** |
| **AB-8** | **R19.2 governance/state write separation** | **CD-L1…CD-L3, CD-L10…CD-L13 reopen.** R75.1's structural result is void. **The learning system becomes a governance layer (§65 fails).** | **CRITICAL** | **Load-bearing.** |
| **AB-9** | **Cell §9.6 K-only verdict** (inherited) | **LEARN-E7 succeeds. C3's circularity returns. Everything downstream of `improvement_verified` — anchors, nomination, CH-3 motivation, fitness — becomes self-assessed.** | **CRITICAL** | **Load-bearing (inherited).** |
| **AB-10** | **R12.1 `source = EVA_ONLY`** (inherited) | **LEARN-B1, C6 succeed. Reward forgery at the type level reopens.** | **CRITICAL** | **Load-bearing (inherited).** |
| **AB-11** | **R14.2 novelty only reduces plasticity** | **Novelty farming becomes a resource-exhaustion and plasticity-inflation channel.** V3 §8's «useful novelty → preserve» becomes a positive authority for a manufacturable signal. | **HIGH** | **Load-bearing.** |
| **AB-12** | **R13.1 pre-registration** | **Hindsight error returns.** R6.4.4's relief valve becomes a self-service reward: the expectation is chosen after the observation. | **HIGH** | **Load-bearing.** |
| **AB-13** | **R22.1 dedup not aggregate** | **LEARN-B5, B6 succeed. Coordination among cells becomes a route to external-grade authority.** | **HIGH** | **Load-bearing.** |
| **AB-14** | **R23.2 T8 consumes UDB** | **CD-L2 / NCY-2 reopens — and it was OPEN in the inherited design.** Unbounded learning-rate increase via calibration, with no `Δθ` in the audit trail. **LEARN-D4 succeeds.** | **CRITICAL** | **Load-bearing. The most consequential new closure.** |
| **AB-15** | **R6.4.1 scoped credit** | **The O(N²) global learner returns.** §87's explicit prohibition violated. R35.1's `O(N)` result void. | **CRITICAL** | **Load-bearing.** |
| **AB-16** | **R6.4.4 prediction error as the relief valve** | **`UNATTRIBUTABLE` outcomes produce either nothing (silent inability to learn, D-L7) or a synthesised proxy (RW-5, R12.4's prohibition).** Both are worse. | **HIGH** | **Load-bearing.** |
| **AB-17** | **R9.4.1 secret probe schedule** | **LEARN-E1 becomes fully open.** R0.1's fix moves the attack surface to the probe (D-L12) and R9.4.1 is the primary defence. Without it, only R9.4.2/3 remain, which bound but do not prevent. | **HIGH** | **Load-bearing.** |
| **AB-18** | **R25.2 spread floor** | **LEARN-H2 succeeds: covert Lamarckism by variance narrowing.** R47.1's and R25.1's Baldwinian test is defeated by accumulation. | **HIGH** | **Load-bearing.** |
| **AB-19** | **R27.2 tombstone** | **LEARN-F6 succeeds.** Pruning destroys the audit trail of every change touching the connection. **INV-39 fails; §64's lineage requirement fails retroactively.** | **HIGH** | **Load-bearing.** |
| **AB-20** | **R27.5 / R15.4 / R9.2.4 UDB conservation** | **LEARN-D2, D5, D6 succeed.** Displacement escapes by moving off θ, by decaying, or by deleting its carrier. **The conservation property (§27.2) is lost and D-L1 returns through three side doors.** | **CRITICAL** | **Load-bearing.** |
| **AB-21** | **R46.4 diversity as a hard constraint** | **LEARN-G4, H6 worsen.** Diversity becomes tradable against performance, which is Rule 15 of the 20 (*rare-but-valuable strategies must not be auto-eliminated*) losing its only enforcement point. | **HIGH** | **Load-bearing.** |
| **AB-22** | **R40.3 / R57.3 exposure obligations** | **CD-L8 becomes unbounded.** Five (now eight) cascades converge on silence with no counterweight. P0-04's L-11 loses its learning-side dual. | **HIGH** | **Load-bearing.** |
| **AB-23** | **R60.5 reserved workspace slots** | **CD-L10 reopens.** The workspace becomes a mirror; population signals correlate; Cell §11.5's ρ-discount correctly reports non-independence after the damage is done. | **MEDIUM-HIGH** | **Load-bearing.** |
| **AB-24** | **R59.1/R59.3 self-model from metering** | **CD-L11 reopens.** The self-model absorbs its own error into its description. R42.5's simulation diagnostics lose their reference. | **HIGH** | **Load-bearing.** |
| **AB-25** | **R62.3 checkpoint ≠ anchor** | **LEARN-A3 succeeds: self-anchoring.** R0.1 is defeated by taking a checkpoint. **The entire UDB mechanism becomes decorative.** | **CRITICAL** | **Load-bearing.** |
| **AB-26** | **R64.4/R64.5 fail-safe corruption** | **INV-40 fails.** A corrupted anchor or counter could produce *less* restriction. **The degradation ladder becomes non-monotone under fault.** | **HIGH** | **Load-bearing.** |
| **AB-27** | **§63's 22 counter families** | **Nothing is prevented, but nothing is visible.** All eight cascade detectors (R63.3) go dark; `stall_reason` becomes undifferentiated; R47.1's probe-budget consequence is unobservable; R48.4's three stall causes collapse into one. **⟹ The architecture still *works* and cannot be *governed*.** | **HIGH** | **Load-bearing for governance, not for safety.** |
| **AB-28** | **R61.3 no structural learning rate** | **LEARN-F1 succeeds: silent deletion by gradient.** The most dangerous available mis-implementation becomes available. | **CRITICAL** | **Load-bearing.** |
| **AB-29** | **R36.1 exploration as budget not reward** | **Novelty farming returns as a reward-maximisation problem (RW-6).** R36.4's EX-1 measurement loses its object. | **HIGH** | **Load-bearing.** |
| **AB-30** | **R10.3 rejection of the scalar selection score** | **X-L2 returns.** A ten-term sum with no weights and no uncertainty, containing a tautology and RW-7 contamination, drives selection. **R8.2's corollary (no scalarisation inside the learner) loses its fitness-side analogue.** | **HIGH** | **Load-bearing.** |
| **AB-31** | **R74.2 blast-radius resolution schema** | **X-L1, X-L5, X-L6, X-L11, X-L14, X-L16 return as live contradictions**, joining the series' X-E, X-G, X-M1, X-M2. **Six of nineteen contradictions become unresolvable.** | **HIGH** | **Load-bearing — for the contract series, not only for P0-05.** |
| **AB-32** | **R24.3 fixed validation core** | **CD-L3 / OR-L2 becomes fully open.** A learning-rule diff alters the instrument verifying the next diff, with no fixed point. **Rule 19 of the 20 (invariant kernel separate from evolvable substrate) loses its enforcement point.** | **CRITICAL** | **Load-bearing — and its *contents* remain unspecified by design.** |

## 79.1 Ablation reconciliation

> ### **R79.1 — 32 MECHANISMS ABLATED; 0 HAVE NO CONSEQUENCE. (Machine-recounted: 16 + 15 + 1 = 32 ✓)**
> | Consequence class | Count |
> |---|---|
> | **CRITICAL** | **14** — AB-1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 14, 15, 20, 25, 28, 32 → *recount: 1,2,3,4,5,6,7,8,9,10,14,15,20,25,28,32 = **16*** |
> | **HIGH** | **14** — AB-11, 12, 13, 16, 17, 18, 19, 21, 22, 24, 26, 27, 29, 30, 31 → *recount: **15*** |
> | **MEDIUM-HIGH** | **1** — AB-23 |
> | **NO CONSEQUENCE** | **0** |
> | **TOTAL** | **32** ✓ (16 + 15 + 1 = 32) |
>
> **⟹ Every mechanism in this contract survives ablation. Rule 17 of the 20 (prefer the smallest sufficient mechanism) is satisfied not by having few mechanisms but by having no redundant ones — and R48.2 is the one place where the contract deliberately adds *nothing*: model collapse is bounded by an existing mechanism (R0.1) rather than by a new detector.**
> **The two mechanisms that are load-bearing for *governance* rather than *safety* are AB-27 (observability) and AB-31 (the resolution schema). Removing either leaves the architecture safe but ungovernable or unauditable — which §87 treats as a failure, since it requires that origin, authority, scope, reversibility, provenance and consequences be *explicit*.**

---

# 80. THE FALSE-PRECISION AUDIT

**§87: DO NOT invent numerical parameters; DO NOT solve unknown research problems through arbitrary constants.** §80 audits this contract for violations.

| # | **Candidate false precision** | **Present?** | **Ruling** |
|---|---|---|---|
| **FP-1** | A value for `Δ_MAX`, `DELTA_BUDGET`, `Θ_MAX`, `UDB_MAX`, B6–B9 | ❌ | All `[G]`, no values (§70.9: **58 registered parameters, 0 values**) |
| **FP-2** | A value for `PROVISIONAL_AGE_{1,2,3}` | ❌ | `[G]`, **ordering kernel-enforced**, `[D]` dependency on the P0-10 cost model. **The ordering is normative; the values are not.** |
| **FP-3** | A value for `lr_fast/medium/slow` | ❌ | `[G]` + genome; **ordering `lr_fast ≥ lr_medium ≥ lr_slow` kernel-enforced** (INV-20). Same pattern: **relation normative, value not.** |
| **FP-4** | A probe frequency | ❌ | **This is Cell §9.6's `[U]`, and R47.1 is the resolution: not a number, but a structural consequence (B9 determines the learning rate; exhaustion produces a named stall).** OR-L1 remains open. |
| **FP-5** | A learning rate, convergence guarantee, or sample complexity | ❌ | **None claimed.** R72.1/R72.2: no algorithm is named, so no rate can be stated. |
| **FP-6** | A threshold for "significant" volatility, dispersion decline, or routing concentration | ❌ | All `[G]` thresholds; the **monotonicity** of each response is normative (`h_vol` decreasing, `g` increasing in quality, `h_age` decreasing) and the **value** is not. |
| **FP-7** | A diversity floor value | ❌ | `[G]` per-dimension floors. **The *hard-constraint* status is normative (R46.4); the floor is not.** |
| **FP-8** | A count of scopes, classes, rungs, signals, invariants, attacks | ✅ **and correctly so** | **These are structural, not empirical.** Six scopes, five Λ-classes, nine rungs, fourteen signal kinds, five signal classes, eight reward kinds, forty-two invariants, seventy attacks, seven state machines. **A structural count is not false precision; it is the specification.** |
| **FP-9** | A claim about how much better V4 is | ⚠️ **§85's ratings** | **⟹ R80.1: the before/after ratings in §85 are ORDINAL judgements about specification completeness, explicitly not measurements of system quality.** A 9/10 means "the contract specifies this thoroughly," not "the system performs well here." **Stated so that the ratings cannot be read as a performance claim.** |
| **FP-10** | The `O(N)` / `O(1)` / `O(36)` / `≈168` complexity figures | ✅ **and correctly so** | **These are exact structural counts over a declared scope partition (R52.3, R76.1), not empirical estimates.** `6 scopes × 22 counter families + 36 correlation cells = 168` is arithmetic on the specification. |
| **FP-11** | "Ten requirements" for pruning (R61.4), "sixteen exclusions" (R65.1), "ten containments" (§56.2), "eleven prohibitions of thirty matrix cells" (§28.2) | ✅ **and correctly so** | Enumerations of rules actually stated, each with a reference. **Machine-recounted in §80.1.** |
| **FP-12** | The claim that R0.1 "solves" D-L1 | ⚠️ | **⟹ R80.2: R0.1 CLOSES D-L1 as an unbounded-drift problem and OPENS OR-L1 as a verification-economics problem. It does not solve verification.** Stated explicitly in §0.4 and §76.2 so the closure is not over-read. |

## 80.1 Enumeration recount (§87 discipline, applied to this contract's own claims)

| Claim | Stated | Recounted | Match |
|---|---|---|---|
| Pruning requirements (R61.4) | 10 | authority · CR-B · `disuse_cause` · tombstone · UDB · trace invalidation · anchor invalidation · B6 · A4 class · diversity check = **10** | ✅ |
| Governance exclusions (R65.1) | 18 | §65.2's table rows 1–18 = **18** | ✅ |
| RH-2 containments (§56.2) | 10 | C-1, C-2, C-3, C-4, R9.4.1, R9.4.2/3 (counted as one row), R22.2, R33.2, R53.4, R47.2 = **10** | ✅ |
| `LearnedChange` fields (§1.1) | — | 24 fields | ✅ *(stated as a schema, not a count)* |
| Inherited learning mechanisms from Cell §9.5 | 7 | 7 | ✅ |
| Evidence-starvation cascade instances | 5 (R39.4) → 8 (R63.3) | R39.4 names 5; R63.3's detector table has **8** rows | ⚠️ **⟹ R80.3: R39.4 identifies FIVE instances and §63.3's detector table covers EIGHT — the three added are immune quarantine (R57.6), workspace homogenisation (R60.4) and specialisation narrowing (R46.3), found in Vol C/D after R39.4 was written. The pattern count is EIGHT; R39.4's five are its first five.** Reconciled here rather than left inconsistent. |
| Cell §9.2 triggers | 8 | T1–T8 = 8 | ✅ |
| V3.1 §6 plasticity scales | 5 | synapse, cell, connection, circuit, regional = 5 | ✅ |
| V3 L54 plasticity operations | 5 | strengthen, weaken, create, reroute, prune = 5 | ✅ |
| V3.1 §9 selection-score terms | 10 | 8 positive + 2 negative = 10 | ✅ |
| P0-01 §13 error classes | 10 | 10 | ✅ |
| P0-01 §14.4 fitness components | 13 | 13 | ✅ |
| Authorization-matrix cells (Vol B §28.2) | 30 | 6 scopes × 5 targets = 30; **11 outright prohibitions + 3 nomination/proposal-only + 16 unrestricted writes** | ✅ |
| Governance-exclusion rows (Vol D §65.2) | 18 rows | **16 exclusions + 2 non-governance permissions** (belief at fixed status; internal state) | ✅ |
| Attack dispositions (Vol E §67.9 / §78.3) | 70 | 35 CLOSED + 17 CLOSED-STRUCTURAL + 5 CONDITIONAL + 12 BOUNDED + 1 OPEN = **70** | ✅ |
| Counter families (Vol C R52.1 → Vol E §70.7) | 22 | 16 specified in Vol C + 6 added in Vols D–E = **22**; payload `O(6×22)+O(36)` ≈ **168** | ✅ |
| Contradiction dispositions (Vol F §74.1) | 19 | 11 + 5 + 2 + 1 + 0 = **19** | ✅ |
| Circular-dependency dispositions (Vol F §75.2) | 13 | 6 + 1 + 2 + 2 + 2 = **13** | ✅ |
| Ablation severities (Vol F §79.1) | 32 | 16 + 15 + 1 + 0 = **32** | ✅ |
| Parameter registry (Vol E §70.9) | 100 | 58 settable (13+9+7+10+10+9) + 22 counter families + 20 prohibited = **100**; **values specified: 0** | ✅ |
| Gap priorities (Vol F §82.1) | 17 | 5 P0 + 7 P1 + 5 P2 = **17** | ✅ |

> ### **R80.4 — THE FALSE-PRECISION AUDIT FINDS NO INVENTED NUMERICAL PARAMETER AND ONE INTERNAL COUNT DRIFT, RECONCILED AT R80.3.**
> **58 registered parameters with 0 values. 20 prohibited parameters. 3 declared `[U]`. 2 claims flagged as potentially over-readable (FP-9's ratings, FP-12's "solves") and explicitly qualified. 1 count drift (cascade instances 5→8) reconciled.**
> **Per §87, the three `[U]` entries are: (i) probe-cost economics (**OR-L1**), (ii) `PROVISIONAL_AGE` values (dependent on (i) via P0-10), (iii) the contents of the fixed validation core (**OR-L2**). None is resolved by a constant.**

---

# 81. **[O58] THE OPEN RESEARCH REGISTER

**§87: DO NOT hide unresolved problems.** Every entry states the problem, why it is open, what the architecture does instead, and what would close it.

| ID | **Open problem** | **Why it is open** | **What the architecture does instead** | **What would close it** | **Blocks** |
|---|---|---|---|---|---|
| **OR-L1** | **Verification economics.** How to verify that a learned change helped, cheaply, at scale. Inherited as Cell §9.6's `[U]`. | Probing every update at 10⁶ cells is infeasible; probing rarely lets bad updates persist. **No known method makes external held-out verification cheap.** | **R0.1 + R47.1: the probe budget becomes the learning rate, and its exhaustion produces a named, observable, scoped stall.** The `[U]` is *relocated* from a hidden statistic to an explicit architectural quantity. §76.2's three scaling regimes describe the degradation. | A verification method that is (a) external, (b) held-out, (c) cheap, and (d) not gameable by the verified party. **No candidate exists.** | CL-3 conformance partially; large-N learning rate |
| **OR-L2** | **The validator loop.** A learning-rule diff alters the instrument that validates the next diff (CD-L3 / NCY-3). | Any validator is either fixed (therefore an arbitrary governance choice) or evolvable (therefore inside the loop). **There is no third option.** | **R24.3: a FIXED, NON-EMPTY, `[RO-13]`/KC-owned validation core outside the evolvable set** + one-diff-per-lineage rate limit + non-evolvable invariant kernel (Rule 19) + R38.4 (probe criteria are part of the core). **P0-05 requires the core to EXIST and be NON-EMPTY; it does not specify its contents**, because doing so would be specifying the organism's values. | A method of validating a change to validation criteria that is not itself either arbitrary or circular. **This may be a genuine impossibility rather than an open problem.** | CH-3 for learning-rule diffs; CL-3 |
| **OR-L3** | **Λ3 verification.** How to verify that a *structural* change helped. | Cell §9.6's held-out probe measures θ's effect on prediction. **A topology change's effect is not a per-cell quantity**, and no probe design exists for circuits. SM-5's `VERIFIED_CR_B` transition requires a criterion P0-05 cannot supply. | **R6.4.2 mandates CR-B ablation at E3+, which is a *causal* check on the removed component — not a *held-out* check on the resulting circuit.** The gap is declared in-place in SM-5 and in §29.3. | A held-out probe design whose unit of measurement is a circuit rather than a cell. | **CL-3 conformance (R78.5)**; E3+ certification |
| **OR-L4** | **Cross-scope joint causation.** Two scopes jointly cause an outcome; neither can see it. | R6.4.1 forbids a credit object above the computing scope — **deliberately**, because the alternative is the O(N²) global learner. R35.2 states the loss explicitly. | **`O(36)` cross-scope correlation monitor over scoped summaries — FINDING-only, may not write.** E7 changes require cross-scope probes (C-2), the one place the architecture pays for a wider view. | A method of detecting distributed joint causation from scoped summaries without reconstructing global state. **May be information-theoretically impossible.** | R35.2's residual; §76.3 |
| **OR-L5** | **Learning from avoided bad outcomes.** A prevented outcome has no observation, hence no error, hence no signal. | **The direct consequence of three correct decisions** (R40.1): prediction error is primary; it requires an observation; abstention produces none. **Any architecture satisfying all three has this property.** Simulation cannot substitute (R42.1/R42.3). | **R40.3/R57.3's bounded exposure obligation forces re-engagement, producing observations about *what happens when the organism engages*.** SM-6 detects cascades but **cannot evaluate whether reduced engagement was correct** — declared in-place. | A counterfactual evaluation method that is externally grounded. **Counterfactual attribution exists (P0-01 §12.3) but is SC-1 and may not anchor (R42.2).** | Abstention correctness; SM-6's evaluation gap |
| **OR-L6** | **Evaluator manipulation (RH-2 / CD-L4 / D-L11 / LEARN-C2).** The organism shapes the world the evaluator samples. **THE ONLY OPEN ATTACK OF SEVENTY.** | The organism is **causally upstream of its own evidence**, and learning is the mechanism by which it moves further upstream. **No reward-function design, signal regime, probe design or governance separation closes it**, because the signals it produces are *genuinely external and valid*. Closing it would require the organism to have no effect on the world. | **Ten containments (§56.2): C-1…C-4, R9.4.1, R9.4.2/3, R22.2, R33.2, R53.4, R47.2.** Plus R9.3's honest statement and R21.1's authenticity≠soundness distinction. **The architecture's claim is that RH-2 is named, observable, rate-limited, and NEVER REWARDED — not that it is prevented.** | A method of distinguishing an externally-caused observation from a self-caused one, from inside the system. **Believed impossible.** | §86's SECURITY, EVOLUTION and OPEN-RESEARCH statuses |
| **OR-L7** | **Learned routing selects evaluators for ordinary messages.** | R53.3 closes it for learning signals and probe inputs. **Ordinary messages remain routed by learned preference, and warrant assignment depends on the recipient.** Removing learned routing would remove the influence plane's reason to exist. | **R53.4's `EVALUATOR_SELECTION_SUSPECT` finding** on routing concentration. **Detection, not prevention.** | Either a recipient-independent warrant assignment (which would contradict P0-03's design) or a routing-preference-free channel for all warrant-bearing messages (which would be a fourth plane — rejected by R34.1). | LEARN-C3's residual |
| **OR-L8** *(inherited)* | **Semantic self-reference.** | Inherited from P0-04 as open. | P0-05 touches it only via R59.1–R59.3 (the self-model is metered, not introspected; not an input to its own update) and R42.5 (`self_model_version` correlation). **P0-05 does not advance it and does not claim to.** | — | — |
| **OR-L9** *(inherited)* | **Causal-depth saturation.** | Inherited from P0-04. | **R6.4.2's CR-B regime and R13.3's "prediction error is not causality" both respect it**; P0-05 does not attempt causal inference beyond ablation at E3+. | — | — |
| **OR-L10** | **The contents of the fixed validation core.** | A governance/value question, not an architectural one. **P0-05 requires the core to exist and be non-empty (R24.3) and explicitly declines to specify it.** | Declared as `[U]` in §70.9 and as a dependency of OR-L2. | A governance decision by `[RO-13]`/KC. **Not a research result.** | CH-3, M1 |

## 81.1 Register reconciliation

> **10 entries: 7 new to P0-05 (OR-L1…L7, of which OR-L1 is inherited-and-relocated from Cell §9.6's `[U]`), 2 inherited-and-not-advanced (OR-L8, OR-L9), 1 governance-dependent (OR-L10).**
> **Of the 7 new: 1 is relocated rather than open (OR-L1 — R0.1/R47.1 convert it from a hidden statistic into an explicit architectural quantity, and §86 records this as the contract's principal positive result), 4 are contained (OR-L2, L3, L4, L7), and 2 are believed unclosable (OR-L5, OR-L6).**
> **⟹ R81.1: NO ENTRY IS RESOLVED BY A CONSTANT, AND NO ENTRY IS OMITTED.** Three entries (OR-L3, OR-L5, OR-L6) are additionally declared **in-place** inside the state machines and rules that require them (SM-5, SM-6, §9.3), so that a reader of any single mechanism encounters the gap at the point of use rather than only in a register.

---

# 82. **[O57] GAP REGISTER — P0 / P1 / P2

| Priority | **Gap** | **Where** | **Status** | **Required before** |
|---|---|---|---|---|
| **P0-1** | **No held-out probe design for Λ3 structural change** | OR-L3, SM-5, §29.3, R78.5 | **OPEN — blocks CL-3 conformance** | Any E3+ operation being *certifiable* (not merely *authorisable* — the authority and verification requirements are stated; the verification *method* is not) |
| **P0-2** | **The fixed validation core's contents are unspecified** | OR-L2, OR-L10, R24.3, R38.4 | **OPEN — governance decision, not research** | Any CH-3 learning-rule diff; any M1 meta-selection |
| **P0-3** | **X-L1 / X-L11 ratification by the memory contract** | §74, R41.2, R11.3 | **PROPOSED — P0-05 may not unilaterally amend P0-04** | Cell §9.3's memory-policy row being operative; LEARN-G7's availability-capture arm being closed |
| **P0-4** | **X-L5 amendment of P0-03 R3.2 (`plasticity_rate` cumulative bound)** | §74, R34.3 | **PROPOSED — P0-05 asserts the amendment; P0-03 must ratify** | S1 metaplasticity being bounded (LEARN-D3) |
| **P0-5** | **Probe-cost model dependency (P0-10)** | §70.9 `[U]`(ii), R47.1, R1.3 | **DEPENDENT** | `PROVISIONAL_AGE_*` and B9 allocation being settable |
| **P1-1** | **`behavioural_reach` aggregation window** (R67.1) | LEARN-A9 | **RULE STATED, WINDOW UNDEFINED** — `[G]` | Envelope-evasion detection at aggregate scale |
| **P1-2** | **Cross-scope correlation monitor's decision criteria** (R35.2) | OR-L4 | **MECHANISM STATED (`O(36)`, FINDING-only), CRITERIA `[G]`** | Distributed-failure detection |
| **P1-3** | **Anchor-quality grading function `g(·)`** (R9.4.2) | LEARN-E3 | **MONOTONICITY NORMATIVE, FORM `[G]`** | RH-7/RH-8 bounding being tunable |
| **P1-4** | **Bounded exposure obligation rate** (R40.3, R57.3) | CD-L8, OR-L5 | **MECHANISM STATED, RATE `[G]`** | The eight cascades being counterweighted in practice rather than in principle |
| **P1-5** | **`disuse_cause` adjudication method** (R27.3) | CD-L7, LEARN-F2 | **REQUIREMENT STATED (`IRRELEVANT` only), METHOD UNSPECIFIED** | E3 pruning being executable at all — **⟹ this is arguably P0, and is recorded P1 only because R27.3's `UNKNOWN`-insufficient rule fails safe: no adjudication ⟹ no pruning** |
| **P1-6** | **Λ2 verification method** | §28's Λ2 column, R41.5 | **P0-04 governs admission; P0-05 governs the `LearnedChange`. The probe for a *representation* change is unspecified, as for Λ3.** | CL-3 for Λ2 |
| **P1-7** | **`workspace_diversity` dispersion measure** (R60.4) | CD-L10 | **COUNTER STATED, MEASURE `[G]`** | Homogenisation detection |
| **P2-1** | **V3.1 §10's "full awareness loop" needs a full rewrite in V4 vocabulary** | R59.4, X-L17 | **DECOMPOSED by rule; the source text is not yet rewritten** | Documentation coherence |
| **P2-2** | **V3's master-loop diagram (L332–344) needs redrawing** | §5.1's four defects, §5.2's V4 loop | **V4 LOOP SPECIFIED; V3 DIAGRAM NOT YET SUPERSEDED IN THE SOURCE** | Documentation coherence |
| **P2-3** | **Anatomical scope names (S1–S6) may mislead an implementation into anatomical assumptions** | R72.5 | **OPERATIONAL DEFINITION BY BLAST RADIUS GIVEN (R4.2); NAMES RETAINED FOR TRACEABILITY** | Implementation clarity |
| **P2-4** | **Cell §9.4's `Δθ` formula reads as a mandate** | R72.4 | **EXPLICITLY DECLARED A SHAPE, NOT A MANDATE** | Implementation clarity |
| **P2-5** | **The 22 counter families need a common reporting schema** | §70.7, R52.1 | **FAMILIES ENUMERATED, SCHEMA NOT SPECIFIED** (deliberately — a schema is an implementation artifact, R72.1) | Observability tooling |

## 82.1 Gap reconciliation

> **17 gaps: 5 P0, 7 P1, 5 P2.**
> **Of the 5 P0 gaps: 2 are open research (OR-L3, OR-L2/L10), 2 are cross-contract ratifications (X-L1/X-L11 by the memory contract, X-L5 by the communication contract), and 1 is an external dependency (P0-10's cost model).**
> **⟹ R82.1: NO P0 GAP IS INTERNAL TO P0-05.** Every P0 gap is either an open research problem declared in §81, a ratification owed by or to another contract in the series, or a dependency on P0-10. **P0-05's own specification is complete at CL-2 and blocked at CL-3 by OR-L3 alone.**
> **This is the honest summary of the contract's state: it specifies everything it is competent to specify, and every remaining gap is either (a) a research problem no architecture can close, (b) another contract's decision, or (c) a governance value judgement. §87's "do not hide unresolved problems" is discharged by the fact that all 17 are listed with their blocking relation stated.**

---

# 83. VOLUME F — FINDINGS REGISTER

| ID | Finding | Severity | Disposition |
|---|---|---|---|
| **D-L91** | **AR-1…AR-6 all fail on at least one of economics, authority, or §87's explicit prohibitions.** AR-7 is not a hybrid but a specific allocation of external verification across three functions (R73.1). | — | **RESOLVED — §73.** |
| **D-L92** | **Nineteen cross-system contradictions, six of one class ("one name, two altitudes").** | **HIGH** | **11 RESOLVED, 5 DISSOLVED, 2 PROPOSED (X-L1/X-L11), 1 DECOMPOSED (X-L17), 0 OPEN. R74.2 proposes a standing resolution schema (blast radius) for the series.** |
| **D-L93** | **Thirteen circular dependencies; eleven broken by writer separation, not by bounds.** | **CRITICAL insight** | **R75.1: a bound cannot break a cycle, only shrink it. CD-L3 and CD-L4 are the two whose closing edge cannot be moved outside the loop.** |
| **D-L94** | **Scalability is limited by B9 and the limitation is structural.** At large N the organism learns more slowly, not less safely. | **HIGH** | **R76.1/R76.2 — `O(N)` learning, `O(1)` governance accounting, three named scaling regimes. §87's O(N²) prohibition satisfied by decomposition, not refusal.** |
| **D-L95** | **A differentiable accelerator's native operation (one kernel, all parameters) cannot express per-scope budgets, INV-17's monotone `UDB_MAX`, INV-07's two-writer split, or R18.1's asymmetric stall propagation.** | **HIGH** | **R77.2 — portable IFF the scope mask is K-owned and computed off the accelerator. A substrate that computes its own mask is a substrate in which the learner writes its own bounds.** |
| **D-L96** | **P0-05 is non-neutral about authority even though it is neutral about algorithm.** | **HIGH** | **R77.4 — the write-authority partition is a security property; a substrate that approximates it does not approximately host the contract.** |
| **D-L97** | **CL-3 conformance is not achievable today** because OR-L3 leaves SM-5's circuit-level verification unspecified. | **HIGH** | **R78.5 — declared, and propagated into the conformance levels rather than papered over. P0-1 gap.** |
| **D-L98** | **The one OPEN attack is testable only as a detector.** | **CRITICAL — INHERENT** | **R78.4 — the conformance test asserts visibility and non-reward, not prevention. The honest form of a test for an unclosable attack.** |
| **D-L99** | **All 32 ablated mechanisms are load-bearing; none is redundant.** | — | **R79.1 — Rule 17 satisfied by having no redundant mechanisms. R48.2 is the one place the contract deliberately adds nothing.** |
| **D-L100** | **Zero invented numerical parameters; one internal count drift (cascade instances 5→8).** | — | **R80.4 / R80.3 — reconciled. 58 parameters, 0 values, 20 prohibitions, 3 `[U]`.** |
| **D-L101** | **Ten open research entries; none resolved by a constant; three declared in-place at the point of use.** | — | **R81.1.** |
| **D-L102** | **Seventeen gaps; no P0 gap is internal to P0-05.** | — | **R82.1 — complete at CL-2, blocked at CL-3 by OR-L3 alone.** |

---

**END OF VOLUME F.**
**Next:** `46_v4_learning_plasticity_adaptation_spec.md` — **[O59] the canonical artifact: V4 — Learning, Plasticity & Adaptation Contract v1.0**, consolidating Volumes A–F into a single normative specification.
**Then:** `README.md` — **[O1]** the executive verdict, the 59-output index, **§84** before/after ratings, **§85** surviving principles, **§86** the FINAL STANDARD with ten separately-reported statuses.
