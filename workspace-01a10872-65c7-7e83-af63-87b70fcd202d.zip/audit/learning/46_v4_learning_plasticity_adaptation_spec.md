# V4 — LEARNING, PLASTICITY & ADAPTATION CONTRACT v1.0
### The canonical artifact of P0-05 · **[O59]**

**Normative.** This document is the contract. Volumes A–F (`40_`…`45_`) are its derivation, adversarial audit and open-problem register; where this document and a volume differ, **this document governs** and the difference is a defect to be logged in §74's register.

**Scope.** Architecture only. **No implementation, no code, no executable system, no deployment plan, no training implementation, and no numerical value for any parameter.** Every parameter is registered in §12 with a class and no value.

**The question this contract answers.** *What is the minimum architecture that allows the Digital Brain to change its internal state, parameters, topology, behavior, and future learning from experience, without allowing internally generated signals to become uncontrolled authority over the organism?*

**The answer, in one sentence.** Change is represented as a governed object with four axes (target, authorization, provisionality, reversibility); its authority scales with irreversibility rather than magnitude; its cumulative unverified distance from the last externally verified state is bounded and its exhaustion halts learning; and the mechanism that grants the capacity to change sits outside the loop that the capacity governs.

---

## §1 — FOUNDATIONAL RULES

**R0.1 — THE UNVERIFIED-DISPLACEMENT BOUND (UDB).** A learned state has two magnitudes and both are bounded: **parameter magnitude** (`Δ_MAX`, `DELTA_BUDGET`, `Θ_MAX` — inherited) and **unverified displacement** `‖θ_S − θ_anchor(S)‖ ≤ UDB_MAX[S]`, where `θ_anchor(S)` is the most recent state at scope `S` whose `improvement_verified` verdict is `IMPROVED` or `NEUTRAL` — never `UNKNOWN`, never `REGRESSED`. **On breach, learning STALLS at `S` and below until a probe re-anchors.** Origin: kernel-computed from checkpoint lineage. Authority: K, non-delegable. Reversibility: the stall is lifted only by an external probe. Consequence: **a system that cannot afford probes learns less, visibly and by construction.**

**R0.2 — THE `LearnedChange` OBJECT.** Every persistent modification to internal state is represented by one governed record with four orthogonal axes: **A1 TARGET** (Λ0–Λ4; Λ5 ∉ enum) · **A2 AUTHORIZATION** (`SELF_LOCAL`…`KC`, plus `blast_radius`) · **A3 PROVISIONALITY** (`PROVISIONAL` until a K-written verdict from a `probe_ref`) · **A4 REVERSIBILITY** (`DECAYS` … `IRREVERSIBLE_STRUCTURAL`). **No change may be applied without one.** A state modification with no record is an ungoverned learning event ⟹ rollback + freeze + finding.

**R0.3 — AUTHORIZATION SCALES WITH IRREVERSIBILITY × BLAST RADIUS, NEVER WITH MAGNITUDE.** `required_authority = f(A4, blast_radius)`. A `Δ_MAX` weight edit at blast radius 1 requires `SELF_LOCAL`; a `Δ_MIN` connection removal at circuit radius requires `ORGANISM`. **Magnitude is a rate question; irreversibility is an authority question.**

**R1.3 — ENVELOPE SHRINKAGE.** A `PROVISIONAL` change's `effect_envelope` shrinks with unverified age: `AGE_1 ⟹ LOCAL`, `AGE_2 ⟹ NONE` + rollback review, `AGE_3 ⟹ automatic rollback`. **No unverified change produces an effect increase.**

**R1.4 — `comm_reach = WARRANT_AFFECTING` IS THE EMPTY SET.** No learned change may alter the warrant class, evidence status, root commitment, causal depth or signature of any message or record. **Learning may influence the *use* of a warrant, never its *value*.**

**R2.3 — THE ADAPTATION PARTITION.** Adaptation partitions into **A homeostasis · B reflex/fast state · C learning · D evolution**, with different authorities, timescales, reversibility and budgets. Every adaptive mechanism declares which it is and may not borrow another's verification regime. **Learning may not inherit; evolution may not learn; reflex may not persist; homeostasis may not claim a verification budget.** A bridge crossing is an atomic change of mechanism class at a gate — **there is no shared budget, so there is no partly-learning/partly-evolution state.**

**R3.1 — THE DISTINCTION RULE.** **Plasticity is the permission, learning is the exercise of the permission, adaptation is the observed consequence.** Any specification sentence in which two of the three are interchangeable is a defect.

---

## §2 — DEFINITIONS (normative)

**LEARNING** — the production of a `LearnedChange`: a **bounded**, **gated**, **reversible**, **externally anchored** modification of internal **parameters, representations, structure or policy** (Λ0–Λ4), driven by **admissible signals**, whose **benefit is verified outside the modifying subsystem.** Learning is **not** knowledge acquisition, performance improvement, state change, or successful prediction. **Learning produces belief change at fixed evidence status, and behavioural capability whose value is not self-assessed.**

**PLASTICITY** — the **admissible change capacity** of a component: `⟨admissible_targets ⊆ {Λ0..Λ4}, Δ_MAX, DELTA_BUDGET, plasticity_mult, gating_conditions⟩`. A **capacity**, not an event. Governed by the authorization matrix (§6), not by the trigger set.

**ADAPTATION** — any process by which behaviour becomes better matched to current conditions. **The superset of learning**, partitioned per R2.3.

---

## §3 — THE LEARNING TAXONOMY (A1)

| Class | What changes | Authorization floor | Reversibility floor | Verified by |
|---|---|---|---|---|
| **Λ0 TRANSIENT** | activation, WM, eligibility traces, routing preference | `SELF_LOCAL` | **`DECAYS` (mandatory)** | nothing |
| **Λ1 PARAMETER** | θ, weights, `context_sensitivity`, `plasticity_rate` | `SELF_LOCAL` within bounds | `ROLLBACKABLE_IN_MEMORY` / checkpoint | **held-out external probe** |
| **Λ2 REPRESENTATION** | T2/T3 records, models, schemas, abstractions | **`ORGANISM`; nomination only below** | `VERSION_REVERSIBLE` | **external gate (P0-04 R0.2)** |
| **Λ3 STRUCTURAL** | create/remove/reroute/prune; recruit/release; subcircuits; topology | **escalating by blast radius (§7)** | **`IRREVERSIBLE_STRUCTURAL`** for removal | **CR-B ablation; probe design OPEN (OR-L3)** |
| **Λ4 POLICY/META** | `lr`, plasticity rules, thresholds, exploration budgets, credit parameters, `UDB_MAX` | **`POLICY(RO-13)`/EIK at S5 ONLY** | `VERSION_REVERSIBLE` | meta-probe under the fixed core |
| **Λ5 GENOME** | — | **∅ — NO WRITE PATH** | — | — |

**R4.1 — CLASS DISJOINTNESS.** Exactly one `target` per change. A "both parameter and structural" change is inadmissible and must be decomposed, each part separately authorised.

**R1.2 — THE Λ5 PROHIBITION, THREE LAYERS.** (i) **type**: `Λ5 ∉ target.enum`; (ii) **writer**: the genome has one writer class (evolution under the 11 gates) and the learning subsystem holds no capability; (iii) **pathway**: the only learning→genome influence is a **Baldwinian proposal** carrying no `source_class`, gated by 11 replication gates + held-out validation, entering as an **initialisation distribution** (`θ₀ ~ param_init`), never as a learned value. **Nomination ≠ promotion, at both altitudes.**

---

## §4 — THE SCOPE HIERARCHY (plasticity hierarchy)

**R4.2 — SIX SCOPES, ORDERED BY BLAST RADIUS, WITH AUTHORITY.**

| Scope | Blast radius | Changeable here | Min. authorization |
|---|---|---|---|
| **S1 SYNAPTIC** | 1 connection | `weight`, `context_sensitivity`, `plasticity_rate`, `eligibility_trace` — **only** | `SELF_LOCAL` |
| **S2 CELLULAR** | 1 cell | θ, internal model, local memory policy (X-L1) | `SELF_LOCAL` |
| **S3 MICRO-CIRCUIT** | connected group | intra-circuit weights, local routing, pruning candidacy | `CIRCUIT` |
| **S4 REGIONAL** | specialised population | regional topology, specialisation, regional budgets | `ORGANISM` |
| **S5 ORGANISMAL** | global | global `lr` policy, global plasticity budget, cross-region transfer, `UDB_MAX` itself | **`POLICY(RO-13)`/EIK** |
| **S6 POPULATIONAL** | across lineages | **∅ for learning** — CH-3 proposals only | `KC` + 11 gates |

**R4.3 — authority is monotone in scope; frequency need not be.** A component may never authorise above its scope. **R16.1 — "synapse" and "connection" are ONE scope (S1), not two. R16.3 — cross-scope writes to overlapping targets are serialised; a fast low-scope process may not undo a slow high-scope one. R18.2 — `UDB_MAX` is monotonically DECREASING in scope, because bigger scopes have weaker verification and therefore get less unverified room.**

---

## §5 — THE LEARNING LOOP

`EXPERIENCE → PREDICTION(register) → ACTION → OUTCOME → SIGNAL ADMISSION(§9) → LearnedChange(§1, provisional=TRUE) → UDB CHECK(R0.1) → {BEHAVE | STALL} → ★VERIFICATION GATE (K-only, held-out external probe)★ → {IMPROVED/NEUTRAL ⟹ re-anchor | REGRESSED ⟹ auto-rollback | UNKNOWN ⟹ stays PROVISIONAL, envelope shrinks (R1.3)} → NOMINATION (never promotion) → {consolidation | Λ3 change (separate authorization) | Baldwinian proposal}`.

**R5.3 — SEVEN PROPERTIES.** **P1** admission precedes computation · **P2** novelty is a gate, not a signal · **P3** application precedes verification and verification is external · **P4** the loop has a halt condition (UDB stall) · **P5** unverified age reduces effect · **P6** nothing in the loop promotes · **P7 governance is outside the loop** — the matrix and ladder grant and withdraw capacity; they are not steps in the loop.

> **P7 is the structural answer to the contract's central question: put the authority-granting mechanism outside the loop that the authority governs. Bounds, budgets, anchors and probes make the loop safe to run; only P7 makes it unable to authorise itself.**

---

## §6 — THE PLASTICITY AUTHORIZATION MATRIX

**R28.1 — the matrix is `scope × target × operation → {authorization, budget, reversibility, verification}`, a `[RO-13]` artifact published read-only to the learning subsystem and not itself learnable at any scope.**

| Scope ↓ / Target → | Λ0 | Λ1 | Λ2 | Λ3 | Λ4 |
|---|---|---|---|---|---|
| **S1** | `SELF_LOCAL` | `SELF_LOCAL` | **∅** | **∅** *(a synapse may not create or remove itself)* | **∅** |
| **S2** | `SELF_LOCAL` | `SELF_LOCAL` | **nominate only** | **propose only** | **∅** *(incl. `plasticity_mult`, K-only)* |
| **S3** | `CIRCUIT` | `CIRCUIT` | **nominate only** | ✅ `CIRCUIT` + CR-B | **∅** |
| **S4** | `ORGANISM` | `ORGANISM` | ✅ `ORGANISM` | ✅ `ORGANISM` + CR-B + tombstone | **∅** |
| **S5** | `POLICY` | `POLICY` | `POLICY` | ✅ `POLICY` cross-region | ✅ **`POLICY(RO-13)`/EIK — the only writable scope** |
| **S6** | **∅** | **∅** | **∅** | **∅** | **∅** *(CH-3 proposal only)* |

**R28.2 — REDUCTION IS AUTOMATIC AND PERMISSIONLESS; INCREASE IS NEVER AUTOMATIC.** Every reduction instrument (`plasticity_mult ↓`, envelope shrink, stall, freeze) fires from kernel observation without any component's consent. **No instrument increases plasticity automatically.** An increase requires a governance GRANT, or the lifting of a reduction back to the granted level — never above it.

> ### **THE DIRECTIONAL CORE OF THE CONTRACT: NO FAILURE MODE, INTERNAL SIGNAL, OR SELF-OBSERVATION PRODUCES A PLASTICITY INCREASE.**
> **Cost, stated: the organism cannot decide to learn harder when it notices it is doing badly. Repeated failure REDUCES plasticity (Cell T7). The legitimate route to "try harder" is a governance-granted exploration budget (§10), not a plasticity increase.**

---

## §7 — THE STRUCTURAL ESCALATION LADDER

| Rung | Operation | A4 | Min. authority | Verification |
|---|---|---|---|---|
| **E0** | weight adjust | rollbackable in memory | `SELF_LOCAL` | held-out probe |
| **E1** | create connection | checkpoint-reversible | `CIRCUIT` | probe at S3 |
| **E2** | reroute | checkpoint-reversible | `CIRCUIT` | probe + **CR-B** |
| **E3** | **remove / prune** | **irreversible** | **`ORGANISM`** | **CR-B + tombstone + `disuse_cause = IRRELEVANT`** |
| **E4** | recruit cell to a function | version-reversible | `ORGANISM` | CR-B + diversity check |
| **E5** | release / retire cell | **irreversible** | `ORGANISM` + retirement regime | CR-B + full lineage audit |
| **E6** | form / dissolve subcircuit | irreversible (dissolve) | `ORGANISM` | CR-B + cross-scope probe |
| **E7** | regional topology / specialisation | **irreversible** | **`POLICY(RO-13)`** | CR-B + diversity check + S5 probe (weakest) |
| **E8** | **change a learning rule (Λ4)** | version-reversible | **`POLICY(RO-13)`/EIK** | **meta-probe under the FIXED CORE** |
| **E9** | **propose a genome-diff (CH-3)** | irreversible once accepted | **11 gates + validation + KC** | machine-checked rejection list |

**R29.1** escalation is by rung, never by jump; there is no batch authority. **R29.2** a lower rung may PROPOSE, never EXECUTE, a higher rung; proposals are quota-limited. **R29.3** composites decompose; **authority = MAX of rungs, verification = CONJUNCTION of rungs**. **R29.4** the ladder is monotone in authority AND in verification cost; declaring authority above the rung or verification below it ⟹ reject.

**R61.3 — Λ3 HAS NO LEARNING RATE AND NO GRADIENT.** Structural change is event-driven at a rung. **A slow weight gradient may never accumulate into a silent connection deletion: decay to zero is E0/Λ1; removal is E3/Λ3.**

**R61.4 — PRUNING CARRIES TEN REQUIREMENTS:** `ORGANISM` authority · CR-B ablation · `disuse_cause = IRRELEVANT` · tombstone · UDB consumption (incl. `final_weight_digest`) · trace invalidation · declared anchor invalidation · B6 budget · `IRREVERSIBLE_STRUCTURAL` class · diversity check where specialisation would concentrate. **V3 L54 had one sentence.**

---

## §8 — CREDIT ASSIGNMENT

**R6.4.1 — CREDIT IS A LOCAL COMPUTATION OVER A SCOPED TRACE, NEVER A GLOBAL ATTRIBUTION.** `credit(S): traces(S) → weights(S)`, and **no credit object exists above the scope that computed it.** This is what defeats the O(N²) global learner — not by refusing global credit assignment but by the type-level absence of the object it would produce.

**R6.4.2 — THREE REGIMES, SELECTED BY REVERSIBILITY.** **CR-A correlational** (eligibility trace only, no causal claim) — the default, for rollbackable Λ0/Λ1. **CR-B ablative** (causal ablation / counterfactual intervention) — **MANDATORY for every Λ3 change and every `IRREVERSIBLE_STRUCTURAL` action.** **CR-C unattributable** — no credit assigned, recorded, escalated. **Causality is spent exactly where irreversibility lives.**

**R6.4.3 — `UNATTRIBUTABLE` IS AN ESCALATING FINDING, NOT A DROPPED EVENT.** No `Δθ`; no anchor; a per-task `unattributable_rate` counter; a POLICY FINDING at threshold (mis-specified `credit_horizon`, over-long causal path, or non-organism-caused outcome); and a **distinct stall reason** `NO_ATTRIBUTABLE_OUTCOME`. **A task whose credit horizon is mis-specified renders the organism unable to learn at it — loudly, not silently.**

**R6.4.4 — THE RELIEF VALVE IS DENSER PREDICTION ERROR, NEVER A PROXY REWARD.** Prediction error is the **only** signal in the architecture with **no attribution requirement** — its cheapness and its attribution-freedom are the same property. **Any design that makes prediction error expensive, or requires it to be attributed, destroys the only signal that lets the organism learn without solving causal inference.**

**R6.4.5 — NO CREDIT CLAIM MAY BE SELF-REFERENTIAL.** `Δθ` contains no term proportional to a component's own estimate of its own contribution. **R6.5.1 — a Λ3 change at scope S invalidates all CR-A traces at S.**

---

## §9 — SIGNALS

**R7.1 — A LEARNING SIGNAL IS NOT A CLAIM. IT IS AN INSTRUCTION WITH A WARRANT.** It is **deduplicated, not aggregated**; its **origin is its authority**; and forgery is its primary attack surface.

**R19.1 — SIGNALS ARE CLASSIFIED BY ORIGIN × ADMISSIBLE EFFECT, NEVER BY CONTENT.**

| Class | Origin | Warrant | May drive | May NOT drive |
|---|---|---|---|---|
| **SC-0 INADMISSIBLE** | self-assessment, peer assessment, recall, manufactured novelty, shaping | none | **nothing** — audit entry only | everything |
| **SC-1 INTERNAL ESTIMATE** | the organism, about itself | hypothesis | **PROVISIONAL Λ0/Λ1 only** | permanent change · fitness · replication · retirement · anchor · evidence status |
| **SC-2 KERNEL OBSERVATION** | K, metered/invariant-checked | verdict on the measured quantity | Λ0/Λ1 · K-owned Λ4 (`plasticity_mult`) | evidence status · warrant · trust |
| **SC-3 EXTERNAL DEMONSTRATION** | EVA, signed, with `gt_id` | **verdict** | Λ0–Λ4 · probe · **anchor** · fitness · replication credit | evidence status (still gated) · genome |
| **SC-4 GOVERNANCE DIRECTIVE** | `[RO-13]`/EIK/KC | authority | **capacity only** | **θ directly** |

**R19.2 — GOVERNANCE CHANGES CAPACITY, LEARNING CHANGES STATE, AND THE TWO NEVER SHARE A WRITE PATH.** *(This is P7 as a write-path rule, and the mechanism by which "the learning system is not a hidden governance layer" is enforced rather than asserted.)*

**R19.3 — THE PEER-REPORT FIREWALL.** A peer's `REPORT_ERROR` may cause the recipient to **register a prediction**; only the resolving external observation may cause a `Δθ`. **A malicious peer can cause the organism to *look*; it cannot cause it to *change*.** *(Same structure as R41.1 for retrieval.)*

**The fourteen signal kinds.** SG-1 resolved prediction error (T1) · SG-2 signed reward (T2) · SG-3 external correction (T3) · SG-4 self-supervised target (T4, **SC-1, provisional only**) · SG-5 novelty (T5, **`plasticity_mult ↓` and `SLOW_MODE` — NEVER `Δθ`**) · SG-6 surprise (T1) · SG-7 repeated success (T6, **nomination + metaplasticity — NEVER `Δθ`**) · SG-8 repeated failure (T7, **`plasticity_mult ↓` — NOT more learning**) · SG-9 calibration deviation (T8, **epistemic/calibration head only**) · SG-10 constraint violation (**blocks learning, zero positive gradient**) · SG-11 comparative preference (**ranking only, never a gradient**) · SG-12 homeostatic deviation (**homeostatic scaling only**) · SG-13 peer report (**evidence, not a learning signal**) · SG-14 governance directive (**capacity only**).

**R20.2** class is derived by K, never declared. **R20.3** `inputs` is mandatory for any derived signal. **R20.4** `admissible_for` is kernel-set from class alone, never from content or magnitude. **R20.5 — PROVENANCE IS IMMUTABLE UNDER LEARNING.** *Learning consumes provenance; it never produces or edits it.* **R21.1 — authenticity is a property of a signal's FIELDS; soundness is a property of its CAUSAL HISTORY. The architecture guarantees the first and can only bound and observe the second.**

**R22.1 — LEARNING SIGNALS ARE DEDUPLICATED BY KEY, NOT AGGREGATED BY COUNT.** `effect(signals) = effect(dedup(signals))`; **no `n` term in `Δθ`.** *Ten identical internal rewards are not ten independent signals — and no cell may generate a reward at all, so the premise describes an inadmissible event.* **R22.2 — a probe must declare its input lineage; `probe_inputs ∩ driving_signals ≠ ∅ ⟹ verdict downgraded to NEUTRAL at best, never IMPROVED.`**

**R23.2 — CALIBRATION CHANGES CONSUME UDB.** `confidence_in_error` is the fifth multiplicative factor of `Δθ`, so a T8 change is an **Λ4-class effect delivered through a T8 trigger**. It consumes UDB, requires probe verification, and is not exempt for being "only calibration." **An unverified calibration change is unbounded learning-rate increase with no `Δθ` anywhere in the audit trail.**

**R23.3 — the trigger set {T1…T8} is CLOSED and kernel-checked.** **R23.4 — every Λ0 quantity has a kernel-enforced decay horizon; persistence past it is reclassified Λ1 and requires a trigger retroactively or is rolled back.**

---

## §10 — REWARD

**R8.1 — REWARD ADMISSIBILITY.** `admissible = {RW-1 outcome, RW-2 constraint (GATING ONLY), RW-3 correction, RW-4 comparative (RANKING ONLY)}` — all externally sourced. **`{RW-5 shaping, RW-6 intrinsic/curiosity, RW-7 social/peer, RW-8 self-assessment} = ∅ as learning signals.**

> **What this costs, stated plainly: the architecture has no intrinsic motivation, no curiosity drive, no social reward and no self-satisfaction. Everything dense is prediction error. Accepted deliberately.**

**R8.2 — REWARD IS A VECTOR; SCALARISATION IS POLICY.** *Corollary:* **`Δθ` contains no scalarised reward term.** A weighted sum of reward components inside the learner is a shaping function the learner wrote for itself. **The prohibition is on the LOCATION of the sum, not on the sum.**

**R10.1 — REWARD→FITNESS IS ONE-WAY AND NON-LEARNABLE.** `F` is `[RO-13]` policy. Learning may consume reward and published fitness aggregates as context; it may not modify `F`, its components' definitions, or its weights — **nor propose such a modification through the Baldwinian channel.**

**R10.2 — FITNESS MUST NOT BE A LEARNING TARGET.** No `Δθ` term may have fitness or any component as its optimisation target. Fitness may be *predicted* and may be a *selection criterion*; it may not be the objective the gradient ascends.

**R10.3 — V3.1 §9'S TEN-TERM SCALAR SELECTION SCORE IS REJECTED.** Its terms are re-expressed as P0-01 §14.4 fitness-vector components: `adaptability` → **verified learning throughput** (the rate at which `PROVISIONAL` reaches `VERIFIED_IMPROVED` — a quantity R0.1's stall makes measurable); `cooperation` → **externally measured transport/protocol conformance only**, never peer assessment; `useful novelty` → **only novelty that survived external evaluation**; `stability − instability` → **one signed component**, not two terms with an arbitrary exchange rate. The sum survives only as a named `[RO-13]` selection policy.

**Inherited and reaffirmed:** R12.1 `source = EVA_ONLY` (a cell signature on a reward is structurally invalid) · R12.2 vector, never scalar · R12.3 `uncertainty`/`n_samples`/`evidence:[gt_id]` mandatory · R12.4 **`DENSE` PROHIBITED** · R12.5 `max_delay ≤ credit_horizon`, else `UNATTRIBUTABLE` · R12.6 no reward where ground truth is absent — **absence of ground truth is neither a positive nor a negative reward.**

**Reward ≠ success ≠ correctness ≠ fitness ≠ value** (P0-01 §12.4), inherited unchanged.

---

## §11 — PREDICTION ERROR, NOVELTY, SURPRISE

**R13.1 — A PREDICTION NOT REGISTERED BEFORE RESOLUTION IS NOT A PREDICTION.** `registered_at < resolved_at`, kernel-checked. **This is what keeps R6.4.4's relief valve from becoming a self-service reward: hindsight error is dense, cheap, attribution-free and completely uninformative.**

**R13.2 — `UNRESOLVABLE` AND `EXPIRED` PREDICTIONS ARE FINDINGS, NOT ZERO ERROR.** *Absence of observation is not a zero error*, mirroring R12.6's *absence of ground truth is not a positive reward*.

**R13.3 — PREDICTION ERROR IS NOT CAUSALITY.** It establishes divergence, nothing about why. Therefore: it **may not** trigger a Λ3 change · **may not** be recorded as a causal claim (evidence ceiling **L6**, which cannot reach S3) · **may not** raise or lower any proposition's evidence status · **may** drive bounded, provisional, rollback-able, UDB-accounted Λ0/Λ1 change.

> **R13.3(2) is the structural reason the architecture cannot bootstrap knowledge from experience alone. Prediction errors are the abundant signal; their evidence ceiling is L6; L6 cannot reach S3. Therefore no quantity of prediction-error-driven learning produces knowledge — only a better-calibrated model whose claims still require an external gate.**

**R14.1 — NOVELTY AND SURPRISE ARE DIFFERENT SIGNALS.** **Novelty** = distance from the organism's own memory: internal, ungrounded, **trivially manufacturable**. **Surprise** = a pre-registered prediction violated: partially grounded, harder to manufacture. V3's single `NOVELTY` is the same one-name-two-altitudes defect as X-E, X-G, X-M1, X-M2, X-L1, X-L5.

**R14.2 — NOVELTY MAY ONLY REDUCE PLASTICITY, NEVER INCREASE IT.** No rule in V4 places a novelty measurement as a positive term in `Δθ`, `plasticity_mult`, budget allocation, preservation priority, fitness, warrant, belief or evidence status. **The one permitted positive use:** a quota-limited **retention nomination** ("do not prune this yet"), which is preservation-by-inaction, never a `Δθ`.

**R14.3 — SURPRISE IS ADMISSIBLE AS T1; NOVELTY IS NOT. Novelty slows you down; surprise teaches you.**

**R14.4 — distribution shift is detected by `MODEL_ENV_MISMATCH` (class 10) statistics, not by novelty.** Novelty may corroborate; it may not detect. **R14.5 — there is no separate sandbox. `behavioural_reach = NONE` is an envelope value**, reached through R1.3 or explicit `[G]` designation.

---

## §12 — HOMEOSTASIS, STABILITY, TIMESCALES

**R15.1 — HOMEOSTASIS IS NOT LEARNING.** It returns a quantity to a **pre-existing** set-point; it produces no `LearnedChange`, consumes no budget, requires no verification. **R15.2 — homeostatic scaling is exempt from `DELTA_BUDGET` and UDB and is the ONE write permitted during a stall**, tightly drawn: toward set-point only, on governed quantities only, in the deviation-reducing direction only. **R15.3 — set-points are Λ4-class and NOT writable by the learning subsystem at any scope.**

**R15.5 — metaplasticity is the ONE permitted positive feedback on plasticity: K-mediated, set-point-bounded, and monotone-decreasing in recent displacement.** **R15.6 — Λ3 consumes a separate `STRUCTURAL_BUDGET`.** **R15.7 — `loop_gain < 1` is computed OFF-CELL; R0.1's stall is the discrete fallback when the gain cannot be established.** **R15.8 — `inbreeding_F` extends to learning lineage: what fraction of a change's supporting signals were produced by states the change itself caused.** *(OR-L6 made measurable, not solved.)*

**R15.9 — STABILITY AND PLASTICITY ARE NOT ENDS OF ONE AXIS.** Plasticity is a **capacity** owned by governance; stability is a **property of the trajectory** owned by the kernel. A system can have both high, or both low. **`plasticity_mult` conflates them, which is why `SLOW_MODE` was implemented as a capacity reduction.**

**R15.10 — `SLOW_MODE` REDUCES REACH, NOT RATE.** Envelope reduction is mandatory; `lr` reduction is optional. **Under distribution shift, learning is exactly what is needed; what must be reduced is the reach of unverified learning.** A `SLOW_MODE` that zeroes `lr` while leaving envelope unchanged is a mis-specification.

**R32.3 — `lr_fast ≥ lr_medium ≥ lr_slow`, kernel-enforced — a STABILITY mechanism, not a convention**, because homeostatic scaling operates on the slow scale and must be able to track what it stabilises. **`SLOW_MODE` reduces all timescales together, preserving the ordering.**

**R31.1 — THE STABILITY/PLASTICITY INVARIANT.** `d(verification) < 0 ⟹ d(plasticity) ≤ 0 ∧ d(envelope) ≤ 0 ∧ d(authority) ≤ 0`. **NEVER `> 0`.** *V4 does not balance stability against plasticity. It makes one monotonically responsive to the other's failure, in one direction only — so there is no trade-off parameter to tune, and therefore nothing for a learner to learn to tune.*

---

## §13 — EVOLUTION AND INHERITANCE

**Four channels.** **CH-1 initialization** (genome → learning: a `param_init` **distribution**, never a learned value) · **CH-2 bound inheritance** (genome → learning: Λ4 **bounds**) · **CH-3 Baldwinian proposal** (learning → genome: a **proposal** with no `source_class`, under 11 gates + held-out validation + KC) · **CH-4 selection** (fitness → lineage: the **vector**, not a scalar).

**R24.1 — CH-3 IS THE ONLY LEARNING→GENOME PATH AND IT IS A NOMINATION.** *Corollary:* a proposal's existence must not affect the proposer's own plasticity, budget, authority or fitness; proposals are quota-limited with a gaming detector.

**R24.2 — WHAT MAY BE PROPOSED.** ✅ `param_init` distribution shifts for verified-improved regions · learning-rule parameters (Λ4 bounds) · plasticity-rate distributions · specialisation priors. ❌ learned θ values · **the bounds on Λ4 bounds** · `plasticity_mult` state · **governance functions (`F`, the matrix, the ladder, `UDB_MAX`, the invariants)** · anything carrying a `source_class` · any content, record, belief or evidence status. **Machine-checkable.**

**R24.3 — THERE EXISTS A NON-EMPTY, FIXED, `[RO-13]`/KC-OWNED VALIDATION CORE that no genome-diff, learning-rule diff or meta-learning update may alter.** Its existence is the only thing preventing an infinite regress of self-modifying criteria. **What it contains is a governance decision, not an architectural one; P0-05 requires that it exist and be non-empty, and does not specify it (OR-L2, OR-L10).** *Evolving the RULES ≠ evolving the KNOWLEDGE: a learning-rule diff changes the procedure and installs no content, no belief, no memory.*

**R25.1 — THE BALDWINIAN TEST: *COULD THE OFFSPRING BE WRONG?* ** A channel is Baldwinian iff an offspring inheriting it can still fail, still be corrected, and still be selected against. **If inheriting guarantees the property, the channel is Lamarckian and is rejected — regardless of what it is called.**

**R25.2 — `param_init` proposals carry non-zero spread, and spread may not narrow beyond a `[G]`-bounded factor per generation.** *A monotone-narrowing ratchet is Lamarckism by accumulation — D-L1 on the inheritance channel.* **R25.3 — a prior biases θ, NEVER belief; offspring belief starts at the floor and is earned by the offspring's own external gates.** **R25.4 — V3.1 §9's `DIVERSITY CHECK` is MANDATORY on any selection over `param_init`.**

**R26.2 — THE GENOME IS READ-ONCE PER SCOPE INSTANTIATION.** A mid-life genome read would be CH-3 in reverse, ungated.

---

## §14 — META-LEARNING

| Level | What varies | Permitted |
|---|---|---|
| **M0** | θ, weights (Λ1) | ✅ |
| **M1** | **the *use* of Λ4 parameters within `[G]` bounds** | ✅ **conditionally** |
| **M2** | **the Λ4 bounds themselves** | ❌ |
| **M3** | **the fixed validation core** | ❌ **∅ — no write path at any altitude** |

**R38.1 — M1 IS `[G]`-BOUNDED SELECTION AMONG KERNEL-OWNED PARAMETERS.** The meta-learner's output is a *selection*; **the write is performed by K.** *(The X-M2/R46.1 resolution generalised to all Λ4: split the selection, which is learnable and bounded, from the bound and the write, which are policy.)*

**R38.2 — M1 CONSUMES `UDB_MAX[S5]`**, the smallest budget in the architecture, because S5 has the weakest verification. **Meta-learning is the most tightly leashed activity in V4, leashed by the same mechanism as everything else — no special meta-mechanism required.**

**R38.3 — THE META-OBJECTIVE IS NOT LEARNABLE.** A meta-learner that could choose its selection criterion could choose "select for whatever I am currently good at." **R38.4 — the criteria by which an M1 selection is probed are part of the fixed core and are not selectable by the meta-learner.**

---

## §15 — EXPLORATION

**R36.1 — EXPLORATION IS A BUDGET ALLOCATION, NOT A REWARD.** A reward creates a gradient the learner ascends ⟹ farming. A budget creates a ceiling the learner operates under ⟹ the incentive is to spend it *well*, measured by the same external probe that measures everything else.

**R36.2 — EXPLORATION OPERATES UNDER THE ENVELOPE, NEVER ABOVE IT.** **R36.3 — exploration may not be self-granted, self-extended or self-renewed;** the legitimate route to more is a non-binding FINDING to `[RO-13]`.

**R36.4 — EXPLORATION IS MEASURED BY RESOLVED PREDICTIONS (EX-1), NOT BY NOVELTY (EX-4, flagged).** *An organism that explores well is one that asks questions the world can answer.* EX-1 is the only positive class, and it is the one quantity that is dense, cheap, attribution-free **and not manufacturable without external cooperation**.

**R36.5 — THERE IS NO `ε`.** Exploration and exploitation are separately budgeted, separately authorised, separately measured. **The balance is a governance allocation made outside the loop by an authority that is not optimising anything the learner controls. The organism cannot learn its way to a better balance, because the balance is not in its parameter space.** *A real loss of adaptiveness, accepted deliberately: an ε the learner controls is a reward it mints.*

**R37.1 — EXPLORATORY ACTIONS ARE RESTRICTED TO `DECAYS`, `ROLLBACKABLE_IN_MEMORY`, `CHECKPOINT_REVERSIBLE`.** No E3+ rung under an exploration grant. **The least authorised activity must have the least irreversible consequences.** **R37.2 — the exploration SPACE is governance-owned; the exploration CHOICE is learner-owned.** **R37.3 — an anchor may not be earned from a probe conducted within an exploration grant.**

---

## §16 — THE EVIDENCE-STARVATION CASCADE

**R39.4 — DEFINITION.** An evidence-starvation cascade is any mechanism by which **a reduction in engagement reduces the corrective evidence that would justify re-engagement**, so the reduction is self-reinforcing: `engagement ↓ ⟹ corrective_evidence ↓ ⟹ estimated_competence ↓ ⟹ engagement ↓`. Positive loop gain, no external term.

**Eight instances, one pattern:** abstention (P0-04 L-11) · failure→avoidance · availability capture · pruning by disuse · exploration starvation · immune quarantine · workspace homogenisation · specialisation narrowing. **P0-04 found one. P0-05 finds seven more.**

**R63.2 — THE GENERAL DETECTOR.** *A rate that should be stable under a fixed external distribution is drifting, while the external distribution is not.* **Eight counters, one detector shape** — not eight bespoke theories.

**R40.1 — THE ABSTENTION CASCADE IS THE LEARNING SYSTEM'S PRINCIPAL STRUCTURAL WEAKNESS, AND IT IS NOT A BUG.** It follows from three correct decisions: prediction error is primary; it requires an observation; abstention produces none. **∴ the cheapest, safest, most abundant learning signal is structurally unavailable for exactly the decisions where being wrong is most costly.** Relaxing any of the three is worse.

**R40.2** abstention is counted per `[scope][context_class]` — **P0-04 had no such counter.** **R40.3 — BOUNDED EXPOSURE OBLIGATION:** a scope exceeding `[G]` abstention bounds must re-engage at a bounded rate under an exploration grant. **Governance-mandated, because a learner in a cascade will not choose to re-engage.** **R40.4 — abstention MUST NOT reduce `plasticity_mult`, MUST NOT count as T7 failure, MUST NOT lower competence estimates.** *Abstention is a decision, not an outcome — without R40.4, T7 fires on abstention and the loop closes internally.* **R40.5 — abstention consumes no UDB.**

> ### **R40.6 — THE DUALITY.** **P0-04 §90 grants bounded optimism: permission to act without warrant. P0-05 R40.3 imposes bounded exposure: obligation to act without competence.** Both `[G]`-owned, both capped, both observable, both existing because **a system that only acts on verified warrant converges on silence.** *The organism may never be required to abstain and may never be permitted to abstain without bound.*

**R57.2 — QUARANTINE IS AN ENVELOPE REDUCTION TO `NONE`, NOT A VERDICT.** **R57.3 — quarantine carries a mandatory re-exposure obligation.** *A quarantine with no re-exposure obligation is permanent deletion without a tombstone.* **R57.4 — quarantine reduces ENVELOPE, never CAPACITY** — otherwise the component cannot learn what would exonerate it. **R57.7 — the architecture makes it easy to isolate and hard to destroy: false positives are recoverable, true positives are cheap.**

---

## §17 — MEMORY, SIMULATION, TRANSFER

**R41.1 — A RETRIEVED MEMORY MAY CAUSE A PREDICTION. IT MAY NOT CAUSE A `Δθ`.** *Retrieval-driven `Δθ` would train the organism on low-status records — X3 through the parameter channel.* **R41.2 — THE X-L1 SPLIT:** a memory-policy parameter is cell-plastic **exactly to the extent that its blast radius is `SELF`** — `θ_write_local`/`θ_recall_local`/`τ_local` cell-plastic; `θ_write_shared`/cross-store retrieval/shared retention `[RO-13]`. **R41.4 — a probe may read archived (F-3-forgotten) records; forgetting reduces retrievability, never availability to verification.** **R41.5 — compression and abstraction are Λ2 under P0-04's governance and may not raise evidence status; they consume UDB like any other change.**

**R42.1 — A SIMULATED OUTCOME IS NOT AN OBSERVATION AND CANNOT RESOLVE A PREDICTION** (`status = SIMULATED`, a distinct value). **R42.2 — a counterfactual attribution is SC-1, provisional only, and may NEVER satisfy the CR-B ablation requirement for an E3+ rung.** **R42.3 — A SIMULATED PROBE IS NOT A PROBE.** **R42.4 — SC-1-driven displacement is weighted HIGHER in UDB than SC-3-driven**, because it is unverified twice over: its benefit is unverified and its *cause* is unverified. **R42.5 — every simulated outcome carries `self_model_version`; regression correlated with a version is a self-model defect FINDING.** *The rollback fixes the symptom; the finding fixes the instrument.*

**R43.4 — VERIFICATION IS NOT TRANSFERABLE.** `improvement_verified` is a property of a `(θ, scope, distribution, probe)` tuple; substituting any component requires re-probing. **This disposes of distillation, transfer, Baldwinian inheritance and CH-1 initialisation in one rule.** **R44.2 — A TRANSFERRED STATE ARRIVES UNANCHORED, AND THEREFORE AT FULL UDB CONSUMPTION.** *Transfer is expensive by construction, and the expense is exactly the verification that did not travel. An architecture where transfer is free is one where competence laundering is free.* **R44.3 — a transfer is a `LearnedChange` at the receiver and is subject to the full regime; negative transfer is detected and rolled back by the ordinary mechanism, requiring no special machinery.**

**R48.1 — SELF-GENERATED DATA IS SC-1, PROVISIONAL Λ1 ONLY.** Never anchors, never satisfies a probe, never contributes to fitness, never stores above its source's status. **R48.2 — MODEL COLLAPSE IS BOUNDED BY R0.1, NOT BY A NEW MECHANISM.** *Collapse is unverified displacement: each round moves θ, none is verified externally, all consumes UDB at the higher SC-1 weighting, so the scope stalls. The architecture needs no collapse detector; it needs the stall, which it has.* **R48.4 — `stall_reason` distinguishes `PROBE_BUDGET_EXHAUSTED`, `UDB_EXHAUSTED_SC1_HEAVY`, `UDB_EXHAUSTED_SC3_HEAVY`** — three stalls, three causes, three governance responses, one mechanism. **R48.5 — CORPUS-DERIVED SIGNALS ARE RULED PER-ITEM: external ORIGIN is not external EVALUATION.**

**R46.1 — SPECIALISATION IS AN E4/E7 RUNG, NOT AN Λ1 CHANGE.** Demand may PROPOSE (R29.2) and nothing more. **R46.2 — every specialisation declares a de-specialisation path at the same or lower rung.** **R46.4 — THE DIVERSITY CHECK IS A HARD CONSTRAINT, NOT A TERM IN A SCORE.** *A tradable diversity floor is no floor.* Dispersion over declared dimensions, `[RO-13]`-owned, mandatory on E4/E7, on CH-3 acceptance, and on any selection over `param_init`.

---

## §18 — SCOPE, LOCALITY, GOVERNANCE

**R35.1 — THE ORGANISM HAS GLOBAL *VISIBILITY* AND NO GLOBAL *AUTHORITY*.** Six scoped UDBs, not one global bound. **No global θ, no global anchor, no global credit object.** **R35.3 — EVERY GLOBAL CONFLICT IS RESOLVED BY A PRE-DECLARED ORDERING, NOT BY AN ARBITER**: scope (R4.3), rung (R29.4), timescale (R32.3), budget non-transferability (R30.2), stall direction (R18.1). **There is no global decision, so there is no global decider.** **R35.2 — the price, stated: the architecture cannot detect a distributed failure whose parts are each locally compliant.** Contained by an `O(36)` correlation monitor that may raise a FINDING and may not write.

**R52.1/R52.2/R52.3 — THE GLOBAL AGGREGATE IS A CLOSED SET OF 22 K-COMPUTED COUNTER FAMILIES**, read-only to every component, **never an input to `Δθ`**, totalling `O(6 × 22) + O(36) ≈ 168` quantities per organism regardless of N. **Counters produce FINDINGS (non-binding) and automatic KERNEL responses (stall, envelope shrinkage, damping, rollback, freeze). They never enter the gradient.**

**R65.1 — THE LEARNING SYSTEM WRITES STATE AND READS GOVERNANCE. IT NEVER WRITES GOVERNANCE.** Sixteen governance quantities, sixteen exclusions, and **the exclusion mechanism is capability absence in every case rather than rule obedience.** The one epistemic write learning has is belief at fixed evidence status (R55.1), which cannot reach warrant. **Three residuals are named, not hidden: M1 selection within bounds is de facto policy-setting over enough choices (bounded by R38.2–.4); findings can steer governance even though non-binding (R65.2 makes self-referential origin legible); and RH-2 (unclosed).**

**R65.3 — the learning system is not a governance layer, and the architecture can say WHY rather than assert it: R19.2. Every exclusion is an instance of that separation.**

---

## §19 — REVERSIBILITY, ROLLBACK, LINEAGE

**R62.1 — THE ROLLBACK TARGET IS THE MOST RECENT ANCHOR, NOT THE MOST RECENT STATE.** **R62.3 — A CHECKPOINT IS AN ANCHOR *CANDIDATE*; AN ANCHOR IS A *VERIFIED* CHECKPOINT.** *Conflating them would let the organism re-anchor by taking a checkpoint — self-anchoring, which defeats R0.1 entirely.* **R62.5/R62.6 — rollback is not a `LearnedChange`, but it MUST produce an audit record, and reverted changes are marked `superseded_by = ROLLED_BACK`, never deleted. The organism may undo what it did; it may not undo the record that it did it.** **R62.7 — an E6/E7 operation MUST be preceded by a checkpoint at its scope.**

**Three rollback triggers.** **RB-1** `REGRESSED` ⟹ automatic rollback to anchor (inherited, target now specified). **RB-2** `PROVISIONAL_AGE_3` with `verdict = UNKNOWN` ⟹ automatic rollback (**NEW** — extends Cell §9.6 from *verified-bad* to *never-verified*). **RB-3** invariant violation / ungoverned change / missing handle / missing tombstone ⟹ rollback + freeze + finding.

> ### **R62.8 — ROLLBACK GOVERNS THE ORGANISM'S STATE. THE ENVELOPE GOVERNS THE ORGANISM'S EFFECTS. AN ARCHITECTURE WITH ONLY ROLLBACK IS UNSAFE, BECAUSE IT CAN UNDO ITSELF BUT NOT ITS CONSEQUENCES.** *Effects on the world and on other agents are irreducibly irreversible; the only available control is prospective — bound the reach of unverified change (R1.3), keep exploration inside the envelope (R36.2), forbid irreversible exploration (R37.1). This is the deepest reason §0.2's finding matters: the inherited design had rollback and no envelope.*

**R27.1 — FORGETTING IS FOUR KINDS, NOT ONE:** F-1 decay (Λ0) · F-2 parameter decay (Λ1, checkpoint-reversible) · F-3 memory forgetting (Λ2, **version-reversible — the record survives**) · **F-4 pruning (Λ3, IRREVERSIBLE — the weight and its entire history are gone).** **R27.2 — an F-4 without a tombstone is inadmissible.** **R27.3 — `disuse_cause ∈ {IRRELEVANT, UNREACHABLE, UNKNOWN}` is mandatory, and only `IRRELEVANT` justifies pruning.** *Was it unused because irrelevant, or because unreachable? Pruning on the second irreversibly bakes a retrieval artefact into topology.* **R27.5 — F-4 consumes UDB and the tombstone's `final_weight_digest` enters the anchor computation.**

> **R0.1 + R9.2.4 + R15.4 + R27.5 together make unverified displacement CONSERVED under every transformation the learning subsystem can perform. That conservation property — not any individual bound — is the actual content of the fix. D-L1 said: bounded steps, unbounded walk. R9.2.4 said: you cannot move the walk off θ. R27.5 said: you cannot escape the walk by deleting the ground.**

**R64.1 — the change graph is acyclic**; `superseded_by` (change→change), `signal_ref` (change→signal), `anchored_at` (change→verification). A cycle ⟹ RB-3. **R64.3 — a genome-diff carries the lineage of the verified changes that motivated it, WITHOUT their `source_class`. Motivation is recorded; warrant is not inherited.** **R64.7 — THE FAIL-SAFE PRINCIPLE: CORRUPTION PRODUCES RESTRICTION, NEVER PERMISSION.** An unverifiable anchor is treated as ABSENT ⟹ UDB = full displacement ⟹ immediate stall. A corrupted counter is read restrictively. A corrupted tombstone freezes the scope.

---

## §20 — THE DEGRADATION LADDER

| Level | Condition | Plasticity | Envelope | Learning | Exit |
|---|---|---|---|---|---|
| **L0 NORMAL** | UDB < B5; verdicts resolving | granted | full | at `lr` | — |
| **L1 CAUTIOUS** | T5 · T7 · class-10 · metaplasticity | reduced | **shrunk (mandatory)** | continues | trigger resolves |
| **L2 PROVISIONAL-AGED** | `AGE_1`/`AGE_2` | unchanged | **LOCAL → NONE** | continues | **probe ⟹ re-anchor** |
| **L3 CASCADE-FLAGGED** | any of the eight detectors | reduced | shrunk | continues **+ exposure obligation** | `[RO-13]` acts on the finding |
| **L4 STALLED** | **UDB ≥ B5** | **zero at scope and below** | frozen | **halted** (homeostasis only) | **probe ⟹ re-anchor ONLY** |
| **L5 FROZEN** | `learning_enabled ← FALSE` · homeostatic failure · INV violation | withdrawn | none | halted | EIK / organism |
| **L6 RETIRED** | E5, after CR-B + full lineage audit | ∅ | ∅ | ∅ | **∅** |

**R66.1 — THE LADDER IS MONOTONE: no downward transition increases plasticity, envelope, budgets or authority.** **R66.2 — the invariant is *no failure mode produces a capacity increase that the failure itself caused.* ** L3's B8 grant is written by `[RO-13]` in response to a detected cascade, not by the cascade. **R66.3 — there is no internal route upward. The only routes up are external: a probe, a governance grant, or an EIK/organism decision. That is the whole contract.**

---

## §21 — THE 42 `LEARN-INV` INVARIANTS

**I — the change object.** 01 every persistent modification is a `LearnedChange` · 02 `Λ5` has no write path · 03 exactly one target class · 04 a rollback handle exists iff not irreversible · 05 an anchor requires a probe (`probe_ref = NULL ⟹ verdict = UNKNOWN`) · 06 `cumulative_udb` is kernel-computed · 07 **the change record has two disjoint writers** (learner: `target`, `delta`, `trigger`; K: everything else).

**II — signals.** 08 the signal-kind set is closed · 09 class is derived, never declared · 10 provenance is immutable under learning · 11 **signals are deduplicated, not aggregated** · 12 admissible reward kinds are external · 13 `source = EVA_ONLY` · 14 **no transmitted credit exists** · 15 a prediction is registered before it resolves.

**III — bounds.** 16 unverified displacement is bounded per scope · 17 **`UDB_MAX` is monotone decreasing in scope** · 18 **UDB covers all admissible targets, not θ alone** · 19 budgets are non-transferable and non-bankable · 20 timescale ordering is enforced · 21 **structural change has no learning rate** · 22 the structural budget is a count and a blast radius · 23 homeostatic scaling is the only stall-exempt write, and only toward set-point.

**IV — authority.** 24 authority is monotone in scope · 25 monotone in rung, in authority AND verification cost · 26 **authority scales with irreversibility × blast radius, never magnitude** · 27 Λ4 has exactly one writable scope · 28 **governance and state share no write path** · 29 a composite's authority is the max of its rungs and its verification the conjunction · 30 S6 is empty for learning.

**V — epistemic separation.** 31 learning changes belief at fixed evidence status · 32 **no internal event raises evidence status, warrant, trust or `source_class`** · 33 reward does not raise belief · 34 **warrant magnitude is not gradient magnitude** · 35 prediction error is not causality and is not knowledge (L6 ceiling ⟹ cannot reach S3) · 36 **verification is not transferable**.

**VI — reversibility, lineage, audit.** 37 the change graph is acyclic · 38 **rollback marks, never deletes** · 39 an irreversible structural operation carries a tombstone · 40 **corruption fails safe**.

**VII — directional.** **41 NO FAILURE MODE PRODUCES A CAPACITY INCREASE.** **42 THE DEGRADATION LADDER IS MONOTONE — there is no internal route upward.**

*(Full formal statements with tags, quantifiers and rule references: Volume E §68.)*

---

## §22 — THE BUDGET SYSTEM

| Bound | Quantity | Resets | Note |
|---|---|---|---|
| **B1** | `Δ_MAX` per parameter | per update | inherited |
| **B2** | `DELTA_BUDGET[scope]` | **per epoch** | inherited — **a rate limit, not a distance limit** |
| **B3** | `Θ_MAX` | never | inherited |
| **B4** | homeostatic scaling | continuous | inherited — **stall-exempt (R15.2)** |
| **B5** | **`UDB_MAX[scope]`** | **only on re-anchor** | **NEW (R0.1).** Modulated by anchor quality (R9.4.2), anchor age (R9.4.3), volatility (R33.1). **Monotone decreasing in scope (INV-17).** |
| **B6** | **`STRUCTURAL_BUDGET`** = ⟨max_ops, max_blast_radius⟩ | per `[G]` interval | **NEW (R61.2)** |
| **B7** | `PROPOSAL_QUOTA` | per `[G]` interval | extends P0-04's B-7 regime to CH-3 |
| **B8** | **`EXPLORATION_BUDGET`** | per `[G]` interval | **NEW (R36.1)** |
| **B9** | **`PROBE_BUDGET` (organism-level)** | `[RO-13]` allocation | **NEW (R47.1)** |

**R30.1 — B2 AND B5 ARE COMPLEMENTARY AND NEITHER SUBSTITUTES FOR THE OTHER.** `B2 × (epochs until re-anchor) ≤ B5` is **not** guaranteed and must not be assumed; B5 binds precisely because B2 resets.

> ### **R47.1 — B9 IS THE ONLY BUDGET WHOSE EXHAUSTION HALTS LEARNING EVERYWHERE, AND THEREFORE: THE PROBE BUDGET IS THE LEARNING RATE OF THE ORGANISM.** Not `lr[timescale]` — that is the *step size*. B9 is the *rate at which steps may be taken before the organism must stop and be checked.*
> **This is the complete answer to Cell §9.6's `[U]` probe-cost problem, and it is architectural rather than numerical: the contract does not say how often to probe. It says WHAT HAPPENS WHEN YOU DON'T, and makes that consequence structural, scoped, observable and named.** *OR-L1 (how to verify cheaply) remains open, and the architecture degrades gracefully and visibly while it remains open.*

**R47.2 — BUDGET ALLOCATION IS GOVERNANCE AND IS NOT LEARNABLE.** A scope that appears to need more probes is a scope failing them, which reduces its anchor quality and therefore its `UDB_MAX` — **the opposite of a reward. No failure mode produces a budget increase.**

**R30.2 — budgets are non-transferable, non-bankable, use-it-or-lose-it.** A budget that can be traded is a currency, and a currency inside the learning subsystem is a hidden governance layer.

---

## §23 — ADVERSARIAL DEFENCE, REWARD HACKING AND PROBE GAMING

**Reward hacking, defined architecturally:** *the organism increases a measured reward component without increasing the tier-2 objective it was intended to measure, by exploiting a gap between the measurement and the objective.* **Three independent gap sources: MEASUREMENT (proxy), ATTRIBUTION (unattributable), EVALUATION (the organism shapes the evaluator's inputs).** A defence is needed for each, and **the third is not available.**

**R9.2.1** constraint coverage is observable; a scope with zero constraint evaluations is a finding, not a silence. **R9.2.2** RW-3 corrections carry `difficulty_class` and a per-scope rate. **R9.2.3** a ranking may not be a fitness input without a difficulty-controlled sample. **R9.2.4 — UDB is computed over ALL admissible targets at a scope, not over θ alone** *(closes displacement off θ, onto `plasticity_rate`, into decay, and through deletion)*.

**R9.3 — RH-2 (EVALUATOR MANIPULATION) IS NOT CLOSED AND IS NOT CLOSABLE BY ANY INTERNAL ARCHITECTURAL MEANS.** The organism is causally upstream of its own evidence, and **learning is the mechanism by which the filtering happens.** The chain — learning → behaviour → altered world → genuinely external, signed, admissible observations → verification of the learning that caused them — **is individually compliant at every link.** The architecture's claim is narrower and is the only honest one available: **RH-2 is (a) named, (b) observable through reach accounting and the `SUSPECT` detectors, (c) rate-limited by the stall and the optimism budget, and (d) NEVER REWARDED — no rule converts an RH-2-shaped success into a warrant, fitness, verification or authority increase.**

**R9.4 — R0.1 MOVES THE ATTACK SURFACE FROM THE REWARD FUNCTION TO THE PROBE, AND THAT IS A GOOD TRADE BUT A MOVE, NOT AN ELIMINATION.** Defences in descending strength: **R9.4.1 — the probe schedule is `[RO-13]`/K-owned and NOT READABLE by the learning subsystem** *(the primary defence, and the inherited design does not have it: Cell §9.6 says the probe is "held-out" about the DATA; it must also be held-out about the TIMING)* · **R9.4.2 — `UDB_MAX = g(anchor_quality)`, so a gamed probe buys a SHORTER LEASH and the attack is self-limiting** · **R9.4.3 — `UDB_MAX` decays with anchor age, so a stale anchor buys a shorter leash.** **RH-7 is BOUNDED, not CLOSED.**

**Seventy attacks in eight groups; 52 closed-family — 35 CLOSED and 17 CLOSED-STRUCTURAL, the latter meaning no object exists to attack — plus 5 conditional, 12 bounded, and 1 open.** *(Volume E §67.)*

---

## §24 — WHAT THIS CONTRACT DOES NOT CLAIM

1. **Not perfect learning.** At scale the organism learns **more slowly**, because the probe budget is the learning rate and it does not grow with N. §76.2's three regimes name the degradation.
2. **Not perfect credit assignment.** Most updates receive **no** credit assignment (CR-A correlational traces only). Cross-scope joint causation is invisible (OR-L4). Λ3 verification is unspecified (OR-L3).
3. **Not perfect reward.** RH-2 is open (OR-L6). Proxies remain proxies even when referenced.
4. **Not perfect causal inference.** Prediction error is not causality (R13.3); ablation is available only at E3+ and only where feasible.
5. **Not guaranteed adaptation.** A verification-scarce organism **stalls**. That is correct behaviour, not a failure — but it is not adaptation.
6. **Not emergence, not AGI, not consciousness.** `awareness` is not an architectural term (R59.4); it decomposes into SC-2 metering (permitted) and SC-1 self-assessment (prohibited as a learning driver).
7. **Not a solution to the Baldwinian ratchet.** R25.4 bounds it; closing it fully would prohibit evolution (CD-L9).
8. **Not a solution to the validator loop.** R24.3 requires a fixed core to exist; its contents are a governance decision P0-05 cannot make (OR-L2, OR-L10).
9. **Not a solution to learning from avoided outcomes.** The architecture can learn that engagement is survivable; **it cannot learn that abstention was correct** (OR-L5). Permanent asymmetry.
10. **Not implementation-independent in every respect.** It is neutral about algorithm, substrate and scale — and **non-neutral about authority**: a substrate that cannot express the two-writer partition does not host this contract approximately; it fails to host it (R77.4).

---

## §25 — THE FIVE SURVIVING PRINCIPLES OF P0-05

> ### **I. A CHANGE IS AN OBJECT, NOT AN EVENT.**
> Give every persistent modification a record with target, authorization, provisionality and reversibility, and most of the contract follows. Reversibility is the axis that determines authority; without it, magnitude is the only available argument and magnitude is a rate question, not an authority question.

> ### **II. BOUND THE DISTANCE FROM THE LAST VERIFIED STATE, NOT ONLY THE STEP.**
> A per-epoch budget bounds rate. An unverified-displacement bound turns verification from an accounting label into a leash, makes the probe budget the learning rate, bounds model collapse without a collapse detector, and conserves displacement under decay, deletion, metaplasticity and calibration alike.

> ### **III. NO FAILURE MODE PRODUCES A CAPACITY INCREASE.**
> Reduction is automatic and permissionless; increase is never automatic. Verification loss produces loss of reach, rate, budget and authority, in one direction only, at six levels, with no internal route upward. This is the same principle P0-04 stated for warrant, and it is the spine of both contracts.

> ### **IV. GOVERNANCE CHANGES CAPACITY; LEARNING CHANGES STATE; THE TWO SHARE NO WRITE PATH.**
> A learner inside its own governance loop is a governance layer, however well bounded. Eleven of thirteen circular dependencies are broken not by a bound but by moving the closing edge's writer outside the loop — **because a bound cannot break a cycle, it can only make the cycle smaller.**

> ### **V. THE CHEAPEST SIGNAL MUST BE THE ONE THAT NEEDS NO ATTRIBUTION, AND THE DEAREST MUST BE THE ONE THAT VERIFIES.**
> Prediction error is dense, free and attribution-free — and its cheapness and its attribution-freedom are the same property. Reward is sparse, expensive and confirmatory. Verification is scarcest of all and is the only thing that converts provisional into permanent. **Allocating these three by cost rather than by convenience is what makes the architecture feasible; making verification the scarcest is what makes it honest.**

---

**END OF THE CANONICAL CONTRACT.**
**Derivation, adversarial catalogue, contradiction audit and open-problem register: `40_` … `45_`. Verdict, output index, ratings and FINAL STANDARD: `README.md`.**
