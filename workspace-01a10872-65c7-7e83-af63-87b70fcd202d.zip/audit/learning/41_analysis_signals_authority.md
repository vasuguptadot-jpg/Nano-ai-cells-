# P0-05 — LEARNING, PLASTICITY & ADAPTATION CONTRACT
## Volume B — Signals, Authority, Evolution and the Plasticity Matrix (§19–§34)

**Status:** adversarial architecture audit. **Architecture only.** No implementation, no numerical parameter values.
**Depends on:** Vol A (§0–§18) — `LearnedChange` (R0.2), UDB (R0.1), Λ0–Λ4 (R4.1), S1–S6 (R4.2), reward taxonomy (R8.1), signal-is-instruction (R7.1).

> **Outputs discharged by this volume:** O8 (learning-signal taxonomy), O16 (local vs global — *jointly with §35*), O17 (signal provenance), O18 (signal authenticity), O19 (signal independence), O20 (plasticity authorization matrix), O21 (structural-change escalation), O23 (stability/plasticity), O36 (learning↔evolution), O37 (Baldwinian boundary), O38 (meta-learning — *authority half; capability half in §38/Vol C*).

---

# 19. **[O8] THE LEARNING-SIGNAL TAXONOMY

## 19.1 The category error the taxonomy must avoid

R7.1 established that a learning signal is **an instruction with a warrant**, not a claim. The immediate consequence is that the taxonomy cannot be organised by *content* (what the signal says) — it must be organised by **origin** (who may issue it) and **admissible effect** (what it may cause).

> ### **R19.1 — SIGNALS ARE CLASSIFIED BY ORIGIN × ADMISSIBLE EFFECT. NEVER BY CONTENT.**
> Two signals with identical content and different origins are **different signals** with different authority. Two signals with identical origin and different content are **the same class** of signal.
> **Why this ordering matters:** classifying by content is how V3 arrived at «successful use → strengthen» — a *content* description ("success") with no origin, which any component can assert. Classifying by origin makes the assertion non-portable.

## 19.2 **[O8] THE TAXONOMY — 5 CLASSES, 14 SIGNAL KINDS

| Class | **Origin** | **Warrant** | **May drive** | **May NOT drive** |
|---|---|---|---|---|
| **SC-0 — INADMISSIBLE** | self-assessment, peer assessment, retrieved memory, manufactured novelty, shaping function | none | **nothing** | everything. **Produces an audit entry only.** |
| **SC-1 — INTERNAL ESTIMATE** | the organism, about itself | **hypothesis** (P0-01 §13.2) | **PROVISIONAL** Λ0/Λ1 change only; rate-limited, tagged, rollback-able | permanent change · fitness · replication gates · retirement · anchor (R0.1) · evidence status |
| **SC-2 — KERNEL OBSERVATION** | K, from metered/invariant-checked state | **verdict on the measured quantity only** | Λ0/Λ1 change · Λ4 adjustment where K owns the parameter (`plasticity_mult`, Cell §4.1.8) | evidence status · warrant · trust |
| **SC-3 — EXTERNAL DEMONSTRATION** | EVA, signed, with `gt_id` | **verdict** (P0-01 §13.2) | Λ0–Λ4 change · `improvement_verified` probe · **anchor** · fitness · replication credit | evidence status (still requires P0-04's gate) · genome (Λ5, §1.2) |
| **SC-4 — GOVERNANCE DIRECTIVE** | `[RO-13]` policy / EIK / KC | **authority** | grant/withdraw plasticity (§28) · escalate (§29) · set bounds · stall/lift stall | **θ directly.** A governance directive changes *capacity*, never *state*. ← **R19.2** |

> ### **R19.2 — GOVERNANCE CHANGES CAPACITY, LEARNING CHANGES STATE, AND THE TWO NEVER SHARE A WRITE PATH.**
> An SC-4 directive may set `plasticity_mult`, `UDB_MAX`, `lr[timescale]`, admissible targets, and scope authority. **It may not write θ, weights, topology or representations.** Conversely no SC-1/2/3 signal may write any Λ4 or governance quantity.
> **This is P7 (governance outside the loop) expressed as a write-path rule.** It is the mechanism by which "the learning system is not a hidden governance layer" is enforced rather than asserted: **the learner holds no capability for governance objects and governance holds no capability for state objects.** §65 audits whether the inherited design actually maintains this separation.

## 19.3 The 14 signal kinds

| # | Kind | Class | Cell §9.2 trigger | Admissible effect | Note |
|---|---|---|---|---|---|
| **SG-1** | Resolved prediction error (§13) | **SC-3** if the observation is external & signed; **SC-1** if self-compared | **T1** | Λ0/Λ1 | **The primary signal.** No attribution requirement (R6.4.4). |
| **SG-2** | EIK/EVA-signed reward vector (RW-1) | **SC-3** | **T2** | Λ0/Λ1 + anchor-eligible | R12.1: cell signature ⟹ structurally invalid. |
| **SG-3** | External supervised correction (RW-3) | **SC-3** | **T3** | Λ0/Λ1 | ⚠️ **RH-C2 correction capture** ⟹ R9.2.2 (`difficulty_class` + rate). |
| **SG-4** | Self-supervised target | **SC-1** | **T4** | Λ0/Λ1 **PROVISIONAL ONLY** | Cell T4: may not move θ toward own reward. §48: **does not detect self-confirmation.** |
| **SG-5** | Novelty (distance-from-memory) | **SC-1** | **T5** | **`plasticity_mult ↓`, `SLOW_MODE`, envelope shrink — NEVER `Δθ`** | R14.2. Manufacturable ⟹ no positive authority. |
| **SG-6** | Surprise (pre-registered prediction violated) | **SC-1/SC-3** per SG-1 | **T1** | Λ0/Λ1 | R14.3: surprise teaches, novelty slows. |
| **SG-7** | Repeated success | **SC-1** | **T6** | **consolidation NOMINATION** (MEM-INV-20) · `plasticity_mult ↓` (metaplasticity) — **NOT `Δθ`, NOT anchor, NOT evidence** | §2.4: «Repeated successful exposure → stable integration» is X3 at learning altitude. |
| **SG-8** | Repeated failure | **SC-1** | **T7** | **`plasticity_mult ↓` — NOT more learning** | Cell T7's deliberate inversion. §39 develops it. |
| **SG-9** | Calibration deviation | **SC-3** (class 7: externally measurable only) | **T8** | **epistemic/calibration head ONLY** | Cell T8. May not touch θ proper. |
| **SG-10** | Constraint violation (RW-2) | **SC-2/SC-3** | — | **BLOCKS learning. Zero positive gradient.** | R8.1: gating, not gradient. |
| **SG-11** | Comparative preference (RW-4) | **SC-3** | — | **ranking only; NEVER a gradient** | R8.2 corollary. |
| **SG-12** | Homeostatic set-point deviation | **SC-2** | — | **homeostatic scaling ONLY** (R15.1) | Not a `LearnedChange`. Exempt from stall (R15.2). |
| **SG-13** | Peer `REPORT_ERROR` | **SC-1** (P0-01 §13.2 `PEER_REPORT`) | — | **evidence only; NOT a learning signal** | Cell §10.3. **A peer report may cause the recipient to *register a prediction*, never to `Δθ`.** ← **R19.3** |
| **SG-14** | Governance directive | **SC-4** | — | **capacity only** (R19.2) | §28/§29. |

> ### **R19.3 — THE PEER-REPORT FIREWALL, RESTATED AT LEARNING ALTITUDE.**
> A peer's `REPORT_ERROR` is **evidence about the world**, admissible into memory under P0-04's source-class regime with the evidence ceiling that regime assigns. **It is not an instruction to the recipient's parameters.**
> **The one permitted indirect path:** the recipient MAY, on receiving a peer report, **register a prediction** (§13.2) about the reported condition. If that prediction later resolves against an external observation, the resulting **SG-1** is admissible. **The peer report caused a prediction; the observation caused the learning.**
> **Why this indirect path is not a loophole:** it inserts an external observation and a pre-registration between the peer's claim and any `Δθ`. A malicious peer can cause the recipient to *look*, and cannot cause it to *change*. **This is the same move as P0-04's "retrieval writes nothing" (MEM-INV-09) and P0-03's "influence ⟶̸ transport".**

## 19.4 What is absent from the taxonomy, deliberately

| Absent kind | Why |
|---|---|
| **Curiosity / intrinsic reward (RW-6)** | R8.1. Self-minted, dense, maximised by manufacturing novelty. **No channel exists.** |
| **Self-assessment (RW-8)** | Cell §9.6. **The enum's absence is the mechanism.** |
| **Transmitted credit** | COMM-INV-20/28. Forbidden fields. |
| **Retrieved reward as signal** | R11.1. `RECALL ∉ T2 sources`. |
| **Simulated outcome as observation** | §42. Simulation is not observation (P0-04, §87). |
| **Consensus as signal** | §22. Consensus is a count; a learning signal is an instruction. |
| **Fitness as target** | R10.2. |
| **Shaping reward (RW-5)** | R12.4. |

**Eight absent kinds. The taxonomy is defined as much by what cannot be a signal as by what can** — and per §87 (*do not treat reward as truth*), the absences are the load-bearing part.

---

# 20. **[O17] SIGNAL PROVENANCE

> ### **R20.1 — EVERY ADMISSIBLE SIGNAL CARRYS MANDATORY PROVENANCE. A SIGNAL WITHOUT PROVENANCE IS SC-0.**

```
SignalProvenance {
  signal_id       : bytes<16>
  signal_kind     : enum{SG-1..SG-14}          // CLOSED set (§19.3)
  class           : enum{SC-0..SC-4}           // ⟵ derived from origin, NOT declared by sender
  origin          : {producer_id, producer_scope, producer_role}
  epoch           : u64                        // EIK-INV-14 binding — defeats replay
  derivation      : enum{OBSERVED, COMPARED, COMPUTED, DIRECTED}
  inputs          : [ref]                      // ⟵ MANDATORY for COMPUTED/COMPARED
  signature       : bytes<64>                  // ⟵ MANDATORY for SC-2/SC-3/SC-4
  gt_refs         : [gt_id]                    // ⟵ MANDATORY for SC-3 (R12.3)
  confidence_in_signal : {value, calibration_class, n}   // Cell §9.4's 5th factor
  delivery        : {at_least_once: TRUE, idempotency_key}  // P0-03: mandatory for learning signals
  admissible_for  : bitmask{Λ0,Λ1,Λ2,Λ3,Λ4, ANCHOR, FITNESS, RETIRE}  // ⟵ §19.2 table, kernel-set
}
```

**The three provenance rules that do the work:**

| Rule | Statement | Closes |
|---|---|---|
| **R20.2 — CLASS IS DERIVED, NEVER DECLARED.** | `class` is computed by K from `origin` + `signature` + `gt_refs`. **A signal that declares its own class is SC-0.** | Self-escalation. A cell cannot label its estimate `SC-3`. |
| **R20.3 — `inputs` IS MANDATORY FOR ANY DERIVED SIGNAL.** | A `COMPUTED` or `COMPARED` signal must list its inputs. **A derived signal with no input list cannot be audited and is SC-0.** | Untraceable internal computation masquerading as observation. **Also makes RH-2 partially observable: a signal whose `inputs` include states the organism itself caused is flagged (§9.3 C-3).** |
| **R20.4 — `admissible_for` IS KERNEL-SET FROM `class`, NOT FROM CONTENT OR MAGNITUDE.** | A large SC-1 signal does not become admissible for `ANCHOR`. | Magnitude-based authority escalation — the learning analogue of P0-04's "importance as hidden master variable." |

> ### **R20.5 — PROVENANCE IS IMMUTABLE UNDER LEARNING.**
> No `LearnedChange` may modify any field of any `SignalProvenance`. **Learning consumes provenance; it never produces or edits it.**
> This is MEM-INV-19 (plasticity cannot rewrite provenance) restated at signal altitude, and it is included here because **the learning subsystem is the only component with a motive**: a learner that could edit `class` from SC-1 to SC-3 would convert every internal estimate into an anchor-eligible external demonstration, defeating R0.1, Cell §9.6 and P0-01 §13.2 in one write. **R20.5 is therefore the highest-value single rule in Volume B.**

---

# 21. **[O18] SIGNAL AUTHENTICITY

| Threat | Mechanism | Defence | Status |
|---|---|---|---|
| **Forged reward** | A cell signs a reward message | **R12.1** — cell signature on reward is *structurally invalid* (I-class) | **CLOSED — type level** |
| **Replayed signal** | An old valid signal is re-delivered | **`epoch` binding (EIK-INV-14)** + `idempotency_key` (P0-03) | **CLOSED** |
| **Duplicated signal** | The same signal delivered *n* times to inflate weight | **at-least-once + idempotent** (P0-03); §22 | **CLOSED** |
| **Relabelled signal** | An SC-1 declared as SC-3 | **R20.2** — class derived, not declared | **CLOSED** |
| **Provenance-stripped signal** | A signal arrives without `inputs`/`gt_refs` | **R20.3, R12.3** — mandatory; absence ⟹ SC-0 | **CLOSED** |
| **Signature from a compromised evaluator** | A valid signature on a false evaluation | **P0-02's EIK regime + P0-01 §12.3's `cross_evaluator`/`n_evaluators`/`disagreement_policy`** | **BOUNDED — reduces to EIK's problem, not learning's** |
| **Signal injected at a scope above its origin** | An S1 signal applied at S3 | **R4.3** — monotone authority; a component may not authorise above its scope | **CLOSED** |
| **Genuine signal, adversarially caused** | The organism arranges the world so that a *valid* external signal is favourable | **§9.3 RH-2** | **⚠️ UNCLOSED — OR-L6.** Authenticity is not the defence; **authenticity is exactly what makes RH-2 hard.** |

> ### **R21.1 — AUTHENTICITY IS NECESSARY AND INSUFFICIENT, AND THE ARCHITECTURE SAYS SO.**
> Every defence above except the last is **CLOSED**. The last is not, and it is not closable by authenticity, because **RH-2 produces perfectly authentic signals.** A signed, epoch-bound, ground-truth-referenced, idempotently-delivered, correctly-classed reward obtained by shaping the evaluator's inputs is *authentic in every field* and *corrupt in its causal history*.
> **⟹ R21.1: authenticity is a property of a signal's FIELDS. Soundness is a property of a signal's CAUSAL HISTORY. The architecture can guarantee the first and can only *bound and observe* the second (R9.3 C-1…C-4, R20.3's `inputs` flagging, §63's monitors).**
> **Per §87: do not assume an external evaluator eliminates all feedback-loop problems. R21.1 is that instruction, discharged.**

---

# 22. **[O19] SIGNAL INDEPENDENCE — A MALFORMED QUESTION, CORRECTLY ANSWERED

## 22.1 The question as asked

> *"If ten cells independently generate the same internal reward, does this constitute ten independent learning signals?"*

## 22.2 Why the question is malformed

It applies an **evidence-aggregation** frame to an **instruction**. P0-04's `n_effective` (Cell §11.5) exists because *claims* accumulate: ten independent observations of the same fact genuinely raise warrant (subject to lineage dedup and error-correlation discount ρ). **Learning signals do not accumulate. They are consumed.**

> ### **R22.1 — LEARNING SIGNALS ARE DEDUPLICATED BY KEY, NOT AGGREGATED BY COUNT.**
> `n` identical signals with the same `idempotency_key` are **ONE signal delivered n times.** The correct response is **idempotent consumption** (P0-03 already mandates this for learning signals), not weighting by `n`.
> **Formally: `effect(signals) = effect(dedup(signals))`. There is no `n` term in `Δθ`.**

**Three reasons this is not merely a convention:**

| # | Reason |
|---|---|
| **1** | **There is no such thing as an independently generated internal reward.** R8.1: RW-8 (self-assessment) is ∅ and RW-6 (intrinsic) is prohibited. **Ten cells cannot "independently generate the same internal reward" because no cell may generate a reward at all.** The premise describes an inadmissible event. |
| **2** | **Ten cells are not independent.** They share genome (`param_init` distributions, Cell §3.4), share θ₀ lineage, share inputs, share the environment, and — decisively — share **the learning rule that produced their estimates.** Cell §11.5's error-correlation discount ρ exists precisely because correlated producers are not independent witnesses. **For identically-trained cells, ρ → 1 and `n_effective → 1`.** |
| **3** | **Aggregating instructions creates a consensus-authority channel.** If `n` identical SC-1 estimates could drive an SC-3 effect, then **coordination among cells would be a route to external-grade authority** — the exact structure P0-03 forbade ("consensus is not independent evidence") and P0-04 forbade (repetition ≠ evidence). **R22.1 closes the learning-side instance.** |

## 22.3 What independence analysis IS required for

The question is not empty — it is **misplaced**. Independence matters for:

| Object | Independence question | Owner | Rule |
|---|---|---|---|
| **The evidence a signal refers to** | Are the *observations* independent? | **P0-04** | `n_effective = |R_union|`, lineage dedup, ρ-discount (Cell §11.5) |
| **The probe that verifies a change** | Is the probe independent of the change's training context? | **P0-05 §9.3 C-1/C-2, R9.4.1** | Probe inputs `[RO-13]`-owned; probe schedule secret; cross-scope where possible |
| **The evaluators behind a reward** | Are `n_evaluators` independent? | **P0-01 §12.3** | `cross_evaluator`, `disagreement_policy` |
| **The signals driving changes at different scopes** | Are S2 and S3 changes driven by overlapping signal sets? | **P0-05** | ⟹ **R22.2** |

> ### **R22.2 — CROSS-SCOPE SIGNAL OVERLAP IS ACCOUNTED, NOT PROHIBITED.**
> The same SG-1 may legitimately drive changes at S1 and S2 (a prediction error is informative at both). **But if a change at S3 is verified by a probe whose inputs overlap the signals that drove the S3 change, the verification is not independent.** ⟹ **A probe MUST declare its input lineage, and `probe_inputs ∩ driving_signals ≠ ∅ ⟹ verdict is downgraded to `NEUTRAL` at best, never `IMPROVED`.**
> **This is the independence rule that actually matters, and the inherited design does not have it.** Cell §9.6 says "held-out" about the *data*; R22.2 says "held-out" about the *signal lineage*. Held-out data drawn from a signal lineage the learner already consumed is not held out.

## 22.4 The repetition question, closed at learning altitude

| Inherited text | Ruling |
|---|---|
| V3 §14 «Repeated successful exposure → stable integration» | **Repetition MAY:** raise consolidation *nomination* priority (MEM-INV-20) · lower `plasticity_mult` (metaplasticity, R15.5) · lower `lr` at that scope. **Repetition MAY NOT:** produce `Δθ` (SG-7) · re-anchor (R0.1 requires an SC-3 probe) · convert `PROVISIONAL → VERIFIED` · raise evidence status (P0-04 R0.2) · raise `n_effective` beyond lineage dedup. |
| V3 §18 «repeated success → cache» | ✅ **Caching is an allocation decision, not an epistemic one.** A cache entry carries the evidence status of its source, unchanged (P0-04). |
| V3 §18 «repeated demand → specialize» | ⚠️ **§46.** Demand is a throughput statistic; specialisation is an Λ3/S4 structural change with a diversity obligation. **Demand alone is never sufficient.** |

---

# 23. THE TRIGGER SET T1–T8, RE-AUDITED

Cell §9.2's eight triggers are a **closed set** and are inherited. The audit asks, for each: *what is its signal class (§19), what may it write (Λ), and does it consume UDB (R0.1)?*

| Trigger | Signal kind | Class | May write | UDB? | Anchor-eligible? | **Audit finding** |
|---|---|---|---|---|---|---|
| **T1** prediction error | SG-1/SG-6 | SC-3 (external obs) / SC-1 (self-compare) | Λ0, Λ1 | ✅ | ✅ if SC-3 | **Sound. The workhorse.** |
| **T2** EIK reward | SG-2 | **SC-3 only** | Λ0, Λ1 | ✅ | ✅ | **Sound.** R12.1 type-level closure. |
| **T3** supervised correction | SG-3 | SC-3 | Λ0, Λ1 | ✅ | ⚠️ | **⚠️ GAP — RH-C2.** No `difficulty_class`, no rate limit. ⟹ **R9.2.2.** Also: a correction is anchor-eligible only if the *probe* is independent of the correction set (R22.2) — otherwise the learner is verified on material it was taught. **⟹ R23.1: T3-driven changes may re-anchor ONLY on a probe whose inputs exclude all T3 corrections.** |
| **T4** self-supervised | SG-4 | **SC-1** | Λ0, Λ1 **PROVISIONAL** | ✅ | ❌ **NEVER** | **⚠️ GAP — self-confirmation.** Cell T4 checks "does not move θ toward own reward." **Model collapse is not a reward increase; it is a variance reduction toward the model's own mean.** T4's guard does not fire. ⟹ **§48: bounded by R0.1 as a special case of drift, not by a new mechanism.** |
| **T5** novelty | SG-5 | SC-1 | **`plasticity_mult ↓`, envelope ↓ — NO `Δθ`** | n/a | ❌ | **Sound, and deliberately inverted from V3 §8's reading.** R14.2. |
| **T6** repeated success | SG-7 | SC-1 | **nomination + metaplasticity — NO `Δθ`** | n/a | ❌ | **Sound.** §22.4. |
| **T7** repeated failure | SG-8 | SC-1 | **`plasticity_mult ↓` — NOT more learning** | n/a | ❌ | **Sound, and the most counter-intuitive rule in the corpus.** §39 explains why it is right and where it fails. |
| **T8** recalibration | SG-9 | **SC-3 only** (class 7 cannot be self-assessed) | **calibration head ONLY** | ⚠️ **see R23.2** | ❌ | **⚠️ GAP — R23.2.** |

> ### **R23.2 — CALIBRATION CHANGES CONSUME UDB.**
> Cell T8 permits recalibration of the epistemic head only. **But `confidence_in_error` is the fifth multiplicative factor of `Δθ` (Cell §9.4).** A change to calibration therefore changes the *gain* of every subsequent update — it is a **Λ4-class effect delivered through a T8 trigger**.
> **⟹ A T8 change MUST consume UDB at its scope, MUST be probe-verified like any Λ1 change, and MUST NOT be exempt merely because it "only" adjusts calibration.** An unverified calibration change that systematically inflates `confidence_in_error` is **unbounded learning-rate increase with no `Δθ` anywhere in the audit trail** — a stall-evasion channel isomorphic to RH-9.
> **This is the most consequential finding of §23.** T8 is presented in the Cell Contract as the *most benign* trigger ("recalibrate epistemic head only"). It is in fact the only trigger that writes a **gain on all other triggers**.

> ### **R23.3 — THE TRIGGER SET IS CLOSED AND ITS CLOSURE IS ENFORCED.**
> `trigger ∈ {T1…T8}` is a **kernel-checked enum**. No component may add a trigger, and no `LearnedChange` may be admitted with a trigger outside the set. **A state change to θ, weights, topology or policy with no `trigger` is an ungoverned learning event ⟹ LEARN-A1 (§67) ⟹ automatic rollback + audit finding.**
> **Note the asymmetry with Λ0:** transient state (activation, WM, eligibility traces) changes continuously and produces no `LearnedChange`. That is correct (R2.3, mechanism B). **The enforcement point is the decay horizon: a Λ0 quantity that persists past its declared horizon has become Λ1 without a trigger, and R2.3 makes that a violation.** ⟹ **R23.4: every Λ0 quantity has a kernel-enforced decay horizon; persistence past it is reclassified as Λ1 and requires a trigger retroactively or is rolled back.**

---

# 24. **[O36] LEARNING ↔ REPLICATION AND EVOLUTION

## 24.1 The inherited separation, and why it is right

V3 §15 («LEARNING VS EVOLUTION + HARD SEPARATION») and §16 («evolutionary firewall»), V3.1 §8 («learning → plasticity → evolution bridge, deliberately gated, Baldwinian»), Cell §3.4/§3.5 (parameters inherited as **distributions**, `θ₀ ~ param_init`; genome-diff proposals gated by 11 replication gates + held-out validation, with a machine-checkable rejection list), MEM-INV-21 (the inheritance channel carries **priors, not policies or content**), P0-04 R47.1 (Lamarckian prohibition).

**This is the strongest and most consistently specified boundary in the entire corpus.** Six independent documents state it. P0-05 inherits it unchanged and adds only what is needed to make it operable at the `LearnedChange` altitude.

## 24.2 The four-channel account

| Channel | Direction | What crosses | Authority | Reversible? |
|---|---|---|---|---|
| **CH-1 — INITIALIZATION** | genome → learning | **`param_init` DISTRIBUTION** (mean, spread) — never a learned value | genome (inherited) | n/a |
| **CH-2 — BOUND INHERITANCE** | genome → learning | `plasticity_rate`, `lr[timescale]` **bounds**, admissible target sets, trigger thresholds — i.e. **Λ4 bounds** | genome + `[RO-13]` | n/a |
| **CH-3 — BALDWINIAN PROPOSAL** | learning → genome | **A genome-diff PROPOSAL**, carrying **no source_class** (OR-M12) | **11 replication gates + held-out validation + KC** | **No** — once accepted it is inherited |
| **CH-4 — SELECTION** | fitness → lineage | **Fitness vector** (P0-01 §14), not scalar (R10.3) | `[RO-13]` selection policy | n/a |

> ### **R24.1 — CH-3 IS THE ONLY LEARNING→GENOME PATH AND IT IS A NOMINATION.**
> A Baldwinian proposal is to the genome what consolidation nomination is to memory tier (MEM-INV-20) and what a Λ2 nomination is to evidence status (P0-04 R0.2): **a request, not a change.** The same three-layer enforcement of §1.2 applies.
> **⟹ R24.1 corollary: a proposal's existence MUST NOT affect the proposer's own plasticity, budget, authority or fitness.** A cell that gains anything from *proposing* will propose maximally. **Proposals are rate-limited by a `[G]` quota and quota-gaming is detected by the same B-7-class detector P0-04 built for consolidation nomination.**

> ### **R24.2 — WHAT MAY BE PROPOSED, AND WHAT MAY NOT.**
> | May be proposed (CH-3) | May NOT be proposed |
> |---|---|
> | `param_init` distribution shifts for **verified-improved** parameter regions | **Learned θ values** (Lamarckian — R47.1) |
> | Learning-rule parameters (**Λ4 bounds**) — see R24.3 | **The bounds on Λ4 bounds** (infinite regress; ⟹ `[RO-13]`/KC only) |
> | Plasticity-rate distributions | `plasticity_mult` **state** (K-only, Cell §4.1.8) |
> | Specialisation priors | **Governance functions** — `F` (fitness aggregation, R10.1), the authorization matrix (§28), the escalation ladder (§29), UDB_MAX (§30), invariants |
> | | **Anything carrying a `source_class`** (OR-M12) |
> | | **Any content, memory record, belief or evidence status** (MEM-INV-21) |
>
> **The rejection list is machine-checkable** (Cell §3.5 already requires this). R24.2 **extends** that list with four entries the Cell Contract does not name: governance functions, the authorization matrix, the escalation ladder, and UDB_MAX. **⟹ A genome-diff that would alter how the organism is governed is rejected at the type level, not by policy review.**

> ### **R24.3 — V3.1 §7's «LEARNING-RULE VARIATION» IS THE HIGHEST-AUTHORITY CHANGE IN THE ARCHITECTURE.**
> V3.1 §7 lists variation of *learning rules*, *memory policies*, *communication policies*, *topology* and *specialisation* as evolutionary operators. The first is Λ4 (§4.1). **So a genome-diff can change how the organism learns.**
> **Consequences, all normative:**
> 1. **Evolving the RULES ≠ evolving the KNOWLEDGE.** A learning-rule diff changes the *procedure*; it installs no content, no belief, no memory. **This is the distinction V3.1 §7 gestures at and never states, and it is what keeps R47.1 intact while permitting §7.**
> 2. **A learning-rule diff alters the criteria by which future diffs are verified.** The held-out validation that gates CH-3 is itself performed under learning rules. **⟹ A diff that changes learning rules changes the instrument that measures the next diff.** This is **OR-L2, UNCLOSED.**
> 3. **Containment (not closure) for OR-L2:** (a) a learning-rule diff requires **all 11 gates PLUS a meta-level probe whose criteria are `[RO-13]`-owned and NOT alterable by any diff** — i.e. there is one fixed validation instrument outside the evolvable set; (b) learning-rule diffs are **rate-limited to one per lineage per `[G]` interval**; (c) the **invariant kernel is not evolvable** (Cell §3.5, and the audit's Rule 19: *treat the external invariant kernel as separate from the evolvable substrate*).
> **⟹ R24.3: there exists a NON-EMPTY, FIXED, `[RO-13]`/KC-OWNED VALIDATION CORE that no genome-diff, learning-rule diff or meta-learning update may alter. Its existence is the only thing preventing an infinite regress of self-modifying criteria. What it contains is a governance decision, not an architectural one, and P0-05 does not specify it — but P0-05 requires that it exist and that it be non-empty.**

**R24.3 is the answer to §87's "do not allow learning to rewrite EIK authority" at the evolutionary altitude.** The learning subsystem cannot rewrite EIK authority (R20.5, R19.2, §1.2). The *evolutionary* subsystem could, in principle, via a learning-rule diff. **R24.3 closes that by positing a fixed validation core outside the evolvable set** — which is Rule 19 of the 20 CRITICAL RULES, finally given a job to do.

---

# 25. **[O37] THE BALDWINIAN BOUNDARY

## 25.1 Baldwinian vs Lamarckian, stated operationally

| | **LAMARCKIAN (prohibited)** | **BALDWINIAN (permitted)** |
|---|---|---|
| **What is inherited** | The **learned value** | The **predisposition to learn it** |
| **Form** | `genome.θ ← θ_learned` | `genome.param_init ← distribution centred near θ_learned` |
| **Effect on offspring** | Offspring **has** the competence | Offspring **reaches** the competence faster, and **can fail to** |
| **Is the acquired property guaranteed?** | Yes — **which is why it is prohibited** | **No.** The offspring must still learn, still be verified, still pass the gates. |
| **Can a wrong learned state propagate?** | **Yes, silently and permanently** | Only as a *bias*, and the bias is re-tested every generation |
| **Evidence status of the inherited item** | Would carry the parent's status — **the fatal property** | **Carries NO `source_class`** (OR-M12) — it is a prior, not a claim |

> ### **R25.1 — THE BALDWINIAN TEST: *COULD THE OFFSPRING BE WRONG?*
> A proposed inheritance channel is Baldwinian **iff** an offspring inheriting it can still fail, still be corrected, and still be selected against. **If inheriting the channel guarantees the property, the channel is Lamarckian and is rejected — regardless of what it is called.**
> **This single test disposes of every candidate crossing**, and it is checkable against R24.2's list: `param_init` distributions ⟹ offspring can fail ✅. Learned values ⟹ offspring cannot fail ❌. Governance functions ⟹ offspring cannot fail ❌. Content/memory ⟹ offspring cannot fail ❌.

## 25.2 The boundary's three failure modes

| # | Failure mode | Mechanism | Defence |
|---|---|---|---|
| **BF-1** | **Distribution narrowing as covert Lamarckism** | Propose `param_init` with **vanishing spread**. In the limit, a zero-variance distribution *is* a learned value. | **⟹ R25.2: `param_init` proposals MUST carry non-zero spread, and the spread MUST NOT decrease below the parent's spread by more than a `[G]`-bounded factor per generation.** A monotone-spread-narrowing ratchet is Lamarckism by accumulation — **D-L1's exact analogue on the inheritance channel**, and the inherited design does not have this rule. |
| **BF-2** | **Priors that carry implicit evidence** | A prior centred on a value that was verified in the parent's context imports the parent's *warrant* into the offspring's *starting point*. | **OR-M12 (inherited): priors carry no `source_class`.** ⟹ **R25.3: an offspring's confidence in any proposition MUST NOT be initialised from the prior's location.** The prior may bias θ; it may not bias belief. **Belief starts at the floor and must be earned by the offspring's own external gates.** |
| **BF-3** | **Baldwinian ratchet via selection** | Even with non-zero spread, **selection** systematically favours offspring whose priors match the current environment. Over generations the population's priors converge on the parent's learned state — **Lamarckism implemented by selection rather than by write.** | **⚠️ PARTIALLY UNCLOSED.** This is not a defect — it is *what Baldwinian evolution is*. **The containment is that the convergence is slow, is re-tested every generation, and can be reversed by environmental change.** ⟹ **R25.4: the V3.1 §9 `DIVERSITY CHECK` is MANDATORY on any selection operating over `param_init`, precisely so that a Baldwinian ratchet cannot collapse the population's learning predisposition to a point.** §46 gives the diversity obligation its trigger and authority. |

**BF-3 deserves the honest label it gets in §86: the Baldwinian boundary is not a wall, it is a rate limit.** What the architecture guarantees is that acquired characteristics propagate **only as re-testable biases at generational timescale**, never as installed values at learning timescale. **It does not guarantee that the population's biases never come to resemble the ancestors' acquired state — because if it did, it would have prohibited evolution.**

---

# 26. THE GENOME INTERFACE — Λ5 IN DETAIL

§1.2 stated the three-layer prohibition. This section states the **interface**: what the learning subsystem may *read* from the genome, since it may write nothing.

| Genome quantity | Learning may READ? | Learning may WRITE? | Note |
|---|---|---|---|
| `param_init` distribution | ✅ **as initialisation only** | ❌ | Read **once**, at scope instantiation. **⟹ R26.1: re-reading `param_init` to re-initialise is a reset, and a reset is an Λ4 governance action, not a learning action.** A learner that could reset itself to its prior could evade UDB by re-anchoring to the genome — **which has no `probe_ref` and therefore cannot be an anchor (R0.1 requires IMPROVED/NEUTRAL from a probe).** |
| `plasticity_rate` bounds | ✅ | ❌ | CH-2. |
| learning-rule parameters (Λ4 bounds) | ✅ | ❌ | R24.3. |
| specialisation priors | ✅ | ❌ | |
| **role, identity, budget, throttle_level, `learning_enabled`, `replication_eligibility`, port schemas, `assigned_objective`, `calibration_class`, `trust_out_assigned`** | ✅ read-only | ❌ **Cell §9.3 already rules all of these ❌ EIK-or-organism** | **Inherited unchanged.** |
| **`source_class` of any record** | ✅ | ❌ | OR-M12, MEM-INV-21. |
| **Invariants (`LEARN-INV`, `MEM-INV`, `COMM-INV`, `EIK-INV`, `TE-*`)** | ✅ | ❌ **∅ — no write path at any altitude, including CH-3** | R24.2, R24.3. |

> ### **R26.2 — THE GENOME IS READ-ONCE PER SCOPE INSTANTIATION.**
> The learning subsystem reads genome-derived bounds at scope creation and **caches them as `[G]` constants for that scope's lifetime**. A genome change takes effect at the **next** instantiation, never mid-life.
> **Why:** a mid-life genome read is a channel by which an evolutionary change becomes a learning-time change — **CH-3 in reverse, ungated.** R26.2 makes the genome/learning interface **transactional at scope boundaries**, which is the only place the 11 gates can be evaluated.

---

# 27. FORGETTING

## 27.1 Forgetting is not one mechanism

The corpus uses "forgetting" for at least four distinct operations with different authorities and different reversibility:

| Kind | **What is lost** | Λ | A4 reversibility | Authority | Inherited |
|---|---|---|---|---|---|
| **F-1 — DECAY** | Λ0 transient state, by horizon | Λ0 | `DECAYS` | none required | ✅ R23.4 |
| **F-2 — PARAMETER DECAY / WEIGHT REGULARISATION** | θ magnitude, toward a set-point | Λ1 | `CHECKPOINT_REVERSIBLE` | `SELF_LOCAL` | ✅ Cell §9.5(1). **⟹ R15.4: consumes UDB.** |
| **F-3 — MEMORY FORGETTING** | retrievability of a record | **Λ2** | **`VERSION_REVERSIBLE`** — **the record survives in archive** (P0-04) | **P0-04's regime** | ✅ P0-04 |
| **F-4 — PRUNING** | a connection, and **its entire weight history** | **Λ3** | **`IRREVERSIBLE_STRUCTURAL`** | **§29 escalation** | ⚠️ V3 §8 «persistent uselessness → prune» with **no authority, no reversibility class, no attribution requirement** |

> ### **R27.1 — F-3 AND F-4 ARE NOT THE SAME KIND OF LOSS, AND V3 TREATS THEM AS ONE.**
> **Forgetting a memory is recoverable: the record persists and its provenance is intact (P0-04). Pruning a connection is not: the weight, its eligibility-trace history, and every `LearnedChange` that referenced it lose their referent.**
> **Consequences:**
> 1. **F-4 requires CR-B ablation** (R6.4.2) — causal attribution is mandatory for irreversible actions (P0-01 §23.2). **Disuse is not attribution.**
> 2. **F-4 must preserve a TOMBSTONE**: `{connection_id, removed_at, removed_by, ablation_ref, final_weight_digest, lineage_refs}`. **Without a tombstone, the audit trail of every change that touched the connection becomes unverifiable** — and §64's lineage requirement fails retroactively. **⟹ R27.2: an F-4 without a tombstone is inadmissible.**
> 3. **F-4 is subject to the disuse-cause attribution** (§2.4): *was it unused because irrelevant, or unused because unreachable?* **Only the first justifies pruning.** The second is P0-04 §26.3's survivorship bias, and pruning on it is **irreversibly** baking a retrieval artefact into topology. **⟹ R27.3: `disuse_cause ∈ {IRRELEVANT, UNREACHABLE, UNKNOWN}` is MANDATORY on any F-4 proposal, and `UNKNOWN` and `UNREACHABLE` are insufficient.**

## 27.2 Forgetting as a stall-evasion channel

R15.4 closed the Λ1 case (decay consumes UDB). Two residuals:

| Residual | Attack | Ruling |
|---|---|---|
| **F-3 as UDB evasion** | Forget the memory that a probe would contradict | **P0-04 already forbids rewriting historical evidence.** Forgetting *retrievability* is permitted; **deleting or altering the record is not.** A probe MUST be able to sample archived records. ⟹ **R27.4: `improvement_verified` probes may access F-3-forgotten (archived) records. Forgetting does not hide evidence from verification.** |
| **F-4 as UDB evasion** | Prune the connections carrying unverified displacement, resetting `‖θ − θ_anchor‖` by deleting θ | **⟹ R27.5: F-4 consumes UDB at its scope, and the tombstone's `final_weight_digest` is included in the anchor computation.** Displacement cannot be erased by deleting its carrier. |

**R27.5 is the closing rule of the D-L1 family.** D-L1 said: bounded steps, unbounded walk. RH-9 said: move the walk off θ. R27.5 says: **you cannot escape the walk by deleting the ground.** Together, R0.1 + R9.2.4 + R15.4 + R27.5 make unverified displacement conserved under every transformation the learning subsystem can perform. **That conservation property — not any individual bound — is the actual content of the fix.**

---

# 28. **[O20] THE PLASTICITY AUTHORIZATION MATRIX

§2.2 identified this as **the largest governance gap in the inherited learning design**: plasticity is governed by exactly one rule (Cell §4.1.8, `plasticity_mult` K-only). The matrix is the missing artifact.

## 28.1 Structure

> ### **R28.1 — THE MATRIX IS `scope × target × operation → {authorization, budget, reversibility, verification}`.**
> It is a **governance artifact owned by `[RO-13]`**, published read-only to the learning subsystem, and **not itself learnable at any scope** (R24.2, R19.2).

## 28.2 The matrix

| Scope ↓ / Target → | **Λ0 transient** | **Λ1 parameter** | **Λ2 representation** | **Λ3 structural** | **Λ4 policy** |
|---|---|---|---|---|---|
| **S1 synaptic** | `SELF_LOCAL` · no budget · `DECAYS` · no verify | `SELF_LOCAL` · per-connection budget · `ROLLBACKABLE_IN_MEMORY` · **probe** | ❌ **∅** | ❌ **∅** — *a synapse may not create or remove itself* | ❌ **∅** |
| **S2 cellular** | `SELF_LOCAL` | `SELF_LOCAL` · `Δ_MAX`/`DELTA_BUDGET`/`Θ_MAX`/homeostatic · `CHECKPOINT` · **probe** | **nominate only** ⟹ P0-04 gate | **propose only** ⟹ S3+ authorises | ❌ **∅** — *including `plasticity_mult` (K-only)* |
| **S3 micro-circuit** | `CIRCUIT` | `CIRCUIT` (over S2 targets within the circuit) | **nominate only** | ✅ **`CIRCUIT`** · structural budget (R15.6) · `IRREVERSIBLE_STRUCTURAL` for removal · **CR-B ablation MANDATORY** | ❌ **∅** |
| **S4 regional** | `ORGANISM` | `ORGANISM` | ✅ **`ORGANISM`** under P0-04 | ✅ **`ORGANISM`** · CR-B · tombstone (R27.2) | ❌ **∅** |
| **S5 organismal** | `POLICY` | `POLICY` | `POLICY` | ✅ **`POLICY (RO-13)`** · **cross-region only** | ✅ **`POLICY (RO-13)` / EIK — the ONLY scope that may write Λ4** |
| **S6 populational** | ❌ **∅ — learning does not operate at S6** | ❌ | ❌ | ❌ | ❌ **CH-3 proposal only, under 11 gates + KC (R24.1)** |

**Reading the matrix — the seven structural facts:**

| # | Fact | Why it matters |
|---|---|---|
| **1** | **The ∅ cells are the mechanism.** Of the thirty cells, **eleven are outright prohibitions** (S1: Λ2/Λ3/Λ4 · S2: Λ4 · S3: Λ4 · S4: Λ4 · S6: all five) **and three more admit nomination or proposal only** (S2: Λ2 nominate, Λ3 propose · S3: Λ2 nominate) — **so only sixteen of thirty are unrestricted writes.** | Per §1.2's logic: a capability that does not exist cannot be abused. Every ❌ is an *absence*, not a rule to obey. |
| **2** | **Λ4 has exactly one writable scope: S5, by `[RO-13]`/EIK.** | **This is R19.2 and R23.2 combined.** No learning subsystem at any scope writes its own policy. Meta-learning (§38) operates *within* Λ4 bounds and never *on* them. |
| **3** | **S6 is entirely ∅ for learning.** | R4.2. Learning and evolution do not share a scope. The only S6 crossing is CH-3, which is a **proposal**, not a learning operation. |
| **4** | **Λ2 is writable at exactly one scope (S4) and is *nomination-only* below it.** | P0-04's governance attaches at the altitude where representation change has shared consequence. **A cell may not write shared representation, full stop.** |
| **5** | **Λ3 requires CR-B ablation at every scope where it is writable.** | R6.4.2 + P0-01 §23.2. **Causality is spent exactly where irreversibility lives.** |
| **6** | **S1 may not create or remove itself.** | A self-removing synapse is an unauthorised F-4 with no ablation and no tombstone. **Topology change is always authorised from above the topology being changed** — the same principle as R15.7's "off-cell" loop gain and Cell §9.6's K-only verdict. |
| **7** | **`SELF_LOCAL` never appears at S3+.** | Below S3, self-authorisation is safe because blast radius is 1 and reversibility is high. **At S3+, "self" is already a collective, and self-authorisation is governance.** |

## 28.3 Grant, reduction and withdrawal

The matrix says who *may*. It does not say who *currently can*. That is the plasticity **state**, and it is governed separately:

| Operation | Who | Instrument | Effect |
|---|---|---|---|
| **GRANT** | `[RO-13]` / EIK, per the matrix | scope instantiation + genome bounds (CH-2, R26.2) | Sets admissible targets, budgets, `lr` bounds |
| **REDUCE** | **K**, from SC-2 observation | `plasticity_mult ↓` (Cell §4.1.8) | Triggered by T5 (novelty), T7 (failure), metaplasticity (R15.5), `SLOW_MODE` (R15.10), R1.3 envelope shrinkage |
| **WITHDRAW** | **K** or `[RO-13]` | `learning_enabled ← FALSE` (Cell §9.3: ❌ for the cell — **EIK or organism only**) | Total. The scope becomes frozen. **Reversible only by the same authority that withdrew.** |
| **STALL** | **K**, automatically | R0.1 UDB breach | Writes halted at scope and below (R18.1). **Lifted only by a probe re-anchor.** Homeostasis exempt (R15.2). |
| **ESCALATE** | per §29 | scope elevation of a proposal | An S2 component may **propose** an Λ3 change; S3+ **authorises** it. |

> ### **R28.2 — REDUCTION IS AUTOMATIC AND PERMISSIONLESS; INCREASE IS NEVER AUTOMATIC.**
> Every instrument in the REDUCE row fires from kernel observation without any component's consent. **No instrument in the matrix increases plasticity automatically.** An increase requires GRANT (governance) or the lifting of a REDUCE (which returns to the granted level, never above it).
> **This is the directional core of the entire contract, and it is the learning-altitude form of P0-04 §91's "no failure mode produces a warrant increase":**
> ### **NO FAILURE MODE, INTERNAL SIGNAL, OR SELF-OBSERVATION PRODUCES A PLASTICITY INCREASE.**
> **The asymmetry is deliberate and it has a cost:** the organism cannot decide to learn harder when it notices it is doing badly. T7 says the opposite — repeated failure *reduces* plasticity. §39 defends that choice and §36 (exploration) provides the legitimate route to "try harder", which is a **budget allocation**, not a plasticity increase.

---

# 29. **[O21] STRUCTURAL-CHANGE ESCALATION LADDER

R0.3 established that authority scales with **irreversibility × blast radius**, not magnitude. §29 is the ladder that operationalises it, and it is what V3.1 §6's unnamed "circuit" and "regional" scales were missing.

## 29.1 The ladder

| Rung | **Operation** | Blast radius | A4 | **Minimum authority** | **Verification** | **Budget** |
|---|---|---|---|---|---|---|
| **E0** | weight adjust | 1 connection | `ROLLBACKABLE_IN_MEMORY` | `SELF_LOCAL` | held-out probe (Cell §9.6) | `Δ_MAX`, `DELTA_BUDGET` |
| **E1** | create connection (additive) | 1 → 2 components | `CHECKPOINT_REVERSIBLE` (removal returns to prior state) | `CIRCUIT` | probe at S3 | structural budget |
| **E2** | reroute connection | circuit | `CHECKPOINT_REVERSIBLE` | `CIRCUIT` | probe at S3 + **CR-B** | structural budget |
| **E3** | **remove / prune connection** | circuit | **`IRREVERSIBLE_STRUCTURAL`** | `ORGANISM` | **CR-B ablation MANDATORY** + tombstone (R27.2) + `disuse_cause = IRRELEVANT` (R27.3) | structural budget |
| **E4** | recruit cell to a function | region | `VERSION_REVERSIBLE` (release) | `ORGANISM` | **CR-B** + diversity check (R25.4) | structural + regional budget |
| **E5** | release / retire cell | region | **`IRREVERSIBLE_STRUCTURAL`** | `ORGANISM` + **P0-01 §23.2's retirement regime** | **CR-B** + full lineage audit (§64) | — |
| **E6** | form / dissolve subcircuit | region | `IRREVERSIBLE` (dissolve) | `ORGANISM` | **CR-B** + cross-scope probe (C-2) | regional budget |
| **E7** | change regional topology / specialisation degree | organism | **`IRREVERSIBLE_STRUCTURAL`** | **`POLICY (RO-13)`** | **CR-B** + diversity check + **S5 probe (weakest — R18.2)** | organismal budget |
| **E8** | **change a learning rule (Λ4)** | organism | `VERSION_REVERSIBLE` | **`POLICY (RO-13)` / EIK** | **meta-probe under the FIXED validation core (R24.3)** | — |
| **E9** | **propose a genome-diff (CH-3)** | population | **irreversible once accepted** | **11 gates + held-out validation + KC** | R24.2's rejection list, machine-checked | proposal quota (R24.1) |

## 29.2 The four ladder rules

> ### **R29.1 — ESCALATION IS BY RUNG, NOT BY JUMP.** An operation at rung *n* requires the authority of rung *n*. **There is no "batch" authority.** A component authorised for E1 is not thereby authorised for E3, even though both are connection operations — **E3's irreversibility is the difference, and R0.3 says irreversibility is what authority tracks.**

> ### **R29.2 — A LOWER RUNG MAY PROPOSE, NEVER EXECUTE, A HIGHER RUNG.** S2 may propose E3. S3 authorises. **The proposal carries no effect and consumes no budget** — but it is rate-limited by a `[G]` quota, because **unlimited proposals are a governance-denial-of-service channel** (E9's quota, R24.1, is the same rule at the top of the ladder).

> ### **R29.3 — DECOMPOSITION IS MANDATORY (R4.1).** A composite operation ("reorganise this circuit") MUST decompose into rungs, each separately authorised. **⟹ The authority of a composite is the MAXIMUM of its rungs, and its verification is the CONJUNCTION of its rungs.** A composite containing an E3 requires `ORGANISM` **and** ablation **and** a tombstone, even if nine tenths of it is E0.
> **This closes LEARN-A6 (authority escalation by adjacency, §4.1) structurally:** there is no composite authorization, so there is no adjacency to exploit.

> ### **R29.4 — THE LADDER IS MONOTONE IN BOTH DIRECTIONS.** `authority(E0) ≤ authority(E1) ≤ … ≤ authority(E9)` **and** `verification_cost(E0) ≤ … ≤ verification_cost(E9)`. **Kernel-enforced.** An operation whose declared authority exceeds its rung is rejected; an operation whose declared verification is *below* its rung is rejected. **⟹ A component cannot obtain E3 authority by declaring E3 verification cheaply, nor E3 cheapness by declaring E0 authority.**

## 29.3 What the ladder does not solve

| Unresolved | Statement |
|---|---|
| **OR-L3** | **There is no probe design for Λ3.** Cell §9.6's held-out probe measures θ's effect on prediction. A topology change's effect is not a per-cell quantity. **R29.1–R29.4 mandate CR-B ablation at E3+, which is a *causal* check on the removed component, not a *held-out* check on the resulting circuit.** The architecture requires verification it cannot yet specify. **Declared, not hidden (§87).** |
| **Rung-cost inversion** | At E7 the probe is at S5, where C-2 (cross-scope probe) is unavailable and R18.2 makes `UDB_MAX` smallest. **⟹ The largest structural changes get the least unverified room and the weakest verification.** This is correct (R18.2's logic) and it means **E7 changes will stall more often than E0 changes.** That is a designed consequence, not a bug: **the architecture makes big changes expensive and slow on purpose.** |

---

# 30. THE PLASTICITY BUDGET

Cell §9.4 gives four bounds. R0.1 adds a fifth. §30 states the complete budget system and its accounting.

| Bound | Quantity | Scope | Owner | Resets | Inherited? |
|---|---|---|---|---|---|
| **B1** | `Δ_MAX` — per-parameter clip | per parameter | `[G]` / genome (CH-2) | per update | ✅ Cell §9.4 |
| **B2** | `DELTA_BUDGET` — `‖ΣΔθ‖` | per scope, **per epoch** | `[G]` / K | **every epoch** ← **the D-L1 defect** | ✅ Cell §9.4 |
| **B3** | `Θ_MAX` — absolute magnitude | per parameter / per scope | `[G]` / genome | never | ✅ Cell §9.4 |
| **B4** | **homeostatic scaling** — deviation from set-point | per scope | K, mandatory | continuous | ✅ Cell §9.4. **Exempt from stall (R15.2).** |
| **B5** | **`UDB_MAX[scope]`** — `‖θ_S − θ_anchor(S)‖` | **per scope, across epochs** | `[G]`, **monotonically decreasing in scope (R18.2)**, modulated by anchor quality (R9.4.2) and anchor age (R9.4.3) | **only on re-anchor** | ❌ **NEW — R0.1** |
| **B6** | **`STRUCTURAL_BUDGET[scope]`** — count/norm of Λ3 operations | per scope | `[G]` | per `[G]` interval | ❌ **NEW — R15.6** |
| **B7** | **`PROPOSAL_QUOTA`** — E9 / nomination rate | per scope | `[G]` | per `[G]` interval | ⚠️ Partial: P0-04's B-7 quota-gaming detector; R24.1 extends it to CH-3 |

> ### **R30.1 — B2 AND B5 ARE COMPLEMENTARY AND NEITHER SUBSTITUTES FOR THE OTHER.**
> **B2 is a rate limit within an epoch. B5 is a distance limit across epochs.** Removing B2 permits a single catastrophic update; removing B5 permits D-L1. **Both are mandatory.**
> **The relationship is: `B2 × (number of epochs until re-anchor) ≤ B5` is NOT guaranteed and MUST NOT be assumed.** B5 is the binding constraint precisely because B2 resets. **A scope that never re-anchors exhausts B5 after `⌈B5/B2⌉` epochs and stalls — and that number is the architecture's honest, structural answer to Cell §9.6's `[U]` probe-cost question: *the probe budget determines how often you may exhaust B5, and therefore how fast you may learn.***

> ### **R30.2 — BUDGETS ARE NOT TRANSFERABLE ACROSS SCOPES OR ACROSS KINDS.**
> Unused B2 at S1 may not be spent at S3. Unused B6 may not be converted to B5. **A budget that can be traded is a currency, and a currency inside the learning subsystem is a hidden governance layer (§65).**
> **⟹ Specifically: no component may accumulate, bank, borrow or lend any of B1–B7.** Every budget is **use-it-or-lose-it within its reset interval**, except B5, whose "reset" is a re-anchor and whose exhaustion is a stall.

> ### **R30.3 — `lr` ORDERING IS KERNEL-ENFORCED ACROSS TIMESCALES AND SCOPES.**
> Cell §9.4: `lr_fast ≥ lr_medium ≥ lr_slow`. R16.3 generalises across scopes: `authority(S') ≤ authority(S)` for `S' ⊂ S`, and cross-scope writes to overlapping targets are serialised.
> **⟹ Combined: a fast, low-scope process may not undo a slow, high-scope one.** This is the temporal form of R29.1's rung monotonicity, and it is what makes multi-timescale plasticity (V3.1 §6) governable rather than merely layered.

---

# 31. **[O23] STABILITY / PLASTICITY — THE COMPLETE CONTRACT

§15 established R15.9 (two quantities, two owners, not one axis) and R15.10 (reduce reach, not rate). §31 completes **[O23]** with the operating regime.

## 31.1 The five stability obligations

| # | Obligation | Instrument | Owner | Inherited |
|---|---|---|---|---|
| **ST-1** | **Bounded step** | B1 `Δ_MAX`, B3 `Θ_MAX` | `[G]`/genome | ✅ |
| **ST-2** | **Bounded rate** | B2 `DELTA_BUDGET` | `[G]`/K | ✅ |
| **ST-3** | **Bounded unverified distance** | **B5 UDB + stall** | K | ❌ **NEW** |
| **ST-4** | **Bounded gain** | `loop_gain < 1`, computed **off-cell** (Cell §9.5(6)) | K | ✅ |
| **ST-5** | **Bounded reach of the unverified** | **R1.3 envelope shrinkage** | K | ❌ **NEW** |
| **ST-6** | **Set-point maintenance** | B4 homeostatic scaling; set-points **not learnable** (R15.3) | K/genome | ✅ (scaling) / ❌ **NEW** (set-point non-learnability made explicit) |
| **ST-7** | **Verified improvement or rollback** | Cell §9.6 verdict + automatic rollback on `REGRESSED`; **extended to `AGE_3` never-verified (R1.3)** | K | ⚠️ Extended |

## 31.2 The regime, as a state description

| State | Condition | Plasticity | Envelope | Learning | Exit |
|---|---|---|---|---|---|
| **NORMAL** | UDB < B5; no shift; verdicts resolving | granted | full | at `lr[timescale]` | → CAUTIOUS, STALLED, FROZEN |
| **CAUTIOUS** (`SLOW_MODE`) | novelty (T5) · failure (T7) · class-10 mismatch (R14.4) · metaplasticity (R15.5) | **reduced** (`plasticity_mult ↓`) | **shrunk** (R15.10: envelope first, `lr` optional) | continues | → NORMAL on resolution; → STALLED on B5 breach |
| **PROVISIONAL-AGED** | `PROVISIONAL_AGE_1/2` reached (R1.3) | unchanged | **LOCAL, then NONE** | continues | → rollback review at `AGE_2`; → auto-rollback at `AGE_3` |
| **STALLED** | **UDB ≥ B5** | **zero at this scope and below (R18.1)** | frozen | **halted** — **homeostasis only (R15.2)** | **probe re-anchor ONLY** |
| **FROZEN** | `learning_enabled = FALSE` (Cell §9.3: EIK/organism only) | **withdrawn** | none | **halted** | same authority that froze |

> ### **R31.1 — THE STABILITY/PLASTICITY RULE, IN FULL.**
> **Plasticity is granted by governance, reduced automatically by observation, and never increased automatically by anything.**
> **Stability is not the opposite of plasticity; it is the property that every reduction of verification produces a reduction of reach, rate or capacity — and that no reduction of verification ever produces an increase of any of them.**
> **⟹ THE INVARIANT: `d(verification) < 0 ⟹ d(plasticity) ≤ 0 ∧ d(envelope) ≤ 0 ∧ d(authority) ≤ 0`. NEVER `> 0`.**

**R31.1 is P0-04 §91's degradation-ladder principle ("no failure mode produces a warrant increase") transplanted to learning, and it is the answer to the brief's §23.** The classical stability/plasticity dilemma asks how to balance two competing goods. **V4 does not balance them. It makes one of them (plasticity) monotonically responsive to the other's (verification's) failure, in one direction only.** There is no trade-off parameter to tune, and therefore nothing for a learner to learn to tune — which is why R15.3's set-point non-learnability and R28.2's directional asymmetry are the same rule seen from two sides.

---

# 32. TIMESCALES AND LEARNING-RATE ORDERING

V3.1 §6's multi-scale plasticity implies multi-timescale plasticity; Cell §9.4's `lr[timescale]` supplies it. §32 states the contract.

| Timescale | What changes | `lr` | UDB scope | Anchor frequency | Note |
|---|---|---|---|---|---|
| **FAST** | Λ0, transient Λ1 | `lr_fast` | S1/S2 | **rarely** — fast changes are mostly `DECAYS` or short-lived | **Must not undo slow (R30.3).** |
| **MEDIUM** | Λ1 | `lr_medium` | S2/S3 | per probe cycle | The bulk of learning. |
| **SLOW** | Λ1 consolidated, Λ2 nomination | `lr_slow` | S3/S4 | **frequently relative to change rate** | Slow changes are the anchors' substrate. |
| **STRUCTURAL** | Λ3 | **n/a — not a rate** | S3/S4/S5 | **CR-B ablation, per operation** | **⟹ R32.1: Λ3 has no `lr`. Structural change is event-driven, not gradient-driven, and its "rate" is B6 (count budget), not a step size.** Applying a learning rate to topology is a category error that would let a slow gradient accumulate into an irreversible structural change without ever passing a rung (§29). |
| **META** | Λ4 | **n/a** | S5 | **meta-probe under the fixed core (R24.3)** | **⟹ R32.2: Λ4 changes are `VERSION_REVERSIBLE` governance events with an explicit version, never a gradient.** |

> ### **R32.3 — TIMESCALE ORDERING IS `lr_fast ≥ lr_medium ≥ lr_slow`, KERNEL-ENFORCED, AND THE ORDERING IS A STABILITY MECHANISM, NOT A CONVENTION.**
> If `lr_slow > lr_fast`, the slow process can outrun the fast one's ability to compensate, and the homeostatic set-point (which operates on the slow scale) cannot track the parameter it is stabilising. **The ordering is what makes B4 (homeostatic scaling) able to do its job.**
> **⟹ Corollary: `SLOW_MODE` reduces `lr` at ALL timescales together, preserving the ordering.** A `SLOW_MODE` that reduced only `lr_fast` would invert the ordering and destabilise homeostasis. **This is a concrete mis-implementation risk that R32.3's corollary closes.**

---

# 33. VOLATILITY AND NON-STATIONARITY

V3 L39 (distribution shift ⟹ novelty + slow mode + sandbox) was audited at R14.4/R14.5. §33 completes the volatility contract.

| Quantity | Measured by | Class | Response |
|---|---|---|---|
| **Environmental volatility** | P0-01 §13 class 10 (`MODEL_ENV_MISMATCH`): distribution tests over a window + drift statistics | **SC-2** (kernel-observable) | `SLOW_MODE`: envelope ↓ (mandatory), `lr` ↓ (optional, R15.10); **UDB_MAX ↓** ⟹ **R33.1** |
| **Outcome volatility** | reward `uncertainty`, `n_samples` (R12.3) | SC-3 | High uncertainty ⟹ **lower weight in `Δθ`**, via `confidence_in_error` |
| **Signal volatility** | SG-class variance over a window | SC-2 | High variance ⟹ `plasticity_mult ↓` |
| **Self-induced volatility** | **`inbreeding_F` extended to learning lineage (R15.8)** | SC-2 | **⚠️ The dangerous one — see R33.2** |

> ### **R33.1 — VOLATILITY REDUCES `UDB_MAX`, NOT ONLY `lr`.**
> A volatile environment is one in which a probe's verdict generalises poorly, so an anchor earned in it is weak. **⟹ `UDB_MAX[scope] = g(anchor_quality) × h(volatility)`, with `h` monotonically decreasing.** Combined with R9.4.2 (gamed probe ⟹ shorter leash) and R9.4.3 (stale anchor ⟹ shorter leash), **`UDB_MAX` is a function of exactly three things: scope (R18.2), anchor quality, and volatility. It is never a function of the learner's own assessment of anything.**

> ### **R33.2 — SELF-INDUCED VOLATILITY IS THE OBSERVABLE FORM OF RH-2.**
> If the organism is shaping its own evidence (OR-L6), the measured volatility of its outcomes will be **lower than the volatility of outcomes in contexts it does not control** — because it is selecting the contexts. **⟹ R33.2: a scope whose outcome volatility is significantly below the population baseline for comparable tasks, while its `behavioural_reach = ORGANISM_OUTPUTS` (RH-2-capable, §9.3 C-3), is flagged as `EVIDENCE_SELECTION_SUSPECT`.**
> **This is a detection rule, not a defence, and §86 reports it as such.** It cannot distinguish "the organism has genuinely mastered a stable task" from "the organism has arranged a stable sample." **Nothing internal can.** But it makes the second case **visible**, which is the most the architecture can do — and P0-04 §90's bounded optimism budget (C-4) then limits how far a suspect scope may act on its own favourable evidence.

---

# 34. THE FOURTH-PLANE QUESTION (§20 of brief)

> *"Does learning require a fourth communication plane, alongside TRANSPORT / WARRANT / INFLUENCE?"*

## 34.1 The case for

Learning signals travel. They have delivery semantics (P0-03 already rules them **at-least-once + idempotent, mandatory**, at warrant class S1–S2). They are neither transport (they carry no payload for a recipient's use), nor warrant (they confer no evidence status), nor influence (they are not modulated by a learned gain — **they *cause* the gain to change**). Three planes and a category that fits none of them.

## 34.2 The case against

| Objection | Weight |
|---|---|
| **P0-03 already assigned learning signals to S1–S2 warrant classes with mandatory delivery semantics.** They are *on* the WARRANT plane, as a class of message. | **Strong.** The plane exists and carries them. |
| **A fourth plane would need its own invariants, its own attack catalogue, its own contradiction audit.** P0-03's three planes generated 34 invariants and 46 attacks. A fourth plane is not a naming change. | **Strong, and it is a real cost.** |
| **§87's discipline and the audit's Rule 17: prefer the smallest sufficient mechanism.** | **Decisive.** |
| **The brief's own instruction: do not add a plane merely for elegance.** | **Decisive.** |

## 34.3 The ruling

> ### **R34.1 — NO FOURTH PLANE. LEARNING SIGNALS TRAVEL ON THE WARRANT PLANE AS A MESSAGE CLASS.**
> **But the WARRANT plane requires a sub-structure it does not have, and that is the real finding.**

P0-03's WARRANT plane classifies messages by **how much epistemic weight they confer** (S0–S4). Learning signals are S1–S2. **What the plane does not classify is what a message DOES to the recipient's state**, and for learning signals that is the whole question:

| Message effect on recipient | Plane | Existing class | **Missing distinction** |
|---|---|---|---|
| Delivers payload | TRANSPORT | — | none needed |
| Confers/attests warrant | WARRANT | S0–S4 | none needed |
| Modulates use of a warrant | INFLUENCE | gain, eligibility, routing | none needed |
| **Changes the recipient's parameters** | **WARRANT (as S1–S2)** | — | **⚠️ Λ0 vs Λ1 vs Λ3 vs Λ4 — four different authorities, four different reversibility classes, ONE delivery class** |

> ### **R34.2 — THE MISSING STRUCTURE IS NOT A PLANE; IT IS THE A1/A4 TYPING OF THE EFFECT.**
> A learning signal's message class (S1–S2) governs **delivery**. Its `signal_kind` (§19.3) governs **admissible effect** via `admissible_for` (R20.4). **Those two together are sufficient, and they are exactly the axes P0-05 introduced independently in R0.2.**
> **⟹ The answer to §20 is: learning does not need a fourth plane. It needs the `LearnedChange` object, and once that object exists the plane question dissolves — because the plane was never where the governance lived.**

**This is a satisfying result and it should be flagged as one of the few places where P0-05 *removes* rather than adds structure.** P0-03 built three planes and correctly refused a fourth. P0-05 confirms the refusal and identifies that the pressure to add a plane came from the absence of a change object, not from the absence of a channel. **The brief's §20 is answered "no", with a reason that strengthens P0-03 rather than amending it.**

> ### **R34.3 — ONE AMENDMENT TO P0-03 IS REQUIRED, AND IT IS SMALL.**
> P0-03 R3.2 fixes the learnable synapse parameter set as `weight`, `context_sensitivity`, `plasticity_rate`, `eligibility_trace` — and correctly excludes `reliability`, `trust`, `latency`. **P0-05 adds one constraint P0-03 does not state:**
> **`plasticity_rate` is an Λ4-class quantity at S1 scope.** It is a *bound on how fast the bound can change* — metaplasticity. **⟹ R34.3: `plasticity_rate` is learnable at S1 only within `[G]` bounds, and its cumulative drift consumes S1 UDB (R9.2.4).** Without this, a synapse can raise its own `plasticity_rate` monotonically, and after enough epochs its effective `lr` exceeds any bound that was ever checked — **D-L1 at S1, on the metaplasticity parameter, invisible to `Δ_MAX` because each individual step is tiny.**
> **This is a genuine gap in P0-03 that only P0-05's UDB machinery exposes.** It is logged as **X-L5** (§74) and is the one place where P0-05 amends a prior contract rather than inheriting it.

---

# 35. VOLUME B — FINDINGS REGISTER

| ID | Finding | Severity | Disposition |
|---|---|---|---|
| **D-L15** | **T8 (recalibration) writes the gain on every other trigger** via `confidence_in_error`, and consumes no UDB. Unverified calibration inflation = unbounded `lr` increase with no `Δθ` in the audit trail. | **CRITICAL** | **CLOSED by R23.2** (T8 consumes UDB, requires probe). |
| **D-L16** | **T3 (correction) has no difficulty control and no probe-independence requirement.** A learner can be verified on material it was taught. | **HIGH** | **CLOSED by R9.2.2 + R23.1 + R22.2.** |
| **D-L17** | **T4's guard detects self-reward but not self-confirmation.** Model collapse passes T4. | **HIGH** | **BOUNDED by R0.1** (collapse is drift). **§48.** Not closed by a new mechanism — deliberately. |
| **D-L18** | **Plasticity capacity is governed by one rule.** No matrix, no grant/reduce/withdraw protocol, no ∅-cells. | **HIGH** | **CLOSED by §28 (R28.1, R28.2) + §29.** |
| **D-L19** | **No escalation ladder exists**, because reversibility was never a property of a change. | **HIGH** | **CLOSED by §29 (E0–E9, R29.1–R29.4).** |
| **D-L20** | **`plasticity_rate` at S1 is learnable with no cumulative bound** (metaplasticity ratchet). | **HIGH** | **CLOSED by R34.3. Logged X-L5 — P0-05 amends P0-03.** |
| **D-L21** | **F-4 pruning has no tombstone**, so the lineage of every change touching a pruned connection becomes unverifiable retroactively. | **HIGH** | **CLOSED by R27.2 + R27.5.** |
| **D-L22** | **Forgetting can evade UDB** by deleting the carrier of displacement. | **HIGH** | **CLOSED by R15.4 + R27.4 + R27.5.** ⟹ **Conservation of unverified displacement** (§27.2). |
| **D-L23** | **`param_init` spread narrowing is covert Lamarckism** (BF-1). | **HIGH** | **CLOSED by R25.2** (spread floor + per-generation bound). |
| **D-L24** | **Baldwinian priors can initialise belief**, importing parental warrant (BF-2). | **HIGH** | **CLOSED by R25.3** (prior biases θ, never belief). |
| **D-L25** | **Baldwinian ratchet via selection** (BF-3) converges population priors on ancestral acquired state. | **MEDIUM — INHERENT** | **BOUNDED by R25.4** (mandatory diversity check). **Not closed: closing it would prohibit evolution. §86 EVOLUTION status.** |
| **D-L26** | **V3.1 §7's learning-rule variation lets a genome-diff alter the instrument that verifies the next diff.** | **CRITICAL — UNCLOSED** | **CONTAINED by R24.3's FIXED VALIDATION CORE.** Registered **OR-L2**. |
| **D-L27** | **Learning signals are aggregated by count in the inherited reading** of "independent internal reward." | **MEDIUM** | **CLOSED by R22.1** (dedup, not aggregate) — **and the premise is inadmissible anyway (R8.1).** |
| **D-L28** | **A composite structural operation obtains authority by adjacency.** | **HIGH** | **CLOSED by R29.3** (decomposition; authority = max, verification = conjunction). |
| **D-L29** | **`SLOW_MODE` reducing only `lr_fast` inverts the timescale ordering and destabilises homeostasis.** | **MEDIUM** | **CLOSED by R32.3 corollary.** |
| **D-L30** | **Self-induced volatility is invisible**, so RH-2's evidence selection cannot be detected. | **HIGH — UNCLOSED** | **OBSERVABLE via R33.2 (`EVIDENCE_SELECTION_SUSPECT`). Detection, not defence. OR-L6.** |
| **X-L5** | P0-03 R3.2 lists `plasticity_rate` as learnable at synapse level with no cumulative-drift bound. | **LIVE — P0-05 AMENDS P0-03** | **R34.3.** |
| **OR-L2, OR-L6** | Meta-probe circularity; evaluator manipulation. | **OPEN RESEARCH** | **§81.** |

---

**END OF VOLUME B.**
**Next:** `42_analysis_exploration_knowledge.md` — Vol C (§35–§52): local vs global learning (**[O16]**, and the proof that R0.1's scoped UDB defeats the O(N²) global learner), exploration/exploitation (**[O24]**), safe exploration (**[O25]**), meta-learning (**[O38]**), failure learning (**[O26]**), the abstention cascade (**[O27]**), memory↔plasticity (**[O28]**), simulation (**[O40]**), transfer (**[O41]**), specialisation & diversity (**[O42]**), self-training & model collapse (**[O39]**), offline/replay learning.
