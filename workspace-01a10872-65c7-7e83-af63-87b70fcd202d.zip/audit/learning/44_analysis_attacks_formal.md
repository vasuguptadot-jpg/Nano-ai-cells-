# P0-05 — LEARNING, PLASTICITY & ADAPTATION CONTRACT
## Volume E — Adversarial Catalogue, Invariants, State Machines, Parameters (§67–§72)

**Status:** adversarial architecture audit. **Architecture only.** No implementation, no numerical parameter values.
**Method (§87: *be adversarial*):** every attack is stated as an adversary would state it, then disposed. Dispositions are **CLOSED** (a rule prevents it), **CLOSED-STRUCTURAL** (no object exists to attack), **BOUNDED** (rate/extent limited, not prevented), **DETECTABLE** (observable, not prevented), **CONDITIONAL** (closed only if a named condition holds), **OPEN** (unclosed, registered in §81).

> **Outputs discharged:** O45 (60+ adversarial attacks), O46 (`LEARN-INV` invariants), O47 (formal state machines), O48 (parameter registry), O49 (parameter dependency), O56 (implementation independence).

---

# 67. **[O45] THE ADVERSARIAL CATALOGUE — 70 ATTACKS IN 8 GROUPS

**Adversary model.** The adversary is **the organism itself** — a component, a scope, a circuit, or a colluding set of scopes — with full knowledge of every rule in this contract and full control of its own internal state, its own outputs, its own proposals and its own signal generation. It does **not** control: K, EVA, `[RO-13]`, KC, the fixed validation core, or the physical world outside its own effects. **It is assumed to be patient, to prefer many small compliant steps to one large violating step, and to treat every `[G]` bound as a target to approach rather than a limit to respect.**

**Disposition counts are stated per group and reconciled in §67.9.**

## 67.1 GROUP A — AUTHORITY AND SELF-AUTHORISATION (LEARN-A1 … A10)

| ID | **Attack** | **Defence** | **Disposition** |
|---|---|---|---|
| **LEARN-A1** | **Ungoverned change.** Modify θ with no `trigger`, no `LearnedChange` record. | R23.3 (closed enum, kernel-checked) + R23.4 (Λ0 persistence past horizon ⟹ reclassified) ⟹ RB-3 rollback + freeze + finding | **CLOSED** |
| **LEARN-A2** | **Self-authorisation.** Declare `authorized_by = ORGANISM` on an S2 change. | R20.2 (class derived, never declared) + R28.1's matrix (S2 may write Λ0/Λ1 only) + `authorization_ref` signature mandatory for A2 ≥ ORGANISM (§1.1) | **CLOSED** |
| **LEARN-A3** | **Self-anchoring.** Set `anchored_at` to the current state so UDB resets. | R0.1 (`θ_anchor` requires `IMPROVED`/`NEUTRAL` from a `probe_ref`) + R62.3 (a checkpoint is a *candidate*, not an anchor) + `verdict` K-only | **CLOSED-STRUCTURAL** — no self-anchor object exists |
| **LEARN-A4** | **Genome reset as anchor.** Re-read `param_init` to re-initialise, evading UDB. | R26.1 (genome read-once per instantiation; re-read is an Λ4 governance action) + R0.1 (an anchor requires a `probe_ref`; the genome has none) | **CLOSED** |
| **LEARN-A5** | **Scope elevation.** Apply an S1-authorised change at S3. | R4.3 (authority monotone in scope; a component may not authorise above its scope) + R20.4 (`admissible_for` kernel-set from class) | **CLOSED** |
| **LEARN-A6** | **Authority by adjacency.** Obtain a composite authorisation covering E0+E3 because most of the composite is E0. | R4.1 (class disjointness) + R29.3 (mandatory decomposition; authority = **max** of rungs, verification = **conjunction**) + R61.1 (V3 L54's five operations are three rungs) | **CLOSED-STRUCTURAL** — no composite authorisation exists |
| **LEARN-A7** | **Self-granted plasticity.** Raise `plasticity_mult` on observing its own poor performance. | Cell §4.1.8 (`plasticity_mult` K-only) + **R28.2 (reduction is automatic and permissionless; increase is never automatic)** + R31.1 (`d(verification)<0 ⟹ d(plasticity) ≤ 0`) | **CLOSED** |
| **LEARN-A8** | **Governance write.** Modify the matrix, the ladder, `UDB_MAX`, `F`, an invariant, or the fixed core. | R19.2 (governance changes capacity, learning changes state, **no shared write path**) + R24.2 (machine-checkable rejection list, extended) + R24.3/M3 (∅ for the fixed core) + R54.1 | **CLOSED-STRUCTURAL** — the learning subsystem holds no capability |
| **LEARN-A9** | **Envelope evasion.** Declare `behavioural_reach = NONE` while acting with full reach; or claim "this is exploration" to exceed the envelope. | §1.1 (envelope **declared at admission, verified by observation**) + R36.2 (exploration operates *under* the envelope) + R37.1 (exploration may not be irreversible) + R33.2/R53.4 (`SUSPECT` findings on reach vs. effect mismatch) | **CONDITIONAL** — closed for declared-vs-observed mismatch; **the declaration itself is only as good as §63's observation of reach. Residual: a change whose reach is genuinely `LOCAL` but whose *aggregate* effect over many changes is `ORGANISM_OUTPUTS`.** ⟹ **R67.1: `behavioural_reach` is aggregated per scope over a window, not per change.** |
| **LEARN-A10** | **Self-granted exploration budget.** Extend or renew B8 after exhausting it. | R36.3 (no self-grant, self-extension or self-renewal) + R30.2 (budgets non-transferable, use-it-or-lose-it) + R47.2 (allocation not learnable) | **CLOSED** |

**Group A: 9 closed-family (6 CLOSED + 3 CLOSED-STRUCTURAL), 1 CONDITIONAL, 0 BOUNDED, 0 OPEN.** *(A9 becomes CLOSED under R67.1; recorded CONDITIONAL because R67.1 is derived here.)*

## 67.2 GROUP B — SIGNAL FORGERY AND PROVENANCE (LEARN-B1 … B10)

| ID | **Attack** | **Defence** | **Disposition** |
|---|---|---|---|
| **LEARN-B1** | **Reward forgery.** Sign a reward message as a cell. | **R12.1** — a cell signature on a reward is *structurally invalid* (I-class). `source = EVA_ONLY`, one value. | **CLOSED-STRUCTURAL** |
| **LEARN-B2** | **Class escalation.** Declare an SC-1 estimate as SC-3. | **R20.2** — `class` derived by K from `origin` + `signature` + `gt_refs` | **CLOSED** |
| **LEARN-B3** | **Provenance stripping.** Send a signal with no `inputs`/`gt_refs`, so it cannot be audited. | **R20.3** (mandatory `inputs` for derived signals) + **R12.3** (mandatory `gt_refs` for reward) ⟹ absence makes it **SC-0** | **CLOSED** |
| **LEARN-B4** | **Signal replay.** Re-deliver an old valid signal. | `epoch` binding (**EIK-INV-14**) + `idempotency_key` (P0-03) | **CLOSED** |
| **LEARN-B5** | **Signal duplication.** Deliver the same signal *n* times to multiply its weight. | **R22.1** — signals are **deduplicated by key, not aggregated by count**; `effect(signals) = effect(dedup(signals))`; no `n` term in `Δθ` | **CLOSED-STRUCTURAL** — no aggregation object exists |
| **LEARN-B6** | **Consensus minting.** Coordinate ten cells to emit the same SC-1 estimate, claiming ten independent signals. | **R22.1** + premise inadmissible (**R8.1**: no cell may generate a reward) + Cell §11.5's ρ-discount (identically-trained cells ⟹ ρ→1 ⟹ `n_effective`→1) | **CLOSED** |
| **LEARN-B7** | **Provenance editing.** Modify a consumed signal's `class`, `origin` or `gt_refs` after the fact. | **R20.5** — provenance immutable under learning; **R54.1** — learning consumes provenance, never produces or edits it | **CLOSED** |
| **LEARN-B8** | **Peer-report laundering.** Use a peer's `REPORT_ERROR` as a direct `Δθ` trigger. | **R19.3** — a peer report may cause the recipient to *register a prediction*; only the resolving observation causes learning. Cell §10.3. P0-01 §13.2 (`PEER_REPORT` = hypothesis). | **CLOSED** |
| **LEARN-B9** | **New signal kind.** Define a 15th `signal_kind`, or an emergent protocol that carries one. | **R23.3** (closed enum) + **R53.9** (an emergent protocol may not define a `signal_kind`) + P0-03's prohibition on emergent protocols bypassing governance | **CLOSED-STRUCTURAL** |
| **LEARN-B10** | **Retrieval-as-signal.** Use a retrieved memory of a past reward as a T2 trigger; or use a retrieved belief as a T1 trigger. | **R11.1** (`RECALL ∉ T2 sources`) + **R41.1** (a retrieved memory may cause a *prediction*, never a `Δθ`) | **CLOSED** |

**Group B: 10 closed-family (7 CLOSED + 3 CLOSED-STRUCTURAL).**

## 67.3 GROUP C — REWARD HACKING (LEARN-C1 … C10)

*(§9 of Vol A established the RH taxonomy; §67.3 restates it as attacks, adds the residual ones, and reconciles the two numbering systems: **RH-n ⟷ LEARN-Cn** as marked.)*

| ID | **Attack** | **RH ref** | **Defence** | **Disposition** |
|---|---|---|---|---|
| **LEARN-C1** | **Proxy optimisation.** Maximise the measured component; ignore the objective. | RH-1 | R12.4 (DENSE prohibited) + R12.3 (`evidence: [gt_id]` mandatory) + R8.1 (RW-5 ∅) | **BOUNDED** — a referenced proxy is still a proxy |
| **LEARN-C2** | **Evaluator manipulation via behaviour.** Produce outputs that make the evaluator's ground truth favourable. | **RH-2** | §9.3 C-1…C-4, §56.2's ten containments | **OPEN — OR-L6.** The binding limit. |
| **LEARN-C3** | **Evaluator manipulation via routing.** Learn a `routing_preference` that selects permissive evaluators. | RH-2 variant | **R53.3** (learning signals and probe inputs are governance-routed) + **R53.4** (`EVALUATOR_SELECTION_SUSPECT`) | **CONDITIONAL** — closed for learning signals/probe inputs; **OPEN for ordinary messages ⟹ OR-L7** |
| **LEARN-C4** | **Credit forgery.** Transmit `credit`/`contribution`/`reward_share`/`utility`/`expected_utility`. | RH-3 | **COMM-INV-20/28** — forbidden fields | **CLOSED-STRUCTURAL** |
| **LEARN-C5** | **Trace manipulation.** Alter eligibility traces so credit lands on chosen actions. | RH-4 | COMM-INV-20 (credit computed, never transmitted) + traces local, λ-decayed, **not causal claims** + **R6.5.1** (a Λ3 change invalidates traces, so structure cannot launder a trace) | **CLOSED-STRUCTURAL** |
| **LEARN-C6** | **Self-generated reward.** Mint an intrinsic/curiosity reward. | RH-5 | **R12.1** (type-level) + **R8.1** (RW-6, RW-8 ∅) + Cell §9.6 (K-only verdict) | **CLOSED-STRUCTURAL** |
| **LEARN-C7** | **Peer-laundered reward.** Get peers to assess you; use it as reward or as fitness. | RH-6 | **R8.1** (RW-7 ∅ as a learning signal) + P0-01 §13.2 (`PEER_REPORT` = hypothesis) + **R10.3.2** (`cooperation` enters fitness only via measured transport conformance) | **CLOSED for learning; CONDITIONAL for fitness** — resolved by R10.3.2 ⟹ **CLOSED** |
| **LEARN-C8** | **Constraint shopping.** Operate where RW-2 constraints are not evaluated. | RH-C1 | Cell §9.5's `utility_basis` (basis change detectable) + **R9.2.1** (constraint coverage is observable; a scope with zero constraint evaluations is a *finding*, not a silence) | **BOUNDED** |
| **LEARN-C9** | **Correction capture.** Provoke RW-3 corrections on easy cases to build apparent competence. | RH-C2 | **R9.2.2** (`difficulty_class` + per-scope rate) + **R23.1** (T3-driven changes may re-anchor only on a probe excluding all T3 corrections) + R22.2 (probe inputs must not overlap driving signals) | **CLOSED** |
| **LEARN-C10** | **Preference inflation.** Present RW-4 comparisons you are certain to win. | RH-C3 | **R8.2 corollary** (RW-4 is ranking-only, never a gradient ⟹ no `Δθ`) + **R9.2.3** (a ranking may not be a fitness input without a difficulty-controlled sample) | **CLOSED** |

**Group C: 6 CLOSED/CLOSED-STRUCTURAL, 2 BOUNDED, 1 CONDITIONAL(→OR-L7), 1 OPEN.**

## 67.4 GROUP D — DRIFT, BUDGET AND STALL EVASION (LEARN-D1 … D10)

| ID | **Attack** | **Defence** | **Disposition** |
|---|---|---|---|
| **LEARN-D1** | **Death by a thousand provisional cuts.** Spend `DELTA_BUDGET` every epoch, never get probed, migrate arbitrarily far. *(This is D-L1 itself.)* | **R0.1 (UDB)** — B5 does not reset per epoch; exhaustion ⟹ **STALL** | **CLOSED** |
| **LEARN-D2** | **Displacement off θ.** Accumulate change at Λ2 (representation) or Λ3 (structure), which does not move θ and so does not consume UDB. | **R9.2.4** — UDB is computed per scope over **all admissible targets**, not θ alone + **R61.2** (B6 is a separate structural count/blast-radius budget) | **CLOSED** |
| **LEARN-D3** | **Displacement off the parameters.** Raise `plasticity_rate` (S1 metaplasticity) monotonically in tiny steps, so effective `lr` exceeds any bound ever checked. | **R34.3 / X-L5** — `plasticity_rate` drift consumes S1 UDB within `[G]` bounds | **CLOSED** *(amends P0-03)* |
| **LEARN-D4** | **Gain inflation via calibration.** Drive T8 to raise `confidence_in_error` systematically, increasing the gain on every subsequent update with no `Δθ` in the trail. | **R23.2** — T8 consumes UDB at its scope and requires probe verification | **CLOSED** |
| **LEARN-D5** | **Decay as evasion.** Let θ decay toward zero to reduce `‖θ − θ_anchor‖`. | **R15.4** — decay is accounted in UDB; a forgotten state is a displaced state | **CLOSED** |
| **LEARN-D6** | **Deletion as evasion.** Prune the connections carrying unverified displacement. | **R27.5** — F-4 consumes UDB and the tombstone's `final_weight_digest` enters the anchor computation | **CLOSED** |
| **LEARN-D7** | **Forgetting as evidence-hiding.** F-3-forget the records a probe would contradict. | **R27.4 + R41.4** — probes may read archived records; forgetting reduces *retrievability*, never *availability to verification*, and the probe does not use the retrieval path | **CLOSED-STRUCTURAL** |
| **LEARN-D8** | **Budget banking.** Accumulate unused B2/B6/B8 and spend it in one burst. | **R30.2** — non-transferable, use-it-or-lose-it within the reset interval; **no component may accumulate, bank, borrow or lend** | **CLOSED-STRUCTURAL** |
| **LEARN-D9** | **Cross-scope budget arbitrage.** Move budget from a slack scope to a constrained one. | **R30.2** + **R47.2** (allocation is `[RO-13]`) | **CLOSED** |
| **LEARN-D10** | **Stall evasion by scope-hopping.** Make the change at a different scope than the one that is stalled. | **R18.1** — stall propagates **downward**; a stalled S3 halts S2 writes to S3 targets. **⟹ R67.2: a stall at S also halts writes at any S' ⊂ S to any target that S authorised or that lies within S's blast radius.** | **CONDITIONAL** — closed for contained targets; **residual: a genuinely disjoint target at a lower scope is writable, which is correct (it is not the stalled thing). Recorded CONDITIONAL for honesty.** |

**Group D: 9 closed-family (7 CLOSED + 2 CLOSED-STRUCTURAL), 1 CONDITIONAL.**

## 67.5 GROUP E — VERIFICATION AND PROBE ATTACKS (LEARN-E1 … E8)

| ID | **Attack** | **Defence** | **Disposition** |
|---|---|---|---|
| **LEARN-E1** | **Probe gaming by timing.** Behave well during probes, badly between them. | **R9.4.1 — the probe schedule is `[RO-13]`/K-owned and NOT readable by the learning subsystem.** *"Held-out" must cover timing, not only data.* | **BOUNDED** — defeats timed gaming; cannot defeat behavioural difference under *any* observation (that is C2's residual) |
| **LEARN-E2** | **Probe gaming by input selection.** Arrange to be probed on favourable inputs. | **C-1** (probe input distribution `[RO-13]`-owned) + **C-2** (cross-scope probe where possible) + **R45.1** (curriculum ordering may not affect the probe distribution) | **BOUNDED** — at S5, C-2 is unavailable (R18.2) |
| **LEARN-E3** | **Anchor laundering.** Earn a cheap anchor to reset UDB, then drift. | **R9.4.2** — `UDB_MAX = g(anchor_quality)`: **a gamed probe buys a shorter leash.** The attack is self-limiting. | **BOUNDED** |
| **LEARN-E4** | **Anchor staleness exploitation.** Verified once, drift forever. | **R9.4.3** — `UDB_MAX` decays with anchor age; **R33.1** — decays with volatility too | **CLOSED** |
| **LEARN-E5** | **Simulated probe.** Verify yourself with your own model's simulation. | **R42.3** — a simulated probe is not a probe; `improvement_verified` requires an external held-out probe (Cell §9.6, P0-01 §13 class 9) | **CLOSED-STRUCTURAL** |
| **LEARN-E6** | **Probe-input contamination.** Get probed on material you were taught (T3) or on signal lineage you already consumed. | **R23.1** (T3-driven changes re-anchor only on a probe excluding all T3 corrections) + **R22.2** (`probe_inputs ∩ driving_signals ≠ ∅ ⟹ verdict downgraded to NEUTRAL at best`) | **CLOSED** |
| **LEARN-E7** | **Self-assessed improvement.** Write your own `verdict`. | Cell §9.6 (`improvement_verified` K-only) + **R20.2** + §1.1 (`probe_ref = NULL ⟹ verdict = UNKNOWN` by implication) + **R54.2** (the change may not edit its own audit fields) | **CLOSED-STRUCTURAL** |
| **LEARN-E8** | **Exploration-earned anchor.** Use an exploration grant's outcomes as a probe. | **R37.3** — an anchor may not be earned from a probe conducted within an exploration grant | **CLOSED** |

**Group E: 5 closed-family (3 CLOSED + 2 CLOSED-STRUCTURAL), 3 BOUNDED.**

## 67.6 GROUP F — STRUCTURAL AND IRREVERSIBLE ATTACKS (LEARN-F1 … F8)

| ID | **Attack** | **Defence** | **Disposition** |
|---|---|---|---|
| **LEARN-F1** | **Silent deletion by gradient.** Decay a weight to zero over many epochs until the connection is functionally gone, without an E3 authorisation. | **R61.3** — Λ3 is **event-driven with no learning rate and no gradient**. Weight decay to zero is E0/Λ1; connection removal is E3/Λ3 requiring `ORGANISM` + CR-B + tombstone. **The two are unreachable by the same mechanism.** | **CLOSED-STRUCTURAL** |
| **LEARN-F2** | **Pruning by disuse.** Prune connections that are unused because they are *unreachable*, baking a retrieval artefact into topology irreversibly. | **R27.3** (`disuse_cause = IRRELEVANT` mandatory; `UNREACHABLE`/`UNKNOWN` insufficient) + **R6.4.2** (CR-B ablation mandatory at E3) + **R63.3** (`DISUSE_PRUNING_SUSPECT` detector) | **CLOSED** |
| **LEARN-F3** | **Self-removal.** A synapse prunes itself. | **R28.2 fact #6** — S1 may not create or remove itself; topology change is authorised from *above* the topology changed (same principle as R15.7's off-cell gain and Cell §9.6's K-only verdict) | **CLOSED-STRUCTURAL** |
| **LEARN-F4** | **Uncheckpointed structural change.** Perform E6/E7 with no preceding checkpoint, making it irreversible *and* unrecoverable. | **R62.7** — an E6/E7 operation MUST be preceded by a checkpoint at its scope; uncheckpointed ⟹ inadmissible | **CLOSED** |
| **LEARN-F5** | **Anchor invalidation by stealth.** Make a structural change that silently un-verifies lower-scope parameter learning. | **R51.2** — an E1+ rung MUST declare the scopes whose traces and anchors it invalidates; invalidating a lower anchor forces re-probe. **R6.5.1** (trace invalidation). | **CLOSED** |
| **LEARN-F6** | **Tombstone omission.** Prune without a tombstone, destroying the audit trail of every change that touched the connection. | **R27.2** — an F-4 without a tombstone is inadmissible; **R64.6** — a corrupted tombstone triggers scope freeze | **CLOSED** |
| **LEARN-F7** | **Structural budget fragmentation.** Make unlimited tiny structural changes, each individually negligible, accumulating into total topology replacement. | **R61.2** — B6 is a **count and a blast-radius bound**, not a magnitude; **R29.3** (decomposition; authority = max of rungs) | **CLOSED** |
| **LEARN-F8** | **Retirement without causality.** Retire a component (E5) on an internal estimate. | P0-01 §13.2 (internal estimates may not trigger retirement, only quarantine *investigation*) + §29 E5 (`ORGANISM` + CR-B + full lineage audit) + **R57.5** | **CLOSED** |

**Group F: 8 closed-family (6 CLOSED + 2 CLOSED-STRUCTURAL).**

## 67.7 GROUP G — CASCADE AND STARVATION ATTACKS (LEARN-G1 … G8)

| ID | **Attack** | **Defence** | **Disposition** |
|---|---|---|---|
| **LEARN-G1** | **Abstention cascade.** Abstain ⟹ no output ⟹ no evaluation ⟹ no warrant ⟹ abstain more. *(P0-04 L-11, arriving in the learning system.)* | **R40.2** (counter) + **R40.3** (bounded exposure obligation) + **R40.4** (abstention MUST NOT reduce `plasticity_mult`, MUST NOT count as T7) + **R40.5** (consumes no UDB) | **BOUNDED** — OR-L5: the architecture can learn that engagement is survivable; it cannot learn that abstention was correct |
| **LEARN-G2** | **Failure→avoidance.** Fail ⟹ avoid ⟹ no corrective evidence ⟹ model degrades ⟹ fail. | **R39.2** (damp → diagnose → escalate, in fixed order) + **R39.3** (unclassified failure ⟹ finding, not `Δθ`) + **R63.3** (`AVOIDANCE_CASCADE`) | **BOUNDED** |
| **LEARN-G3** | **Quarantine cascade.** False threat ⟹ immune learning ⟹ quarantine ⟹ reduced exposure ⟹ no correction ⟹ stronger false threat model. | **R57.1–R57.6**, principally **R57.3** (mandatory re-exposure obligation) and **R57.4** (quarantine reduces *envelope*, never *capacity*) + **R57.6** (counter) | **BOUNDED** — residual: the re-exposure rate is `[G]` with no value |
| **LEARN-G4** | **Specialisation narrowing.** Specialise ⟹ narrow inputs ⟹ accurate in-distribution ⟹ never tested out-of-distribution. | **R46.1** (specialisation is E4/E7, not writable by demand) + **R46.2** (mandatory de-specialisation path) + **R46.4** (diversity as a **hard constraint**, not a score term) + §46.4 (specialisation counted as filtering via `context_class`) | **BOUNDED** |
| **LEARN-G5** | **Exploration starvation.** Low B8 ⟹ no EX-1 ⟹ no resolved predictions ⟹ no anchor ⟹ stall ⟹ low throughput ⟹ weaker case for B8. | **R36.4** (exploration measured by resolved predictions) + **R63.3** (`EXPLORATION_STARVATION`) + **R10.3.1** (`adaptability` = verified learning throughput, making the starvation visible as a fitness-relevant quantity) | **BOUNDED** |
| **LEARN-G6** | **Workspace homogenisation.** Learn a broadcast preference that selects confirming content ⟹ all scopes condition on it ⟹ population signals correlate. | **R60.4** (`workspace_diversity` counter) + **R60.5** (`[G]`-reserved governance slots the learned preference does not control) + **R60.6** (per-scope fraction cap) | **BOUNDED** |
| **LEARN-G7** | **Availability capture via learning.** Learn retrieval weights that concentrate on already-available records. | **R41.2** (the X-L1 split: `θ_recall` is cell-plastic only for the cell's *own* store; cross-store retrieval policy is `[RO-13]`) + P0-04 §26.3 + **R63.3** (`AVAILABILITY_CAPTURE`) | **CONDITIONAL** — closed pending ratification of X-L1's proposed resolution (§74) |
| **LEARN-G8** | **Model collapse.** Self-train until output dispersion degenerates. | **R48.1** (self-generated data is SC-1, provisional only) + **R48.2** (**bounded by R0.1 with no new mechanism** — collapse is unverified displacement) + **R48.3/R48.4** (`output_dispersion` counter; `UDB_EXHAUSTED_SC1_HEAVY` stall reason) | **CLOSED** — the strongest single validation of R0.1 as a primitive |

**Group G: 1 CLOSED, 1 CONDITIONAL, 6 BOUNDED.**

## 67.8 GROUP H — INHERITANCE AND EVOLUTION ATTACKS (LEARN-H1 … H6)

| ID | **Attack** | **Defence** | **Disposition** |
|---|---|---|---|
| **LEARN-H1** | **Lamarckian write.** Install a learned θ value into the genome. | §1.2's **three layers**: type (`Λ5 ∉ target.enum`) + writer (genome has one writer class; the learning subsystem holds no capability) + pathway (CH-3 only, gated). Cell §3.4, MEM-INV-18/21, P0-04 R47.1. | **CLOSED-STRUCTURAL** |
| **LEARN-H2** | **Covert Lamarckism by spread narrowing.** Propose `param_init` with vanishing variance; in the limit a zero-variance distribution *is* a learned value. | **R25.2** — proposals MUST carry non-zero spread, and spread MUST NOT decrease below the parent's by more than a `[G]`-bounded factor per generation. **A monotone-narrowing ratchet is D-L1 on the inheritance channel.** | **CLOSED** |
| **LEARN-H3** | **Prior-as-evidence.** Initialise offspring belief from the prior's location, importing parental warrant. | **R25.3** — a prior biases θ, never belief; **OR-M12** (priors carry no `source_class`); belief starts at the floor and is earned by the offspring's own external gates | **CLOSED** |
| **LEARN-H4** | **Governance diff.** Propose a genome-diff that alters `F`, the matrix, the ladder, `UDB_MAX`, or an invariant. | **R24.2** — the rejection list, extended with four entries the Cell Contract does not name (governance functions, matrix, ladder, `UDB_MAX`); machine-checkable (Cell §3.5) | **CLOSED-STRUCTURAL** |
| **LEARN-H5** | **Validator capture.** Propose a learning-rule diff (V3.1 §7) that alters the instrument verifying the next diff. | **R24.3** — a **FIXED, NON-EMPTY, `[RO-13]`/KC-OWNED VALIDATION CORE** outside the evolvable set + all 11 gates + a meta-probe + rate limit (one diff per lineage per `[G]` interval) + **R38.4** (probe criteria are part of the core) | **CONDITIONAL** — containment, not closure. **The core's contents are a governance decision P0-05 cannot make. OR-L2.** |
| **LEARN-H6** | **Baldwinian ratchet.** Let selection converge population priors on the ancestors' acquired state — Lamarckism by selection rather than by write. | **R25.4** — V3.1 §9's `DIVERSITY CHECK` is **mandatory** on any selection over `param_init`, with per-dimension `[G]` floors and **hard-constraint** enforcement (R46.4) | **BOUNDED — INHERENT.** Closing it fully would prohibit evolution. **§86 EVOLUTION status.** |

**Group H: 4 closed-family (2 CLOSED + 2 CLOSED-STRUCTURAL), 1 CONDITIONAL, 1 BOUNDED.**

## 67.9 DISPOSITION RECONCILIATION (machine-recounted)

| Group | Attacks | CLOSED | CLOSED-STRUCTURAL | CONDITIONAL | BOUNDED | OPEN |
|---|---|---|---|---|---|---|
| **A** — authority | 10 | 6 | 3 | 1 | 0 | 0 |
| **B** — signals | 10 | 7 | 3 | 0 | 0 | 0 |
| **C** — reward hacking | 10 | 3 | 3 | 1 | 2 | **1** |
| **D** — drift/budget | 10 | 7 | 2 | 1 | 0 | 0 |
| **E** — verification | 8 | 3 | 2 | 0 | 3 | 0 |
| **F** — structural | 8 | 6 | 2 | 0 | 0 | 0 |
| **G** — cascades | 8 | 1 | 0 | 1 | 6 | 0 |
| **H** — inheritance | 6 | 2 | 2 | 1 | 1 | 0 |
| **TOTAL** | **70** | **35** | **17** | **5** | **12** | **1** |

**Reconciliation: 35 + 17 + 5 + 12 + 1 = 70 ✓** — i.e. **52 closed-family (17 of them structural), 5 conditional, 12 bounded, 1 open.**

> **Note on the 17 CLOSED-STRUCTURAL entries.** These are attacks for which **no object exists to attack**: no `Λ5` enum value (H1) · no composite authorization (A6) · no self-anchor (A3) · no governance write capability (A8) · no cell-signable reward (B1) · no signal aggregation (B5) · no fifteenth signal kind (B9) · no `credit`/`utility` field (C4) · no transmitted trace to alter (C5) · no self-minted reward (C6) · no retrieval-as-trigger path (D7) · no bankable budget (D8) · no simulated probe (E5) · no self-writable verdict (E7) · no structural learning rate (F1) · no self-removing synapse (F3) · no governance diff (H4). **A rule can be violated; an absent object cannot be constructed.** This is the most efficient defensive technique in the contract and the reason §70.8 exists as a section.

> **Note on the zero DETECTABLE count.** Several defences in Volumes A–D were introduced as *detection only* — R33.2 (`EVIDENCE_SELECTION_SUSPECT`), R53.4 (`EVALUATOR_SELECTION_SUSPECT`), R42.5 (`self_model_version` correlation), R48.3 (`MODEL_COLLAPSE_SUSPECT`), R65.2 (findings carry their origin's signal-class histogram). **None is the sole defence for any attack in this catalogue**: each is paired with a bounding rule (C-1…C-4, R53.3, R48.2, R38.2). **⟹ The catalogue reports no attack as merely DETECTABLE, and the detection rules are recorded as *augmentations* of bounded or conditional defences rather than as defences in their own right.** This is deliberate: **§87 requires that unresolved problems not be hidden, and labelling an attack "detectable" is the most common way of hiding one.**

> **Note on the single OPEN attack.** **LEARN-C2 / RH-2 / OR-L6 is the only attack in seventy that is neither closed, bounded nor conditional.** It is unclosable because it is not a defect of the reward function, the signal regime, the probe design or the governance separation — it is the fact that **an organism is causally upstream of its own evidence, and learning is the mechanism by which it moves further upstream.** Ten containment mechanisms are directed at it (§56.2 of Vol D). **§86 reports SECURITY, EVOLUTION and OPEN-RESEARCH status against this single entry.**

---

# 68. **[O46] THE `LEARN-INV` INVARIANT SET — 42 INVARIANTS IN 7 GROUPS

**Notation.** Each invariant is `LEARN-INV-n (tags) — statement`, where tags ⊆ {**W** write-path, **S** structural, **C** causal/accounting, **X** exclusion, **G** governance, **E** epistemic, **T** temporal}. "Kernel-checked" means violation ⟹ RB-3 (rollback + freeze + finding) per R62.2.

## Group I — The change object (LEARN-INV-01 … 07)

**LEARN-INV-01** *(W, S)* — **Every persistent modification is a `LearnedChange`.**
`∀ Δ applied to θ ∨ weights ∨ topology ∨ representation ∨ policy: ∃ change: LearnedChange ∧ change.target = Δ.target ∧ change.delta = Δ`. **A state modification with no corresponding record is an ungoverned learning event.** Kernel-checked. *(R0.2, R23.3.)*

**LEARN-INV-02** *(W, X)* — **`Λ5_GENOME` has no write path.**
`¬∃ change: change.target = Λ5`. Enforced at three layers: type (∉ enum), capability (absent), pathway (CH-3 only). *(§1.2, R24.1, LEARN-H1.)*

**LEARN-INV-03** *(W, S)* — **A change has exactly one target class.**
`∀ change: |{Λ ∈ change.target}| = 1`. Composites MUST decompose. *(R4.1, R29.3, LEARN-A6.)*

**LEARN-INV-04** *(W, S)* — **A rollback handle exists iff the change is not irreversible.**
`∀ change: change.reversibility ≠ IRREVERSIBLE_STRUCTURAL ⟹ change.rollback_handle ≠ NULL`. A change without a handle that claims reversibility is rejected at admission. *(§1.1, R0.3.)*

**LEARN-INV-05** *(W, C)* — **An anchor requires a probe.**
`∀ change: change.anchored_at ≠ NULL ⟹ change.probe_ref ≠ NULL ∧ change.verdict ∈ {IMPROVED, NEUTRAL}`. **`probe_ref = NULL ⟹ verdict = UNKNOWN`**, by implication, with no code path producing a verdict without a probe. *(§1.1, R0.1, R62.3, LEARN-A3, LEARN-E7.)*

**LEARN-INV-06** *(W, C)* — **`cumulative_udb` is kernel-computed.**
`¬∃ component: component writes cumulative_udb`. A self-reported UDB is a self-assessed improvement in disguise. *(§1.1, R52.2.)*

**LEARN-INV-07** *(W, S)* — **The change record has two writers and they are disjoint.**
`learner writes {target, delta, trigger, target_ref}`; `K writes {change_id, epoch, authorized_by, authorization_ref, probe_ref, verdict, anchored_at, reversibility, cumulative_udb, audit, effect_envelope verification}`. `writer(learner) ∩ writer(K) = ∅`. *(R54.2, D-L60.)*

## Group II — Signals (LEARN-INV-08 … 15)

**LEARN-INV-08** *(W, X)* — **The signal-kind set is closed.**
`∀ signal: signal.signal_kind ∈ {SG-1 … SG-14}`. No component may define a 15th; no emergent protocol may carry one. *(R23.3, R53.9, LEARN-B9.)*

**LEARN-INV-09** *(W, X)* — **Signal class is derived, never declared.**
`class = K.derive(origin, signature, gt_refs)`. `¬∃ signal: signal.class = sender_declared`. *(R20.2, LEARN-B2.)*

**LEARN-INV-10** *(S, X)* — **Provenance is immutable under learning.**
`∀ change, ∀ field ∈ SignalProvenance: change does not modify field`. *(R20.5, R54.1, LEARN-B7.)*

**LEARN-INV-11** *(C, S)* — **Learning signals are deduplicated, not aggregated.**
`effect(S) = effect(dedup(S))`. `¬∃ term in Δθ proportional to |S|`. *(R22.1, LEARN-B5, LEARN-B6.)*

**LEARN-INV-12** *(W, X)* — **Admissible reward kinds are external.**
`admissible = {RW-1, RW-2(gating), RW-3, RW-4(ranking)}`; `{RW-5, RW-6, RW-7, RW-8} = ∅ as learning signals`. *(R8.1, LEARN-C6.)*

**LEARN-INV-13** *(W, X)* — **`source = EVA_ONLY` for reward.**
`∀ reward: reward.source = EVA ∧ reward.signature = EVA_signature`. A cell signature is structurally invalid. *(R12.1, LEARN-B1.)*

**LEARN-INV-14** *(S, X)* — **No transmitted credit exists.**
`¬∃ field ∈ {credit, contribution, reward_share, utility, expected_utility, expected_reward, anticipated_credit}` on any message, synapse record, or `LearnedChange`. *(COMM-INV-20/28, LEARN-C4.)*

**LEARN-INV-15** *(C, T)* — **A prediction must be registered before it resolves.**
`∀ prediction: prediction.registered_at < prediction.resolved_at`, kernel-checked. An `error_signal` from a post-hoc registration is inadmissible. *(R13.1.)*

## Group III — Bounds and budgets (LEARN-INV-16 … 23)

**LEARN-INV-16** *(S, C)* — **Unverified displacement is bounded per scope.**
`∀ S ∈ {S1…S5}: ‖θ_S − θ_anchor(S)‖ ≤ UDB_MAX[S]`. Breach ⟹ **STALL**. *(R0.1.)*

**LEARN-INV-17** *(S)* — **`UDB_MAX` is monotonically decreasing in scope.**
`UDB_MAX[S1] ≥ UDB_MAX[S2] ≥ … ≥ UDB_MAX[S5]`, kernel-enforced. **Bigger scopes have weaker verification, so they get less unverified room.** *(R18.2.)*

**LEARN-INV-18** *(C, S)* — **UDB covers all admissible targets at a scope, not θ alone.**
`UDB(S) = ‖state_S − anchor_S‖` over `Λ1 ∪ Λ2 ∪ Λ3 ∪ Λ4` targets admissible at S, including `plasticity_rate` drift, decay, and pruned-connection digests. *(R9.2.4, R15.4, R27.5, R34.3, LEARN-D2/D3/D5/D6.)*

**LEARN-INV-19** *(S)* — **Budgets are non-transferable and non-bankable.**
`¬∃ transfer(budget, S, S') ∧ ¬∃ transfer(budget_i, budget_j) ∧ ¬∃ accumulate(budget) across reset intervals` — except B5, whose "reset" is a re-anchor. *(R30.2, LEARN-D8/D9.)*

**LEARN-INV-20** *(T, S)* — **Timescale ordering is enforced.**
`lr_fast ≥ lr_medium ≥ lr_slow`, kernel-enforced; `SLOW_MODE` reduces all timescales together, preserving the ordering. *(R32.3, Cell §9.4, D-L29.)*

**LEARN-INV-21** *(S, T)* — **Structural change has no learning rate.**
`¬∃ lr_structural ∧ ¬∃ Δ_topology`. Λ3 is event-driven at a rung. *(R61.3, R32.1, LEARN-F1.)*

**LEARN-INV-22** *(S)* — **The structural budget is a count and a blast radius, not a magnitude.**
`B6(S) = ⟨max_operations, max_blast_radius⟩ per interval`. *(R61.2, LEARN-F7.)*

**LEARN-INV-23** *(S, W)* — **Homeostatic scaling is the only write permitted during a stall, and only toward set-point.**
`stalled(S) ⟹ permitted_writes(S) = {homeostatic scaling ∧ direction reduces deviation}`. *(R15.2, R66 ladder L4.)*

## Group IV — Authority and escalation (LEARN-INV-24 … 30)

**LEARN-INV-24** *(G, S)* — **Authority is monotone in scope.**
`authority(S1) ≤ authority(S2) ≤ … ≤ authority(S6)`. A component may not authorise above its scope. *(R4.3, LEARN-A5.)*

**LEARN-INV-25** *(G, S)* — **Authority is monotone in rung.**
`authority(E0) ≤ authority(E1) ≤ … ≤ authority(E9)` **and** `verification_cost(E0) ≤ … ≤ verification_cost(E9)`. Declaring authority above the rung ⟹ reject; declaring verification below the rung ⟹ reject. *(R29.4, LEARN-A2.)*

**LEARN-INV-26** *(G, S)* — **Authority scales with irreversibility × blast radius, never with magnitude.**
`required_authority = f(A4, blast_radius)`, `¬∃ g: required_authority = g(‖Δ‖)`. *(R0.3.)*

**LEARN-INV-27** *(G, X)* — **Λ4 has exactly one writable scope.**
`writable_scope(Λ4) = {S5} ∧ writable_by(Λ4) ⊆ {POLICY(RO-13), EIK}`. *(R28.1 fact #2, R19.2, LEARN-A8.)*

**LEARN-INV-28** *(G, X)* — **Governance and state share no write path.**
`writes(governance) ∩ writes(learning) = ∅`, where `governance = {matrix, ladder, budgets, F, probe criteria, fixed core, invariants, signal_kind set, error_class set}`. *(R19.2, R65.1, LEARN-A8.)*

**LEARN-INV-29** *(G, S)* — **A composite's authority is the max of its rungs and its verification is the conjunction.**
`authority(⋃ E_i) = max(authority(E_i)) ∧ verification(⋃ E_i) = ⋀ verification(E_i)`. *(R29.3, LEARN-A6.)*

**LEARN-INV-30** *(G, W)* — **S6 is empty for learning.**
`¬∃ change: change.scope = S6`. The only S6 crossing is a CH-3 *proposal*, which is not a `LearnedChange`. *(R4.2, R28.1, R24.1.)*

## Group V — Epistemic separation (LEARN-INV-31 … 36)

**LEARN-INV-31** *(E, X)* — **Learning changes belief at fixed evidence status.**
`∀ change: change may modify belief ∧ change may not modify evidence_status`. *(MEM-INV-18, R55.1.)*

**LEARN-INV-32** *(E, X)* — **No internal event raises evidence status.**
Inherits P0-04 R0.3's `∅` and restates it at learning altitude: `¬∃ change: change raises evidence_status ∨ warrant_class ∨ trust ∨ source_class`. *(R1.4, R12.1, R54.1, MEM-INV-19/33/50, COMM-INV-08/25.)*

**LEARN-INV-33** *(E, X)* — **Reward does not raise belief.**
`reward > 0 ⟹̸ P(b) increases`. Belief decrease from `VERIFIED_REGRESSED` is permitted and lowers calibration, not evidence status. *(Vol A R12.1/R12.2.)*

**LEARN-INV-34** *(E, X)* — **Warrant magnitude is not gradient magnitude.**
`¬∃ term in Δθ proportional to warrant_class(signal)`. Warrant changes a signal's **class**, never its **size**. *(R54.3, D-L61.)*

**LEARN-INV-35** *(E, X)* — **Prediction error is not causality and is not knowledge.**
`error_class = PREDICTION ⟹ evidence ceiling = L6 ⟹ ¬reaches S3`. `¬∃ Λ3 change triggered by prediction error alone`. *(R13.3, §87.)*

**LEARN-INV-36** *(E, X)* — **Verification is not transferable.**
`improvement_verified` is a property of `(θ, scope, distribution, probe)`; substituting any component requires re-probing. Distillation, transfer, Baldwinian inheritance and CH-1 initialisation all arrive `provisional = TRUE`, unanchored. *(R43.4, R44.2, R25.3, D-L46.)*

## Group VI — Reversibility, lineage and audit (LEARN-INV-37 … 40)

**LEARN-INV-37** *(S, C)* — **The change graph is acyclic.**
`¬∃ cycle in (superseded_by ∪ signal_ref ∪ anchored_at)`. A cycle ⟹ RB-3. *(R64.1, R64.2.)*

**LEARN-INV-38** *(C, S)* — **Rollback marks; it never deletes.**
`rollback ⟹ superseded_by = ROLLED_BACK`, and the record persists. **The organism may undo what it did; it may not undo the record that it did it.** *(R62.6, P0-04's no-rewrite principle at change-log altitude.)*

**LEARN-INV-39** *(S, C)* — **An irreversible structural operation carries a tombstone.**
`∀ E3+: tombstone = {id, removed_at, removed_by, ablation_ref, final_weight_digest, lineage_refs} ≠ NULL`. *(R27.2, R64.6, LEARN-F6.)*

**LEARN-INV-40** *(S, C)* — **Corruption fails safe.**
`∀ corruption detected: response ∈ {stall, freeze, restrictive reading, rollback}` and `response ∉ {increase plasticity, increase envelope, increase budget, increase authority}`. *(R64.4, R64.5, R64.7.)*

## Group VII — The directional invariant (LEARN-INV-41 … 42)

**LEARN-INV-41** *(G, S, T)* — **NO FAILURE MODE PRODUCES A CAPACITY INCREASE.**
`d(verification) < 0 ∨ d(cascade_signature) > 0 ∨ budget exhausted ∨ invariant violated ⟹ d(plasticity) ≤ 0 ∧ d(envelope) ≤ 0 ∧ d(budget) ≤ 0 ∧ d(authority) ≤ 0`.
**The one apparent exception — L3's governance-granted B8 (R40.3, R57.3) — is not an exception, because the writer is `[RO-13]`, not the failure.** *(R28.2, R31.1, R66.1, R66.2. P0-04 §91's principle at learning altitude.)*

**LEARN-INV-42** *(G, S)* — **THE DEGRADATION LADDER IS MONOTONE.**
`∀ transition L_i → L_{i+1}` in the §66 ladder: no governed quantity increases. **There is no internal route upward.** *(R66.1, R66.3.)*

## 68.1 Invariant count reconciliation

| Group | Range | Count |
|---|---|---|
| I — change object | 01–07 | 7 |
| II — signals | 08–15 | 8 |
| III — bounds & budgets | 16–23 | 8 |
| IV — authority & escalation | 24–30 | 7 |
| V — epistemic separation | 31–36 | 6 |
| VI — reversibility, lineage, audit | 37–40 | 4 |
| VII — directional | 41–42 | 2 |
| **TOTAL** | **01–42** | **42** ✓ |

**Tag coverage:** W appears in 01,02,03,04,05,07,08,09,12,13,27,30 (12) · S in 01,03,04,07,09,10,11,14,16,17,19,20,21,22,23,24,25,26,27,29,30,37,38,39,40,41,42 (27) · C in 05,06,10,11,15,16,18,22,37,38,39,40 (12) · X in 02,08,09,12,13,19,27,28,30,31,32,33,34,35,36 (15) · G in 24,25,26,27,28,29,30,41,42 (9) · E in 31–36 (6) · T in 15,20,23,41 (4).

---

# 69. **[O47] FORMAL STATE MACHINES — 7 MACHINES

## SM-1 — `LearnedChange` LIFECYCLE

```
States: {∅, PROPOSED, ADMITTED, APPLIED, PROVISIONAL, VERIFIED_I, VERIFIED_N,
         VERIFIED_R, ROLLED_BACK, AGED_LOCAL, AGED_NONE, SUPERSEDED, REJECTED}

∅ ──trigger ∈ T1..T8 ∧ signal admissible (§19) ∧ authorization valid (§28)
     ∧ rollback_handle present (INV-04) ∧ anchored_at present (Λ1/Λ3/Λ4)──► PROPOSED
∅ ──any of the above fails──► REJECTED  [terminal; audit entry; no state change]

PROPOSED ──UDB check passes (R0.1) ∧ budget available (B1,B2,B3,B6)──► ADMITTED
PROPOSED ──UDB ≥ UDB_MAX[S]──► ⟵ the change is NOT admitted; the SCOPE stalls (SM-2)

ADMITTED ──apply Δ (bounded: Δ_MAX, homeostatic scaling)──► APPLIED
APPLIED ──provisional := TRUE──► PROVISIONAL       [effect_envelope = FULL]

PROVISIONAL ──probe → IMPROVED──► VERIFIED_I ──re-anchor θ_anchor──► SUPERSEDED(anchor)
PROVISIONAL ──probe → NEUTRAL ──► VERIFIED_N ──re-anchor θ_anchor──► SUPERSEDED(anchor)
PROVISIONAL ──probe → REGRESSED──► VERIFIED_R ──AUTOMATIC ROLLBACK to θ_anchor (R62.1)──► ROLLED_BACK
PROVISIONAL ──probe → UNKNOWN ∧ age < AGE_1──► PROVISIONAL   [envelope FULL]
PROVISIONAL ──age ≥ AGE_1 (R1.3)──► AGED_LOCAL               [envelope → LOCAL]
PROVISIONAL ──age ≥ AGE_2──► AGED_NONE                       [envelope → NONE; rollback review]
PROVISIONAL ──age ≥ AGE_3──► ROLLED_BACK                     [AUTOMATIC (R1.3); never-verified]
AGED_LOCAL ──probe → IMPROVED/NEUTRAL──► VERIFIED_I/N        [envelope restored]
AGED_NONE  ──probe → IMPROVED/NEUTRAL──► VERIFIED_I/N        [envelope restored]

VERIFIED_I / VERIFIED_N ──may nominate (R50.1) / may anchor (R0.1) / may enter CH-3 proposal (R24.1)
ROLLED_BACK ──superseded_by := ROLLED_BACK (INV-38: marked, never deleted)──► [terminal]
SUPERSEDED  ──[terminal for the change; the anchor persists]

INVARIANTS ON SM-1:
  • No transition into VERIFIED_* without a probe_ref (INV-05)
  • No transition out of PROVISIONAL by self-action (Cell §9.6; LEARN-E7)
  • ROLLED_BACK is terminal and recorded (INV-38)
  • Every transition is written by K except PROPOSED→ADMITTED's Δ fields (INV-07)
```

## SM-2 — SCOPE LEARNING STATE (the §66 ladder)

```
States: {NORMAL, CAUTIOUS, PROVISIONAL_AGED, CASCADE_FLAGGED, STALLED, FROZEN, RETIRED}

NORMAL ──T5 ∨ T7 ∨ class-10 mismatch ∨ metaplasticity──► CAUTIOUS
NORMAL ──any R63.3 detector fires──► CASCADE_FLAGGED
NORMAL ──UDB ≥ UDB_MAX[S]──► STALLED
NORMAL ──learning_enabled ← FALSE ∨ homeostatic failure ∨ INV violation──► FROZEN

CAUTIOUS ──trigger resolved──► NORMAL
CAUTIOUS ──UDB ≥ UDB_MAX[S]──► STALLED
CAUTIOUS ──age ≥ AGE_1 at scope level──► PROVISIONAL_AGED

PROVISIONAL_AGED ──probe re-anchor──► NORMAL
PROVISIONAL_AGED ──age ≥ AGE_3──► (rollback all AGED changes) ──► NORMAL

CASCADE_FLAGGED ──[RO-13] acts on finding──► NORMAL ∨ CAUTIOUS
CASCADE_FLAGGED ──obligation discharged (R40.3/R57.3) ∧ detector clears──► NORMAL
CASCADE_FLAGGED ──UDB ≥ UDB_MAX[S]──► STALLED

STALLED ──probe → IMPROVED/NEUTRAL ⟹ re-anchor──► NORMAL ∨ CAUTIOUS
STALLED ──[no other exit]                        (homeostatic scaling continues: INV-23)

FROZEN ──EIK/organism restores learning_enabled──► NORMAL
FROZEN ──[no self-exit]

RETIRED ──[terminal; E5; requires CR-B + full lineage audit]

INVARIANTS ON SM-2 (INV-41, INV-42):
  • Every downward transition: plasticity ↓∨=, envelope ↓∨=, budgets ↓∨=, authority ↓∨=
  • STALLED propagates DOWNWARD only (R18.1, R67.2)
  • The only upward transitions are: probe re-anchor (external), [RO-13] action (governance),
    EIK/organism restore (governance). NO INTERNAL ROUTE UPWARD.
  • L3's B8 grant is written by [RO-13], not by the cascade (R66.2)
```

## SM-3 — ANCHOR LIFECYCLE

```
States: {NO_ANCHOR, CANDIDATE, ANCHORED, WEAK, DECAYED, INVALIDATED, ABSENT_CORRUPT}

NO_ANCHOR ──scope instantiation──► NO_ANCHOR   [UDB = ‖θ_S − θ_S‖ = 0, but no anchor exists:
                                                ⟹ transfers arrive here (R44.2) ⟹ effectively
                                                at full displacement ⟹ immediate stall risk]
NO_ANCHOR ──checkpoint taken by K──► CANDIDATE     [NOT an anchor (R62.3, LEARN-A3)]
CANDIDATE ──probe → IMPROVED ∨ NEUTRAL──► ANCHORED [UDB_MAX = g(quality) (R9.4.2)]
CANDIDATE ──probe → REGRESSED ∨ UNKNOWN──► CANDIDATE  [stays candidate; no re-anchor]
CANDIDATE ──no probe within [G] interval──► NO_ANCHOR  [candidate expires]

ANCHORED ──anchor quality low (R9.4.2)──► WEAK     [UDB_MAX reduced]
ANCHORED ──anchor age grows (R9.4.3)──► DECAYED    [UDB_MAX reduced continuously]
ANCHORED ──volatility rises (R33.1)──► DECAYED     [UDB_MAX = g(quality) × h(volatility)]
ANCHORED ──R51.2: an E1+ change invalidates it──► INVALIDATED  [lower scopes MUST re-probe]
ANCHORED ──checksum fails──► ABSENT_CORRUPT        [R64.4: treated as ABSENT ⟹ UDB = full
                                                    displacement ⟹ IMMEDIATE STALL. Fails safe.]
WEAK / DECAYED ──probe re-anchor──► ANCHORED
INVALIDATED ──probe──► ANCHORED
ABSENT_CORRUPT ──[no self-repair; K must re-establish]

INVARIANTS ON SM-3:
  • INV-05: an anchor requires probe_ref ∧ verdict ∈ {IMPROVED, NEUTRAL}
  • R62.3: a checkpoint is never an anchor without a probe
  • R64.4: corruption ⟹ ABSENT ⟹ MORE restriction, never less (INV-40)
  • UDB_MAX is a function of (scope, anchor quality, volatility) ONLY —
    never of anything the learner assesses (R33.1, R9.4.2, R18.2)
```

## SM-4 — SIGNAL ADMISSION

```
States: {RECEIVED, CLASSIFIED, ADMISSIBLE, PROVISIONAL_ONLY, INADMISSIBLE, CONSUMED, DEDUPED}

RECEIVED ──K derives class from (origin, signature, gt_refs) (INV-09)──► CLASSIFIED

CLASSIFIED ──class = SC-0──► INADMISSIBLE ──[audit entry; NO change]──► [terminal]
CLASSIFIED ──class = SC-1──► PROVISIONAL_ONLY
CLASSIFIED ──class = SC-2──► ADMISSIBLE (restricted: Λ0/Λ1, K-owned Λ4 params, homeostasis)
CLASSIFIED ──class = SC-3──► ADMISSIBLE (full: Λ0–Λ4 per matrix, anchor-eligible, fitness-eligible)
CLASSIFIED ──class = SC-4──► ADMISSIBLE (capacity ONLY; NEVER θ — R19.2)

PROVISIONAL_ONLY ──idempotency_key seen before──► DEDUPED ──► [terminal; no effect] (INV-11)
ADMISSIBLE       ──idempotency_key seen before──► DEDUPED ──► [terminal; no effect]

PROVISIONAL_ONLY ──fresh key──► ADMISSIBLE-for-Λ0/Λ1-provisional ──► CONSUMED
ADMISSIBLE ──fresh key ∧ signal_kind ∈ admissible_for(target) (R20.4)──► CONSUMED
ADMISSIBLE ──signal_kind ∉ admissible_for(target)──► INADMISSIBLE

CONSUMED ──► produces SM-1's PROPOSED transition (or a capacity change, for SC-4)

SPECIAL TRANSITIONS:
  SG-5 (novelty)   ──► NEVER produces Δθ; ONLY plasticity_mult ↓ ∧ SLOW_MODE (R14.2)
  SG-7 (repetition)──► NEVER produces Δθ; ONLY nomination + metaplasticity (§22.4)
  SG-8 (failure)   ──► NEVER produces "more learning"; ONLY plasticity_mult ↓ (Cell T7)
  SG-10 (constraint)──► BLOCKS learning; zero positive gradient (R8.1)
  SG-13 (peer report)──► may cause PREDICTION REGISTRATION only, never Δθ (R19.3)
  RECALL            ──► INADMISSIBLE as T1/T2 (R11.1, R41.1)
  SIMULATED         ──► INADMISSIBLE as probe/observation (R42.1, R42.3)

INVARIANTS ON SM-4:
  • INV-08 (closed kind set), INV-09 (derived class), INV-11 (dedup),
    INV-12/13 (external reward), INV-15 (pre-registration)
  • class ⟹ admissible_for is a KERNEL-SET function of class alone, never of
    content or magnitude (R20.4)
```

## SM-5 — STRUCTURAL ESCALATION

```
States: {OBSERVED, PROPOSED(rung), AUTHORISED, CHECKPOINTED, VERIFIED_CR_B,
         EXECUTED, TOMBSTONED, REJECTED, ROLLED_BACK}

OBSERVED ──demand ∨ diagnosis (R39.2) ∨ finding──► PROPOSED(rung n)
   [a lower rung may PROPOSE a higher rung, never EXECUTE it (R29.2)]
   [proposals consume B7 PROPOSAL_QUOTA (R24.1, R29.2)]

PROPOSED(n) ──decompose into rungs (R29.3)──► PROPOSED(n_1), …, PROPOSED(n_k)
PROPOSED(n) ──authority(n) not held──► REJECTED [terminal; audit entry]
PROPOSED(n) ──n ≥ E6 ∧ no checkpoint──► REJECTED (R62.7)
PROPOSED(n) ──n = E3 ∧ disuse_cause ∈ {UNREACHABLE, UNKNOWN}──► REJECTED (R27.3)
PROPOSED(n) ──n ≥ E3 ∧ CR-B ablation infeasible──► REJECTED (R6.4.2)
PROPOSED(n) ──diversity floor would breach (R46.4)──► REJECTED (HARD CONSTRAINT)

PROPOSED(n) ──authority(n) held ∧ B6 available──► AUTHORISED
AUTHORISED ──n ≥ E6──► CHECKPOINTED ──► VERIFIED_CR_B
AUTHORISED ──n < E6──► VERIFIED_CR_B
VERIFIED_CR_B ──ablation confirms──► EXECUTED
VERIFIED_CR_B ──ablation refutes──► REJECTED

EXECUTED ──n ≥ E3──► TOMBSTONED [mandatory; INV-39]
EXECUTED ──traces at scope invalidated (R6.5.1) ∧ lower anchors invalidated (R51.2)──►
           ──► downstream scopes MUST re-probe
EXECUTED ──later VERIFIED_REGRESSED at circuit level──► ROLLED_BACK (if A4 permits) ∨
           ──► [IRREVERSIBLE: finding + audit; NO rollback exists] (R62.8)

INVARIANTS ON SM-5:
  • INV-21 (no structural learning rate — event-driven only)
  • INV-22 (B6 is a count and a blast radius)
  • INV-25 (rung monotonicity in authority AND verification cost)
  • INV-29 (composite authority = max, verification = conjunction)
  • INV-39 (tombstone)
  • OR-L3: VERIFIED_CR_B at circuit level has NO SPECIFIED PROBE DESIGN.
    The machine requires a transition it cannot yet justify. DECLARED, NOT HIDDEN.
```

## SM-6 — CASCADE DETECTOR (the general R39.4 shape)

```
States: {MONITORED, DRIFTING, FLAGGED, OBLIGATION_IMPOSED, CLEARED, ESCALATED}

MONITORED ──rate[scope][context] stable under fixed external distribution──► MONITORED
MONITORED ──rate drifting ∧ external distribution NOT drifting──► DRIFTING
   [the general signature (R63.2): internally-caused drift in an engagement rate]

DRIFTING ──drift < [G] threshold──► MONITORED
DRIFTING ──drift ≥ [G] threshold──► FLAGGED ──emit FINDING (non-binding, R63.2)──►
                                        ──► SM-2 CASCADE_FLAGGED

FLAGGED ──cascade ∈ {abstention, quarantine}──► OBLIGATION_IMPOSED
   [R40.3 bounded exposure obligation / R57.3 re-exposure obligation]
   [B8 grant by [RO-13] — the ONE capacity increase, and it is governance-written (R66.2)]
FLAGGED ──cascade ∈ {diversity floor}──► ESCALATED ──► HARD REJECTION of the causing
                                        operation (R46.4), not a rate adjustment
FLAGGED ──cascade ∈ {homogenisation}──► OBLIGATION_IMPOSED
   [R60.5 reserved governance slots engage]

OBLIGATION_IMPOSED ──rate returns to band──► CLEARED ──► MONITORED
OBLIGATION_IMPOSED ──rate does not return within [G] interval──► ESCALATED ──► [RO-13]

THE EIGHT INSTANCES (R63.3), all sharing this machine:
  abstention (R40.2) · failure→avoidance (R39.3) · availability capture ·
  pruning-by-disuse (R27.3) · exploration starvation · quarantine (R57.6) ·
  workspace homogenisation (R60.4) · specialisation narrowing (R46.3)

INVARIANTS ON SM-6:
  • INV-41: the cascade itself never increases capacity; [RO-13] does, in response
  • The detector is O(8) counters, not eight theories (R63.2)
  • OR-L5: the detector can identify a cascade; it CANNOT determine whether the
    reduced engagement was CORRECT. Detection of the pattern ≠ evaluation of the choice.
```

## SM-7 — BALDWINIAN PROPOSAL (CH-3)

```
States: {MOTIVATED, PROPOSED, QUOTA_CONSUMED, GATED(1..11), META_PROBED,
         REJECTED, ACCEPTED, INHERITED}

MOTIVATED ──a set of VERIFIED_IMPROVED changes at a scope──► PROPOSED
   [ONLY VERIFIED_IMPROVED may motivate (R50.3, R24.1). PROVISIONAL may not.]

PROPOSED ──consume B7 PROPOSAL_QUOTA──► QUOTA_CONSUMED
   [R24.1: a proposal's existence MUST NOT affect the proposer's plasticity, budget,
    authority or fitness. Otherwise cells propose maximally.]
   [B-7-class quota-gaming detector applies (P0-04, R50.1)]

QUOTA_CONSUMED ──machine-checkable rejection list (Cell §3.5 + R24.2)──►
   REJECTED if the diff would carry: a learned θ VALUE · a source_class ·
     content/memory/belief/evidence_status · F or its weights · the authorization matrix ·
     the escalation ladder · UDB_MAX · any invariant · the fixed validation core ·
     plasticity_mult STATE
   GATED(1) if none of the above

GATED(1..11) ──the 11 replication gates (Cell §3.5)──► META_PROBED ∨ REJECTED

META_PROBED ──held-out validation under the FIXED CORE (R24.3, R38.4)──►
   ACCEPTED ∨ REJECTED
   [if the diff alters LEARNING RULES (V3.1 §7): rate-limited to one per lineage per
    [G] interval, AND the validating instrument is the fixed core, which the diff
    may not alter. OR-L2: the core's CONTENTS are a governance decision.]

ACCEPTED ──R25.2 spread floor check──► INHERITED ∨ REJECTED
   [param_init spread MUST be non-zero and MUST NOT narrow beyond a [G]-bounded
    factor per generation. BF-1 / LEARN-H2.]

INHERITED ──offspring instantiation──► CH-1 read-once (R26.2)
   [R25.3: the prior biases θ, NEVER belief. Offspring belief starts at the floor.]
   [R25.4 / R46.4: DIVERSITY CHECK mandatory on any selection over param_init]
   [R44.2: the offspring arrives UNANCHORED — the gates were the pre-paid verification]

INVARIANTS ON SM-7:
  • INV-02 (no Λ5 write path — the proposal is not a write)
  • INV-30 (S6 is empty for learning; CH-3 is a proposal, not a change)
  • INV-36 (verification is not transferable — R44.2)
  • R25.1 THE BALDWINIAN TEST: could the offspring be wrong? If inheriting guarantees
    the property, the channel is Lamarckian and is REJECTED regardless of its name.
  • LEARN-H6 / OR: the Baldwinian ratchet via selection is BOUNDED by R25.4, not closed.
    Closing it would prohibit evolution.
```

## 69.1 State machine count and coverage

| Machine | States | Transitions | Governs | Principal invariant set |
|---|---|---|---|---|
| **SM-1** | 13 | 18 | the change object | I (01–07) |
| **SM-2** | 7 | 15 | the scope's learning state — the §66 ladder | VII (41, 42), III (16, 23) |
| **SM-3** | 7 | 12 | anchors | I (05), VI (40) |
| **SM-4** | 7 | 20 | signal admission | II (08–15) |
| **SM-5** | 9 | 16 | structural escalation | IV (24–30), III (21, 22), VI (39) |
| **SM-6** | 6 | 11 | cascades | VII (41) |
| **SM-7** | 9 | 14 | Baldwinian proposals | I (02), IV (30), V (36) |
| **TOTAL** | **58 states** | **106 transitions** | | **all 42 invariants are asserted by ≥ 1 machine** |

> ### **R69.1 — EVERY INVARIANT IS ASSERTED BY AT LEAST ONE MACHINE, AND EVERY MACHINE ASSERTS AT LEAST ONE INVARIANT THAT NO OTHER MACHINE ASSERTS.**
> Verified by inspection of the "INVARIANTS ON SM-n" blocks: I⟶SM-1 · II⟶SM-4 · III⟶SM-2/SM-5 · IV⟶SM-5/SM-7 · V⟶SM-7 (+SM-4 for 32–35) · VI⟶SM-1/SM-3/SM-5 · VII⟶SM-2/SM-6. **No orphan invariants; no redundant machines.**
> **Two machines carry declared gaps rather than resolved transitions: SM-5 (`VERIFIED_CR_B` at circuit level — OR-L3) and SM-6 (cannot evaluate whether reduced engagement was *correct* — OR-L5). Both are annotated in-place per §87's "do not hide unresolved problems."**

---

# 70. **[O48] THE PARAMETER REGISTRY

**§87: DO NOT invent numerical parameters. Every parameter below is registered with a class and NO VALUE.**

**Classes:** `[G]` governed — set by `[RO-13]`/governance, no architectural value · `[K]` kernel — computed/enforced by K, not settable · `[D]` derived — computed from other quantities by a stated rule · `[X]` external — supplied by EVA/environment · `[U]` unresolved — no rule determines it; declared open · `[RO-n]` policy-class — immutable governance policy · `[∅]` does not exist — the absence is the mechanism.

## 70.1 Group I — Bounds on change (13 parameters)

| # | Parameter | Class | Set by | Consumed by | Note |
|---|---|---|---|---|---|
| 1 | `Δ_MAX` | `[G]` + genome (CH-2) | `[RO-13]` | B1 | Inherited (Cell §9.4) |
| 2 | `DELTA_BUDGET[scope][epoch]` | `[G]` | `[RO-13]` | B2 | Inherited. **A rate limit, not a distance limit (D-L1).** |
| 3 | `Θ_MAX` | `[G]` + genome | `[RO-13]` | B3 | Inherited |
| 4 | **`UDB_MAX[scope]`** | `[G]`, **monotone decreasing in scope (INV-17)** | `[RO-13]` | **B5** | **NEW — R0.1, R18.2** |
| 5 | **`anchor_quality_weighting g(·)`** | `[G]` | `[RO-13]` | B5 modulation | **NEW — R9.4.2.** Monotone increasing in probe quality. |
| 6 | **`anchor_age_decay h_age(·)`** | `[G]` | `[RO-13]` | B5 modulation | **NEW — R9.4.3** |
| 7 | **`volatility_factor h_vol(·)`** | `[G]` | `[RO-13]` | B5 modulation | **NEW — R33.1.** Monotone decreasing. |
| 8 | **`SC1_displacement_weight`** | `[G]` | `[RO-13]` | B5 | **NEW — R42.4.** SC-1-driven displacement counts MORE than SC-3-driven. |
| 9 | **`STRUCTURAL_BUDGET[scope]`** = ⟨max_ops, max_blast_radius⟩ | `[G]` | `[RO-13]` | B6 | **NEW — R61.2, INV-22.** A count and a radius, not a magnitude. |
| 10 | **`PROPOSAL_QUOTA[scope]`** | `[G]` | `[RO-13]` | B7 | Extends P0-04's B-7 regime to CH-3 (R24.1) |
| 11 | **`EXPLORATION_BUDGET[scope]`** | `[G]` | `[RO-13]` | B8 | **NEW — R36.1** |
| 12 | **`PROBE_BUDGET` (organism-level)** | `[G]` | `[RO-13]` | B9 | **NEW — R47.1. THE ORGANISM'S LEARNING RATE.** |
| 13 | `lr[fast/medium/slow]` | `[G]` + genome, **ordering kernel-enforced (INV-20)** | `[RO-13]`/K | Δθ | Inherited (Cell §9.4). **No `lr_structural` exists (INV-21, `[∅]`).** |

## 70.2 Group II — Plasticity state (9 parameters)

| # | Parameter | Class | Set by | Note |
|---|---|---|---|---|
| 14 | `plasticity_mult[scope]` | `[K]` | **K ONLY** | Inherited (Cell §4.1.8). **May decrease automatically; may never increase automatically (R28.2, INV-41).** |
| 15 | `plasticity_rate` (S1) | `[G]`-bounded, learnable within bounds | learner selects / K writes | Inherited (V3 §8, P0-03 R3.2). **⟹ X-L5 / R34.3: cumulative drift consumes S1 UDB.** |
| 16 | `context_sensitivity` | learnable within `[G]` bounds | learner | Inherited (P0-03 R3.2) |
| 17 | `weight` (S1) | learnable within `[G]` bounds | learner | Inherited |
| 18 | `eligibility_trace` | `[K]`-written, sparse, EIK-inspectable | K | Inherited (Cell §4.1.8, §14.3). **Local, λ-decayed, NOT a causal claim.** |
| 19 | `trace_decay λ` | `[G]` | `[RO-13]` | Inherited. **Invalidated wholesale by Λ3 change (R6.5.1).** |
| 20 | **`homeostatic set-point`** | `[G]` + genome | `[RO-13]` | **NOT LEARNABLE (R15.3, R58.2, R58.5).** The stability floor is unlearned by definition. |
| 21 | **`homeostatic scaling law`** | `[RO-13]` | policy | **NOT LEARNABLE (R58.2).** |
| 22 | `learning_enabled[scope]` | `[K]`/EIK/organism | **never the cell** | Inherited (Cell §9.3) |

## 70.3 Group III — Provisionality and envelope (7 parameters)

| # | Parameter | Class | Note |
|---|---|---|---|
| 23 | **`PROVISIONAL_AGE_1 < AGE_2 < AGE_3`** | `[G]`, **ordering kernel-enforced** | **NEW — R1.3.** No values. `[D]` dependency on the probe-cost model (P0-10). |
| 24 | **`effect_envelope.behavioural_reach`** | `[D]` declared at admission, **verified by observation** | **NEW — §1.3, R67.1 (aggregated per scope over a window).** |
| 25 | **`effect_envelope.comm_reach`** | `[D]`, with **`WARRANT_AFFECTING = ∅`** | **NEW — R1.4.** The empty value is the mechanism. |
| 26 | **`effect_envelope.mem_reach`** | `[D]` | **NEW.** Binds X-L1. |
| 27 | `improvement_verified` | `[K]` | Inherited (Cell §9.6). **K-only writer.** |
| 28 | **`probe_schedule`** | `[RO-13]`, **NOT READABLE BY THE LEARNING SUBSYSTEM** | **NEW — R9.4.1. The primary RH-7 defence.** |
| 29 | **`probe_input_distribution`** | `[RO-13]` | **NEW — C-1, R45.1, R37.2.** |

## 70.4 Group IV — Signals and reward (10 parameters)

| # | Parameter | Class | Note |
|---|---|---|---|
| 30 | `signal_kind` set {SG-1…SG-14} | `[RO-13]`, **CLOSED (INV-08)** | No 15th kind exists. |
| 31 | `class → admissible_for` map | `[K]`, **derived (INV-09, R20.4)** | Kernel-set from class alone, never from content or magnitude. |
| 32 | `confidence_in_error` | `[X]` + calibration | Inherited (Cell §9.4's 5th factor). **P0-01 §13 class 7: cannot be self-assessed. T8 writes it ⟹ consumes UDB (R23.2).** |
| 33 | `idempotency_key` | `[K]` | Inherited (P0-03). **Dedup, not aggregation (INV-11).** |
| 34 | `credit_horizon[task]` | `[RO-13]` | Inherited (P0-01 §3.1). **Mis-specification ⟹ R6.4.3(4) policy finding.** |
| 35 | `attribution_method` ∈ {TD, CAUSAL_ABLATION, EPISODIC_REPLAY, COUNTERFACTUAL} | `[RO-13]` per task | Inherited (P0-01 §12.3). **R6.4.2 restricts which regimes may satisfy E3+ (only CAUSAL_ABLATION; R42.2).** |
| 36 | `reward.density` ∈ {SPARSE, SEMI_DENSE} | `[RO-13]`, **DENSE = `[∅]`** | Inherited (R12.4). **The absent value is the mechanism.** |
| 37 | `reward.vector components` | `[X]` from EVA | Inherited (R12.2). **No scalarisation inside the learning subsystem (R8.2 corollary).** |
| 38 | **`UNATTRIB_ESCALATE`** | `[G]` | **NEW — R6.4.3(4).** |
| 39 | **`difficulty_class` on RW-3 corrections + per-scope correction rate** | `[G]` / `[X]` | **NEW — R9.2.2. Closes RH-C2 / LEARN-C9.** |

## 70.5 Group V — Exploration, diversity, cascades (10 parameters)

| # | Parameter | Class | Note |
|---|---|---|---|
| 40 | **`admissible_actions` predicate** | `[RO-13]` | **NEW — R37.2.** The exploration *space* is governance-owned; the *choice* is learner-owned. |
| 41 | **`exploration_envelope_ceiling`** | `[D]` = the scope's current envelope | **NEW — R36.2.** Never above it. |
| 42 | **`EX_class accounting` {EX-1…EX-5}** | `[K]` | **NEW — R36.4.** EX-1 (resolved prediction) is the only positive class. |
| 43 | **`BOUNDED_EXPOSURE_OBLIGATION rate`** | `[G]` | **NEW — R40.3, R57.3.** No value. **The counterweight to five cascades.** |
| 44 | **`optimism_budget`** | `[G]` | Inherited (P0-04 §90, C-4). |
| 45 | **`diversity[population][dimension]` floors** | `[G]`, **HARD CONSTRAINT (R46.4)** | **NEW.** Not a score term. Rule 15 of the 20 given an enforcement point. |
| 46 | **`de_specialisation_path` declaration** | `[G]` / `[RO-13]` | **NEW — R46.2.** Mandatory on every E4/E7. |
| 47 | **`workspace_reserved_fraction` of `k`** | `[G]` | **NEW — R60.5.** Slots the learned broadcast preference does not control. |
| 48 | **`workspace_per_scope_fraction` of `k`** | `[G]` | **NEW — R60.6.** |
| 49 | **`workspace capacity k`** | `[G]` | **NEW — R60.3.** Not raisable by the learner. |

## 70.6 Group VI — Inheritance and meta (9 parameters)

| # | Parameter | Class | Note |
|---|---|---|---|
| 50 | `param_init` distribution (mean, **spread**) | genome (CH-1) | Inherited (Cell §3.4). **Spread floor: R25.2, INV on SM-7.** |
| 51 | **`spread_narrowing_bound` per generation** | `[G]` | **NEW — R25.2. Closes LEARN-H2.** |
| 52 | **`genome_read_policy` = read-once per instantiation** | `[K]` | **NEW — R26.2.** |
| 53 | the **11 replication gates** | `[RO-13]` | Inherited (Cell §3.5) |
| 54 | **the machine-checkable rejection list** | `[RO-13]`, **EXTENDED by R24.2** | Four new entries: `F`, the matrix, the ladder, `UDB_MAX`. |
| 55 | **the FIXED VALIDATION CORE** | `[RO-13]` / KC, **`M3 = ∅`** | **NEW — R24.3, R38.4. MUST EXIST AND BE NON-EMPTY. Its CONTENTS are a governance decision P0-05 does not and cannot make. OR-L2.** |
| 56 | **learning-rule diff rate limit** | `[G]` | **NEW — R24.3(3).** One per lineage per interval. |
| 57 | **M1 selection space** = `[G]` bounds on Λ4 parameters | `[G]` | **NEW — R38.1.** The meta-learner *selects*; K *writes*. |
| 58 | **the meta-objective** | `[RO-13]`, **NOT LEARNABLE (R38.3)** | The meta-learner may not optimise the quantity by which it is evaluated. |

## 70.7 Group VII — Observability (16 counters, all `[K]`)

Per R52.1: `UDB/UDB_MAX` · `stall_reason` (3-way, R48.4) · `anchor_age` · `anchor_quality` · `verdict_distribution` · `provisional_age_histogram` · `budget_consumption[B1..B9]` · `signal_class_histogram` · `unattributable_rate[task]` · `abstention_rate[scope][context]` · `output_dispersion[scope]` · `EX_class_counts` · `E3+_operations` · `nomination_rate` + quota · `diversity[population][dimension]` · `EVIDENCE_SELECTION_SUSPECT` · `EVALUATOR_SELECTION_SUSPECT` · `workspace_diversity` · `avoidance_rate` · `retrieval_concentration` · `quarantine_rate[scope][threat_class]` · `cross_scope_correlation[6×6]`.

**⟹ 22 named counter families**, all `[K]`-computed, all read-only to learning (R52.2), none an input to `Δθ`. **Total accounting payload ≈ `O(6 × 22) + O(36)` ≈ 168 quantities per organism (R52.3).**

## 70.8 Group VIII — Parameters that DO NOT EXIST (`[∅]`)

**The absence of each is a mechanism, not an oversight.**

| # | Non-existent parameter | Why it must not exist | Rule |
|---|---|---|---|
| 59 | **`Λ5_GENOME` as a `target` enum value** | No Lamarckian write path | §1.2, INV-02 |
| 60 | **`expected_utility` / `credit` / `contribution` / `reward_share` / `utility`** | A transmitted credit claim is a reward-hacking channel | COMM-INV-20/28, INV-14 |
| 61 | **`RW-8 self-assessment`** | Cell §9.6's entire existence | R8.1, INV-12 |
| 62 | **`RW-6 intrinsic/curiosity reward`** | Novelty is manufacturable at zero cost | R8.1, R14.2, R36.1 |
| 63 | **`RW-5 shaping function`** | A hand-authored proxy that gets optimized | R12.4 |
| 64 | **`reward.density = DENSE`** | Same | R12.4 |
| 65 | **`lr_structural` / `Δ_topology`** | Λ3 is event-driven; a gradient on topology permits silent deletion | INV-21, R61.3 |
| 66 | **`ε` (exploration/exploitation trade-off)** | An ε the learner controls is a reward it mints | R36.5 |
| 67 | **`stability_plasticity_tradeoff` scalar** | Two quantities with two owners, not one axis | R15.9, R31.1 |
| 68 | **`SELECTION_SCORE` (10-term scalar sum)** | Contradicts P0-01 §14's vector fitness; contains a tautology and RW-7 contamination | R10.3, X-L2 |
| 69 | **`comm_reach = WARRANT_AFFECTING`** | Learning may influence the *use* of a warrant, never its *value* | R1.4, COMM-INV-25 |
| 70 | **`ConsolidationNomination.promotion`** | Nomination ≠ promotion; promotion is a different record type under a different authority | R50.1, MEM-INV-20 |
| 71 | **`global_Θ` / `global_anchor` / `global_credit`** | A global learner is `O(N²)` and is a hidden governance layer | R6.4.1, R35.1, R35.5 |
| 72 | **`awareness` as an architectural term** | A biological metaphor substituting for a mechanism | R59.4, Rules 3 and 5 of the 20 |
| 73 | **`Prediction.status = RESOLVED` on a simulated outcome** | Simulation is not observation; the value is `SIMULATED` | R42.1 |
| 74 | **`self_model` as an input to its own update** | A fixed-point iteration with no external term | R59.3 |
| 75 | **`Δθ` term ∝ warrant magnitude** | Warrant-gaining would become plasticity-gaining | R54.3, INV-34 |
| 76 | **`Δθ` term ∝ self-estimated contribution** | A self-referential credit claim | R6.4.5 |
| 77 | **`Δθ` term ∝ |signal count|** | Signals dedup, not aggregate | INV-11 |
| 78 | **`F` (fitness aggregation) as a learnable quantity** | Fitness must not be a learning target | R10.1, R10.2 |

## 70.9 Registry reconciliation

| Group | Count |
|---|---|
| I — bounds on change | 13 |
| II — plasticity state | 9 |
| III — provisionality & envelope | 7 |
| IV — signals & reward | 10 |
| V — exploration, diversity, cascades | 10 |
| VI — inheritance & meta | 9 |
| VII — observability counters | **22 families** (counted separately — they are `[K]`-computed, not settable) |
| VIII — **parameters that do not exist** | **20** |
| **TOTAL SETTABLE/REGISTERED (I–VI)** | **58** |
| **TOTAL OBSERVABLE (VII)** | **22** |
| **TOTAL PROHIBITED (VIII)** | **20** |
| **GRAND TOTAL REGISTERED** | **100** |
| **PARAMETERS WITH A NUMERICAL VALUE SPECIFIED** | **0** ✓ |

**Class distribution over the 58 settable:** `[G]` 31 · `[K]` 8 · `[RO-13]` 11 · `[X]` 3 · genome/CH-1/CH-2 4 · `[D]` 1 (`effect_envelope.behavioural_reach` is declared-then-verified). *(Some parameters carry two classes; counted by primary.)*
**`[U]` unresolved:** **3** — (i) the probe-cost economics behind B9's allocation (**OR-L1**), (ii) the `PROVISIONAL_AGE_{1,2,3}` values, which depend on (i) via the P0-10 cost model, (iii) the **contents** of the fixed validation core (**OR-L2**). **All three are declared in §81 with their dependencies; none is resolved by a constant.**

---

# 71. **[O49] THE PARAMETER DEPENDENCY GRAPH

## 71.1 The critical chain

```
                        [RO-13] GOVERNANCE
                              │ sets
        ┌─────────────────────┼──────────────────────┬─────────────────────┐
        ▼                     ▼                      ▼                     ▼
   UDB_MAX[scope]        PROBE_BUDGET (B9)      PROVISIONAL_AGE_*      MATRIX / LADDER
   (param 4)             (param 12)             (param 23)             (§28, §29)
        │                     │                      │                     │
        │  modulated by       │ allocated across     │ ordering             │ grants
        │  ┌──────┬───────┐   │ scopes by [RO-13]    │ kernel-enforced      │ CAPACITY
        ▼  ▼      ▼       ▼   ▼                      ▼                     ▼
   g(anchor    h_age   h_vol  probe FREQUENCY      envelope shrinkage    plasticity_mult
   quality)   (age)  (volat.)      │                     │              (param 14, K-only)
   (5)        (6)     (7)          │                     │                     │
        ▲                          ▼                     ▼                     ▼
        │                   SM-3 ANCHOR            R1.3 AGED_*           Δθ GAIN
        │                   (probe → verdict)      states                     │
        │                          │                     │                     │
        └──────────────────────────┘                     │                     │
              re-anchor resets UDB                       │                     │
                                                         ▼                     ▼
                                              ROLLBACK / RESTRICTION      Δθ MAGNITUDE
                                                                         (B1,B2,B3 + Δθ)
                                                                              │
                                                                              ▼
                                                                     ‖θ − θ_anchor‖ = UDB
                                                                              │
                                                                              ▼
                                                              UDB ≥ UDB_MAX ? ── YES ──► STALL
                                                                              │            │
                                                                              NO           │
                                                                              ▼            │
                                                                          BEHAVE ◄─────────┘
                                                                    (homeostasis only, INV-23)
```

## 71.2 The dependency table

| Parameter | Depends on | Depended on by | Cycle? |
|---|---|---|---|
| `UDB_MAX[S]` (4) | scope (INV-17) · `g(anchor_quality)` (5) · `h_age` (6) · `h_vol` (7) | STALL decision · `Δθ` admission | **No** |
| `anchor_quality` (5's input) | `PROBE_BUDGET` (12) · probe design · `probe_input_distribution` (29) | `UDB_MAX` | **No — see §71.3** |
| `PROBE_BUDGET` (12) | `[RO-13]` allocation | anchor frequency ⟹ `UDB_MAX` reset rate ⟹ **learning rate** | **No** |
| `θ_anchor` | `probe_ref` ∧ `verdict ∈ {I,N}` (INV-05) | `UDB` computation · rollback target (R62.1) | **No** |
| `verdict` (27) | K + external probe | anchor · nomination · CH-3 motivation · fitness | **No** |
| `probe_schedule` (28) | `[RO-13]`, **secret from the learner** | when verdicts occur | **No** |
| `plasticity_mult` (14) | K, from SC-2 observation | `Δθ` gain | **⚠️ See §71.3 — the one near-cycle** |
| `Δθ` | `plasticity_mult` × `lr` × `trace` × `error_signal` × `confidence_in_error` | `UDB` | **No** |
| `confidence_in_error` (32) | T8 (external calibration, class 7) | `Δθ` gain | **⚠️ R23.2 — consumes UDB, which closes it** |
| `effect_envelope` (24–26) | `provisional` age · `SLOW_MODE` · governance | what a change may affect · R36.2's exploration ceiling | **No** |
| `diversity floors` (45) | `[G]` | **HARD rejection** of E4/E7 and of CH-4 selection | **No** |
| `param_init spread` (50) | genome · `spread_narrowing_bound` (51) | offspring θ₀ · `diversity` | **No** |
| `FIXED CORE` (55) | `[RO-13]`/KC | validation of every CH-3 diff and every M1 selection | **⚠️ OR-L2 — the one genuine near-cycle, §71.3** |

## 71.3 The three near-cycles, and how each is broken

> ### **NCY-1 — THE PLASTICITY LOOP.**
> `plasticity_mult` affects `Δθ` ⟹ `Δθ` affects activity ⟹ activity affects `plasticity_mult` (metaplasticity, Cell §9.5(2)).
> **A genuine closed loop.** Broken by: (a) **`loop_gain < 1` computed OFF-CELL** (Cell §9.5(6), R15.7) — the gain is measured outside the loop it governs; (b) **`plasticity_mult` is K-only** (Cell §4.1.8) — the loop's writable element is not writable by the loop's subject; (c) **metaplasticity is monotone-decreasing in recent displacement** (R15.5) — the loop's feedback term is negative by construction; (d) **the set-point is not learnable** (R15.3, R58.5).
> **Status: BROKEN. Four independent breaks; any one suffices.**

> ### **NCY-2 — THE CALIBRATION LOOP.**
> `confidence_in_error` affects `Δθ` gain ⟹ `Δθ` affects behaviour ⟹ behaviour affects calibration measurement ⟹ measurement affects `confidence_in_error`.
> **A genuine closed loop, and the inherited design does not break it** — Cell T8 permits recalibration and Cell §9.4 makes `confidence_in_error` a multiplicative gain, with no rule connecting them.
> **Broken by R23.2: T8 consumes UDB and requires probe verification.** ⟹ The loop now runs **inside** the UDB budget, so its gain cannot increase without consuming displacement, and displacement exhaustion stalls it.
> **Status: BROKEN by a NEW rule (R23.2 / D-L15). This is the most consequential near-cycle P0-05 closes, because the inherited design had it open.**

> ### **NCY-3 — THE VALIDATOR LOOP (OR-L2).**
> A learning-rule diff (V3.1 §7, CH-3) alters the rules ⟹ the rules determine how the *next* diff is validated ⟹ the validation instrument is altered by what it validates.
> **A genuine closed loop at the highest altitude, and it CANNOT be broken architecturally** — any validator is either fixed (and therefore arbitrary, a governance choice) or evolvable (and therefore subject to the loop).
> **Contained by R24.3: a FIXED, NON-EMPTY validation core outside the evolvable set, plus a rate limit, plus the invariant kernel's non-evolvability (Rule 19 of the 20).**
> **Status: CONTAINED, NOT BROKEN. ⟹ The containment requires a governance decision that P0-05 cannot make: *what goes in the core.* P0-05 requires that the core exist and be non-empty; specifying its contents would be specifying the organism's values, which is outside an architecture contract's competence. OR-L2, declared in §81, reported in §86's EVOLUTION and OPEN-RESEARCH status.**

## 71.4 The acyclicity result

> ### **R71.1 — THE PARAMETER DEPENDENCY GRAPH IS ACYCLIC OVER ALL QUANTITIES THE LEARNING SUBSYSTEM MAY WRITE.**
> Three near-cycles exist. **All three pass exclusively through quantities the learning subsystem may NOT write** (`plasticity_mult` ⟶ K; `confidence_in_error`'s calibration ⟶ external class-7 measurement; the validation core ⟶ `[RO-13]`/KC). **⟹ The cycles are broken by the two-writer split (R54.2, INV-07) and by R19.2's governance/state separation, not by any bound.**
> **This is the deepest structural result of P0-05: *the architecture's circular dependencies are all resolved by writer separation rather than by magnitude limits.* A bound cannot break a cycle — it can only make the cycle smaller. Only a writer separation can break one.**
> **Corollary (§87: do not hide unclosable circular dependencies): NCY-3 is NOT resolved by writer separation alone, because the writer of the core is a governance authority whose *choices* the organism's findings can influence (R65.2 residual 2). It is contained, and the containment is declared.**

---

# 72. **[O56] IMPLEMENTATION INDEPENDENCE

§87: **DO NOT implement.** §72 states what that means precisely, and audits the contract for implementation leakage.

## 72.1 What this contract specifies, and what it does not

| Specifies | Does NOT specify |
|---|---|
| **What objects exist** (`LearnedChange`, `SignalProvenance`, `Prediction`, `ExplorationGrant`, `ConsolidationNomination`, tombstone) | Any data structure, layout, encoding or storage engine |
| **What fields they have and who writes each** | Any serialisation format |
| **What transitions are admissible** (SM-1…SM-7) | Any scheduler, executor, thread model or concurrency primitive |
| **What invariants must hold** (LEARN-INV-01…42) | Any proof assistant, type system or runtime checker |
| **What quantities are bounded and by whom** (B1–B9) | **Any numerical value for any bound** |
| **What is observable** (22 counter families) | Any monitoring stack, telemetry format or dashboard |
| **What authority each operation requires** (§28 matrix, §29 ladder) | Any permission system, capability implementation or access-control mechanism |
| **What does not exist** (20 `[∅]` parameters) | Any language-level encoding of the absence |

## 72.2 The three implementation-neutrality tests

> ### **R72.1 — SUBSTRATE NEUTRALITY.** Every rule in this contract is expressible over **any** substrate that supports (i) addressable mutable state, (ii) a distinguished write-authority partition, (iii) discrete epochs, and (iv) an external signed evaluation channel. **Nothing requires gradients, backpropagation, neural networks, tensors, differentiability, a loss function, or a specific learning algorithm.**
> **⟹ Specifically: `Δθ = clip(plasticity_mult × lr × trace × error × confidence, ±Δ_MAX)` (Cell §9.4) is inherited as a *shape*, not as a mandate.** A symbolic, evolutionary, Bayesian, reinforcement, Hebbian, or non-differentiable implementation satisfies this contract equally, provided it produces `LearnedChange` records, respects the matrix and ladder, consumes the budgets, and submits to external probes. **The contract constrains the governance of change, not the mathematics of change.**

> ### **R72.2 — ALGORITHM NEUTRALITY.** No rule names an algorithm. `attribution_method ∈ {TD, CAUSAL_ABLATION, EPISODIC_REPLAY, COUNTERFACTUAL}` (param 35) is inherited from P0-01 as a **declared choice among regimes**, not as an implementation of any of them. **⟹ CR-A (correlational) does not require TD learning; CR-B (ablative) does not require a specific counterfactual estimator.** The contract requires that the *regime* be declared and that the regime's *authority consequence* (R6.4.2: CR-B mandatory at E3+) hold.

> ### **R72.3 — SCALE NEUTRALITY.** No rule assumes a component count. R52.3's ≈168 accounting quantities are **`O(1)` per organism** regardless of N, which is the point (R35.1, R35.5). **⟹ The contract is stated for N = 10² and N = 10⁹ identically.** What changes with N is the *pressure* on B9 (probe budget), and R47.1 makes that pressure explicit rather than absorbing it into a constant.

## 72.3 Implementation-leakage audit

| Candidate leak | Present? | Ruling |
|---|---|---|
| Numerical bound values | ❌ **None.** 58 registered parameters, **0 values** (§70.9) | ✓ Clean |
| Named algorithms | ❌ | ✓ Clean |
| Data structures / encodings | ❌ | ✓ Clean |
| Concurrency model | ❌ — "serialisation" (R16.3) is an ordering requirement, not a mechanism | ✓ Clean |
| Hardware assumptions | ❌ — §77 audits portability explicitly | ✓ Clean |
| Gradient/differentiability assumptions | ⚠️ **Cell §9.4's `Δθ` formula is quoted as inherited.** | **⟹ R72.4: the formula is quoted as the *inherited instance* of a bounded-update shape, and R72.1 explicitly does not mandate it.** Flagged here rather than left implicit. |
| "Neural" vocabulary | ⚠️ V3's "synapse", "circuit", "regional" are anatomical. | **⟹ R72.5: anatomical terms are retained as SCOPE NAMES (S1–S6) because they are inherited and renaming them would break traceability to V3/V3.1/P0-03. They carry no architectural commitment.** Rule 5 of the 20 (no biological metaphors as mechanism substitutes) is satisfied because **every scope has an operational definition by blast radius (R4.2), not by anatomy.** |
| Probe implementation | ⚠️ "held-out external probe" is required but not specified. | **⟹ Declared as OR-L1/OR-L3. The contract requires that a probe be external, held-out, signed, and independent of the driving signals (R22.2). It does not require a specific probe design — and at Λ3 it cannot supply one (OR-L3).** |

> ### **R72.6 — THE CONTRACT IS IMPLEMENTATION-INDEPENDENT, WITH TWO DECLARED EXCEPTIONS.**
> **(1)** It inherits Cell §9.4's `Δθ` formula as a *shape*, and R72.1 states that the shape is not mandated. **(2)** It requires a probe mechanism it cannot fully specify (OR-L1, OR-L3). **Both are declared rather than hidden, per §87.**
> **Everything else — 42 invariants, 7 state machines, 58 registered parameters, 20 prohibited parameters, 70 attacks, 9 budget classes, 6 scopes, 5 change classes, 9 escalation rungs, 14 signal kinds, 5 signal classes, 8 reward kinds — is stated without reference to any implementation.**

---

## 72.7 VOLUME E — FINDINGS REGISTER

| ID | Finding | Severity | Disposition |
|---|---|---|---|
| **D-L83** | **`behavioural_reach` declared per change misses the aggregate**: many `LOCAL`-reach changes can sum to `ORGANISM_OUTPUTS`. | **HIGH** | **CLOSED by R67.1** (reach aggregated per scope over a window). |
| **D-L84** | **Stall evasion by scope-hopping** to a disjoint lower-scope target. | **MEDIUM** | **CONDITIONAL — R67.2.** Writing to a genuinely disjoint target at a lower scope is *correct*, not an evasion. Recorded CONDITIONAL for honesty. |
| **D-L85** | **NCY-2, the calibration loop, is OPEN in the inherited design.** T8 writes a multiplicative gain on all other triggers with no rule connecting it to a budget. | **CRITICAL** | **CLOSED by R23.2 / LEARN-INV-18 / LEARN-D4.** **The most consequential near-cycle P0-05 closes.** |
| **D-L86** | **NCY-3, the validator loop, cannot be broken architecturally.** | **CRITICAL — UNCLOSED** | **CONTAINED by R24.3's fixed core + rate limit + non-evolvable invariant kernel. OR-L2.** The core's contents are a governance decision outside an architecture contract's competence. |
| **D-L87** | **SM-5 requires a `VERIFIED_CR_B` transition at circuit level with no specified probe design.** | **HIGH — UNCLOSED** | **DECLARED IN-PLACE in SM-5. OR-L3.** |
| **D-L88** | **SM-6 can detect a cascade but cannot evaluate whether the reduced engagement was correct.** | **HIGH — UNCLOSED** | **DECLARED IN-PLACE in SM-6. OR-L5.** Permanent asymmetry (§40.3). |
| **D-L89** | **The catalogue has ZERO detection-only dispositions.** | — | **A design property, not a gap.** Every detection rule is paired with a bounding rule (§67.9 note). Labelling an attack "detectable" is the most common way of hiding one. |
| **D-L90** | **Exactly ONE attack of seventy is OPEN.** | — | **LEARN-C2 / RH-2 / OR-L6.** §86 reports SECURITY, EVOLUTION and OPEN-RESEARCH against this single entry. |

---

**END OF VOLUME E.**
**Next:** `45_analysis_audit_scale.md` — Vol F (§73–§82): candidate learning architectures compared, the cross-system contradiction audit (**[O54]**), the circular dependency audit (**[O50]**), scalability (**[O51]**), hardware portability (**[O52]**), conformance and testability (**[O55]**), ablation (**[O53]**), the false-precision audit, the open research register (**[O58]**), and the P0/P1/P2 gap list (**[O57]**).
