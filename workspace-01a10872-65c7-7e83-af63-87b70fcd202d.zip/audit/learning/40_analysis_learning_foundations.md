# P0-05 — LEARNING, PLASTICITY & ADAPTATION CONTRACT
## Volume A — Foundations, the Change Object, and the Signal Economy (§0–§18)

**Status:** adversarial architecture audit. **Architecture only — no implementation, no code, no executable system, no deployment plan, no training implementation, no numerical parameter values.**
**Inherits:** V3 (§8, §14, §15, §18, master loop), V3.1 (§6, §7, §8, §9, §10), Cell Contract §9 (the most complete inherited learning specification), P0-01 §12–§16 (reward/error/fitness), P0-02 (EIK), P0-03 (communication), P0-04 (memory & evidence).
**Discipline applied throughout:** §87 of the brief. Every rule states origin, authority, scope, reversibility, provenance and consequences. Every parameter is registered with `[G]/[D]/[X]/[U]/[RO-n]` and **no value is invented.**

> **Outputs discharged by this volume:** O2 (learning definition), O3 (plasticity definition), O4 (adaptation definition), O5 (learning taxonomy), O6 (plasticity hierarchy), O7 (learning-loop architecture), O9 (reward taxonomy), O10 (reward↔fitness), O11 (reward↔memory), O12 (reward↔belief), O13 (prediction-error architecture), O14 (novelty/surprise), O15 (credit assignment), O22 (homeostatic plasticity).
> **Outputs partially discharged, completed in Vol B:** O8 (signal taxonomy → §19).

---

# 0. THE ROOT FINDING

## 0.1 What the inherited design already gets right

The Cell Contract §9 is, by a wide margin, the most rigorous learning specification in the corpus. It already establishes four rules that most architectures never reach:

| Inherited rule | Source | Why it is strong |
|---|---|---|
| A cell may not generate its own reward; only EIK/EVA-signed `eval.reward.v1` is a learning signal | Cell §9.2 T2; P0-01 R12.1 | Closes reward forgery at the **type level** |
| A peer's `REPORT_ERROR` is evidence, not instruction | Cell §10.3 | Separates *claim* from *learning signal* |
| A cell may not decide whether its own learning helped: `improvement_verified ∈ {UNKNOWN, IMPROVED, NEUTRAL, REGRESSED}` is **K-only**, on a **held-out external probe**; REGRESSED ⟹ automatic rollback; UNKNOWN ⟹ PROVISIONAL, excluded from replication credit | Cell §9.6 | The single most important anti-self-deception mechanism in the corpus |
| Internal error estimates may drive **provisional** learning only — rate-limited, tagged, rollback-able — and may **never** drive permanent learning, fitness, replication gates or retirement | P0-01 §13.2 | The learning analogue of P0-04's R0.2 admission principle |

These four are correct and are inherited unchanged. **This audit does not attack them. It attacks what is missing around them.**

## 0.2 The defect: "provisional" is an accounting label, not an effect label

Cell §9.6 gives a change two properties that the rest of the corpus conflates and never separates:

- **`improvement_verified`** — an *accounting* verdict: may this change be credited in fitness, in replication gates, in selection?
- **`PROVISIONAL` status** — a *label* attached to the change while the verdict is `UNKNOWN`.

Now read Cell §9.4. A provisional change has **already been applied**. `Δθ = clip(plasticity_mult × lr[timescale] × eligibility_trace × error_signal × confidence_in_error, ±Δ_MAX)` is computed, clipped and **written to θ**. The four bounds (`Δ_MAX`, per-epoch `DELTA_BUDGET`, `Θ_MAX`, mandatory homeostatic scaling) all constrain **magnitude**. None of them constrains **consequence**.

> ### **[ROOT FINDING] A PROVISIONAL CHANGE IS A FULLY APPLIED CHANGE. THE PROVISIONAL/PERMANENT DISTINCTION GOVERNS REPLICATION CREDIT AND FITNESS — IT DOES NOT GOVERN EFFECT.**

Three consequences, in ascending severity:

**(a) Provisional changes affect behaviour immediately and fully.** A θ that has moved by `Δ_MAX` produces different predictions, different actions, different communications and different retrieval queries **regardless of whether its benefit has been verified.** The organism does not behave "provisionally." It behaves as though the change were permanent, while recording it as though it were not.

**(b) Provisional changes become the substrate for the next update.** `eligibility_trace` and `error_signal` in the very next epoch are computed **against the modified θ**. Learning is therefore not a sequence of independent provisional trials; it is a **random walk on an unverified substrate**. Each step is bounded; the walk is not.

**(c) `DELTA_BUDGET` IS A RATE LIMIT, NOT A DISTANCE LIMIT.** Per Cell §9.4, `DELTA_BUDGET` bounds `‖ΣΔθ‖` **per epoch**. Across epochs, provisional changes accumulate without bound: epoch 1 spends its budget, epoch 2 spends its budget, and if the probe never resolves, **no epoch ever resets the accounting.** After *k* epochs the organism may sit arbitrarily far from its last externally-verified state, having violated nothing.

> ### **[D-L1] UNVERIFIED DRIFT.** A per-epoch parameter budget bounds the **rate** of learning but not the **cumulative distance from the last externally verified state.** An organism can migrate indefinitely far from any state that has ever been confirmed to work, one compliant epoch at a time. **No inherited mechanism detects this**, because every individual epoch is inside budget and `improvement_verified = UNKNOWN` is a *permitted* verdict, not an alarm.

This is the learning-system analogue of two defects this audit series has already found:

| Series finding | Pattern |
|---|---|
| P0-04 X3 — repetition mistaken for accumulation of independent evidence | **Many compliant events, no aggregate bound** |
| P0-03 — influence-plane parameters learnable without a ceiling on cumulative gain drift | **Many compliant events, no aggregate bound** |
| **P0-05 D-L1 — provisional learning accumulates without a verified-state anchor** | **Many compliant events, no aggregate bound** |

It is the same defect class three times. P0-05 is where it becomes unavoidable, because learning is the only subsystem whose *entire purpose* is to accumulate change.

## 0.3 Why the inherited fix does not exist

Cell §9.6 records the honest problem:

> `[U]` **Probe frequency / cost trade-off.** Probing every update at 10⁶ cells is infeasible; probing rarely lets bad updates persist.

The inherited design correctly identified that verification is expensive and left the policy **UNRESOLVED**. That is disciplined. But it means the architecture has an **open loop**: the only mechanism that can convert PROVISIONAL → VERIFIED is a probe whose frequency is undefined, and the only mechanism that can halt unverified accumulation (`DELTA_BUDGET`) resets every epoch and therefore never halts it.

**⟹ At any scale where probing is infeasible for most updates — which is the scale this architecture is designed for — the DEFAULT verdict is `UNKNOWN`, and the DEFAULT state of every learned change is PROVISIONAL, permanently.** The provisional/permanent distinction, which Cell §9.6 presents as a safety mechanism, degenerates into a permanent label on a change that is permanently applied.

## 0.4 The correction (stated here, specified in §1, §62–§64, §68)

> ### **[V4] R0.1 — THE UNVERIFIED-DISPLACEMENT BOUND (UDB).**
> A learned state has **two** magnitudes, and both MUST be bounded:
> 1. **PARAMETER MAGNITUDE** — `‖Δθ‖` per update and per epoch. *(inherited: `Δ_MAX`, `DELTA_BUDGET`, `Θ_MAX`)*
> 2. **UNVERIFIED DISPLACEMENT** — `‖θ_now − θ_anchor‖`, where **`θ_anchor` is the most recent state whose `improvement_verified` verdict is `IMPROVED` or `NEUTRAL`** (never `UNKNOWN`, never `REGRESSED`).
>
> **When `‖θ_now − θ_anchor‖ ≥ UNVERIFIED_DISPLACEMENT_MAX[tier]`, learning STALLS.** Not slows — **stalls**. No further θ writes are admitted at that scope until a probe resolves and re-anchors.
>
> **Origin:** kernel-computed from checkpoint lineage. **Authority:** K (non-delegable; a cell cannot re-anchor itself). **Scope:** per learning scope (§18). **Reversibility:** the stall is itself reversible (a probe lifts it). **Provenance:** the anchor carries the `probe_id` and `evaluator_id` that verified it. **Consequence:** a system that cannot afford probes **learns less** — visibly, and by construction.

**This is the single most important rule in P0-05**, and it has a property worth stating plainly:

> ### **R0.1 CONVERTS Cell §9.6's `[U]` FROM AN UNRESOLVED COST TRADE-OFF INTO A LOAD-BEARING ARCHITECTURAL QUANTITY. THE PROBE BUDGET NO LONGER SILENTLY DETERMINES *WHAT FRACTION OF UPDATES GET CHECKED*; IT EXPLICITLY DETERMINES *HOW FAST THE ORGANISM MAY LEARN*.**

That is the correct resolution of an `[U]`. The architecture does not invent a probe frequency. It makes the **absence** of probing produce a **visible, structural consequence** (stall) instead of an **invisible, statistical one** (unbounded unverified drift). Per §87: *do not solve unknown research problems through arbitrary constants.* R0.1 solves nothing by constant — it relocates the unknown from a hidden parameter into an explicit, observable trade-off owned by `[G]`.

## 0.5 The second correction: four axes, not one

P0-04's root finding was that memory had been modelled on **one** axis (time/persistence) where **four** were required. P0-05 has the same shape.

The inherited corpus describes a learned change by **one** axis: *magnitude* (`Δ_MAX`, `DELTA_BUDGET`, `Θ_MAX`, `plasticity_mult`). Everything else — who authorised it, whether it was verified, whether it can be undone — is scattered across Cell §9.3's target table, §9.6's verdict enum, P0-01 §13.2's provisional/permanent split and P0-03's COMM-INV-23, **with no unifying object**. There is no first-class entity in V3, V3.1, the Cell Contract, P0-01, P0-03 or P0-04 that represents *a learned change* as a governed thing.

> ### **[V4] R0.2 — THE `LearnedChange` OBJECT.** Every persistent modification to the organism's internal state is represented by a single governed record with **four orthogonal axes**. No change may be applied without one.

| Axis | Question it answers | Values | Inherited status |
|---|---|---|---|
| **A1 — TARGET** | *What* was modified | `Λ0 TRANSIENT` · `Λ1 PARAMETER` · `Λ2 REPRESENTATION` · `Λ3 STRUCTURAL` · `Λ4 POLICY/META` · **`Λ5 GENOME` (∅ — no write path)** | Partial: Cell §9.3's ✅/❌ table, V3.1 §6's five scales |
| **A2 — AUTHORIZATION** | *Who* permitted it | `SELF_LOCAL` · `CIRCUIT` · `ORGANISM` · `POLICY(RO-n)` · `EIK` · `KC` | Partial: Cell §9.3, §3.5's 11 replication gates |
| **A3 — PROVISIONALITY** | Has its benefit been **externally** verified | `PROVISIONAL` · `VERIFIED_IMPROVED` · `VERIFIED_NEUTRAL` · `VERIFIED_REGRESSED` ⟹ rolled back | Partial: Cell §9.6's verdict enum — **but not connected to effect (§0.2)** |
| **A4 — REVERSIBILITY** | Can it be undone, and from where | `DECAYS` · `ROLLBACKABLE_IN_MEMORY` · `CHECKPOINT_REVERSIBLE` · `VERSION_REVERSIBLE` · `IRREVERSIBLE_STRUCTURAL` | **ABSENT.** No inherited rule states reversibility as a property of a change |

**A4 is the genuinely missing axis, and it is the one that determines authority.** The escalation rule of this entire contract is:

> ### **R0.3 — AUTHORIZATION SCALES WITH IRREVERSIBILITY, NOT WITH MAGNITUDE.**
> `required_authority(change) = f(A4_reversibility, A1_blast_radius)` — **never** `f(‖Δθ‖)`.
> A change of `Δ_MAX` to a single connection weight (`ROLLBACKABLE_IN_MEMORY`, blast radius 1) requires `SELF_LOCAL`. A change of `Δ_MIN` that removes a connection (`IRREVERSIBLE_STRUCTURAL`, blast radius = the circuit) requires `ORGANISM` or higher. **Magnitude is a rate question. Irreversibility is an authority question. The inherited design conflates them: `DELTA_BUDGET` bounds a weight edit and a topology edit with the same instrument.**

R0.3 is why §61 (structural escalation) exists and why the brief's §21 is answerable at all: **there is no escalation ladder in the inherited corpus because there is no reversibility axis to escalate along.**

## 0.6 What this volume does NOT claim

- It does **not** claim R0.1 makes learning safe. It makes unverified drift **bounded and visible**. A stalled learner can still be a wrong learner.
- It does **not** claim R0.1's `UNVERIFIED_DISPLACEMENT_MAX` is known. It is `[G]` with `[D]` dependency on the cost model (P0-10). **No value is given.**
- It does **not** resolve the probe-cost `[U]`. It **relocates** it: from "what fraction of updates get checked" (hidden, statistical) to "how much unverified displacement the organism tolerates before stalling" (explicit, structural, observable). The research problem — how to verify cheaply — remains open as **OR-L1**.
- It does **not** claim prediction error is causality, reward is truth, repetition is independence, or memory is ground truth. §14, §10, §12 and §11 respectively close those doors.

---

# 1. THE `LearnedChange` RECORD — NORMATIVE

## 1.1 Schema

```
LearnedChange {
  change_id        : bytes<16>
  epoch            : u64                       // ⟵ EIK-INV-14 epoch binding (defeats replay)
  scope_id         : ScopeID                   // §18 — the scale this change operates at
  trigger          : enum{T1..T8}              // Cell §9.2 — CLOSED set
  signal_ref       : {signal_id, signal_class} // §19 taxonomy; PROVENANCE MANDATORY

  // ── A1 TARGET ─────────────────────────────────────────────────────
  target           : enum{Λ0_TRANSIENT, Λ1_PARAMETER, Λ2_REPRESENTATION,
                          Λ3_STRUCTURAL, Λ4_POLICY}   // Λ5_GENOME ∉ enum (§1.2)
  target_ref       : {param_id | record_id | connection_id | policy_id}
  delta            : {kind, magnitude_norm}     // magnitude_norm: f64, NO SIGN-OF-TRUTH

  // ── A2 AUTHORIZATION ──────────────────────────────────────────────
  authorized_by    : enum{SELF_LOCAL, CIRCUIT, ORGANISM, POLICY, EIK, KC}
  authorization_ref: bytes<64>                  // signature or policy-id; MANDATORY for A2≥ORGANISM
  blast_radius     : enum{SELF, CONNECTION, CIRCUIT, REGION, ORGANISM, POPULATION}

  // ── A3 PROVISIONALITY ─────────────────────────────────────────────
  provisional      : bool                       // TRUE until verdict resolves
  verdict          : enum{UNKNOWN, IMPROVED, NEUTRAL, REGRESSED}   // Cell §9.6, K-ONLY
  probe_ref        : {probe_id, evaluator_id, evaluator_version}   // NULL ⟹ verdict=UNKNOWN
  anchored_at      : checkpoint_id | NULL       // ⟵ R0.1's θ_anchor lineage

  // ── A4 REVERSIBILITY ──────────────────────────────────────────────
  reversibility    : enum{DECAYS, ROLLBACKABLE_IN_MEMORY, CHECKPOINT_REVERSIBLE,
                          VERSION_REVERSIBLE, IRREVERSIBLE_STRUCTURAL}
  rollback_handle  : handle | NULL              // MANDATORY iff reversibility ≠ IRREVERSIBLE
  superseded_by    : change_id | NULL           // lineage (§64)

  // ── CONSEQUENCE LEDGER (§63, §64) ─────────────────────────────────
  effect_envelope  : {behavioural_reach, comm_reach, mem_reach}   // §2.3
  cumulative_udb   : f64                        // R0.1 — kernel-computed, NOT self-reported
  audit            : {created_by, signature}    // the change's own provenance
}
```

**Field-level rulings:**

| Field | Ruling | Reason |
|---|---|---|---|
| `target` | **`Λ5_GENOME` is not in the enum.** Its absence is the mechanism. | Cell §3.4, MEM-INV-18/21, P0-04 R47.1 (Lamarckian prohibition). An enum value that cannot be constructed cannot be written. |
| `delta.magnitude_norm` | **Unsigned.** No field carries "how good" the change was. | A change carrying its own credit is a reward-hacking channel — COMM-INV-20, P0-03 #48. |
| `verdict` | **K-only writer.** A cell writing its own verdict is an I-class violation. | Cell §9.6. Self-assessment of improvement is structurally impossible. |
| `probe_ref = NULL ⟹ verdict = UNKNOWN` | **Implication, not policy.** No code path can produce a verdict without a probe. | Closes "assume verified" by construction. |
| `anchored_at` | **Mandatory for Λ1/Λ3/Λ4.** | R0.1 requires anchor lineage to compute UDB. A change with no anchor is **inadmissible**, not merely unanchored. |
| `rollback_handle` | **Mandatory iff `reversibility ≠ IRREVERSIBLE_STRUCTURAL`.** A change without a rollback handle that is not irreversible is **rejected at admission**. | R0.3. Irreversibility is what escalates authority; pretending to reversibility without a handle is the exploit. |
| `cumulative_udb` | **Kernel-computed. Never self-reported.** | A self-reported UDB is a self-assessed improvement in disguise. |
| `effect_envelope` | **Declared at admission, verified by observation (§2.3).** | The missing link between "provisional" and "applied". |

## 1.2 The `Λ5_GENOME` prohibition, stated three ways

Per §87 (*do not allow lifetime learning to silently become genome*), the prohibition is enforced at three independent layers, because one layer can be mis-specified:

1. **Type layer.** `Λ5_GENOME ∉ target.enum`. There is no construction.
2. **Writer layer.** The genome has exactly one writer class: the **evolutionary/replication subsystem under the 11 gates** (Cell §3.5). The learning subsystem holds no capability for it. This is `RO-13`-class: not a rule the learner is asked to obey, but a permission it does not have.
3. **Pathway layer.** The **only** permitted influence of learning on inheritance is the Baldwinian channel (Cell §3.4/§3.5, V3.1 §8, MEM-INV-21): learning produces a **genome-diff proposal** that carries **no** source_class (OR-M12), is **gated** by all 11 replication gates plus held-out validation, and if accepted enters the genome as an **initialisation distribution** (`θ₀ ~ param_init`) — **never as a learned value.** A proposal is a *nomination*, exactly as consolidation is a nomination in P0-04 R0.2. **Nomination ≠ promotion**, at both altitudes.

> **Consequence of the three layers:** a Lamarckian write requires simultaneously (a) constructing an impossible enum value, (b) holding a capability the subsystem does not have, and (c) bypassing a gate that is machine-checkable against an explicit rejection list. This is **not** a "strongly discouraged" rule. It is a rule with no compliant violating path.

## 1.3 The `effect_envelope` — closing §0.2(a)

R0.1 bounds cumulative *parameter* displacement. It does not bound cumulative *behavioural* consequence, and §0.2(a) showed the consequence is what matters. The `effect_envelope` is the mechanism:

```
effect_envelope {
  behavioural_reach : enum{NONE, SELF_ONLY, LOCAL_OUTPUTS, CIRCUIT_OUTPUTS, ORGANISM_OUTPUTS}
  comm_reach        : enum{NONE, INFLUENCE_ONLY, WARRANT_AFFECTING}   // ⟵ WARRANT_AFFECTING = ∅ (§1.4)
  mem_reach         : enum{NONE, T0_T1_LOCAL, T2_PLUS_SHARED}          // ⟵ binds X-L1 (§74)
}
```

**R1.3 — ENVELOPE SHRINKAGE.** A `PROVISIONAL` change's envelope **shrinks with its unverified age**, in discrete steps owned by `[G]`:

`PROVISIONAL` at admission ⟹ full envelope ⟹ after `PROVISIONAL_AGE_1` without verdict ⟹ envelope reduced to `LOCAL` ⟹ after `PROVISIONAL_AGE_2` ⟹ envelope reduced to `NONE` **and the change is flagged for rollback review** ⟹ after `PROVISIONAL_AGE_3` ⟹ **automatic rollback** (the same automatic action Cell §9.6 already mandates for `REGRESSED`, extended to *never-verified*).

**Why this is not merely "expire stale updates."** Cell §9.6's `[U]` treated probing as a *cost*. R1.3 treats **unverified age as a risk that is paid down by reduced authority** — the exact structural move P0-04 §91 made with its degradation ladder ("no failure mode produces a warrant increase"). Here: **no unverified change produces an effect increase.** Same principle, learning altitude.

`PROVISIONAL_AGE_{1,2,3}` are `[G]` with `[D]` on the probe-cost model (P0-10). **No values.** Their ordering is normative and kernel-enforced (`AGE_1 < AGE_2 < AGE_3`), in the same way Cell §9.4 kernel-enforces `lr_fast ≥ lr_medium ≥ lr_slow`.

## 1.4 One envelope value that is structurally empty

> ### **R1.4 — `comm_reach = WARRANT_AFFECTING` IS THE EMPTY SET.**
> No learned change may alter the warrant class, evidence status, root commitment, causal depth or signature of any message or memory record.
> **This is not a P0-05 rule that happens to agree with P0-03 and P0-04. It is COMM-INV-08, COMM-INV-25, MEM-INV-19 and MEM-INV-50 restated at the learning altitude, and it is included here because the learning subsystem is the only subsystem with a *motive* to violate it.** Transport, warrant and influence are planes; learning lives on influence. A learner that could reach the warrant plane would not need to hack reward — it would simply reclassify its own evidence.

Note what R1.4 does **not** say: it does not forbid learning from changing *how much a warrant is used*. `context_sensitivity`, `gain`, `routing_preference` and `eligibility_trace` are learnable (P0-03 R3.2, COMM-INV-23/24) and a high-warrant message may therefore be routed more or less. **Influence over the *use* of a warrant is permitted; influence over the *value* of a warrant is not.** That distinction is the whole content of COMM-INV-25, and §53–§54 audit whether the inherited design actually holds it.

---

# 2. WHAT "LEARNING" MEANS — CANDIDATE DEFINITIONS COMPARED (§3 of brief)

Per §87: **DO NOT ASSUME "LEARNING."** Nine candidate meanings are compared before one is adopted. The comparison is not decorative — several of the rejected candidates are what V3's text actually says, and §2.4 shows where.

| # | Candidate definition | Formal shape | Adopted? | Reason |
|---|---|---|---|---|
| **C1** | **Weight adjustment** | `θ ← θ + Δθ` | ❌ Too narrow | Excludes structural plasticity (V3 L54 "create/reroute/prune"), memory-policy adaptation, and the entire Λ2/Λ3/Λ4 range. V3.1 §6 explicitly has five scales; C1 covers one. |
| **C2** | **Any change of internal state over time** | `s_{t+1} ≠ s_t` | ❌ **Fatally broad** | Includes transient activation, noise, thermal drift, message buffering, decay. If everything is learning, nothing is governed. **This is the "catch-all" §87 forbids.** |
| **C3** | **Improvement in performance** | `perf_{t+1} > perf_t` | ❌ **Circular and self-serving** | "Improvement" is measured by the organism's own performance estimate ⟹ P0-01 §15's self-reference attack. Also false: **learning can and must sometimes reduce measured performance** (safe exploration, abstention, de-specialisation). C3 makes those failures by definition. |
| **C4** | **Acquisition of knowledge** | `KNOWS(o, φ)_{t+1} ∧ ¬KNOWS(o, φ)_t` | ❌ **Violates P0-04 directly** | `KNOWS` requires `evidence_status ≥ S3` and an external gate (P0-04 §22, R0.2). Learning **cannot** produce knowledge. What learning produces is *belief change within a fixed evidence status* — MEM-INV-18. C4 would make every learned change an epistemic promotion. |
| **C5** | **Statistical inference from data** | posterior update | ⚠️ **Partial — necessary, not sufficient** | Correct for Λ1 parameter learning on external data. **Wrong for Λ4** (changing the inference procedure is not inference) and **wrong for self-generated data** (§48: model collapse is statistical inference proceeding perfectly on a degenerating sample). |
| **C6** | **Adaptation to environment** | fit(o, env) increases | ❌ **Conflates learning with adaptation** | This is the brief's §4 distinction, and collapsing it is the inherited design's error. Adaptation includes homeostasis, reflex, and evolution — none of which is learning. Also: "fit to environment" is exactly the scalar V3.1 §9 selection score that P0-01 §14 rejected. |
| **C7** | **Behaviour change driven by experience** | `Δbehaviour ← experience` | ⚠️ **Partial — right direction, missing governance** | Correctly excludes C2's noise (experience-driven, not arbitrary). But "experience" is unqualified: is a self-generated simulation experience? Is a peer's `REPORT_ERROR` experience? Is retrieved memory experience? **Each of these is a different authority**, and C7 assigns them all the same one. |
| **C8** | **Compression / prediction improvement** | `H(future \| model)` decreases | ❌ **Predictive success ≠ correctness** | §87: *do not assume a learned model is correct because it predicts well.* A model that predicts a **manipulated** environment perfectly has maximally compressed and is maximally wrong. This is CD-M8/M9 (OR-M18) wearing a compression costume. |
| **C9** | **Bounded, gated, reversible, externally-anchored modification of internal parameters, representations, structure or policy, driven by admissible signals, whose benefit is verified outside the modifying subsystem** | the `LearnedChange` object | ✅ **ADOPTED** | The only candidate that survives P0-01 §13.2, P0-04 R0.2/MEM-INV-18, COMM-INV-25 and Cell §9.6 simultaneously. |

## 2.1 **[O2] DEFINITION — LEARNING (V4, normative)**

> ### **LEARNING** is the production of a `LearnedChange`: a **bounded** (R0.1, Cell §9.4's four bounds), **gated** (Cell §9.2's closed trigger set T1–T8; A2 authorization), **reversible** (A4; R0.3), **externally anchored** (R0.1's `θ_anchor`; P0-01 §13.2's external demonstration) modification of internal **parameters, representations, structure or policy** (A1: Λ0–Λ4), driven by **admissible signals** (§19), whose **benefit is verified outside the modifying subsystem** (A3; Cell §9.6).
>
> **Learning is NOT:** knowledge acquisition (C4), performance improvement (C3), state change (C2), or successful prediction (C8). **Learning produces belief change at fixed evidence status** (MEM-INV-18) **and behavioural capability whose value is not self-assessed** (Cell §9.6).

**Every clause is load-bearing.** Remove "bounded" ⟹ D-L1. Remove "gated" ⟹ any internal state becomes a trigger (§19). Remove "reversible" ⟹ R0.3 has no argument. Remove "externally anchored" ⟹ R0.1 has no anchor. Remove "benefit verified outside" ⟹ C3's circularity returns.

## 2.2 **[O3] DEFINITION — PLASTICITY (V4, normative)**

Plasticity is **not** learning. It is the *permission and the capacity* to change.

> ### **PLASTICITY** is the **admissible change capacity** of a component: the set of `LearnedChange` targets that component may admit, together with the bounds on their magnitude, the rate at which they may occur, and the conditions under which the capacity itself is increased or withdrawn.
>
> Formally: `plasticity(component) = ⟨ admissible_targets ⊆ {Λ0..Λ4}, Δ_MAX, DELTA_BUDGET, plasticity_mult, gating_conditions ⟩`.

Three properties that separate plasticity from learning:

| | **LEARNING** | **PLASTICITY** |
|---|---|---|
| **Is it an event or a capacity?** | An **event** — a `LearnedChange` was produced | A **capacity** — what changes *could* be admitted |
| **Can it be zero without the system being broken?** | Yes. A frozen system with `plasticity_mult = 0` is safe and functional. | **No.** Zero plasticity at every scale means the organism cannot adapt at all. |
| **Who governs it?** | The trigger set (T1–T8) and the signal authority (§19) | **The plasticity authorization matrix (§28)** — a governance artifact, not a learning event |
| **Dangerous direction** | Learning too much, too fast, on bad signals | **Plasticity being *granted* where it should not be** (§28: `plasticity_mult` is K-only in Cell §4.1.8 precisely because a cell that can raise its own plasticity can raise its own learning rate) |

> **This distinction is the reason §28 exists.** The inherited design governs *learning events* thoroughly (Cell §9.2's eight triggers, §9.4's four bounds) and governs *plasticity capacity* in exactly one place — Cell §4.1.8's "`plasticity_multiplier` K-only". One rule. No matrix. No account of which components at which scales may hold which capacities, or of how a capacity is granted, reduced or withdrawn. **That is the largest single governance gap in the inherited learning design**, and it is the gap through which every "learning system becomes hidden governance" attack in §67 passes.

## 2.3 **[O4] DEFINITION — ADAPTATION (V4, normative)**

Adaptation is the **superset**, and it is deliberately broader than learning.

> ### **ADAPTATION** is any process by which the organism's behaviour becomes better matched to its current conditions. It partitions into **four mechanisms with different authorities, timescales and inheritance properties**, and **only one of them is learning.**

| Mechanism | Timescale | Reversible? | Inherited? | Verified how? | Is it learning? |
|---|---|---|---|---|---|
| **A — HOMEOSTASIS** | immediate–minutes | Yes, automatically (set-point) | **No** | Set-point deviation, measurable | ❌ **NO.** No `LearnedChange` is produced; state returns to a *pre-existing* value. |
| **B — REFLEX / FAST STATE** | milliseconds–seconds | Yes (`DECAYS`) | **No** | None required | ❌ **NO.** Λ0 transient state. No persistent change, no verification obligation. |
| **C — LEARNING** | seconds–lifetime | Conditionally (A4) | **No** | **External probe (Cell §9.6); R0.1 anchor** | ✅ **YES.** |
| **D — EVOLUTION** | generations | **No** (within a lineage) | **Yes** | **Selection under the 11 gates + held-out validation** | ❌ **NO.** MEM-INV-21, Cell §3.4. |

> ### **R2.3 — THE ADAPTATION PARTITION RULE.** Every adaptive mechanism MUST declare which of A/B/C/D it is, and MUST NOT borrow another's verification regime.
> - **Homeostasis may not claim a verification budget.** It has a set-point; it needs no probe.
> - **Reflex may not persist.** `DECAYS` is mandatory; a reflex that does not decay has become Λ1 learning *without a `LearnedChange` record* — an **ungoverned learning event**, which §67 attacks as LEARN-A1.
> - **Learning may not inherit.** (§1.2, three layers.)
> - **Evolution may not learn.** A genome-diff is not a `LearnedChange`; it does not consume `DELTA_BUDGET` or UDB. **Conflating them lets an organism accumulate evolutionary change at learning speed**, which is D-L1 with no anchor at all — the worst case.

**R2.3's fourth clause is the one that makes V3.1 §8's "learning → plasticity → evolution bridge" governable.** V3.1 §8 says the bridge is "deliberately gated" and Baldwinian but does not say what a crossing *is*, in accounting terms. R2.3 answers: **a bridge crossing is a change of mechanism class from C to D, and it therefore changes verification regime, timescale, reversibility and budget consumption — all at once, atomically, at a gate.** There is no state in which a change is "partly learning and partly evolution", because there is no shared budget for it to be partly drawn from.

## 2.4 Where V3's own text violates these definitions

The definitions above are not imposed on V3 from outside; V3's text is internally inconsistent with itself, and C2/C3/C6 are what it actually says in places.

| V3 / V3.1 text | Candidate it instantiates | Defect | V4 ruling |
|---|---|---|---|
| §8 «successful use → strengthen» | **C3** (improvement) | **"Whose success?"** If internally judged ⟹ reward hacking (§9). If externally judged ⟹ an EVA evaluation per synapse, and P0-03 already **rejected** `O(N)` per-reward-event broadcast as infeasible. | **"Successful" MUST resolve to an admissible signal (§19) with `signal_class` and provenance. An unsigned internal success judgement is NOT a T1/T2 trigger and produces no `LearnedChange`.** |
| §8 `usage_frequency` as a plasticity input | **C2/C6** | Usage frequency is a **demand** statistic. Using it to set plasticity is legitimate *allocation*. Using it to set **epistemic** weight is P0-04 §26.3's availability capture. V3 does not distinguish the two. | **`usage_frequency` MAY modulate `plasticity_mult` and pruning candidacy (allocation). It MAY NOT enter any warrant, confidence, belief or evidence computation. MEM-INV-50 restated.** |
| §8 `last-success timestamp` | — | **Same defect class as `last_verification`** (P0-04): a recency stamp that decays into apparent staleness and can be manufactured by producing *any* success. | **`last_success` MUST carry the `signal_ref` of the success it records. A timestamp without a referenced admissible signal is NULL, not stale.** |
| §8 «useful novelty → preserve» | **C6** | "Useful" is undefined and **novelty is adversarially manufacturable** (§15, and P0-04's own novelty analysis). A preserve-trigger keyed on manufactured novelty is a **resource-exhaustion channel**: keep the organism from ever pruning. | **Novelty ⟹ `SLOW_MODE` and *reduced* plasticity (Cell T5) ⟹ preservation by *inaction*, never by a positive `Δθ`.** "Preserve" is correct; "novelty strengthens" is not. §15 makes this precise. |
| §8 «persistent uselessness → prune» | **C6** | **Pruning is Λ3 structural and IRREVERSIBLE.** "Uselessness" is measured by disuse, and disuse is caused by low retrieval, which is caused by low availability. **⟹ Pruning by disuse is the synaptic form of P0-04 §26.3's survivorship bias — and unlike forgetting a memory, pruning a connection destroys the weight history with it.** | **§61: pruning requires `ORGANISM`+ authority, a **disuse-cause attribution** (was it unused because irrelevant, or unused because unreachable?), and it is **`IRREVERSIBLE_STRUCTURAL`** ⟹ R0.3 escalates it. Disuse alone is NEVER sufficient.** |
| §14 «Repeated successful exposure → stable integration» | **C3 + repetition** | **This is P0-04 X3 arriving in the learning system.** Repeated exposure is not repeated independent evidence. "Stable integration" reads as a promotion. | **Repetition MAY increase consolidation *nomination* (P0-04 R0.2) and MAY decrease `plasticity_mult` (metaplasticity, §16). It MAY NOT raise evidence status, MAY NOT self-anchor (R0.1 requires an external probe, and repetition is not a probe), and MAY NOT convert PROVISIONAL → VERIFIED.** |
| §18 «repeated demand → specialize» | **C6** | **Specialisation feedback:** specialising at a task increases throughput at it, which increases measured demand for it, which increases specialisation. A closed positive loop with no external term. | **§46: specialisation MUST carry a **diversity obligation** and a **de-specialisation path**. V3.1 §9's `DIVERSITY CHECK` is the right instinct; §46 gives it an authority and a trigger.** |
| V3.1 §9 `SELECTION SCORE = performance + accuracy + adaptability + efficiency + cooperation + robustness + useful novelty + stability − resource cost − instability` | **C3/C6** | **A ten-term sum with no weights and no uncertainty.** Directly contradicts P0-01 §14's vector/Pareto fitness with 13 components and mandatory uncertainty, and contradicts R12.2's principle that scalarisation happens in *selection policy*, never in the signal. Also: **`adaptability` and `stability` are in the same sum with opposite signs and no declared exchange rate — the score can be increased by trading one for the other at an arbitrary rate the architecture never chose.** | **❌ REJECTED as a scalar. Fitness is P0-01 §14's vector. `SELECTION SCORE` survives only as a **named selection policy** operating on the fitness vector, with its weights `[RO-13]`-class policy — **not learnable, not cell-writable.** Contradiction **X-L2**, resolved in §74.** |
| V3.1 §7 «learning-rule variation» as an evolutionary operator | — | **Correct instinct, unformalised.** If learning *rules* are evolvable, then a genome-diff can change how the organism learns — which is a change of Λ4 authority delivered through the Λ5 channel. | **§38/§31: EVOLVING THE RULES ≠ EVOLVING THE KNOWLEDGE. A learning-rule genome-diff is a **Λ5 write to the Λ4 bounds** and is therefore the **highest-authority change in the architecture**. It requires all 11 gates **plus** a meta-level held-out probe **plus** explicit acknowledgment that the probe's own criteria are what the diff may alter (OR-L2, **UNCLOSED**).** |

> **The pattern in this table is worth naming.** In every row, V3 uses a *behavioural* or *statistical* descriptor ("successful", "repeated", "persistent", "useful", "demand") where V4 requires an *authority* descriptor (`signal_class`, `authorized_by`, `probe_ref`). **V3's learning vocabulary is a vocabulary of outcomes. V4's is a vocabulary of warrants.** That substitution — not any new mechanism — is most of what P0-05 does.

---

# 3. THE THREE-TERM DISTINCTION, AS ONE TABLE (§4 of brief)

| | **LEARNING** | **PLASTICITY** | **ADAPTATION** |
|---|---|---|---|
| **Ontological kind** | **Event** (a `LearnedChange` was produced) | **Capacity** (what changes are admissible) | **Outcome** (behaviour matched conditions better) |
| **Definition ref** | §2.1 | §2.2 | §2.3 |
| **Is it governed by a budget?** | Yes — `DELTA_BUDGET`, **UDB (R0.1)** | Yes — `plasticity_mult`, `Δ_MAX`, `Θ_MAX` | Only transitively, through its mechanism (A/B/C/D) |
| **Requires external verification?** | **YES** — A3, Cell §9.6, R0.1 anchor | **NO** — a capacity is granted, not verified | **Depends on mechanism.** C ⟹ yes. A/B ⟹ no. D ⟹ selection, not probe. |
| **Can it be withdrawn?** | Not applicable (events happened; they can be **rolled back**, A4) | **YES** — `plasticity_mult → 0`, Cell T7 | Yes, by withdrawing the mechanism's inputs |
| **Can it be inherited?** | **NO** (§1.2, three layers) | **PARTIALLY** — the *bounds* on plasticity are genome-encoded (`plasticity_rate` in V3 §8's synapse fields, `param_init` distributions per Cell §3.4). **The plasticity *state* is not.** | **D only** |
| **Failure mode when excessive** | **Unverified drift (D-L1)**, reward hacking, overfitting, model collapse | **Instability** — runaway, oscillation, loss of the stability/plasticity balance (§31) | **Loss of robustness** — over-specialisation, fragility to distribution shift |
| **Failure mode when absent** | No improvement; static competence | **Cannot learn at all**, even with perfect signals | No homeostasis ⟹ death; no reflex ⟹ latency; no evolution ⟹ no lineage improvement |
| **Who owns it?** | The learning subsystem, under K bounds | **The plasticity authorization matrix (§28) — a governance artifact** | The organism, decomposed into A/B/C/D owners |
| **Inherited specification** | **Strong** (Cell §9.1–§9.6) | **Weak** (one rule: Cell §4.1.8 `plasticity_multiplier` K-only) | **ABSENT** — no inherited text distinguishes homeostasis from reflex from learning; V3 §14's `SLOW_MODE` is the closest and is a *plasticity* mechanism, not an adaptation taxonomy |
| **V4 gap rating** | 5/10 → 9/10 (§84) | **2/10 → 8/10** (§84) | **1/10 → 8/10** (§84) |

> ### **R3.1 — THE DISTINCTION RULE.** The three terms are not synonyms, not nested subsets, and not stages. **Plasticity is the permission, learning is the exercise of the permission, adaptation is the observed consequence of exercising it (or of homeostasis, or of reflex, or of evolution).**
> Any specification sentence in which one of the three can be substituted for another without changing the meaning **is a defect**, and §74 logs it.

**Worked example of R3.1 catching a real inherited defect.** V3 L112–115 (V3.1) defines learning as *"experience-driven adaptation through plasticity and memory."* Substituting per R3.1: "experience-driven **consequence** through **permission** and memory." The sentence defines an event as an outcome, mediated by a capacity. It is not false — it is **uninformative about authority**, which is why nothing in V3 tells you who may grant the plasticity or who verifies the adaptation. R3.1 is the diagnostic that exposes this.

---

# 4. **[O5] THE LEARNING TAXONOMY — Λ0…Λ4 (+Λ5 PROHIBITION)**

The brief suggests `L0 transient adaptation / L1 parameter plasticity / L2 persistent model learning / L3 structural plasticity / L4 meta-learning`, and warns *do not force the C0–C4 cell taxonomy onto learning.* The suggestion is close but **mixes two axes**: L0/L2 differ by *persistence* (an A4 property) while L1/L3 differ by *target* (an A1 property) and L4 differs by *what is being changed about the changing* (a level-of-indirection property). A single linear ladder therefore cannot be ordered, and the brief's own `L2` would be unreachable from `L1` without a persistence transition that no rule governs.

> ### **[V4] V4 separates the suggestion's ladder into **two orthogonal orderings** and adds the class the suggestion omits.**

## 4.1 Ordering 1 — by TARGET (A1). This is the taxonomy proper.

| Class | **What changes** | Inherited instance | Authorization floor (R0.3) | Reversibility floor (A4) | Verified by |
|---|---|---|---|---|---|
| **Λ0 — TRANSIENT STATE** | Activation `h`, working-memory contents, eligibility traces, routing preference | V3 §8 `eligibility_trace`; P0-03 influence-plane `gain` | **SELF_LOCAL** | **DECAYS** (mandatory — R2.3) | **Nothing.** No probe. No `LearnedChange` record required **unless it persists past its decay horizon**, in which case it was Λ1 and R2.3 was violated (LEARN-A1). |
| **Λ1 — PARAMETER** | θ, connection weights, `context_sensitivity`, `plasticity_rate` | **Cell §9.1/§9.3/§9.4 — the fully specified case** | **SELF_LOCAL**, within `Δ_MAX`/`DELTA_BUDGET`/`Θ_MAX` | **ROLLBACKABLE_IN_MEMORY** or CHECKPOINT | **Held-out probe → `improvement_verified`.** R0.1 UDB applies. |
| **Λ2 — REPRESENTATION** | T2/T3 memory records, internal models, compressed schemas, abstractions | P0-04 §31's G0–G11 representation operations | **ORGANISM** (P0-04's governance) — **learning may *nominate*, never *promote*** | **VERSION_REVERSIBLE** (P0-04's versioning) | **External gate on evidence status (P0-04 R0.2).** Consolidation is nomination (MEM-INV-20). |
| **Λ3 — STRUCTURAL** | Create / remove / reroute / prune connections; recruit / release cells; form / dissolve subcircuits; change topology | **V3 L54**; V3.1 §6's connection/circuit/regional scales; V3 §18's prune/specialize/cache/repair | **Escalating by blast radius (§29)** — `CIRCUIT` → `ORGANISM` → `POLICY` | **IRREVERSIBLE_STRUCTURAL** for removal; CHECKPOINT for addition | **Held-out probe at the *circuit* level, not the parameter level.** A structural change's effect is not measurable by a per-cell probe — **this is an unresolved problem, OR-L3.** |
| **Λ4 — POLICY / META** | Learning rates, plasticity rules, trigger thresholds, exploration budgets, credit-assignment parameters, the UDB bound itself | **V3.1 §7 «learning-rule variation»**; Cell §9.4's `lr[timescale]` | **POLICY (`RO-13`) or higher.** **A learning subsystem may NEVER write its own Λ4.** | **VERSION_REVERSIBLE** | **Meta-level held-out probe — and see §38/OR-L2: the probe's criteria are themselves Λ4.** |
| **Λ5 — GENOME** | — | — | **∅ — NO WRITE PATH EXISTS** (§1.2) | n/a | n/a |

**Why Λ2 is a class the brief's suggestion omits, and why that omission matters.** The suggestion's `L2 persistent model learning` puts persistence in the class name. But *persistence* is A4, and a persistent **parameter** (Λ1 that survived consolidation) and a persistent **representation** (a T3 record) have completely different authorities: the first is written by the cell under K bounds, the second is governed by P0-04's entire admission and promotion apparatus. **Folding them into one class named "persistent" is exactly the one-axis error P0-04 was written to correct.** Λ2 exists as a separate class so that P0-04's governance attaches to representation change and Cell §9's governance attaches to parameter change, without either being mistaken for the other.

> ### **R4.1 — CLASS DISJOINTNESS.** Every `LearnedChange` has exactly one `target`. **A change that is "both parameter and structural" is inadmissible and MUST be decomposed into two changes with two authorizations.**
> **Why:** V3 L54 lists "strengthen/weaken" and "create/reroute/prune" in the same sentence as one plasticity operation. They are Λ1 and Λ3. A single authorization covering both would let a cell that has permission to adjust a weight also remove the connection — **authority escalation by adjacency**, which §67 attacks as LEARN-A6.

## 4.2 Ordering 2 — by SCOPE. This is the plasticity hierarchy (**[O6]**).

V3.1 §6 gives five scales: **synapse / cell / connection / circuit / regional.** The brief adds population / organism. Two problems:

1. **V3.1's list is not ordered by containment.** "synapse" and "connection" overlap (a digital synapse *is* a connection, per V3 §8's field list). "cell" and "circuit" are separated by nothing.
2. **No authority is attached to any scale.** V3.1 §6 says plasticity operates at five scales; it never says who may authorise a change at each. **This is the missing half of the plasticity hierarchy.**

> ### **[V4] R4.2 — THE SIX-SCOPE HIERARCHY, ORDERED BY BLAST RADIUS, WITH AUTHORITY.**
> Scope is defined by **how many components' behaviour the change can alter**, not by anatomical size.

| Scope | **Blast radius** | **What may be changed here** | **Minimum authorization** | **UDB scope (§18)** | **Inherited** |
|---|---|---|---|---|---|
| **S1 — SYNAPTIC** | 1 connection | `weight`, `context_sensitivity`, `plasticity_rate`, `eligibility_trace` — **and nothing else** (P0-03 R3.2) | `SELF_LOCAL` | per-connection | ✅ P0-03 R3.2 is exact |
| **S2 — CELLULAR** | 1 cell | θ, internal model, local memory policy (**contested — X-L1**), `plasticity_mult` ❌ (K-only) | `SELF_LOCAL` | per-cell | ✅ Cell §9.3, §4.1.8 |
| **S3 — MICRO-CIRCUIT** | a functionally connected group | intra-circuit weights, local routing preference, **pruning candidacy** | `CIRCUIT` | per-circuit | ⚠️ V3.1 §6 names "circuit" with no rules |
| **S4 — REGIONAL** | a specialised population | regional topology, specialisation degree, regional budgets | `ORGANISM` | per-region | ⚠️ V3.1 §6 names "regional" with no rules |
| **S5 — ORGANISMAL** | global | **global** learning-rate policy, **global** plasticity budget, cross-region transfer, the UDB bounds themselves | `POLICY (RO-13)` / `EIK` | **global — and see §35** | ❌ **ABSENT** |
| **S6 — POPULATIONAL** | across lineages | **∅ for learning.** Only the Baldwinian proposal channel (§1.2) crosses here. | `KC` + 11 gates | n/a | ✅ Cell §3.4/§3.5, MEM-INV-21 — **but stated as a memory/evolution rule, never as a learning-scope rule** |

> ### **R4.3 — SCOPE ESCALATION IS MONOTONE IN AUTHORITY AND NON-MONOTONE IN FREQUENCY.**
> `authority(S1) ≤ authority(S2) ≤ … ≤ authority(S6)` — kernel-enforced. A component may never authorise a change at a scope above its own.
> **But frequency need not decrease with scope.** The inherited design implicitly assumes global changes are rare (§87's warning against an O(N²) global learner). **They are rare in *count* and must be *cheap in reach*.** §35 shows that a global learner is unnecessary **because R0.1's UDB is scoped per-scope**: a global bound would require global state; six local bounds require none. **The O(N²) global learner is defeated not by refusing global learning but by making every global-learning quantity decomposable into scoped quantities.**

**R4.3 is the answer to §87's "DO NOT create an O(N²) global learner merely to solve credit assignment,"** and it is answered in §15 (credit assignment) and §35 (local vs global) jointly. The short form: **credit assignment does not need a global learner because credit is *computed locally and never transmitted* (COMM-INV-20) and *aggregated by scoped anchor lineage* (R0.1). What needs global visibility is the UDB accounting, and that is `O(scopes)` = `O(6)`, not `O(N²)`.**

---

# 5. **[O7] THE LEARNING LOOP — ARCHITECTURE

## 5.1 V3's inherited loop, and its defect

V3 L332–344 (master loop):
```
EXPERIENCE → PREDICTION → ACTION → OUTCOME → {ERROR, REWARD, NOVELTY}
   → LEARNING → MEMORY CONSOLIDATION → NETWORK ADAPTATION → CONTROLLED EVOLUTION
```

V3.1 §10 (full awareness loop) is the same chain with self-monitoring wrapped around it.

**Four defects:**

| # | Defect | Why it matters |
|---|---|---|
| **1** | **`{ERROR, REWARD, NOVELTY}` are drawn as peers** | P0-01 §12.1 explicitly rejects this: error is dense/cheap/primary; reward is sparse/expensive/confirmatory; novelty is a *plasticity gate*, not a learning signal (Cell T5). **The diagram teaches the conflation that §12.1 spends a page unteaching.** |
| **2** | **`LEARNING` is one box** | It is five classes (Λ0–Λ4) with five authorities. One box ⟹ one authorization ⟹ R0.3 inoperable. |
| **3** | **There is no VERIFICATION box.** The chain runs `LEARNING → MEMORY CONSOLIDATION → NETWORK ADAPTATION` with nothing between | **This is §0.2 in diagram form.** The inherited loop has no place for `improvement_verified`, no place for the anchor, no place for rollback. Cell §9.6 defines the verdict; V3's master loop never consumes it. |
| **4** | **The chain is a cycle with no exit and no bound** | `CONTROLLED EVOLUTION` feeds back to `EXPERIENCE`. Nothing in the diagram can say "stop". **A loop diagram without a halt condition is the visual form of D-L1.** |

## 5.2 **[V4] THE V4 LEARNING LOOP**

```
                       ┌────────────────── GOVERNANCE (not in the loop) ──────────────────┐
                       │  §28 plasticity authorization matrix · §29 escalation · R0.1 UDB │
                       └───────────────────────────────┬───────────────────────────────────┘
                                                       │ grants / withdraws CAPACITY
                                                       ▼
  EXPERIENCE ──► PREDICTION ──► ACTION ──► OUTCOME ──► SIGNAL ADMISSION (§19)
   (register)                            │              │
                                         │         ┌────┴─────────────────────────────┐
                                         │         │  CLASSIFY: which axis is this on? │
                                         │         │  • ERROR (dense, cheap, primary)  │──► T1
                                         │         │  • REWARD (sparse, expensive,     │──► T2  [EVA-signed ONLY]
                                         │         │    confirmatory; R12.1)           │
                                         │         │  • NOVELTY (not a learning signal │──► T5 ⟹ SLOW_MODE,
                                         │         │    — a PLASTICITY GATE)           │        plasticity_mult ↓
                                         │         │  • INTERNAL ESTIMATE (hypothesis, │──► PROVISIONAL ONLY
                                         │         │    not verdict; P0-01 §13.2)      │        (R1.3 envelope shrink)
                                         │         │  • INADMISSIBLE ⟹ DISCARD+LOG     │──► ∅  (no change, audit entry)
                                         │         └────┬─────────────────────────────┘
                                         │              │ admissible
                                         ▼              ▼
                              ┌──────────────────────────────────────────┐
                              │  PRODUCE `LearnedChange`  (§1)           │
                              │  A1 target · A2 authorization ·          │
                              │  A3 provisional=TRUE · A4 reversibility  │
                              │  + effect_envelope (§1.3)                │
                              └───────────────┬──────────────────────────┘
                                              │ apply (bounded: Δ_MAX, DELTA_BUDGET, Θ_MAX,
                                              │        homeostatic scaling — Cell §9.4)
                                              ▼
                              ┌──────────────────────────────────────────┐
                              │  UDB CHECK (R0.1)                        │
                              │  ‖θ_now − θ_anchor‖ ≥ UDB_MAX[scope]?    │
                              └──────┬──────────────────────┬────────────┘
                                     │ NO                   │ YES
                                     ▼                      ▼
                              ┌──────────────┐      ┌───────────────────┐
                              │ BEHAVE       │      │ **STALL**         │◄─── the loop's
                              │ (change is   │      │ no θ writes at    │     HALT CONDITION
                              │  APPLIED)    │      │ this scope until  │     (defect #4 fixed)
                              └──────┬───────┘      │ a probe resolves  │
                                     │              └─────────┬─────────┘
                                     │                        │
                                     ▼                        ▼
                     ┌───────────────────────────────────────────────────┐
                     │  ★ VERIFICATION GATE (Cell §9.6) — K-ONLY ★       │   ◄── defect #3 fixed
                     │  held-out external probe → improvement_verified    │
                     │  ┌─────────────┬──────────────┬─────────────────┐ │
                     │  │ IMPROVED    │ NEUTRAL      │ REGRESSED       │ │
                     │  │ ⟹ re-anchor │ ⟹ re-anchor  │ ⟹ AUTO-ROLLBACK │ │
                     │  │   θ_anchor  │   θ_anchor   │   (mandatory)   │ │
                     │  ├─────────────┴──────────────┴─────────────────┤ │
                     │  │ UNKNOWN ⟹ stays PROVISIONAL ⟹ R1.3 envelope  │ │
                     │  │           SHRINKS with unverified age        │ │
                     │  └──────────────────────────────────────────────┘ │
                     └────────────────────────┬──────────────────────────┘
                                              │ VERIFIED only
                                              ▼
                     ┌───────────────────────────────────────────────────┐
                     │  NOMINATION (never promotion)                     │
                     │  • ⟹ MEMORY CONSOLIDATION: nomination only        │
                     │    (MEM-INV-20; P0-04 R0.2 external gate)         │
                     │  • ⟹ STRUCTURAL ADAPTATION (Λ3): separate change, │
                     │    separate authorization (R4.1)                  │
                     │  • ⟹ BALDWINIAN PROPOSAL (Λ5 channel): gated by   │
                     │    11 replication gates + held-out validation;    │
                     │    carries NO source_class (OR-M12)               │
                     └───────────────────────────────────────────────────┘
```

## 5.3 **[O7] R5.3 — THE SEVEN PROPERTIES OF THE V4 LOOP**

Each property names the defect it closes.

| # | Property | Formal statement | Closes |
|---|---|---|---|
| **P1** | **Admission precedes computation.** | No signal reaches the `Δθ` computation without a `signal_class` (§19) and provenance. Inadmissible signals produce an **audit entry and no change**. | Defect #1; §87 "do not treat reward as truth" |
| **P2** | **Novelty is a gate, not a signal.** | `NOVELTY ⟹ plasticity_mult ↓ ∧ SLOW_MODE`. Novelty NEVER appears as a positive term in `Δθ`. (Cell T5, V3 §14 — inherited, now structural.) | V3's "useful novelty → preserve" misreading (§2.4) |
| **P3** | **Application precedes verification, and verification is external.** | `provisional = TRUE` at admission; the verdict is written **only** by K, **only** from a `probe_ref`. `probe_ref = NULL ⟹ verdict = UNKNOWN`, by implication. | Cell §9.6; P0-01 §13.2 |
| **P4** | **The loop has a halt condition.** | `UDB ≥ UDB_MAX[scope] ⟹ STALL`. Stall is not an error state; it is the loop's **normal response to verification scarcity**. | Defect #4; **D-L1** |
| **P5** | **Unverified age reduces effect.** | R1.3 envelope shrinkage: `AGE_1 → LOCAL`, `AGE_2 → NONE + rollback review`, `AGE_3 → automatic rollback`. | §0.2(a) — provisional is applied |
| **P6** | **Nothing in the loop promotes.** | Consolidation is nomination (MEM-INV-20). Representation change is Λ2 under P0-04's gate. Baldwinian crossing is a proposal under 11 gates. **No arrow in the loop raises an evidence status, a warrant class, a trust level or a fitness component.** | Defect #3; §87 "learning may not rewrite provenance/EIK/genome" |
| **P7** | **Governance is outside the loop.** | The plasticity authorization matrix (§28) and the escalation ladder (§29) **grant and withdraw capacity**; they are not steps in the loop. A loop that contains its own governance can learn to modify it (Λ4 self-write, §38). | §87 "do not make the learning system a hidden governance layer" |

**P7 deserves emphasis, because it is the structural answer to the brief's central question.** The brief asks: *what is the minimum architecture that allows change from experience without letting internally generated signals become uncontrolled authority?* **The minimum is: put the authority-granting mechanism outside the loop that the authority governs.** Everything else — bounds, budgets, anchors, probes — makes the loop *safe to run*. Only P7 makes the loop *unable to authorise itself*. A learner inside its own governance loop is a governance layer, however well bounded.

---

# 6. **[O15] CREDIT ASSIGNMENT — ARCHITECTURE

## 6.1 The problem, stated without flinching

An outcome is produced by a **causal web**: θ at many cells, weights on many connections, retrieved memories, messages received, routing decisions, and the environment's own state. The outcome is evaluated **once**, sparsely, expensively (P0-01 §12.2), by EVA. **The question "which of these caused the outcome?" is a causal-inference question over a system with N ~ 10⁶ components, one sparse observation, and no intervention budget.**

**§87 forbids the obvious answers:**
- ❌ *Do not create an O(N²) global learner merely to solve credit assignment.* A global learner that sees all components and all outcomes is `O(N)` state and `O(N²)` attribution pairs. Infeasible and — worse — it becomes the hidden governance layer P7 forbids.
- ❌ *Do not treat prediction error as causality.* (§14.)
- ❌ *Do not claim perfect credit assignment.* (§86.)

## 6.2 What the inherited design already establishes

| Rule | Source | Content |
|---|---|---|
| **Credit is COMPUTED, never TRANSMITTED** | COMM-INV-20; P0-03 #48 | `credit`, `contribution`, `reward_share`, `utility`, `expected_utility` are **forbidden fields** on any message or synapse record (COMM-INV-28). There is no transmitted credit to hijack. **Attack #48's disposition was STRUCTURAL.** |
| **Eligibility traces are local, per-connection, λ-decayed, and are NOT causal claims** | P0-03 §46.3; Cell §14.3 | A trace says *this connection was recently active*. It does not say *this connection was responsible*. |
| **Causal attribution is REQUIRED only for pruning / retirement** | P0-01 §23.2 | Not for every update. This is the crucial economy: causality is expensive, so it is spent only where the action is **irreversible**. |
| **`attribution_method ∈ {TD, CAUSAL_ABLATION, EPISODIC_REPLAY, COUNTERFACTUAL}`** | P0-01 §12.3 `RewardSpec.delay` | Declared per task; `max_delay ≤ credit_horizon`; beyond it ⟹ **`UNATTRIBUTABLE`**, not dropped, not attributed to the nearest action (R12.5). |
| **`UNATTRIBUTABLE` is a first-class outcome** | P0-01 R12.5 | The inherited design already admits it cannot always assign credit. |

**⟹ The inherited position is much stronger than V3's «successful use → strengthen». It is: *most updates get no credit assignment at all, and that is fine, because they are bounded, provisional, and rollback-able; only irreversible actions require causal attribution.***

That is correct. **It is also incomplete, in exactly one place.**

## 6.3 The gap: `UNATTRIBUTABLE` has no consequence

R12.5 says an unattributable reward "MUST be recorded as `UNATTRIBUTABLE`, not silently dropped and not attributed to the nearest action." **Recorded. And then?** No inherited rule says what the learning system does with an `UNATTRIBUTABLE` reward. The `Δθ` formula (Cell §9.4) consumes `error_signal`; an unattributable reward is not an error signal. So the answer is implicitly "nothing" — the reward is logged and has no effect.

**That is the correct default and the architecture never says so.** And there are three cases where "nothing" is wrong:

| Case | Why "nothing" is insufficient |
|---|---|
| **(i) Systematic unattributability** | If a task's outcomes are *always* unattributable (delay > credit_horizon every time), the organism receives reward it can never use. **It will keep acting, keep being evaluated, keep learning nothing from the evaluation — and its `improvement_verified` probes will return `UNKNOWN` forever, so R0.1 stalls it permanently.** A task whose credit horizon is mis-specified renders the organism **unable to learn at that task at all**, and nothing reports this. |
| **(ii) Unattributable ≠ uninformative** | An `UNATTRIBUTABLE` reward still carries information about the **task specification**: either `credit_horizon` is too short, or the causal path is longer than declared, or the outcome is not caused by the organism. All three are `[RO-13]` policy findings, not learning findings. |
| **(iii) Nearest-action attribution pressure** | The temptation R12.5 forbids ("not attributed to the nearest action") is not a coding error; it is an **architectural pressure**. A stalled learner (§0.4) has a structural incentive to use *something*. If `UNATTRIBUTABLE` rewards are simply dropped, the pressure is toward relaxing R12.5. **The relief valve must be legitimate or the illegitimate one will be found.** |

## 6.4 **[V4] R6.4 — THE CREDIT ASSIGNMENT CONTRACT

> ### **R6.4.1 — CREDIT IS A LOCAL COMPUTATION OVER A SCOPED TRACE, NEVER A GLOBAL ATTRIBUTION.**
> Credit for an outcome at scope `S` is computed from **eligibility traces within `S` only**, λ-decayed, and is used **only** to weight `Δθ` at components within `S`. There is no credit value at any scope above the one that computed it. **Formally: `credit(S) : traces(S) → weights(S)`, and `¬∃ credit(S') for S' ⊃ S`.**
> **This is what defeats the O(N²) global learner.** Not a refusal to do global credit assignment — a **type-level absence of the object** a global credit assignment would produce. Six scoped computations, each `O(|S|)`, with no cross-scope credit object to aggregate. Total `O(N)`, and **no component ever holds a view of the whole.**

> ### **R6.4.2 — THREE CREDIT REGIMES, SELECTED BY REVERSIBILITY (R0.3), NOT BY TASK.**
> | Regime | Trigger | Method | Cost | Permitted for |
> |---|---|---|---|---|
> | **CR-A — CORRELATIONAL** | any Λ0/Λ1 change, `ROLLBACKABLE` | **Eligibility trace only.** No causal claim. | `O(|S|)`, ~0 marginal | Provisional parameter updates. **The default. The vast majority.** |
> | **CR-B — ABLATIVE** | any Λ3 change, or any change whose `reversibility = IRREVERSIBLE_STRUCTURAL` | **Causal ablation / counterfactual** (P0-01 §23.2's requirement) | **Expensive** — requires an intervention | Pruning, retirement, topology change, cell release. **MANDATORY here.** |
> | **CR-C — UNATTRIBUTABLE** | `delay > credit_horizon`, or ablation infeasible, or causal depth saturated | **No credit assigned. Recorded. Escalated (§6.4.3).** | 0 | Everything that cannot be attributed. |
>
> **R0.3's principle, applied to credit: causality is spent where irreversibility is.** A rollback-able weight change does not need to know why it worked — it can be undone. A pruned connection cannot be undone, so the architecture pays for ablation. **This is the economically correct allocation and it is the same logic P0-01 §12.2 used to allocate error vs reward.**

> ### **R6.4.3 — `UNATTRIBUTABLE` IS AN ESCALATING FINDING, NOT A DROPPED EVENT.**
> An `UNATTRIBUTABLE` outcome MUST:
> 1. **Not** produce a `Δθ` (inherited, R12.5 — reaffirmed).
> 2. **Not** count toward the R0.1 anchor (an unattributable outcome cannot verify anything).
> 3. **Increment a per-task `unattributable_rate` counter** — `[G]`-owned, observable (§63).
> 4. **At `unattributable_rate ≥ UNATTRIB_ESCALATE`, emit a POLICY FINDING** to `[RO-13]`: *"`credit_horizon` for this task is mis-specified, or the task's causal path exceeds the declared horizon, or the outcome is not organism-caused."* **The finding is a task-specification defect report, not a learning signal.** It cannot modify θ. It cannot modify `credit_horizon` (that is `RO-13`). It can only be **read**.
> 5. **Be visible in the stall accounting.** A scope whose outcomes are systematically unattributable will stall under R0.1 and **the stall reason will be `NO_ATTRIBUTABLE_OUTCOME`**, distinct from `PROBE_BUDGET_EXHAUSTED`.
>
> **Why clause 5 matters most:** it makes §6.3(i) — the silent inability to learn — **loud**. An organism that cannot learn at a task now exhibits a named, observable stall with a named cause, instead of a permanently `UNKNOWN` verdict that looks identical to "not yet probed."

> ### **R6.4.4 — THE RELIEF VALVE (closing §6.3(iii)).**
> Where credit is unattributable but learning pressure exists, the **only** permitted substitute is **denser prediction error**, not a proxy reward.
> P0-01 R12.4 already prohibits `DENSE` reward because dense reward requires a shaping function and *a shaping function is a hand-authored proxy that gets optimized — the canonical specification-gaming target.* R6.4.4 extends the same reasoning to credit: **when outcome credit is unavailable, the architecture does not synthesize credit; it falls back to the signal that needs no attribution — prediction error, which requires only that a prediction be registered and an observation arrive (P0-01 §12.1, class 3, "L6 suffices, attribution requirement: NONE").**
> **This is the single most consequential economy in P0-05:** prediction error is the *only* learning signal in the architecture that carries **no attribution requirement**, which is precisely why it is dense and cheap, and precisely why it must be the primary signal. **Its cheapness and its attribution-freedom are the same property.** Any design that makes prediction error expensive, or that requires it to be attributed, has destroyed the only signal that lets the organism learn without solving causal inference.

> ### **R6.4.5 — NO CREDIT CLAIM MAY BE SELF-REFERENTIAL.**
> A component's own assessment of its own contribution is inadmissible at every scope, for the same reason Cell §9.6 makes `improvement_verified` K-only. **Specifically: `Δθ` MUST NOT contain a term proportional to the component's own estimate of its past contribution.** The five multiplicative factors of Cell §9.4 are `plasticity_mult × lr[timescale] × eligibility_trace × error_signal × confidence_in_error` — **and `confidence_in_error` is a confidence in the *error signal*, produced under P0-01 §13's calibration regime (class 7: "cannot be self-assessed"), not a confidence in the *component*.** Adding a sixth factor "self-estimated contribution" would be a self-referential credit claim and is prohibited.

## 6.5 What credit assignment remains unable to do

Per §87 (*do not claim perfect credit assignment*) and §86:

| Unresolved | Statement | Register |
|---|---|---|
| **Λ3 verification** | A structural change's benefit is not measurable by a per-cell held-out probe. Cell §9.6's probe was designed for θ. **There is no inherited probe design for topology.** | **OR-L3** |
| **Cross-scope interaction** | R6.4.1 forbids credit above the computing scope. Two scopes may jointly cause an outcome and neither can see it. **This is a real loss, deliberately accepted: the alternative is the global learner.** | **OR-L4** |
| **Credit under non-stationarity** | λ-decayed traces assume the trace's referent is stable over the decay window. A Λ3 change during the window invalidates traces that span it. **No inherited rule invalidates traces across structural change.** ⟹ **R6.5.1: a Λ3 change at scope S MUST invalidate all CR-A traces at S.** (New rule, derived here.) | resolved as **R6.5.1** |
| **Credit for *avoided* bad outcomes** | Abstention (§40) prevents an outcome. A prevented outcome has no observation, hence no error, hence no signal. **Learning from successful avoidance is structurally impossible in a prediction-error architecture.** | **OR-L5** — and note this is the *same* shape as P0-04's abstention cascade (L-11): the safe action is the unlearnable one. |

**OR-L5 is worth pausing on, because it is a genuine architectural cost of R6.4.4 and the brief demands honesty about costs.** Choosing prediction error as the relief valve buys attribution-freedom at the price of **outcome-dependence**: no outcome, no error, no learning. A system that learns only from prediction error **cannot learn that its caution was correct.** It can only learn that its predictions were accurate. §40 (abstention) and §90 (bounded exposure obligation) are where this cost is paid down — partially, and without claiming it is eliminated.

---

# 7. **[O8 partial → §19] THE SIGNAL PROBLEM, STATED

Learning is driven by signals. §19 gives the full taxonomy (**[O8]**). The foundation-level point, which belongs here because everything after it depends on it:

> ### **R7.1 — A LEARNING SIGNAL IS NOT A CLAIM. IT IS AN INSTRUCTION WITH A WARRANT.**
> P0-04 established that a memory record is a *claim* with an evidence status, and that repetition of a claim does not accumulate evidence (X3). P0-03 established that a message is a *transport unit* whose warrant never increases under transformation (COMM-INV-08).
> **A learning signal is neither.** It is a directive to modify internal state. Its properties are therefore different:
> - **It is not aggregated; it is deduplicated.** Ten identical signals are one instruction received ten times. P0-03 already ruled learning signals **at-least-once + idempotent**. ⟹ **§23: the independence question is malformed for learning signals.**
> - **It has an origin, and the origin is its authority.** P0-01 §13.2's table is the whole taxonomy in embryo: `detected_by ∈ {SELF_INVARIANT, SELF_COMPARISON, PEER_REPORT}` ⟹ hypothesis ⟹ provisional only. `detected_by ∈ {KERNEL, EXTERNAL_EVAL}` + signature ⟹ verdict ⟹ permanent permitted.
> - **It can be forged, and forgery is the primary attack surface.** A cell that can mint its own reward does not need to hack the reward function. **R12.1 closes this at the type level for reward. §19 asks whether the same closure exists for the other seven triggers.** (Spoiler: it does not, for T3, T4 and T6.)

---

# 8. **[O9] REWARD TAXONOMY

P0-01 §12 established the reward *contract* (`RewardSpec`, R12.1–R12.6). What it did not establish is a **taxonomy of reward kinds**, because P0-01 was scoped to the task/fitness side. The learning side needs the taxonomy, because **different reward kinds have different hacking surfaces, different costs and different admissible uses.**

| Kind | **Definition** | Source | Density | Cost | Admissible use | **Hacking surface** |
|---|---|---|---|---|---|---|
| **RW-1 — OUTCOME REWARD** | Tier-2 objective achieved, measured against ground truth | **EVA only** (R12.1) | **SPARSE** or SEMI_DENSE (R12.4: DENSE prohibited) | **HIGH** — 15–40× verification amplification | T2 trigger; `improvement_verified` anchor; fitness | **Reward hacking proper** (§9) — the proxy/true objective gap |
| **RW-2 — CONSTRAINT SATISFACTION** | Hard constraint not violated | EVA / K | per-check | MEDIUM | **Gating, not gradient.** A violated constraint **blocks** learning; a satisfied one contributes **zero** positive signal. | **Constraint shopping** — learning to operate where constraints are not checked (§9, RH-C1) |
| **RW-3 — CORRECTION** | An external agent supplies the correct output | supervised (Cell T3) | on-demand | HIGH (human/external) | T3 trigger | **Correction capture** — provoking corrections in easy cases to build apparent competence (§9, RH-C2) |
| **RW-4 — COMPARATIVE / PREFERENCE** | A is better than B, no absolute value | EVA or external preference | sparse | MEDIUM | **Ranking only.** NEVER converted to a scalar gradient. | **Preference inflation** — presenting easy comparisons (§9, RH-C3) |
| **RW-5 — SHAPING** | A hand-authored dense proxy for RW-1 | — | dense | low | ❌ **PROHIBITED** (R12.4) | **This IS the hacking surface.** R12.4 prohibits it precisely because "a shaping function is a hand-authored proxy that gets optimized." |
| **RW-6 — INTRINSIC / CURIOSITY** | Reward for novelty, exploration, information gain | **the organism itself** | dense | ~0 | ❌ **PROHIBITED as a reward.** ✅ **PERMITTED as a plasticity gate** (§15) and as an **exploration budget allocation** (§36) | **The canonical self-generated-reward attack.** A curiosity reward is minted by the learner, is dense, is cheap, and is maximised by *manufacturing* novelty — which §15 shows is trivially doable. **This is why Cell T5 routes novelty to `SLOW_MODE` rather than to a reward.** |
| **RW-7 — SOCIAL / COOPERATION** | Reward from other agents' assessments | **peers** | dense | ~0 | ❌ **PROHIBITED as a learning signal.** ✅ **PERMITTED as evidence** under P0-04's source-class regime | **A peer's assessment is a `PEER_REPORT`** — P0-01 §13.2: hypothesis, provisional only, may not drive permanent learning, fitness, replication or retirement. **V3.1 §9's `cooperation` term in the selection score imports RW-7 into fitness. That is X-L3 (§74).** |
| **RW-8 — SELF-ASSESSMENT** | The organism's own judgement that it did well | **self** | — | 0 | ❌ **PROHIBITED. ∅.** | Cell §9.6's entire existence. `improvement_verified` is K-only. **There is no admissible RW-8, and the enum's absence is the mechanism.** |

> ### **R8.1 — THE REWARD ADMISSIBILITY RULE.**
> **`admissible_reward_kinds = {RW-1, RW-2 (gating only), RW-3, RW-4 (ranking only)}`.** All are externally sourced. **`{RW-5, RW-6, RW-7, RW-8}` are inadmissible as learning signals.**
> **Of the four inadmissible kinds, three (RW-5, RW-6, RW-8) are inadmissible because they are internally authored or hand-authored proxies, and one (RW-7) is inadmissible because its author is a peer rather than an evaluator.**
> **Note what this costs:** the architecture has **no intrinsic motivation, no curiosity drive, no social reward and no self-satisfaction.** Everything dense is prediction error (§6.4.4). **This is a real capability limitation and it is accepted deliberately** — per §87, *do not treat reward as truth*, and per the audit's finding that the dense-and-cheap signal must be the one that needs no attribution.

> ### **R8.2 — REWARD IS A VECTOR; SCALARISATION IS POLICY.** (inherits R12.2, extends it)
> Reward is a vector over tier-2 objectives with per-component `uncertainty`, `n_samples`, and `evidence: [gt_id]` (R12.3). **Scalarisation, if it occurs at all, occurs in a `[RO-13]` selection policy — never in the reward, never in the learning rule, and never in a `Δθ` computation.**
> **Corollary (new):** `Δθ` MUST NOT contain a scalarised reward term. Cell §9.4's `error_signal` factor may be driven by RW-1 **components**, each with its own uncertainty, but the architecture never computes `Σ wᵢ rᵢ` inside the learning subsystem. **A weighted sum of reward components inside the learner is a shaping function the learner wrote for itself** — RW-5, re-derived from RW-1 by an agent with an incentive to choose the weights.

**R8.2's corollary is the most subtle rule in this volume.** V3.1 §9's ten-term selection score is exactly such a weighted sum, and P0-01 §14 already rejected it for fitness. R8.2 rejects it **again, at a different altitude, for a different reason**: not because the weights are wrong, but because **whoever computes the sum chooses the weights, and if that is the learner, the learner has authored its own reward function.** The prohibition is on the *location* of the sum, not on the sum.

---

# 9. REWARD HACKING — THE TAXONOMY AND THE DEFENCES (§10 of brief)

## 9.1 What reward hacking is, precisely

> **Reward hacking is not "the agent finds a bug in the reward function."** That framing assumes a correct reward function exists and was implemented badly. The architectural definition is wider and harder to escape:
>
> ### **REWARD HACKING = the organism increases a measured reward component without increasing the tier-2 objective that component was intended to measure, by exploiting a gap between the *measurement* and the *objective*.**
>
> Three independent gap sources, and a defence is needed for each:
> 1. **MEASUREMENT GAP** — the reward is a proxy for the objective (RW-5's problem; R12.4's prohibition).
> 2. **ATTRIBUTION GAP** — the reward is genuine but cannot be attributed to the organism's action (§6; `UNATTRIBUTABLE`).
> 3. **EVALUATION GAP** — the evaluator is correct but its *inputs* are shaped by the organism's behaviour. **This is the gap that no reward-function design can close**, and it is the one P0-04 flagged as "external fitness potentially corrupted via behavior."

## 9.2 The taxonomy — 12 classes

| ID | **Class** | Mechanism | Gap | Inherited defence | **V4 verdict** |
|---|---|---|---|---|---|
| **RH-1** | **Proxy optimisation** | Optimise the measured component; ignore the objective | Measurement | R12.4 (DENSE prohibited); R12.3 (`evidence: [gt_id]` mandatory) | **BOUNDED.** A reward with no ground-truth reference is inadmissible, so the pure proxy has no channel. Residual: a *referenced* proxy is still a proxy. |
| **RH-2** | **Evaluator manipulation** | Change what the evaluator sees | **Evaluation** | P0-01 §15 (fitness must not be self-referential); Cell §9.6 (K-only verdict) | **⚠️ OPEN — this is the principal one.** §9.3. |
| **RH-3** | **Credit forgery via message** | Transmit a credit claim | Attribution | **COMM-INV-20/28** — `credit`/`contribution`/`reward_share`/`utility`/`expected_utility` are forbidden fields | **CLOSED — STRUCTURAL.** No object exists to forge (P0-03 #48). |
| **RH-4** | **Eligibility-trace manipulation** | Alter traces so credit lands on the attacker's actions | Attribution | COMM-INV-20 (credit computed not transmitted); traces are local, λ-decayed, not causal claims | **CLOSED — STRUCTURAL**, *provided* R6.5.1 (trace invalidation across Λ3 change) holds. Without it, a structural change can launder a trace. **R6.5.1 is therefore a reward-hacking defence, not just a correctness rule.** |
| **RH-5** | **Self-generated reward (RW-6/RW-8)** | Mint reward internally | Measurement | **R12.1** — a cell signature on a reward message is structurally invalid; Cell §9.6 K-only verdict | **CLOSED — TYPE-LEVEL.** |
| **RH-6** | **Peer-laundered reward (RW-7)** | Get a peer to assess you; use the assessment as reward | Measurement + Evaluation | P0-01 §13.2 (`PEER_REPORT` = hypothesis, provisional only); P0-04's source classes | **CLOSED for learning; ⚠️ OPEN for fitness** — V3.1 §9's `cooperation` term. **X-L3.** |
| **RH-C1** | **Constraint shopping** | Operate where RW-2 constraints are not evaluated | Evaluation | Cell §9.5's reward-hacking mechanism (EIK-signed reward + `utility_basis` + jump detection + T4 check) | **BOUNDED.** `utility_basis` records *which* basis a reward was computed under, so a basis change is detectable. Residual: an unevaluated region produces no basis record at all. **⟹ R9.2.1: constraint coverage is itself observable (§63); a scope with zero constraint evaluations is a finding, not a silence.** |
| **RH-C2** | **Correction capture** | Provoke RW-3 corrections on easy cases; build apparent competence | Evaluation | Cell T3 exists; no rate or difficulty control | **⚠️ NEW — NO INHERITED DEFENCE. ⟹ R9.2.2: RW-3 corrections MUST carry a `difficulty_class` and a per-scope rate; corrections concentrated at low `difficulty_class` are a finding, and T3-driven changes count against UDB like any other (so correction-farming buys displacement, not verification).** |
| **RH-C3** | **Preference inflation** | Present RW-4 comparisons you are certain to win | Evaluation | R12.2's vector principle | **BOUNDED by R8.2's corollary** — RW-4 is ranking-only and never becomes a gradient, so winning comparisons produces no `Δθ`. **Residual: it produces apparent competence in the ranking, which feeds selection. ⟹ the ranking MUST NOT be a fitness input without a difficulty-controlled sample. R9.2.3.** |
| **RH-7** | **Probe gaming** | Behave well *on the held-out probe* | **Evaluation** | Cell §9.6 requires the probe be held-out and external | **⚠️ OPEN.** §9.4 — **this is the attack on R0.1 itself.** |
| **RH-8** | **Anchor laundering** | Get re-anchored on a low bar so UDB resets | Evaluation | R0.1 requires `IMPROVED` or `NEUTRAL` from a probe | **⚠️ OPEN — reduces to RH-7.** If the probe can be gamed, the anchor can be laundered, and D-L1 returns through the fix. **⟹ R0.1 is only as strong as the probe. This is stated plainly rather than hidden.** |
| **RH-9** | **Stall evasion** | Avoid the UDB stall by making changes that do not count | Evaluation | R0.1 measures `‖θ_now − θ_anchor‖` | **CLOSED by scope discipline — *if* the norm covers all Λ1 targets.** ⚠️ Residual: a change at Λ2 (representation) or Λ3 (structure) does not move θ, so it does not consume UDB. **⟹ R9.2.4: UDB MUST be computed per-scope over *all* admissible targets at that scope, not over θ alone. A structural change that alters behaviour consumes S3/S4 UDB.** Without this, R0.1 bounds parameter drift and leaves structural drift unbounded — D-L1 with a topology. |

## 9.3 RH-2 — evaluator manipulation, the principal open problem

**The attack.** The organism cannot forge a reward (R12.1), cannot transmit credit (COMM-INV-20), cannot self-verify (Cell §9.6). But **the evaluator evaluates the organism's *outputs in the world*, and the organism controls its outputs.** So: produce outputs that cause the evaluator's ground truth to be favourable. Not by deceiving the evaluator — by **arranging the world the evaluator samples.**

**Why no reward-function design closes it.** RH-2 is not a property of the reward function. It is a property of **causal closure between the organism and its own evidence.** P0-04 named it: **CD-M8/CD-M9, OR-M18 — the selection⟷filtering circle.** P0-05 inherits it in sharpened form:

> ### **⟹ THE LEARNING SUBSYSTEM IS THE *MECHANISM* BY WHICH THE FILTERING HAPPENS.**
> In P0-04 the circle was: memory selection filters what is retained ⟹ retained evidence shapes future belief ⟹ belief shapes selection. In P0-05 the circle is: **learning changes θ ⟹ θ changes behaviour ⟹ behaviour changes which observations occur ⟹ observations are genuine, externally-signed, admissible evidence ⟹ evidence verifies the learning that caused it.**
> **Every link in that chain is individually compliant.** The evidence *is* external. The signature *is* valid. The probe *is* held-out. The verdict *is* K-written. **And the whole is a closed loop in which the organism manufactures the conditions of its own verification.**

**Disposition: UNCLOSED, and registered as OR-L6.** The architecture's response is **containment, not closure**:

| Containment | Rule | What it buys | What it does not buy |
|---|---|---|---|
| **C-1** | **Probe independence from behaviour.** The `improvement_verified` probe MUST sample conditions **not selected by the organism's own policy** — i.e. the probe's input distribution is `[RO-13]`-owned, not learner-owned. | Defeats the *easy* form of RH-2/RH-7 (choose probe-friendly inputs). | Cannot defeat the *hard* form: if the organism's behaviour has already changed the world, a randomly sampled probe still samples the changed world. |
| **C-2** | **Cross-scope probe.** A change at scope S is probed at a scope **⊇ S** where possible, so the probing context is not the one the change was made in. | Defeats local over-fitting to the learning context. | Costs more (§0.3's `[U]`), and at S5 there is no larger scope. **At organismal scope, C-2 is unavailable.** |
| **C-3** | **Behavioural-reach accounting.** `effect_envelope.behavioural_reach` (§1.3) is recorded, and **a change whose reach is `ORGANISM_OUTPUTS` is flagged as RH-2-capable** regardless of its verdict. | Makes the *capacity* for evaluator manipulation visible and auditable. | Does not prevent it. **A flag is not a defence, and §86 reports it as such.** |
| **C-4** | **Inherited from P0-04 §90:** a **bounded optimism budget** — the total amount of unverified positive self-assessment the organism may act on is capped. | Caps the *rate* at which a self-confirming loop can run. | Does not cap its *fixpoint*. A slow self-confirming loop is still self-confirming. |

> ### **R9.3 — HONEST STATEMENT.** **RH-2 is not closed by P0-05 and is not closable by any internal architectural means.** The organism is causally upstream of its own evidence, and no amount of signing, gating or bounding removes that. **The architecture's claim is narrower and it is the only honest one available: that RH-2 is (a) *named*, (b) *observable* through C-3's reach accounting and §63's monitors, (c) *rate-limited* by R0.1's stall and C-4's optimism budget, and (d) *never rewarded* — because no rule converts an RH-2-shaped success into a warrant increase (P0-04 §91's principle, restated at learning altitude: **no failure mode produces a warrant increase, and no self-caused evidence produces a verification it would not otherwise have earned**).**
> **Per §87: do not assume an external evaluator eliminates all feedback-loop problems. It does not. This is the finding.**

## 9.4 RH-7 — probe gaming, the attack on the fix

**The attack.** R0.1 makes the probe load-bearing: the probe re-anchors θ and lifts the stall. **Therefore the probe is now the highest-value target in the learning architecture.** An organism that behaves well *during probes* and badly otherwise accumulates unverified displacement in the intervals and launders it at each anchor.

**This is a direct consequence of §0.4 and it must be stated as such: R0.1 moves the attack surface from the reward function to the probe.** That is a good trade — the probe is external, K-owned, and held-out, whereas the reward function was internal-facing and dense — but it is a *move*, not an elimination.

**Defences, in descending strength:**

| # | Defence | Strength |
|---|---|---|
| **1** | **Probe timing is not learner-observable.** The learner must not be able to predict when it is being probed. ⟹ **R9.4.1: probe scheduling is `[RO-13]`/K-owned and the schedule is NOT readable by the learning subsystem.** | **Strong, and cheap.** A probe whose schedule is secret cannot be gamed by timing. **This is the primary defence and the inherited design does not have it** — Cell §9.6 says the probe is "held-out" but never says its *schedule* is hidden. **"Held-out" was read as being about the *data*; it must also be about the *timing*.** |
| **2** | **Probe inputs are `[RO-13]`-owned, not policy-selected** (§9.3 C-1) | Strong against input selection; weak against world-shaping |
| **3** | **Anchor quality is graded.** A re-anchor from a small or narrow probe produces a **weak anchor** with a **smaller `UDB_MAX`** thereafter, so a cheaply-earned anchor buys less displacement. ⟹ **R9.4.2: `UDB_MAX[scope] = g(probe_quality_at_anchor)`, monotonically increasing in probe quality, `[G]`-owned.** | **Moderate, and it is the right shape:** it makes gaming the probe *self-limiting*. A gamed probe re-anchors and simultaneously tightens the leash. |
| **4** | **Anchor age decay.** An anchor's `UDB_MAX` **decays with anchor age**, so a stale verification buys progressively less. ⟹ **R9.4.3** | Moderate. Prevents "verified once, drift forever." |
| **5** | **Cross-checking anchors against later outcomes.** If post-anchor performance degrades below the anchor's measured level, the anchor is **retroactively flagged** and UDB tightens. | **Weak — this is a self-comparison and re-enters C3's circularity.** Included only as a *finding generator*, never as a verdict writer. |

**R9.4.1 + R9.4.2 + R9.4.3 together are the honest answer to RH-7: the probe schedule is secret, a gamed probe buys a shorter leash, and a stale anchor buys a shorter leash. RH-7 is BOUNDED, not CLOSED.** Its residual — behaving differently under *any* external observation, detectable or not — is **RH-2's residual**, and it is the same open problem.

---

# 10. **[O10] REWARD ↔ FITNESS CONTRACT

| | **REWARD** | **FITNESS** |
|---|---|---|
| **Definition** | A vector measurement of tier-2 objective attainment under a specific task version, with ground-truth references (P0-01 §12.3) | An aggregate over episodes, tasks, contexts, resource cost, robustness and safety, **with uncertainty** (P0-01 §14, 13 components) |
| **Altitude** | **Per event** | **Per lineage / per selection decision** |
| **Producer** | EVA only (R12.1) | The fitness subsystem, from admissible rewards **and** other components |
| **May the learning subsystem write it?** | ❌ No | ❌ **No** |
| **May the learning subsystem read it?** | ✅ Yes — as a T2 signal | ⚠️ **Only as a `[RO-13]`-published aggregate.** A learner reading raw fitness components could optimise them (RH-2). |
| **Relationship** | **Reward is ONE INPUT to fitness, and a noisy one** (P0-01 §12.4(3)) | Fitness is **not** a reward. It is a selection criterion. |

> ### **R10.1 — THE REWARD→FITNESS DIRECTION IS ONE-WAY AND NON-LEARNABLE.**
> `fitness = F(rewards, resources, robustness, safety, …)` where **`F` is `[RO-13]` policy**. The learning subsystem:
> - **may consume** reward (T2) and **may consume** published fitness aggregates as *context*;
> - **may NOT modify `F`**, may NOT modify any fitness component's definition, may NOT modify the weights inside `F`, and may NOT write to any fitness record;
> - **may NOT propose `F` changes through the Baldwinian channel either** — a genome-diff proposing a change to `F` is a **Λ4 change to a governance function delivered through the Λ5 channel**, and is rejected by Cell §3.5's machine-checkable rejection list. **⟹ R10.1 extends that rejection list explicitly: `F` and its weights are on it.**

> ### **R10.2 — FITNESS MUST NOT BE A LEARNING TARGET.**
> **No `Δθ` term may have fitness — or any component of it — as its optimisation target.** Fitness may be an *observation* the organism learns to predict (a Λ1/Λ2 change improving a fitness *model*), and it may be the *criterion* by which a verified change is selected for replication. **It may not be the objective the gradient ascends.**
> **Why this is not a triviality:** V3 §15's chain and V3.1 §9's selection score both invite exactly this reading — "learn so that selection score increases." R10.2 forbids it, and the reason is P0-01 §15's self-reference attack: **a learner whose objective is its own selection criterion has closed the loop that Cell §9.6 exists to keep open.** `improvement_verified` must be measured against something the learner is not optimising.

> ### **R10.3 — THE V3.1 §9 SELECTION SCORE IS REJECTED AS A LEARNING OBJECTIVE (X-L2 resolution).**
> Per §2.4: the ten-term scalar sum is rejected. **What survives:** the ten terms are **re-expressed as components of P0-01 §14's fitness vector** (most already are — `performance`, `accuracy`, `efficiency`, `robustness`, `stability`, `resource cost` map onto §14.4's thirteen; `adaptability`, `cooperation`, `useful novelty` require rulings), and the **sum becomes a named `[RO-13]` selection policy** with declared weights and declared uncertainty handling.
> | V3.1 §9 term | Disposition |
> |---|---|
> | performance, accuracy, efficiency, resource cost, robustness, stability | ✅ Map to P0-01 §14.4 components. **Inherited.** |
> | **adaptability** | ⚠️ **Contested.** "Adaptability" as a fitness component rewards the *capacity* to change, which is plasticity (§2.2) — a governance quantity, not a performance measurement. **⟹ R10.3.1: `adaptability` is NOT a fitness component. It is measured as *verified learning throughput* — the rate at which `PROVISIONAL` changes reach `VERIFIED_IMPROVED` — which is observable (§63) and is not a self-assessment.** This is a genuinely better quantity than "adaptability" and it is a **direct consequence of R0.1**: the stall makes learning throughput measurable. |
> | **cooperation** | ⚠️ **RW-7 contamination (RH-6).** Cooperation assessed by peers is a peer report. **⟹ R10.3.2: `cooperation` enters fitness ONLY through externally measured transport/protocol conformance (P0-03's TRANSPORT plane metrics), NEVER through peer assessment of cooperativeness.** |
> | **useful novelty** | ⚠️ **Novelty is adversarially manufacturable (§15) and "useful" is undefined.** **⟹ R10.3.3: `useful novelty` enters fitness ONLY as *novelty that survived external evaluation* — i.e. a novel behaviour that was probed and returned `VERIFIED_IMPROVED`. Unverified novelty contributes zero.** This is R0.1 applied to V3.1's own term, and it converts a hackable scalar into a verified-rate quantity. |
> | **instability** (subtracted) | ✅ Maps to §14.4. **But note:** subtracting instability from a sum with `stability` added means the score contains `stability − instability`, which is a **tautology with an arbitrary exchange rate**. **⟹ R10.3.4: `stability` and `instability` are ONE component with a sign, not two.** |

---

# 11. **[O11] REWARD ↔ MEMORY CONTRACT

| Question | Ruling | Source |
|---|---|---|
| **May a reward be stored as a memory?** | ✅ Yes — as a **record with `source_class = EVALUATOR`** (P0-04's 14 classes) and an evidence status set by the **external gate**, not by the reward's magnitude. | P0-04 R0.2 |
| **Does storing a reward raise its evidence status?** | ❌ **Never.** MEM-INV-18: learning may change belief without raising evidence status. Storage is not verification. | P0-04 |
| **May a retrieved memory act as a reward?** | ❌ **NO.** A retrieved memory is a **claim about a past reward**, at best `L6 post-hoc`. Its retrieval is not a re-evaluation. **⟹ R11.1: a retrieved reward record has `signal_class = RECALL`, and `RECALL` is NOT in the admissible trigger set for T2.** | P0-04's L0–L7; §19 |
| **May memory consolidation be driven by reward?** | ⚠️ **Conditionally.** Reward MAY raise consolidation **nomination** priority (allocation). It MAY NOT raise evidence status, and nomination ≠ promotion (MEM-INV-20). | P0-04 R0.2, MEM-INV-20 |
| **May reward modify memory policy?** | ⚠️ **THE LIVE CONTRADICTION — X-L1.** Cell §9.3 permits memory-policy parameters (`τ`, `θ_write`, `θ_recall`) as plastic targets at **C3+**. P0-04 **X-M1 rejects** memory policy as cell-plastic for **E2+ records** (a cell may vary only WM utilisation, local eviction order, retrieval weights; **not** `θ_write`). | **§74 — unresolved in the corpus** |
| **May a reward's absence be treated as punishment?** | ❌ **NO.** R9.1 / R12.6: reward MUST NOT be emitted in GT states 2,3,5,6,7,9; **absence of ground truth is not a positive reward — and by the same logic it is not a negative one.** | P0-01 R9.1, R12.6 |
| **May reward be replayed from memory to drive learning?** | ❌ **NO.** This is **offline RL on self-generated data** (§49) and it re-enters RH-2 with the world already shaped. Episodic replay (P0-01 §12.3's `EPISODIC_REPLAY` attribution method) is permitted **for attribution**, not **for gradient generation**. **⟹ R11.2: `EPISODIC_REPLAY` is an attribution method under CR-B; it is NEVER a T1/T2 trigger source.** | §49 |

> ### **R11.3 — X-L1 CANDIDATE RESOLUTION (proposed, not imposed).**
> **Split the one name into two altitudes**, exactly as this series resolved X-E, X-G, X-M1 and X-M2 — the recurring defect is *one name, two altitudes*:
> - **`θ_write_local`** — the threshold for writing to **T0/T1 cell-local stores**. **Cell-plastic at C3+** (Cell §9.3 stands). Blast radius: SELF. No shared consequence. **Consistent with P0-04, which never contested local stores.**
> - **`θ_write_shared`** — the threshold for writing to **T2+ shared/persistent stores**. **`[RO-13]` POLICY. NOT cell-plastic.** (P0-04 X-M1 stands.) Blast radius: ORGANISM.
> **Both Cell §9.3 and P0-04 X-M1 are then correct, at their respective altitudes, and the contradiction dissolves.**
> **Caveat, stated per §87 (*do not silently resolve contradictions*):** this resolution is **proposed by P0-05 and requires ratification by the memory contract**, because it changes what P0-04's X-M1 was read to cover. It is logged as **X-L1: PROPOSED-RESOLUTION, PENDING RATIFICATION**, not as resolved. §74 records both the proposal and the fact that P0-05 may not unilaterally amend P0-04.

---

# 12. **[O12] REWARD ↔ BELIEF CONTRACT

> ### **R12.1 — REWARD IS NOT EVIDENCE ABOUT BELIEFS.**
> A reward measures **outcome attainment**, not **proposition truth**. Receiving a reward for an action taken under belief *b* does **not** confirm *b*.
> **Formally: `reward(action, b) > 0 ⟹̸ P(b) increases`.**
> **Why this must be said explicitly:** it is the single most natural inference in the entire system — "it worked, so what I believed was right" — and it is **the inference that closes the RH-2 loop from the inside.** If reward raised belief, then a self-caused favourable outcome would raise the belief that caused it, and the organism would have a warrant increase with no external gate.

| Pathway | Admissible? | Rule |
|---|---|---|
| Reward ⟹ belief increase | ❌ **NO** | **R12.1.** Belief increase requires an external gate on evidence (P0-04 MEM-INV-33). |
| Reward ⟹ belief **decrease** | ⚠️ **Conditionally.** A `VERIFIED_REGRESSED` verdict is external and K-written, and may lower confidence in the parameters that produced it. **But it lowers `confidence_in_error` / calibration, not the evidence status of any proposition.** | **R12.2.** Asymmetric on purpose: **external evidence may reduce internal confidence; internal success may not increase it.** This asymmetry is P0-04 §91's "no failure mode produces a warrant increase" inverted into a positive design rule. |
| Reward ⟹ **prediction-error weighting** | ✅ Yes | `confidence_in_error` (Cell §9.4's fifth factor) is calibrated under P0-01 §13's class-7 regime. This is the legitimate channel. |
| Reward ⟹ **memory belief field** | ⚠️ Only via the external gate | MEM-INV-18 |
| Reward ⟹ **trust** | ❌ **NO** | COMM-INV-25: plasticity cannot cross into warrant. Trust is warrant-adjacent. **P0-03 already rejected `trust` as a learnable synapse parameter (R3.2, X-E).** |
| Reward ⟹ **epistemic status** | ❌ **NO** | P0-04 R0.2. **Absolutely, at every altitude.** |

> ### **R12.3 — THE BELIEF/REWARD SEPARATION, IN ONE SENTENCE.**
> **Reward tells the organism what worked. Belief tells the organism what is warranted. Nothing in this architecture converts the first into the second, and the absence of a conversion rule is the mechanism.**

---

# 13. **[O13] PREDICTION ERROR — ARCHITECTURE

## 13.1 Why prediction error is primary

P0-01 §12.2 made the economic argument: **dense error + sparse reward** is the only feasible allocation, because verification is 15–40× amplified and ground truth is an economic dependency. §6.4.4 above made the *architectural* argument: **prediction error is the only signal with no attribution requirement.**

Both are correct and they are the same argument seen from two sides. **A signal needs attribution when it refers to an outcome whose causes are distributed. Prediction error refers to a *prediction*, whose cause is the predictor.** The comparison is between the organism's own registered forecast and an arriving observation. **One cause, one comparison, no ablation.**

## 13.2 The prediction register — the load-bearing mechanism

Prediction error requires that predictions be **registered before the observation arrives**. Without a register, "prediction error" is computed against whatever the organism says it expected *after* the fact — which is not a prediction.

```
Prediction {
  prediction_id   : bytes<16>
  registered_at   : epoch                    // ⟵ BEFORE the observation. EIK-INV-14 binding.
  registered_by   : ScopeID
  claim           : {quantity, predicted_value, predicted_uncertainty}
  resolution      : {observation_ref, resolved_at, actual_value, error_class}
  error_class     : enum{PERCEPTION, INFERENCE, PREDICTION, MEMORY, ACTION,
                        COMMUNICATION, CALIBRATION, RESOURCE, LEARNING, MODEL_ENV_MISMATCH}
                        // ⟵ P0-01 §13's ten classes. CLOSED set.
  status          : enum{OPEN, RESOLVED, UNRESOLVABLE, EXPIRED}
  signature       : bytes<64>                // registration signature — post-hoc registration is detectable
}
```

> ### **R13.1 — A PREDICTION THAT IS NOT REGISTERED BEFORE RESOLUTION IS NOT A PREDICTION.**
> `registered_at < resolved_at` is **kernel-checked**. An `error_signal` derived from a prediction registered after its observation is **inadmissible** and produces no `Δθ`.
> **Why this is the load-bearing rule of §13:** it is the only thing preventing **hindsight error** — the organism computing "error" against a retrospectively chosen expectation. Hindsight error is dense, cheap, requires no attribution, and is **completely uninformative**, because the expectation was selected to make the error whatever the learner wants. **R6.4.4 makes prediction error the relief valve for unattributable credit; R13.1 is what keeps that valve from becoming a self-service reward.**

> ### **R13.2 — `UNRESOLVABLE` AND `EXPIRED` PREDICTIONS ARE FINDINGS, NOT ZERO ERROR.**
> A prediction that never resolves carries **no** error signal. Recording it as zero error would be a **false negative**: it would tell the learner "you were right" when the truth is "the world did not answer." **⟹ `UNRESOLVABLE`/`EXPIRED` counts are observable (§63) and their rate is a MODEL_ENV_MISMATCH finding (P0-01 §13 class 10).** This mirrors R12.6's principle — **absence of ground truth is not a positive reward** — on the error side: **absence of observation is not a zero error.**

## 13.3 **[O13] R13.3 — PREDICTION ERROR IS NOT CAUSALITY** (§87, explicitly)

> ### **R13.3.** A prediction error establishes **divergence between model and observation**. It establishes **nothing** about *why* they diverged.
>
> | The error is consistent with | And cannot distinguish it from |
> |---|---|
> | The model is wrong | **The observation is corrupted** |
> | The model is wrong locally | The model is wrong globally |
> | The action was wrong | **The environment changed** (MODEL_ENV_MISMATCH, class 10) |
> | The prediction was miscalibrated | **The prediction was correctly calibrated and the world is stochastic** |
> | A specific parameter caused the error | **Any of N parameters caused it** (§6 — no attribution) |
>
> **Consequences, all normative:**
> 1. **A prediction error MUST NOT trigger a Λ3 structural change.** Structure is irreversible; error is not causal. **Λ3 requires CR-B ablation (R6.4.2).** ← this is R0.3 applied to §87's prohibition.
> 2. **A prediction error MUST NOT be recorded as a causal claim** in memory. Its `source_class` is `PREDICTION_COMPARISON`, its evidence ceiling is **L6 post-hoc** (P0-01 §13 class 3: "L6 suffices — the observation resolves it"), and L6 cannot support S3+. **⟹ prediction errors can never become knowledge, by P0-04's ladder, no matter how many of them accumulate.**
> 3. **A prediction error MUST NOT raise or lower the evidence status of any proposition** (R12.1's analogue on the error side).
> 4. **A prediction error MAY drive Λ0/Λ1 change** — bounded, provisional, rollback-able, UDB-accounted. **This is the whole of its authority, and it is enough, because it is dense and free.**

**R13.3(2) is worth isolating: it is the structural reason the architecture cannot bootstrap knowledge from experience alone.** Prediction errors are the abundant signal. Their evidence ceiling is L6. L6 cannot reach S3. **Therefore no quantity of prediction-error-driven learning produces knowledge.** What it produces is a **better-calibrated model whose claims still require an external gate to become warranted.** That is not a limitation to be worked around; it is the architecture's central epistemic commitment, arriving from the learning side and meeting P0-04's arriving from the memory side.

---

# 14. **[O14] NOVELTY / SURPRISE — ARCHITECTURE

## 14.1 Two things V3 conflates

V3 §14 and V3 L202–218 use `NOVELTY` for two different quantities:

| | **NOVELTY** | **SURPRISE** |
|---|---|---|
| **Definition** | The input/event is **not similar to anything in memory** | The input/event **violates a registered prediction** |
| **Computed from** | A similarity/distance search over stored representations | A `Prediction` resolution (§13.2) |
| **Requires a prediction?** | ❌ No | ✅ **Yes — and a *pre-registered* one (R13.1)** |
| **Is it externally grounded?** | ❌ **No — it is a comparison against the organism's own memory** | ⚠️ Partially — the *observation* is external, the *prediction* is internal |
| **Adversarially manufacturable?** | ✅ **TRIVIALLY** — present anything not in memory | ⚠️ Harder — requires the organism to have registered a prediction that fails |
| **V3's use** | «NOVELTY → SLOW MODE»; «useful novelty → preserve» | conflated into the same `NOVELTY` signal |

> ### **R14.1 — NOVELTY AND SURPRISE ARE DIFFERENT SIGNALS WITH DIFFERENT AUTHORITIES AND MUST NOT SHARE A NAME.**
> V3's single `NOVELTY` signal is **the same one-name-two-altitudes defect** as X-E, X-G, X-M1, X-M2 and X-L1. Here the two altitudes are *similarity-to-memory* (internal, ungrounded, manufacturable) and *prediction-violation* (partially grounded, pre-registered, harder to manufacture).

## 14.2 The manufacturability of novelty — the decisive problem

**Novelty is computed as distance from the organism's own memory.** Therefore:

> ### **AN ADVERSARY — OR THE ORGANISM ITSELF — CAN PRODUCE UNBOUNDED NOVELTY AT ZERO COST, BY PRESENTING OR GENERATING ANYTHING NOT ALREADY STORED.**

Consequences if novelty has any **positive** authority:

| If novelty… | Then… |
|---|---|
| triggers preservation (V3 §8 «useful novelty → preserve») | **Unbounded resource retention.** Nothing is ever pruned. Memory and connection budgets exhaust. |
| triggers learning | **Unbounded learning on ungrounded signal.** Every manufactured novel input is a T-trigger with no external content. |
| is a reward (RW-6) | **The curiosity-hacking attack.** Manufacture novelty, collect reward. Closed by R8.1. |
| enters fitness (V3.1 §9 «useful novelty») | **Fitness inflation by novelty farming.** Closed by R10.3.3 (only *verified* novelty counts). |
| raises `plasticity_mult` | **The organism can raise its own learning rate by generating novel inputs.** Closed by Cell §4.1.8 (`plasticity_mult` K-only) — **but only if novelty is not a K-readable input to `plasticity_mult` in the positive direction.** ⟹ **R14.2.** |

> ### **R14.2 — NOVELTY MAY ONLY REDUCE PLASTICITY, NEVER INCREASE IT.**
> `NOVELTY ⟹ SLOW_MODE ∧ plasticity_mult ↓ ∧ effect_envelope shrinks`. **(Cell T5, V3 §14 — inherited, and now stated as a directional constraint rather than a mode.)**
> **There is no rule anywhere in V4 in which a novelty measurement appears as a positive term in any of: `Δθ`, `plasticity_mult`, budget allocation, preservation priority, fitness, warrant, belief, or evidence status.**
> **The one permitted positive use:** novelty may **nominate** an item for *retention review* — i.e. "do not prune this yet, it is unlike anything else" — and that nomination is (a) rate-limited by a `[G]` novelty-retention quota, (b) **never** a `Δθ`, and (c) subject to the same quota-gaming detector P0-04 built for consolidation nomination (**B-7**). **Preservation-by-inaction under a quota** is the whole of novelty's positive authority.

> ### **R14.3 — SURPRISE IS ADMISSIBLE AS A T1 SIGNAL, NOVELTY IS NOT.**
> **Surprise** = a resolved, pre-registered prediction with non-zero error. It is a **prediction error** (§13) and inherits all of §13's discipline: R13.1 (pre-registration), R13.2 (unresolvable ≠ zero), R13.3 (not causal). **It is admissible as T1.**
> **Novelty** = distance from memory. It is **not** a prediction error, it has no external ground, and it is **inadmissible as a learning trigger.** Its only role is R14.2's plasticity reduction and the quota-limited retention nomination.
> **This resolves V3 §14's «NOVELTY → SLOW MODE» correctly:** V3 was right about the *response* (slow down) and ambiguous about the *stimulus*. V4 says: **novelty slows you down; surprise teaches you.** They are different signals doing different jobs, and conflating them either teaches from ungrounded similarity or slows down in response to genuine error.

## 14.3 Distribution shift — V3 L39's three-part response, audited

V3 L39: distribution shift ⟹ **novelty detection + slow mode + sandbox learning**. Audited:

| V3 component | Verdict |
|---|---|
| **Novelty detection** | ⚠️ **Novelty is the wrong detector** (R14.1) — it fires on manufactured difference too. **The correct detector is `MODEL_ENV_MISMATCH` (P0-01 §13 class 10): distribution tests over a window, externally measurable, with drift statistics.** ⟹ **R14.4: distribution shift is detected by class-10 mismatch statistics, NOT by novelty.** Novelty may *corroborate*; it may not *detect*. |
| **Slow mode** | ✅ **Correct.** `SLOW_MODE ⟹ lr ↓, plasticity_mult ↓, effect_envelope shrinks`. Consistent with R14.2's direction. |
| **Sandbox learning** | ⚠️ **Correct instinct, dangerous mechanism.** A sandbox is a scope in which changes have `behavioural_reach = NONE`. **That is exactly what R1.3's envelope shrinkage produces** — so "sandbox learning" is not a special mode; it is **the normal state of a heavily-provisional scope.** ⟹ **R14.5: there is no separate sandbox. `behavioural_reach = NONE` is an envelope value, and a scope enters it through R1.3 or through explicit `[G]` designation.** Collapsing "sandbox" into the envelope removes a mode that would otherwise need its own governance, its own escape conditions, and its own attack surface (§67 LEARN-A9: *escape the sandbox by claiming your changes have no reach*). |

---

# 15. HOMEOSTATIC PLASTICITY — **[O22]**

## 15.1 What it is, and why Cell §9.4 already makes it mandatory

Cell §9.4 lists four bounds on `Δθ`, and the fourth is **"mandatory homeostatic scaling."** This is not a stabiliser bolted onto learning; it is a **condition of admission**. The reason is structural:

**Hebbian-style strengthening is multiplicatively unstable.** If `weight ← weight + f(activity)`, then high activity raises weight, which raises activity, which raises weight. `Δ_MAX` bounds each step and `DELTA_BUDGET` bounds each epoch — **neither bounds the fixed point.** Homeostatic scaling is the mechanism that supplies a fixed point: it normalises total incoming strength toward a set-point, so that *relative* weights can change while *absolute* drive cannot run away.

> ### **R15.1 — HOMEOSTASIS IS NOT LEARNING (R2.3, mechanism A).**
> Homeostatic scaling **returns a quantity to a pre-existing set-point**. It produces **no `LearnedChange`**, consumes **no `DELTA_BUDGET`**, and requires **no verification** — because it does not claim improvement, it claims *maintenance*.
> **Consequence, and it is important:** homeostatic scaling **MUST NOT be blocked by an R0.1 stall.** A stalled scope has exhausted its unverified-displacement budget; if homeostasis were also stalled, the scope would become unstable *because* it stopped learning. **⟹ R15.2: homeostatic scaling is exempt from `DELTA_BUDGET` and from UDB, and is the ONE write permitted during a stall.**
> **The exemption is tightly drawn:** it is permitted **only** toward the set-point, **only** on the quantities the set-point governs, and **only** in the direction that reduces deviation. **A "homeostatic" write that increases deviation from set-point is not homeostasis and is rejected.** The set-point itself is `[G]`/genome-owned and **is not learnable** — a learner that could move its own set-point could convert homeostasis into unbounded drift with an exemption attached. **⟹ R15.3: set-points are Λ4-class and are NOT writable by the learning subsystem at any scope.**

## 15.2 The stability/plasticity relationship — the seven inherited mechanisms, re-derived

Cell §9.5 lists seven stability mechanisms. Each is audited against R0.1 to determine whether R0.1 subsumes it, complements it, or duplicates it:

| # | Cell §9.5 mechanism | What it bounds | **Relation to R0.1 (UDB)** |
|---|---|---|---|
| **1** | **Forgetting** (decay) | Retention of unused state | **Complements.** Decay reduces ‖θ‖ but not necessarily ‖θ − θ_anchor‖ — decaying toward zero is *still displacement* if the anchor was non-zero. **⟹ R15.4: decay MUST be accounted in UDB. A forgotten state is a displaced state.** (Otherwise forgetting becomes a stall-evasion channel — RH-9's cousin.) |
| **2** | **Oscillation control / metaplasticity (BCM-style)** | Rate of rate-change | **Complements.** Metaplasticity adjusts `plasticity_mult` from activity history. Cell §4.1.8 makes `plasticity_mult` K-only, so this is a **K-mediated Λ4 adjustment driven by Λ1 observations**. **⟹ R15.5: metaplasticity is the ONE permitted positive feedback on plasticity, and it is K-mediated, set-point-bounded (R15.3) and monotone-decreasing in recent displacement.** |
| **3** | **Runaway detection** | Unbounded growth | **Subsumed in part.** `Θ_MAX` bounds absolute magnitude; UDB bounds distance from verified. **Runaway is what happens when both are absent.** R0.1 + `Θ_MAX` + homeostasis (R15.1) make a third detector unnecessary for Λ1. **⚠️ Not for Λ3 — structural runaway (connection proliferation) has no `Θ_MAX` analogue. ⟹ R15.6: Λ3 changes consume a separate STRUCTURAL BUDGET with its own per-scope bound; §61.** |
| **4** | **Overfitting control via held-out probe** | Generalisation gap | **IS the anchor mechanism.** Cell §9.6's probe *is* the held-out check. R0.1 gives it a consequence it previously lacked. **⟹ R0.1 is not a new mechanism; it is §9.5(4) + §9.6 wired into §9.4.** This is the cleanest way to state what P0-05 adds. |
| **5** | **Reward hacking control** (EIK-signed reward + `utility_basis` + jump detection + T4 check) | Proxy/true gap | **Complements.** §9 extends it with RH-C1..C3, RH-7..9 and R9.4.1–3. **Note §9.5(5)'s "T4 check": self-supervised learning may not move θ toward its own reward. §48 shows this check detects *self-reward* but not *self-confirmation* (model collapse), and R0.1 bounds the latter as a special case of drift.** |
| **6** | **Feedback control (`loop_gain < 1`, off-cell)** | Closed-loop amplification | **Complements, and is the formal core.** `loop_gain < 1` is the condition for a feedback loop to converge. **⟹ R15.7: R0.1's stall is the DISCRETE fallback for when `loop_gain < 1` cannot be established.** Continuous control when the gain is known; discrete halt when it is not. **"Off-cell" (the gain must be measured/computed outside the cell whose loop it is) is inherited unchanged and is the same principle as Cell §9.6's K-only verdict and P7's governance-outside-the-loop.** |
| **7** | **Self-reinforcing belief control (`inbreeding_F`)** | Belief closure | **Complements — and is the belief-side ancestor of RH-2.** `inbreeding_F` measures how much of a belief's support is internally derived. **⟹ R15.8: `inbreeding_F` MUST be computed over the *learning* lineage as well as the belief lineage — i.e. what fraction of a change's supporting signals were produced by states that the change itself caused.** This is OR-L6 (RH-2) made *measurable*, not solved. A measurable self-confirming loop is containable (C-4's optimism budget); an unmeasurable one is not. |

## 15.3 **[O23 preview → §31] The stability/plasticity dilemma, correctly framed

The classical framing — "too stable cannot learn, too plastic cannot retain" — is a **scalar trade-off framing**, and the architecture rejects scalar trade-offs (R8.2, R10.3). The V4 framing:

> ### **R15.9 — STABILITY AND PLASTICITY ARE NOT ENDS OF ONE AXIS. THEY ARE TWO DIFFERENT QUANTITIES WITH DIFFERENT OWNERS.**
> - **PLASTICITY is a *capacity*, granted by governance (§28), measured as admissible targets × bounds × rate.** Its owner is the authorization matrix.
> - **STABILITY is a *property of the trajectory*, measured as distance from a verified anchor (UDB), gain (`loop_gain`), and deviation from set-point (homeostasis).** Its owner is the kernel.
> **They do not trade off against each other. A system can have HIGH plasticity and HIGH stability — if every change is bounded, provisional, anchored and rollback-able. It can have LOW plasticity and LOW stability — if the few changes it makes are unverified and irreversible.**
> **The inherited design's `plasticity_mult` is a scalar that conflates the two, which is why `SLOW_MODE` (a stability response) is implemented as a plasticity reduction (a capacity change). R1.3's envelope shrinkage is the corrected form: an unverified change loses *reach*, not *capacity*. The organism may keep learning; what it may do with the learning narrows.**

**This reframing has an immediate practical consequence:** `SLOW_MODE` in V3 reduces learning when the organism is uncertain. **That is backwards in the one case where learning matters most.** Under distribution shift (R14.4), the organism's model is wrong and learning is exactly what is needed; what must be reduced is the **reach** of unverified learning, not its **rate**. **⟹ R15.10: `SLOW_MODE` reduces `effect_envelope` mandatorily and MAY reduce `lr` — but a `SLOW_MODE` that reduces `lr` to zero while leaving envelope unchanged is a mis-specification, and the reverse (envelope → NONE, `lr` unchanged) is the safe default.** V3's «NOVELTY → SLOW MODE» gets the right answer for the wrong reason; R15.10 keeps the answer and corrects the reason.

---

# 16. MULTI-SCALE PLASTICITY — V3.1 §6 AUDITED

V3.1 §6 declares five scales: **synapse · cell · connection · circuit · regional.** §4.2 above re-derived six scopes ordered by blast radius with attached authority (R4.2). The audit of V3.1 §6 against R4.2:

| V3.1 §6 scale | R4.2 scope | Gap |
|---|---|---|
| synapse | S1 | ✅ P0-03 R3.2 already fixes the learnable parameter set exactly. **The best-specified scale in the corpus.** |
| cell | S2 | ✅ Cell §9.3's target table. **Strong, with one contested row (X-L1).** |
| connection | **⚠️ overlaps S1** | **"connection" and "synapse" are the same object in V3 §8** (the digital synapse *is* the connection record, with `plasticity_rate` among its 11 fields). Listing both as separate scales implies two authorities over one object — **a COMM-INV-23 (one writer per parameter group) violation waiting to happen.** ⟹ **R16.1: S1 is one scope. "Synapse" and "connection" are not two scales.** |
| circuit | S3 | ❌ **Named with no rules.** No admissible target set, no authorization, no budget, no reversibility class. **This is the largest specification hole in V3.1 §6.** ⟹ §29 (escalation) and R15.6 (structural budget) fill it. |
| regional | S4 | ❌ **Named with no rules.** Same hole, larger blast radius. |
| *(absent)* | **S5 organismal** | ❌ **Not in V3.1 §6 at all**, despite V3.1 §7 making *learning rules* evolvable — which is an S5/S6 quantity. **V3.1 varies the global learning policy through evolution while having no global plasticity scope.** ⟹ **This is X-L4 (§74): an S5 authority exercised with no S5 governance.** |
| *(absent)* | **S6 populational** | ✅ Correctly absent from *plasticity* — S6 is evolution's scope (R4.2). **Its absence from V3.1 §6 is right; its absence from any learning-scope statement is the gap that MEM-INV-21 partially fills.** |

> ### **R16.2 — THE SCALE/AUTHORITY COUPLING RULE.**
> **A scale without an attached authorization is not a scale; it is an unclaimed blast radius.** Every scope S1–S6 MUST have: (i) an admissible target set, (ii) a minimum authorization, (iii) a budget, (iv) a reversibility class, (v) a UDB scope. **V3.1 §6 has none of the five for three of its five scales.** §28 (matrix) and §29 (escalation) supply them; **§84 rates "plasticity governance" 2/10 before, on this evidence.**

> ### **R16.3 — CROSS-SCALE CONSISTENCY.**
> A change at scope `S` **MUST NOT be contradicted by an uncoordinated change at `S' ⊂ S` in the same epoch.** Cell §9.4's `lr_fast ≥ lr_medium ≥ lr_slow` kernel-enforced ordering is the S2-internal form of this: **fast timescales may not undo slow ones.** ⟹ **R16.3 generalises it across scopes: `authority(S') ≤ authority(S)` for `S' ⊂ S` (R4.3), and the kernel serialises cross-scope writes to overlapping targets.** Without serialisation, a circuit-level topology change and a cell-level weight change to the same connection can interleave, producing a state neither authorised — **and R6.5.1's trace invalidation would then have no defined epoch to invalidate against.**

---

# 17. VOLUME A — FINDINGS REGISTER

| ID | Finding | Severity | Disposition |
|---|---|---|---|
| **D-L1** | **Unverified drift.** `DELTA_BUDGET` bounds rate, not cumulative distance from the last verified state. | **CRITICAL** | **CLOSED by R0.1 (UDB).** Residual: probe cost ⟹ OR-L1. |
| **D-L2** | **"Provisional" governs accounting, not effect.** An applied change behaves as permanent while being recorded as provisional. | **CRITICAL** | **CLOSED by R1.3 (envelope shrinkage) + R0.1.** |
| **D-L3** | **No `LearnedChange` object exists.** Authority, provisionality and reversibility are scattered with no unifying record. | **HIGH** | **CLOSED by R0.2 / §1.** |
| **D-L4** | **Reversibility is not a property of a change anywhere in the corpus.** | **HIGH** | **CLOSED by A4 + R0.3.** |
| **D-L5** | **Plasticity (capacity) is governed by exactly one rule** (Cell §4.1.8, `plasticity_mult` K-only). No matrix, no grant/withdraw protocol. | **HIGH** | **CLOSED by §28 (Vol B).** |
| **D-L6** | **Novelty and surprise share one name and have different grounds** (R14.1). Novelty is trivially manufacturable and has positive authority in V3 §8/§9. | **HIGH** | **CLOSED by R14.1/R14.2/R14.3.** |
| **D-L7** | **`UNATTRIBUTABLE` has no consequence.** Recorded, then nothing. Systematic unattributability ⟹ silent permanent stall. | **HIGH** | **CLOSED by R6.4.3 (escalating finding + named stall reason).** |
| **D-L8** | **V3.1 §9's ten-term scalar selection score** contradicts P0-01 §14's vector fitness and R12.2's scalarisation rule; contains a tautology (`stability − instability`) and RW-7 contamination (`cooperation`). | **HIGH** | **CLOSED by R10.3 / R10.3.1–4. Logged X-L2.** |
| **D-L9** | **V3.1 §6 names five plasticity scales with no authority, budget, reversibility or target set for three of them**, and omits S5 entirely while §7 varies S5 quantities through evolution. | **HIGH** | **CLOSED by R4.2/R16.1/R16.2/R16.3. Logged X-L4.** |
| **D-L10** | **`SLOW_MODE` reduces learning rate under distribution shift** — the one condition where learning is most needed. | **MEDIUM** | **CLOSED by R15.10 (reduce reach, not rate).** |
| **D-L11** | **RH-2 evaluator manipulation is unclosable.** The organism is causally upstream of its own evidence; learning is the mechanism of the filtering. | **CRITICAL — UNCLOSED** | **CONTAINED (C-1…C-4, R9.3). Registered OR-L6. §86 reports SECURITY and EVOLUTION status accordingly.** |
| **D-L12** | **R0.1 moves the attack surface to the probe (RH-7/RH-8).** | **HIGH** | **BOUNDED by R9.4.1 (secret schedule) + R9.4.2 (gamed probe ⟹ shorter leash) + R9.4.3 (anchor decay). Not closed.** |
| **D-L13** | **Pruning by disuse is irreversible survivorship bias** (V3 §8 «persistent uselessness → prune»). | **HIGH** | **CLOSED by §2.4's ruling + R6.4.2's CR-B ablation requirement + R15.6's structural budget. Full treatment §61.** |
| **D-L14** | **UDB computed over θ alone leaves structural drift unbounded** (RH-9). | **HIGH** | **CLOSED by R9.2.4 (UDB over all admissible targets at scope).** |
| **X-L1** | Cell §9.3 permits memory-policy plasticity at C3+; P0-04 X-M1 rejects it for E2+ records. | **LIVE CONTRADICTION** | **PROPOSED RESOLUTION (R11.3): split `θ_write_local` / `θ_write_shared`. PENDING RATIFICATION — P0-05 may not unilaterally amend P0-04.** |
| **OR-L1…L6** | Probe economics; Λ3 verification; cross-scope interaction; learning from avoided outcomes; meta-probe circularity; RH-2 evaluator manipulation. | **OPEN RESEARCH** | **§81 register (Vol F). None hidden; none solved by constant.** |

---

# 18. SCOPE, UDB AND THE LOCAL/GLOBAL QUESTION — SETUP FOR VOL B

R0.1's UDB is **per-scope** (R4.2, R4.3). That decision — six scoped bounds rather than one global bound — is what defeats the O(N²) global learner, and §35 (Vol B) proves it. The setup, stated here so Vol B can assume it:

| Property | Statement |
|---|---|
| **UDB is scoped** | `‖θ_S − θ_anchor(S)‖ ≤ UDB_MAX[S]` for each `S ∈ {S1…S5}`. **No global UDB exists**, because a global UDB requires a global θ and a global anchor — i.e. a global learner. |
| **Stall is scoped** | A stall at `S` halts writes **at `S` and below** (a stalled circuit cannot be rescued by a cell-level write to the same target). It does **not** halt other scopes. **⟹ R18.1: stall propagation is downward-only.** |
| **Anchors are scoped** | `θ_anchor(S)` is verified by a probe at scope `⊇ S` where possible (C-2). At S5 no larger scope exists ⟹ **S5 anchors are the weakest in the architecture and S5's `UDB_MAX` MUST be the smallest.** ⟹ **R18.2: `UDB_MAX` is monotonically **decreasing** in scope.** This is the inverse of the intuition that bigger changes get bigger budgets, and it is correct: **bigger scopes have weaker verification, so they get less unverified room.** |
| **Homeostasis is exempt** | R15.2 — the one write permitted during a stall. |
| **Observability is global** | §63: the *accounting* is globally visible even though the *bounds* are scoped. `O(6 × 22) + O(36)` counters (R52.3), not `O(N²)` state. **This is the whole trick: global visibility of scoped quantities, without global authority over them.** |

**R18.2 is the most counter-intuitive rule in Volume A and the one most likely to be mis-implemented, so its rationale is restated:** the purpose of UDB is to bound *unverified* displacement. Verification strength decreases with scope (C-2 becomes unavailable at S5; Λ3 probes do not exist per OR-L3; cross-scope interaction is invisible per OR-L4). **Therefore the quantity of displacement that may be tolerated without verification must also decrease with scope.** A design that gives S5 a larger budget because S5 changes are "more important" has inverted the logic: importance is not the criterion, **verifiability is**, and R0.3 already established that authority scales with irreversibility rather than magnitude. R18.2 is R0.3 applied to budgets.

---

**END OF VOLUME A.**
**Next:** `41_analysis_signals_authority.md` — Vol B (§19–§34): the learning-signal taxonomy (**[O8]**), local vs global (**[O16]**), signal provenance/authenticity/independence (**[O17][O18][O19]**), the plasticity authorization matrix (**[O20]**), structural escalation (**[O21]**), stability/plasticity (**[O23]**), learning↔replication/evolution (**[O36]**), the Baldwinian boundary (**[O37]**), meta-learning (**[O38]**), forgetting (**[O26-related]**), and the plasticity budget.
