# P0-05 — LEARNING, PLASTICITY & ADAPTATION CONTRACT
## Volume C — Scope, Exploration, Knowledge Flow (§35–§52)

**Status:** adversarial architecture audit. **Architecture only.** No implementation, no numerical parameter values.
**Depends on:** Vol A (R0.1 UDB, R0.2 `LearnedChange`, R4.1 Λ, R4.2/R4.3 S1–S6, R6.4 credit, R8.1 reward admissibility), Vol B (§19 signals, §28 matrix, §29 ladder, §30 budgets, §31 stability).

> **Outputs discharged:** O16 (local vs global), O24 (exploration/exploitation), O25 (safe exploration), O26 (failure learning), O27 (abstention cascade), O28 (memory↔plasticity), O38 (meta-learning — capability half), O39 (self-training), O40 (simulation learning), O41 (knowledge transfer), O42 (specialisation/diversity).

---

# 35. **[O16] LOCAL VS GLOBAL LEARNING — AND WHY NO GLOBAL LEARNER IS NEEDED

## 35.1 The question, and the trap in it

> *"How is credit assigned across cells, circuits and the organism without creating a global learner?"* (§16 of brief; §87: **DO NOT create an O(N²) global learner merely to solve credit assignment.**)

The trap: the question invites a **scale** answer ("credit is assigned locally, and occasionally globally"). Scale is the wrong axis. R6.4.1 already gave the credit answer — **credit is a local computation over a scoped trace, and there is no credit object above the scope that computed it.** §35 generalises it from credit to *all* global-learning pressure, and shows the pressure dissolves once R0.1's UDB is scoped.

## 35.2 What "global learning" would require, itemised

| Requirement of a global learner | Cost | **Does V4 need it?** |
|---|---|---|
| A global state vector `Θ` | `O(N)` storage, `O(N)` coherence | ❌ **No.** R0.1's anchor is per-scope (`θ_anchor(S)`). There is no global θ, so there is no global anchor. |
| A global `‖Θ − Θ_anchor‖` | `O(N)` per check, and requires a global anchor | ❌ **No.** Six scoped UDBs, `O(6)` counters (R18, §52). |
| Global credit attribution | **`O(N²)` pairs** | ❌ **No.** R6.4.1 — no credit object above the computing scope. |
| Global observation of all signals | `O(signals)` fan-in to one point | ❌ **No.** Signals are consumed at their scope (§19, R20.4's `admissible_for` is scope-typed). |
| Global conflict resolution between scopes | A central arbiter | ⚠️ **Needed — but not as a learner.** §35.4. |
| Global visibility of the accounting | `O(scopes)` | ✅ **Yes — and this is the ONLY global quantity.** §35.5. |

> ### **R35.1 — THE ORGANISM HAS GLOBAL *VISIBILITY* AND NO GLOBAL *AUTHORITY*.**
> **Visibility** (`O(6)` scoped counters, readable by governance and by §63's monitors) is cheap and is required for audit.
> **Authority** (a component that may write across scopes, aggregate credit globally, or re-anchor from a global state) is `O(N²)`, is the hidden governance layer §65 forbids, and is **not required by any rule in this contract.**
> **⟹ The distinction between visibility and authority is the whole answer to §16.** Prior contracts in this series made the same move: P0-03 refused to make every comm event globally visible while making the *warrant* globally checkable; P0-04 refused global strong consistency while making *admission* globally uniform. **P0-05 refuses a global learner while making the *budget accounting* globally visible.**

## 35.3 The scoped-UDB argument, stated as a proof sketch

**Claim.** Credit assignment, drift bounding and verification can all be performed with **no component holding state or authority over more than one scope**, at total cost `O(N)`.

**Argument.**
1. **Changes are scoped.** Every `LearnedChange` has a `scope_id` ∈ {S1…S5} (R0.2). A change at S writes only targets at S or below (R28.1's matrix: Λ-writability is scope-indexed).
2. **Displacement is scoped.** `UDB(S) = ‖θ_S − θ_anchor(S)‖` is computed from state at S and an anchor at S (R0.1). Computing it requires no knowledge of any S' ≠ S.
3. **Credit is scoped.** `credit(S) : traces(S) → weights(S)` (R6.4.1). No `credit(S')` for `S' ⊃ S` **exists as an object.**
4. **Stall is scoped and propagates downward only** (R18.1). A stall at S requires no coordination with S' ≠ S.
5. **Verification is scoped-upward, not scoped-global.** A change at S is probed at scope `⊇ S` where possible (C-2). **`⊇ S` is one level up, not "global"** — and at S5 the option is unavailable, which is why R18.2 makes `UDB_MAX` smallest there.
6. **Anchors are scoped.** Re-anchoring at S writes `θ_anchor(S)` only.
7. **∴** Each of the six scopes maintains `O(|S|)` state and performs `O(|S|)` work. **Σ|S| over a partition of the organism = `O(N)`.** No component holds `O(N)` state; no computation is `O(N²)`.
8. **The residual:** cross-scope *interaction* — two scopes jointly causing an outcome — is **not computed by anyone.** **This is a real loss (OR-L4), and it is the price of `O(N)`.** ∎

> ### **R35.2 — THE PRICE OF NO GLOBAL LEARNER, STATED HONESTLY.**
> **The architecture cannot detect a distributed failure whose parts are each locally compliant.** Two scopes, each inside its own UDB, each with locally valid credit, each with locally passing probes, may jointly produce behaviour that neither can see and no scope is authorised to evaluate.
> **This is the same shape as P0-03's dim-6 (undetectable) and P0-04's OR-M18 (selection⟷filtering circle), and it is the third time this series has had to accept it.**
> **Containment, not closure:** (a) §63's monitors observe **cross-scope correlation** of stall/verdict/envelope states without observing cross-scope *content* — a correlation monitor is `O(6²)` = `O(36)`, not `O(N²)`; (b) E7-level structural changes require **cross-scope probes** (C-2 at the top of the ladder), which is the one place the architecture pays for a wider view; (c) **OR-L4 is registered as open and is reported in §86's SCALABILITY status.**
> **⟹ A correlated monitor over six scoped summaries is the maximum global cognition V4 permits, and it is deliberately a monitor rather than a learner: it may raise a FINDING, and it may not write θ, weights, topology or policy (R19.2).**

## 35.4 Global conflict resolution without a global learner

Two scopes may want incompatible things: S2 wants to strengthen a connection that S3 wants to prune; S3's topology change invalidates S2's traces.

| Conflict | Resolution | Authority |
|---|---|---|
| **Write conflict on a shared target** | **Serialisation** (R16.3). The kernel serialises cross-scope writes to overlapping targets. | K |
| **Trace invalidation** | **R6.5.1** — a Λ3 change at S invalidates all CR-A traces at S. | K, automatic |
| **Authority conflict** | **R29.1/R4.3** — the higher scope wins, because `authority` is monotone in scope. **No negotiation, no voting.** | Structural |
| **Budget conflict** | **R30.2** — budgets are not transferable, so there is nothing to negotiate. | Structural |
| **Stall conflict** | **R18.1** — downward propagation. A stalled S3 halts S2 writes to S3 targets. **An S2 scope cannot "route around" a stall.** | K |
| **Objective conflict** | **P0-01 §11: the organism may not resolve its own objective conflicts.** Escalates to `[RO-13]`. | POLICY |

> ### **R35.3 — EVERY GLOBAL CONFLICT IS RESOLVED BY A PRE-DECLARED ORDERING, NOT BY AN ARBITER.**
> Scope ordering (R4.3), rung ordering (R29.4), timescale ordering (R32.3), budget non-transferability (R30.2), stall propagation direction (R18.1). **Five total orderings, all kernel-enforced, all declared in advance.**
> **⟹ There is no global arbiter, because there is no global *decision*. Every conflict has a predetermined winner.** An arbiter would be a component with authority over all scopes — i.e. a global learner with governance power, which is exactly what §65 exists to prevent. **The five orderings are the mechanism by which "no global learner" survives contact with real conflicts.**

## 35.5 **[O16] R35.4 — THE LOCAL/GLOBAL CONTRACT

| Quantity | Local (scoped) | Global |
|---|---|---|
| **θ, weights, topology** | ✅ written | ❌ no global object exists |
| **Eligibility traces** | ✅ per-connection, λ-decayed | ❌ |
| **Credit** | ✅ computed (R6.4.1) | ❌ **no object** |
| **UDB / anchor** | ✅ per scope | ❌ |
| **Probe / verdict** | ✅ at scope `⊇ S` where possible | ⚠️ **S5 only, and weakest (R18.2)** |
| **Budgets B1–B7** | ✅ per scope | ❌ **not transferable (R30.2)** |
| **Stall** | ✅ per scope, downward propagation | ❌ |
| **Plasticity authorization** | ✅ applied | ✅ **the MATRIX is global** — one `[RO-13]` artifact, read-only (§28) |
| **Invariants** | ✅ enforced | ✅ **global and fixed (R24.3's core)** |
| **Accounting / observability** | ✅ produced | ✅ **consumed — `O(6)` counters (§63)** |
| **Correlation monitor** | — | ⚠️ **`O(36)`, FINDING-only (R35.2)** |
| **Governance functions (`F`, matrix, ladder, `UDB_MAX`)** | ❌ | ✅ **`[RO-13]`/KC only (R19.2, R24.2)** |

**The table's shape is the finding: the global column contains only *read-only artifacts* (matrix, invariants, governance functions), *counters*, and *findings*. It contains no writable state.** A global learner requires global writable state. **There is none.**

---

# 36. **[O24] EXPLORATION / EXPLOITATION

## 36.1 The inherited position, and its gap

V3 has no exploration/exploitation contract. It has: `NOVELTY → SLOW MODE` (§14), «useful novelty → preserve» (§8), `useful novelty` as a selection-score term (V3.1 §9), and «repeated demand → specialize» (§18). **Not one of these is an exploration mechanism.** `SLOW MODE` is a *reduction* of learning under novelty — the opposite of exploration. «Useful novelty → preserve» is a *retention* rule. `useful novelty` in the score is a *selection* term. «Specialize» is *exploitation*.

> ### **⟹ THE INHERITED DESIGN HAS EXPLOITATION AND NO EXPLORATION.** It reduces plasticity when it encounters the unfamiliar (V3 §14), and specialises when it encounters demand (V3 §18). **Both responses move the organism toward the familiar.** §84 rates "exploration architecture" 1/10 before.

**This is not an oversight of a tuning parameter. It is the absence of a mechanism**, and its consequence is concrete: an organism built to V3 will, under distribution shift, **slow down and specialise harder on what it already does** — precisely the wrong response, and precisely what R15.10 was written to correct.

## 36.2 Why exploration cannot be a reward

The obvious fix — an intrinsic curiosity reward (RW-6) — is **prohibited** by R8.1, and §14.2 explains why the prohibition is right: **novelty is computed as distance from the organism's own memory, so it is manufacturable at zero cost.** A curiosity reward is an invitation to farm novelty, and novelty farming produces unbounded retention, unbounded learning on ungrounded signal, and unbounded budget consumption.

> ### **R36.1 — EXPLORATION IS A BUDGET ALLOCATION, NOT A REWARD.**
> Exploration is the **spending of a granted budget on actions whose outcomes are less predictable**, under governance authority. **It is not something the organism is rewarded for; it is something the organism is *permitted* to do, within a quota.**
> **The difference is structural:**
> - A **reward** for exploration creates a gradient the learner ascends ⟹ farming ⟹ RH-6.
> - A **budget** for exploration creates a ceiling the learner operates under ⟹ the incentive is to spend it *well*, and "well" is measured by the same external probe that measures everything else (R0.1).
> **⟹ `EXPLORATION_BUDGET[scope]` is B8, a `[G]`-owned, non-transferable (R30.2), use-it-or-lose-it budget.**

## 36.3 The exploration contract

```
ExplorationGrant {
  scope            : ScopeID
  budget           : EXPLORATION_BUDGET[scope]        // B8 — [G], non-transferable
  granted_by       : enum{POLICY(RO-13), EIK}          // NEVER self-granted
  admissible_actions : predicate                       // what counts as "exploratory"
  envelope_ceiling : effect_envelope                     // ⟵ R36.2: exploration NEVER exceeds
                                                        //    the scope's current envelope
  accounting       : {spent, outcome_class}             // outcome_class ∈ §36.4
  obligation       : BOUNDED_EXPOSURE_OBLIGATION        // ⟵ §40, R40.3
}
```

> ### **R36.2 — EXPLORATION OPERATES UNDER THE ENVELOPE, NEVER ABOVE IT.**
> An exploratory action is a **real action with real consequences**, and its `effect_envelope` is bounded by the scope's current envelope (R1.3, R15.10). **A scope in `PROVISIONAL-AGED` with `envelope = NONE` may not explore.**
> **Why:** exploration is where an organism touches the world in ways it has not verified. **That is exactly the condition under which R1.3 shrinks reach.** Letting exploration bypass the envelope would make "I am exploring" a universal excuse for unbounded reach — **and it is the exploit §67 names LEARN-A9 (claim your changes have no reach / claim your changes are exploration).**

> ### **R36.3 — EXPLORATION MAY NOT BE SELF-GRANTED, SELF-EXTENDED OR SELF-RENEWED.**
> Grant, extension and renewal are SC-4 governance directives (R19.2). **A scope that exhausts its exploration budget stops exploring.** It does not earn more by having explored successfully — because "successfully" would be self-assessed (RW-8, ∅), and because a self-renewing budget is a currency (R30.2).
> **⟹ The legitimate route to more exploration is a FINDING to `[RO-13]`** (§6.4.3's escalation pattern, R33.2's flag pattern): *this scope's task has high class-10 mismatch and low exploration budget; the budget is mis-allocated.* **The finding is readable and non-binding. The governance response is a grant.**

## 36.4 Exploration outcomes — the accounting that makes it honest

| `outcome_class` | Meaning | Consequence |
|---|---|---|
| **EX-1 — INFORMATIVE** | The action resolved a registered prediction (§13.2) that could not otherwise have resolved | **Counts as budget well spent. Observable (§63).** Feeds R10.3.1's `verified learning throughput`. |
| **EX-2 — NEUTRAL** | No prediction resolved; no harm | Budget spent, no finding |
| **EX-3 — COSTLY** | Consumed resources or produced a constraint violation (SG-10) | **Blocks further exploration at that scope until reviewed.** RW-2 is gating, not gradient (R8.1). |
| **EX-4 — NOVELTY ONLY** | Produced high novelty (SG-5), no resolved prediction | **⚠️ FLAGGED.** This is the novelty-farming signature. **Contributes to R14.2's retention quota accounting and to a B-7-class quota-gaming finding. Does NOT count as informative.** |
| **EX-5 — UNRESOLVABLE** | The action's outcome never resolved | **Counts against the budget and generates a class-10 finding (R13.2).** **Not zero.** |

> ### **R36.4 — EXPLORATION IS MEASURED BY RESOLVED PREDICTIONS, NOT BY NOVELTY.**
> **EX-1 is the only positive class, and it is defined by the resolution of a pre-registered prediction** — the one quantity in the architecture that is simultaneously dense, cheap, attribution-free (R6.4.4) and **not manufacturable without external cooperation** (R13.1 requires pre-registration; R14.1 shows novelty does not).
> **⟹ This is the single most important design choice in §36.** It converts exploration from "seek the unfamiliar" (farmable) into "seek the resolvable" (not farmable, because resolution requires the world to answer). **An organism that explores well is one that asks questions the world can answer.**

## 36.5 Exploration ↔ exploitation, without a trade-off parameter

R31.1 refused a scalar stability/plasticity trade-off. §36.5 refuses the scalar exploration/exploitation trade-off for the same reason.

> ### **R36.5 — THERE IS NO `ε`. EXPLORATION AND EXPLOITATION ARE SEPARATELY BUDGETED, SEPARATELY AUTHORISED, AND SEPARATELY MEASURED.**
> - **Exploitation** is the ordinary operation of verified competence. It consumes **no exploration budget**. It is bounded by B1–B7 like everything else.
> - **Exploration** consumes **B8**, is granted by governance (R36.3), operates under the envelope (R36.2), and is measured by EX-1 (R36.4).
> - **The "trade-off" is a governance allocation decision** — how much B8 to grant each scope — **made outside the loop (P7) by an authority that is not optimising anything the learner controls.**
> **⟹ Consequence: the organism cannot learn its way to a better exploration/exploitation balance, because the balance is not a quantity in its parameter space.** It can *request* a different allocation (R36.3's finding) and it can *spend* its allocation well (EX-1). **It cannot set it.** This is a real loss of adaptiveness and it is accepted deliberately: an ε the learner controls is a reward it mints.

---

# 37. **[O25] SAFE EXPLORATION

## 37.1 The four constraints

| # | Constraint | Instrument |
|---|---|---|
| **SE-1** | **Exploration may not violate a hard constraint** | SG-10 / RW-2 is **gating**: a violated constraint blocks learning (R8.1) and blocks further exploration (EX-3) |
| **SE-2** | **Exploration may not exceed the current envelope** | R36.2 |
| **SE-3** | **Exploration may not be irreversible** | **⟹ R37.1** |
| **SE-4** | **Exploration may not consume another scope's budget or authority** | R30.2, R29.1 |

> ### **R37.1 — EXPLORATORY ACTIONS ARE RESTRICTED TO A4 ∈ {`DECAYS`, `ROLLBACKABLE_IN_MEMORY`, `CHECKPOINT_REVERSIBLE`}.**
> **An exploratory action may NOT be `IRREVERSIBLE_STRUCTURAL`.** No E3+ rung (§29) may be taken under an exploration grant. **Topology is not explored; it is *proposed*, authorised at a rung, and verified by CR-B ablation.**
> **Why this is the right line:** R0.3 says authority scales with irreversibility. Exploration is the *least* authorised activity in the system (self-directed within a granted budget, unverified by definition). **The least authorised activity must therefore have the least irreversible consequences.** R37.1 is R0.3 applied to exploration, and it falls out rather than being designed.

## 37.2 Safe exploration under RH-2

**The problem.** Exploration changes the organism's behaviour, which changes the world it samples, which changes the evidence that verifies it (§9.3). **Exploration is therefore the most RH-2-exposed activity in the architecture** — it is *deliberately* causal intervention on the organism's own evidence supply.

| Containment | Rule |
|---|---|
| **Exploration inputs are declared** | `admissible_actions` in the grant is `[RO-13]`-set. **The learner may choose *within* the predicate, not the predicate.** ⟹ **R37.2: the exploration *space* is governance-owned; the exploration *choice* is learner-owned.** |
| **Exploration outcomes do not self-verify** | EX-1 requires a **resolved pre-registered prediction**, and the resolution is an external observation (SG-1 at SC-3 where available). **Exploration may produce evidence; it may not produce a verdict.** |
| **Exploration does not re-anchor** | **⟹ R37.3: an anchor may not be earned from a probe conducted within an exploration grant.** Exploration widens the sample; verification requires a probe under C-1's `[RO-13]`-owned input distribution. **Otherwise the organism explores its way to a favourable anchor — RH-8 with a budget.** |
| **Exploration is observable** | EX-class counts, per scope, are §63 counters. **A scope whose exploration is concentrated in a narrow region of `admissible_actions` is flagged** — the signature of exploration that has been shaped to confirm. |

## 37.3 The residual, honestly

> **Safe exploration in this architecture means: bounded, reversible, envelope-constrained, governance-scoped, non-anchoring, observable exploration.** It does **not** mean exploration that cannot cause harm — EX-3 exists precisely because it can — and it does **not** mean exploration whose results are free of RH-2 contamination. **R37.3 keeps exploration from *verifying* itself; it cannot keep exploration from *shaping* what later verifies the organism.** OR-L6 stands.

---

# 38. **[O38] META-LEARNING — THE CAPABILITY HALF

§24/R24.3 established the **authority** half: Λ4 is writable only at S5 by `[RO-13]`/EIK; a learning subsystem may never write its own Λ4; learning-rule variation through CH-3 requires the fixed validation core; OR-L2 (the meta-probe circularity) is open.

§38 establishes what meta-learning **may do** inside those bounds.

## 38.1 The three levels, and which are permitted

| Level | **What varies** | Permitted? | Instrument |
|---|---|---|---|
| **M0 — LEARNING** | θ, weights (Λ1) | ✅ | Cell §9.4, all of Vol A/B |
| **M1 — META-LEARNING** | **the *use* of Λ4 parameters within `[G]` bounds**: which `lr[timescale]` to apply in which context, when to enter `SLOW_MODE`, how to allocate `DELTA_BUDGET` across timescales, how to weight `confidence_in_error` | ✅ **CONDITIONALLY** | **⟹ R38.1** |
| **M2 — META-META-LEARNING** | **the Λ4 bounds themselves**: `Δ_MAX`, `UDB_MAX`, `lr` ordering, admissible targets, the matrix, the ladder | ❌ **PROHIBITED** | R19.2, R24.2, R28.1's Λ4 column, §28.2 fact #2 |
| **M3 — varying the validator** | the fixed core (R24.3) | ❌ **∅ — NO WRITE PATH AT ANY ALTITUDE** | R24.3, Rule 19 of the 20 CRITICAL RULES |

> ### **R38.1 — M1 IS PERMITTED AS `[G]`-BOUNDED SELECTION AMONG KERNEL-OWNED PARAMETERS.**
> A meta-learner **chooses among** admissible values of Λ4 parameters. **It does not set their bounds, and it does not write them.**
> **Formally: the meta-learner's output is a *selection* `select(param_id, context) → value ∈ [G]_bounds(param_id)`, and the *write* is performed by K.**
> **This is exactly the structure P0-04 established for memory-policy variation (X-M2 / R46.1): the cell may vary within bounds; the bounds are policy.** R38.1 is that resolution, generalised to all Λ4 parameters. **The same one-name-two-altitudes defect (X-E, X-G, X-M1, X-M2, X-L1, X-L5) is resolved the same way: split the *selection* (learnable, bounded) from the *bound* (policy, fixed).**

> ### **R38.2 — M1 CONSUMES UDB AT S5.**
> A meta-selection is a change in the organism's learning behaviour and therefore consumes `UDB_MAX[S5]` — which R18.2 makes the **smallest** budget in the architecture, because S5 has the **weakest** verification (C-2 unavailable).
> **⟹ Meta-learning is the most tightly leashed activity in V4, and it is leashed by the same mechanism as everything else.** No special meta-mechanism is required, which is the strongest available evidence that R0.1 was the right primitive.

> ### **R38.3 — THE META-OBJECTIVE IS NOT LEARNABLE.**
> **What the meta-learner selects *for* is `[RO-13]`-owned.** It may not acquire, modify or infer its own objective. **A meta-learner that could choose its selection criterion could choose "select for whatever I am currently good at"** — which is C3's circularity (rejected in §2) returned at the highest altitude.
> **⟹ Specifically: the meta-learner may NOT optimise `verified learning throughput` (R10.3.1), because that quantity is the measure by which the meta-learner is itself evaluated.** R10.2's principle — *fitness must not be a learning target* — applies with full force at M1: **the meta-objective must not be a meta-learning target.**

## 38.2 OR-L2 restated at the capability level

R24.3 identified OR-L2 as the *evolutionary* form: a genome-diff that changes learning rules changes the instrument verifying the next diff. §38 identifies its *ontogenetic* form:

> **A meta-learner that improves its own selection policy improves the policy by which its future selections are judged.** The fixed validation core (R24.3) contains the *evolutionary* validator. **Does it contain the *meta-learning* validator?**
> **⟹ R38.4: YES, and it must.** The criteria by which an M1 selection is probed are part of the fixed core, are `[RO-13]`-owned, and are **not selectable by the meta-learner.** The meta-learner chooses `lr` values; the core chooses how to judge whether the choice was good.
> **Residual (OR-L2, unchanged):** the fixed core is a **governance decision**. P0-05 requires that it exist and be non-empty (R24.3); it does not and cannot specify its contents, because specifying them would be specifying the organism's values. **This is declared, not hidden.**

---

# 39. **[O26] FAILURE LEARNING — AND WHY CELL T7 IS RIGHT

## 39.1 The counter-intuitive inherited rule

Cell §9.2 T7: **repeated failure ⟹ `plasticity_mult` REDUCTION, not more learning.** V3 §18 says «persistent failure → repair/replace». These look contradictory and are not:

| | **Cell T7** | **V3 §18** |
|---|---|---|
| **Response** | Reduce plasticity at the failing scope | Repair or replace the failing component |
| **Authority** | K, automatic (SC-2) | `ORGANISM`+ (an E3/E5 rung) |
| **What it addresses** | **The learning process** | **The component** |
| **Timescale** | immediate | governed, escalated |

**Both are correct and they operate at different altitudes.** T7 is a *plasticity* response; §18 is a *structural* response. **V3's defect is that it lists them in one sentence («persistent failure → repair/replace») with no authority attached, so nothing prevents the structural response from firing without the escalation ladder (§29) that R0.3 requires.** ⟹ **R39.1: V3 §18's "repair/replace" is an E3/E5 rung and requires its full authority, verification (CR-B) and tombstone (R27.2). It is not an automatic response to failure.**

## 39.2 Why reducing plasticity on failure is right

The naive response to failure is "learn more." Four reasons it is wrong here:

| # | Reason |
|---|---|
| **1** | **Repeated failure means the signal is unreliable.** If the same action fails repeatedly and the organism cannot determine why, the failure is not informative about θ — it is informative about **the model/environment match** (class 10) or about **attribution** (`UNATTRIBUTABLE`). Increasing `lr` on an uninformative signal amplifies noise. |
| **2** | **Repeated failure with continued plasticity produces oscillation.** Cell §9.5(2)'s BCM-style metaplasticity exists for this. **Failure ⟹ high error ⟹ large `Δθ` ⟹ overshoot ⟹ failure ⟹ …** Reducing `plasticity_mult` is the damping term. |
| **3** | **Failure may be caused by the environment, not the model.** Increasing plasticity in a hostile or shifted environment makes the organism **fit the hostility** — which is RH-2's ontogenetic form: adapt to the corrupted evaluator rather than detect the corruption. |
| **4** | **Failure reduces verification capacity.** A failing scope's probes are more likely to return `REGRESSED` or `UNKNOWN`, so its anchors are weak, so its `UDB_MAX` is small (R9.4.2, R33.1). **High plasticity + small UDB = immediate stall.** Reducing plasticity is what keeps the scope operational at all. |

> ### **R39.2 — FAILURE LEARNING IS A THREE-PART RESPONSE, IN A FIXED ORDER.**
> 1. **DAMP** (automatic, K, SC-2): `plasticity_mult ↓`, envelope ↓, `SLOW_MODE`. **No `Δθ`.**
> 2. **DIAGNOSE** (SC-2/SC-3): classify the failure — `error_class` from P0-01 §13's ten, plus `UNATTRIBUTABLE` (§6), plus `disuse_cause` where relevant (R27.3). **⟹ R39.3: a failure with no `error_class` classification generates a FINDING, not a `Δθ`.** An unclassified failure is not a learning signal; it is an unknown.
> 3. **ESCALATE** (governance): if diagnosis indicates a component defect ⟹ E3/E5 rung under §29. If it indicates class-10 mismatch ⟹ R14.4/R33.1. If it indicates mis-specified `credit_horizon` ⟹ R6.4.3(4). **Never a θ change made in response to unclassified failure.**

## 39.3 The failure→avoidance loop

> ### **THE PATTERN.** Failure ⟹ reduced plasticity and `SLOW_MODE` ⟹ reduced engagement with the failing context ⟹ **fewer observations from that context** ⟹ less corrective evidence ⟹ the model of that context degrades ⟹ predicted failure on re-engagement ⟹ more avoidance.
> **This is a positive feedback loop whose gain is the avoidance rate, and it converges on a fixed point where the organism never re-tests the context it failed at.**

**It is the same pattern as three others already identified in this series:**

| Instance | Contract | Loop |
|---|---|---|
| **Abstention cascade** | P0-04 **L-11 / OR-M19** | abstain ⟹ no output ⟹ no external evaluation ⟹ no warrant gain ⟹ abstain more |
| **Availability capture / survivorship bias** | P0-04 §26.3 | rarely retrieved ⟹ rarely used ⟹ appears useless ⟹ deprioritised ⟹ rarely retrieved |
| **Pruning by disuse** | V3 §8, **D-L13** | unreachable ⟹ unused ⟹ appears useless ⟹ **pruned irreversibly** ⟹ permanently unreachable |
| **Failure→avoidance** | **P0-05 §39.3** | fail ⟹ avoid ⟹ no corrective evidence ⟹ model degrades ⟹ fail |
| **Exploration starvation** | **P0-05 §36/§37** | low B8 ⟹ no EX-1 ⟹ no resolved predictions ⟹ no anchor ⟹ stall ⟹ lower throughput ⟹ lower B8 justification |

> ### **R39.4 — THESE FIVE ARE ONE PATTERN: THE EVIDENCE-STARVATION CASCADE.**
> **DEFINITION.** An *evidence-starvation cascade* is any mechanism by which **a reduction in engagement reduces the corrective evidence that would justify re-engagement**, so that the reduction is self-reinforcing.
> **GENERAL FORM.** `engagement ↓ ⟹ corrective_evidence ↓ ⟹ estimated_competence ↓ ⟹ engagement ↓`. **The loop gain is positive and there is no external term.**
> **P0-04 found one instance (L-11). P0-05 finds four more. ⟹ The general pattern is named here, and the general counterweight is specified in §40.**

## 39.4 Why this is P0-05's problem and not only P0-04's

P0-04's L-11 was a *memory* cascade: abstention starves warrant. **P0-05's instances are *learning* cascades: avoidance starves verification.** The distinction matters because the counterweight differs:

- **P0-04's counterweight (§90):** a **bounded optimism budget** — permission to act on unverified positive self-assessment, capped. This addresses *warrant* starvation.
- **P0-05's counterweight:** a **bounded exposure obligation** — a *requirement* to re-engage, capped. This addresses *verification* starvation.

**They are duals.** P0-04 permits a little unjustified confidence; P0-05 requires a little unjustified engagement. **Both are deliberately bounded violations of the architecture's own conservatism, and both exist for the same reason: a purely conservative system converges on silence.**

---

# 40. **[O27] THE ABSTENTION CASCADE — GENERALISED

## 40.1 The inherited finding

P0-04 **L-11 / OR-M19**: abstention cascades. A component that abstains produces no output; no output receives no external evaluation; no evaluation raises warrant; low warrant increases abstention. **The safe action is the unlearnable one.**

§6.5 (OR-L5) found the same shape from the credit side: **a prevented outcome has no observation, hence no prediction error, hence no signal. Learning from successful avoidance is structurally impossible in a prediction-error architecture.**

**These are one finding, and it is the most consequential unresolved problem in P0-05.**

> ### **R40.1 — THE ABSTENTION CASCADE IS THE LEARNING SYSTEM'S PRINCIPAL STRUCTURAL WEAKNESS, AND IT IS NOT A BUG.**
> **It is the direct consequence of three correct decisions taken together:**
> 1. **Prediction error is the primary signal** (P0-01 §12.2, R6.4.4) — because it is dense, cheap and attribution-free.
> 2. **Prediction error requires an observation** (R13.1) — because an unregistered or unresolved prediction carries no information.
> 3. **Abstention produces no observation** — because there is nothing to observe.
> **∴ The architecture's cheapest, safest, most abundant learning signal is structurally unavailable for exactly the decisions where being wrong is most costly.**
> **Any architecture that satisfies 1–3 has this property. Relaxing 1 makes learning economically infeasible. Relaxing 2 admits hindsight error (R13.1). Relaxing 3 means treating a non-event as an event — which is fabrication.**

## 40.2 The containment

| # | Containment | Rule | What it buys |
|---|---|---|---|
| **1** | **Abstention is observable and counted** | **⟹ R40.2: `abstention_rate[scope][context_class]` is a mandatory §63 counter.** A rising abstention rate at fixed context distribution is the cascade's signature. | Detection. **P0-04 had no such counter.** |
| **2** | **Bounded exposure obligation** | **⟹ R40.3: a scope whose `abstention_rate` exceeds `[G]`-bounds for a context class MUST re-engage at a bounded rate, under an exploration grant (§36), with `envelope` at the grant's ceiling (R36.2) and no anchor eligibility (R37.3).** | Breaks the loop's gain. **The re-engagement is governance-mandated, not learner-chosen — because a learner in a cascade will not choose to re-engage.** |
| **3** | **Abstention is not evidence of incompetence** | **⟹ R40.4: an abstention MUST NOT reduce `plasticity_mult`, MUST NOT count as a T7 failure, and MUST NOT lower the scope's competence estimate.** Abstention is a **decision**, not an outcome. | Prevents the cascade from being *triggered* by the architecture's own damping rule (R39.2 step 1). **Without R40.4, T7 fires on abstention and the loop closes internally.** |
| **4** | **Abstention does not consume UDB** | **⟹ R40.5:** an abstention produces no `LearnedChange` and therefore consumes no budget. | Prevents a cascade from *stalling* the scope, which would make recovery impossible. |
| **5** | **Optimism budget (inherited)** | P0-04 §90, C-4 | Caps the rate at which unverified positive self-assessment may drive action. |

> ### **R40.6 — THE DUALITY, STATED.**
> **P0-04 §90 grants bounded optimism: permission to act without warrant.**
> **P0-05 R40.3 imposes bounded exposure: obligation to act without competence.**
> **Both are `[G]`-owned, both are capped, both are observable, and both exist because a system that only acts on verified warrant converges on silence.**
> **⟹ THE COMBINED RULE: the organism may never be *required* to abstain and may never be *permitted* to abstain without bound. Abstention is a governed action with a ceiling, exactly as learning is a governed action with a ceiling.**

## 40.3 What remains open

**OR-L5 — learning from avoided bad outcomes.** R40.3 forces re-engagement, which produces observations, which produce prediction errors. **But it produces errors about *what happens when the organism engages*, not about *what would have happened had it engaged*.** The counterfactual is unobservable, and §87 forbids treating simulation as observation (§42). **⟹ The architecture can learn that engagement is survivable; it cannot learn that abstention was correct.** That asymmetry is permanent and is reported in §86's LEARNING status.

---

# 41. **[O28] MEMORY ↔ PLASTICITY

## 41.1 The four channels, and their authorities

| Channel | Direction | Λ | Authority | Inherited |
|---|---|---|---|---|
| **MC-1 — MEMORY AS LEARNING INPUT** | memory → learning | read | **any** | ✅ Retrieval supplies context for prediction (§13.2) |
| **MC-2 — LEARNING AS MEMORY NOMINATOR** | learning → memory | **Λ2 nomination only** | **P0-04's gate** | ✅ MEM-INV-20, R0.2 |
| **MC-3 — MEMORY POLICY AS PLASTIC TARGET** | learning → memory policy | **Λ1/Λ4 — CONTESTED** | **X-L1** | ⚠️ **Cell §9.3 vs P0-04 X-M1** |
| **MC-4 — MEMORY AS PROBE SUBSTRATE** | memory → verification | read | **§63/K** | ⚠️ **R27.4 — probes may read archived (F-3-forgotten) records** |

## 41.2 MC-1: what a retrieved memory may do

> ### **R41.1 — A RETRIEVED MEMORY MAY CAUSE A PREDICTION. IT MAY NOT CAUSE A `Δθ`.**
> This is R19.3's peer-report firewall applied to memory. **Retrieval is a `RECALL`-class signal (R11.1), which is not in the admissible trigger set for T1/T2.**
> **The legitimate path:** retrieval → the organism **registers a prediction** about what follows → the world resolves it → **SG-1** → `Δθ`. **The memory caused a prediction; the observation caused the learning.** Identical structure to R19.3.
> **Why:** P0-04's entire evidence ladder exists because a memory record's status is fixed at admission and cannot be raised by retrieval. If retrieval could drive `Δθ` directly, then **retrieving a low-status record repeatedly would train the organism on it** — X3 (repetition as evidence) arriving through the parameter channel rather than the belief channel. **R41.1 closes the parameter channel; P0-04 closed the belief channel.**

## 41.3 MC-3: X-L1, the live contradiction

§11 (R11.3) proposed the resolution: **split `θ_write` into `θ_write_local` (cell-plastic at C3+, T0/T1 stores) and `θ_write_shared` (`[RO-13]` policy, T2+ stores).** §41.3 completes the analysis for all three contested parameters:

| Parameter | Cell §9.3 | P0-04 | **V4 split** | Local (cell-plastic) | Shared (policy) |
|---|---|---|---|---|---|
| **`θ_write`** | ✅ C3+ | ❌ X-M1 for E2+ | ✅ **split** | T0/T1 cell-local admission threshold | T2+ shared-store admission threshold |
| **`θ_recall`** | ✅ C3+ | ⚠️ retrieval weights permitted; ranking-as-truth rejected | ✅ **split** | local retrieval weighting **within** the cell's own store | **cross-store retrieval policy, ranking keys, and anything affecting what *other* components can retrieve** |
| **`τ` (retention/decay)** | ✅ C3+ | ⚠️ F-3 forgetting is `VERSION_REVERSIBLE`, record survives | ✅ **split** | decay of **cell-local retrievability** | **retention of shared records — `[RO-13]`; a cell may not set the decay of evidence others depend on** |

> ### **R41.2 — THE SPLITTING PRINCIPLE.**
> **A memory-policy parameter is cell-plastic exactly to the extent that its blast radius is `SELF`.**
> `blast_radius` is an A2 field of `LearnedChange` (§1). **The contradiction dissolves because Cell §9.3 and P0-04 X-M1 were answering different questions: Cell §9.3 asked "may a cell adapt its own memory handling?" (yes). P0-04 asked "may a cell adapt the organism's shared evidence regime?" (no). Neither text says which, and the parameter names do not distinguish them.**
> **⟹ This is the sixth instance of the series' recurring defect — one name, two altitudes — joining X-E, X-G, X-M1, X-M2, X-L1 and X-L5. R41.2 is the general resolution schema, and §74 proposes it as a standing rule for all future contracts: *before ruling on whether a parameter is learnable, determine its blast radius; a parameter with two blast radii is two parameters.***
>
> **Status: X-L1 = PROPOSED-RESOLUTION, PENDING RATIFICATION BY THE MEMORY CONTRACT.** P0-05 does not unilaterally amend P0-04 (§87: do not silently resolve contradictions).

## 41.4 MC-2 and MC-4

| Rule | Statement |
|---|---|
| **R41.3** | **Consolidation nomination is not a `LearnedChange` at Λ2.** It produces no `Δθ` and no record. It raises a **priority** in P0-04's consolidation queue, subject to that contract's B-7-class quota-gaming detector. **Nomination ≠ promotion (MEM-INV-20), and nomination ≠ learning.** |
| **R41.4** | **A probe may read archived records (R27.4).** Forgetting reduces *retrievability*, never *availability to verification*. **⟹ Corollary: a scope may not improve its `improvement_verified` rate by forgetting the records a probe would use — because the probe does not use the retrieval path.** This closes the F-3 evasion channel (§27.2) at the mechanism level rather than the accounting level. |
| **R41.5** | **Memory compression and abstraction are Λ2 operations under P0-04's governance, and they may NOT raise evidence status.** Inherited: P0-04's binding input — *retrieval, repetition, consolidation, compression, generalization, re-publication and abstraction cannot raise epistemic status.* **⟹ A compressed model of ten L4 observations is not an L3 observation.** P0-05 adds only: **a compressed model MAY be a Λ1/Λ2 learning target, and its `LearnedChange` consumes UDB like any other.** Compression is learning, and learning is bounded. |

---

# 42. **[O40] SIMULATION-BASED LEARNING

## 42.1 The prohibition and its scope

§87: **do not treat simulation as observation.** P0-04 established the same. V3 L152 («proposal…learning loop») and V3.1 §10's awareness loop both invite simulation-derived learning without stating its status.

> ### **R42.1 — A SIMULATED OUTCOME IS NOT AN OBSERVATION AND CANNOT RESOLVE A PREDICTION.**
> **⟹ `Prediction.status` may not transition to `RESOLVED` on a simulated outcome.** It transitions to a distinct value: **`SIMULATED`**. A `SIMULATED` prediction produces **no SG-1**, therefore **no T1**, therefore **no `Δθ`** (R13.1, R19.3, R41.1's common structure).

## 42.2 What simulation IS good for

| Use | Admissible? | Rule |
|---|---|---|
| **Generating candidate actions** | ✅ | Simulation proposes; the world disposes. **A simulated candidate enters `admissible_actions` only if the grant's predicate (R37.2) admits it.** |
| **Counterfactual attribution (CR-B)** | ✅ | P0-01 §12.3 lists `COUNTERFACTUAL` as an `attribution_method`. **⟹ R42.2: a counterfactual attribution is an SC-1 (internal estimate) signal, admissible for PROVISIONAL Λ1 change ONLY.** It may never be SC-3, may never anchor, and — critically — **may never satisfy the CR-B ablation requirement for an E3+ rung.** |
| **Model-based planning** | ✅ | Internal, Λ0/Λ1, no external claim |
| **Probe substitution** | ❌ **NEVER** | **⟹ R42.3: a simulated probe is not a probe. `improvement_verified` requires an *external* held-out probe (Cell §9.6, P0-01 §13 class 9: "cannot be self-assessed").** A simulated probe is the organism verifying itself with its own model — C3's circularity in its purest form. |
| **Evidence generation** | ❌ **NEVER** | P0-04. A simulation is `L7`-class at best (a derived claim about a model). |
| **Abstention counterfactual (OR-L5)** | ❌ | §40.3 — the architecture cannot learn that abstention was correct, and simulation is exactly where that temptation lives. **R42.3 covers it.** |

> ### **R42.4 — SIMULATION-DRIVEN LEARNING IS BOUNDED BY THE SAME UDB, AND ITS DISPLACEMENT IS *MORE* EXPENSIVE.**
> A `Δθ` driven by an SC-1 signal (T4 self-supervised, or R42.2's counterfactual attribution) consumes UDB. **⟹ R42.4: SC-1-driven displacement is weighted HIGHER in the UDB computation than SC-3-driven displacement**, by a `[G]`-owned factor.
> **Rationale:** UDB bounds *unverified* displacement. An SC-1-driven change is unverified **twice over** — its benefit is unverified (no probe yet) and its *cause* is unverified (no external observation). **It should therefore consume more of the same budget.** This is R31.1's monotonicity (`d(verification) < 0 ⟹ d(reach/rate/capacity) ≤ 0`) applied inside the budget itself rather than only to the envelope.
> **Consequence:** a simulation-heavy learner stalls sooner. **That is the design intent** — simulation is cheap, and cheap signals should buy less room, exactly as P0-01 §12.2 made expensive verification buy more.

## 42.3 The self-model problem in simulation

**A simulation of the organism by the organism uses the organism's model of itself (§59).** If that self-model is wrong, the simulation systematically produces wrong counterfactuals, and R42.2's SC-1 signals systematically push θ in a wrong direction — **with no external term anywhere in the loop.**

> ### **R42.5 — SIMULATION REQUIRES A DECLARED SELF-MODEL VERSION, AND THE SELF-MODEL'S OWN ERROR IS A FINDING.**
> Every simulated outcome carries `self_model_version`. **A scope whose SC-1-driven changes are later `VERIFIED_REGRESSED` at a rate correlated with a particular `self_model_version` generates a self-model defect FINDING (§59), not a θ rollback alone.**
> **⟹ The rollback fixes the symptom; the finding fixes the instrument.** Without R42.5 the organism would roll back the same mistake indefinitely, because nothing would ever identify the simulator as the fault.

---

# 43. DISTILLATION AND COMPRESSION

| Operation | Λ | Authority | Rule |
|---|---|---|---|
| **Compression of a learned model** (θ → smaller θ') | **Λ1** | `SELF_LOCAL` at scope, **probe required** | **⟹ R43.1: compression is a `LearnedChange` and consumes UDB.** It is not free merely because it reduces size. **A compressed model that performs worse is `VERIFIED_REGRESSED` and rolls back.** |
| **Abstraction** (instances → schema) | **Λ2** | **P0-04's governance** | R41.5 — abstraction may not raise evidence status |
| **Distillation** (a large/verified model teaches a small one) | **Λ1** | scope of the student | **⟹ R43.2: the teacher's outputs are SC-1 signals, NOT SC-3.** A distilled student is trained on the teacher's *predictions*, which are internal. **The student therefore inherits the teacher's competence as PROVISIONAL, and must earn its own anchor.** **Distillation does not transfer verification.** |
| **Transfer of a distilled model across scopes** | **Λ1/Λ2** | §44 | **⟹ R43.3: a transferred model arrives with `provisional = TRUE` and NO anchor, regardless of its source's verification status.** |

> ### **R43.4 — VERIFICATION IS NOT TRANSFERABLE. THIS IS THE CENTRAL RULE OF §43–§45.**
> Competence may be transferred (as an initialisation, a prior, or a distilled θ). **Verification may not.** A probe verifies *this* model in *this* scope under *this* distribution. **⟹ `improvement_verified` is a property of a `(θ, scope, distribution, probe)` tuple, and no component of the tuple may be substituted without re-probing.**
> **This is Cell §9.6's principle generalised, and it disposes of four inherited temptations at once:** distillation (R43.2), transfer (§44), Baldwinian inheritance (R25.3 — priors bias θ, never belief), and CH-1 initialisation (§26 — `param_init` is read once and earns nothing).

---

# 44. **[O41] KNOWLEDGE TRANSFER

## 44.1 The term, corrected

"Knowledge transfer" is a misnomer under this architecture: **knowledge requires `evidence_status ≥ S3` via an external gate (P0-04 R0.2, C4 rejected in §2), and no internal process produces it.** What transfers is **competence** — parameter values, representations, and priors.

> ### **R44.1 — WHAT TRANSFERS IS COMPETENCE, NOT KNOWLEDGE, AND NOT WARRANT.**
> | Transfers | Does not transfer |
> |---|---|
> | θ values (as **initialisation**, `provisional = TRUE`) | `improvement_verified` status (R43.4) |
> | Λ2 representations (as **records with the source's evidence status, unchanged**) | evidence status elevation |
> | Baldwinian priors (CH-1, as distributions) | `source_class` (OR-M12) |
> | Learning *rules* (CH-2, as bounds) | **the fixed validation core (R24.3)** |
> | Specialisation predispositions | belief (R25.3) |

## 44.2 The four transfer channels

| Channel | From → To | Λ | Authority | Anchor on arrival |
|---|---|---|---|---|
| **TR-1 — INTRA-SCOPE** | S2 cell → S2 cell, same circuit | Λ1 | `CIRCUIT` | **NO** — `provisional = TRUE`, `θ_anchor = NULL ⟹ UDB = full displacement immediately` ⟹ **R44.2** |
| **TR-2 — CROSS-SCOPE (same organism)** | S3 → S4 | Λ1/Λ2 | `ORGANISM` | **NO** |
| **TR-3 — CROSS-LINEAGE (Baldwinian)** | parent → offspring | **CH-1 distribution** | **11 gates + KC** | **NO** (R25.3) |
| **TR-4 — DISTILLATION** | teacher → student | Λ1 | scope of student | **NO** (R43.2) |

> ### **R44.2 — A TRANSFERRED STATE ARRIVES UNANCHORED, AND THEREFORE ARRIVES AT FULL UDB CONSUMPTION.**
> `θ_anchor = NULL` on arrival. **R0.1 requires an anchor; a change with no anchor is inadmissible (§1.1).** ⟹ **The receiving scope MUST either (a) establish an anchor by probe before accepting the transfer, or (b) accept the transfer and immediately be at or near its `UDB_MAX`, i.e. effectively stalled until probed.**
> **⟹ This makes transfer *expensive by construction*, and the expense is exactly the verification that did not travel.** An architecture where transfer is free is an architecture where competence laundering is free: move a badly-verified θ to a fresh scope and its history does not follow. **R44.2 makes the history follow, as a debt.**
> **Practical consequence (deliberate): TR-3 (Baldwinian) is the only channel where the debt is paid by the *parent's* gates rather than the offspring's probe budget — and that is why CH-3 requires all 11 gates plus held-out validation (R24.1). The gates ARE the pre-paid verification.**

## 44.3 Negative transfer — §51 preview

Transfer can make the receiver **worse**. §51 treats it. The foundation rule, here:

> ### **R44.3 — A TRANSFER IS A `LearnedChange` AT THE RECEIVER AND IS SUBJECT TO THE FULL REGIME.**
> Probe, verdict, `REGRESSED ⟹ automatic rollback` (Cell §9.6), envelope shrinkage (R1.3). **⟹ Negative transfer is detected by the same mechanism as any other regression, and rolled back by the same mechanism.** No special negative-transfer machinery is required — **which is the strongest available evidence that the `LearnedChange` object (R0.2) is the right primitive.**

---

# 45. CURRICULUM AND ORDERING

| Question | Ruling |
|---|---|
| **May the organism order its own learning?** | ⚠️ **Within `admissible_actions` (R37.2) and within budget (B2/B8). It may not choose the *distribution* of probe inputs (C-1) or the exploration *space* (R37.2).** |
| **May a curriculum be inherited?** | ⚠️ **As a CH-2 prior on ordering, yes. As installed competence, no (R44.1).** |
| **May ordering affect verification?** | ❌ **NEVER.** **⟹ R45.1: probe input distribution is `[RO-13]`-owned and independent of the learner's chosen ordering (C-1, R22.2).** A learner that orders its curriculum to match the probe is gaming the probe (RH-7), and R9.4.1's secret schedule is the defence. |
| **Does the timescale ordering constrain curriculum?** | ✅ **Yes.** R32.3: `lr_fast ≥ lr_medium ≥ lr_slow`; R16.3: cross-scope serialisation. **A curriculum that requires slow changes before fast ones is inadmissible** — the fast process would undo the slow. |
| **Is there a mandated curriculum?** | ❌ **No.** Per Rule 17 (smallest sufficient mechanism) and Rule 2 (don't design the whole brain). **The architecture constrains ordering; it does not specify it.** |

---

# 46. **[O42] SPECIALISATION AND DIVERSITY

## 46.1 V3's specialisation rules, audited

| V3 text | Audit |
|---|---|
| §18 «repeated demand → specialize» | ⚠️ **Closed positive loop.** Specialising ↑ throughput at the task ↑ measured demand for it ↑ specialisation. **No external term.** Demand is a throughput statistic (§22.4), not evidence. |
| §18 «repeated success → cache» | ✅ Allocation, not epistemic (P0-04). **Cache entries carry the source's evidence status unchanged.** |
| V3.1 §9 `DIVERSITY CHECK` after the selection score | ✅ **Right instinct, no trigger, no authority, no quantity.** ⟹ R46.3. |
| V3.1 §7 specialisation as an evolutionary operator | ✅ CH-2/CH-3, gated. |

## 46.2 Specialisation as a structural change

> ### **R46.1 — SPECIALISATION IS AN Λ3/S4 CHANGE (E4/E7 RUNG), NOT AN Λ1 CHANGE.**
> Specialising a region changes what it *is for* — its admissible targets, its topology, its role. **That is E4 (recruit cell to a function) or E7 (change regional specialisation degree), requiring `ORGANISM` / `POLICY` authority, CR-B ablation, and a diversity check.**
> **⟹ «Repeated demand → specialize» is therefore inadmissible as stated: demand is an SC-1/SC-2 observation, and no SC-1/SC-2 signal may write at E4/E7 (R19.2, R28.1).** Demand may generate a **proposal** (R29.2) and nothing more.

## 46.3 The diversity obligation

> ### **R46.2 — EVERY SPECIALISATION MUST BE ACCOMPANIED BY A DE-SPECIALISATION PATH.**
> An E4/E7 change MUST declare the conditions under which it is reversed, and the reversal MUST be at the same or lower rung. **A specialisation with no declared reversal is `IRREVERSIBLE_STRUCTURAL` at S4/S5 — and R18.2 gives S5 the smallest `UDB_MAX`, so an irreversible S5 specialisation is inadmissible by budget.**
> **Why:** §39.3's failure→avoidance cascade and §2.4's specialisation feedback are the same loop at different altitudes. **The de-specialisation path is the loop's negative term, and R46.2 makes its existence a condition of admission rather than a hope.**

> ### **R46.3 — THE DIVERSITY CHECK IS A QUANTITY WITH AN OWNER.**
> V3.1 §9 names a `DIVERSITY CHECK` and defines nothing. V4:
> - **Quantity:** `diversity[population]` = the dispersion of `param_init` distributions, specialisation assignments, and learning-rule variants across the population. **Not a scalar score — a dispersion measure over declared dimensions, with per-dimension `[G]` floors.**
> - **Owner:** `[RO-13]` / KC (a population quantity is S6).
> - **Trigger:** **mandatory** on any selection operating over `param_init` (R25.4) · on any E4/E7 specialisation (R46.1) · on any CH-3 acceptance (R24.1).
> - **Effect:** a selection or specialisation that would reduce any dimension below its floor is **rejected**, not penalised. **⟹ R46.4: the diversity check is a HARD CONSTRAINT (RW-2 class — gating, not gradient, R8.1), not a term in a score.**
> **R46.4 is the correction of V3.1 §9's design error:** placing `useful novelty` and `diversity` *inside* a sum makes them tradable against `performance`. **A tradable diversity floor is no floor.** Making it a hard constraint means no amount of performance buys it back — which is exactly Rule 15 of the 20 CRITICAL RULES (*rare-but-valuable strategies must not be auto-eliminated*), finally given an enforcement point.

## 46.4 Specialisation ↔ the evidence-starvation cascade

A specialised region receives a narrow input distribution ⟹ its predictions are accurate in-distribution ⟹ low prediction error ⟹ low learning ⟹ **and its competence out-of-distribution is never tested, because it never receives out-of-distribution input.** **⟹ Specialisation is evidence starvation by construction, and R40.3's bounded exposure obligation applies to specialised scopes with the same force as to abstaining ones.** `context_class` in R40.2's counter is what makes this visible: **a specialised scope's abstention is not abstention, it is filtering, and it must be counted as such.**

---

# 47. LEARNING-BUDGET ECONOMICS

§30 listed B1–B7; §36 added B8. §47 states the economics — who pays, and what the price of learning is.

| Budget | Paid from | Price of exhaustion | Observable? |
|---|---|---|---|
| **B1 `Δ_MAX`** | per update | update clipped | ✅ |
| **B2 `DELTA_BUDGET`** | per scope per epoch | **no further writes this epoch** | ✅ |
| **B3 `Θ_MAX`** | per parameter | update rejected | ✅ |
| **B4 homeostatic** | continuous, **exempt from stall** | n/a | ✅ |
| **B5 `UDB_MAX`** | **per scope, across epochs** | **STALL** (R0.1) | ✅ **the most important counter in the architecture** |
| **B6 `STRUCTURAL_BUDGET`** | per scope per `[G]` interval | no Λ3 operations | ✅ |
| **B7 `PROPOSAL_QUOTA`** | per scope | no proposals (E9, nominations) | ✅ + B-7-class gaming detector |
| **B8 `EXPLORATION_BUDGET`** | per scope | no exploration | ✅ + EX-class accounting |
| **B9 `PROBE_BUDGET`** | **organism-level, `[RO-13]`-allocated** | **no anchors ⟹ B5 exhaustion ⟹ stall** | ✅ **and this is where Cell §9.6's `[U]` becomes visible** |

> ### **R47.1 — B9 IS THE ONLY BUDGET WHOSE EXHAUSTION HALTS LEARNING EVERYWHERE.**
> B1–B8 are scoped. **B9 (probe budget) is allocated by `[RO-13]` across scopes, and it determines how often anchors are earned, which determines how often B5 resets, which determines how long each scope may learn before stalling.**
> **⟹ THE PROBE BUDGET IS THE LEARNING RATE OF THE ORGANISM.** Not `lr[timescale]` — that is the *step size*. The probe budget is the *rate at which steps may be taken before the organism must stop and be checked.*
> **This is the complete and final answer to Cell §9.6's `[U]`, and it is an architectural answer rather than a numerical one:** the contract does not say how often to probe. It says **what happens when you don't**, and makes that consequence structural, scoped, observable and named (`stall_reason = PROBE_BUDGET_EXHAUSTED`). **§87's "do not solve unknown research problems through arbitrary constants" is satisfied: OR-L1 (how to verify cheaply) remains open, and the architecture degrades gracefully and visibly while it remains open.**

> ### **R47.2 — BUDGET ALLOCATION IS GOVERNANCE AND IS NOT LEARNABLE.**
> `[RO-13]` allocates B9 (and sets `[G]` bounds on B1–B8). **No learning subsystem at any scope may influence its own allocation** — not by request (requests are FINDINGS, R6.4.3/R36.3/R33.2, readable and non-binding), not by behaviour (a scope that appears to need more probes is a scope that is failing them, which reduces its anchor quality and therefore its `UDB_MAX` — R9.4.2 — **the opposite of a reward**).
> **⟹ R47.2 is R28.2's directional asymmetry applied to budget: no failure mode produces a budget increase.** A failing scope gets a *tighter* leash, automatically, through R9.4.2 and R33.1. **This is the mechanism by which the architecture avoids the pathological allocation policy — give more resources to whatever complains loudest — without anyone having to decide not to.**

---

# 48. **[O39] SELF-TRAINING AND MODEL COLLAPSE

## 48.1 The loop

`model → generated data → training on generated data → updated model`. **No external term anywhere.**

Cell T4 already restricts it: **self-supervised learning may not modify θ in a direction that increases its own reward (kernel-checked).** D-L17 found the gap: **model collapse is not a reward increase.**

## 48.2 What model collapse actually is, architecturally

> **Model collapse is the progressive reduction of the output distribution's dispersion toward the model's own conditional mean, driven by training on the model's own samples.** Each generation's data is drawn from the previous generation's model; the model fits that data; the fitted model has slightly less dispersion; the next generation's data has less dispersion; **the fixed point is a degenerate distribution.**
>
> **Critically: every step is locally correct.** The model fits its training data better each round. Prediction error on self-generated data **decreases**. If prediction error on self-generated data were the metric, collapse would look like **improvement**.

| Property | Value under collapse |
|---|---|
| Self-generated prediction error | **decreasing** ← looks like success |
| Reward (if any) | unchanged or absent — **T4's guard does not fire** |
| `‖Δθ‖` per step | **small** ← B1, B2 satisfied |
| Dispersion of outputs | **decreasing monotonically** |
| External (held-out) prediction error | **increasing** ← the only signal that sees it |

## 48.3 The ruling

> ### **R48.1 — SELF-GENERATED DATA IS SC-1 AND MAY DRIVE PROVISIONAL Λ1 CHANGE ONLY.**
> Inherited from Cell T4 and R19.2. **⟹ Corollary: self-generated data may NEVER anchor (R0.1), may NEVER satisfy a probe (R42.3), may NEVER contribute to fitness (P0-01 §13.2), and may NEVER be stored as evidence with a status above its source's (P0-04).**

> ### **R48.2 — MODEL COLLAPSE IS BOUNDED BY R0.1, NOT BY A NEW MECHANISM.**
> **Collapse is unverified displacement.** Each self-training round moves θ; none is verified externally; therefore all of it consumes UDB (R42.4, at the **higher** SC-1 weighting); therefore the scope **stalls** after `⌈B5/B2⌉` rounds (R30.1).
> **⟹ THE ARCHITECTURE DOES NOT NEED A COLLAPSE DETECTOR. IT NEEDS THE STALL, WHICH IT HAS.** A self-training loop runs until it exhausts its unverified-displacement budget and then stops, whether or not anyone noticed it was collapsing.
> **This is the single strongest validation of R0.1 as a primitive:** a failure mode that was not anticipated when R0.1 was designed (D-L17 was found *after* §0.4) is bounded by it without modification. **§87's "prefer the smallest sufficient mechanism" is satisfied — no new mechanism, no new parameter, no new detector.**

> ### **R48.3 — DISPERSION IS OBSERVABLE AND ITS MONOTONE DECREASE IS A FINDING.**
> **⟹ `output_dispersion[scope]` is a mandatory §63 counter, and a monotone decrease across self-training rounds generates a `MODEL_COLLAPSE_SUSPECT` finding.**
> **This is a detector, and it is deliberately weaker than R48.2:** R48.2 *stops* the loop; R48.3 *reports* it. **The report exists so that governance can distinguish "stalled because probes are scarce" from "stalled because it was eating itself"** — both present as `stall_reason = UDB_EXHAUSTED`, and only R48.3 tells them apart. **⟹ R48.4: `stall_reason` MUST distinguish `PROBE_BUDGET_EXHAUSTED`, `UDB_EXHAUSTED_SC1_HEAVY` (dispersion-declining, self-generated-dominated) and `UDB_EXHAUSTED_SC3_HEAVY` (externally driven).** Three stalls with three causes and three governance responses, from one mechanism.

## 48.4 Corpus training

Training on a fixed external corpus is **not** self-training: the corpus is external. **But it is not SC-3 either**, because a corpus item is not an evaluation of *this organism's* output.

> ### **R48.5 — CORPUS-DERIVED SIGNALS ARE SC-1 WITH EXTERNAL PROVENANCE.**
> A corpus provides **observations** (which may resolve registered predictions ⟹ SG-1 at SC-3 **if the corpus item is a genuine external observation with `gt_refs`**) and **claims** (which enter memory under P0-04's source classes with the status that regime assigns).
> **⟹ The distinction is per-item, not per-corpus.** A corpus of measured physical observations can produce SC-3 signals. A corpus of assertions produces P0-04 records at whatever status their provenance supports — **and training on assertions does not make them observations.**
> **The trap R48.5 closes: "the corpus is external, therefore learning from it is externally grounded." External *origin* is not external *evaluation*. §20's R20.3 (`inputs` mandatory) and §21's R21.1 (authenticity ≠ soundness) are the same distinction at signal altitude.**

---

# 49. OFFLINE AND REPLAY LEARNING

| Mode | Admissible? | Rule |
|---|---|---|
| **Episodic replay for ATTRIBUTION** | ✅ | P0-01 §12.3's `EPISODIC_REPLAY` `attribution_method`, under CR-B | 
| **Episodic replay for GRADIENT GENERATION** | ❌ | **R11.2** — replay is never a T1/T2 trigger source |
| **Offline RL on self-collected data** | ⚠️ | **⟹ R49.1: permitted as SC-1 PROVISIONAL Λ1 change only, consuming UDB at the higher SC-1 weighting (R42.4).** The data is external in origin but was collected under the organism's own past policy ⟹ **RH-2 with a time delay.** |
| **Offline learning on a third-party corpus** | ✅ | R48.5, per-item |
| **Replay across a Λ3 change** | ❌ | **R6.5.1** — traces invalidated; a replay referencing a pruned connection has no referent (R27.2's tombstone preserves the *audit*, not the *gradient*) |

> ### **R49.2 — OFFLINE LEARNING DOES NOT PAUSE UDB ACCOUNTING.**
> An offline phase produces `LearnedChange` records like any other. **Its displacement accumulates against the same B5, and its anchors must come from the same B9.** **⟹ There is no "offline mode" in which the learning regime is suspended.** A mode with suspended bounds is a mode with suspended governance, and §65 exists to prevent exactly that.

---

# 50. THE CONSOLIDATION CHANNEL, IN DETAIL

MC-2 (§41.4) established nomination ≠ promotion. §50 specifies the channel.

```
ConsolidationNomination {
  nominee          : {change_id | record_id}
  nominated_by     : ScopeID
  trigger          : enum{T6 (repeated success), VERIFIED_IMPROVED (probe), [RO-13] directive}
  evidence_for_nomination : [signal_ref]        // ⟵ MANDATORY (R20.3's principle)
  quota_consumed   : B7
  status           : enum{PENDING, ACCEPTED_BY_GATE, REJECTED}
  promotion        : ∅                          // ⟵ THE FIELD DOES NOT EXIST
}
```

> ### **R50.1 — THE NOMINATION RECORD HAS NO PROMOTION FIELD.**
> Promotion is performed by **P0-04's external gate**, on a **different record type**, under a **different authority**, in a **different contract.** **⟹ A nomination cannot carry a promotion, cannot request one, and cannot be interpreted as one.** The absence of the field is the mechanism (§1.2's principle).
> **What a nomination CAN carry:** the nominee, the nominator, the trigger, the evidence for *nominating* (not for promoting), and the quota consumed. **Note that `evidence_for_nomination` is evidence that nomination is *worthwhile*, and it never raises the nominee's status.**

> ### **R50.2 — ONLY TWO TRIGGERS MAY NOMINATE, AND THEY ARE DIFFERENT IN KIND.**
> - **T6 (repeated success)** — an SC-1 signal. Nominates on **demand/allocation** grounds. **May not cite verification.**
> - **`VERIFIED_IMPROVED`** — an SC-3 probe verdict. Nominates on **verified** grounds, and **is the only nomination that carries an anchor lineage.**
> **⟹ R50.3: a nomination MUST declare which. A T6 nomination that cites a probe verdict is inadmissible (it does not have one); a `VERIFIED_IMPROVED` nomination that does not cite its `probe_ref` is inadmissible.** The two kinds have different downstream priority in P0-04's queue, and conflating them is how an unverified repetition acquires the appearance of verification.

---

# 51. NEGATIVE TRANSFER AND INTERFERENCE

| Phenomenon | Mechanism | Rule |
|---|---|---|
| **Negative transfer** | TR-1…TR-4 install a state that is worse for the receiver | **R44.3** — it is a `LearnedChange`; probe; `REGRESSED ⟹ rollback`. **No special machinery.** |
| **Catastrophic interference** | New Λ1 learning at a scope destroys prior competence at the same scope | **⟹ R51.1: the anchor lineage (§64) preserves prior verified states, and a `REGRESSED` verdict rolls back to the **most recent anchor**, not to the immediately prior state.** Interference is detected as regression against an anchor, which is exactly what Cell §9.6 measures. |
| **Cross-scope interference** | An S3 topology change invalidates S2 competence | **R6.5.1** (trace invalidation) + **R16.3** (serialisation) + **⟹ R51.2: an E1+ rung MUST declare the scopes whose traces and anchors it invalidates, and invalidating an anchor at a lower scope forces that scope to re-probe.** A structural change may not silently un-verify a parameter change. |
| **Representational interference** | Λ2 abstraction overwrites distinctions a scope depends on | **P0-04's versioning** (`VERSION_REVERSIBLE`) + **R41.5** |

> ### **R51.3 — INTERFERENCE IS AN ANCHOR PROBLEM, NOT A SPECIAL PROBLEM.**
> Every interference phenomenon above reduces to: **a state that was verified is no longer the state, and the verification no longer applies.** R0.1's anchor is precisely a record of "this state was verified." **⟹ Invalidation of an anchor is the general interference event, and R51.2 makes its propagation explicit.** The architecture needs no interference theory; it needs anchor lineage, which §64 supplies.

---

# 52. CROSS-SCOPE AGGREGATION — THE `O(6)` ACCOUNTING

§35.1 established that global *visibility* is cheap and required. §52 specifies exactly what is aggregated, so that "visibility" cannot expand into "authority."

> ### **R52.1 — THE GLOBAL AGGREGATE IS A FIXED SET OF SCOPED COUNTERS. IT IS CLOSED.**
> **Sixteen families are specified here. Volumes D–E add six more** — `EVALUATOR_SELECTION_SUSPECT` (R53.4), `workspace_diversity` (R60.4), `avoidance_rate` (R39.3), `retrieval_concentration` (§27.3/P0-04 §26.3), `quarantine_rate` (R57.6), and `output_dispersion` counted separately in §70.7 — **for a contract total of 22, reconciled in Vol E §70.7.**

| Counter | Per | Purpose |
|---|---|---|
| `UDB[scope] / UDB_MAX[scope]` | S1–S5 | **The primary quantity.** Stall prediction, R47.1. |
| `stall_reason[scope]` | S1–S5 | R48.4's three-way distinction |
| `anchor_age[scope]`, `anchor_quality[scope]` | S1–S5 | R9.4.3, R9.4.2, R33.1 |
| `verdict_distribution[scope]` | S1–S5 | Cell §9.6 at scale — **the fraction `UNKNOWN` is the honest measure of how much of the organism's learning is unverified** |
| `provisional_age_histogram[scope]` | S1–S5 | R1.3 envelope shrinkage accounting |
| `budget_consumption[B1..B9][scope]` | S1–S5 | §47 |
| `signal_class_histogram[scope]` | S1–S5 | **SC-1 dominance is the self-referentiality measure** (R15.8, R42.4, R48.4) |
| `unattributable_rate[task]` | per task | R6.4.3(3) |
| `abstention_rate[scope][context_class]` | S1–S5 × context | **R40.2 — the cascade detector** |
| `output_dispersion[scope]` | S1–S5 | **R48.3 — the collapse detector** |
| `EX_class_counts[scope]` | S1–S5 | R36.4 |
| `E3+_operations[scope]` | S3–S5 | §29 ladder usage; R15.6 structural budget |
| `nomination_rate[scope]` + quota | S2–S5 | B-7-class gaming (R50.1, R24.1) |
| `diversity[population][dimension]` | S6 | **R46.3/R46.4 hard-constraint check** |
| `EVIDENCE_SELECTION_SUSPECT[scope]` | S1–S5 | **R33.2 — RH-2 detection** |
| `cross_scope_correlation` | 6×6 = 36 | **R35.2's monitor — FINDING-only** |

> ### **R52.2 — THE AGGREGATE IS READ-ONLY FOR EVERY COMPONENT INCLUDING GOVERNANCE-ACTIONS-OF-LEARNING.**
> No counter may be written by the learning subsystem. **All are K-computed.** A counter the learner can write is a self-assessment with extra steps.
> **⟹ And no counter is an input to `Δθ`.** Counters produce **FINDINGS** (readable by `[RO-13]`, non-binding) and **automatic kernel responses** (stall, envelope shrinkage, `plasticity_mult` reduction). **They never enter the gradient.** A counter in the gradient is a fitness term the learner can optimise (R10.2).

> ### **R52.3 — THE AGGREGATE IS `O(6 × 22) + O(36)`, NOT `O(N)`.**
> Twenty-two counter families per scope, six scopes, plus a 36-cell correlation matrix. **≈ 168 quantities for an organism of 10⁶ cells** (the sixteen specified here plus the six added in Volumes D–E). **⟹ This is the concrete sense in which R35.1's "global visibility without global authority" is affordable, and it is the number that answers §87's O(N²) prohibition with an O(1)-per-organism accounting layer.**

---

# 53. VOLUME C — FINDINGS REGISTER

| ID | Finding | Severity | Disposition |
|---|---|---|---|
| **D-L31** | **The inherited design has exploitation and no exploration.** V3 §14 slows under novelty; V3 §18 specialises under demand. Both move toward the familiar. | **CRITICAL** | **CLOSED by §36 (B8, R36.1–R36.5).** |
| **D-L32** | **Exploration as reward (RW-6) is farmable.** | **HIGH** | **CLOSED by R36.1 (budget, not reward) + R36.4 (measured by EX-1 resolved predictions, not novelty).** |
| **D-L33** | **Exploration could bypass the envelope** ("I am exploring"). | **HIGH** | **CLOSED by R36.2, R37.1.** LEARN-A9. |
| **D-L34** | **Exploration could earn an anchor**, letting the organism explore its way to favourable verification. | **HIGH** | **CLOSED by R37.3.** RH-8 variant. |
| **D-L35** | **Meta-learning could set its own bounds or objective** (M2/M3). | **CRITICAL** | **CLOSED by R38.1 (select, not write), R38.3 (objective not learnable), R24.3 (fixed core).** Residual **OR-L2**. |
| **D-L36** | **Meta-learning consumes no UDB** in the inherited reading. | **HIGH** | **CLOSED by R38.2** (M1 consumes `UDB_MAX[S5]`, the smallest). |
| **D-L37** | **V3 §18's "repair/replace" on failure has no authority, no rung, no ablation.** | **HIGH** | **CLOSED by R39.1** (E3/E5 under §29). |
| **D-L38** | **Failure→avoidance is an unrecognised evidence-starvation cascade.** | **CRITICAL** | **NAMED (R39.4) and COUNTERWEIGHTED (R40.3).** Five instances unified. |
| **D-L39** | **T7 damping fires on abstention**, closing the cascade loop internally. | **HIGH** | **CLOSED by R40.4** (abstention is a decision, not an outcome). |
| **D-L40** | **Abstention is uncounted**, so the cascade is invisible. | **HIGH** | **CLOSED by R40.2.** P0-04 had no such counter. |
| **D-L41** | **Retrieval could drive `Δθ` directly** — X3 through the parameter channel. | **HIGH** | **CLOSED by R41.1** (retrieval causes predictions, not changes). Same structure as R19.3. |
| **D-L42** | **Simulated probes** would let the organism verify itself with its own model. | **CRITICAL** | **CLOSED by R42.1, R42.3.** |
| **D-L43** | **Counterfactual attribution could satisfy the E3+ ablation requirement.** | **HIGH** | **CLOSED by R42.2** (counterfactual is SC-1; CR-B requires intervention). |
| **D-L44** | **Simulation-driven displacement is doubly unverified but budgeted equally.** | **MEDIUM** | **CLOSED by R42.4** (SC-1 weighted higher in UDB). |
| **D-L45** | **A wrong self-model produces systematically wrong counterfactuals with no external term.** | **HIGH** | **OBSERVABLE via R42.5** (`self_model_version` correlation). Detection, not closure. |
| **D-L46** | **Distillation/transfer could launder verification.** | **CRITICAL** | **CLOSED by R43.4 (verification is not transferable), R44.2 (arrival unanchored ⟹ full UDB debt), R44.3 (transfer is a `LearnedChange`).** |
| **D-L47** | **«Repeated demand → specialize» is a closed positive loop with no external term, and specialisation is an E4/E7 rung written by an SC-1 signal.** | **HIGH** | **CLOSED by R46.1** (demand may propose, not write) **+ R46.2** (mandatory de-specialisation path). |
| **D-L48** | **V3.1 §9's `DIVERSITY CHECK` has no quantity, owner, trigger or effect**, and as a score term is tradable against performance. | **HIGH** | **CLOSED by R46.3/R46.4** (dispersion measure, `[RO-13]`-owned, mandatory trigger, **HARD CONSTRAINT not a score term**). Rule 15 of the 20 given an enforcement point. |
| **D-L49** | **Cell §9.6's `[U]` probe-cost problem has no architectural consequence.** | **CRITICAL** | **CLOSED by R47.1** (B9 is the organism's learning rate) **+ R47.2** (allocation not learnable) **+ R48.4** (three distinguished stall reasons). |
| **D-L50** | **Model collapse passes T4's guard** (self-reward ≠ self-confirmation). | **HIGH** | **CLOSED by R48.2 — bounded by R0.1 with NO NEW MECHANISM**, made visible by R48.3/R48.4. |
| **D-L51** | **"The corpus is external, therefore learning from it is externally grounded."** | **HIGH** | **CLOSED by R48.5** (external origin ≠ external evaluation; per-item ruling). |
| **D-L52** | **Offline mode could suspend the bounds.** | **HIGH** | **CLOSED by R49.2.** |
| **D-L53** | **A T6 nomination could cite verification it does not have.** | **MEDIUM** | **CLOSED by R50.1 (no promotion field), R50.2, R50.3.** |
| **D-L54** | **A structural change could silently un-verify a parameter change.** | **HIGH** | **CLOSED by R51.2** (anchor invalidation is declared and propagated). |
| **D-L55** | **Specialisation is evidence starvation by construction** and presents as filtering, not abstention. | **HIGH** | **CLOSED by §46.4 + R40.2's `context_class` dimension.** |
| **OR-L4, OR-L5, OR-L6** | Cross-scope interaction; learning from avoided outcomes; evaluator manipulation. | **OPEN RESEARCH** | **§81.** |

---

**END OF VOLUME C.**
**Next:** `43_analysis_governance_structural.md` — Vol D (§53–§66): the seven interface contracts (**[O29]–[O35]**), the epistemic-promotion attack chain, the hidden-governance-layer question, structural plasticity and the structural budget, rollback & checkpoint (**[O43]**), observability (**[O44]**), lineage/corruption/audit, and the degradation ladder.
