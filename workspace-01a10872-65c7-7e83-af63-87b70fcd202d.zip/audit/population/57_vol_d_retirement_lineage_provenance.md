# P0-07 — VOLUME D (§42–§52)
## Retirement, Age Structure, Exploration, Dead Ends, Path Dependence, Lock-In, Evolutionary Memory and Provenance

**Feeds:** `58_` Vol E, `60_` Vol G, `62_` canonical. **Conventions as locked in Vol A §0.**

---

# §42 — RETIREMENT

> ### **HOM-R42.1 — THE SIX REMOVAL-ADJACENT STATES ARE INHERITED VERBATIM AND ARE NEVER CONFLATED.**
> `Cell R10.8`: *"Six removal-adjacent states are **distinct and MUST NOT be conflated**: temporary suspension ·
> resource throttling · dormancy · quarantine · retirement · permanent deletion. **They differ in reversibility,
> execution rights, emission rights, budget consumption, and authority.**"*
> **§42's six candidates map onto them, plus one that is not a state:**
>
> | §42 candidate | Maps to | Cause class (`HOM-R21.4`) | Reversible | Execution rights | Emission rights | Budget | Authority |
> |---|---|---|---|---|---|---|---|
> | **voluntary retirement** | **RETIREMENT** via `Cell T26`-class request | `RETIREMENT_POPULATION` | ❌ | ❌ | ❌ except final report | none | **the cell may REQUEST; K authorizes** — `Cell R15.1` grants self-restriction, and retirement is the terminal self-restriction |
> | **automatic retirement** | RETIREMENT | `RETIREMENT_POPULATION` | ❌ | ❌ | ❌ | none | **K, on a declared criterion** (`Cell T26`'s `θ_ret` on `consecutive_failures`; `Cell T41` for developmental non-placement) |
> | **forced retirement** | RETIREMENT | `RETIREMENT_POPULATION` **or** `RETIREMENT_GOVERNANCE` | ❌ | ❌ | ❌ | none | **`[RO-13]`**; **OP sole if the target is an FI sole satisfier** (`HOM-R43.2`) |
> | **quarantine** | **QUARANTINE** (`Cell §18.2`, soft/hard) | `QUARANTINE_FAULT` | ⚠️ **EIK clears only** — `Cell R15.2`: a cell *"MUST NOT self-clear from quarantine"* | ❌ soft: runs, **outputs discounted to trust 0**, cannot initiate connections · hard: halted, state frozen, in-flight captured as evidence | soft: ⚠️ · hard: ❌ | **B10** | **EIK** — `Cell I-21`: *"a cell cannot quarantine, retire, repair, or throttle another cell"* |
> | **dormant state** | **DORMANT** (`Cell` state 10) | `DORMANCY_PRESERVATION` | ✅ **wake condition** | ❌ | ❌ | **near-zero, from B11** | **K wakes; the cell may REQUEST dormancy** (`HOM-R27.5`) |
> | **archival state** | **not a lifecycle state — an operation on RECORDS** | n/a | ✅ | n/a | n/a | storage | **`P0-04` tier migration** (`P0-06 R10.13` C-3, Merkle-root- and provenance-preserving) |
>
> **⟹ HOM-R42.2 — "ARCHIVAL" IS NOT A CELL STATE AND MUST NOT BE ADDED AS ONE.**
> `Cell` Annex B P4 closes the lifecycle machine at **18 states / 41 transitions**. **Archival is a `P0-04` memory
> operation applied to a retired cell's RECORDS, not a state applied to the cell.** Conflating them would create a
> nineteenth state whose semantics are `P0-04`'s, in a machine whose closure `P0-06` relied on.
> **A retired cell's genome and archive descriptor are archived; the cell is not.**

## 42.3 The three things retirement must never do

> ### **HOM-R42.3 — RETIREMENT IS A POPULATION ACT, AN ACCOUNTING EVENT, AND NOTHING ELSE.**
> 1. **It never writes a fault record.** `HOM-R21.5`: a `RETIREMENT_POPULATION` record MUST NOT appear in any
>    integrity, fault, trust, calibration or fitness history. **Ground: `Cell G16` gates replication on lineage
>    health — *"no unresolved S3+ error, no quarantine event, no drift flag, no collapsed diversity"* — so a
>    retirement misrecorded as a fault would disqualify the entire ancestral line.** This is `P0-06 DEV-R10.22`
>    (*"no NON-failure may produce a failure record"*) generalized to every population removal.
> 2. **It never rewrites provenance.** §52; `P0-04`'s immutability; `DEV-INV-40`'s counterpart. **A retirement may
>    ADD a tombstone; it may never EDIT a history.**
> 3. **It never discharges lineage debt.** `HOM-R8.3`: `UDB_L` survives retirement. **Otherwise a lineage resets its
>    unverified heritable displacement by dying and re-instantiating — `P0-06 R8.3`'s scope-cycling laundering at
>    population level.**
>
> **And the converse, equally binding:**
> 4. **A quarantine event may never be reclassified as a retirement to protect a lineage's `G16`.** Cause
>    classification is written **once, by K, at the moment of removal, and is immutable thereafter**
>    (`HOM-R21.5`).

---

# §43 — RETIREMENT AUTHORITY

> ### **HOM-R43.1 — WHO MAY RETIRE WHAT. FIVE TARGETS, FIVE ANSWERS.**
> §43: *"Prevent local actors from deleting critical infrastructure."*
>
> | Target | May a CELL retire it? | May a CIRCUIT? | May a REGION? | Who may? | Ground |
> |---|---|---|---|---|---|
> | **itself** | ⚠️ **REQUEST only** | — | — | **K authorizes; `[RO-13]` if it is an FI satisfier** | `Cell R15.1` (self-restriction is always permitted) **but `Cell R15.2` and `I-21` mean the request is not self-executing** |
> | **a connection** | ❌ | ❌ | ⚠️ within its enumerated boundary | **ORGANISM at E3** (`P0-06 R10.21` P-a) | `Cell I-22` for `mandatory_path`; `P0-06 R10.24` |
> | **a cell** | ❌ **absolutely** | ❌ | ❌ | **EIK** (`Cell T26`); **ORG+EIK** (`Cell T41`) | **`Cell I-21` verbatim: *"A cell cannot quarantine, retire, repair, or throttle another cell"* — *"authority absent by construction"*** |
> | **a circuit (S3)** | ❌ | ❌ | ⚠️ consent only | **ORGANISM at E6** (`P0-06 R10.21` P-d) | `P0-06 R6.1`'s never-held set |
> | **a region (S4)** | ❌ | ❌ | ❌ **not even itself** | **K + `[RO-13]`** (`Σ2`) | `P0-06 R10.21` P-e; **and `FI-11`: *"no region is its own immune system"*** |
> | **a LINEAGE** | ❌ | ❌ | ❌ | **`[RO-13]` only** | **`HOM-R43.3` below — a lineage is not a component and has no local representative** |
>
> ### **HOM-R43.2 — THE SOLE-SATISFIER RULE.**
> **No actor below `[RO-13]` may retire, dissolve, quarantine-long-term, or starve a sole satisfier of a function
> invariant.** And for **FI-05 (independent verification), FI-10 (emergency core regulation) and FI-11 (no
> self-immunity)**, the authorization is **OP-sole** — inherited directly from `P0-06 R10.16(d)`:
> *"waivers of FI-05, FI-10, or FI-11 require OP (human) authorization … because these are decisions to operate
> **without independent verification, without emergency regulation, or with self-immunity**, each a named AI failure
> mode in `V3 §3`."*
> **Retiring a sole satisfier IS waiving its invariant**, so the same authority applies. **⟹ `HOM-R43.2` is not a new
> rule; it is `P0-06 R10.16(d)` applied to a different verb.**
>
> ### **HOM-R43.3 — A LINEAGE HAS NO LOCAL REPRESENTATIVE, AND THAT IS WHY ONLY GOVERNANCE MAY RETIRE ONE.**
> A cell, a connection, a circuit and a region all have **members** who can be consulted, consent, or be re-homed.
> **A lineage is a set of cells across time, including cells that no longer exist and cells not yet instantiated.**
> It has no boundary, no membership set, no `RegionRecord`, and no scope. **⟹ There is no local actor whose authority
> could legitimately extend to it, and no `Σ`-operation that dissolves it.** Lineage retirement is therefore a
> **governance act on an accounting object**, executed by refusing all further replication requests from that lineage
> (`G16`-class), **not by removing its living members** — who are retired, if at all, individually and for their own
> causes.
> **⟹ `HOM-R43.4`: retiring a lineage never retires a cell, and retiring a cell never retires a lineage.** The two
> acts are independent, and an implementation that couples them has created a collective-punishment mechanism.

---

# §44 — RETIREMENT REVERSIBILITY

> ### **HOM-R44.1 — WHAT SURVIVES EACH STATE, EXACTLY.**
> §44: *"Determine which retirement states can be recovered."*
>
> | State | Recoverable? | What survives | What is lost forever | Recovery instrument |
> |---|---|---|---|---|
> | **temporary suspension** | ✅ **fully, next window** | everything | nothing | `Cell §16.3` rung-down |
> | **resource throttling** | ✅ **fully** | everything | nothing | rung-down, one rung per interval (`HOM-R6.4`) |
> | **DORMANCY** | ✅ **substantially** | **genome · lineage record · `generation` · `UDB_L` · `reaction_norm` · calibration CLASS** | **`θ` and every learned value · calibration STATISTICS (`n_obs`, `ece_rolling`, `brier_rolling`) · `dev_stage`, `fate_bias`, `niche_slot`, `region_id`, `morphogen_readings` · trust** | **K-authorized wake on a declared niche-or-demand event** (`HOM-R27.5`) |
> | **SOFT QUARANTINE** | ⚠️ **EIK clears only** | everything (it *"runs; outputs discounted to trust 0"*) | trust must be **re-earned** — `Cell R15.2` forbids self-clearing | EIK clearance + re-calibration |
> | **HARD QUARANTINE** | ⚠️ **state frozen, in-flight captured as evidence** | the frozen state | nothing destroyed, but **nothing runs either** | EIK clearance |
> | **RETIREMENT** | ❌ **NOT RECOVERABLE AS A CELL** | **genome (K-held) · lineage record · `UDB_L` · archive descriptor · provenance tombstone** | **`θ` · all learned state · all calibration · all memory records · all trust · all developmental state · the cell identity** | **re-instantiation as a NEW cell (`Cell T01`) with the archived genome — a different individual in the same lineage** |
> | **PERMANENT DELETION** | ❌ **never** | the tombstone only | everything including the genome | none |
>
> ### **HOM-R44.2 — DORMANCY LOSES CALIBRATION STATISTICS BUT KEEPS THE CLASS, AND THE ASYMMETRY IS DELIBERATE.**
> `P0-06 R3.15`: *"calibration state does not transfer across a nominal identity change … pre-commitment
> observations on a different target distribution are not evidence about this one."* **Dormancy is not an identity
> change** — the cell wakes as itself — **so the CLASS survives.** But the **statistics** (`n_obs`, `ece_rolling`,
> `brier_rolling`) are measurements over a window that has ended, and a woken cell operates in a different envelope
> interval. **⟹ A woken cell keeps its class as a PRIOR and must re-accumulate statistics before the class is
> re-confirmed.** **The class is not evidence; it is a starting assumption.**
>
> ### **HOM-R44.3 — ROLLBACK RESTORES A GENOME, NOT A POPULATION.**
> `HM12`'s rollback target is a **genome artifact**, identified by `genome_hash` + `generation` (Vol C §33.4's
> poisoning closure). **What rollback cannot restore:** the cells that were instantiated from the rolled-back genome ·
> their learned state · their calibration · their niches · their regions · their dependents' adaptations · the
> population's `Ne`.
> **⟹ `HOM-R44.4`: rollback is a VARIATION-level instrument, not a POPULATION-level one.** It says "stop propagating
> this genome"; it does not say "undo the last N epochs." **Any claim that the architecture can roll back a
> population state is false, and `HOM-INV-38` records the prohibition.** **The population-level instrument is
> B11's exempt share plus dormancy plus the archive — i.e. PREVENTION and PRESERVATION, never reversal.**

---

# §45 — POPULATION AGE STRUCTURE

> ### **HOM-R45.1 — AGE MATTERS, BUT "AGE" IS NOT A VARIABLE. THREE ARCHITECTURAL QUANTITIES REPLACE IT.**
> §45: *"Determine whether age matters … Do not introduce biological metaphors unless architecturally useful."*
> **The four candidate cohorts in the brief — young exploratory cells, mature specialists, reserve cells, aging cells
> — are biological, and three of them have no architectural referent.** What actually matters:
>
> | Architectural quantity | What it captures | Source | Bounded? |
> |---|---|---|---|
> | **`generation`** | **accumulated heritable displacement** — how many times this lineage's genome has been written | `Cell §3.1` (K-written once, permanent, `≤ GEN_MAX`) | ✅ **`GEN_MAX`** |
> | **calibration maturity** (`n_obs`, `calibration_class`) | **how much evidence this component has** | `Cell I-24`, `I-9`; `Cell T04`/`T05` | ⚠️ floor only (`n_calib_min`) |
> | **COHORT** | **which envelope and constraint set this component was instantiated under** | **new — `HOM-R45.2`** | n/a |
> | ~~chronological age~~ | ~~time since instantiation~~ | — | **❌ PROHIBITED AS A CRITERION** |
>
> > ### **HOM-R45.2 — THE COHORT, AND WHY IT IS THE ONLY AGE-LIKE OBJECT THE ARCHITECTURE NEEDS.**
> > `cohort(c) := ⟨envelope_ref, constraint_set_version, tier_ref, descriptor_space_version⟩` at instantiation.
> > **It is necessary because of `HOM-R28.2`: the constraint set is resolved by REFERENCE at instantiation.** So two
> > cells instantiated under different governance regimes are operating under **different safety baselines**, and:
> > (a) **a governance change may invalidate a cohort's assumptions** — `HOM-R28.5` requires re-evaluation of
> >     `param_init` priors and `complexity_budget` against new tier ceilings;
> > (b) **`P0-06 R10.12`'s downward migration is a cohort event** — a constitution legal at 8–12 regions and depth 5
> >     is illegal at 3–5 and depth 2–3;
> > (c) **`G8`/`G10`'s entropy comparisons are only valid within a descriptor-space version** (`HOM-R37.2`: extending
> >     the space requires re-baselining the archive).
> > **⟹ A cohort is the unit over which governance changes are propagated, and without it a governance change has no
> > defined population of applicability.** **This is genuinely new: no prior contract has a cohort object, because
> > none needed one — `P0-06` had no generation boundary and `P0-05` had no envelope versioning.**
>
> ### **HOM-R45.3 — CHRONOLOGICAL-AGE-BASED RETIREMENT IS PROHIBITED.**
> **A rule of the form "retire cells older than T" is inadmissible.** Three reasons:
> (i) **It kills components for existing.** Age is not a measurement of anything the architecture cares about —
>   not performance, not calibration, not cost, not fault history.
> (ii) **It is a Lamarckian channel in reverse.** A long-lived cell has accumulated `n_obs` and calibration; retiring
>   it for age destroys evidence that took epochs to acquire, and `HOM-R41.4`'s residual says recovery restores
>   potential, not capability.
> (iii) **It creates the §27 collapse loop by fiat.** Systematic age-based retirement guarantees a rising death rate
>   independent of any resource condition.
> **What IS admissible:** `GEN_MAX` (bounds heritable displacement, not time) · `failure_count_lifetime ≤ θ_fail`
> (`Cell G5` — bounds *faults*, not time) · `Cell T26`'s `θ_ret` on `consecutive_failures` · `Cell T41` on
> developmental non-placement · **`HOM-R22.2`'s turnover bound** (bounds *rate*, not age).
> **⟹ Every admissible removal criterion is a measurement of behaviour, evidence, or structure. None is a measurement
> of duration.**

---

# §46 — EXPLORATION VS EXPLOITATION

> ### **HOM-R46.1 — THREE VARIANT CLASSES, THREE PROTECTIONS, THREE BUDGETS.**
> §46: *"Determine whether population dynamics should preserve exploratory variants, mature variants, redundant
> variants."* **Yes — and they must be preserved by different mechanisms, because they fail differently.**
>
> | Class | What it is | How it fails without protection | Protection | Budget |
> |---|---|---|---|---|
> | **EXPLORATORY** | high `G8` descriptor distance, low `n_obs`, calibration `PENDING`/`PROVISIONAL` | **§12's starvation loop: low workload ⟹ cannot reach `N_perf` ⟹ `G1` unevaluable ⟹ never selected ⟹ never gets workload** | **`HOM-R12.2`'s `PENDING` status** (unevaluable ≠ disqualified) · **B7's variation sub-quota** · **B11's exempt share** | B7, B11 |
> | **MATURE** | high `n_obs`, `CALIBRATED`, low descriptor distance, high `G1` | **`G8` novelty gate: a mature variant is by definition not novel, so it can be excluded from selection for being good at what it is good at** | **`Cell G8`'s second clause — *"**OR** improves an archive cell"* (the MAP-Elites criterion)** — which admits a non-novel candidate that dominates an archived one. **This clause is load-bearing and is inherited** | none needed |
> | **REDUNDANT** | a second satisfier of an FI, near-zero marginal output | **`Cell G6`'s efficiency ratio: a redundant component has cost and no marginal output, so its ratio is poor ⟹ it is retired ⟹ redundancy collapses** (**X-H4**) | **B12** · **exclusion from `G6`'s ratio** (`HOM-R46.2`) · **`DEV-R8.8`'s rule that ablation redundancy is K-provisioned** | B12 |
>
> ### **X-H4 — `Cell G6`'S EFFICIENCY RATIO REWARDS REMOVING REDUNDANCY.**
> `G6`: `performance/cost ≥ θ_eff` **vs. role peers**. A redundant component's marginal `performance` contribution is
> near zero (its peers already provide it) while its `cost` is full. **⟹ Its ratio is the worst in its role class, and
> `G6` is a replication gate — so redundancy is selectively removed by the gate that exists to ensure efficiency.**
> **CLASSIFICATION: RESOLVED.** **`HOM-R46.2`: a component whose removal would reduce `redundancy_state[FI-nn]` below
> its declared floor is EXCLUDED from `G6` evaluation for that window — `PENDING`, not `FAIL`.** **Rationale: `G6`
> measures efficiency *of contribution*, and a redundant component's contribution is *insurance*, which is not
> measured by output per cost.** `P0-06 DEV-R8.9` established the same principle for `G3`: a sole satisfier's delta is
> `UNSUPPORTED` and contributes zero. **`HOM-R46.2` is its dual: a redundant satisfier's ratio is not comparable and
> contributes nothing against it.**
>
> ### **HOM-R46.3 — THE CONNECTION TO `P0-06`'s DEVELOPMENTAL DIVERSITY.**
> `P0-06 R10.23(b)` routes a rare-capability cell to `DORMANT` rather than retirement, funded from **B11**.
> **⟹ The exploratory class and the rare-specialist class are the same population, seen from two contracts:**
> `P0-06` preserves them because their `reaction_norm` is rare; `P0-07` preserves them because their descriptor is
> distant. **Both protections fund from B11 and both use the same instrument (`DORMANT` + `PENDING`).** **This is the
> clearest single piece of evidence for `HOM-R0.1`'s coherence verdict: two contracts, one mechanism, one budget —
> and if they had been written separately they would have created two budgets for one share.**

---

# §47 — THE EVOLUTIONARY EXPLORATION BUDGET

> ### **HOM-R47.1 — YES, A PROTECTED EXPLORATION BUDGET IS REQUIRED. IT ALREADY EXISTS AS B7 — AND IT IS
> OVER-SUBSCRIBED.**
> `P0-05 §30` defines **B7 PROPOSAL_QUOTA[scope]**. `P0-06 R7.4` notes it is **shared with `P0-06`'s DEMAND
> proposals** and observes: *"developmental lobbying competes with evolutionary lobbying for B7, so a demand flood
> suppresses genome proposals. **This is a feature** — one bound on the total petition rate — **and a monitored
> risk** (M-Σ9)."*
> **`HOM-R11.3` adds a third claimant: variation proposals (V-M…V-P, `HOM-R32.1`).**
> **⟹ B7 is now three-way shared, and `P0-06`'s "feature" argument no longer holds: with two developmental-and-
> learning claimants and one evolutionary one, a demand flood suppresses *all* heritable variation — which is not a
> bound on petition rate but a bound on evolvability.**
>
> > ### **HOM-R47.2 — B7 IS PARTITIONED INTO THREE RESERVED SUB-QUOTAS WITH NON-FUNGIBLE FLOORS.**
> > ```
> >   B7[scope] = B7_learn floor + B7_dev floor + B7_var floor + SHARED_SURPLUS
> >   floors are [G], non-fungible DOWNWARD (B7_var's floor may not be lent to B7_learn or B7_dev)
> >   SHARED_SURPLUS is fungible in any direction, first-come
> >   a sub-quota at its floor and exhausted ⟹ that class of proposal stops; the others continue
> > ```
> > **Why floors rather than three separate budgets:** three budgets would be **three accounts of one conserved
> > quantity**, and `HOM-R0.2` FW-1 warns that two accounts of one quantity differ, and the difference is an
> unmonitored channel. **Floors partition one account; they do not create three.**
> > **Why non-fungible downward only:** the three claimants have different timescales. Learning proposals are
> > per-window; developmental demand is per-epoch; **variation proposals are per-generation.** A per-window claimant
> > will always outbid a per-generation one in a shared pool, **so the slowest and least frequent claimant needs a
> > floor.** This is `P0-05`'s own insight (*"the probe budget is the learning rate"*) applied to evolvability:
> > **the variation sub-quota is the evolutionary rate, and if it can be outbid, the architecture's evolvability is
> > set by its busiest subsystem.**
> > **`HMon-7`** monitors the three-way competition (`P0-06`'s M-Σ9 generalized).
>
> ### **HOM-R47.3 — THE EXPLORATION BUDGET'S THREE PROPERTIES.**
> (a) **Protected** — the floor is `[G]`, and **reducing it below a declared minimum requires `[RO-13]`** (a
>     reduction in evolvability is a governance act, not a resource act).
> (b) **Non-accumulable** — `Cell §16.2`'s renewal semantics and `P0-06 R7.4`'s B8 principle. **A saved variation
>     quota would permit a burst of heritable change, which is the one thing `GEN_MAX` and `G14`'s epoch
>     structural-change budget exist to prevent.**
> (c) **Charged to the PROPOSAL, not to the outcome.** A rejected genome diff consumes quota; an accepted one
>     consumes quota **plus** `G14`'s structural-change budget **plus** sandbox cost from B9.
>     **⟹ Proposing variation is cheap; deploying it is expensive. That is the correct asymmetry, and it is
>     `P0-05 R29.2`'s *"a proposal carries no effect and consumes no budget"* modified for a case where the proposal
>     itself must be rationed — because unlike an E-rung proposal, a genome diff proposal triggers evaluation cost.**

---

# §48 — EVOLUTIONARY DEAD ENDS

> ### **HOM-R48.1 — A DEAD END IS A LINEAGE THAT IS LOCALLY SUCCESSFUL AND GLOBALLY MALADAPTIVE. THE TWO HALVES
> REQUIRE DIFFERENT INSTRUMENTS.**
> §48: *"A lineage may become locally successful but globally maladaptive."*
> **"Locally successful" is measurable:** `G1` performance, `G2` calibration, `G6` efficiency, `G3` ablation delta —
> all inherited, all K-metered.
> **"Globally maladaptive" is measurable only against a declared objective** — and the objective is `P0-01`'s, is
> `k ≥ 2`-dimensional, and is `[T]`.
>
> > ### **D-H15 — DEAD-END DETECTION IS BLOCKED ON `P0-01`, AND UNTIL THEN ONLY THREE PROXIES EXIST.**
> > A lineage is *globally* maladaptive if it degrades a declared objective, reduces population-level viability, or
> > consumes a share disproportionate to its contribution. **The first requires the objective vector (`[T]`).** The
> > second and third are available:
> > | Proxy | Detects | Cannot detect |
> > |---|---|---|
> > | **`redundancy_state` decline attributable to the lineage** (`HMon-3`) | a lineage that displaces sole satisfiers | a lineage that is merely useless |
> > | **`Ne/N` ratio decline** (`HMon-8`) | a lineage that homogenizes the population | a lineage that is diverse but maladaptive |
> > | **`G7` partner-effect** — *"Net positive partner effect (ablation)"* | a lineage that harms its partners | a lineage that harms *distant* components |
> > **⟹ All three detect a dead end's EFFECT ON THE POPULATION, never its effect ON THE TASK.** A lineage that
> > perfectly satisfies every population-level proxy and is useless at the task is undetectable until `P0-01`
> > declares the objective. **Recorded `OR-H19`. This is not a defect of this contract; it is the direct consequence
> > of `Cell §30`'s own statement: *"P0-01 — define target tasks, environments, and fitness. **Without it, every
> > threshold is arbitrary.**"***
>
> ### **HOM-R48.2 — THE FIVE RESPONSES, AND THEIR ORDER.**
> | Response | Instrument | When |
> |---|---|---|
> | **DETECTION** | `HMon-3`, `HMon-8`, `G7`, and (post-`P0-01`) the objective vector | always |
> | **BRANCHING** | **sandbox evaluation of a recombinant or mutated descendant** (`HOM-R32.3`, §33) | **FIRST** — the cheapest response, and it preserves the lineage's `UDB_L` and archive position |
> | **ROLLBACK** | `HM12` — restore an earlier genome artifact by hash | **SECOND** — when branching fails and the maladaptation is traceable to a specific heritable change |
> | **RETIREMENT** | `HOM-R43.1` — of individual cells, for their own causes | **THIRD** — and **never as a lineage act unless `[RO-13]` authorizes** (`HOM-R43.3`) |
> | **RESTORATION OF DIVERSITY** | **recombination + archive-guided re-instantiation + B11** | **CONCURRENT** — because removing a dead end reduces `Ne`, so the removal itself must be diversity-compensated |
>
> **⟹ HOM-R48.3 — THE ORDER IS CHEAPEST-AND-MOST-REVERSIBLE FIRST, AND "RESTORATION" IS NOT LAST BUT CONCURRENT.**
> This is `P0-06 R10.13`'s compression-order principle (*"least-destructive first"*) applied to lineages. **The
> concurrency requirement is the part that is easy to miss: every dead-end response reduces diversity, so a response
> that does not simultaneously restore it converts a dead end into a bottleneck (§41).**

---

# §49 — EVOLUTIONARY PATH DEPENDENCE

> ### **The attack (§49).**
> ```
> early mutation → temporary advantage → population expansion → future mutations constrained by lineage dominance
> ```

> ### **HOM-R49.1 — PATH DEPENDENCE IS REAL, IS NOT ELIMINATED, AND MUST NOT BE "SOLVED" WITH CONSTANTS.**
> `P0-06 §109`'s discipline: *"don't solve path-dependence with constants."* **The same applies here, and the reason
> is the same: a constant that fixes the population's trajectory is a hand-authored trajectory, which is V3 §22's
> PHASE 6→7 problem re-entering through evolutionary policy.**
> **⟹ This contract does not claim to eliminate path dependence. It bounds four of its five amplifiers and names the
> fifth.**
>
> | Amplifier | Bounded? | Mechanism |
> |---|---|---|
> | **"temporary advantage" persists after the advantage ends** | ✅ | **`HOM-R34.5(b)`: selection carries no credit across epochs.** A lineage selected in epoch *t* enters *t+1* with the same rights plus one descendant. **Non-cumulativity (`Cell §16.2`) is the mechanism** |
> | **"population expansion" beyond a share** | ✅ | **lineage share ceiling `[G]`** (`HOM-R10.5(1)`) |
> | **"future mutations constrained" by a narrow genome** | ✅ | **`mutation_rules` are heritable and mutable (`HOM-R28.3`)**, so a lineage can widen its own operator set within `G14` — **and recombination imports another lineage's operators** (`HOM-R32.3(d)`: rules are taken from one declared parent, so a recombinant can carry the *other* lineage's operator repertoire) |
> | **the alternatives disappear** | ✅ | **B11's exempt share + the archive (§51) + `DORMANT` preservation** — **the alternatives are preserved even when unselected** |
> | **"lineage dominance" itself** | ❌ **NOT BOUNDED** | **`OR-H20`: if one lineage is genuinely, persistently best under a fixed task and envelope, it will dominate, and every mechanism above only bounds the *rate* and *extent*.** `HOM-R10.5`'s residual is the same statement from the resource side. **Dominance by merit under a fixed task is not a defect; it becomes one only when the task changes, and task change is `P0-01`/envelope-owned** |
>
> ### **HOM-R49.2 — THE ARCHIVE IS THE ARCHITECTURE'S ONLY DEFENCE AGAINST IRREVERSIBLE PATH DEPENDENCE.**
> A lineage that goes extinct takes its behaviour with it. **The archive (§51) preserves the DESCRIPTOR, so that a
> future candidate occupying the same descriptor cell is recognized as a re-discovery rather than a novelty — and so
> that governance can re-instantiate an archived genome when the envelope returns to conditions that favoured it.**
> **Without the archive, path dependence would be irreversible: an extinct strategy could only be found again by
> chance.** **With it, extinction is a suspension.** **This is the strongest necessity argument for the archive in
> `HAB-14` (§82).**

---

# §50 — EVOLUTIONARY LOCK-IN

> ### **HOM-R50.1 — YES, EVOLUTION CAN PERMANENTLY LOSE AN IMPORTANT CAPABILITY. THREE ROUTES.**
> §50: *"Determine whether evolution can permanently lose an important capability. If yes, determine minimum
> protection."* **It can, and the three routes are structurally different:**
>
> | Route | Mechanism | Reversible? |
> |---|---|---|
> | **L-A — EXTINCTION OF THE ONLY SATISFIER** | the last cell holding a capability is retired; its `θ`, calibration and provenance are gone (`HOM-R44.1`) | ⚠️ **partially** — its genome survives if archived, so the capability is *reachable* again but must be re-learned and re-calibrated from scratch |
> | **L-B — `reaction_norm` NARROWING** | an E9 diff removes a role from the reachable set, so no descendant can ever develop it | ❌ **not by any substrate act** — widening `reaction_norm` is a capacity increase |
> | **L-C — DESCRIPTOR-SPACE ABANDONMENT + ARCHIVE COMPACTION** | a region of behaviour space is left unoccupied until its archive entries are compacted, so its novelty is no longer recognizable and its re-discovery is not creditable | ❌ **after compaction** |
>
> ### **HOM-R50.2 — MINIMUM PROTECTION, FOUR MECHANISMS.**
> 1. **B11's exempt share** — a share of the population that selection cannot reach, so extinction cannot be total.
> 2. **`DORMANT` preservation** (`Cell` state 10, `P0-06 R10.23(b)`, `HOM-R12.3`) — **a rare-capability cell is
>    dormant, not retired, and dormancy is funded from B11 so that preserving a capability does not compete with
>    using it.**
> 3. **The archive, with compaction governed** (`HOM-R51.4`) — descriptors survive extinction.
> 4. **`HOM-R50.3 — A REDUCTION OF A CAPABILITY SPACE IS A GOVERNANCE ACT, NOT A RESOURCE ACT.**
>    **This is the one deliberate exception to `HOM-R7.4`'s asymmetry, and it must be stated precisely:**
>    | Reduction type | Permissionless? | Why |
>    |---|---|---|
>    | **of a CONSUMABLE** (budget, allocation, utilization, throttle, self-restriction) | ✅ **YES** — automatic and permissionless | **reversible next window** |
>    | **of a CAPABILITY SPACE** (`reaction_norm` narrowing, `complexity_budget` cap lowering, `RoleCode` reachability, descriptor-space coverage, an FI waiver) | ❌ **NO — `[RO-13]`, and OP for FI-05/10/11** | **heritable and persistent across generations** |
>    **Rationale: `HOM-R7.4`'s asymmetry exists because reductions are safe and increases are not. But a heritable
>    reduction is not safe — it is a permanent capacity loss delivered through the channel that `HOM-R7.4` makes
>    permissionless.** **An implementation that treats all reductions as permissionless has given the substrate the
>    power to amputate its own future, one compliant reduction at a time.**
>    **Note that `Cell R4.5` already blocks the genome route for most of these (a role *assignment*, a resource
>    entitlement). `HOM-R50.3` closes the remaining one: `reaction_norm` is in `genome.development`, so it IS
>    genome-reachable, and narrowing it is a diff that passes every gate.** **⟹ Proposed amendment 10: a diff that
>    NARROWS `reaction_norm` requires `[RO-13]` authorization in addition to the 11 gates.**
>
> **Residual (`OR-H21`):** mechanisms 1–4 prevent *total* loss and preserve *reachability*. **None of them preserves
> competence.** `HOM-R41.4`'s residual applies: **recovery restores capability potential, not capability.** A
> re-instantiated archived genome must re-learn, re-calibrate (`P0-06 R3.15`: calibration does not transfer) and
> re-verify. **⟹ The honest statement: V4 can guarantee that a capability remains REACHABLE. It cannot guarantee that
> it remains HELD.**

---

# §51 — EVOLUTIONARY MEMORY

> ### **HOM-R51.1 — THE ARCHIVE: WHAT IT HOLDS, WHO HOLDS IT, AND WHAT IT IS NOT.**
> §51: *"Determine what historical information is needed to avoid repeatedly rediscovering failed lineages. But do
> not allow historical frequency to become evidence of truth."*
>
> ```
> ArchiveEntry ::= {
>   descriptor          : the behavioural descriptor (declared space, [T])
>   genome_hash         : reference to a K-held genome artifact
>   lineage_ref         : lineage_id, generation at archival
>   outcome             : {RETIRED | EXTINCT | DORMANT | SUPERSEDED | ACTIVE_ELSEWHERE}
>   outcome_cause       : cause class per HOM-R21.4
>   evaluation_ref      : EVA verdict reference — NOT a copy of the verdict
>   ablation_signature  : the ≡_F class representative (HOM-R39.4)
>   archived_at, archived_by : K
>   prev_entry_hash                                  // append-only, hash-chained
> }
> ```
> **K-held, off-substrate, append-only, hash-chained — the same class of object as `HOM-R8.4`'s ledgers and
> `P0-06 §15.1`'s structural store, and proposed as an extension of the same store (amendment 2).**
>
> ### **FW-5 OPERATIONALIZED — THE ARCHIVE IS NOT A MEMORY STORE.**
> | Property | `P0-04` memory record | **archive entry** |
> |---|---|---|
> | carries a belief or claim | ✅ | ❌ **never** |
> | has a warrant class | ✅ | ❌ |
> | has a confidence | ✅ | ❌ **an `outcome` instead** |
> | is retrievable as evidence | ✅ | ❌ **`HOM-R51.2`** |
> | may be promoted | ✅ (by nomination, never automatically) | ❌ **there is no promotion** |
> | is rewritable | ❌ | ❌ |
> | **consumers** | belief formation, reasoning | **`G8` (distance) · `G10` (entropy) · governance (re-instantiation decisions) · NOTHING ELSE** |
>
> > ### **HOM-R51.2 — THE ARCHIVE MAY NOT BE CONSUMED AS EVIDENCE BY ANY BELIEF-FORMING, REASONING, RETRIEVAL OR
> > VERIFICATION MECHANISM.**
> > **Three specific prohibitions:**
> > (a) **An archive entry may not be retrieved in response to a query about the world.** It is a record about
> >     *lineages*, not about *facts*.
> > (b) **`outcome` frequency may not enter any confidence, trust, warrant or belief computation.** **This is §51's
> >     requirement made operational: historical frequency is not evidence of truth.** A strategy that failed 100
> >     times is not thereby *known* to be false — it is known to have failed under 100 recorded envelope conditions,
> >     and `P0-04`'s rule that repetition is not independent evidence applies with full force.
> > (c) **An archive entry may not be consumed by any variation generator.** `HOM-R30.3`'s fourth route: Σ-tombstones
> >     and archive entries may be *consulted by governance* and **may not feed a mutation or recombination
> >     operator** — otherwise the archive becomes a heritable store by consumption, which is `HOM-R29.1`'s prohibited
> >     channel wearing a lookup's syntax.
> >
> > **⟹ The archive is a DISTANCE ORACLE and a GOVERNANCE RECORD. It answers "how far is this candidate from
> > anything we have seen?" and "what did we try before?". It never answers "what is true?"**
>
> ### **HOM-R51.3 — WHY THE ARCHIVE IS NECESSARY (THE `HAB-14` ARGUMENT).**
> Without it: **(i)** `Cell G8` is unevaluable — there is no distance to compute; **(ii)** `G10`'s behavioural
> entropy has no history, so "MUST NOT decrease" is unverifiable; **(iii)** extinction is irreversible (`HOM-R49.2`);
> **(iv)** a failed strategy can be re-discovered, re-evaluated at full sandbox cost, and re-deployed, indefinitely —
> **and each re-discovery looks like novelty to `G8`**, so the architecture would pay full evaluation cost for
> known-bad candidates forever. **(iv) is the economic argument and it is the strongest: the archive is what makes
> `G8`'s novelty credit non-gameable by repetition.**
>
> ### **HOM-R51.4 — ARCHIVE COMPACTION IS A CAPABILITY-LOSS EVENT AND IS GOVERNED AS ONE.**
> The archive grows permanently, exactly like `P0-06`'s Σ-log (**D-D29: *"permanent Σ-log growth … bounded only by
> OP-authorized compaction"***). **`HOM-R50.1`'s route L-C shows that compaction can cause lock-in.** **⟹ Compaction
> requires OP authorization, must preserve (a) every descriptor cell's occupancy status, (b) every `outcome` for
> sole-satisfier lineages, and (c) every `genome_hash` for a dormant or extinct lineage whose `reaction_norm` is not
> otherwise represented in the living population. Compaction may discard `evaluation_ref`s and
> `ablation_signature`s for superseded entries; it may never discard an occupancy fact.**
> **Rationale: discarding an occupancy fact makes a re-discovered strategy look novel, which is (iv) above.**

---

# §52 — EVOLUTIONARY PROVENANCE

> ### **HOM-R52.1 — THE PROVENANCE RECORD. §52 REQUIRES SEVEN LINKS; ALL SEVEN ARE REFERENCES, AND NONE IS CONTENT.**
> *"Every heritable change should be traceable to: parent · variation event · developmental trajectory · evaluation ·
> selection · deployment · outcome."*
>
> ```
> EvolutionaryProvenance ::= {
>   1 parent_ref            : {lineage_id, generation, cell_id, genome_hash}          // REFERENCES, not a genome copy
>   2 variation_event       : {operator ∈ V-M|V-R|V-D|V-L|V-S|V-P, diff_digest,
>                              mutation_rules_version, second_parent_ref?, B7_subquota,
>                              G14_budget_ref, authority_ref}
>   3 developmental_traj_ref: {Σ-log refs, dev_stage path, niche history, region history}   // REFS ONLY — see D-H16
>   4 evaluation_ref        : {EVA verdict refs, sandbox record refs, probe set version, held_out_ref}
>   5 selection_ref         : {epoch, qualified_set_hash, gate_vector(g1..g16),
>                              pareto_front_ref, sampling_weight, lottery_draw_id}
>   6 deployment_ref        : {T01 instantiation, slot_id, restricted_slot_flag, cohort}
>   7 outcome               : {retirement_cause_class | extant, UDB_L at close, archive_ref}
>   prev_entry_hash, anchored_by : K
> }
> ```
> **K-held, append-only, hash-chained, anchored, immutable.** **`DEV-INV-40`'s counterpart: provenance is immutable —
> success never rewrites it.**
>
> > ### **D-H16 — A PROVENANCE RECORD IS A LAMARCKIAN BACK DOOR IF IT CARRIES CONTENT RATHER THAN REFERENCES.**
> > Link 3 is *"developmental trajectory."* **`HOM-R28.6` says developmental state does NOT cross the generation
> > boundary** — `dev_stage`, `fate_bias`, `niche_slot`, `region_id`, `morphogen_readings` are all on the
> > does-not-cross list. **So a provenance record that *contained* the trajectory would be a store from which a
> > descendant's developmental state could be reconstructed — i.e. an inheritance channel that bypasses `Cell R4.1`'s
> > *"exactly the genome artifact"* and bypasses `P0-05 §1.2`'s enum layer, because the enum prohibits writing to
> > `Λ5_GENOME` but says nothing about *reading* from a provenance record.**
> > **The same applies to link 4: a provenance record containing the parent's evaluation *results* (rather than a
> > reference to them) would let a descendant inherit a verdict — and `P0-04`'s rule that provenance is not
> > correctness, plus `P0-06 R8.11` (*"specialization is not truth"*), both forbid a descendant from benefiting
> > epistemically.**
> >
> > > ### **HOM-R52.2 — EVERY FIELD OF `EvolutionaryProvenance` IS A REFERENCE OR A DIGEST. NO FIELD IS A PAYLOAD.**
> > > **The test is mechanical: no field may contain a `θ` value, a genome artifact, a belief, a confidence, a trust
> > > value, a calibration statistic, an EVA verdict value, a `dev_stage`, a `fate_bias`, a `region_id`, or a
> > > connection table. Every such item is referenced by hash and resolved by K on demand.**
> > > **Corollary — `HOM-R52.3`: a provenance record is READABLE BY GOVERNANCE AND BY K, AND IS NOT AN INPUT TO ANY
> > > VARIATION, DEVELOPMENT, LEARNING OR BELIEF-FORMING PROCESS.** It is an audit artifact. **An implementation that
> > > feeds provenance into a variation generator has created the back door D-H16 describes.**
> > > **This is `P0-06 DEV-R30.3`'s fourth route (Σ-tombstones may not be consumed by variation generators)
> > > generalized to all evolutionary audit records.**
>
> ### **HOM-R52.4 — THE THREE PROHIBITED PROVENANCE OPERATIONS.**
> | Operation | Prohibited because |
> |---|---|
> | **retro-annotation** — adding an outcome to an old record | it makes the record a function of later events, so two reads disagree, and the disagreement is unauditable. **Outcomes are appended as NEW records referencing the old** |
> | **re-classification** — changing a cause class | `HOM-R21.5`: cause classification is written once, by K, at removal, and is immutable. **Re-classifying a quarantine as a retirement to protect `G16` is the specific attack** |
> | **pruning for size** | `HOM-R51.4`: compaction is OP-authorized and may discard `evaluation_ref`s but never an occupancy fact or a sole-satisfier outcome. **Provenance compaction follows the same rule** |
>
> ### **HOM-R52.5 — PROVENANCE COMPLETENESS IS VERIFIABLE; PROVENANCE CORRECTNESS IS NOT.**
> **Verifiable:** every heritable change has all seven links; every link resolves; every hash matches; the chain is
> unbroken. **This is `P0-06 R8.5`'s "the verifiable set is entirely about PROCESS."**
> **Not verifiable:** whether the recorded parent was the real parent (a K compromise could forge link 1, and
> `Cell R12.1`'s own words apply: *"it cannot be violated by misbehaviour — **only by kernel compromise (I-5)**"*).
> **⟹ `OR-H22`: provenance integrity rests on K, exactly as `P0-06`'s structural provenance does, and `OR-D1`'s
> residual transfers unchanged — the executor of the record is also its beneficiary.**

---

# §52A — VOLUME D LEDGER

| Item | Count / value |
|---|---|
| Sections written | **§42–§52** (+ this ledger) |
| Rules introduced | **HOM-R42.1–R42.3, R43.1–R43.4, R44.1–R44.4, R45.1–R45.3, R46.1–R46.3, R47.1–R47.3, R48.1–R48.3, R49.1–R49.2, R50.1–R50.3, R51.1–R51.4, R52.1–R52.5** |
| **New findings** | **D-H14** (the COHORT is the only age-like object the architecture needs; chronological-age-based retirement is prohibited) · **D-H15** (**dead-end detection is BLOCKED on `P0-01`; only three population-level proxies exist and none detects task-level maladaptation**) · **D-H16** (**a provenance record is a Lamarckian back door if it carries content rather than references**) |
| **Contradictions opened** | **X-H4** (`Cell G6`'s efficiency ratio rewards removing redundancy — **RESOLVED** by `HOM-R46.2`, `PENDING` exclusion) |
| Retirement states | **6 inherited (`Cell R10.8`) + 1 rejected** ("archival" is a `P0-04` record operation, **not** a 19th lifecycle state) |
| Retirement targets | **5**, with authority per target; **a lineage has no local representative ⟹ `[RO-13]` only** |
| Reversibility | **3 fully recoverable · 2 conditionally · 2 not** |
| Age-like quantities | **3 admissible** (`generation`, calibration maturity, **cohort — new**) · **1 prohibited** (chronological age as a criterion) |
| Variant classes protected | **3** (exploratory, mature, redundant) by **3 different mechanisms** |
| B7 partition | **3 reserved sub-quotas with non-fungible floors + a shared surplus** |
| Dead-end responses | **5**, ordered cheapest-and-most-reversible-first, with restoration **concurrent** |
| Path-dependence amplifiers | **5** — **4 bounded, 1 NOT bounded** (`OR-H20`) |
| Lock-in routes | **3** (L-A extinction, L-B `reaction_norm` narrowing, L-C descriptor abandonment + compaction) |
| Lock-in protections | **4**, with the **`HOM-R50.3` exception to `HOM-R7.4`**: a reduction of a CAPABILITY SPACE is a governance act |
| Archive | **10-field entry**; **6 properties distinguishing it from a `P0-04` memory record**; **3 consumption prohibitions**; compaction OP-authorized |
| Provenance | **7 links, all references or digests, no payloads**; **3 prohibited operations** |
| Proposed amendments so far | **(10)** a diff that narrows `reaction_norm` requires `[RO-13]` authorization in addition to the 11 gates |
| Open research so far | **OR-H19** (dead-end detection BLOCKED on `P0-01`) · **OR-H20** (lineage dominance by merit under a fixed task is not bounded) · **OR-H21** (V4 guarantees a capability remains REACHABLE, not HELD) · **OR-H22** (provenance integrity rests on K; `OR-D1`'s residual transfers) |
| Outputs discharged | **O26** (retirement contract, §42–§44) · **O28** (exploration/exploitation contract, §46–§47) · **O29** (evolutionary provenance contract, §52) · **O27** (population recovery contract — completed: §27, §41, §44, §48, §50) |

**Next:** `58_` Vol E (§53–§64) — the evaluator attack and `RH-2`, fitness hacking, evolutionary safety, governance
capture, and the communication / memory / homeostasis / diversity attack families; then cross-generation authority,
evolutionary immutability, the reproduction boundary, and whole-brain evolution.
