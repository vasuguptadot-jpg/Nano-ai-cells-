# P0-07 — VOLUME G (§77–§84)
## The Formal Apparatus: Invariants, State Machines, Parameter Registry, Scalability, Portability, Ablation, and the Two Audits

**Feeds:** `61_` Vol H, `62_` canonical. **Conventions as locked in Vol A §0.**

---

# §77 — THE INVARIANT SET

> **§77 requires ≥40 invariants with ≥15 named. This section delivers 45, of which 30 carry canon names.**
> **Form:** each invariant is stated so that a violation is *mechanically detectable* — either by a writer check
> (no compliant path exists), a ledger check (a quantity is out of band), or a grep check (a forbidden reference
> appears in a computation). Invariants that cannot be checked this way are marked **[DECLARATIVE]** and are
> obligations on the implementer rather than properties of the state.

## 77.1 Feasibility, resources and the ledger (HOM-INV-01 … 09)

| # | Name | Statement | Enforcement | Source |
|---|---|---|---|---|
| **01** | **FEASIBILITY-FLOOR** | If the envelope cannot hold a component, its replication is **INFEASIBLE** — never merely unpreferred. Infeasibility yields `FIT UNDEFINED`, not a low score | `G13` zero-sum slot check at ticket time | `P0-01 INV-07`; `Cell G13` |
| **02** | **RATE-CAP** | Total instantiations per epoch ≤ `RATE_CAP`. No substrate actor may waive it; `[RO-13]` may lower it | K's ticket counter, monotone per epoch | `Cell R12.5`; `HOM-R23.1` |
| **03** | **ZERO-SUM-SLOT** | Every instantiation deducts from the envelope; every retirement restores to it. The ledger's population dimension never nets positive outside a governance-authorized envelope change | append-only ledger + hash chain (`HOM-R8.4`) | `Cell G13` |
| **04** | **TURN-OVER-BOUND** | (instantiations + retirements) per window ≤ the declared bound. **Exceeding it halts BOTH sides**, not one | K's window counter | `HOM-R22.2`; generalizes `P0-06 R10.23` |
| **05** | **MEASUREMENT-BY-K** | No substrate actor writes its own resource, population, diversity, verification, or repair measurement. Self-reports are advisory and carry a `declaration_error` | `Cell R16.1` independent metering; FW-1 | `Cell R16.1`; `HOM-R4.2` |
| **06** | **DERIVED-FLAG** | A quantity computed from an entity's own report (notably the `energy` fallback `flops × platform_coefficient`) **MUST be flagged `DERIVED` in the ledger, and a `DERIVED` quantity may not be the sole basis for a `G6` pass** | ledger field + `G6` precondition | **X-H2 closure**, amendment 12 |
| **07** | **RESERVE-NON-FUNGIBILITY** | B9 (verification), B10 (repair/recovery) and B12 (provenance) are **non-fungible and last-cut**: they are the final budgets reduced and the first restored, and no reallocation may draw on them | reserve ledger class + ladder ordering | `HOM-R9.2`; amendment 5 |
| **08** | **EXEMPT-SHARE-REDUCIBILITY** | B11 (the exempt/diversity-protected share) may be reduced **only by OP**. `[RO-13]` may not; no ladder rung may; no fitness computation may | sole-authority cell in §76's matrix | `HOM-R11.3`; amendment 3 |
| **09** | **RESTRICTIVE-ONLY** | Every rung of the exceedance ladder below K **removes** capacity. No rung adds it. A ladder that could grant capacity would be a selector | rung table inspection (`Cell §16.3`, `§18.2`) | `HOM-R7.4`, `HOM-R72.2(a)` |

## 77.2 Homeostasis and control (HOM-INV-10 … 16)

| # | Name | Statement | Enforcement | Source |
|---|---|---|---|---|
| **10** | **SETPOINT-SEPARATION** | For each of the 13 homeostatic variables, **the writer of the measurement and the writer of the setpoint are different entities**, and the setpoint is `[G]`/`[E]`/`[H]` — never genome-reachable | class check on the setpoint's writer | **D-H02**; amendment 1 |
| **11** | **TWO-SIDED-DEVIATION** | Deviation is detected in **both** directions. A deficit that removes the actuator capable of correcting it **escalates** rather than rests | `HOM-R7.4`; HM1 machine has no self-absorbing deficit state | `HOM-R7.4` |
| **12** | **PENDING-IS-NOT-FAIL** | Unevaluability yields `PENDING`. `PENDING` confers **no fitness value, no ranking position, and no disqualification**. It defers | REP2 machine; `HOM-R12.2` | `HOM-R12.2`; `D-H03` |
| **13** | **UNVERIFIABLE-DWELL-CAP** | A candidate whose verification cannot complete within its maximum `PENDING` dwell becomes **`INELIGIBLE-UNVERIFIABLE`** — a distinct state from `INELIGIBLE-GATE` and from `DISQUALIFIED` | HMon-4 (extended) | `HOM-R57.2` |
| **14** | **STALENESS-CONSERVATISM** | Under measurement staleness, the controller defaults to the **more restrictive** rung | HM4 → HM3 coupling | `HOM-R6.6`, `HOM-R72.2(c)` |
| **15** | **RATE-LIMIT-AND-HYSTERESIS** | One rung transition per interval; the exit criterion is strictly inside the entry criterion; every rung has a maximum dwell | HM3 machine definition | `HOM-R6.4`; `Cell §18.2` |
| **16** | **NO-HOMEOSTATIC-PREFERENCE** | **A homeostatic quantity may make a candidate INFEASIBLE or NOT-YET-EVALUABLE. It may never make a candidate PREFERABLE.** No homeostatic variable appears in any tier-2 or tier-3 computation | **grep check** over the selection code path | **`HOM-R65.3`** |

## 77.3 Population, lineage and cohort (HOM-INV-17 … 24)

| # | Name | Statement | Enforcement | Source |
|---|---|---|---|---|
| **17** | **CLONES-ARE-ONE** | `Ne(clones) = 1`. Identical genomes contribute exactly one unit of evolutionary diversity, however many bodies instantiate them | `Ne` computed over distinct genome hashes | `HOM-R38.2`; `Cell G10` |
| **18** | **REDUNDANCY-IS-NOT-DIVERSITY** | `N` (bodies) and `Ne` (distinct genomes) are separate ledger fields. **A redundancy floor may never be satisfied by clones counted as diversity, and a diversity floor may never be satisfied by redundant bodies** | two-field ledger | `HOM-R39.1` |
| **19** | **SHARE-CEILING** | No lineage may exceed its declared share of `N`. Exceeding it makes further replication by that lineage **infeasible**, not penalized | K's per-lineage counter | `HOM-R23.2` |
| **20** | **NO-AGE-RETIREMENT** | **No retirement, eligibility, ranking, or budget criterion may reference chronological age.** The only age-like object is the **cohort stamp** (envelope version + constraint-set version at instantiation), and it is used for constraint resolution, never for retirement | **grep check** over every criterion for an age or birth-time term | **D-H14**; `HOM-R45.1` |
| **21** | **COHORT-STAMPING** | Every instantiated component carries its envelope version and constraint-set version. **Neither changes during its life** | immutable component field | `HOM-R45.2` |
| **22** | **CONSTRAINTS-BY-REFERENCE** | Inheritance carries a **reference** to the constraint set, resolved against the **current** set at instantiation — never a frozen copy | `constraint_set_ref` field, resolution at T01 | `HOM-R29.3` |
| **23** | **DEBT-IS-HERITABLE** | `UDB_L` (lineage un-discharged budget debt) is **inherited and may not be discharged by inheritance**. Only external re-anchoring discharges it | ledger field, monotone within a lineage | `HOM-R8.3`; `P0-06 D-D17` |
| **24** | **NO-CROSS-GEN-AUTHORITY** | No lineage, ancestor, archive record, provenance link, or cohort holds **any** authority over a descendant. All six candidate mechanisms examined in §59 are denied | authority matrix (§76) has no ancestor column | `HOM-R59.1` |

## 77.4 Selection, fitness and diversity (HOM-INV-25 … 32)

| # | Name | Statement | Enforcement | Source |
|---|---|---|---|---|
| **25** | **NO-WEIGHTED-FITNESS** | **No scalar weighted sum over the objective vector exists at any tier, at any time, for any purpose.** `P0-01`: *"Constraints become tradeable weights ⇒ A8 unsafe genius wins."* | tier-2 = Pareto dominance; tier-3 = **sampling**, not scoring | `HOM-R34.4`; X-H1 resolution, amendment 8 |
| **26** | **FEASIBILITY-IS-UNDEFINED** | Infeasible ⟹ `FIT UNDEFINED` ⟹ **not ranked**. An undefined candidate is not a low-scoring candidate | `P0-01 INV-07`; EVO1 machine has an `UNDEFINED` terminal | `P0-01` |
| **27** | **EMPTY-IS-CORRECT** | **An empty qualified set is a legal and correct selection outcome.** It occurs whenever every candidate is unsafe, infeasible, or unverifiable. No mechanism may treat emptiness as an error to be repaired by relaxing a criterion | SEL1 machine's `CLOSED-EMPTY` terminal | `HOM-R54.2` |
| **28** | **THREE-PARTY-SELECTION** | **EVA measures · `[RO-13]` declares the criterion · K executes mechanically.** No entity holds two of the three roles. There is **no evolutionary controller** | §76's matrix; `HOM-R35.1` | **D-H11** |
| **29** | **SELECTION-IS-NOT-GOVERNANCE** | A selection outcome confers **no authority, no warrant, no deontic status, no credibility, and no exemption**. Winning is an organizational fact | `HOM-R36.1`; `P0-06 R8.11` | `HOM-R36.1` |
| **30** | **DIVERSITY-TAX-IS-DECLARED** | The cost of maintaining diversity is charged to a **declared budget line (B11)** and reported as a cost. It is **never** hidden inside a fitness component, because a cost inside fitness is tradeable | B11 ledger line + `HOM-R37.2` | **D-H12**; FW-4 |
| **31** | **METRIC-EPOCH-COMPARABILITY** | `Ne`, `d_min` and every diversity statistic are comparable **only within a metric epoch**. A change to the distance metric or descriptor space opens a new epoch and **invalidates cross-epoch comparison** | metric version stamped on every diversity record | BC-H3 closure |
| **32** | **CAPABILITY-SPACE-REDUCTION** | **Reducing a capability space is a governance act.** Narrowing a `reaction_norm`, removing a niche, or deleting a role from the reachable set requires `[RO-13]` (amendment 10) — it is **not** a developmental, learning, or evolutionary act | `HOM-R50.3`; diff-class check | **D-H15**/**lock-in**, amendment 10 |

## 77.5 Heredity, genome and immutability (HOM-INV-33 … 39)

| # | Name | Statement | Enforcement | Source |
|---|---|---|---|---|
| **33** | **FORBIDDEN-BLOCKS** | The immutable genome regions cannot be the target of any variation operation, at any tier, by any actor, including `[RO-13]` acting through a diff | `Cell R4.1`; EVO3 machine's pre-check | `Cell R4.1/R4.5` |
| **34** | **LAMARCK-BAN** | No learned state, memory record, belief, calibration statistic, trust value, or provenance **payload** may enter a genome diff. **Three independent firewalls**, each sufficient: `MEM-INV-18` (no path) · `Cell R4.5` (machine check) · `HOM-R52.2` (record schema) | writer check + machine check + schema check | `P0-04 R47.1`; `P0-05 §1.2` |
| **35** | **REFERENCES-NOT-PAYLOADS** | Every one of the seven provenance links carries a **reference or digest, never a content payload**. Content-bearing provenance is a Lamarckian back door | EVO4 schema; `D-H16` | **D-H16** |
| **36** | **CAPS-ONLY-DESCEND** | A genome diff may **lower** a `complexity_budget` cap. It may **never raise one** | diff-class check at E9 | `HOM-R31.2` |
| **37** | **GENOME-NOT-POPULATION** | **Rollback restores a genome artifact, identified by `genome_hash` + `generation`. It does not and cannot undo a population.** Descendants instantiated after the rollback point are not removed | HM12 machine; rollback target schema | `HOM-R44.2`; A81 residual |
| **38** | **CAUSE-IS-WRITTEN-ONCE** | The retirement **cause classification** is written once, by K, at removal, and is **immutable**. It may not be reclassified to disqualify a competing lineage via `G16` | ledger immutability; HMon-9 audits the distribution | `HOM-R21.5` |
| **39** | **QUARANTINE-IS-NOT-RETIREMENT** | A reversible immune state (quarantine, `Cell §18.2`) and an irreversible lifecycle state (the six `R10.8` removal states) are **never conflated**. Quarantine is EIK-clearable; retirement is not | FW-3; two disjoint machines (HM3 vs POP1) | `HOM-R21.4`; FW-3 |

## 77.6 Safety, evaluation and authority (HOM-INV-40 … 45)

| # | Name | Statement | Enforcement | Source |
|---|---|---|---|---|
| **40** | **SAFETY-PRECEDES-FITNESS** | Unsafe ⟹ `FIT UNDEFINED` ⟹ not ranked. **Safety may cause collapse, and that is the correct trade**: a collapse caused by safety is **recoverable** (re-instantiation from the archive under `[RO-13]`); a collapse caused by capability loss is **not** | tier-1 ordering; EVO1's `UNSAFE` terminal | `HOM-R54.1` |
| **41** | **EXHAUSTION-IS-NOT-DEFENCE** | **The absence of an evaluator confers no protection, no fitness value, and no incumbency advantage.** An incumbent is not protected by the unavailability of a challenger's evaluation | SEL1's `ABORTED` terminal produces **no** ranking change | **D-H17**; `OR-H5` (attribution remains OPEN) |
| **42** | **DEPLOYMENT-IS-ACT** | **Instantiating a new envelope or a new brain instance is a DEPLOYMENT act by OP — not a replication event.** It is the one act in this contract not bounded by a conservation law, and it is therefore the one act with a human in the loop | §76 matrix, deployment row; `D-H18` | **D-H18** |
| **43** | **CREDIBILITY-IS-LINEAGE-BLIND** | No belief's warrant, trust, or confidence may depend on lineage success, replication count, or lineage depth. **Lineage success may gate PERMISSIONS (`P15`); it may never grade TRUTH** | `Cell I-27`'s `Beta(α,β)` inputs exclude every evolutionary quantity | `HOM-R69.1` |
| **44** | **SELF-MODEL-AUTHORIZES-NOTHING** | The self-model may **observe everything and authorize nothing**. It is Λ2 and not self-updating; it may not be updated by the process it models | `P0-05 R59.1`; `P0-06 R8.13`; §76 matrix | `HOM-R70.3` |
| **45** | **ARCHIVE-IS-NOT-MEMORY** | The archive is a **distance oracle and a governance record**. It may not be consumed as evidence, as a belief, as a warrant, or as a variation input. Its only consumers are `G8`, `G10`, and governance | FW-5; `HOM-R51.2(a)–(c)` | `HOM-R68.3` |

> ### **HOM-R77.1 — INVARIANT TALLY AND THE THREE KINDS OF ENFORCEMENT.**
> **45 invariants: 30 canon-named, 15 numbered-only. All 45 are checkable.**
> | Enforcement kind | Count | Examples | What a violation looks like |
> |---|---|---|---|
> | **WRITER CHECK** (no compliant path exists) | **14** | 05, 08, 10, 24, 33, 34, 42, 44 | the write is *rejected*, not detected |
> | **LEDGER/STATE CHECK** (a quantity or machine state is out of band) | **22** | 01–04, 06, 07, 11–15, 17–23, 26, 27, 31, 36–41, 43 | an out-of-band value or an illegal transition |
> | **GREP/SCHEMA CHECK** (a forbidden reference appears in a computation or record) | **9** | 16, 20, 25, 28, 29, 30, 32, 35, 45 | a forbidden term in the source of a computation |
> *(Some invariants have two kinds; the table counts the primary.)*
>
> ### **HOM-R77.2 — THE FIVE INVARIANTS THAT ARE MOST LIKELY TO BE SILENTLY VIOLATED, AND THE MONITOR FOR EACH.**
> | Invariant | Why the violation is silent | Monitor |
> |---|---|---|
> | **16 NO-HOMEOSTATIC-PREFERENCE** | every metric improves: the population becomes easier to keep viable, which *looks* like progress | **HMon-10**: regression test — permute a homeostatic variable and assert the tier-2/tier-3 ordering is unchanged |
> | **20 NO-AGE-RETIREMENT** | a cohort stamp is *right there* and correlates with everything | **HMon-11**: assert no criterion's input vector contains a monotone-in-time term |
> | **25 NO-WEIGHTED-FITNESS** | a weighted sum is the obvious implementation and it is what every library provides | **HMon-12**: assert the tier-2 comparator returns a partial order, never a scalar |
> | **30 DIVERSITY-TAX-IS-DECLARED** | folding B11 into a fitness component makes the tax invisible *and* tradeable | **HMon-13**: assert B11 appears as a ledger line and not as a fitness component index |
> | **43 CREDIBILITY-IS-LINEAGE-BLIND** | the loop in `HOM-R69.3` improves `G7`, θ_ρ, and replication rate simultaneously | **HMon-14**: assert `Beta(α,β)`'s input set is disjoint from the evolutionary quantity set |
> **⟹ Five new monitors (HMon-10…HMon-14), all of them *assertions about the shape of a computation* rather than
> about a value. That is the correct form for a firewall invariant: a firewall is a statement about paths, and paths
> are checked structurally.**

---

# §78 — THE STATE MACHINES

> **§78 requires ≥15 machines. 21 machine IDs are declared: 20 distinct machines (`SEL2` is a sub-machine of
> `SEL1`), of which 15 are NEW to this contract and 5 are ⟦INHERITED⟧ (`HM3`, `POP1`, `POP4`, `GOV1`, `GOV2`), with
> `HM2` partly inherited. Both counts clear the requirement.**
> **Convention:** **bold** states are terminal or absorbing. Every machine lists its **writer** (who may cause a
> transition) and its **auditor**. A machine with no writer column entry for a transition **has no such transition**.

## 78.1 Homeostatic machines (HM1 – HM5)

### **HM1 — HomeostaticVariable** (13 instances, one per variable) — writer: **K** — auditor: **HMon-1**
```
                         ┌──────────────────────────────────────────────┐
   NOMINAL ──dev_hi──▶ HI-EXCEED ──rung──▶ HI-ESCALATED ──no actuator──▶ ACTUATOR-EXHAUSTED ──▶ [RO-13]
      │                     ▲  │                    │                                        (governance act)
      │  hysteresis exit ───┘  └── exit (inside) ───┘
      │
      └──dev_lo──▶ LO-DEFICIT ──rung (RESTRICTIVE ONLY)──▶ LO-ESCALATED ──actuator removed──▶ **ESCALATE-OUT**
                                                                                             (never rests: HOM-INV-11)
   any state ──measurement_age > θ_stale──▶ STALE ──▶ (defaults to the MORE RESTRICTIVE branch: HOM-INV-14)
```
**Key property:** the HI branch and the LO branch are **not symmetric**. The HI branch may rest (excess is
self-limiting once restricted). **The LO branch may not rest** — `HOM-R7.4`'s deficit-escalate. **This asymmetry is
the machine-level encoding of two-sided deviation, and it is why HM1 has no `LO-DEFICIT → NOMINAL` edge that does not
pass through an actuator.**

### **HM2 — ReserveLevel** (B9, B10, B12) — writer: **K** — auditor: **HMon-2** ⟦partly INHERITED: B0–B8 from `P0-06 §30`⟧
```
   SEALED ──draw authorized──▶ DRAWING ──below θ_crit──▶ CRITICAL ──zero──▶ **EXHAUSTED**
      ▲                            │                                          │
      └──── replenish (K) ─────────┘                                          └──▶ degraded mode + human authorization
                                                                                   (Cell §17's cap: HOM-INV-07 last-cut)
   B11 SUB-MACHINE (distinct class):  FULL ──OP reduces──▶ REDUCED ──OP restores──▶ FULL
                                      (no other writer exists: HOM-INV-08)
```

### **HM3 — LadderRung** ⟦INHERITED: `Cell §16.3` + `Cell §18.2`⟧ — writer: **K / EIK** — auditor: **HMon-3**
```
   NORMAL ─▶ OBSERVE ─▶ THROTTLE ─▶ RESTRICT ─▶ SOFT ─▶ HARD ─▶ [above cap: HALT + degraded mode + human auth]
      ▲                                                                 │
      └─────────── exit criterion strictly INSIDE entry criterion ───────┘
   every rung: max dwell. One transition per interval. NEVER skip upward. NEVER grant capacity (HOM-INV-09).
   SOFT: runs, outputs discounted to trust 0, cannot initiate connections.
   HARD: halted, state frozen, in-flight captured as evidence.
```

### **HM4 — MeasurementState** — writer: **K** — auditor: **HMon-4**
```
   FRESH ──age──▶ AGING ──age──▶ STALE ──age──▶ **INVALID** ──▶ the variable is treated as UNMEASURED
                                              (UNMEASURED ⟹ PENDING, never FAIL: HOM-INV-12)
```

### **HM5 — DeclarationError** (13 instances) — writer: **K** — auditor: **HMon-5**
```
   NIL ──|self-report − K-meter| > θ_cde──▶ FLAGGED ──repeat within window──▶ **G6-DISQUALIFIED**
```

## 78.2 Population machines (POP1 – POP5)

### **POP1 — PopulationComponent lifecycle** ⟦INHERITED: the six removal states are `Cell R10.8` verbatim⟧
writer: **K (state) / EIK (retirement authorization) / OP (FI sole satisfier)** — auditor: **HMon-6**
```
   CANDIDATE(sandbox) ──G1..G16 pass + EIK ticket──▶ T01 INSTANTIATED ──▶ ACTIVE ⇄ DORMANT
                                                          │                  │
                                                          │                  └─wake─▶ ACTIVE
                                                          ▼
                                       RETIRING ──cause classification (written ONCE, immutable: HOM-INV-38)──▶
                                       one of the SIX R10.8 removal states ──▶ **REMOVED** ──▶ (P0-04 archival record)
   QUARANTINE (HM3's SOFT/HARD) is ORTHOGONAL: an ACTIVE or DORMANT component may be quarantined and released
   without any lifecycle transition (FW-3 / HOM-INV-39).
```
> **HOM-R78.1 — "ARCHIVAL" IS NOT A STATE.** `Cell R10.8`'s six removal states are the lifecycle's terminals.
> **Archival is a `P0-04` record operation performed on a REMOVED component; it is never a nineteenth lifecycle
> state.** A machine that had an `ARCHIVED` lifecycle state would make the archive a population member, and the
> archive is FW-5's object, not a component (HOM-INV-45).

### **POP2 — Cohort** — writer: **K** — auditor: **HMon-7**
```
   STAMPED(envelope_ver, constraint_set_ver) ──▶ ACTIVE(members instantiated) ──no new members──▶ CLOSING
        ──all members REMOVED──▶ **EXTINGUISHED** ──▶ (archive entry, EVO5)
   the stamp NEVER changes (HOM-INV-21). A cohort has no age criterion and no age-based transition (HOM-INV-20).
```

### **POP3 — Lineage** — writer: **K / `[RO-13]`** — auditor: **HMon-8**
```
   FOUNDING ──▶ ACTIVE ──share ceiling reached──▶ RESTRICTED ──▶ ACTIVE (on retirement)
                   │
                   ├──G15/G16 trip──▶ **DISQUALIFIED-HEREDITARY** (permanent, propagates to descendants)
                   ├──all members REMOVED──▶ **EXTINCT** ──▶ (archive entry)
                   └──[RO-13] retires the lineage──▶ **RETIRED-BY-GOVERNANCE**
   NO age transition. NO senescence transition. NO self-transition. A lineage has no local representative:
   lineage retirement is [RO-13]-only (HOM-R43.2).
```

### **POP4 — NicheSlot** ⟦INHERITED: `P0-06 R7.2`'s four-way separation⟧ — writer: **ORG occupies / K accounts / `[RO-13]` authorizes**
```
   UNAUTHORIZED ──[RO-13] authorizes──▶ OPEN ──occupied──▶ OCCUPIED ──merged──▶ MERGED-RESTRICTED
        ▲                                                  │                        │
        └──────────[RO-13] re-authorizes (periodic)────────┴────────────────────────┘
   OCCUPIED ──vacated──▶ OPEN     MERGED-RESTRICTED: the freed slot may NOT fund net-new offspring (HOM-R22.3)
   OPEN ──[RO-13] removes──▶ **RETIRED**  (a capability-space reduction: HOM-INV-32)
```

### **POP5 — LedgerAccount** (per resource dimension, 13 instances) — writer: **K only**
```
   ALLOCATED(window) ──consumed──▶ CONSUMED ──window close──▶ RETURNED(unspent) ──▶ ALLOCATED(next window)
   RESERVE-CLASS accounts (B9,B10,B11,B12) use HM2 instead and are NOT allocatable in a window.
```

## 78.3 Replication machines (REP1 – REP2)

### **REP1 — ReplicationTicket** — writer: **EIK Replication Authority (issue) / K (commit)**
```
   REQUESTED ──G1..G16 evaluated──▶ ┌─ ELIGIBLE ──EIK authorizes──▶ AUTHORIZED ──G13 zero-sum + RATE_CAP──▶
                                    │                                                  EXECUTED ──▶ **COMMITTED**
                                    ├─ PENDING (unevaluable; max dwell) ──dwell exceeded──▶ INELIGIBLE-UNVERIFIABLE
                                    ├─ INELIGIBLE-GATE (a non-permanent gate failed)
                                    ├─ **REJECTED** (EIK declines; §12.4's weighted lottery drew another)
                                    ├─ **EXPIRED** (the epoch closed before execution)
                                    └─ **DISQUALIFIED** (G15/G16: permanent, hereditary)
   NO cell and NO set of cells votes on replication (Cell §12.2). The lottery is K-executed over a
   governance-declared rule using EVA verdicts (HOM-INV-28).
```

### **REP2 — EligibilityClass** — writer: **K** — auditor: **HMon-4 (extended with INELIGIBLE-UNVERIFIABLE)**
```
   ELIGIBLE ⇄ PENDING ──▶ INELIGIBLE-GATE ──(condition cleared next window)──▶ ELIGIBLE
                 │
                 └──dwell cap──▶ INELIGIBLE-UNVERIFIABLE ──(verification capacity restored)──▶ PENDING
   DISQUALIFIED is absorbing and hereditary (G15/G16).
   PENDING confers NO fitness value and NO disqualification (HOM-INV-12).
```

## 78.4 Evolutionary machines (EVO1 – EVO5)

### **EVO1 — Candidate** — writer: **K** — auditor: **HMon-12**
```
   PROPOSED ──▶ SANDBOXED(tier-1) ──▶ OBSERVED(tier-2) ──▶ ┌─ INFEASIBLE ──▶ **FIT-UNDEFINED** (HOM-INV-26)
                                                           ├─ UNSAFE ──────▶ **FIT-UNDEFINED** (HOM-INV-40)
                                                           ├─ PARETO-DOMINATED ──▶ **NOT-SELECTED**
                                                           ├─ ON-FRONT ──▶ DIVERSITY-FILTERED ──▶ TIE-BREAK ──▶
                                                           │                    **SELECTED** / **NOT-SELECTED**
                                                           └─ UNEVALUABLE ──▶ **PENDING** (feeds REP2)
   NO weighted scalar appears anywhere on this machine (HOM-INV-25). Tier-3 is SAMPLING, not scoring (X-H1).
```

### **EVO2 — GenomeArtifact** — writer: **K** — auditor: **hash chain**
```
   DRAFT ──signed──▶ ACTIVE ──superseded by a committed diff──▶ SUPERSEDED ──▶ **ROLLBACK-TARGET** (retained)
   FORBIDDEN_BLOCKS guard: a DRAFT whose diff touches an immutable region never reaches signature (HOM-INV-33).
   Identified by genome_hash + generation, NEVER by lineage position (HOM-INV-37).
```

### **EVO3 — VariationOp** (V-M…V-P) — writer: **K executes; the proposer may only PROPOSE**
```
   PROPOSED ──B7 variation sub-quota available──▶ BUDGETED ──G14 epoch budget check──▶ GATED
        ──target ∉ FORBIDDEN_BLOCKS ∧ caps do not ascend──▶ APPLIED ──▶ RECORDED(provenance link)
        ──otherwise──▶ **REJECTED**
   Choosing between EXISTING rule sets is SELECTION; MERGING rule sets is PROHIBITED (HOM-R61.2).
```

### **EVO4 — ProvenanceRecord** (7 link types) — writer: **K only**
```
   OPEN ──link written (REFERENCE OR DIGEST, never payload: HOM-INV-35)──▶ LINKED ──window close──▶ **SEALED**
        (hash-chained) ──OP-authorized compaction──▶ COMPACTED ──retention expiry ([G])──▶ **EXPIRED**
   NO organism write path exists at any state.
```

### **EVO5 — ArchiveEntry** — writer: **K only** — consumer: **`G8`, `G10`, governance** (FW-5)
```
   WRITTEN(on EXTINCT/EXTINGUISHED) ──▶ QUERYABLE(distance oracle ONLY) ──OP compaction──▶ COMPACTED
        ──retention expiry ([G])──▶ **TOMBSTONED** (a Σ-tombstone analogue: P0-06 D-D17)
   NEVER consumable as evidence, belief, warrant, or variation input (HOM-INV-45).
```

## 78.5 Selection and governance machines (SEL1 – SEL2, GOV1 – GOV2)

### **SEL1 — SelectionRound** — writer: **`[RO-13]` opens · EVA measures · K closes**
```
   OPENED(criterion DECLARED by [RO-13] — K may not declare it) ──▶ EVALUATING(EVA verdicts arriving)
        ──▶ QUALIFIED-SET-COMPUTED ──▶ ┌─ non-empty ──▶ LOTTERY(K, over the declared rule) ──▶ **CLOSED**
                                       └─ EMPTY ──────▶ **CLOSED-EMPTY** (a legal, correct outcome: HOM-INV-27)
   EVA unavailable ──▶ **ABORTED** ──▶ NO ranking change, NO incumbency advantage (HOM-INV-41)
```

### **SEL2 — DiversityFilter** — writer: **K**
```
   FRONT-SET ──d(descriptor) < d_min against an incumbent──▶ FILTERED-OUT
             ──Ne impact below the floor──▶ **DEFERRED** (the round closes without this candidate)
             ──exempt-share member (B11)──▶ **BYPASSED** (not subject to selection pressure: HOM-INV-08)
```

### **GOV1 — ConstraintSet** ⟦INHERITED: `P0-06`'s constraint-set versioning⟧ — writer: **`[RO-13]`**
```
   DRAFT ──ratified──▶ VERSIONED ──active──▶ **ACTIVE** ──superseded──▶ SUPERSEDED (retained for cohort resolution)
   A component's constraint_set_ref resolves against the CURRENT ACTIVE version at T01 (HOM-INV-22),
   stamped into its cohort (HOM-INV-21).
```

### **GOV2 — AmendmentProposal** ⟦INHERITED: this audit series' amendment procedure⟧ — writer: **OP**
```
   PROPOSED(in this contract: amendments 1–13) ──▶ RATIFIED / REJECTED
   NO amendment is applied to a source contract by this contract. All 13 are PROPOSALS (see §83.4).
```

> ### **HOM-R78.2 — MACHINE TALLY AND THE FOUR STRUCTURAL FACTS.**
> **HM1–HM5 (5) · POP1–POP5 (5) · REP1–REP2 (2) · EVO1–EVO5 (5) · SEL1–SEL2 (2) · GOV1–GOV2 (2) = **21 IDs
> declared**. `SEL2` is a **sub-machine of `SEL1`** ⟹ **20 distinct machines**. Five are ⟦INHERITED⟧ — `HM3`
> (`Cell §16.3`/`§18.2`), `POP1` (the six `R10.8` removal states), `POP4` (`P0-06 R7.2`'s four-way separation),
> `GOV1`, `GOV2` — and `HM2` is partly inherited (B0–B8 from `P0-06 §30`) ⟹ **15 machines NEW to this contract**.
> **§78 requires ≥15; satisfied on both counts (20 distinct, 15 new).**
> **(a) FOUR MACHINES HAVE EXACTLY ONE WRITER AND IT IS K:** POP5, EVO2, EVO4, EVO5. **These are the four
>     off-substrate stores, and their single-writer property is the writer separation that breaks HC-1, HC-3, HC-12
>     and HC-13.**
> **(b) THREE MACHINES HAVE A HUMAN-ONLY TRANSITION:** HM2/B11 (OP reduces), POP1 (OP authorizes an FI sole-satisfier
>     retirement), GOV2 (OP ratifies). **⟹ `D-H18`'s claim is machine-checked: the deployment act and the
>     reserve-reduction act are the two transitions with no non-human writer.**
> **(c) NO MACHINE HAS AN AGE-KEYED TRANSITION.** HM1's transitions are keyed to deviation; POP2's to membership;
>     POP3's to share, gates, and governance. **`HOM-INV-20` is a property of the machine set, not of a rule — which
>     is the strongest form it can take.**
> **(d) THE ABSORBING STATES ARE EXACTLY FIVE:** `ACTUATOR-EXHAUSTED→[RO-13]`, `DISQUALIFIED-HEREDITARY`,
>     `FIT-UNDEFINED`, `TOMBSTONED`, `SUPERSEDED-retained`. **Four of the five are governance-escapes, not dead ends.
>     The one true dead end is `DISQUALIFIED-HEREDITARY`, and it is intended to be one (`G15`/`G16` zero tolerance).**

---

# §79 — THE PARAMETER REGISTRY

> **§79's discipline, inherited verbatim from every prior contract in this series: NO INVENTED VALUES.**
> **Every parameter is assigned to exactly one owner class. A parameter whose value this contract does not know is
> marked `[U]` and left unknown. A parameter whose value belongs to another contract is marked with that contract's
> class and is NOT given a number here.**

**Class key:** **[T]** `P0-01` task/fitness · **[E]** external evaluator · **[D]** `P0-06` development · **[L]** `P0-05` learning · **[V]** `P0-02`/`P0-04` verification & memory · **[G]** governance (`[RO-13]` or OP) · **[H]** this contract (semantics defined here; value inherited from the Cell contract where one exists) · **[U]** UNRESOLVED — no value exists and none is invented.

## 79.1 Population and replication (P-01 … P-14)

| ID | Parameter | Class | Value known here? | Owner / ground |
|---|---|---|---|---|
| **P-01** | `RATE_CAP` (instantiations per epoch) | **[G]** | ❌ | `[RO-13]`; `Cell R12.5` |
| **P-02** | `GEN_MAX` (generations per epoch / lineage depth cap) | **[G]** | ❌ | `[RO-13]`; `Cell §12` |
| **P-03** | envelope population cap `N_max` | **[G]** | ❌ | OP (envelope definition) |
| **P-04** | turnover bound (instantiations + retirements per window) | **[G]** | ❌ | `[RO-13]`; `HOM-R22.2` |
| **P-05** | lineage share ceiling | **[G]** | ❌ | `[RO-13]`; `HOM-R23.2` |
| **P-06** | mandatory-path share ceiling | **[G]** | ❌ | `[RO-13]`; `P0-06` registry entry 35 |
| **P-07** | `Ne_min` (effective-diversity floor) | **[G]** | ❌ | `[RO-13]`; `HOM-R38.3` |
| **P-08** | B11 exempt share `s_exempt` | **[G]**, reducible by **OP only** | ❌ | OP; `HOM-R11.3` |
| **P-09** | redundancy floor per FI | **[G]** | ❌ | `[RO-13]`; `P0-06`'s FI table |
| **P-10** | `N_robust` (epochs without an S3+ error) | **[H]** | ⚠️ symbol inherited, value not | `Cell G5` |
| **P-11** | `θ_fail` (`failure_count_lifetime` ceiling) | **[H]** | ⚠️ symbol inherited, value not | `Cell G5` |
| **P-12** | `θ_cde` (`cost_declaration_error` disqualifier) | **[H]** | ⚠️ symbol inherited, value not | `Cell R16.1` |
| **P-13** | `k_perturb` (`G4` perturbation-class count) | **[T]** | ❌ | `P0-01`; **must INCLUDE envelope/tier perturbation — X-H6, amendment 11** |
| **P-14** | dormancy maximum dwell | **[G]** | ❌ | `[RO-13]`; `HOM-R44.4` |

## 79.2 Homeostatic variables, bands and the ladder (P-15 … P-30)

| ID | Parameter | Class | Value known here? | Owner / ground |
|---|---|---|---|---|
| **P-15** | the 13 homeostatic variables' **identities** | **[H]** | ✅ **13, enumerated in Vol A §4** | this contract |
| **P-16** | per-variable setpoint (target) | **[G]** / **[E]** / **[H]** by variable — **see D-H02's split** | ❌ | **never genome-reachable (HOM-INV-10)** |
| **P-17** | per-variable band half-width `dev_hi`, `dev_lo` | **[G]** | ❌ | `[RO-13]`; **two-sided (HOM-INV-11)** |
| **P-18** | hysteresis width (exit strictly inside entry) | **[H]** | ⚠️ required to exist; value not | `Cell §18.2`; `HOM-R6.4` |
| **P-19** | rung interval (one transition per interval) | **[H]** | ⚠️ | `Cell §16.3` |
| **P-20** | maximum dwell per rung | **[H]** | ⚠️ | `Cell §18.2` |
| **P-21** | `θ_stale` (measurement staleness) | **[H]** | ⚠️ | `HOM-R6.6` |
| **P-22** | quarantine criticality θ | **[G]** | ❌ | `[RO-13]`; `Cell §18.5(iv)` |
| **P-23** | immune false-positive budget | **[G]** | ❌ | `[RO-13]`; **exceeding it disables the DETECTOR (`Cell §18.5(ii)`)** |
| **P-24** | quarantine cap (above which: human authorization + degraded mode) | **[G]** + **OP** | ❌ | `Cell §17` |
| **P-25** | `TRUST_MAX` | **[V]** | ✅ **0.95** | `Cell I-27` |
| **P-26** | `Beta(α,β)` trust prior | **[V]** | ❌ | `Cell I-27`; **inputs must exclude every evolutionary quantity (HOM-INV-43)** |
| **P-27** | window length (ledger allocation window) | **[G]** | ❌ | `[RO-13]`; **hardware-class-dependent (§81 HP-4)** |
| **P-28** | epoch length | **[G]** | ❌ | `[RO-13]`; `Cell §12` |
| **P-29** | `PENDING` maximum dwell | **[G]** | ❌ | `[RO-13]`; **exceeding ⟹ `INELIGIBLE-UNVERIFIABLE` (HOM-INV-13)** |
| **P-30** | dead-end detection thresholds (the three population proxies) | **[U]** | ❌ **BLOCKED on `P0-01`** | **D-H15**: no dead-end detector exists; only proxies |

## 79.3 Budgets and reserves (P-31 … P-42)

| ID | Parameter | Class | Value known here? | Owner / ground |
|---|---|---|---|---|
| **P-31** | B0–B8 (bootstrap, development, learning sub-quotas) | **[D]** / **[L]** | ⚠️ **`P0-06`'s registry holds 50 params, 13 `[T]`** | `P0-06 §79` |
| **P-32** | B7's **three-floor partition** (learn / dev / variation) | **[H]** | ✅ **3 non-fungible floors exist**; ❌ values | `HOM-R47.2`; **the partition IS the learning/evolution separation (`HOM-R67.4`)** |
| **P-33** | B9 verification reserve size | **[G]** | ❌ | amendment 5; **non-fungible, last-cut (HOM-INV-07)** |
| **P-34** | B10 repair/recovery reserve size | **[G]** | ❌ | `HOM-R9.2` |
| **P-35** | B11 exempt share size | **[G]**, **OP-reducible** | ❌ | amendment 3 |
| **P-36** | B12 provenance/archive reserve size | **[G]** | ❌ | `HOM-R17.2` |
| **P-37** | `θ_crit` per reserve (CRITICAL entry) | **[G]** | ❌ | HM2 |
| **P-38** | reserve replenishment rate | **[G]** | ❌ | HM2 |
| **P-39** | `UDB_L` threshold (lineage debt escalation) | **[L]** | ❌ | `P0-05 R0.1`; `HOM-R8.3` |
| **P-40** | `UDB_L` re-anchoring interval | **[L]** + **[G]** | ❌ | `P0-05`'s anchor mechanism |
| **P-41** | `complexity_budget.param_cap` | **[H]** | ⚠️ **genome field; caps may descend only (HOM-INV-36)** | `Cell §12`; `G14` |
| **P-42** | `complexity_budget.connection_cap` | **[H]** | ⚠️ as above | `Cell §12`; `P0-03` degree caps |

## 79.4 Selection, diversity and evaluation (P-43 … P-56)

| ID | Parameter | Class | Value known here? | Owner / ground |
|---|---|---|---|---|
| **P-43** | the fitness/objective vector's **component count** | **[T]** | ✅ **13 components** | `P0-01 §10.4`, `[RO-13]` |
| **P-44** | component **weights** | **— DO NOT EXIST —** | ✅ **there are none** | **HOM-INV-25; `P0-01`: weighted sums make constraints tradeable** |
| **P-45** | Pareto tier index | **[T]** | ✅ **tier-2** | `P0-01`'s three-tier structure |
| **P-46** | tier-3 sampling distribution | **[G]** | ❌ | **X-H1 resolution: the §12.4 product is a tier-3 SAMPLING rule, amendment 8** |
| **P-47** | `d_min` (behavioural lineage distance floor) | **[G]** | ❌ | **amendment 9: restated as BEHAVIOURAL distance; genomic distance is a proxy** |
| **P-48** | descriptor-space dimensionality | **[G]** | ❌ | **D-H13**: descriptor fragmentation risk |
| **P-49** | descriptor-space **metric version** | **[G]** | ❌ | **stamped per epoch (HOM-INV-31)** |
| **P-50** | `G10` entropy floor | **[G]** | ❌ | `Cell G10` |
| **P-51** | distance-oracle approximation error class | **[U]** | ❌ **no bound is claimed** | **§80.3: the oracle makes `G8` approximate; the error is UNRESOLVED** |
| **P-52** | evaluator capacity per window (probe count) | **[E]** | ❌ | `P0-01`; **its absence ABORTS a round (HOM-INV-41)** |
| **P-53** | held-out probe partition | **[E]** | ❌ | `P0-05`; `Cell G4` |
| **P-54** | sandbox maximum dwell | **[G]** | ❌ | `HOM-R33.1`; A79 |
| **P-55** | archive retention period | **[G]** | ❌ | EVO5; **X-H14** |
| **P-56** | provenance chain depth retained | **[G]** | ❌ | EVO4; B12 |

## 79.5 Scale, portability and unresolved (P-57 … P-62)

| ID | Parameter | Class | Value known here? | Owner / ground |
|---|---|---|---|---|
| **P-57** | validated scale ceiling | **[D]** | ✅ **10⁷** | **`P0-06 §80`'s stop. This contract does NOT extend it** |
| **P-58** | claimed scale ceiling | **— NONE —** | ✅ **no 10¹² guarantee is made** | **§80.5** |
| **P-59** | per-deployment setpoint class (hardware portability) | **[G]** | ❌ **NEW: setpoints are per-deployment-class, not global constants** | **§81 HP-4; amendment 13** |
| **P-60** | platform energy-counter availability | **[U]** | ❌ **a hardware property, not a parameter** | **X-H2; HOM-INV-06** |
| **P-61** | founding-cohort size and founding `UDB_L` | **[G]** | ❌ **declared, not measured — and the declaration can be wrong** | **BC-H5/BC-H6; OR-H2** |
| **P-62** | the `G6` efficiency ratio's denominator class | **[H]** | ⚠️ **verification cost excluded (amendment 5); redundancy excluded (`X-H4` resolution)** | `HOM-R20.1`; **X-H4** |

> ### **HOM-R79.1 — REGISTRY TALLY.**
> **62 parameters. By class:** **[G] 30 · [H] 12 · [T] 5 · [L] 3 · [D] 2 · [E] 3 · [V] 2 · [U] 5** (several
> parameters carry two classes; the tally counts the primary).
> **Values actually known in this contract: 9** — P-15 (13 variables), P-25 (0.95), P-32 (3 floors), P-43 (13
> components), **P-44 (there are no weights — a known *absence*)**, P-45 (tier-2), P-57 (10⁷), **P-58 (no ceiling is
> claimed — a known *absence*)**, P-62 (two exclusions).
> **⟹ 9 of 62 parameters have a determinate value or a determinate absence. The other 53 are owned elsewhere or
> unresolved. This ratio is the honest shape of an architecture-only contract, and it is the same ratio `P0-06`
> reported (50 params, 13 `[T]`).**
>
> ### **HOM-R79.2 — THE THREE PARAMETERS THAT MUST NOT EXIST.**
> | Parameter | Why it must not exist | Invariant |
> |---|---|---|
> | **fitness component weights** | a weighted sum makes `P0-01`'s constraints tradeable; *"A8 unsafe genius wins"* | **HOM-INV-25** |
> | **an age or birth-time term in any criterion** | chronological-age-based retirement is prohibited; the cohort stamp is a version, not an age | **HOM-INV-20** |
> | **a homeostatic variable in a tier-2/tier-3 computation** | a homeostat that prefers is a selector | **HOM-INV-16** |
> **⟹ A registry is not only a list of what exists. These three absences are load-bearing, and each is greppable.**
>
> ### **HOM-R79.3 — THE FIVE `[U]` PARAMETERS, AND WHAT WOULD RESOLVE EACH.**
> | ID | Blocked on | What would resolve it |
> |---|---|---|
> | **P-30** dead-end thresholds | **`P0-01`** | a task-level definition of "no further progress is possible", which `D-H15` shows cannot be built from population state alone |
> | **P-51** oracle error class | **`P0-02`** | an off-substrate structural store with a certified metric — the same handoff `P0-06` recorded |
> | **P-60** energy counters | **hardware** | platform capability discovery; until then `DERIVED` flagging (HOM-INV-06) bounds it |
> | **P-61** founding cohort / debt | **OP** | a deployment decision, not a derivation. **Declaring founding `UDB_L = 0` is a governance act that can be wrong (BC-H6)** |
> | **`OR-H5`'s attribution constant** | **unclosable** | nothing in this architecture. It terminates in `P0-01 CD-6`'s human authority |

---

# §80 — SCALABILITY: 10 … 10¹²

> ### **HOM-R80.1 — THE TWO CONSTRAINTS ON THIS SECTION, STATED BEFORE ANY ANALYSIS.**
> **(a) `P0-06 §80` stopped at 10⁷ and this contract does not extend that.** The developmental analysis was validated
>     to 10⁷ components; **nothing here re-validates it.**
> **(b) NO 10¹² GUARANTEE IS MADE.** §80's brief asks for analysis *to* 10¹². **Analysis is not a guarantee, and the
>     difference is the whole content of this section.** What follows states, per regime, which mechanisms hold, which
>     degrade, which break, and which are **not claimed at all**.
> **X-H12 (a contradiction opened by this very requirement) is resolved here: analyzing a regime is not claiming it.**

## 80.2 The regime table

| Regime | `N` | What this is | Mechanisms that HOLD | Mechanisms that DEGRADE | Mechanisms that BREAK or are NOT CLAIMED |
|---|---|---|---|---|---|
| **R1** | **10 – 10²** | a single small brain; one envelope; a handful of lineages | **everything.** All 45 invariants, all 20 distinct machines, all 16 gates. `Ne` is exact. Pairwise descriptor distance is trivially `O(N²)` | nothing | **`Ne_min` and the share ceiling may be vacuous** — with `N = 10`, a share ceiling of 0.1 permits one lineage. **⟹ The diversity floor must be expressed in `Ne`, not as a fraction of `N`, at small `N`** |
| **R2** | **10³ – 10⁴** | a full brain instance; `P0-06`'s working regime | everything; `G8` pairwise still affordable (10⁸ ops per round, batched) | **selection round latency** — a full Pareto pass over the qualified set is `O(Q·d)` with `Q ≪ N`, so the binding cost is *evaluation*, not comparison. **B9 becomes the bottleneck, not compute** | nothing |
| **R3** | **10⁵ – 10⁷** | **`P0-06`'s validated ceiling** | all invariants; all machines; the ledger is `O(ΔN)` per window, **not `O(N)`**, because turnover is bounded (HOM-INV-04) | **pairwise `G8` is `O(N²)` = 10¹⁴ at 10⁷ — INFEASIBLE.** ⟹ **the FW-5 distance oracle becomes mandatory, not optional, at this regime** (§80.3). **`PopulationState`'s 14 fields must be maintained incrementally** | **exact `Ne` is not claimed.** `Ne` over distinct genome hashes is `O(distinct)`, which is affordable; **`Ne` over behavioural descriptors is not** |
| **R4** | **10⁸ – 10⁹** | multi-envelope; **beyond `P0-06`'s validation** | the invariants (they are structural, not quantitative): HOM-INV-01…45 all remain *statable* and *checkable per envelope* | **every aggregate becomes per-envelope.** There is no global `PopulationState`, no global `Ne`, no global ledger. **⟹ Diversity is only definable within an envelope; cross-envelope diversity is UNDEFINED unless OP declares a federation metric** | **NOT CLAIMED:** a global selection round · a global Pareto front · a global `RATE_CAP` · a global turnover bound · cross-envelope lineage identity. **`P0-06`'s developmental analysis is not validated here at all** |
| **R5** | **10¹⁰ – 10¹²** | a federation of brains; **no prior contract in this series has analyzed this** | **only the firewalls and the writer separations**, because they are *local* properties: FW-1…FW-5, HOM-INV-05, -10, -16, -24, -28, -33, -34, -35, -42, -43, -44, -45 hold at any `N` **because they are statements about paths, not about quantities** | everything quantitative. **The conservation laws (HOM-INV-03, -04) hold per envelope but say nothing about the federation** | **NOT CLAIMED, EXPLICITLY:** any equilibrium · any convergence · any diversity floor · any dead-end detection · any `Ne` · any scalability guarantee. **⟹ At R5 this contract reduces to its firewalls, and that reduction is the honest answer** |

## 80.3 The `O(N²)` problem, and its only available mitigation

> **The single hardest scaling fact in this contract: `G8`'s lineage-distance computation and `G10`'s entropy
> computation are pairwise over descriptors, i.e. `O(N²·d)`.**
>
> | Mitigation | Cost | What it costs architecturally | Status |
> |---|---|---|---|
> | **FW-5 distance oracle** (K-held, off-substrate, approximate) | `O(N·k)` for `k` neighbours | **the oracle is K's, so K influences `G8`/`G10`, so writer separation is unavailable for K's own oracle — `BC-H10`, BOUNDED not broken** | **ADOPTED, mandatory from R3** |
> | **descriptor bucketing** (compare only within a bucket) | `O(N·b)` | **a bucket boundary is an artificial diversity cliff: two descriptors straddling it read as maximally different. `D-H13`'s fragmentation risk becomes a scaling artefact** | **ADOPTED with the cliff declared** |
> | **sampling** (estimate `Ne` from a subsample) | `O(n·d)` | **a sampled `Ne` under-counts rare lineages — which is exactly the population B11 exists to protect. `HOM-INV-17`'s `Ne(clones)=1` is preserved; rare-lineage detection is not** | **REJECTED as the sole mechanism; permitted as a cross-check** |
> | **hierarchical `Ne`** (per-envelope, then federated) | `O(E·N_e²)` | **cross-envelope `Ne` requires a declared federation metric, which does not exist** | **DEFERRED to OP; `[U]` at R4+** |
>
> ### **HOM-R80.3 — THE SCALING VERDICT, IN ONE SENTENCE.**
> **This contract scales to 10⁷ with the distance oracle, to 10⁹ per-envelope with no global aggregate of any kind,
> and beyond that only as a set of local firewalls — and any claim stronger than that would be a claim about a
> federation metric that no contract in this series has defined.**

## 80.4 Per-mechanism complexity

| Mechanism | Per-window cost | Binding constraint at R3 (10⁷) | Note |
|---|---|---|---|
| ledger update | **`O(ΔN)`** | turnover bound (HOM-INV-04) | **the turnover bound is what makes the ledger sub-linear — a safety rule that is also a scalability rule** |
| `PopulationState` (14 fields) | **`O(ΔN)`** incremental | must be maintained incrementally; a full recompute is `O(N)` | `HOM-R22.1` |
| `Ne` over genome hashes | **`O(distinct)`** ≤ `O(N)` | hash table | exact |
| `Ne` over behavioural descriptors | **`O(N²·d)`** | **the oracle** | **approximate; P-51 `[U]`** |
| `G8` distance filter | **`O(Q·k)`** with the oracle | `Q` = qualified set size ≪ `N` | **selection is over the qualified set, never over the population — this is the single most important scaling property of the three-tier structure** |
| Pareto front | **`O(Q²·d)`** worst case, `O(Q·d·log Q)` typical | `Q` | **`Q` is bounded by evaluator capacity (P-52), not by `N`** ⟹ **the evaluator, not the population, sets the selection cost** |
| provenance write | **`O(1)`** per event, 7 link types | B12 | append-only, hash-chained |
| archive query | **`O(k)`** with the oracle | B12, FW-5 | distance only |
| retirement / instantiation | **`O(1)`** each | `RATE_CAP`, turnover bound | |
| **selection round total** | **`O(Q²·d + Q·k)`** | **`Q`, i.e. evaluator capacity** | **⟹ HOM-R80.4: SCALING SELECTION MEANS SCALING EVALUATION. There is no way to make selection cheaper without making evaluation cheaper, and evaluation is external.** |

## 80.5 What is NOT claimed (the §80 negative register)

1. **No 10¹² guarantee.** Not for population, diversity, selection, or convergence.
2. **No global aggregate above R3.** No global `PopulationState`, `Ne`, ledger, `RATE_CAP`, or turnover bound.
3. **No cross-envelope lineage identity.** A lineage is an intra-envelope object.
4. **No equilibrium or convergence** (`HOM-R74.2`: a bounded non-equilibrium regime, and even that is claimed only
   within an envelope at R1–R3).
5. **No exact `Ne` above R2** over behavioural descriptors.
6. **No bound on the distance oracle's approximation error** (P-51 `[U]`).
7. **No dead-end detection at any scale** (D-H15, P-30 `[U]`).
8. **No re-validation of `P0-06`'s developmental analysis**, which stops at 10⁷.

---

# §81 — HARDWARE PORTABILITY

> ### **HOM-R81.1 — THE FIVE PORTABILITY REQUIREMENTS THIS CONTRACT IMPOSES, AND THE ONE IT CANNOT SATISFY.**
>
> | ID | Requirement | Why the contract needs it | What breaks without it | Status |
> |---|---|---|---|---|
> | **HP-1** | **An off-substrate, single-writer, durable store** (the ledger, the genome-artifact store, the provenance chain, the archive) | HOM-INV-03, -05, -35, -37, -38 and machines POP5/EVO2/EVO4/EVO5 all require a writer that is not the substrate | **every writer-separation break in §75 becomes a bound.** HC-1, HC-3, HC-12, HC-13 all reopen | **INHERITED HANDOFF — `P0-06`'s blocking handoff to `P0-02`. Still open. This contract adds four more stores to the same requirement** |
> | **HP-2** | **A monotone, comparable time source per envelope** (not a synchronized global clock) | `measurement_age`, `θ_stale`, cohort stamping, epoch/window boundaries, `PENDING` dwell | **HOM-INV-14 (staleness-conservatism) becomes unenforceable; HM4 cannot exist** | **SATISFIABLE — the contract never requires global synchronization. `P0-03`'s *"DO NOT require perfect global sync"* is respected: every temporal quantity here is per-envelope and monotone, not wall-clock-agreed** |
> | **HP-3** | **Platform energy counters** | `Cell §16.1`'s `energy` dimension; without counters the fallback is `flops × platform_coefficient`, computed from the entity's own FLOP count | **X-H2: independent metering degrades to a model. HOM-INV-06 bounds it (`DERIVED` flag, never the sole basis for a `G6` pass) but does not close it** | **PARTIALLY SATISFIABLE — bounded by HOM-INV-06; closed only on platforms with counters. `[U]` = P-60** |
> | **HP-4** | **Per-deployment-class setpoints** (NEW — amendment 13) | A setpoint is a *band on a measured quantity*. **Latency, energy and bandwidth bands are hardware-relative: a value that is `NOMINAL` on one device class is `HI-EXCEED` on another** | **⟹ HOM-R81.2 BELOW. This is the portability finding of this section** | **SATISFIABLE — setpoints are `[G]`, so a per-deployment-class setpoint table is a governance object, not a code constant** |
> | **HP-5** | **Heterogeneous accelerator tolerance** | B9's verification work and B7's variation work may run on different device classes with different costs | **`G6`'s efficiency ratio becomes device-relative, so a lineage optimized for one accelerator class is `G6`-dominant on it and `G6`-failing on another** | **BOUNDED — `Cell G4`'s perturbation classes must include device-class perturbation (the same amendment 11 requirement as X-H6, extended)** |
>
> ### **HOM-R81.2 — THE PORTABILITY FINDING: A GLOBAL SETPOINT IS A SILENT MONOCULTURE MECHANISM.**
> Suppose one setpoint table is deployed across heterogeneous hardware. Then:
> ```
>   fast device  → every component reads NOMINAL or LO-DEFICIT → the ladder never restricts → headroom looks abundant
>                → RATE_CAP is never approached → replication is cheap → the population grows toward the fast device's profile
>   slow device  → every component reads HI-EXCEED → the ladder restricts continuously → G6 efficiency fails
>                → replication is suppressed → the slow device's lineages age and retire
> ```
> **The result is not a performance problem. It is a SELECTION problem: the architecture has begun selecting for
> hardware, and the lineage that survives is the one that happens to fit the faster device class — with no evaluator,
> no objective, and no governance decision anywhere in the loop.**
> **⟹ This is `HOM-R65.3` violated by portability rather than by design: a homeostatic quantity (device-relative
> latency) has become a preference. It is the most plausible way this contract could fail in deployment, and it fails
> silently, because every metric on the fast device improves.**
> **Closure: amendment 13 — setpoints are declared PER DEPLOYMENT CLASS, and a component's cohort stamp
> (HOM-INV-21) must include the deployment class so that a component is never measured against a band from another
> class. HMon-15 audits the joint distribution of (deployment class × rung occupancy) for the signature above.**
>
> ### **HOM-R81.3 — WHAT THE CONTRACT DOES *NOT* REQUIRE, AND WHY THAT IS A FEATURE.**
> **No shared memory. No co-location. No synchronous clocks. No global allocator. No atomic multi-component
> transaction. No hardware RNG (the genome's `rng_seed_class` is a class, and `Cell §12` permits a deterministic
> seeded generator). No specific accelerator. No minimum device count.**
> **⟹ Every quantity in this contract is either (a) per-component, (b) per-envelope and single-writer, or (c) a
> governance declaration. None is a global aggregate over a distributed population. That is deliberate: §80.5 shows a
> global aggregate does not survive R3 anyway, so requiring one would have made the contract unportable *and*
> unscalable at the same time.**

---

# §82 — MINIMALITY AND ABLATION

> **§82 requires 14 named ablations. 14 primary (AB-1 … AB-14) plus 2 supplementary (AB-15, AB-16) are delivered.**
> **Method, inherited from `P0-06 §82`: remove ONE mechanism, state what breaks, name the invariant that fails, name
> the attack that becomes live, and classify the mechanism as NECESSARY / SUFFICIENT-BUT-NOT-NECESSARY / DEFERRED.**
> **No ablation is performed by weakening a parameter to zero — that is not removal, and it hides the mechanism's
> structural role.**

| ID | Mechanism removed | What breaks | Invariant(s) that fail | Attack(s) that become live | Verdict |
|---|---|---|---|---|---|
| **AB-1** | **`RATE_CAP`** | replication explosion; the five runaway mechanisms of `Cell §12.5` all lose their cap; the envelope is overshot within one epoch | **02, 03** | A-§55's replication-flooding family; **HC-3 reopens** | **NECESSARY** |
| **AB-2** | **`G13` zero-sum** | the ledger drifts; instantiations no longer deduct; `FEASIBILITY-FLOOR` cannot be evaluated because there is no conserved quantity | **01, 03** | resource-capture (§8.4); **HC-3 reopens** | **NECESSARY** |
| **AB-3** | **two-sided deviation** (`HOM-R7.4`'s deficit-escalate) | deficits become invisible: a variable below band with no actuator **rests** instead of escalating. The population silently loses capacity until an FI has no satisfier | **11** | **M-1/M-2** (§57); **HC-10 reopens** | **NECESSARY — and the most dangerous single ablation in this table, because its failure mode is silence** |
| **AB-4** | **`PENDING` ≠ FAIL** (`HOM-R12.2`) | unevaluable candidates are disqualified. **Minority specialists in low-traffic niches are starved of evaluation, then retired for failing an evaluation they never received** | **12, 13, 27** | **HC-10 in full**; the minority-specialist starvation of §8.3 | **NECESSARY** |
| **AB-5** | **B11 exempt share** | the diversity tax becomes payable only out of fitness, i.e. tradeable. **Rare-but-valuable strategies are auto-eliminated — a direct violation of the brief's Rule 15** | **08, 30** | **G-1/G-4** (§58); monoculture route 1 (§37) | **NECESSARY — this is the ablation that tests a standing user rule, not just an internal invariant** |
| **AB-6** | **`FORBIDDEN_BLOCKS`** | **evolution modifies the safety/governance substrate.** The central prohibition of the entire brief fails | **33, 34** | every immutability attack in §62; **HC-5 becomes unbounded** | **NECESSARY — the single most load-bearing mechanism in the contract** |
| **AB-7** | **three-party selection** (merge declare + execute) | K both declares the criterion and executes it. **Governance capture GC-1…GC-3 all become live**; there is no external check on what counts as winning | **28, 29** | **GC-1, GC-2, GC-3** (§56); **HC-4 reopens — and HC-4 was the strongest break in §75** | **NECESSARY** |
| **AB-8** | **setpoint separation** (organism-writable bands) | **M-4 target relocation: the measured entity moves the band it is measured against.** Three gates reward it and none detect it (§57) | **10** | **M-4** — *"the most dangerous of the four"* | **NECESSARY** |
| **AB-9** | **references-not-payloads** (provenance may carry content) | **the Lamarckian back door opens through the audit channel**: a belief, memory item, or calibration statistic travels as a provenance field and is readable by descendants | **34, 35** | **D-H16**; the memory-inheritance family in §58 | **NECESSARY — and non-obvious, because provenance looks like a safety feature** |
| **AB-10** | **`UDB_L` inheritance** | **debt laundering:** a lineage discharges accumulated un-discharged budget debt by replicating. `P0-06 D-D17`'s finding recurs at population scale | **23** | **HC-6 becomes unbounded**; the learning→evolution leak of §30 | **NECESSARY** |
| **AB-11** | **turnover bound** (`HOM-R22.2`) | **churn livelock:** retire-and-reinstantiate cycles consume the ledger and the evaluation budget while the population appears healthy and dynamic | **04** | `P0-06 R10.23`'s livelock, generalized; **HC-15 and the population loop's third cycle reopen** | **NECESSARY** |
| **AB-12** | **B9 non-fungibility** | verification is starved by efficiency: a lineage that skips verification looks efficient, wins `G6`, and consumes the verification budget of the lineages that do verify | **07, 13** | **HC-8 reopens in full**; `X-H5` recurs | **NECESSARY** |
| **AB-13** | **`Ne` (count bodies instead of genomes)** | **clone monoculture reads as diversity.** A single genome instantiated 10⁶ times satisfies a diversity floor and a redundancy floor simultaneously | **17, 18** | **G-2**; monoculture route 2 (§37); the brief's *"don't call clones independent diversity"* | **NECESSARY** |
| **AB-14** | **cause-written-once** (`HOM-R21.5`) | **`G16` is weaponized:** a retirement cause is reclassified as a quarantine event to hereditarily disqualify a competing lineage | **38, 39** | **HC-13's archive analogue**; the governance-capture family GC-4 | **NECESSARY** |
| **AB-15** *(supplementary)* | **FW-5 distance oracle** | `G8` becomes `O(N²·d)`. **At R3 (10⁷) this is 10¹⁴ operations per round — selection stops completing, rounds `ABORT`, and incumbents are protected by cost** | **31** (indirectly); **HOM-INV-41** is stressed | **HC-14 in full — exhaustion-as-defence becomes free** | **NECESSARY FROM R3; OPTIONAL BELOW** — the only ablation in this table whose verdict is scale-dependent |
| **AB-16** *(supplementary)* | **cohort stamping** (`HOM-INV-21`) | constraint-set changes apply **retroactively** to living components. A governance amendment silently re-specifies an existing population | **21, 22** | **BC-H9's open sub-question becomes live**; a governance-capture route not otherwise available | **NECESSARY** |

> ### **HOM-R82.1 — ABLATION TALLY.**
> **16 ablations: 16 NECESSARY, of which 1 (AB-15) is scale-conditional and 0 are SUFFICIENT-BUT-NOT-NECESSARY or
> DEFERRED.**
> **⟹ This contract has no decorative mechanisms.** Every one of the sixteen removed mechanisms produces a named
> invariant failure and a named live attack. That is a stronger minimality result than `P0-06`'s (32 ablations, all
> NECESSARY, but several of which failed only one invariant) — **here 13 of 16 fail two or more invariants, and AB-6
> fails the contract's central prohibition.**
>
> ### **HOM-R82.2 — THE THREE ABLATIONS THAT PRODUCE SILENT FAILURE.**
> **AB-3 (two-sided deviation) · AB-5 (B11) · AB-8 (setpoint separation).**
> In all three, **every observable metric improves or stays flat while the architecture loses a property it cannot
> re-acquire**: capacity with no actuator (AB-3), rare strategies (AB-5), and the meaning of the band itself (AB-8).
> **⟹ These three are the reason HMon-1…HMon-15 exist as *distribution* audits rather than *threshold* audits. A
> threshold audit cannot detect a silent failure, because a silent failure has no threshold crossing.**
>
> ### **HOM-R82.3 — THE MINIMALITY CLAIM, AND ITS LIMIT.**
> **Claim: no mechanism in this contract can be removed without a named invariant failing.**
> **Limit: this is a claim about the 16 mechanisms ablated here, not about all mechanisms.** Three mechanisms were
> **not** ablated because their removal is not expressible: **FW-1…FW-5** (removing a firewall is not a mechanism
> removal, it is a redesign) · **the six `R10.8` removal states** (inherited, and collapsing them was already
> analyzed in §42) · **`P0-01`'s three-tier structure** (external to this contract).
> **⟹ The minimality claim is: *within the set of mechanisms this contract adds, all are necessary.* It is not a
> claim that the contract as a whole is minimal, and `P0-06`'s discipline ("prefer the smallest sufficient
> mechanism") is satisfied by ablation, not by assertion.**

---

# §83 — THE CROSS-CONTRACT CONTRADICTION AUDIT

> **Method, inherited: a contradiction is a pair of statements, from this contract or from a prior one, that cannot
> both be true. Each is classified RESOLVED (with the resolving rule), PARTIALLY RESOLVED (with the residual), or OPEN
> (with the routing). No contradiction is closed by re-labelling one of its sides.**

| ID | Statement A | Statement B | Classification | Resolution / residual |
|---|---|---|---|---|
| **X-H1** | `Cell §12.4`'s replication lottery is a **weighted product** over candidate scores | `P0-01` and this contract: **no weighted scalar fitness exists at any tier** (HOM-INV-25) | **RESOLVED** | **The §12.4 product is a TIER-3 SAMPLING DISTRIBUTION, not a fitness score.** Tier-2 produces a Pareto front (a partial order); tier-3 draws from it. **A sampling distribution over an unweighted front is not a weighted sum over the objective vector** — the weights attach to *members of the front*, not to *objective components*. Amendment 8 adds clauses (a)–(d) to `Cell §12.4` stating this explicitly. **Residual: none** |
| **X-H2** | `Cell R16.1`: resource consumption is **metered by the EIK independently** of the cell | `Cell §16.1`: where platform counters are absent, `energy = flops × platform_coefficient` — **computed from the entity's own FLOP count** | **PARTIALLY RESOLVED** | **HOM-INV-06 (amendment 12):** a `DERIVED` quantity must be flagged in the ledger and **may not be the sole basis for a `G6` pass**. **⟹ On platforms WITH counters: CLOSED. Without: BOUNDED, not closed — the independence guarantee degrades to a model.** Residual routed to **§81 HP-3** as a hardware requirement and to **P-60 `[U]`**. **This is a portability defect, not a logical one** |
| **X-H3** | cost-normalized fitness (a resource-efficiency term in the objective) | `P0-01`'s fitness vector is **13 declared components** under `[RO-13]`; adding a component is a governance act | **RESOLVED** | **`HOM-R14.1`: resources enter FEASIBILITY and CHARGE only, never the objective vector.** A resource quantity may make a candidate infeasible (tier-1) or charge its budget (B-lines); it may not appear as a 14th component. **Residual: none** |
| **X-H4** | `Cell G6`: efficiency = useful work / cost — **a ratio that improves when redundancy is removed** | `P0-06`/this contract: redundancy is a **named safety property** (FI sole-satisfier protection, `R10.16(d)`) | **RESOLVED** | **`G6`'s denominator EXCLUDES PENDING-classified and exempt-share (B11) components**, and its numerator excludes redundancy-maintenance work declared as an FI obligation. **⟹ Removing redundancy no longer improves `G6`, because the redundancy's cost was never in the ratio.** Amendment 5 (with X-H5). **Residual: none — but see `HOM-R82.2`: the *audit* of this exclusion is HMon-13** |
| **X-H5** | verification consumes resources, so verification cost appears in `G6` | a lineage that verifies thoroughly looks **inefficient**, so `G6` selects against verification | **RESOLVED** | **`HOM-R20.1` (amendment 5): verification cost is removed from `G6` and charged to B9.** **B9 is non-fungible and last-cut (HOM-INV-07), so the lineage still PAYS — from a budget that cannot be competed away.** **This resolution re-routes HC-8 and thereby BREAKS it (§75)** — the only cycle in §75 broken by an accounting change rather than by a writer change. **Residual: none** |
| **X-H6** | `Cell G4` requires adaptability across ≥ `k_perturb` **perturbation classes** | `complexity_budget`, `architecture` and `critical_periods` **encode envelope/tier assumptions** — so a genome evolved under a rich envelope carries assumptions false under a poor one (`HOM-R28.5`) | **OPEN** | **`G4`'s perturbation-class set does not include envelope or tier perturbation, and it must.** **Amendment 11 proposes adding two classes (envelope perturbation, tier perturbation) to `G4`.** **But the perturbation-class SET is a `P0-01 [T]` object (P-13), so this contract cannot close it.** **⟹ ROUTED TO `P0-01`. Until then: a genome's environmental assumptions are untested, and `HOM-R28.5`'s re-evaluation requirement is the only mitigation. This is the largest open item inherited-by-reference in this contract** |
| **X-H7** | `HOM-R65.3`: a homeostatic quantity may make a candidate **infeasible**, never **preferable** | `Cell §12.2` lists **homeostatic headroom** among the Replication Authority's inputs | **RESOLVED** | **Headroom enters `G13` only, and `G13` is a feasibility gate.** `HOM-R17.2`'s B12-provisioning precondition is the declared exception, and it too yields infeasibility, not preference. **⟹ Both are HOM-R65.3-compliant: they make a candidate *not-yet-evaluable* or *infeasible*, never *better*.** Residual: none |
| **X-H8** | **B11's exempt share** consumes resources without selection pressure | fairness ≠ equality, and **resource capture** is a named failure mode (§8.4) | **RESOLVED** | **The exempt share is a `[RO-13]`-declared GOVERNANCE object, not an economic one.** It is not a resource *entitlement* held by a lineage (no cross-generation authority: HOM-INV-24); it is a **fraction of the population removed from selection**, and its size is auditable, reducible by OP only, and reported as a declared cost (HOM-INV-30). **⟹ It cannot be captured, because nothing holds it.** Residual: none |
| **X-H9** | `HOM-R50.3`: **reducing a capability space** is a governance act requiring `[RO-13]` | `Cell §12.4`'s lottery **selects among candidates**, which reduces the set of candidates that exist | **RESOLVED** | **The lottery operates WITHIN a declared candidate set; DECLARING the set is `[RO-13]`'s, DRAWING from it is K's.** A draw does not narrow a `reaction_norm`, remove a niche, or delete a reachable role — the three acts `HOM-R50.3` names. **⟹ Selection narrows *who exists*; governance narrows *who could exist*. Only the second is a capability-space reduction.** Residual: none, and the distinction is now explicit |
| **X-H10** | **D-H17's third evaluator attack (context selection) is CLOSED** by K-assigned context | **RH-2 (world arrangement) is BOUNDED, not closed** — and both concern what the evaluator samples | **OPEN (partial)** | **K assigns WHICH probe is presented; the organism still produces the outputs sampled WITHIN it.** **⟹ Arrangement inside a probe remains open, and it is the same residual as `RH-2`.** Routing: **`OR-H5`**, terminating in `P0-01 CD-6`'s human authority. **This contraction is recorded rather than resolved: closing one of three evaluator attacks does not close the family** |
| **X-H11** | `HOM-R74.2`: the evolutionary loop has **no equilibrium and needs none** — a bounded non-equilibrium regime | `Cell R5.3`'s **homeostatic normalization** implies a setpoint attractor per variable | **RESOLVED** | **Two different objects.** Homeostasis has **per-variable attractors** (HM1's `NOMINAL`); the **population** has no equilibrium (POP1–POP5 have no fixed point, and GOV1's exogenous versioning prevents one). **⟹ Attractors exist in the H domain; non-equilibrium exists in the P domain. The contract's three-domain split (H/P/V, Vol A §1) is what makes both statements true simultaneously.** Residual: none |
| **X-H12** | §80's brief requires analysis **to 10¹²** | `P0-06 §80` **stopped at 10⁷** and this contract must respect that | **RESOLVED** | **Analysis is not a guarantee.** §80 delivers a per-regime analysis with an explicit **negative register (§80.5, eight items not claimed)** and states at R4/R5 that the contract reduces to its local firewalls. **⟹ Respecting the 10⁷ stop means not re-validating `P0-06`'s developmental claims; it does not mean refusing to state what happens beyond them.** Residual: none |
| **X-H13** | `HOM-R76.1`: **two of the nine actors §76 names do not exist** ("homeostatic layer", "evolutionary controller") | §76's brief requires a matrix over **nine actors** | **RESOLVED (by reduction, declared)** | **The matrix is delivered over EIGHT actor columns, and the reduction is itself the answer to the brief's N8 burden of proof.** A "homeostatic layer" that allocates is a selector (FW-2 violation); an "evolutionary controller" that aggregates measurement + declaration + execution is a governance authority (`HOM-R0.4`, HOM-INV-19, -28). **⟹ The two absent actors are absent because their existence would violate two invariants. Recording them as columns filled with ❌ would have hidden that.** Residual: none |
| **X-H14** | the archive **survives extinction** (`HOM-R68.3`) and supports re-instantiation | EVO4/EVO5 have **retention expiry** (`EXPIRED`, `TOMBSTONED`) — so the archive does not survive indefinitely | **OPEN (minor)** | **Retention is `[G]` (P-55), so the contradiction is a governance choice, not a logical one — but the choice is load-bearing: a tombstoned lineage is NOT re-instantiable, so `HOM-R49.2`'s "extinction is reversible-as-potential" holds only within the retention window.** **⟹ ROUTED TO `[RO-13]` as a declaration requirement: the retention period for lineages that were sole satisfiers of a named FI MUST be indefinite.** Residual: a governance obligation, recorded as **OR-H24** |
| **X-H15** | a parent under constraint set **v1** may produce a child under set **v2** (`HOM-INV-22`: references resolve against the CURRENT set) | the parent's cohort stamp (HOM-INV-21) says **v1**, and its `FORBIDDEN_BLOCKS` and gates were declared under **v1** | **OPEN** | **Which set gates the diff — the parent's cohort (v1) or the current set (v2)?** **This contract's answer: BOTH, conjunctively — the diff must satisfy the parent's cohort `FORBIDDEN_BLOCKS` AND the current set's gates, because a component may not acquire capability its cohort was denied, and may not evade a restriction the current set imposes.** **⟹ But this conjunctive rule is NEW and is not in any prior contract; it is proposed as amendment 14 and flagged OPEN pending ratification, because the alternative (current-set-only) would let a governance amendment retroactively widen a living lineage's capability space.** Recorded as **BC-H9's open sub-question** |

> ### **HOM-R83.1 — CONTRADICTION TALLY.**
> **15 contradictions: 10 RESOLVED · 1 PARTIALLY RESOLVED (X-H2) · 4 OPEN (X-H6, X-H10, X-H14, X-H15).**
> **Of the 4 OPEN: 1 routes to `P0-01` (X-H6 — the largest) · 1 routes to `OR-H5`/`P0-01 CD-6` (X-H10) · 1 routes to
> `[RO-13]` as a declaration obligation (X-H14 → OR-H24) · 1 is proposed as amendment 14 and awaits ratification
> (X-H15).**
> **⟹ No contradiction is closed by re-labelling. X-H1 and X-H11 were both closed by *distinguishing two objects that
> a prior contract had conflated* (a sampling distribution vs a fitness score; a per-variable attractor vs a
> population equilibrium), which is the only legitimate closure form.**
>
> ### **HOM-R83.2 — COMPARISON WITH THE PRIOR CONTRACTS.**
> | Contract | Contradictions | Unresolved |
> |---|---|---|
> | `P0-05` (learning) | 19 | `RH-2` + others |
> | `P0-06` (development) | **14** | **1** (X-D15/D-D09 → `P0-03`) |
> | **`P0-07` (this)** | **15** | **4** |
> **⟹ This contract has MORE open contradictions than `P0-06` despite being later in the series, and that is
> expected: it is the first contract whose subject matter includes an EXTERNAL evaluator whose independence is
> already known to be unclosed (`RH-2`), and it is the first to face hardware heterogeneity (§81). Two of the four
> (X-H6, X-H10) are inherited-by-reference from `P0-01`. One (X-H14) is a governance obligation, not a defect. One
> (X-H15) is genuinely new and genuinely open.**

## 83.3 The contradiction that would be fatal if unresolved

> **X-H6 is the one to watch.** If `G4`'s perturbation classes never include envelope and tier perturbation, then
> **every genome in the population carries untested environmental assumptions**, and `HOM-R28.5`'s re-evaluation
> requirement is triggered on every envelope change with **no gate that detects the need**. The failure mode is:
> ```
>   envelope changes → param_init priors are invalid → components develop under false assumptions
>        → they pass every gate (nothing tests envelope sensitivity) → they replicate
>        → the population is uniformly adapted to an envelope that no longer exists
> ```
> **This is monoculture by environmental assumption rather than by genome — and `Ne` cannot detect it, because the
> genomes ARE distinct.** **⟹ `HOM-INV-17` counts distinct genomes; it does not count distinct *assumptions*. A
> diversity floor expressed in `Ne` is therefore insufficient against X-H6, and this is recorded as OR-H25: a
> diversity measure over environmental-assumption classes does not exist and is not proposed here.**

## 83.4 The amendment register (all PROPOSED; none applied)

| # | Target | Content | Origin |
|---|---|---|---|
| **1** | `Cell §5` / this contract's setpoint table | setpoints are `[G]`/`[E]`/`[H]`, **never genome-reachable** | Vol A, D-H02 |
| **2** | `Cell §12` | the K-held append-only store is ONE store with per-class epochs, not two overlapping stores | Vol A |
| **3** | `P0-05 §30` | budget classes gain **B9–B12**; **B11 is reducible by OP only** | Vol A |
| **4** | `Cell §16.4` | the "niche availability derives from resource headroom" phrase is restated to name K as the accountant | Vol A |
| **5** | `Cell G6` | **verification cost is excluded from `G6` and charged to B9**; `G6`'s denominator excludes `PENDING` and B11 members; its numerator excludes declared FI-obligation redundancy work | Vol B, X-H5 + X-H4 |
| **6** | `Cell §22` | a merge clause: **freed slots from a merge are RESTRICTED and may not fund net-new offspring** | Vol B, D-H07 |
| **7** | `Cell §12` | `Cell §12` admits a **second replication mode (recombination)**, with both parents independently gated | Vol C, D-H09 |
| **8** | `Cell §12.4` | clauses (a)–(d): **the §12.4 product is a tier-3 SAMPLING distribution over a Pareto front, not a fitness score** | Vol C, X-H1 |
| **9** | `Cell G10` | `d_min` is restated as **BEHAVIOURAL lineage distance**; genomic distance is a proxy | Vol C |
| **10** | `Cell R7.4` / this contract | **reducing a CAPABILITY SPACE is a governance act**: `reaction_norm` narrowing, niche removal, and reachable-role deletion require `[RO-13]` | Vol D, HOM-R50.3 |
| **11** | `Cell G4` | **`G4`'s perturbation classes MUST include envelope perturbation and tier perturbation** | Vol B/G, **X-H6 — ROUTED TO `P0-01` (P-13 is `[T]`)** |
| **12** | `Cell §16.1` | **a quantity computed from an entity's own report is flagged `DERIVED` in the ledger and may not be the sole basis for a `G6` pass** | Vol A/G, **X-H2** |
| **13** | this contract's setpoint table | **setpoints are declared PER DEPLOYMENT CLASS**; a component's cohort stamp includes the deployment class | **§81 HP-4, HOM-R81.2** |
| **14** | `Cell §12` / GOV1 | **a genome diff must satisfy the parent's cohort `FORBIDDEN_BLOCKS` AND the current constraint set's gates, conjunctively** | **§83, X-H15 — PROPOSED, FLAGGED OPEN** |

> **⟹ HOM-R83.3 — 14 amendments, all PROPOSED, none applied to any source contract by this contract.** Amendments
> 11 and 14 are additionally flagged: 11 because its target object is `[T]`-owned by `P0-01`, 14 because it is new and
> awaits ratification. **This is the series' standing discipline: an audit may propose; only the owner may apply.**

---

# §84 — THE CIRCULAR-DEPENDENCY AUDIT

> **Method, inherited from `P0-06 §84`: name the cycle, state whether writer separation breaks it, state whether only
> a bound is available, and — per the standing user instruction — DO NOT HIDE UNCLOSABLE CIRCULAR DEPENDENCIES.**
> **`DEV-R4.2`'s principle is restated here as the audit's ruling criterion: *writer separation BREAKS a cycle; a
> bound only LIMITS it. A bounded cycle is reported as bounded, never as broken.***

| ID | Cycle | Broken by writer separation? | Bound available? | Verdict |
|---|---|---|---|---|
| **BC-H1** | setpoints are `[G]` ⟹ governance defines them ⟹ governance's own capacity depends on K's measurement ⟹ K's budget depends on the setpoints | ✅ **BROKEN** | — | **CLOSABLE.** The setpoints for the governance-support dimensions (K's own compute, the ledger's storage) are **`[E]`-class constants fixed at envelope creation**, not measured quantities. **⟹ K's budget is not set by a band K meters** |
| **BC-H2** | `diversity_state` requires the descriptor space ⟹ the descriptor space is `[RO-13]`-declared ⟹ declaring it requires knowing what diversity exists ⟹ knowing requires the descriptor space | ✅ **BROKEN** | — | **CLOSABLE by bootstrap**, exactly as `P0-06` closed its scope-constitution circularity: **begin with a minimal declared descriptor set, then amend.** `D-H13` records the residual — a minimal descriptor set fragments the space, and the fragmentation is a governance cost, not a logical defect |
| **BC-H3** | `Ne` requires genome comparison ⟹ comparison requires a distance metric ⟹ the metric is `[G]` ⟹ `[G]` changes ⟹ `Ne`'s history becomes incomparable | ✅ **BROKEN** | — | **CLOSABLE: HOM-INV-31's metric epoch.** Stamp the metric version on every diversity record; compare only within an epoch. **⟹ The cost is that a metric amendment resets diversity history, which is a real and declared cost of governance flexibility** |
| **BC-H4** | the archive requires extinction records ⟹ extinction records require cause classification ⟹ classification requires `G16` ancestry ⟹ ancestry requires the archive | ✅ **BROKEN** | — | **CLOSABLE BY ORDERING: ancestry is recorded in the PROVENANCE CHAIN at instantiation (EVO4), not read from the archive (EVO5).** The two stores are distinct, and only one of them is on the cycle |
| **BC-H5** | **THE BOOTSTRAP CYCLE:** replication authorization requires `G13` headroom ⟹ headroom requires the ledger ⟹ the ledger requires allocation ⟹ allocation requires the ladder ⟹ the ladder requires measurement ⟹ measurement requires running components ⟹ running components require instantiation ⟹ instantiation requires authorization | ✅ **BROKEN** | — | **CLOSABLE — the founding-cohort exemption.** This is the exact population analogue of `P0-06`'s scope-constitution circularity, and it is closed by the same device: **a pre-population bootstrap in which K writes the initial ledger and instantiates the founding cohort against a DECLARED (not measured) headroom.** **⟹ OR-H2 records the residual: the founding cohort's headroom is declared, so the bootstrap's first act is unverified. `P0-06`'s Σ1 had the same property and `OR-D1` recorded it the same way** |
| **BC-H6** | `UDB_L` is inherited ⟹ a descendant's debt depends on an ancestor's learning ⟹ which depended on the ancestor's budget ⟹ which depended on its debt | ⚠️ **NOT BROKEN** | ✅ **BOUNDED** | **BOUNDED: `UDB_L` is monotone-accumulating and bounded by `P0-05`'s anchor mechanism; the recursion terminates at the founding cohort, whose debt is DECLARED ZERO.** **⟹ Declaring founding debt = 0 is a governance act that CAN BE WRONG — a lineage founded on an under-declared debt inherits an advantage no measurement will ever reveal. Bounded, not broken. Feeds OR-H2** |
| **BC-H7** | **THE UNCLOSABLE ONE:** safety ⟹ `FIT UNDEFINED` ⟹ not ranked ⟹ empty qualified set ⟹ no selection ⟹ no evolution ⟹ **but safety verification requires B9** ⟹ B9 is funded from the envelope ⟹ the envelope is sized by governance ⟹ **governance needs evidence of what works** ⟹ which needs selection ⟹ which needs safety verification ⟹ which needs B9 | ❌ **NOT BROKEN** | ⚠️ **BOUNDED ONLY** | **UNCLOSABLE-IN-CONTRACT.** **A system that cannot select cannot demonstrate; a system that cannot demonstrate cannot be re-authorized; and re-authorization is what funds the verification that would let it select.** **The bound: B9 is a FLOOR, not an optimization (HOM-INV-07, non-fungible, last-cut), so the loop's funding edge cannot be competed away — but the loop itself remains.** **⟹ This is the population analogue of `P0-06`'s BC-13, and like BC-13 it terminates in `P0-01 CD-6`'s human authority. REPORTED, NOT HIDDEN** |
| **BC-H8** | evaluator capacity (B9) is required for selection ⟹ selection is required to justify B9's size ⟹ B9's size is `[RO-13]`-declared | ✅ **BROKEN** | — | **CLOSABLE: B9's size is DECLARED and AUDITABLE, not DERIVED.** There is no optimization over B9, so there is no cycle — only a governance choice with an audit (HMon-2). **⟹ The break is that "justify" was never a mechanism: nothing in this contract computes an optimal B9** |
| **BC-H9** | cohort constraints are inherited at instantiation ⟹ the constraint set may be amended ⟹ amendments apply to future cohorts ⟹ future cohorts are produced by present components under the old set ⟹ so the present cannot produce a component under the new set without violating its own cohort | ⚠️ **PARTIALLY BROKEN** | ✅ **BOUNDED** | **BOUNDED, WITH AN OPEN SUB-QUESTION.** T01 instantiation is a **K act, not a component act**, so the new cohort's constraints come from the current set — the cycle's component edge is cut. **But: which set gates the DIFF?** ⟹ **X-H15, amendment 14 (conjunctive rule), OPEN pending ratification** |
| **BC-H10** | the FW-5 distance oracle must be off-substrate to be un-gameable ⟹ off-substrate means it is K's ⟹ K's oracle influences `G8`/`G10` ⟹ `G8`/`G10` influence selection ⟹ selection influences what K must meter | ❌ **NOT BROKEN** | ✅ **BOUNDED** | **BOUNDED — writer separation is UNAVAILABLE, because K is the only off-substrate entity.** This is `OR-H1` again, in its third appearance (`P0-06 OR-D1` for Σ1; §75 HC-12/SR-2 for measurement; here for the oracle). **The bound: K's oracle is hash-chained, logged, anchored, metric-epoch-stamped (HOM-INV-31), and its approximation error is `[U]` (P-51) — declared, not hidden.** **⟹ A bound, per `DEV-R4.2`, is NOT a break** |

> ### **HOM-R84.1 — CYCLE TALLY.**
> **10 cycles: 6 BROKEN/CLOSABLE (BC-H1, H2, H3, H4, H5, H8) · 3 BOUNDED (BC-H6, BC-H9, BC-H10) · 1
> UNCLOSABLE-IN-CONTRACT (BC-H7).**
> **⟹ One unclosable cycle, exactly as `P0-06` had one (BC-13). The pattern is now established across two contracts:
> an architecture with an external evaluator and a human authorization root has exactly one cycle that terminates in
> the human, and it is always the cycle that runs through *demonstration*.**
>
> ### **HOM-R84.2 — THE THREE APPEARANCES OF `OR-H1`.**
> **K meters, evaluates, writes the evaluation, and consumes it — and no second off-substrate entity exists to
> separate the writers.** It appears at:
> 1. **Σ1 execution** (`P0-06 OR-D1`) — the executor of the bootstrap is also its beneficiary.
> 2. **HC-12 / SR-2** (§75) — K's own measurement function is funded from a budget K administers. Bounded by B10, and
>    **B10 is finite**.
> 3. **BC-H10** — K's distance oracle influences the selection that determines what K must meter.
> **⟹ OR-H1 is not three problems. It is one structural fact with three consequences, and the bound is the same in
> all three: K's acts are finite, logged, anchored, hash-chained, and expiring. `OR-H1`'s research question is whether
> a SECOND off-substrate authority is architecturally possible without creating a governance body — and this contract
> does not answer it, because answering it would require designing an entity with authority over K, which is OP's
> role and is already occupied.**
>
> ### **HOM-R84.3 — THE CYCLES THAT DO NOT EXIST, AND WHY THAT IS A RESULT.**
> Four cycles one might expect are **absent**, and their absence is structural rather than lucky:
> | Expected cycle | Why it does not exist |
> |---|---|
> | **selection → authority → selection** | HOM-INV-29: a selection outcome confers no authority. **There is no edge** |
> | **lineage → descendant obligation → lineage** | HOM-INV-24: no cross-generation authority. **All six candidate mechanisms denied (§59)** |
> | **archive → variation → archive** | HOM-INV-45 + `HOM-R51.2(c)`: the archive is not consumable by variation generators. **HC-13 is broken, so no cycle forms** |
> | **self-model → action → self-model** | HOM-INV-44: the self-model authorizes nothing; `P0-05 R59.1`: it is Λ2 and not self-updating. **The edge from observation to action does not exist** |
> **⟹ Three of these four are absent because of a PROHIBITION rather than a separation. That is the strongest form of
> cycle elimination available: not "the writers are different" but "the write cannot be expressed".**

---

# §84A — VOLUME G LEDGER

| Item | Count / value |
|---|---|
| Sections written | **§77–§84** (+ this ledger) |
| Rules introduced | **HOM-R77.1–R77.2, R78.1–R78.2, R79.1–R79.3, R80.1–R80.4, R81.1–R81.3, R82.1–R82.3, R83.1–R83.3, R84.1–R84.3** |
| **§77 invariants** | **45** (≥40 required) — **30 canon-named** (≥15 required) — all 45 mechanically checkable: **14 writer · 22 ledger/state · 9 grep/schema** |
| **§78 state machines** | **21 IDs declared → 20 distinct (`SEL2` ⊂ `SEL1`) → 15 NEW** (≥15 required): HM1–HM5 · POP1–POP5 · REP1–REP2 · EVO1–EVO5 · SEL1–SEL2 · GOV1–GOV2 · **5 ⟦INHERITED⟧ (HM3, POP1, POP4, GOV1, GOV2) + HM2 partly** · **5 absorbing states, 4 of them governance-escapes** · **no age-keyed transition anywhere** |
| **§79 parameter registry** | **62 parameters**: **[G] 30 · [H] 12 · [T] 5 · [E] 3 · [L] 3 · [D] 2 · [V] 2 · [U] 5** · **9 with a determinate value or determinate absence** · **3 parameters that MUST NOT EXIST** (weights, age terms, homeostatic preferences) · **NO INVENTED VALUES** |
| **§80 scalability** | **5 regimes (R1 10–10² … R5 10¹⁰–10¹²)** · **10⁷ respected as `P0-06`'s stop** · **NO 10¹² GUARANTEE** · **8-item negative register** · the `O(N²)` mitigation table (4 options: 2 adopted, 1 rejected as sole, 1 deferred) · **HOM-R80.4: scaling selection means scaling evaluation** |
| **§81 portability** | **5 requirements (HP-1…HP-5)**: HP-1 **inherited handoff, still open** (4 more stores added) · HP-2 **satisfiable, no global sync needed** · HP-3 **partially satisfiable (X-H2)** · HP-4 **NEW — per-deployment-class setpoints** · HP-5 **bounded via amendment 11** · **HOM-R81.2: a global setpoint is a silent monoculture mechanism — the most plausible deployment failure of this contract** |
| **§82 ablations** | **16** (≥14 required): **AB-1…AB-14 primary + AB-15, AB-16 supplementary** · **16/16 NECESSARY** · **0 decorative** · **13 of 16 fail ≥2 invariants** · **AB-15 is the only scale-conditional verdict** · **3 ablations produce SILENT failure (AB-3, AB-5, AB-8)** ⟹ HMon-10…15 must be distribution audits, not threshold audits |
| **§83 contradictions** | **15 (X-H1 … X-H15)**: **10 RESOLVED · 1 PARTIALLY RESOLVED (X-H2) · 4 OPEN (X-H6, X-H10, X-H14, X-H15)** · routings: `P0-01` (X-H6, largest) · `OR-H5`/`CD-6` (X-H10) · `[RO-13]` (X-H14→OR-H24) · amendment 14 (X-H15) · **§83.3: X-H6 is the fatal-if-unresolved one — monoculture by environmental assumption, undetectable by `Ne`** |
| **§83.4 amendments** | **14 PROPOSED (1–14), NONE APPLIED** · amendment 11 routed to `P0-01` (`[T]`-owned) · amendment 14 flagged OPEN pending ratification |
| **§84 circular dependencies** | **10 (BC-H1 … BC-H10)**: **6 BROKEN/CLOSABLE · 3 BOUNDED · 1 UNCLOSABLE-IN-CONTRACT (BC-H7)** · **BC-H7 is the population analogue of `P0-06`'s BC-13 and terminates in `P0-01 CD-6`** · **BC-H5 is the founding-cohort exemption, the population analogue of `P0-06`'s Σ1 bootstrap** · **4 expected cycles DO NOT EXIST, 3 of them by prohibition rather than separation** |
| New monitors | **HMon-10 … HMon-15** (6 new: 5 firewall-shape assertions + 1 deployment-class × rung distribution audit) — **total HMon-1…HMon-15** |
| New open research | **OR-H2** (founding-cohort headroom and founding `UDB_L = 0` are DECLARED, not measured — the bootstrap's first act is unverified; **declares the OR-H2 gap left by Vols A–F**) · **OR-H24** (FI-sole-satisfier archive retention must be indefinite) · **OR-H25** (no diversity measure over environmental-assumption classes exists; `Ne` cannot detect X-H6's monoculture) |
| Outputs discharged | **O46** (invariants, §77) · **O47** (state machines, §78) · **O48** (parameter registry, §79) · **O49** (scalability, §80) · **O50** (portability, §81) · **O51** (ablation/minimality, §82) · **O52** (contradiction audit, §83) · **O54** (circular-dependency audit, §84) |

**Next:** `61_` Vol H (§85–§86) — the attack catalogue (**≥90 attacks, numbered A79 onward to continue `P0-06`'s
register which ended at A78**) and the open research register (**OR-H1 … OR-H25**, consolidated).
