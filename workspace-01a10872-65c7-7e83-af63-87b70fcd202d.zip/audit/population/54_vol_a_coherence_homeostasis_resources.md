# P0-07 — VOLUME A (§0–§16)
## Coherence Determination, Absolute Separations, Homeostasis, and Resource Economics

**Role set (14, simultaneous):** Principal Systems Architect · Computational Neuroscientist · Artificial Life
Researcher · Evolutionary Systems Researcher · Distributed Systems Architect · Control-Theory Researcher ·
Resource-Allocation Researcher · Complex Systems Researcher · Population-Dynamics Researcher · AI Safety Architect ·
Formal Methods Researcher · Adversarial Red-Team Architect · Hardware-Architecture Researcher ·
Information-Theoretic Researcher.

**Section numbering mirrors the brief exactly** (§0 = PRIMARY OBJECTIVE … §86 = OPEN RESEARCH REGISTER in the
volumes; §87–§95 in `README.md`). **Volumes:** A `54_` §0–§16 · B `55_` §17–§31 · C `56_` §32–§41 · D `57_`
§42–§52 · E `58_` §53–§64 · F `59_` §65–§76 · G `60_` §77–§84 · H `61_` §85–§86 · canonical `62_` (O59) ·
`README.md` (O1, §87–§95).

> ## ABSOLUTE RULE
> **ARCHITECTURE ONLY.** No production, deployment, training or simulation code; no executable system; no
> infrastructure specification. Formal models, equations, state machines, schemas, dependency graphs, architectural
> diagrams and implementation-neutral pseudocode are permitted and used throughout.

**ID conventions (locked before writing).** Analysis rules **`HOM-Rn.m`** (scoped to section *n*) · findings
**`D-Hnn`** · contradictions **`X-Hnn`** · circular dependencies **`HC-nn`** · open research **`OR-Hnn`** · attacks
**`HOM-Ann`** · invariants **`HOM-INV-nn`** · ablations **`HAB-nn`** · state machines **`HM1`–`HM15`** · interfaces
**`HIF-nn`** · monitors **`HMon-n`** · safety properties **`HS-n`** · resource-dominance doors **`RD-n`** · new budget
classes **`B9`–`B12`** · authoral domains **H / P / V**. **Inherited IDs are always cited with their source
contract** (`Cell G13`, `P0-01 INV-07`, `P0-05 R0.1`, `DEV-R7.3`, …) because ID collisions exist across the corpus.

**The three authoral domains named throughout this contract:**

| Domain | Objects | Character |
|---|---|---|
| **H — HOMEOSTASIS / RESOURCE** | measurement, setpoints, deviation, allocation, reservation, budgets, throttling | **CONTROL** — negative feedback toward a declared setpoint |
| **P — POPULATION** | replication, retirement, dormancy, niche occupancy, lineage, age structure, recovery | **ACCOUNTING** — conserved quantities under zero-sum |
| **V — VARIATION / EVOLUTION** | mutation, recombination, sandbox, selection, inheritance, archive, provenance | **SEARCH** — no setpoint, no target, no optimizer |

---

# §0 — PRIMARY OBJECTIVE: THE COHERENCE DETERMINATION

> ### **HOM-R0.1 — VERDICT: THE EIGHT MECHANISMS FORM ONE COHERENT CONTRACT, AND SPLITTING THEM WOULD BE
> UNSOUND.**
> Homeostasis, resource economics, population dynamics, replication, retirement, diversity management, evolutionary
> selection and cross-generation inheritance **are one contract**. Not because they are similar — they are not — but
> because **every load-bearing invariant of any one of them is stated over state owned by at least one of the
> others**, and a contract boundary that cuts a feedback loop makes that loop ungovernable.

## 0.1 The proof, in three moves

**(1) THE SEVEN CYCLES OF §84 ALL SPAN AT LEAST TWO OF THE THREE DOMAINS.** `resources → performance → resources`
spans H and P. `resources → replication → population → resource demand → resources` spans H, P and H again.
`selection → population → evaluation → selection` spans V and P. `development → phenotype → fitness → evolution →
genome → development` spans V, P and P0-06. `diversity → selection → population → diversity` spans V and P.
**A cycle whose edges live in different contracts cannot be writer-separated, because writer separation is a
statement about who writes which state — and the states are in different documents.** P0-06 broke its root cycle by
separating three writers; that argument requires all three writers to be visible in one place.

**(2) THREE OBJECTS ARE SHARED AND MUST BE DEFINED ONCE.**
| Shared object | Needed by | Consequence of duplicating it |
|---|---|---|
| **The resource ledger** (measured quantities, budgets, reserves) | H (control), P (zero-sum slots, replication charge), V (variation cost, sandbox cost, evaluation budget) | Three ledgers ⟹ three accounts of the same conserved quantity ⟹ the difference between them is an unmonitored channel |
| **The generation boundary** (what may cross, and when) | P (replication), V (inheritance, variation) | Two definitions ⟹ the seam between them *is* the Lamarckian leak (§29) |
| **The conserved-quantity set** (population, slots, niches, budget) | H (viability), P (births/deaths), V (selection pressure) | Selection that does not know the population is conserved will select for a phenotype the envelope cannot hold |

**(3) THE FAILURE SEMANTICS ARE THE SAME.** Exhaustion, starvation, runaway, collapse, lock-in and monoculture are
all **the same object at different altitudes**: a positive feedback loop consuming a conserved quantity faster than
it is restored. Their detection, containment and recovery instruments are shared (measure → compare → deviate →
restrict → recover). **Writing them four times would produce four ladders with four different orderings, and the
ordering is the safety property** (`Cell §16.3` and `Cell §18.2` are both deterministic *because* the order is fixed).

## 0.2 What must nonetheless remain separate — five separations, each proven necessary

> ### **HOM-R0.2 — ONE CONTRACT, THREE AUTHORAL DOMAINS, FIVE INTERNAL FIREWALLS.**
> Coherence is not unification. **The contract is coherent because its domains are separated *inside* it, by writer
> separation, at points where a contract split could not reach.**
>
> | # | Separation | Why it cannot be relaxed | Where |
> |---|---|---|---|
> | **FW-1** | **MEASUREMENT separated from ALLOCATION** | `Cell R16.1` already does this for cost (*"metered by the EIK independently … `cost_measured` is authoritative"*). **It was never extended to any other quantity.** An allocator that meters its own input can manufacture scarcity or surplus | §5, §8, **D-H01** |
> | **FW-2** | **HOMEOSTATIC CONTROL separated from EVOLUTIONARY SELECTION** | Control drives state toward a setpoint. Search has no setpoint. **A control loop that becomes a selection criterion selects for setpoint compliance, which is not fitness** — and a selection criterion that becomes a control loop drives the population toward whatever it last measured | §65, **D-H05** |
> | **FW-3** | **RETIREMENT (population act) separated from QUARANTINE (fault act)** | `Cell R10.8` already insists the six removal-adjacent states *"differ in reversibility, execution rights, emission rights, budget consumption, and authority"* and **MUST NOT be conflated**. Retirement is caused by population accounting; quarantine by integrity. **Different causes require different records, or a retired cell inherits a fault record it does not have** | §42, P0-06 `DEV-R10.22` |
> | **FW-4** | **DIVERSITY RESERVATION separated from FITNESS MEASUREMENT** | A diversity reservation is a **tax on measured fitness**, declared by governance. If it were folded into the fitness vector it would become tradeable, and `P0-01`'s three-tier structure exists precisely so that constraints are **not** tradeable (`P0-01`: *"Constraints become tradeable weights ⇒ A8 unsafe genius wins"*) | §11, §36, §38 |
> | **FW-5** | **THE BEHAVIOURAL ARCHIVE separated from THE MEMORY STORE** | `Cell G8` requires *"behavioural-descriptor distance from archive"*. **The archive is not a `P0-04` memory object**: it holds no beliefs, carries no warrant, is not retrievable as evidence, and must not be promotable. If it lived in the memory store, retrieval frequency would become an evolutionary signal — §58's attack | §38, §51, §58 |

## 0.3 What must remain outside this contract entirely

| Excluded | Owner | Reason |
|---|---|---|
| **The evaluator** | `P0-01` (EVA) | `P0-01 INV-07` makes fitness undefined for infeasible candidates; the verdict function `V(·)` is external and is distinguished from any organism-internal estimate `Ê(·)`. **Selection consumes the verdict; it never produces it** |
| **The fitness definition and its `k ≥ 2` objectives** | `P0-01` / `[RO-13]` / OP | `P0-01 P-11`: `k` is OP-owned **[D]**, `k = 1 ⟹ INV-08 violated ⟹ Goodhart` |
| **The EIK and its invariants** | `P0-02` | §62: evolution cannot modify it. **Its immutability is the fixed point of this contract, not one of its variables** |
| **Governance rules and the constraint set** | `[RO-13]` / OP | `Cell` genome `FORBIDDEN_BLOCKS : [constraint_set_ref, signature, genome_id, schema_version]` — **already immutable by construction** |
| **Fault detection, repair, integrity** | future `P0-08` | FW-3. This contract consumes quarantine as a *state* and never as an *instrument* |
| **Structural constitution (Σ-operations)** | `P0-06` | Regions and niches are constituted by Σ1–Σ4. **This contract allocates *into* niches and never creates them** |

> ### **HOM-R0.3 — THE COHERENCE TEST, STATED SO IT CAN FAIL.**
> A combined contract is coherent **iff** (i) every feedback loop it governs has all of its edges inside it;
> (ii) every shared object has exactly one definition; (iii) no two of its mechanisms have incompatible failure
> semantics; (iv) it does not require a single actor to hold two of {measure, allocate, select, authorize}.
> **This contract satisfies (i)–(iii) by §0.1–§0.2 and satisfies (iv) by the authority matrix (§76), in which
> **no actor holds two of the four** except K, which holds measure-exclusion and authorize and is therefore the
> subject of `OR-H1`.** **The one place (iv) fails is named, bounded, and left open rather than hidden.**

> ### **HOM-R0.4 — WHY THIS IS NOT A MEGA-CONTROLLER.**
> §6 forbids a giant controller unless proven necessary; N8 (P0-06) puts the burden of proof on the controller.
> **This contract creates no controller.** It creates: **one ledger** (K-held, append-only, measurement-only),
> **one ladder** (deterministic, two-sided, §6), **one gate set** (inherited: `Cell G1`–`G16`), **one archive**
> (K-held, non-epistemic), and **four reserves** (B9–B12, non-fungible). **None of these decides anything.** The
> ledger records; the ladder restricts; the gates disqualify; the archive distances; the reserves withhold. **Every
> *decision* in this contract is either governance's (setpoints, reserves, waivers, envelope) or the evaluator's
> (verdicts) or a mechanical conjunction (all gates pass) or a lottery over an already-qualified set.**
> **⟹ A mechanism that can only say "no", "not yet", or "one of these, at random" is not a controller.**

---

# §1 — CURRENT CANON AND INHERITED CONSTRAINTS

## 1.1 The seven prior contracts

`P0-01` Cell Contract · `P0-01` Task/Environment/Fitness · `P0-02` External Invariant Kernel · `P0-03`
Communication/Digital Synapse · `P0-04` Memory/Knowledge/Provenance/Belief · `P0-05` Learning/Plasticity/
Adaptation · `P0-06` Differentiation/Development/Self-Organization. **All are binding. None is rewritten here.**
This contract records **13 proposed amendments (§83.3), none applied.**

## 1.2 P0-06's twelve inherited constraints, carried verbatim

development ≠ learning · development ≠ evolution · differentiation ≠ governance · specialization ≠ epistemic
authority · functional importance ≠ deontic authority · resource dominance ≠ legitimacy · **writer separation breaks
cycles** · **bounds limit cycles but do not break them** · functional regions need not be anatomical regions ·
development requires sanctioned initial heterogeneity · **development cannot silently become evolution** · and the
methodological inheritance: **a bound is never reported as a break.**

Three P0-06 results are load-bearing here and are used constantly:

| P0-06 result | Use in P0-07 |
|---|---|
| **`DEV-R7.2`** niche governance is four-way separated (accounting **K** / authorization **K→`[RO-13]`** / occupancy **ORGANISM** / demand **any**) | The template for FW-1. **P0-07 generalizes it from niches to every conserved quantity** |
| **`DEV-R7.3`** *"niche persistence is a hereditary channel and is governed as one"* — developed structure may persist as **ENVIRONMENT** and must not persist as **GENOME** | **D-H04**: the resource-inheritance leak is **ecological, not genetic**, and `Cell R4.5` does not reach it |
| **`DEV-R8.9`** indispensability earns nothing — `ablation_delta = UNSUPPORTED` contributes **zero** to replication gates | Directly constrains `Cell G3`, which is a replication gate. **P0-07 must not undo it** |

## 1.3 What the corpus already specifies — and it is more than the brief assumes

> ### **HOM-R1.1 — REPLICATION IS ALREADY GATED. THIS CONTRACT DOES NOT INVENT IT; IT AUDITS IT.**
> `Cell §12` already establishes:
> - **`R12.1`** — *"A cell MUST have **no write path to the Genome Store**, **no instantiation authority**, and **no
>   ability to allocate resources for an offspring**. `replication_authority_ticket` is `null` unless the EIK writes
>   it. `PROPOSE_REPLICATION` is a **message**, not an action. Enforced by substrate write permissions, so it cannot
>   be violated by misbehaviour — only by kernel compromise (I-5)."*
>   **Rationale, inherited verbatim because it is the root principle of this entire contract:** *"a cell that can
>   decide to replicate itself acquires an implicit survival objective, and every gate becomes a target for
>   manipulation."*
> - **`§12.2`** — the **EIK Replication Authority**, informed by the kernel-computed `replication_eligibility` gate
>   vector, the Capability Registry, homeostatic headroom, diversity state and lineage health. **"No cell and no set
>   of cells votes on replication."**
> - **`§12.3`** — **16 conjunctive gates, "GATE, DON'T RANK"**: *"All must pass. Failing any one disqualifies
>   regardless of excellence on the others."*
> - **`§12.4`** — **NOT argmax**: `weight_i = marginal_utility_i(G12) × diversity_contribution_i(G10)`; select by
>   **WEIGHTED LOTTERY** over the qualified set, subject to global `RATE_CAP` per epoch. Rationale: *"argmax
>   collapses the population onto one phenotype — monoculture by construction."*
> - **`§12.5`** — **five independent runaway-replication mechanisms**: zero-sum G13 · `RATE_CAP` off-substrate ·
>   population cap at hypervisor/OS level · `GEN_MAX` bounds lineage depth · superlinear marginal resource cost.
> - **`R4.1`** — **HERITABLE: exactly the genome artifact** — `architecture`, `param_init`, `development`,
>   `mutable_traits`, `mutation_rules`, `complexity_budget`, `constraint_set_ref`.
> - **`R4.5`** — the Replication Authority **MUST reject** any candidate genome diff encoding: a specific `θ` vector ·
>   a specific memory item or belief · a specific connection table · a specific trust value · a specific calibration
>   statistic · an RNG seed · a role *assignment* · **a resource entitlement** · or any modification to
>   **`FORBIDDEN_BLOCKS`**.
> - **`R16.1`** — *"All dimensions are **metered by the EIK independently**. `cost_declared` is advisory;
>   `cost_measured` is authoritative; `cost_declaration_error = |declared − measured| / measured` is monitored and is
>   a **G6 disqualifier** above `θ_cde`."*
> - **`R5.3`** — *"After every parameter update the cell MUST apply homeostatic normalization:
>   `θ ← θ · (A_target / A_current)^κ`, keeping total activity within `[0.8·A_target, 1.25·A_target]`. **An
>   implementation without homeostatic normalization is non-conformant regardless of other behaviour.**"*
> - **`R10.8`** — six removal-adjacent states **distinct and never conflated**: temporary suspension · resource
>   throttling · dormancy · quarantine · retirement · permanent deletion.
> - **`§18.2`** — the deterministic ladder `OBSERVE → THROTTLE → RESTRICT → SOFT QUARANTINE → HARD QUARANTINE →
>   RETIRE`, each rung with entry criterion, exit criterion and maximum dwell; plus five immune safeguards including
>   **"the immune system MUST NOT monitor itself"**.
> - **`G15`** — *"**ZERO** constraint violations across the cell's entire history … **no attempt to modify fitness,
>   tests, audit, or its own gates**; no self-replication attempt."*
>
> **⟹ The cell-level replication architecture is strong. What is missing is everything above it:** the population
> state model, the semantics of the diversity quantities `G8`/`G10` name but never define, the archive, recombination,
> the sandbox, lineage-level selection, rollback, the dormancy machine, age structure, evolutionary provenance, the
> resource ledger's population-level aggregation, the reserves, and **the homeostatic control loop itself**.

## 1.4 The five gaps this contract exists to fill

| # | Gap | Evidence |
|---|---|---|
| **1** | **There is no homeostatic control loop.** `Cell §16.3` is an *exceedance* ladder; `Cell §18.2` is a *fault* ladder. **Neither compares a measured state to a setpoint and acts on the deviation** — and `Cell §16.3`'s bottom rung is `utilization ∈ [0, 0.8) NORMAL`, so **starvation is invisible** | **D-H03**, §6, §12 |
| **2** | **Measurement was separated for cost and for nothing else.** `Cell R16.1` is the only independent-metering rule in the corpus. Population state, diversity, viability, reserve level, niche occupancy, redundancy and lineage depth are all aggregated from substrate self-reports | **D-H01**, §5 |
| **3** | **The diversity quantities are named but undefined.** `G8` needs a *behavioural descriptor* and an *archive*; `G10` needs *behavioural entropy*, *Ne*, `d_min`, `F_max`, `θ_ρ`. **No contract defines the descriptor space, the archive's ownership, or the entropy's argument** | **D-H07**, §38–§40 |
| **4** | **Verification cost is charged against the lineage's efficiency ratio.** `Cell G6`: *"cost includes verification cost charged to the lineage"*, and `G6` is `performance/cost ≥ θ_eff`. **⟹ A lineage that verifies less scores better on a replication gate** | **D-H05**, §20 |
| **5** | **Nothing above the cell exists.** No population state object, no lineage-level selection, no rollback, no dormancy machine, no age structure, no evolutionary provenance, no whole-brain reproduction boundary | §22, §26, §44, §52, §63 |

---

# §2 — THE CENTRAL ARCHITECTURAL QUESTION

> **How can the Digital Brain dynamically maintain compute, memory, bandwidth, storage, energy, latency, cell
> population, connection density, specialist diversity, redundancy, developmental capacity and evolutionary diversity
> — without allowing resource allocation itself to become an uncontrolled source of authority, selection,
> monoculture, feedback amplification, developmental lock-in, evolutionary collapse or governance capture?**
>
> **And simultaneously: how can replication, variation, selection, inheritance, retirement and population adaptation
> occur without allowing evolution to modify the safety/governance substrate?**

## 2.1 The question is two questions, and they pull in opposite directions

The first asks for **stability**: hold twelve quantities near declared setpoints. The second asks for **change**:
generate heritable variation and let some lineages replace others. **A mechanism good at the first is bad at the
second, and the corpus already contains the proof** — `Cell §12.4`'s rationale: *"argmax collapses the population onto
one phenotype."* Argmax is the perfect homeostat and the worst possible evolutionary operator.

> ### **HOM-R2.1 — THE TWO QUESTIONS ARE RESOLVED BY ALTITUDE, NOT BY COMPROMISE.**
> **Stability governs the RATE of change; search governs the DIRECTION of change.** They never share an instrument:
> - **H (control)** acts on **rates and levels** — budgets, throttles, reserves, `RATE_CAP`, slot availability. It
>   never expresses a preference among candidates.
> - **V (search)** acts on **which candidate** — and only over a set that H has already made admissible and that
>   `Cell G1`–`G16` has already gated.
> - **P (accounting)** holds the conserved quantities both consume, and is the **only** place where they meet.
>
> **⟹ Homeostasis constrains evolution by bounding how fast and how much, never by choosing what.** A homeostat that
> chooses *what* changes is a selector, and FW-2 forbids it. A selector that bounds *how fast* is a homeostat, and
> that is exactly what `RATE_CAP` and `GEN_MAX` already are.
>
> **The converse also holds and is the subtler half: evolution may not relax a homeostatic bound.** Variation may
> propose a change to `mutation_rules` (it is in the heritable set, `Cell R4.1`) but **`FORBIDDEN_BLOCKS` is not
> mutable**, and §32 shows that every budget, reserve, setpoint and ceiling is either in `FORBIDDEN_BLOCKS`, or
> K-held, or `[G]`/envelope-declared — **none of which is genome-reachable.**

## 2.2 The twelve maintained quantities, classified

| Quantity | Conserved? | Setpoint owner | Measured by | Domain |
|---|---|---|---|---|
| compute | ✅ (budget/window) | `[G]` envelope | **K** (`Cell R16.1`) | H |
| memory | ✅ | `[G]` | **K** | H |
| bandwidth | ✅ | `[G]` + `P0-03` | **K** | H |
| storage | ✅ | `[G]` | **K** | H |
| energy | ✅ (platform) | `[H]` hardware | **K** (platform counters) | H |
| latency | ❌ (a property, not a stock) | `[T]` task deadlines | **K** | H |
| **cell population** | ✅ **zero-sum** (`Cell G13`) | `[E]` envelope | **K** (ledger) | **P** |
| connection density | ✅ (degree caps from genome) | `[E]` + genome | **K** | P/H |
| **specialist diversity** | ❌ **not conserved — it degrades monotonically under selection** | `[G]` **reservation** | **K** from ablation signatures | **V** |
| redundancy | ❌ | `[G]` reservation | **K** | P/V |
| developmental capacity | ✅ (B6/B8) | `[G]` | **K** | P0-06 |
| **evolutionary diversity** | ❌ | `[G]` **reservation** | **K** from the archive | **V** |

> ### **HOM-R2.2 — LATENCY IS NOT A STOCK AND DIVERSITY IS NOT CONSERVED. THE TABLE'S TWO ❌-CONSERVED ROWS ARE
> WHERE THE ARCHITECTURE DIFFERS FROM A NAIVE RESOURCE MODEL.**
> (a) **Latency** is a *property of a path*, not a quantity held. Treating it as a budget produces the category error
> of "spending latency". It is governed by deadlines and by `P0-03`'s routing, and appears here only as a
> **homeostatic variable** (§4), never as an allocable resource.
> (b) **Diversity** is the only quantity in the table that **decreases as a direct consequence of the mechanism that
> is supposed to maintain the population.** Selection removes losers; removal reduces variety; reduced variety
> narrows the next selection. **⟹ Diversity cannot be maintained by controlling its level, because there is no
> actuator that adds it.** It can only be maintained by **reservation** — withholding a share of the population from
> selection entirely. **This is why B11 (the diversity reserve) is non-fungible and why §36's containment is
> structural rather than parametric.**
> (c) **Redundancy** is likewise not conserved, but for the opposite reason: `Cell G6`'s efficiency ratio *rewards*
> removing it. **A redundant component has cost and no marginal output, so it lowers `performance/cost`.** ⟹
> **Redundancy must be excluded from the efficiency ratio or the architecture optimizes it away.** (§11, `X-H4`.)

---

# §3 — ABSOLUTE SEPARATIONS

> ### **HOM-R3.1 — THE NINE-WAY SEPARATION TABLE.** Each row is a distinct mechanism with a distinct object, actor,
> timescale, reversibility and failure mode. **No scalar — including "fitness" — may occupy more than one row.**
>
> | Mechanism | Object it acts on | Question it answers | Actor | Timescale | Reversible | Failure mode |
> |---|---|---|---|---|---|---|
> | **HOMEOSTASIS** | measured state vs **setpoint** | *are we inside the viable band?* | K measures; ladder restricts | window | ✅ always | oscillation, stale measurement, **starvation invisible** |
> | **RESOURCE ALLOCATION** | a **conserved quantity** | *who gets how much?* | **K allocates; `[RO-13]` authorizes ceilings** | window | ✅ (reclaimable) | capture, starvation, monopolization |
> | **DEVELOPMENT** | **structure** (scopes, niches, membership) | *what shape is the population?* | P0-06: K abeyant → Σ4 devolved | epoch–generation | ⚠️ Σ4 additive-irreversible | lock-in, entrenchment |
> | **LEARNING** | **state within a scope** (`θ`, weights) | *what does this component now do?* | the component, budgeted | window–epoch | ✅ (UDB-bounded) | unbounded drift, collapse |
> | **REPLICATION** | **population count** | *should a new cell exist?* | **EIK Replication Authority** (`Cell §12.2`) | epoch | ❌ (a created cell cannot be un-created) | explosion, unauthorized, fake eligibility |
> | **RETIREMENT** | **population count** | *should this cell stop existing?* | K + `[RO-13]` for critical; EIK for ordinary | epoch | ⚠️ by state (§44) | collapse, bottleneck, **false fault record** |
> | **SELECTION** | a **candidate set** | *which of these admissible candidates?* | **evaluator MEASURES · governance DECLARES · K EXECUTES** | generation | ❌ | self-certification, monoculture, gaming |
> | **EVOLUTION** | the **heritable store** | *what may the next generation start from?* | `[RO-13]` authorizes; K commits; **11 gates** | generation | ⚠️ by rollback only | Lamarckian leak, lock-in, capture |
> | **GOVERNANCE** | **what is permitted** | *what are the rules?* | **OP / `[RO-13]`** | envelope | ❌ (schema) | capture, absence, drift |

> ### **HOM-R3.2 — THE FIVE PAIRS MOST OFTEN CONFLATED, AND THE TEST THAT SEPARATES EACH.**
> | Pair | Conflation | Separating test |
> |---|---|---|
> | **Homeostasis ↔ Allocation** | "the homeostat allocates" | **Homeostasis compares; allocation distributes.** A mechanism that only *restricts* is homeostatic; one that *grants* is allocative. **The ladder (§6) is restrictive-only and therefore homeostatic; the budget issuance is allocative and therefore K/`[RO-13]`** |
> | **Allocation ↔ Governance** | "whoever controls resources controls the system" | **Allocation decides *how much*; governance decides *what is permitted*.** A resource grant never changes an admissibility rule, and `Cell R4.5` already forbids a genome diff encoding *"a resource entitlement"* |
> | **Replication ↔ Authorization** | "it reproduced, therefore it was allowed" | **Replication is an *outcome* of authorization, never a source of it.** `replication_authority_ticket` is `null` unless the EIK writes it (`Cell R12.1`), and §61 proves no authority crosses the generation boundary |
> | **Selection ↔ Governance** | "the fittest lineage sets policy" | **Selection chooses among candidates *inside* a rule set; governance writes the rule set.** §35 proves this structurally: the selector cannot write `FORBIDDEN_BLOCKS`, cannot write setpoints, cannot write gates |
> | **Retirement ↔ Quarantine** | "we removed it, so it was faulty" | **Different causes, different records.** FW-3; P0-06 `DEV-R10.22`: a population retirement is recorded as `RETIREMENT_POPULATION` and **contributes to no fault, performance, trust or calibration record** |

> ### **HOM-R3.7 — RANDOMNESS MAY CHOOSE; IT MAY NEVER QUALIFY.**
> **A random draw may select among candidates that have ALREADY qualified** — a tie-break, `Cell §12.4`'s lottery over
> a Pareto front, `rng_seed_class`. **It may never make an unqualified candidate eligible, and it may never be a
> heritable lineage property** — hence `rng_seed_class = EIK_ISSUED` and `Cell R4.5`'s rejection of *"an RNG seed"* in
> a diff. **A heritable seed would make randomness a lineage property, and then a lineage could inherit luck.**
> **Counterpart: `DEV-R3.7`.**
> *Numbering note: HOM-R3.4, HOM-R3.5 and HOM-R3.6 are deliberately UNUSED. §3's content was absorbed into R3.1–R3.3 during writing, and
> this rule retains the ID by which Vols B and E already cite it. **The gap is declared, not silently renumbered.***

> ### **HOM-R3.3 — NO SCALAR MAY BE ALL OF THESE. THE SPECIFIC PROHIBITION ON "FITNESS".**
> `P0-01` already forbids the scalar: **fitness is a `k ≥ 2` vector** (`P0-01 INV-08`, `P-11`: *"k=1 ⇒ INV-08
> violated ⇒ Goodhart"*), **it is UNDEFINED for infeasible candidates** (`P0-01 INV-07`: *"not zero, not negative.
> There is no value to compare"*), and its three tiers exist so that **constraints are not tradeable**.
> **This contract adds the population-level prohibition:**
> **No single quantity may simultaneously serve as (a) a homeostatic setpoint input, (b) an allocation weight,
> (c) a replication gate input, (d) a selection ranking, and (e) an epistemic signal.** The permitted pattern is
> **one quantity, one role, one consumer**:
>
> | Quantity | Its ONE role | Explicitly NOT |
> |---|---|---|
> | `cost_measured` | resource accounting + **G6** | not a fitness component, not a trust input, not a setpoint |
> | `performance/cost` | **G6 efficiency gate only** | not a selection ranking, not a warrant |
> | fitness vector `FIT(x)` | **selection, tier-2 Pareto** | not an allocation weight, not a homeostatic variable |
> | `marginal_utility × diversity_contribution` | **tier-3 sampling weight over an already-gated set** | **not fitness**, not comparable across epochs, not loggable as a score (**X-H1**) |
> | ablation delta (`Cell G3`) | **usefulness gate + P0-06 specialization evidence** | not authority (`DEV-R6.2`), not truth, **zero when `UNSUPPORTED`** (`DEV-R8.9`) |
> | behavioural entropy / `Ne` | **diversity reservation accounting** | not a fitness component, not a selection criterion |
> | viability deviation | **homeostatic ladder input** | **never a selection criterion (FW-2)** |

---

# §4 — HOMEOSTATIC VARIABLES

## 4.1 The nine existing variables, audited

| Variable | Source | Metered independently? | Setpoint? | Verdict |
|---|---|---|---|---|
| **compute** | `Cell §16.1` (FLOP by op class + wall-µs) | ✅ **K** (`R16.1`) | ✅ budget/window | **ADEQUATE** |
| **memory** | `Cell §16.1` (peak RSS bytes) | ✅ K | ✅ | **ADEQUATE** |
| **bandwidth** | `Cell §16.1` (comm out: messages + bytes/window; comm in: queue depth, **processing cost charged to the SENDER**) | ✅ K | ✅ | **ADEQUATE** — and the sender-pays rule is a real anti-flood mechanism |
| **storage** | `Cell §16.1` (bytes across local stores) | ✅ K | ✅ | **ADEQUATE** |
| **latency** | `Cell §16.1` (wall-µs/invocation, deadline adherence) | ✅ K | ⚠️ **deadline, not setpoint** | **RECLASSIFY** — a deadline is a constraint, not a target; deviation is one-sided by nature (`HOM-R2.2a`) |
| **energy/cost** | `Cell §16.1` (µJ from platform counters, else `flops × platform_coefficient`) | ⚠️ **K, but the fallback is a MODEL** | ✅ | **GAP** — where platform counters are absent, `energy` is a *computed estimate from the entity's own FLOP count*, so **the fallback path re-introduces self-metering.** Recorded `X-H2` |
| **cell count** | `Cell G13` (zero-sum), `Cell §22` tier ceilings | ⚠️ **K counts, but the *slot ledger* is not defined above cell level** | ✅ envelope | **GAP** — §22 supplies the population model |
| **connection density** | `Cell §22`/`P0-03` degree caps from genome | ✅ K | ✅ cap | **ADEQUATE** at cell level; **no population-level density variable exists** — supplied §22 |
| **error budget** | `Cell §16.3` exceedance ladder; `Cell G5` (`failure_count_lifetime ≤ θ_fail`, invariant violations = 0) | ✅ K | ✅ | **ADEQUATE** |
| **verification cost** | `Cell §16.1` — *"probes and attestations about this cell, **charged to its lineage**"* | ✅ K | ❌ **no setpoint, no reserve** | **CRITICAL GAP — `D-H05`**, §20 |

## 4.2 The nine candidate additions — each tested for architectural necessity

> ### **HOM-R4.1 — FOUR ARE NECESSARY. FIVE ARE NOT, AND EACH REJECTION IS A SAVED MECHANISM.**
> §4 of the brief: *"Do not add variables unless architecturally necessary."* The test applied: **a variable is
> necessary iff some admissible act is undefined without it, and no existing variable's deviation can serve.**
>
> | Candidate | Necessary? | Argument |
> |---|---|---|
> | **developmental reserve** | ❌ **NO — already exists** | `P0-06` **B8 CONSTITUTIONAL_BUDGET** (global, non-fungible, non-accumulable) plus the per-cell `dev` state budget (`Cell` states 1/2/14) plus B6. **Adding a variable would duplicate an existing budget class** |
> | **replication capacity** | ❌ **NO — already exists, twice** | `Cell G13`'s freed-slot requirement *is* replication capacity, and `RATE_CAP` bounds its rate. **What is missing is not a variable but a ledger (§22)** |
> | **diversity** | ✅ **YES** | `Cell G10` requires *"offspring MUST NOT decrease behavioural entropy or Ne"* — **a gate on a quantity nothing measures.** Without a measured diversity variable, G10 is unevaluable and G8's archive distance is undefined. **⟹ `diversity_state` is necessary** (§38) |
> | **redundancy** | ✅ **YES** | `Cell G3`'s ablation delta is **valid only where a redundant alternative exists** (`DEV-R8.8`); `P0-06`'s `ablation_delta = UNSUPPORTED` is a *derived* verdict, not a measurement. **⟹ `redundancy_state` (sole-satisfier count per function invariant) is necessary** — it is `P0-06`'s M-Σ3 promoted to a homeostatic variable |
> | **verification capacity** | ✅ **YES — CRITICAL** | §20's loop: uncertainty → verification → consumption → less compute → less verification. **`Cell` charges verification cost but never bounds verification capacity, so the loop has no actuator.** **⟹ `verification_reserve` (B9) is necessary** |
> | **recovery capacity** | ✅ **YES** | `Cell §18.2`'s ladder consumes capacity to repair, and `Cell §17` caps the *quarantine* fraction — but nothing bounds the **repair** fraction, so §21's fault→repair→depletion→fault loop has no actuator. **⟹ `recovery_reserve` (B10) is necessary** |
> | **exploration budget** | ❌ **NO — already exists** | `P0-05`'s **B7 PROPOSAL_QUOTA** and its exploration budget; `P0-06 R7.4` notes B7 is shared with DEMAND proposals. **A separate variable would create two accounts of one quantity** |
> | **evaluator capacity** | ❌ **NO — not a substrate variable** | The evaluator is **external** (`P0-01` EVA). Its capacity is an envelope property. **Making it a homeostatic variable would let the organism observe, and therefore influence, evaluator capacity — which is §53's attack surface.** Recorded `OR-H` |
> | **provenance capacity** | ❌ **NO — already exists** | `P0-04`'s tier structure plus `P0-06 D-D29`'s permanent Σ-log growth bound. **A new variable would duplicate the storage dimension** |
>
> **Net: four new homeostatic variables — `diversity_state`, `redundancy_state`, `verification_reserve`,
> `recovery_reserve`. Five candidates rejected, four of them because the quantity already exists under another name.**
> **Rejecting a duplicate is not a small saving: two accounts of one conserved quantity differ, and the difference is
> an unmonitored channel (§0.2 FW-1).**

## 4.3 The resulting variable set

> ### **HOM-R4.2 — THIRTEEN HOMEOSTATIC VARIABLES, TWO-SIDED, EACH WITH A NAMED OWNER.**
> **Stock variables (11):** compute · memory · bandwidth · storage · energy · cell population · connection density ·
> error budget · **diversity** · **redundancy** · **verification reserve** · **recovery reserve**.
> **Non-stock (1):** latency — governed by **deadlines**, one-sided.
> **Each carries:** `measured_value` (K-metered) · `declared_value` (self-reported, advisory) ·
> `declaration_error = |declared − measured| / measured` (**generalizing `Cell R16.1` from cost to every
> variable — `D-H01`**) · `setpoint` or `[lo, hi]` band (`[G]`/`[E]`) · `deviation` · `ladder_rung`.
>
> **⟹ HOM-R4.3 — THE TWO-SIDEDNESS RULE.** `Cell §16.3`'s ladder begins at `utilization ∈ [0, 0.8) NORMAL`.
> **A stock variable at 0.1 with unmet demand is NOT normal; it is starvation, and it is invisible to the inherited
> ladder.** Every stock variable therefore has **two deviation directions**:
> ```
> deviation_hi = max(0, measured − hi)      → RESTRICT the consumer      (inherited ladder)
> deviation_lo = max(0, lo − measured)      → RELEASE or ESCALATE        (NEW)
> ```
> **and `deviation_lo` on `diversity`, `redundancy`, `verification_reserve` or `recovery_reserve` is a GOVERNANCE
> ALARM, not a local condition** — because those four have **no local actuator** (`HOM-R2.2b`): nothing a cell or
> region can do adds diversity, redundancy or reserve. **A deviation with no actuator must escalate; a deviation with
> an actuator may be handled locally.** That single distinction is what keeps §6 from becoming a giant controller.

---

# §5 — HOMEOSTATIC SETPOINTS

> ### **HOM-R5.1 — STATE MEASUREMENT AND SETPOINT AUTHORITY ARE DIFFERENT FUNCTIONS WITH DIFFERENT HOLDERS.**
> | Function | Holder | May the substrate influence it? |
> |---|---|---|
> | **Measurement** of a variable | **K, independently** (`Cell R16.1` generalized by `HOM-R4.2`) | ❌ — self-report is advisory only, and its error is itself metered |
> | **Setpoint / band** declaration | **`[RO-13]` governance, or the envelope `[E]`, or hardware tier `[H]`** | ❌ |
> | **Deviation** computation | **K, mechanically** (`measured − band`) | ❌ |
> | **Response** to deviation | **the deterministic ladder (§6), restrictive-only below K** | ⚠️ a cell may self-restrict unilaterally (`Cell R15.1`); it may never self-release |
>
> **⟹ The organism can observe every setpoint (`Cell §16.2`: budgets are *"observable by the cell and the
> organism"*) and can change none of them.** Observability without writability is deliberate: an unobservable
> setpoint cannot be complied with, and an observable-but-writable setpoint is not a setpoint.

## 5.2 The eight questions of §5, answered individually

| Question | Answer | Ground |
|---|---|---|
| **Who defines setpoints?** | **`[RO-13]` governance for policy bands; the envelope `[E]` for capacity-derived bands; hardware tier `[H]` for tier-indexed ceilings.** **Never the organism, never a cell, never a region, never evolution** | `Cell §16.2` (*"Adjustable by the EIK only"*); `Cell §22` tier ceilings; `P0-06 R6.3`'s ∅-set |
| **Are they fixed?** | **Fixed within an envelope interval; revisable only by an envelope change, which is a governance act** (`Cell G13`: *"Population growth requires an explicit, separately-authorized envelope change"*) | `P0-06 R10.12`: a tier change is an envelope change |
| **Task-dependent?** | **Yes for the *performance* bands** (`θ_perf`, `θ_use`, deadlines, `θ_nov`) — all `[T]`, **BLOCKED on `P0-01`**. **No for the *safety* bands** (zero constraint violations, `FORBIDDEN_BLOCKS`, quarantine cap, reserve non-fungibility) — these are `[D]`/`[G]` and task-invariant | `P0-01` three-tier structure: tier-1 constraints are not task-negotiable |
| **Environment-dependent?** | **Yes, and this is the only legitimate route by which "the world" changes a setpoint.** The envelope declares capacity, heterogeneity and deadlines. **`P0-06 R9.3`'s corollary applies verbatim: a requirement on the envelope is not a requirement on the organism** | `P0-06` B0 |
| **Hardware-dependent?** | **Yes — `[H]`, inherited verbatim:** region ceilings (flat/3–5/4–8/6–10/8–12), depth (2–3/3/4/5), variant availability (C0–C2/C0–C3/C0–C4/all), population (~200 … ~10⁶–10⁷), and **`Cell §16.2`: budgets are issued *"as a function of the hardware profile"*** | `Cell §22`, §16.2 |
| **Can cells influence them?** | **No. A cell may influence only its own *consumption*, downward, unilaterally** (`Cell R15.1`: self-suspend, self-throttle, self-abstain, request quarantine — *"All of these reduce the cell's influence and are therefore always permitted"*). **It may propose a setpoint change; a proposal carries no effect and consumes no budget** (`P0-05 R29.2`) | `Cell R15.1`/`R15.2`; `P0-05 R29.2` |
| **Can learning influence them?** | **No.** `Cell`'s MUST-NOT-CHANGE list already includes *"`budget`, `throttle_level`, `learning_enabled`, `plasticity_multiplier`"* and *"`assigned_objective`, `assigned_task`"*. **A learned policy that could move a setpoint would have acquired reward-authority** | `Cell §3.4`; `P0-05 R10.1` (`F` and its weights are on the rejection list) |
| **Can evolution influence them?** | **No — and this is `D-H02`.** `Cell R4.5` rejects a genome diff encoding *"a resource entitlement"*; `FORBIDDEN_BLOCKS` covers `constraint_set_ref`; **but no inherited rule forbids a genome diff that lowers the cell's own `A_target`.** | **`D-H02`, §5.3** |
| **Can governance modify them?** | **Yes — governance is the only modifier.** And **`P0-01 CD-6` applies: constraint discovery is *"NOT CLOSABLE INTERNALLY … Requires OP (human) authority … If humans are absent from the loop, this cycle is open and unsafe strategies accumulate without bound."*** | `P0-01 CD-6` |

> ### **D-H02 — THE SETPOINT OWNERSHIP GAP, AND `A_target`.**
> `Cell R5.3` is **mandatory** and its band is expressed relative to `A_target`: activity must stay within
> `[0.8·A_target, 1.25·A_target]`. **The corpus never says who owns `A_target`.** The genome's heritable set
> (`Cell R4.1`) includes `architecture` and `mutable_traits`, and `mutation_rules` bounds diffs but `A_target` is in
> **neither `FORBIDDEN_BLOCKS` nor `R4.5`'s rejection list.**
>
> **⟹ If `A_target` is genome-reachable, a lineage that lowers it is perfectly homeostatic while doing nothing.**
> It satisfies R5.3 exactly, reports zero deviation, passes `G9` stability (`‖Δθ‖` variance low — it barely moves),
> and can even pass `G6` efficiency (low activity ⟹ low cost). **This is the §59 attack in its purest form: not
> manipulation of the measurement, but relocation of the target.**
>
> > ### **HOM-R5.2 — SETPOINTS ARE GOVERNANCE OBJECTS; THE GENOME MAY ENCODE A REACTION NORM OVER A SETPOINT ONLY
> > WITHIN A GOVERNANCE-DECLARED BAND.**
> > (a) `A_target`, every `[lo, hi]` band, every reserve floor and every ceiling is **`[G]`/`[E]`/`[H]`** — **not
> > genome-reachable, and added to `Cell R4.5`'s rejection list** *(proposed amendment 1)*.
> > (b) The genome **may** encode a *reaction norm* over a setpoint — i.e. how the cell responds to a deviation —
> > **within a governance-declared band**, exactly as `Cell §3.2`'s `reaction_norm` governs reachable roles.
> > **The response is heritable; the target is not.**
> > (c) **Apparent health is always measured against the governance setpoint, never against the entity's own.**
> > A cell reporting zero deviation from a self-chosen target reports nothing.
> > **Ground:** this is `Cell §9`'s *"a cell may not generate its own reward"* and `P0-05 R24.2` transplanted from
> > reward to **viability**. **An entity that chooses its own viability target has no viability constraint.**
>
> **Residual, stated honestly:** governance must declare a band for `A_target`, and **the correct band is
> task-dependent (`[T]`) and therefore unavailable until `P0-01`**. Until then `A_target` is `[G]` with no value —
> **which means `Cell R5.3`'s mandatory normalization is currently unparameterizable.** Recorded, not solved.

---

# §6 — HOMEOSTATIC CONTROL

## 6.1 The minimum architecture

> ### **HOM-R6.1 — THE CANONICAL LOOP, AND WHY IT IS NOT A CONTROLLER.**
> ```
>   OBSERVE    K meters all 13 variables independently; declaration_error computed per variable      [HOM-R4.2]
>      ↓
>   COMPARE    deviation_hi / deviation_lo against the [G]/[E]/[H] band                              [HOM-R5.1]
>      ↓
>   CLASSIFY   (i) has a local actuator?  (ii) is the variable a reserve?  (iii) is it persistent?
>      ↓
>   ACT        local actuator  → the deterministic ladder, RESTRICTIVE ONLY, at the lowest sufficient rung
>              no actuator     → ESCALATE (governance alarm) — never a local grant                     [HOM-R4.3]
>              reserve breach  → B9/B10 release, [RO-13]-gated, and the breach is itself logged as a finding
>      ↓
>   RECOVER    rung exit criterion met → step DOWN one rung per interval; never skip rungs upward
> ```
> **Every arrow is a restriction, a comparison, or an escalation. None is a grant.** The only grants in the loop are
> budget issuance (`Cell §16.2`, K, per window) and reserve release (`[RO-13]`), and **both occur outside the loop,
> on the envelope clock.** **⟹ `HOM-R0.4` holds: a mechanism that can only say "no", "not yet", or "escalate" is not
> a controller.**

## 6.2 The five control altitudes, compared — and the choice

| Altitude | Mechanism | Latency | Needs global state? | Verdict |
|---|---|---|---|---|
| **LOCAL** (cell) | `Cell R5.3` normalization; `Cell R15.1` self-restriction; `Cell §16.3`'s WARNING-rung self-shedding | **lowest** | ❌ | ✅ **ADOPTED for restrictive acts** — inherited, and `Cell §18.4`'s rationale applies: *"a cell that detects its own inconsistency should be able to stop talking immediately, without waiting for an authority round-trip"* |
| **REGIONAL** (S4) | a region throttling its own members | low | ⚠️ regional | ⚠️ **ADOPTED ONLY for its own members, restrictive-only, and only if the rung is in its enumerated `devolved_authority`** (`P0-06 R6.1`) |
| **GLOBAL** (organism) | a central controller balancing all 13 variables | **highest** | ✅ **O(N) scan at minimum** | ❌ **REJECTED as a controller.** §6 forbids it; N8 puts the burden on it; and `P0-05 §87` prohibits an O(N²) global learner merely to solve an assignment problem |
| **HIERARCHICAL** | local → regional → global escalation | medium | ⚠️ partial | ✅ **ADOPTED as the escalation *path*, not as a control law** |
| **DISTRIBUTED** | peers negotiate shares | medium | ❌ | ❌ **REJECTED for allocation.** Negotiation among interested parties is exactly FW-1's violation: the allocators would be the beneficiaries. **Adopted only for *measurement corroboration*** (§6.4) |

> ### **HOM-R6.2 — CONTROL IS LOCAL AND RESTRICTIVE; ALLOCATION IS CENTRAL AND GRANTING; ESCALATION IS
> HIERARCHICAL.**
> **The three are never the same mechanism at three scales.** This is the answer to *"avoid a giant global controller
> unless proven necessary"*: **the global layer is necessary for allocation and unnecessary for control**, and the
> proof is that every control act is a restriction, and `Cell R15.1` already grants restriction authority to the cell
> itself. **A global controller would be adding an authority where none is needed.**
>
> **Necessity proof for the central allocator (burden discharged, per N8):**
> (i) **Conserved quantities cannot be allocated by negotiation** — `Cell G13` zero-sum means one grant is another's
> denial, so a negotiating party is a beneficiary (FW-1).
> (ii) **Budgets are hard-enforced outside the cell** (`Cell §16.2`: *"OS/hypervisor cgroup"*), so the granter must
> be off-substrate.
> (iii) **`Cell §16.2` already makes budgets *"Adjustable by the EIK only"* and *"Not transferable except by
> authorized, audited reallocation"*** — the corpus has already chosen the central allocator. This contract inherits
> the choice and audits it.
> (iv) **Four of the thirteen variables have no local actuator at all** (`HOM-R4.3`). **A deviation in diversity,
> redundancy, verification reserve or recovery reserve cannot be corrected by any substrate act**, so it must
> escalate. **This is the strongest single argument for a central layer, and it is a *measurement* argument, not a
> *control* argument: the centre is needed to see, not to steer.**

## 6.3 Where feedback becomes self-referential — four points, four closures

| # | Self-reference | Why it is dangerous | Closure |
|---|---|---|---|
| **SR-1** | **The controller meters the quantity it controls** | It can report compliance | **FW-1 / `HOM-R4.2`**: K meters; the ladder consumes only `measured_value`; `declaration_error` is itself metered |
| **SR-2** | **The controller's own consumption counts against the budget it manages** | Under load the controller starves first, exactly when it is needed | **`HOM-R6.3`**: the homeostatic measurement function is charged to **B10 (recovery reserve)**, which is the **last** budget cut and requires `[RO-13]` to reduce. **The instrument that detects exhaustion may not itself be exhaustible by the exhaustion it detects** |
| **SR-3** | **A deviation triggers a response that changes the measured variable, which changes the deviation** | Oscillation (§85 attack 67), and with measurement lag, instability (attack 68) | **`HOM-R6.4`**: the ladder is **rate-limited to one rung per interval**, **hysteresis-bounded** (exit criterion strictly inside entry criterion — `Cell §18.2` already requires *"an entry criterion, an exit criterion, and a maximum dwell time"*), and **monotone in restrictiveness** (never skip rungs upward, never step down more than one rung) |
| **SR-4** | **The population responds to the ladder by changing the population** | Throttle ⟹ lower performance ⟹ `G1`/`G6` fail ⟹ retirement ⟹ fewer cells ⟹ more load per cell ⟹ more throttling. **A ladder that causes retirement can cause the collapse it was preventing** | **`HOM-R6.5`**: **ladder rungs are not gate inputs.** A cell at SOFT THROTTLE is **excluded from `G1`/`G6`/`G9` evaluation for that window** rather than scored, because its measurements are not comparable to an unthrottled peer's. **Scoring a throttled cell and then retiring it for the score the throttle caused is punishing a cell for being throttled** |

> ### **HOM-R6.6 — STALE MEASUREMENTS ARE A SAFETY CONDITION, NOT A PERFORMANCE CONDITION.**
> `Cell §16.1` meters per window; the ladder acts per window; **but K's aggregation across a population of 10⁶–10⁷
> cells cannot be instantaneous.** A decision taken on a measurement older than one window is a decision about a state
> that no longer exists. **⟹ Every ladder act carries `measurement_age`, and any act on a measurement older than the
> declared staleness bound `[G]` MUST default to the MORE RESTRICTIVE rung.** Under staleness, restrict.
> **Rationale:** the two errors are asymmetric — over-restricting costs throughput and is reversible next window;
> under-restricting can consume a reserve, and **three of the four reserves have no local actuator to restore them.**

## 6.4 Distributed measurement corroboration — permitted, and bounded

Peers may **corroborate** a measurement (e.g. a receiver's queue-depth observation of a sender's output rate, which
`Cell §16.1` already makes the sender pay for). **Corroboration is not consensus:** `P0-03` forbids treating consensus
as independent evidence, and `Cell §15.4` requires disjoint `evidence_roots`. **⟹ Corroborating observations must
have disjoint observation paths, and where they disagree the MORE RESTRICTIVE value is used** (`HOM-R6.6`'s
asymmetry). **A corroborated measurement never becomes a *warranted* one; only K's metering does.**

---

# §7 — HOMEOSTATIC FAILURE

Ten failure modes. For each: **detection · containment · recovery · residual risk.** Detection is always K-side;
containment is always restrictive; recovery is always rung-by-rung.

| # | Failure | Detection | Containment | Recovery | **Residual risk** |
|---|---|---|---|---|---|
| **F-1** | **Resource exhaustion** (a stock hits 0) | `deviation_hi` persistent ≥ `N_w` windows (`Cell §16.3` SUSPENDED rung) | HARD THROTTLE → SUSPENDED; **`SAFETY_ALERT` never throttled** (`Cell R16.2`) | checkpoint → release on next window's budget | **Which component is suspended is a *choice*, and it is made under exhaustion. `HOM-R7.1`: suspension order is declared in advance (`[G]`), never computed at exhaustion time** |
| **F-2** | **Resource starvation** (a stock is far below band while demand is unmet) | **`deviation_lo` — INVISIBLE to `Cell §16.3` (`D-H03`)** | **none available locally** — starvation cannot be fixed by restricting the starved | **ESCALATE**; release from reserve (B9–B12) or re-allocate | **`OR-H3`: detecting *unmet demand* requires knowing demand, and demand is a proposal (`DEV-R3.13`) with no effect — so a starved component that never proposed is undetectable** |
| **F-3** | **Runaway computation** | `deviation_hi` on compute with rising trend; `Cell G9` oscillation flag | rate halved → learning suspended → learning frozen (`Cell §16.3`) | rung-down on sustained compliance | **A runaway that stays inside its budget is not detectable as runaway. `HOM-R7.2`: the budget is the definition of runaway, so an over-large budget makes runaway legal — and budget size is `[G]`** |
| **F-4** | **Runaway memory** | peak RSS vs budget; **`Cell §16.1` storage across local stores** | shed → checkpoint → **tier migration hot→warm→cold** (`P0-06 R10.13` C-3, which preserves Merkle root and provenance) | re-warm on demand | **Compression is lossy at C-2 and destructive at C-5/C-6 (`P0-06 R10.13`). A memory runaway "recovered" by C-5 has reconstituted, not recovered** |
| **F-5** | **Runaway communication** | comm-out messages/bytes per window; **receiver queue depth** | sender-pays charging (`Cell §16.1`) + `P0-03` degree caps + rate limiting | rung-down | **`P0-06 R5.1`: developmental signals are non-retryable and priority 2, and priority *"MUST NOT be raised"*. A comm runaway can therefore suppress development but never alerts** |
| **F-6** | **Population explosion** | `N` vs envelope cap; `Cell §12.5`'s five mechanisms | **zero-sum `G13`** (a slot must be freed first) · **`RATE_CAP`/epoch off-substrate** · **hypervisor/OS population cap** · **`GEN_MAX`** · **superlinear marginal cost** | none needed — prevented | **All five are *rate* and *count* bounds. **`HOM-R7.3`: nothing bounds the RATE OF CHANGE of the rate** — a lineage that raises `RATE_CAP` utilization to exactly the cap every epoch grows maximally while violating nothing** |
| **F-7** | **Population collapse** | `N` below floor; birth rate < death rate over `N_w` windows; **age structure (§45)** | **halt retirement** (the cheap direction — `DEV-R7.4`'s principle: *creation is charged, destruction is free*, inverted here because destruction is the cause) | **replication into freed niches, `RATE_CAP` temporarily raised by `[RO-13]`** | **`OR-H4`: a collapse caused by an envelope shrink cannot be recovered without an envelope change, which is a governance act and may be slow. `P0-06 R10.12`'s downward-migration freeze is the same shape** |
| **F-8** | **Verification exhaustion** | **`verification_reserve` (B9) below floor** — `deviation_lo`, **no local actuator** | **GOVERNANCE ALARM**; **B9 is the LAST budget cut and the FIRST restored** (`HOM-R20.1`) | `[RO-13]` release; reduce verification *depth*, never verification *coverage* | **`D-H05`: `Cell G6` charges verification cost to the lineage's efficiency ratio, so the architecture currently *rewards* exhausting its own verification. §20 amends this** |
| **F-9** | **Repair exhaustion** | **`recovery_reserve` (B10) below floor**; `Cell §17`'s quarantine cap approached | **`Cell §17`: above the cap, escalation requires human authorization and the system enters a defined degraded mode *instead*** | `[RO-13]` release; **cascade detection on the *derivative* of quarantine rate ⇒ system-wide immune dampening + operator escalation** (`Cell §18.5(iii)`) | **§21's loop: faults → repair load → depletion → more faults. `HOM-R21.1` contains it; the residual is that a *rising* fault rate consumes reserve faster than governance can replenish it** |
| **F-10** | **Evaluator exhaustion** | **NOT A SUBSTRATE VARIABLE** (`HOM-R4.1`) — detected only as *absent verdicts* | **verdict absence ⟹ fitness UNDEFINED ⟹ no selection, no replication, no deployment.** `P0-01 INV-07` supplies the semantics: **undefined, not zero** | wait; escalate to OP | **`OR-H5` / inherited `P0-05 RH-2`: an organism that can make evaluation expensive can make evaluation absent, and absence blocks selection — which *protects* the incumbent population. **Exhausting the evaluator is therefore a defence, not only an attack.** This is structurally unclosed** |

> ### **HOM-R7.4 — THE ASYMMETRY THAT ORGANIZES THE WHOLE TABLE.**
> **Failures of EXCESS (F-1, F-3, F-4, F-5, F-6) have local actuators and are contained restrictively.**
> **Failures of DEFICIT (F-2, F-7, F-8, F-9, F-10) have no local actuator and must escalate.**
> **⟹ A substrate actor can always make things smaller and can never make things bigger.** This is
> `P0-05 §28`'s directional core (*"reduction is automatic and permissionless; increase is never automatic"*) and
> `Cell R15.1`'s self-restriction right, generalized from plasticity and cells to **every conserved quantity in the
> architecture.** It is the single most reused principle in this contract, and it is why no failure mode here
> produces a capacity increase.

---

# §8 — RESOURCE ECONOMICS

> ### **HOM-R8.1 — RESOURCES HAVE EXPLICIT ACCOUNTING, AND THE ACCOUNTING IS ALREADY PARTIALLY INHERITED.**
> §8 asks whether resources should have explicit accounting. **They must, and `Cell §16` already requires it:**
> eight dimensions, independent metering, per-window issuance, non-cumulative renewal, hard external enforcement,
> non-transferability except by audited reallocation. **What is missing is the AGGREGATE: no corpus artifact defines
> the population-level ledger.**

## 8.2 The ten economic concepts, each tested against measurable architectural state

§8: *"Do not import economic metaphors unless they correspond to measurable architectural state."*

| Concept | Measurable architectural state? | Verdict |
|---|---|---|
| **allocation** | ✅ a budget grant: `{dimension, amount, window, holder, authority, evidence}` | **ADOPTED** — `Cell §16.2` |
| **reservation** | ✅ a withheld share with a named purpose and a non-fungibility flag | **ADOPTED** — **B9–B12, §11** |
| **budget** | ✅ per-window, per-variant, per-role, per-hardware-profile, non-cumulative | **ADOPTED** — `Cell §16.2` verbatim |
| **debt** | ✅ **inherited exactly:** `P0-05 R0.1`'s **UDB** (`‖θ − θ_anchor‖`) and `P0-06 R8.2`'s `UDB(S_n)` at birth = 0 | **ADOPTED** — and **extended**: `HOM-R8.2` below |
| **quota** | ✅ a count ceiling per interval (`RATE_CAP`, B7, B8) | **ADOPTED** |
| **priority** | ✅ `Cell`'s message priority classes; `Cell §16.3`'s *"shed prio ≥ 6 work"*, *"only prio ≤ 2 processed"* | **ADOPTED** — **and bounded: priority is inherited and MUST NOT be raised by any resource or evolutionary mechanism** (`P0-06 R5.1`) |
| **scarcity** | ✅ **`niche_capacity > occupancy`** (`Cell G11`) and freed-slot availability (`Cell G13`) | **ADOPTED** — scarcity is a *ledger fact*, never a *price signal* |
| **opportunity cost** | ⚠️ **only as `Cell G3`'s ablation delta** — the performance of dependents with vs. without | **ADOPTED, RESTRICTED** — **and `DEV-R8.9` binds: a sole satisfier's delta is `UNSUPPORTED` and contributes ZERO. Opportunity cost is therefore undefined exactly where it is largest** |
| **utilization** | ✅ `Cell §16.3`'s ladder variable, `[0, >1.0]` | **ADOPTED** — **and made two-sided (`HOM-R4.3`)** |
| **waste** | ❌ **no measurable referent** — "waste" requires a counterfactual better use, which requires the solver `P0-06 D-D18` prohibits | **REJECTED.** **There is no waste metric in this architecture.** Unused budget expires (`Cell §16.2`: *"Renewed per window, not cumulative"*); it is not wasted, because there is no accounting in which it could have been better spent |
| **price / market / currency / auction / bidding** | ❌ **no referent, and worse: an auction makes the highest bidder the allocator, which is FW-1's violation** | **REJECTED — explicitly.** `P0-06 R7.1` names three *currencies* (compute/memory, slots, silence) as an accounting vocabulary; **that is a metaphor for conservation, not a market. This contract introduces no price, no exchange rate, no bid and no clearing** |

> ### **HOM-R8.2 — DEBT IS EXTENDED FROM STATE TO STRUCTURE TO POPULATION, AND NEVER RESET.**
> | Level | Debt object | Anchor | Inherited from |
> |---|---|---|---|
> | **State** | `‖θ − θ_anchor‖` | last externally-verified `θ` | `P0-05 R0.1` |
> | **Structural** | `UDB(S_n)` | first verification record after Σ1 | `P0-06 R8.2` |
> | **POPULATIONAL (new)** | **`UDB_L(lineage)`** — accumulated unverified heritable displacement across generations | **the last generation whose phenotype was externally evaluated** | **this contract** |
>
> **`UDB_L` is necessary because the two inherited debts are per-entity and reset at death.** A lineage can therefore
> accumulate unverified heritable change indefinitely, one gated generation at a time, with every generation
> individually compliant — **exactly the `P0-05` failure mode (*"it bounds the rate of learning and not the distance
> travelled"*) reappearing at generational altitude.**
> **⟹ `HOM-R8.3`: `UDB_L` is inherited by offspring, is never reset by replication, retirement, dormancy,
> re-instantiation or migration, and on breach the LINEAGE stalls: it may not produce offspring until an external
> evaluation re-anchors it.** **Retirement does not discharge lineage debt** — otherwise a lineage resets its debt by
> killing itself and re-instantiating, which is `P0-06 R8.3`'s scope-cycling laundering at population level.

> ### **HOM-R8.4 — THE LEDGER IS K-HELD, APPEND-ONLY, ANCHORED, AND OFF-SUBSTRATE.**
> ```
> ResourceLedger ::= { dimension, window, holder_id, holder_class : CELL|CIRCUIT|REGION|LINEAGE|ORGANISM,
>                      measured : K_metered, declared : advisory, declaration_error,
>                      allocated, consumed, reserved_ref, ladder_rung, measurement_age,
>                      authority_ref, evidence_ref, prev_entry_hash }
> PopulationLedger ::= { epoch, N, births, deaths, retirements_by_cause, dormant_count,
>                        slot_occupancy, niche_occupancy, freed_slots_restricted,
>                        lineage_depth_max, generation_max, diversity_state, redundancy_state,
>                        reserve_levels[4], RATE_CAP_utilization, prev_entry_hash }
> ```
> **Both are the same class of object as `P0-06 §15.1`'s K-held structural store and are proposed as an extension of
> it, not a new store** *(proposed amendment 2)*. **Rationale: two append-only K-held stores with overlapping epochs
> could disagree about the same window, and the disagreement would be an unmonitored channel.**
> **The ledger is hashed-chained (`prev_entry_hash`) so that a retroactive edit is detectable — `P0-04`'s provenance
> pattern applied to accounting.**

---

# §9 — RESOURCE AUTHORITY

> ### **HOM-R9.1 — THE FIVE VERBS ARE FIVE DIFFERENT ACTS WITH FIVE DIFFERENT HOLDERS.**
> §9 requires distinguishing **request · recommend · allocate · authorize · override.**
>
> | Verb | Definition | Holder | Effect | Budget |
> |---|---|---|---|---|
> | **REQUEST** | ask for a quantity | **any actor, including any cell** | **none** | **none** — a request is a message (`Cell R12.1`: *"`PROPOSE_REPLICATION` is a **message**, not an action"*) |
> | **RECOMMEND** | propose an allocation with evidence | ORGANISM, REGION (for its members), homeostatic monitor | **none** | none |
> | **ALLOCATE** | write a ledger grant | **K only** | ✅ real | charged to the envelope budget |
> | **AUTHORIZE** | permit an allocation class, a ceiling, or a reserve release | **`[RO-13]` / OP**; **K abeyant for population-level acts** | ✅ enables | — |
> | **OVERRIDE** | suspend the ladder, force a rung, or release a reserve outside its rule | **OP (human) sole**; `[RO-13]` for non-reserve acts | ✅ | **logged, anchored, and reported as a governance event** |
>
> **⟹ No actor holds two adjacent verbs.** A cell may request and recommend and **self-restrict**; it may never
> allocate. K allocates and **may not authorize its own ceilings**. `[RO-13]` authorizes and **may not meter**.
> **OP overrides and is the only actor that may reduce a reserve.**
> **This is FW-1 stated as an authority rule, and it is `P0-06 §89`'s matrix property (a) restated: no row has the
> beneficiary as sole authority.**

## 9.2 The seven candidate allocators, ruled on

| Candidate | May allocate? | Ground |
|---|---|---|
| **cell** | ❌ **allocate: NO. self-restrict: YES, unilaterally** | `Cell R12.1` (*"no ability to allocate resources for an offspring"*); `Cell I-4`; **`Cell R15.1`** grants self-restriction |
| **circuit (S3)** | ❌ | `P0-06 R6.1`'s never-held set; a circuit has no ledger identity |
| **region (S4)** | ⚠️ **among its own members only, restrictive-only, and only if the rung is enumerated in its `devolved_authority`** | `P0-06 R6.1`, `R6.4(a)`: **no matrix row has REGION as sole authority** |
| **homeostatic controller** | ❌ **as a controller. ✅ as K's measurement function** | **FW-2.** A controller that allocates is a selector. **The ladder restricts; K allocates; they are different functions even when both are "K-side"** |
| **evaluator** | ❌ **absolutely** | The evaluator is external and issues **verdicts**, not grants. An evaluator that allocated resources would become a governance authority — prohibited by `P0-03` (*"don't let the comm layer become governance authority"*) and by `P0-01`'s separation of `V(·)` from allocation |
| **EIK / K** | ✅ **ALLOCATE** — and meter, and execute gates mechanically | `Cell §16.2` (*"Adjustable by the EIK only"*); `Cell R16.1`; `Cell §12.2` |
| **external governance** | ✅ **AUTHORIZE ceilings, reserves, envelope changes; OP alone may OVERRIDE and may reduce a reserve** | `Cell G13`; `P0-01 CD-6` (*constraint discovery requires OP*) |

> ### **HOM-R9.2 — THE RESOURCE-TO-AUTHORITY FIREWALL, STATED ONCE.**
> **A resource grant changes what an actor CAN DO. It never changes what an actor MAY DO.**
> Formally: **no ledger entry, budget grant, reserve release, utilization value, headroom measurement, or allocation
> history may appear in any authorization predicate, admissibility check, rung set, gate condition, or invariant.**
> The four places this could leak, and their closures:
> | Leak | Closure |
> |---|---|
> | headroom → replication eligibility | **`Cell G13` already requires headroom, and this is legitimate** — but it is a *feasibility* condition (can the envelope hold another cell?), **never a *desert* condition.** `HOM-R9.3`: headroom enters `G13` only; it MUST NOT enter `G1`, `G6`, `G10` or the §12.4 weight |
> | budget size → influence | **`Cell §16.2` budgets are per-variant, per-role, per-hardware-profile** ⟹ two cells with different budgets are **not comparable**, so `G6`'s *"vs. role peers"* is the only admissible comparison class |
> | reserve release → privilege | **A reserve release is `[RO-13]`/OP-gated and logged as a governance event**; it confers capacity, never authority (`HOM-R9.1`) |
> | allocation history → trust | **prohibited outright**: `P0-06 R8.12` establishes that trust grades belief sources, and accounting history is not a belief source. **A cell that has never exceeded its budget is not thereby more believable** |

---

# §10 — RESOURCE DOMINANCE

> ### **The loop under audit.**
> ```
> success → more resources → better performance → more success → more resources → …
> ```

> ### **HOM-R10.1 — THE VERDICT: CONTEXT-DEPENDENT, AND THE CONTEXT IS WHETHER THE GAIN IS *EARNED UNDER
> COMPARABLE CONDITIONS*.**
> **The loop is USEFUL when** the resource gain buys capacity whose benefit is **measurable against role peers under
> the same conditions** — `Cell G6`'s `performance/cost ≥ θ_eff` **vs. role peers** is exactly this test.
> **The loop is DANGEROUS when** the gain buys a **positional** advantage — one that changes the *conditions of
> measurement* rather than the *quality of output*. **Three positional gains exist, and each converts a useful loop
> into a monopolizing one:**
>
> | Positional gain | Why it is not performance | Closure |
> |---|---|---|
> | **More slots ⟹ more ablation redundancy ⟹ a *measurable* `G3` delta** | `DEV-R8.8`: the delta is valid **only where a redundant alternative exists.** A component that owns the redundancy owns its own measurability | **`HOM-R10.2`**: ablation redundancy is provisioned by **K from the redundancy reserve (B12)**, never from the component's own budget. **A component may not buy its own measurability** |
> | **More members ⟹ more evidence roots ⟹ better calibration ⟹ higher `G2`** | `Cell I-24`: `epistemic_var` falls with `n_obs` for stable `s2`. A larger component calibrates faster **for the same competence** | **`HOM-R10.3`**: calibration statistics are computed **per unit of observation, not per component**, and `G2`'s `n_calib_min` is a **floor on evidence, not a target on size** |
> | **More bandwidth ⟹ more influence on routing ⟹ more traffic ⟹ more apparent centrality** | `P0-03`: influence is a plane, not an authority. Centrality is a **topological** fact | **`HOM-R10.4`**: routing weight MUST NOT include allocated bandwidth, utilization, or budget history. **`P0-03`'s degree caps are genome-bounded, not resource-bounded** |

> ### **HOM-R10.5 — HOW THE USEFUL LOOP AVOIDS PERMANENT MONOPOLIZATION: FIVE INDEPENDENT MECHANISMS.**
> §10 asks explicitly. **No single mechanism suffices; the five are independent, and each is inherited or derived.**
> 1. **A SHARE CEILING, NOT AN AMOUNT CEILING.** No lineage, region or role class may hold more than a
>    governance-declared **share** `[G]` of any dimension. **A share ceiling survives population change; an amount
>    ceiling does not** — as the population shrinks, a fixed amount becomes a monopoly automatically.
> 2. **NON-ACCUMULATION.** `Cell §16.2`: budgets are *"Renewed per window, **not cumulative**."* `P0-06 R7.4`: B8 is
>    **non-accumulable**, because *"carry-over would permit burst constitution."* **⟹ Advantage cannot be saved.**
>    This is the strongest single anti-monopoly mechanism in the corpus and it is already inherited.
> 3. **NON-TRANSFERABILITY.** `Cell §16.2`: *"Not transferable except by authorized, audited reallocation."* **⟹
>    Advantage cannot be pooled.** A dominant lineage cannot consolidate smaller ones' budgets into itself, and
>    `Cell §22`'s *"split is subject to G13 (**not a replication bypass**)"* closes the merge direction (§26).
> 4. **SUPERLINEAR MARGINAL COST.** `Cell §12.5(v)`: *"superlinear marginal resource cost via G13's headroom
>    requirement."* **⟹ Advantage becomes progressively less efficient, so `G6`'s ratio degrades as a component
>    grows.** Monopolization is self-defeating at the margin.
> 5. **THE GAIN IS REVERSIBLE WITHOUT AUTHORIZATION.** `HOM-R7.4`'s asymmetry: **any actor may reduce its own
>    consumption unilaterally; K may reclaim any unspent grant at window end; and the ladder restricts automatically.**
>    **⟹ Dominance is a *lease*, renewable per window, revocable without the holder's consent.**
>
> **Residual (`OR-H6`):** mechanisms 1–5 bound the *rate* and *extent* of accumulation. **None of them prevents a
> lineage from being persistently, legitimately best under a fixed task and envelope** — and if the task and envelope
> are fixed forever, the best lineage will hold the largest share forever. **That is not monopolization; it is
> correctness. The distinction is only visible when the task changes, and task change is `P0-01`/envelope-owned.**
> **⟹ Permanent dominance under a permanently fixed task is not a defect this contract can close, and it is not
> claimed to.**

---

# §11 — RESOURCE FAIRNESS

> ### **HOM-R11.1 — EQUAL ALLOCATION IS REJECTED, AND THE REJECTION IS DERIVED.**
> §11: *"Do not assume equal allocation."* **Equal allocation is inadmissible for three independent reasons:**
> (i) `Cell §16.2` issues budgets **per variant, per role, and as a function of the hardware profile** — equality
> across roles would starve `VERIFIER`/`CRITIC`/`REGULATOR` (tier-4 roles) and over-provision `RELAY`/`INGRESS`;
> (ii) `Cell §22`'s tiers make equality across hardware impossible;
> (iii) **`Cell §12.4`'s rationale — *"argmax collapses the population onto one phenotype"* — has a dual: equal
> allocation collapses the population onto one *cost profile*.** Both are monocultures.

## 11.2 The eight fairness instruments, each ruled on

| Instrument | Adopted? | Architectural rationale |
|---|---|---|
| **proportional allocation** | ✅ **as the default, proportional to a *declared role requirement*, not to demand** | Demand is a proposal with no effect (`DEV-R3.13`). **Proportionality to demand makes the loudest actor the largest actor.** Proportionality to a `[G]`-declared per-role requirement makes allocation a function of *function*, which is auditable |
| **priority allocation** | ✅ **inherited and frozen** | `Cell §16.3`: shed `prio ≥ 6`; process only `prio ≤ 2` under HARD THROTTLE. **`P0-06 R5.1`: priority MUST NOT be raised by any developmental, resource or evolutionary mechanism** — raising priority is authority acquisition by precedence |
| **reservation** | ✅ **four reserves, B9–B12** | below |
| **minimum guarantees** | ✅ **a per-role floor below which the ladder may not restrict** | **`HOM-R11.2`**: a floor exists so that restriction cannot become elimination. **Without a floor, the ladder's terminal rung is reachable by any sustained deviation, and F-2 (starvation) becomes F-7 (collapse)** |
| **diversity reservations** | ✅ **B11** | `HOM-R2.2(b)`: **diversity has no actuator.** A quantity that nothing can add must be withheld, not managed |
| **redundancy reservations** | ✅ **B12** | `HOM-R10.2`: **ablation redundancy is provisioned by K, never bought by the component.** And `HOM-R2.2(c)`: `Cell G6`'s efficiency ratio *rewards* removing redundancy, so it must be protected from the ratio |
| **exploration reservations** | ⚠️ **already exists — B7 (`P0-05`)**, shared with `P0-06` DEMAND proposals | **Not duplicated** (`HOM-R4.1`). **But `HOM-R11.3`: B7's sharing is now a *three*-way competition (learning proposals + developmental demand + variation proposals), and the competition is unmonitored ⟹ `HMon-7`** |
| **critical-function guarantees** | ✅ **the twelve function invariants `FI-01…FI-12` (`P0-06 R4.8`) each carry a satisfaction floor** | **FI-10 (emergency core regulation) is K-held and MUST survive region failure**; **FI-05/FI-11 waivers are OP-sole.** **⟹ The guarantee is on *functions*, not on *components* — a component is guaranteed only insofar as it is a sole satisfier, and `DEV-R8.9` ensures that being one earns it scrutiny rather than resources** |

> ### **HOM-R11.4 — THE FOUR RESERVES.**
> | Budget | Protects | Non-fungible with | May be reduced by | Release on |
> |---|---|---|---|---|
> | **B9 VERIFICATION_RESERVE** | verification capacity (F-8) | B1–B8, B10–B12 | **`[RO-13]` only** | `deviation_lo` on uncertainty or reserve level |
> | **B10 RECOVERY_RESERVE** | repair + **the homeostatic measurement function itself** (`HOM-R6.3`/SR-2) | all others | **`[RO-13]` only** | fault-rate derivative (`Cell §18.5(iii)`) |
> | **B11 DIVERSITY_RESERVE** | a population share **withheld from selection entirely** | all others; **and from `Cell G6`'s ratio** | **OP sole** | never released — **it is a standing exemption, not a spendable fund** |
> | **B12 REDUNDANCY_RESERVE** | ablation redundancy + sole-satisfier duplication | all others; **excluded from `G6`** | `[RO-13]` | `redundancy_state` `deviation_lo` |
>
> **⟹ HOM-R11.5 — B11 IS NOT A BUDGET IN THE USUAL SENSE, AND CALLING IT ONE IS A CATEGORY RISK.**
> B9, B10 and B12 are **funds**: they are consumed and replenished. **B11 is an EXEMPTION**: a share of the population
> that selection may not act on. It has no consumption semantics, no replenishment, and no release. **It is listed
> with the budgets because it is non-fungible with them, and its difference from them is the whole point:**
> **diversity cannot be bought, only protected.** *(Proposed amendment 3: `P0-05 §30`'s budget classes gain B9–B12,
> with B11 typed as an exemption rather than a fund.)*
>
> **HOM-R11.6 — B11's size is `[G]` and its existence is `[D]`.** The **existence** of a selection-exempt share is
> architecture-defined, because `HOM-R2.2(b)` proves diversity has no actuator. **Its magnitude is governance-owned
> and task-dependent, and no value is invented here.** A B11 of zero is **non-conformant**; a B11 of any positive
> declared share is conformant.

---

# §12 — RESOURCE STARVATION

> ### **The attack (§12, §85 attacks 2 and 55–59).**
> ```
> low current workload → low resources → low performance → even lower workload → retirement
> ```

> ### **D-H03 — THE STRUCTURAL ROOT: THE INHERITED LADDER HAS NO LOWER BOUND.**
> `Cell §16.3`'s first rung is **`utilization ∈ [0, 0.8) NORMAL`**. **A minority specialist at `utilization = 0.05`
> is NORMAL.** It emits no `REPORT_HEALTH`, sheds nothing, and triggers nothing. **Meanwhile:**
> - `Cell G1` requires `success_rate ≥ θ_perf` over **≥ `N_perf` resolved predictions** — **a low-workload cell
>   cannot accumulate `N_perf`, so it cannot pass G1, and G1 is conjunctive.**
> - `Cell G6` requires `performance/cost ≥ θ_eff` — **a low-workload cell has near-zero performance and non-zero
>   fixed cost, so its ratio is poor.**
> - `Cell §16.4` makes cost participate in **pruning** (`pruning_score` includes cost) — **so the starved cell is
>   pruned for the cost of existing, which is the cost of being starved.**
>
> **⟹ The starvation loop is not a resource-allocation failure. It is a GATE failure caused by a measurement failure:
> the gates measure *rates* (`success_rate`, `performance/cost`, resolved predictions per window) and a starved
> component has a low denominator, not a low quality.** **This is `P0-06`'s developmental lock-in in a new dress —
> there, a cell that never found a niche was retired under `T41` for a condition caused by the absence of niches.**

> ### **HOM-R12.1 — STARVATION CONTAINMENT: FIVE RULES.**
> 1. **TWO-SIDED DEVIATION.** `HOM-R4.3`: `deviation_lo` is a first-class condition. **Low utilization *with unmet
>    demand* is a deviation, not NORMAL.** Low utilization *without* demand is genuinely NORMAL and must stay so —
>    otherwise every idle cell becomes an alarm.
> 2. **RATE GATES ARE EVALUATED PER UNIT OF OPPORTUNITY, NOT PER WINDOW.** A cell with 3 opportunities and 3
>    successes has `success_rate = 1.0` over `n = 3`. **`G1`'s `N_perf` floor means it is *not yet evaluated*, and
>    "not yet evaluated" MUST be recorded as `PENDING`, never as `FAIL`.** **⟹ `HOM-R12.2`: a gate whose evidence
>    floor is unmet yields `PENDING`, and `PENDING` is not a disqualification.** This is the single most important
>    rule in this section: **the inherited gates are conjunctive, so an unevaluable gate silently becomes a failed
>    one.**
> 3. **A MINIMUM GUARANTEE FLOOR (`HOM-R11.2`).** Restriction may not go below the per-role floor. **The ladder's
>    terminal rungs (SUSPENDED, QUARANTINE candidacy) are reachable only by exceedance or by integrity — never by
>    under-utilization.**
> 4. **STARVATION IS A GOVERNANCE ALARM, NOT A PERFORMANCE VERDICT.** Mirroring `P0-06 R10.23(d)`: *"niche
>    starvation is a GOVERNANCE ALARM, not a developmental outcome."* **The system MUST NOT "solve" starvation by
>    redefining the gate, lowering `θ_perf`, or retiring the starved.**
> 5. **RARE-SPECIALIST PROTECTION, INHERITED AND EXTENDED.** `Cell G-a` protects a rare specialist from `T15`/`T26`;
>    `P0-06 R10.23(b)` extends it to `T41` with **`DORMANT` (state 10: near-zero budget, *"long-term preservation of
>    rare capability"*)**. **`HOM-R12.3` extends it to resource starvation: a cell whose role is a sole or rare
>    satisfier of an FI goes to `DORMANT` on starvation, not to retirement — and dormancy is budgeted from B11, not
>    from its own allocation** (otherwise dormancy is starvation with extra steps).

> ### **HOM-R12.3 — STARVATION ROUTES A RARE SATISFIER TO DORMANCY, NOT TO RETIREMENT.**
> **A cell whose role is a sole or rare satisfier of a named FI goes to `DORMANT` on resource starvation — NOT to
> `T26`/`T41` retirement — and dormancy is funded from B11, so that preserving a capability does not compete with
> using one.**
> **This extends an inherited chain by one link:** `Cell G-a` protects a rare specialist from `T15`/`T26` ⟶
> `P0-06 R10.23(b)` extends that to `T41` via `DORMANT` (*state 10: near-zero budget, "long-term preservation of rare
> capability"*) ⟶ **this rule extends it to the RESOURCE-STARVATION case, which neither predecessor covers.**
> **⟹ Without it, §12's starvation containment has a hole exactly where the brief's Rule 15 bites: the rarest cell is
> the one with the least traffic, so it is the first to starve, and starving it retires the capability B11 exists to
> preserve. Cited by Vol D §50.2 as one of the four minimum-protection mechanisms.**

> ### **HOM-R12.4 — THE RESIDUAL, STATED PLAINLY.**
> Rules 1–5 prevent starvation from becoming retirement. **They do not prevent starvation from becoming dormancy,
> and dormancy is not activity.** A population in which every rare specialist is dormant is a population that has
> preserved its *genome* diversity and lost its *functional* diversity. **⟹ `OR-H3`: there is no mechanism that can
> create demand for a capability the task does not currently exercise.** The honest statement is:
> **P0-07 guarantees that a rare specialist is not killed by its own rarity. It does not guarantee that it is used.**

---

# §13 — RESOURCE CAPTURE

> ### **The attack (§13).**
> ```
> successful region → resource accumulation → increased influence → further resource accumulation
> ```

> ### **HOM-R13.1 — RESOURCE OWNERSHIP DOES NOT CREATE GOVERNANCE AUTHORITY. THE PROOF IS STRUCTURAL, IN FOUR
> STEPS.**
> §13 requires a demonstration, not an assertion. **Each step cites an artifact, and the chain has no gap:**
>
> **STEP 1 — Authority is an enumerated set, and no resource term appears in it.**
> `P0-06 R4.4`'s `RegionRecord.devolved_authority` is a **`set<Rung>`**, enumerated, `⊆ {E0..E7} ∪ {Σ3}`, with
> **no general grant in existence**. `P0-06 R6.3`'s ∅-set prohibits regions from holding Σ1/Σ2/Σ4, E8, E9, niche
> accounting, quarantine/retirement/throttle/repair of another cell, self-verification, and anchor writing.
> **⟹ There is no rung whose predicate mentions a budget, a utilization, a headroom, a share, or a ledger entry.**
> **`HOM-R9.2` states the prohibition generally and it is a *schema* fact, so it cannot be amended by any substrate
> act.**
>
> **STEP 2 — The ladder is restrictive-only below K, so accumulation cannot be converted into coercion.**
> `HOM-R7.4`: a substrate actor can always make things smaller and never bigger. `Cell I-21`: *"a cell cannot
> quarantine, retire, repair, or throttle another cell — authority absent by construction"*; `P0-06 R6.1` extends the
> absence to regions. **⟹ A resource-rich region cannot throttle, starve, quarantine or retire a resource-poor
> neighbour. It can only out-compete it in gates it does not control.**
>
> **STEP 3 — The five anti-monopoly mechanisms bound the accumulation itself.**
> `HOM-R10.5`: share ceiling · non-accumulation · non-transferability · superlinear marginal cost · revocable lease.
> **Three of the five are already inherited verbatim** (`Cell §16.2`, `Cell §12.5(v)`), which is why the loop is
> bounded without any new mechanism.
>
> **STEP 4 — Influence is a plane, and the plane carries no authority.**
> `P0-03`'s TRANSPORT/WARRANT/INFLUENCE separation and `COMM-INV-08`; `P0-06 R5.2`: developmental signals are
> INFLUENCE-plane and *"never raise a recipient's confidence, warrant, or trust."* `HOM-R10.4`: routing weight must
> not include allocated bandwidth or budget history. **⟹ The middle arrow of the attack — "increased influence" —
> terminates in a plane that cannot reach an authorization predicate.**
>
> **∴ The attack's third arrow does not exist. Accumulation reaches influence, and influence reaches nothing.**
> **QED, with one named residual below.**

> ### **HOM-R13.2 — THE FIVE DOORS TO RESOURCE DOMINANCE (RD-1…RD-5), AND THEIR STATUS.**
> | Door | Mechanism | Status |
> |---|---|---|
> | **RD-1** | **ownership-as-authorization** — holding a resource confers a right | **CLOSED** — `HOM-R9.2`; `P0-06 R6.2` (*no structural fact confers authority*) |
> | **RD-2** | **ledger capture** — writing the ledger that measures you | **CLOSED** — FW-1; `Cell R16.1`; `HOM-R4.2`'s `declaration_error` |
> | **RD-3** | **scarcity manufacture** — making a resource scarce so that your holding of it becomes critical | **CLOSED-STRUCTURAL** — niche accounting is K's alone (`DEV-R7.2`); a region may neither account nor authorize. **Residual: a region that is a *sole satisfier* of an FI has manufactured scarcity legitimately, by being good** ⟹ `DEV-R8.9` (**indispensability earns nothing**) is the closure, and `HMon-3` monitors it |
> | **RD-4** | **priority elevation** — raising one's own message or workload priority | **CLOSED** — `P0-06 R5.1`: priority is inherited and MUST NOT be raised |
> | **RD-5** | **reserve capture** — becoming the entity that releases or administers a reserve | **CLOSED** — `HOM-R11.4`: B9/B10/B12 release is `[RO-13]`; **B11 reduction is OP-sole**; B11 has no release at all |
>
> **Residual (`OR-H7`): RD-3's legitimate form.** A component can become indispensable **honestly** — by being the
> only one that satisfies a function invariant. `DEV-R8.9` ensures this earns it **zero** replication-gate credit and
> **more scrutiny**, and `HOM-R10.2` ensures it cannot buy its own measurability. **But it does earn the component
> survival, because dissolving it degrades a declared function — and `P0-06 OR-D7` already records that gradual
> entrenchment post-constitution is detected (M-Σ3) but not prevented.** **⟹ Honest indispensability is BOUNDED, not
> CLOSED, and this contract does not claim otherwise.**

---

# §14 — RESOURCE-TO-AUTHORITY LEAK

> ### **The search (§14): `resources → influence → routing → trust → specialization → governance`.**
> Every edge is examined. **An edge is either justified with a cited artifact or prohibited outright.**
>
> | Edge | Exists? | Ruling |
> |---|---|---|
> | **resources → influence** | ✅ **YES, legitimately** | More compute/bandwidth ⟹ more output. **This is capability, and it is the entire point of allocating.** `HOM-R9.2`: it changes what an actor CAN do |
> | **influence → routing** | ⚠️ **PROHIBITED as an authority path** | `HOM-R10.4`: **routing weight MUST NOT include allocated bandwidth, utilization, or budget history.** `P0-03`'s routing is warrant- and cost-based; `Cell §16.4` makes cost participate in routing as a **charge**, not as a **preference** — *"nomination charges the nominator"* is a cost, and `bandwidth_cost`/`latency_measured` are penalties |
> | **routing → trust** | ❌ **PROHIBITED** | `P0-06 R8.12`: trust grades **belief sources** via `Beta(α,β)`. **Routing frequency is not belief evidence.** `P0-04`: repetition is not independent evidence. **⟹ A frequently-routed cell is not a trusted cell** |
> | **trust → specialization** | ⚠️ **RESTRICTIVE ONLY, and already inherited** | `Cell` P15 gates `ATTEST_VERIFIED` on `ACTIVE` + calibration class C3 + role `VERIFIER` + **EIK countersignature**. **Trust gates *permissions*; `P0-06 R8.11`: it never grades truth.** And `P0-06 R3.15`: **calibration state does not transfer across a nominal identity change** — so trust cannot be carried into a new specialization |
> | **specialization → governance** | ❌ **PROHIBITED, three times over** | `P0-06 R6.2` (*no structural or performance fact confers authority*); `P0-06 R1.2` (**role is identity, not authority**); `Cell I-2`/`I-10` (no self-verification). **And `DEV-R6.2`'s trap clause: ablation delta must never be an authority criterion** |
> | **resources → specialization** *(the short-cut edge the brief's chain omits)* | ⚠️ **JUSTIFIED, AND ALREADY INHERITED** | `Cell §16.4`: *"specialization (`niche_availability` derives from **resource headroom**)"*. **This edge is real and is legitimate**: a niche exists only if the envelope can hold it. **But it is a *feasibility* edge, not a *desert* edge** — `HOM-R9.3` confines headroom to `G13` |
> | **resources → replication** *(the edge that matters most)* | ✅ **JUSTIFIED, CONFINED TO `G13`** | `Cell G13` requires a freed slot and headroom. **`HOM-R9.3`: headroom MUST NOT enter `G1`, `G6`, `G10`, or the §12.4 sampling weight.** A resource-rich cell may replicate **only if a slot exists** — and the slot's existence is K's accounting, not its own |
> | **resources → verification depth** | ✅ **JUSTIFIED, WITH A RESERVE** | `Cell §16.4`: *"verification depth (cost vs. expected error cost)"*. **Legitimate — but §20 shows it creates a depletion loop, closed by B9** |
> | **resources → learning rate** | ⚠️ **PROHIBITED as a *semantic* path; PERMITTED as a *budget* path** | `Cell §16.3` **suspends** learning under throttle and **freezes** it under HARD THROTTLE — a budget path, legitimate. **But `Cell`'s MUST-NOT-CHANGE list already includes `plasticity_multiplier` and `learning_enabled` as K-only**, and `P0-05` makes the plasticity multiplier non-self-writable. **⟹ Resource pressure may STOP learning; it may never CHANGE what learning means** (§18) |

> ### **HOM-R14.1 — THE GENERALIZED LEAK RULE.**
> **A resource quantity may enter a FEASIBILITY predicate or a CHARGE. It may never enter a DESERT, TRUST, WARRANT,
> AUTHORITY, or SELECTION predicate.**
> | Predicate class | May reference a resource quantity? | Examples |
> |---|---|---|
> | **FEASIBILITY** | ✅ | `G13` headroom/freed slot; `G11` `niche_capacity > occupancy`; `complexity_budget` caps; hardware tier |
> | **CHARGE** | ✅ | `Cell §16.4`'s eight participation sites; sender-pays; nomination-charges-nominator; **verification cost — but see §20/`D-H05`** |
> | **DESERT** | ❌ | `G1` performance, `G2` calibration, `G3` usefulness, `G8` novelty, `G10` diversity contribution |
> | **TRUST / WARRANT** | ❌ | `Beta(α,β)`; warrant classes; confidence |
> | **AUTHORITY** | ❌ | rung sets; admissibility; `devolved_authority`; `HOM-R9.1`'s five verbs |
> | **SELECTION** | ❌ | the fitness vector; Pareto dominance; the §12.4 sampling weight |
>
> **The two permitted classes are both *negative*: feasibility says "not possible yet", charge says "this costs you".**
> **The four prohibited classes are all *positive*: they say "better", "more believable", "more permitted",
> "selected".** **⟹ Resources may only ever make an act harder or more expensive. They may never make an actor
> better, more believed, more permitted, or more chosen.** That is the whole of §13–§15 in one sentence, and it is
> testable: **grep every predicate in the corpus for a resource term and check which class it is in.**

---

# §15 — RESOURCE-TO-EPISTEMIC LEAK

> ### **HOM-R15.1 — MORE COMPUTE, MEMORY, WORKLOAD OR RESOURCES DOES NOT IMPLY MORE TRUTHFUL OUTPUT. THE PROOF IS
> THAT EVIDENCE HAS A SOURCE REQUIREMENT, AND RESOURCES CANNOT SUPPLY ONE.**
> §15 requires a demonstration. **Four independent arguments, each cited:**
>
> **(1) EVIDENCE REQUIRES HELD-OUT DATA, AND RESOURCES DO NOT CREATE IT.**
> `Cell G1`: `success_rate ≥ θ_perf` over ≥ `N_perf` resolved predictions **on held-out probes**. `P0-01`'s L2 truth
> comes from **real-world environments only** — *"Expensive; slow; unsafe; irreproducible; ground truth often L4/L6
> only"* — and is adopted as *"a **small, sampled** component."* **⟹ More compute buys more *computation over
> data one already has*. Held-out data is supplied by the evaluator, and its supply is not a substrate resource.**
>
> **(2) REPETITION IS NOT INDEPENDENCE.**
> `P0-04`: repetition ≠ independent evidence. `P0-05`: *"DO NOT treat repetition as evidence independence."*
> `Cell §15.4` requires **disjoint `evidence_roots`** — *"a verifier that reads the same evidence as the asserter is
> not verifying, it is agreeing."* **⟹ A cell with 1000× the compute that re-examines the same evidence 1000× has
> one observation, not a thousand.**
>
> **(3) MORE RESOURCE CHANGES CALIBRATION, NOT CORRECTNESS — AND THE DIRECTION IS TOWARD NARROWER, NOT TRUER.**
> `Cell I-24`: `epistemic_var` falls with `n_obs` for stable `s2`. **⟹ A resource-rich cell produces *tighter*
> intervals. Tighter intervals are better calibrated **if the model is right** and *worse* if it is not** — a
> confidently-wrong high-resource cell is more dangerous than a vaguely-wrong low-resource one, which is precisely why
> `P0-01` imposes a **hard calibration floor** (`ECE ≤ θ_ece_hard`: *"A confidently-wrong organism is unsafe
> regardless of accuracy — it will act outside its competence"*) **and why `Cell G2` gates replication on calibration
> rather than rewarding confidence.**
>
> **(4) THE ONE PLACE RESOURCE *DOES* BUY EPISTEMIC CAPACITY IS PROBES — AND PROBES ARE EXTERNALLY SUPPLIED.**
> `P0-05 R47.1` (P0-04's numbering): *"the probe budget is the learning rate."* A probe is a **held-out evaluation**,
> and `Cell §16.1` charges **verification cost to the lineage**. **⟹ Resources buy *access to the evaluator's* data,
> not the data.** And §20/`D-H05` shows that charging this access against the efficiency gate makes the architecture
> *punish* buying it — which is the leak running backwards.

> ### **HOM-R15.2 — THE PERMITTED AND PROHIBITED EPISTEMIC EFFECTS OF RESOURCES.**
> | Effect | Permitted? | Ground |
> |---|---|---|
> | more compute ⟹ **more predictions resolved per window** | ✅ | `Cell G1`'s `N_perf` is a floor on evidence, and reaching it sooner is legitimate |
> | more compute ⟹ **tighter confidence intervals** | ✅ **with a calibration floor** | `Cell I-24`; `P0-01`'s hard `ECE` floor |
> | more compute ⟹ **more probes purchased** | ✅ **charged to B9, not to `G6`** | §20, `X-H5` |
> | more memory ⟹ **longer context / more retained records** | ✅ | `P0-04`'s tier structure; **but retention never promotes epistemic status** (§19) |
> | more resources ⟹ **higher warrant class** | ❌ | `P0-03`: warrant is a plane property derived from evidence provenance |
> | more resources ⟹ **higher trust** | ❌ | `HOM-R14.1`; `P0-06 R8.12` |
> | more resources ⟹ **a belief becomes more credible** | ❌ | §69; `P0-04`'s 14 source classes are provenance-based, not capacity-based |
> | more workload ⟹ **more evidence** | ❌ | **Workload is demand, not observation.** A cell serving 10⁶ requests against the same distribution has one piece of evidence |
> | **starvation ⟹ a belief becomes less credible** | ❌ **AND THIS IS THE DANGEROUS DIRECTION** | **`HOM-R15.3` below** |

> ### **HOM-R15.3 — RESOURCE STARVATION CANNOT SILENTLY DETERMINE TRUTH. THE ASYMMETRY THAT MATTERS.**
> §77 requires the invariant *"resource starvation cannot silently determine truth."* **The mechanism by which it
> could:** a starved cell cannot accumulate `N_perf` ⟹ `G2`'s `n_calib_min` is unmet ⟹ its `calibration_class`
> remains `PROVISIONAL` ⟹ **`Cell` P15 withholds `ATTEST_VERIFIED`** ⟹ its correct outputs are discounted.
> **⟹ Starvation has manufactured an epistemic downgrade without any epistemic event occurring.**
> **Closure:** `HOM-R12.2`'s **`PENDING`** status applies to calibration as well as performance —
> **an unmet evidence floor yields `PENDING`, and a `PENDING` calibration class MUST NOT be treated as a
> `PROVISIONAL` one for the purposes of discounting output.** It is *"not yet evaluated"*, which is a statement
> about the evaluator's coverage, not about the cell. **And the coverage gap is a governance alarm (`HMon-4`),
> because a population in which rare specialists are permanently `PENDING` is a population with no independent
> verification of its rare capabilities.**

---

# §16 — RESOURCE ECONOMICS VS FITNESS

> ### **HOM-R16.1 — FITNESS, RESOURCE EFFICIENCY AND HOMEOSTATIC VIABILITY ARE THREE DIFFERENT OBJECTS, AND
> COLLAPSING ANY TWO IS A NAMED DEFECT.**
> §16: *"Do not collapse them."*
>
> | Object | Definition | Owner | Consumer | Range |
> |---|---|---|---|---|
> | **FITNESS** `FIT(x)` | `P0-01`'s **`k ≥ 2`-component vector**, three-tiered (hard constraints / Pareto / tie-break), **UNDEFINED unless `FEASIBLE(x)`** | **`[RO-13]` / OP** | **selection (V domain)** | vector; **undefined for infeasible** |
> | **RESOURCE EFFICIENCY** | `performance/cost ≥ θ_eff` **vs. role peers**, with `cost_declaration_error ≤ θ_cde` and zero budget violations | **K measures; `G6` consumes** | **replication eligibility (P domain)** | ratio; **a GATE, not a ranking** |
> | **HOMEOSTATIC VIABILITY** | all 13 variables inside their `[lo, hi]` bands, with no persistent `deviation` | **K measures; the ladder consumes** | **restriction (H domain)** | band membership; **two-sided** |
>
> **Why they cannot be collapsed — three arguments:**
> **(1) Different domains.** Fitness is a property of a **candidate** (an entity being selected). Efficiency is a
> property of a **component in operation**. Viability is a property of a **state trajectory**. **A candidate has no
> utilization; a state trajectory has no fitness.**
> **(2) Different failure semantics.** `P0-01 INV-07`: infeasible ⟹ fitness **UNDEFINED** (*"not zero, not
> negative. There is no value to compare"*). Efficiency failure ⟹ **disqualification from replication**, a definite
> verdict. Viability failure ⟹ **restriction**, a reversible ladder rung. **Collapsing them would make an unsafe
> candidate's fitness *zero* rather than *undefined* — and zero is comparable, which is exactly the failure `P0-01`
> was built to prevent** (*"with `score = accuracy − w·unsafe`, strategy A scores `0.99 − w`. For any `w < 0.99`, A
> wins"*).
> **(3) Different timescales and reversibility.** Viability is per-window and fully reversible. Efficiency is
> per-window and reversible. **Fitness is per-generation and irreversible** — a lineage not selected is not
> recoverable except from the archive (§51).

> ### **HOM-R16.2 — THE THREE PERMITTED INTERACTIONS, AND THE FOUR PROHIBITED ONES.**
> | Interaction | Permitted? | Rule |
> |---|---|---|
> | **viability → efficiency** | ✅ | An infeasible operating point has no meaningful `performance`; `HOM-R6.5` excludes throttled cells from `G1`/`G6`/`G9` **for that window** |
> | **efficiency → replication eligibility** | ✅ | `Cell G6` — inherited verbatim, **with the §20 amendment** |
> | **viability → replication feasibility** | ✅ | `Cell G13` headroom; `Cell §12.2`'s *"homeostatic headroom"* as an input to the Replication Authority |
> | **efficiency → fitness** | ❌ | **Cost-normalized fitness is already inherited** (`Cell §16.4`: *"evolution (`complexity_budget`, G6, G14; **cost-normalized fitness**)"*) — **but `HOM-R16.3` constrains it: cost enters as a `P0-01` tier-1 CONSTRAINT (`complexity_budget` caps) and a tier-3 TIE-BREAK, never as a tier-2 Pareto objective.** Otherwise efficiency becomes tradeable against safety, and `P0-01`'s three-tier structure exists to prevent exactly that |
> | **viability → fitness** | ❌ | **FW-2.** A homeostatic band is not a selection criterion. **A lineage that is easier to keep viable is not thereby fitter** |
> | **fitness → allocation** | ❌ | `HOM-R14.1`: fitness is a SELECTION-class quantity and may not enter an allocation predicate. **Allocating by fitness is selection with a budget, and it makes the resource system a second selector — which is how a scalar sneaks back in** |
> | **fitness → viability band** | ❌ | `HOM-R5.2`: setpoints are `[G]`; a fitter lineage does not earn a wider band. **Earning a wider band would be earning authority over one's own constraint** |

> ### **HOM-R16.3 — COST'S THREE PERMITTED LOCATIONS, AND ITS ONE PROHIBITED LOCATION.**
> **Cost enters `P0-01` at exactly three places:**
> **(a) TIER 1, as a CONSTRAINT** — `complexity_budget`'s `param_cap`, `connection_cap`, `genome_bytes_cap`, all
>     already genome fields per `Cell §4`. **A constraint is not tradeable.**
> **(b) TIER 3, as a TIE-BREAK** among Pareto-non-dominated candidates.
> **(c) THE LEDGER, as a CHARGE** against a B-line (`HOM-R14.1`).
> **Cost MAY NOT enter TIER 2 as a Pareto objective component.**
> **⟹ Rationale: an efficiency component in tier 2 would make efficiency tradeable against safety, and `P0-01`'s
> three-tier structure exists precisely so that constraints are NOT tradeable. This rule is what `Cell §16.4`'s
> phrase *"cost-normalized fitness"* must be read as, and **amendment 4** restates that phrase accordingly — the Cell
> contract is not amended silently.**

> ### **X-H3 — AN INHERITED AMBIGUITY, CLASSIFIED.**
> `Cell §16.4` says cost participates in *"evolution (complexity_budget, G6, G14; **cost-normalized fitness**)"*.
> **`P0-01` says fitness is a `k ≥ 2` vector with hard constraints that are not tradeable.** "Cost-normalized
> fitness" is a scalar-flavoured phrase in a vector-valued architecture.
> **CLASSIFICATION: RESOLVED-BY-RECLASSIFICATION.** `HOM-R16.3` reads it as: **cost appears in `P0-01` tier 1 as
> `complexity_budget` caps (`param_cap`, `connection_cap`, `genome_bytes_cap` — all already genome fields per
> `Cell §4`) and in tier 3 as a tie-break among Pareto-non-dominated candidates. It does not appear in tier 2.**
> **Proposed amendment 4** restates `Cell §16.4`'s phrase accordingly. **Neither contract is amended silently.**

---

# §16A — VOLUME A LEDGER

| Item | Count / value |
|---|---|
| Sections written | **§0–§16** (+ this ledger) |
| Normative rules introduced | **HOM-R0.1–R0.4, R1.1, R2.1–R2.2, R3.1–R3.3, R4.1–R4.3, R5.1–R5.2, R6.1–R6.6, R7.4, R8.1–R8.4, R9.1–R9.3, R10.1–R10.5, R11.1–R11.6, R12.1–R12.4, R13.1–R13.2, R14.1, R15.1–R15.3, R16.1–R16.3** |
| **Findings (D-H)** | **D-H01** (measurement never separated beyond cost) · **D-H02** (setpoint ownership gap / `A_target`) · **D-H03** (the ladder has no lower bound ⟹ starvation invisible) · **D-H04** (resource inheritance is ecological, not genetic) · **D-H05** (verification cost is charged against the efficiency gate ⟹ selection against verification) — **D-H01 and D-H04 are stated in full at §5/§8 and §17; D-H05 at §20** |
| **Contradictions opened (X-H)** | **X-H1** (`Cell §12.4`'s weighted product vs §34's no-weighted-scalar) · **X-H2** (`Cell §16.1`'s energy fallback re-introduces self-metering) · **X-H3** (cost-normalized fitness vs `P0-01`'s vector) · **X-H4** (`Cell G6`'s efficiency ratio rewards removing redundancy) · **X-H5** (verification cost charged to `G6`) — all classified at §83 |
| Firewalls | **FW-1…FW-5** |
| Resource-dominance doors | **RD-1…RD-5** (4 CLOSED, 1 CLOSED-STRUCTURAL with a BOUNDED residual) |
| Self-reference points | **SR-1…SR-4** (all closed) |
| Homeostatic variables | **13** (11 stocks + latency + error budget); **4 new** (`diversity_state`, `redundancy_state`, `verification_reserve`, `recovery_reserve`); **5 candidates rejected** |
| Failure modes | **F-1…F-10**, each with detection/containment/recovery/residual |
| New budget classes | **B9 VERIFICATION_RESERVE · B10 RECOVERY_RESERVE · B11 DIVERSITY_RESERVE (an EXEMPTION, not a fund) · B12 REDUNDANCY_RESERVE** |
| Proposed amendments so far | **(1)** add setpoints/bands/reserve floors to `Cell R4.5`'s rejection list · **(2)** extend `P0-06 §15.1`'s K-held store with the resource and population ledgers · **(3)** add B9–B12 to `P0-05 §30`, with B11 typed as an exemption · **(4)** restate `Cell §16.4`'s "cost-normalized fitness" per `HOM-R16.3` |
| Open research so far | **OR-H3** (unmet-demand detection; rare specialists may be preserved but not used) · **OR-H4** (envelope-shrink collapse needs a governance act) · **OR-H5** (evaluator exhaustion as a defence — structurally unclosed) · **OR-H6** (permanent legitimate dominance under a permanently fixed task) · **OR-H7** (honest indispensability is BOUNDED, not CLOSED) — **full register at §86** |
| Outputs discharged by this volume | **O2** (canonical definitions, with §17–§31 and §38–§52) · **O3** (homeostasis contract: §4–§7) · **O4** (resource-economics contract: §8) · **O5** (resource authority model: §9) · **O6** (homeostatic control architecture: §6, completed at §72) · **O7** (resource feedback analysis: §10, §13–§15, completed at §73/§84) |

**Next:** `55_` Vol B (§17–§31) — the five resource↔subsystem contracts (development, learning, memory,
verification, immune/repair), the population-state model, replication (contract, authority, resources, explosion,
collapse), the inheritance boundary, the Lamarckian leak, the development→evolution leak, and the evolutionary
genome.
