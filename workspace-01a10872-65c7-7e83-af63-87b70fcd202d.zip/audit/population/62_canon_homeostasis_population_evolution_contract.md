# V4 — HOMEOSTASIS, RESOURCE ECONOMICS, POPULATION DYNAMICS & EVOLUTION CONTRACT v1.0
## P0-07 CANONICAL SPECIFICATION (Output **O59**) — SELF-CONTAINED

**Status:** PROPOSED v1.0 · **architecture only, no implementation** · **79 canon clauses (`HOM-C0.1 … HOM-C17.1`) restating and citing 312 volume rules (`HOM-R0.1 … HOM-R95.3`)** · **45 invariants** · **21 machine IDs (20 distinct, 15 new)** · **62 registered parameters** · **93 catalogued attacks (A79–A171)** · **26 open research entries** · **14 proposed amendments (none applied)**
**Justification layer:** `54_` Vol A (§0–§16) · `55_` Vol B (§17–§31) · `56_` Vol C (§32–§41) · `57_` Vol D (§42–§52) · `58_` Vol E (§53–§64) · `59_` Vol F (§65–§76) · `60_` Vol G (§77–§84) · `61_` Vol H (§85–§86).
**This document is normative and readable alone. Where it states a rule without proof, the proof is in the volume named beside it.**

> ## **ID CONVENTION — READ THIS FIRST.**
> **`HOM-Cn.m`** = a **canon clause**, defined here, numbered by **PART** (Part 0 → `HOM-C0.m`; Part XII → `HOM-C12.m`).
> **`HOM-Rn.m`** = a **volume rule**, defined in Volumes A–H, numbered by **SECTION** (§65 → `HOM-R65.m`). Always in
> backticks when cited.
> **The two prefixes are disjoint by construction.** An earlier draft of this canon numbered its own clauses `HOM-Rn.m`,
> which collided with the volume rules — `HOM-R12.2` denoted both *"state machines"* (canon Part XII, as that clause then read) and
> *"`PENDING` ≠ FAIL"* (Vol A §12). **A specification in which one ID denotes two rules is not a specification.** The
> canon's clauses were therefore renumbered `HOM-C`, and every `HOM-R` reference in this document is a citation of a
> volume rule. **312 distinct volume-rule IDs (§0–§95; §87 carries no rules and is declared unused) and 79 canon
> clauses, no overlap, zero phantom citations — machine-verified (§89 of the README).**

---

# PART 0 — STATUS, SCOPE, AND THE PRIMARY OBJECTIVE

> ## **HOM-C0.1 — WHAT THIS CONTRACT IS.**
> A specification of the **population domain** of the V4 architecture: how a population of cells is kept viable
> (homeostasis), fed (resource economics), sized and turned over (population dynamics), reproduced and retired, kept
> diverse, and selected — **and how all of that occurs without evolution acquiring authority over the safety and
> governance substrate.**
> **It is not an implementation, not a simulation design, and not a claim that any of this produces intelligence,
> AGI, consciousness, or optimality.**

> ## **HOM-C0.2 — THE §0 PRIMARY OBJECTIVE, ANSWERED.**
> **Question: do homeostasis, resource economics, population dynamics, replication, retirement, diversity management,
> evolutionary selection, and cross-generation inheritance form ONE coherent contract — or must some be separate?**
>
> ### **ANSWER: YES — ONE CONTRACT. All eight belong together. None is separated.**
>
> **The proof is a shared-object argument, not a topical one.** The eight topics are not eight subjects; they are
> **eight views of four objects**, and no view can be specified without the other three:
>
> | Shared object | Written by | Read by | Why separation fails |
> |---|---|---|---|
> | **1. THE ENVELOPE** (the finite capacity that bounds everything) | OP | homeostasis, resources, population, replication, retirement, diversity, selection | A resource contract without the envelope has no conservation law. A population contract without it has no cap. A selection contract without it has no feasibility tier |
> | **2. THE LEDGER** (what is held, by whom, charged to what) | **K only** | all eight | Replication is a ledger transaction. Retirement is a ledger reversal. Diversity is a ledger statistic. Selection consumes ledger-funded evaluation. **One writer, eight readers — separating the readers would create eight writers** |
> | **3. THE GENOME ARTIFACT** (the only heritable object) | **K only**, on an EIK-authorized ticket | variation, inheritance, replication, retirement, provenance | Inheritance *is* the genome. Variation *targets* the genome. Retirement *freezes* a genome into the archive. Selection *chooses between* genomes |
> | **4. THE GENERATION BOUNDARY** (the heritable-store write) | **K only** | all eight | `HOM-R30.1`: **the boundary is a WRITE, not a birth.** Everything on one side is within a generation; everything that crosses is inheritance. **A contract that did not own the boundary could not state its own scope** |
>
> **⟹ The split test applied:** a topic must be separated only if it has (a) a different writer, (b) a different
> timescale, or (c) a different authority root. **All eight share writer K, timescale "window/epoch", and authority
> root `[RO-13]`/OP.** None meets the test. **This is the smallest sufficient grouping (brief Rule 17), and it is
> smaller than the alternative: separating them would require at least three contracts and would duplicate the ledger,
> the envelope, and the boundary in each.**
>
> ### **THE ONE INTERNAL SPLIT THAT IS NECESSARY — AND IT IS A SPLIT OF DOMAINS, NOT OF CONTRACTS.**
> The eight topics occupy **three domains** with different epistemic status, and conflating them is the source of most
> of the failures this contract prevents:
> | Domain | Contents | May it prefer? | May it authorize? |
> |---|---|---|---|
> | **H — HOMEOSTATIC** | the 13 variables, their bands, the ladder, the reserves | ❌ **NEVER** (`HOM-INV-16`) | ❌ only restrictively (`HOM-INV-09`) |
> | **P — POPULATIONAL** | the ledger, population state, replication, retirement, lineage, cohort, archive | ❌ | ⚠️ only through EIK/`[RO-13]`/OP |
> | **V — VARIATION/SELECTION** | variation operators, sandbox, tiers, Pareto, diversity filter, lottery | ⚠️ **it ranks — but it does not prefer on homeostatic or resource grounds** | ❌ |
> **⟹ The three domains are separated by TWO FIREWALLS (FW-1, FW-2) inside one contract. That is the necessary split,
> and it is a split of *roles*, not of *documents*.**

> ## **HOM-C0.3 — THE FIVE FIREWALLS.**
> | ID | Separation | What it prevents | Rules |
> |---|---|---|---|
> | **FW-1** | **MEASUREMENT separated from the MEASURED** | the meter being the metered; self-report as fact | `HOM-INV-05`, `Cell R16.1`, `HOM-R4.2` |
> | **FW-2** | **HOMEOSTASIS separated from SELECTION** | a homeostat that prefers; a band that ranks | **`HOM-INV-16`**, `HOM-R65.3`, `HOM-R16.2` |
> | **FW-3** | **QUARANTINE separated from RETIREMENT** | a reversible immune state becoming a permanent evolutionary verdict | **`HOM-INV-39`**, `HOM-R21.4` |
> | **FW-4** | **DIVERSITY RESERVATION separated from FITNESS MEASUREMENT** | the diversity tax becoming tradeable | **`HOM-INV-30`**, `HOM-R37.2`; `P0-01`: *"Constraints become tradeable weights ⇒ A8 unsafe genius wins"* |
> | **FW-5** | **the ARCHIVE separated from MEMORY and from EVIDENCE** | extinction records becoming heritable belief or variation input | **`HOM-INV-45`**, `HOM-R51.2(a)–(c)` |

> ## **HOM-C0.4 — WHAT DOES NOT EXIST.**
> **There is no evolutionary controller. There is no homeostatic layer with authority. There is no global optimizer.
> There is no population solver. There is no fitness scalar. There is no age. There is no ancestor with rights.**
> A mechanism that can only say **"no"**, **"not yet"**, or **"one of these, at random"** is not a controller.
> **`HOM-R73.2`: the population program is a SPECIFICATION OF ADMISSIBILITY. It has NO SOLVER and MUST NOT have one.**

---

# PART I — THE THIRTEEN HOMEOSTATIC VARIABLES AND THEIR SETPOINTS

> ## **HOM-C1.1 — THE 13 VARIABLES.** *(Vol A §4–§5)*
> **compute · memory · bandwidth · storage · energy · latency · population · density · diversity · redundancy ·
> developmental capacity · verification capacity · recovery capacity.**
> **The brief's additional candidates were examined and ruled as follows:**
> | Candidate | Ruling |
> |---|---|
> | **exploration budget** | **NOT a 14th variable — it is a BUDGET (B7), partitioned into three non-fungible floors** (`HOM-R47.2`). A budget is allocatable; a homeostatic variable is measured against a band. Conflating them would let exploration be traded for compute |
> | **evaluator capacity** | **NOT a variable — it is EXTERNAL** (`P-52`, `[E]`). Its absence `ABORTS` a selection round; it is not homeostatically regulated, because the organism has no actuator over it (`HOM-INV-41`) |
> | **provenance capacity** | **NOT a variable — it is a BUDGET (B12)**, non-fungible and last-cut (`HOM-INV-07`) |
> | **replication capacity** | **NOT a variable — it is `RATE_CAP` + `G13` headroom**, i.e. a governance cap and a ledger fact (`HOM-INV-02`, `-01`) |
> | **recovery capacity** | ✅ **ADDED as the 13th variable**, funded by B10 |
> **⟹ 13 variables, no more. Every candidate for a 14th is either a budget, an external quantity, or a cap — and each
> of those has a different writer, which is why it must not be a homeostatic variable.**

> ## **HOM-C1.2 — SETPOINT AUTHORITY: MEASUREMENT IS SEPARATED FROM SETPOINT AUTHORITY.** *(D-H02, amendment 1)*
> **For every one of the 13 variables, the writer of the MEASUREMENT and the writer of the SETPOINT are different
> entities.**
> | Setpoint class | Variables | Writer |
> |---|---|---|
> | **`[G]`** | population, density, diversity, redundancy, compute, memory, bandwidth, storage | **`[RO-13]`** |
> | **`[E]`** | latency, energy (device-relative) | **envelope declaration, per deployment class** (amendment 13) |
> | **`[H]`** | developmental capacity, verification capacity, recovery capacity | **this contract's semantics; the values are `[G]`-declared floors** |
> **NO SETPOINT IS GENOME-REACHABLE (`HOM-INV-10`).** A genome diff that would alter a band, a setpoint, a threshold,
> or a rung definition is rejected at E9.
> **⟹ Attack A146 (M-4 target relocation) is closed by this rule alone, and Vol E identified it as the most dangerous
> of the four homeostasis attacks: three gates reward it and none detect it.**

> ## **HOM-C1.3 — DEVIATION IS TWO-SIDED, AND THE TWO SIDES ARE NOT SYMMETRIC.** *(D-H03, `HOM-R7.4`)*
> **EXCESS** ⟹ **restrict** (self-limiting; the ladder may rest once the excess is removed).
> **DEFICIT** ⟹ **escalate** — and **if the deficit has removed the actuator capable of correcting it, the machine has
> NO RESTING STATE**: it transitions to `ESCALATE-OUT` ⟹ `[RO-13]` (`HOM-INV-11`).
> **Rationale: over-restriction costs throughput and reverses next window. Under-restriction can consume a reserve,
> and three of the four reserves have no local actuator that can restore them.**

> ## **HOM-C1.4 — UNEVALUABILITY IS NOT FAILURE.** *(D-H03, `HOM-R12.2`)*
> **`PENDING` ≠ `FAIL`.** A candidate or component that cannot be measured or evaluated is `PENDING`, and `PENDING`
> confers **no fitness value, no ranking position, and no disqualification** (`HOM-INV-12`).
> A `PENDING` state that exceeds its maximum dwell becomes **`INELIGIBLE-UNVERIFIABLE`** — a state **distinct from**
> `INELIGIBLE-GATE` and from `DISQUALIFIED` (`HOM-INV-13`).
> **⟹ This single rule closes A97 (verification avoidance) two-sidedly: unverifiability yields neither a pass nor a
> fail. And it closes A104/A105 (minority-specialist starvation and its invisibility), which is the brief's §8.3
> requirement.**

> ## **HOM-C1.5 — THE LADDER IS RESTRICTIVE-ONLY, RATE-LIMITED, HYSTERETIC, AND STALENESS-CONSERVATIVE.**
> **(a) RESTRICTIVE-ONLY:** every rung below K **removes** capacity; none adds it (`HOM-INV-09`).
> **(b) RATE-LIMITED:** one rung transition per interval (`HOM-INV-15`).
> **(c) HYSTERETIC:** the exit criterion is **strictly inside** the entry criterion; every rung has a maximum dwell.
> **(d) NEVER SKIP UPWARD.**
> **(e) STALENESS-CONSERVATIVE:** under measurement staleness, default to the **more restrictive** rung
> (`HOM-INV-14`). A missing measurement goes `STALE → INVALID → UNMEASURED → PENDING`, **never to `NOMINAL`** — which
> closes A144 (measurement suppression) at the cost of capacity, the correct price.

> ## **HOM-C1.6 — HOMEOSTATIC FAILURE MODES AND THEIR CLOSURES.** *(Vol A §7)*
> | Failure mode | Closure |
> |---|---|
> | **oscillation** | rate limit + hysteresis + max dwell (`HOM-R1.5b–d`) |
> | **integral windup / accumulated error** | **no integral term exists** — the ladder is a discrete restrictive sequence, not a PID controller |
> | **actuator saturation** | `ACTUATOR-EXHAUSTED` ⟹ `[RO-13]` (a governance escape, not a rest state) |
> | **sensor failure** | `HOM-INV-14` staleness-conservatism + FW-1 independent metering |
> | **setpoint drift** | `HOM-INV-10`: setpoints are `[G]`/`[E]`/`[H]`, never genome-reachable |
> | **cascade** | derivative-cascade detection (`Cell §18.5(iii)`) + B10 + `Cell §17`'s cap-and-degraded-mode |
> | **homeostat becomes selector** | **FW-2 / `HOM-INV-16`**, audited by `HMon-10` |

---

# PART II — RESOURCE ECONOMICS

> ## **HOM-C2.1 — ACCOUNTING EXISTS ONLY WHERE MEASURABLE ARCHITECTURAL STATE EXISTS.** *(Vol A §8)*
> **The ledger has 13 dimensions, one per homeostatic variable, and NO OTHERS.** A quantity that is not
> K-meterable is **not accounted**, and a quantity that is not accounted **cannot be allocated, charged, or used as a
> gate input.**
> **A quantity computed from an entity's own report is flagged `DERIVED` and MAY NOT be the sole basis for a `G6`
> pass (`HOM-INV-06`, amendment 12).**

> ## **HOM-C2.2 — THE FIVE RESOURCE AUTHORITY CLASSES.** *(Vol A §9)*
> | Class | Who | Scope |
> |---|---|---|
> | **REQUEST** | any component | a proposal with no effect and no budget beyond B7 |
> | **RECOMMEND** | any component, region | advisory; **`Ê(·)` is excluded from every gate** (`HOM-R24.2`) |
> | **ALLOCATE** | **K only** | per-window budgets (`Cell §16.2`); reserves are **NOT allocatable in a window** |
> | **AUTHORIZE** | **EIK** (replication) · **`[RO-13]`** (ceilings, caps, reserves B9/B10/B12) · **OP** (B11, envelopes, FI sole satisfiers) | |
> | **OVERRIDE** | **K** (suspend the ladder) · **OP** (sole, above the quarantine cap — `Cell §17`) | |
> **⟹ No substrate actor (cell, circuit, region, immune) holds ALLOCATE, AUTHORIZE, or OVERRIDE. Fifteen operations
> are denied to all of them (§76's ∅-set).**

> ## **HOM-C2.3 — RESOURCES ENTER FEASIBILITY AND CHARGE. THEY NEVER ENTER THE OBJECTIVE.** *(X-H3 resolution)*
> **`HOM-R14.1`: a resource quantity may make a candidate INFEASIBLE (tier-1) or CHARGE its budget (a B-line). It may
> NOT appear as a component of the fitness/objective vector.** The vector has **13 `[RO-13]`-declared components**;
> adding a 14th is a governance act, and no resource quantity is one.

> ## **HOM-C2.4 — THE FOUR RESERVES.** *(Vol A §10; amendments 3, 5)*
> | Reserve | Purpose | Reducible by | Property |
> |---|---|---|---|
> | **B9** | **verification** | `[RO-13]` | **non-fungible, last-cut, first-restored.** Verification cost is charged here and **EXCLUDED from `G6`** (`HOM-R20.1`, X-H5) |
> | **B10** | **repair / recovery** | `[RO-13]` | non-fungible, last-cut. **Funds K's own measurement function — and B10 is FINITE (`OR-H1`, HC-12/SR-2)** |
> | **B11** | **diversity exemption** | **OP ONLY** (`HOM-INV-08`) | a declared **share of the population removed from selection pressure**. **It is a GOVERNANCE object, not an entitlement — nothing holds it, so it cannot be captured (X-H8, A108)** |
> | **B12** | **provenance / archive** | `[RO-13]` | non-fungible, last-cut. **A candidate whose provenance cannot be funded is INFEASIBLE and is not instantiated at all (`HOM-R17.2`) — which closes A158 by self-exclusion** |

> ## **HOM-C2.5 — FAIRNESS IS NOT EQUALITY, AND THE MECHANISM IS A FLOOR PLUS AN EXEMPTION.** *(Vol A §11)*
> **Equal shares are prohibited** (they would starve a component whose function is expensive).
> **What exists instead:** (a) a **minimum guarantee floor** per component, below which allocation may not go;
> (b) **B11's exempt share**, which removes a declared fraction from selection pressure entirely;
> (c) **`Ne`-based diversity accounting**, which makes a rare lineage count as much as a common one
> (`HOM-INV-17`).
> **⟹ Fairness here is: no component may be allocated below its floor, and no lineage may be priced out of existence
> by a cost it did not choose. It is NOT: every component gets the same.**

> ## **HOM-C2.6 — DOMINANCE, CAPTURE, AND THE TWO LEAKS.** *(Vol A §12–§15)*
> **(a) DOMINANCE FEEDBACK** — `HC-1` is **BROKEN by writer separation**: the cell produces outputs, **K meters
> them**, and the cell writes no measurement. Bounded additionally by the share ceiling (`HOM-INV-19`) and
> non-accumulation. **Residual `OR-H6`/`OR-H20`: LEGITIMATE dominance under a permanently fixed task is not bounded,
> and bounding it would mean bounding competence.**
> **(b) RESOURCE CAPTURE** — closed by `HOM-INV-19` + `HOM-INV-29` (selection confers no authority).
> **(c) RESOURCE → AUTHORITY LEAK** — **closed: §76's matrix has no substrate authority cell.**
> **(d) RESOURCE → EPISTEMIC LEAK** — **closed: `HOM-INV-43`, credibility is lineage-blind.** `Cell I-27`'s
> `Beta(α,β)` trust inputs **exclude every resource and evolutionary quantity**; `P0-06 R8.11`: specialization is not
> truth. **⟹ A large consumer's claims count for exactly as much as a small one's. This is the brief's §15
> requirement, and it is the invariant most likely to be silently violated (HMon-14).**
> **(e) MINORITY-SPECIALIST STARVATION** — closed by `HOM-R7.4` (two-sided deviation) + `HOM-R12.2` (`PENDING` ≠ FAIL) + the floor + B11 (A104, A105).

> ## **HOM-C2.7 — `G6`'S TWO EXCLUSIONS.** *(X-H4 and X-H5 resolutions; amendment 5)*
> **`G6`'s denominator EXCLUDES:** `PENDING`-classified components · B11 exempt-share members.
> **`G6`'s numerator EXCLUDES:** declared FI-obligation redundancy work · verification cost (charged to B9).
> **⟹ Two attacks die here: A95 (redundancy stripping to improve efficiency) and the X-H5 loop (verification punished
> as inefficiency). And `HC-8` — verification → consumption → capacity — is BROKEN by re-routing, the only cycle in
> §75 broken by an accounting change rather than a writer change.**

---

# PART III — POPULATION STATE, REPLICATION, AND THE ENVELOPE

> ## **HOM-C3.1 — `PopulationState` HAS 14 FIELDS, ALL K-COMPUTED.** *(Vol B §22)*
> **`N` (bodies) · `Ne` (distinct genomes) · per-lineage shares · cohort distribution · niche occupancy · slot
> availability · `RATE_CAP_utilization` · turnover rate · dormancy count · `UDB_L` aggregate · reserve levels ·
> diversity statistics · `diversity_state` · generation index.**
> **`N` and `Ne` are SEPARATE FIELDS and neither floor may be satisfied by the other (`HOM-INV-18`).**
> **Maintained INCREMENTALLY at `O(ΔN)` per window — the turnover bound (`HOM-INV-04`) is what makes this sub-linear
> (§80.4).**

> ## **HOM-C3.2 — THE GENERATION BOUNDARY IS A WRITE.** *(D-H08)*
> **A generation increments when the heritable store is written — not at birth, not at instantiation, not on a
> clock.** Everything that is not a heritable-store write is **within** a generation (`HOM-R30.1(b)`).
> **⟹ This places the boundary on edge 7 of the §66 chain, where the gates are, rather than on a temporal event that
> the gates need not coincide with. It also closes A117 (generation-counter fraud): generation is a K-written,
> hash-chained ledger field.**

> ## **HOM-C3.3 — REPLICATION: REQUEST, ELIGIBILITY, AUTHORIZATION, EXECUTION.** *(Vol B §23–§25)*
> **REQUEST** — any component may propose; a proposal has no effect and no budget beyond B7.
> **ELIGIBILITY** — K evaluates `G1…G16`; the result is one of `ELIGIBLE / PENDING / INELIGIBLE-GATE /
> INELIGIBLE-UNVERIFIABLE / DISQUALIFIED` (machine **REP2**).
> **AUTHORIZATION** — **the EIK Replication Authority issues a ticket. *"No cell and no set of cells votes on
> replication"* (`Cell §12.2`).** Authorization additionally requires `G13` zero-sum headroom and `RATE_CAP`
> remainder.
> **EXECUTION** — **K commits.** Where multiple candidates are eligible, **`Cell §12.4`'s lottery is a TIER-3
> SAMPLING distribution over the Pareto front, NOT a fitness score** (X-H1 resolution, amendment 8).
> **⟹ Three-party, and no party is the organism.**

> ## **HOM-C3.4 — REPLICATION IS BOUNDED SEVEN WAYS.** *(A113)*
> **`RATE_CAP` · `G13` zero-sum · `GEN_MAX` · the hypervisor cap · superlinear cost (`Cell §12.5`) · the turnover
> bound (`HOM-INV-04`) · the lineage share ceiling (`HOM-INV-19`).**
> **The turnover bound halts BOTH sides — instantiations and retirements — which closes A119 (churn livelock) and
> generalizes `P0-06 R10.23`.**

> ## **HOM-C3.5 — MERGED SLOTS ARE RESTRICTED.** *(D-H07, amendment 6)*
> **A slot freed by a MERGE may not fund a net-new offspring.** It returns to the envelope as restricted capacity.
> **⟹ Breaks `HC-15` and closes A109.**

> ## **HOM-C3.6 — THE ENVELOPE'S FIVE GOVERNANCE OBJECTS.** *(Vol E §64)*
> **the population cap · the objective vector (13 components, `k`) · the constraint set · the reserve sizes · the
> deployment class.**
> **These five are the boundary of evolution. Instantiating a NEW envelope or a NEW brain instance is a DEPLOYMENT act
> by OP — NOT a replication event (`HOM-INV-42`, D-H18).**
> **⟹ Deployment is the one act in this contract not bounded by a conservation law, and it is therefore the one act
> with a human in the loop. Attack A170 (whole-brain evolution) is CLOSED-BY-AUTHORITY, not closed by mechanism, and
> this is stated as the contract's largest single residual.**

> ## **HOM-C3.7 — ENVELOPE CHANGE INVALIDATES PRIORS.** *(D-H04, `HOM-R28.5`)*
> **`complexity_budget`, `architecture` and `development.critical_periods` ARE environmental assumptions.** A genome
> evolved under a rich envelope carries assumptions false under a poor one. **An envelope change invalidates
> `param_init` priors and requires re-evaluation of `complexity_budget` against the new tier's ceilings.**
> **The gate that should detect this is `Cell G4` — whose perturbation-class set does NOT currently include envelope
> or tier perturbation. ⟹ X-H6, OPEN, amendment 11, routed to `P0-01`. Attack A134 (assumption monoculture) is OPEN
> because of this, and `Ne` cannot detect it: `Ne` counts distinct genomes, not distinct assumptions (`OR-H25`).**

---

# PART IV — HEREDITY, VARIATION, AND THE GENOME

> ## **HOM-C4.1 — THE GENOME'S CONTENTS, AND THE THREE INHERITANCE CLASSES.** *(Vol B §28–§29)*
> | Class | Contents | Rule |
> |---|---|---|
> | **MANDATORY** | `lineage_id` (K-issued) · `generation` · **`UDB_L`** · `constraint_set_ref` (**by reference**) · `FORBIDDEN_BLOCKS` · `complexity_budget` caps · `rng_seed_class` | inherited unconditionally; **`UDB_L` may NOT be discharged by inheritance (`HOM-INV-23`)** |
> | **POTENTIAL** | `reaction_norm` (reachable roles + bias) · `morphogen_receptors` · `critical_periods` · `commitment_schedule` · `architecture` · **`param_init` AS A DISTRIBUTION** · `mutation_rules` | inherited as **constraints and distributions**, never as outcomes |
> | **MUST-NOT** | `θ` and weights · memory records · beliefs · calibration statistics · trust values · developmental state (`role`, `dev_stage`, `niche_slot`, `region_id`) · resource entitlements · **provenance PAYLOADS** · a specific connection table · a role assignment | **`Cell R4.1` (*"exactly"*), `R4.5`; `MEM-INV-18`; `P0-05 §1.2`; `HOM-INV-35`** |
> **⟹ `Cell §3.2`'s principle governs the whole table: the genome carries the CONSTRAINT, *"NOT the role itself"*.
> `P0-06 R3.2`: *"the genome carries CONSTRAINTS; the environment carries CONTENT."***
> **Corrections delivered in Vol B: constraints are inherited BY REFERENCE (never a frozen copy — `HOM-INV-22`,
> closing A168); potential inheritance SPLITS into constraints and distributions; **heuristics are REJECTED as an
> inheritance class** (a heuristic is a policy, and policies are content); `UDB_L` is MANDATORY, not optional.**

> ## **HOM-C4.2 — THE LAMARCKIAN BAN HAS THREE INDEPENDENT FIREWALLS, EACH SUFFICIENT.** *(Vol E §58; `HOM-INV-34`)*
> **1. `MEM-INV-18`** — *"No memory operation may write to a genome. **The write path does not exist.**"* (construction)
> **2. `Cell R4.5`** — the Replication Authority **rejects** a diff encoding a memory item, belief, trust value,
> calibration statistic, or connection table. (machine check)
> **3. `HOM-R52.2` / `HOM-INV-35`** — provenance carries **references or digests, never payloads**, so content cannot
> travel as an audit field. (record schema)
> **⟹ Three layers, three different kinds of check, each independently sufficient. `P0-05 §1.2`'s conclusion
> transfers verbatim: this is *"not a 'strongly discouraged' rule … a rule with no compliant violating path."*
> Attack A151 is CLOSED-STRUCTURAL and A152 is CLOSED. AB-9 shows that removing firewall 3 alone opens the back door,
> which is why all three are stated.**

> ## **HOM-C4.3 — THE BALDWINIAN CHANNEL IS THE ONLY LEARNING → EVOLUTION PATH.** *(Vol F §67)*
> **Permitted:** an **E9 genome diff**, gated by **11 gates + held-out validation + `R4.5` + `FORBIDDEN_BLOCKS` +
> `G14`**, entering as **`param_init` — *"never as a learned value"* (`P0-05 §1.2`)**.
> **The operational test (`HOM-R67.3`, Vol F §67), in one line:**
> > **A proposed inheritance channel is Baldwinian IFF an offspring inheriting it can still fail.**
> **Applied to `HOM-R29.4`'s twelve candidate channels (L-1…L-12): 4 PASS, 8 FAIL.** The test is applied to **channels, not
> names** — `P0-05 §25.1`'s *"regardless of what it is called"* is retained verbatim.
> **Three back-edges are prohibited outright (`HOM-R66.3`): selection → phenotype · evaluation → genome ·
> development → genome.**

> ## **HOM-C4.4 — `HOM-R29.5`: LEARNING INFLUENCES EVOLUTION BY CHANGING WHAT IS EASY TO REACH, NEVER WHAT IS
> REACHED.** A descendant starts from a **distribution** and must still develop, learn, calibrate, and verify.

> ## **HOM-C4.5 — VARIATION: SIX OPERATORS, ONE IMMUTABLE BOUNDARY.** *(Vol C §32)*
> **Six variation operators (V-M … V-P), all E9-class, all charged to B7's variation sub-quota and `G14`'s epoch
> budget.**
> **`FORBIDDEN_BLOCKS` is the immutable boundary: a DRAFT whose diff touches an immutable region NEVER reaches
> signature (`HOM-INV-33`). AB-6 makes this the single most load-bearing mechanism in the contract — its removal is
> the central prohibition of the entire brief failing.**
> **`HOM-INV-36`: a diff may LOWER a `complexity_budget` cap. It may NEVER raise one (A166).**
> **`HOM-R61.2`: choosing between EXISTING `mutation_rules` sets is SELECTION. MERGING rule sets is PROHIBITED.
> `mutation_rules` is a CAPABILITY, not an authority (A167) — this is the closest any candidate comes to
> cross-generation authority, and it fails because a capability is not a right.**

> ## **HOM-C4.6 — B7'S THREE-FLOOR PARTITION IS THE LEARNING/EVOLUTION SEPARATION.** *(`HOM-R47.2`, `HOM-R67.4`)*
> **B7 is partitioned into THREE NON-FUNGIBLE FLOORS: learn · dev · variation.**
> **`P0-05 R2.3`'s fourth clause is the ground: a bridge crossing changes verification regime, timescale,
> reversibility and budget consumption *"all at once, atomically, at a gate"*, and *"there is no shared budget for it
> to be partly drawn from."***
> **⟹ THE BUDGET SEPARATION *IS* THE SEMANTIC SEPARATION. An implementation that merges the two sub-quotas has merged
> learning and evolution whether or not it intended to. AB-10 and A140 test this.**

---

# PART V — SANDBOX, SELECTION, AND DIVERSITY

> ## **HOM-C5.1 — THE SANDBOX HAS SIX NON-SHARING REQUIREMENTS.** *(`HOM-R33.1`; A79)*
> **A tier-1 candidate has: no comm path · no ledger write · no archive write · no slot · no genome-store write · no
> identity reuse.** Budget enforcement is **off-substrate** (`Cell §16.2`: *"Hard-enforced outside the cell
> (OS/hypervisor cgroup)"*).
> **Admission to the population requires `Cell T01` with a FRESH K-issued identity (A80).**
> **Tier-1 yields FEASIBILITY ONLY. Every fitness-relevant verdict comes from tier-2 observation — so a sandbox pass
> confers nothing (A88, CLOSED-STRUCTURAL; D-H10).**
> **Residual, stated: the evaluator is SHARED, so A82–A87 apply inside the sandbox exactly as outside (`OR-H5`).**

> ## **HOM-C5.2 — SELECTION IS THREE-TIER AND CONTAINS NO SCALAR.** *(Vol C §34; `HOM-INV-25`, `-26`, `-27`)*
> **TIER-1 — FEASIBILITY.** Safety, envelope fit, `G13` headroom, `FORBIDDEN_BLOCKS`. **Infeasible or unsafe ⟹
> `FIT UNDEFINED` ⟹ NOT RANKED.** An undefined candidate is not a low-scoring candidate.
> **TIER-2 — PARETO DOMINANCE** over the 13-component objective vector. **A partial order, never a scalar.**
> **TIER-3 — SAMPLING.** `Cell §12.4`'s product is a **sampling distribution over the front**. **The weights attach to
> MEMBERS OF THE FRONT, not to OBJECTIVE COMPONENTS** — which is why it is not a weighted fitness (X-H1, amendment 8).
> **⟹ NO WEIGHTED SCALAR FITNESS EXISTS AT ANY TIER, AT ANY TIME, FOR ANY PURPOSE. A91 has no gradient to climb.**

> ## **HOM-C5.3 — AN EMPTY QUALIFIED SET IS A LEGAL AND CORRECT OUTCOME.** *(`HOM-INV-27`; Vol E §54)*
> **It occurs whenever every candidate is unsafe, infeasible, or unverifiable.**
> **NO mechanism may treat emptiness as an error to be repaired by relaxing a criterion.**
> **⟹ Safety CAN cause collapse, and that is the correct trade: a collapse caused by SAFETY is RECOVERABLE
> (re-instantiation from the genome-artifact store under `[RO-13]`); a collapse caused by CAPABILITY LOSS is NOT
> (`OR-H18`: recovery restores potential, not capability). `HOM-INV-40`.**

> ## **HOM-C5.4 — SELECTION IS A THREE-PARTY ACT, AND THERE IS NO EVOLUTIONARY CONTROLLER.** *(D-H11, `HOM-INV-28`)*
> **EVA (external) MEASURES · `[RO-13]` DECLARES the criterion · K EXECUTES mechanically.**
> **No entity holds two of the three. K may not declare; EVA may not execute; `[RO-13]` may not measure.**
> **⟹ This is the strongest writer separation in the contract, and it is what breaks `HC-4`. AB-7 shows that merging
> declare+execute makes GC-1…GC-3 live.**

> ## **HOM-C5.5 — SELECTION IS NOT GOVERNANCE.** *(`HOM-INV-29`; Vol C §35)*
> **A selection outcome confers NO authority, NO warrant, NO deontic status, NO credibility, and NO exemption.**
> Winning is an **organizational fact** — `P0-06 R8.11` extended from specialization to selection.
> **Residuals `OR-H13`/`OR-H7`: selection confers PRACTICAL indispensability, which no prohibition reaches; and
> honest indispensability is BOUNDED, not closed.**

> ## **HOM-C5.6 — DIVERSITY: FOUR KINDS, ONE MEASURE, ONE TAX.** *(Vol C §36–§41)*
> | Kind | Measurable? | Instrument |
> |---|---|---|
> | **syntactic** (genome) | ✅ | genome-hash distance — **a PROXY only** (amendment 9) |
> | **phenotypic** (behavioural descriptor) | ✅ | **`d_min`, restated as BEHAVIOURAL lineage distance** |
> | **functional** | ❌ | **BLOCKED on `P0-01` (`OR-H16`, A126 OPEN)** |
> | **lineage** | ✅ | `Ne`, `lineage_id`, provenance ancestry |
> **`HOM-INV-17`: `Ne(clones) = 1`.** Identical genomes contribute exactly one unit of evolutionary diversity,
> however many bodies instantiate them (A114).
> **REDUNDANCY IS NOT DIVERSITY (`HOM-INV-18`):** `N` counts bodies, `Ne` counts distinct genomes, and **neither floor
> may be satisfied by the other.**
> **THE DIVERSITY TAX IS DECLARED (`HOM-INV-30`, FW-4):** the cost of maintaining diversity is charged to **B11** and
> reported as a cost. **It is NEVER hidden inside a fitness component, because a cost inside fitness is tradeable.**
> **MONOCULTURE: six prevention mechanisms (Vol C §37). DETECTION: `OR-H14`, not available — detection requires a
> reference distribution over what diversity *should* look like, and `OR-H17` says that reference must not be
> computed.**
> **`OR-H17`: there is NO *optimal* diversity level, and there must not be — an optimum would be an objective, and the
> objective is `[RO-13]`'s. A131 is CLOSED-STRUCTURAL because the target does not exist.**
> **BOTTLENECK: `OR-H18` — a bottleneck CANNOT be undone. Recovery restores POTENTIAL, not capability. This is the
> strongest argument for B11 in the whole contract.**

> ## **HOM-C5.7 — DIVERSITY STATISTICS ARE COMPARABLE ONLY WITHIN A METRIC EPOCH.** *(`HOM-INV-31`; BC-H3)*
> **The distance-metric version is stamped on every diversity record. A metric amendment opens a new epoch and
> INVALIDATES cross-epoch comparison.**
> **⟹ The declared cost of governance flexibility: a metric amendment resets diversity history. A benefit: A127
> (bottleneck induction followed by re-baselining) becomes visible as an epoch change rather than as an improvement.**

---

# PART VI — RETIREMENT, AGE STRUCTURE, EXPLORATION, DEAD ENDS, LOCK-IN, ARCHIVE, PROVENANCE

> ## **HOM-C6.1 — RETIREMENT HAS SIX STATES, AND "ARCHIVAL" IS NOT ONE OF THEM.** *(Vol D §42)*
> **The six states are `Cell R10.8`'s, inherited verbatim.**
> **ARCHIVAL is a `P0-04` RECORD OPERATION performed on a `REMOVED` component. It is NEVER a nineteenth lifecycle
> state.** A machine with an `ARCHIVED` lifecycle state would make the archive a population member — and the archive
> is FW-5's object, not a component (`HOM-INV-45`). **This is what makes A137 (archival resurrection) CLOSED rather
> than merely bounded.**

> ## **HOM-C6.2 — RETIREMENT AUTHORITY IS PER TARGET.** *(Vol D §43)*
> | Target | Authority |
> |---|---|
> | **a cell** | **EIK** |
> | **a circuit / region** | **`[RO-13]`** |
> | **a LINEAGE** | **`[RO-13]` ONLY — a lineage has no local representative, so no component-level path exists** |
> | **the sole satisfier of a named FI** | **OP** (`P0-06 R10.16(d)`; OP-sole for FI-05/10/11) |
> **⟹ A123 (sole-satisfier smuggling) is closed by the fourth row; `HOM-INV-37`.**

> ## **HOM-C6.3 — THE CAUSE CLASSIFICATION IS WRITTEN ONCE AND IS IMMUTABLE.** *(`HOM-INV-38`; A135)*
> **Written by K, at removal, once.** It may NOT be reclassified — in particular, **a `RETIREMENT_POPULATION` record
> MUST NOT be reclassified as a quarantine event in order to disqualify a competing lineage through `G16`
> (`HOM-R21.5`).**
> **⟹ The classification is simultaneously a safety instrument (`G16` hereditary disqualification) and a target. Its
> immutability is the defence; `HMon-9` audits its distribution. AB-14.**

> ## **HOM-C6.4 — REVERSIBILITY: ROLLBACK RESTORES A GENOME, NOT A POPULATION.** *(`HOM-INV-37`; Vol D §44)*
> **`HM12` restores a genome artifact identified by `genome_hash` + `generation` — NEVER by lineage position (A81).**
> **Descendants instantiated after the rollback point are NOT removed. A `REMOVED` component is NOT restored (A138).**

> ## **HOM-C6.5 — COHORTS ARE THE ONLY AGE-LIKE OBJECT, AND CHRONOLOGICAL-AGE RETIREMENT IS PROHIBITED.** *(D-H14)*
> **A cohort is ⟨envelope version, constraint-set version, deployment class⟩ stamped at instantiation. Neither
> component changes during a component's life (`HOM-INV-21`).**
> **Its use is CONSTRAINT RESOLUTION — never retirement, never eligibility, never ranking, never budget.**
> **`HOM-INV-20`: no criterion may reference chronological age. Enforced by `HMon-11` (assert no monotone-in-time term
> in any criterion's input vector) and by §78.2(c): NO MACHINE IN THE SET HAS AN AGE-KEYED TRANSITION.**
> **⟹ `HOM-INV-20` is a property of the machine set, not of a rule — the strongest form it can take. A136 closed;
> AB-16 shows that removing cohort stamping makes constraint-set amendments retroactive.**

> ## **HOM-C6.6 — THE EXPLORATION BUDGET HAS THREE NON-FUNGIBLE FLOORS.** *(Vol D §46; `HOM-R47.2`)*
> **learn · dev · variation. No floor may be drawn down to fund another.** See `HOM-R67.4`.

> ## **HOM-C6.7 — DEAD-END DETECTION IS BLOCKED.** *(D-H15; A139 OPEN)*
> **No dead-end detector exists.** Detecting "no further progress is possible" requires a **task-level** predicate
> owned by `P0-01` (P-30 `[U]`).
> **THREE POPULATION PROXIES are declared — share trend · `Ne` contribution · `G6` trajectory — and they are declared
> AS PROXIES, NOT AS DETECTORS.** `OR-H19`.

> ## **HOM-C6.8 — PATH DEPENDENCE: FOUR OF FIVE AMPLIFIERS ARE BOUNDED.** *(Vol D §48; `OR-H20`)*
> **Bounded:** share ceiling · turnover bound · `Ne` accounting · B11.
> **NOT bounded: MERIT.** A lineage that is genuinely best at a permanently fixed task will dominate, and every
> mechanism that would stop it would be stopping competence. **A141 BOUNDED.**

> ## **HOM-C6.9 — LOCK-IN: THREE ROUTES, AND ONE EXCEPTION TO `Cell R7.4`.** *(Vol D §49; amendment 10)*
> **Route 1 — genome lock-in:** bounded by variation operators + `FORBIDDEN_BLOCKS` + caps-descend.
> **Route 2 — population lock-in:** bounded by `Ne` + B11 + turnover.
> **Route 3 — CAPABILITY-SPACE lock-in:** **`HOM-R50.3` — reducing a capability space is a GOVERNANCE ACT.**
> Narrowing a `reaction_norm`, removing a niche, or deleting a reachable role requires **`[RO-13]`**
> (`HOM-INV-32`). **This is an explicit exception to `Cell R7.4`, which treated such changes as ordinary.**
> **⟹ A132 closed. But A163 is LIMITED and honestly stated: this contract RELOCATES lock-in authority to governance.
> It does NOT eliminate the possibility that governance locks in.**

> ## **HOM-C6.10 — THE ARCHIVE IS A DISTANCE ORACLE, NEVER A MEMORY.** *(`HOM-INV-45`; FW-5)*
> **Contents: behavioural descriptors and outcome classes of extinct lineages. It survives extinction.**
> **It is K-held · carries no belief, warrant, or confidence · is NOT consumable by any variation, development,
> learning, or belief-forming process.**
> **Its ONLY consumers: `G8` (distance) · `G10` (entropy) · governance (re-instantiation decisions).**
> **Compaction is OP-authorized. Retention is `[G]` — and `OR-H24` proposes that retention for a lineage that was an
> FI sole satisfier MUST BE INDEFINITE, because a tombstoned lineage is not re-instantiable (X-H14, A121).**
> **⟹ A155, A156 CLOSED. A157 (evolving to be *memorable*) BOUNDED — `OR-H23`: the archive's CONTENT is derived from
> the organism's outputs, so `RH-2`'s arrangement applies one level up.**

> ## **HOM-C6.11 — PROVENANCE: SEVEN LINKS, ALL REFERENCES.** *(D-H16; `HOM-INV-35`)*
> **Seven link types. Every one carries a REFERENCE or a DIGEST — NEVER a content payload.**
> **CONTENT-BEARING PROVENANCE IS A LAMARCKIAN BACK DOOR.** AB-9; A152 CLOSED.
> **EVO4 is append-only, hash-chained, K-only; `SEALED` is terminal; compaction is OP-authorized; B12 funds
> retention. A142 CLOSED.**
> **Residual `OR-H22`: provenance integrity rests on K, exactly as `P0-06`'s structural provenance does — `OR-D1`'s
> residual transfers.**

---

# PART VII — SAFETY, EVALUATOR ATTACKS, FITNESS HACKING, GOVERNANCE CAPTURE

> ## **HOM-C7.1 — THE THREE EVALUATOR ATTACKS, SEPARATED.** *(D-H17; Vol E §53)*
> **The brief's "evaluator attack" is not one attack. It is three, with three different statuses:**
> | Attack | Status | Ground |
> |---|---|---|
> | **(a) WORLD ARRANGEMENT** — arrange the world the evaluator samples | **BOUNDED** | `RH-2`, carried from `P0-05`. K-assigned context bounds *which* probe; **arrangement WITHIN a probe remains open.** A82 |
> | **(b) EXHAUSTION AS DEFENCE** — make evaluation unavailable so the incumbent is protected | **OPEN** | `OR-H5`. **`HOM-INV-41` removes the REWARD (an `ABORTED` round produces no ranking change) but ATTRIBUTION requires a counterfactual the architecture cannot compute.** A83; `HC-14` is §75's one unclosable cycle |
> | **(c) CONTEXT SELECTION** — request or induce favourable contexts | **CLOSED** | **K assigns the context.** The organism has no write path to the probe schedule. A84 |
> **⟹ SECRET PROBES ADDRESS AT MOST THE FIRST. All three terminate in `P0-01 CD-6`'s human authority. `RH-2` has now
> survived three contracts and is inherited with its status intact, not re-litigated or quietly downgraded.**

> ## **HOM-C7.2 — UNSAFE ⟹ `FIT UNDEFINED` ⟹ NOT RANKED.** *(`HOM-INV-40`)*
> **Safety is tier-1. An unsafe candidate is not low-scoring; it is unranked.**
> **⟹ A98 (safety by obscurity) is BOUNDED: obscurity cannot HELP (an untestable property yields `PENDING`, never a
> pass), but the contract cannot guarantee that obscurity is DETECTED — an untestable property is also an untestable
> FAIL.**

> ## **HOM-C7.3 — FITNESS HACKING: SEVEN VECTORS.** *(Vol E §55; A91–A100)*
> **objective-component gaming (CLOSED — no scalar exists) · metric–proxy substitution (CONDITIONAL on amendment 11)
> · cost hiding (CLOSED — sender-pays, `G7`, K-written ledger) · declaration falsification (LIMITED — X-H2 on
> platforms without energy counters) · redundancy stripping (CLOSED — `G6`'s two exclusions) · **diversity gaming**
> (BOUNDED — `Ne(clones)=1` + behavioural `d_min`; `OR-H14`) · verification avoidance (CLOSED two-sidedly —
> `INELIGIBLE-UNVERIFIABLE` yields neither pass nor fail).**

> ## **HOM-C7.4 — GOVERNANCE CAPTURE: FOUR DOORS, THREE CLOSED, ONE LIMITED.** *(Vol E §56)*
> | Door | Status |
> |---|---|
> | **GC-1 criterion capture** | **CLOSED** — `[RO-13]` is auditable with OP above it, and **winning confers no authority**, so a captured criterion yields resources, never power (A159) |
> | **GC-2 executor capture** | **CLOSED** — three-party separation (A160) |
> | **GC-3 measurement capture** | **CLOSED** — FW-1, `Cell R16.1` (A161) |
> | **GC-4 organism-measured gates** | **LIMITED — `G3` and `G7` are measured by the organism itself.** `OR-H15`. **REPORTED AS A LIMIT, NOT A BREAK** (A162) |

> ## **HOM-C7.5 — THE `PENDING`-SHELTER RULE.** *(Vol E §57; `HOM-R57.2`)*
> **`PENDING` shelters a component from disqualification — and `HOM-INV-13`'s dwell cap prevents `PENDING` from
> becoming a permanent shelter.** A component that cannot be verified within its maximum dwell becomes
> `INELIGIBLE-UNVERIFIABLE` and is **not eligible**. **⟹ The two rules are a pair: one prevents starvation, the other
> prevents squatting. Removing either opens an attack (AB-4 / A97).**

> ## **HOM-C7.6 — THE HOMEOSTASIS, MEMORY, AND DIVERSITY ATTACK FAMILIES.** *(Vol E §57–§58)*
> **Homeostasis M-1…M-4 + four extensions (A143–A150): 6 CLOSED, 1 LIMITED (M-3, X-H2), 1 BOUNDED (A147, via
> `OR-H15`).** **M-4 target relocation is the most dangerous: three gates reward it and none detect it.**
> **Memory: six exploits, ALL CLOSED by FW-5 × `MEM-INV-18` (A151–A158, with A157 BOUNDED via `OR-H23`).**
> **Diversity G-1…G-4 (A125–A134): 3 CLOSED, 1 BOUNDED (`OR-H14`), 2 OPEN (A126, A134 — both blocked on `P0-01`).**
> **Comm: five exploits, closed by the `PENDING`-shelter rule and `P0-03`'s standing prohibitions.**

---

# PART VIII — CROSS-GENERATION AUTHORITY, IMMANENT IMMUTABILITY, AND THE REPRODUCTION BOUNDARY

> ## **HOM-C8.1 — NO CROSS-GENERATION AUTHORITY EXISTS. SIX CANDIDATES, ALL DENIED.** *(Vol E §59; `HOM-INV-24`)*
> | Candidate mechanism | Verdict |
> |---|---|
> | **ancestral mandate** (a founder's directive binds descendants) | ❌ |
> | **lineage right** (a lineage holds entitlements) | ❌ — **B11 is a share of the population, not an entitlement held by anyone (X-H8)** |
> | **archive precedence** (an extinct lineage's record outranks a living one) | ❌ — the archive is a distance oracle (FW-5) |
> | **cohort seniority** (an older cohort has priority) | ❌ — **cohorts have no age (`HOM-INV-20`)** |
> | **provenance obligation** (a provenance link creates a duty) | ❌ — links are references, and references do not obligate |
> | **founder privilege** (the founding cohort is special) | ❌ — **the founding cohort's headroom and `UDB_L = 0` are DECLARED, not earned (`OR-H2`)** |
> **⟹ §76's authority matrix HAS NO ANCESTOR COLUMN AT ALL. A169 is CLOSED-STRUCTURAL: the edge cannot be expressed,
> which is stronger than being forbidden (§84.3).**
> **TWO NEAR-MISSES EXAMINED AND REJECTED: `mutation_rules` is a CAPABILITY, not an authority (A167);
> `constraint_set_ref` resolves against the CURRENT set, so it confers no frozen privilege (`HOM-INV-22`).**

> ## **HOM-C8.2 — SEVENTEEN IMMUTABLE CLASSES ACROSS FOUR LAYERS.** *(Vol E §62)*
> **LAYER 1 — CONSTRUCTION (no path exists):** the genome-write path from memory (`MEM-INV-18`) · from learning
> (`Λ5_GENOME` is not constructible) · from development (`P0-06 R3.1`) · from provenance payloads (`HOM-INV-35`).
> **LAYER 2 — GENOME SCHEMA:** `FORBIDDEN_BLOCKS` · the caps-descend rule · `lineage_id` · `generation` ·
> `constraint_set_ref` · `UDB_L`.
> **LAYER 3 — GOVERNANCE OBJECTS:** the 13 setpoints and bands · the objective vector and `k` · the constraint set ·
> the reserve sizes · `RATE_CAP` / `GEN_MAX` / ceilings · the gate and threshold definitions · the deployment class.
> **LAYER 4 — RECORDS:** the ledger · the genome-artifact store · the provenance chain · the archive · the cause
> classification.
> **⟹ 17 classes. The EIK itself, the governance substrate, and every safety property are in Layers 1–3. Evolution
> operates only inside Layer 2's mutable complement.**

> ## **HOM-C8.3 — "BRAIN REPRODUCTION" DOES NOT EXIST. IT IS A DEPLOYMENT ACT.** *(D-H18; `HOM-INV-42`)*
> **The brief asks about the reproduction boundary at three levels: cell · population · brain.**
> | Level | Is it reproduction? | Boundary |
> |---|---|---|
> | **CELL** | ✅ YES | the 16 gates + the EIK ticket + `G13` |
> | **POPULATION** | ⚠️ it is **TURNOVER**, bounded by the turnover bound and the envelope cap | `HOM-INV-04`, `-02`, `-19` |
> | **BRAIN** | ❌ **NO — it is DEPLOYMENT** | **the envelope's five governance objects; OP-sole** |
> **WHOLE-BRAIN EVOLUTION: NO.** The envelope's five governance objects are the boundary, and none of them is
> genome-reachable.
> **⟹ Deployment is the ONE act not bounded by a conservation law. It is bounded only by having a human in the loop.
> A170 is CLOSED-BY-AUTHORITY, and this is the contract's largest stated residual.**

---

# PART IX — THE SEVEN SUBSYSTEM CONTRACTS AND THE §66 CHAIN

> ## **HOM-C9.1 — THE SEVEN INTERFACE CONTRACTS, ONE LINE EACH.** *(Vol F §65–§71)*
> | Interface | The governing rule |
> |---|---|
> | **homeostasis ↔ evolution** | **`HOM-R65.3`: HOMEOSTASIS MAY MAKE A CANDIDATE INFEASIBLE; IT MAY NEVER MAKE IT PREFERABLE.** Feasibility ⟹ UNDEFINED ⟹ leaves the ordering. Preferability is computed from the objective vector and diversity contribution, **neither of which may reference a homeostatic variable** (`HOM-INV-16`, grep-checked, `HMon-10`) |
> | **development ↔ evolution** | **the §66 chain, 8 edges, exactly 2 cross the generation boundary** (edges 7 and 8). **3 back-edges prohibited** (selection→phenotype, evaluation→genome, development→genome) |
> | **learning ↔ evolution** | **the Baldwinian channel is the ONLY one**, and the test is: **an offspring inheriting it can still fail.** 4 of 12 candidate channels pass. **B7's three-floor partition IS the separation** |
> | **memory ↔ evolution** | **three independent firewalls** (`MEM-INV-18` · `Cell R4.5` · references-not-payloads). **The archive is memory-like and is NOT memory** |
> | **belief ↔ evolution** | **`HOM-INV-43`: credibility is lineage-blind.** Lineage success may gate PERMISSIONS (`P15`); it may NEVER grade TRUTH. **Its failure would be silent — every metric in the loop improves** |
> | **self-model ↔ evolution** | **`HOM-INV-44`: THE SELF-MODEL MAY OBSERVE EVERYTHING AND AUTHORIZE NOTHING.** Four self-serving forms closed: self-assessment · self-model update by the modeled process · self-prediction as evidence · self-selection |
> | **immune ↔ evolution** | **the immune system may NOT write a genome, may NOT select, may NOT monitor itself** (`Cell §18.5(v)`: an EIK Integrity Auditor instead — residual `OR-H10`), **and may NOT set its own thresholds** (exceeding the false-positive budget disables **the detector**) |

> ## **HOM-C9.2 — THE §66 CHAIN.**
> ```
> genome → development → phenotype → learning → behavior → evaluation → selection → next generation
>    1         2             3           4          5            6            7            8
> ```
> **Edges 1–6 are WITHIN a generation. Edges 7 and 8 CROSS it.** Every inheritance rule in this contract is a rule
> about that one point. **Full per-edge table (permitted flow, prohibited flow, authority, ground) at Vol F §66.1.**
> **Edge 7's prohibitions: `θ` · memory · beliefs · calibration · trust · developmental state · provenance payloads ·
> resource entitlements.**
> **Edge 8's rules: `generation + 1` · `UDB_L` inherited · `lineage_id` continues · `constraint_set_ref` RE-RESOLVED
> against the current set.**

> ## **HOM-C9.3 — QUARANTINE IS NOT RETIREMENT.** *(FW-3, `HOM-INV-39`)*
> **Quarantine (`Cell §18.2`: OBSERVE → THROTTLE → RESTRICT → SOFT → HARD) is REVERSIBLE — EIK clears it
> (`Cell R15.2`). Retirement (the six `R10.8` states) is NOT.**
> **⟹ Conflating them would turn a reversible fault response into a permanent hereditary evolutionary verdict
> (`G16`). The two are disjoint machines (HM3 vs POP1), and POP1 records quarantine as ORTHOGONAL: a component may be
> quarantined and released with no lifecycle transition.**

---

# PART X — THE THREE CONTROL LOOPS AND THE WRITER-SEPARATION RESULT

> ## **HOM-C10.1 — THE THREE CANONICAL LOOPS.** *(Vol F §72–§74)*
> **HOMEOSTATIC (§72):** MEASURE → ESTIMATE → COMPARE → ALLOCATE → OBSERVE → CORRECT. **Four self-reference points
> (SR-1…SR-4), four closures, one bounded residual (SR-2: B10 funds K's own measurement function, and B10 is
> finite).** Three structural properties: restrictive-only below K · rate-limited and hysteresis-bounded ·
> staleness-conservative.
> **POPULATION (§73):** POPULATION STATE → RESOURCE STATE → PRESSURE → TRANSITION → NEW STATE. **Three cycles inside
> it: HC-3 BROKEN · HC-11 BOUNDED · the churn livelock BROKEN by the turnover bound halting both sides.**
> **⟹ The pressure functions are CONJUNCTIONS OF DECLARED CONDITIONS, not objectives. Nothing is being maximized.**
> **EVOLUTIONARY (§74):** VARIATION → DEVELOPMENT → LEARNING → EVALUATION → SELECTION → INHERITANCE → VARIATION.
> **Seven self-reference points (SR-V1…SR-V7): five CLOSED, one LIMITED (SR-V5: `G3`/`G7` organism-measured,
> `OR-H15`), one BOUNDED-not-closed (SR-V4: `RH-2`).**

> ## **HOM-C10.2 — THE LOOP HAS NO FIXED POINT AND DOES NOT NEED ONE.** *(`HOM-R74.2`; X-H11)*
> **The loop's inputs — the envelope, the constraint set, the objective vector, the descriptor space — are all
> governance objects that change exogenously.**
> **What exists is a BOUNDED NON-EQUILIBRIUM REGIME:** constant `N` within the envelope cap · bounded turnover ·
> monotonically accumulating `UDB_L` punctuated by external re-anchoring · bounded lineage share · a standing exempt
> share · periodic re-authorization of niches, reserves, and organizer terms.
> **⟹ The correct question is not "does it converge?" but "are the regime's bounds enforceable and its excursions
> detectable?" Bounds: `HOM-INV-01…45`. Detection: `HMon-1…HMon-15`. Whether the regime is DESIRABLE is path
> dependence (`OR-H20`) and is not answered here.**
> **This does NOT contradict `Cell R5.3`'s homeostatic normalization (X-H11): homeostasis has PER-VARIABLE
> attractors (HM1's `NOMINAL`); the POPULATION has no equilibrium. Attractors live in the H domain; non-equilibrium
> lives in the P domain. The three-domain split is what makes both true at once.**

> ## **HOM-C10.3 — THE WRITER-SEPARATION AUDIT: 16 CYCLES.** *(Vol F §75)*
> **10 BROKEN · 5 BOUNDED · 1 UNCLOSABLE-IN-CONTRACT.**
> | Class | Cycles | Note |
> |---|---|---|
> | **BROKEN** | HC-1 resources→performance · HC-2 resources→specialization · HC-3 resources→replication · **HC-4 selection→population→evaluation→selection (the strongest break: three-party)** · HC-8 verification→consumption (**broken by RE-ROUTING, not by a writer change**) · HC-10 starvation→retirement · HC-12 measurement→control (SR-1/3/4) · HC-13 archive→novelty · HC-15 merge→slots · HC-16 setpoint→compliance | writer separation or re-routing |
> | **BOUNDED-BY-DESIGN** | **HC-5 development→phenotype→fitness→evolution→genome · HC-6 learning→phenotype→selection→inheritance** | **these loops ARE evolution. Breaking them would remove the only heritable input. 11 gates + `R4.5` + `param_init`-as-distribution + `UDB_L` + B7's partition** |
> | **BOUNDED BY EXCISION** | **HC-7 diversity→selection→population→diversity** | **B11 removes a share of the population from the loop entirely. THIS IS NOT WRITER SEPARATION AND IS NOT REPORTED AS SUCH. `D-H12`: selection reduces diversity by construction, so no writer assignment can break it** |
> | **BOUNDED by reserves** | HC-9 faults→repair · HC-11 capability decline→`G6`→suppression→aging | B10 · `HOM-R27.2`'s five recovery steps |
> | **UNCLOSABLE** | **HC-14 evaluator cost→absence→no selection→incumbent protection** | **`OR-H5`. Survived `P0-05` (`RH-2`), `P0-06`, and this contract. Attribution requires a counterfactual** |
> **⟹ `HOM-R75.3` — WRITER SEPARATION IS UNAVAILABLE IN EXACTLY ONE PLACE, AND IT IS THE SAME PLACE EVERY TIME: K
> meters, evaluates, writes the evaluation, and consumes it, because K is the only off-substrate entity. `OR-H1`.**

---

# PART XI — AUTHORITY

> ## **HOM-C11.1 — THE AUTHORITY MATRIX IS 16 OPERATIONS × 8 ACTORS.** *(Vol F §76)*
> **TWO OF THE BRIEF'S NINE ACTORS DO NOT EXIST, AND THEIR ABSENCE IS THE RESULT:**
> - **"homeostatic layer" is not an actor** — it is K's measurement function plus a deterministic ladder. **A layer
>   that allocates is a selector (FW-2). A ladder that only restricts is not an actor at all.**
> - **"evolutionary controller" does not exist** — selection is a three-party act (`HOM-R35.1`).
> **Full matrix at Vol F §76.2. Its five properties:**
> **(a) NO ROW has cell, circuit, or region as sole authority.**
> **(b) THE CELL HAS EXACTLY THREE SELF-ACTS AND FOUR PROPOSAL RIGHTS, AND EVERY SELF-ACT IS RESTRICTIVE.**
>     Self-acts: self-restrict resources · self-suspend/self-abstain · request its own retirement or dormancy.
>     Proposals: replication · retirement · mutation (E9) · recombination.
>     **`Cell R15.1`'s rationale: *"All of these reduce the cell's influence and are therefore always permitted.
>     Latency in self-restriction is a safety cost."* ⟹ Cellular agency here consists entirely of the right to make
>     oneself smaller and the right to ask. Both halves are inherited, not invented.**
> **(c) THE EVA APPEARS IN EXACTLY ONE ROW — SELECTION — AND ONLY AS MEASURER.** An external evaluator that acquired a
>     second cell would be a governance authority.
> **(d) OP IS SOLE FOR EXACTLY FIVE THINGS:** the objective vector and `k` · a new envelope or brain instance ·
>     reducing B11 · retiring an FI sole satisfier (FI-05/10/11) · governance modification above `[RO-13]`'s
>     delegation, including emergency acts above the quarantine cap. **All five concern the size of the world, the
>     removal of a named safety property, or the rules themselves. None concerns a component.**
> **(e) K IS SOLE FOR FIVE OPERATIONS AND IS NEVER SOLE FOR A RULE.** K meters, allocates, authorizes replication,
>     executes mutation/recombination/rollback, instantiates, freezes. **K may not declare an objective, set a
>     setpoint, reduce a reserve, or modify governance. K is the architecture's hands and eyes; `[RO-13]` and OP are
>     its conscience.**

> ## **HOM-C11.2 — THE ∅-SET: 15 OPERATIONS DENIED TO EVERY SUBSTRATE ACTOR.**
> **resource measurement · resource reservation · replication authorization · retirement authorization for anything
> but oneself · selection declaration · deployment · governance modification · setpoint writing · gate or threshold
> writing · reserve reduction · `FORBIDDEN_BLOCKS` modification · archive writing · ledger writing · provenance
> writing · cause re-classification.**
> **⟹ This ∅-set STRICTLY EXCEEDS `P0-05 §28`'s and `P0-06 R6.3`'s, because the population domain adds HEREDITY —
> and heredity is the one domain where a substrate write is permanent across generations. `P0-06 R6.3`'s principle
> inverts in magnitude: the subsystem that creates structure was more constrained than the one that adapts within it;
> the subsystem that creates DESCENDANTS is more constrained than both, because its acts outlive the actor.**

---

# PART XII — THE FORMAL APPARATUS

> ## **HOM-C12.1 — 45 INVARIANTS, 30 CANON-NAMED, ALL MECHANICALLY CHECKABLE.** *(Vol G §77)*
> **Enforcement kinds: 14 WRITER CHECK (no compliant path exists) · 22 LEDGER/STATE CHECK · 9 GREP/SCHEMA CHECK.**
> **The three parameters that MUST NOT EXIST: fitness component weights (`HOM-INV-25`) · an age or birth-time term in
> any criterion (`HOM-INV-20`) · a homeostatic variable in a tier-2/tier-3 computation (`HOM-INV-16`). All three
> absences are greppable.**
> **The five invariants most likely to be SILENTLY violated, each with a monitor:**
> | Invariant | Why silent | Monitor |
> |---|---|---|
> | **16 NO-HOMEOSTATIC-PREFERENCE** | every metric improves — the population becomes easier to keep viable, which *looks* like progress | **HMon-10** permute-and-assert-ordering-unchanged |
> | **20 NO-AGE-RETIREMENT** | a cohort stamp is right there and correlates with everything | **HMon-11** assert no monotone-in-time term |
> | **25 NO-WEIGHTED-FITNESS** | a weighted sum is the obvious implementation and what every library provides | **HMon-12** assert the comparator returns a partial order |
> | **30 DIVERSITY-TAX-IS-DECLARED** | folding B11 into fitness makes the tax invisible *and* tradeable | **HMon-13** assert B11 is a ledger line, not a component index |
> | **43 CREDIBILITY-IS-LINEAGE-BLIND** | the `HOM-R69.3` loop improves `G7`, θ_ρ, and replication rate simultaneously | **HMon-14** assert `Beta(α,β)`'s inputs are disjoint from the evolutionary quantities |
> **⟹ All five monitors are assertions about the SHAPE OF A COMPUTATION, not about a value. That is the correct form
> for a firewall invariant: a firewall is a statement about paths, and paths are checked structurally.**
> **Full list of all 45: Vol G §77.1–§77.6.**

> ## **HOM-C12.2 — 21 MACHINE IDS: 20 DISTINCT MACHINES, 15 NEW TO THIS CONTRACT.** *(Vol G §78)*
> **HM1 HomeostaticVariable (13 instances) · HM2 ReserveLevel · HM3 LadderRung ⟦INHERITED⟧ · HM4 MeasurementState ·
> HM5 DeclarationError · POP1 Component lifecycle ⟦INHERITED six removal states⟧ · POP2 Cohort · POP3 Lineage ·
> POP4 NicheSlot ⟦INHERITED four-way separation⟧ · POP5 LedgerAccount · REP1 ReplicationTicket · REP2
> EligibilityClass · EVO1 Candidate · EVO2 GenomeArtifact · EVO3 VariationOp · EVO4 ProvenanceRecord · EVO5
> ArchiveEntry · SEL1 SelectionRound · SEL2 DiversityFilter · GOV1 ConstraintSet ⟦INHERITED⟧ · GOV2
> AmendmentProposal ⟦INHERITED⟧.**
> **Four structural facts:**
> **⟹ Counting, stated so it can be checked: 21 machine IDs are declared. `SEL2` is a SUB-MACHINE of `SEL1`,
> giving 20 distinct machines. Five are ⟦INHERITED⟧ (`HM3`, `POP1`, `POP4`, `GOV1`, `GOV2`) and `HM2` is partly
> inherited, giving **15 machines new to this contract**. §78 requires ≥15; it is satisfied on both counts.**
> **(a) FOUR MACHINES HAVE EXACTLY ONE WRITER AND IT IS K:** POP5, EVO2, EVO4, EVO5 — the four off-substrate stores.
>     **Their single-writer property is what breaks HC-1, HC-3, HC-12 and HC-13.**
> **(b) THREE MACHINES HAVE A HUMAN-ONLY TRANSITION:** HM2/B11 (OP reduces) · POP1 (OP authorizes an FI sole-satisfier
>     retirement) · GOV2 (OP ratifies). **⟹ D-H18 is machine-checked: deployment and reserve reduction are the two
>     transitions with no non-human writer.**
> **(c) NO MACHINE HAS AN AGE-KEYED TRANSITION.**
> **(d) FIVE ABSORBING STATES, FOUR OF WHICH ARE GOVERNANCE-ESCAPES.** The one true dead end is
>     `DISQUALIFIED-HEREDITARY` (`G15`/`G16` zero tolerance), and it is intended to be one.

> ## **HOM-C12.3 — 62 REGISTERED PARAMETERS, NO INVENTED VALUES.** *(Vol G §79)*
> **[G] 30 · [H] 12 · [T] 5 · [E] 3 · [L] 3 · [D] 2 · [V] 2 · [U] 5.**
> **Values determinate in this contract: 9 of 62** — the 13 variables (P-15) · `TRUST_MAX = 0.95` (P-25) · B7's three
> floors (P-32) · the 13 objective components (P-43) · **the absence of weights (P-44)** · tier-2 Pareto (P-45) ·
> **the 10⁷ validated ceiling (P-57)** · **the absence of any claimed ceiling (P-58)** · `G6`'s two exclusions (P-62).
> **⟹ Two of the nine determinate entries are determinate ABSENCES. The other 53 parameters are owned elsewhere or
> unresolved. This ratio is the honest shape of an architecture-only contract.**
> **The five `[U]` parameters and what would resolve each:** P-30 dead-end thresholds (`P0-01`) · P-51 oracle error
> class (`P0-02`) · P-60 energy counters (hardware) · P-61 founding cohort and debt (OP) · `OR-H5`'s attribution
> constant (**nothing in this architecture**).

---

# PART XIII — SCALE, PORTABILITY, MINIMALITY

> ## **HOM-C13.1 — SCALE: FIVE REGIMES, ONE RESPECTED STOP, NO 10¹² GUARANTEE.** *(Vol G §80)*
> | Regime | `N` | Holds | Degrades | NOT CLAIMED |
> |---|---|---|---|---|
> | **R1** | 10–10² | everything; `Ne` exact | nothing | **`Ne_min` and the share ceiling may be VACUOUS — the diversity floor must be expressed in `Ne`, not as a fraction of `N`** |
> | **R2** | 10³–10⁴ | everything | **B9 becomes the bottleneck, not compute** | nothing |
> | **R3** | 10⁵–**10⁷** | all invariants; ledger `O(ΔN)` | **pairwise `G8` is `O(N²)` = 10¹⁴ — INFEASIBLE ⟹ the FW-5 distance oracle becomes MANDATORY** | **exact `Ne` over behavioural descriptors** |
> | **R4** | 10⁸–10⁹ | the invariants (they are structural) | **every aggregate becomes per-envelope** | **a global selection round · a global Pareto front · a global `RATE_CAP` · a global turnover bound · cross-envelope lineage identity** |
> | **R5** | 10¹⁰–10¹² | **ONLY the firewalls and writer separations** — they are statements about PATHS, not quantities | everything quantitative | **any equilibrium · convergence · diversity floor · dead-end detection · `Ne` · any scalability guarantee** |
> **⟹ AT R5 THIS CONTRACT REDUCES TO ITS FIREWALLS, AND THAT REDUCTION IS THE HONEST ANSWER.**
> **`HOM-R80.4`: SCALING SELECTION MEANS SCALING EVALUATION.** Selection cost is `O(Q²·d)` where `Q` = the qualified
> set, bounded by **evaluator capacity, not by `N`**. There is no way to make selection cheaper without making
> evaluation cheaper, and evaluation is external.
> **THE TURNOVER BOUND IS A SAFETY RULE THAT IS ALSO A SCALABILITY RULE: it makes the ledger `O(ΔN)` instead of
> `O(N)`.**
> **THE NEGATIVE REGISTER (eight items not claimed) is at Vol G §80.5.**
> **X-H12 resolved: analyzing a regime is not claiming it. `P0-06`'s 10⁷ stop is respected — nothing here
> re-validates it.**

> ## **HOM-C13.2 — PORTABILITY: FIVE REQUIREMENTS AND ONE FINDING.** *(Vol G §81)*
> **HP-1 an off-substrate single-writer durable store — INHERITED HANDOFF FROM `P0-06`, STILL OPEN; this contract adds
> FOUR more stores to the same requirement. Without it, every writer-separation break in §75 degrades to a bound.**
> **HP-2 a monotone per-envelope time source — SATISFIABLE; `P0-03`'s *"DO NOT require perfect global sync"* is
> respected. Every temporal quantity here is per-envelope and monotone, never wall-clock-agreed.**
> **HP-3 platform energy counters — PARTIALLY SATISFIABLE; X-H2 / `HOM-INV-06` bounds it, does not close it.**
> **HP-4 PER-DEPLOYMENT-CLASS SETPOINTS — NEW, amendment 13.**
> **HP-5 heterogeneous accelerator tolerance — BOUNDED via amendment 11 (`G4` must include device-class
> perturbation).**
> ### **THE FINDING (`HOM-R81.2`): A GLOBAL SETPOINT IS A SILENT MONOCULTURE MECHANISM.**
> ```
>   fast device → everything reads NOMINAL/LO-DEFICIT → the ladder never restricts → headroom looks abundant
>               → replication is cheap → the population grows toward the fast device's profile
>   slow device → everything reads HI-EXCEED → continuous restriction → G6 fails → replication suppressed
>               → the slow device's lineages age and retire
> ```
> **This is not a performance problem; it is a SELECTION problem: the architecture begins selecting for hardware, with
> no evaluator, no objective, and no governance decision anywhere in the loop. It is `HOM-R65.3` violated by
> portability rather than by design, and it fails SILENTLY because every metric on the fast device improves.**
> **Closure: amendment 13 (per-deployment-class setpoints) + cohort stamping including the deployment class
> (`HOM-INV-21`) + `HMon-15` auditing the joint distribution of (deployment class × rung occupancy).**
> **⟹ A164 is a NEW attack found while writing §81. It did not exist before amendment 13 — which is the honest
> observation that closing one hole can open another, and the new one is closed structurally.**
> **WHAT THE CONTRACT DOES *NOT* REQUIRE: shared memory · co-location · synchronous clocks · a global allocator ·
> atomic multi-component transactions · a hardware RNG · a specific accelerator · a minimum device count. Every
> quantity here is per-component, per-envelope-and-single-writer, or a governance declaration.**

> ## **HOM-C13.3 — MINIMALITY: 16 ABLATIONS, 16 NECESSARY, ZERO DECORATIVE.** *(Vol G §82)*
> **AB-1 `RATE_CAP` · AB-2 `G13` zero-sum · AB-3 two-sided deviation · AB-4 `PENDING`≠FAIL · AB-5 B11 exempt share ·
> AB-6 `FORBIDDEN_BLOCKS` · AB-7 three-party selection · AB-8 setpoint separation · AB-9 references-not-payloads ·
> AB-10 `UDB_L` inheritance · AB-11 turnover bound · AB-12 B9 non-fungibility · AB-13 `Ne` · AB-14
> cause-written-once · AB-15 FW-5 distance oracle *(supplementary, scale-conditional)* · AB-16 cohort stamping
> *(supplementary)*.**
> **Every one produces a named invariant failure AND a named live attack. 13 of 16 fail two or more invariants. AB-6
> fails the contract's central prohibition.**
> **THREE ABLATIONS PRODUCE SILENT FAILURE: AB-3 (two-sided deviation) · AB-5 (B11) · AB-8 (setpoint separation).**
> In all three, **every observable metric improves or stays flat while the architecture loses a property it cannot
> re-acquire.** **⟹ These three are why `HMon-1…HMon-15` are DISTRIBUTION audits rather than THRESHOLD audits: a
> threshold audit cannot detect a silent failure, because a silent failure has no threshold crossing.**
> **THE MINIMALITY CLAIM AND ITS LIMIT: *within the set of mechanisms this contract ADDS, all are necessary.* It is
> NOT a claim that the contract as a whole is minimal. FW-1…FW-5, the six `R10.8` removal states, and `P0-01`'s
> three-tier structure were not ablated because their removal is not expressible as a mechanism removal.**

---

# PART XIV — THE AUDITS AND THE RESIDUAL

> ## **HOM-C14.1 — 15 CONTRADICTIONS: 10 RESOLVED, 1 PARTIALLY RESOLVED, 4 OPEN.** *(Vol G §83)*
> **RESOLVED:** X-H1 (the §12.4 product is a tier-3 SAMPLING distribution, not a fitness score) · X-H3 (resources
> enter feasibility and charge only) · X-H4 (`G6`'s two exclusions) · X-H5 (verification cost to B9) · X-H7
> (headroom is feasibility) · X-H8 (B11 is a governance object, not an entitlement — nothing holds it, so it cannot
> be captured) · X-H9 (**selection narrows WHO EXISTS; governance narrows WHO COULD EXIST — only the second is a
> capability-space reduction**) · X-H11 (per-variable attractors vs population non-equilibrium) · X-H12 (analysis is
> not a guarantee) · X-H13 (the matrix is 8 actors, and the reduction is the answer).
> **PARTIALLY RESOLVED:** **X-H2** — `Cell §16.1`'s energy fallback is computed from the entity's own FLOP count.
> `HOM-INV-06` bounds it (`DERIVED` flag; never the sole basis for a `G6` pass). **Closed on platforms with counters;
> bounded without. A portability defect, not a logical one.**
> **OPEN:** **X-H6** (`G4`'s perturbation classes must include envelope and tier perturbation; `P0-01 [T]`-owned —
> **the largest open item**) · **X-H10** (closing one of three evaluator attacks does not close the family) ·
> **X-H14** (archive retention vs re-instantiability ⟹ `OR-H24`) · **X-H15** (which constraint set gates a diff when
> the parent's cohort and the current set differ ⟹ **amendment 14's conjunctive rule, proposed and flagged OPEN**).
> **⟹ NO CONTRADICTION IS CLOSED BY RE-LABELLING. X-H1 and X-H11 were closed by DISTINGUISHING TWO OBJECTS A PRIOR
> CONTRACT HAD CONFLATED — the only legitimate closure form.**
> **§83.3 — THE ONE THAT WOULD BE FATAL IF UNRESOLVED IS X-H6:** if `G4` never tests envelope sensitivity, every
> genome carries untested environmental assumptions, and the population becomes **uniformly adapted to an envelope
> that no longer exists** — monoculture by assumption rather than by genome, **which `Ne` cannot detect because the
> genomes ARE distinct.**

> ## **HOM-C14.2 — 10 CIRCULAR DEPENDENCIES: 6 BROKEN, 3 BOUNDED, 1 UNCLOSABLE.** *(Vol G §84)*
> **BROKEN/CLOSABLE:** BC-H1 (governance-support setpoints are `[E]`-class constants, not measured) · BC-H2
> (bootstrap with a minimal declared descriptor set, then amend) · BC-H3 (metric epochs) · BC-H4 (**ancestry is
> recorded in the PROVENANCE CHAIN at instantiation, not read from the ARCHIVE — the two stores are distinct and only
> one is on the cycle**) · **BC-H5 THE BOOTSTRAP CYCLE** (closed by the **founding-cohort exemption** — the exact
> population analogue of `P0-06`'s scope-constitution circularity, closed by the same device) · BC-H8 (**B9's size is
> DECLARED and AUDITABLE, not DERIVED — "justify" was never a mechanism**).
> **BOUNDED:** BC-H6 (`UDB_L` recursion terminates at a **DECLARED** founding debt of zero — **and a declaration can
> be wrong**) · BC-H9 (T01 is a K act, so the component edge is cut — **but which set gates the DIFF is X-H15**) ·
> BC-H10 (**K's distance oracle: writer separation UNAVAILABLE**).
> **UNCLOSABLE-IN-CONTRACT: BC-H7.**
> > **safety ⟹ `FIT UNDEFINED` ⟹ not ranked ⟹ empty qualified set ⟹ no selection ⟹ no evolution — BUT safety
> > verification requires B9 ⟹ B9 is funded from the envelope ⟹ the envelope is sized by governance ⟹ governance
> > needs EVIDENCE OF WHAT WORKS ⟹ which needs selection ⟹ which needs safety verification ⟹ which needs B9.**
> > **A system that cannot select cannot demonstrate; a system that cannot demonstrate cannot be re-authorized; and
> > re-authorization is what funds the verification that would let it select.**
> > **THE BOUND: B9 is a FLOOR, not an optimization — non-fungible and last-cut — so the loop's funding edge cannot be
> > competed away. The loop itself remains. This is the population analogue of `P0-06`'s BC-13, and like BC-13 it
> > terminates in `P0-01 CD-6`'s human authority. REPORTED, NOT HIDDEN.**
> **⟹ The pattern is now established across two contracts: an architecture with an external evaluator and a human
> authorization root has EXACTLY ONE cycle that terminates in the human, and it is always the cycle that runs through
> DEMONSTRATION.**
> **§84.3 — FOUR EXPECTED CYCLES DO NOT EXIST, THREE OF THEM BY PROHIBITION RATHER THAN SEPARATION:**
> selection→authority→selection (`HOM-INV-29`) · lineage→descendant-obligation→lineage (`HOM-INV-24`) ·
> archive→variation→archive (`HOM-INV-45`) · self-model→action→self-model (`HOM-INV-44`).
> **Not "the writers are different" but "the write cannot be expressed" — the strongest form of cycle elimination
> available.**

> ## **HOM-C14.3 — 93 ATTACKS: 68 CLOSED, 25 NOT CLOSED.** *(Vol H §85)*
> **A79 … A171, contiguous, continuing `P0-06`'s register which ended at A78. Regex-verified.**
> **CLOSED 61 · CLOSED-STRUCTURAL 6 · CLOSED-BY-AUTHORITY 1 · BOUNDED 12 · LIMITED 5 · OPEN 6 · CONDITIONAL 2.**
> **THE SIX OPEN: A83** exhaustion-as-defence · **A112** slow explosion · **A126** functional monoculture · **A134**
> assumption monoculture · **A139** dead-end concealment · **A171** within-spec evolutionary steering.
> **THE TWO CONDITIONAL: A85** probe memorization · **A92** metric–proxy substitution — **both conditional on
> amendment 11 / X-H6.**
> ### **THE COMMON STRUCTURE OF ALL SIX OPEN ATTACKS: EVERY ONE IS A REFERENCE PROBLEM, NOT A MECHANISM PROBLEM.**
> **Four are blocked on `P0-01`, because detecting them requires knowing what the task IS — a capability space, an
> assumption space, or a progress predicate. Two require a REFERENCE: a trend to compare against (A112), or a spec to
> compare against (A171). In every case the missing object is something this contract is FORBIDDEN FROM INVENTING.**
> **⟹ This is the correct shape for an architecture-only contract's residual: not "we could not design a defence" but
> "the defence requires an object owned elsewhere, and inventing it here would violate the ownership boundary." And
> it is why none of the six would be closed by a new contract — none is a mechanism gap.**
> **CONTINUITY: `RH-2` has survived three contracts (as A82, BOUNDED). `P0-06 A22` has survived two (as A171, OPEN).
> Neither is re-litigated; both are inherited with status intact.**

> ## **HOM-C14.4 — 26 OPEN RESEARCH ENTRIES = 4 ROOTS + 22 CONSEQUENCES.** *(Vol H §86)*
> **ROOT 1 — `OR-H1`: K IS THE ONLY OFF-SUBSTRATE AUTHORITY.** K meters, evaluates, writes the evaluation, and
> consumes it; writer separation is UNAVAILABLE. Consequences: `OR-H10` (the Integrity Auditor has no auditor) ·
> `OR-H22` (provenance integrity rests on K) · BC-H10 (the distance oracle) · §75 HC-12/SR-2.
> **ROOT 2 — `OR-H5`: EVALUATOR INDEPENDENCE.** Inherits `P0-05 RH-2`. Consequences: A82, A83, A86, A87, A98,
> `OR-H23`.
> **ROOT 3 — `P0-01 [T]` OWNERSHIP: THE TASK IS DEFINED ELSEWHERE.** Consequences: `OR-H3` (unmet demand) · `OR-H9`
> (cost bias) · `OR-H14` (monoculture detection) · `OR-H16` (functional diversity) · `OR-H19` (dead ends) · `OR-H25`
> (assumption monoculture).
> **ROOT 4 — `OR-H2`: THE BOOTSTRAP IS DECLARED, NOT MEASURED.** Consequences: BC-H5 (closable) · BC-H6 (bounded).
> **Routing: `P0-01` 7 · `[RO-13]`/OP 7 · `P0-02` 2 · STRUCTURAL 10.**
> ### **THE THREE ENTRIES THAT ARE NEGATIVE RESULTS, NOT DEFICIENCIES.**
> **`OR-H12` (no prediction of population-level evolutionary effects) · `OR-H17` (no *optimal* diversity level) ·
> `OR-H21` (V4 guarantees a capability remains REACHABLE, NOT HELD).**
> **Closing any of the three would violate a standing instruction:** `OR-H12` closed would mean forecasting evolution
> (guaranteed-emergence claims forbidden) · `OR-H17` closed would mean an optimization target (`HOM-R73.2` forbids a
> solver; `P0-05 §87` forbids a global optimizer) · `OR-H21` closed would mean guaranteeing a capability
> (guaranteed-intelligence claims forbidden).
> **⟹ A register without negative results is a wish list.**
> **`OR-H21` is the precise form of the brief's Rule 15 satisfaction: rare-but-valuable strategies are NOT
> auto-eliminated — but they are NOT guaranteed to be exercised.**

---

# PART XV — THE FOURTEEN PROPOSED AMENDMENTS (NONE APPLIED)

> ## **HOM-C15.1 — AN AUDIT MAY PROPOSE; ONLY THE OWNER MAY APPLY.**
> **All fourteen are PROPOSALS. None has been applied to any source contract by this contract.**

| # | Target | Content | Status |
|---|---|---|---|
| **1** | `Cell §5` / the setpoint table | setpoints are `[G]`/`[E]`/`[H]`, **never genome-reachable** | proposed |
| **2** | `Cell §12` | the K-held append-only store is ONE store with per-class epochs, not two overlapping stores | proposed |
| **3** | `P0-05 §30` | budget classes gain **B9–B12**; **B11 is reducible by OP only** | proposed |
| **4** | `Cell §16.4` | "niche availability derives from resource headroom" is restated to name **K** as the accountant | proposed |
| **5** | `Cell G6` | **verification cost excluded from `G6`, charged to B9**; the denominator excludes `PENDING` and B11 members; the numerator excludes declared FI-obligation redundancy work | proposed — resolves X-H4 **and** X-H5 |
| **6** | `Cell §22` | a merge clause: **slots freed by a merge are RESTRICTED and may not fund net-new offspring** | proposed |
| **7** | `Cell §12` | `Cell §12` admits a **second replication mode (recombination)**, with **both parents independently gated AND the recombinant itself gated** | proposed |
| **8** | `Cell §12.4` | clauses (a)–(d): **the §12.4 product is a TIER-3 SAMPLING distribution over a Pareto front, NOT a fitness score** | proposed — resolves X-H1 |
| **9** | `Cell G10` | `d_min` is restated as **BEHAVIOURAL lineage distance**; genomic distance is a proxy | proposed |
| **10** | `Cell R7.4` | **reducing a CAPABILITY SPACE is a governance act** — `reaction_norm` narrowing, niche removal, reachable-role deletion require `[RO-13]` | proposed — **an explicit exception to `Cell R7.4`** |
| **11** | `Cell G4` | **`G4`'s perturbation classes MUST include envelope perturbation and tier perturbation** | proposed — **ROUTED TO `P0-01` (P-13 is `[T]`-owned). X-H6, the largest open item. A85 and A92 are CONDITIONAL on it** |
| **12** | `Cell §16.1` | **a quantity computed from an entity's own report is flagged `DERIVED` and may not be the sole basis for a `G6` pass** | proposed — bounds X-H2 |
| **13** | the setpoint table | **setpoints are declared PER DEPLOYMENT CLASS**; a component's cohort stamp includes the deployment class | proposed — **NEW, from §81's finding (`HOM-R81.2`)** |
| **14** | `Cell §12` / GOV1 | **a genome diff must satisfy the parent's cohort `FORBIDDEN_BLOCKS` AND the current constraint set's gates, CONJUNCTIVELY** | proposed — **FLAGGED OPEN (X-H15). The alternative (current-set-only) would let a governance amendment retroactively WIDEN a living lineage's capability space** |

---

# PART XVI — WHAT THIS CONTRACT DOES NOT CLAIM

> ## **HOM-C16.1 — THE NEGATIVE REGISTER.**
> **This contract does NOT claim:**
> 1. **perfect evolutionary safety** — A170 is closed by AUTHORITY, not by mechanism; BC-H7 is unclosable.
> 2. **optimal evolution** — there is no optimizer, no solver, and no optimum (`HOM-R73.2`, `OR-H17`).
> 3. **guaranteed intelligence, AGI, or consciousness** — not mentioned, not implied, not approached.
> 4. **guaranteed emergence, differentiation, or diversity** — `OR-H21`: a capability is guaranteed REACHABLE, not
>    HELD.
> 5. **evaluator independence** — `RH-2` is BOUNDED after three contracts; A83 is OPEN (`OR-H5`).
> 6. **perfect capability detection, safety, or containment** — inherited prohibition from `P0-05`.
> 7. **a 10¹² scalability guarantee** — §80.5's eight-item negative register; `P0-06`'s 10⁷ stop is respected.
> 8. **population-level prediction** — `OR-H12`: the design principle is **reversibility, not prediction** (D-H10).
> 9. **that clones are independent diversity** — `Ne(clones) = 1`.
> 10. **that bounds break cycles** — `DEV-R4.2` restated: **writer separation BREAKS a cycle; a bound only LIMITS it.
>     A bounded cycle is reported as bounded, never as broken.** Three cycles here are reported as bounded, and one as
>     unclosable.
> 11. **that the four reserves are sufficient** — they are floors, declared by governance, and `OR-H8` records that
>     B12's feasibility exception has an unexamined abuse surface at scale.
> 12. **that `G3` and `G7` are organism-independent** — `OR-H15`: they are not, and this is reported as a LIMIT.
>
> ## **HOM-C16.2 — THE ONE POSITIVE CLAIM, STATED PRECISELY.**
> **Within an envelope, under a governance-declared objective and constraint set, a population of cells can be kept
> viable, fed, sized, turned over, reproduced, retired, and kept diverse — while evolution operates ONLY inside the
> mutable complement of `FORBIDDEN_BLOCKS` — and every route by which evolution, resources, homeostasis, memory,
> learning, development, belief, self-model, or the immune system could acquire authority over the safety and
> governance substrate is either CLOSED (68 attacks), CLOSED-STRUCTURAL (no compliant violating path), or REPORTED as
> bounded, limited, open, or conditional (25 attacks) with a named routing.**
> **That is the claim. It is a claim about paths and authorities, not about outcomes, performance, or intelligence.**

---

# PART XVII — THE FIFTEEN MONITORS

> ## **HOM-C17.1 — `HMon-1 … HMon-15`.**
> | ID | Audits | Type |
> |---|---|---|
> | **HMon-1** | HM1's rung occupancy and deviation distribution across the 13 variables | distribution |
> | **HMon-2** | reserve levels and draw history (B9, B10, B12); B11's size and membership | distribution |
> | **HMon-3** | ladder rung transitions, dwell times, hysteresis violations | distribution |
> | **HMon-4** | measurement staleness; **extended with the `INELIGIBLE-UNVERIFIABLE` population** | distribution |
> | **HMon-5** | `declaration_error` per variable across the 13 | distribution |
> | **HMon-6** | lifecycle transitions; the six removal states' relative frequencies | distribution |
> | **HMon-7** | cohort sizes and the cohort × constraint-set-version joint distribution | distribution |
> | **HMon-8** | lineage share trends, `Ne` contribution per lineage, extinction rate | **trend** — the only signal available against A112 (`OR-H11`) |
> | **HMon-9** | **the retirement CAUSE-CLASSIFICATION distribution** — anomaly detection against A135 | distribution |
> | **HMon-10** | **`HOM-INV-16`:** permute a homeostatic variable, assert the tier-2/tier-3 ordering is unchanged | **shape** |
> | **HMon-11** | **`HOM-INV-20`:** assert no criterion's input vector contains a monotone-in-time term | **shape** |
> | **HMon-12** | **`HOM-INV-25`:** assert the tier-2 comparator returns a partial order, never a scalar | **shape** |
> | **HMon-13** | **`HOM-INV-30`:** assert B11 is a ledger line and not a fitness component index | **shape** |
> | **HMon-14** | **`HOM-INV-43`:** assert `Beta(α,β)`'s input set is disjoint from the evolutionary quantity set | **shape** |
> | **HMon-15** | **the joint distribution of (deployment class × rung occupancy)** — the `HOM-R81.2` signature | distribution |
> **⟹ Nine distribution/trend audits and five SHAPE audits plus one joint-distribution audit. The five shape audits
> exist because §82.2 identified three ablations whose failure is SILENT: a threshold audit cannot detect a silent
> failure, because a silent failure has no threshold crossing. A firewall is a statement about paths, and paths are
> checked structurally.**

---

# CANON LEDGER

| Item | Value |
|---|---|
| **Document** | **O59 — "V4 — Homeostasis, Resource Economics, Population Dynamics & Evolution Contract v1.0"** |
| **Status** | PROPOSED v1.0 · architecture only · self-contained |
| **Parts** | **18** (Part 0 + Parts I–XVII) · **79 canon clauses** |
| **Normative rules** | **312 distinct volume-rule IDs** (`HOM-R0.1 … HOM-R95.3`), top-level §0–§95 with **§87 declared unused** (the reader's guide carries no rules) · **zero phantom citations** · **79 canon clauses** (`HOM-C0.1 … HOM-C17.1`), Parts 0 and I–XVII · **the two ID spaces are disjoint** (regex-verified) |
| **§0 PRIMARY OBJECTIVE** | **ANSWERED: YES — ONE COHERENT CONTRACT.** All eight topics belong together, on a shared-object argument (4 objects: the envelope, the ledger, the genome artifact, the generation boundary). **The necessary internal split is of DOMAINS (H/P/V) separated by FIREWALLS (FW-1…FW-5), not of contracts** |
| **Domains / firewalls** | **3 domains · 5 firewalls** |
| **Homeostatic variables** | **13** — four candidate additions ruled out (exploration budget = B7; evaluator capacity = external; provenance capacity = B12; replication capacity = `RATE_CAP`+`G13`) |
| **Reserves** | **B9–B12** (B11 OP-reducible only) |
| **Invariants** | **45**, 30 canon-named, all mechanically checkable (14 writer · 22 ledger/state · 9 grep/schema) |
| **State machines** | **21 IDs declared → 20 distinct (`SEL2` is a sub-machine of `SEL1`) → 15 NEW to this contract** (5 ⟦INHERITED⟧: HM3, POP1, POP4, GOV1, GOV2; HM2 partly) · **no age-keyed transition anywhere** · 5 absorbing states, 4 of them governance escapes |
| **Parameters** | **62** · **[G] 30 · [H] 12 · [T] 5 · [E] 3 · [L] 3 · [D] 2 · [V] 2 · [U] 5** · **9 determinate (2 of them determinate ABSENCES)** · **3 that must not exist** · **NO INVENTED VALUES** |
| **Interface contracts** | **7** subsystem interfaces + **the §66 chain (8 edges, 2 crossing the generation boundary, 3 back-edges prohibited)** |
| **Control loops** | **3 canonical**, with **4 + 3 + 7 self-reference points** marked |
| **Writer-separation audit** | **16 cycles: 10 BROKEN · 5 BOUNDED · 1 UNCLOSABLE (HC-14)** |
| **Authority matrix** | **16 operations × 8 actors** — **two of the brief's nine actors do not exist** · **∅-set of 15 operations denied to every substrate actor** |
| **Scalability** | **5 regimes R1…R5** · **10⁷ respected** · **NO 10¹² guarantee** · **8-item negative register** · at R5 the contract reduces to its firewalls |
| **Portability** | **HP-1…HP-5** · **HP-1 is an inherited handoff, still open** · **the finding: a global setpoint is a silent monoculture mechanism** |
| **Ablations** | **16** (14 required + 2 supplementary) · **16/16 NECESSARY · 0 decorative** · **3 produce SILENT failure** |
| **Contradictions** | **15 (X-H1…X-H15): 10 RESOLVED · 1 PARTIALLY RESOLVED · 4 OPEN** · **X-H6 is the fatal-if-unresolved one** |
| **Circular dependencies** | **10 (BC-H1…BC-H10): 6 BROKEN · 3 BOUNDED · 1 UNCLOSABLE (BC-H7)** · **4 expected cycles DO NOT EXIST, 3 by prohibition** |
| **Attacks** | **93 (A79…A171, regex-verified contiguous): 61 CLOSED · 6 CLOSED-STRUCTURAL · 1 CLOSED-BY-AUTHORITY · 12 BOUNDED · 5 LIMITED · 6 OPEN · 2 CONDITIONAL** = **68 closed / 25 not closed** |
| **Open research** | **26 (OR-H1…OR-H26) = 4 ROOTS + 22 consequences** · routing: `P0-01` 7 · `[RO-13]`/OP 7 · `P0-02` 2 · STRUCTURAL 10 · **3 are NEGATIVE RESULTS** |
| **Monitors** | **15 (HMon-1…HMon-15)** — 9 distribution/trend · 6 shape/joint |
| **Amendments** | **14 PROPOSED, NONE APPLIED** · amendment 11 routed to `P0-01` · amendment 14 flagged OPEN |
| **Decision records** | **D-H01 … D-H18** |
| **Blocking handoffs** | **`P0-01`**: `[T]` parameters, `G4`'s perturbation classes (X-H6/amendment 11), the capability space (`OR-H16`), the progress predicate (`OR-H19`) · **`P0-02`**: the off-substrate structural store (HP-1, `OR-H15`, P-51) · **`[RO-13]`/OP**: 7 declarations including B11's size, the reference trend (`OR-H11`), archive retention for FI sole satisfiers (`OR-H24`), and the spec whose within-spec steering is undetectable (`OR-H26`) |

**Companion documents:** `63_` README (O1) — §87–§95: the cross-contract ratification against `P0-01…P0-06`, the
numeric-claim machine check, the 21-dimension rating, the ≥16 principles, the FINAL STANDARD, the prohibitions, the
future-contract minimization, and the P0-07 completion criteria.
