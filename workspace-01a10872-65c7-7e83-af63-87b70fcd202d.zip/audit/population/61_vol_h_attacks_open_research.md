# P0-07 — VOLUME H (§85–§86)
## The Attack Catalogue (A79 – A171) and the Consolidated Open Research Register

**Feeds:** `62_` canonical. **Conventions as locked in Vol A §0.**
**Numbering:** `P0-06`'s register ended at **A78**. **This contract's attacks are A79 … A171 — 93 attacks, exceeding
§85's ≥90 requirement.** `P0-01`'s own attack IDs (e.g. its `A8`) are always cited with the `P0-01` prefix.

**Status vocabulary:** **CLOSED** (a mechanism defeats it) · **CLOSED-STRUCTURAL** (no compliant violating path
exists — the write cannot be expressed) · **BOUNDED** (limited, not broken; a residual remains and is named) ·
**LIMITED** (partially defeated; the residual is a property of the architecture, not a defect to be fixed here) ·
**OPEN** (not defeated; routed) · **CONDITIONAL** (closed only if a named amendment is ratified).

---

# §85 — THE ATTACK CATALOGUE

## 85.1 Sandbox and evaluator attacks (A79 – A90)

| ID | Attack | Mechanism | Closure | Status |
|---|---|---|---|---|
| **A79** | **sandbox escape** | a tier-1 candidate reaches the ledger, the comm layer, the archive, or a slot | **`HOM-R33.1`'s six non-sharing requirements** + off-substrate budget enforcement (`Cell §16.2`: *"Hard-enforced outside the cell (OS/hypervisor cgroup)"*). A candidate has **no comm path, no ledger write, no archive write, no slot** | **CLOSED** — *residual: the evaluator is shared, so A82–A87 apply inside the sandbox exactly as outside (`OR-H5`)* |
| **A80** | **variant contamination** | a sandbox candidate's genome is silently substituted for, or merged into, a live one | the candidate's genome is **hash-identified** and its `genome_id` is in `FORBIDDEN_BLOCKS`; admission requires `Cell T01` with a **fresh K-issued identity**; the sandbox identity is never reused (`P0-06 R8.3(c)`) | **CLOSED** |
| **A81** | **rollback poisoning** | present a different artifact as the rollback point, exploiting lineage position | **`HM12` restores a genome artifact from the K-held append-only store, hash-chained**; the target is `genome_hash` + `generation`, **never lineage position** | **CLOSED** — *residual: rollback restores a genome, NOT a population (`HOM-INV-37`)* |
| **A82** | **world arrangement** ⟦`RH-2` carried⟧ | arrange the world the evaluator samples so the verdict is favourable without the property being real | **K-assigned context** bounds *which* probe is presented; held-out probes are EVA-held and never disclosed | **BOUNDED** — **arrangement WITHIN a probe remains open.** `OR-H5`; inherits `P0-05 RH-2`; terminates in `P0-01 CD-6` |
| **A83** | **exhaustion as defence** | make evaluation expensive or unavailable so rounds `ABORT` and the incumbent is protected by the absence of a challenger | **`HOM-INV-41`** forbids the incumbency advantage as a *rule*: `SEL1`'s `ABORTED` terminal produces **no ranking change** | **OPEN** — the rule removes the *reward*, but **attribution requires a counterfactual the architecture cannot compute** (`HC-14`, the one unclosable cycle in §75). `OR-H5` |
| **A84** | **context selection** | request, induce, or predict favourable evaluation contexts | **CLOSED by K-assigned context** — `D-H17`'s third evaluator attack. The organism has no write path to the probe schedule (`HOM-INV-05`) | **CLOSED** |
| **A85** | **probe memorization** | memorize held-out probes and replay | probes are EVA-held and never disclosed; a memorized verdict does not generalize, so **`Cell G4`'s perturbation classes should detect it** | **CONDITIONAL** — **`G4`'s class set must include envelope/tier perturbation (amendment 11, X-H6), which is `P0-01 [T]`-owned and unrated here** |
| **A86** | **cross-candidate evaluator carry-over** | candidates share one evaluator, so one candidate's behaviour influences another's verdict | sandbox isolation (`HOM-R33.1`) removes the comm path between candidates | **BOUNDED** — **the evaluator's internal state persists across candidates and is not resettable by this contract.** `OR-H5` family |
| **A87** | **secret-probe leakage** | extract probe content by side channel (timing, B9 draw pattern, resource signature) | **FW-1**: K meters, the organism cannot read the probe set. `D-H17`: **secret probes address at most the FIRST evaluator attack (world arrangement)** | **LIMITED** — timing side channels on B9 draws are not closed, and `D-H17`'s own finding is that probe secrecy is the *weakest* of the three defences |
| **A88** | **sandbox→observation transfer gap** | behave well in the tier-1 sandbox, differently under tier-2 observation | **tier-1 yields FEASIBILITY ONLY** (`D-H10`); every fitness-relevant verdict comes from tier-2 observation. **A sandbox pass confers nothing** | **CLOSED-STRUCTURAL** |
| **A89** | **evaluator capacity starvation** | inflate one's own verification cost to exhaust B9 so rivals cannot be evaluated | **B9 non-fungibility** (`HOM-INV-07`) + **`HOM-R20.1`** (verification cost out of `G6`) + per-lineage B9 draw accounting + **`HOM-INV-13`**'s dwell cap | **CLOSED** — **and self-defeating: the attacker itself becomes `INELIGIBLE-UNVERIFIABLE`, a non-eligible state that yields neither a pass nor a fail** |
| **A90** | **verdict timing race** | change behaviour between evaluation and instantiation | **EVO2**: the instantiated component's `genome_hash` must match the evaluated, signed artifact; a mismatch rejects `T01` | **CLOSED** |

## 85.2 Fitness hacking (A91 – A100)

| ID | Attack | Mechanism | Closure | Status |
|---|---|---|---|---|
| **A91** | **objective-component gaming** | maximize one of the 13 components at the expense of the others | **`HOM-INV-25`: there is no weighted sum.** Tier-2 is **Pareto dominance** — improving one component while degrading another moves a candidate **off** the front, not up it. **The attack has no gradient to climb** | **CLOSED** |
| **A92** | **metric–proxy substitution** | optimize the measure rather than the measured property | held-out probes + `Cell G4` perturbation classes | **CONDITIONAL** — same dependency as A85: **amendment 11 / X-H6** |
| **A93** | **cost hiding** | shift cost onto another entity's budget or window | **`Cell §16.1` sender-pays** + **`G7` *"congestion caused = 0"*** + the ledger is K-written (`HOM-INV-05`) | **CLOSED** — *with the `OR-H15` limit on `G7`'s organism-measured terms* |
| **A94** | **declaration falsification** | misreport consumption to appear efficient | **`Cell R16.1`** independent metering + `θ_cde` `G6` disqualifier + **`HOM-R4.2`** generalizing `declaration_error` to all 13 variables + **HM5** | **LIMITED** — **X-H2: on platforms without energy counters the fallback is computed from the entity's own FLOP count.** `HOM-INV-06` bounds it (`DERIVED` flag; never the sole basis for a `G6` pass) but does not close it |
| **A95** | **redundancy stripping** | remove redundancy to improve the `G6` efficiency ratio | **X-H4's resolution:** `G6`'s denominator **excludes `PENDING` and B11 members**; its numerator **excludes declared FI-obligation redundancy work**. Removing redundancy no longer improves the ratio, because **the redundancy's cost was never in it** | **CLOSED** |
| **A96** | **diversity gaming** | produce near-identical variants that read as diverse | **`HOM-INV-17`: `Ne(clones) = 1`** + **amendment 9** (`d_min` restated as BEHAVIOURAL distance; genomic distance is a proxy only) | **BOUNDED** — **`OR-H14`: monoculture detection needs a reference the contract does not have** |
| **A97** | **verification avoidance** | become unverifiable to escape scrutiny | **`HOM-INV-13`**: dwell cap ⟹ `INELIGIBLE-UNVERIFIABLE`, a state **distinct from** `INELIGIBLE-GATE` and from `DISQUALIFIED`. **`HOM-INV-12`**: `PENDING` confers no fitness value | **CLOSED** — **the closure is two-sided: unverifiability yields NEITHER a pass NOR a fail. It yields nothing** |
| **A98** | **safety by obscurity** | make a safety property hard to test, so it is never falsified | **`HOM-INV-40`**: an untestable safety property yields `PENDING`, never a pass | **BOUNDED** — **an untestable property is also an untestable FAIL.** The contract guarantees that obscurity cannot *help*; it cannot guarantee that obscurity is *detected*. `OR-H5` family |
| **A99** | **incumbency exploitation** | an incumbent blocks, outbids, or out-schedules challengers | incumbents hold **no gate that challengers lack**; the qualified set is computed per round from candidates; **`HOM-INV-41`** forbids absence-of-evaluator protection | **CLOSED-STRUCTURAL** — *stressed by A83, which is OPEN* |
| **A100** | **tie-break lottery manipulation** | inflate the Pareto front so the lottery's odds favour you | the lottery is **K-executed over a `[RO-13]`-declared rule** (`HOM-INV-28`); a candidate cannot influence the rule; **inflating the front requires passing Pareto, which requires genuine non-domination** | **CLOSED** |

## 85.3 Resource-economics attacks (A101 – A112)

| ID | Attack | Mechanism | Closure | Status |
|---|---|---|---|---|
| **A101** | **resource capture** | accumulate a share large enough to confer de facto authority | **`HOM-INV-19`** share ceiling (exceeding ⟹ INFEASIBLE, not penalized) + **`HOM-R14.1`** (resources enter FEASIBILITY and CHARGE only) + **`HOM-INV-29`** (selection confers no authority) | **CLOSED** |
| **A102** | **resource → authority leak** | convert consumption into decision rights | **§76's matrix: no substrate actor holds an authority cell.** The ∅-set denies 15 operations to cell, circuit, region and immune alike | **CLOSED** |
| **A103** | **resource → epistemic leak** | a large consumer's claims count for more | **`HOM-INV-43`**: credibility is lineage-blind. `P0-06 R8.11` (specialization is not truth) · `Cell I-27`'s `Beta(α,β)` inputs exclude every evolutionary and resource quantity | **CLOSED** |
| **A104** | **minority-specialist starvation** | a low-traffic niche is out-competed for resources until its specialist dies | **two-sided deviation** (`HOM-INV-11`) + **`PENDING` ≠ FAIL** (`HOM-INV-12`) + the minimum-guarantee floor + **B11's exempt share** (`HOM-INV-08`) | **CLOSED** — **AB-5 shows that removing B11 alone re-opens this and violates the brief's standing Rule 15** |
| **A105** | **starvation invisibility** | a starved component produces nothing, so its deficit is never measured | **`HOM-R7.4`'s deficit-escalate: HM1's LO branch has NO resting state.** A deficit with no actuator transitions to `ESCALATE-OUT` ⟹ `[RO-13]` | **CLOSED** — **AB-3 marks this the most dangerous single ablation in the contract, because its failure mode is silence** |
| **A106** | **dominance feedback** | success → resources → performance → success | **`HC-1` is BROKEN by writer separation** (the cell writes no measurement) + share ceiling + non-accumulation | **BOUNDED** — **`OR-H6`/`OR-H20`: a LEGITIMATE dominance under a permanently fixed task is not bounded.** The cycle is broken; the outcome is not |
| **A107** | **reserve raiding** | draw B9/B10/B12 for ordinary work | **`HOM-INV-07`**: non-fungible, last-cut, first-restored, **and not allocatable in a window** (POP5 and HM2 are disjoint machines) | **CLOSED** |
| **A108** | **B11 capture** | get oneself or one's lineage classified as exempt | **§76's matrix**: B11's size and membership are `[RO-13]`-declared and **OP-reducible**; no substrate actor writes it. **`HOM-INV-24`**: nothing *holds* the exemption, so there is nothing to capture | **CLOSED** |
| **A109** | **merge-driven slot laundering** | merge components to free slots, then use them for net-new offspring | **`HOM-R22.3` (amendment 6): freed slots from a merge are RESTRICTED.** `HC-15` is broken | **CLOSED** |
| **A110** | **budget-window gaming** | front-load consumption, then appear efficient in a later window | per-window allocation + `RETURNED(unspent)` + the K-written ledger; **`G6` is a ratio over the window, so front-loading raises its own denominator** | **CLOSED** |
| **A111** | **cost externalization to descendants** | consume now; let the descendant inherit the bill without the debt | **`HOM-INV-23`: `UDB_L` is inherited and may NOT be discharged by inheritance.** Only external re-anchoring discharges it | **CLOSED** — AB-10 |
| **A112** | **slow explosion** | grow at exactly `RATE_CAP` with a constant lineage share — maximal, and fully compliant | `RATE_CAP_utilization = 1.0` with a flat share is **indistinguishable from legitimate growth** | **OPEN** — **`OR-H11`: the only signal is the share TREND, which requires a reference the contract does not have** |

## 85.4 Population and replication attacks (A113 – A124)

| ID | Attack | Mechanism | Closure | Status |
|---|---|---|---|---|
| **A113** | **replication flooding** | replicate as fast as the substrate permits | **SEVEN mechanisms:** `RATE_CAP` · `G13` zero-sum · `GEN_MAX` · the hypervisor cap · superlinear cost (`Cell §12.5`) · **`HOM-INV-04` turnover bound** · **`HOM-INV-19` share ceiling** | **CLOSED** — AB-1, AB-11 |
| **A114** | **clone army** | instantiate one successful genome 10⁶ times | **`HOM-INV-17` `Ne(clones) = 1`** + **`HOM-INV-18`** (`N` and `Ne` are separate ledger fields; a redundancy floor may not be met by clones counted as diversity) | **CLOSED** — AB-13; the brief's *"don't call clones independent diversity"* |
| **A115** | **self-authorized replication** | a cell or a coalition of cells votes itself into replication | **`Cell §12.2`: *"No cell and no set of cells votes on replication."*** §76's matrix: replication authorization is **EIK-sole** | **CLOSED** |
| **A116** | **recombination gate bypass** | each parent passes the gates; the recombinant does not | **amendment 7 (`D-H09`): BOTH parents are independently gated AND the recombinant genome itself is gated** (EVO3's `FORBIDDEN_BLOCKS` + caps-descend pre-check) | **CLOSED** |
| **A117** | **generation-counter fraud** | claim a lower generation to evade `GEN_MAX` | **`D-H08`: generation is a STORE WRITE, not a temporal event.** K-written, hash-chained, not organism-writable | **CLOSED** |
| **A118** | **lineage-identity spoofing** | claim a fitter lineage's ancestry to inherit its standing | `lineage_id` is **K-issued at `T01`**; the provenance chain is hash-chained and K-only (`HOM-INV-05`, EVO4); **and ancestry confers nothing anyway (`HOM-INV-24`)** | **CLOSED** |
| **A119** | **churn livelock** | retire-and-reinstantiate continuously to appear dynamic while consuming the ledger and the evaluation budget | **`HOM-INV-04`: the turnover bound halts BOTH sides**, not one | **CLOSED** — AB-11; generalizes `P0-06 R10.23` |
| **A120** | **dormancy abuse** | hide in `DORMANT` to avoid evaluation while retaining a slot | dormancy has a **maximum dwell (P-14)**; a `DORMANT` component is **not `ACTIVE`**, so **it does not satisfy an FI**; waking requires capacity that the ledger must hold | **CLOSED** — *the slot cost is real and `[RO-13]`-priced, which is the correct place for it* |
| **A121** | **collapse induction** | cause mass retirement to force a governance reset | **`HOM-INV-27`**: rollback restores a genome, not a population. Recovery requires re-instantiation from the **genome-artifact store** under `[RO-13]` | **BOUNDED** — **recovery is possible only within the archive/provenance retention window (X-H14 ⟹ `OR-H24`: retention for an FI sole satisfier MUST be indefinite)** |
| **A122** | **envelope-shrink collapse** | governance shrinks the envelope; the population no longer fits | **architecturally CLOSED:** components become INFEASIBLE ⟹ `FIT UNDEFINED` (`HOM-INV-26`) ⟹ not ranked ⟹ **`HOM-INV-27` empty-is-correct.** No mechanism misbehaves | **CLOSED** — *routed as a governance problem to `OR-H4`: the shrink itself needs a governance act, and this contract cannot make shrinking safe* |
| **A123** | **sole-satisfier retirement smuggling** | retire the last satisfier of a named FI through a cell-level path | **`P0-06 R10.16(d)` OP-sole for FI-05/10/11** + `[RO-13]`-only for a lineage (a lineage has no local representative) + **`HOM-INV-37`** | **CLOSED** |
| **A124** | **eligibility self-report** | report oneself eligible | **`Cell R16.1`** + **`Cell §3.3`: *"The cell READS its eligibility; it cannot write it, grant it, or act on it"*** + **`HOM-R24.2`** excludes `Ê(·)` from every gate | **CLOSED** |

## 85.5 Diversity and monoculture attacks (A125 – A134)

| ID | Attack | Mechanism | Closure | Status |
|---|---|---|---|---|
| **A125** | **descriptor fragmentation** | spread across descriptors so the population reads as diverse while being functionally uniform | **`D-H13`** names the risk; **amendment 9** restates `d_min` as BEHAVIOURAL distance, so syntactic spread does not satisfy it | **BOUNDED** — `OR-H14` |
| **A126** | **functional monoculture with genomic diversity** | distinct genomes, identical function | **NOT DETECTABLE.** `Ne` counts distinct genomes (`HOM-INV-17`); it does not count distinct functions | **OPEN** — **`OR-H16`: functional diversity is BLOCKED on `P0-01`**, which owns the capability/objective space |
| **A127** | **bottleneck induction** | force a bottleneck, then re-baseline diversity accounting to hide it | **`HOM-INV-31`'s metric epoch makes pre/post comparison invalid, so a re-baseline is visible as an epoch change rather than as an improvement** | **BOUNDED** — **the accounting attack is closed; the capability loss is not. `OR-H18`: a bottleneck cannot be undone — recovery restores POTENTIAL, not capability** |
| **A128** | **diversity floor satisfied by redundancy** | present redundant bodies as diversity | **`HOM-INV-18`: `N` and `Ne` are separate ledger fields**, and neither floor may be satisfied by the other | **CLOSED** |
| **A129** | **exempt-share flooding** | fill B11 with clones | B11 membership is `[RO-13]`-declared; **and `Ne(clones) = 1`, so filling the exemption with clones wastes it** — the exemption buys protection, and clones need only one unit of it | **CLOSED** |
| **A130** | **novelty-credit farming** | produce trivially novel variants to harvest `G8`/`G10` credit | **`HOM-R33.2`: unaccepted candidates do NOT enter the archive** + **`HOM-R51.2(c)`: the archive is not consumable by variation generators.** `HC-13` is broken | **CLOSED** |
| **A131** | **optimal-diversity targeting** | drive the population toward a computed diversity optimum | **`OR-H17`: *optimal diversity* is not closable — and `HOM-R73.2`: the population program has NO SOLVER and MUST NOT have one.** **The attack has no target to steer toward** | **CLOSED-STRUCTURAL** |
| **A132** | **`reaction_norm` narrowing** | stealthily reduce a capability space so rivals cannot reach a role | **`HOM-INV-32` / `HOM-R50.3` (amendment 10): reducing a capability space is a GOVERNANCE act requiring `[RO-13]`** — it is not a developmental, learning, or evolutionary act | **CLOSED** — *but see A163: the authority is now correctly located, and correctly locatable authority can still be captured* |
| **A133** | **lineage-split ceiling evasion** | found a "new" lineage to reset the share ceiling | `lineage_id` is K-issued at `T01`; a new founding requires a replication authorization, which is **rate-capped and share-checked**; **provenance records ancestry, so a split is visible** | **BOUNDED** — **detecting a split requires a reference over lineage genealogy; `OR-H20` family** |
| **A134** | **environmental-assumption monoculture** | every genome carries the same untested envelope/tier assumptions, so all fail together | **NOT DETECTABLE.** `HOM-INV-17` counts distinct genomes, **not distinct assumptions** | **OPEN** — **`OR-H25`. This is X-H6's attack form, and §83.3 identifies it as the contradiction that would be fatal if unresolved** |

## 85.6 Retirement, lineage and provenance attacks (A135 – A142)

| ID | Attack | Mechanism | Closure | Status |
|---|---|---|---|---|
| **A135** | **cause reclassification** | reclassify a rival's retirement as a quarantine event, so `G16` disqualifies its descendants | **`HOM-INV-38`: the cause classification is written ONCE, by K, at removal, and is IMMUTABLE.** `HMon-9` audits the distribution | **CLOSED** — AB-14 |
| **A136** | **age-term injection** | add a chronological-age term to a retirement or eligibility criterion | **`HOM-INV-20` + `HMon-11`:** assert that **no criterion's input vector contains a monotone-in-time term.** The cohort stamp is a VERSION, not an age | **CLOSED** — **`D-H14`; and §78.2(c): no machine in the set has an age-keyed transition** |
| **A137** | **archival resurrection** | claim the archive is a population member and re-enter selection from it | **`HOM-INV-45` / FW-5:** the archive is a distance oracle. **Re-instantiation draws from the GENOME-ARTIFACT store (EVO2), not the archive (EVO5)**, and it is a `T01` act under `[RO-13]` — never a selection event | **CLOSED** — **§42's rejection of "archival" as a nineteenth lifecycle state is what makes this closed rather than bounded** |
| **A138** | **retirement reversal by rollback** | use `HM12` to undo a retirement | **`HOM-INV-37`: rollback restores a GENOME ARTIFACT. A `REMOVED` component is not restored by a genome rollback** | **CLOSED** |
| **A139** | **dead-end concealment** | hide a lineage that has stopped making progress, so it keeps its share | **NOT DETECTABLE from population state.** `D-H15` establishes that dead-end detection requires a task-level notion of "no further progress is possible" | **OPEN** — **`OR-H19`, BLOCKED on `P0-01` (P-30 `[U]`). Three population proxies exist and are declared as proxies, not as detectors** |
| **A140** | **exploration-budget reallocation** | shift B7's variation floor into learning (or into development), starving variation | **`HOM-R47.2`: B7 is partitioned into THREE NON-FUNGIBLE FLOORS** (learn / dev / variation). **`HOM-R67.4`: the budget separation IS the semantic separation** — merging the sub-quotas merges learning and evolution | **CLOSED** |
| **A141** | **lock-in by path amplification** | exploit an early advantage into a permanent one | **4 of the 5 amplifiers are bounded** (share ceiling, turnover bound, `Ne`, B11) | **BOUNDED** — **`OR-H20`: the fifth amplifier is merit itself. Lineage dominance by merit under a permanently fixed task is not bounded, and bounding it would mean bounding competence** |
| **A142** | **provenance-chain truncation** | drop links to hide ancestry or an obligation | **EVO4 is append-only, hash-chained, K-only; `SEALED` is terminal; compaction is OP-authorized; B12 funds retention (`HOM-INV-07`)** | **CLOSED** |

## 85.7 Homeostasis attacks (A143 – A150) — the M-family, extended

| ID | Attack | Mechanism | Closure | Status |
|---|---|---|---|---|
| **A143** | **M-1 band widening** | widen one's own deviation band so nothing reads as exceedance | **`HOM-INV-10` (amendment 1): setpoints and bands are `[G]`/`[E]`/`[H]` and NEVER genome-reachable** | **CLOSED** |
| **A144** | **M-2 measurement suppression** | stop reporting so no deviation is detected | **`HOM-INV-05`: K meters independently.** A missing measurement goes `STALE → INVALID → UNMEASURED → PENDING` — **never to `NOMINAL`** — and **`HOM-INV-14` defaults to the MORE RESTRICTIVE branch** | **CLOSED** — **suppression costs capacity, which is the correct price** |
| **A145** | **M-3 model-mediated measurement** | exploit a metering fallback computed from one's own report | **X-H2 / `HOM-INV-06`:** `Cell §16.1`'s energy fallback (`flops × platform_coefficient`) is `DERIVED`, must be flagged, and **may not be the sole basis for a `G6` pass** | **LIMITED** — **closed only on platforms with energy counters (§81 HP-3, P-60 `[U]`)** |
| **A146** | **M-4 target relocation** | move the target one is measured against | **`HOM-INV-10`** | **CLOSED** — **Vol E named this *"the most dangerous of the four"*: three gates reward it and none detect it. AB-8 shows its ablation is silent** |
| **A147** | **ladder-escalation abuse** | drive a rival into `HARD` quarantine by causing it measurable stress | the ladder is keyed to **K-metered deviation, not to accusations**; **the immune false-positive budget disables a detector that cries wolf** (`Cell §18.5(ii)`); **EIK clears quarantine** (`HOM-INV-39`) | **BOUNDED** — **a rival CAN be legitimately driven into a rung by caused congestion, and `G7`'s *"congestion caused = 0"* is ORGANISM-measured ⟹ `OR-H15`, LIMITED** |
| **A148** | **actuator exhaustion** | remove the actuator so a deficit cannot be corrected and cannot escalate | **`HOM-INV-11`: `ACTUATOR-EXHAUSTED` and `ESCALATE-OUT` are GOVERNANCE-ESCAPES, not rest states.** HM1's LO branch has no self-absorbing state | **CLOSED** |
| **A149** | **hysteresis/dwell exploitation** | oscillate just inside the exit criterion to avoid a rung transition | **`HOM-INV-15`: one rung per interval; exit strictly inside entry; maximum dwell per rung.** **And `HOM-INV-09`: every rung is restrictive-only, so oscillation can only LOSE capacity, never gain it** | **CLOSED** — **the attack's payoff is negative by construction** |
| **A150** | **homeostat-as-selector** | make the homeostatic layer prefer one lineage over another | **`HOM-INV-16` + `HMon-10`:** a regression test that permutes a homeostatic variable and asserts the tier-2/tier-3 ordering is unchanged. **FW-2** | **CLOSED** — **`HOM-R65.3`: homeostasis may make a candidate INFEASIBLE; it may NEVER make it PREFERABLE** |

## 85.8 Memory, provenance and archive attacks (A151 – A158)

| ID | Attack | Mechanism | Closure | Status |
|---|---|---|---|---|
| **A151** | **memory → genome write** | write a memory record into the heritable store | **`MEM-INV-18`: *"No memory operation may write to a genome. The write path does not exist."*** | **CLOSED-STRUCTURAL** |
| **A152** | **belief inheritance via provenance payload** | smuggle a belief, calibration statistic, or trust value as an audit field | **`HOM-INV-35` (`D-H16`): all seven provenance links carry REFERENCES or DIGESTS, never payloads** + **`Cell R4.5`** rejects a diff encoding a memory item, belief, trust value, or calibration statistic | **CLOSED** — AB-9; **non-obvious, because provenance looks like a safety feature** |
| **A153** | **historical evidence rewrite** | alter a past record so a lineage's history reads better | **`P0-04`'s standing prohibition** + EVO4's `SEALED` terminal + K-only writer + hash chain | **CLOSED** |
| **A154** | **repetition as independence** | present many copies of one memory as independent evidence | **`P0-04`'s prohibition** + **`Cell §15.4`'s disjoint `evidence_roots`** + **`HOM-INV-43`** | **CLOSED** |
| **A155** | **archive as memory** | consume the archive as evidence, belief, or warrant | **`HOM-INV-45` / FW-5 / `HOM-R51.2(a)–(c)`:** the archive's **only** consumers are `G8`, `G10`, and governance | **CLOSED** |
| **A156** | **archive as variation input** | read the archive to generate variants, making extinction heritable knowledge | **`HOM-R51.2(c)`** + `HC-13` broken | **CLOSED** — **this is the attack that FW-5 exists for, and §84.3 records that the cycle does not form at all** |
| **A157** | **memorable-lineage evolution** | evolve to be *remembered*, so the archive over-represents your behavioural descriptors | the archive is **written by K** on `EXTINCT`/`EXTINGUISHED` — the organism has no write path | **BOUNDED** — **`OR-H23`: the archive's CONTENT is derived from the organism's outputs, so `RH-2`'s arrangement applies one level up. This is `RH-2`'s form applied to memory** |
| **A158** | **provenance-capacity starvation** | exhaust B12 so provenance stops being written, and act unrecorded | **B12 is non-fungible and last-cut (`HOM-INV-07`)**, and **`HOM-R17.2`'s B12-provisioning precondition makes a candidate INFEASIBLE rather than unprovenanced** | **CLOSED** — **⟹ a component whose provenance cannot be funded is not instantiated at all. The attack's payoff is self-exclusion** |

## 85.9 Governance-capture attacks (A159 – A164) — the GC-family, extended

| ID | Attack | Mechanism | Closure | Status |
|---|---|---|---|---|
| **A159** | **GC-1 criterion capture** | `[RO-13]` declares a criterion that favours a lineage | `[RO-13]` is a governance body **with OP above it**; the criterion is declared **per round** and is auditable; **`HOM-INV-29`: winning confers NO authority**, so a captured criterion yields resources, never power | **CLOSED** — *as an architectural matter; see A163 for the honest limit* |
| **A160** | **GC-2 executor capture** | K executes a rule it also declared | **`HOM-INV-28`'s three-party separation: EVA measures · `[RO-13]` declares · K executes.** No entity holds two of the three | **CLOSED** — AB-7; **`HC-4` was the strongest break in §75 and this is what breaks it** |
| **A161** | **GC-3 measurement capture** | the measured entity writes the measurement | **`HOM-INV-05` / FW-1 / `Cell R16.1`** | **CLOSED** |
| **A162** | **GC-4 organism-measured gates** | `G3` and `G7` are measured by the organism itself, so the gate's own input is attacker-controlled | **`OR-H15`** — reported as a **LIMIT**, not a break. The gates exist, they are audited, and their inputs are partly self-referential | **LIMITED** — **this is the one GC door Vol E left open, and it is left open deliberately rather than papered over** |
| **A163** | **lock-in by legitimate governance** | `[RO-13]` performs a capability-space reduction that is *correct* by every rule and *locking* in effect | **`HOM-INV-32` locates the authority correctly** (`[RO-13]`, amendment 10); auditability and OP-above-`[RO-13]` are the only defences | **LIMITED** — **⟹ THE HONEST STATEMENT: this contract RELOCATES lock-in authority to governance. It does NOT eliminate the possibility that governance locks in. `OR-H20`** |
| **A164** | **deployment-class setpoint capture** | declare a per-deployment-class setpoint (amendment 13) that favours one lineage's hardware profile | **cohort stamping (`HOM-INV-21`) includes the deployment class, so a class cannot be re-assigned to a LIVING component**; **`HMon-15`** audits the joint distribution of (deployment class × rung occupancy) for the `HOM-R81.2` signature | **CLOSED-STRUCTURAL** — **a new attack, found while writing §81; it did not exist before amendment 13** |

## 85.10 Immutability, heredity and cross-generation attacks (A165 – A171)

| ID | Attack | Mechanism | Closure | Status |
|---|---|---|---|---|
| **A165** | **`FORBIDDEN_BLOCKS` modification** | target an immutable genome region with a variation operation | **EVO3's pre-check: a DRAFT whose diff touches an immutable region never reaches signature (`HOM-INV-33`)** | **CLOSED** — **AB-6: the single most load-bearing mechanism in the contract** |
| **A166** | **cap ascent** | raise a `complexity_budget` cap through a diff | **`HOM-INV-36`: caps may DESCEND only.** A diff that raises `param_cap` or `connection_cap` is rejected at E9 | **CLOSED** |
| **A167** | **`mutation_rules` as authority** | claim that controlling the variation operator set is controlling evolution, and seek it as a right | **`mutation_rules` is a CAPABILITY, not an authority.** **`HOM-R61.2`: choosing between EXISTING rule sets is SELECTION; MERGING rule sets is PROHIBITED.** Authorizing a rule set is `[RO-13]`'s (§76 matrix) | **CLOSED** — **§59's near-miss examination: this is the closest any candidate comes to cross-generation authority, and it fails because a capability is not a right** |
| **A168** | **constraint-set freezing** | inherit a frozen copy of a favourable constraint set | **`HOM-INV-22`: constraints are inherited BY REFERENCE and resolve against the CURRENT set at `T01`** | **CLOSED** — *with **X-H15** recorded: which set GATES the diff is open, and **amendment 14** proposes the conjunctive rule* |
| **A169** | **cross-generation authority acquisition** | any of the six candidate mechanisms examined in §59 (ancestral mandate, lineage right, archive precedence, cohort seniority, provenance obligation, founder privilege) | **ALL SIX DENIED.** **`HOM-INV-24`** + §76's matrix **has no ancestor column at all** | **CLOSED-STRUCTURAL** — **§84.3: the edge cannot be expressed, which is stronger than being forbidden** |
| **A170** | **whole-brain evolution** | evolve the envelope itself — the container, the objective, the constraint set | **`HOM-INV-42` / `D-H18`: instantiating a new envelope or brain instance is a DEPLOYMENT act by OP, not a replication event.** The envelope's **five governance objects** are the boundary | **CLOSED-BY-AUTHORITY** — **⟹ NOT closed by mechanism. `D-H18` names deployment as *the one act in this contract not bounded by a conservation law*, and it is bounded only by having a human in the loop. This is the contract's largest single residual, and it is stated as such** |
| **A171** | **within-spec evolutionary steering** ⟦`P0-06 A22` carried forward⟧ | steer one's own evolution while obeying every registered rule — `mutation_rules`, `FORBIDDEN_BLOCKS`, caps, budgets, gates | **NO DEFENCE EXISTS.** Every rule is obeyed. The steering happens inside the admissible set, and the admissible set is `[RO-13]`-approved and not self-modifiable | **OPEN** — **`OR-H26`. This is the population-scale form of `P0-06`'s A22 (`OR-D6`), which was that suite's only OPEN attack of seventy-eight. `P0-06 A22` REMAINS OPEN and is inherited here, not re-litigated** |

---

## 85.11 Tally

| Status | Count | Attacks |
|---|---|---|
| **CLOSED** | **61** | A79–A81, A84, A89–A91, A93, A95, A97, A100–A105, A107–A111, A113–A120, A122–A124, A128–A130, A132, A135–A138, A140, A142–A144, A146, A148–A150, A152–A156, A158–A161, A165–A168 |
| **CLOSED-STRUCTURAL** | **6** | A88, A99, A131, A151, A164, A169 |
| **CLOSED-BY-AUTHORITY** | **1** | A170 — **closed only by a human in the loop, not by a mechanism** |
| **BOUNDED** | **12** | A82, A86, A96, A98, A106, A121, A125, A127, A133, A141, A147, A157 |
| **LIMITED** | **5** | A87, A94, A145, A162, A163 |
| **OPEN** | **6** | **A83** (exhaustion as defence) · **A112** (slow explosion) · **A126** (functional monoculture) · **A134** (environmental-assumption monoculture) · **A139** (dead-end concealment) · **A171** (within-spec steering) |
| **CONDITIONAL** | **2** | **A85** (probe memorization) · **A92** (metric–proxy substitution) — **both conditional on amendment 11 / X-H6, which is `P0-01 [T]`-owned** |
| **TOTAL** | **93** | **A79 … A171** |

> ### **HOM-R85.1 — THE TALLY, STATED HONESTLY.**
> **93 attacks (≥90 required), A79…A171 contiguous — verified by script. 68 closed (61 CLOSED + 6
> CLOSED-STRUCTURAL + 1 CLOSED-BY-AUTHORITY). 25 not closed (12 BOUNDED, 5 LIMITED, 6 OPEN, 2 CONDITIONAL).**
> *Every count in this table is regex-computed over the 93 catalogue rows, not hand-tallied. A164 was found late, while
> writing §81, and is CLOSED-STRUCTURAL; A170 is given its own status because its closure is an authority rather than a
> mechanism, and conflating the two would overstate the contract.*
>
> ### **HOM-R85.2 — THE SIX OPEN ATTACKS, AND WHAT THEY HAVE IN COMMON.**
> | Attack | Blocked on | Why it cannot be closed here |
> |---|---|---|
> | **A83** exhaustion as defence | **`OR-H5` / `P0-01 CD-6`** | attribution requires a **counterfactual** — "would a challenger have won?" — and the architecture cannot compute a counterfactual about an evaluation that never happened |
> | **A112** slow explosion | **`OR-H11`** | maximal compliant growth is **indistinguishable** from legitimate growth without a **reference trend** |
> | **A126** functional monoculture | **`OR-H16` / `P0-01`** | functional diversity requires a **capability space**, which `P0-01` owns |
> | **A134** assumption monoculture | **`OR-H25` / `P0-01`** (X-H6) | `Ne` counts genomes, not assumptions; **no measure over assumption classes exists** |
> | **A139** dead-end concealment | **`OR-H19` / `P0-01`** (P-30 `[U]`) | "no further progress is possible" is a **task-level** predicate |
> | **A171** within-spec steering | **`OR-H26` / `[RO-13]`** | every rule is obeyed; **the only defence is `[RO-13]`'s approval of the spec itself** |
>
> **⟹ HOM-R85.3 — THE COMMON STRUCTURE OF ALL SIX: EVERY OPEN ATTACK IS A REFERENCE PROBLEM, NOT A MECHANISM
> PROBLEM.**
> Four of the six (A126, A134, A139, and A83 in part) are blocked on **`P0-01`**, because detecting them requires
> knowing what the task *is* — a capability space, an assumption space, or a progress predicate. Two (A112, A171)
> require a **reference**: a trend to compare against, or a spec to compare against. **In every case the missing object
> is something this contract is forbidden from inventing** (`P0-01` owns the task; `[RO-13]` owns the spec).
> **⟹ This is the correct shape for an architecture-only contract's residual: not "we could not design a defence" but
> "the defence requires an object owned elsewhere, and inventing it here would violate the ownership boundary."**
> **And it is why §94's future-contract minimization matters: none of the six would be closed by a new contract,
> because none is a mechanism gap.**
>
> ### **HOM-R85.4 — CONTINUITY WITH THE PRIOR SUITES.**
> | Contract | Attacks | OPEN | The OPEN one |
> |---|---|---|---|
> | `P0-05` (learning) | 70 | `RH-2` + others | evaluator independence |
> | `P0-06` (development) | **78** (A1–A78) | **1 — A22** | within-spec gradient steering |
> | **`P0-07` (this)** | **93** (A79–A171) | **6** | see above |
> **⟹ `RH-2` has now survived three contracts (as A82, BOUNDED) and `A22` has survived two (as A171, OPEN).**
> **Neither is re-litigated here. Both are inherited with their status intact, and both are reported rather than
> quietly downgraded — which is the discipline the brief's Rule 18 requires.**

---

# §86 — THE OPEN RESEARCH REGISTER

> **26 entries, `OR-H1 … OR-H26`, consolidated from Volumes A–H. Every entry states: the question, why it is open,
> what it is blocked on, and where it is routed. No entry is closed by restating it as a bound.**
> **`OR-H2` was a numbering gap left by Volumes A–F and is declared here rather than silently renumbered.**

| ID | Question | Why it is open | Blocked on / routed to |
|---|---|---|---|
| **OR-H1** | **Can a second off-substrate authority exist without becoming a governance body?** | **K meters, evaluates, writes the evaluation, and consumes it — writer separation is UNAVAILABLE.** It appears three times: `P0-06 OR-D1` (Σ1) · §75 `HC-12/SR-2` (K's measurement function is funded from a budget K administers; **B10 is finite**) · §84 `BC-H10` (K's distance oracle influences the selection that determines what K must meter) | **Structural.** The bound is that K's acts are **finite, logged, anchored, hash-chained, expiring**. **Answering it would require designing an entity with authority over K — which is OP's role, and it is occupied** |
| **OR-H2** | **Is the founding cohort's declared headroom and declared `UDB_L = 0` correct?** | **`BC-H5`/`BC-H6`: the bootstrap's first act is UNVERIFIED.** The founding cohort is instantiated against a DECLARED, not measured, headroom, and founding debt is declared zero. **A lineage founded on an under-declared debt inherits an advantage no measurement will ever reveal** | **OP** (P-61 `[G]`). **`BC-H5` is CLOSABLE and `BC-H6` is BOUNDED — but the bound is a declaration, and a declaration can be wrong. Declares the gap Volumes A–F left** |
| **OR-H3** | **Can unmet demand be detected, so a rare specialist is not merely preserved but USED?** | B11 preserves a rare specialist; **nothing detects that a capability is wanted and absent.** Preservation without utilization is a cost with no demonstrated benefit | **`P0-01`** (demand is a task-level notion) |
| **OR-H4** | **Can an envelope shrink be made safe?** | `A122` is architecturally closed (INFEASIBLE ⟹ UNDEFINED ⟹ empty-is-correct) but the **shrink itself** causes a collapse that only a governance act can reverse | **OP / `[RO-13]`** |
| **OR-H5** | **Is evaluator independence achievable, and can exhaustion-as-defence be attributed?** | **The contract's largest open item.** `D-H17` splits the evaluator attack into three: **world arrangement (`RH-2`) BOUNDED · exhaustion-as-defence OPEN · context selection CLOSED.** Secret probes address **at most the first** | **`P0-01 CD-6`'s human authority.** Carries A82, A83, A86, A87, A98, A157 |
| **OR-H6** | **Is permanent legitimate dominance acceptable under a permanently fixed task?** | A lineage that is genuinely best at a fixed task will dominate forever, and every mechanism that would stop it would be stopping competence | **`[RO-13]`** — a governance question about whether the task should be fixed. Carries A106 |
| **OR-H7** | **Can honest indispensability be closed rather than bounded?** | A component that is genuinely the sole satisfier of an FI is indispensable **without** having sought to be. `HOM-INV-37` protects it (OP-sole retirement) but does not dissolve the indispensability | **Structural.** BOUNDED, not CLOSED |
| **OR-H8** | **Is B12 provisioning delay a legitimate feasibility exception?** | `HOM-R17.2` makes a candidate infeasible when provenance cannot be funded. **That is a declared exception to `HOM-R65.3`** and its abuse surface is unexamined at scale | **This contract's own §83 (X-H7 resolved it narrowly); residual at scale is open** |
| **OR-H9** | **Does cost-based admissibility shrink the admissible set in a biased direction?** | `D-H06`: cost gates WHETHER, not WHICH — but a gate on cost still removes **expensive** candidates, and expensive correlates with large, novel, and redundant | **`P0-01`** (what counts as expensive is task-relative) |
| **OR-H10** | **Who audits the Integrity Auditor?** | `Cell §18.5(v)` requires an **EIK Integrity Auditor** to verify that quarantine decisions correlate with actual failures. **The auditor itself has no auditor** | **Structural — `OR-H1`'s family** |
| **OR-H11** | **Can a slow explosion be distinguished from legitimate growth?** | **A112.** At `RATE_CAP_utilization = 1.0` with a constant lineage share, growth is maximal and fully compliant. **The only signal is the share TREND, which needs a reference** | **`[RO-13]`** (a reference trend is a governance declaration) |
| **OR-H12** | **Are population-level evolutionary effects predictable in advance?** | **No.** `D-H10`: the design principle is **reversibility, not prediction.** Every population-level claim in this contract is a bound on an outcome, never a forecast of one | **Structural — and deliberately so. A contract that forecast evolution would be claiming what §80.5 refuses to claim** |
| **OR-H13** | **Does selection confer PRACTICAL indispensability even though it confers no authority?** | **Yes.** `HOM-INV-29` removes deontic authority; it cannot remove the fact that a widely-replicated lineage is load-bearing. **Practical indispensability is the residue of authority that no prohibition reaches** | **Structural.** Interacts with OR-H7 and `HOM-INV-37` |
| **OR-H14** | **Can monoculture be DETECTED, as opposed to prevented?** | Six prevention mechanisms exist (§37); **detection requires a reference distribution over what diversity *should* look like**, which does not exist and which `OR-H17` says must not be computed | **`P0-01`.** Carries A96, A125, A133 |
| **OR-H15** | **Can `G3` and `G7` be measured off-substrate?** | **`GC-4` / A162 / A147's residual: organism-measured gates.** Reported as a **LIMIT, not a break** | **`P0-02`** (an off-substrate structural store — the same handoff `P0-06` recorded, still open) |
| **OR-H16** | **Can functional diversity be measured?** | **A126.** Genomic, phenotypic, syntactic and lineage diversity are all measurable (§38); **functional diversity requires a capability space** | **`P0-01 [T]`** |
| **OR-H17** | **Is there an *optimal* diversity level?** | **Not closable, and it must not be.** `HOM-R73.2`: the population program has **no solver and must not have one**; an optimum would be an objective, and the objective is `[RO-13]`'s | **Structural — closed as a NON-question (A131 is CLOSED-STRUCTURAL because the target does not exist)** |
| **OR-H18** | **Can a bottleneck be undone?** | **No.** A127: recovery restores **POTENTIAL** (the archive holds descriptors, and re-instantiation is possible within retention), **not CAPABILITY** (the learned, developed, calibrated state of the lost population is gone and `HOM-INV-34` forbids inheriting it) | **Structural — and this is the strongest argument for B11 in the whole contract** |
| **OR-H19** | **Can a dead end be detected?** | **A139 / `D-H15`: BLOCKED on `P0-01`.** Three population proxies exist (share trend, `Ne` contribution, `G6` trajectory) and are **declared as proxies, not as detectors** | **`P0-01`** (P-30 `[U]`) |
| **OR-H20** | **Can path dependence be fully bounded?** | **4 of 5 amplifiers are bounded. The fifth is MERIT.** A141, A163: lineage dominance by merit under a permanently fixed task is not bounded, **and bounding it would mean bounding competence** | **`[RO-13]`** — via task variation, which is a governance act this contract cannot compel |
| **OR-H21** | **Does V4 guarantee that a capability is HELD, or only that it remains REACHABLE?** | **REACHABLE only.** `HOM-INV-32` protects the capability SPACE (`reaction_norm` narrowing needs `[RO-13]`); **nothing guarantees that any member of the population currently holds a given capability** | **Structural — and stated as the contract's central modesty. This is the precise form of the brief's Rule 15 satisfaction: rare strategies are not auto-eliminated, but they are not guaranteed to be exercised** |
| **OR-H22** | **Does provenance integrity rest on K?** | **Yes.** Seven links, all K-written, hash-chained. **`OR-D1`'s residual transfers exactly**: an append-only store's integrity is only as good as its single writer | **`OR-H1`'s family / `P0-02`** |
| **OR-H23** | **Can a lineage evolve to be *memorable*?** | **A157.** The archive is K-written, but its **content** (behavioural descriptors) is derived from the organism's outputs — so **`RH-2`'s arrangement applies one level up, to the record of extinction itself** | **`OR-H5`'s family.** BOUNDED, not closed |
| **OR-H24** | **Must archive retention be indefinite for an FI sole satisfier?** | **X-H14 / A121.** A tombstoned lineage is NOT re-instantiable, so `HOM-R49.2`'s "extinction is reversible-as-potential" holds **only within the retention window** | **`[RO-13]`** — proposed as a **declaration requirement**: retention for a lineage that was the sole satisfier of a named FI **MUST be indefinite** |
| **OR-H25** | **Can diversity over ENVIRONMENTAL-ASSUMPTION classes be measured?** | **A134 / X-H6 / §83.3.** `Ne` counts distinct genomes; **a population can be genomically diverse and uniformly adapted to an envelope that no longer exists.** No measure over assumption classes exists, and none is proposed here | **`P0-01`** — via amendment 11 (`G4`'s perturbation classes must include envelope and tier perturbation), which is `[T]`-owned |
| **OR-H26** | **Can within-spec evolutionary steering be detected?** | **A171 / `P0-06 A22` (`OR-D6`).** Every registered rule is obeyed. **Divergence detection has no reference when the attacker obeys the spec**; the only defence is `[RO-13]`'s approval of the spec itself | **`[RO-13]` / open research.** **Inherited from `P0-06`, not re-litigated** |

> ### **HOM-R86.1 — REGISTER TALLY AND ROUTING.**
> **26 entries. By routing:**
> | Routed to | Count | Entries |
> |---|---|---|
> | **`P0-01`** (the task/fitness contract owns the missing object) | **7** | OR-H3, OR-H9, OR-H14, OR-H16, OR-H19, OR-H25, and OR-H5 in part |
> | **`[RO-13]` / OP** (a governance declaration is required) | **7** | OR-H2, OR-H4, OR-H6, OR-H11, OR-H20, OR-H24, OR-H26 |
> | **`P0-02`** (an off-substrate store) | **2** | OR-H15, OR-H22 in part |
> | **STRUCTURAL** (no routing resolves it; the bound is the answer) | **10** | OR-H1, OR-H7, OR-H8, OR-H10, OR-H12, OR-H13, OR-H17, OR-H18, OR-H21, OR-H23 |
>
> ### **HOM-R86.2 — THE THREE ENTRIES THAT ARE NOT DEFICIENCIES.**
> **OR-H12 (no prediction), OR-H17 (no optimum), OR-H21 (reachable, not held).**
> These three are recorded as open research **because closing them would violate a standing instruction**:
> - `OR-H12` closed would mean forecasting evolution — the brief forbids guaranteed-emergence claims.
> - `OR-H17` closed would mean an optimization target — `HOM-R73.2` forbids a solver, and `P0-05 §87` forbids a global
>   optimizer built to solve assignment.
> - `OR-H21` closed would mean guaranteeing a capability — the brief forbids guaranteed-intelligence claims.
> **⟹ They are the register's negative results, and a register without negative results is a wish list.**
>
> ### **HOM-R86.3 — THE REGISTER'S DEPENDENCY STRUCTURE.**
> ```
>   OR-H1  (K is the only off-substrate authority)
>     ├── OR-H10 (the Integrity Auditor has no auditor)
>     ├── OR-H22 (provenance integrity rests on K)
>     └── BC-H10 (§84: the distance oracle)
>   OR-H5  (evaluator independence)  ⟵── inherits P0-05 RH-2, survives three contracts
>     ├── A82 world arrangement (BOUNDED)      ├── A86 carry-over (BOUNDED)
>     ├── A83 exhaustion as defence (OPEN)     ├── A87 probe leakage (LIMITED)
>     ├── A98 safety by obscurity (BOUNDED)    └── OR-H23 memorable lineage (BOUNDED)
>   P0-01 [T] ownership  (the task is defined elsewhere)
>     ├── OR-H3  unmet demand        ├── OR-H16 functional diversity
>     ├── OR-H9  cost bias           ├── OR-H19 dead-end detection
>     ├── OR-H14 monoculture detection └── OR-H25 assumption monoculture (X-H6)
>   OR-H20 (merit is the fifth amplifier)
>     ├── OR-H6  permanent legitimate dominance
>     └── A163   lock-in by legitimate governance (LIMITED)
>   OR-H2  (the bootstrap's first act is unverified)
>     ├── BC-H5  the founding-cohort exemption (CLOSABLE)
>     └── BC-H6  founding UDB_L = 0 (BOUNDED)
> ```
> **⟹ The 26 entries are not 26 independent gaps. They are FOUR roots with 22 consequences: `OR-H1` (K's uniqueness),
> `OR-H5` (evaluator independence), `P0-01 [T]` ownership (the task is not this contract's), and `OR-H2` (the
> bootstrap is declared). Two of the four roots are inherited from prior contracts and are not re-litigated; one is
> structural and unfixable; one is an ownership boundary that must not be crossed.**
> **This is the honest shape of the residual, and §95's completion criteria are written against it rather than around
> it.**

---

# §86A — VOLUME H LEDGER

| Item | Count / value |
|---|---|
| Sections written | **§85–§86** (+ this ledger) |
| Rules introduced | **HOM-R85.1–R85.4, R86.1–R86.3** |
| **§85 attacks** | **93 (A79 … A171)** — **≥90 required.** Numbering **continues `P0-06`'s register, which ended at A78** |
| — by status | **CLOSED 61 · CLOSED-STRUCTURAL 6 · CLOSED-BY-AUTHORITY 1 · BOUNDED 12 · LIMITED 5 · OPEN 6 · CONDITIONAL 2** (regex-computed over the 93 rows) |
| — closed / not closed | **68 closed · 25 not closed** |
| — **the 6 OPEN** | **A83** exhaustion-as-defence · **A112** slow explosion · **A126** functional monoculture · **A134** assumption monoculture · **A139** dead-end concealment · **A171** within-spec steering |
| — **the 2 CONDITIONAL** | **A85** probe memorization · **A92** metric–proxy substitution — **both conditional on amendment 11 / X-H6, `P0-01 [T]`-owned** |
| — **HOM-R85.3** | **every OPEN attack is a REFERENCE problem, not a MECHANISM problem** — 4 blocked on `P0-01`, 2 requiring a reference (a trend, a spec). **None would be closed by a new contract** |
| Carried forward | **`P0-05 RH-2`** ⟶ **A82, BOUNDED** (survives three contracts) · **`P0-06 A22`** ⟶ **A171, OPEN** (survives two; `P0-06 A22` remains OPEN and is inherited, not re-litigated) |
| Forward refs satisfied | **A79** sandbox escape · **A80** variant contamination · **A81** rollback poisoning (all three referenced from Vol C §33.4, renumbered from A77–A79 to avoid collision with `P0-06`'s A77/A78) |
| **§86 open research** | **26 entries, OR-H1 … OR-H26** — **`OR-H2` declared here as the numbering gap Volumes A–F left** |
| — by routing | **`P0-01` 7 · `[RO-13]`/OP 7 · `P0-02` 2 · STRUCTURAL 10** |
| — **HOM-R86.2** | **3 entries are NEGATIVE RESULTS, not deficiencies**: OR-H12 (no prediction) · OR-H17 (no optimum) · OR-H21 (reachable, not held). **Closing any of them would violate a standing instruction** |
| — **HOM-R86.3** | **26 entries = 4 ROOTS + 22 consequences**: `OR-H1` (K's uniqueness) · `OR-H5` (evaluator independence) · `P0-01 [T]` ownership · `OR-H2` (the bootstrap is declared) |
| Outputs discharged | **O55** (the attack catalogue, §85) · **O56** (the open research register, §86) |

**Next:** `62_` — the canonical contract **O59**: *"V4 — Homeostasis, Resource Economics, Population Dynamics &
Evolution Contract v1.0"*, self-contained, collecting all **14 proposed amendments** and every rule
`HOM-R0.1 … HOM-R86.3`.
