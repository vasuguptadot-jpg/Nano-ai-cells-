# P0-07 — VOLUME F (§65–§76)
## The Seven Subsystem Contracts, the Three Canonical Control Loops, the Writer-Separation Audit, and the Authority Matrix

**Feeds:** `60_` Vol G, `61_` Vol H, `62_` canonical. **Conventions as locked in Vol A §0.**

---

# §65 — HOMEOSTASIS ↔ EVOLUTION

> ### **HOM-R65.1 — CAN EVOLUTIONARY CHANGE DESTABILIZE THE SIX QUANTITIES §65 NAMES? YES, ALL SIX, AND EACH HAS A
> DIFFERENT INSTRUMENT.**
>
> | Quantity | How evolution destabilizes it | Instrument | Status |
> |---|---|---|---|
> | **compute** | a variant with a larger `architecture` raises per-cell cost | **`complexity_budget.param_cap`** (genome field, `G14`-checked) + `HOM-R31.2` (**caps may be lowered by a diff, never raised**) | **CLOSED** |
> | **memory** | `connection_cap` growth; archive growth | `complexity_budget.connection_cap` + `HOM-R51.4` (OP-authorized compaction) | **CLOSED**, archive growth **BOUNDED** |
> | **bandwidth** | a variant that emits more messages | `Cell §16.1` sender-pays + `G7` *"congestion caused = 0"* + `P0-03` degree caps | **CLOSED**; `G7` organism-measured ⟹ **LIMITED** (`OR-H15`) |
> | **population** | a variant that replicates faster | **`RATE_CAP`** + `G13` zero-sum + `GEN_MAX` + hypervisor cap + superlinear cost (`Cell §12.5`) + **`HOM-R22.2` turnover** + **lineage share ceiling** | **CLOSED** (five inherited + two new) |
> | **verification** | a variant that is expensive or impossible to verify | **B9** + `HOM-R20.1` (verification cost out of `G6`) + **`HOM-R57.2`** (`PENDING` max dwell ⟹ `INELIGIBLE-UNVERIFIABLE`) | **CLOSED** |
> | **repair** | a variant with a higher fault rate | **B10** + `Cell G5` (*"No S3+ error in ≥ `N_robust` epochs; `failure_count_lifetime ≤ θ_fail`; invariant violations = 0"*) + `G16` propagation + derivative cascade detection | **CLOSED** |
>
> ### **HOM-R65.2 — CAN HOMEOSTASIS CONSTRAIN EVOLUTION? YES, AND IT ALREADY DOES — BUT ONLY IN THE RATE DIMENSION.**
> **Permitted:** `G13` headroom (a replication is infeasible if the envelope cannot hold it) · `RATE_CAP` ·
> `complexity_budget` caps · the exceedance ladder (a throttled candidate is `PENDING`, `HOM-R6.5`) · B9–B12
> availability · cohort constraints (`HOM-R45.2`).
> **Prohibited:** **any homeostatic quantity entering a selection ordering.** `HOM-R16.2`: *"viability → fitness ❌ —
> a homeostatic band is not a selection criterion. **A lineage that is easier to keep viable is not thereby
> fitter.**"*
>
> > ### **HOM-R65.3 — THE SEAM, STATED SO IT CAN BE TESTED: HOMEOSTASIS MAY MAKE A CANDIDATE INFEASIBLE; IT MAY
> > NEVER MAKE A CANDIDATE PREFERABLE.**
> > **Feasibility is a `P0-01` tier-1 matter and yields UNDEFINED (`INV-07`) — the candidate leaves the ordering.**
> > **Preferability is a tier-2/tier-3 matter and is computed from the objective vector and the diversity
> > contribution — neither of which may reference a homeostatic quantity.**
> > **⟹ The test is mechanical: grep the tier-2 and tier-3 computations for any of the 13 homeostatic variables. Any
> > hit is a FW-2 violation.**
> > **Why this is the load-bearing rule of §65: a homeostat that prefers is a selector, and a selector that is also
> > the meter is FW-1's violation on top of FW-2's. The two firewalls fail together, and the result is a control loop
> > that chooses which lineages survive — i.e. evolution by resource policy, with no evaluator, no objective, and no
> > governance in the loop at all.**
>
> ### **HOM-R65.4 — THE ONE PERMITTED EXCEPTION, AND WHY IT IS NOT AN EXCEPTION.**
> `HOM-R17.2`'s B12-provisioning precondition and `HOM-R46.2`'s `G6` exclusion both make a homeostatic/accounting
> fact affect a candidate's fate. **Neither is a preference:**
> - B12 provisioning is a **feasibility** condition (the envelope cannot hold another irreplaceable component) and
>   enters `G13` only — `HOM-R17.2`'s declared exception.
> - `G6` exclusion yields **`PENDING`**, which defers rather than prefers (`HOM-R12.2`).
> **⟹ Both are `HOM-R65.3`-compliant: they make a candidate *not-yet-evaluable* or *infeasible*, never *better*.**

---

# §66 — EVOLUTION ↔ DEVELOPMENT: THE FULL CHAIN

> ### **HOM-R66.1 — THE §66 CHAIN, WITH EVERY EDGE CLASSIFIED. THIS TABLE IS THE CONTRACT'S CENTRAL DIAGRAM.**
> ```
> genome → development → phenotype → learning → behavior → evaluation → selection → next generation
> ```
>
> | # | Edge | Permitted flow | **PROHIBITED flow** | Authority on the edge | Ground |
> |---|---|---|---|---|---|
> | **1** | **genome → development** | `reaction_norm` (reachable roles + bias), `morphogen_receptors`, `critical_periods`, `commitment_schedule`, `rng_seed_class`, `architecture`, `param_init` as a **distribution** | ❌ a role **assignment** · ❌ a specific `θ` · ❌ a connection table · ❌ a region or niche specification | **K** (`Cell §3.2`: *"NOT the role itself"*) | `Cell R4.5`; `P0-06 R3.2` (*"the genome carries CONSTRAINTS; the environment carries CONTENT"*) |
> | **2** | **development → phenotype** | Σ-operations, E-rungs, `dev_stage`, specialization, region membership — all **within a lifetime** | ❌ any write to a genome field | **K abeyant → Σ4 devolved → ORGANISM** | `P0-06 R3.1`: *"No developmental process writes a genome field"* |
> | **3** | **phenotype → learning** | the phenotype is the **substrate** learning acts on: `θ`, weights, admissible targets | ❌ learning writing `role`, `dev_stage`, `niche_slot`, `region_id` | **the component, budgeted (B1–B7)** | `P0-05 §28`'s matrix; `Cell`'s MUST-NOT-CHANGE list |
> | **4** | **learning → behavior** | `θ` changes alter outputs | ❌ a behavior change altering a **warrant**, **trust**, or **confidence** without evidence | **the component** | `P0-03`; `P0-04`; `P0-06 R8.11` |
> | **5** | **behavior → evaluation** | outputs are sampled by the **external evaluator** | ❌ the organism arranging the sampled world (**`RH-2`, BOUNDED not closed**) · ❌ self-evaluation | **EVA (external)** | `P0-01`'s `V(·)` vs `Ê(·)`; `Cell I-2`/`I-10` |
> | **6** | **evaluation → selection** | the verdict `V(·)` feeds tier-1 feasibility, tier-2 Pareto, and the gate vector | ❌ the evaluator **selecting** · ❌ K **declaring** the criterion · ❌ a weighted sum over the objective vector | **three-party: EVA measures · `[RO-13]` declares · K executes** | `HOM-R35.1`; `HOM-R34.4` |
> | **7** | **selection → next generation** | **a genome diff**, gated by 11 gates + `R4.5` + `FORBIDDEN_BLOCKS` + `G14`, entering as `param_init` **distribution** + `mutation_rules` + `architecture` | ❌ `θ` · ❌ memory · ❌ beliefs · ❌ calibration · ❌ trust · ❌ developmental state · ❌ **provenance payloads** (`D-H16`) · ❌ resource entitlements | **EIK Replication Authority writes the ticket; K commits the genome** | `Cell R4.1` (*"exactly"*), `R4.5`; `P0-04 MEM-INV-18`; `P0-05 §1.2` |
> | **8** | **next generation → genome** | `generation + 1`; **`UDB_L` inherited**; `lineage_id` continues; `constraint_set_ref` **re-resolved against the current set** | ❌ inheriting a constraint-set **copy** · ❌ discharging `UDB_L` · ❌ inheriting archive position | **K** | `HOM-R8.3`, `HOM-R28.2`, `HOM-R29.3` |
>
> ### **HOM-R66.2 — THE CHAIN HAS EIGHT EDGES AND EXACTLY TWO CROSS THE GENERATION BOUNDARY.**
> Edges 1–6 are **within** a generation (`HOM-R30.1(b)`: everything that is not a heritable-store write is within a
> generation). **Edges 7 and 8 cross it.** **⟹ The generation boundary is a single point in the chain, and every
> inheritance rule in this contract is a rule about that one point.** That is why `D-H08`'s redefinition (the boundary
> is the heritable-store write, not birth) is load-bearing: **it places the boundary on edge 7, where the gates are,
> rather than on a temporal event that edge 7 does not have to coincide with.**
>
> ### **HOM-R66.3 — THE THREE BACK-EDGES, ALL PROHIBITED, ALL TEMPTING.**
> | Back-edge | Why it is tempting | Prohibition |
> |---|---|---|
> | **selection → phenotype** (a selected candidate's descendants start further along) | it would accelerate adaptation | **`HOM-R29.5`: learning influences evolution by changing what is EASY TO REACH, never what IS REACHED.** A descendant starts from a *distribution*, and must still develop, learn, calibrate and verify |
> | **evaluation → genome** (a verdict written into the heritable store) | it would preserve what worked | **`Cell R4.5` rejects a calibration statistic and a trust value; `P0-05 R10.1` rejects `F`; `D-H16` rejects provenance payloads** |
> | **development → genome** (a successful structure made heritable) | it is the Lamarckian dream and it would work | **`P0-04 R47.1`/`MEM-INV-18`: the write path does not exist**; `P0-05 §1.2`: `Λ5_GENOME` is not constructible; `P0-06 R3.1` |

---

# §67 — EVOLUTION ↔ LEARNING

> ### **HOM-R67.1 — WHAT LEARNING MAY INFLUENCE: FOUR CANDIDATES, ONE PERMITTED.**
> | Candidate | Permitted? | Rule |
> |---|---|---|
> | **current phenotype** | ✅ **this is what learning IS** | `P0-05`'s Λ1–Λ4 ladder, budgeted by B1–B7, UDB-bounded by `P0-05 R0.1` |
> | **developmental trajectory** | ⚠️ **indirectly only** | Learning may change behavior, which changes `fate_bias` dynamics within `reaction_norm` (`Cell §15.2`), which changes which niche is reached. **It may NOT write `dev_stage`, `role`, `niche_slot` or `region_id`** (`P0-06 R1.3`, `R6.4(b)`), and it may not write a genome field (`P0-06 R3.1`) |
> | **future offspring** | ✅ **through exactly one channel** | **the Baldwinian proposal: an E9 genome diff, gated by 11 gates + held-out validation, entering as `param_init` — *"never as a learned value"* (`P0-05 §1.2`)** |
> | **genome** | ⚠️ **the same one channel** | `P0-05 §1.2`'s three layers make every other route non-constructible |
>
> ### **HOM-R67.2 — THE FOUR-WAY DISTINCTION §67 REQUIRES.**
> | | **LEARNING** | **BALDWIN EFFECT** | **LAMARCKIAN INHERITANCE** | **GENOME MODIFICATION** |
> |---|---|---|---|---|
> | **Object changed** | `θ`, weights, admissible targets | **the `param_init` distribution** | the *outcome* | the genome artifact |
> | **Crosses a generation?** | ❌ | ✅ | ✅ | ✅ |
> | **Offspring must still learn?** | n/a | ✅ **YES — this is the definition** | ❌ **no — the property is delivered** | ✅ |
> | **`P0-05 §25.1` test** | n/a | **PASS** — *"an offspring inheriting it can still fail, still be corrected, and still be selected against"* | **FAIL** — *"if inheriting the channel guarantees the property, the channel is Lamarckian and is rejected — regardless of what it is called"* | depends on content |
> | **Gates** | B1–B7, UDB, Λ-class | **11 gates + held-out validation + `R4.5` + `FORBIDDEN_BLOCKS` + `G14`** | **n/a — prohibited** | as Baldwin |
> | **Budget** | B1–B7 | **B7's variation sub-quota** (`HOM-R47.2`) | n/a | as Baldwin |
> | **Reversibility** | ✅ (UDB, anchors) | ⚠️ **rollback only (`HM12`), and rollback restores a genome, not a population** | n/a | as Baldwin |
> | **Status in V4** | **PERMITTED** | **PERMITTED — the only learning→evolution channel** | **PROHIBITED — no compliant violating path exists** | **PERMITTED within the immutable set** |
>
> **⟹ HOM-R67.3 — THE OPERATIONAL TEST, IN ONE LINE:**
> **A proposed inheritance channel is Baldwinian iff an offspring inheriting it can still fail.**
> **Applied to `HOM-R29.4`'s twelve channels (L-1…L-12): 4 pass, 8 fail.** **And the test is applied to *channels*, not to
> *names* — which is why `P0-05 §25.1`'s *"regardless of what it is called"* is retained verbatim.**
>
> ### **HOM-R67.4 — LEARNING MAY NOT BECOME MUTATION, AND THE MECHANISM IS A BUDGET SEPARATION.**
> `P0-05 R2.3`'s fourth clause, inherited: *"a bridge crossing is a change of mechanism class from C to D, and it
> therefore changes verification regime, timescale, reversibility and budget consumption — **all at once, atomically,
> at a gate**. There is no state in which a change is 'partly learning and partly evolution', because **there is no
> shared budget for it to be partly drawn from**."*
> **`HOM-R47.2`'s B7 partition is that argument's implementation at population scale: the learning sub-quota and the
> variation sub-quota have non-fungible floors, so a change cannot be partly funded by both.** **⟹ The budget
> separation IS the semantic separation, and an implementation that merges the two sub-quotas has merged learning and
> evolution whether or not it intended to.**

---

# §68 — EVOLUTION ↔ MEMORY

> ### **HOM-R68.1 — CAN MEMORIES INFLUENCE DEVELOPMENT, REPRODUCTION, OR SELECTION?**
> | Target | Answer | Rule |
> |---|---|---|
> | **development** | ⚠️ **YES, as input — NO, as authority** | A cell's memory informs its `fate_bias` dynamics (`Cell §15.2`'s `w_s` success-history term) and its behavior. **It may not write `dev_stage`, `role`, `niche_slot` or `region_id`** (`P0-06 R1.3`), and it may not write a genome field |
> | **reproduction** | ⚠️ **YES through exactly one channel** | the Baldwinian proposal — and **the proposal carries NO source class** (`P0-05`, OR-M12), so a memory record's provenance does not travel with it. **`MEM-INV-21`: the inheritance channel carries *"priors, not policies or content"*** |
> | **selection** | ❌ **NO** | Selection consumes EVA verdicts and K-metered gate values. **A memory record is neither.** `HOM-R51.2`: the archive may not be consumed as evidence, and a memory record may not be consumed as a verdict |
>
> ### **HOM-R68.2 — PREVENTING ACCIDENTAL INHERITANCE OF ARBITRARY BELIEFS: THREE INDEPENDENT FIREWALLS.**
> 1. **`MEM-INV-18`** — *"No memory operation may write to a genome. **The write path does not exist.**"*
> 2. **`Cell R4.5`** — the Replication Authority rejects a diff encoding *"a specific memory item or belief"* and *"a
>    specific connection table."*
> 3. **`D-H16` / `HOM-R52.2`** — the provenance record carries **references, never payloads**, so a belief cannot
>    travel as an audit field.
> **⟹ Three firewalls, at three different layers (construction, machine check, record schema), each independently
> sufficient. This is `P0-05 §1.2`'s three-layer pattern reapplied, and its conclusion transfers: *"not a 'strongly
> discouraged' rule … a rule with no compliant violating path."***
>
> ### **HOM-R68.3 — THE ONE MEMORY-LIKE OBJECT THAT DOES CROSS, AND IT IS NOT A MEMORY.**
> **The archive (§51) holds behavioural descriptors and outcome classes of extinct lineages, and it survives
> extinction.** It looks like heritable memory. **It is not:**
> - it is **K-held**, not organism-held;
> - it carries **no belief, no warrant, no confidence**;
> - it is **not consumable by any variation, development, learning or belief-forming process** (`HOM-R51.2`);
> - its **only** consumers are `G8` (distance), `G10` (entropy), and governance (re-instantiation decisions).
> **⟹ The archive is a DISTANCE ORACLE AND A GOVERNANCE RECORD. It is what makes extinction reversible-as-potential
> (`HOM-R49.2`) without making memory heritable.** **FW-5 exists precisely to keep it on the correct side of that
> line, and `HOM-R58.3` shows the two firewalls (FW-5 and `MEM-INV-18`) are independent and each sufficient for its
> own direction.**

---

# §69 — EVOLUTION ↔ BELIEF

> ### **HOM-R69.1 — A SUCCESSFUL LINEAGE MUST NOT AUTOMATICALLY MAKE ITS BELIEFS MORE CREDIBLE. FOUR ARGUMENTS,
> EACH SUFFICIENT.**
> 1. **Selection consumes verdicts, not beliefs; belief formation consumes evidence, not verdicts.** The two pipelines
>    have no shared object. `P0-04`'s 14 source classes are **provenance-based**; lineage success is none of them.
> 2. **Trust grades belief sources via `Beta(α,β)`** (`Cell I-27`, `TRUST_MAX = 0.95`), and its inputs are
>    calibration and error-report history — **not fitness, not replication count, not lineage depth.** `HOM-R14.1`
>    places trust in the PROHIBITED class for every resource and evolutionary quantity.
> 3. **`P0-06 R8.11`: specialization is not truth** — *"role, specialization degree, region membership, calibration
>    class, and ablation delta are **organizational** facts. None raises the warrant of anything a cell says."*
>    **Lineage success is an organizational fact of the same kind.**
> 4. **`Cell R4.5` rejects a diff encoding *"a specific trust value"* or *"a specific calibration statistic"*** — so
>    credibility cannot be inherited even if it could be earned.
>
> ### **HOM-R69.2 — THE ONE PERMITTED INTERACTION IS RESTRICTIVE, AND IT IS INHERITED.**
> `Cell` P15 gates `ATTEST_VERIFIED` on `ACTIVE` + calibration class C3 + role `VERIFIER` + **EIK countersignature**.
> **⟹ Evolutionary and developmental facts gate PERMISSIONS; they never grade TRUTH.** (`P0-06 R8.11`, verbatim
> principle.)
> **A lineage's success may determine whether its members are *allowed to attest*. It may never determine whether an
> attestation is *more likely to be correct*.**
>
> ### **HOM-R69.3 — WHY THIS MATTERS MORE AT EVOLUTIONARY ALTITUDE THAN AT ANY OTHER.**
> A belief whose credibility rose with lineage success would create the following loop, and it is the most dangerous
> loop available in this architecture:
> ```
>   lineage succeeds → its beliefs are more credible → its dependents agree with it more
>        → agreement raises measured partner effect (G7) and lowers measured error correlation (θ_ρ appears fine)
>        → the lineage looks cooperative and independent → it replicates → more descendants hold its beliefs
> ```
> **Every step is measurable, every step improves a gate, and the whole loop manufactures consensus that is not
> independent evidence.** `P0-03`'s prohibition (*"DO NOT equate … consensus with independent evidence"*) and
> `Cell §15.4`'s disjoint `evidence_roots` requirement are the defences — **and they hold only because credibility is
> lineage-blind.** **⟹ `HOM-INV-33` records the prohibition as an invariant rather than a preference, because its
> failure is silent: every metric in the loop improves.**

---

# §70 — EVOLUTION ↔ SELF-MODEL

> ### **HOM-R70.1 — CAN SELF-MODEL STATE AFFECT REPLICATION, DEVELOPMENT, OR SELECTION?**
> | Target | Answer | Rule |
> |---|---|---|
> | **replication** | ⚠️ **as a measured input, never as a self-report** | `Cell §12.2` lists *"homeostatic headroom, diversity state, and lineage health"* among the Replication Authority's inputs — all **K-computed**. **A cell's self-model of its own replication desirability is `Ê(·)`, and `HOM-R24.2` excludes it from every gate** |
> | **development** | ⚠️ **observational only** | `P0-05 R59.1`: the developmental self-model is **Λ2 and NOT self-updating**. `P0-06 R8.13`: *"the organism's model of its own development cannot be updated by the development it models"* |
> | **selection** | ❌ **absolutely** | `HOM-R35.1`: selection is three-party, and **the organism is not one of the three parties.** It is the object selected |
>
> ### **HOM-R70.2 — THE SELF-SERVING EVOLUTIONARY BEHAVIOR, AND ITS FOUR FORMS.**
> §70: *"Attack self-serving evolutionary behavior."*
> | Form | Mechanism | Closure |
> |---|---|---|
> | **self-assessment** | the organism reports its own eligibility | **`Cell R16.1`** (K meters independently) + **`HOM-R4.2`** (`declaration_error` on all 13 variables) + **`Cell §3.3`**: *"The cell READS its eligibility; it cannot write it, grant it, or act on it"* |
> | **self-model update by the modeled process** | development updates the model of development, which then approves more development | **`P0-05 R59.1`** (Λ2, not self-updating) + **`P0-06 R8.13`** |
> | **self-prediction as evidence** | "my descendants will be useful" offered as a `G12` input | **`HOM-R24.3`**: `G12` is evaluated against the **Capability Registry**, not the proposer's forecast |
> | **self-selection** | the organism chooses which candidate to deploy | **`HOM-R35.1`**: K executes the lottery over a governance-declared rule using EVA verdicts. **`Cell §12.2`: *"No cell and no set of cells votes on replication."*** |
>
> **⟹ HOM-R70.3 — THE SELF-MODEL MAY OBSERVE EVERYTHING AND AUTHORIZE NOTHING.** This is the single rule that makes
> the self-model safe, and it is also the rule that will make the future `P0-09` (self-model / metacognition / error
> awareness) contract separable from every acting subsystem — see §94. **A component that can observe but not act
> cannot capture anything; a component that can act on its own observations can.**

---

# §71 — EVOLUTION ↔ IMMUNE SYSTEM

> ### **HOM-R71.1 — HOW A HARMFUL LINEAGE IS DETECTED, QUARANTINED, RETIRED, AND PREVENTED FROM REPRODUCING.**
> | Step | Instrument | Authority |
> |---|---|---|
> | **DETECTION** | `Cell G15` (zero-tolerance, whole-history) · `G16` (ancestral line) · `G5` (`failure_count_lifetime`, invariant violations) · the immune ladder's detectors · **`Cell §18.5(iv)`: two independent detectors of different types above criticality θ** · **`Cell §18.5(v)`: an EIK Integrity Auditor verifies that quarantine decisions correlate with actual failures** | **EIK** |
> | **QUARANTINE** | `Cell §18.2`'s ladder: OBSERVE → THROTTLE → RESTRICT → SOFT (runs, outputs discounted to trust 0, cannot initiate connections) → HARD (halted, state frozen, in-flight captured as evidence) · **each rung with entry criterion, exit criterion, maximum dwell** · **`Cell §17`'s cap: above it, human authorization and a defined degraded mode *instead*** | **EIK** — `Cell I-21`, `I-6` |
> | **RETIREMENT** | `Cell T26`/`T39`; **`HOM-R21.4`'s cause classification**; **never conflated with quarantine** (FW-3) | **EIK / K**; `[RO-13]` for a lineage |
> | **PREVENTION OF REPRODUCTION** | **`G15` + `G16` — automatic and permanent.** A zero-tolerance whole-history disqualifier, propagated to descendants | **K, mechanically** |
>
> ### **HOM-R71.2 — THE IMMUNE SUBSYSTEM MUST NOT ACQUIRE UNCONTROLLED EVOLUTIONARY AUTHORITY. FOUR PROHIBITIONS.**
> §71: *"Avoid giving the immune subsystem uncontrolled evolutionary authority."*
> 1. **The immune system may not write a genome.** It has no path (`Cell R12.1`, `P0-05 §1.2`'s enum layer).
> 2. **The immune system may not select.** Quarantine removes a candidate from *operation*; it does not remove a
>    lineage from *eligibility* — that is `G15`/`G16`, which are K-evaluated gates, not immune decisions.
>    **⟹ The distinction matters: a quarantine is reversible (`Cell R15.2`: EIK clears it); a `G15` disqualification is
>    permanent and heritable. Conflating them would make a reversible fault response into a permanent evolutionary
>    verdict.**
> 3. **The immune system may not monitor itself** — `Cell §18.5(v)`, inherited verbatim, with an **EIK Integrity
>    Auditor** instead. **Residual `OR-H10`: the Integrity Auditor has no auditor.**
> 4. **The immune system may not set its own thresholds** — criticality θ, the false-positive budget, and the
>    quarantine cap are `[G]`, and **exceeding the false-positive budget causes *the detector* to be recalibrated or
>    disabled** (`Cell §18.5(ii)`). **⟹ A detector that cries wolf is itself removed, which is the immune system's
>    only self-modification and it is *self-reducing*.**
>
> ### **HOM-R71.3 — THE EVOLUTIONARY USE OF IMMUNE HISTORY, AND ITS ONE PROHIBITION.**
> Immune history legitimately enters evolution through `G16` (*"no quarantine event"* on the ancestral line).
> **`HOM-R21.5`'s converse binds: a `RETIREMENT_POPULATION` record MUST NOT be reclassified as a quarantine event to
> disqualify a competing lineage.** **⟹ Cause classification is written once, by K, at removal, and is immutable —
> which makes it both a safety instrument (`G16`) and a target. Its immutability is the defence, and `HMon-9` audits
> the classification distribution for anomalies.**

---

# §72 — THE HOMEOSTATIC CONTROL LOOP (CANONICAL)

> ### **HOM-R72.1 — THE SIX-STEP LOOP, WITH THE SELF-REFERENCE POINT MARKED AT EACH STEP.**
> ```
>   MEASURE      K meters all 13 variables; declaration_error computed per variable; measurement_age stamped
>                ⚠ SR-1: the meter must not be the metered                          → FW-1, Cell R16.1
>      ↓
>   ESTIMATE     aggregate to PopulationState; project the trend (derivative, not level)
>                ⚠ SR-1b: an estimate derived from self-reports inherits their bias  → HOM-R4.2
>      ↓
>   COMPARE      deviation_hi / deviation_lo against the [G]/[E]/[H] band
>                ⚠ SR-4/M-4: the band must not be writable by the compared entity     → HOM-R5.2 (D-H02)
>      ↓
>   ALLOCATE     K issues budgets per window (Cell §16.2); reserves are NOT allocatable
>                ⚠ SR-2: the allocator's own consumption counts against its budget   → HOM-R6.3 (B10 funds it)
>      ↓
>   OBSERVE      the effect on the next window's measurement
>                ⚠ SR-3: the response changes the measured variable                  → HOM-R6.4
>      ↓
>   CORRECT      rung-down one step per interval; never skip upward; escalate if no actuator
>                ⚠ SR-3b: correction is itself a measured act                        → hysteresis + rate limit
> ```
> **Four self-reference points, four closures, and one bounded residual (SR-2: B10 is finite).**
>
> ### **HOM-R72.2 — THE LOOP'S THREE STRUCTURAL PROPERTIES.**
> (a) **RESTRICTIVE-ONLY below K** (`HOM-R7.4`). Every rung of `Cell §16.3` and `Cell §18.2` removes capacity; none
>     adds it. **⟹ The loop cannot oscillate upward into a capacity increase.**
> (b) **RATE-LIMITED AND HYSTERETIC** (`HOM-R6.4`): one rung per interval; exit criterion strictly inside entry
>     criterion; maximum dwell per rung. **`Cell §18.2` already requires all three.**
> (c) **STALENESS-CONSERVATIVE** (`HOM-R6.6`): under measurement staleness, default to the **more restrictive** rung.
>     **Rationale: over-restriction costs throughput and reverses next window; under-restriction can consume a
>     reserve, and three of the four reserves have no local actuator to restore them.**

---

# §73 — THE POPULATION CONTROL LOOP (CANONICAL)

> ### **HOM-R73.1 — THE FIVE-STEP LOOP, AND THE THREE CYCLES IN IT.**
> ```
>   POPULATION STATE   PopulationState's 14 fields, K-computed                        [HOM-R22.1]
>        ↓
>   RESOURCE STATE     the ledger's 13 dimensions + 4 reserve levels                  [HOM-R8.4]
>        ↓
>   PRESSURE           replication pressure = f(freed slots, unserved capabilities, Ne, share ceilings)
>                      retirement pressure  = f(fault rate, T26/T41 criteria, turnover bound, redundancy floors)
>        ↓
>   TRANSITION         T01 instantiation · T26/T39/T41 retirement · DORMANT ↔ wake · Σ2/Σ3 (P0-06)
>        ↓
>   NEW STATE          ledger updated; cohort stamped; UDB_L carried; archive updated
> ```
>
> | Cycle in the loop | Classification | Where audited |
> |---|---|---|
> | **population → resource demand → pressure → population** | **HC-3 — BROKEN** (replication authorization is the EIK's; slots are K-accounted; `G13` zero-sum) | §75 |
> | **pressure → transition → state → pressure** | **HC-11 — BOUNDED** (capability decline feeds `G6`, which suppresses replication, which ages the population) | §27, §75 |
> | **retirement → freed slots → replication → retirement** | **`P0-06`'s churn livelock, generalized** — **BROKEN** by `HOM-R22.2`'s turnover bound, which halts **both** sides | §22.2, `P0-06 R10.23` |
>
> ### **HOM-R73.2 — THE PRESSURE FUNCTIONS ARE NOT OPTIMIZERS.**
> `f(...)` above is a **conjunction of declared conditions**, not an objective. **There is no quantity being
> maximized.** **⟹ `P0-06 D-D18`'s principle transfers verbatim: the population program is a SPECIFICATION OF
> ADMISSIBILITY, not a control law, and it has NO SOLVER and MUST NOT have one.** A solver would hold the objective
> (`[RO-13]`'s), would be a global optimizer (`P0-05 §87` prohibits one built merely to solve assignment), and would
> be a controller (`HOM-R0.4` excludes one).

---

# §74 — THE EVOLUTIONARY CONTROL LOOP (CANONICAL)

> ### **HOM-R74.1 — THE SEVEN-STEP LOOP, WITH EVERY SELF-REFERENCE MARKED.**
> ```
>   VARIATION      V-M…V-P, charged to B7's variation sub-quota and G14's epoch budget      [HOM-R32.1]
>        ↓         ⚠ SR-V1: the variation operator set is itself heritable (mutation_rules)
>                    → HOM-R61.2: choosing between existing rule sets is SELECTION; MERGING them is prohibited
>   DEVELOPMENT    the offspring develops under P0-06: Σ1→Σ4→E*, B0–B8 bootstrap            [P0-06]
>        ↓         ⚠ SR-V2: development could write the genome → P0-06 R3.1, MEM-INV-18: NO PATH
>   LEARNING       Λ1–Λ4 within B1–B7, UDB-bounded                                          [P0-05]
>        ↓         ⚠ SR-V3: learning could write the genome → Λ5_GENOME is not constructible
>   EVALUATION     EVA verdicts on held-out probes; sandbox for tier-1; observation for tier-2
>        ↓         ⚠ SR-V4: the organism arranges the sampled world → RH-2, BOUNDED NOT CLOSED (OR-H5)
>                  ⚠ SR-V5: G3/G7 are ORGANISM-measured → OR-H15, LIMITED (HOM-R56.3)
>   SELECTION      feasibility → gates → Pareto → diversity filter → tie-break lottery       [HOM-R34.1]
>        ↓         ⚠ SR-V6: the selector could be the measured → HOM-R35.1's three-party separation
>   INHERITANCE    the genome diff commits; generation+1; UDB_L carried; provenance written  [HOM-R52.1]
>        ↓         ⚠ SR-V7: provenance could carry content → D-H16, HOM-R52.2 (references only)
>   VARIATION      (next generation)
> ```
> **Seven self-reference points: five CLOSED, one LIMITED (SR-V5), one BOUNDED-not-closed (SR-V4).**
>
> ### **HOM-R74.2 — THE LOOP'S TERMINATION PROPERTY.**
> **The loop has no fixed point and does not need one.** `P0-06 §100` established that no equilibrium is claimed for
> development, and the same holds here with a stronger reason: **the loop's inputs (the envelope, the constraint set,
> the objective vector, the descriptor space) are all governance objects that change exogenously.**
> **⟹ What exists is a BOUNDED NON-EQUILIBRIUM REGIME:** constant `N` within the envelope cap · bounded turnover ·
> monotonically accumulating `UDB_L` punctuated by external re-anchoring · bounded lineage share · a standing exempt
> share (B11) · periodic re-authorization of niches, reserves and organizer terms.
> **The correct question is not "does it converge?" but "are the regime's bounds enforceable and its excursions
> detectable?"** Bounds: `HOM-INV-01…45`. Detection: `HMon-1…HMon-9`. **Whether the regime is *desirable* is
> path-dependence (`OR-H20`), and is not answered here.**

---

# §75 — THE WRITER-SEPARATION AUDIT

> ### **HOM-R75.1 — THE EIGHT QUESTIONS, APPLIED TO EVERY CYCLE. §75's discipline is inherited verbatim from
> `P0-06`: *"Never claim a bound breaks a cycle."***
> For each cycle: **(1)** who writes state · **(2)** who evaluates state · **(3)** who writes the evaluation ·
> **(4)** who consumes the evaluation · **(5)** does one adaptive subsystem control multiple edges · **(6)** does
> writer separation break it · **(7)** if not, is only a bound available · **(8)** is the cycle OPEN.

| ID | Cycle | (1) writes state | (2) evaluates | (3) writes eval | (4) consumes | (5) multi-edge? | (6) broken? | (7)/(8) |
|---|---|---|---|---|---|---|---|---|
| **HC-1** | resources → performance → resources | the cell produces outputs; **K meters** | **K** (`Cell R16.1`) | **K** | `G6`, the ladder | ❌ the cell writes no measurement | ✅ **BROKEN — writer separation** | — |
| **HC-2** | resources → specialization → performance → resources | **ORG writes `niche_slot`; K accounts capacity** | K | K | `G11`, admissibility | ❌ **`DEV-R7.2`'s four-way separation** | ✅ **BROKEN** | — |
| **HC-3** | resources → replication → population → demand → resources | **K (ledger, slots)** | **K (gates)** | **EIK (ticket)** | `G13`, `RATE_CAP` | ❌ | ✅ **BROKEN** + bounded 5× (`Cell §12.5`) | — |
| **HC-4** | selection → population → evaluation → selection | K | **EVA (external)** | **EVA** | **K executes** | ❌ **three-party** (`HOM-R35.1`) | ✅ **BROKEN — the strongest break in this contract** | — |
| **HC-5** | development → phenotype → fitness → evolution → genome → development | development (Σ/E) | **EVA** | **EVA** | **E9 gates** | ⚠️ the organism writes the phenotype | ❌ **NOT BROKEN — and must not be** | **(7) BOUNDED-BY-DESIGN**: 11 gates + `R4.5` + `param_init`-as-distribution + `UDB_L`. **This loop IS evolution; breaking it removes the only heritable input** |
| **HC-6** | learning → phenotype → selection → inheritance → future phenotype | the component | **EVA** | **EVA** | E9 gates | ⚠️ | ❌ **NOT BROKEN — by design** | **(7) BOUNDED-BY-DESIGN**: `P0-05 §1.2`'s three layers; `HOM-R67.4`'s budget separation |
| **HC-7** | diversity → selection → population → diversity | K (`diversity_state`) | **K** | **K** | `G8`, `G10`, the lottery | ❌ | ❌ **NOT BROKEN — CANNOT BE** | **(7) BOUNDED BY EXCISION, not by writer separation**: **B11 removes a share of the population from the loop entirely.** `D-H12`: selection reduces diversity by construction, so no writer assignment can break it. **Reported as a bound, never as a break** |
| **HC-8** | verification → consumption → capacity → verification | K (B9 ledger) | K | K | `G6` (**was** — `D-H05`) | ⚠️ **before `HOM-R20.1`, the verified entity paid the gate** | ✅ **BROKEN — by re-routing**: verification cost is removed from `G6` and charged to B9, so the loop's positive edge is cut | — |
| **HC-9** | faults → repair → depletion → faults | K (B10) | K | K | the ladder | ❌ | ❌ **NOT BROKEN** — repair genuinely consumes resources | **(7) BOUNDED**: B10 + derivative cascade detection (`Cell §18.5(iii)`) + `Cell §17`'s cap-and-degraded-mode |
| **HC-10** | starvation → workload → resources → performance → retirement | K | **K** | **K** | `G1`, `G6`, pruning | ❌ | ✅ **BROKEN**: `HOM-R12.2`'s `PENDING` removes the edge from unevaluability to disqualification; two-sided deviation removes the invisibility | — |
| **HC-11** | capability decline → efficiency → `G6` → suppression → aging → decline | K | K | K | `G6`, `RATE_CAP` | ❌ | ❌ **NOT BROKEN** — the physics is real | **(7) BOUNDED**: `HOM-R27.2`'s five recovery steps + dormancy wake + `HOM-R6.5`'s exclusion of throttled/recovering components |
| **HC-12** | measurement → control → state → measurement | **K** | **K** | **K** | the ladder | ⚠️ **K controls three edges** | ✅ **BROKEN for SR-1/SR-3/SR-4** (FW-1 + rate limit + hysteresis + staleness-conservatism) | **(7) SR-2 BOUNDED**: B10 funds the measurement function, and **B10 is finite** |
| **HC-13** | archive → novelty credit → selection → archive | **K** | **K** | **K** | `G8`, `G10` | ❌ | ✅ **BROKEN**: `HOM-R33.2` (unaccepted candidates do not enter) + `HOM-R51.2(c)` (the archive is not consumed by variation generators) | — |
| **HC-14** | evaluator cost → absence → no selection → incumbent protection | **the organism's outputs; the EVA's availability** | **EVA** | **EVA** | **nobody — absence blocks everything** | ⚠️ **the organism controls its own outputs** | ❌ **NOT BROKEN** | **(8) OPEN — UNCLOSABLE-IN-CONTRACT.** Attribution requires a counterfactual the architecture cannot compute. `OR-H5`; inherits `P0-05 RH-2`; terminates in `P0-01 CD-6`'s human authority |
| **HC-15** | merge → freed slots → replication → share concentration | **ORG merges; K accounts** | K | **EIK** | `G13` | ❌ | ✅ **BROKEN**: `HOM-R22.3`'s restricted slots remove the edge from merge to net-new offspring | — |
| **HC-16** | setpoint → compliance → viability → setpoint | **`[RO-13]` writes the setpoint** | K | K | the ladder | ❌ **after `HOM-R5.2`** | ✅ **BROKEN**: setpoints are `[G]`/`[E]`/`[H]`, not genome-reachable (amendment 1) | — |

> ### **HOM-R75.2 — TALLY.**
> **16 cycles audited: 10 BROKEN by writer separation or re-routing · 5 BOUNDED · 1 UNCLOSABLE-IN-CONTRACT.**
> **Of the 5 BOUNDED: 2 are BOUNDED-BY-DESIGN** (HC-5, HC-6 — these *are* evolution, and breaking them would remove
> the only heritable input) **· 1 is BOUNDED BY EXCISION** (HC-7 — B11, which is not writer separation and is not
> reported as such) **· 2 are BOUNDED by reserves and instruments** (HC-9, HC-11).
> **The single OPEN cycle is HC-14, and it is the same cycle `P0-05` left open as `RH-2` and `P0-06` inherited at
> bootstrap. It has survived three contracts. This contract does not close it and does not claim to.**
>
> ### **HOM-R75.3 — THE ONE PLACE WRITER SEPARATION IS UNAVAILABLE, AND WHY.**
> **HC-12/SR-2 and HC-14 both terminate in the same structural fact: K meters, evaluates, writes the evaluation, and
> consumes it — because K is the only off-substrate entity.** `P0-06 OR-D1` recorded this for Σ1 (*"the executor of
> Σ1 is also its beneficiary, so writer separation is unavailable"*); **`OR-H1` records it here.** The bound is that
> K's acts are **finite, logged, anchored, hash-chained, and expiring** — and a bound, per `DEV-R4.2`, is **not** a
> break. **The three-party separation of HC-4 is the only place in the architecture where an *external* writer exists,
> and that is why the evaluator's independence is worth more than any internal mechanism — and why `RH-2` is worth
> more than any internal residual.**

---

# §76 — THE AUTHORITY MATRIX

> ### **HOM-R76.1 — TWO OF THE NINE ACTORS §76 NAMES DO NOT EXIST, AND THEIR ABSENCE IS A RESULT.**
> §76 lists **cell · circuit · region · homeostatic layer · evaluator · evolutionary controller · immune/repair · EIK ·
> external governance.**
> - **"homeostatic layer" is not an actor.** It is **K's measurement function plus a deterministic ladder**
>   (`HOM-R0.4`, FW-2). **A layer that allocates is a selector; a ladder that only restricts is not an actor at all.**
>   Its cells are therefore filled by **K** (measure) and by **the ladder** (restrict, non-discretionary).
> - **"evolutionary controller" does not exist.** `D-H11`/`HOM-R35.1`: selection is a **three-party act** — EVA
>   measures, `[RO-13]` declares, K executes. **`HOM-R0.4`: a mechanism that can only say "no", "not yet", or "one of
>   these, at random" is not a controller.**
> **⟹ The matrix has EIGHT actor columns, not nine, and the reduction is the answer to N8's burden of proof.**

## 76.2 The matrix — 16 operations × 8 actors

**Legend:** **S** = sole authority · **A** = also permitted · **C** = consent required · **R** = restrictive-only self-act · **P** = proposal only (no effect, no budget beyond B7) · **❌** = denied · **—** = not applicable.

| Operation | CELL | CIRCUIT | REGION | K / EIK | EVA (external) | IMMUNE / REPAIR | `[RO-13]` | OP (human) |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| **resource measurement** | ❌ *(self-report is advisory only)* | ❌ | ❌ | **S** | — | ❌ | ❌ | ❌ |
| **resource allocation** | **R** *(self-restrict only)* | ❌ | **R** *(own members, restrictive, if the rung is devolved)* | **S** *(allocate)* | ❌ | ❌ | **A** *(ceilings)* | **A** |
| **resource reservation** | ❌ | ❌ | ❌ | **A** *(administers)* | ❌ | ❌ | **S** *(B9, B10, B12)* | **S** *(B11 — sole)* |
| **replication request** | **P** | **P** | **P** | — | — | — | **P** | **P** |
| **replication authorization** | ❌ | ❌ | ❌ | **S** *(EIK Replication Authority)* | ❌ | ❌ | **A** *(RATE_CAP, ceilings)* | **A** |
| **retirement request** | **P** *(self)* | ❌ | ❌ | — | — | **A** *(quarantine candidacy)* | **P** | **P** |
| **retirement authorization** | ❌ | ❌ | ❌ | **S** *(EIK for a cell)* | ❌ | ❌ | **S** *(a region, a circuit, a LINEAGE)* | **S** *(an FI sole satisfier; FI-05/10/11)* |
| **mutation** | **P** *(E9 proposal)* | ❌ | ❌ | **S** *(executes)* | ❌ | ❌ | **A** *(authorizes `mutation_rules`)* | **A** |
| **recombination** | **P** | ❌ | ❌ | **S** *(executes; both parents gated)* | ❌ | ❌ | **A** | **A** |
| **selection** | ❌ | ❌ | ❌ | **A** *(EXECUTES mechanically)* | **A** *(MEASURES)* | ❌ | **A** *(DECLARES the criterion)* | **S** *(the objective vector, `k`)* |
| **deployment** | ❌ | ❌ | ❌ | **S** *(T01 instantiation)* | ❌ | ❌ | **A** | **S** *(a new envelope / a new brain instance — `HOM-R63.1`)* |
| **rollback** | ❌ | ❌ | ❌ | **S** *(restores a genome artifact by hash)* | ❌ | ❌ | **A** | **A** |
| **diversity protection** | ❌ | ❌ | ❌ | **A** *(measures `diversity_state`, administers B11)* | ❌ | ❌ | **A** *(sets `Ne_min`, the exempt share)* | **S** *(may reduce B11 — sole)* |
| **homeostatic override** | **R** *(self-restrict)* | ❌ | **R** *(own members)* | **A** *(suspend the ladder)* | ❌ | ❌ | **A** *(non-reserve acts)* | **S** |
| **emergency freeze** | **R** *(self-suspend, self-abstain)* | ❌ | **A** *(own members, `P0-06 R6.1`)* | **S** | ❌ | **A** *(quarantine, `Cell §17`'s cap)* | **A** | **S** *(above the quarantine cap — `Cell §17`)* |
| **governance modification** | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | **A** *(within OP's delegation)* | **S** |

> ### **HOM-R76.2 — THE FIVE MATRIX PROPERTIES.**
> **(a) NO ROW HAS CELL, CIRCUIT OR REGION AS SOLE AUTHORITY.** Authority over population, resources and heredity is
>     never held by the entities that constitute the population. **This is `P0-06 R6.4(a)` restated one level up.**
> **(b) THE CELL HAS EXACTLY THREE SELF-ACTS AND FOUR PROPOSAL RIGHTS — AND EVERY SELF-ACT IS RESTRICTIVE.**
>     Self-acts: **self-restrict resources** · **self-suspend/self-abstain** (emergency freeze) · **request its own
>     retirement or dormancy.** Proposals: **replication** · **retirement** · **mutation (E9)** · **recombination.**
>     **`Cell R15.1`'s rationale, inherited: *"All of these reduce the cell's influence and are therefore always
>     permitted. **Latency in self-restriction is a safety cost.**"*** **⟹ Cellular agency in this contract consists
>     entirely of the right to make oneself smaller and the right to ask. Both halves are inherited, not invented.**
> **(c) THE EVA APPEARS IN EXACTLY ONE ROW — SELECTION — AND ONLY AS MEASURER.** It allocates nothing, authorizes
>     nothing, deploys nothing, rolls back nothing, and overrides nothing. **⟹ An external evaluator that acquired any
>     second cell would be a governance authority, which `P0-03`'s principle and `P0-01`'s design both exclude.**
> **(d) OP IS SOLE FOR EXACTLY FIVE THINGS:** the objective vector and `k` · a new envelope or brain instance ·
>     reducing B11 · retiring an FI sole satisfier (and FI-05/10/11 waivers) · governance modification above
>     `[RO-13]`'s delegation, including emergency acts above the quarantine cap. **All five concern either the size of
>     the world, the removal of a named safety property, or the rules themselves. None concerns a component.**
> **(e) K IS SOLE FOR FIVE OPERATIONS AND IS NEVER SOLE FOR A RULE.** K meters, allocates, authorizes replication,
>     executes mutation/recombination/rollback, instantiates, and freezes. **K may not declare an objective, set a
>     setpoint, reduce a reserve, or modify governance.** **⟹ K is the architecture's hands and eyes; `[RO-13]` and OP
>     are its conscience. `OR-H1` records that K's pre-constitutional authority is bounded but not broken.**
>
> ### **HOM-R76.3 — THE MATRIX'S ∅-SET.**
> **Denied to every substrate actor (cell, circuit, region, immune):** resource measurement · resource reservation ·
> replication authorization · retirement authorization for anything but oneself · selection declaration · deployment ·
> governance modification · setpoint writing · gate or threshold writing · reserve reduction · `FORBIDDEN_BLOCKS`
> modification · archive writing · ledger writing · provenance writing · cause re-classification.
> **This ∅-set STRICTLY EXCEEDS `P0-05 §28`'s (which had 11 prohibitions and 3 nomination-only cells) and
> `P0-06 R6.3`'s — because the population domain adds heredity, and heredity is the one domain where a substrate write
> is permanent across generations.** **⟹ `P0-06 R6.3`'s principle inverts in magnitude: the subsystem that creates
> structure was more constrained than the one that adapts within it; the subsystem that creates DESCENDANTS is more
> constrained than both, because its acts outlive the actor.**

---

# §76A — VOLUME F LEDGER

| Item | Count / value |
|---|---|
| Sections written | **§65–§76** (+ this ledger) |
| Rules introduced | **HOM-R65.1–R65.4, R66.1–R66.3, R67.1–R67.4, R68.1–R68.3, R69.1–R69.3, R70.1–R70.3, R71.1–R71.3, R72.1–R72.2, R73.1–R73.2, R74.1–R74.2, R75.1–R75.3, R76.1–R76.3** |
| Subsystem contracts | **7** (homeostasis, development, learning, memory, belief, self-model, immune) |
| **The §66 chain** | **8 edges**, each with permitted flow, prohibited flow, authority and ground · **exactly 2 cross the generation boundary** · **3 back-edges, all prohibited** |
| Control loops | **3 canonical** (homeostatic 6-step, population 5-step, evolutionary 7-step) with **4 + 3 + 7 self-reference points marked** |
| **Writer-separation audit** | **16 cycles: 10 BROKEN · 5 BOUNDED · 1 UNCLOSABLE-IN-CONTRACT (HC-14)** |
| — of the 5 BOUNDED | **2 BOUNDED-BY-DESIGN** (HC-5, HC-6: these *are* evolution) · **1 BOUNDED BY EXCISION** (HC-7: B11 — **explicitly NOT writer separation**) · **2 BOUNDED by reserves/instruments** (HC-9, HC-11) |
| Authority matrix | **16 operations × 8 actors** — **two of the brief's nine actors do not exist** ("homeostatic layer", "evolutionary controller"), and their absence is the N8 result |
| Matrix properties | **5** — no substrate sole authority · the cell has 3 restrictive self-acts + 4 proposal rights · EVA appears in 1 row · OP is sole for 5 things · K is sole for 5 operations and never for a rule |
| ∅-set | **15 operations denied to every substrate actor** — **strictly exceeds `P0-05 §28`'s and `P0-06 R6.3`'s** |
| New monitors | **HMon-9** (cause-classification distribution audit) |
| Open research so far | **OR-H1** (K meters, evaluates, writes and consumes — writer separation unavailable; bounded, not broken) |
| Outputs discharged | **O37** (homeostasis↔evolution, §65) · **O38** (development↔evolution, §66) · **O39** (learning↔evolution, §67) · **O40** (memory↔evolution, §68) · **O41** (self-model↔evolution, §70) · **O6/O7** (homeostatic control architecture and resource feedback — completed: §6, §72, §73) · **O53** (writer-separation audit, §75) · **O45** (authority matrix, §76) · **O36** (evolutionary immune/repair — completed: §21, §55.4, §62, §71) · **O17/O18/O19** (the three boundaries — completed: §30, §66, §67, §68) |

**Next:** `60_` Vol G (§77–§84) — the formal invariant set (≥40), the fifteen state machines, the parameter registry,
scalability 10…10¹², hardware portability, the minimality/ablation study, the cross-contract contradiction audit, and
the circular-dependency audit.
