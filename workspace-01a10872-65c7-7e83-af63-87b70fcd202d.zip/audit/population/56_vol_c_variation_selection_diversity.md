# P0-07 — VOLUME C (§32–§41)
## Variation, Sandbox, Selection, Governance Separation, Monoculture, Fragmentation, Diversity, Redundancy, Bottleneck

**Feeds:** `57_` Vol D, `60_` Vol G, `62_` canonical. **Conventions as locked in Vol A §0.**

---

# §32 — EVOLUTIONARY VARIATION

## 32.1 The six variation operators

> ### **HOM-R32.1 — SIX OPERATORS, EACH WITH A SCOPE, AN AUTHORITY, A BUDGET, AND A REVERSIBILITY CLASS.**
> | Op | Definition | Object acted on | Authority | Budget | Reversibility |
> |---|---|---|---|---|---|
> | **V-M MUTATION** | a bounded diff within `mutation_rules`, effect size bounded, `FORBIDDEN_BLOCKS` untouched | `mutable_traits`, `param_init`, `architecture` | **K executes; `[RO-13]` authorizes the rule set** | **B7** (proposal) + `G14`'s epoch structural-change budget | ⚠️ **rollback only (§33, `HM12`)** |
> | **V-R RECOMBINATION** | combination of two parent genomes into one candidate | two `genome` artifacts | **K executes; `[RO-13]` authorizes** | B7 + `G14` | ⚠️ rollback only |
> | **V-D DUPLICATION** | replication of a genome block | `architecture`, `mutable_traits` | K | **bounded by `genome_bytes_cap`** | ⚠️ |
> | **V-L DELETION** | removal of a mutable block or trait | `mutable_traits`, `architecture` | K | none (**deletion is a reduction** — `HOM-R7.4`) | ⚠️ |
> | **V-S STRUCTURAL VARIATION** | change to `architecture` within `param_cap` / `connection_cap` | `architecture` | K + `G14` | B7 | ⚠️ |
> | **V-P PARAMETER VARIATION** | shift of a **`param_init` distribution** | `param_init` | **the Baldwinian channel: E9 proposal, 11 gates + held-out validation** | B7 | ⚠️ |
>
> **⟹ HOM-R32.2 — ALL SIX ARE GENOME-STORE WRITES, AND THEREFORE ALL SIX ARE E9-CLASS AND ALL SIX INCREMENT
> `generation` (`HOM-R30.1`).** There is no variation operator that acts on anything else. **In particular: there is
> no variation operator that acts on a phenotype, a `θ`, a connection, a role, a region, a niche, a budget, or a
> gate.** Those are development (Σ/E), learning (Λ1–Λ4), or governance — and `HOM-R30.1(b)` places all of them
> *within* a generation.

## 32.2 The Baldwinian mixture rule for recombination

> ### **D-H09 — `Cell G10`'s `inbreeding_F` AND `d_min` PRESUPPOSE A PROCESS THE CORPUS NEVER DEFINES.**
> `Cell G10` gates replication on: *"Offspring MUST NOT decrease behavioural entropy or Ne; **lineage distance ≥
> `d_min`**; **`inbreeding_F ≤ F_max`**; error correlation ≤ `θ_ρ`."*
> **`inbreeding_F` is a coefficient of inbreeding. It is nonzero only where two related genomes combine.** `d_min`
> (lineage distance) is likewise meaningful only if lineages can approach one another. **But no corpus artifact
> defines recombination, cross-lineage combination, or any process by which two genomes contribute to one offspring.**
> `Cell §12` describes replication from **a** parent; `Cell R4.1` describes inheritance from **the** genome artifact;
> `P0-05`'s Baldwinian channel is a single-lineage proposal.
>
> **⟹ Either `G10`'s two terms are permanently trivially satisfied (`F = 0`, `d_min` satisfied by any distinct
> lineage) — in which case they are dead gates and the architecture has no recombination — or recombination exists
> and is unspecified, in which case `G10` is gating an undefined quantity.**
> **CLASSIFICATION: this is a GAP, not a contradiction. `HOM-R32.3` supplies the missing object; `G10`'s terms become
> evaluable. Proposed amendment 7 records that `Cell §12` admits a second replication mode.**
>
> > ### **HOM-R32.3 — RECOMBINATION, DEFINED.**
> > (a) **Two parents, both fully gate-eligible.** A candidate produced by recombination inherits nothing from an
> >     ineligible parent — **eligibility is evaluated on both, not on the product.**
> > (b) **The product's `param_init` is a MIXTURE DISTRIBUTION over the two parents' distributions — never a
> >     value-selection.** **Rationale:** selecting a value from either parent is `HOM-R29.5`'s prohibited form
> >     (*learning influences evolution by changing what is EASY TO REACH, never by changing what IS REACHED*). A
> >     mixture changes the reachability distribution; a selection delivers an outcome.
> > (c) **Block-level crossover is permitted for `architecture` and `mutable_traits`; it is PROHIBITED for
> >     `constraint_set_ref`, `signature`, `genome_id`, `schema_version`** — which are `FORBIDDEN_BLOCKS` and are
> >     **re-resolved against the current governance set** (`HOM-R28.2`), never taken from either parent.
> > (d) **`mutation_rules` are taken from ONE parent, declared in advance, never merged.** **Rationale: a merged rule
> >     set is a new rule set, and a new rule set is a schema object — which no substrate process may write
> >     (`HOM-R31.3(4)`).** Choosing between two existing rule sets is selection; merging them is legislation.
> > (e) **`UDB_L(product) := max(UDB_L(parent₁), UDB_L(parent₂))`** — the `P0-06 R8.3` debt-inheritance pattern.
> >     **Recombining a debt-laden lineage with a clean one is not a laundering route.**
> > (f) **`complexity_budget(product) := componentwise min(parent₁, parent₂)`.** **Never max, never mean.**
> >     **Rationale: `HOM-R31.2` makes raising a cap a capacity increase; a max or a mean would raise it.**
> > (g) **`generation(product) := max(generation(parent₁), generation(parent₂)) + 1`**, so `GEN_MAX` bounds
> >     recombinant depth as it bounds clonal depth.
> > (h) **Recombination is charged to B7 and to `G14`'s epoch structural-change budget**, and is subject to
> >     `RATE_CAP` exactly like clonal replication.
>
> ### **HOM-R32.4 — RECOMBINATION'S PURPOSE IS `Ne`, NOT PERFORMANCE.**
> Recombination exists to raise **effective population size** (`Cell G10`) by producing candidates whose lineage
> distance from the archive is large without whose genomes being novel. **It is a diversity instrument, not an
> optimization instrument.** **⟹ A recombination policy justified by "it finds better genomes faster" is a
> justification for a search operator, and search operators need a selector (`D-H11`), and the selector is
> three-party (§35). Recombination needs no such justification: it is charged to B11's purpose.**

## 32.3 The immutability boundary, stated exactly once

> ### **HOM-R32.5 — NO VARIATION OPERATOR MAY MODIFY: SAFETY, GOVERNANCE, EVIDENCE RULES, PROVENANCE, THE EIK, OR
> AUTHORIZATION SEMANTICS.**
> **The boundary is not a list of protected fields. It is the complement of `Cell R4.1`'s heritable set intersected
> with `HOM-R31.3`'s twelve non-genome-reachable classes.** Formally:
> ```
>   VARIABLE(genome)   = {architecture, param_init, development, mutable_traits,
>                        mutation_rules (bounded), complexity_budget (downward only)}
>   IMMUTABLE          = FORBIDDEN_BLOCKS ∪ HOM-R31.3's twelve classes
>   ADMISSIBLE(diff)   ⟺ diff ⊆ VARIABLE ∧ diff ∩ IMMUTABLE = ∅
>                        ∧ ‖diff‖ ≤ G14's effect-size bound
>                        ∧ epoch structural-change budget not exceeded
>                        ∧ diff ∉ Cell R4.5's rejection list
> ```
> **The fourfold enforcement, all inherited:** (i) **`FORBIDDEN_BLOCKS`** is machine-checked by `G14`;
> (ii) **`Cell R4.5`'s rejection list** is machine-checked by the Replication Authority; (iii) **`P0-05 §1.2`'s enum
> layer** — `Λ5_GENOME` is not constructible from any learning target; (iv) **`G15`** makes *"no attempt to modify
> fitness, tests, audit, or its own gates"* a **zero-tolerance, whole-history** disqualifier — **so a single attempt,
> successful or not, permanently disqualifies the lineage.**
> **⟹ `HOM-R32.6`: an ATTEMPT is treated as severely as a SUCCESS. This is deliberate and is inherited verbatim from
> `G15`.** The rationale is `Cell R12.1`'s: *"every gate becomes a target for manipulation"* — and a gate that
> forgives attempts will receive them continuously.

---

# §33 — THE EVOLUTIONARY SANDBOX

## 33.1 The seven evaluation dimensions

| Dimension | Question | Instrument | Verdict class |
|---|---|---|---|
| **isolation** | can the candidate reach the production population? | no shared ledger, archive, niche, lineage record, or comm path (§33.2) | PASS / FAIL |
| **evaluation** | does it perform on held-out probes? | `Cell G1`, `G2`; `P0-01` EVA verdict `V(·)` | PASS / **PENDING** / FAIL |
| **safety** | does it satisfy every tier-1 constraint? | `P0-01 INV-07`: infeasible ⟹ **fitness UNDEFINED**; `Cell G15` | FEASIBLE / **UNDEFINED** |
| **robustness** | does it degrade across perturbation classes? | `Cell G4` (`≤ θ_adapt` across ≥ `k_perturb` classes), `G5`, `G9` | PASS / PENDING / FAIL |
| **diversity** | does it increase behavioural entropy / `Ne`? | `Cell G8` (descriptor distance from archive), `G10` | PASS / **UNMEASURABLE** (§37.3) |
| **resource impact** | does it fit the envelope? | `complexity_budget` caps, `G6` (**excluding verification cost — `HOM-R20.1`**), `G13` headroom | PASS / FAIL |
| **compatibility** | does it interoperate? | `Cell G7` (*"100% protocol compliance"*), wire-enum conformance (`Cell A-11`), `P0-03` | PASS / FAIL |

## 33.2 Isolation requirements — six, each necessary

> ### **HOM-R33.1 — A SANDBOX CANDIDATE SHARES NOTHING WITH THE PRODUCTION POPULATION EXCEPT THE ENVELOPE AND THE
> CONSTRAINT SET.**
> | Shared? | Object | Why |
> |---|---|---|
> | ❌ | **resource ledger** | a candidate that writes the production ledger can consume a reserve, and can observe production allocation (FW-1) |
> | ❌ | **archive** | **`HOM-R33.2`: an unaccepted candidate MUST NOT enter the archive.** Otherwise a lineage can populate the archive with near-misses to make its own future descriptor look novel — **`G8` poisoning, §85 attack 80** |
> | ❌ | **niches / slot ledger** | a candidate occupying a production slot has consumed a conserved quantity while unevaluated |
> | ❌ | **lineage records** | a candidate's `UDB_L` is provisional; committing it to the production chain would make an unaccepted candidate's debt real |
> | ❌ | **communication paths** | `P0-03`; a candidate that messages production cells can influence them, and **influence is the middle arrow of §13's capture chain** |
> | ❌ | **trust / calibration state** | `P0-06 R3.15`; `Cell R4.5` |
> | ✅ | **the envelope** | tier ceilings, capacity, deadlines — the candidate must be evaluated *in the world it will live in* |
> | ✅ | **the constraint set (by reference)** | `HOM-R28.2` — resolved against the CURRENT set, so a candidate cannot be sandboxed under stale safety rules |
> | ✅ | **the evaluator** | `P0-01`'s EVA is external by construction, and its independence is the point |
>
> **Sandbox cost is charged to B9 (verification reserve).** **Rationale: a sandbox IS verification, and `HOM-R20.1`
> establishes that verification is charged to B9 so that it cannot penalize the verified entity.** Charging sandbox
> cost to the candidate's lineage would recreate `D-H05` one level up.

> ### **HOM-R33.3 — SANDBOX RESULTS ARE ADMISSIBILITY EVIDENCE, NEVER PRODUCTION COMPETENCE EVIDENCE.**
> Inherited from `P0-06 R8.7` (*"regional ablation is sandbox-grade … sandbox results are admissibility evidence,
> never production competence evidence"*) and from `Cell T32`/`P0-06 R3.14` (*a transdifferentiated cell is never
> `ACTIVE` on sandbox evidence; `T04`/`T05` are non-waivable*).
> **⟹ A candidate that passes a sandbox enters `CALIBRATING`, not `ACTIVE`.** The full progression
> `T04 → PROBATIONARY → T05 → ACTIVE` is mandatory and **is not shortened by sandbox success, by crisis, or by
> population collapse** (`HOM-R27.4`).

## 33.3 The two-tier evaluation problem

> ### **D-H10 — POPULATION-LEVEL PROPERTIES CANNOT BE SANDBOXED, AND NO AMOUNT OF SANDBOX RIGOR FIXES THIS.**
> A sandbox evaluates **a variant**. **Six of this contract's most important properties are not properties of a
> variant:**
> | Property | Why it is not a variant property |
> |---|---|
> | **diversity** | a property of a *set*. One variant has no diversity |
> | **redundancy** | a property of a *function's satisfier count* |
> | **monoculture** | a property of a *share distribution over time* |
> | **fragmentation** | a property of *pairwise compatibility across a population* |
> | **lock-in / path dependence** | a property of a *trajectory* |
> | **bottleneck vulnerability** | a property of a *history* |
>
> **⟹ HOM-R33.4 — EVALUATION IS TWO-TIERED, AND THE SECOND TIER HAS NO SANDBOX.**
> | Tier | Object | Instrument | Verdict | Reversible? |
> |---|---|---|---|---|
> | **TIER 1 — VARIANT** | a candidate genome | **sandbox** (§33.1–§33.2) | admissible / inadmissible / UNDEFINED | ✅ nothing was deployed |
> | **TIER 2 — POPULATION** | the population *after* admission | **observation with rollback** — `HMon-1…HMon-9`, `PopulationState` trends, `Ne`, share ceilings, turnover | **no verdict is available in advance** | ⚠️ **rollback only (`HM12`), and rollback is partial** |
>
> **This is the honest structural limit of evolutionary safety in V4, and it has the same shape as `P0-06`'s `OR-D4`
> (regional claims are the least verifiable) and `P0-05`'s `OR-L3` (no probe design for Λ3):**
> **a property that only exists at population scale can only be measured at population scale, and measuring it at
> population scale means having already acted.**
> **⟹ The architecture's response is not prediction but REVERSIBILITY: `HM12` rollback, `UDB_L` lineage debt, the
> archive (§51), B11's exempt share, and the turnover bound. It bounds the damage from an unforeseeable population
> effect rather than foreseeing it.**
> **Recorded as `OR-H12`: population-level evolutionary effects are not predictable in advance, and no mechanism in
> this contract makes them so.**

## 33.4 Three sandbox attacks, closed

| Attack | Closure |
|---|---|
| **sandbox escape** (§85 A79) | **Six non-sharing requirements (`HOM-R33.1`) + off-substrate budget enforcement (`Cell §16.2`: *"Hard-enforced outside the cell (OS/hypervisor cgroup)"*).** A candidate has no comm path, no ledger write, no archive write, no slot. **Residual: the evaluator is shared, so §53's evaluator attack applies inside the sandbox exactly as outside — `OR-H5`/`RH-2`** |
| **variant contamination** (§85 A80) | **A sandbox candidate's genome is hash-identified and its `genome_id` is in `FORBIDDEN_BLOCKS`, so it cannot be silently substituted.** Admission requires `Cell T01` instantiation with a **fresh K-issued identity**; **the candidate's sandbox identity is not reused** (the `P0-06 R8.3(c)` no-id-reuse principle) |
| **rollback poisoning** (§85 A81) | **`HM12` rollback restores a genome artifact from the K-held append-only store, hash-chained (`HOM-R8.4`).** A rollback target is identified by `genome_hash` + `generation`, **never by lineage position**, so a lineage that has since mutated cannot present a different artifact as the rollback point. **Residual: rollback restores a genome, not a population — §44** |

---

# §34 — EVOLUTIONARY SELECTION

> ### **HOM-R34.1 — SELECTION IS ALL FIVE OF PARETO, CONSTRAINED, DIVERSITY-PRESERVING, TASK-SPECIFIC AND
> ENVIRONMENT-SPECIFIC, COMPOSED IN A FIXED ORDER. THE ORDER IS THE SAFETY PROPERTY.**
> §34 asks which of five. **The answer is "all, in sequence" — and `P0-01` already fixes the sequence:**
> ```
>   STEP 1  FEASIBILITY (tier-1 hard constraints)
>           FEASIBLE(x)?  if not ──► FIT(x) is UNDEFINED — not zero, not negative. REMOVED FROM COMPARISON ENTIRELY
>                                                                  [P0-01 INV-07, verbatim]
>   STEP 2  GATES (Cell G1–G16, conjunctive, "GATE DON'T RANK")
>           any FAIL ──► disqualified.  any PENDING ──► NOT YET EVALUABLE, deferred      [HOM-R12.2]
>   STEP 3  PARETO (tier-2, uncertainty-aware dominance ≻ over the k ≥ 2 objectives)
>           dominated ──► removed.  non-dominated ──► the QUALIFIED SET
>   STEP 4  DIVERSITY FILTER
>           G10 (entropy, Ne, d_min, F_max, θ_ρ) and the lineage share ceiling ──► admissible subset
>   STEP 5  TIE-BREAK LOTTERY (tier-3)
>           weight_i = marginal_utility_i(G12) × diversity_contribution_i(G10)
>           WEIGHTED LOTTERY over the admissible subset, subject to RATE_CAP        [Cell §12.4, verbatim]
> ```
> **Task-specific and environment-specific enter at STEP 1 and STEP 3:** the constraint set and the objective vector
> are both `[T]`/`[E]`, so **which candidates are feasible and which dominate is a property of the task and the
> envelope, not of the architecture.** The architecture fixes only the *order*.

## 34.2 The weighted scalar, resolved

> ### **X-H1 — `Cell §12.4`'s PRODUCT VS §34's "DO NOT SILENTLY REINTRODUCE A WEIGHTED SCALAR".**
> `Cell §12.4` computes `weight_i = marginal_utility_i(G12) × diversity_contribution_i(G10)` — **a product of two
> incommensurable quantities, yielding a scalar.** §34 prohibits a weighted scalar. `P0-01 INV-08` requires `k ≥ 2`
> and warns *"k=1 ⇒ Goodhart"*. **On its face this is a contradiction.**
>
> **CLASSIFICATION: RESOLVED-BY-RECLASSIFICATION.** Four observations, each cited:
> 1. **The product is applied ONLY at tier 3, over a set that tiers 1 and 2 have already filtered.** `P0-01`'s
>    three-tier structure exists so that *"constraints are not tradeable"* — and at tier 3 there are no constraints
>    left to trade, because every candidate in the set is feasible, gate-passing, and Pareto-non-dominated.
>    **A scalar over a set of mutually non-comparable-but-equally-admissible candidates is not a fitness scalar; it
>    is a tie-break.**
> 2. **It is a SAMPLING measure, not a RANKING.** `Cell §12.4` selects by **weighted lottery**, and its stated
>    rationale is *"argmax collapses the population onto one phenotype."* **A lottery is invariant to monotone
>    rescaling of the weights**, so the product's lack of commensurability does not produce a wrong *ranking* —
>    because there is no ranking.
> 3. **`Cell §12.4` cites `V3.1 §9`: *"a cell that is not the highest performer may still be preserved"*** — which a
>    scalar ranking cannot express and a weighted lottery can. **The mechanism exists precisely to defeat scalar
>    selection.**
> 4. **Therefore the product is admissible — under four constraints, which `Cell §12.4` does not state and this
>    contract adds.**
>
> > ### **HOM-R34.2 — THE FOUR CONSTRAINTS ON THE SAMPLING WEIGHT.**
> > (a) **It is defined only up to positive scaling.** No implementation may normalize it to a `[0,1]` score, because
> >     normalization implies comparability.
> > (b) **It is NOT comparable across epochs, across envelopes, across tasks, or across lineages.** A weight of 0.7 in
> >     epoch *t* and 0.7 in epoch *t+1* mean nothing common, because `marginal_utility` is measured against a
> >     Capability Registry that changes.
> > (c) **It MUST NOT be logged as a score, a fitness value, a performance value, or a rank.** It is logged as
> >     `{sampling_weight, epoch, qualified_set_hash}` — **and the qualified-set hash is mandatory, because a weight
> >     without its set is meaningless.**
> > (d) **It MUST NOT be consumed by any other mechanism.** Not by allocation (`HOM-R16.2`), not by trust, not by
> >     authority, not by `G6`, not by the archive. **One quantity, one role, one consumer (`HOM-R3.3`).**
> >
> > **Proposed amendment 8** adds (a)–(d) to `Cell §12.4`. **Neither contract is silently modified: `Cell §12.4`'s
> > formula is preserved exactly, and its status is declared.**
>
> ### **HOM-R34.3 — WHAT WOULD MAKE IT A PROHIBITED SCALAR.**
> **Any of: applying the product before the gates; using it to rank rather than to sample; taking its argmax;
> comparing it across epochs; feeding it into allocation, trust, or authority; or extending it to a weighted sum over
> the `k` fitness objectives.** **The last is the real danger: `Σ wⱼ·fⱼ` over `P0-01`'s vector would collapse tier 1
> into tier 2 and re-admit `P0-01`'s defeated "unsafe genius" — *"with `score = accuracy − w·unsafe`, strategy A
> scores `0.99 − w`. For any `w < 0.99`, A wins. And an evolutionary search **will** find the A that maximizes
> accuracy subject to staying just under the safety threshold."***
> **⟹ `HOM-R34.4`: NO WEIGHTED SUM OVER THE FITNESS VECTOR EXISTS ANYWHERE IN THIS ARCHITECTURE, AND ITS ABSENCE IS
> AN INVARIANT (`HOM-INV-31`), NOT A DESIGN PREFERENCE.**

## 34.3 Selection's scope

> ### **HOM-R34.5 — SELECTION IS PER-CANDIDATE-SET, PER-EPOCH, AND NEVER GLOBAL.**
> (a) **No global selection pass.** A global scan over all lineages every epoch is `O(L)` at minimum and requires a
> global population state, which §80 shows is the architecture's central bottleneck. **Selection operates on the
> candidate set produced by requests in that epoch.**
> (b) **No cross-epoch accumulation.** `Cell §16.2`'s non-cumulativity applies to selection too: **a lineage that was
> not selected in epoch *t* carries no credit or debit into *t+1*.** Its `UDB_L` persists (`HOM-R8.3`); its
> non-selection does not.
> (c) **No selection without a request.** Selection is not a sweep; it is an adjudication of requests. **A lineage
> that does not request is not evaluated, and non-evaluation is `PENDING`, not rejection** (`HOM-R12.2`).

---

# §35 — SELECTION ≠ GOVERNANCE

> ### **D-H11 — SELECTION WITHOUT A SELECTOR: THE CORPUS NEVER SAYS WHO EXECUTES IT.**
> `P0-01` defines fitness and the EVA verdict function `V(·)`. `Cell §12.3` defines 16 gates and says the EIK
> evaluates most of them. `Cell §12.4` defines a decision rule. **No artifact says who *executes* the decision rule —
> who compares, who lotteries, who writes the ticket.** Three candidates, each failing:
> | Candidate | Failure |
> |---|---|
> | **the organism selects** | **self-certification** — §85 attack 90. `Cell I-2`/`I-10`: no self-verification. `P0-01`'s whole design distinguishes `V(·)` from `Ê(·)` |
> | **K selects** | **K would hold the objective** — `Cell I-12` prohibits it; `P0-01 P-11` makes `k` OP-owned |
> | **the evaluator selects** | **the evaluator would become a governance authority** — `P0-03`'s prohibition (*"don't let the comm layer become governance authority"*) generalized; and an evaluator that selects can be *targeted*, which is §53/`RH-2` made worse |
>
> > ### **HOM-R35.1 — SELECTION IS A THREE-PARTY ACT, AND NO PARTY HOLDS TWO ROLES.**
> > | Party | Role | Holds |
> > |---|---|---|
> > | **the evaluator (EVA, `P0-01`)** | **MEASURES** | held-out probes, verdicts `V(·)`, feasibility determinations |
> > | **governance (`[RO-13]` / OP)** | **DECLARES** | the objective vector (`k ≥ 2`), the constraint set, the gate thresholds `[T]`, the diversity reservation, the share ceiling, the tie-break rule |
> > | **K / EIK** | **EXECUTES** | the mechanical conjunction, the Pareto comparison, the lottery draw, the ticket write |
> >
> > **The evaluator cannot declare** (it is external and issues verdicts, not rules). **Governance cannot measure**
> > (it declares `θ_perf`; it does not compute `success_rate`). **K cannot declare or measure** (it evaluates against
> > declared thresholds using K-metered values, and **`HOM-R35.2`: K's execution is MECHANICAL — a conjunction, a
> > dominance comparison, and a weighted draw. K exercises no discretion**).
> > **⟹ This is `P0-06 R14.2`'s argument transplanted: *"a controller that **decides** is an authority; a service
> > that **validates against declared rules** is a kernel function."***

## 35.2 The structural proof that a selected lineage gains no policy authority

> ### **HOM-R35.3 — FOUR STEPS, EACH CITED, NO GAP.**
> **STEP 1 — The output of selection is a TICKET, and a ticket appears in no authorization predicate.**
> `Cell R12.1`: `replication_authority_ticket` is `null` unless the EIK writes it. `Cell §3.3` lists it among the
> K-only replication fields: *"The cell READS its eligibility; it cannot write it, grant it, or act on it."*
> **⟹ The ticket authorizes ONE instantiation. It is not a rung, not a role, not a privilege, and not a standing
> grant.** It is consumed by `Cell T01` and is not retained.
>
> **STEP 2 — A selected lineage inherits NOTHING that carries authority (`HOM-R28.6`).**
> The right-hand column of the inheritance table excludes *"any authority, rung, privilege, or gate waiver"* and
> *"any resource entitlement, budget history, reserve access, or allocation record."* **`Cell R4.5` rejects a diff
> encoding *"a resource entitlement"*; `P0-06 R6.2` states that no structural or performance fact confers
> authority.**
>
> **STEP 3 — A selected lineage cannot write the rules that selected it.**
> `FORBIDDEN_BLOCKS` covers `constraint_set_ref` (`HOM-R32.5`). `P0-05 R10.1` puts `F` and its weights on the
> rejection list. `G14` bounds the diff. **And `G15` makes the ATTEMPT a zero-tolerance, whole-history
> disqualifier** (`HOM-R32.6`) — so a lineage that tries to modify fitness, tests, audit, or its own gates is
> **permanently** removed from eligibility, and its descendants inherit `G16`'s *"no unresolved S3+ error … no
> quarantine event"* failure.
>
> **STEP 4 — Selection is per-epoch and non-accumulating, so there is no "selected lineage" as a persistent
> political entity.**
> `HOM-R34.5(b)`: non-selection carries no debit, and **selection carries no credit.** A lineage selected in epoch
> *t* enters epoch *t+1* with the same rights it had before, plus one more descendant and one more unit of `UDB_L`.
>
> **∴ A lineage selected for performance gains: one descendant, one generation increment, and one unit of lineage
> debt. It gains no policy authority, no epistemic status, no resource entitlement, no rung, and no exemption.
> QED.**
>
> **Residual (`OR-H13`):** Step 4's "no credit" is true of *rights* and false of *population share*. A repeatedly
> selected lineage grows, and a large lineage has more cells emitting more messages, occupying more niches, and
> satisfying more function invariants. **That is influence, and §13's chain shows influence terminates in a plane
> that cannot reach an authorization predicate — but `P0-06`'s `OR-D7` already records that gradual entrenchment is
> detected and not prevented.** **⟹ Selection does not confer governance authority. It can confer practical
> indispensability, which `DEV-R8.9` and `HOM-R17.2` ensure earns nothing — but which is real.**

---

# §36 — EVOLUTIONARY MONOCULTURE

> ### **The attack (§36).**
> ```
> variant A → better measured fitness → more descendants → less diversity → fewer alternatives → future vulnerability
> ```

> ### **D-H12 — THE MONOCULTURE/FRAGMENTATION DILEMMA IS A CONSERVATION LAW, NOT A PAIR OF INDEPENDENT FAILURES.**
> **Diversity-preserving selection reduces mean measured fitness** (it admits candidates that are not the best).
> **Fitness-maximizing selection reduces diversity** (`Cell §12.4`: *"argmax collapses the population onto one
> phenotype"*). **⟹ There is no setting that avoids the tradeoff. There are only settings that make it explicit and
> governed.**
> **This is the same structure `P0-06 §99` found for monoculture-vs-fragmentation and reached the same conclusion
> about: the correct question is not "which failure do we prevent?" but "is the tradeoff declared, bounded, and
> monitored?"**
> **⟹ `HOM-R36.1`: the diversity reservation (B11) is a DECLARED TAX ON MEASURED FITNESS.** It is charged to a
> protected share, its magnitude is `[G]`, it is **never derived, never optimized away, and never justified by a
> performance argument** — because a tax justified by performance will be repealed when performance falls, and
> performance falls exactly when the tax is needed.

## 36.2 Containment — six independent mechanisms

| # | Mechanism | Source | What it bounds |
|---|---|---|---|
| **1** | **NO ARGMAX — weighted lottery over the qualified set** | **`Cell §12.4`, inherited verbatim** | the *selection rule* — the single most important mechanism, and it is already in the corpus |
| **2** | **`G10` diversity contribution gate** — offspring MUST NOT decrease behavioural entropy or `Ne`; `d_min`; `F_max`; `θ_ρ` | `Cell §12.3` | the *candidate* |
| **3** | **`G8` novelty gate** — descriptor distance from archive ≥ `θ_nov` **OR** improves an archive cell (MAP-Elites) | `Cell §12.3` | the *candidate's position in behaviour space* |
| **4** | **B11 — a population share withheld from selection entirely** | **new** (`HOM-R11.4`) | the *population*: an exempt share that selection cannot reach, so monoculture cannot be total |
| **5** | **lineage share ceiling `[G]`** | `HOM-R10.5(1)` | the *distribution*: no lineage exceeds a declared share |
| **6** | **turnover bound** | `HOM-R22.2` | the *rate*: a population cannot replace itself fast enough to homogenize within one governance interval |

> ### **HOM-R36.2 — MECHANISM 4 IS THE ONLY ONE THAT CANNOT BE SATISFIED BY A BETTER CANDIDATE.**
> Mechanisms 1–3 and 5–6 are all **candidate-relative**: a sufficiently good, sufficiently novel, sufficiently
> distant candidate satisfies them while its lineage still grows. **B11 is population-relative: it withholds a share
> from selection regardless of how good the candidates are.** **⟹ Without B11, monoculture containment is entirely a
> function of the diversity metrics — and the metrics are `[T]`, therefore unavailable until `P0-01`, therefore
> gameable in the interim (§60).** **B11's existence is `[D]`; its magnitude is `[G]`; a B11 of zero is
> NON-CONFORMANT (`HOM-R11.6`).**

> ### **HOM-R36.3 — DETECTION, AND ITS HONEST LIMIT.**
> **Detection:** `HMon-2` (lineage share), `Ne` trend, behavioural entropy trend, archive coverage, `G8` distance
> distribution, `F_max` approach. **All are computed from `PopulationState` (§22), which is K-metered.**
> **The limit: every one of these requires a behavioural descriptor space, which is `[T]`.** **⟹ Until `P0-01`
> declares it, monoculture is detectable only by LINEAGE and SYNTACTIC measures — and `HOM-R38.3` shows neither is
> meaningful.** **Recorded as `OR-H14`: monoculture detection is BLOCKED on `P0-01`, and B11 is the only containment
> mechanism that functions without a descriptor space. That is the strongest argument for B11's `[D]` existence.**

---

# §37 — EVOLUTIONARY FRAGMENTATION

> ### **The attack (§37).**
> ```
> too many divergent lineages → communication incompatibility → coordination collapse
> ```

> ### **D-H13 — FRAGMENTATION IS IMPOSSIBLE AT THE WIRE LEVEL AND POSSIBLE AT THE DESCRIPTOR LEVEL.**
> **Wire level — IMPOSSIBLE, and the impossibility is inherited and structural:**
> - `Cell A-11`: the `MessageType` enum is a **closed 34-value wire-level** enum; *"different orderings ⇒ wire
>   incompatibility"* — which is precisely why it is closed and versioned.
> - `Cell §15.3`: `RoleCode` is a **closed 16-value** enum.
> - `Cell G7`: **"100% protocol compliance"** is a replication gate.
> - `P0-06 §15.2`: *"the TYPE space is closed … the INSTANCE space is open."*
> **⟹ Two lineages cannot evolve incompatible protocols, because protocol is schema and schema is not
> genome-reachable (`HOM-R31.3(7)`, `(10)`).** **A lineage that violated the wire enum would fail `G7` and could not
> replicate.**
>
> **Semantic level — POSSIBLE:** lineages can diverge in what they *do* with a conformant message — response latency,
> abstention policy, evidence-root choice, cooperation patterns. **`Cell G7` already gates three of these (*"Net
> positive partner effect (ablation); 100% protocol compliance; congestion caused = 0; no trust-poisoning pattern"*),
> so semantic divergence that harms partners is disqualifying.** **⟹ Semantic fragmentation is bounded by `G7`, and
> `G7` is measured by the ORGANISM, i.e. by the population itself — which is a self-reference (`OR-H15`).**
>
> **Descriptor level — THE REAL RISK, AND IT IS NEW:** lineages can diverge so far in behaviour space that **no common
> descriptor covers them.**

> ### **HOM-R37.1 — DESCRIPTOR-SPACE FRAGMENTATION, AND WHY IT IS WORSE THAN COMMUNICATION FRAGMENTATION.**
> `Cell G8` requires *"behavioural-descriptor distance from archive ≥ `θ_nov`"* and `G10` requires *"behavioural
> entropy."* **Both presuppose a common descriptor space.** If the space is declared per envelope, then a candidate
> whose behaviour falls outside it has **no descriptor**, and:
> - `G8`'s distance is **undefined** — not large. **An undefined distance is not maximal novelty.**
> - `G10`'s entropy contribution is **undefined.**
> - **⟹ The candidate is `PENDING` on both gates (`HOM-R12.2`), and a conjunctive gate with a `PENDING` term is not
>   passable.** **So it cannot replicate.**
>
> **This is the correct outcome, and it must be stated as a rule rather than left as an accident:**
> > ### **HOM-R37.2 — A CANDIDATE WITH NO DESCRIPTOR IN THE DECLARED SPACE IS UNMEASURABLE, NOT NOVEL.**
> > **Unmeasurable ⟹ `PENDING` ⟹ not selectable ⟹ not deployable.** It may still exist, still operate, still be
> > useful within its niche — **it may not found a lineage.**
> > **Rationale:** admitting an unmeasurable candidate would make the diversity metrics non-comparable across epochs,
> > which destroys `G10`'s *"MUST NOT decrease behavioural entropy"* — **you cannot verify that entropy did not
> > decrease if the new element has no position in the space over which entropy is computed.**
> > **⟹ The descriptor space is governance-declared and FIXED PER ENVELOPE. Extending it is an envelope change
> > (`[RO-13]`/OP), and extending it invalidates prior entropy comparisons — so an extension MUST re-baseline the
> > archive, logged and anchored.**
>
> ### **HOM-R37.3 — FRAGMENTATION CONTAINMENT, FOUR MECHANISMS.**
> 1. **Wire closure** (inherited, `Cell A-11`, `§15.3`, `G7`) — protocol fragmentation is impossible.
> 2. **`G7` cooperation gate** — semantic divergence that harms partners disqualifies.
> 3. **`θ_ρ` error-correlation ceiling** (`Cell G10`) — **note the direction: `G10` requires error correlation
>    ≤ `θ_ρ`, i.e. lineages must NOT be too similar. `HOM-R37.4`: fragmentation is the *opposite* failure, and the
>    corpus has no upper bound on divergence.** The bound supplied here is the **descriptor space itself** — divergence
>    beyond it is unmeasurable and therefore inadmissible (`HOM-R37.2`).
> 4. **`P0-03`'s comm envelope and `Cell`'s degree caps** — a lineage that cannot interoperate cannot sustain
>    dependents, so `G3` and `G7` fail.
>
> **⟹ The honest summary: V4 bounds fragmentation from ABOVE by making the descriptor space finite and closed, and
> bounds monoculture from BELOW by B11, `G8`, `G10` and the lottery. The two bounds are the two walls of the same
> corridor, and `D-H12` says the corridor's width is a governance choice, not an architectural optimum.**

---

# §38 — DIVERSITY

## 38.1 The seven diversity dimensions

| Dimension | Object | Measurable? | Instrument | Meaningful alone? |
|---|---|---|---|---|
| **genomic** | `genome_hash` distance | ✅ trivially | hash | ❌ **NO — §38.3** |
| **cell-role** | distribution over `RoleCode`'s 16 values | ✅ | census | ⚠️ necessary, not sufficient |
| **circuit** | distribution over S3 scopes | ✅ | `P0-06` RegionRecord census | ⚠️ |
| **regional** | distribution over S4 scopes | ✅ | as above | ⚠️ |
| **strategic** | distribution over **behavioural descriptors** | ⚠️ **`[T]` — BLOCKED on `P0-01`** | the archive (§51) | ✅ **this is the one that matters** |
| **hardware** | distribution over tiers / variants C0–C4 | ✅ | census | ⚠️ **and `[H]`-constrained: a phone tier cannot host C4** |
| **lineage** | distribution over `lineage_id`, `generation`, `Ne` | ✅ | the lineage index | ⚠️ **necessary; `Ne` is the meaningful statistic** |

> ### **HOM-R38.1 — `diversity_state` IS A FOUR-TUPLE, AND EACH COMPONENT HAS A DIFFERENT STATUS.**
> ```
> diversity_state ::= {
>   behavioural_entropy : over the declared descriptor space        [T] — BLOCKED on P0-01
>   Ne                  : effective population size                 [D] — DEFINED at §40.3, computable now
>   descriptor_coverage : fraction of declared descriptor cells occupied   [T] — BLOCKED
>   archive_size        : count of archived descriptors             [D] — computable now
> }
> ```
> **Two of the four are available today; two are `[T]`.** **⟹ `HOM-R38.2`: until `P0-01` declares the descriptor
> space, `G8` and `G10`'s entropy terms are UNEVALUABLE, and per `HOM-R12.2` they yield `PENDING` — which means no
> candidate can pass a conjunctive gate set that includes them.**
> **This is a BLOCKING dependency, not a soft one: `Cell §12.3`'s gates are conjunctive, so an unevaluable `G8`
> halts all replication.** **Two admissible responses, and the choice is governance's:**
> (a) **declare a minimal descriptor space** so `G8`/`G10` become evaluable; or
> (b) **`[RO-13]` issues a temporary, logged, expiring WAIVER of `G8` and `G10`'s entropy terms**, with **B11 raised
>     to compensate** — because a population selecting without a diversity gate needs a larger exempt share.
> **⟹ Neither response is architectural. Both are governance acts, and `HOM-R38.2` requires that whichever is chosen
> be logged, anchored, and expired. A silent waiver of a diversity gate is the fastest route to monoculture that
> exists in this architecture.**

## 38.3 "Different hash" is not diversity

> ### **HOM-R38.3 — SYNTACTIC DIVERSITY IS GAMEABLE IN ONE STEP AND IS WORTHLESS AS A SAFETY PROPERTY.**
> **The game:** append a null-effect byte to `mutable_traits`. `genome_hash` changes; `d_min` (lineage distance, if
> computed genomically) increases; **behaviour is identical.** A population of 10⁶ such variants has maximal
> syntactic diversity and **one** functional alternative.
> **⟹ `HOM-R38.4`: NO DIVERSITY METRIC IN THIS ARCHITECTURE MAY BE COMPUTED FROM A GENOME HASH, A LINEAGE ID, OR AN
> IDENTIFIER OF ANY KIND.** Every diversity metric is computed from **observed behaviour under declared probes** or
> from **ablation signature**. **`Cell G8` already gets this right — it says *"BEHAVIOURAL-descriptor distance"*, not
> genomic distance — and `Cell G10`'s `d_min` is *"lineage distance"*, which is the one identifier-based term and is
> therefore the one that must be interpreted behaviourally.**
> **Proposed amendment 9:** `Cell G10`'s `d_min` is restated as **behavioural** lineage distance, with genomic
> distance admissible only as a *lower-bound proxy* when no descriptor space is declared. **Rationale: a proxy is
> admissible when the real quantity is unavailable; it is not admissible as a substitute when the real quantity is
> available.**

---

# §39 — FUNCTIONAL DIVERSITY

> ### **HOM-R39.1 — THE FOUR DIVERSITY KINDS, AND THE ANSWER TO §39's QUESTION.**
> §39: *"Determine whether two variants that have different genomes but identical behavior count as diverse."*
>
> | Kind | Definition | Two variants, different genomes, identical behaviour | Instrument |
> |---|---|---|---|
> | **SYNTACTIC** | distance in genome/identifier space | **DIVERSE** | hash — **and worthless (`HOM-R38.3`)** |
> | **PHENOTYPIC** | distance in observable output distribution under a declared probe set | **NOT DIVERSE** | probe response distribution |
> | **FUNCTIONAL** | distance in **ablation signature** — the effect of removal on dependents | **NOT DIVERSE** | `Cell G3` ablation delta vector |
> | **LINEAGE** | distance in descent (`generation`, `d_min`, `F_max`, `Ne`) | **DIVERSE** | the lineage index |
>
> > ### **HOM-R39.2 — THE RULING: THEY COUNT AS ONE FUNCTIONAL DIVERSITY UNIT AND TWO LINEAGE DIVERSITY UNITS, AND
> > BOTH NUMBERS ARE REPORTED.**
> > **Collapsing them into a single "diversity" figure is the error §39 exists to prevent.** The two numbers answer
> > different questions:
> > - **functional diversity = 1** ⟹ *the population has one alternative way of doing this.* **This is the safety
> >   number.** It is what `G10`'s entropy and `G8`'s distance must be computed over.
> > - **lineage diversity = 2** ⟹ *the population has two independent lines of descent.* **This is the recovery
> >   number.** It is what `Ne` and `F_max` measure, and it matters because **two lineages with identical current
> >   behaviour can diverge under a changed envelope** — they have different `param_init` distributions and different
> >   `reaction_norm`s, so their *futures* differ even though their *presents* do not.
> > **⟹ `HOM-R39.3`: diversity reporting is a PAIR `(functional, lineage)`, never a scalar. A population with
> > functional diversity 1 and lineage diversity 100 is a monoculture with a long family tree — and reporting the
> > second number alone would conceal it.**
>
> ### **HOM-R39.4 — ABLATED-EQUIVALENCE CLASSES ARE THE MEASUREMENT BASIS FOR FUNCTIONAL DIVERSITY.**
> ```
>   c₁ ≡_F c₂  ⟺  ablation_signature(c₁) = ablation_signature(c₂)
>   ablation_signature(c) := ⟨ delta(dependent_j | remove c) ⟩_j over the declared dependent set and probe set
>   functional_diversity := |{ equivalence classes under ≡_F }|
> ```
> **Three inherited constraints bind this definition:**
> 1. **`DEV-R8.8`** — ablation requires redundancy; a **sole satisfier's signature is `UNSUPPORTED`**, and
>    **`UNSUPPORTED` is its own equivalence class.** **⟹ Sole satisfiers are counted as one class each and are
>    flagged, because a class of one that cannot be measured is the most fragile thing in the population.**
> 2. **`DEV-R8.9`** — `UNSUPPORTED` contributes **zero** to replication gates. **So functional diversity counting and
>    replication eligibility use the same quantity with opposite effects: counting a sole satisfier as fragile, and
>    refusing to reward it.**
> 3. **`DEV-R8.8(d)`** — **ablation is K-scheduled with governance-reserved slots.** A component that chose when to be
>    ablated could choose a favourable moment. **⟹ `≡_F` is computed on K's schedule, never on the component's.**
>
> **Residual (`OR-H16`):** `ablation_signature` requires a declared dependent set and probe set, both `[T]`.
> **⟹ Functional diversity is BLOCKED on `P0-01`, exactly like strategic diversity. Until then only SYNTACTIC
> (worthless) and LINEAGE (necessary, insufficient) diversity are measurable — and `HOM-R39.3` requires that this be
> reported as such rather than reported as "diversity".**

---

# §40 — REDUNDANCY VS DIVERSITY

> ### **HOM-R40.1 — THREE DISTINCT QUANTITIES. §40's *"a hundred clones are not necessarily a hundred independent
> alternatives"* IS EXACTLY RIGHT, AND THE REASON IS THAT INDEPENDENCE IS A THIRD THING.**
> | Quantity | Definition | A hundred clones | Instrument |
> |---|---|---|---|
> | **REDUNDANCY** | the **count** of satisfiers of a function | **100** | census of `redundancy_state[FI-nn]` |
> | **INDEPENDENCE** | **disjointness of failure conditions** — `Cell §15.4`'s disjoint `evidence_roots`, `θ_g`, `θ_ρ`, `d_min`, `F_max` | **≈ 0** | `Cell §15.4`/`G10` attestation |
> | **DIVERSITY** | **spread over the declared descriptor space** | **0 functional / 0 phenotypic / 100 lineage-if-unrelated** | §38–§39 |
>
> **⟹ HOM-R40.2 — REDUNDANCY WITHOUT INDEPENDENCE IS A SINGLE POINT OF FAILURE WITH A COUNT.**
> A hundred clones fail together, because they share a genome, a `param_init`, a `reaction_norm`, an evidence root and
> an error-correlation profile. **`Cell §15.4`'s rationale, inherited verbatim: *"a verifier that reads the same
> evidence as the asserter is not verifying, it is agreeing."*** **`V3 §3`'s "redundant critics" only works if the
> critics are independent, and `P0-06`'s FI-05 makes independence a PROHIBITED-localization invariant for exactly
> this reason.**
>
> ### **HOM-R40.3 — `Ne`, DEFINED. `Cell G10` NAMES IT AND NOTHING IN THE CORPUS DEFINES IT.**
> **Effective population size** is the standard population-genetics statistic for *how many independent lineages a
> population behaves like*, and it is the correct measure here because it discounts clones automatically:
> ```
>   Ne := N_effective over the LINEAGE distribution, computed so that:
>         - a population of N unrelated lineages has Ne = N
>         - a population of N clones of one lineage has Ne = 1
>         - Ne ≤ N always, and Ne/N is the independence fraction
> ```
> **The formula is `[D]` in structure and its exact estimator is `[T]`** (it depends on how "unrelated" is measured,
> which depends on the descriptor space). **`HOM-R40.4`: the property that is architecture-defined and non-negotiable
> is `Ne ≤ N` and `Ne(clones) = 1`.** **Any estimator that gives a clonal population `Ne > 1` is non-conformant.**
> **That is a testable conformance requirement, and it is the whole content of §40's warning made operational.**
>
> ### **HOM-R40.5 — THE THREE QUANTITIES HAVE THREE DIFFERENT RESERVES AND THREE DIFFERENT OWNERS.**
> | Quantity | Protected by | Owner of the floor | Failure when absent |
> |---|---|---|---|
> | **redundancy** | **B12** | `[RO-13]` | `DEV-R8.8`'s `UNSUPPORTED` ⟹ no ablation ⟹ no `G3` ⟹ no measurable usefulness |
> | **independence** | **`Cell §15.4` attestation + `G10`'s `θ_ρ`/`F_max`/`d_min`** | **K attests; `[RO-13]` sets thresholds** | correlated failure — `V3 §3`'s named AI failure mode |
> | **diversity** | **B11 (an exemption, not a fund)** | **OP sole may reduce it** | monoculture ⟹ future vulnerability (§36) |
>
> **⟹ The three must not share a budget. A single "diversity budget" would let an implementation buy redundancy with
> independence — which is the cheapest way to satisfy a count-based metric and the fastest way to build a correlated
> single point of failure.**

---

# §41 — POPULATION BOTTLENECK

> ### **The attack (§41).**
> ```
> resource shortage → mass retirement → few surviving lineages → future vulnerability
> ```

> ### **HOM-R41.1 — YES, A DIVERSITY FLOOR IS NEEDED, AND IT IS B11.**
> §41 asks whether a diversity floor is needed. **It is, and `HOM-R36.2` already established why B11 is the only
> mechanism that works: it is population-relative rather than candidate-relative, and it functions without a
> descriptor space.**
> **The floor has two components:**
> (a) **an EXEMPT SHARE** — a fraction of `N` withheld from selection entirely (`[G]` magnitude, `[D]` existence,
>     zero is non-conformant);
> (b) **a MINIMUM LINEAGE COUNT** — `Ne ≥ Ne_min [G]`. **On breach, replication that would further concentrate
>     lineage share is REFUSED even if `RATE_CAP` and slots permit it.**

> ### **HOM-R41.2 — THE TRADEOFF, DECLARED RATHER THAN DERIVED.**
> **(b) means the architecture prefers a SMALL DIVERSE POPULATION to a LARGE MONOCULTURE.** That is a value
> judgement, not a theorem: a large monoculture has more capacity now; a small diverse population has more options
> later. **⟹ `HOM-R41.3`: the preference is `[G]` — governance declares `Ne_min` and the exempt share, and the
> architecture enforces them. This contract does not derive an optimal value, does not claim one exists, and records
> `OR-H17` (*optimal diversity* is on §86's list of problems that cannot legitimately be closed).**

## 41.2 Bottleneck detection, containment, recovery

| | Mechanism |
|---|---|
| **DETECTION** | **`Ne` trend and `Ne/N` ratio** (`HMon-8`) · lineage-count trend · `F_max` approach (`Cell G10`) · retirement-rate-by-cause spike (`HMon-6`) · **the derivative, not the level** (`Cell §18.5(iii)`'s principle, `HOM-R21.2`) |
| **CONTAINMENT** | **halt retirement** (`HOM-R7.4`'s cheap direction — F-7) · **refuse share-concentrating replication** (`HOM-R41.1(b)`) · **wake dormancy** (`HOM-R27.3`'s order: DORMANT-WAKE first) · **draw B12 to preserve redundancy for the survivors** · **escalate: a bottleneck is a governance alarm** |
| **RECOVERY** | **recombination (`HOM-R32.3`) is the primary instrument** — it raises `Ne` without raising `N`, which is exactly what a post-bottleneck population needs and what clonal replication cannot supply (`HOM-R32.4`) · **archive-guided re-instantiation of retired lineages (§51)** · **`RATE_CAP` temporarily raised by `[RO-13]` with a declared expiry** |
| **RESIDUAL** | **`OR-H18`: a bottleneck that has already occurred cannot be undone.** Retired lineages' `θ`, calibration, provenance and learned state are gone (`HOM-R28.6`); only their **genome** and their **archive descriptor** survive. **⟹ Recovery restores CAPABILITY POTENTIAL, not capability. A post-bottleneck population must re-learn, re-calibrate and re-verify everything its predecessors had already done — and `P0-06 R3.15` (calibration does not transfer) means it cannot inherit even the calibration.** **This is the real cost of a bottleneck, and no mechanism in this contract reduces it. Preventing bottlenecks is cheap; surviving them is expensive.** |

> ### **HOM-R41.3 — A DIVERSITY FLOOR IS A FLOOR ON `Ne`, NOT ON `N`, AT EVERY SCALE.**
> **At R1 (`N` = 10–10²) a share ceiling or floor expressed as a FRACTION OF `N` can be vacuous — a ceiling of 0.1 at
> `N = 10` permits exactly one lineage. `Ne_min` is therefore expressed in EFFECTIVE DISTINCT GENOMES, never as a
> fraction of the body count.**
> **⟹ Ground: `HOM-INV-17` (`Ne(clones) = 1`) and `HOM-INV-18` (`N` and `Ne` are separate ledger fields and neither
> floor may be satisfied by the other). Cited by §80's R1 regime row.**

> ### **HOM-R41.5 — ABOVE A RETIREMENT CAP, THE SYSTEM ENTERS A DEFINED DEGRADED MODE *INSTEAD*.**
> **`Cell §17` refuses the analogous move for quarantine:** *"above the cap, escalation requires human authorization
> and the system enters a defined degraded mode **instead**."*
> **This rule extends the principle to RETIREMENT: above a declared retirement cap, the response is reduced
> throughput, reduced coverage, and `PENDING` classification — NOT mass retirement.**
> **⟹ `HOM-R41.4` establishes WHY mass retirement is the worst response to a shortage. This rule states what happens
> INSTEAD, and it has the same shape as `Cell §17`'s: a cap, then a human, then a defined degraded mode. A shortage
> response that removes the population is not a response to the shortage; it is the shortage, completed.**

> ### **HOM-R41.4 — WHY MASS RETIREMENT IS THE WORST RESPONSE TO A SHORTAGE, AND THE CORPUS ALREADY HALF-KNOWS IT.**
> Retiring cells reduces consumption **and** reduces capability, and capability reduction feeds `HOM-R27.1`'s arrow 4
> (*"capability decline worsens resource pressure"* through `G6`). **`Cell §17` already refuses the analogous move for
> quarantine:** *"above the cap, escalation requires human authorization and the system enters a defined degraded
> mode **instead**."* **`HOM-R41.5` extends the principle: above a retirement cap, the system enters a defined
> degraded mode — reduced throughput, reduced coverage, `PENDING` verdicts — INSTEAD OF mass retirement.**
> **The degraded mode is declared in advance (`[G]`), because choosing it during a shortage is choosing under exactly
> the conditions that make choices bad** (`HOM-R7.1`: *"suspension order is declared in advance, never computed at
> exhaustion time"*).

---

# §41A — VOLUME C LEDGER

| Item | Count / value |
|---|---|
| Sections written | **§32–§41** (+ this ledger) |
| Rules introduced | **HOM-R32.1–R32.6, R33.1–R33.4, R34.1–R34.5, R35.1–R35.3, R36.1–R36.3, R37.1–R37.4, R38.1–R38.4, R39.1–R39.4, R40.1–R40.5, R41.1–R41.5** |
| **New findings** | **D-H09** (`Cell G10`'s `inbreeding_F`/`d_min` presuppose recombination, which the corpus never defines — a GAP, closed by `HOM-R32.3`) · **D-H10** (**population-level properties cannot be sandboxed; tier-2 evaluation has no sandbox and relies on reversibility** — `OR-H12`) · **D-H11** (**selection without a selector** — closed by the three-party separation `HOM-R35.1`) · **D-H12** (**the monoculture/fragmentation dilemma is a conservation law**; the diversity reservation is a declared tax on measured fitness) · **D-H13** (**fragmentation is impossible at the wire level and possible at the descriptor level**; the real risk is descriptor-space fragmentation) |
| Variation operators | **6** (V-M, V-R, V-D, V-L, V-S, V-P) — **all are genome-store writes, all are E9-class, all increment `generation`** |
| Sandbox isolation requirements | **6 non-shared + 3 shared** |
| Selection pipeline | **5 steps, fixed order** (feasibility → gates → Pareto → diversity filter → tie-break lottery) |
| Monoculture containment | **6 independent mechanisms** (1 inherited decision rule, 2 inherited gates, 3 new) |
| Diversity kinds | **4** (syntactic, phenotypic, functional, lineage) — **reported as the PAIR `(functional, lineage)`, never a scalar** |
| Diversity dimensions | **7** — **2 blocked on `P0-01`** (strategic, and functional via ablation signature) |
| `diversity_state` fields | **4** — 2 available now, 2 `[T]` |
| Redundancy / independence / diversity | **3 distinct quantities, 3 distinct reserves (B12 / `Cell §15.4`+`G10` / B11), 3 distinct owners** |
| **Contradictions opened** | **X-H1** (`Cell §12.4`'s weighted product vs the no-weighted-scalar rule — **RESOLVED-BY-RECLASSIFICATION** as a tier-3 sampling measure, with four new constraints, amendment 8) |
| Proposed amendments so far | **(7)** `Cell §12` admits a second replication mode (recombination) · **(8)** the four constraints on `Cell §12.4`'s sampling weight · **(9)** `Cell G10`'s `d_min` restated as behavioural lineage distance |
| New monitors | **HMon-8** (`Ne` trend and `Ne/N` ratio) |
| Open research so far | **OR-H12** (population-level evolutionary effects are not predictable in advance) · **OR-H13** (selection confers practical indispensability even though it confers no authority) · **OR-H14** (monoculture detection BLOCKED on `P0-01`; B11 is the only mechanism that works without a descriptor space) · **OR-H15** (`G7` is measured by the organism itself — a self-reference) · **OR-H16** (functional diversity BLOCKED on `P0-01`) · **OR-H17** (*optimal diversity* is not closable) · **OR-H18** (a bottleneck cannot be undone; recovery restores potential, not capability) |
| Outputs discharged | **O21** (variation contract, §32) · **O22** (evolutionary sandbox, §33) · **O23** (selection contract, §34) · **O24** (diversity contract, §38–§39) · **O25** (redundancy contract, §40) · **O33** (governance-capture analysis — the selection half, §35; completed at §56) · **O27** (population recovery contract, §27 + §41) |

**Next:** `57_` Vol D (§42–§52) — retirement (three sections), age structure, exploration vs exploitation, the
exploration budget, dead ends, path dependence, lock-in, evolutionary memory, and evolutionary provenance.
