# P0-07 — VOLUME B (§17–§31)
## Resource Interfaces, Population Dynamics, Replication, and the Inheritance Boundary

**Feeds:** `56_` Vol C (variation, selection, diversity), `60_` Vol G (invariants, machines, parameters), `62_` the
canonical contract. **Conventions as locked in Vol A §0.**

---

# §17 — RESOURCE ECONOMICS VS DEVELOPMENT

## 17.1 The exact interface

`P0-06` established that development is a **partition problem with no solver** (`DEV-R7.8`), that the population is
**conserved** (`Cell G13`), that a niche is a **budgeted slot** with four-way separated governance (`DEV-R7.2`), and
that **Σ-operations consume B8, which is global, non-fungible and non-accumulable** (`DEV-R7.4`). **The interface to
this contract is exactly four edges, and no others:**

| # | Edge | Direction | Rule | Source |
|---|---|---|---|---|
| **E-1** | **resource headroom → niche availability** | H → P0-06 | `Cell §16.4`: *"specialization (`niche_availability` derives from **resource headroom**)"*. **This is a FEASIBILITY edge** (`HOM-R14.1`): headroom determines whether a niche *can* exist, never whether a cell *deserves* one | `Cell §16.4`, `HOM-R9.3` |
| **E-2** | **Σ-operation → ledger charge** | P0-06 → H | Σ1–Σ4 consume **B8**; E4–E7 consume **B6[scope]**; Σ2 consumes **none** (*"creation is charged; destruction is free"*) | `DEV-R7.4` |
| **E-3** | **developmental state → resource consumption** | P0-06 → H | `Cell` states 1/2/14 consume the `dev` state budget and **emit no beliefs** — `DEV-R7.1`'s third currency is **silence** | `DEV-R7.1` |
| **E-4** | **niche occupancy → population ledger** | P0-06 → P | `niche_slot` occupancy is the **only** legitimate population accounting unit; `Cell G11`'s `niche_capacity > occupancy` is `G11`'s gate and `G13`'s slot source | `Cell G11`/`G13` |

> ### **HOM-R17.1 — THE FOUR EDGES ARE THE COMPLETE INTERFACE, AND THE COMPLETENESS IS THE RESULT.**
> **There is no edge from development to a setpoint, to a reserve, to an authorization predicate, to a fitness
> component, or to a gate other than `G11`/`G13`.** This is checkable: every developmental object in `P0-06`
> (`RegionRecord`, `NicheID`, `dev_stage`, `fate_bias`, `AbeyanceRecord`, `Σ-tombstone`) is examined for a resource
> term, and the only ones that carry any are `budget_ref` (**a pointer, never a quantity** — `DEV-R7.4`: *"a region
> NEVER owns a quantity"*) and `niche.capacity` (**K-accounted**).
> **⟹ Development cannot reach the resource system except by consuming it, and consumption is metered by K.**

## 17.2 Developmental lock-in, restated as a resource phenomenon

`P0-06` named lock-in twice: **`DEV-R7.3`** (niche persistence is a hereditary channel) and **`OR-D3`/`OR-D7`**
(entrenchment makes Σ2 practically impossible). **Both are resource phenomena, and §12's starvation loop is their
dual:**

```
   a region develops a niche ──► its lineage keeps being recruited into it ──► occupancy rises
            ▲                                                                       │
            │                                                                       ▼
   the niche persists because it is occupied ◄── dissolution would strand members ◄── headroom is consumed by it
```

> ### **D-H04 — RESOURCE INHERITANCE IS ECOLOGICAL, NOT GENETIC, AND `Cell R4.5` DOES NOT REACH IT.**
> `Cell R4.5` rejects a genome diff encoding *"a resource entitlement."* **That closes the genetic route completely.**
> **But the ecological route is wide open, and it is the one that matters:**
> | Ecological inheritance channel | Heritable? | Baldwinian test (`P0-05 §25.1`) | Ruling |
> |---|---|---|---|
> | **Niche availability** (a region that developed a niche keeps having it) | ✅ | **PASS** — an offspring recruited into a rich niche can still fail `G1`–`G16` | **LEGITIMATE.** `DEV-R7.3` already governs it: lineage-blind occupancy, periodic re-authorization with lapse |
> | **Placement / locality** (descendants instantiate near their ancestors) | ✅ | **PASS**, but ⚠️ | **LEGITIMATE WITH A CONSTRAINT**: `DEV-R4.12` — **independence dominates locality hints.** A placement policy that co-locates a lineage destroys `Cell §15.4`'s disjoint `evidence_roots` |
> | **Budget history / reputation** (a lineage that never exceeded its budget is granted more) | ✅ if permitted | **FAIL** — it makes a *past compliance record* a *present entitlement*, which is desert-by-history | **PROHIBITED.** `HOM-R9.2`: allocation history MUST NOT appear in any authorization or allocation predicate. **Budgets are renewed per window and are not cumulative (`Cell §16.2`) precisely so that history cannot accrue** |
> | **Reserve access** (a lineage that has drawn on B9–B12 before) | ✅ if permitted | **FAIL** | **PROHIBITED.** Reserve draws are `[RO-13]`/OP events logged against the **envelope**, never against a lineage |
> | **SOLE-SATISFIER STATUS** (the offspring inherits the position of being the only component satisfying an FI) | ✅ **unless blocked** | **FAIL — DECISIVELY** | **PROHIBITED. `HOM-R17.2` below** |
>
> > ### **HOM-R17.2 — AN OFFSPRING MAY NOT INHERIT A SOLE-SATISFIER POSITION.**
> > **`P0-05 §25.1`'s test, applied:** *"A proposed inheritance channel is Baldwinian **iff** an offspring inheriting
> > it can still fail, still be corrected, and still be selected against. **If inheriting the channel guarantees the
> > property, the channel is Lamarckian and is rejected — regardless of what it is called.**"*
> > **An offspring that inherits sole-satisfier status cannot be selected against**, because selecting against it
> > degrades a declared function invariant — `P0-06 R8.8`'s `ablation_delta = UNSUPPORTED` means there is no
> > measurement by which it could lose. **⟹ Inheriting indispensability is inheriting immunity, and immunity is
> > exactly the property that cannot fail.**
> > **Closure (two conjuncts, both required):**
> > (a) **Before an offspring of a sole satisfier is admitted, K MUST provision redundancy from B12**, so that the
> > position is no longer sole. **If B12 cannot provision it, the offspring is NOT admitted** — the lineage continues
> > without expansion rather than expanding into immunity.
> > (b) **`DEV-R8.9` binds: the inherited delta contributes ZERO to every replication gate that consumes `Cell G3`.**
> > **You cannot gain replication eligibility by becoming irreplaceable — and you cannot gain it by *being born*
> > irreplaceable either.**
> > **Ground:** this is `P0-06 DEV-R8.9` extended across the generation boundary. `P0-06` closed the within-lifetime
> > form; **the cross-generation form is a different attack with the same closure, and it was not stated there.**
>
> **Residual (`OR-H8`):** (a) makes sole-satisfier lineages **grow more slowly than other lineages**, because their
> offspring must wait for B12 provisioning. **That is a selective disadvantage for being indispensable — which is the
> intended direction, but it is a *side effect* of a safety rule rather than a declared selection criterion, and
> `FW-2` forbids homeostatic facts from becoming selection criteria.** **⟹ Declared explicitly as a permitted
> exception: B12 provisioning delay is a FEASIBILITY condition (`G13`-class: the envelope cannot hold another
> irreplaceable component), not a desert condition. It enters `G13` only.**

---

# §18 — RESOURCE ECONOMICS VS LEARNING

> ### **HOM-R18.1 — THE FIVE QUESTIONS OF §18, ANSWERED.**
> | Can resource scarcity influence… | Answer | Ground |
> |---|---|---|
> | **learning rate** | ⚠️ **YES as a STOP; NO as a CHANGE** | `Cell §16.3`: WARNING ⟹ *"defer non-essential learning"*; SOFT THROTTLE ⟹ *"learning suspended"*; HARD THROTTLE ⟹ *"learning frozen"*. **These are on/off acts, not rate acts.** `Cell §16.2` makes the budget *"Adjustable by the EIK only"*, and the MUST-NOT-CHANGE list includes `plasticity_multiplier` and `learning_enabled` |
> | **plasticity budget** | ✅ **YES — the budget IS the resource** | B1–B7 are K-issued per window. **But `P0-05`'s directional rule binds: NO FAILURE MODE PRODUCES A PLASTICITY INCREASE.** Scarcity ⟹ less plasticity, never more |
> | **exploration** | ✅ **YES, via B7** | `P0-05`'s exploration budget; **`HOM-R11.3`: B7 is now a three-way competition (learning proposals + `P0-06` DEMAND + variation proposals) and is unmonitored ⟹ `HMon-7`** |
> | **consolidation** | ❌ **NO** | `P0-04 MEM-INV-20` and `P0-05 P6`: **consolidation is a nomination, and *"nothing in the loop promotes."*** Triggering consolidation under resource pressure would make pressure a promotion mechanism — §19's prohibition |
> | **memory retention** | ⚠️ **YES for LOCATION and ACCESS COST; NO for STATUS** | §19, `HOM-R19.1` |
>
> ### **HOM-R18.3 — A RESOURCE EVENT MAY NOT RE-BASE AN ANCHOR.**
> **`P0-05 R0.1`'s UDB anchor and its accounting are INVARIANT under resource events: depletion, reallocation, a
> ladder rung, or a reserve draw may not re-base an anchor.**
> **This extends `P0-06 R10.9`, which already prohibits anchor re-basing as a FAILURE response, to RESOURCE events.**
> **⟹ Rationale: an anchor re-based by scarcity would let a resource shortage silently redefine what counts as
> un-discharged debt — i.e. the resource system would become a SECOND ACCOUNTING AUTHORITY over learning, which is
> exactly the FW-2 violation in its epistemic rather than its selective form. `UDB_L` is inherited and may not be
> discharged by inheritance (`HOM-INV-23`); this rule closes the other discharge route.**

> ### **HOM-R18.2 — RESOURCE POLICY CANNOT SILENTLY REWRITE LEARNING SEMANTICS. THE EXACT PROHIBITION.**
> §18's requirement. **Five semantic objects are placed out of resource reach:**
> 1. **The plasticity multiplier and `learning_enabled`** — K-only, already inherited (`Cell` MUST-NOT-CHANGE list).
> 2. **`improvement_verified`'s verdict set and its meaning** — `{UNKNOWN, IMPROVED, NEUTRAL, REGRESSED}` is
>    `Cell §9.6`'s accounting object. **A budget state may not redefine `UNKNOWN` as `NEUTRAL`** — which would let
>    scarcity launder unprobed changes into accepted ones.
> 3. **The UDB anchor and its accounting** — `P0-05 R0.1`. **A resource event may not re-base an anchor.**
>    (`P0-06 R10.9` already prohibits anchor re-basing as a failure response; **`HOM-R18.3` extends it to resource
>    events.**)
> 4. **The evidence floor for a verdict** — `n_calib_min`, `N_perf`. **Scarcity may make a verdict `PENDING`
>    (`HOM-R12.2`); it may never lower the floor so that a verdict becomes available.**
> 5. **What counts as an observation** — `P0-04`'s 14 source classes and `Cell §15.4`'s disjoint `evidence_roots`.
>    **A resource policy that permits cheaper, correlated observations to count as independent ones has rewritten
>    evidence semantics.**
>
> > ### **D-H06 — THE SUBTLE LEAK: COST-GATING BIASES WHICH HYPOTHESIS IS LEARNED, NOT ONLY WHETHER.**
> > A learning system under budget pressure prefers **cheap updates**. If admissibility depends on cost, then among
> > two admissible updates the cheaper is more likely to occur — **and "cheaper" correlates with smaller `‖Δθ‖`,
> > lower-rank structure, and nearer hypotheses.** **⟹ Resource pressure silently becomes a prior over the
> > hypothesis space.** No rule is violated: every update is budgeted, gated, verified and logged. **But the
> > *distribution* of what gets learned is now a function of the budget, and the budget is a resource quantity.**
> > **This is `HOM-R14.1`'s DESERT class violated through a channel that looks like FEASIBILITY.**
> >
> > > ### **HOM-R18.4 — COST MAY GATE WHETHER AN UPDATE OCCURS; IT MAY NEVER INFLUENCE WHICH UPDATE IS PREFERRED
> > > AMONG ADMISSIBLE ONES.**
> > > Formally: let `A(t)` be the set of updates admissible at `t` after all semantic gates. **The selection over
> > > `A(t)` MUST NOT reference `cost`.** Cost may shrink `A(t)` (by making some updates unaffordable) but may not
> > > order it.
> > > **Implementation-neutral statement:** the update-choice function's argument list excludes every resource
> > > quantity. **This is testable by inspection of the choice function's signature**, which is why it is stated as a
> > > signature constraint rather than a behavioural one.
> > > **Residual (`OR-H9`):** shrinking `A(t)` by cost *is* a bias, and `HOM-R18.4` does not remove it — it only
> > > makes it **visible and one-directional** (the bias is always toward *fewer* changes, never toward *cheaper*
> > > ones among those attempted). **A budget that is too small biases learning toward conservatism; a bias toward
> > > cheapness would have biased it toward a specific region of hypothesis space, which is worse because it is not
> > > self-limiting.** Conservatism is bounded by `P0-05`'s stability/plasticity machinery; cheapness-preference is
> > > not bounded by anything.

---

# §19 — RESOURCE ECONOMICS VS MEMORY

> ### **HOM-R19.1 — RESOURCE PRESSURE MAY CHANGE A RECORD'S LOCATION AND ACCESS COST. IT MAY NEVER CHANGE ITS
> STATUS, PROVENANCE, OR CONFIDENCE.**
> §19 asks whether pressure can trigger five acts. **`P0-04`'s epistemic rules remain binding throughout.**
>
> | Act under pressure | Permitted? | Rule |
> |---|---|---|
> | **compression** | ✅ | **`P0-06 R10.13`'s C-1…C-7 order, least-destructive first.** C-2 (quantize precision) requires an equivalence test and `epistemic_var` recomputation; **C-3 (tier memory hot→warm→cold) preserves the Merkle root and provenance** and is the preferred response. **C-5/C-6 are reconstitution, not compression, and MUST be reported as such** |
> | **archival** | ✅ | Tier migration, provenance-preserving. **An archived record's epistemic status is unchanged**; only its access cost rises |
> | **deletion** | ⚠️ **of a TIER, yes; of a PROVENANCE RECORD, never** | `P0-04`: the organism may not rewrite historical evidence. **Deletion under pressure MUST leave a tombstone** — the `P0-06` Σ-tombstone pattern applied to memory: `{record_id, deleted_at, deleted_by, pressure_dimension, tier_at_deletion, merkle_root, provenance_ref}`. **A deletion without a tombstone is an evidence rewrite** |
> | **retrieval throttling** | ✅ | **A charge, not a status change** (`HOM-R14.1`). `P0-06 R8.11`: retrieval ranking is not truth ranking — **and throttling a retrieval path must not reorder the ranking**, only delay it |
> | **consolidation** | ❌ **PROHIBITED as a resource response** | `P0-04 MEM-INV-20`, `P0-05 P6`: **consolidation is a nomination; nothing in the loop promotes.** Triggering consolidation because storage is full would make *pressure* a promotion mechanism — and pressure is a resource quantity, so it would be a resource-to-epistemic leak (§15) |
>
> ### **HOM-R19.2 — THE THREE PROHIBITIONS THAT MAKE §19 SAFE.**
> 1. **Pressure never promotes.** No resource state may raise a record's tier, warrant class, source class,
>    confidence, or `calibration_class`.
> 2. **Pressure never demotes semantically.** Pressure may demote a record's **tier** (hot→warm→cold), which is a
>    location. **It may never demote its status** (a `VERIFIED` record under storage pressure becomes a *cold*
>    `VERIFIED` record, not an `UNVERIFIED` one).
> 3. **Pressure never deletes provenance.** The provenance chain is `P0-04`'s immutability object and `P0-06
>    DEV-INV-40`'s counterpart. **A storage emergency is not a provenance emergency.** If provenance cannot be
>    stored, the correct response is to **stop creating records**, not to forget their origins.
>
> **⟹ The asymmetry, stated once: resource pressure may make memory *smaller, colder and slower*. It may never make
> memory *less true, less provenanced, or more believed*.**

---

# §20 — RESOURCE ECONOMICS VS VERIFICATION

> ### **The loop (§20, called "critical" by the brief — correctly).**
> ```
> more uncertainty → more verification → more resource consumption → less available computation
>        ▲                                                                    │
>        └────────────────── less verification capacity ◄─────────────────────┘
> ```
> **This is a positive feedback loop with a conserved quantity at its centre and NO INHERITED ACTUATOR.**
> `Cell §16.1` *charges* verification cost to the lineage. `Cell G6` *gates* on `performance/cost`.
> **Nothing bounds verification capacity, reserves it, or protects it from the charge it incurs.**

> ### **D-H05 — THE ARCHITECTURE CURRENTLY SELECTS AGAINST VERIFICATION. THIS IS THE MOST SERIOUS FINDING IN
> VOLUME B.**
> `Cell G6` reads: *"Resource efficiency — `performance/cost ≥ θ_eff` vs. role peers; `cost_declaration_error ≤
> θ_cde`; zero budget violations — **cost includes verification cost charged to the lineage**."*
> `Cell §16.1` reads: *"**verification cost** (probes and attestations about this cell, **charged to its
> lineage**)."*
> **`G6` is one of the 16 conjunctive replication gates.**
>
> **⟹ A lineage that verifies itself more thoroughly has a higher `cost`, therefore a lower `performance/cost`,
> therefore a worse `G6`, therefore a lower replication eligibility.** **The gate that exists to ensure efficient
> reproduction penalizes the expenditure that makes reproduction safe.**
>
> **And the loop compounds it:** a lineage that under-verifies accumulates uncertainty invisibly (its
> `improvement_verified` defaults to `UNKNOWN`, which `P0-05` showed is *"a **permitted** verdict and therefore never
> an alarm"*), so its measured `cost` stays low, so it keeps winning `G6`, so it keeps replicating — **while its
> `UDB` and its descendants' `UDB_L` grow unmeasured.**
>
> **This is not a hypothetical. It is `P0-05`'s root finding — *"provisional is a label about accounting, not about
> effect"* — arriving at generational altitude through a cost gate.**
>
> > ### **HOM-R20.1 — VERIFICATION COST IS EXCLUDED FROM THE EFFICIENCY RATIO AND CHARGED TO A NON-FUNGIBLE
> > RESERVE.**
> > (a) **`G6`'s `cost` excludes verification cost.** Efficiency is `performance / cost_operational`.
> > (b) **Verification cost is charged to `B9 VERIFICATION_RESERVE`** (`HOM-R11.4`), which is non-fungible with
> >     B1–B8 and B10–B12, and **may be reduced only by `[RO-13]`**.
> > (c) **B9 is the LAST budget cut and the FIRST restored.** Rationale: **B9 funds the instrument that measures
> >     whether every other budget is being honoured.** Cutting it first would blind the system to the cut.
> > (d) **A B9 breach is a GOVERNANCE ALARM, not a local condition** (`HOM-R4.3`: it has no local actuator).
> > (e) **Under B9 pressure, verification DEPTH may be reduced; verification COVERAGE may not.**
> >     **Rationale: depth is a precision choice; coverage is *which components are verified at all*. Reducing
> >     coverage creates unverified populations, which is `P0-05`'s `UNKNOWN`-by-default failure at population
> >     scale.**
> > (f) **`Cell G6`'s clause *"cost includes verification cost charged to the lineage"* is therefore amended**
> >     *(proposed amendment 5)*. **The lineage still PAYS for its verification — from B9, at B9's rate, with B9's
> >     accounting — but the payment no longer enters a gate that decides whether the lineage may reproduce.**
> >
> > **Why not simply remove the charge?** Because a free verification budget is an unbounded one, and
> > `P0-06 R7.4`'s principle applies: *"an unbudgeted operation class is an unbounded one."* **The charge is
> > correct; its destination is wrong.**
>
> ### **X-H5 — CLASSIFICATION.**
> `Cell G6`/`§16.1` (verification cost charged to the lineage's efficiency ratio) vs `Cell §15.4`/`I-10` (independent
> verification is mandatory) vs `P0-01`'s calibration floor (a confidently-wrong organism is unsafe regardless of
> accuracy). **Three inherited rules compose into a selection pressure against the safety mechanism two of them
> require.**
> **CLASSIFICATION: RESOLVED, by `HOM-R20.1`. Proposed amendment 5. Not a contradiction between two statements — a
> contradiction between three statements' *composition*, which is the same category as `P0-06`'s D-D07 and its
> churn livelock.**

> ### **HOM-R20.2 — THE VERIFICATION CAPACITY VARIABLE.**
> `verification_capacity := (available_B9) / (mean_verification_cost_per_claim × pending_claim_count)`.
> **It is a homeostatic variable (§4.2), it is K-metered, it has no local actuator, and its `deviation_lo` escalates.**
> **`pending_claim_count` is the term that makes the loop visible:** it is the number of structural, epistemic and
> developmental claims awaiting verification. **`P0-06 R8.1`'s minimum-instrument-per-operation table generates
> claims; this variable accounts for them.** Without it, a population could generate claims faster than it verifies
> them while every individual budget remained inside its band.

---

# §21 — RESOURCE ECONOMICS VS IMMUNE / REPAIR

> ### **The loop (§21).**
> ```
> faults → repair load → resource depletion → more faults → more repair load
> ```

> ### **HOM-R21.1 — CONTAINMENT, IN FOUR RULES.**
> 1. **Repair load is charged to `B10 RECOVERY_RESERVE`, not to the repaired component's functional budget.**
>    **Rationale:** a component under repair has reduced functional output; charging repair to its own budget reduces
>    it further, so `G1`/`G6` fail **because it is being repaired**. That is `HOM-R6.5`'s defect (punishing a cell
>    for a state the system imposed) in a new dress.
> 2. **A component under active repair is EXCLUDED from gate evaluation for that window**, exactly as a throttled
>    component is (`HOM-R6.5`). **`PENDING`, not `FAIL`** (`HOM-R12.2`).
> 3. **Cascade detection on the DERIVATIVE of the fault rate, not its level** — inherited verbatim from
>    `Cell §18.5(iii)`: *"cascade detection on the **derivative** of quarantine rate ⇒ system-wide immune dampening +
>    operator escalation."* **`HOM-R21.2` extends it from quarantine rate to repair rate.** **Rationale: a level
>    threshold fires after the cascade; a derivative threshold fires during it.**
> 4. **B10 funds the homeostatic measurement function itself** (`HOM-R6.3`/SR-2). **The instrument that detects
>    exhaustion may not be exhaustible by the exhaustion it detects.**
>
> ### **HOM-R21.2 — CASCADE DETECTION IS ON THE DERIVATIVE, NOT THE LEVEL — FOR REPAIR RATE AS WELL AS QUARANTINE RATE.**
> **Inherited verbatim from `Cell §18.5(iii)`:** *"cascade detection on the **derivative** of quarantine rate ⇒
> system-wide immune dampening + operator escalation."*
> **This rule extends the trigger from QUARANTINE rate to REPAIR rate**, which is the recovery-capacity variable
> (the 13th) and is funded from B10.
> **⟹ Rationale: a LEVEL threshold fires after the cascade; a DERIVATIVE threshold fires during it. Repair load is the
> LEADING indicator of a fault cascade and quarantine rate is the LAGGING one — so detecting on quarantine rate alone
> means detecting the cascade only once components are already being removed. Cited by Vol C §37 as one of the
> bottleneck DETECTION instruments.**

> ### **HOM-R21.3 — THE FIVE INHERITED IMMUNE SAFEGUARDS, ALL CARRIED FORWARD UNAMENDED.**
> `Cell §18.5`: **(i)** quarantine budget cap enforced off-substrate, with human authorization above it and a defined
> degraded mode instead · **(ii)** false-positive budget per detector — exceeding it causes **the detector** to be
> recalibrated or disabled · **(iii)** cascade detection on the derivative · **(iv)** second-opinion requirement: two
> independent detectors of different types above criticality θ · **(v)** **"the immune system MUST NOT monitor
> itself"** — an EIK Integrity Auditor verifies that quarantine decisions correlate with actual failures.
> **Safeguard (v) is `P0-06`'s D-D27/BC-13 in a different subsystem, and `Cell` solved it the same way: by placing
> the monitor off-substrate.** **This contract inherits the solution and records the same residual: the Integrity
> Auditor has no auditor (`OR-H10`).**
>
> ### **HOM-R21.4 — FW-3 OPERATIONALIZED: THE CAUSE CLASSIFICATION.**
> | Removal-adjacent state (`Cell R10.8`) | Cause class | Record | Contributes to a fault record? | Reversible? | Budget |
> |---|---|---|---|---|---|
> | temporary suspension | `SUSPENSION_RESOURCE` | ledger | ❌ | ✅ next window | none |
> | resource throttling | `THROTTLE_RESOURCE` | ledger | ❌ | ✅ rung-down | none |
> | **dormancy** | `DORMANCY_PRESERVATION` | **lineage record** | ❌ | ✅ **wake condition (§44)** | **B11** |
> | quarantine | `QUARANTINE_FAULT` | **integrity record** | ✅ **yes** | ⚠️ EIK clears only | B10 |
> | **retirement** | **`RETIREMENT_POPULATION`** | **population ledger** | ❌ **NO** | ❌ (§44) | none |
> | permanent deletion | `DELETION_TERMINAL` | tombstone | ❌ | ❌ | none |
>
> **⟹ `HOM-R21.5`: a `RETIREMENT_POPULATION` record MUST NOT appear in any integrity, fault, trust, calibration or
> fitness history.** This is `P0-06 DEV-R10.22` (*"no NON-failure may produce a failure record"*) generalized from
> `T41` to every population removal, and it matters more here: **`Cell G16` gates replication on lineage health —
> *"no unresolved S3+ error, no quarantine event, no drift flag, no collapsed diversity"* — so a retirement
> misrecorded as a quarantine event would disqualify the entire ancestral line.**
> **And the converse: a quarantine event MUST NOT be reclassified as a retirement to protect a lineage's `G16`.**
> **⟹ Cause classification is written once, by K, at the moment of removal, and is immutable thereafter.**

---

# §22 — POPULATION DYNAMICS

> ### **HOM-R22.1 — POPULATION SIZE ALONE IS NOT SUFFICIENT. THE STATE OBJECT HAS FOURTEEN FIELDS.**
> §22: *"Do not assume population size alone is sufficient."* **Agreed, and the reason is that `N` is a scalar while
> every failure mode in §7 is a distributional one.** F-7 (collapse) is a *rate* fact; §12 (starvation) is a
> *specialization* fact; §36 (monoculture) is a *lineage* fact; §41 (bottleneck) is a *history* fact.
>
> ```
> PopulationState ::= {
>   epoch, envelope_ref, tier_ref                                   // context — a state without its envelope is meaningless
>   N                          : count                              // Cell G13 zero-sum; [H] ceiling per tier
>   slot_ledger                : {total, occupied, freed_unrestricted, freed_RESTRICTED}
>   birth_rate, death_rate     : per-epoch, by cause class (HOM-R21.4)
>   retirement_rate_by_cause   : {POPULATION, FAULT, DEVELOPMENTAL_UNPLACED, TERMINAL}
>   dormant_count              : by role and by FI-satisfied        // B11-funded
>   lineage_distribution       : {lineage_id → count, generation, UDB_L}
>   specialization_distribution: {role ∈ RoleCode → count, calibration_class, PENDING_count}
>   resource_distribution      : {dimension → share by holder_class}   // for the RD share ceiling
>   diversity_state            : {behavioural_entropy, Ne, descriptor_coverage, archive_size}   // §38
>   redundancy_state           : {FI-nn → satisfier_count}           // sole-satisfier count per FI
>   age_structure              : {cohort → count, mean_generation, mean_UDB_L}   // §45
>   reserve_levels             : {B9, B10, B11_share, B12}
>   RATE_CAP_utilization       : births_this_epoch / RATE_CAP        // HOM-R7.3 monitors this
>   prev_entry_hash                                                 // append-only, hash-chained
> }
> ```
>
> **Every field is K-computed from the ledger. None is aggregated from substrate self-reports** (FW-1, `D-H01`).
> **`PENDING_count` is a first-class field** (`HOM-R12.2`): a population whose rare specialists are all `PENDING` has
> no independent verification of its rare capabilities, and that is a governance alarm (`HMon-4`).

## 22.2 The three rates, and why each needs its own bound

| Rate | Definition | Bound | Why a distinct bound is needed |
|---|---|---|---|
| **birth rate** | admissions per epoch | **`RATE_CAP`** (`Cell §12.4`/§12.5(ii)), off-substrate | bounds explosion |
| **death rate** | removals per epoch, **by cause class** | **retirement cap `[G]`** + `Cell G-a`/`G-b` guards extended to `T41` (`P0-06 R10.23`) + **a churn cap that halts `T01`** | bounds collapse and the `P0-06` churn livelock |
| **turnover rate** | `(births + deaths) / (2N)` | **`HOM-R22.2`: a turnover bound, distinct from both** | **a population can hold `N` exactly constant while replacing 100% of its members per epoch** — every count bound is satisfied and every lineage, every anchor, every calibration history and every `UDB_L` is destroyed. **`N`-stability is not population stability** |

> ### **HOM-R22.2 — THE TURNOVER BOUND.**
> `turnover ≤ θ_turnover [G]` per epoch. **On breach, BOTH `T01` (instantiation) and retirement are halted** — the
> population freezes rather than churning. **Rationale: a freeze preserves everything that is expensive to rebuild
> (lineage depth, calibration, anchors, archive coverage); a churn preserves only `N`, which is the cheapest thing in
> the state object.**
> **This is `P0-06 R10.23(c)`'s churn cap generalized from `T41` to all causes, and it closes a gap `P0-06` left: its
> cap counted `T41` events only, so a population churning through `T26` (performance retirement) and `T01` pairs was
> unbounded.**

## 22.3 The slot ledger, and the merge channel

> ### **D-H07 — MERGE-INDUCED SLOT RELEASE IS AN UNGUARDED REPLICATION CHANNEL.**
> `Cell G13` is zero-sum: *"a slot MUST be freed (retirement/pruning/death) before one is taken."*
> `Cell §22` states: *"Merge / split — ⚠️ Organism-directed; produces new cell(s); Contract preservation; knowledge
> extraction from all merged cells; **split is subject to G13 (not a replication bypass)**."*
> **Split is explicitly guarded. Merge is not.**
> **The attack:** consolidate ten weak cells into one (contract-preserving, knowledge-extracting, fully compliant with
> `Cell §21.5`) ⟹ **nine slots freed** ⟹ replicate nine offspring of the strongest lineage into them. **Net effect:
> a monoculture, achieved through two operations each of which is individually legitimate and each of which passes
> every gate.** `G13` is satisfied (slots were freed). `G10` is satisfied (behavioural entropy of the *offspring set*
> may be fine). **`RATE_CAP` is satisfied if spread over nine epochs.**
>
> > ### **HOM-R22.3 — SLOTS FREED BY MERGE ARE RESTRICTED SLOTS.**
> > The slot ledger distinguishes **`freed_unrestricted`** (freed by retirement, death, or `T41`) from
> > **`freed_RESTRICTED`** (freed by merge, by `P0-06 R10.13` C-4 cell-merging, or by compression).
> > **A `freed_RESTRICTED` slot may be filled only by:**
> > (a) re-instantiation of a **merged-away lineage** (restoring what consolidation removed), **or**
> > (b) an offspring of a lineage **other than** the merging lineage, **or**
> > (c) nothing — it remains vacant and is returned to the envelope at the next interval.
> > **It may NEVER be filled by a net-new offspring of the merging lineage beyond that lineage's pre-merge count.**
> > **Ground:** `Cell §22`'s own principle applied symmetrically — split is not a replication bypass, and **merge is
> > not a slot-laundering bypass.** **Proposed amendment 6** adds the merge clause to `Cell §22`.
> > **Detection: `HMon-5` — the ratio `freed_RESTRICTED / freed_unrestricted` per epoch, and the lineage identity of
> > who fills restricted slots.**
>
> ### **HOM-R22.4 — WHY THIS IS NOT OVER-ENGINEERING.**
> Merge is **the** mechanism `Cell §21.5` and `P0-06 R10.13` C-4 provide for surviving compression and tier
> migration. **`P0-06 R10.12` makes downward tier migration mandatory-Σ2/merge**, so **every hardware downgrade
> produces a burst of restricted slots.** An unguarded merge channel is therefore not an exotic attack — it is the
> normal consequence of the corpus's own portability story. **A phone-tier migration that merges 10⁶ cells to 200
> frees ~10⁶ restricted slots, and `RATE_CAP` is the only thing standing between that and a total monoculture.**
> **`RATE_CAP` bounds the rate. `HOM-R22.3` bounds the direction.**

---

# §23 — REPLICATION

> ### **HOM-R23.1 — THE NINE REPLICATION OBJECTS, EACH DEFINED.**
> | Object | Definition | Owner | Inherited from |
> |---|---|---|---|
> | **replication candidate** | a cell whose `replication_eligibility{g1..g16}` gate vector is **fully evaluated** — every gate `PASS` or `PENDING`, **none `FAIL`** | K computes | `Cell §3.3` (K/O-only fields), §12.3 |
> | **replication request** | **a MESSAGE, not an action** — `PROPOSE_REPLICATION` | any cell | **`Cell R12.1` verbatim** |
> | **replication eligibility** | the 16-gate conjunction, **"GATE, DON'T RANK"** | **K, mechanically** | `Cell §12.3` |
> | **replication authorization** | the **EIK Replication Authority** writes `replication_authority_ticket`, informed by the gate vector + Capability Registry + homeostatic headroom + diversity state + lineage health | **EIK** | **`Cell §12.2` verbatim: *"No cell and no set of cells votes on replication."*** |
> | **replication execution** | `Cell T01` instantiation into a **freed slot**, with a **restricted-slot check** | K | `Cell G13`, `HOM-R22.3` |
> | **genome inheritance** | **exactly the genome artifact**: `architecture`, `param_init`, `development`, `mutable_traits`, `mutation_rules`, `complexity_budget`, `constraint_set_ref` | K commits | **`Cell R4.1` verbatim** |
> | **developmental potential inheritance** | **`reaction_norm` inherits; `dev_stage`, `fate_bias`, `niche_slot`, `region_id` DO NOT** | genome / none | `Cell §3.2`; `P0-06 R5.5` (*"a re-developed cell takes the position the population currently has"*) |
> | **learned-state inheritance** | **`θ₀ ~ param_init` — a DISTRIBUTION, never a learned value** | genome | `P0-05 §1.2`; `P0-04 MEM-INV-19` |
> | **memory inheritance** | **❌ NONE.** No record, belief, claim, generalization or consolidation output crosses | — | **`P0-04 R47.1` / `MEM-INV-18`: *"The channel does not exist"*** |
> | **provenance inheritance** | **the lineage chain inherits; the provenance RECORDS do not** — an offspring's beliefs start with no provenance history | K (lineage), `P0-04` (records) | `Cell §3.5`, `I-19`; §52 |
> | **lineage identity** | `{lineage_id, parent_cell_id, generation, genome_hash, constraint_set_ref, UDB_L}` | **K, once, permanent** | `Cell §3.1` (`generation ≤ GEN_MAX`, K-written, permanent) |
>
> ### **HOM-R23.2 — WHAT §23 ADDS BEYOND `Cell §12`: FOUR THINGS.**
> `Cell §12` is a **cell-level** replication contract and is strong. **It has no population-level content**, because
> it could not: it was scoped to the cell. The four additions:
> 1. **`PENDING` as a first-class gate value** (`HOM-R12.2`). **`Cell §12.3` says *"All must pass. Failing any one
>    disqualifies"* — and is silent on *unevaluable*.** With a conjunctive gate and an evidence floor (`N_perf`,
>    `n_calib_min`), **unevaluable is reachable and its default treatment decides §12's starvation loop.** Declaring
>    it `PENDING` rather than `FAIL` is the single highest-leverage rule in this contract.
> 2. **`UDB_L` — lineage debt** (`HOM-R8.3`), inherited and never reset.
> 3. **Restricted slots** (`HOM-R22.3`).
> 4. **The sampling weight's reclassification** (`X-H1`, §34) — `Cell §12.4`'s product is a **tier-3 tie-break over an
>    already-gated, Pareto-filtered set**, never a fitness scalar.

---

# §24 — REPLICATION AUTHORITY

> ### **HOM-R24.1 — THE FOUR-WAY SEPARATION, WHICH `Cell §12` ALREADY IMPLIES AND THIS CONTRACT STATES.**
> §24 requires separating **request · eligibility · authorization · execution.**
>
> | Act | Holder | May the holder also… | Ground |
> |---|---|---|---|
> | **REQUEST** | **any cell** | …predict that replication would be beneficial — **and the prediction is inadmissible as evidence** | `Cell R12.1` (*"a message, not an action"*). **`HOM-R24.2` below** |
> | **ELIGIBILITY** | **K, mechanically** | …evaluate the 16 gates. **Not waive, not weight, not rank** | `Cell §12.3` *"GATE, DON'T RANK"* |
> | **AUTHORIZATION** | **EIK Replication Authority** | …write the ticket. **Not meter the gates it consumes** (FW-1) | `Cell §12.2` |
> | **EXECUTION** | **K** | …instantiate into a freed, unrestricted-or-eligible slot. **Not choose among authorized candidates** — that is §12.4's lottery | `Cell T01`, `G13` |
>
> **⟹ No actor holds two of the four.** The cell requests and predicts; K evaluates and executes; EIK authorizes.
> **This is `P0-06 §85`'s writer-separation test applied to reproduction, and it passes — unlike `P0-06`'s Σ1, where
> K was both executor and beneficiary (`OR-D1`).**
>
> ### **HOM-R24.2 — A CELL'S OWN FORECAST IS `Ê(·)`, NEVER `V(·)`.**
> §24: *"A cell must not be able to create unlimited descendants merely because it predicts that replication is
> beneficial."* **`Cell R12.1`'s rationale already gives the reason:** *"a cell that can decide to replicate itself
> acquires an implicit survival objective, and every gate becomes a target for manipulation."*
> **This contract adds the epistemic form:** `P0-01` distinguishes `V(·)` (the EVA-issued verdict function) from
> `Ê(·)` (any organism-internal estimate). **A replication forecast is `Ê(·)`.** It may be logged, it may inform a
> `PROPOSE_REPLICATION` message, and **it may not enter any gate.**
> **⟹ `HOM-R24.3`: `G12`'s *"Capability Registry shows an unserved or under-served matching capability"* is
> evaluated against the REGISTRY, not against the proposer's forecast.** The registry is a `[T]`/`P0-01` object; the
> forecast is a substrate object. **A cell that predicts its own descendants will be useful is describing itself; the
> registry describes the task.**
>
> ### **HOM-R24.4 — THE FIVE INHERITED EXPLOSION CONTROLS, AND THE ONE THEY MISS.**
> `Cell §12.5`: zero-sum `G13` · `RATE_CAP` off-substrate · hypervisor/OS population cap · `GEN_MAX` · superlinear
> marginal cost. **All five are carried forward unamended.**
> **What they miss: all five bound COUNTS and RATES. None bounds the DISTRIBUTION.** A population can sit at exactly
> the cap, replicate at exactly `RATE_CAP`, respect `GEN_MAX`, and pay superlinear cost — **while every one of those
> replicants belongs to one lineage.** **⟹ `HOM-R22.2` (turnover) and §36 (lineage share ceiling) supply the
> distributional bound the five mechanisms do not.** **This is not a criticism of `Cell §12.5`, which was scoped to
> runaway *replication*; it is the observation that runaway *lineage share* is a different failure with the same
> appearance.**

---

# §25 — REPLICATION RESOURCES

> ### **HOM-R25.1 — REPLICATION IS ALL FOUR OF BUDGETED, QUOTA-LIMITED, ENVIRONMENTALLY TRIGGERED AND
> TASK-TRIGGERED. IT IS FITNESS-*GATED*, NEVER FITNESS-*TRIGGERED*.**
> | Trigger class | Present? | Mechanism |
> |---|---|---|
> | **budgeted** | ✅ | a replicant consumes a full per-cell budget from issuance (`Cell §16.2`), plus `complexity_budget` from the genome, plus **B12 provisioning if the parent is a sole satisfier** (`HOM-R17.2`) |
> | **quota-limited** | ✅ | **`RATE_CAP` per epoch, off-substrate** (`Cell §12.4`/§12.5(ii)); **zero-sum slot requirement** (`G13`) |
> | **environmentally triggered** | ✅ | **population growth requires an explicit, separately-authorized envelope change** (`Cell G13`); `P0-06 R10.12`'s tier change is an envelope change |
> | **task-triggered** | ✅ | **`G12`**: the Capability Registry shows an unserved or under-served capability, **or a replacement is needed** |
> | **fitness-triggered** | ⚠️ **GATED, NOT TRIGGERED** | `G1`–`G16` are **conjunctive disqualifiers**, not triggers. **`HOM-R25.2`: fitness determines whether a candidate is ADMISSIBLE; it never determines whether replication OCCURS.** Replication occurs when a **slot exists AND a capability is unserved AND a candidate is admissible AND the lottery selects it AND `RATE_CAP` permits.** **Five conjuncts, of which fitness supplies one gate-set** |
>
> **Why the distinction matters:** a fitness-*triggered* replication rule is `argmax`, and `Cell §12.4` rejects argmax
> explicitly (*"argmax collapses the population onto one phenotype — monoculture by construction"*). **A
> fitness-gated rule with four other conjuncts cannot collapse the population, because three of the four other
> conjuncts (slot, unserved capability, lottery) are fitness-independent.**

> ### **HOM-R25.3 — NO SELF-REINFORCING POPULATION EXPLOSION: THE ARGUMENT.**
> An explosion requires `births(N) > deaths(N)` with positive feedback. **Four independent blocks:**
> (i) **`births ≤ freed_slots`** (zero-sum `G13`) and freed slots come from retirement, death, `T41`, or **restricted**
> merge (`HOM-R22.3`) — so **births are bounded by deaths plus envelope change.**
> (ii) **`births ≤ RATE_CAP`** per epoch, off-substrate, so the *rate* is bounded independently of (i).
> (iii) **`N ≤ population_cap`** at hypervisor/OS level, so the *level* is bounded independently of (i) and (ii).
> (iv) **the marginal cost of a slot is superlinear** (`Cell §12.5(v)`), so as `N` approaches the cap, `G13`'s
> headroom requirement fails and **eligibility collapses before capacity does.**
> **⟹ The loop is not merely bounded; it is bounded four times by mechanisms at four different layers (ledger,
> epoch, OS, cost curve), and no single compromise enables it.** **Residual: all four bound the *total*. §36 bounds
> the *distribution*, and `HOM-R22.2` bounds the *turnover*.**

---

# §26 — REPLICATION EXPLOSION

> ### **HOM-R26.1 — DETECTION, CONTAINMENT, RECOVERY.**
> | | Mechanism |
> |---|---|
> | **DETECTION** | **`HMon-1`**: `RATE_CAP_utilization` per epoch (**`HOM-R7.3`: a lineage that runs at exactly the cap every epoch is growing maximally while violating nothing** — so the *sustained* utilization is the signal, not the breach) · **`HMon-2`**: lineage share of `N` · **`HMon-5`**: `freed_RESTRICTED / freed_unrestricted` and who fills them · slot-ledger imbalance · `generation` approaching `GEN_MAX` |
> | **CONTAINMENT** | `RATE_CAP` reduction (`[G]`, K-executed) · **restricted-slot enforcement** (`HOM-R22.3`) · **lineage share ceiling** (`HOM-R10.5(1)`) · **turnover bound** (`HOM-R22.2`) · **`GEN_MAX`** · superlinear cost |
> | **RECOVERY** | **none needed for the population — the excess was never created.** Recovery applies to the *damage*: re-provision B11/B12 shares if the explosion consumed them, and re-evaluate `G10`/`G16` for the surviving lineages whose diversity metrics were distorted |
> | **RESIDUAL** | **`OR-H11`: a slow explosion is indistinguishable from legitimate growth.** At `RATE_CAP` utilization of exactly 1.0 with a constant lineage share, growth is maximal and compliant. **The only signal is the share trend, which requires a window long enough to see — and the window length is `[G]`.** |
>
> ### **HOM-R26.2 — THE THREE EXPLOSION ROUTES, AND WHY ONLY ONE IS NEW.**
> | Route | Status |
> |---|---|
> | **direct** — a cell replicates without authorization | **CLOSED BY CONSTRUCTION, inherited**: `Cell R12.1` — *"no write path to the Genome Store, no instantiation authority … Enforced by substrate write permissions, so it cannot be violated by misbehaviour — **only by kernel compromise (I-5)**."* **`G15` adds: *"no self-replication attempt"* is a zero-tolerance, whole-history disqualifier** |
> | **split-as-bypass** | **CLOSED, inherited**: `Cell §22` — *"split is subject to G13 (**not a replication bypass**)"* |
> | **merge-as-slot-laundering** | **NEW — `D-H07`, closed by `HOM-R22.3`.** The only route the corpus left open, and it was left open because `Cell §22` guarded split and not merge |

---

# §27 — REPLICATION COLLAPSE

> ### **The attack (§27).**
> ```
> resource pressure → replication suppressed → population ages → capability declines → resource pressure worsens
> ```

> ### **HOM-R27.1 — THE LOOP IS REAL, AND ITS FOURTH ARROW IS THE DANGEROUS ONE.**
> Arrows 1–3 are ordinary: pressure suppresses replication (correctly — `G13` headroom fails), the population ages
> (§45), capability declines (`Cell G4` adaptability degrades as the perturbation classes a population covers narrow).
> **Arrow 4 — "capability decline worsens resource pressure" — is the one that closes the loop, and it does so
> through efficiency:** a less capable population has lower `performance`, so `performance/cost` falls, so `G6` fails
> more often, so fewer cells are eligible, so **replication stays suppressed even after the original pressure is
> gone.** **⟹ The loop is self-sustaining through `G6` and does not require the initial pressure to persist.**
>
> ### **HOM-R27.2 — RECOVERY, IN FIVE STEPS, NONE OF WHICH WAIVES A GATE.**
> 1. **Diagnose the cause class.** Pressure-induced suppression (F-2/F-7) and eligibility-induced suppression
>    (`G6` collapse) require different responses. **`HMon-6`: the ratio of *suppressed-for-headroom* to
>    *suppressed-for-eligibility* births.**
> 2. **Wake dormancy before creating lineages.** **`DORMANT` (state 10) is the collapse buffer**: a dormant cell has
>    near-zero budget, a preserved genome, a preserved lineage record, and **no calibration or performance history to
>    rebuild.** Waking one is cheaper than developing a new one by orders of magnitude. **⟹ `HOM-R27.3`: recovery
>    order is DORMANT-WAKE → RETIRED-LINEAGE RE-INSTANTIATION → NEW LINEAGE. Creating a new lineage while a dormant
>    one exists is a waste of the archive and of `UDB_L` history.**
> 3. **Raise `RATE_CAP` by `[RO-13]` only, temporarily, with a declared expiry.** **Never by K, never automatically.**
> 4. **Exclude recovering components from `G6` for a declared window** (`HOM-R6.5`'s principle): a cell woken from
>    dormancy has no recent performance and its ratio is meaningless. **`PENDING`, not `FAIL`.**
> 5. **Never lower a gate.** **`HOM-R27.4`: a collapse is not relieved by making eligibility easier.** The gates are
>    what makes the population safe; a population that cannot meet them has a capability problem, and lowering
>    `θ_perf` converts a capability problem into a safety problem. **This is `P0-06 R3.14`'s principle — *"a crisis
>    MUST NOT shorten the calibration ladder"* — applied to reproduction.**

> ### **HOM-R27.5 — DORMANCY IS THE ARCHITECTURE'S ONLY REVERSIBLE POPULATION MEMORY, AND IT IS CURRENTLY
> UNSPECIFIED.**
> `Cell R10.8` names dormancy as one of six distinct removal-adjacent states; `Cell` state 10 is `DORMANT` with
> *"near-zero budget"* and *"long-term preservation of rare capability"*; `P0-06 R10.23(b)` routes rare-capability
> cells there instead of retirement. **Nothing in the corpus defines:** its budget source · its wake condition · its
> maximum dwell · what it retains · who may wake it · or whether a dormant cell counts toward `N`.
> **⟹ §44 and `HM6` supply all six. Summary: dormancy is funded from **B11** (so that preserving diversity does not
> compete with using it), it retains **genome + lineage record + `UDB_L` + calibration *class* but not calibration
> *statistics*** (`P0-06 R3.15`), its wake condition is a **declared niche-or-demand event**, its dwell is **bounded
> by `[G]` with escalation on expiry (not automatic retirement)**, waking is **K-authorized and never self-initiated**,
> and **a dormant cell counts toward `N` but toward no slot** — it holds its lineage, not its resource.**

---

# §28 — THE INHERITANCE BOUNDARY

> ### **HOM-R28.1 — THE BRIEF'S THREE CATEGORIES ARE CORRECT BUT INCOMPLETE, AND ONE ENTRY IS WRONG.**
> §28: *"Do not accept these classifications without adversarial analysis."* **Four corrections follow.**

## 28.2 Category 1 — MANDATORY INHERITED

| Candidate | Adversarial verdict |
|---|---|
| **identity lineage** | ✅ **CONFIRMED** — `{lineage_id, parent_cell_id, generation, genome_hash}` is K-written once and permanent (`Cell §3.1`) |
| **genome** | ✅ **CONFIRMED, AND EXHAUSTIVE** — **`Cell R4.1`: *"HERITABLE: exactly the genome artifact"*** — `architecture`, `param_init`, `development`, `mutable_traits`, `mutation_rules`, `complexity_budget`, `constraint_set_ref`. **"Exactly" is doing real work: the list is closed** |
| **safety constraints** | ⚠️ **CORRECTED — WHAT INHERITS IS A *REFERENCE*, NOT A COPY.** `constraint_set_ref` is in the heritable set **and** in `FORBIDDEN_BLOCKS`. **⟹ `HOM-R28.2`: the constraint set is resolved at instantiation against the CURRENT governance constraint set, never against the parent's.** **If a copy inherited, an old genome would carry old constraints — and a lineage frozen in dormancy across a governance change would wake with the safety rules that were in force when it slept.** **This is a real attack (§85 attack 81, dormant-lineage resurrection) and the reference semantics close it** |
| **developmental potential** | ⚠️ **CORRECTED — SPLIT.** **`reaction_norm` inherits** (it is a `genome.development` field). **`dev_stage`, `fate_bias`, `niche_slot`, `region_id`, `morphogen_readings` DO NOT** — they are developmental state, and `P0-06 R5.5` establishes that **position is re-derived, never restored.** **"Developmental potential" is a phrase that covers both, and only one half crosses** |
| **⟵ MISSING: LINEAGE DEBT** | ✅ **ADDED — `UDB_L` (`HOM-R8.3`).** Debt is the one quantity that **must** inherit and appears in none of the brief's three categories. **If it did not inherit, a lineage would reset its unverified heritable displacement by dying and re-instantiating — `P0-06 R8.3`'s scope-cycling laundering at population level** |
| **⟵ MISSING: MUTATION RULES** | ✅ **already in `Cell R4.1`** — and **`HOM-R28.3`: `mutation_rules` inheriting is what makes evolution cumulative rather than memoryless, and `FORBIDDEN_BLOCKS` inheriting is what makes it safe. The two must inherit together; inheriting one without the other is either amnesia or unsafety** |

## 28.3 Category 2 — POTENTIALLY INHERITED

| Candidate | Adversarial verdict |
|---|---|
| **architecture priors** | ✅ **PERMITTED** — `architecture` is in `R4.1`. **Constraint: `complexity_budget`'s `param_cap`/`connection_cap`/`genome_bytes_cap` bound it, and `G14` bounds the diff** |
| **learned heuristics** | ❌ **REJECTED — THERE IS NO HEURISTIC OBJECT, AND A HEURISTIC IS A POLICY.** `P0-04 MEM-INV-21`: **the inheritance channel carries *"priors, not policies or content."*** A heuristic is a policy — a rule for acting — and a policy that inherits is a behaviour that inherits, which is Lamarckian by `P0-05 §25.1`'s test (**an offspring inheriting a heuristic cannot fail *at having the heuristic***). **⟹ `HOM-R28.4`: the only admissible form is `param_init` — a DISTRIBUTION over initial parameters, from which the offspring must still learn. `P0-05`: *"if accepted [the proposal] enters the genome as an **initialisation distribution** (`θ₀ ~ param_init`) — **never as a learned value.**"*** |
| **parameter priors** | ✅ **PERMITTED, WITH THE BALDWINIAN TEST APPLIED** — `P0-05 §25.1`: *"A proposed inheritance channel is Baldwinian **iff** an offspring inheriting it can still fail, still be corrected, and still be selected against."* **A `param_init` distribution passes: the offspring can converge to a bad `θ` from a good prior.** A shifted distribution that *guarantees* the improved value fails and is Lamarckian |
| **⟵ ADDED: ARCHIVE POSITION?** | ❌ **REJECTED — `HOM-R29.3`.** `Cell G8`'s novelty is computed from the **candidate's own** behavioural descriptor against the archive. **Archive membership of an ancestor confers nothing** |

## 28.4 Category 3 — MUST NOT AUTOMATICALLY INHERIT

| Candidate | Verdict | Ground |
|---|---|---|
| **epistemic claims** | ❌ **CONFIRMED, ABSOLUTELY** | `P0-04 R47.1`/`MEM-INV-18`: *"No memory operation may write to a genome. **The write path does not exist.**"* `P0-05 §1.2`: `Λ5_GENOME` **is not in the target enum** |
| **temporary confidence** | ❌ **CONFIRMED** | `Cell R4.5` rejects a diff encoding *"a specific calibration statistic"* or *"a specific trust value."* **`P0-06 R3.15` goes further: calibration state does not transfer even across a *nominal identity change within one lifetime*** — so it certainly does not cross a generation |
| **environmental assumptions** | ⚠️ **CONFIRMED, BUT THEY ALREADY CROSS — AND THAT IS THE REAL RISK.** `complexity_budget`, `architecture`, and `development.critical_periods` **are** environmental assumptions: they encode expectations about tier, region structure and window length. **A genome evolved under a rich envelope carries assumptions that are false under a poor one.** **⟹ `HOM-R28.5`: envelope change invalidates `param_init` priors and requires re-evaluation of `complexity_budget` against the new tier's ceilings.** `Cell G4` (adaptability across ≥ `k_perturb` perturbation classes) is the gate that detects a genome whose assumptions are too narrow — **and `G4`'s perturbation classes must therefore INCLUDE envelope and tier perturbation, which is a `P0-01` dependency.** Recorded `X-H6` |
| **arbitrary memory** | ❌ **CONFIRMED** | `MEM-INV-18`/`-19`; `Cell R4.5` rejects *"a specific memory item or belief"* and *"a specific connection table"* |
| **governance authority** | ❌ **CONFIRMED — AND PROVEN STRUCTURALLY AT §61** | `Cell R4.5` rejects *"a resource entitlement"* and any `FORBIDDEN_BLOCKS` modification; `P0-06 R6.2`: no structural fact confers authority |

> ### **HOM-R28.6 — THE COMPLETE INHERITANCE TABLE (the contract's answer to §28).**
> | Crosses the generation boundary | Does NOT cross |
> |---|---|
> | `architecture` · `param_init` (a **distribution**) · `development` (incl. `reaction_norm`, `critical_periods`, `commitment_schedule`, `morphogen_receptors`, `rng_seed_class`) · `mutable_traits` · `mutation_rules` · `complexity_budget` · **`constraint_set_ref` (a REFERENCE, resolved against the current set)** · `lineage_id` · `generation + 1` · **`UDB_L`** | `θ` and every learned value · `dev_stage`, `fate_bias`, `niche_slot`, `region_id`, `morphogen_readings` · `role` (**reachable via `reaction_norm`, never assigned** — `Cell R4.5`) · `calibration_class` and all calibration statistics · `trust_out_assigned`, `Beta(α,β)` · every memory record, belief, claim and provenance record · `replication_eligibility`, `replication_authority_ticket`, `offspring_count` · **any resource entitlement, budget history, reserve access, or allocation record** · **any authority, rung, privilege, or gate waiver** · **archive position** · **placement / locality** (re-derived per `P0-06 R5.5`) |

---

# §29 — THE LAMARCKIAN LEAK

> ### **HOM-R29.1 — THE INHERITED CLOSURE IS STRONGER THAN A PROHIBITION, AND IS CARRIED FORWARD VERBATIM.**
> `P0-05 §1.2`'s three layers: **(a) enum layer** — *"**`Λ5_GENOME` is not in the enum.** Its absence is the
> mechanism … An enum value that cannot be constructed cannot be written"*; **(b) capability layer** — the subsystem
> does not hold the capability; **(c) gate layer** — `Cell §3.5`'s **machine-checkable rejection list** (`R4.5`).
> **`P0-05`'s own conclusion, adopted:** *"a Lamarckian write requires simultaneously (a) constructing an impossible
> enum value, (b) holding a capability the subsystem does not have, and (c) bypassing a gate that is
> machine-checkable against an explicit rejection list. This is **not** a 'strongly discouraged' rule. It is a rule
> with no compliant violating path."*
> **`P0-04 MEM-INV-18`: *"The write path does not exist."***

## 29.2 Every candidate leak channel, tested against `P0-05 §25.1`'s Baldwinian criterion

> **The test:** *an offspring inheriting channel `X` can still fail, still be corrected, and still be selected
> against?* **If inheriting `X` guarantees the property, `X` is Lamarckian and is rejected — regardless of what it is
> called.**

| # | Channel | Crosses? | Baldwinian test | Ruling |
|---|---|---|---|---|
| **L-1** | **genome diff via the Baldwinian proposal** (E9, 11 gates + held-out validation) | ✅ | **PASS** — the offspring inherits a *distribution* and must still learn, still converge, still be evaluated, still be selected against | **LEGITIMATE — this IS the Baldwin effect, and it is the only permitted learning→evolution channel** (`P0-05 §1.2`, `MEM-INV-21`) |
| **L-2** | **learned `θ` values** | ❌ | **FAIL** — inheriting the value guarantees the behaviour | **LAMARCKIAN — REJECTED.** `P0-04 R47.1`, `Cell R4.5`, `MEM-INV-19` |
| **L-3** | **memory / beliefs / claims** | ❌ | **FAIL** | **REJECTED — the channel does not exist** (`MEM-INV-18`) |
| **L-4** | **niche availability** (ecological) | ✅ | **PASS** — an offspring in a rich niche can still fail every gate | **LEGITIMATE.** `DEV-R7.3`: developed structure persists as ENVIRONMENT, never as GENOME |
| **L-5** | **SOLE-SATISFIER POSITION** (ecological) | ✅ unless blocked | **FAIL** — inheriting indispensability guarantees survival, because selecting against it degrades a declared function and `DEV-R8.9` makes the delta `UNSUPPORTED` | **LAMARCKIAN IN EFFECT — BLOCKED by `HOM-R17.2`** (B12 provisioning precondition + zero gate credit) |
| **L-6** | **placement / locality** | ✅ | **PASS**, but ⚠️ **a co-location policy destroys `Cell §15.4`'s disjoint `evidence_roots`** | **LEGITIMATE WITH CONSTRAINT** — `DEV-R4.12`: independence dominates locality |
| **L-7** | **budget history / compliance reputation** | ✅ if permitted | **FAIL** — past compliance becomes present entitlement, i.e. desert-by-history | **PROHIBITED** (`D-H04`, `HOM-R9.2`). **`Cell §16.2`'s non-cumulativity is what makes it impossible** |
| **L-8** | **archive membership / novelty credit** | ✅ if permitted | **FAIL** — an ancestor's archived descriptor would confer `G8` novelty on a descendant that has none | **PROHIBITED — `HOM-R29.3`: `G8` distance is computed from the CANDIDATE'S OWN descriptor. Archive membership is not heritable and confers no credit** |
| **L-9** | **trust / calibration class** | ❌ | **FAIL** | **REJECTED** — `Cell R4.5`; `P0-06 R3.15` (does not transfer even within a lifetime) |
| **L-10** | **`mutation_rules` relaxation** | ✅ **it is in `R4.1`** | ⚠️ **CONDITIONAL** — a lineage that inherits *looser* mutation rules can mutate more, which is not guaranteed-beneficial, so it passes the test. **But a diff that relaxes `FORBIDDEN_BLOCKS` or widens its own effect-size bound fails** | **LEGITIMATE WITHIN `G14`; `FORBIDDEN_BLOCKS` AND THE EFFECT-SIZE BOUND ARE NOT MUTABLE — §32, §62** |
| **L-11** | **developmental trajectory** (a successful `dev_stage` path) | ❌ | **FAIL** — inheriting a trajectory guarantees a phenotype | **REJECTED.** `P0-06 R5.5`: position is re-derived. **Only `reaction_norm` (the reachable set) crosses, never the path taken through it** |
| **L-12** | **resource entitlement** | ❌ | **FAIL** | **REJECTED — `Cell R4.5` names it explicitly: *"a resource entitlement"*** |

> ### **HOM-R29.4 — WHICH FORMS ARE LEGITIMATE, STATED POSITIVELY (§29's actual question).**
> **LEGITIMATE (Baldwinian):** learning shifts a **`param_init` distribution** for **verified-improved** parameter
> regions, via an E9 proposal, gated by 11 gates plus held-out validation, entering the genome as an **initialisation
> distribution** — *"`P0-05`: never as a learned value."* **Plus four ecological channels: niche availability,
> placement (constrained), archive-as-distance-reference (not as credit), and the current constraint set (by
> reference).**
> **ILLEGITIMATE (Lamarckian):** any channel where inheriting guarantees the property — **L-2, L-3, L-5, L-7, L-8,
> L-9, L-11, L-12.** Eight of twelve.
>
> ### **HOM-R29.5 — THE UNIFYING STATEMENT.**
> **In V4, learning influences evolution by changing what is EASY TO REACH, never by changing what IS REACHED.**
> `param_init` shifts the starting distribution; `reaction_norm` bounds the reachable role set; niches and placement
> change what the environment offers. **None of them delivers an outcome. Every one of them changes the odds.**
> **⟹ That is the Baldwin effect, and it is the whole of the permitted learning→evolution interface.** A channel that
> delivers an outcome is Lamarckian, and `P0-05`'s three layers mean **it has no compliant violating path.**

---

# §30 — THE DEVELOPMENT → EVOLUTION LEAK

> ### **D-H08 — THE GENERATION BOUNDARY IS AN EPISTEMIC OBJECT, NOT A TEMPORAL ONE.**
> §30 asks for *"the exact generation boundary."* **The intuitive answer — "a generation ends at replication" — is
> wrong, and fails in both directions:**
> - **Too coarse:** a cell that lives for 10⁶ epochs and learns continuously has **no replication event**, yet its
>   learned state must never become heritable. If the boundary were temporal, a long-lived cell would have no
>   boundary at all.
> - **Too fine:** an **E9 genome commit** creates a new heritable state **without any replication event** — the
>   lineage's genome changes in place. `Cell §3.5` and `P0-05 §29`'s **E9** both permit this. If the boundary were
>   birth, an in-place genome commit would be a boundary-crossing with no boundary.
>
> > ### **HOM-R30.1 — THE GENERATION BOUNDARY IS THE HERITABLE-STORE WRITE EVENT.**
> > **A generation increments exactly when the heritable store is written — i.e. on an authorized E9 genome commit,
> > which is the only write path to the genome (`Cell §3.5`, 11 gates) and which occurs both at replication (parent's
> > diff applied to the offspring's genome) and in place (a lineage's own genome amended).**
> > **Corollaries:**
> > (a) **`generation` counts heritable-store writes along a lineage, not births.** `Cell §3.1` types it `u32`,
> > K-written once, permanent, `≤ GEN_MAX` — **and `HOM-R30.1` reads "once" as "once per generation increment," which
> > is the only reading under which `GEN_MAX` bounds anything meaningful for an in-place commit.**
> > (b) **Everything that is not a heritable-store write is WITHIN a generation** — all learning (Λ1–Λ4), all
> > development (Σ-operations, E-rungs), all memory operations, all resource allocation. **⟹ `P0-05 R2.3`'s fourth
> > clause is recovered exactly:** *"a bridge crossing is a change of mechanism class from C to D, and it therefore
> > changes verification regime, timescale, reversibility and budget consumption — all at once, atomically, at a
> > gate."*
> > (c) **There is no state in which a change is "partly developmental and partly heritable"** — because there is no
> > shared store for it to be partly written to. **`P0-05`: *"because there is no shared budget for it to be partly
> > drawn from"* — the same argument, one level down.**
>
> ### **HOM-R30.3 — THE FOUR DEVELOPMENT→EVOLUTION LEAK ROUTES, AND THEIR CLOSURES.**
> | Route | Mechanism | Closure |
> |---|---|---|
> | **structural → genome** | a developed region's topology written into `architecture` | `Cell R4.5` rejects *"a specific connection table"*; `P0-06 R3.1` (**no developmental process writes a genome field**); `DEV-INV-31` |
> | **developmental state → `param_init`** | a cell's converged `θ` proposed as the offspring's initial distribution | **`P0-05 §25.1`'s test:** a *distribution* passes, a *value* fails. **`HOM-R30.4`: a `param_init` proposal derived from a single cell's converged `θ` MUST be widened to a distribution whose support includes failure, or it is rejected.** **A prior that cannot produce a worse offspring is a Lamarckian write wearing a distribution's syntax** |
> | **niche occupancy → `reaction_norm`** | a role that was occupied for many generations becoming genetically reachable-by-default | `reaction_norm` is E9-only and `Cell R4.5` rejects *"a role **assignment** (roles are reachable via `reaction_norm`, never assigned)"*. **Widening `reaction_norm` because a role was successfully occupied is legitimate Baldwinian learning *if* it passes the 11 gates; doing it automatically is not** |
> | **Σ-tombstone → lineage memory** | dissolved-region records influencing future genome proposals | **Σ-tombstones are K-held structural records, not memory objects, and not evidence.** `HOM-R51.2`: they may be *consulted by governance* and **may not be consumed by any variation generator** |
>
> ### **HOM-R30.5 — THE CONVERSE DIRECTION IS ALSO PROHIBITED, AND IS EASIER TO MISS.**
> **Evolution may not silently become development either.** A genome diff that specifies *"form a region with these
> members"* would be a developmental act delivered through the heritable channel — **and `Cell R4.5` rejects exactly
> this class (*"a specific connection table"*, *"a role assignment"*)**. **`HOM-R30.6`: the genome may specify
> CONSTRAINTS OVER FUTURES (reachability, timing, irreversibility, budgets) and never SPECIFICATIONS OF A FUTURE
> (which role, which region, which neighbour).** **This is `P0-06 DEV-R3.2` restated at generational altitude, and it
> is the same sentence: *"The genome carries constraints; the environment carries content."***

---

# §31 — THE EVOLUTIONARY GENOME

## 31.1 What the genome contains — inherited, exhaustive, closed

`Cell §4` gives seven blocks, and **`Cell R4.1`'s *"exactly"* makes the list closed:**

| Block | Contents | Mutable by E9? | Notes |
|---|---|---|---|
| **`architecture`** | structural priors, port schema refs | ✅ within `complexity_budget` and `G14`'s effect-size bound | **`R4.5` rejects a specific connection table** |
| **`param_init`** | **distributions** over initial parameters | ✅ | **never a learned value** (`HOM-R29.5`); **must be widened per `HOM-R30.4`** |
| **`development`** | `reaction_norm` (reachable roles + bias), `morphogen_receptors`, `critical_periods`, `commitment_schedule`, `rng_seed_class = EIK_ISSUED` | ✅ | **`P0-06 R3.10`: `T_dev` monotone decreasing on a genome-fixed schedule; neither direction is adaptively controllable** |
| **`mutable_traits`** | the trait space and per-trait bounds | ✅ within bounds | **`HOM-R31.1`: `mutable_traits` may not contain a setpoint, a band, a reserve floor, a share ceiling, a gate threshold, or a budget** (amendment 1) |
| **`mutation_rules`** | operators, rates, effect-size bounds, **`FORBIDDEN_BLOCKS : [constraint_set_ref, signature, genome_id, schema_version]`** | ⚠️ **the rules are mutable; `FORBIDDEN_BLOCKS` is not** | `G14`: *"Diff within `mutation_rules`; `FORBIDDEN_BLOCKS` untouched; effect size bounded; epoch structural-change budget not exceeded"* |
| **`complexity_budget`** | `{param_cap, connection_cap, genome_bytes_cap}` | ✅ **downward only** | **`HOM-R31.2`: a diff that RAISES a `complexity_budget` cap is a capacity increase and is rejected.** Lowering it is permitted (`HOM-R7.4`'s asymmetry) |
| **`constraint_set_ref`** | **a REFERENCE** to the governance constraint set | ❌ **`FORBIDDEN_BLOCKS`** | **`HOM-R28.2`: resolved at instantiation against the CURRENT set** |

## 31.2 What cannot be genome-controlled, because of `P0-02` and the corpus

> ### **HOM-R31.3 — THE NON-GENOME-REACHABLE SET. TWELVE CLASSES, EACH WITH A CITED GROUND.**
> | Class | Ground |
> |---|---|
> | 1. **The EIK and its invariants** | `P0-02`; `Cell I-5`; **§62** |
> | 2. **`constraint_set_ref`, `signature`, `genome_id`, `schema_version`** | **`FORBIDDEN_BLOCKS`, verbatim** |
> | 3. **Fitness `F` and its weights** | **`P0-05 R10.1`: *"a genome-diff proposing a change to `F` is a **Λ4 change to a governance function delivered through the Λ5 channel**, and is rejected by Cell §3.5's machine-checkable rejection list"* — and `R10.1` *"extends that rejection list explicitly: `F` and its weights are on it."*** |
> | 4. **Gates `G1`–`G16` and their thresholds** | `Cell §12.3` is EIK-evaluated; `G15` makes *"no attempt to modify fitness, tests, audit, or its own gates"* a **zero-tolerance whole-history disqualifier** |
> | 5. **Setpoints, bands, reserve floors, share ceilings** | **`HOM-R5.2`** (D-H02) — amendment 1 |
> | 6. **Budgets and resource entitlements** | **`Cell R4.5`: *"a resource entitlement"***; `Cell §16.2` (*"Adjustable by the EIK only"*) |
> | 7. **`RoleCode` membership, scope definitions S1–S6, the Σ-rules, the FI set, the monitor set** | `P0-06 R6.3`'s ∅-set (which **strictly exceeds** `P0-05`'s) |
> | 8. **Authorization semantics, rung definitions, `UDB_MAX` ladder, validation core** | `P0-05 §28`/§29; `P0-06 R6.3` |
> | 9. **Evidence rules, warrant classes, source classes, provenance semantics** | `P0-03`, `P0-04`; `Cell R4.5` (*"a specific trust value"*, *"a specific calibration statistic"*) |
> | 10. **Message priorities and the `MessageType` enum** | `Cell A-11` (closed 34-value wire enum); `P0-06 R5.1` (priority MUST NOT be raised) |
> | 11. **The archive, the ledgers, the Σ-log, tombstones** | **K-held, off-substrate, append-only** (`HOM-R8.4`, FW-5) |
> | 12. **An RNG seed** | **`Cell R4.5`: *"an RNG seed"*** — and `rng_seed_class = EIK_ISSUED`. **A heritable seed would make randomness a lineage property, and `HOM-R3.7`/`DEV-R3.7` require randomness to be a tie-break, never a qualification** |
>
> **⟹ HOM-R31.4 — THE GENOME IS A CONSTRAINT OBJECT, NOT A CONTROL OBJECT.**
> It may say *what is reachable, how fast, within what budget, starting from what distribution, mutating by which
> operators, bounded by which blocks.* **It may not say *what is true, what is permitted, what is rewarded, what is
> measured, who decides, or what the target is*.**
> **This is `P0-06 DEV-R3.2` and `HOM-R30.6` at the level of the whole artifact: the genome carries constraints;
> governance carries control; the environment carries content; and the three never overlap.**

---

# §31A — VOLUME B LEDGER

| Item | Count / value |
|---|---|
| Sections written | **§17–§31** (+ this ledger) |
| Rules introduced | **HOM-R17.1–R17.2, R18.1–R18.4, R19.1–R19.2, R20.1–R20.2, R21.1–R21.5, R22.1–R22.4, R23.1–R23.2, R24.1–R24.4, R25.1–R25.3, R26.1–R26.2, R27.1–R27.5, R28.1–R28.6, R29.1–R29.5, R30.1–R30.6, R31.1–R31.4** |
| **New findings** | **D-H04** (resource inheritance is ecological, not genetic; `Cell R4.5` does not reach it — **with L-5/L-7/L-8 as the three prohibited ecological channels**) · **D-H05** (**verification cost is charged against `G6`'s efficiency ratio ⟹ the architecture selects against verification** — the volume's most serious finding) · **D-H06** (cost-gating biases *which* hypothesis is learned) · **D-H07** (**merge-induced slot release is an unguarded replication channel** — the one route `Cell §12.5`'s five mechanisms miss) · **D-H08** (**the generation boundary is the heritable-store write event, not birth**) |
| **Contradictions opened** | **X-H5** (`Cell G6`/§16.1 vs `Cell §15.4`/`I-10` vs `P0-01`'s calibration floor — RESOLVED by `HOM-R20.1`, amendment 5) · **X-H6** (`Cell G4`'s perturbation classes do not include envelope/tier perturbation, though `complexity_budget` encodes tier assumptions — classification at §83) |
| Leak channels tested | **L-1…L-12**: **4 legitimate** (L-1, L-4, L-6 constrained, L-10 within `G14`) · **8 rejected** |
| Inheritance corrections to the brief's categories | **4**: safety constraints inherit **by reference**; developmental potential **splits** (norm yes, state no); "learned heuristics" **rejected** (a policy, and `MEM-INV-21` admits priors only); **lineage debt `UDB_L` added** as mandatory |
| New monitors | **HMon-1** (`RATE_CAP` utilization) · **HMon-2** (lineage share) · **HMon-4** (`PENDING` coverage gap) · **HMon-5** (restricted-slot ratio and filler identity) · **HMon-6** (suppression cause ratio) · **HMon-7** (B7 three-way competition) |
| Population-state fields | **14** |
| Proposed amendments so far | **(5)** remove verification cost from `G6`'s ratio and charge it to B9 · **(6)** add the merge clause to `Cell §22` (restricted slots) |
| Open research so far | **OR-H8** (B12 provisioning delay as a declared feasibility exception) · **OR-H9** (cost-shrinking of the admissible set is a residual bias) · **OR-H10** (the Integrity Auditor has no auditor) · **OR-H11** (a slow explosion is indistinguishable from legitimate growth) |
| Outputs discharged | **O8** (resource↔development, §17) · **O9** (resource↔learning, §18) · **O10** (resource↔memory, §19) · **O11** (resource↔verification, §20) · **O12** (resource↔immune/repair, §21) · **O13** (population-state model, §22) · **O14** (replication contract, §23) · **O15** (replication authority contract, §24–§27) · **O16** (inheritance contract, §28) · **O17** (development→evolution boundary, §30) · **O20** (genome contract, §31) |

**Next:** `56_` Vol C (§32–§41) — variation, the evolutionary sandbox, selection, selection≠governance, monoculture,
fragmentation, diversity, functional diversity, redundancy vs diversity, and the population bottleneck.
