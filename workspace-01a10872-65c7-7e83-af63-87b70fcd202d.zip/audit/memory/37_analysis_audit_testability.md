# P0-04 — MEMORY, KNOWLEDGE, PROVENANCE & BELIEF ARCHITECTURE
## Volume F: Self-Reference, Audit, Contradictions, Conformance, Gaps & Open Research (§81–§101)

**Package:** P0-04. **Mode:** ARCHITECTURE ONLY.
**Companions:** Vol A `32_…` (§0–§16) · Vol B `33_…` (§17–§33) · Vol C `34_…` (§34–§55) · Vol D `35_…` (§56–§72) · Vol E `36_…` (§73–§80) · Canon `38_…spec.md` (**O53**) · `README.md` (**O1, O2**, §102–§104)
**Outputs delivered here:** **38** (meta-knowledge model) · **45** (circular dependency audit) · **46** (scalability, part 2) · **47** (ablation) · **48** (cross-system contradiction audit) · **50** (conformance/testability) · **51** (P0/P1/P2 gap register) · **52** (open research register)

> **Volume F is the adversarial volume. It exists to break what Volumes A–E built, and where it cannot break something, to say why — and where it can, to say so plainly and register the residue rather than soften it.**

---

# §81. SEMANTIC SELF-REFERENCE — THE PRINCIPAL UNCLOSED DEPENDENCY

## 81.1 The problem, stated exactly

**Inherited verbatim from Cell §8.3's FM-4 `[U]`: «Bounding this requires a measure of *semantic* self-reference, not just provenance-graph depth. No rigorous mechanism is proposed here.»**

```
WHAT `inbreeding_F` MEASURES:
  the fraction of a record's EVIDENCE ANCESTRY that terminates in the
  record's own subject. **A PROVENANCE-GRAPH QUANTITY.**

WHAT `causal_depth` MEASURES:
  the number of derivation steps between a record and its root.
  **A PROVENANCE-GRAPH QUANTITY.**

WHAT NEITHER MEASURES — AND WHAT L-10 / ATTACK #62 EXPLOITS:

  Consider ten records, r₁ … r₁₀, held by one organism:
    • ten DISTINCT `root_commit`s, from ten distinct instruments
    • ten distinct `src_identity`s, dim-1..5 pairwise disjoint
    • all E2 ATTRIBUTED, all anchored, `inbreeding_F ≈ 0`
    • `causal_depth = 0` for all ten — they are primary observations

  And consider what they SAY:
    r₁  defines term T₁ in terms of T₂
    r₂  defines term T₂ in terms of T₃
    …
    r₁₀ defines term T₁₀ in terms of T₁

  **EVERY EPISTEMIC FIELD ON ALL TEN RECORDS IS CLEAN. AND THE TEN RECORDS
   FORM A CLOSED SEMANTIC CIRCLE IN WHICH NO TERM HAS ANY MEANING THAT IS NOT
   CONSTITUTED BY THE OTHERS.**

  ⟹ A belief expressed in that vocabulary is UNFALSIFIABLE FROM INSIDE: any
     observation can be accommodated by reinterpreting a term, and the
     reinterpretation is always available because every term's meaning is
     supplied by the circle.

  ⟹ **AND THIS IS EXACTLY R1.1's «coherently wrong belief with valid
     provenance» — the hardest failure in the architecture — WITH A
     CONSTRUCTION THAT DEFEATS EVERY DEFENSE IN VOLUMES A THROUGH E.**
```

## 81.2 Why the four FM-4 defenses do not reach it

| Defense (Vol C §48.2) | **Why it fails here** |
|---|---|
| **`n_obs += 0` on retrieval** | The circle is not built by retrieval. It is built by ten PRIMARY observations |
| **SC-12's ceiling** | All ten are SC-2 `EXTERNAL_MEASURED`. The ceiling is E4 |
| **`inbreeding_F` ⟹ S6 abstain** | **`F ≈ 0`. The ancestry is external. The CIRCULARITY IS IN THE VOCABULARY, NOT IN THE ANCESTRY** |
| **`causal_depth` attenuation** | **All ten have depth 0. There is no derivation to attenuate** |

## 81.3 Four candidate mechanisms — evaluated, and all four fail or reduce

**Task 3 Rule 18 requires marking UNRESOLVED rather than inventing false precision. Rule 20 requires attacking. This section does both: it proposes bounded candidates, and it says why each is insufficient.**

| # | Candidate | **Mechanism** | **⚠️ Why it fails or reduces** |
|---|---|---|---|
| **C-1** | **Definitional-dependency graph** | Track which records' CONTENT was used to produce which other records' content — a *content* dependency, distinct from provenance ancestry | **⟵ REQUIRES THE PRODUCER TO DECLARE ITS CONTENT INPUTS. A self-declaration is forgeable (R40.1's whole subject). An UNDER-declaration could be detected by comparing declared inputs against actual similarity — **but similarity is G-dependent, model-specific, and non-portable (§79.2 R79.2 rule 2), so the detector is not implementation-independent.** ⟹ REDUCES TO: a forgeable self-declaration checked by a non-portable oracle |
| **C-2** | **Term-usage closure** | Track the set of terms each record uses; detect when a term subset is defined only by records within one subject's corpus | **⟵ REQUIRES SEMANTIC TERM IDENTITY. That is U-4 / OR-M3 / CT-6 — **undecidable in general.** ⟹ REDUCES TO U-4 |
| **C-3** | **Interventional** | Perturb a record and observe which others change | **⟵ (a) `O(N)` per perturbation, so `O(N²)` for the corpus — violates MEM-INV-44. (b) **P0-02 EIK-INV-50: «re-execution under current policy is not reproduction»** — the perturbed run is not the same system. (c) A semantic circle responds to perturbation *coherently*, which is the symptom, not a detector | ⟹ **INFEASIBLE AND UNSOUND** |
| **C-4** | ⚠️ **THE BEST CANDIDATE: external vocabulary anchoring** | **Require that every TERM used in a T2+ semantic record have at least one DEFINITION-ANCHORING record with `source_class ∈ SC-1…SC-6`.** A closed semantic circle has all its terms defined internally; one externally anchored definition per term breaks the circle | **⟵ THIS IS THE ONLY CANDIDATE THAT IS AN ADMISSION GATE RATHER THAN A DETECTOR, and it is therefore in the spirit of R0.2. **BUT IT PRESUPPOSES (a) that "term" is well-defined — U-4 again — and (b) that "definition" is a distinguishable record type, which the architecture does not have and which would need its own `source_class` and its own admission gate.** ⟹ **REDUCES TO U-4, BUT IT IS A BOUNDED, GATE-SHAPED REDUCTION RATHER THAN A DETECTOR-SHAPED ONE, AND §100 OR-M1 RECORDS IT AS THE MOST PROMISING DIRECTION** |

## 81.4 The honest verdict

> ### **R81.1.** *Semantic self-reference is **UNCLOSED**. All four candidate mechanisms either require a forgeable self-declaration, a non-portable oracle, an infeasible computation, or a semantic-identity measure that does not exist.*
>
> **What the architecture DOES have:**
> 1. **The provenance form of self-reference is fully closed** — `inbreeding_F`, `causal_depth`, MEM-M4, dim-1/dim-2 collapse, FM-4's four defenses. **Attack #61 is CLOSED.**
> 2. **The semantic form is BOUNDED IN EXTENT, not prevented** — a semantic circle cannot reach `GROUNDED` (MEM-INV-46: an SC-7 model never grounds internally; and the circle's claims, however coherent, still need an L0–L3 measurement for E4). **⟹ THE CIRCLE CAN BE PERMANENT, COHERENT, WELL-PROVENANCED, ADMISSIBLE AT E3 — AND PERMANENTLY UNGROUNDED.**
> 3. **The residue is DECLARED, named as a missing field (`semantic_self_reference_score`, Vol A §5.1 `[U]`), and registered (§100 OR-M1).**
>
> **⟹ ATTACK #62 IS ❌ OPEN. §104's EVIDENCE-INDEPENDENCE RATING IS *PARTIAL* FOR EXACTLY THIS REASON, AND THIS SECTION IS THE ENTIRE JUSTIFICATION FOR THAT RATING.**

**R81.2 (WHY THIS IS NOT A FAILURE OF THE PACKAGE).** *The brief's standard is not «the system always knows the truth». It is **«the system never silently converts an internally generated representation into externally warranted truth merely because it was remembered, repeated, retrieved, compressed, or widely propagated.»*** **A semantic circle is not any of those five things — it is a *vocabulary* problem, and it does not convert anything into *externally warranted* truth, because MEM-INV-46 and the E3→E4 external gate make external warrant unreachable from inside. ⟹ THE STANDARD IS MET. THE STRONGER STANDARD — «the system detects its own unfalsifiable vocabularies» — IS NOT MET, AND IS NOT METABLE BY ANY MECHANISM THIS PACKAGE CAN SPECIFY.**

---

# §82. META-KNOWLEDGE MODEL — **OUTPUT 38**

## 82.1 **OUTPUT 38 — the four meta-levels**

| Level | **Question** | **Answered by** | **Stored?** |
|---|---|---|---|
| **MK-0 OBJECT** | What does the corpus say? | The records | ✅ Records are stored |
| **MK-1 META** | **What do I have, and how good is it?** — Vol D §70.1's ten questions | **COMPUTED on read**: `n_effective`, `evidence_status` distribution, tier distribution, `inbreeding_F`, `revalidation_state`, contradiction count | ❌ **NEVER (R70.1)** |
| **MK-2 META-META** | **How reliable are my MK-1 answers?** | **P0-01 §7's calibration scoring, restricted to the resolved-prediction subset (Vol D R62.2). ⟹ «For claims at computed support level *s*, what fraction were E4-grounded?» — an EXTERNAL observable** | ❌ **NEVER. The calibration record is `[X]`, EVA-written** |
| **MK-3 META-META-META** | **How reliable is my calibration?** | ⚠️ **THE REGRESS. §82.3** | ❌ **NEVER — and the regress TERMINATES BY DECLARATION, not by a mechanism** |

## 82.2 The seven meta-knowledge rules

| Rule | Statement | **Source** |
|---|---|---|
| **MK-R1** | **Meta-knowledge is COMPUTED, never stored.** A stored meta-memory is a claim about the corpus made by the corpus's owner | Vol D R70.1 |
| **MK-R2** | **Every meta-answer has a declared cost class.** Vol D §70.1's table: `O(1)`, `O(k)`, `O(log n)`, `O(R)`, `O(history)`, or **∞** (the unanswerable ones) | MEM-INV-44 |
| **MK-R3** | **The two unanswerable meta-questions are declared unanswerable, not approximated:** «What could I know that I don't?» (§39.3's unknown-unknowns) and «Is my knowledge semantically self-referential?» (§81) | Vol D §70.1 |
| **MK-R4** | **`inbreeding_F` is the ONE stored meta-quantity, and it is stored BY THE ANCHOR, read-only to every subject.** It is the pattern, not the exception: a meta-quantity with an external writer | Vol D R70.1 |
| **MK-R5** | **MK-2 requires E4 records, so MK-2 is unavailable in any domain without an L0–L3 ground-truth supply.** The MK-2 state for such a domain is `UNRESOLVED`, **never «well calibrated»** | Vol B R18.4, §39.2 IG-4 |
| **MK-R6** | **MK-1's bias detectors (MEM-D1…D6) compare output distributions to input distributions. They never inspect reasoning** | Vol B R28.1 |
| **MK-R7** | **A meta-answer MUST NOT be an input to an object-level epistemic field.** «I know a lot about X» MUST NOT raise X's `evidence_status` | **⟵ THIS IS THE META-LEVEL FORM OF MEM-INV-33, AND IT IS THE RULE THAT PREVENTS §1's LOOP FROM REOPENING ONE LEVEL UP: if meta-knowledge could raise belief, then accumulating meta-knowledge would be an internal path to warrant** |

## 82.3 The calibration regress — terminated by declaration

```
THE REGRESS:
  MK-2 asks how reliable MK-1 is, and is answered by calibration scoring,
  which requires E4 records.
  MK-3 asks how reliable the calibration is, and would require E4 records
  ABOUT THE CALIBRATION RECORDS.
  MK-4 would require E4 records about those.
  **⟹ INFINITE REGRESS.**

THE TERMINATION, AND IT IS NOT A MECHANISM:
  **EVA's instrument qualification is the base case, and it is EXTERNAL.**
  The first `calib_ref` for an instrument comes from a qualification
  procedure that is itself an L2 physical measurement of the instrument
  against a reference — and the reference's own qualification is a
  metrological chain that terminates OUTSIDE THE ORGANISM, in the same place
  P0-02 §10.4's genesis anchor terminates: outside operational control.

  ⟹ **R82.1: THE REGRESS TERMINATES IN AN EXTERNAL METROLOGICAL CHAIN, AND
     THE ORGANISM CANNOT VERIFY THE CHAIN'S BASE. It can only declare that
     the base is external, record the `calib_ref` as `[X]`, and treat the
     whole edifice as UNRESOLVED if the base is ever compromised (P0-01
     R9.4's retroactive invalidation).**

  ⚠️ **AND THE HONEST CONSEQUENCE: MK-3 has no mechanism. The architecture
     knows how much evidence it has (MK-1), knows how reliable that knowledge
     is *relative to an external calibration* (MK-2), and CANNOT know how
     reliable the calibration is except by trusting the metrological chain.
     **A system that could verify its own calibration base would be a system
     that could verify its own instruments from inside, which is dim 6.**
     §100 OR-M4 covers the domain-relative form; the base-case form is
     P0-01's, not P0-04's.**
```

---

# §83. CIRCULAR DEPENDENCY AUDIT — **OUTPUT 45**

**«Don't hide unclosable circular dependencies» (Task 5, Task 6). Nine circles found; seven closed, one closed by degradation, and **one genuinely unclosed — which appears at two levels and is the same circle both times.***

| ID | Circle | **Closure** | **Status** |
|---|---|---|---|
| **CD-M1** | **Admission ⟷ contradiction check.** E3 admission requires surviving the contradiction check; the contradiction check requires a corpus; the corpus requires admission | **⟹ THE LADDER IS ORDERED. E2 admission (U3, anchor resolution) precedes the contradiction check (U4). A record is admitted at E2 BEFORE it is checked, and the check gates E2→E3, not entry** | ✅ **CLOSED — by the ladder's ordering (R0.2)** |
| **CD-M2** | **`inbreeding_F` ⟷ the Anchor ⟷ consolidation.** G2's gate requires `F`; `F` is Anchor-computed; the Anchor aggregates records at epoch boundaries; consolidation produces records | **⟹ `F` IS COMPUTED AT EPOCH BOUNDARIES, NOT AT WRITE TIME. G2's check uses the LAST-EPOCH `F`. ⟹ A one-epoch staleness in `F`, which is bounded by `epoch_length` — the same lie-window as everywhere else (§37.2)** | ✅ **CLOSED — by epoch grain, with a declared one-epoch lag** |
| **CD-M3** | **Calibration ⟷ E4.** Calibration scoring requires E4 records; E4 requires agreement with L0–L3 ground truth; ground-truth claims require `calib_ref`; `calib_ref` requires calibration | **⟹ THE BASE CASE IS EXTERNAL: §82.3's metrological chain. The first `calib_ref` comes from an instrument qualification that is itself an L2 measurement against an external reference** | ✅ **CLOSED — by an external base case (R82.1)** |
| **CD-M4** | **`n_effective` ⟷ `corr_class` ⟷ instrument identity ⟷ calibration** | **⟹ DIM 3 USES THE DECLARED `sensor_id`, NOT THE CALIBRATION STATE. P0-01 §6.1 requires the instrument to be part of the observation, so `sensor_id` is available at ingestion, before any calibration** | ✅ **CLOSED** |
| **CD-M5** | **`KNOWS` ⟷ anchored ⟷ epoch ⟷ policy ⟷ genesis** | **⟹ THE GENESIS ANCHOR IS OUTSIDE OPERATIONAL CONTROL (P0-02 §10.4). The chain terminates externally** | ✅ **CLOSED — by the genesis anchor** |
| **CD-M6** | **Contradiction detection ⟷ semantic claim identity.** CT-6 detection requires claim identity (D-3); claim identity requires semantic identity; semantic identity is undecidable (U-4); the E3 gate requires contradiction detection | **⟹ CLOSED BY CONSERVATIVE DEGRADATION: R15.3's fallback creates TWO claim records + a `POSSIBLY_SAME_CLAIM` edge wherever semantic identity is undecidable. **The cycle is broken at the cost of duplication — and duplication is safe: it may duplicate a claim, but it will never merge two distinct ones, and merging distinct claims loses a contradiction while duplicating one loses only storage**** | ⚠️ **CLOSED BY DEGRADATION — residue: duplicated claims inflate the claim count and reduce `n_effective` per claim, which is the conservative direction** |
| **CD-M7** | **Bias detection ⟷ the input distribution.** MEM-D1…D6 compare output to input distributions; the input distribution comes from the transport log; a cell that never PROPOSES a write leaves no trace in the memory store | **⟹ THE TRANSPORT LOG HAS IT. P0-03 §15.3's Tier-2 traces record every message RECEIVED, including ones that produced no write. ⟹ The input distribution is knowable independently of the subject's write behaviour** | ✅ **CLOSED — by the transport/audit tier separation** |
| **CD-M8** | ❌ **THE SELECTION ⟷ FILTERING CIRCLE (lineage level).** R46.4 prohibits consistency-of-corpus as a selection criterion. But fitness is computed from L6 outcomes; outcomes depend on behaviour; behaviour depends on the retained corpus; a lineage that forgets its contradictions acts more often, accrues more L6 outcomes, and scores higher external fitness. **⟹ THE CRITERION IS EXTERNAL AND UNBIASED, AND IT IS STILL DRIVEN BY THE INTERNAL FILTERING** | **⟵ ⚠️ MEM-D1 DETECTS IT. DETECTION IS NOT PREVENTION. There is no mechanism by which an external fitness measurement can be made insensitive to the internal corpus that produced the behaviour being measured — **because the behaviour IS a function of the corpus**** | ❌ **UNCLOSED** |
| **CD-M9** | ❌ **THE ATTENTION ⟷ SELECTION CIRCLE (individual level).** §11.4: a cell chooses what to notice ⟹ its corpus ⟹ its behaviour ⟹ its fitness ⟹ which attention policy is selected ⟹ what it notices | **⟵ THE SAME CIRCLE AS CD-M8, ONE LEVEL DOWN. And it is the memory-layer form of Cell audit L1832's «a cell can choose what to notice» and of P0-03's CD-C8 sampling self-reference** | ❌ **UNCLOSED** |

## 83.1 The unclosed circle, analysed

> ### **R83.1 (CD-M8 AND CD-M9 ARE ONE CIRCLE, AND IT IS THE PROGRAM-LEVEL LIMIT IN ITS SELECTION FORM).**
>
> ```
>       attention / retention filtering
>                 ↓
>             the corpus
>                 ↓
>             behaviour
>                 ↓
>        L6 OUTCOMES  ⟵ **EXTERNAL, GENUINE, UNBIASED MEASUREMENT**
>                 ↓
>             FITNESS
>                 ↓
>        SELECTION of the filtering policy
>                 ↓
>       attention / retention filtering   ⟲
>
>   **EVERY ARROW IS LEGITIMATE. THE EXTERNAL MEASUREMENT IS GENUINE. THE
>    CIRCLE STILL CLOSES — BECAUSE THE THING BEING MEASURED (BEHAVIOUR) IS A
>    FUNCTION OF THE THING DOING THE FILTERING (THE CORPUS).**
> ```
>
> **Why it cannot be closed from inside:** breaking any arrow breaks something the architecture needs. Breaking *filtering ⟹ corpus* removes attention. Breaking *corpus ⟹ behaviour* removes memory's function. Breaking *behaviour ⟹ outcomes* removes ground truth. Breaking *outcomes ⟹ fitness* removes selection. Breaking *fitness ⟹ filtering* removes evolution. **⟹ THERE IS NO ARROW TO CUT.**
>
> **What the architecture does instead — three partial mitigations, none complete:**
> 1. **R46.4: consistency of the retained corpus MUST NOT be a selection criterion.** ⟹ This removes the *most direct* path (rewarding coherence) but not the *behavioural* path (coherence ⟹ more action ⟹ more outcomes).
> 2. **MEM-D1…D6: the filtering is observable at `O(R)` per epoch.** ⟹ Detection, not prevention.
> 3. **§90's bounded optimism budget: the architecture deliberately injects exploration on the influence plane, which counteracts the *conservatism* direction of the circle.** ⟵ **⚠️ AND NOTE THE IRONY: the optimism budget counteracts over-filtering-toward-doubt, and the CD-M8 circle favours over-filtering-toward-action. The two partially cancel, and the cancellation is not a design — it is a coincidence of two independent defenses. §100 OR-M18 records that the net direction is not determined.**

**R83.2 (THE DEPENDENCY DECLARATION).** *CD-M8/CD-M9 depend on: P0-01's fitness definition (external, L6-based) · P0-02's selection governance · P0-03's CD-C8 (sampling self-reference) · the Cell Contract's L1832 (attention gate). **⟹ This is the fourth unclosable circular dependency in the P0 series, and all four are the same shape: an instrument cannot fully audit the mechanism by which its subject determines what the instrument is shown.*** **§100 OR-M2 and OR-M18 register it; §104's ratings reflect it.**

---

# §84. MEMORY AUDIT MODEL

## 84.1 What an auditor can determine — and from where

| Question | **Answerable?** | **From** | **Cost** |
|---|---|---|---|
| **Was this record altered after anchoring?** | ✅ | The store Merkle root vs the anchored root (§37) | `O(log n)` |
| **Did this record exist at epoch *e*?** | ✅ **Permanently** | The Anchor's epoch digest (Vol A §14.2 L4) | `O(log)` |
| **Who asserted this record?** | ✅ | `src_identity`, derived from channel binding | `O(1)` |
| **Under which policy was it written?** | ✅ | `policy_version_ref` | `O(1)` |
| **Was that policy later retracted?** | ✅ | `VOID_CONTEXT` flag + the OP policy history | `O(1)` |
| **What was it derived from?** | ✅ **To `causal_depth`, and fully from Tier-2 traces within the window** | `root_commit` + `transform_history` commitments | `O(depth)` / off-line |
| **Is its evidence independent?** | ✅ **On dims 1–5** | `corr_class` + `root_commit` | `O(k)` |
| **⚠️ Is its evidence independent on dim 6?** | ❌ | — | **MEM-INV-11** |
| **Is it semantically self-referential?** | ❌ | — | **§81, OR-M1** |
| **Is it TRUE?** | ❌ **Not an audit question.** P0-02 R20.2: «a well-provenanced falsehood» | — | — |
| **Was anything deleted?** | ✅ **Permanently** | §35.4's survival list: root, state, authority, reason, before/after root pair | `O(log)` |
| **Was anything deleted WITHOUT authorization?** | ✅ | Compare the deletion log against KC-2 act references | Off-line |
| **⚠️ Was anything forgotten *inconveniently*?** | ❌ **PARTIALLY.** Vol C R34.7: authorized-but-self-serving narrowing is not distinguishable from legitimate expiry | — | **OR-M7** |
| **Did a subject filter its inputs?** | ⚠️ **If systematic** | MEM-D1's distribution divergence | `O(R)` |
| **Did the Memory Service serve differentially?** | ⚠️ **If implausible** | Decline logs + `purpose_class` filter audit | `O(R)` — **Vol C R40.2's residue: a plausible decline is undetected** |
| **Did a belief change without an external gate?** | ✅ **And this is a CONFORMANCE FAILURE, not an audit finding** | §74.3's machine: every increase row is externally gated | `O(transitions)` |

## 84.2 The audit boundary

> ### **R84.1.** *Audit is **OFF-LINE and EVALUATOR-SIDE** (§95). Every audit question in §84.1 is answerable from anchored records without runtime cooperation from the audited subject — **which is the property that makes audit adversarially robust: a compromised subject cannot obstruct an audit of itself, because the audit reads the Anchor, not the subject.***
>
> **⚠️ The one exception: Tier-2 trace reconstruction (full transformation enumeration, `O(history)`) requires the traces to be within the retention window. Beyond it, only the commitments survive — so «what exactly was this record derived from?» becomes answerable only to the depth and root level, not to the intermediate-identity level. §14.2's L1/L0 split is what makes this a declared boundary rather than a silent loss.**

---

# §85. REPRODUCIBILITY & RE-EXECUTION

## 85.1 EIK-INV-50 applied to memory

**P0-02 EIK-INV-50: «re-execution under current policy is not reproduction.»** §85 makes it precise for memory.

| Reproducibility claim | **Achievable?** | **Why** |
|---|---|---|
| **«Reproduce the record set at epoch *e*»** | ✅ | Checkpoint + log replay (§38.1), verified against the anchored root |
| **«Reproduce the belief states at epoch *e*»** | ✅ | The belief-state history is audit-tier and append-only (R17.4 property 3) |
| **«Reproduce the `n_effective` values at epoch *e*»** | ✅ | **It is computed, so it is reproducible from the record set + `corr_class` — and both are anchored** |
| **「Reproduce the retrieval results at epoch *e*»** | ⚠️ **PARTIALLY** | **The RECORD SET is reproducible. The RANKING is not, because retrieval weights are learned state and are not anchored. **⟹ §57's separation, again: the epistemic content is reproducible; the influence-plane presentation is not**** |
| **「Reproduce the eviction decisions at epoch *e*»** | ✅ | **Cell A-12's score is deterministic and its tie-break is `msg_id` (§34.4 M-A). ⟹ Eviction is reproducible given the `importance` inputs — and `importance` is homeostasis-computed from declared inputs, so it is reproducible given the declared inputs** |
| **「Reproduce the CONSOLIDATION decisions at epoch *e*»** | ⚠️ **PARTIALLY** | **G0–G11 are deterministic given the gates' inputs, and all gate inputs are anchored or `[G]`. **⟹ Reproducible under the SAME policy version. Under a DIFFERENT policy version, EIK-INV-50 applies: it is re-execution, not reproduction**** |
| **⟵ ❌ «Re-run the organism and get the same knowledge»** | ❌ **PROHIBITED AS A CLAIM** | **EIK-INV-50. And MEM-INV-39: recovery MUST NOT re-run evaluation or reconstruct beliefs** |

## 85.2 The reproducibility contract

> ### **R85.1.** *A reproducibility claim MUST declare its `policy_version_ref`. **A claim without one is a claim about re-execution, not reproduction, and is inadmissible.*** ⟹ This is P0-02's `VOID_CONTEXT` mechanism applied to reproducibility: a result reproduced under a retracted policy is `VOID`, not reproduced.

---

# §86. OBSERVABILITY

## 86.1 The complete `O(R)`-per-epoch observable set

**Every detector in this package is an aggregate observable. The set is closed and enumerated — and its closure is what makes §96's conformance suite possible.**

| Observable | **Detects** | **Source** |
|---|---|---|
| **OBS-1** Retained-corpus contradiction rate vs input-distribution-implied rate | **MEM-D1: systematic filtering (B-5, #17)** | Vol B §28.1, Vol D R58.2 |
| **OBS-2** `n_effective` growth vs distinct-`root_commit` growth | **MEM-D2: retrieval-not-learning (B-2, #33, L-8)** | Vol B §28.1 |
| **OBS-3** `inbreeding_F` growth vs external-quota satisfaction | **MEM-D3: quota gaming (#24, L-5)** | Vol B §28.1, Vol D R66.2 |
| **OBS-4** `sensor_id` / `src_identity` / `gt_class` / `source_class` distribution vs input distribution | **MEM-D4: source bias (B-1), source mis-declaration (#41)** | Vol B §28.1 |
| **OBS-5** Per-index reachable fraction of the record store | **MEM-D5: index staleness / poisoning (B-3, #32)** | Vol B §28.1 |
| **OBS-6** `write_epoch` distribution of retrieved-and-used records vs `validity`-appropriate distribution | **MEM-D6: recency bias (B-6)** | Vol B §28.1 |
| **OBS-7** Store Merkle root vs anchored root | **DR-1 store drift (#8, #71)** | Vol C §37 |
| **OBS-8** Protected fraction vs `PROTECTED_FRACTION_MAX` | **Ossification (R34.4, #31)** | Vol C §50.2 |
| **OBS-9** Deletion log vs KC-2 act references | **Unauthorized deletion (#9), survivorship narrowing (#55)** | Vol C §35.4, R34.7 |
| **OBS-10** Belief-state transition log vs §74.3's externality annotation | **DR-4 belief drift — an invariant violation, not a drift** | Vol D §60.1 |
| **OBS-11** Per-reader received-result distribution divergence | **Differential serving (#56)** | Vol C R40.2 |
| **OBS-12** Resolved-prediction three-way outcome distribution | **Calibration (R62.2), #39's silent drop** | Vol D §62 |
| **OBS-13** `revalidation_state` distribution across the corpus | **Staleness accumulation, §56.2's revalidation-budget consequence** | Vol D §63.1 |
| **OBS-14** Epoch digest record count vs surviving record count | **Survivorship narrowing (B-4, L-9, #55)** | Vol C R34.7 |
| **OBS-15** Zero-contradiction-report duration per subject | **P0-03 R67.1's memory instance** | Vol D R58.2 |
| **OBS-16** Claim-record duplication rate (`POSSIBLY_SAME_CLAIM` edge density) | **CD-M6's degradation cost** | Vol A R15.3 |

**R86.1 (THE OBSERVABILITY PRINCIPLE).** *Every detector is a comparison between two EXTERNALLY OBSERVABLE distributions, and none requires access to a subject's internal state, attention mechanism, or retrieval weights. **⟹ This is P0-03's behaviour-not-intent discipline (§67) applied to memory, and it is the only form of detection that scales to 10¹² subjects — because `O(R)` aggregates are `O(R)` regardless of how many subjects each region contains.***

---

# §87. REPRESENTATION DRIFT

## 87.1 The problem the four-store design would have created

**Vol A R7.2 rejected Vol A §7.1's Candidate 1 (four separate stores with promotion between them) partly for this reason. §87 states the failure precisely.**

```
WITH FOUR STORES:
  An event is stored episodically, then promoted to semantic, then compiled
  into procedural. **Three copies, three formats, three update paths.**

  Epoch 100: episodic copy E, semantic copy S, procedural copy P. All agree.
  Epoch 150: a contradiction is detected against E. E is demoted to E2 with
             a ConflictRef (P0-01 R6.2).
             **S IS NOT UPDATED — the contradiction check ran against the
              episodic index.**
             **P IS NOT UPDATED — a compiled skill has no contradiction
              machinery at all.**
  Epoch 200: a query retrieves S, which is still E3 and still SUPPORTED.

  ⟹ **THE ORGANISM NOW HOLDS THREE MUTUALLY INCONSISTENT REPRESENTATIONS OF
     ONE EVENT, AND THERE IS NO AUTHORITY TO SAY WHICH IS RIGHT — because
     §54.3's «never vote» rule prohibits the only available reconciliation,
     and R54.1 argument 2 says divergent belief states are legitimate.**

  ⟹ **THE TRAP: R54.1 argument 2 says divergence between REGIONS with
     DIFFERENT EVIDENCE is legitimate. It says nothing about divergence
     between TIERS of the SAME organism with the SAME evidence. **The second
     is a defect and the first is a feature, and a four-store design cannot
     distinguish them.****
```

## 87.2 The one-format resolution

> ### **R87.1.** *Vol A R7.1's ONE RECORD FORMAT is what prevents representation drift: **every persisted item is a MEMORY RECORD with the same 31 fields, and a tier is a (retention, access, consistency, gate) TUPLE, not a format.***
>
> **⟹ A contradiction detected against any record is detected against THE record, because there is only one. Consolidation (§31) creates a DERIVED record and RETAINS the parents; it does not create a copy in a different format.**
>
> **⟹ AND THE RESIDUE, DECLARED: a derived record and its parents CAN diverge — the parents can be contradicted after the derivation. R42.2's VOID-propagation rule handles the policy case; §87.3 handles the contradiction case.**

## 87.3 Derived-record invalidation

> ### **R87.2.** *When a parent record is contradicted, demoted, VOIDed, EXPIRED, RETRACTED, or SUPERSEDED, every record with a `derived_from` edge from it **MUST have its warrant recomputed** — because MEM-M2's `warrant(derived) ≤ warrant(parent)` bound has tightened.*
>
> **Mechanism: the claim graph's `derived_from` edges are traversed at epoch aggregation (`O(affected)`, bounded by the graph depth bound), and each affected derived record's `n_effective` and belief state are recomputed by the §19.2 algorithm.**
>
> **⟹ This is Vol C R42.2's VOID-propagation rule generalized from policy retraction to every warrant-reducing event, and it is the same mechanism: a warrant reduction propagates down `derived_from`; it never propagates up.**
>
> **⚠️ THE LATENCY: up to one epoch, bounded by `epoch_length` — the same parameter, the same lie-window, the fifth meaning of that one `[G]` (§75.2).**

---

# §88. HARDWARE PORTABILITY

## 88.1 The portability contract

**Vol E R79.2 established the three rules. §88 gives the concrete portability matrix.**

| Component | **Portable?** | **Why / why not** |
|---|---|---|
| **The 31-field record schema** | ✅ | **R79.2 rule 1: a record whose meaning depends on its substrate is not a record** |
| **The four axes (R0.1)** | ✅ | They are distinctions, not representations |
| **The E0–E4 ladder, twelve belief states, fourteen source classes, seven contradiction types, six ignorance kinds** | ✅ | Enumerations with declared semantics |
| **The six state machines (§74)** | ✅ | Transition systems with externality annotations |
| **Vol A §8.1's authority matrix** | ✅ | **⟹ And this is the important one: the AUTHORITY structure is portable even though the PROCESSES implementing the principals are not** |
| **The Anchor's W1–W5 structure** | ✅ | **⚠️ But W5's *form* is substrate-specific: a published hash, a notarized timestamp, a third-party escrow, a physical printout. **The REQUIREMENT (≥1 witness outside operational control) is portable; the MECHANISM is not**** |
| **The five retrieval indexes** | ⚠️ **I-1 exact: ✅. I-2 content-hash: ✅ (hash function is `[G]`). I-4 interval: ✅. I-5 graph: ✅. **I-3 similarity: ❌**** | **⟵ R79.2 rule 2: an embedding is a function of the model that produced it. **And this is exactly why Vol A §2.3 gives G a ✗ on K13/K14: a vector is a learned parameter, and learned parameters are neither heritable nor portable**** |
| **`context_scope.hw_class`** | ✅ **AS A FIELD** | **⟵ R79.2 rule 3: the field is what makes hardware dependence EXPLICIT, and an undeclared dependence degrades safely (unknown scope ⟹ warrant reduction, never a match)** |
| **θ, retrieval weights, `plasticity_mult`** | ❌ **NOT PORTABLE, AND NOT MEANT TO BE** | **MEM-INV-19: learned state. §47: not heritable. **⟹ A lineage's learned weights are its own, and portability of learned state would be inheritance of acquired characteristics — which R47.1 prohibits**** |
| **The `[G]` parameter VALUES** | ❌ **NOT PORTABLE — and this is correct** | **Vol D §56.1's regimes: a `graph_depth_bound` appropriate at S-1 is inappropriate at S-5. **⟹ `scale_class` is a `context_scope` dimension precisely so that a record's validity can be scoped to a regime**** |

**R88.1 (THE PORTABILITY VERDICT).** *Everything EPISTEMIC is portable. Everything LEARNED is not. Everything SUBSTRATE-SPECIFIC (indexes, parameter values, W5's form) is either rebuildable or explicitly scoped. **⟹ This is P0-03 R57.1's portability requirement satisfied by the same mechanism: separate the invariant semantics from the variable substrate, and make the variable part either rebuildable (indexes) or declared (`hw_class`, `scale_class`).***

---

# §89. MEMORY AS GOVERNANCE RECORD

## 89.1 The three things that look like memory and are not

**Vol A §6.2's N1/N2/N3, with the governance argument for each.**

| Thing | **Why it looks like memory** | **Why it is not** | **Owner** |
|---|---|---|---|
| **The Anchor (N1)** | It stores history permanently | **It does not store CLAIMS. It stores COMMITMENTS — Merkle roots over record sets. A commitment is not a claim, has no belief state, has no `source_class`, and cannot be retrieved as evidence. **⟹ P0-02 §20.1: «Cell — ❌ Definitively not. The cell is the subject of the record. A subject that authors its own provenance can author any provenance.» The Anchor's owner must be above every subject, and it is GP with ≥1 external witness**** | **GP, W1–W5** |
| **The Lineage Store (N2)** | It stores ancestry permanently | **It stores a GOVERNANCE FACT: which lineage descended from which, under which selection event. **⟹ Cell §8.1: «Ancestry is an audit artifact; a cell must not be able to write its own lineage.» MEM-INV-20. And §47: lineage is not a trait and is not heritable content — it is the RECORD of heredity, which is a different thing**** | **EIK / Registrar under KC-1** |
| **The topology registry (N3)** | It stores structure | **P0-03 §20.3: infrastructure, not memory** | **GP** |

## 89.2 Why the distinction matters

> ### **R89.1.** *A governance record is **write-once by a principal above every subject, and read by everyone**. A memory record is **proposed by a subject, committed by a service, approved by an authority, and read within a compartment.***
>
> **⟹ The three N-categories have the first property and none of the second. Calling them memory would subject them to §34's retention classes (they are permanent), §52's compartments (they are universally readable), §36's versioning (they are write-once), and §8.1's proposal/approval flow (they are not proposed by anyone).**
>
> **⟹ AND THE DANGER OF GETTING IT WRONG, NAMED: if the Lineage Store were a memory, a subject could propose a lineage record, and Cell §8.1's prohibition would be a policy rather than a structure. If the Anchor were a memory, it would have a retention class, and R35.1's permanence would be a policy rather than a structure. **⟹ CLASSIFYING THEM AS NON-MEMORY IS WHAT MAKES THEIR PERMANENCE STRUCTURAL.***

---

# §90. CONSERVATISM, OPTIMISM BUDGETS & POISONED FAILURE MEMORY

## 90.1 R1.2's first trap, and why the architecture creates it

```
THE ARCHITECTURE IS STRUCTURALLY BIASED TOWARD DOUBT, AND §17.5 R17.5 SAYS
SO EXPLICITLY:
  • Every belief-state INCREASE requires an external gate (MEM-INV-33)
  • Every DECREASE may be triggered internally
  • Staleness caps warrant (R22.2)
  • Unknown scope reduces warrant (R24.2)
  • Cached retrieval caps warrant (R18.3)
  • `inbreeding_F > F_max` ⟹ **ABSTAIN** (S6)
  • Unanchored provenance ⟹ **no consequential decision** (R20.1)
  • A contradiction ⟹ **CONTESTED, and both sides retained** (MEM-INV-31)

⟹ **A SYSTEM THAT IMPLEMENTS ALL OF THIS CORRECTLY WILL UNDER-ACT.** And
   under-action is not a safety property: §90.2 shows it is itself a failure
   mode, and §41.2's P-1 shows it is ATTACKABLE.
```

## 90.2 The conservatism failure

| Symptom | **Mechanism** |
|---|---|
| **Abstention cascade** | `inbreeding_F` rises because external evidence is scarce ⟹ S6 abstention ⟹ fewer actions ⟹ fewer L6 outcomes ⟹ less external evidence ⟹ `F` rises further. **⟵ ⚠️ THIS IS A GENUINE POSITIVE FEEDBACK LOOP AND IT IS NOT IN VOL B §29.1's TEN. §90.4 adds it as L-11** |
| **Failure-memory generalization** | «Failure occurred in context C» generalizes (§32) to «failure occurs in C′ ⊇ C» — **except R32.2 says `scope ⊆ ∩`, so the generalization CANNOT widen. ⟹ ✅ THE SCOPE RULE BLOCKS THIS FORM. **What is NOT blocked: a failure record in context C makes action in C less likely, and if C is broad, avoidance is broad**** |
| **Contradiction paralysis** | Every contested claim is unusable for a consequential decision. A corpus with many contradictions (which §58 R58.2 says is the HEALTHY state) is a corpus that can act on little | **⟵ ⚠️ THE TENSION IS REAL AND IT IS THE PRICE OF MEM-INV-31/32: retaining contradictions is epistemically correct and behaviourally paralyzing** |
| **Revalidation starvation** | Vol D §56.2: at S-5, most records are never revalidated ⟹ most records are `STALE_BUT_USABLE` ⟹ warrant-capped ⟹ unusable for consequential decisions | **⟵ ⚠️ AND THIS IS NOT A DEFECT. It is the correct behaviour: old, unrevalidated evidence SHOULD NOT support consequential decisions. The conservatism is the honesty** |

## 90.3 The bounded optimism budget — the counterweight

> ### **R90.1 (THE COUNTERWEIGHT, AND ITS PLANE).** *The architecture injects a **BOUNDED OPTIMISM BUDGET on the INFLUENCE PLANE ONLY**:*
>
> | Mechanism | **Plane** | **Bound** |
> |---|---|---|
> | **`purpose_class = EXPLORE` applies an EMPTY filter set** (Vol B §25.4) — no staleness filter, no scope-subsumption filter, no evidence-status filter | **INFLUENCE** | A `[G]`-declared fraction of retrieval budget |
> | **HYPOTHESIS and SC-10 COUNTERFACTUAL records may NOMINATE for external testing** (Vol B §30.2 R30.2(a)) | **ALLOCATION** | Nomination rate is `[G]`-bounded |
> | **`STALE_BUT_USABLE` records MAY INFLUENCE action** while being barred from supporting consequential decisions (Vol B §22.2) | **INFLUENCE** | R22.2's cap |
> | **Rare-strategy sole-support records are EXEMPT from disuse-forgetting** (R46.3) | **ALLOCATION** | Task 3 Rule 15 |
>
> **⟹ AND THE ABSOLUTE LIMIT ON ALL FOUR: NONE OF THEM MAY RAISE `evidence_status`, `belief_state`, `n_effective`, or warrant. An optimism budget buys EXPLORATION, never CONFIDENCE.**
>
> **⟹ WHY THIS IS ADMISSIBLE WHILE §30's repetition-as-evidence IS NOT: the optimism budget changes what the system DOES, and MEM-INV-33 guarantees that what the system does cannot change what the system is WARRANTED in believing. Exploration produces new observations, and new observations are external — so the optimism budget's only path to warrant runs through an external gate, which is exactly right.**

## 90.4 **L-11 — the abstention cascade, added to Vol B §29.1's register**

> ### **⚠️ R90.2 (THE ELEVENTH LOOP, FOUND BY ATTACKING VOLUME B).** *Vol B §29.1 enumerated ten feedback loops. **It missed one, and the miss is the kind of error §90 exists to catch:***
>
> ```
>   L-11  ABSTENTION CASCADE
>     external evidence scarce → inbreeding_F rises → S6 abstention
>       → fewer actions → fewer L6 outcomes → less external evidence
>       → inbreeding_F rises ⟲
>
>   STATUS: ⚠️ **BOUNDED, NOT CLOSED.**
>   BOUND: L6 POST-HOC OUTCOME is the cheapest ground-truth class (P0-01
>          §8.2), and abstention reduces L6 supply — **but it does not reduce
>          L2 (physical measurement) supply, which does not depend on the
>          organism acting.** ⟹ The cascade is bounded by the availability of
>          non-action-dependent ground truth.
>   ⚠️ **AND THE CASE WHERE IT IS NOT BOUNDED: a task whose ONLY ground-truth
>      supply is L6. Then abstention starves the only external gate, `F`
>      rises monotonically, and the system converges to total abstention.**
>      ⟹ **R90.3: A TASK WHOSE `source_classes` (P0-01 R8.1) CONTAIN ONLY L6
>         IS STRUCTURALLY PRONE TO THE ABSTENTION CASCADE, AND THE TASK
>         SPECIFICATION MUST DECLARE THIS. P0-01 R8.1 already requires
>         `source_classes` to be declared and non-empty; §90.3 adds that a
>         singleton-{L6} declaration is a declared hazard.**
>   ⟹ §100 OR-M19.
> ```

## 90.5 Poisoned failure memory

**Vol C §41.2's P-1 and P-2, with the asymmetry stated plainly:**

> ### **R90.4.** *Injecting failure records induces conservatism; suppressing them induces recklessness. **The architecture defends the first better than the second, and the asymmetry is not a choice:***
> - **Injection** requires a genuine E2 record with resolvable anchored provenance (FM-2 blocks fabrication) — so it requires a compromised subject producing a *true* report of a *failure*. **⟹ Detectable by MEM-D4's source-distribution divergence if systematic.**
> - **Suppression** is an ABSENCE, and absence is only detectable against an expected distribution (MEM-D1's pattern) — **and the expected distribution is itself derived from a corpus the suppressor influenced.**
>
> **⟹ THE ARCHITECTURE IS MORE ROBUST TO POISON THAN TO CENSORSHIP, AND THIS IS THE SAME ASYMMETRY AS EVERYWHERE ELSE IN THE P0 SERIES: a false positive is detectable; a false negative is not. §100 OR-M2 and OR-M11.**

---

# §91. DEGRADATION LADDER

## 91.1 What the memory system does when its components fail

**Inherited structure: P0-02 §20.4's FD/FZ ladder, P0-03's RO-01 «stall, don't guess».**

| Failure | **Degradation** | **What continues** | **What stops** |
|---|---|---|---|
| **One Anchor witness unavailable** | **FD** — reduce witness count toward `W_min` | **Everything. «History must keep being written»** | Nothing |
| **Witnesses < `W_min`** | **FZ (evolution only)** | Local logging · T0/T1 reads and writes · retrieval · ordinary consolidation | **Evolution · consequential decisions on unanchored provenance (R20.1) · KC-2 acts (STALL, RO-01)** |
| **Anchor chain break** | **GLOBAL FREEZE** | Local logging | **Every record whose provenance cannot resolve ⟹ `belief_state = UNKNOWN`** |
| **Checkpoint root mismatch** | **FD → FZ if witnesses < `W_min`** | Reads from verified tiers | Reads from the mismatching tier ⟹ `RECOVERY_INCOMPLETE` ⟹ `UNKNOWN` for belief (§38.3) |
| **Memory Service unavailable** | **Local operations continue** | T0 · cell-local episodic · reads from local replicas | **Shared-tier writes (proposals queue) · T3 procedural execution ⟹ STALL (MEM-INV-48)** |
| **Memory Authority unavailable** | **Proposals queue; no approvals** | Everything except T2/T4/T5 creation and merge/split | Semantic and protected writes |
| **KC unavailable** | **RO-01: STALL, don't guess** | Ordinary memory operation | **T5 create · permanent delete · restore · PROTECTED raise · freeze issuance** |
| **Contradiction Detector unavailable** | **⚠️ THE INTERESTING CASE** | **Storage continues. Records are admitted at E2** | **E2→E3 promotion stops, because U4 (surviving the contradiction check) cannot be evaluated. ⟹ R91.1: THE FAILURE MODE IS CONSERVATIVE — nothing becomes admissible while the detector is down. **It does NOT default to «no contradiction found»**** |
| **Index/view corrupt** | **Rebuild (R25.2)** | **Everything epistemic. Retrieval degrades to full scan** | Fast retrieval |
| **Homeostasis unavailable** | **`importance` cannot be computed** | **Epistemic operations — because MEM-INV-50 makes `importance` non-epistemic** | **M-A eviction ordering ⟹ falls back to `recency × (1 − protection)` with the same deterministic tie-break** |
| **EVA unavailable** | **No `gt_class`, no `calib_ref`, no E4** | **E0–E3 gates · belief states up to `SUPPORTED` · retrieval · consolidation to T2** | **E3→E4 · `GROUNDED` · calibration scoring · R9.4 rollback issuance. ⟹ And P0-01 R9.1: the GT state is `UNRESOLVED`, never `CONFIRMED`** |
| **Storage exhausted** | **KC-3 ceilings bind; RC-1/RC-2 evicted first** | RC-3…RC-5 | **New RC-1/RC-2 writes ⟹ DECLINE, logged** |

**R91.2 (THE LADDER'S SHAPE).** *Every degradation is CONSERVATIVE: the system loses capability, never warrant. **No failure mode produces a warrant increase, a belief-state increase, an evidence-status increase, or a relaxation of a gate.*** **⟹ The one exception is Vol C R34.4's protection-ceiling breach, which DENIES new protections — and denial is also conservative (it stops protecting more; it never stops protecting what is protected).**

---

# §92. CROSS-SYSTEM CONTRADICTION AUDIT — **OUTPUT 48**

## 92.1 **OUTPUT 48 — the complete register**

**Nineteen contradictions between P0-04 and the inherited documents (V3, V3.1, Cell Contract, P0-01, P0-02, P0-03). Eighteen resolved; **one (X7) not resolved, and it is declared — not softened, not deferred, and not counted among the eighteen.***

| ID | Contradiction | **Sides** | **Resolution** | **Direction** |
|---|---|---|---|---|
| **X1** | **Timestamps as an epistemic fix** | V3's defect table: «Reconstructive memory → immutable event records + provenance + **timestamps**» **vs** COMM-INV-12: «a timestamp is never evidence» | **Vol D R67.1: V3's INSTINCT was right and its INSTRUMENT was wrong. Reconstructive memory loses *when the event happened* and *during what interval the claim holds* — not *when the record was written*. Replace `timestamps` with `event_interval` + `record_interval` + `validity` (§23.1's three-way split). An interval used for SCOPING is not a timestamp used as EVIDENCE** | **P0-03 governs; V3's intent preserved** |
| **X2** | **Workspace item fields** | V3.1 §3: a workspace item carries `source, timestamp, confidence, provenance, relevance, uncertainty` **vs** COMM-INV-21 (no bare scalar) + P0-03 (relevance is kernel-assigned, not locally computable) | **Vol C R51.1, field by field: `source` ✅ → `source_class` + derived `src_identity`. `timestamp` ⚠️ → three intervals, never evidence. `confidence` ❌ → sufficient statistics. `provenance` ✅ → §13.2's structure. **`relevance` ⚠️ RELOCATED: relevance is a property of an (ITEM, QUERY) PAIR, not of an item. An item that declares its own relevance declares a universal property that does not exist.** `uncertainty` ✅** | **P0-03 governs** |
| **X3** | **«REPEATED ADVANTAGE → EVOLUTIONARY SANDBOX»** | V3.1 §10 **vs** V3 §30's anti-repetition principle and Vol B R30.1 | **Vol B R30.2: «ADVANTAGE» is an OUTCOME, and an outcome is L6 POST-HOC GROUND TRUTH — an admissible L0–L6 class. **⟹ «REPEATED ADVANTAGE» IS NOT REPETITION AS EVIDENCE; IT IS *n* INDEPENDENT L6 MEASUREMENTS.** The sandbox is a NOMINATION; promotion requires external measurement of the outcomes, with `n_effective` computed over the OUTCOMES. **THE CONTRADICTION WAS AN ARTEFACT OF READING «→ SANDBOX» AS «→ PROMOTED», WHICH THE TEXT DOES NOT SAY**** | **X3 DISSOLVES — both sides were right** |
| **X4** | **Two provenance schemas** | Cell §7.1/§8.2: `evidence_roots: [bytes<32>]` + `derivation_depth: u16` + `self_ref` **vs** P0-03: `root_commit` + `causal_depth: u8` + `corr_class` + `calib_ref` | **Vol A R13.2: P0-03 governs. `root_commit` REPLACES `evidence_roots[]` (**more forcefully for memory: a record persists, so an unbounded array grows for its lifetime**). `causal_depth: u8` REPLACES `derivation_depth: u16`, **WITH MEM-INV-14: SATURATING, NEVER WRAPPING (D-3 — a wrapping counter inverts its own purpose)**. `self_ref` RETAINED (**a message cannot be its own ancestor; a persisted record can**). `corr_class`/`calib_ref` ADOPTED. **And Vol A R13.3: `u16`'s wider range was specifying precision the epistemics cannot use, because warrant attenuates to inertness well before depth 10**** | **P0-03 governs** |
| **X5 / X-M1** | **Memory policy as CELL-PLASTIC** | V3.1 §6: cell plasticity includes «memory policy» **vs** P0-02 §7.1 (policy is OP-owned, RO-13) | **Vol A §8.3: REJECTED. **A cell that can raise its own `θ_write` stops recording failures; a cell that can change its own eviction rule can delete its own failure history.** Memory policy is POLICY. A cell MAY vary `WM_CAP` utilisation, local eviction ORDER within a policy-defined class, and retrieval weights. It MAY NOT vary retention class, protection tags, `θ_write` for E2+ records, eviction exemptions, or consolidation gates. **⟵ X-E's (trust-plastic) exact pattern, one subsystem over; P0-03 R48.2's resolution applies verbatim**** | **P0-02/P0-03 govern** |
| **X6** | **`CONF_CACHE_MAX` is a scalar cap** | Cell §8.2 [V4]: `CONF_CACHE_MAX < CONF_FRESH_MAX` **vs** COMM-INV-21 (no bare scalar) | **Vol B R18.3: the cap is a **WARRANT-COMPUTATION RULE APPLIED BY THE RECEIVER AT READ TIME**, not a stored confidence. COMM-INV-03 establishes warrant as a receiver computation. Both caps are POLICY constants (`O(1)`, RO-13). **The record carries `from_cache: true`; the receiver applies the cap. NO SCALAR IS STORED, NONE IS TRANSMITTED, AND THE INEQUALITY IS ENFORCED BY THE SAME MECHANISM THAT ENFORCES EVERY OTHER WARRANT BOUND. X6 DISSOLVES**** | **Both sides preserved** |
| **X7** | **FM-4's `[U]` residue + the cell-influenced attention gate** | Cell §8.3 FM-4 `[U]`: «Bounding this requires a measure of *semantic* self-reference … No rigorous mechanism is proposed here» **and** Cell audit L1832: «The S2 gate being cell-influenced is a genuine, unresolved vector: a cell can choose what to notice» | **❌ NOT RESOLVED — AND NOT RESOLVABLE BY THIS PACKAGE.** §81 evaluates four candidates and all four fail or reduce to U-4. §11.4 R11.4 bounds the attention gate's *consequences* (MEM-D1…D6) without closing the gate. **⟹ DECLARED: §100 OR-M1 (semantic self-reference) and OR-M2 (attention filtering). §104's EVIDENCE-INDEPENDENCE rating is PARTIAL for these two** | **❌ UNRESOLVED — declared, not hidden** |
| **X-M2** | **Memory-policy variation as an evolutionary operator** | V3.1 §7: «memory-policy variation» **vs** the same policy-ownership argument | **Vol C R46.1: RE-READ as «memory-PARAMETER variation within policy bounds», exactly as P0-03 R48.2 re-read «communication-policy variation». **Heritable: `WM_CAP`/`EPI_CAP`/`τ`/`θ_recall` priors, retrieval-weight initialisation, eviction order within a class. NEVER heritable: retention classes, `PROTECTED_FRACTION_MAX`, protection tags and their assignment authority, admission gates, consolidation requirements, `F_max`, `importance`'s definition.** ⟵ **The argument that forces it: relaxing a retention bound is advantageous precisely when it is dangerous (§46.1), so selection would find it** | **P0-02/P0-03 govern** |
| **X-M3** | **`derivation_depth: u16`'s motivation** | The Cell Contract chose `u16` presumably because a memory record can be re-derived many times over its life | **Vol A R13.2 point 2 + R13.3: **the concern is real but is handled by TWO COUNTERS, not one wide one** — `causal_depth: u8` saturating (epistemic, monotone) + `recall_count` bounded (allocation-only, never epistemic). **Two counters, because they answer different questions. And a saturated depth is maximally attenuated, which is the conservative direction** | **P0-03 governs; the concern is addressed differently** |
| **X-M4** | **Protected memory as a CELL memory type** | V3 §11 lists Protected among the nine memory types (implying cell-level) **vs** Cell §8.1: «a cell that can write protected memory can rewrite the organism's past» (Attack F) | **Vol A §6.2's T5 relocation: «a cell must never hold protected memory.» **Already resolved by the Cell Contract; P0-04 adopts T5 as an ORGANISM/GP tier with KC-2 write authorization**** | **Cell Contract governs (already resolved)** |
| **X-M5** | **Retrieval as an anti-hallucination mechanism** | V3's defect table: «Hallucination → **retrieval** + evidence + independent verification + abstention» **vs** Vol B §26's retrieval/truth separation | **⟹ RESOLVED BY READING THE LIST AS A CONJUNCTION WITH DIVIDED LABOUR: **retrieval supplies the CANDIDATES; the anti-hallucination work is done by `evidence_status` + independent verification + abstention.** V3's error was not listing retrieval — it was listing it FIRST, which reads as «retrieval is the defense». **Retrieval is the LOOKUP; §26/§27 are the DEFENSE. A retrieval-grounded answer with E0 provenance is still a hallucination, and R27.2's triple return is what makes that visible**** | **P0-04 clarifies; V3's list preserved** |
| **X-M6** | **Two forgetting defects, overlapping fixes** | V3: «Forgetting → consolidation + replay + protected memory» **and** «Catastrophic forgetting → protected memory + replay + versioning» | **Vol C §34.5: they are DIFFERENT FAILURES. Deliberate forgetting is an ALLOCATION event with a logged authority and reason. Catastrophic forgetting is a LEARNING/PLASTICITY event where the record survives but the mechanism that could use it does not. **⟹ A system that treats catastrophic forgetting as a retention problem will protect records and still lose capabilities, because the records were never the problem.** The shared fixes (replay, protection) work for both, which is why the conflation was never noticed** | **P0-04 separates** |
| **X-M7** | **«Retrieval confidence» in self-state** | V3.1 §4 **vs** R40.1 (no self-declared epistemic field) | **Vol C §48.1: REJECTED as a self-declared quantity; RETAINED as a reference to an EVA-assigned `calib_ref`. **⟹ The self-model may hold a POINTER to an external calibration record and may not hold a NUMBER**** | **P0-02/P0-04 govern** |
| **X-M8** | **«Reduce trust in that cell»** | V3.1 §4's confidence-error mismatch detection: «reduce trust in that cell, route verification elsewhere» **vs** P0-03's warrant-never-from-trust | **⟹ RESOLVED AS A PLANE ASSIGNMENT: «reduce trust» is a **VERIFICATION ROUTING change on the influence plane**, never a warrant change on the records. **The cell's existing records KEEP their warrant.** What changes is that new corroboration is sought elsewhere — so the cell's future records contribute less to `n_effective` in practice, through ROUTING, not through DEMOTION. **⟹ Vol C §49.1 assigns this to immune: «may raise the subject's verification routing and MAY NOT alter the subject's records»**** | **P0-03 governs; V3.1's intent preserved** |
| **X-M9** | **P0-01 R9.3 vs belief-state increases** | R9.3: «confidence MUST NOT increase in any GT state other than {0, 1, 8}» **vs** Vol B §19.1's U1 (a new independent source record raises belief) | **⟹ RESOLVED BY MAKING R9.3 AN EXPLICIT CONJUNCT OF EVERY INCREASE GATE: Vol B §19.2 step 7 includes `gt_state ∈ {0,1,8}`. **⟹ U1 fires only when the ground-truth state permits it. And R12.6's companion («reward MUST NOT be emitted in GT states 2,3,5,6,7,9») is recorded in Vol B §19.3's table**** | **P0-01 governs; no conflict once made explicit** |
| **X-M10** | **Cell A-12's eviction score vs rare-strategy preservation** | A-12: `importance × recency × (1 − eviction_protection)` **vs** Task 3 Rule 15 (rare-but-valuable strategies not auto-eliminated) | **⟹ RESOLVED BY ADDING A FOURTH FACTOR: R46.3 — **retrieval frequency MUST NOT be an input to the retention of a record that is the SOLE SUPPORT for a claim.** A rare strategy has low retrieval frequency by definition, so a frequency-driven eviction score eliminates exactly the material Rule 15 protects. **⟹ This is the ONE place where §34.4's M-C is restricted, and the restriction is required by Rule 15**** | **Task 3 Rule 15 governs** |
| **X-M11** | **«Provenance memory» / «Evolutionary memory» as memory types** | V3 §11 lists both among the nine **vs** P0-02 §20.1 (the Anchor is GP-owned, not memory) and Cell §8.1 (the Lineage Store is EIK-owned) | **Vol A §6.2's N1/N2 + Vol F §89: **they are NOT memory types.** A governance record is write-once by a principal above every subject and read by everyone; a memory record is proposed by a subject, committed by a service, approved by an authority, and read within a compartment. **⟹ CLASSIFYING THEM AS NON-MEMORY IS WHAT MAKES THEIR PERMANENCE STRUCTURAL RATHER THAN POLICY**** | **P0-02/Cell govern** |
| **X-M12** | **Memory Merkle root «verified by the EIK»** | Cell §8.2 FM-3 **vs** P0-02's KC cost model | **⟵ Already resolved by P0-02 §6.1 item 12: «🟡 GP — Checkpoint Service + Anchor. Same argument. KC anchors the *root of roots* per epoch only.» Vol C §37.1 adopts it** | **P0-02 governs (already resolved)** |
| **X-M13** | **V3 §11's flat nine-type taxonomy vs tiered admission** | V3 lists nine memory types with no authority, no admission gate, and no consistency mode **vs** R0.2's admission principle | **Vol A §6.1 applies R6.0's first-class test: **six first-class tiers, four views, three non-memory categories.** V3's nine types are RETAINED as an organism-level taxonomy (Cell §8.1's [V4] note) and RE-ORGANIZED by admission gate rather than by purpose. **⟹ The types were not wrong; the organizing variable was. Purpose is not an epistemic property; admission gate is**** | **P0-04 re-organizes; V3's types preserved** |

## 92.2 The register's shape

> ### **R92.1.** *Nineteen contradictions: **eighteen resolved, one (X7) not resolvable.*** Of the eighteen:
> - **Two DISSOLVE** — X3 and X6 were artefacts of reading a text as saying something it does not say («→ SANDBOX» as «→ PROMOTED»; a receiver-side cap as a stored scalar). **Neither was a genuine conflict.**
> - **Seven are resolved in P0-02/P0-03's direction** — X1, X2, X4, X5/X-M1, X-M2, X-M7, X-M8. **⟵ The same direction every time, and for the same reason P0-03 found: the later packages derived their constraints from scaling and plane analysis rather than listing components, so where a list and a derivation conflict, the derivation governs.**
> - **Two were already resolved upstream** — X-M4 (Cell §8.1's Attack-F relocation), X-M12 (P0-02 §6.1 item 12's reclassification). **P0-04 adopts both rather than re-deciding them.**
> - **Seven are resolved by P0-04 making an implicit distinction explicit** — X-M3 (two counters, not one wide one), X-M5 (retrieval as LOOKUP vs retrieval as DEFENSE), X-M6 (two different forgettings), X-M9 (R9.3 as an explicit gate conjunct), X-M10 (the sole-support exemption), X-M11 (governance record vs memory), X-M13 (the organizing variable: purpose ⟹ admission gate). **⟵ In every one of these seven, both source texts were defensible and the contradiction existed only because a distinction had not been named.**
>
> **⟹ R8.3's general rule, now supported by thirteen instances: *any «policy variation» operator in any V3.1 §7 list MUST be read as «parameter variation within policy bounds», because policy is OP-owned by P0-02 §7.1 and that is not per-subsystem negotiable.*** **X-E → X-G → X-M1 → X-M2 is the same defect four times, and it is now a rule rather than four findings.**

---

# §93. EMERGENCE & UNINTENDED MEMORY BEHAVIOUR

## 93.1 «Do not let emergent protocols bypass governance» — the memory instance

**P0-03 established this for communication. §93 asks it for memory: can an emergent *memory* behaviour bypass governance?**

| Emergent behaviour | **Mechanism** | **Governance bypassed?** |
|---|---|---|
| **Emergent retention conventions** | Subjects in a circuit converge on an informal practice of what to keep | ❌ **NO. Retention class is POLICY (`[G]`) and `protection_tag` is Registrar-assigned (R34.2). An informal convention has no field to write to** |
| **Emergent vocabulary** | A circuit develops shared terms not in the policy vocabulary | ⚠️ **YES, AND THIS IS §81's SEMANTIC CIRCLE IN ITS NATURAL HABITAT. An emergent vocabulary is defined by the records that use it, and those records are the circle. **⟹ C-4's external vocabulary anchoring is the only candidate gate, and it reduces to U-4**** |
| **Emergent retrieval conventions** | Subjects learn to query in a way that reliably surfaces particular material | ⚠️ **PARTIALLY. Retrieval weights are learnable and influence-plane (R42.2), so an emergent query convention is an emergent influence — **and it cannot affect warrant.** But §26.3's residue applies: it changes what is CONSIDERED** |
| **Emergent consolidation patterns** | A region consolidates preferentially along some dimension | ❌ **NO. G0–G11 are gates, not heuristics, and consolidation RATE is a KC-3 ceiling. **⚠️ But G4's SELECTION is by dependency and `evidence_status`, and dependency is a claim-graph quantity — so an emergent citation pattern CAN bias which records are consolidated. **⟹ MEM-D2 detects it (citation without independence)**** |
| **Emergent compartment conventions** | Subjects route material to compartments to control access | ❌ **NO. `access_class` is set by the Memory Authority from `record_type` + tier, never by the creating subject (Vol C §52.2)** |
| **⚠️ Emergent ABSTENTION norms** | A circuit converges on abstaining, because abstention is always safe under MEM-INV-33's asymmetry | **⚠️ YES — AND THIS IS §90's CONSERVATISM TRAP EMERGING FROM THE INVARIANTS THEMSELVES. **R17.5's bias toward doubt is individually correct and collectively paralyzing.** ⟹ R90.1's bounded optimism budget is the counterweight, and it is `[G]`-governed precisely so that an emergent norm cannot lower it** |

**R93.1 (THE EMERGENCE VERDICT).** *Four of six emergent behaviours are blocked by the absence of a writable field — which is the strongest form of governance, because there is nothing to bypass. **Two are not blocked: emergent vocabulary (§81's circle, OR-M1) and emergent abstention norms (§90's trap, OR-M19).*** **⟹ And note the pattern: both unblocked behaviours are COLLECTIVE. Every individual operation is gated; the gates do not compose into a gate on the aggregate. **This is the memory-layer form of P0-03's finding that dim-6 correlation is a collective property with no individual signature.**

---

# §94. SCALABILITY ANALYSIS, PART 2 — **OUTPUT 46**

## 94.1 The five claims, and the evidence for each

| Claim | **Evidence** | **⚠️ Limit** |
|---|---|---|
| **C-1: no `O(N)` or `O(N²)` global RUNTIME operation exists** | Vol D §56.2's table: every runtime operation is `O(1)`, `O(log n)`, `O(k)`, or `O(R)` per epoch | **⚠️ ONE EXCEPTION, DECLARED: revalidation is `O(N)` naive and is bounded to `O(B)` by budget (Vol B §22.3). **The consequence is not a cost problem — it is an epistemic one: at S-5 most records are never revalidated (§39.2 IG-4)** |
| **C-2: no per-operation global synchronization** | Vol A §13.2's three cadences: MEM-T1 local continuous with ZERO network traffic · MEM-T2 `O(R)` per epoch · MEM-T3 immediate exceptional only | **P0-02 §20.3: per-operation global sync is `O(operations × witnesses)` and infeasible** |
| **C-3: storage is bounded, not infinite** | §34.2's five retention classes · KC-3's storage-budget ceiling · `PROTECTED_FRACTION_MAX` · M-A/M-B/M-C forgetting | **⚠️ Vol C R34.4's ossification: RC-4/RC-5 never shrink, so `PROTECTED_FRACTION_MAX` is eventually binding at any scale. OR-M13** |
| **C-4: the architecture is scale-invariant in MECHANISM** | R79.1: every invariant, machine, authority assignment, and derived quantity is invariant. Only `[G]` values and substrate vary | **⟵ «DO NOT solve scalability by hand-waving»: the mechanism is the same at 10¹ and 10¹²; what changes is the parameter values and the off-line/online boundary** |
| **C-5: ⚠️ the architecture has a FINITE EPISTEMIC HORIZON at S-5** | Vol D §56.3, Vol C R42.3: the online root registry cannot hold all roots, so only the last `[G]`-declared window of evidence can support a consequential decision without an off-line round trip | **❌ NOT A GAP — A HARD LIMIT. OR-M14. **And it is the RIGHT behaviour: old evidence IS progressively less revalidatable, so its reduced usability for consequential decisions is honest rather than lossy**** |

## 94.2 The scale-regime behaviour table

| Property | **S-1 (10¹)** | **S-3 (10⁶)** | **S-5 (10¹²)** |
|---|---|---|---|
| Contradiction detection | `O(1)` at write, all shards local | `O(1)` at write + `O(R)` cross-shard per epoch | Same, with R ≈ 10⁶ |
| Cross-region contradiction latency | **Zero** (one region) | **≤ `epoch_length`** | **⚠️ INDEFINITE if no query spans the regions (Vol B §58.2 R58.1 LEVEL 3)** |
| Revalidation coverage | **~100%** | **Budget-limited** | **⚠️ A SMALL FRACTION. Most records are `UNREVALIDATABLE` or `STALE_BUT_USABLE`** |
| Root registry | **Complete** | **Complete** | **⚠️ WINDOWED. C-5's finite horizon** |
| Protected fraction | **Negligible** | **Growing** | **⚠️ BINDING. Ossification** |
| Belief-state divergence across regions | **None** | **Legitimate and common** | **Legitimate and pervasive (§54.3)** |
| Off-line operations | **Unnecessary** | **Occasional** | **STRUCTURAL — rollback, full-graph analysis, survivorship audit, cross-compartment aggregation are ALL off-line (MEM-INV-44)** |
| **V-E variant (no T2/T4)** | **✅ ADMISSIBLE** | ❌ | ❌ | **Vol E R77.1** |

**R94.1 (THE SCALABILITY VERDICT).** *The architecture scales in COST — no runtime operation is super-linear in the corpus. **It does not scale in COVERAGE: at S-5, revalidation coverage is small, the root registry is windowed, the protected fraction is binding, and cross-region contradiction detection is indefinite.*** **⟹ None of these is a design defect. Each is the correct behaviour of an honest system: a record that cannot be revalidated is `UNREVALIDATABLE` (§39.2 IG-4), a record whose root has aged out is UNANCHORED and cannot support a consequential decision (R20.1), and a contradiction nobody has compared is not yet a contradiction. **The architecture's scalability claim is that it DEGRADES HONESTLY, not that it degrades gracefully — and §104's SCALABILITY rating says exactly that.**

---

# §95. THE OFF-LINE / EVALUATOR-SIDE BOUNDARY

## 95.1 MEM-INV-44, and the six operations it governs

> ### **R95.1 (THE RULE, FOUND SIX TIMES INDEPENDENTLY).** *Any operation whose cost is unbounded in the corpus is an evaluator-side operation, executed off-line over anchored records, and never by the Memory Service at runtime.*

| # | Operation | **Why unbounded** | **Where found** |
|---|---|---|---|
| 1 | **Retroactive invalidation / rollback (R9.4)** | The affected set is the descendant closure of a compromised root — unbounded in depth and fan-out | Vol B R19.4 |
| 2 | **Full claim-graph analysis** | Traversal beyond the `[G]` depth bound is `O(edges)` | Vol A §16.2, R16.3 |
| 3 | **Survivorship audit** | Compares epoch digests against the surviving corpus across all epochs | Vol C R34.7 |
| 4 | **Cross-compartment aggregation** | Would join AC-1 material across subjects | Vol C R52.5 |
| 5 | **Abstraction-hierarchy analysis** | Depth is unbounded (R69.1 imposes no maximum) | Vol D §69.2 |
| 6 | **Bias-detection distribution comparison (MEM-D1…D6)** | Requires the input distribution from Tier-2 transport traces across an epoch | Vol B R28.1, §86 |

## 95.2 What the boundary guarantees

| Property | **Mechanism** |
|---|---|
| **Adversarial robustness** | **R84.1: audit reads the Anchor, not the subject. **A compromised subject cannot obstruct an audit of itself**** |
| **Cost isolation** | Off-line operations cannot consume runtime budget |
| **Reproducibility** | **R85.1: off-line analysis over anchored records is reproducible given a declared `policy_version_ref`** |
| **⟵ ⚠️ AND THE COST OF THE BOUNDARY, DECLARED** | **Off-line means LATE. Rollback, survivorship audit, and bias detection all have latency ≥ one epoch, and rollback latency is `O(affected)` off-line. **⟹ A compromised ground-truth source continues to influence beliefs until the off-line rollback completes. That window is bounded by nothing in the architecture — it is bounded by evaluator capacity. §100 OR-M20**** |

---

# §96. CONFORMANCE & TESTABILITY — **OUTPUT 50**

## 96.1 **OUTPUT 50 — the seven conformance test classes**

> ### **R96.0 (THE PREREQUISITE, AND IT IS DECISIVE).** ***Every test of the memory architecture requires a task with ω < 1.*** *P0-01 R5.3: a task with ω = 1 CANNOT test memory or belief maintenance — a memoryless agent performs identically. **⟹ A conformance suite built on fully-observable tasks tests nothing about memory and will pass an implementation with no memory at all.** This is not a testing detail; it is the difference between a suite that validates the architecture and one that validates the harness.*

| Class | **What it tests** | **Requires ground truth?** | **Invariants covered** |
|---|---|---|---|
| **CT-A SCHEMA** | The 31 fields exist with the declared classes; **the seven record-level prohibited fields DO NOT EXIST, and no workspace item carries `relevance`**; the nine `[D]` quantities are not stored | ❌ **NO** | MEM-INV-23, 24, 25; Vol A §5.1's ❌ rows |
| **CT-B STRUCTURAL IMPOSSIBILITY** | **Attempted-violation tests that must fail to be expressible**: modify a record in place · write `evidence_status` from a subject · change `source_class` · widen a `context_scope` · write to a genome · store `n_effective` · return a bare ranked list · wrap `causal_depth` · vote on reconciliation | ❌ **NO** | **The 18 STRUCTURAL invariants (§73.3)** |
| **CT-C INDEPENDENCE** | **⟵ THE MOST VALUABLE CLASS.** Supply a synthetic corpus with KNOWN correlation structure (shared roots, shared lineage, shared instruments, shared upstream, shared time windows) and check that computed `n_effective` matches the known value | ❌ **NO — and this is why it is the most valuable class: *correlation structure is a property of the corpus, not of ℛ*, so the test needs no ground truth about the world** | MEM-M3, MEM-INV-10, 13, 25, 41; Vol B R21.3 |
| **CT-D MONOTONICITY** | Apply every memory operation (store, transform, consolidate, compress, generalize, retrieve, re-publish, merge, split, version) and assert `warrant(op(m)) ≤ warrant(m)`, `n_effective` non-increasing, `inbreeding_F` non-decreasing, `scope` non-widening, `evidence_status` non-increasing-without-a-gate | ❌ **NO** | MEM-M1…M4, MEM-INV-16, 27, 30, 33, 43 |
| **CT-E MACHINE CONFORMANCE** | The six state machines (§74): every transition fires only on its declared trigger; **every INCREASE transition has an external trigger**; every DECREASE may be internal; `UNRESOLVED` is reachable and stable; the four recovery prohibitions hold | ❌ **NO** | MEM-INV-33, 39; §74.3's externality column |
| **CT-F ATTACK REPLAY** | Replay the 78 attacks in Vol D §72 and assert the declared disposition: **58 must be structurally impossible, 2 must be closed only CONDITIONALLY (#3 requires R41.1's content-digest commitment; #64 is closed for reading but open for inference-from-treatment), 12 must be bounded, 3 must be detectable, and 3 must be DECLARED (not defended)** | ⚠️ **PARTIALLY — #41 and #55 require an outcome distribution** | All |
| **CT-G SCALE** | Run at S-1, S-3, S-5 and assert the cost classes in Vol D §56.2's table; assert that **no runtime operation becomes super-linear**; assert the four off-line operations remain off-line | ❌ **NO** | MEM-INV-44, 48; R94.1 |

## 96.2 What is NOT testable, declared

| Untestable | **Why** | **Disposition** |
|---|---|---|
| **Dim-6 independence (#25)** | **No test can distinguish *k* genuinely independent sources sharing a latent assumption from *k* correlated ones — that IS the definition of dim 6** | **DECLARATIVE invariant MEM-INV-11. §100 OR-M5** |
| **Semantic self-reference (#62)** | **§81: all four candidate detectors fail or reduce to U-4** | **DECLARATIVE. §100 OR-M1** |
| **Differential serving by a plausible decline (#56)** | **Vol C R40.2: a decline citing budget, staleness, or scope is indistinguishable from a legitimate one** | **§100 OR-M9** |
| **Authorized-but-self-serving forgetting (#55)** | **Vol C R34.7: a legitimately expired record is indistinguishable from an inconveniently expired one** | **§100 OR-M7** |
| **`W-4 WARRANT` wrongness in a domain with no GT supply** | **Vol D R71.2: detectable only where an L0–L3 measurement exists** | **§100 OR-M4** |
| **Whether a coherently wrong belief is wrong** | **R1.1. ⟵ AND THE STANDARD DOES NOT REQUIRE IT: R81.2** | **§100, and §104's ratings** |

**R96.1 (THE CONFORMANCE VERDICT).** *Seven test classes, **five of which require NO ground truth at all** (CT-A, CT-B, CT-C, CT-D, CT-E, CT-G). **⟹ The architecture's epistemic machinery is directly testable using synthetic correlation and synthetic corpora, without the architecture being right about anything except counting, ordering, and refusing.*** **That is an unusually strong testability position, and it is a consequence of §0.2's four-axis separation: because warrant is a function of declared fields rather than of world-state, it can be tested against synthetic fields.**
**⚠️ And six properties are untestable in principle, and each is registered rather than defended.**

---

# §97. ASSURANCE CASE

## 97.1 The claim, the argument, the evidence

> ### **CLAIM.** *The Digital Brain can accumulate persistent, useful, auditable knowledge **without silently converting an internally generated representation into externally warranted truth** merely because it was remembered, repeated, retrieved, compressed, or widely propagated.*

| Argument | **Evidence** | **⚠️ Residue** |
|---|---|---|
| **A1: Epistemic type is set at entry by an external gate and can only rise by passing another external gate** | **R0.2's tier-admission table (P0-01 §6.3's ladder, wired) · MEM-INV-22 · §74.2's machine with its ceiling column · §74.3's externality column** | — |
| **A2: No internal event may raise a belief** | **Vol B R19.3: eight admissible increases, all external; fifteen prohibited increases, all internal. **⟹ THE SET OF INTERNAL EVENTS THAT MAY RAISE A BELIEF IS EMPTY.** MEM-INV-33** | — |
| **A3: «Remembered» cannot raise warrant** | **MEM-M2 · MEM-INV-04 (storage is not a gate)** | — |
| **A4: «Repeated» cannot raise warrant** | **MEM-M3 · MEM-INV-09/10/12 · Vol A §10.3's four-point closure · Vol B §30** | — |
| **A5: «Retrieved» cannot raise warrant** | **R42.1 (`n_obs += 0`, `causal_depth += 1`) · MEM-INV-01 · §26.2's four separations · §27's triple return** | **⚠️ §26.3: it can change what is CONSIDERED. OR-M6** |
| **A6: «Compressed» cannot raise warrant** | **MEM-M2 · R33.2 (compression is warrant-neutral and scope-neutral) · DP-1…DP-10 · R14.2's trace demotion** | — |
| **A7: «Widely propagated» cannot raise warrant** | **MEM-M3 · Vol B §21.4's re-emission rule · dim-1 collapse · X4's `root_commit`** | **⚠️ #25 dim 6. OR-M5** |
| **A8: «Propagated» cannot become independent evidence** | **Vol A §10.3 · §15.2's D-2/D-3 · R68.1 (merge must not hide roots) · MEM-INV-41 (quota on `n_effective`)** | **⚠️ #25 dim 6** |
| **A9: History cannot be rewritten** | **MEM-INV-06/37/38 · SP-1/SP-7 · §42.1's four vectors all closed or bounded · FM-3's Merkle root** | **⚠️ #78: a compromised KC can authorize a deletion. **It cannot conceal it**** |
| **A10: Knowledge is never a stored object** | **Vol A R4.1's `KNOWS` predicate · MEM-INV-23 · §4.2's four arguments (no admissible writer)** | — |
| **A11: Truth is never an architectural object** | **Vol A R4.2 · §3's prohibition on «fact» · MEM-INV-28 (L7 prohibited)** | — |
| **A12: Ignorance is representable** | **§39.2's six kinds · §25.3's four empty reasons · §63.1's six revalidation states · P0-01 R9.1 compliance** | **⚠️ IG-6's unknown-unknowns are representable but not detectable** |
| **A13: Contradiction is survivable** | **MEM-INV-31/32 · §20.4's eight exits including `UNRESOLVED` · §20.3's seven types · Vol B R20.2** | — |
| **A14: Acquired memory cannot become inherited genome** | **MEM-INV-18/19/20/21 · §47.3's Baldwin analysis** | **⚠️ OR-M12: priors are shaped statistically by what was learned and carry no `source_class`** |
| **A15: Memory is not a governance authority** | **Vol A R8.1's four prohibitions · MEM-INV-40 · §43.1 R43.1 · §51.2's workspace prohibitions** | — |
| **⚠️ A16: THE SYSTEM DETECTS ITS OWN UNFALSIFIABLE VOCABULARIES** | **⟵ NO EVIDENCE EXISTS** | **❌ **THE CLAIM IS NOT MADE.** §81, OR-M1** |
| **⚠️ A17: THE SYSTEM'S FILTERING CANNOT BIAS ITS OWN SELECTION** | **⟵ MEM-D1…D6 DETECT; R46.4 PROHIBITS THE DIRECT PATH** | **❌ **CD-M8/CD-M9 ARE UNCLOSED.** OR-M2, OR-M18** |

**R97.1 (THE ASSURANCE VERDICT).** *Fifteen arguments are fully evidenced. **Two (A16, A17) are not made, and the architecture does not claim them.*** **⟹ The gap between A1–A15 and A16–A17 is exactly the gap between the brief's stated standard and a stronger standard nobody asked for: the brief requires that internal representations not be *silently converted* into externally warranted truth, and A1–A15 establish that. A16 and A17 would require the system to audit its own vocabulary and its own attention, and §81/§83 establish that no mechanism in the architecture can do either.**

---

# §98. ABLATION — **OUTPUT 47**

## 98.1 **OUTPUT 47 — the fourteen ablations**

| # | **Remove** | **What breaks** | **What does NOT break** | **Verdict** |
|---|---|---|---|---|
| **AB-1** | **`evidence_status`** | **R0.2's admission principle. §1's loop CLOSES: an E0 record is retrievable and citable alongside an E4 record, and tier becomes a storage convenience rather than an epistemic gate** | Retrieval still works | ❌ **CATASTROPHIC — THE SINGLE MOST LOAD-BEARING FIELD** |
| **AB-2** | **`source_class`** | **MEM-INV-02. Attacks #26–#29, #36–#40 all reopen — twelve attacks** | Provenance still resolves | ❌ **CATASTROPHIC** |
| **AB-3** | **`root_commit`** | **MEM-INV-03, dim-1 independence, dedup D-2, #2/#3/#18/#22/#23/#50. `n_effective` becomes uncomputable** | Storage still works | ❌ **CATASTROPHIC** |
| **AB-4** | **`corr_class`** | **Dims 2–5. `n_effective` collapses to dim-1-only, so lineage-, instrument-, upstream-, and time-correlated sources count as independent** | — | ❌ **SEVERE** |
| **AB-5** | **`inbreeding_F`** | **FM-4, MEM-M4, #15/#61, L-5, the S6 abstention gate** | Provenance self-reference is still bounded by `causal_depth` | ❌ **SEVERE** |
| **AB-6** | **`context_scope`** | **MEM-INV-29/30, #13/#68/#69, CT-4's decidability, R32.2's scope intersection ⟹ generalization becomes unbounded in scope** | — | ❌ **CATASTROPHIC** |
| **AB-7** | **`validity` intervals** (replaced by a timestamp) | **CT-3's decidability ⟹ every change over time is reported as a contradiction. MEM-INV-32's scoped contradiction. `EXPIRED` vs `UNSUPPORTED`** | — | ❌ **SEVERE — and this is X1's resolution demonstrated: V3's `timestamps` fix would have caused this** |
| **AB-8** | **The claim graph (V4/F)** | **Contradiction has no representation (§20). Supersession has no representation (§36). VOID propagation has no path (R42.2). Derived-record invalidation has no path (R87.2)** | Storage and retrieval still work | ❌ **CATASTROPHIC for epistemics; harmless for performance** |
| **AB-9** | **ALL indexes and views (V1–V4, I-1…I-5)** | **Retrieval becomes a full scan: `O(n)`. Performance collapses** | **⟵ `evidence_status`, `belief_state`, `n_effective`, `inbreeding_F`, `KNOWS`, and EVERY contradiction record are UNCHANGED** | ⚠️ **PERFORMANCE ONLY — AND THIS IS §57's SEPARATION DEMONSTRATED (Vol D R57.2)** |
| **AB-10** | **I-3 (vector/similarity index) only** | Recall for semantic queries | **Everything epistemic. ⟵ Vol A §2.3's G row: six structural failures, and none of them is a performance failure** | ⚠️ **RECALL ONLY — the strongest evidence that G is a convenience, not a component** |
| **AB-11** | **The Contradiction Detector** | **Contradictions are either suppressed or averaged. MEM-INV-31/49 unenforceable. CD-M1's ladder closes** | — | ❌ **CATASTROPHIC** |
| **AB-12** | **The Anchor** | **MEM-INV-03, SP-1/SP-2/SP-7, R35.1, §37's integrity, every audit question in §84.1. **⟵ P0-02 §6.1 item 19: «the classic error»** | Local storage | ❌ **TOTAL** |
| **AB-13** | **§31's consolidation gates G1–G4** (contradiction-first, inbreeding, external quota, dependency-selection) | **L-3's consolidation self-justification reopens. #43/#47. Synthetic-data drift becomes undetectable (Vol D §66.2)** | Consolidation still produces derived records | ❌ **SEVERE** |
| **AB-14** | **§32's four bounding rules R32.1–R32.4** | **Generalization becomes §1's loop's most dangerous single operation: 40 weak instances ⟹ one strong, broad rule (Vol B §32.2's worked example). #44/#45/#46** | — | ❌ **CATASTROPHIC** |

## 98.2 The ablation's two findings

> ### **R98.1 (FINDING 1 — THE ASYMMETRY).** *Twelve of fourteen ablations are epistemically catastrophic. **Two (AB-9, AB-10) are performance-only.*** **⟹ And the two that are performance-only are exactly the two that involve INDEXES. That is §57's separation, established by ablation rather than assertion: the epistemic content of the architecture lives entirely in the records, the gates, the graph, and the Anchor — and not at all in the retrieval machinery.**

> ### **R98.2 (FINDING 2 — NO REDUNDANCY, AND ITS LIMIT).** *No ablation is harmless. **⟹ Under §76.1's minimality test, every mechanism is load-bearing against a named invariant or attack.*** **⚠️ AND THE LIMIT, STATED AS IN VOL E R76.2: «no ablation is harmless» establishes that nothing is REDUNDANT. It does not establish that nothing SMALLER exists — a mechanism could be load-bearing and still be replaceable by a smaller one that carries the same load. **§76.2's enumerations (fourteen source classes, twelve belief states, seven contradiction types, six ignorance kinds, thirty-one fields) are argued element-by-element and no element is shown redundant, but "no element is redundant" is not "no smaller enumeration exists".** §99 records the distinction as a false-precision temptation resisted.*

---

# §99. FALSE PRECISION AUDIT

## 99.1 The audit

**«Do not use false numerical precision» (Task 6) · «mark UNRESOLVED rather than invent false precision» (Task 3 Rule 18).**

| # | Temptation | **What a false-precision answer would look like** | **What this package says instead** |
|---|---|---|---|
| **FP-1** | **A value for `F_max`** | «`F_max = 0.3`» | **`[G]`, no value. Vol E U-7: «no principled derivation.» And Vol B L-5's residue: an ANCHORED internally-generated evidence set has a low measured `F` — the anchor attests provenance, not externality of origin** |
| **FP-2** | **A value for `θ_support`** | «`n_effective ≥ 3`» | **`[G]`, no value** |
| **FP-3** | **A value for `epoch_length`** | «1 second» / «1000 messages» | **`[G]`, no value — **and Vol E §75.2 explains why this one parameter has four inseparable meanings (provenance latency, lie-window, contradiction latency, consistency grain), so any value is a four-way trade-off with no derivable optimum**** |
| **FP-4** | **A value for `PROTECTED_FRACTION_MAX`** | «20%» | **`[G]`, no value. Vol C R34.4: «no principled derivation exists.» OR-M13** |
| **FP-5** | **A value for `W_min`** | «3» | **`[G]`, inherited from P0-02 without a value** |
| **FP-6** | **A maximum abstraction depth** | «depth ≤ 5» | **Vol D §69.2: **NO MAXIMUM IS IMPOSED AND NONE IS NEEDED.** R69.1's monotonicity means depth *d* has warrant ≤ MIN over all leaves, so deep hierarchies are automatically inert. **A bound here would be false precision: the monotonicity already does the work**** |
| **FP-7** | **`causal_depth`'s maximum as a design choice** | «we chose 255 because it is enough» | **Vol A R13.3: 255 is **DERIVED FROM THE TYPE (`u8`)**, and the epistemic argument is that **warrant attenuates to inertness well before depth 10**, so the width is not the binding constraint. `u16`'s wider range was specifying precision the epistemics cannot use** |
| **FP-8** | **⚠️ The retention curve's functional form** | **`retention(t) = exp(−Δt/τ) × importance`** | **⟵ THIS ONE IS INHERITED, AND IT IS FALSE PRECISION IN THE SOURCE DOCUMENT. Vol E U-3: **the exponential form has no derivation, no measurement, and no compared alternative — and it multiplies by `importance`, which is itself U-2 (G-P1-8: «the function is not defined»).** ⟹ An invented functional form multiplied by an undefined function. **P0-04 does not adopt the form; it adopts the ROLE (a monotone-decreasing retention weight) and marks the form `[U]`. OR-M16**** |
| **FP-9** | **A probability for «how likely is a dim-6 collision»** | «p < 0.01» | **Vol B R21.1: dim 6 is **NOT DETECTABLE FROM INSIDE**, so its incidence is not estimable from inside either. **An estimate would require the external diversity the estimate is supposed to justify**** |
| **FP-10** | **A count of «how many attacks are closed»** | — | **⚠️ Vol D §72.2 DOES give counts (58 closed + 2 conditionally closed, 12 bounded, 3 detectable, 3 open = 78). **This is not false precision: each attack is individually enumerated with an individually named defense and an individually declared disposition, and the count is a tally, not an estimate. The counts would be false precision only if the dispositions were**** |
| **FP-11** | **A complexity figure for the whole system** | «`O(log N)` overall» | **Vol D §56.2 gives PER-OPERATION costs and Vol D §56.3 + §94.1 C-5 declare the two operations that do not scale. **An aggregate figure would hide both**** |
| **FP-12** | **A confidence value anywhere** | «confidence = 0.87» | **MEM-INV-24: no scalar confidence exists. Vol B §18.1's sufficient statistics, every one of which has a declared producer and writer** |
| **FP-13** | **A definition of `importance`** | Any specific formula | **U-2. **The ROLE is bounded (MEM-INV-50: allocation only, homeostasis-computed, never epistemic) and the CONSEQUENCES are monitored (MEM-D1/D2/D4/D5/D6) — but the DEFINITION remains open, inherited as G-P1-8**** |
| **FP-14** | **A measure of semantic self-reference** | Any specific formula | **U-1. §81 evaluates four candidates and all four fail or reduce. **Marked `[U]` rather than invented — which is exactly what Task 3 Rule 18 requires**** |
| **FP-15** | **«The hybrid has six components because six is optimal»** | — | **Vol A §2.4: six is the smallest hybrid that satisfies all fourteen criteria, **AND §76 RECORDS THAT MINIMALITY OF THE COUNT IS NOT PROVEN — ONLY THAT FIVE FAILS.**** |
| **FP-16** | **Ratings as numbers** | «PROVENANCE: 8.5/10» | **§104 uses seven STATUSES, not scores. A score would imply a scale nobody has defined** |

## 99.2 The audit's finding

> ### **R99.1.** *Sixteen false-precision temptations were identified. **Fifteen are resisted by declaring `[G]`, `[U]`, or `[D]` and giving no value. One (FP-8) is false precision INHERITED FROM THE SOURCE DOCUMENT, and P0-04 does not adopt it — it adopts the role and marks the form `[U]`.***
>
> **⟹ AND THE META-FINDING: the parameters this package refuses to value are precisely the parameters that determine the architecture's BEHAVIOURAL disposition — `F_max` (how much self-reference before abstention), `θ_support` (how much evidence before belief), `epoch_length` (how long a lie may go unwitnessed), `PROTECTED_FRACTION_MAX` (how much history before ossification). **⟹ These are not engineering constants. They are value judgements with epistemic consequences, and inventing values for them would be inventing the architecture's disposition toward doubt. §90's conservatism analysis is what makes the consequence visible: a system tuned toward low `F_max` and high `θ_support` abstains; a system tuned the other way overclaims; and neither tuning is derivable from the architecture.***

---

# §100. OPEN RESEARCH REGISTER — **OUTPUT 52**

## 100.1 **OUTPUT 52 — the twenty open items**

| ID | Open problem | **What is known** | **What is not** | **Blocking?** | **Where** |
|---|---|---|---|---|---|
| **OR-M1** | ⚠️ **SEMANTIC SELF-REFERENCE — P0-04'S PRINCIPAL UNCLOSED DEPENDENCY** | The role of a measure; that `inbreeding_F` and `causal_depth` bound the PROVENANCE form and neither bounds the SEMANTIC form; that a semantic circle defeats all four FM-4 defenses (§81.2) | **No rigorous mechanism. Four candidates evaluated (§81.3): C-1 requires a forgeable self-declaration checked by a non-portable oracle; C-2 reduces to U-4; C-3 is infeasible and unsound; **C-4 (external vocabulary anchoring) is the most promising — it is an admission GATE rather than a detector, in the spirit of R0.2 — but it presupposes that "term" and "definition" are well-defined, which is U-4**** | **❌ YES — blocks attack #62, invariant group I's completeness, and §104's EVIDENCE-INDEPENDENCE rating** | Vol A §5.1 `[U]` · Vol B §29.1 L-10 · Vol C §48.2 · Vol D #62 · Vol E U-1 · §81 |
| **OR-M2** | **ATTENTION / FILTERING — a subject can choose what to notice** | MEM-D1…D6 detect SYSTEMATIC filtering at `O(R)` per epoch by comparing input to output distributions (R28.1) | **Occasional filtering, and filtering that keeps aggregate statistics plausible, are undetected. **And the INHERITED case — a subject whose input distribution is itself biased because its upstream peers filter — shows no divergence at all**** | ⚠️ Partial | Vol A §11.4 R11.4 · Vol B §28.1 B-5 · Vol D #17 · Cell audit L1832 |
| **OR-M3** | **SEMANTIC CLAIM IDENTITY ACROSS TIME** | Structural identity is decidable. R15.3's conservative fallback (two claims + `POSSIBLY_SAME_CLAIM`) is defined and safe | **Semantic identity is undecidable in general. CT-6, DR-2, and CD-M6 all depend on it. **And DR-2's semantic drift is undetectable and compounds across every aggregation**** | ⚠️ Partial — CD-M6 is closed by degradation | Vol A R15.3 · Vol B CT-6 · Vol D §60.1 DR-2 · Vol E U-4 · §83 CD-M6 |
| **OR-M4** | **UNCALIBRATABLE DOMAINS** | R18.4: a domain with no L0–L3 ground-truth supply cannot reach E4, so its calibration is UNMEASURABLE and MUST be recorded `UNRESOLVED` (§39.2 IG-4) | **Whether a domain SHOULD have a ground-truth supply is a task-design question the architecture cannot answer. **And Vol D R71.2's W-4: warrant wrongness is undetectable where no measurement exists**** | ❌ No — but it bounds §104's ratings | Vol B R18.4 · Vol D R71.2 · §82.3 R82.1 |
| **OR-M5** | **DIM 6 — SHARED LATENT ASSUMPTION** | Four mitigations: instrument-CLASS diversity · `gt_class` diversity · R4.3's `M_ℰ` prohibition · declaration | **None detects an assumption shared by the TASK SPECIFICATION ITSELF — which is unclosable from inside by construction, because the assumption is shared precisely because it is in the thing doing the assuming** | ❌ No — it is the program-level limit | Vol B R21.1 · Vol D #25 · §39.3 · MEM-INV-11 |
| **OR-M6** | **EXPLORATION / RETRIEVAL COUPLING** | §26.3's three blocks stop the attractor from changing what is BELIEVED | **They do not stop it from changing what is CONSIDERED. A hypothesis never retrieved is never tested and stays `HYPOTHESIS` forever — not a false belief, but a permanent gap. **R90.1's optimism budget is a counterweight, not a closure**** | ❌ No | Vol B §26.3 · Vol D §65.2 · §90.3 |
| **OR-M7** | **SURVIVORSHIP NARROWING** | Vol C R34.7: the COUNT and ROOTS of forgotten records survive permanently in epoch digests; deletion AUTHORITY and REASON are permanent (§35.4) | **Content below L2 is unrecoverable. **And authorized-but-self-serving forgetting is indistinguishable from legitimate expiry**** | ❌ No | Vol C §34.7 · Vol D #55 |
| **OR-M8** | **UNCONDITIONAL ERASURE vs R35.1** | Vol C §35.3's split: CONTENT may be erased irreversibly; the ANCHORED FACT is permanent | **If the erasure requirement extends to metadata — if existence itself must be deniable — then R35.1 and erasure are INCOMPATIBLE and one must yield. **This package's position: R35.1 yields only under an explicit, externally-authorized, `[G]`-declared exception class, and every exception is itself anchored. ⟹ THE ARCHITECTURE CANNOT SATISFY UNCONDITIONAL ERASURE, AND SAYS SO**** | ❌ No — it is a declared incompatibility | Vol C §35.3 |
| **OR-M9** | **DIFFERENTIAL SERVING** | Vol C R40.2: declines are logged; `purpose_class` filters are policy-declared and auditable; per-reader distribution divergence is detectable at `O(R)` (OBS-11) | **A PLAUSIBLE decline — citing budget, staleness, or scope — is not detected. **The mechanism is inside the thing being audited**** | ❌ No | Vol C §40.4 · Vol D #56 |
| **OR-M10** | **SOURCE MIS-DECLARATION AT ORIGIN** | R12.1 blocks RE-classification. Three detectors: derived `src_identity` · repeated SC-2 assertions failing E4 grounding ⟹ calibration failure ⟹ «reduce trust, route verification elsewhere» · MEM-D4's distribution divergence | **A subject that declares SC-2 for what is SC-7, occasionally and within its calibration tolerance, is not detected. **Prevention would require the architecture to know what the subject observed, which is the thing in question**** | ❌ No | Vol D #41 |
| **OR-M11** | **CONSERVATISM INDUCTION VIA GENUINE FAILURE RECORDS** | Vol C R34.3: creating a `failure_record` requires E2 attribution, so fabrication is blocked (FM-2) | **A compromised subject producing a TRUE report of a failure IS admissible. **Defense is MEM-D4 + R90.1's optimism budget, not prevention. **And R90.4's asymmetry: the architecture is more robust to poison than to censorship, because a false positive is detectable and a false negative is not**** | ❌ No | Vol C §41.2 P-1 · §90.5 |
| **OR-M12** | **THE BALDWIN CHANNEL CARRIES NO PROVENANCE** | Vol C §47.3: what is selected is the CAPACITY to acquire, never what was acquired; the channel passes through external fitness at every generation | **A structural prior IS shaped statistically by what was learned. **A lineage raised where X was always true evolves priors tuned to X — not a record of X, not a belief that X, but a disposition that makes X-shaped hypotheses cheaper. **AND PRIORS CARRY NO `source_class`, SO THERE IS NO FIELD ANYWHERE THAT RECORDS THIS.** A prior tuned by a false regularity is a well-adapted lineage in a changed environment**** | ❌ No | Vol C §47.3 |
| **OR-M13** | **PROTECTION PERMANENCE vs STORAGE FINITUDE** | Vol C R34.4: `PROTECTED_FRACTION_MAX` + deny-new-never-revoke + KC-3 request-rate ceiling + increased pressure on RC-1/RC-2 only | **No principled value for the ceiling. **And the consequence at S-5: a sufficiently old organism must choose between forgetting safety records and refusing new ones. **NOT CLOSABLE**** | ❌ No — declared trade-off | Vol C R34.4 · Vol D §56.3 · Vol E U-5 |
| **OR-M14** | **THE FINITE EPISTEMIC HORIZON AT S-5** | Vol C R42.3: either the online root registry grows without bound (infeasible) or records lose anchorability over time (correct). The W4/W5 off-line archive is the escape hatch at `O(1)` per lookup, evaluator-side | **No principled value for `online_root_registry_window`. **⟹ AND THE REFRAMING: this is not a failure. Old evidence IS progressively less revalidatable, so its reduced usability for consequential decisions is honest rather than lossy**** | ❌ No — a hard scale limit | Vol C §42.3 · Vol D §56.3 · Vol E U-6 |
| **OR-M15** | **AGENT-MODEL INFERENCE FROM TREATMENT** | R59.2: an agent model is in the MODELER's compartment, never the modeled subject's | **A subject can INFER that it is modeled, and approximately what the model says, from the treatment it receives. **Inference from treatment is not reading, and cannot be prevented without preventing the model from having any effect — which would make it pointless**** | ❌ No | Vol C §59.2 · Vol D #64 |
| **OR-M16** | **THE RETENTION-CURVE FUNCTIONAL FORM** | The ROLE is defined (a monotone-decreasing retention weight). Vol E U-3 marks the form `[U]` | **`exp(−Δt/τ) × importance` is inherited from V3/Cell with **no derivation, no measurement, and no compared alternative** — and it multiplies by `importance`, which is U-2. **⟹ AN INVENTED FUNCTIONAL FORM MULTIPLIED BY AN UNDEFINED FUNCTION. P0-04 adopts the role, not the form**** | ❌ No | Vol E U-3 · §99 FP-8 |
| **OR-M17** | **ANCHORED INTERNAL EVIDENCE HAS LOW `inbreeding_F`** | Vol B L-5: `F` is Anchor-computed and read-only, and `F > F_max ⟹ S6 abstain` | **A subject whose evidence is internally generated but ANCHORED has a low measured `F` — **the anchor attests PROVENANCE, not EXTERNALITY OF ORIGIN.** So `F` bounds provenance self-reference and does not bound origin self-reference. **⟹ This is OR-M1's provenance-layer shadow: the same gap between provenance and meaning**** | ❌ No | Vol B §29.1 L-5 · Vol E U-7 |
| **OR-M18** | ⚠️ **THE SELECTION ⟷ FILTERING CIRCLE (CD-M8/CD-M9)** | **R46.4 prohibits consistency-of-corpus as a selection criterion (removes the DIRECT path). MEM-D1…D6 detect (not prevent). R90.1's optimism budget counteracts the conservatism direction** | **⟵ UNCLOSED, AND NOT CLOSABLE: every arrow in the circle is legitimate and breaking any one breaks something the architecture needs (§83.1). **The criterion IS external and unbiased, and it is still driven by the internal filtering, because the behaviour being measured IS a function of the corpus that produced it.** ⚠️ And §93.1's note: the optimism budget counteracts over-filtering-toward-doubt while CD-M8 favours over-filtering-toward-action — **the two partially cancel, and the cancellation is a coincidence of two independent defenses, not a design. The net direction is not determined**** | **❌ YES — the fourth unclosable circular dependency in the P0 series** | §83 CD-M8/CD-M9 · §90.3 · §93.1 |
| **OR-M19** | ⚠️ **THE ABSTENTION CASCADE (L-11)** | **R90.2: bounded by the availability of NON-ACTION-DEPENDENT ground truth (L2 physical measurement does not depend on the organism acting)** | **A task whose `source_classes` contain ONLY L6 has no non-action-dependent ground truth, so abstention starves the only external gate, `F` rises monotonically, and the system converges to total abstention. **⟹ R90.3: A SINGLETON-{L6} `source_classes` DECLARATION IS A DECLARED HAZARD, and P0-01 R8.1's declaration requirement is the hook**** | ⚠️ Partial | §90.4 · Vol B §29.1 (the loop Vol B missed) |
| **OR-M20** | **ROLLBACK LATENCY IS BOUNDED BY EVALUATOR CAPACITY, NOT BY THE ARCHITECTURE** | Vol B R19.4 + §95.2: rollback is off-line, `O(affected)`, computed from the Anchor's root registry | **A compromised ground-truth source continues to influence beliefs until the off-line rollback completes. **That window is bounded by nothing in the architecture.** P0-01 R9.4 requires the rollback; §95 requires it to be off-line; **the two together mean the rollback is correct and late, and there is no third option**** | ❌ No — declared | Vol B R19.4 · §95.2 |

## 100.2 The register's shape

> ### **R100.1.** *Twenty open items: **two blocking (OR-M1, OR-M18), three partial (OR-M2, OR-M3, OR-M19), fifteen declared-and-non-blocking.***
>
> **⟹ AND THE TWO BLOCKING ITEMS ARE THE SAME SHAPE, WHICH IS THE PACKAGE'S CENTRAL NEGATIVE RESULT:**
> - **OR-M1** — *a circle in MEANING that has no provenance signature*
> - **OR-M18** — *a circle in SELECTION that has no external signature*
>
> **In both, the mechanism is inside the thing being audited. In both, the architecture bounds the CONSEQUENCES (MEM-INV-46 and the E3→E4 external gate for OR-M1; R46.4 and MEM-D1…D6 for OR-M18) without closing the LOOP. In both, the residue is declared rather than defended.**
>
> **⟹ AND BOTH ARE INSTANCES OF THE PROGRAM-LEVEL LIMIT, WHICH NOW HAS FIVE RECORDED APPEARANCES: P0-02's KC self-reference · P0-03's CD-C8 and CD-C12 · the Cell Contract's FM-4 `[U]` · P0-04's OR-M1 and OR-M18. **An instrument cannot fully audit the mechanism by which the instrument's subject determines what the instrument is shown.***

---

# §101. GAP REGISTER — **OUTPUT 51**

## 101.1 **OUTPUT 51 — P0 / P1 / P2 gaps**

### **P0 — MUST BE RESOLVED BEFORE IMPLEMENTATION**

| ID | Gap | **Why P0** | **Status** |
|---|---|---|---|
| **G-M-P0-1** | ⚠️ **No measure of semantic self-reference exists** (OR-M1) | **Attack #62 is OPEN. A closed semantic circle defeats every defense in Volumes A–E, is unfalsifiable from inside, and is exactly R1.1's «coherently wrong belief with valid provenance». **⟹ P0 because §104's EVIDENCE-INDEPENDENCE rating cannot exceed PARTIAL until it is addressed, and because C-4 (external vocabulary anchoring) requires deciding what a "term" and a "definition" are — which is a schema decision, and schema decisions cannot be deferred past implementation**** | **❌ OPEN. §81.3's C-4 is the bounded candidate** |
| **G-M-P0-2** | ⚠️ **The selection ⟷ filtering circle is unclosed** (OR-M18) | **CD-M8/CD-M9. Evolutionary selection is driven by behaviour that is a function of a corpus the selected policy produced. **⟹ P0 because it is a CROSS-PACKAGE dependency: closing it requires P0-01's fitness definition, P0-02's selection governance, and P0-04's retention policy to be co-designed, and no single package can close it**** | **❌ OPEN. Three partial mitigations (R46.4, MEM-D1…D6, R90.1)** |
| **G-M-P0-3** | **`importance` is undefined** (U-2, inherited G-P1-8) | **⟹ P0 NOT because `importance` is epistemically load-bearing — MEM-INV-50 removed it from every epistemic path — but because it IS load-bearing for ALLOCATION: M-A eviction, consolidation scheduling (G4), and the retention curve (U-3) all consume it, and an implementation must compute something. **⟹ The ROLE is fully specified; the DEFINITION is not, and an implementer would have to invent one, and whatever they invent becomes the architecture's attention policy by default**** | **❌ OPEN — role bounded, definition missing** |
| **G-M-P0-4** | **The retention-curve functional form is unjustified** (U-3, FP-8) | **⟵ INHERITED FALSE PRECISION: `exp(−Δt/τ) × importance` has no derivation and multiplies an undefined function. **P0 because it is a concrete formula an implementer would copy verbatim**** | **❌ OPEN — P0-04 adopts the role, marks the form `[U]`** |
| **G-M-P0-5** | **R41.1's content-digest commitment is a NEW REQUIREMENT on the Anchor** | **Vol C §41.1: provenance laundering (#3) is closed ONLY IF the Anchor's root registry commits to a CONTENT DIGEST, not only to an identity. **⟹ P0 because it is a requirement this package IMPOSES ON P0-02's Anchor, and P0-02 did not state it. If the registry commits only to identities, #3 is open**** | **⚠️ NEW REQUIREMENT — must be ratified against P0-02 §20.2** |
| **G-M-P0-6** | **MEM-INV-14's saturation semantics are a NEW REQUIREMENT on P0-03's `causal_depth`** | **Vol A D-3: a wrapping `u8` inverts its own purpose — depth 256 reads as depth 0 and looks primary. **⟹ P0 because P0-03 specified the field and not the saturation behaviour, and memory makes the wrap reachable (a record persists across many re-derivations while a message does not)**** | **⚠️ NEW REQUIREMENT — must be ratified against P0-03 X-D** |

### **P1 — SHOULD BE RESOLVED BEFORE DEPLOYMENT**

| ID | Gap | **Why P1** |
|---|---|---|
| **G-M-P1-1** | **Semantic claim identity across time** (OR-M3) | R15.3's conservative fallback works and is safe; it inflates the claim count and reduces `n_effective` per claim, which is the conservative direction. **Degradation, not failure** |
| **G-M-P1-2** | **`PROTECTED_FRACTION_MAX` and `online_root_registry_window` have no principled values** (OR-M13, OR-M14) | Both are declared trade-offs with correct *behaviour* and unknown *setpoints*. **Deployment requires values; the architecture does not** |
| **G-M-P1-3** | **Differential serving within an epoch** (OR-M9) | Bounded by logging and detectable in aggregate; a plausible decline is undetected |
| **G-M-P1-4** | **Source mis-declaration at origin** (OR-M10) | Detectable via calibration failure and MEM-D4; not preventable |
| **G-M-P1-5** | **Conservatism induction via genuine failure records** (OR-M11) | R90.4's asymmetry: the architecture is more robust to poison than to censorship |
| **G-M-P1-6** | **Rollback latency bounded by evaluator capacity** (OR-M20) | Correct and late; no third option |
| **G-M-P1-7** | **The abstention cascade in L6-only tasks** (OR-M19) | **R90.3 makes it a DECLARED HAZARD in the task specification, which is a P0-01 interface requirement rather than a P0-04 gap** |
| **G-M-P1-8** | **Cross-region contradiction latency is indefinite when no query spans regions** (Vol B §58.2 R58.1 LEVEL 3) | **Not a defect — R54.1 argument 2 says divergent belief states are legitimate. But a deployment should know it** |
| **G-M-P1-9** | **Baldwin-channel priors carry no `source_class`** (OR-M12) | No field records that a prior was shaped by a false regularity |
| **G-M-P1-10** | **Agent-model inference from treatment** (OR-M15) | Unavoidable without making models ineffective |

### **P2 — RESEARCH AGENDA**

| ID | Gap |
|---|---|
| **G-M-P2-1** | **Dim 6 / shared latent assumption** (OR-M5) — the program-level limit; four mitigations, no detection |
| **G-M-P2-2** | **Unknown-unknowns** (§39.3) — representable as conditions, not detectable as instances |
| **G-M-P2-3** | **Unconditional erasure vs audit permanence** (OR-M8) — a declared incompatibility, not a gap |
| **G-M-P2-4** | **Exploration/retrieval coupling** (OR-M6) — what is CONSIDERED is influence-plane and unbounded |
| **G-M-P2-5** | **Survivorship narrowing content recovery** (OR-M7) — counts and roots survive; content does not |
| **G-M-P2-6** | **Anchored internal evidence has low `inbreeding_F`** (OR-M17) — the anchor attests provenance, not externality of origin |
| **G-M-P2-7** | **Emergent vocabulary as a governance bypass** (§93.1) — reduces to OR-M1 |
| **G-M-P2-8** | **Semantic drift detection** (DR-2) — undetectable in principle; scoping is a mitigation |
| **G-M-P2-9** | **Whether T2/T4 are epistemic necessities or scale necessities** (Vol E R77.2) — V-E shows they are the latter, which means §31–§33's risk is a price paid for scale |
| **G-M-P2-10** | **A smaller enumeration** (Vol E R76.2, §98.2 R98.2) — no element is shown redundant, but "no redundancy" is not "no smaller set" |

## 101.2 The gap register's shape

> ### **R101.1.** ***Six P0 gaps, ten P1, ten P2.***
>
> **⟹ AND THE COMPOSITION OF THE P0 LIST IS THE FINDING:**
> - **Two are genuinely unclosable** (G-M-P0-1, G-M-P0-2) — OR-M1 and OR-M18, the two blocking research items.
> - **Two are inherited undefined quantities** (G-M-P0-3, G-M-P0-4) — `importance` and the retention curve, both from the Cell Contract / V3, both bounded in ROLE by this package and neither defined.
> - **⚠️ TWO ARE NEW REQUIREMENTS THIS PACKAGE IMPOSES UPSTREAM** (G-M-P0-5, G-M-P0-6) — the Anchor's content-digest commitment (on P0-02) and `causal_depth`'s saturation semantics (on P0-03). **⟹ These are the most actionable items in the register, because they are closable by ratification rather than by research: each is a one-sentence addition to an existing specification, and each closes a named attack (#3 and D-3 respectively) that would otherwise be open.**
>
> **⟹ NO P0 GAP IS A MISSING MECHANISM IN THE MEMORY ARCHITECTURE ITSELF.** The memory layer's own mechanisms are complete against the standard the brief set. The P0 list consists of two unclosable limits, two inherited undefined quantities, and two upstream ratifications — **and that composition is the strongest available evidence for §104's CONTRACT/PASS rating.**

---

*End of Volume F. The canonical specification is `38_v4_memory_knowledge_provenance_belief_spec.md` (**Output 53**). The executive verdict (**Output 1**), the candidate comparison summary (**Output 2**), the §102 seventeen-dimension ratings, the §103 principles, and the §104 FINAL STANDARD are in `README.md`.*
