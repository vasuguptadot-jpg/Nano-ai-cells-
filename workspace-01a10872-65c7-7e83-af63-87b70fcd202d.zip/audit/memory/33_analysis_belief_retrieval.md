# P0-04 — MEMORY, KNOWLEDGE, PROVENANCE & BELIEF ARCHITECTURE
## Volume B: Belief, Independence, Retrieval, Consolidation & Compression (§17–§33)

**Package:** P0-04. **Mode:** ARCHITECTURE ONLY.
**Companions:** Vol A `32_…object_authority.md` (§0–§16) · Vol C `34_…lifecycle_interfaces.md` (§34–§55) · Vol D `35_…scale_cognition_attacks.md` (§56–§72) · Vol E `36_…formal_specification.md` (§73–§80) · Vol F `37_…audit_testability.md` (§81–§101) · Canon `38_…spec.md` (**O53**) · `README.md` (**O1, O2**, §99, §102–§104)
**Outputs delivered here:** **20** (evidence-independence model) · **21** (belief-state model) · **22** (confidence/uncertainty representation) · **23** (belief-update architecture) · **24** (contradiction architecture) · **25** (temporal/contextual memory model) · **26** (retrieval architecture) · **27** (retrieval/truth separation) · **28** (consolidation architecture) · **29** (generalization architecture)

> **Volume B is the heart of the package.** §1's dangerous loop has exactly one step that is not a communication event and not an evidence-gate event: **«belief strengthening»**. Everything below exists to make that step unreachable from inside memory.

---

# §17. BELIEF ARCHITECTURE — **OUTPUT 21**

## 17.1 Should belief be first-class?

**Vol A §4.4 already answered: YES, as a composite — claim + belief state + `n_effective` + `inbreeding_F` — and NO as a stored scalar.**

The remaining question is whether **belief state** deserves to be first-class, and the test is Vol A R6.0's: *does it have a distinct retention class, access class, consistency mode, or admission gate?*

| Test | Answer |
|---|---|
| Distinct **gate**? | ✅ **Yes — and it is the strongest gate in the system.** P0-01 **R9.3: confidence MUST NOT increase in any ground-truth state other than {0, 1, 8}.** A belief-state transition is gated on an *external* quantity (GT state) that the belief's owner cannot produce |
| Distinct **consistency**? | ✅ **Yes — causal, not strong.** Two regions may hold different belief states about the same claim at the same instant, and that is legitimate: they have different evidence. **Forcing agreement would be forcing belief by consensus, which is L7** |
| Distinct **access**? | ✅ **Yes — a belief state is readable by anyone who may read the claim, but writable only by the organism's belief-maintenance component, never by the storing subject** |
| Distinct **retention**? | ⚠️ Partially — belief states are retained with their claim, but a *history* of belief states is a separate, bounded, audit-tier artifact (§17.4) |

⟹ **FIRST-CLASS. And §17.3 explains why the state set is a partially-ordered transition system, not a scale.**

## 17.2 **OUTPUT 21 — the belief-state model**

> ### **R17.1 (TWELVE STATES IN THREE GROUPS, AND THE GROUPS ARE NOT ORDERED BY TRUTH).**

```
┌─ PRE-EVIDENTIAL ─────────────────────────────────────────────────────┐
│  UNKNOWN        No admissible evidence either way.                   │
│                 **⟵ P0-01 R9.1: absence, delay, insufficiency,       │
│                    conflict, or compromise of ground truth MUST be    │
│                    recorded as UNRESOLVED — never CONFIRMED,          │
│                    CORRECT, or PASSED. UNKNOWN IS A STATE, NOT THE    │
│                    ABSENCE OF A STATE. §39 makes this the ignorance   │
│                    representation**                                   │
│  UNSUPPORTED    Evidence exists and does not support the claim.       │
│                 **Distinct from UNKNOWN: «we looked and found nothing» │
│                 ≠ «we did not look»**                                 │
│  HYPOTHESIS     Under consideration. P0-03 §11.2's S2 message type.   │
│                 **⟹ MUST NOT contribute to `evidence_roots`**         │
├─ EVIDENTIAL ─────────────────────────────────────────────────────────┤
│  PROVISIONAL    E1–E2 evidence, no unresolved contradiction.          │
│                 **May influence action; MAY NOT support a              │
│                 consequential decision (P0-02 R20.1 if unanchored)**   │
│  SUPPORTED      E3 admissible, `n_effective` ≥ θ_support, anchored,   │
│                 no unresolved contradiction.                          │
│                 **⟹ May contribute to `evidence_roots`**              │
│  GROUNDED       E4 — agrees with an L0–L3 ground-truth claim.         │
│                 **⟹ The ONLY state that may support calibration        │
│                    scoring and fitness (P0-01 §6.3)**                 │
│  CONTESTED      An unresolved contradiction exists. **BOTH claims are  │
│                 retained (§20). This is MORE informative than           │
│                 PROVISIONAL, not less**                                │
│  DISPUTED       Escalated: the Contradiction Detector could not        │
│                 resolve it internally and external adjudication is     │
│                 required. **⟹ P0-01: a κ < κ_min label is a DISPUTED   │
│                 label, not ground truth (R8.3)**                       │
├─ CONTEXTUAL / TERMINAL ──────────────────────────────────────────────┤
│  EXPIRED        `validity.t_end` passed without successful             │
│                 revalidation (§22). **⟹ NOT FALSE. «No longer known     │
│                 to hold» is not «known not to hold» — P0-01 R9.1's      │
│                 absence-≠-negation rule, applied to time**              │
│  VOID           Written under a retracted policy. P0-02's              │
│                 `VOID_CONTEXT`: **not deleted (M6), flagged.**          │
│                 **⟹ MUST NOT be cited as evidence under current rules** │
│  SUPERSEDED     A newer version holds (§36). P0-02 EIK-INV-08:          │
│                 corrections supersede, never overwrite.                 │
│                 **⟹ Retained and readable for audit; not citable as     │
│                    current**                                            │
│  RETRACTED      Withdrawn by the asserting source. **⟵ Distinct from    │
│                 SUPERSEDED: a retraction removes the assertion without  │
│                 replacing it**                                          │
└──────────────────────────────────────────────────────────────────────┘
```

## 17.3 The anti-scalar structure — why this is not a confidence scale

> ### **R17.2 (THE STATES ARE NOT TOTALLY ORDERED, AND THE ARCHITECTURE MUST NOT IMPOSE AN ORDER).**

The temptation is to read the list above as `UNKNOWN < HYPOTHESIS < PROVISIONAL < SUPPORTED < GROUNDED` and call it a scale. **That reading is exactly the «scalar truth score» the brief prohibits, and it is wrong in five specific places:**

| Pair | **Why no order exists** |
|---|---|
| **CONTESTED vs PROVISIONAL** | **CONTESTED is more informative.** A contested claim has evidence on both sides; a provisional one has evidence on one. Ranking CONTESTED below PROVISIONAL means «learning that there is a problem lowers your standing», which makes discovering contradictions *penalized* — and §28's confirmation-bias residue becomes structurally rewarded |
| **UNSUPPORTED vs UNKNOWN** | **Incomparable.** «We measured and it failed» and «we have no measurement» are different epistemic situations with different correct actions. P0-01 R9.1's whole point is that conflating them converts absence into negation |
| **EXPIRED vs UNSUPPORTED** | **Incomparable.** An expired belief was once grounded and its validity lapsed. An unsupported belief was never grounded. Ordering them makes «time passing» equivalent to «evidence against», which is COMM-INV-12's error (a timestamp is never evidence) in belief form |
| **GROUNDED vs SUPPORTED** | **Different KINDS, not different degrees.** SUPPORTED is an internal-evidence property; GROUNDED requires an external measurement of class L0–L3. **A claim can be SUPPORTED with overwhelming internal evidence and never GROUNDED — and R13.1 («no internal pathway from belief to verdict») means no amount of internal evidence closes that gap** |
| **VOID vs RETRACTED** | **Incomparable.** VOID means «the rules under which this was written no longer hold» — the claim may still be true. RETRACTED means «the source withdrew the assertion». **Treating VOID as weaker than RETRACTED would make a policy change into evidence about the world** |

**R17.3 (WHAT «VERIFIED» MEANS — and Vol A §4.1 R4.1's `KNOWS` predicate depends on this).** *A claim is `VERIFIED` — the property `KNOWS` requires — only relative to four declared parameters, and never absolutely:*
1. **TASK-SPECIFIC** — verified *for* a task with a declared ground-truth source set (P0-01 R8.1: the task must declare `source_classes` non-empty).
2. **EVALUATOR-SPECIFIC** — verified *by* an evaluator whose `gt_class` is L0–L6 and whose calibration record (`calib_ref`) is current.
3. **CONTEXT-SPECIFIC** — verified *within* the `context_scope` recorded on the claim (§24).
4. **VERSION-SPECIFIC** — verified *under* the `policy_version_ref` in force at verification, and VOID if that policy is retracted.

⟹ **`VERIFIED` is not a belief state; it is the conjunction of `belief_state ∈ {SUPPORTED, GROUNDED}` with the four relativity parameters being satisfied at read time.** **A stored `verified: bool` would be stale in all four dimensions simultaneously.**

## 17.4 The transition system

```
                    ┌──────────┐
     (no evidence)  │ UNKNOWN  │◄────────────────────┐
                    └────┬─────┘                     │
      assert / consider  │                           │ E-status demotion
                    ┌────▼─────┐                     │ (contradiction,
                    │HYPOTHESIS│                     │  P0-01 R6.2)
                    └────┬─────┘                     │
        E1/E2 gate passed│                     ┌─────┴──────┐
                    ┌────▼──────┐              │            │
              ┌─────│PROVISIONAL│──────────────┘            │
              │     └────┬──────┘                           │
   contradiction│        │ E3 gate passed                   │
   detected     │   ┌────▼────┐    contradiction       ┌────▼────┐
              ┌─▼────┤SUPPORTED├──────detected─────────►│CONTESTED│
              │      └────┬────┘                        └────┬────┘
              │           │ E4 gate passed (L0–L3 GT)        │ escalated
              │      ┌────▼────┐                        ┌────▼────┐
              └─────►│GROUNDED │                        │DISPUTED │
                     └────┬────┘                        └────┬────┘
                          │                                  │
     ┌────────────────────┼──────────────────────────────────┼──────────┐
     │ validity lapses    │ new version     policy retracted │ external │
     │              ┌─────▼─────┐      ┌──────────┐    ┌─────▼──────┐   │
     └─────────────►│  EXPIRED  │      │SUPERSEDED│    │  VOID      │   │
              ┌─────┴───────────┘      └──────────┘    └────────────┘   │
              │ source withdraws  ┌──────────┐                          │
              └──────────────────►│RETRACTED │                          │
                                  └──────────┘                          │
     ──────────────────────────────────────────────────────────────────  ┘
       **revalidation success (§22) returns EXPIRED → its prior state**
```

**R17.4 (THE FOUR PROPERTIES OF THE TRANSITION SYSTEM).**
1. **Every INCREASE transition (→ SUPPORTED, → GROUNDED, and revalidation → prior state) requires an EXTERNAL GATE.** There is no transition into SUPPORTED or GROUNDED that is triggered by an internal event. **⟹ This is R0.2's admission principle at the belief layer, and it is the single mechanism that breaks §1's loop.**
2. **Every DECREASE transition may be triggered internally** — a contradiction detected locally demotes to CONTESTED without anyone's permission. **⟹ Asymmetric on purpose: the system may always become more cautious on its own initiative, and may never become more confident on its own initiative.**
3. **No transition DELETES a state.** The prior state is appended to a bounded belief-state history (audit tier, `O(R)` per epoch digest). **⟹ §36's immutability applied to belief: a belief that changed is a belief with a history, not a belief that was edited.**
4. **`UNKNOWN` is reachable from every state** — evidence can be lost, an anchor can break, a calibration record can expire. **⟹ P0-01 R9.2: unresolved past a deadline is a CALIBRATION FAILURE. A system that cannot return to UNKNOWN cannot report its own ignorance (§39).**

## 17.5 The belief lifecycle, end to end

| Stage | **Event** | **State effect** | **Authority** |
|---|---|---|---|
| **1. ASSERTION** | A claim record is created with a `source_class` | → `HYPOTHESIS` if SC-7…SC-14; → `PROVISIONAL` if SC-1…SC-6 with E1+ | The asserting subject (as a record); **the state is DERIVED from `source_class` + `evidence_status`, not chosen** |
| **2. SUPPORT ACCUMULATION** | New source records attach via §15.1(d) | **No state change until `n_effective` crosses θ_support AND `evidence_status` ≥ E3** | **Computed on read (§21)** |
| **3. CORROBORATION GATE** | External corroboration / anchor resolution / contradiction survival | E0→E1→E2→E3 | **EXTERNAL** |
| **4. GROUNDING GATE** | Agreement with an L0–L3 GT claim | E3→E4; → `GROUNDED` | **EVA only** |
| **5. CONTRADICTION** | A contradicting record attaches | → `CONTESTED` (or `DISPUTED` on escalation); **`evidence_status` demoted to E2 + `ConflictRef` (P0-01 R6.2)** | The Contradiction Detector (organism) |
| **6. STALENESS** | `validity.t_end` passes; revalidation budget exhausted | → `EXPIRED` | Automatic, `[G]`-bounded |
| **7. REVALIDATION** | A fresh E3+/E4 measurement within scope | `EXPIRED` → prior state, **with a new `calib_ref` and a new `write_epoch`** | EVA / external |
| **8. SUPERSESSION** | A new version is created | → `SUPERSEDED`; the new record carries its own state | §36 |
| **9. RETIREMENT** | Source withdraws / policy retracted | → `RETRACTED` / `VOID` | Source / OP |

**R17.5 (THE LIFECYCLE'S CENTRAL ASYMMETRY, stated for the record).** *Stages 3, 4, and 7 — the only three that can raise a belief — all require an external principal. Stages 5, 6, 8, and 9 — all of which lower or terminate a belief — require no external principal. **⟹ The system is structurally biased toward doubt, and that bias is the design.*** **It is also why §90's conservatism trap is real: a system biased toward doubt will under-act, and §90 supplies the counterweight (a bounded optimism budget on the influence plane, never on the warrant plane).**

---

# §18. CONFIDENCE & UNCERTAINTY REPRESENTATION — **OUTPUT 22**

## 18.1 The prohibition, and what replaces it

**Brief: «Do not introduce a scalar truth score for confidence.»** Inherited: **COMM-INV-21 (no bare scalar)**, **P0-01 R6.4 (observation-confidence and belief-confidence are distinct quantities and MUST NOT be conflated)**, **Cell §8.2's `CONF_CACHE_MAX < CONF_FRESH_MAX`**.

> ### **R18.1 (UNCERTAINTY IS A SET OF SUFFICIENT STATISTICS, NEVER A SCALAR, AND NEVER STORED AS A BELIEF PROPERTY).**

```
UNCERTAINTY(m) = {
  ── ABOUT THE OBSERVATION (P0-01 R6.4's "input property") ──
  sensor_reliability   : the instrument's declared reliability at write time
  sensor_calibration   : `calib_ref` → EVA-assigned calibration record
  measurement_variance : sufficient statistics (n, mean, M2) for L2/L3 —
                         **Welford-style, O(1), never the raw sample**
  inter_annotator_kappa: for L4 only. **κ < κ_min ⟹ NOT ground truth (R8.3)**
  gt_class             : L0–L6 or null. **L7 PROHIBITED (R8.1)**
  gt_state             : P0-01's ground-truth state (0–9) at write time

  ── ABOUT THE EVIDENCE SET (P0-01 R6.4's "output property") ──
  evidence_status      : E0–E4, EXTERNALLY assigned
  n_effective          : **DERIVED ON READ (§21). NEVER STORED**
  inbreeding_F         : **ANCHOR-COMPUTED. READ-ONLY to every subject**
  corr_disjointness    : per-dimension digest (P0-03's six dimensions)
  contradiction_count  : |contradiction_refs| — **a count of RECORDS, not of
                         "independent confirmations" (⟵ D-1's field, replaced)**

  ── ABOUT THE RECORD ITSELF ──
  causal_depth         : u8, SATURATING (MEM-INV-14)
  from_cache           : bool → applies a POLICY CAP at read time (§18.3)
  policy_version_ref   : → VOID_CONTEXT applicability
  validity             : interval + context_scope
  staleness_state      : §22's revalidation state machine
}
```

**R18.2 (WHY SUFFICIENT STATISTICS AND NOT DISTRIBUTIONS).** *A distribution over a proposition's truth is a scalar with extra steps, and it inherits the scalar's fatal property: **it can be updated by anything, including retrieval.*** **Sufficient statistics are updated only by new records, and each field's writer is declared (Vol A §5.1). ⟹ A distribution answers «how sure am I?»; sufficient statistics answer «what do I have, where did it come from, and how much of it is independent?» — and only the second question is answerable without an oracle.**

## 18.2 The two confidences, kept apart

| | **OBSERVATION-CONFIDENCE** | **BELIEF-CONFIDENCE** |
|---|---|---|
| **What it is** | A property of an INPUT: how reliable is this measurement? | A property of an OUTPUT: how well is this claim supported? |
| **Producer** | The instrument + EVA's calibration record | **Computed on read** from `n_effective`, `evidence_status`, `inbreeding_F`, contradiction state |
| **Stored?** | ✅ Yes — on the record, as sufficient statistics | ❌ **NO — never stored. A stored belief-confidence is a scalar truth score** |
| **May it rise from retrieval?** | ❌ Never | ❌ Never |
| **May it rise from repetition?** | ❌ Never | ❌ Never |
| **May it rise at all without an external gate?** | ⚠️ Only by recalibration of the *instrument* (Cell T8: «recalibrate the epistemic head only») — which is an EVA act | ❌ **Never. R17.4 property 1** |
| **P0-01's rule** | R9.3: **confidence MUST NOT increase in any GT state other than {0, 1, 8}** | Same rule, applied to the computed quantity |

**R18.3 (X6 RESOLVED — `CONF_CACHE_MAX` without a scalar).** ⚠️ **CONTRADICTION X6:** Cell §8.2 [V4] requires `CONF_CACHE_MAX < CONF_FRESH_MAX` — a *scalar cap* — while COMM-INV-21 prohibits bare scalars.

> **Resolution: the cap is a WARRANT-COMPUTATION RULE applied by the RECEIVER at read time, not a stored confidence value.** COMM-INV-03 establishes that warrant is a receiver computation. ⟹
>
> `warrant(retrieve_cached(x)) ≤ CAP_CACHED(policy)` and `warrant(retrieve_fresh(x)) ≤ CAP_FRESH(policy)`, with `CAP_CACHED < CAP_FRESH` declared in `[G]`.
>
> **Both caps are POLICY constants (`O(1)`, cached, RO-13-owned), and neither is a property of the record.** The record carries `from_cache: true`; the receiver applies the cap. **⟹ No scalar is stored, no scalar is transmitted, and the inequality is enforced by the same mechanism that enforces every other warrant bound. X6 dissolves.**

## 18.3 Calibration — who produces it, and how it is checked

**«Every confidence mechanism has a producer + calibration» (Task 3 Rule 11).**

| Quantity | **Producer** | **Calibration mechanism** | **Check** |
|---|---|---|---|
| `sensor_reliability` | The instrument's declared spec | **EVA recalibration** (Cell T8: epistemic head only, never the reward head) | Predicted-vs-observed error rate over a rolling window |
| `measurement_variance` | The measurement process | Sufficient statistics (n, mean, M2), **updated only by new measurements** | χ²-style consistency between declared and observed variance — **evaluator-side, off-line** |
| `inter_annotator_kappa` | The annotation process (L4) | **P0-01 R8.3: κ declared; `κ < κ_min` ⟹ the label is DISPUTED, not ground truth** | Multi-annotator overlap |
| `n_effective` | **Computed** (§21) | **Not calibrated — it is derived.** What IS calibrated is the *threshold* θ_support | §21.5's independence-audit |
| `inbreeding_F` | **The Anchor** | **Not calibrated — it is counted from anchored ancestry.** What IS calibrated is `F_max` | Cell §8.3 FM-4's gate: `F > F_max ⟹ S6 abstain` |
| `evidence_status` | **External gates** | The gate definitions themselves are policy (RO-13) and their *effectiveness* is measured by E4-agreement rates | **P0-01: E4 is the only rung that touches L0–L3, so the E-gates' calibration IS the ground-truth agreement rate** |
| Belief-confidence (computed) | **The reader, at read time** | **P0-01 §7's calibration scoring, which requires E4 records — i.e. it requires ground truth** | **Reliability-diagram style: for claims at computed support level *s*, what fraction were E4-grounded? ⟹ A system whose SUPPORTED claims are rarely GROUNDED is over-confident, and this is measurable without any internal introspection** |

**R18.4 (THE CALIBRATION LOOP'S OWN INBREEDING PROBLEM — ⚠️ DECLARED).** *Calibration scoring requires E4 records, and E4 requires agreement with L0–L3 ground truth. **If the ground-truth supply is silent about a domain, no record in that domain can reach E4, and the calibration of beliefs in that domain is UNMEASURABLE — not bad, not good, unmeasurable.*** **⟹ P0-01 R9.1's rule applies: the calibration state for that domain MUST be recorded as `UNRESOLVED`, and MUST NOT be recorded as «well calibrated». §39's ignorance representation covers this case, and §100 OR-M4 records that a domain with no ground-truth supply is permanently uncalibratable from inside.**

---

# §19. BELIEF UPDATE ARCHITECTURE — **OUTPUT 23**

## 19.1 **OUTPUT 23 — the update rules**

> ### **R19.1 (THE COMPLETE ENUMERATION OF WHAT MAY CHANGE A BELIEF STATE).**

| # | **MAY increase belief** | **Requires** | **Invariant** |
|---|---|---|---|
| **U1** | A new source record attaches, with a **distinct `root_commit`** and **disjoint `corr_class`** on all six dimensions | §21's `n_effective` recomputation crossing θ_support | MEM-M3 |
| **U2** | An **external corroboration gate** passes (E0→E1) | ≥ `n_corr` independent sensors, P0-01 §6.3 | R0.2 |
| **U3** | **Anchor resolution** succeeds (E1→E2) | `root_commit` resolves in the Anchor's root registry; **P0-02: «Roots are appended by the Anchor, not by cells»** | MEM-INV-03 |
| **U4** | A record **survives the contradiction check** (E2→E3) | §20's detector finds no unresolved contradiction within scope | R0.2 |
| **U5** | An **EVA ground-truth measurement of class L0–L3** agrees (E3→E4) | `gt_class` set by EVA; **L7 PROHIBITED**; P0-01 R8.1 | MEM-INV-08 |
| **U6** | A **successful revalidation** within scope and validity (§22) | A fresh U2–U5 event | R17.4 |
| **U7** | A **contradiction is resolved** by the Contradiction Detector in this claim's favour, with a declared reason | §20.4's resolution statuses | MEM-INV-07 |
| **U8** | **Instrument recalibration** improves `sensor_reliability` | Cell T8: **the epistemic head only, never the reward head** | R18.2 |

> ### **R19.2 (THE COMPLETE ENUMERATION OF WHAT MAY NOT).**

| # | **MUST NOT change belief** | **Why** | **Where it is defeated** |
|---|---|---|---|
| **N1** | **Retrieval** | R42.1: `n_obs` contribution = 0 | §25, §30, MEM-INV-01 |
| **N2** | **Repetition / re-publication** | «Propagation ≠ independent evidence» | §30, MEM-M3 |
| **N3** | **Storage duration** | Time passing is not evidence. COMM-INV-12 | §22, §30 |
| **N4** | **Consolidation** | MEM-M2: warrant is monotone-non-increasing under every memory operation | §31 |
| **N5** | **Compression** | DP-1…DP-10 must survive; nothing new is created | §33 |
| **N6** | **Generalization** | A general rule inherits the MINIMUM warrant of its instances (R32.1) | §32 |
| **N7** | **Internal agreement / consensus** | **L7 DERIVED/CONSENSUS is NEVER ground truth** — «the self-referential trap» (P0-01 R8.1) | §12 SC-14, MEM-INV-08 |
| **N8** | **Self-consistency** | A coherent set of mutually-supporting internal beliefs has high consistency and zero external warrant | §81, FM-4, R1.1 |
| **N9** | **Citation count / reference count** | A count of references is a count of retrievals | §28, D-1 |
| **N10** | **Rank position in a retrieval result** | §27: rank is an allocation output, not an epistemic one | §26, §27 |
| **N11** | **Importance / salience** | D-2: `importance` is an allocation quantity (R11.2) | §11.4, §28 |
| **N12** | **Access frequency** | Vol A §5.1: `access_count` is PROHIBITED as an epistemic input | §30, MEM-D2 |
| **N13** | **Similarity to other records** | Similarity is a property of an embedding, which is model- and hardware-specific (§2.3's K13/K14 failures for G) | §27, §16.1 |
| **N14** | **The subject's own report of confidence** | Vol A §5.1: no field asserts its own truth | §8.1, MEM-INV-04 |
| **N15** | **A `causal_depth` decrease** | Depth only rises. **A record cannot become less derived** | MEM-INV-14, MEM-M2 |

**R19.3 (THE ASYMMETRY IS THE DESIGN).** *Eight admissible increases, every one requiring an external principal or an external measurement. Fifteen prohibited increases, every one of which is an internal event. **⟹ The set of internal events that may raise a belief is EMPTY. That is not a policy choice; it is the structural statement of «the system never silently converts an internally generated representation into externally warranted truth merely because it was remembered, repeated, retrieved, compressed, or widely propagated.»***

## 19.2 The update algorithm

```
ON new source record r attaching to claim C:

  1. **CLASSIFY**   src_class(r) is IMMUTABLE (R12.1).
                    If src_class(r) ∈ {SC-9 SIMULATION, SC-10 COUNTERFACTUAL,
                    SC-14 INTERNAL_CONSENSUS} ⟹ **r contributes ZERO to
                    support at any evidence status above its ceiling
                    (R12.2). STOP for support purposes; still store r.**

  2. **DEDUP**      If root_commit(r) matches an existing support ref of C
                    ⟹ **admit r as a record, count the evidence ONCE**
                    (Vol A §15.2 D-2). n_effective unchanged.

  3. **CORRELATE**  Compute corr_class disjointness against every existing
                    support ref on P0-03's SIX dimensions (§21).
                    **Non-disjoint ⟹ collapse. n_effective does not rise.**

  4. **RECOMPUTE**  n_effective(C) = Σ over support refs of the collapsed
                    independent count (§21.3). **COMPUTED, NEVER STORED.**

  5. **CEILING**    ceiling(C) = MIN over support refs of ceiling(src_class)
                    (R12.3). **One simulated instance caps the whole claim.**

  6. **INBREEDING** inbreeding_F(C) is read from the Anchor. **NEVER
                    self-computed. NEVER self-reported.**

  7. **GATE CHECK** IF n_effective ≥ θ_support
                    AND evidence_status(C) ≥ E3
                    AND inbreeding_F(C) ≤ F_max
                    AND ceiling(C) ≥ E3
                    AND ¬∃ unresolved contradiction
                    AND gt_state ∈ {0, 1, 8}          ⟵ **P0-01 R9.3**
                    THEN belief_state(C) := SUPPORTED
                    ELSE **no change. Record the reason in the belief-state
                         history. An update that does not fire is an
                         observable event, not a silent no-op**

  8. **E4 GATE**    SUPPORTED → GROUNDED requires U5: an EVA measurement of
                    class L0–L3 agreeing. **NO INTERNAL PATH (R13.1).**

⟹ **STEPS 1–6 ARE ALL READ-ONLY WRT r AND C. Step 7 is the only write, and
   every one of its six conjuncts is externally sourced or externally
   computed. THERE IS NO STEP AT WHICH THE SUBJECT'S OWN ACTIVITY
   CONTRIBUTES.**
```

## 19.3 What happens on decrease

| Trigger | **Effect** | **Reversible?** |
|---|---|---|
| Contradiction detected | → `CONTESTED`; `evidence_status` demoted to E2 + `ConflictRef` (P0-01 R6.2) | ✅ On resolution (U7) |
| Anchor chain break | **GLOBAL freeze** (P0-02 §20.2); every record whose provenance cannot be resolved → `UNKNOWN` | ✅ On re-anchoring |
| Policy retracted | → `VOID` (`VOID_CONTEXT`), **record NOT deleted (M6)** | ⚠️ Only by a NEW record under the new policy — **a VOID record is never un-VOIDed, because the history of having been written under bad rules is itself the audit trail** |
| Validity lapsed | → `EXPIRED` | ✅ On revalidation (U6) |
| Source retracts | → `RETRACTED` | ❌ **A retraction is not reversible by the retracting source; a new assertion is a new claim record** |
| Calibration record expires | `calib_ref` stale ⟹ **the record's warrant is recomputed lower by the reader** (COMM-INV-03) | ✅ On recalibration |
| `gt_state` leaves {0,1,8} | **Any belief state held during states 2,3,4,5,6,7,9 may HOLD or DECREASE but MUST NOT INCREASE** (R9.3), and **reward MUST NOT be emitted in states 2,3,5,6,7,9** (R12.6) | ✅ On GT supply restoration |
| Ground-truth source **COMPROMISED** | **P0-01 R9.4: triggers RETROACTIVE INVALIDATION + rollback candidates.** Every belief that rested on the compromised source → `UNKNOWN`, and the belief-state history identifies the rollback set | ⚠️ Only by fresh external measurement |

**R19.4 (RETROACTIVE INVALIDATION IS THE MOST EXPENSIVE AND MOST NECESSARY OPERATION IN THE SYSTEM).** *P0-01 R9.4 requires it, and it requires traversing the claim graph backwards from a compromised root to every belief that rested on it.* **⟹ Vol A §16.2's bounded-depth rule cannot apply here: an invalidation traversal MUST be unbounded. Resolution: invalidation is an OFF-LINE, evaluator-side operation over anchored records (§95), executed at `O(affected)` with the affected set computed from the Anchor's root registry — not a runtime operation, and never performed by the Memory Service.** **⟹ This is the second place (after §16.2's full-graph analysis) where an unbounded traversal is required and is therefore moved off-line, and §57 records the general rule: *any operation whose cost is unbounded in the corpus is an evaluator-side operation.***

---

# §20. CONTRADICTION ARCHITECTURE — **OUTPUT 24**

## 20.1 «Do not force contradiction resolution»

> ### **R20.1 (UNRESOLVED IS A VALID, STABLE, FIRST-CLASS OUTCOME).** *The Contradiction Detector's output set includes `UNRESOLVED` as a terminal-for-now state with no deadline after which it becomes an error. **A system that must resolve every contradiction will resolve some of them wrongly, and a wrongly resolved contradiction is worse than an unresolved one: the unresolved one is visible.***
>
> **This is P0-01 R9.1's rule at the belief layer: absence, delay, insufficiency, CONFLICT, or compromise of ground truth MUST be recorded as `UNRESOLVED`, never as `CONFIRMED`.**

## 20.2 The `ContradictionRecord` object

```
CONTRADICTION RECORD
├─ contradiction_id      : global, permanent, never reused
├─ claim_ref             : **ONE claim (§15.2 D-3). A contradiction is a
│                          relation between RECORDS attached to a single
│                          CLAIM — without claim identity there is nothing
│                          for two records to contradict**
├─ record_a, record_b    : **BOTH RETAINED. Neither is overwritten, deleted,
│                          demoted below E2, or hidden (Cell §8.2: «both
│                          retained + ConflictRef emitted; never overwrite»)**
├─ contradiction_type    : §20.3's seven types
├─ scope_overlap         : **the intersection of context_scope(a) and
│                          context_scope(b), and the intersection of their
│                          validity intervals. ⟵ THIS FIELD IS WHAT
│                          DISTINGUISHS A REAL CONTRADICTION FROM A SCOPE
│                          ERROR (§20.3 types 3 and 4)**
├─ independence          : **corr_class disjointness between a and b (§21).
│                          Two contradicting records that share a root are
│                          not a contradiction — they are a corruption**
├─ evidence_status_a/b   : **compared, never averaged**
├─ gt_class_a/b          : **L2 beats L4 beats L7 — and L7 is not admissible
│                          at all (R8.1)**
├─ detection_epoch
├─ detector_ref          : **the ORGANISM Contradiction Detector (P0-03
│                          §42.2's ownership table). NOT the Memory Service,
│                          NOT the reader, NOT either claimant**
├─ resolution_status     : §20.4's eight statuses
├─ resolution_reason     : **required whenever status ≠ UNRESOLVED. A
│                          resolution without a declared reason is a silent
│                          overwrite**
├─ resolution_authority  : **who resolved it, and under what warrant**
└─ escalation_ref        : if DISPUTED
```

## 20.3 **OUTPUT 24 — the seven contradiction types**

| # | Type | **Definition** | **Decidable?** | **Correct handling** |
|---|---|---|---|---|
| **CT-1** | **LOGICAL** | `A ∧ ¬A` within the same context scope and overlapping validity intervals | ✅ **Decidable in the symbolic representation (§2.4: H is the component that must be exact)** | Genuine contradiction. Both retained, `CONTESTED` |
| **CT-2** | **EMPIRICAL** | Two L2 measurements disagree beyond their declared variances | ✅ Decidable *given declared variance* | **NOT a logical contradiction.** Re-measurement is the resolution path (U5). If variances were undeclared ⟹ **the fault is in the record, not the world** |
| **CT-3** | **TEMPORAL** | `A` at interval *I₁*, `¬A` at interval *I₂* | ✅ **Decidable — and usually NOT a contradiction** | **⟵ THE MOST COMMONLY MISDETECTED TYPE. If `I₁ ∩ I₂ = ∅`, this is a CHANGE, not a contradiction.** §23's interval algebra is what distinguishes them. **A memory system without interval representation reports every change as a contradiction** |
| **CT-4** | **CONTEXTUAL** | `A` in context *C₁*, `¬A` in context *C₂* | ✅ Decidable given `context_scope` | **NOT a contradiction — a SCOPE ERROR in whatever query retrieved them together.** §24: retrieval outside `context_scope` is a malformed result. **⟹ If `C₁ ∩ C₂ = ∅`, close as `BOTH_VALID_IN_DISJOINT_CONTEXTS`** |
| **CT-5** | **PROVENANCE** | Identical content, incompatible `root_commit`s | ✅ Decidable | **NOT a contradiction about the world — a CORRUPTION or FORGERY indicator.** ⟹ immune report (§49), not belief demotion. **Vol A §15.2 D-1's rule: identical content, different roots ⟹ two records, linked, never merged** |
| **CT-6** | **SEMANTIC** | Two records use the same term with different meanings | ⚠️ **UNDECIDABLE in general** | **⟵ TIES DIRECTLY TO §15.2's claim-identity problem and FM-4's `[U]` residue. R20.2: where semantic identity is undecidable, create TWO claim records linked by `POSSIBLY_SAME_CLAIM`. Conservative: it may duplicate a claim, but it will never merge two distinct ones — and merging distinct claims loses a contradiction, while duplicating one loses only storage. §100 OR-M3** |
| **CT-7** | **SELF-CONTRADICTION** | A record contradicts another record from the **same subject** with the **same root** | ✅ Decidable | **NOT evidence about the world — evidence about the SUBJECT.** ⟹ calibration failure for that subject (V3.1 §4's «confidence-error mismatch detection: if a cell was highly confident and repeatedly wrong → calibration failure → reduce trust in that cell, route verification elsewhere»), **and `inbreeding_F` for that subject rises. Never a belief update about the claim** |

**R20.2 (THE POINT OF THE SEVEN-WAY SPLIT).** *Only CT-1 and CT-2 are contradictions about the world. **CT-3 and CT-4 are artefacts of missing temporal or contextual representation. CT-5 is a security event. CT-6 is undecidable. CT-7 is a calibration event about a subject.*** **⟹ A system with one contradiction type treats all seven identically, and four of the seven responses would be wrong. Vol A §2.2's K5 criterion («can 'we do not know which is correct' be represented?») is therefore not about representing uncertainty — it is about representing the RIGHT KIND of disagreement.**

## 20.4 The eight resolution statuses

| Status | **Meaning** | **Effect on belief** | **Authority** |
|---|---|---|---|
| **UNRESOLVED** | Open, stable, no deadline | `CONTESTED`; **both records retained at E2 + `ConflictRef`** | — |
| **BOTH_VALID_IN_DISJOINT_INTERVALS** | CT-3 with `I₁ ∩ I₂ = ∅` | **No belief change. This was never a contradiction** | Detector |
| **BOTH_VALID_IN_DISJOINT_CONTEXTS** | CT-4 with `C₁ ∩ C₂ = ∅` | **No belief change** | Detector |
| **RESOLVED_IN_FAVOR_OF(a)** | A declared reason exists | `a` restored to prior state; **`b` → `SUPERSEDED` or `RETRACTED`, NEVER DELETED** | Detector + the reason's warrant source |
| **MERGED_AS_ONE_CLAIM** | CT-6 resolved: they were the same claim after all | **⚠️ THE DANGEROUS STATUS. Requires an explicit, audited, externally-validated semantic-identity judgement. NEVER automatic** | **Memory Authority + external validation (Cell §17.5's pattern: «audited, externally-validated semantic content may promote»)** |
| **ESCALATED_TO_DISPUTED** | Internal resolution failed | `DISPUTED`; external adjudication required | Detector → organism → **EVA if a GT claim is involved** |
| **REFERRED_TO_IMMUNE** | CT-5, or a CT-7 pattern above threshold | **Not a belief event at all** | Immune (§49) |
| **VOID_ONE** | One record was written under a retracted policy | The VOID record is not citable; **the contradiction closes without either record being judged false** | OP (via `policy_version_ref`) |

## 20.5 Contradiction handling at scale

| Concern | **Mechanism** | **Cost** |
|---|---|---|
| **Detection** | **At ingestion step [7] only, against the D-3 claim index.** Never all-pairs | **`O(1)` per write** (Vol A §16.2) |
| **Detection across regions** | **Not required to be synchronous.** A contradiction between a region-1 record and a region-2 record is detected when either is retrieved in a shared context, or at epoch aggregation | **`O(R)` per epoch** |
| **⚠️ The cross-region detection gap** | **A contradiction may exist undetected for up to one epoch.** ⟹ **DECLARED, not hidden: `CONTRADICTION_LATENCY ≤ epoch_length`, a `[G]` parameter, and the same trade-off as P0-02 §20.3's lie-window** | — |
| **Storage** | `ContradictionRecord`s are audit-tier, append-only, bounded by `[G]` | `O(contradictions)` |
| **Never averaged** | **P0-03 §42.2: «conflicts → Contradiction Detector, never averaged».** And P0-03's partition rule: memory conflicts ⟹ **UNION for append-only records; RE-EVALUATE for derived state; NEVER VOTE** | — |
| **Suppression attack (#16)** | A subject that suppresses a `ConflictRef` is detectable: **the detector runs at ingestion, in the Memory Service, not in the subject.** A subject cannot prevent detection of a contradiction between its own record and an existing one | **CLOSED** |

---

# §21. EVIDENCE-INDEPENDENCE MODEL — **OUTPUT 20**

## 21.1 Why memory makes independence harder

**P0-03 solved independence for messages, where records are transient and the correlation structure is carried in the envelope. Memory breaks three of its assumptions:**

| P0-03's assumption | **How memory breaks it** | **Consequence** |
|---|---|---|
| The envelope travels with the message | A record is **stored**, then **retrieved**, then **re-emitted** — three separate events, possibly epochs apart, possibly by different subjects | **The correlation structure must be STORED, not just carried.** ⟹ `corr_class` and `root_commit` are mandatory fields on the record (Vol A §5.1), not just on the envelope |
| A message has one sender | A memory record may be **written by one subject and retrieved by another**, and the retriever becomes the re-emitter | **`src_identity` (derived from channel binding) and the retrieving subject's identity are DIFFERENT and both must be recorded.** ⟹ §21.4's re-emission rule |
| Depth is bounded by the message chain | A record **persists** and can be re-derived many times | **D-3: `causal_depth: u8` must SATURATE, never wrap (MEM-INV-14)** |

## 21.2 The six dimensions, applied to memory

**P0-03's six correlation dimensions, with the memory-specific test for each:**

| Dim | **P0-03's dimension** | **Memory test** | **Detectable?** |
|---|---|---|---|
| **1** | **Shared evidence root** | `root_commit(a) == root_commit(b)`, or Merkle proof that one root is an ancestor of the other | ✅ **`O(log)` proof against the Anchor** |
| **2** | **Shared lineage** | `lineage_ref(a)` and `lineage_ref(b)` resolve to the same ancestor in the EIK Lineage Store | ✅ |
| **3** | **Shared instrument / sensor** | `sensor_id` in the observation's sufficient statistics | ✅ **if declared — and P0-01 §6.1 requires the instrument to be part of the observation, so it is** |
| **4** | **Shared upstream processor** | `transform_history` commitments share a processing subject | ✅ |
| **5** | **Shared time window** | `validity` intervals overlap AND `write_epoch` proximity | ✅ **⚠️ but temporal proximity is CORRELATION EVIDENCE, never truth evidence (COMM-INV-12)** |
| **6** | **Shared latent assumption** | **No test exists** | ❌ **NOT DETECTABLE FROM INSIDE. COMM-INV-18 / MEM-INV-11** |

**R21.1 (DIM 6, FOURTH APPEARANCE).** *P0-03 found dim 6 undetectable for messages. **It is worse for memory**, because a memory record persists and can accumulate dim-6-correlated support over epochs: a shared latent assumption in the instrument calibration, in the task specification, in the environment model `M_ℰ`, or in the policy — **and every record that inherits the assumption looks independent on dims 1–5.***
> **⟹ The only mitigations are external and none of them is complete:**
> 1. **Instrument diversity as a `[G]`-declared requirement** — corroboration at E1 requires ≥`n_corr` independent sensors, and «independent» MUST mean *different instrument classes*, not different instrument instances. **Two copies of the same sensor model share a latent assumption.**
> 2. **`gt_class` diversity** — a claim supported only by L0 (simulator) evidence shares the simulator's assumptions; only L2 (physical measurement) touches ℛ. **P0-01 R8.2: L0 MUST NOT be ground truth for claims about ℛ.**
> 3. **P0-01 R4.3: `M_ℰ` (the environment model) MUST NOT be an evaluation input** — because a model evaluating against itself is dim 6 with extra steps.
> 4. **⚠️ NONE OF THESE DETECTS A SHARED ASSUMPTION IN THE TASK SPECIFICATION ITSELF.** **§100 OR-M5 records this as the memory-layer form of the program-level limit, and it is unclosable from inside by construction: the assumption is shared precisely because it is in the thing doing the assuming.**

## 21.3 `n_effective` — the computation

> ### **R21.2.** *`n_effective(C)` is computed on read, is never stored, and is defined as the size of the largest set of support records for `C` that are pairwise disjoint on dimensions 1–5, weighted by each record's admissibility at `C`'s current evidence status.*

```
n_effective(C) =
    Σ over the maximal dim-1..5-disjoint subset S of support_refs(C)
      of  admissible(r, evidence_status(C))
    where
      admissible(r, E) = 0  if ceiling(source_class(r)) < E     (R12.2)
                       = 0  if r is a RETRIEVED or RETRIEVED_CACHED
                              re-emission of an already-counted record
                       = 0  if r ∈ contradict_refs(C)
                       = 1  otherwise, scaled by the record's declared
                              measurement precision for L2/L3
                              **(P0-01 §8.2: L3 redundant-independent gives
                                1/√n error reduction IF AND ONLY IF the
                                redundancy is genuine — which is exactly
                                what the disjointness test establishes)**

PROPERTIES:
  • **n_effective ≤ |support_refs|, always.** Equality holds only when every
    support record is genuinely independent — which is the rare case, and
    the inequality is the whole point.
  • **n_effective is MONOTONE NON-INCREASING under every memory operation**
    (MEM-M3): consolidation, compression, generalization, and re-emission
    can only lose independence information, never create it.
  • **n_effective of a record's OWN PRIOR RETRIEVALS is 0.** (R42.1:
    `n_obs` contribution from a retrieval = 0.)
  • **⚠️ n_effective IS NOT STORED.** Vol A D-1: a stored count whose name
    asserts independence is a counter an attacker can increment. **A computed
    quantity cannot be forged — only its INPUTS can, and its inputs
    (`root_commit`, `corr_class`, `source_class`) are all externally written
    or anchor-verified.**
```

## 21.4 Re-emission — the memory-specific independence rule

```
THE SITUATION: subject X retrieves record r (written by Y) and re-emits it
as a message. Subject Z receives it.

WHAT Z MUST SEE:
  • src_identity  = **X** (derived from channel binding, COMM-INV-09).
                    **NOT Y.** X is who sent this message.
  • origin_ref    = **r's mem_id, and Y's identity as the original asserter.**
                    **Both. Conflating them is the error: «X said it» and
                    «Y observed it» are different claims**
  • source_class  = **SC-12 RETRIEVED** (or SC-13 RETRIEVED_CACHED).
                    **⟹ CEILING: inherits r's status, can never exceed it
                       (R12.1's immutability + §12 SC-12)**
  • causal_depth  = **r's causal_depth + 1** (R42.1)
  • root_commit   = **r's root_commit, UNCHANGED**
  • corr_class    = **r's corr_class, UNCHANGED**
  • n_obs contribution to Z = **0**

⟹ **Z CANNOT COUNT X's RE-EMISSION AS AN OBSERVATION, AND CANNOT COUNT IT AS
   INDEPENDENT OF Y's ORIGINAL.** Both follow from fields Z receives, not
   from Z's diligence.

⟹ **AND THE §10.3 ATTACK DIES HERE: B, C, D all re-emit from the same root,
   so D's three records have three different `causal_depth`s and ONE shared
   `root_commit`. n_effective = 1.**
```

**R21.3 (THE INDEPENDENCE-AUDIT REQUIREMENT).** *Any component that aggregates support across records MUST compute `n_effective` and MUST NOT use `|support_refs|`. **A conformance test (§96) supplies a corpus with known correlation structure and checks that the computed `n_effective` matches the known value — this is testable without any ground truth about the world, because correlation structure is a property of the corpus, not of ℛ.*** ⟹ **This is §96's most valuable test class: it tests the epistemic machinery directly, using synthetic correlation, and it does not require the architecture to be right about anything except counting.**

---

# §22. STALENESS, EXPIRY & REVALIDATION

## 22.1 Why `last_verification` is the wrong field

**V3 §11's BELIEF RECORD has `last verification`. Vol A §5.1 prohibits it as a truth indicator. The mechanism:**

```
`last_verification: t` invites exactly one inference: «verified at t ⟹ still
true now». **That inference is COMM-INV-12's error («a timestamp is never
evidence») in belief form, and it fails in four ways:**

 1. **The world changed at t+1.** A timestamp says nothing about the future.
 2. **The verification was scoped.** It verified the claim in context C at
    interval I. `last_verification` records neither.
 3. **The verification's own warrant decayed.** The `calib_ref` it used may
    have expired; the instrument may have been recalibrated; the policy may
    have been retracted. **A verification is a record with a warrant, and
    its warrant is subject to every rule in this package.**
 4. **Recency is retrievable-ness, not truth.** §27: a recent record ranks
    higher. **If recency also implies validity, the retrieval ranking has
    become the epistemology — R1.2's availability-capture trap.**

⟹ **REPLACED BY:**
   `validity: {t_start, t_end?, context_scope}`  — an INTERVAL, declared at
                                                    write time, scoped
   `revalidation_state`                          — §22.2's machine
   `calib_ref`                                   — the warrant of the last
                                                    verification, which DECAYS
                                                    like any other warrant
```

## 22.2 The revalidation state machine

```
        ┌──────────┐  validity.t_end passes   ┌───────────────┐
        │  FRESH   ├─────────────────────────►│ DUE_FOR_REVAL │
        └────┬─────┘                          └───────┬───────┘
             │ revalidated (U6)                       │
             │◄───────────────────────────────────────┤
             │                                        │ budget exhausted
   ┌─────────▼─────────┐                              │
   │ STALE_BUT_USABLE  │◄─────────────────────────────┤
   │ **warrant capped  │                              │
   │  by staleness;    │   revalidation SUCCEEDS      │
   │  may influence,   ├──────────────────────────────► FRESH
   │  may NOT support  │
   │  a consequential  │   revalidation FAILS
   │  decision**       ├──────────────────────────────► EXPIRED (§17.2)
   └───────────────────┘
                                          ┌──────────────────────┐
   revalidation IMPOSSIBLE (no GT supply) │ UNREVALIDATABLE      │
   ──────────────────────────────────────►│ **⟵ P0-01 R9.1:      │
                                          │ recorded UNRESOLVED, │
                                          │ NEVER as FRESH and   │
                                          │ NEVER as EXPIRED**   │
                                          └──────────────────────┘
```

**R22.1 (THE THREE-WAY DISTINCTION THAT MAKES THIS WORK).** *`EXPIRED` («we checked and it no longer holds, or we could not re-check in time») ≠ `UNREVALIDATABLE` («no ground-truth supply exists for this domain») ≠ `STALE_BUT_USABLE` («past its interval, warrant capped, still informative»).* **A system with one staleness flag conflates all three, and P0-01 R9.1 says the conflation converts absence into negation.** ⟹ **`UNREVALIDATABLE` is the memory-layer form of §39's ignorance representation, and R18.4's uncalibratable-domain problem is the same case.**

## 22.3 The revalidation budget — and why it must be bounded

```
THE PROBLEM: revalidating every record periodically is O(N) per period.
At 10¹² records this is infeasible (§56, §94). Doing nothing is §22's
staleness failure. **The budget must be allocated, and allocation is a
policy question, not an epistemic one.**

ALLOCATION RULE — **by DEPENDENCY, not by importance:**

  revalidation_priority(r) = f(
      how many consequential decisions currently rest on r     ⟵ from the
                                                                 claim graph
    + r's proximity to a KC-2-authorized act                   ⟵ P0-02 R20.1
    + r's staleness relative to its declared validity interval
    + r's evidence_status                                      ⟵ E4 records
                                                                 revalidate
                                                                 first: they
                                                                 are the ones
                                                                 that MATTER
  )

⟹ **⚠️ `importance` (D-2) IS NOT AN INPUT.** R11.2: `importance` gates
   allocation of STORAGE; revalidation budget is allocated by DEPENDENCY,
   which is a claim-graph quantity computed by the organism, not a
   subject-declared salience.

⟹ **AND THE FAILURE MODE THIS CREATES, DECLARED:** a record that nothing
   currently depends on is never revalidated, and if it later becomes
   load-bearing it enters use STALE. **Mitigation: any consequential
   decision that rests on a record whose `revalidation_state ≠ FRESH`
   MUST either revalidate first or record the decision as resting on
   stale evidence — which lowers the decision's own warrant (MEM-M2)
   and is visible in the audit.**
```

**R22.2 (THE STALENESS/WARRANT COUPLING).** *Staleness does not make a record false. **It caps the warrant a reader may derive from it** — the same mechanism as R18.3's cache cap, and for the same reason: warrant is a receiver computation (COMM-INV-03), and staleness is an input to that computation, not a property stamped on the record.*

---

# §23. TEMPORAL MEMORY MODEL — **OUTPUT 25 (part 1)**

## 23.1 The representation

> ### **R23.1 (INTERVALS, NOT TIMESTAMPS; PARTIAL ORDER, NOT TOTAL).**

```
TEMPORAL FIELDS ON EVERY RECORD:
  event_interval   : [t_start, t_end) — **when the asserted state of affairs
                     held in the world.** May be OPEN (t_end = ∞)
  record_interval  : [t_written, t_superseded?) — **when the record existed.**
                     ⟵ **THESE TWO ARE DIFFERENT AND CONFLATING THEM IS THE
                        ROOT OF CT-3's misdetection: a record written at t₅
                        about an event at t₁ has event_interval ≠
                        record_interval, and a query that uses the wrong one
                        produces a phantom contradiction**
  validity         : the interval during which the CLAIM holds (§22)
  write_epoch      : the governance epoch (P0-03 COMM-INV-13)
  causal_depth     : u8, SATURATING — **the partial order**
  root_commit      : **the anchored identity of the evidence, which supplies
                     the AUTHORITATIVE order when clocks disagree**

CLOCK DISCIPLINE (inherited, and binding):
  • **COMM-INV-12: a timestamp is never evidence.** Timestamps order records
    for human reading and for interval arithmetic; they NEVER establish
    precedence as an epistemic fact.
  • **P0-03: no global clock, no perfect synchronization (§81's
    non-requirement).** Clock skew is assumed.
  • **`causal_depth` + `root_commit` give the partial order that survives
    skew.** Where two records' intervals overlap and their causal order is
    unknown, the order is **UNKNOWN — and P0-03 R37.1 applies: UNKNOWN ≠
    DISJOINT.**
```

## 23.2 Interval relations — the temporal reasoning substrate

**Allen's thirteen interval relations are the natural formalism, and they are adopted because they are decidable in `O(1)` per pair and because they make CT-3 decidable:**

| Relation | **Contradiction?** | **Handling** |
|---|---|---|
| **BEFORE / AFTER** (`I₁` ends before `I₂` starts) | ❌ **NO — a CHANGE** | Both records valid; `scope_overlap = ∅`; **CT-3 closes as `BOTH_VALID_IN_DISJOINT_INTERVALS`** |
| **MEETS / MET-BY** (endpoint touching) | ⚠️ **Boundary case** | **`[G]`-declared: half-open intervals `[t_start, t_end)` make MEETS disjoint. ⟹ NO contradiction. This is why the interval is half-open** |
| **OVERLAPS / OVERLAPPED-BY** | ✅ **YES, in the overlap** | **The contradiction is scoped to `I₁ ∩ I₂` — and the `ContradictionRecord.scope_overlap` field records exactly that. ⟹ A claim may be CONTESTED during an interval and SUPPORTED outside it** |
| **DURING / CONTAINS** | ✅ **YES, in the inner interval** | Same, scoped |
| **STARTS / STARTED-BY / FINISHES / FINISHED-BY** | ✅ **YES** | Same, scoped |
| **EQUALS** | ✅ **YES, fully** | Genuine CT-1 or CT-2 |

**R23.2 (THE RESULT).** *Temporal contradiction is always **SCOPED TO AN INTERVAL**, never global. **⟹ «A contradicts B» is not a well-formed statement in this architecture; «A contradicts B during *I*» is.** A memory system that stores unscoped contradictions reports every change in the world as an inconsistency in its beliefs — which is CT-3's misdetection, and it is the single most common failure of naive temporal memory.*

## 23.3 What temporal order may and may not establish

| Temporal relation | **May establish** | **MUST NOT establish** |
|---|---|---|
| `A` before `B` | Record order, for audit and reconstruction | **Causation.** §16.1: `caused_by` is not a memory edge; causal inference is evaluator-side (P0-03 RULE 5.9) |
| `A` before `B` | That `B` could have used `A` | **That `B` DID use `A`.** ⟵ This is the inference that makes repetition look like corroboration (§30) |
| `A` recent | That `A` is likely still within its validity interval | **That `A` is more likely TRUE.** COMM-INV-12 |
| `A` and `B` simultaneous | Correlation dim 5 (**they may share a cause**) | **Independence.** ⟵ **Simultaneity is EVIDENCE OF CORRELATION, and the naive reading is the opposite** |
| `A` superseded `B` | That `A` is current | **That `A` is correct.** §36: supersession is a version relation, not a truth judgement |

---

# §24. CONTEXTUAL MEMORY MODEL — **OUTPUT 25 (part 2)**

## 24.1 The context representation

> ### **R24.1.** *`context_scope` is a MANDATORY struct with individually OPTIONAL dimensions. A record with no `context_scope` is MALFORMED and is rejected at ingestion step [1].*

```
context_scope = {
  task_ref?        : which task specification this holds under
                     **⟵ P0-01 R17.3: «verified» is task-specific**
  env_ref?         : which environment (Σ or ℛ, and which instance)
                     **⟵ P0-01 R4.3: M_ℰ must not be an evaluation input,
                        so a record scoped to a model is scoped to a model**
  agent_ref?       : which agent/cell/circuit/region this holds for
                     **⟵ a record about cell X's θ is not a record about the
                        organism's θ**
  hw_class?        : which hardware class
                     **⟵ P0-03 R57.1's portability requirement: a record
                        whose validity depends on hardware MUST declare it,
                        or §88's portability is silently violated**
  policy_version?  : which policy this holds under
                     **⟵ the `VOID_CONTEXT` hook (P0-02 §12)**
  epoch_range?     : which governance epochs
  scale_class?     : which scale regime (10¹ / 10³ / 10⁶ / 10⁹ / 10¹²)
                     **⟵ §56: a record valid at 10³ may be invalid at 10⁹,
                        and this is the field that says so**
}
```

## 24.2 Context matching at retrieval

> ### **R24.2 (THE CONTEXT-COLLAPSE RULE).** *A record whose `context_scope` does not subsume the query's context is a **MALFORMED RESULT**, not a weaker result. **It MUST NOT be returned.***

```
WHY "MALFORMED" AND NOT "WEAKER":
  A weaker result can be used with a discount. **A claim that does not apply
  in this context cannot be used at any discount** — «θ_write = 0.7 worked in
  task A» retrieved during task B is not a 60%-useful hint, it is a category
  error, and acting on it is #13's context-stripping attack succeeding
  through the retrieval path rather than the ingestion path.

  ⟹ **R1.2's context-collapse trap is closed by making context a RETRIEVAL
     FILTER, not a RANKING SIGNAL.**

THE ASYMMETRY THAT MAKES IT SAFE:
  • A record with a NARROW scope retrieved in a NARROWER query context
    ⟹ **admissible** (the claim holds in a superset of the query context)
  • A record with a NARROW scope retrieved in a BROADER query context
    ⟹ **MALFORMED. Reject.**
  • A record with NO declared scope on a dimension the query specifies
    ⟹ **⚠️ P0-03 R37.1: UNKNOWN ≠ DISJOINT.** The record MAY apply.
    ⟹ **Return it, flagged `SCOPE_UNKNOWN_ON(dim)`, and the reader's
       warrant computation MUST treat an unknown scope as a warrant
       reduction, never as a scope match.**

⟹ **THE CONSERVATIVE DIRECTION IS DECLARED: an undeclared scope is treated
   as UNKNOWN, never as UNIVERSAL.** A system that treats undeclared scope as
   universal has made every context-free what was merely context-unstated —
   which is #13 succeeding by default rather than by attack.
```

## 24.3 The three context failures

| Failure | **Mechanism** | **Defense** |
|---|---|---|
| **Context stripping (#13)** | A record is stored without its context, so it is retrieved everywhere | **`context_scope` is MANDATORY; a record without it is MALFORMED (rejected at step [1])** |
| **Context collapse** | A record scoped to *C₁* is retrieved in *C₂* | **R24.2: retrieval filter, not ranking signal** |
| **Context inflation** | A record's scope is *widened* after storage — by consolidation, generalization, or compression | **MEM-M2 applied to scope: `scope(derived) ⊆ ∩ scope(sources)` (R32.2). ⟹ NO OPERATION WIDENS A SCOPE. This is the single rule that makes §32's generalization safe** |

**R24.3 (CONTEXT IS PART OF THE CLAIM'S IDENTITY).** *§15.2's D-3 dedup keys on (proposition, context scope, validity interval) — **not on proposition alone.*** **⟹ The same proposition in two disjoint contexts is TWO claims, and they may hold different belief states simultaneously without contradiction. This is CT-4's resolution built into the identity of the object rather than into the detector.**

---

# §25. RETRIEVAL ARCHITECTURE — **OUTPUT 26**

## 25.1 **OUTPUT 26 — the retrieval contract**

```
RETRIEVAL IS AN S1/S2 MESSAGE EXCHANGE WITH A SERVICE (P0-03 R42.1/R42.2):

  REQUEST  (subject → Memory Service)
    query          : typed, bounded
    query_context  : **MANDATORY — the context_scope of the querying
                     situation (R24.2). A query without a context is
                     MALFORMED**
    query_epoch    : for freshness and COMM-INV-13
    budget         : max results, max latency, max work — **all [G]-bounded**
    purpose_class  : **⚠️ what the result will be used for. This is NOT an
                     epistemic input; it is a COMPILE-TIME selection of
                     which indexes to consult and which filters to apply.
                     A query for «act now» applies stricter staleness and
                     scope filters than a query for «explore». §25.4**
    compartment    : §52's access class the requester holds

  RESPONSE (`mem.result.v1`, SERVICE-SIGNED — Cell §6.2)
    results[]      : **each is a TRIPLE: (record_ref, rank, evidence_status)**
                     **⟵ §27: rank and evidence_status are SEPARATE outputs.
                      A consumer that reads only the rank has violated the
                      contract**
    declined?      : **the service MAY DECLINE (budget exhausted, no match,
                     compartment insufficient, epoch stale)**
    scope_warnings[]: `SCOPE_UNKNOWN_ON(dim)` flags (R24.2)
    staleness[]    : each result's `revalidation_state` (§22.2)
    service_sig    : **signature proves the service did not alter the result.
                     ⟵ P0-02 R20.2 / R19.4: a signature proves ORIGIN and
                     NON-ALTERATION, NEVER TRUTH**

  HARD RULES (all inherited, all binding):
    • **«May decline, may not alter»** (Cell §6.2's `mem.result.v1`)
    • **`≤ RETR_BYTES_MAX`** — a bounded response
    • **The learnable retrieval function is INFLUENCE-PLANE and MUST NEVER
      affect warrant** (R42.2)
    • **Retrieval is WARRANT-NEUTRAL TRANSPORT: `n_obs += 0`,
      `causal_depth += 1`** (R42.1)
    • **Attention is a QUERY PRIOR, warrant-neutral** (P0-03)
    • **Retrieval MUST NOT WRITE TO THE RETRIEVED RECORD** (§30, MEM-INV-09)
```

## 25.2 The five indexes

**Vol A §2.4's hybrid, at the retrieval layer. Each index is a VIEW (V1–V4): rebuildable, lossy, never authoritative.**

| Index | **Component** | **Answers** | **Cost** | **⚠️ Failure mode** |
|---|---|---|---|---|
| **I-1 EXACT** | **H (symbolic)** | «the record with `mem_id` / this exact typed key» | `O(1)` | None — this is the authoritative lookup |
| **I-2 CONTENT-HASH** | **D (content-addressed)** | «records with identical content» | `O(1)` | **§15.2 D-1: identical content ≠ identical provenance. MUST link, never merge** |
| **I-3 SIMILARITY** | **G (vector/embedding)** | «records semantically near this query» | `O(log)` ANN | **⚠️ THE DANGEROUS ONE. Similarity is not relevance, relevance is not truth (§27). Two opposing claims can be adjacent — which is what a vector store DOES, not what an attacker makes it do (§2.3's K2/K5 ✗✗). ⟹ I-3 results are ALWAYS `evidence_status`-tagged and NEVER admissible as the sole retrieval path for a consequential decision** |
| **I-4 INTERVAL** | **V3 (temporal view)** | «records whose event/validity interval overlaps *I*» | `O(log + k)` | **§23: must distinguish `event_interval` from `record_interval`** |
| **I-5 GRAPH** | **F/V4 (bounded-depth claim graph)** | «claims supporting / contradicting / derived-from X, within depth *d*» | `O(d)` | **Vol A §16.2: `d` is `[G]`-bounded. An unbounded traversal is an evaluator-side operation (§95)** |

**R25.1 (INDEX FUSION, AND WHY IT IS NOT VOTING).** *Results from multiple indexes are UNIONED and de-duplicated by `mem_id`, then FILTERED by `context_scope` (R24.2) and by compartment (§52), then RANKED (§27).* **⟹ Fusion is a set operation on identities, never a vote on truth. P0-03's partition rule applies verbatim: «UNION for append-only records; RE-EVALUATE for derived state; NEVER VOTE.» An index that appears in three of five results is not more likely to be right — it is the same record, found three ways.**

**R25.2 (INDEX FAILURE IS NEVER RECORD FAILURE).** *An index may be wrong, stale, corrupt, hardware-specific, or entirely absent. **The record store is the authority; the index is a path to it. A record that no index can find still exists and still has its warrant.** ⟹ §57's separation, and §98's ablation: removing I-3 degrades recall and changes nothing epistemic; removing the record store destroys the memory.*

## 25.3 The retrieval budget

| Dimension | **Bound** | **On exhaustion** |
|---|---|---|
| Result count | `[G]` per query class | **DECLINE with `BUDGET_EXHAUSTED`, never truncate silently** |
| Latency | `[G]` | **DECLINE. ⟵ A late result that is used as if fresh is §22's staleness failure** |
| Work (index traversals) | `[G]` | **DECLINE** |
| Bytes | `RETR_BYTES_MAX` (inherited) | **DECLINE** |
| Depth (graph) | `[G]` | **Return the bounded result, flagged `DEPTH_TRUNCATED`** |
| Rate per subject | KC-3 ceiling | **Throttle; immune report on sustained excess (§49)** |

**R25.3 (DECLINE IS A FIRST-CLASS OUTCOME).** *Every budget exhaustion produces an explicit DECLINE with a reason, and **a DECLINE is recorded in the retrieval trace**. A silent empty result is indistinguishable from «nothing matches», and §39's ignorance representation requires the difference:* **`NO_MATCH` (we looked, nothing fits) ≠ `BUDGET_EXHAUSTED` (we stopped looking) ≠ `DECLINED_COMPARTMENT` (you may not look) ≠ `MALFORMED_QUERY` (the question was ill-formed).*** **⟹ Four distinct empty-result reasons, because P0-01 R9.1's absence-≠-negation rule applies to retrieval as much as to ground truth.**

## 25.4 `purpose_class` — the one legitimate use of intent in retrieval

```
THE TEMPTATION: let the requester's purpose influence the RESULT.
THE PROHIBITION: R42.2 — a learnable retrieval function is influence-plane
and must never affect warrant.

⟹ **THE RESOLUTION: `purpose_class` selects FILTERS, and filters may only
   REMOVE results, never ADD, RE-RANK, or MODIFY them.**

  purpose = ACT_NOW       ⟹ apply: staleness must be FRESH · scope must
                              SUBSUME (not UNKNOWN) · evidence_status ≥ E3
  purpose = EXPLORE       ⟹ apply: none of the above; SCOPE_UNKNOWN
                              permitted and flagged
  purpose = AUDIT         ⟹ apply: include SUPERSEDED, VOID, RETRACTED,
                              and L2-compressed records that ACT_NOW excludes
  purpose = CONSOLIDATE   ⟹ apply: §31's gate prerequisites only

⟹ **EVERY FILTER IS MONOTONE-REMOVING. A purpose can make the result set
   SMALLER and can never make it LARGER, can never change a record's
   evidence_status, and can never change a rank.**

⟹ **AND THIS IS WHY `purpose_class` IS ADMISSIBLE WHILE «RELEVANCE» IS NOT:**
   a purpose is a declared, policy-checked, auditable filter selection.
   «Relevance» is an unspecified judgement that, if it could add or reorder
   results, would be §11.4's attention gate with write access to the
   epistemics.
```

---

# §26. RETRIEVAL / TRUTH SEPARATION — **OUTPUT 27**

## 26.1 **OUTPUT 27 — the separation**

> ### **R26.1 (THE CENTRAL RULE OF THIS VOLUME).** *Retrieval answers **«WHAT MATCHES?»**. It never answers **«WHAT IS TRUE?»**. The two questions have different answer types, different authorities, and different failure modes, and no component of the architecture may convert an answer to the first into an answer to the second.*

| | **RETRIEVAL** | **TRUTH** |
|---|---|---|
| **Question** | What records match this query in this context? | Does this claim hold in ℛ? |
| **Answer type** | A ranked, filtered, budgeted SET of record references | **⚠️ NOT ANSWERABLE.** §4.2 R4.2: truth is a property of ℛ and the organism has no access to ℛ except through L0–L6 ground-truth claims |
| **Authority** | The Memory Service (GP), within compartment | **EVA, within a declared `gt_class` and task scope. NEVER the Memory Service** |
| **Plane** | **INFLUENCE** (which records are surfaced) + **TRANSPORT** (the envelope) | **WARRANT** — and it is external |
| **May it be learned?** | ✅ **Yes — retrieval weights are learnable** (Cell C1: «minimal learning of retrieval weights only») | ❌ **No. R13.1: no internal pathway from belief to verdict** |
| **Failure mode** | Low recall, low precision, bias (§28) | **Overclaiming — and the architecture's answer is that it does not attempt it** |

## 26.2 The four structural separations

| # | Separation | **Mechanism** | **What it defeats** |
|---|---|---|---|
| **S-1** | **Retrieval result ≠ belief input** | A retrieved record is `SC-12 RETRIEVED`; its `n_obs` contribution is **0**; its `causal_depth` is **+1** | #19 self-reinforcing false belief; FM-4 |
| **S-2** | **Retrieval rank ≠ evidence status** | The response is a set of **TRIPLES** `(record_ref, rank, evidence_status)`. **Rank is computed by the influence-plane retrieval function; `evidence_status` is copied from the record and is externally written. They are different fields from different planes** | §27's rank-as-truth; R1.2's availability capture |
| **S-3** | **Retrieval frequency ≠ corroboration** | **Retrieval MUST NOT write to the retrieved record** (MEM-INV-09). Access statistics live in a separate homeostatic aggregate at `O(R)` | §30's repetition-as-evidence; D-1's counter |
| **S-4** | **Retrieval availability ≠ existence** | §25.3 R25.3's four distinct empty-result reasons. **A record that no index surfaces still exists with its full warrant** | Availability capture; survivorship bias (§28) |

**R26.2 (WHY S-2 IS THE ONE THAT MATTERS MOST).** *Every other separation can be enforced by a rule. **S-2 must be enforced by the SHAPE OF THE RETURN TYPE.** If the retrieval response is a ranked list, a consumer will read the list order as a quality order — not through malice, but because a list has an order and the order is the most salient thing about it.* **⟹ Making rank and evidence_status separate fields of a triple is not a documentation convention; it is a type-level separation, and it is the only one of the four that cannot be violated by inattention.**

## 26.3 The availability-capture trap — R1.2's fifth trap, closed

```
THE TRAP: what is easy to retrieve determines what is believed, so the
retrieval index becomes the epistemology.

WHY IT IS SEDUCTIVE: the retrieval function is LEARNABLE (Cell C1), so it
improves with use, so frequently-retrieved records become easier to
retrieve, so the belief system converges on whatever the retrieval function
finds easy. **This is a genuine attractor, and it operates entirely on the
influence plane where no warrant rule applies.**

WHY IT FAILS HERE — THREE INDEPENDENT BLOCKS:

 1. **S-1/S-3: retrieval cannot raise belief.** The attractor makes some
    records MORE VISIBLE. It cannot make them MORE WARRANTED. **A belief
    system that only ever sees E0 records still has only E0 beliefs.**

 2. **§28's MEM-D2 detector: a subject whose n_effective rises while its
    distinct root_commit count is flat is RETRIEVING, NOT LEARNING.**
    ⟹ The attractor is OBSERVABLE as a divergence between retrieval
    frequency and evidence accumulation, at O(R) per epoch.

 3. **§25.4's `purpose_class = EXPLORE` filter set is EMPTY.** An exploring
    query applies no staleness, no scope-subsumption, and no
    evidence-status filter. **⟹ The architecture retains a retrieval mode
    in which the attractor's preferences are deliberately not applied, and
    §90's bounded optimism budget requires its use.**

⚠️ **RESIDUE, DECLARED:** blocks 1–3 stop the attractor from changing what
   is BELIEVED. They do not stop it from changing what is CONSIDERED. **A
   system that never retrieves a hypothesis never tests it, and an untested
   hypothesis stays HYPOTHESIS forever — which is not a false belief, but it
   is a permanent gap.** **§100 OR-M6: the exploration/retrieval coupling is
   bounded but not closed, and it is the memory-layer form of the same limit
   as §11.4's R11.4 residue (a cell can choose what to notice) and FM-4's
   `[U]` (semantic self-reference). All three are the same problem: an
   instrument cannot fully audit the mechanism by which its subject decides
   what to show it.**
```

---

# §27. RANKING VS TRUTH RANKING

## 27.1 What ranking is for

> ### **R27.1.** *Ranking is an **ALLOCATION** function: given more matching records than the budget permits, it decides which the requester sees. **It is a resource-allocation decision on the influence plane, and it is not an epistemic judgement on any plane.***

## 27.2 The admissible ranking signals — and the prohibited ones

| Signal | **Admissible?** | **Why** |
|---|---|---|
| **Query-match score** (exact, hash, similarity, interval overlap, graph distance) | ✅ | It is what «matches» means |
| **Recency** (within `validity`) | ✅ **as an allocation signal** | A fresher record is more likely still valid — **⚠️ and this is a statement about VALIDITY, never about TRUTH (§23.3)** |
| **`evidence_status`** | ✅ **as a FILTER (§25.4), and as a SEPARATE RETURNED FIELD (§26.2 S-2). ⚠️ NEVER as a rank multiplier** | **Making E4 outrank E3 in the ranking conflates the two planes. A filter says «E0 is not admissible for ACT_NOW»; a rank says «E4 is better». The first is a policy fact; the second is a truth claim** |
| **`n_effective`** | ⚠️ **Only via the filter path, and only for `purpose_class = ACT_NOW`** | Same argument |
| **Dependency count** (how many decisions rest on this record) | ✅ **for revalidation priority (§22.3), ❌ for retrieval rank** | Dependency is about what matters to the organism, not about what matches the query |
| ~~**Access frequency**~~ | ❌ **PROHIBITED** | §26.2 S-3, MEM-INV-09, §30 |
| ~~**Citation count**~~ | ❌ **PROHIBITED** | R19.2 N9 |
| ~~**Importance**~~ | ❌ **PROHIBITED** | D-2, R11.2 |
| ~~**Confidence (any scalar)**~~ | ❌ **PROHIBITED — does not exist** | R18.1 |
| ~~**Consensus / agreement among records**~~ | ❌ **PROHIBITED** | R19.2 N7, L7 |
| ~~**Similarity to the requester's existing beliefs**~~ | ❌ **PROHIBITED** | **This is confirmation bias implemented as a ranking function.** §28 |

## 27.3 The decisive case

```
THE CASE: a query returns two records.
  r₁ — rank 1, similarity 0.97, evidence_status E0, SC-11 RECONSTRUCTED,
       from_cache: true, EXPIRED
  r₂ — rank 47, similarity 0.31, evidence_status E4, SC-2 EXTERNAL_MEASURED,
       anchored, FRESH, GROUNDED

**r₁ IS THE BETTER MATCH. r₂ IS THE BETTER EVIDENCE. BOTH STATEMENTS ARE
  TRUE AND THEY ARE NOT IN TENSION — THEY ARE ANSWERS TO DIFFERENT
  QUESTIONS.**

⟹ **THE CONTRACT'S REQUIREMENT:** the response contains
     (r₁, rank=1,  E0)  and  (r₂, rank=47, E4)
   **as triples.** A consumer acting on rank alone retrieves a cached,
   expired, reconstructed E0 record and treats it as the answer. **A
   consumer acting on the triple sees that the top match is E0 and that an
   E4 record exists at rank 47.**

⟹ **AND THE FILTER PATH IS WHAT MAKES THIS USABLE:** with
   `purpose_class = ACT_NOW`, r₁ is REMOVED (expired, cached, below E3) and
   r₂ is returned. **The filter did not re-rank; it excluded. And the
   exclusion is declared, policy-checked, and auditable (§25.4).**

⟹ **R27.2: THE ARCHITECTURE NEVER PRODUCES A SINGLE ORDERED LIST THAT A
   CONSUMER COULD MISTAKE FOR A TRUTH ORDERING. It produces a triple set
   plus a declared filter. **A single ordered list of records, unannotated,
   is a prohibited return type.**
```

---

# §28. SOURCE BIAS & RETRIEVAL BIAS

## 28.1 The seven biases

| # | Bias | **Mechanism** | **Detector** | **Status** |
|---|---|---|---|---|
| **B-1** | **Source bias** | The evidence corpus over-represents some sources — one instrument class, one region, one peer group | **MEM-D4: the distribution of `sensor_id` / `src_identity` / `gt_class` across a subject's E2+ corpus, compared against the input distribution it received.** `O(R)` aggregate | ✅ **DETECTABLE** |
| **B-2** | **Retrieval bias** | The learned retrieval function systematically favours some records (§26.3's attractor) | **MEM-D2: `n_effective` rising while distinct `root_commit` count is flat** | ✅ **DETECTABLE** |
| **B-3** | **Availability bias** | What is indexed is what is believed; unindexed records are effectively absent | **MEM-D5: the fraction of the record store reachable by each index. An index whose reachable fraction falls below a `[G]` threshold is STALE and must be rebuilt** | ✅ **DETECTABLE** |
| **B-4** | **Survivorship bias** | **Forgetting creates it.** Records that were forgotten cannot be retrieved, so the surviving corpus looks more consistent than the history was | **⚠️ PARTIALLY DETECTABLE: the Anchor's epoch digests record that a set of records EXISTED (Vol A §14.2's L4). A survivorship audit compares the digested set against the surviving set. ⟹ THE COUNT IS RECOVERABLE; THE CONTENT IS NOT.** | ⚠️ **PARTIAL — §34.6** |
| **B-5** | **Confirmation bias** | The subject attends to confirming evidence and not to disconfirming evidence (**§11.4's D-2 residue; Cell audit L1832: «a cell can choose what to notice»**) | **MEM-D1: a subject whose retained corpus has a systematically LOWER CONTRADICTION RATE than its input distribution implies is not harmonious — it is filtering.** ⟵ **P0-03 R67.1's memory instance: a zero-contradiction-report rate above a `[G]`-declared duration is an immune incident** | ⚠️ **DETECTABLE IF SYSTEMATIC; NOT DETECTABLE IF OCCASIONAL — §100 OR-M2** |
| **B-6** | **Recency bias** | Recent records dominate retrieval (§27.2's recency signal) and older grounded records are never surfaced | **MEM-D6: the `write_epoch` distribution of retrieved-and-used records vs. the `validity`-appropriate distribution** | ✅ **DETECTABLE** |
| **B-7** | **Quota gaming** | **⟵ THE DETECTOR THAT WAS REFERENCED BEFORE IT WAS DEFINED, AND IT IS THE ONE THAT MATTERS MOST.** A subject satisfies the consolidation external-evidence quota by citing the SAME external record across many consolidations — the quota's *count* is met while `n_effective` contributes 1 | **MEM-D3: `inbreeding_F` rising while the external quota remains satisfied. ⟹ AND THE STRUCTURAL FIX, WHICH MAKES THE DETECTOR A BACKSTOP RATHER THAN THE DEFENSE: Vol D R66.2 / MEM-INV-41 — the quota MUST be expressed on `n_effective`, NOT on record count. **A quota on `n_effective` cannot be gamed by repetition, because `n_effective` has already collapsed the repetition (§21.3)**** | ✅ **DETECTABLE — and structurally closed by MEM-INV-41** |

## 28.2 The general detector pattern

> ### **R28.1 (BIAS IS DETECTED BY COMPARING A SUBJECT'S OUTPUT DISTRIBUTION TO ITS INPUT DISTRIBUTION — never by inspecting the subject's reasoning.)** *Seven biases, six detectors: B-1→MEM-D4, B-2→MEM-D2, B-3→MEM-D5, B-5→MEM-D1, B-6→MEM-D6, B-7→MEM-D3. **B-4 (survivorship) has no detector — only the partial audit of Vol C R34.7, because the content of what was forgotten is unrecoverable even though its count and roots are not.***

```
THE PATTERN, FOR ALL SIX:
   input_distribution(subject, dim)   — what the subject RECEIVED, which is
                                        knowable from the transport plane
                                        (P0-03's envelopes are logged at
                                        Tier-2)
   output_distribution(subject, dim)  — what the subject RETAINED / RETRIEVED
                                        / CITED, knowable from the record
                                        store at O(R) aggregate

   **DIVERGENCE(input, output) ABOVE A [G] THRESHOLD ⟹ BIAS INCIDENT.**

WHY THIS WORKS WITHOUT MIND-READING:
  Both distributions are EXTERNAL OBSERVABLES. Neither requires access to
  the subject's internal state, its attention mechanism, or its retrieval
  weights. **⟹ This is P0-03's behaviour-not-intent discipline (§67) applied
  to memory, and it is the only form of bias detection that scales to 10¹²
  subjects.**

WHY IT IS INCOMPLETE, DECLARED:
  A subject that filters OCCASIONALLY, or that filters in a way that keeps
  its aggregate distribution plausible, is not detected. **And a subject
  whose INPUT distribution is itself biased (because its upstream peers
  filter) shows no divergence at all — the bias is inherited, not produced.**
  ⟹ **§100 OR-M2. And the inherited case is dim 6 in bias form: a shared
     latent assumption about what is worth noticing.**
```

**R28.2 (THE `importance` QUESTION, FINALLY ANSWERED).** *D-2 asked whether an undefined, cell-influenced scalar can gate write, retention, and promotion. **§11.4 answered: it may gate the first two as an ALLOCATION quantity computed by homeostasis, and never the third. §28 supplies what §11.4 could not: the DETECTOR.*** **⟹ `importance` remains cell-influenced for local episodic write, and MEM-D1/D2/D4/D5/D6 make the *consequences* of that influence visible at `O(R)` per epoch. The gate is not closed; the gate's output is monitored. That is the strongest available result and §100 records the residue.**

---

# §29. FEEDBACK LOOPS & SELF-CORRUPTION

## 29.1 Every loop in the memory system, enumerated

**«Attack before improving.»** Ten loops; four closed structurally, three bounded with declared residue, two detectable-only, one **UNCLOSED**.

| # | Loop | **Path** | **Status** | **Mechanism / residue** |
|---|---|---|---|---|
| **L-1** | **The brief's loop** | Observation → Message → Memory → Belief → Communication → propagation → apparent independence → strengthening → Memory | ✅ **CLOSED STRUCTURALLY** | **R19.3: the set of internal events that may raise a belief is EMPTY. «Belief strengthening» requires U1–U8, all external. §10.3 shows the propagation step dying at four separate points** |
| **L-2** | **Retrieval self-reinforcement** | Retrieve → access count rises → importance rises → rank rises → retrieve more | ✅ **CLOSED STRUCTURALLY** | **MEM-INV-09: retrieval MUST NOT write to the retrieved record. `access_count` is PROHIBITED as an epistemic input (Vol A §5.1) and is banned from ranking (§27.2)** |
| **L-3** | **Consolidation self-justification** | Records → consolidate → the consolidated record cites its own sources as independent support → consolidate again | ✅ **CLOSED STRUCTURALLY** | **MEM-M3: `n_effective(derived) ≤ n_effective(sources)`, and a derived record's own prior retrievals contribute zero. Plus `inbreeding_F` monotone non-decreasing under self-derived operations (MEM-M4)** |
| **L-4** | **Generalization scope creep** | Instances in context C → generalize → the general rule is retrieved in context C′ → C′ instances support the rule → generalize further | ✅ **CLOSED STRUCTURALLY** | **R32.2: `scope(derived) ⊆ ∩ scope(sources)`. NO OPERATION WIDENS A SCOPE (§24.3). ⟹ The rule can never leave the context its instances came from** |
| **L-5** | **Inbreeding drift** | Internal evidence → belief → more internal evidence → `inbreeding_F` rises → but the subject does not notice | ⚠️ **BOUNDED, RESIDUE DECLARED** | **`inbreeding_F` is Anchor-computed and read-only, and `F > F_max ⟹ S6 abstain` (Cell FM-4). ⟹ BOUNDED. **Residue: `F_max` is a `[G]` parameter whose correct value is unknown (§99), and a subject whose evidence is internally generated but ANCHORED has a low measured `F` — the anchor attests provenance, not externality of ORIGIN** |
| **L-6** | **Calibration circularity** | Beliefs → calibration scoring → recalibrated instruments → new beliefs | ⚠️ **BOUNDED** | **P0-01: calibration scoring requires E4, and E4 requires L0–L3 ground truth. **⟹ The loop passes through EVA every iteration and cannot close internally.** Residue: R18.4 — a domain with no GT supply is permanently uncalibratable, and its calibration state MUST be `UNRESOLVED`** |
| **L-7** | **Contradiction suppression** | Contradiction detected → suppressed → belief strengthens → fewer contradictions detected | ⚠️ **BOUNDED** | **The detector runs in the Memory Service at ingestion, not in the subject (§20.5). A subject cannot prevent detection of a contradiction between its record and an existing one. **Residue: a subject can avoid WRITING the record that would contradict — which is B-5's confirmation bias, MEM-D1's target** |
| **L-8** | **Retrieval-weight capture** | Retrieval weights learn → favoured records surface → favoured records are used → weights reinforce | ⚠️ **DETECTABLE ONLY** | **§26.3: MEM-D2 detects it. **⟹ BOUNDED IN EFFECT (cannot change warrant) but NOT BOUNDED IN EXTENT (can change what is considered). §100 OR-M6** |
| **L-9** | **Survivorship narrowing** | Forgetting → the corpus narrows → the narrowed corpus looks consistent → less contradiction → less revalidation → more forgetting | ⚠️ **DETECTABLE ONLY** | **B-4: the Anchor's epoch digests make the COUNT of forgotten records recoverable, never the content. ⟹ A survivorship audit can detect narrowing but cannot reconstruct what was lost. §34.6** |
| **L-10** | **SEMANTIC SELF-REFERENCE** | A record's meaning depends on other records whose meaning depends on it — **a closed loop in the SEMANTIC layer that has no provenance signature at all** | ❌ **UNCLOSED** | **⟵ THIS IS FM-4's `[U]` RESIDUE, INHERITED VERBATIM: «Bounding this requires a measure of *semantic* self-reference, not just provenance-graph depth. **No rigorous mechanism is proposed here.**» `inbreeding_F` measures PROVENANCE ancestry. `causal_depth` measures DERIVATION depth. **NEITHER MEASURES MEANING DEPENDENCE.** A set of records can be externally sourced, independently anchored, dim-1–5 disjoint, and still form a closed semantic circle in which each term is defined by the others. **§81 analyses it; §100 OR-M1 records it as P0-04's principal unclosed dependency; Vol A §5.1 declares the missing field `semantic_self_reference_score` as `[U]`** |

## 29.2 Self-corruption — the five paths

**«Can memory corrupt itself without external attack?»** Yes, in five ways, and each is a loop above seen from the other side:

| Path | **Mechanism** | **Loop** | **Blocked by** |
|---|---|---|---|
| **SC-1** | **Belief → evidence**: an internally generated belief is stored and later retrieved as support for itself | L-1, L-3 | **R19.2 N7/N8; `source_class` immutability (R12.1); SC-14's permanent E0 ceiling** |
| **SC-2** | **Repetition → corroboration**: the same content, re-emitted, looks like multiple observations | L-1 | **§10.3's four-point closure; §15.2 D-2** |
| **SC-3** | **Compression → certainty**: a compressed record loses the qualifiers that made it tentative, and the compressed form reads as more definite | L-3 | **§33: DP-1…DP-10 are decision properties; losing one is DESTRUCTION, not compression. And a record compressed below L1 becomes a TRACE, which makes no claim (R14.2)** |
| **SC-4** | **Generalization → law**: instances become a rule, and the rule is cited without its instances | L-4 | **R32.1/R32.2: warrant ≤ min(instances), scope ⊆ ∩ contexts. And the generalization RETAINS `instance_refs` — a rule whose instances are gone is not retrievable as support** |
| **SC-5** | **Forgetting → consistency**: inconvenient records expire, and the surviving corpus is artificially coherent | L-9 | **⚠️ PARTIALLY. B-4's survivorship audit detects narrowing. ⟹ BUT: a record that expired legitimately (its validity lapsed) is indistinguishable from one that expired inconveniently. §34.6 declares this** |

**R29.1 (THE HONEST SUMMARY).** *Four of five self-corruption paths are structurally blocked, and the fifth is detectable but not preventable. **The one loop that is not closed at all (L-10) is not a corruption loop — it is a MEANING loop, and it is the reason FM-4's residue is `[U]` rather than merely hard.*** **⟹ §104's EVIDENCE-INDEPENDENCE rating is PARTIAL, not PASS, and L-10 is the reason.**

---

# §30. REPETITION, REINFORCEMENT & SELF-STRENGTHENING

## 30.1 «Do not equate repetition with truth»

> ### **R30.1 (THE THREE THINGS REPETITION LEGITIMATELY DOES, AND THE ONE THING IT NEVER DOES).**

| Repetition MAY… | **Plane** | **Mechanism** |
|---|---|---|
| **Raise retrieval priority** (within a bounded budget) | INFLUENCE | §27.2: recency is an admissible allocation signal; **⚠️ access frequency is NOT** — the distinction is that recency is a property of the record's `validity` and frequency is a property of the subject's behaviour |
| **Trigger a consolidation CANDIDACY** | ALLOCATION | **Cell T6: «repeated success → CONSOLIDATION CANDIDATE, NOT a large Δθ.» ⟹ Repetition schedules work; it does not produce warrant** |
| **Nominate a hypothesis for external testing** | ALLOCATION | **§30.2's resolution of X3** |
| ~~**Raise `evidence_status`, `n_effective`, `belief_state`, or warrant**~~ | ❌ **NEVER** | **R19.2 N2. MEM-M3: a record's own prior retrievals contribute zero to `n_effective`** |

## 30.2 **X3 RESOLVED — «REPEATED ADVANTAGE → EVOLUTIONARY SANDBOX»**

⚠️ **CONTRADICTION X3:** V3.1 §10 lists **«REPEATED ADVANTAGE? → YES → EVOLUTIONARY SANDBOX»** as a promotion criterion, while V3 §30's anti-repetition principle (and this package's R30.1) prohibits repetition as evidence.

```
THE APPARENT CONFLICT: if repetition is never evidence, how can «repeated
advantage» promote anything?

THE RESOLUTION — **AND IT TURNES ON WHAT «ADVANTAGE» MEANS, NOT ON WHAT
«REPEATED» MEANS:**

  «REPEATED» alone proves nothing. **Ten occurrences of an internally
  judged advantage are one occurrence, counted ten times (§10.3).**

  «ADVANTAGE» is an OUTCOME, and an outcome is **L6 POST-HOC GROUND TRUTH**
  (P0-01 §8.2: «the cheapest and most realistic class»). **L6 IS AN
  ADMISSIBLE GROUND-TRUTH CLASS — it is one of L0–L6, and only L7 is
  prohibited.**

  ⟹ **«REPEATED ADVANTAGE» IS NOT REPETITION AS EVIDENCE. IT IS n INDEPENDENT
     L6 MEASUREMENTS OF AN OUTCOME.** And n independent L6 measurements ARE
     evidence — provided they are independent, which is §21's test, applied
     to the outcomes rather than to the observations.

  ⟹ **THE CORRECT READING, AND IT IS A TWO-PART RULE:**
     **REPETITION MAY NOMINATE. ONLY EXTERNAL MEASUREMENT MAY DECIDE.**

     R30.2 (a) **Repetition of an internally-judged advantage produces a
                SANDBOX NOMINATION — a request to test, not a promotion.**
     R30.2 (b) **Promotion out of the sandbox requires an EXTERNAL
                measurement (L0–L6) that the advantage is real, with
                `n_effective` computed over the OUTCOMES (§21), not over the
                occurrences.**
     R30.2 (c) **A nomination is not evidence and MUST NOT raise
                `evidence_status`, `n_effective`, or `belief_state`
                (R30.1).**

⟹ **X3 DISSOLVES. V3.1's «REPEATED ADVANTAGE → SANDBOX» is CORRECT as
   written — the sandbox is the nomination, and the promotion criterion is
   what happens IN the sandbox, which is external measurement.** The
   contradiction was an artefact of reading «→ EVOLUTIONARY SANDBOX» as
   «→ PROMOTED», which the text does not say.

⟹ **AND THE RESIDUE, DECLARED: if the advantage judgement is itself
   internal (SC-7 ORGANISM_INFERENCE), then the NOMINATION is
   internally generated, and a system that only nominates its own
   preferences will only ever test its own preferences. **That is B-5's
   confirmation bias at the evolutionary layer, and MEM-D1 detects it the
   same way: a subject whose nomination distribution diverges from its
   input distribution is filtering.** §100 OR-M2 covers it.
```

## 30.3 The anti-repetition invariants

| Invariant | Statement | **Defeats** |
|---|---|---|
| **MEM-INV-09** | **Retrieval MUST NOT write to the retrieved record.** No access count, no importance increment, no rank feedback, no `n_obs` contribution | L-2, S-3, FM-4 |
| **MEM-INV-10** | **A record's own re-emissions MUST NOT be counted as independent support for itself.** `n_effective` collapses on shared `root_commit` (dim 1) | L-1, L-3, §10.3 |
| **MEM-INV-12** | **Repetition MUST NOT shorten a validity interval, raise an evidence status, or lower a staleness state.** Repetition is invisible to the warrant plane | R30.1 |
| **MEM-INV-13** | **Consolidation and generalization MUST NOT increase `n_effective` above the minimum of their inputs** (MEM-M3) | L-3, SC-3, SC-4 |

---

# §31. CONSOLIDATION ARCHITECTURE — **OUTPUT 28**

## 31.1 Attacking the inherited pipeline

**V3 §11: `Replay → importance → conflict detection → compression → generalization → versioned storage`.**

| Step | **Attack** | **Verdict** |
|---|---|---|
| **1. Replay** | ✅ Sound in principle — Cell §8.3's episodic replay, and P0-01's `08_…evaluation.md` L343 lists episodic replay as a drift-memory protection | **RETAIN** |
| **2. Importance** | ❌ **D-2. An UNDEFINED scalar (G-P1-8) in the second position of the pipeline, gating everything downstream.** And it is cell-influenced | **REPLACE** with dependency + evidence_status (§31.3) |
| **3. Conflict detection** | ❌ **MISORDERED.** Conflict detection runs AFTER importance — **so a record's importance has already been computed, and possibly already influenced what was replayed, before anyone checks whether it is contradicted.** A contradicted record with high importance is consolidated | **MOVE TO FIRST** |
| **4. Compression** | ❌ **MISORDERED, and worse than misordered.** Compression runs BEFORE generalization — **so generalization operates on compressed records, and compression may have discarded the `context_scope` detail that generalization needs to compute the scope intersection (R32.2)** | **MOVE AFTER generalization, and only to L1 (§33)** |
| **5. Generalization** | ⚠️ Sound as a step, **but with no warrant bound in the inherited pipeline** | **RETAIN + R32.1/R32.2** |
| **6. Versioned storage** | ✅ Sound — §36 | **RETAIN** |
| **— MISSING —** | ❌ **NO EVIDENCE-STATUS GATE ANYWHERE IN THE PIPELINE.** The inherited pipeline can consolidate E0 records | **ADD — this is the single most important correction** |
| **— MISSING —** | ❌ **NO `inbreeding_F` GATE.** Cell §8.3 and the consolidation gate at L1474/L776 require «external-evidence quota + `inbreeding_F ≤ F_max` + external corroboration» — **and V3 §11's pipeline has none of the three** | **ADD** |
| **— MISSING —** | ❌ **NO AUTHORITY.** Who runs consolidation? V3 does not say | **ADD — §8.1: Memory Authority approves; Memory Service executes** |

## 31.2 **OUTPUT 28 — the corrected consolidation architecture**

```
CONSOLIDATION — **IT DOES NOT MOVE RECORDS. IT CREATES A DERIVED RECORD.**
(Vol A R7.1: «a pipeline promotes records, and promotion is the loop's final
step. A create-and-bound model never promotes anything»)

  [G0] ELIGIBILITY          evidence_status ≥ E3 · anchored · retention_class
                            permits · not VOID · not EXPIRED
  [G1] CONTRADICTION FIRST  **no unresolved contradiction within scope.**
                            ⟵ MOVED FROM POSITION 3 TO POSITION 1.
                            A contradicted record is NOT a consolidation
                            candidate, at any importance
  [G2] INBREEDING           **inbreeding_F ≤ F_max** (Anchor-computed,
                            read-only) — Cell §8.3's gate
  [G3] EXTERNAL QUOTA       **the «mandatory external-evidence quota»
                            (Cell L1474/L776): ≥ [G]-declared fraction of
                            n_effective must come from SC-1…SC-6**
  [G4] SELECTION            **by DEPENDENCY and evidence_status (§22.3),
                            NEVER by `importance`** — D-2's resolution
  [G5] REPLAY               the eligible set is replayed. **Replay is a
                            READ operation. It does not write to the replayed
                            records (MEM-INV-09)**
  [G6] GROUPING             records are grouped by CLAIM identity (§15.2 D-3)
                            and by context_scope intersection
  [G7] GENERALIZATION       **§32's rules apply: warrant ≤ min, scope ⊆ ∩,
                            inbreeding_F ≥ max, n_effective ≤ min**
  [G8] VERSIONING           the derived record is created with
                            `version_kind = MERGE`, `parent_mem_id`s = the
                            sources, and **THE SOURCES ARE RETAINED**
                            (§36: never overwrite)
  [G9] COMPRESSION          **ONLY NOW, and ONLY to L1 (§33).** The SOURCES
                            may be compressed to L2/L4 on a `[G]` schedule;
                            the DERIVED record is stored at L1 minimum
  [G10] AUTHORIZATION       **Memory Service executes; Memory Authority
                            approves (§8.1). T4 CONSOLIDATED requires
                            E4 evidence status — so a consolidation whose
                            inputs are E3 produces an E3 record at T2, NOT
                            a T4 record. ⟹ CONSOLIDATION ALONE CANNOT REACH
                            T4. Only an external E4 gate can**
  [G11] ANCHOR              the derived record's root is anchored at the
                            next epoch (MEM-T2)

⟹ **THE PIPELINE'S CENTRAL PROPERTY: at every step, the derived record is
   WEAKER THAN OR EQUAL TO its sources (MEM-M2, MEM-M3, R32.1, R32.2), and
   the ONLY step that can make it stronger is an external E4 gate that is
   NOT PART OF CONSOLIDATION.**
```

**R31.1 (WHY G10 IS THE MOST IMPORTANT GATE).** *V3 §11's «CONSOLIDATION» and this package's T4 CONSOLIDATED tier are not the same thing, and conflating them is the error that would reopen §1's loop.* **Consolidation as an OPERATION groups, generalizes, and versions — all internal, all warrant-non-increasing. T4 as a TIER requires E4 evidence status — which requires an external L0–L3 measurement.** ⟹ **A consolidated record sits at T2 (semantic) unless and until an external gate grounds it. The word «consolidated» in the tier name refers to the record's *durability and scope*, not to its *warrant*.**

**R31.2 (THE STABILITY MECHANISM — Task 3 Rule 12).** *Every adaptive mechanism needs a stability mechanism. Consolidation's is threefold:* **(a)** the derived record never supersedes its sources, so a bad consolidation is reversible by ignoring the derived record; **(b)** consolidation RATE is a KC-3 ceiling (§9.1), so a runaway consolidation cannot consume the store; **(c)** `inbreeding_F ≥ max(sources)` (MEM-M4) means repeated consolidation of the same material monotonically raises `F` toward `F_max`, at which point G2 blocks further consolidation. **⟹ Consolidation is self-limiting: the more you consolidate your own material, the less you may consolidate.**

---

# §32. GENERALIZATION ARCHITECTURE — **OUTPUT 29**

## 32.1 The four bounding rules

> ### **R32.1 (MINIMUM WARRANT).** *`warrant(general) ≤ MIN over instances of warrant(instance)`.* **MEM-M2's instance for generalization. ⟹ A generalization built from nine E3 records and one E1 record is an E1 record.**

> ### **R32.2 (SCOPE INTERSECTION).** *`context_scope(general) ⊆ ∩ over instances of context_scope(instance)`.* **⟹ NO OPERATION IN THE ARCHITECTURE WIDENS A SCOPE (§24.3's context-inflation defense). A rule generalized from instances in tasks A, B, C applies to `A ∩ B ∩ C` — which may be empty, in which case the generalization is NOT ADMISSIBLE and is rejected at G7.**

> ### **R32.3 (MAXIMUM INBREEDING).** *`inbreeding_F(general) ≥ MAX over instances of inbreeding_F(instance)`.* **MEM-M4's instance. ⟹ A generalization over internally-derived instances is at least as internally derived as the worst of them, and G2's `F ≤ F_max` gate therefore blocks generalizations built from inbred material.**

> ### **R32.4 (COLLAPSED COUNT).** *`n_effective(general) ≤ MIN over instances of n_effective(instance)`, and the generalization RETAINS `instance_refs`.* **⟹ A rule whose instances have been forgotten is NOT RETRIEVABLE AS SUPPORT (§29.2 SC-4). The instances are the rule's evidence, and evidence that is gone cannot support anything.**

## 32.2 «A generalized memory must not silently inherit greater certainty than its evidence supports»

```
THE FAILURE, CONCRETELY:
  40 episodes, each in a different task context, each recording
  «strategy S succeeded». Each is E2, SC-6 (peer observation), n_effective 1.

  NAIVE GENERALIZATION:
    «Strategy S succeeds» — E3, scope = ALL TASKS, n_effective = 40.
    ⟹ **CERTAINTY INCREASED FROM 1 TO 40 AND SCOPE EXPANDED FROM ONE TASK
       TO ALL TASKS, IN ONE INTERNAL OPERATION.**
    ⟹ **THIS IS §1's LOOP'S FINAL STEP, AND IT IS THE MOST DANGEROUS SINGLE
       OPERATION IN THE ENTIRE MEMORY SYSTEM.**

  BOUNDED GENERALIZATION (R32.1–R32.4):
    «Strategy S succeeded» — **evidence_status = MIN = E2**, scope = **the
    INTERSECTION of 40 different task contexts** (which may be nearly empty),
    `n_effective` = **MIN = 1, NOT 40** — because the 40 episodes were
    observed by peers and §21's dim-1..5 test applies to THEM, not to their
    count.
    `inbreeding_F` = **MAX over the 40.**
    ⟹ **THE GENERALIZATION IS WEAKER THAN ITS WEAKEST INSTANCE AND NARROWER
       THAN ITS NARROWEST INSTANCE.**

  ⚠️ **AND THE OBJECTION, TAKEN SERIOUSLY: this makes generalization almost
     useless. Forty genuine successes produce a rule with n_effective = 1?**

  ⟹ **NO — AND THE DISTINCTION IS THE WHOLE POINT.** If the 40 episodes have
     40 DISTINCT `root_commit`s and are pairwise disjoint on dims 1–5, then
     `n_effective` of the CLAIM «S succeeds in context C» computed over those
     40 support records IS ~40 (§21.3). **R32.4's MIN applies to the
     generalization's own `n_effective` as a DERIVED RECORD, while the CLAIM
     it supports accumulates `n_effective` normally from its support refs.**

     **⟹ THE TWO QUANTITIES ARE DIFFERENT AND MUST BE:**
       • `n_effective(claim C)` — computed over C's support records,
         collapsed by §21's disjointness test. **CAN BE 40.**
       • `n_effective(derived generalization record G)` — bounded by MIN over
         G's instances. **IS 1.**
     **G is a RECORD that asserts a general rule; C is a CLAIM with 40
      independent supports. G's warrant is weak because G is a single derived
      assertion. C's support is strong because 40 independent episodes
      support it. ⟹ THE RIGHT ARCHITECTURE ATTACHES THE 40 SUPPORTS TO THE
      CLAIM, AND RECORDS G AS A DERIVED SUMMARY WITH WEAK WARRANT AND
      `instance_refs` TO ALL 40.**

     **⟹ AND THAT IS WHY §15.1(d)'s structure — separate source records
        linked to one claim record — is load-bearing here as well as in §15:
        it is the only structure in which 40 instances can strengthen a CLAIM
        without strengthening a DERIVED RECORD.**
```

**R32.5 (GENERALIZATION IS NOT INFERENCE).** *§16.4: the claim graph is not a reasoner. **Generalization creates a summary record with bounded warrant; it does not derive new claims by logical rule.*** **⟹ A memory subsystem that performs inductive inference is a second evaluator, and R13.1 is violated. §98's ablation tests this: removing the generalization step must reduce storage efficiency and change no belief state.**

---

# §33. MEMORY COMPRESSION & OVER-COMPRESSION

## 33.1 The distinction, restated for memory

**Vol A §14.1 R14.1: provenance is COMPRESSED iff every decision property survives, and DESTROYED iff any is lost.** §33 extends it from provenance to the whole record.

> ### **R33.1 (COMPRESSION IS DIMENSION-SELECTIVE).** *A record has an epistemic dimension (DP-1…DP-10, `source_class`, `evidence_status`, `belief_state`, `validity`, `context_scope`) and a payload dimension (`content`). **Compression operates ONLY on the payload dimension. The epistemic dimension is `O(1)` per record already (Vol A §14.2's L1 level) and there is nothing to gain by compressing it — and everything to lose.***

**⟹ The inherited error, named: V3 §11's pipeline runs compression as a step over the WHOLE RECORD, which is how `context_scope` and qualifiers get discarded. R33.1 forbids it structurally: compression is a payload operation.**

## 33.2 The four over-compression failures

| # | Failure | **Mechanism** | **Defense** |
|---|---|---|---|
| **OC-1** | **Qualifier loss → certainty gain** | «S succeeded in 7 of 10 trials in task A» compresses to «S succeeds». **The compressed form reads as MORE definite than the original** | **R33.1: the epistemic dimension is not compressed. The trial count, the task scope, and the success ratio are `context_scope` + sufficient statistics, and both are preserved at L1. ⟹ SC-3 (§29.2)** |
| **OC-2** | **Scope loss → over-generalization** | `context_scope` is dropped as «metadata», and the record becomes context-free | **`context_scope` is MANDATORY and a record without it is MALFORMED (§24.1). ⟹ Compression that removes it produces a MALFORMED record, which is rejected at any re-ingestion** |
| **OC-3** | **Root loss → unauditability** | The evidence enumeration is dropped without a Merkle commitment | **DP-1. Vol A §14.3: «Unacceptable — and each is a named destruction». ⟹ A record that has lost DP-1 is not a compressed record; it is an UNANCHORED one, and P0-02 R20.1 applies: no consequential decision may rest on it** |
| **OC-4** | **Contradiction loss → false coherence** | One side of a contradiction is compressed away, and the surviving corpus looks consistent | **⚠️ THE SUBTLEST. `contradiction_refs` is MANDATORY (may be empty) and points at `ContradictionRecord`s, which are AUDIT-TIER, APPEND-ONLY, and NOT COMPRESSIBLE below L1. ⟹ Compressing a record does not compress its contradictions. **AND L-9's survivorship bias is the same failure via forgetting rather than compression — §34.6** |

## 33.3 The compression contract

```
COMPRESS(record, target_level) →
  PRECONDITIONS (all mandatory):
    • target_level ≥ L1 if the record is to remain RETRIEVABLE AS EVIDENCE
      (R14.2). **Below L1, the record becomes a TRACE — a change of
      record_type, visible and auditable, not a loss of fields**
    • Every DP-1…DP-10 survives, or the operation is a DESTRUCTION and is
      PROHIBITED
    • `contradiction_refs` survive unchanged
    • `instance_refs` survive if the record is a generalization (R32.4)
    • The record is not T4 or T5 (those are L0-permanent)

  POSTCONDITIONS:
    • `transform_history` gains an append-only commitment recording the
      compression — **compression is a TRANSFORMATION and MEM-M2 applies:
      warrant(compressed) ≤ warrant(original)**
    • `evidence_status` is UNCHANGED. **⟹ Compression neither raises nor
      lowers evidence status. It is not an epistemic event**
    • The new store Merkle root reflects the compressed form, and BOTH roots
      are anchored — **so «this record was compressed at epoch e, from a
      form whose root was R₁, to a form whose root is R₂» is permanently
      auditable**

  ⟹ **R33.2: COMPRESSION IS WARRANT-NEUTRAL AND SCOPE-NEUTRAL. It changes
     the payload's size and nothing else. Any compression that changes
     warrant, scope, evidence status, or belief state is a prohibited
     operation, not a compression.**
```

**R33.3 (WHAT MAY BE DISCARDED — the complete list).** *Payload detail beyond the level's retention requirement · the enumeration of roots (DP-1's commitment preserves membership) · the enumeration of transformations (DP-2's commitment preserves monotonicity) · per-dimension correlation detail below L2 (DP-3 coarsens, and **L2 is therefore inadmissible for `n_effective`** — Vol A §14.2) · intermediate identities (recoverable off-line from Tier-2 traces within the window).* **Nothing else. And «nothing else» is enforced by DP-1…DP-10 being a closed list with a named destruction for each.**

---

*End of Volume B. Volume C (`34_analysis_lifecycle_interfaces.md`) covers §34–§55: forgetting and retention, deletion, versioning, checkpoint, recovery, memory security, memory poisoning, the 50+ attack surface begins, and the nine subsystem interfaces (Evaluation, Learning, Plasticity, Evolution, Self-Model, Immune, Homeostasis, Workspace), access control, distributed consistency, and the consistency matrix.*
