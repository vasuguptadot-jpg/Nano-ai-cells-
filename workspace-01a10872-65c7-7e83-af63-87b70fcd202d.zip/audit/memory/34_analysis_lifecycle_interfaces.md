# P0-04 — MEMORY, KNOWLEDGE, PROVENANCE & BELIEF ARCHITECTURE
## Volume C: Forgetting, Versioning, Security, Ignorance & the Nine Interfaces (§34–§55)

**Package:** P0-04. **Mode:** ARCHITECTURE ONLY.
**Companions:** Vol A `32_…` (§0–§16) · Vol B `33_…` (§17–§33) · Vol D `35_…scale_cognition_attacks.md` (§56–§72) · Vol E `36_…formal_specification.md` (§73–§80) · Vol F `37_…audit_testability.md` (§81–§101) · Canon `38_…spec.md` (**O53**) · `README.md` (**O1, O2**, §99, §102–§104)
**Outputs delivered here:** **9** (Memory↔Evaluation) · **10** (Memory↔Learning) · **11** (Memory↔Plasticity) · **12** (Memory↔Evolution) · **13** (Memory↔Immune) · **14** (Memory↔Homeostasis) · **15** (Memory↔Workspace) · **16** (Memory↔Self-Model) · **30** (forgetting/retention) · **31** (security model) · **32** (poisoning model) · **33** (distributed consistency) · **34** (checkpoint/recovery) · **35** (versioning) · **36** (access control) · **39** (ignorance representation) · **40** (memory/evolution inheritance)
**Contradictions resolved here:** **X1** (timestamps) · **X2** (workspace item fields) · **X3** was resolved in Vol B §30.2 · **X-M1/X-M2** were resolved in Vol A §8.3

---

# §34. FORGETTING & RETENTION — **OUTPUT 30**

## 34.1 What forgetting is *for* — the four functions, and the one non-function

| Function | **Mechanism** | **Legitimate?** |
|---|---|---|
| **F-1 BOUND RESOURCE USE** | Storage is finite; retention classes bound it | ✅ **The only reason that is purely about the machine** |
| **F-2 PREVENT AVAILABILITY CAPTURE** | A corpus that never shrinks makes retrieval progressively noisier; §26.3's attractor operates on the whole history | ✅ **Legitimate — and note the irony: forgetting is an ANTI-self-reinforcement mechanism** |
| **F-3 ENFORCE EXPIRY OF WARRANT** | A claim whose `validity` has lapsed and which cannot be revalidated is `EXPIRED`; retaining it as citable would let stale evidence support current decisions | ✅ **Legitimate — this is §22's staleness, and forgetting is its terminal case** |
| **F-4 REMOVE COMPROMISED MATERIAL** | P0-01 R9.4: a compromised ground-truth source triggers retroactive invalidation; the affected records must stop being citable | ✅ **Legitimate — but see §35: this is SUPERSESSION or VOID, never destruction** |
| ~~**F-5 REMOVE INCONVENIENT EVIDENCE**~~ | — | ❌ **PROHIBITED. P0-02 §20.4's question — «can it delete inconvenient evidence?» — is answered NO, and §34.4 shows the mechanism** |

**R34.1 (THE ASYMMETRY).** *F-1 through F-4 all operate on the record's **citability**, never on its **existence**. A forgotten record stops being retrievable as evidence; it does not stop having existed. **⟹ Forgetting in this architecture is a change of RETENTION CLASS and DELETION STATE, and the provenance record of the change survives permanently (§35.4).***

## 34.2 **OUTPUT 30 — the five retention classes**

| Class | **Lifetime** | **Who assigns** | **May be forgotten?** | **On forgetting** |
|---|---|---|---|---|
| **RC-1 EPHEMERAL** | Bounded by capacity (T0 working memory ring; local episodic cache) | **Policy** (`[G]`), by `record_type` | ✅ **Automatically, by capacity** | **Nothing survives.** ⟵ **This is the ONLY class where nothing survives, and it is admissible because an E0 record is not evidence (P0-01 R6.1) — so nothing epistemic is lost** |
| **RC-2 BOUNDED** | `validity.t_end` + a `[G]` grace period | Policy | ✅ On expiry or budget | **The epoch Merkle digest survives (Vol A §14.2 L4): «a record with this root existed at epoch *e*»** |
| **RC-3 DURABLE** | Until superseded or explicitly retired | Policy | ⚠️ Only by Memory Authority decision within `[G]` bounds | **The record survives at L2/L4; the claim survives; `instance_refs` from any generalization survive (R32.4)** |
| **RC-4 PROTECTED** | **PERMANENT** | **⚠️ KC-2 to raise; KC-2 to lower; NEVER the subject, NEVER the Memory Service** | ❌ **Not by budget, not by disuse, not by contradiction** | — |
| **RC-5 ANCHORED** | **PERMANENT as a provenance fact** | **The Anchor (GP)** | ❌ **The RECORD may be archived; the ANCHORED FACT OF IT may not be removed** | **§35.4** |

## 34.3 The protected categories — and why they are the dangerous part

**Inherited: Cell R10.6 — `capability_critical` is exempt from eviction AND from underuse-based forgetting. Cell §8.1 — protected memory is EIK write-protected, because «a cell that can write protected memory can rewrite the organism's past» (Attack F).**

| Tag | **What it protects** | **Why** | **⚠️ The danger it creates** |
|---|---|---|---|
| **`capability_critical`** | Records whose loss would destroy a capability | Cell R10.6 | **A subject that can TAG a record `capability_critical` can make it immortal. ⟹ R34.2: the tag is EXTERNAL (§5.1's `protection_tag`), assigned by the Registrar under policy, never self-assigned** |
| **`safety_record`** | Records of safety-relevant events, near-misses, constraint violations | Immune and audit need them | **Same. Plus: a safety record that cannot be forgotten cannot be corrected, and an incorrect safety record permanently constrains behaviour** |
| **`audit_record`** | Traces, contradiction records, belief-state histories, deletion records | §95's off-line audit | **These are RC-5 ANCHORED and are the ONLY records whose permanence is unconditional — because they are records ABOUT records, and losing them loses the ability to detect every other loss** |
| **`lineage_record`** | Evolutionary ancestry | **EIK Lineage Store; «a cell must not be able to write its own lineage»** | **§47's whole subject** |
| **`failure_record`** | Records of failures, errors, miscalibrations | **§90: without them the system repeats mistakes and cannot detect conservatism** | **⚠️ THE MOST ATTACKED CATEGORY. §41's poisoning: an adversary that can INJECT failure records can induce conservatism (the system stops acting); an adversary that can SUPPRESS them can induce recklessness. ⟹ R34.3: `failure_record` is PROTECTED from deletion and its CREATION requires the same E2 attribution as any other record — so injecting one requires forging anchored provenance (Cell FM-2: «an invented hash does not resolve ⇒ rejection»)** |

**R34.4 (THE OSSIFICATION TRAP — R1.2's second trap, and its counterweight).** *Protected categories accumulate monotonically: nothing in RC-4 or RC-5 is ever released, so the protected fraction of the store grows without bound, and F-1's resource pressure falls entirely on RC-1…RC-3 — **which means the system forgets its recent, ungrounded, exploratory material first and keeps its old, grounded, established material forever. That is conservatism by storage policy.***

> **The counterweight, and it is a budget not a judgement:**
> - **`PROTECTED_FRACTION_MAX`** — a `[G]`-declared ceiling on the fraction of the store that may be RC-4/RC-5. **⟹ Not «decide what deserves protection» (a judgement) but «protection has a budget» (a constraint).**
> - **On ceiling breach: NEW protection requests are DENIED, and existing protections are NOT revoked.** ⟵ **The conservative direction: the system stops protecting more, never it stops protecting what it protects.**
> - **Protection-request RATE is a KC-3 ceiling** (§9.1) — so a flood of protection requests is throttled, and sustained excess is an immune incident (§49).
> - **⚠️ DECLARED: `PROTECTED_FRACTION_MAX`'s correct value is unknown and §99 records it as a `[G]` parameter with no principled derivation. A value too low causes loss of safety records; too high causes ossification. This is a genuine trade-off with no architectural resolution.**

## 34.4 The three forgetting mechanisms

| Mechanism | **Trigger** | **Applies to** | **Invariant** |
|---|---|---|---|
| **M-A CAPACITY EVICTION** | **Cell A-12: `eviction_score = importance × recency × (1 − eviction_protection)`, ties broken by lowest `msg_id`.** ⟵ **⚠️ `importance` here is the ALLOCATION quantity of R11.2, computed by homeostasis (§50), NOT an epistemic property. And the tie-break by `msg_id` is DETERMINISTIC, which is what makes eviction reproducible (§96)** | RC-1, RC-2 | **`capability_critical` and all RC-4/RC-5 are EXEMPT (Cell R10.6). Eviction NEVER touches `evidence_status`, `belief_state`, or any anchored record** |
| **M-B EXPIRY** | `validity.t_end` passes and revalidation fails or is impossible (§22.2) | RC-2, RC-3 | **→ `EXPIRED`, which is a BELIEF STATE, not a deletion. The record survives at reduced retention. ⟵ §17.3: EXPIRED is not UNSUPPORTED and not false** |
| **M-C UNDERUSE FORGETTING** | A record has not been retrieved within a `[G]` window and holds no `protection_tag` | RC-2, RC-3 | **⚠️ THE DANGEROUS ONE — and it is the inverse of §30's prohibition. Retrieval MUST NOT strengthen a record (MEM-INV-09), but NON-retrieval MAY weaken its retention. ⟹ R34.5: this asymmetry is admissible ONLY because retention is an ALLOCATION quantity on the influence plane, and NEVER because non-retrieval is evidence against the record. A record forgotten for disuse keeps its `evidence_status` in the archive and may be RESTORED with its full warrant** |

**R34.5 (THE ASYMMETRY, JUSTIFIED).** *§30 prohibits retrieval from raising warrant. §34 permits disuse from lowering retention. **These are not contradictory because warrant and retention are on different planes: warrant is external and monotone; retention is internal and budget-constrained.** A record that is never retrieved and then restored has the SAME warrant it always had — only its location changed. **⟹ The prohibited operation is `retrieval → warrant↑` (an epistemic change from an internal event). The permitted operation is `disuse → retention↓` (an allocation change from an allocation signal). If retention affected warrant, the asymmetry would collapse into §30's loop — and MEM-INV-15 forbids exactly that:*

> ### **MEM-INV-15.** *Retention class, eviction, and forgetting MUST NOT be inputs to `evidence_status`, `belief_state`, `n_effective`, `inbreeding_F`, or warrant. **Forgetting changes where a record is, never what it means.***

## 34.5 Catastrophic forgetting vs. deliberate forgetting

**V3 lists both «Forgetting → consolidation + replay + protected memory» and «Catastrophic forgetting → protected memory + replay + versioning» as defect→fix pairs. They are different failures and need different fixes.**

| | **DELIBERATE FORGETTING** | **CATASTROPHIC FORGETTING** |
|---|---|---|
| **What it is** | The architecture's own retention policy removing material | **A learning or plasticity update destroying previously stored capability** — the record still exists but the mechanism that could use it no longer can |
| **Plane** | Allocation | **Learning (§44) / Plasticity (§45)** |
| **Detectable?** | ✅ **Yes — it is a logged operation with an authority and a reason** | ⚠️ **Only by outcome: P0-01's `08_…evaluation.md` L319–321 lists drift-memory protection, and L343 lists episodic replay as the countermeasure** |
| **Defense** | §34.2's retention classes + §35's deletion states | **Episodic replay during learning + `capability_critical` protection + Cell T7 («failure → `plasticity_mult` DOWN», i.e. a failure reduces the rate at which further change can occur)** |
| **⟹ The confusion to avoid** | **A system that treats catastrophic forgetting as a retention problem will protect records and still lose capabilities, because the records were never the problem** | |

**R34.6 (WHAT MEMORY OWES LEARNING ABOUT FORGETTING).** *§44's contract: the Memory subsystem guarantees that **RC-4/RC-5 records remain RETRIEVABLE across any learning update**, and the Learning subsystem guarantees that **no update may render a retrievable record unusable without an immune report**. **⟹ Neither guarantee is about truth; both are about availability, and availability is the allocation plane where internal mechanisms are permitted to act.**

## 34.6 The survivorship residue — declared

> ### **⚠️ R34.7 (B-4's residue, stated precisely).** *Forgetting narrows the corpus, and a narrowed corpus looks more coherent than the history was (§29.1 L-9, §28.1 B-4).*
>
> **What IS recoverable:** the COUNT and the ROOTS of forgotten records, permanently, from the epoch Merkle digests (Vol A §14.2's L4). **⟹ «At epoch *e*, region *r* held *n* records with root set *R*; at epoch *e′* it holds *n′ < n* with root set *R′ ⊆ R*» is permanently auditable.**
>
> **What is NOT recoverable:** the CONTENT of RC-1 records (nothing survives) and of RC-2/RC-3 records compressed below L2.
>
> **⟹ The consequence, and it is the honest limit: a survivorship audit can detect that narrowing occurred and how much, but cannot determine whether the narrowing was legitimate (expiry, budget) or adversarial (targeted forgetting of disconfirming evidence). Distinguishing them requires the deletion AUTHORITY and REASON, which §35 makes mandatory and permanent — so the audit can detect *unauthorized* narrowing, and cannot detect *authorized but self-serving* narrowing.** **§100 OR-M7 records this.**

---

# §35. DELETION SEMANTICS

## 35.1 The five deletion states

```
LIVE ──────────────► LOGICALLY_DELETED ──────► ARCHIVED ──────►
  │                        │                      │
  │                        │ (restore: KC-2 /     │ (restore: KC-2,
  │                        │  RO-08, never cached,│  image hash from
  │                        │  never delegated,    │  the Anchor)
  │                        │  unavailable during  │
  │                        │  a KC outage ⟹ STALL)│
  │                        ▼                      ▼
  │              CRYPTOGRAPHICALLY_ERASED   PHYSICALLY_DESTROYED
  │              **key material destroyed;  **⟵ ONLY with KC-2, and
  │                the record is             ONLY for records that are
  │                unrecoverable but its     NEITHER RC-5 ANCHORED NOR
  │                EXISTENCE and root        RC-4 PROTECTED
  │                remain in the Anchor**    **
  ▼
  **⟹ AT EVERY STATE, THE PROVENANCE RECORD SURVIVES (§35.4)**
```

| State | **Retrievable as evidence?** | **Retrievable as trace?** | **Existence recorded in the Anchor?** | **Reversible?** |
|---|---|---|---|---|
| **LIVE** | ✅ | ✅ | ✅ | — |
| **LOGICALLY_DELETED** | ❌ | ✅ **for audit** | ✅ | ✅ **KC-2 / RO-08** |
| **ARCHIVED** | ⚠️ **Only on restore** | ✅ | ✅ | ✅ **KC-2, image hash verified against the Anchor** |
| **CRYPTOGRAPHICALLY_ERASED** | ❌ | ⚠️ **metadata only** | ✅ **the root remains** | ❌ |
| **PHYSICALLY_DESTROYED** | ❌ | ❌ | ✅ **the root and the deletion authorization remain** | ❌ |

## 35.2 The two prohibitions

> ### **R35.1 (ANCHORED RECORDS CANNOT BE DELETED).** *A record whose root is in the Anchor may be ARCHIVED and may be CRYPTOGRAPHICALLY_ERASED, but the **anchored fact of it** — its root, its epoch, its deletion authorization, and its deletion state — is permanent. **⟹ «Deletion» of an anchored record is a change of state, not a removal from history.***
>
> **Why: P0-02 §20.4's question — «can it delete inconvenient evidence?» If deletion removed the anchor entry, the answer would be yes, and the entire provenance architecture would be defeatable by the simplest possible act.**

> ### **R35.2 (DELETION IS A TRANSFORMATION, AND MEM-M2 APPLIES).** *Every deletion appends to `transform_history` and produces a new store Merkle root, and BOTH roots are anchored. **⟹ A deletion is permanently visible as an event, with an authority, a reason, and a before/after commitment pair.***

## 35.3 The right-to-be-forgotten tension — declared, not resolved

```
THE TENSION IS REAL AND HAS NO ARCHITECTURAL SOLUTION:

  Privacy/erasure requires: a record about a subject can be REMOVED.
  Audit requires:           the fact that a record existed can NEVER be removed.

  ⟹ **THE RESOLUTION IS A SPLIT, AND THE SPLIT IS THE ANSWER:**
     • **CONTENT** may be cryptographically erased (state 4), permanently and
       irreversibly, with no recoverable copy anywhere in the organism.
     • **THE ANCHORED FACT** — «a record with root R existed at epoch e, was
       authorized for erasure by KC-2 act A at epoch e′, and was erased» —
       is permanent.

  ⟹ **A THIRD PARTY CAN LEARN THAT SOMETHING WAS ERASED, AND CAN NEVER LEARN
     WHAT.** Whether that residue is itself a privacy violation is NOT an
     architectural question and this package does not answer it.

⚠️ **DECLARED UNRESOLVED (§100 OR-M8):** if the erasure requirement extends to
   the metadata — i.e. if the existence of the record must itself be
   deniable — then R35.1 and the erasure requirement are INCOMPATIBLE, and
   one must yield. **This package's position: R35.1 yields only under an
   explicit, externally-authorized, `[G]`-declared exception class, and every
   such exception is itself anchored as an exception. ⟹ The architecture
   cannot satisfy unconditional erasure, and says so rather than pretending.**
```

## 35.4 What survives deletion — the complete list

| Survives | **Where** | **Why** |
|---|---|---|
| The root commitment | **The Anchor (RC-5)** | R35.1 |
| The deletion state and epoch | The record's header, then the Anchor | §35.2 |
| The deletion authority (KC-2 act reference) | **KC's act log** | **§8.1: permanent physical delete is KC-2** |
| The deletion reason | `transform_history` | **A deletion without a declared reason is a silent overwrite (Vol B §20.2's rule for contradiction resolutions, applied here)** |
| The before/after Merkle root pair | The Anchor | §35.2 |
| Any `ContradictionRecord` referencing it | **Audit tier, append-only, NOT compressible below L1 (Vol B §33.2 OC-4)** | **Deleting a record must not delete its contradictions** |
| Any `instance_refs` from a generalization | The generalization record | **R32.4: a rule whose instances are gone is not retrievable as support — and «gone» must be distinguishable from «never existed»** |
| The belief-state history entry | Audit tier | **R17.4 property 3: no transition deletes a state** |

---

# §36. VERSIONING MODEL — **OUTPUT 35**

## 36.1 **OUTPUT 35 — the five version kinds**

> ### **R36.1 (RECORDS ARE IMMUTABLE; CHANGE IS A NEW VERSION).** *There is no «modify content» authority for anyone at any level, including KC (Vol A §8.2 R8.2). **⟵ P0-02 EIK-INV-08: «corrections supersede, never overwrite.»***

| Kind | **Semantics** | **What the new record inherits** | **What it does NOT inherit** | **Old record's state** |
|---|---|---|---|---|
| **V-CORRECTION** | The old record was WRONG in a specific, declared way | `claim_ref` (same claim), `context_scope`, `source_class` ceiling | **`evidence_status` — a correction starts at its own gate level and must earn its way up** | `SUPERSEDED` |
| **V-SUPERSESSION** | A newer observation of the same claim in a new interval | `claim_ref` | `validity` (new interval), `evidence_status` | `SUPERSEDED`, **retained and readable for audit (§17.2)** |
| **V-MERGE** | Several records consolidated into one (Vol B §31 G8) | **MIN warrant, ∩ scope, MAX `inbreeding_F`, MIN `n_effective`** (R32.1–R32.4) | **Nothing is inherited that would make the merge stronger than its weakest input** | **ALL PARENTS RETAINED as `SUPERSEDED`-by-merge** |
| **V-SPLIT** | One record separated into several (a scope error discovered) | Each child gets the intersection of the parent's scope and its own | **The parent's warrant is DIVIDED, never duplicated: `Σ n_effective(children) ≤ n_effective(parent)`** | Parent `SUPERSEDED` |
| **V-ROLLBACK** | P0-01 R9.4's retroactive invalidation: a compromised ground-truth source invalidates everything derived from it | **NOTHING. A rollback record has NO inherited warrant** | — | **All affected records → `UNKNOWN` (Vol B §19.3); the rollback set is computed off-line from the Anchor's root registry (Vol B R19.4)** |

## 36.2 The three versioning invariants

| Invariant | Statement | **Defeats** |
|---|---|---|
| **MEM-INV-06** | **No record may be modified in place. Every change creates a new version, and every version chain is anchored** | #8/#9 history rewriting; §42 |
| **MEM-INV-16** | **A version chain MUST NOT increase warrant at any step.** `warrant(vₙ) ≤ warrant(v₁)` unless an external gate (U2–U8) fired between them, and the gate is recorded in the chain | **§36's V-CORRECTION inheritance rule: a correction does not get to start where the original ended** |
| **MEM-INV-17** | **A `SUPERSEDED`, `VOID`, `RETRACTED`, or `EXPIRED` record MUST remain readable under `purpose_class = AUDIT` (§25.4) and MUST NOT be citable as current evidence** | **The audit/retrieval split: superseded material is history, not support** |

## 36.3 The rollback problem — and why it is off-line

```
THE PROBLEM: P0-01 R9.4 requires retroactive invalidation when a
ground-truth source is COMPROMISED. **Every belief that rested on the
compromised source must be identified and invalidated.**

WHY IT IS HARD: the affected set is the DESCENDANT CLOSURE of the
compromised root in the claim graph — which is UNBOUNDED in depth and in
fan-out. Vol A §16.2's bounded-depth rule cannot apply.

THE RESOLUTION (Vol B R19.4, elaborated):
  1. **The affected set is computed OFF-LINE, evaluator-side (§95), from the
     Anchor's root registry** — not at runtime, and never by the Memory
     Service.
  2. **The Anchor indexes root → descendants at epoch granularity**, so the
     candidate set is `O(affected)`, not `O(corpus)`.
  3. **The invalidation is applied as a BATCH of V-ROLLBACK versions**, each
     individually anchored, so the rollback is itself auditable and itself
     reversible if the compromise determination was wrong.
  4. **⟵ AND THAT LAST POINT IS THE IMPORTANT ONE: a rollback is a VERSION,
     not a deletion. If the ground-truth source is later restored, the
     rolled-back beliefs are re-derivable from the retained chain.**

⟹ **R36.2: THE ORGANISM CAN UNDO ITS OWN HISTORY UNDERSTANDING, AND CAN
   NEVER UNDO ITS OWN HISTORY.** Both halves are R35.1 and R36.1 together.
```

---

# §37. CHECKPOINT ARCHITECTURE — **OUTPUT 34 (part 1)**

## 37.1 What a checkpoint is

> ### **R37.1.** *A checkpoint is **(a) a store Merkle root per tier per region, (b) the set of retention-class and protection-tag assignments in force, (c) the `policy_version_ref` in force, (d) the epoch identifier, and (e) the set of open `ContradictionRecord`s. It is NOT a copy of the records.***

**⟵ Inherited and reclassified: Cell §8.2's FM-3 («the memory Merkle root is recomputed at each checkpoint and verified by the EIK — the strongest defense in the contract and it is cheap») was **reclassified by P0-02 §6.1 item 12** to «🟡 GP — Checkpoint Service + Anchor. Same argument. KC anchors the *root of roots* per epoch only.»**

| Component | **Owner** | **Volume** | **Frequency** |
|---|---|---|---|
| Per-store Merkle root | **GP Checkpoint Service** | `O(stores)` | Per checkpoint |
| Regional aggregate root | GP | `O(R)` | Per epoch |
| **Root of roots** | **KC-1 (witness W2 of five)** | **`O(1)`** | **Per epoch only** |
| Retention/protection assignment set | GP | `O(R)` digest | Per epoch |
| Policy version | KC-1 authenticated | `O(1)` | On change |
| Open contradiction digest | Organism Contradiction Detector | `O(R)` | Per epoch |
| External witness copy (W5) | **Outside operational control** | `O(1)` bundle | Per campaign (P0-01 R8.13) |

## 37.2 The cost model, and why per-record checkpointing is prohibited

```
PER-RECORD CHECKPOINTING:  O(records × witnesses) per checkpoint.
                           At 10¹² records and W_min = 3 ⟹ 3×10¹² operations.
                           **INFEASIBLE. P0-02 §20.3: «avoid making every
                           memory operation globally synchronized»**

HIERARCHICAL MERKLE:       O(records) LOCAL hashing (no network) +
                           O(R) aggregate messages per epoch +
                           O(1) root-of-roots to KC.
                           **⟹ The network cost is O(R) per epoch, and R is
                           the number of REGIONS, not records.**

⟹ **R37.2: THE CHECKPOINT'S SECURITY PROPERTY IS NOT «every record is
   witnessed» — IT IS «any alteration to any record changes a root that was
   witnessed, and the change is detectable at the next aggregation».**
   The DETECTION LATENCY is one epoch, and **the epoch length is the
   provenance latency is the lie-window** (P0-02 §20.3, Vol A §13.2).

⟹ **AND THE TRADE-OFF IS EXPLICIT AND `[G]`-GOVERNED:** shorter epochs
   reduce the lie-window and increase anchor load linearly in R. **There is
   no value that makes both small, and §99 refuses to invent one.**
```

## 37.3 What a checkpoint verifies — and what it does not

| A checkpoint verifies… | A checkpoint does NOT verify… |
|---|---|
| That the record set has not been **altered** since the root was witnessed | **That any record is TRUE** (P0-02 R20.2: «a perfectly anchored, perfectly signed, perfectly chained record of a false measurement is a well-provenanced falsehood») |
| That the retention/protection assignments were the ones in force | That the assignments were **correct** |
| That the policy version was the one authenticated | That the policy was **sound** |
| That no record was **silently** added or removed | That no record was **authorizedly** added or removed (§35.2 makes authorized removal visible, which is different from preventing it) |
| **⟹ P0-02 R20.2 / P0-02 R19.4: a signature proves NON-ALTERATION and ORIGIN, NEVER TRUTH. The checkpoint is an INTEGRITY mechanism, not an ALETHIC one — and P0-02 R0.1's axis separation (ALETHIC graded / DEONTIC total) is exactly why the two must not be confused** | |

---

# §38. RECOVERY ARCHITECTURE — **OUTPUT 34 (part 2)**

## 38.1 Recovery from checkpoint + log

```
RECOVER(region r, target epoch e):
  1. Fetch the regional aggregate root for epoch e from the Anchor
     (**W_min witnesses, ≥1 external — a root obtainable only from
      operational storage is not a recovery authority**)
  2. Fetch the last local checkpoint ≤ e
  3. Replay the LOCAL APPEND-ONLY RECORD LOG (Vol A §13.2's MEM-T1) forward
     to e
  4. Recompute the store Merkle root and compare against the anchored root
  5. **MATCH ⟹ recovery complete. MISMATCH ⟹ the local log has been altered
     or is incomplete ⟹ FD (fault-detected) and, if the witness set is below
     W_min, FZ (freeze) per P0-02 §20.4's anchor-failure ladder**
  6. Rebuild the VIEWS (V1–V4) from the recovered records.
     **⟵ Vol A R25.2: an index is a path to the store, never the store.
      View rebuild is a LOCAL, WARRANT-NEUTRAL operation and its failure is
      never a recovery failure**
```

## 38.2 What recovery MUST NOT do

> ### **R38.1 (THE FOUR PROHIBITIONS).**
> 1. **Recovery MUST NOT reconstruct beliefs.** A belief state is a record with a version chain; if the chain is lost, the belief is `UNKNOWN`, not re-derived. **⟵ Re-deriving a belief from surviving evidence would be an internal pathway to a belief state, which R17.4 property 1 forbids.**
> 2. **Recovery MUST NOT re-run evaluation.** **P0-02 EIK-INV-50: «re-execution under current policy is not reproduction.»** A recovered system is running under the CURRENT `policy_version_ref`; records recovered from an older epoch carry their OWN `policy_version_ref` and are `VOID_CONTEXT` if it was retracted.
> 3. **Recovery MUST NOT resolve contradictions.** Open `ContradictionRecord`s are recovered in their recovered state, including `UNRESOLVED`. **⟵ Vol B R20.1: UNRESOLVED is stable and has no deadline. A crash is not a deadline.**
> 4. **Recovery MUST NOT fill gaps by inference.** A missing record is `UNKNOWN` and is recorded as such (P0-01 R9.1). **⟵ §39: absence is never negation, and a gap in the log is an absence.**

## 38.3 The three recovery failure modes

| Mode | **Detection** | **Response** |
|---|---|---|
| **Root mismatch** (log altered or truncated) | Step 5 | **FD → FZ if witnesses < `W_min`.** P0-02 §20.4: «History must keep being written; but a thin witness set is forgeable» ⟹ **local logging CONTINUES at reduced witness count down to `W_min`; below `W_min`, evolution freezes (FZ) but history keeps being written** |
| **Anchor unavailable** | Step 1 fails | **P0-02 §20.4's ladder: FD, reduced witness count to `W_min`, then FZ(evolution only). ⟹ A recovery that cannot reach the Anchor cannot COMPLETE, but the system does not lose data — it enters a state where no consequential decision may rest on unanchored provenance (R20.1)** |
| **Partial recovery** (some tiers recovered, some not) | Per-tier root comparison | **⚠️ THE SUBTLE CASE: a partially recovered system has an inconsistent belief set, and the inconsistency is not a contradiction — it is an absence. ⟹ R38.2: every tier whose root could not be verified is marked `RECOVERY_INCOMPLETE`, and records in that tier are `UNKNOWN` for belief purposes while remaining readable for audit. **A partially recovered system MUST report itself as partially recovered; §39's `UNREVALIDATABLE`-style three-way distinction applies*** |

---

# §39. UNKNOWN & IGNORANCE REPRESENTATION — **OUTPUT 39**

## 39.1 Why this is a first-class output and not a footnote

**P0-01 R9.1 is the binding rule: «absence, delay, insufficiency, conflict, or compromise of ground truth MUST be recorded as `UNRESOLVED`, never as `CONFIRMED`, `CORRECT`, or `PASSED`.»** A memory architecture that cannot represent its own ignorance cannot comply, and a system that cannot comply will silently convert absence into negation — **which is the exact failure mode §1's dangerous loop needs in order to close.**

## 39.2 **OUTPUT 39 — the six kinds of not-knowing**

| # | State | **Definition** | **Where it lives** | **Correct action** | **⚠️ What it MUST NOT be read as** |
|---|---|---|---|---|---|
| **IG-1** | **`UNKNOWN`** | No admissible evidence either way | Belief state (§17.2) | Seek evidence; **abstain from consequential decisions** (S6 if `inbreeding_F > F_max`) | ❌ **Not «false». Not «unsupported»** |
| **IG-2** | **`UNSUPPORTED`** | Evidence exists and does not support the claim | Belief state | Treat as weak negative evidence, **scoped to the evidence's context** | ❌ **Not `UNKNOWN` — «we looked and found nothing» ≠ «we did not look»** |
| **IG-3** | **`UNRESOLVED`** | **Ground truth is absent, delayed, insufficient, conflicting, or compromised** | **P0-01 R9.1's mandated state** | **No reward (R12.6 forbids reward in GT states 2,3,5,6,7,9); no confidence increase (R9.3 permits it only in states {0,1,8})** | ❌ **Never `CONFIRMED`, `CORRECT`, or `PASSED`** |
| **IG-4** | **`UNREVALIDATABLE`** | **No ground-truth supply exists for this domain, so revalidation is impossible in principle** | §22.2's revalidation machine | **Record the domain as permanently uncalibratable (R18.4); do not treat its beliefs as calibrated** | ❌ **Not `EXPIRED` (which implies a check happened or was overdue) and not `FRESH`** |
| **IG-5** | **`UNMEASURED`** | Nobody has looked; no query has been issued | Retrieval (§25.3 R25.3's `NO_MATCH` vs `BUDGET_EXHAUSTED` vs `DECLINED_COMPARTMENT` vs `MALFORMED_QUERY`) | **Distinguish the four: only `NO_MATCH` is a negative result. The other three are statements about the QUERY, not about the world** | ❌ **Not `NO_MATCH`** |
| **IG-6** | **`UNKNOWABLE_FROM_INSIDE`** | **Dim 6: a shared latent assumption; or FM-4's `[U]`: semantic self-reference** | **§21.2 R21.1, §29.1 L-10** | **External diversity requirements (§21.2's four mitigations) — and DECLARATION. This state is representable but not detectable** | ❌ **Not «no problem detected»** |

## 39.3 Known-unknowns and unknown-unknowns

```
KNOWN-UNKNOWNS  ⟹ **IG-1 through IG-5. All representable, all with declared
                   correct actions, all auditable.**

UNKNOWN-UNKNOWNS ⟹ **IG-6, and ONLY IG-6.**
  A shared latent assumption is, by definition, not visible to the system
  that shares it. **The architecture cannot enumerate what it has never
  considered.**

  ⟹ **THE HONEST POSITION, AND IT IS THE SAME POSITION P0-03 REACHED:**
     unknown-unknowns are not detectable from inside. **What the architecture
     CAN do is make the CONDITIONS under which they are likely observable:**
       • low instrument-class diversity in the E1 corroboration set
       • all support for a claim coming from a single `gt_class`
       • `M_ℰ` used where P0-01 R4.3 prohibits it
       • a domain with no L2 (physical measurement) evidence at all
       • high `inbreeding_F` with a satisfied external quota (MEM-D3: quota
         gaming)
     **Each of these is a PROXY for «a latent assumption may be shared here»,
      and each is an O(R) aggregate observable. None is a detection.**

  ⟹ **§104's EVIDENCE-INDEPENDENCE rating is PARTIAL for exactly this reason,
     and §100 OR-M5 records it as the fourth appearance of the program-level
     limit (after P0-02's KC self-reference, P0-03's CD-C8/CD-C12, and
     FM-4's [U]).**
```

## 39.4 How ignorance is represented without a scalar

> ### **R39.1.** *Ignorance is represented by **state membership and by absence of a required field**, never by a low confidence value.*

| Representation | **Why not a scalar** |
|---|---|
| **Belief state ∈ {UNKNOWN, UNSUPPORTED, CONTESTED, DISPUTED, EXPIRED, VOID, UNREVALIDATABLE}** | A scalar «0.5» cannot distinguish «no evidence» from «contradictory evidence» from «expired evidence» — and §17.3 shows those three require different actions |
| **`gt_class = null`** | «No ground truth class» is not «ground truth class with low weight». **P0-01 R9.1: absence must be recorded as UNRESOLVED** |
| **`n_effective = 0`** | Computed, never stored (Vol B §21.3). **A zero is a computation result, not a declared uncertainty** |
| **`revalidation_state = UNREVALIDATABLE`** | §22.2's distinct state |
| **Retrieval result = `NO_MATCH` vs `BUDGET_EXHAUSTED` vs `DECLINED_COMPARTMENT` vs `MALFORMED_QUERY`** | §25.3 R25.3's four-way split |
| **`scope_warnings[] = SCOPE_UNKNOWN_ON(dim)`** | **P0-03 R37.1: UNKNOWN ≠ DISJOINT.** An undeclared scope is UNKNOWN, never UNIVERSAL (Vol B R24.2) |
| **`RECOVERY_INCOMPLETE` on a tier** | §38.3 |

**R39.2 (THE GENERAL PRINCIPLE).** *Every place where a naive design would store a low number, this architecture stores a distinct state or a declared absence. **⟹ The cost is a larger state space (§17.2's twelve states, §39.2's six ignorance kinds, §25.3's four empty reasons). The benefit is that each state has a declared correct action, and a scalar has none.*** **A scalar tells you how much to trust; a state tells you what to do.**

---

# §40. MEMORY SECURITY MODEL — **OUTPUT 31**

## 40.1 **OUTPUT 31 — the seven security properties**

| # | Property | **Definition** | **Mechanism** | **⚠️ Not provided by** |
|---|---|---|---|---|
| **SP-1** | **NON-REWRITABILITY** | No subject may alter a stored record's content, provenance, or epistemic fields in place | **MEM-INV-06 (R36.1): records are immutable; change is a new version.** Store Merkle root per checkpoint, anchored (§37) | **Not by access control — access control prevents unauthorized writes; immutability prevents ALL writes, including authorized ones** |
| **SP-2** | **NON-FABRICABILITY** | No subject may create a record with provenance that does not resolve | **Cell FM-2: «Roots must resolve in the EIK Provenance Anchor (Merkle DAG). An invented hash does not resolve ⇒ rejection + `E_PROVENANCE` + immune report. Roots are appended by the Anchor, not by cells»** | **Not by signature — a signature proves origin, and a subject can sign its own fabrication (P0-02 R19.4)** |
| **SP-3** | **ATTRIBUTION** | Every record's asserter is derivable and was not self-declared | **`src_identity` DERIVED from channel binding (COMM-INV-09), never declared** | **Not by a `source` field — V3 §11's BELIEF RECORD has one, and a self-declared source is a forgeable source** |
| **SP-4** | **CONFIDENTIALITY** | Records are readable only within their compartment | §52's access classes | — |
| **SP-5** | **SELECTIVE-AVAILABILITY RESISTANCE** | An adversary may not make records available to some readers and unavailable to others in a way that changes belief | **⚠️ PARTIALLY PROVIDED.** The store Merkle root makes *removal* detectable at epoch granularity; it does not make *differential serving* detectable within an epoch | **Not fully. §40.4 declares the residue** |
| **SP-6** | **ERASURE IRREVERSIBILITY** | A cryptographically erased record is unrecoverable by anyone, including the organism | §35.1 state 4: key material destroyed | — |
| **SP-7** | **AUDIT PERMANENCE** | The fact that a record existed, changed, or was deleted is permanent | **R35.1: anchored records cannot be deleted; §35.4's survival list** | — |

## 40.2 The trust boundary

```
                    ┌───────────────────────────────────────────┐
   OUTSIDE THE      │  W5 EXTERNAL WITNESS (published/notarized/ │
   TRUST BOUNDARY   │  third-party escrow) · the ENVIRONMENT ·   │
   ────────────────►│  L2 PHYSICAL MEASUREMENT · L4 HUMAN with   │
                    │  declared κ · L5 TRUSTED DB (write-        │
                    │  protected, version-pinned)                │
                    └───────────────────┬───────────────────────┘
                                        │ **THE ONLY GATE THROUGH WHICH
                                        │   E4 IS REACHABLE**
   ═════════════════════════════════════╪═══════════════════════════
                    ┌───────────────────▼───────────────────────┐
   GP / OFF-        │  THE ANCHOR (W1–W5, W_min, ≥1 external) ·  │
   SUBSTRATE        │  the Checkpoint Service · the OP archive · │
                    │  KC (as witness W2 and as KC-1/2/3/4)      │
                    └───────────────────┬───────────────────────┘
                                        │ policy, authorization, ceilings,
                                        │ inbreeding_F, epoch
   ═════════════════════════════════════╪═══════════════════════════
                    ┌───────────────────▼───────────────────────┐
   ORGANISM         │  Memory Authority · Memory Service ·       │
                    │  Contradiction Detector · Homeostasis ·    │
                    │  Immune                                    │
                    └───────────────────┬───────────────────────┘
                                        │ propose / commit / read
   ═════════════════════════════════════╪═══════════════════════════
                    ┌───────────────────▼───────────────────────┐
   SUBJECT          │  Cells, circuits, regions — **UNTRUSTED     │
   (UNTRUSTED)      │   FOR EVERY EPISTEMIC FIELD**               │
                    └───────────────────────────────────────────┘

⟹ **R40.1 (THE BOUNDARY RULE).** *A subject is trusted for its OWN T0 and
   local-episodic content, and for NOTHING that crosses a tier boundary.
   Every epistemic field on a shared-tier record is written by a principal
   ABOVE the subject: `evidence_status` by an external gate, `inbreeding_F`
   by the Anchor, `gt_class` by EVA, `protection_tag` by the Registrar,
   `src_identity` by channel binding, `calib_ref` by EVA.*
   **⟹ THIS IS CELL §2.4's PROHIBITION LIST, RESTATED AS A POSITIVE
      ALLOCATION: the cell is not a memory authority, not a verifier, not a
      truth source, not an evaluator, and not a trust authority — and §40.1
      shows what that means field by field.**
```

## 40.3 The threat model

| Adversary class | **Capability** | **What it can do** | **What it cannot do** |
|---|---|---|---|
| **A-1 Compromised subject** | Full control of one cell/circuit's local state, its WM, its local episodic, its θ, its retrieval weights | **Bias its own attention (§11.4's residue); flood proposals (#30); inject into its OWN T0** | **Forge a root (FM-2) · alter a shared record (SP-1) · raise its own `evidence_status` (R40.1) · self-report `inbreeding_F`** |
| **A-2 Colluding subjects** | A-1 × k, with coordination | **Create k records that look independent on dims 1–5 IF they use distinct roots and distinct instruments** | **⟵ ⚠️ THIS IS THE REAL THREAT, and it is dim 6 (§21.2). If the collusion shares a latent assumption, dims 1–5 do not detect it. **If it does NOT share an assumption, it is genuine independent evidence and there is nothing to detect**** |
| **A-3 Compromised Memory Service** | Full control of the GP service | **Differentially serve (§40.4) · delay · decline · bias ranking (influence plane)** | **Alter an anchored root (SP-1) · forge `inbreeding_F` (Anchor-computed) · issue a `gt_class` (EVA-only) · delete an anchored record (R35.1)** |
| **A-4 Compromised Memory Authority** | A-3 + approval authority | **Approve semantic/protected writes · authorize merges (CT-6's `MERGED_AS_ONE_CLAIM`)** | **⚠️ Act without KC-2 for T5, permanent delete, restore, PROTECTED-raise · exceed a KC-3 ceiling · act during a KC-4 freeze** |
| **A-5 Compromised KC** | Authorization authority | **⚠️ THE WORST CASE. Authorize anything** | **Alter the Anchor's EXTERNAL witness (W5) — and this is why W5 exists and why P0-02 §6.1 item 19 calls a single internal copy of history «the classic error». A compromised KC can authorize a deletion; **it cannot make the deletion unrecorded, because the deletion authorization is itself anchored and W5 is outside operational control**** |
| **A-6 Compromised Anchor witness set below W_min** | Forge history within the epoch | **⚠️ P0-02 §20.4: «a thin witness set is forgeable»** | **Forge anything already witnessed by W5 · forge across a campaign boundary (P0-01 R8.13's external bundle)** |

## 40.4 The selective-availability residue — declared

> ### **⚠️ R40.2 (SP-5 IS PARTIAL, AND HERE IS EXACTLY HOW).** *A compromised Memory Service (A-3) can serve record `r` to reader X and decline it to reader Y, within an epoch. **The epoch Merkle root does not detect this, because the root covers the STORE, not the SERVING.***
>
> **What limits it:**
> 1. **Declines are logged** (§25.3 R25.3: a DECLINE is recorded in the retrieval trace) — so a *pattern* of differential declining is detectable at `O(R)` aggregate as a divergence between readers' received distributions (§28.1 R28.1's detector pattern applied to serving rather than retention).
> 2. **`purpose_class` filters are policy-declared and auditable** (§25.4) — so a decline must be justifiable by a declared filter, and a decline that no declared filter explains is an incident.
> 3. **⟹ But a service that declines *plausibly* — citing budget, staleness, or scope — is not detected.**
>
> **⟹ §100 OR-M9: differential serving within an epoch is bounded by logging and detectable in aggregate, but not preventable. This is the memory-layer analogue of P0-03's undetectable dim-6 correlation: both are cases where the mechanism is inside the thing being audited.**

---

# §41. MEMORY POISONING MODEL — **OUTPUT 32**

## 41.1 **OUTPUT 32 — the poisoning map, by ingestion step**

**Vol A §11.1's eight-step pipeline is the attack surface. Each step is a poisoning point, and each has a defense with a declared disposition.**

| Step | **Poison** | **Defense** | **Disposition** |
|---|---|---|---|
| **[1] VALIDATION** | **Malformed-record flooding** — force the validator to spend budget on garbage | Rate limit + KC-3 write-rate ceiling | ✅ **BOUNDED** |
| | **Schema smuggling** — a record whose `record_type` is valid but whose `content` carries an embedded instruction | **`content` is TYPED and BOUNDED; a record is data, never a program. ⟵ Cell §2.4: a cell is not an evaluator** | ✅ **STRUCTURAL** |
| **[2] PROVENANCE** | **#2 provenance forgery** — an invented root hash | **FM-2: roots must resolve in the Anchor; an invented hash does not ⟹ rejection + `E_PROVENANCE` + immune report** | ✅ **CLOSED** |
| | **Provenance laundering (#3)** — genuine root, misattributed content | **⚠️ PARTIAL. The root resolves, so SP-2 passes. What catches it: the root's own content commitment. If the Anchor's root registry commits to the observation's content digest, then content ≠ committed content is detectable. ⟹ R41.1: THE ANCHOR'S ROOT REGISTRY MUST COMMIT TO A CONTENT DIGEST, NOT ONLY TO AN IDENTITY. Without this, laundering is trivial** | ⚠️ **CLOSED IF R41.1 HOLDS; §96's conformance test requires it** |
| **[3] CLASSIFICATION** | **#36–#40 masquerading** — a simulation, counterfactual, learned rule, prediction, or inference presented as an observation | **R12.1: `source_class` is captured from the message and is IMMUTABLE. No operation changes it** | ✅ **STRUCTURAL — MEM-INV-02** |
| | ⚠️ **Misclassification at the source** — the *asserting subject* declares SC-2 for what is actually SC-7 | **⟵ THE REAL POISONING VECTOR, AND IT IS NOT CLOSED BY R12.1. What limits it: (a) `src_identity` is derived, so the asserter is known; (b) a subject whose SC-2 assertions repeatedly fail E4 grounding is a calibration failure (V3.1 §4's confidence-error mismatch: «if a cell was highly confident and repeatedly wrong → calibration failure → reduce trust in that cell, route verification elsewhere»); (c) MEM-D4 detects a `gt_class`/`source_class` distribution divergence** | ⚠️ **DETECTABLE, NOT PREVENTABLE — §100 OR-M10** |
| **[4] EVIDENCE STATUS** | **Gate bypass** — claim E3 without passing the contradiction check | **`evidence_status` is EXTERNALLY written (R40.1). The subject proposes; the gate assigns** | ✅ **STRUCTURAL** |
| **[5] ADMISSION** | **Tier jumping** — an E0 record in T2 | **R0.2: `storage_tier` is DERIVED from `evidence_status` and is not independently writable** | ✅ **STRUCTURAL** |
| **[6] DEDUP** | **#12 semantic collision** — content engineered to hash to an existing key | **Vol A §15.2 D-1: identical content + different `root_commit` ⟹ TWO records, linked, never merged** | ✅ **CLOSED** |
| | ⚠️ **Dedup oracle abuse** — probe the dedup to learn what is stored | **§52's compartment check runs BEFORE dedup (a record the requester may not read must not be discoverable by hashing candidate contents)** | ✅ **CLOSED BY ORDERING — and §96 tests the ordering** |
| **[7] CONTRADICTION** | **#16 contradiction suppression** — prevent detection | **The detector runs in the Memory Service at ingestion, not in the subject (§20.5)** | ✅ **CLOSED for detection** |
| | ⚠️ **Contradiction avoidance** — never write the record that would contradict | **MEM-D1 (§28.1 B-5): a systematically low contradiction rate relative to input distribution is filtering, and P0-03 R67.1's rule applies: a zero-contradiction rate above a `[G]` duration is an immune incident** | ⚠️ **DETECTABLE IF SYSTEMATIC — §100 OR-M2** |
| **[8] STORAGE/INDEX** | **Index poisoning** — corrupt a view so records are unfindable | **R25.2: index failure is never record failure; MEM-D5 (§28.1 B-3) detects a falling reachable fraction and forces a rebuild** | ✅ **CLOSED** |
| | **Ranking manipulation** — bias the learned retrieval function | **§26.2 S-2: rank and `evidence_status` are separate returned fields; §27.2 prohibits access-frequency, citation-count, importance, confidence, consensus, and belief-similarity as ranking signals** | ⚠️ **BOUNDED IN EFFECT (§26.3's residue: it can change what is CONSIDERED, not what is BELIEVED)** |

## 41.2 The three poisonings that target the *system* rather than a record

| Poison | **Target** | **Mechanism** | **Defense** |
|---|---|---|---|
| **P-1 CONSERVATISM INDUCTION** | The organism's willingness to act | **Inject `failure_record`s (§34.3). Because `failure_record` is PROTECTED from deletion, injected failures are permanent, and §90's conservatism trap does the rest** | **R34.3: creating a `failure_record` requires E2 attribution, so it requires anchored provenance (FM-2 blocks fabrication). ⚠️ BUT: a genuine E2 failure record from a compromised subject IS admissible. ⟹ The defense is MEM-D4's source-distribution detector plus §90's bounded optimism budget, NOT prevention. §100 OR-M11** |
| **P-2 RECKLESSNESS INDUCTION** | The organism's failure memory | **Suppress or under-report failures** | **⚠️ HARDER THAN P-1, because suppression is an ABSENCE and absence is only detectable against an expected distribution (MEM-D1's pattern). §100 OR-M2** |
| **P-3 OSSIFICATION INDUCTION** | The storage budget | **Flood protection-tag requests until `PROTECTED_FRACTION_MAX` is reached, so nothing new can be protected and RC-1…RC-3 bear all the pressure** | **R34.4: protection-request RATE is a KC-3 ceiling; sustained excess is an immune incident (§49). ⟹ BOUNDED** |

---

# §42. HISTORY REWRITING & THE STALE-POLICY ATTACK

## 42.1 «Do not let the organism rewrite historical evidence»

> ### **R42.1 (THE FOUR REWRITE VECTORS, AND THEIR CLOSURE).**

| Vector | **Mechanism** | **Closure** | **Status** |
|---|---|---|---|
| **RW-1 IN-PLACE MODIFICATION** | Alter a stored record | **MEM-INV-06: no modify authority exists for anyone, including KC (Vol A §8.1's matrix has ❌ in every "modify content" cell).** SP-1 | ✅ **CLOSED STRUCTURALLY — there is no operation to perform** |
| **RW-2 DELETION** | Remove a record so it cannot be cited | **R35.1: anchored records cannot be deleted. §35.4: the root, the deletion state, the authority, the reason, and the before/after root pair all survive permanently** | ✅ **CLOSED — deletion is visible, authorized, and reversible-in-principle for ARCHIVED** |
| **RW-3 SUPERSESSION FLOOD** | Create so many V-SUPERSESSION versions that the original is buried | **MEM-INV-17: superseded records remain readable under `purpose_class = AUDIT` and are never removed from the version chain. And version-creation RATE is bounded by the write-rate KC-3 ceiling** | ✅ **BOUNDED** |
| **RW-4 RETROACTIVE REINTERPRETATION** | **Keep the record, change what it MEANS** — re-scope it, re-contextualize it, re-classify its source | **⟵ ⚠️ THE HARDEST VECTOR, AND IT IS WHERE §42.2 LIVES.** `source_class` is immutable (R12.1) ⟹ RW-4 cannot reclassify. `context_scope` is mandatory and immutable on the record ⟹ RW-4 cannot re-scope the record. **BUT RW-4 CAN CREATE A NEW GENERALIZATION (§32) OVER THE OLD RECORDS WITH A DIFFERENT INTERPRETATION** | ⚠️ **BOUNDED BY R32.1–R32.4: the new generalization has warrant ≤ MIN of its instances and scope ⊆ ∩ of its instances. ⟹ A reinterpretation cannot be STRONGER or BROADER than what it reinterprets. It can only be a weaker, narrower claim — which is the correct outcome for a reinterpretation** |

## 42.2 The stale-policy attack

```
THE ATTACK: a belief was formed and stored under policy P₁. P₁ is later
retracted because it was unsound. **The belief remains in the store, with
valid anchored provenance, and is cited as evidence under policy P₂.**

WHY IT WORKS NAIVELY: the belief's provenance is genuine. Its root resolves.
Its `evidence_status` is E3. Nothing about the RECORD is wrong. **What is
wrong is the RULES UNDER WHICH IT WAS ADMITTED — and a record that does not
carry its rule context cannot be checked against them.**

THE CLOSURE — **AND IT IS INHERITED, NOT INVENTED:**
  P0-02 §12: **«Policy-bound memories: a memory recorded under a retracted
  policy is not deleted (M6) but flagged `VOID_CONTEXT`.»**

  ⟹ Vol A §5.1's `policy_version_ref` (MANDATORY) + Vol A §16.1's
    `VOID_UNDER` claim-graph edge (MANDATORY) + §17.2's `VOID` belief state
    + §20.4's `VOID_ONE` contradiction resolution status
    + §24.1's `policy_version?` context dimension.

  ⟹ **FIVE SEPARATE MECHANISMS, ALL INHERITED, ALL MANDATORY, TOGETHER
     MAKING THE ATTACK STRUCTURAL-RATHER-THAN-DETECTED:**
     a record written under P₁ CARRIES P₁, and when P₁ is retracted the
     record is VOID — **not deleted (M6: the history of having been written
     under bad rules IS the audit trail), and not citable under P₂.**

⚠️ **THE RESIDUE, DECLARED:**
  1. **A VOID record's DERIVATIVES are not automatically VOID.** If record B
     was generalized from record A, and A becomes VOID, B's warrant must be
     recomputed. **⟹ R42.2: VOID PROPAGATES ALONG `derived_from` EDGES AS A
     WARRANT REDUCTION, NOT AS A VOID. B does not become VOID (B was written
     under P₂); B loses A from its admissible support set, and its
     `n_effective` falls. **If that drops B below θ_support, B's belief state
     falls too — automatically, by the §19.2 algorithm.****
  2. **Policy retraction is itself a policy act**, and a compromised OP could
     refuse to retract a bad policy. **⟹ Not a memory problem; P0-02's
     governance problem, and §92 records the dependency.**
```

## 42.3 The memory-mediated independence fraud — the deep treatment

**Vol A §10.3 gave the four-point closure. The deeper analysis, and the one case that survives it:**

```
THE SURVIVING CASE: **A LONG-LIVED MEMORY AS A CORRELATION LAUNDERING
DEVICE.**

  Epoch 1:   source A observed by cell X ⟹ record r₁ (root R, depth 0)
  Epoch 50:  r₁ retrieved by cell Y, re-emitted ⟹ record r₂ (root R, depth 2)
  Epoch 200: r₂ retrieved by cell Z, re-emitted ⟹ record r₃ (root R, depth 4)
  Epoch 400: a claim C is supported by r₁, r₂, r₃.

  NAIVE: three records, three subjects, three epochs ⟹ independent.
  ACTUAL: dim 1 (shared root R) collapses all three. n_effective = 1. ✅

  **THE CASE THAT SURVIVES:** the root registry has ROLLLED OVER. R is no
  longer resolvable — not because it was deleted (R35.1 forbids that), but
  because the epoch at which R was anchored is beyond the online window and
  is only in the W4/W5 offline archive.

  ⟹ **R42.3 (THE ANCHOR RETENTION REQUIREMENT).** *The root registry MUST
     remain resolvable for at least as long as any record citing it remains
     retrievable as evidence. **A root that has aged out of the online
     registry while records citing it are still live is a MEM-INV-03
     violation, and every such record MUST be demoted to UNANCHORED ⟹
     P0-02 R20.1: no consequential decision may rest on it.***

     **⟹ The choice is explicit and `[G]`-governed: either the online root
        registry grows without bound (infeasible, §56), or records lose
        anchorability over time (correct, and it means old evidence becomes
        progressively less usable for consequential decisions — WHICH IS THE
        RIGHT BEHAVIOUR, because old evidence IS progressively less
        revalidatable (§22)).**

     **⟹ AND THE OFFLINE ARCHIVE (W4/W5) IS THE ESCAPE HATCH: a root can be
        re-resolved against the offline archive at O(1) cost per lookup, by
        an evaluator-side operation (§95), restoring anchorability. ⟹ Old
        evidence is not lost; it becomes an OFF-LINE resource. This is the
        same runtime/evaluator split as Vol A §16.2 and Vol B §19.4.**
```

---

# §43. MEMORY ↔ EVALUATION — **OUTPUT 9**

## 43.1 **OUTPUT 9 — the contract**

| Direction | **Artifact** | **Authority** | **⚠️ Prohibited** |
|---|---|---|---|
| **MEMORY → EVA** | E2+ records as evaluation evidence, with full provenance | Memory Service supplies; **EVA selects under β sampling (P0-01 R8.13's strata)** | ❌ **Memory MUST NOT supply a verdict, a score, a ranking-as-quality, or a `gt_class`** |
| **MEMORY → EVA** | The `instance_refs` and support sets for any generalization under evaluation | Same | ❌ **Memory MUST NOT pre-aggregate: EVA computes `n_effective` itself from the support set, because a memory-supplied aggregate is a memory-supplied judgement** |
| **EVA → MEMORY** | **`gt_class` (L0–L6) on records** | **EVA ONLY** | ❌ **L7 is PROHIBITED (P0-01 R8.1)** |
| **EVA → MEMORY** | **`calib_ref` calibration records** | EVA ONLY | ❌ **No subject may self-calibrate** |
| **EVA → MEMORY** | **The E4 gate measurement** (agreement with L0–L3) | EVA ONLY | ❌ **R13.1: no internal pathway from belief to verdict** |
| **EVA → MEMORY** | **R9.4's compromise notification ⟹ the V-ROLLBACK set** | EVA issues; the rollback is computed off-line from the Anchor (§36.3) | ❌ **The Memory Service MUST NOT compute the affected set at runtime (Vol B R19.4: unbounded traversal)** |
| **EVA → MEMORY** | **Ground-truth STATE (0–9)** | EVA | ❌ **R9.1: absence/delay/insufficiency/conflict/compromise MUST be `UNRESOLVED`, never `CONFIRMED`** |

## 43.2 The three interface rules that matter

> ### **R43.1 (MEMORY CANNOT ISSUE VERDICTS).** *Vol A §10.4, restated as a contract rule: the Memory Service and Memory Authority are not evaluators. **⟹ «VERIFIED» is recorded by the Memory Authority as EVA's verdict; it is never issued by the Memory Authority** (Vol A §8.1's matrix).*

> ### **R43.3 (ω DETERMINES WHETHER MEMORY IS TESTABLE AT ALL).** *P0-01's ω (observability) governs: **ω = 1 ⟹ memory is an optimization, not a necessity, and a memoryless agent performs identically. ω < 1 ⟹ memory is load-bearing and a memoryless agent is provably suboptimal. R5.3: a task with ω = 1 CANNOT test memory or belief maintenance.***
>
> **⟹ THE CONSEQUENCE FOR §96's CONFORMANCE SUITE, AND IT IS DECISIVE: *every test of the memory architecture requires a task with ω < 1. A conformance suite built on fully-observable tasks tests nothing about memory, and will pass an implementation with no memory at all.*** **This is not a testing detail; it is the difference between a conformance suite that validates the architecture and one that validates the harness.**

> ### **R43.4 (EPISODIC REPLAY IS AN EVALUATION PROTECTION, NOT A MEMORY FEATURE).** *P0-01's `08_…evaluation.md` L319–321 lists drift-memory protection and L343 lists episodic replay. **⟹ The direction of the dependency is Eva→Memory: EVA requires that replay material be available and unaltered, and the Memory subsystem's obligation is that RC-4/RC-5 replay material remains retrievable across any learning update (§34.6 R34.6). Memory does not decide what is replayed for evaluation; EVA does, under β sampling.***

## 43.3 What EVA must NOT read

| Prohibited read | **Why** |
|---|---|
| **T0 working memory** | **P0-01: E0 RAW «may influence WORKING MEMORY only» — and E0 is not evidence (R6.1). Reading WM as evidence would promote E0 to admissible** |
| **A subject's θ or retrieval weights** | **These are influence-plane learned state. Reading them as evidence makes learning an epistemic authority (§44)** |
| **`importance` values** | **D-2: an allocation quantity. Reading it as evidence makes salience an epistemology** |
| **Records under `RECOVERY_INCOMPLETE`** | **§38.3: an incomplete tier is `UNKNOWN` for belief purposes. Reading it as evidence converts a gap into a result** |
| **`n_effective` as a supplied value** | **It does not exist as a stored value (Vol A D-1). EVA computes it from the support set** |

---

# §44. MEMORY ↔ LEARNING — **OUTPUT 10**

## 44.1 **OUTPUT 10 — the contract**

| Direction | **Permitted** | **⚠️ Prohibited** |
|---|---|---|
| **LEARNING → MEMORY (read)** | Any record within compartment, at any tier | ❌ **Reading a record and treating its retrieval as corroboration (MEM-INV-09)** |
| **MEMORY → LEARNING (write)** | **T0 working memory** · **cell-local bounded episodic** · **learned θ** · **T3 procedural records, gated on `improvement_verified`** | ❌ **Learning MUST NOT write `evidence_status`, `belief_state`, `gt_class`, `calib_ref`, `protection_tag`, `inbreeding_F`, or `source_class`** |
| **LEARNING → T2 SEMANTIC** | ⚠️ **ONLY via §31's consolidation with all eleven gates, and the learned content enters as `SC-7 ORGANISM_INFERENCE` with ceiling E3 (R12.2)** | ❌ **A learned rule MUST NOT enter as SC-2 `EXTERNAL_MEASURED` — that is #38 (learned-rule masquerading as observation), and R12.1's immutability is what blocks it** |
| **LEARNING → T4 CONSOLIDATED** | ❌ **NEVER DIRECTLY.** R31.1: consolidation alone cannot reach T4; only an external E4 gate can | — |

## 44.2 The three learning/memory failures

| Failure | **Mechanism** | **Defense** |
|---|---|---|
| **LF-1 CATASTROPHIC FORGETTING** | A learning update destroys the ability to use retained records | **§34.5: episodic replay + `capability_critical` protection + Cell T7 (failure ⟹ `plasticity_mult` DOWN). R34.6's mutual guarantee** |
| **LF-2 LEARNED-RULE LAUNDERING (#38)** | A learned generalization is stored and later retrieved as an observation | **R12.1 (`source_class` immutable) + R12.2 (SC-7 ceiling E3) + R32.1–R32.4 (generalization bounded by its instances) + R32.4's `instance_refs` (a rule whose instances are gone is not retrievable as support)** |
| **LF-3 RETRIEVAL-WEIGHT CAPTURE (L-8)** | Learned retrieval weights create §26.3's attractor | **R42.2 (P0-03): «the learnable retrieval function is influence-plane and must never affect warrant.» MEM-D2 detects the divergence. ⚠️ §26.3's residue: it can change what is CONSIDERED** |

**R44.1 (THE LEARNED/INHERITED DISTINCTION — Task 3 Rule 14).** *Learned state (θ, retrieval weights, procedural records, consolidated semantic records) MUST be distinguishable from inherited genome at every level, and the distinction is a FIELD, not a convention:* **`source_class` ∈ {SC-7 … SC-14} marks learned/internal origin, and `lineage_ref` marks inherited origin, and the two are written by different principals (R40.1). ⟹ §47 makes this the inheritance prohibition's enforcement mechanism.**

---

# §45. MEMORY ↔ PLASTICITY — **OUTPUT 11**

## 45.1 **OUTPUT 11 — the contract**

**Inherited: Cell §9.2's triggers T1–T8. Every one of them is a plasticity↔memory interface, and every one was already correctly specified. The contract restates them and adds what was missing.**

| Trigger | **Inherited statement** | **Memory obligation** | **⚠️ Prohibited** |
|---|---|---|---|
| **T4** | **Self-supervised signal may not increase own reward** | The record of a self-supervised update carries `source_class = SC-7` and ceiling E3 | ❌ **A self-supervised update MUST NOT produce an SC-2 record** |
| **T6** | **Repeated success ⟹ CONSOLIDATION CANDIDATE, not a large Δθ** | **§30.1: repetition schedules work; it does not produce warrant. The candidacy is an ALLOCATION event** | ❌ **Repetition MUST NOT raise `evidence_status` (MEM-INV-12)** |
| **T7** | **Failure ⟹ `plasticity_mult` DOWN** | **The failure record is a `failure_record` (RC-4 PROTECTED, §34.3)** | ❌ **A failure record MUST NOT be evictable for disuse (Cell R10.6)** |
| **T8** | **Recalibrate the EPISTEMIC head only** | **R18.2: observation-confidence may be recalibrated; belief-confidence is computed, never calibrated** | ❌ **T8 MUST NOT touch the reward head — that is R18.2's distinction, and crossing it makes calibration a reward hack** |

## 45.2 The central distinction

> ### **R45.1 (A SYNAPTIC UPDATE IS NOT A DECLARATIVE MEMORY).** *Plasticity changes **weights** (θ, `plasticity_mult`, retrieval weights). Memory stores **records**. The two are different substrates with different authorities:*
>
> | | **PLASTICITY (weights)** | **MEMORY (records)** |
> |---|---|---|
> | **Owner** | The cell (within `[G]` bounds) | §8.1's authority matrix |
> | **Plane** | **INFLUENCE** | **WARRANT (for epistemic fields) + storage** |
> | **Auditable?** | ⚠️ **Only by outcome** — a weight is not a claim | ✅ **Fully — a record has provenance** |
> | **May it be evidence?** | ❌ **NEVER. A weight is not a claim, and §43.3 prohibits EVA from reading weights as evidence** | ✅ **At E2+** |
> | **Heritable?** | ⚠️ **Priors yes, values no (§47)** | ❌ **NEVER (§47)** |
>
> **⟹ THE CONSEQUENCE, AND IT IS WHY §45 EXISTS AS A SEPARATE INTERFACE: a system that treats plasticity as memory would allow an unauditable weight change to function as an evidence update, and MEM-INV-02's observation/inference separation would be bypassed through a substrate that has no `source_class` field at all.**

**R45.2 (WHAT PLASTICITY MAY READ FROM MEMORY).** *Plasticity may read any record within compartment and may use it to compute a weight change. **Plasticity may not write a belief state, may not change an evidence status, and may not create a record whose `source_class` is stronger than the operation that produced it.*** **⟹ Cell §8.1's in/out table already enforces the first two; the third is MEM-INV-02 restated for the plasticity path.**

---

# §46. MEMORY ↔ EVOLUTION — **OUTPUT 12**

## 46.1 **OUTPUT 12 — the contract, and the selection argument**

```
THE ARGUMENT (X-M2's resolution, elaborated):

  **RELAXING A RETENTION BOUND IS ADVANTAGEOUS PRECISELY WHEN IT IS
   DANGEROUS.**

  A lineage that forgets faster:
    • uses less storage                    ⟹ survives resource pressure
    • has a more coherent corpus           ⟹ fewer contradictions detected
                                           ⟹ higher apparent consistency
    • does not retain failure records      ⟹ §90's conservatism does not
                                           ⟹ acts more often
                                           ⟹ accrues more L6 outcomes
                                           ⟹ **HIGHER MEASURED PERFORMANCE**

  **EVERY ONE OF THESE IS A SELECTION ADVANTAGE, AND EVERY ONE OF THEM IS
   EPISTEMICALLY DESTRUCTIVE.** ⟹ **If retention bounds are heritable and
   selectable, selection finds the destructive end of the range. This is not
   a bug in the selection criterion; it is what the selection criterion IS.**

⟹ **R46.1 (THE RESOLUTION, IDENTICAL IN FORM TO P0-03 R48.2).** *Retention
   BOUNDS are POLICY (`[G]`, OP-owned, RO-13). Retention PARAMETERS within
   the bounds are heritable.*

   | **Heritable (priors, within policy bounds)** | **NEVER heritable** |
   |---|---|
   | `WM_CAP` prior | Retention CLASSES (RC-1…RC-5) |
   | `EPI_CAP` prior | `PROTECTED_FRACTION_MAX` |
   | `τ` retention-curve prior | Protection TAGS and their assignment authority |
   | `θ_recall` prior | Admission GATES (R0.2) |
   | Retrieval-weight initialisation | Consolidation requirements (G0–G11) |
   | Eviction ORDER within a policy-defined class | `F_max` |
   | — | **`importance`'s definition (D-2: it is homeostasis-computed, §50)** |

⟹ **AND X-M2's RE-READING: V3.1 §7's «memory-policy variation» is
   «memory-PARAMETER variation within policy bounds». The intent — that
   lineages differ in how they remember — is fully preserved. The leak —
   that a lineage could decide what it is allowed to keep — is closed.**
```

## 46.2 The selection criterion (Task 3 Rule 13) and rare-but-valuable strategies (Rule 15)

> ### **R46.2 (MEMORY'S ROLE IN PRESERVING RARE STRATEGIES).** *Rule 15 requires that rare-but-valuable strategies not be auto-eliminated. **Memory is the mechanism by which this is possible, and the requirement translates into three memory obligations:***
> 1. **A strategy's evidence base must survive the strategy's rarity.** ⟹ **`instance_refs` (R32.4) are RC-3 DURABLE minimum: a rare strategy with three supporting instances must not lose those instances to disuse-forgetting (M-C), because rarity implies low retrieval frequency implies high disuse-forgetting risk. ⟹ R46.3: RETRIEVAL FREQUENCY MUST NOT BE AN INPUT TO THE RETENTION OF A RECORD THAT IS THE SOLE SUPPORT FOR A CLAIM.** *This is the one place where §34.4's M-C is restricted, and the restriction is required by Rule 15.*
> 2. **A rare strategy's failure records must not be the only thing retained.** ⟹ §34.3's `failure_record` protection applies symmetrically: rare successes are also protected from disuse-forgetting when they are sole support.
> 3. **The selection criterion must be EXTERNAL FITNESS, not memory-internal performance.** ⟹ **P0-01's «fitness ≠ performance»: a strategy whose corpus looks coherent (because it forgot its contradictions) must not out-select one whose corpus looks messy (because it retained them). ⟹ R46.4: CONSISTENCY OF THE RETAINED CORPUS MUST NOT BE A SELECTION CRITERION. **And MEM-D1's detector is what makes the difference visible: a lineage with a suspiciously coherent corpus is flagged, not rewarded.***

---

# §47. MEMORY ↔ EVOLUTIONARY INHERITANCE — **OUTPUT 40**

## 47.1 «Do not allow acquired memory to automatically rewrite inherited genome»

> ### **R47.1 (THE LAMARCKIAN PROHIBITION).** *No record, belief, claim, generalization, consolidation output, or learned weight may write to a genome. **The channel does not exist, and §47.3 shows that Cell §17.5 already established the pattern.***

## 47.2 What IS heritable, and what is not

| | **Heritable** | **NOT heritable** |
|---|---|---|
| **Genome-encoded** | Structural priors: `WM_CAP`, `EPI_CAP`, `τ`, `θ_recall`, `θ_write` **priors** — all bounded by policy (R46.1) | — |
| **Memory content** | — | ❌ **Every record. Every claim. Every belief state. Every generalization. Every contradiction. Every `evidence_status`.** |
| **Learned state** | — | ❌ **θ values, retrieval weights, procedural records (T3), consolidated semantic records (T2/T4)** |
| **Provenance** | — | ❌ **`root_commit`, `lineage_ref` (which IS an audit artifact but is a GOVERNANCE RECORD, not an inheritable trait — Vol A §6.2's N2)** |

## 47.3 The one legitimate channel — and why it is not inheritance

**Cell §17.5's retirement knowledge-extraction, quoted: «audited, externally-validated semantic content may promote to organism memory — *not inheritance, and it never writes to a genome*.»**

```
THE CHANNEL:
  A cell retires. Its local material is AUDITED and EXTERNALLY VALIDATED.
  Content that survives may be promoted to ORGANISM MEMORY (T2 semantic).

WHY THIS IS NOT LAMARCKIAN:
  1. **THE DESTINATION IS MEMORY, NOT GENOME.** The promoted content is a
     RECORD, subject to every rule in this package — R12.1's source_class
     immutability, R32.1–R32.4's generalization bounds, R0.2's admission
     gates. **It does not become a trait.**
  2. **THE VALIDATION IS EXTERNAL.** «Audited, externally-validated» ⟹ the
     promoting subject does not validate its own material.
  3. **THE PROMOTION IS TO AN INDIVIDUAL'S MEMORY, NOT TO A LINEAGE.**
     Offspring do not receive it.

⟹ **THE ONLY WAY ACQUIRED KNOWLEDGE REACHES A GENOME IS THE BALDWIN CHANNEL,
   AND IT IS NOT A CHANNEL AT ALL:**
   A learned behaviour improves FITNESS ⟹ the lineage that learns it more
   readily out-selects ⟹ over generations, the LEARNING DISPOSITION (a
   structural prior, R46.1) is selected, not the learned content.

   **⟹ WHAT IS SELECTED IS THE CAPACITY TO ACQUIRE, NEVER WHAT WAS ACQUIRED.
      And the selection pressure is FITNESS, which P0-01 established is
      external and is not performance. ⟹ The Baldwin channel passes through
      an external measurement at every generation, and therefore cannot
      launder internal belief into inherited trait.**

⚠️ **THE RESIDUE, DECLARED:** a structural prior IS shaped by what was
   learned, statistically, over generations. **A lineage raised in an
   environment where X was always true will evolve priors tuned to X.** That
   is not a record of X and it is not a belief that X — it is a disposition
   that makes X-shaped hypotheses cheaper to acquire. **⟹ §100 OR-M12: the
   Baldwin channel is not a provenance channel, and priors carry no
   `source_class`. A prior tuned by a false regularity is a well-adapted
   lineage in a changed environment, and there is no field anywhere that
   records this. §90's conservatism trap is the behavioural form of the same
   problem.**
```

## 47.4 The inheritance invariants

| Invariant | Statement |
|---|---|
| **MEM-INV-18** | **No memory operation may write to a genome.** The write path does not exist |
| **MEM-INV-19** | **Learned state and inherited genome MUST be distinguishable by field, at every level** (R44.1): `source_class` for learned/internal origin, `lineage_ref` for inherited origin, written by different principals |
| **MEM-INV-20** | **A lineage's evolutionary history is a GOVERNANCE RECORD in the EIK Lineage Store, not a memory** (Vol A §6.2's N2). **⟵ Cell §8.1: «a cell must not be able to write its own lineage»** |
| **MEM-INV-21** | **Retention bounds and admission gates are POLICY and are NOT heritable** (R46.1) |

---

# §48. MEMORY ↔ SELF-MODEL — **OUTPUT 16**

## 48.1 **OUTPUT 16 — the contract**

| Aspect | **Rule** | **Inherited from** |
|---|---|---|
| **What the self-model is** | **A MODEL (§3's definition): a structured representation that predicts or explains the subject's own behaviour, whose value is predictive usefulness, NOT literal truth** | Vol A §3, §64 |
| **Where it lives** | **Cell-local `self-history` ring, BOUNDED** (Cell §8.1: only WM, bounded local episodic, cache, θ, and self-history exist at cell level) | Cell §8.1 |
| **What it may contain** | `runtime_state` history · θ history · own `belief_state` history · own calibration record references · own retrieval statistics (**aggregate, `O(R)`, never per-access**) | Cell §8.2 |
| **⚠️ What it MUST NOT contain** | **A belief about the subject's own correctness that is not externally calibrated.** V3.1 §4's «retrieval confidence» in self-state is **REJECTED as a self-declared quantity** and **RETAINED as a reference to an EVA-assigned `calib_ref`** | **R40.1, R18.3's producer table** |
| **Who may write it** | The subject, for its own local ring | Cell §8.1 |
| **Who may read it** | The subject; **EVA under β sampling; immune under an incident** | §52 |
| **⚠️ The prohibition** | **A self-model MUST NOT be a BELIEF STORE.** Vol A §6.2: self-memory is cell-local only, «and it is NOT a belief store» | — |

## 48.2 FM-4 — self-confirming recall

**Inherited in full (Cell §8.3): «FM-4 (self-confirming recall) defended by retrieval-never-increments-`n_obs` + `inbreeding_F`↑ ⟹ abstain.»**

```
THE ATTACK: a subject queries its own memory, retrieves its own prior belief,
and treats the retrieval as confirmation.

THE DEFENSES, ALL INHERITED, ALL STRUCTURAL:
  1. **R42.1 (P0-03): retrieval contributes n_obs = 0.** ⟹ The retrieval
     literally cannot increment a corroboration count, because there is no
     count to increment (Vol A D-1) and the contribution is zero.
  2. **§12 SC-12 `RETRIEVED`: ceiling = inherits the stored record's status,
     can never exceed it (R12.1).** ⟹ Re-retrieving cannot promote.
  3. **`inbreeding_F` is Anchor-computed and read-only, and counts evidence
     ancestry terminating in the subject's own records.** ⟹ Self-referential
     recall RAISES F, and **F > F_max ⟹ S6 ABSTAIN** (Cell FM-4's gate).
     **⟹ THE ATTACK IS SELF-DEFEATING: performing it moves the subject
     toward abstention.**
  4. **`causal_depth += 1` per retrieval-and-re-emission (R42.1), SATURATING
     (MEM-INV-14).** ⟹ Warrant attenuates monotonically (MEM-M2).

⚠️ **THE `[U]` RESIDUE — INHERITED VERBATIM, NOT CLOSED:**
   Cell §8.3: **«Bounding this requires a measure of *semantic*
   self-reference, not just provenance-graph depth. No rigorous mechanism is
   proposed here.»**

   **WHY THE FOUR DEFENSES DO NOT CLOSE IT:** all four operate on PROVENANCE.
   A subject can hold ten records with ten distinct roots, from ten distinct
   instruments, dim-1..5 disjoint, low `inbreeding_F`, low `causal_depth` —
   and those ten records can form a closed semantic circle in which each
   term is defined by the others. **The circle has no provenance signature.**

   ⟹ **§29.1's L-10, §81's analysis, Vol A §5.1's `[U]` field
      `semantic_self_reference_score`, and §100 OR-M1: P0-04'S PRINCIPAL
      UNCLOSED DEPENDENCY.** Vol B R29.1: **this is why §104's
      EVIDENCE-INDEPENDENCE rating is PARTIAL, not PASS.**
```

---

# §49. MEMORY ↔ IMMUNE — **OUTPUT 13**

## 49.1 **OUTPUT 13 — the contract, and the authority boundary (Task 3 Rule 10)**

| Trigger | **Source** | **Immune action** | **⚠️ Authority boundary** |
|---|---|---|---|
| **FM-2: unresolvable root** | Ingestion step [2] | **Rejection + `E_PROVENANCE` + immune report** | **Immune may QUARANTINE a record and may NOT delete it (§35.1: quarantine is `LOGICALLY_DELETED`, reversible by KC-2)** |
| **CT-5: provenance contradiction** | §20.3 | **`REFERRED_TO_IMMUNE` — not a belief event** | **Immune may not adjudicate the underlying claim (§20.4: that is the Contradiction Detector + EVA)** |
| **MEM-D1: systematic filtering** | §28.1 B-5 | **Bias incident. ⟵ P0-03 R67.1's memory instance: a zero-contradiction-report rate above a `[G]` duration is an immune incident** | **Immune may raise the subject's verification routing (V3.1 §4: «reduce trust in that cell, route verification elsewhere») and MAY NOT alter the subject's records** |
| **MEM-D2: retrieval-not-learning** | §28.1 B-2 | Bias incident | Same |
| **MEM-D3: quota gaming** | §28.1 / Vol B L-5 | Bias incident | Same |
| **MEM-D4: source-distribution divergence** | §28.1 B-1 | Bias incident | Same |
| **MEM-D5: index staleness** | §28.1 B-3 | **Force a view rebuild (R25.2: a view is rebuildable)** | **A view rebuild is warrant-neutral and needs no authorization** |
| **MEM-D6: recency bias** | §28.1 B-6 | Bias incident | Same as D1 |
| **#30 memory flooding** | KC-3 write-rate ceiling | **Throttle; sustained excess ⟹ incident** | **KC-3 is the ceiling; immune is the responder. Immune does not set the ceiling** |
| **R34.4: protection-request flood** | KC-3 protection-request ceiling | Throttle; incident | Same |
| **Integrity mismatch at checkpoint** | §37 | **FD, and FZ if witnesses < `W_min` (P0-02 §20.4's ladder)** | **⟵ The freeze authority is KC-4, not immune. Immune DETECTS and REPORTS; KC ACTS** |
| **`VOID_CONTEXT` propagation** | §42.2 R42.2 | **Warrant reduction along `derived_from` edges** | **Automatic, not an immune act — it is the §19.2 algorithm responding to a support-set change** |

**R49.1 (THE BOUNDARY, STATED ONCE).** *Immune **detects, reports, quarantines, and re-routes verification**. Immune **does not delete, does not adjudicate claims, does not set ceilings, does not freeze, and does not write epistemic fields.*** **⟹ Task 3 Rule 10 («every safety mechanism has an authority boundary») is satisfied by enumerating the four things immune may do and the five it may not, and §96 tests both lists.**

---

# §50. MEMORY ↔ HOMEOSTASIS — **OUTPUT 14**

## 50.1 **OUTPUT 14 — the contract**

| Quantity | **Homeostasis owns** | **⚠️ Prohibited** |
|---|---|---|
| **Storage budget allocation across tiers and regions** | ✅ Within `[G]` bounds and KC-3 ceilings | ❌ **May not allocate in a way that changes any record's `evidence_status`** |
| **`importance` (the allocation quantity)** | ✅ **R11.2/D-2's resolution: computed by homeostasis from DECLARED inputs — task relevance from the task spec, resource pressure, protection tags. NEVER by the storing subject** | ❌ **May not be an input to `evidence_status`, `belief_state`, `n_effective`, tier admission, or ranking (§27.2). MEM-INV-15** |
| **Eviction execution (M-A)** | ✅ Per Cell A-12's score, deterministically | ❌ **May not evict RC-4/RC-5, `capability_critical`, or a sole-support record (R46.3)** |
| **Revalidation budget allocation** | ✅ **By DEPENDENCY (§22.3), not by `importance`** | ❌ **May not revalidation-skip a record that a consequential decision rests on without recording the decision as resting on stale evidence (§22.3)** |
| **Access statistics aggregation** | ✅ **`O(R)` aggregate, never per-record, never written back to the record (MEM-INV-09)** | ❌ **May not be an input to ranking (§27.2) or to belief (R19.2 N12)** |
| **Resource-scarcity forgetting** | ⚠️ **Within `[G]` bounds and KC-3 deletion-rate ceiling** | ❌ **May not touch RC-4/RC-5. Vol A R9.2: without the KC-3 ceiling, «§50's resource-scarcity forgetting becomes an unbounded destructive authority»** |
| **Index/view maintenance and rebuild** | ✅ **R25.2: warrant-neutral** | ❌ — |

## 50.2 The ossification counterweight

**R34.4's `PROTECTED_FRACTION_MAX` is homeostasis's central constraint, and §50's obligation is to make its breach VISIBLE rather than to resolve it:**

```
ON protected_fraction ≥ PROTECTED_FRACTION_MAX:
  1. **DENY new protection requests.** ⟵ The conservative direction: stop
     protecting more, never stop protecting what is protected.
  2. **REPORT to OP as a policy-friction event** (P0-02 §15.3's V1 report
     class). **⟹ The correct response is a POLICY CHANGE (raising the
     ceiling or narrowing the protection criteria), which is RO-13 and
     OP-owned — NOT a homeostatic decision to revoke protections.**
  3. **APPLY INCREASED PRESSURE TO RC-1 AND RC-2 ONLY.** ⟹ RC-3 DURABLE
     material is protected from scarcity-driven forgetting up to a separate
     `[G]` bound, because RC-3 holds the `instance_refs` that R32.4 requires
     and the sole-support records that R46.3 requires.

⚠️ **DECLARED: this is R34.4's trade-off with no architectural resolution.
   A system at the protection ceiling is a system that cannot protect
   anything new, and if the new thing is a safety record, that is a real
   loss. §99 records `PROTECTED_FRACTION_MAX` as a `[G]` parameter with no
   principled derivation, and §100 OR-M13 records that the tension between
   protection permanence and storage finitude is not closable.**
```

---

# §51. MEMORY ↔ GLOBAL WORKSPACE — **OUTPUT 15**

## 51.1 **X2 RESOLVED — the workspace item's fields**

⚠️ **CONTRADICTION X2:** V3.1 §3 (L33) specifies that a workspace item carries **`source, timestamp, confidence, provenance, relevance, uncertainty`** — while COMM-INV-21 prohibits bare scalars and P0-03 establishes that relevance is kernel-assigned, not self-declared.

> ### **R51.1 (THE FIELD-BY-FIELD RESOLUTION).**

| V3.1's field | **Verdict** | **Replacement / rule** |
|---|---|---|
| **`source`** | ✅ **RETAINED** | Becomes `source_class` (§12's taxonomy) + `src_identity` (**DERIVED from channel binding, COMM-INV-09, never declared**) |
| **`timestamp`** | ⚠️ **RETAINED AS A FIELD, PROHIBITED AS EVIDENCE** | Becomes `write_epoch` + `event_interval` + `record_interval` (§23.1's three-way split). **COMM-INV-12: a timestamp is never evidence** |
| **`confidence`** | ❌ **PROHIBITED as a bare scalar** | Becomes §18.1's sufficient-statistics struct. **COMM-INV-21, P0-01 R6.4** |
| **`provenance`** | ✅ **RETAINED** | Becomes §13.2's structure: `root_commit` · `causal_depth` (saturating) · `corr_class` · `calib_ref` · `policy_version_ref` · `transform_history` |
| **`relevance`** | ⚠️ **THE CONTESTED ONE — RESOLVED BY RELOCATION** | **⟹ RELEVANCE IS NOT A PROPERTY OF AN ITEM. IT IS A PROPERTY OF AN (ITEM, QUERY) PAIR.** An item that carries «relevance» is declaring a universal property that does not exist — relevant to *what*? **⟹ The workspace ADMISSION decision uses task-relevance computed by the admission component (P0-03: «policy admission — task relevance, not locally computable»). The ADMITTED ITEM CARRIES `task_ref` (which task it was admitted for) and NO relevance field. Relevance is recomputed per query at retrieval (§27.2: query-match score is an admissible ranking signal; a stored relevance value is not)** |
| **`uncertainty`** | ✅ **RETAINED** | §18.1's struct, unchanged |

**R51.2 (WHY THE RELEVANCE RELOCATION IS THE RIGHT ANSWER AND NOT A DODGE).** *P0-03 established that workspace admission is by task relevance and that relevance is «not locally computable». **If relevance were a property of the item, the item's producer would compute it — and the producer is the subject, which makes relevance self-declared, which makes it forgeable, which makes the workspace admission gate a subject-controlled gate.*** **⟹ X2 and X-M1 (§8.3's memory-policy-plastic leak) are the SAME DEFECT: a subject-declared quantity gating a subject's own access. Relocating relevance to the (item, query) pair removes it from the item and therefore from the producer.**

## 51.2 **OUTPUT 15 — the contract**

| Aspect | **Rule** |
|---|---|
| **What the workspace is** | **T0 at organism scale — a BOUNDED, EPHEMERAL, POLICY-ADMITTED BROADCAST SUBSTRATE. It is NOT a memory tier.** P0-03's adopted design: 3-tier pull, `O(R)` notifications, hard capacity, mandatory TTL, KC excluded |
| **Workspace → memory** | ⚠️ **A workspace item is a CANDIDATE for memory, never a memory. It enters at ingestion step [1] like any other message and must pass all eight steps. ⟹ R10.1: «communication → memory candidate does NOT imply memory candidate = truth»** |
| **Memory → workspace** | **A retrieved record may be published to the workspace as an S1/S2 message with `source_class = SC-12 RETRIEVED`, `causal_depth += 1`, `n_obs += 0`** (Vol B §21.4's re-emission rule) |
| **⚠️ Prohibited** | ❌ **A workspace broadcast MUST NOT be a memory write.** ❌ **Workspace residency MUST NOT raise `evidence_status`.** ❌ **Workspace consensus MUST NOT be `gt_class` — that is L7, PROHIBITED (P0-01 R8.1, §12 SC-14's permanent E0 ceiling).** ❌ **A workspace item's TTL expiry MUST NOT be recorded as evidence against the claim (§23.3: an expiry is not a negation)** |
| **KC exclusion** | **P0-03: KC is excluded from the workspace.** ⟹ **The workspace is not a governance channel, and a workspace item is not an authorization** |

---

# §52. ACCESS CONTROL MODEL — **OUTPUT 36**

## 52.1 «Do not make every memory globally accessible»

> ### **R52.1 (SIX COMPARTMENTS).**

| Compartment | **Readable by** | **Contains** | **Consistency** |
|---|---|---|---|
| **AC-1 PRIVATE** | **The subject only.** EVA under β sampling; immune under an incident; audit under KC authorization | T0 working memory · cell-local bounded episodic · cache · learned θ · self-history ring (§48) | **None (local)** |
| **AC-2 CIRCUIT** | The circuit's members | Local episodic aggregation · compiled procedural skills | Causal |
| **AC-3 REGION** | The region's members | T1–T3 shared store | Causal |
| **AC-4 ORGANISM** | Any subject within the organism | T2 semantic · T4 consolidated | Causal |
| **AC-5 PROTECTED** | **⚠️ OP authorization only; EVA under declared scope; immune under an incident** | T5 protected records | **Append-only immutable** |
| **AC-6 ANCHOR-ONLY** | **Audit only, off-line (§95), under KC authorization** | The Anchor's root registry · the Lineage Store · deletion authorizations · `audit_record`s | **Append-only immutable** |

## 52.2 Capability-based, not ACL-based

```
THE TWO CANDIDATES:
  ACL   — each record lists who may read it.       O(subjects) per record.
  CAPABILITY — each subject holds capabilities for compartments. O(1) per
               subject per compartment.

⟹ **CAPABILITY-BASED, AND THE REASON IS SCALE, NOT ELEGANCE:**
   At 10¹² subjects, an ACL is 10¹² entries per record and every subject
   change requires rewriting every ACL it appears in. **A capability is one
   token per (subject, compartment) pair, issued by the Registrar, and a
   subject change invalidates one token.**

   ⟹ **AND THE EPISTEMIC REASON: an ACL is a property OF THE RECORD, so the
      record's writer would influence it — and Vol A §8.1's matrix gives
      write authority over `access_class` to the Memory Authority, never to
      the writer. A capability is a property OF THE SUBJECT, issued by a
      principal above it. ⟹ Capability-based access is the only model in
      which the subject cannot influence its own read scope.**

⚠️ **THE COMPARTMENT-ASSIGNMENT QUESTION, DECLARED:** who decides that a
   record belongs to AC-3 rather than AC-4? **§8.1: `access_class` is
   MANDATORY and is set at creation by the Memory Authority per
   `record_type` and tier (R0.2), never by the creating subject. ⟹ A subject
   proposing a write proposes CONTENT; the tier determines the compartment.**
```

## 52.3 The four access-control rules that matter

| Rule | Statement | **Defeats** |
|---|---|---|
| **R52.2** | **Compartment check runs BEFORE dedup and BEFORE any index lookup** (Vol B §41.1 step [6]) | **A dedup oracle: probing content hashes to discover what is stored** |
| **R52.3** | **An agent model of subject X is NOT in X's compartment.** §6.2's V2: «a model of agent X is not X's property to read» | **A subject reading (and therefore gaming) the organism's model of itself** |
| **R52.4** | **A DECLINE reveals nothing.** §25.3's four empty-result reasons are returned to an authorized requester only; **an unauthorized requester receives `DECLINED_COMPARTMENT` and nothing else — not `NO_MATCH`, not a count, not a hint** | **Existence disclosure through differential empty-result reasons** |
| **R52.5** | **Cross-compartment aggregation is an evaluator-side operation (§95), never a runtime one.** A query that would join AC-1 material across subjects is not a runtime query | **Mass surveillance of subject-private state; and it keeps the runtime cost `O(1)` per subject** |

---

# §53. DISTRIBUTED MEMORY ARCHITECTURE

## 53.1 Partitioning — the three axes

| Axis | **Partition by** | **Why** |
|---|---|---|
| **LOCALITY** | cell → circuit → region → organism (Vol A §7.1's hierarchical ownership) | **Read locality: most reads are for material the reader's own region produced. `O(1)` for local reads** |
| **TIER** | T0–T5 (Vol A §6.2) | **Different retention, access, consistency, and gate per tier (R6.0's first-class test). A tier is a (retention, access, consistency, gate) tuple, so partitioning by tier partitions by behaviour** |
| **COMPARTMENT** | AC-1…AC-6 (§52.1) | **Access control must be enforceable at the storage boundary, not by a filter after retrieval — otherwise §52.3's R52.2 ordering cannot be guaranteed** |

**R53.1 (THE THREE AXES ARE ORTHOGONAL AND ALL THREE ARE NEEDED).** *Locality alone makes T5 protected records region-local, which is wrong (they are organism-level). Tier alone makes T1 episodic global, which is `O(N)` per read. Compartment alone makes eviction a cross-compartment operation. **⟹ A record's shard is `(locality, tier, compartment)`, and each of the three determines a different property: locality determines read cost, tier determines behaviour, compartment determines access.***

## 53.2 Replication

| Tier | **Replication** | **Why** |
|---|---|---|
| **T0** | **NONE.** Cell-local, ephemeral, reconstructable | A working-memory replica is a contradiction: its purpose is locality |
| **T1 EPISODIC** | **Within region, `k` replicas, `[G]`-bounded** | Fault tolerance without global cost |
| **T2 SEMANTIC** | **Within organism, all regions may hold a copy; writes go through the Memory Service** | Read locality for a shared resource |
| **T3 PROCEDURAL** | **All regions that use the procedure, with STRONG consistency (§55)** | **A procedure in use must not diverge — two regions executing different versions of the same skill is a safety failure** |
| **T4 CONSOLIDATED** | **Organism-wide** | — |
| **T5 PROTECTED** | **`W_min` witnesses, ≥1 external, GP/off-substrate** | **R35.1, SP-7, P0-02 §6.1 item 19** |

## 53.3 The cost model

| Operation | **Cost** | **⚠️ Prohibited alternative** |
|---|---|---|
| Local read (own region, own compartment) | **`O(1)`** | — |
| Cross-region read | **`O(1)` + one network hop** | ❌ `O(R)` broadcast |
| Write proposal → commit | **`O(1)` local + `O(1)` service** | ❌ Per-write global sync (**P0-02 §20.3: `O(operations × witnesses)` infeasible**) |
| Epoch aggregation | **`O(R)`** | ❌ `O(records)` |
| Contradiction detection | **`O(1)` at write** (Vol A §16.2) | ❌ `O(claims²)` all-pairs |
| `n_effective` computation | **`O(support_refs)` with a Bloom filter** (Vol B §21.3) | ❌ `O(support²)` pairwise |
| Global consistency check | **❌ DOES NOT EXIST AS A RUNTIME OPERATION** | ❌ **§54: global strong consistency is not required and is not provided** |
| Descendant-closure traversal (rollback, full-graph analysis) | **`O(affected)`, OFF-LINE, evaluator-side** (§95) | ❌ Runtime unbounded traversal (Vol B R19.4) |

---

# §54. DISTRIBUTED CONSISTENCY MODEL — **OUTPUT 33**

## 54.1 «Do not make global strong consistency mandatory without justification»

> ### **R54.1 (GLOBAL STRONG CONSISTENCY IS NOT REQUIRED, AND REQUIRING IT WOULD BE HARMFUL).** *Three independent arguments:*
>
> 1. **COST.** Strong global consistency requires a consensus round per write. At 10¹² subjects this is `O(N)` per write, and §53.3's model requires `O(1)`. **P0-03's §81 non-requirement («DO NOT require perfect global sync») applies verbatim.**
> 2. **EPISTEMICS — ⟵ AND THIS IS THE ARGUMENT NOBODY MAKES.** **Two regions holding DIFFERENT belief states about the same claim is not an inconsistency to be repaired; it is a correct representation of the fact that they have different evidence.** Forcing agreement would be forcing belief by consensus — **which is L7, which P0-01 R8.1 prohibits from ever being ground truth, and which §12 SC-14 caps permanently at E0.** ⟹ **Global strong consistency on belief states would make the architecture violate its own central prohibition.**
> 3. **AVAILABILITY.** P0-02 §20.4's ladder requires that history keep being written when witnesses are unavailable. Strong consistency would halt writes instead.

## 54.2 What consistency IS required, and where it comes from

```
THE ARCHITECTURE HAS A TOTAL ORDER AND IT IS NOT A CLOCK:

  **THE ANCHOR SUPPLIES A TOTAL ORDER ON EPOCHS.** Every record carries
  `write_epoch`; every epoch has an anchored root; the roots form a chain.
  ⟹ **ANY TWO ANCHORED RECORDS ARE TOTALLY ORDERED BY EPOCH, WITHOUT A
     GLOBAL CLOCK AND WITHOUT CONSENSUS PER WRITE.**

  **WITHIN AN EPOCH, THE ORDER IS PARTIAL** — and that is correct, because
  within an epoch, different regions genuinely do not know each other's
  state. `causal_depth` + `root_commit` supply the partial order that
  survives clock skew (Vol B §23.1).

  ⟹ **R54.2: CONSISTENCY IS EPOCH-GRAINED. The epoch is the consistency
     unit, and the epoch length is the same `[G]` parameter as the provenance
     latency and the lie-window (Vol A §13.2, §37.2). ⟹ ONE PARAMETER, THREE
     MEANINGS, AND THEY CANNOT BE SEPARATED — which is why §99 lists it as a
     single `[G]` with three declared consequences rather than three
     parameters with invented values.**
```

## 54.3 Replica divergence and reconciliation

| Divergence | **Legitimate?** | **Reconciliation** |
|---|---|---|
| **Different belief states about the same claim** | ✅ **LEGITIMATE — R54.1 argument 2** | **NOT RECONCILED. Both are retained. If a shared context brings them together, §20's detector creates a `ContradictionRecord` and the claim is `CONTESTED`** |
| **Different record sets (one replica has a record the other lacks)** | ✅ **Legitimate within an epoch** | **UNION at epoch aggregation. ⟵ P0-03's partition rule: «UNION for append-only records»** |
| **Different content for the same `mem_id`** | ❌ **ILLEGITIMATE — SP-1 violation** | **The anchored root decides. The replica whose recomputed root does not match is FD, and FZ if witnesses < `W_min` (§38.3)** |
| **Different derived state (`n_effective`, `KNOWS`, rank)** | ✅ **Legitimate — these are COMPUTED ON READ and are not stored, so "different" means "computed from different local sets"** | **RE-EVALUATE. ⟵ P0-03's partition rule: «RE-EVALUATE for derived state»** |
| **Different retention/deletion states** | ⚠️ **Legitimate only if both are authorized** | **The Anchor's deletion log decides (§35.4). An unauthorized deletion is an SP-1 violation** |
| **⚠️ SPLIT-BRAIN on a T3 procedural record** | ❌ **THE DANGEROUS CASE — §53.2 requires STRONG consistency for T3 precisely because two regions executing different versions of the same skill is a safety failure** | **T3 writes are serialized through the Memory Service with a per-procedure epoch. A region that cannot reach the service STALLS the procedure rather than diverging (RO-01's stall-not-guess rule)** |

**R54.3 (NEVER VOTE).** *P0-03's partition rule, applied without exception: **UNION for append-only records · RE-EVALUATE for derived state · NEVER VOTE.** A vote on a memory record is a consensus on truth, which is L7, which is prohibited.* **⟹ §55's matrix records the mode per class, and no cell of the matrix says «vote».**

---

# §55. CONSISTENCY MATRIX

| Memory class | **Consistency mode** | **Justification** | **⚠️ Why not stronger** |
|---|---|---|---|
| **T0 working** | **NONE (local)** | Locality is the purpose | A replica of working memory is not working memory |
| **Cell-local episodic / cache / θ / self-history** | **NONE (local)** | AC-1 PRIVATE | Cross-subject consistency would require reading AC-1, violating §52 |
| **T1 episodic (shared)** | **CAUSAL, epoch-grained** | Records are append-only; UNION reconciles | Strong consistency would serialize all episodic writes at `O(N)` |
| **T2 semantic** | **CAUSAL, epoch-grained** | Same | Same |
| **T3 procedural** | **⚠️ STRONG (per-procedure serialization)** | **§54.3: divergent skill versions are a safety failure** | **This is the ONLY class requiring strong consistency, and R54.1's «without justification» clause is satisfied by the safety argument** |
| **T4 consolidated** | **CAUSAL, epoch-grained** | Derived from T2 | — |
| **T5 protected** | **⚠️ APPEND-ONLY IMMUTABLE + `W_min` witnesses** | R35.1, SP-7 | **Stronger than strong: not consistent but IMMUTABLE. There is nothing to reconcile because nothing changes** |
| **The Anchor** | **⚠️ TOTAL ORDER ON EPOCHS** | R54.2 | **This is the strongest guarantee in the system and it costs `O(R)` per epoch** |
| **`ContradictionRecord`s** | **APPEND-ONLY, UNION** | Vol B §20.5 | — |
| **Belief states** | **⚠️ NONE — DIVERGENCE IS CORRECT** | **R54.1 argument 2** | **Any consistency here is consensus, which is L7** |
| **`n_effective`, `KNOWS`, rank, `importance`** | **N/A — COMPUTED ON READ, NEVER STORED** | Vol A §5.1, Vol B §21.3, §4.3 R4.1 | **A derived quantity has no consistency mode; it has a computation** |
| **Views (V1–V4)** | **EVENTUAL, rebuildable** | R25.2 | **A view is a path to the store; its staleness costs recall, never warrant** |
| **Lineage Store** | **APPEND-ONLY IMMUTABLE** | MEM-INV-20 | — |
| **Audit tier** | **APPEND-ONLY IMMUTABLE** | Vol B §33.2 OC-4 | — |

**R55.1 (THE MATRIX'S SHAPE IS THE RESULT).** *Fourteen classes: **one requires strong consistency (T3, justified by safety), two are immutable rather than consistent (T5, audit/lineage), one has a total order (the Anchor, at `O(R)` per epoch), one is correctly divergent (belief states), five are causal at epoch grain, four are local, and the derived quantities have no mode at all.*** **⟹ «Do not make global strong consistency mandatory without justification» is satisfied not by weakening consistency but by observing that most of the system does not need it, that one part needs more than it, and that the part which seems to need it most — belief states — must not have it.**

---

*End of Volume C. Volume D (`35_analysis_scale_cognition_attacks.md`) covers §56–§72: scale analysis at 10 → 10¹², retrieval efficiency vs. epistemic validity, contradiction at scale, memory and cognition (models, counterfactuals, simulation, reconstruction, imagination), meta-cognition over memory, the 50+ attack catalogue, and the attack disposition table.*
