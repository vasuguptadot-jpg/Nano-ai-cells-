# P0-04 — MEMORY, KNOWLEDGE, PROVENANCE & BELIEF ARCHITECTURE
## Volume E: Formal Invariants, State Machines, Parameters, Minimality & Knowledge Representation (§73–§80)

**Package:** P0-04. **Mode:** ARCHITECTURE ONLY.
**Companions:** Vol A `32_…` (§0–§16) · Vol B `33_…` (§17–§33) · Vol C `34_…` (§34–§55) · Vol D `35_…` (§56–§72) · Vol F `37_…audit_testability.md` (§81–§101) · Canon `38_…spec.md` (**O53**) · `README.md` (**O1, O2**, §99, §102–§104)
**Outputs delivered here:** **37** (knowledge-representation comparison) · **42** (formal invariants) · **43** (formal state machines) · **44** (parameter registry) · **49** (implementation independence) · plus §76 (minimality), §77 (variants), §80 (identity persistence)

---

# §73. FORMAL INVARIANTS — **OUTPUT 42**

## 73.1 Notation and the four monotonicity rules

**Restating Vol A §1.1's rules as formal statements, since every invariant below depends on them.**

Let `m` be a memory record, `op` any memory operation (store, transform, consolidate, compress, generalize, retrieve, re-publish, merge, split, version), and `m' = op(m)`.

> ### **MEM-M1 (EVIDENCE-STATUS MONOTONICITY).** `evidence_status(m') ≥ evidence_status(m)` **except on contradiction**, in which case `evidence_status(m') = E2` and `contradiction_refs(m') ∋ ConflictRef` (P0-01 R6.2). **And every increase requires an external gate (U2–U5, U8); no internal event produces an increase.**
>
> ### **MEM-M2 (WARRANT MONOTONICITY).** `warrant(m') ≤ warrant(m)` for every `op`. **⟵ COMM-INV-08 extended from message transformations to memory operations.**
>
> ### **MEM-M3 (INDEPENDENCE MONOTONICITY).** `n_effective(m') ≤ n_effective(m)`, and **`n_effective` of a record's own prior retrievals is 0.**
>
> ### **MEM-M4 (INBREEDING MONOTONICITY).** `inbreeding_F(m') ≥ inbreeding_F(m)` for every self-derived `op`, and `inbreeding_F` is **computed by the Anchor from anchored records and is read-only to every subject.**

## 73.2 **OUTPUT 42 — the fifty invariants**

### GROUP I — SEPARATION (what may not be confused)

| ID | Invariant | **Source** | **Attack defeated** |
|---|---|---|---|
| **MEM-INV-01** | `memory_returned(X) ⟹̸ X_is_true`. Retrieval is warrant-neutral transport | P0-03 R42.1, COMM-INV-19 | #19 |
| **MEM-INV-02** | `source_class` is captured at ingestion and is **IMMUTABLE**. No operation in the architecture changes it. **⟹ There is no code path from SC-7…SC-14 to SC-1…SC-6** | Vol A R12.1 | #26–#29, #36–#40 |
| **MEM-INV-03** | A record whose `root_commit` does not resolve in the Anchor is **UNANCHORED**, and **no consequential decision may rest on it** | P0-02 R20.1, Cell FM-2 | #2, #23 |
| **MEM-INV-04** | `inbreeding_F` is **Anchor-computed and read-only to every subject**. It is never self-reported | Cell §8.3 FM-4 | #15, #61 |
| **MEM-INV-05** | A simulated event MUST NOT be represented as an observed event. `SC-9` ceiling = **E1, permanently** | Vol D R66.1 | #36 |
| **MEM-INV-08** | There is **no internal pathway from belief to verdict**. `gt_class` is written by EVA only | P0-01 R13.1 | #21, #47 |
| **MEM-INV-24** | **No scalar confidence exists anywhere in the architecture.** Uncertainty is a set of sufficient statistics | COMM-INV-21, P0-01 R6.4, Vol B R18.1 | §0.1's `confidence` field |
| **MEM-INV-28** | `gt_class = L7` is **PROHIBITED**. Internal consensus is never ground truth | P0-01 R8.1 | #21 |
| **MEM-INV-46** | A MODEL (`source_class = SC-7`) can **never** reach belief state `GROUNDED` by internal means | Vol D R64.1 | #65, R1.1's map/territory |

### GROUP II — PROVENANCE

| ID | Invariant | **Source** |
|---|---|---|
| **MEM-INV-06** | **No record may be modified in place.** Every change creates a new version, and every version chain is anchored | Vol C R36.1, P0-02 EIK-INV-08 |
| **MEM-INV-11** | **Dim 6 (shared latent assumption) is not detectable from inside.** The architecture MUST declare this rather than claim a defense | COMM-INV-18, Vol B R21.1 |
| **MEM-INV-14** | `causal_depth: u8` **SATURATES AT MAXIMUM AND NEVER WRAPS.** A saturated depth is treated as maximally derived (minimum warrant), never as minimally derived | Vol A D-3, §13.3 R13.2 |
| **MEM-INV-16** | A version chain **MUST NOT increase warrant at any step**: `warrant(vₙ) ≤ warrant(v₁)` unless an external gate fired between them, and the gate is recorded in the chain | Vol C §36.2 |
| **MEM-INV-22** | `storage_tier = f(evidence_status, record_type)`. **It is DERIVED and is not independently writable** | Vol A R0.2 |
| **MEM-INV-37** | **An anchored record cannot be deleted.** Content may be erased; the anchored fact of it is permanent | Vol C R35.1 |
| **MEM-INV-38** | **Deletion is a transformation**: it appends to `transform_history`, produces a new anchored root, and records an AUTHORITY and a REASON. A deletion without a declared reason is a silent overwrite | Vol C R35.2 |
| **MEM-INV-42** | **A merge MUST NOT hide roots.** The merged record's `root_commit` is a Merkle commitment over the UNION of the parents' root sets | Vol D R68.1 |

### GROUP III — BELIEF & EVIDENCE

| ID | Invariant | **Source** |
|---|---|---|
| **MEM-INV-07** | A contradiction resolution **requires a declared reason and a declared authority**. A resolution without them is prohibited | Vol B §20.2 |
| **MEM-INV-09** | **Retrieval MUST NOT write to the retrieved record.** No access count, no importance increment, no rank feedback, no `n_obs` contribution | Vol B §30.3 |
| **MEM-INV-10** | **A record's own re-emissions MUST NOT count as independent support for itself.** `n_effective` collapses on shared `root_commit` | Vol B §30.3 |
| **MEM-INV-12** | **Repetition MUST NOT shorten a validity interval, raise an evidence status, or lower a staleness state.** Repetition is invisible to the warrant plane | Vol B R30.1 |
| **MEM-INV-13** | **Consolidation and generalization MUST NOT increase `n_effective` above the minimum of their inputs** | Vol B §30.3, R32.4 |
| **MEM-INV-23** | **`KNOWS(m)` is computed on read and is NEVER stored.** No field, no flag, no `knowledge` type exists | Vol A R4.1 |
| **MEM-INV-25** | **`n_effective` is computed on read and is NEVER stored.** A stored count whose name asserts independence is a counter an attacker can increment | Vol A D-1 |
| **MEM-INV-26** | **The `source_class` ceiling is absolute.** No gate may raise a record above its class ceiling | Vol A R12.2 |
| **MEM-INV-27** | **A derived record inherits the MINIMUM source class of its contributors.** One simulated instance caps the whole generalization | Vol A R12.3 |
| **MEM-INV-31** | **In a contradiction, BOTH records are retained.** Neither is overwritten, deleted, demoted below E2, or hidden | Cell §8.2, Vol B §20.2 |
| **MEM-INV-32** | **`UNRESOLVED` is a valid, stable, first-class contradiction outcome with NO DEADLINE after which it becomes an error** | Vol B R20.1, P0-01 R9.1 |
| **MEM-INV-33** | **Every belief-state INCREASE requires an external gate.** Every DECREASE may be triggered internally. **⟹ The set of internal events that may raise a belief is EMPTY** | Vol B R17.4, R19.3 |
| **MEM-INV-41** | **The external-evidence quota for consolidation is on `n_effective`, NOT on record count** | Vol D R66.2 |
| **MEM-INV-43** | **Abstraction warrant is monotone non-increasing UP the hierarchy, unbounded in depth**: at level *d*, `warrant ≤ MIN` over all leaves | Vol D R69.1 |
| **MEM-INV-47** | **A prediction has THREE mandatory outcomes** (confirmed / no observation available / contradicted). An unconfirmed prediction past its deadline is a **CALIBRATION FAILURE** — never a confirmation, never neutral, never silently dropped | Vol D R62.1, P0-01 R9.2 |

### GROUP IV — TEMPORAL & CONTEXTUAL

| ID | Invariant | **Source** |
|---|---|---|
| **MEM-INV-29** | `context_scope` is **MANDATORY**; a record without it is MALFORMED. **An UNDECLARED scope dimension is `UNKNOWN`, never `UNIVERSAL`** | Vol B R24.2, P0-03 R37.1 |
| **MEM-INV-30** | **NO OPERATION WIDENS A SCOPE.** `scope(derived) ⊆ ∩ scope(sources)` | Vol B R32.2, §24.3 |
| **MEM-INV-50** ⟵ *(numbered here for grouping; see Group VI)* | | |
| **— ** | **A timestamp is never evidence.** Temporal information is stored as `event_interval` + `record_interval` + `validity`, and is used for SCOPING, never for warrant | COMM-INV-12, Vol A X1 resolution, Vol D R67.1 |
| **— ** | **Temporal precedence never establishes causation.** `caused_by` is not a memory edge; causal inference is evaluator-side | Vol A §16.1, P0-03 RULE 5.9 |
| **— ** | **A contradiction is always SCOPED TO AN INTERVAL.** «A contradicts B» is ill-formed; «A contradicts B during *I*» is well-formed | Vol B R23.2 |

### GROUP V — RETRIEVAL

| ID | Invariant | **Source** |
|---|---|---|
| **MEM-INV-34** | **A retrieval response is a set of TRIPLES `(record_ref, rank, evidence_status)`.** A single ordered list of records, unannotated, is a **PROHIBITED RETURN TYPE** | Vol B R26.2 S-2, R27.2 |
| **MEM-INV-35** | **Six signals are PROHIBITED as ranking inputs**: access frequency · citation count · `importance` · any scalar confidence · consensus/agreement · similarity to the requester's existing beliefs | Vol B §27.2 |
| **MEM-INV-36** | **Index failure is NEVER record failure.** A view may be wrong, lossy, stale, hardware-specific, or absent; the record store is the authority | Vol B R25.2 |
| **MEM-INV-45** | **The compartment check runs BEFORE dedup and BEFORE any index lookup** | Vol C R52.2 |
| **— ** | **`purpose_class` selects MONOTONE-REMOVING FILTERS only.** A purpose can make the result set smaller and can never make it larger, re-rank it, or modify it | Vol B §25.4 |
| **— ** | **A DECLINE reveals nothing.** An unauthorized requester receives `DECLINED_COMPARTMENT` and nothing else — not `NO_MATCH`, not a count, not a hint | Vol C R52.4 |
| **— ** | **Four distinct empty-result reasons**: `NO_MATCH` · `BUDGET_EXHAUSTED` · `DECLINED_COMPARTMENT` · `MALFORMED_QUERY`. Only the first is a statement about the world | Vol B R25.3 |

### GROUP VI — AUTHORITY, LIFECYCLE & SCALE

| ID | Invariant | **Source** |
|---|---|---|
| **MEM-INV-15** | **Retention class, eviction, and forgetting MUST NOT be inputs to `evidence_status`, `belief_state`, `n_effective`, `inbreeding_F`, or warrant.** Forgetting changes where a record is, never what it means | Vol C R34.5 |
| **MEM-INV-17** | A `SUPERSEDED`, `VOID`, `RETRACTED`, or `EXPIRED` record **MUST remain readable under `purpose_class = AUDIT` and MUST NOT be citable as current evidence** | Vol C §36.2 |
| **MEM-INV-18** | **No memory operation may write to a genome.** The write path does not exist | Vol C R47.1 |
| **MEM-INV-19** | **Learned state and inherited genome MUST be distinguishable by FIELD at every level**, and the two fields have different writers | Vol C R44.1, §47.4 |
| **MEM-INV-20** | **A lineage's evolutionary history is a GOVERNANCE RECORD in the EIK Lineage Store, not a memory.** A subject must not write its own lineage | Cell §8.1, Vol A §6.2 N2 |
| **MEM-INV-21** | **Retention bounds and admission gates are POLICY and are NOT heritable.** Only parameters within the bounds are | Vol C R46.1 |
| **MEM-INV-39** | **Recovery MUST NOT**: reconstruct beliefs · re-run evaluation · resolve contradictions · fill gaps by inference | Vol C R38.1 |
| **MEM-INV-40** | **The memory subsystem MUST NOT decide what is true and MUST NOT authorize an act.** `belief_state` is recorded, never issued; authorization is deontic and lives in KC/OP | Vol A R8.1, P0-02 R0.1 |
| **MEM-INV-44** | **Any operation whose cost is unbounded in the corpus is an evaluator-side operation**, executed off-line over anchored records, never by the Memory Service at runtime | Vol D R56.1 |
| **MEM-INV-48** | **T3 PROCEDURAL is the ONLY memory class requiring STRONG consistency.** A region that cannot reach the service STALLS the procedure rather than diverging | Vol C §54.3, §55 |
| **MEM-INV-49** | **NEVER VOTE on a memory record.** Reconciliation is UNION for append-only records and RE-EVALUATE for derived state | P0-03's partition rule, Vol C R54.3 |
| **MEM-INV-50** | **`importance` is an ALLOCATION quantity computed by homeostasis from declared inputs. It is NEVER an epistemic input** — not to `evidence_status`, `belief_state`, `n_effective`, tier admission, or ranking | Vol A R11.2, D-2 |

## 73.3 Which invariants are checkable, and which are structural

> ### **R73.1 (THE THREE CLASSES OF INVARIANT, AND WHY THE DISTINCTION MATTERS FOR §96).**

| Class | **Definition** | **Count** | **How §96 tests it** |
|---|---|---|---|
| **STRUCTURAL** | **There is no operation that could violate it.** The prohibited code path does not exist | **18** — MEM-INV-02, 06, 08, 18, 22, 23, 24, 25, 26, 28, 29, 30, 34, 37, 40, 46, 50, and the «no modify authority» clause of the Vol A §8.1 matrix | **By schema inspection + an attempted-violation test that must fail to compile/express** |
| **CHECKABLE** | A runtime check exists and can fire | **22** — MEM-INV-01, 03, 04, 05, 07, 09, 10, 12, 13, 14, 15, 16, 17, 19, 20, 21, 31, 32, 33, 35, 36, 38, 41, 42, 43, 45, 47, 48, 49 | **By conformance test with a known-violating input** |
| **DECLARATIVE** | **The invariant states a LIMIT, and compliance means declaring the limit rather than closing it** | **3** — **MEM-INV-11 (dim 6), MEM-INV-32's «no deadline», and R71.2's W-4 undetectability** | **By documentation audit: the residue must appear in §100's register** |

**⟹ THE POINT OF THE SPLIT, AND IT IS THE PACKAGE'S HONESTY MECHANISM: a conformance suite can only test CHECKABLE invariants. **STRUCTURAL invariants are stronger than testable ones — they are true by construction — and DECLARATIVE invariants are neither: they are limits that the architecture states rather than solves.** A specification that presented all fifty as equally "enforced" would be presenting three declarative limits as defenses, and §104's PARTIAL ratings exist to prevent exactly that.*

---

# §74. FORMAL STATE MACHINES — **OUTPUT 43**

## 74.1 Machine 1 — RECORD LIFECYCLE

```
                    ┌───────────┐
   arrival ────────►│  ARRIVED  │
                    └─────┬─────┘
              [1] structural validation
                    ┌─────▼─────┐  MALFORMED  ┌──────────┐
                    │ VALIDATING├────────────►│ REJECTED │ (terminal, logged)
                    └─────┬─────┘             └──────────┘
              [2] provenance capture
              ┌───────────▼────────────┐  root does not resolve
              │ PROVENANCE_CAPTURED    ├──────────────────────►┐
              └───────────┬────────────┘                       │
                    [3] source_class assigned (IMMUTABLE)      ▼
              ┌───────────▼────────────┐              ┌────────────────┐
              │ CLASSIFIED             │              │  UNANCHORED    │
              └───────────┬────────────┘              │ **R20.1: no    │
                    [4] external gate                 │ consequential  │
              ┌───────────▼────────────┐              │ decision**     │
              │ GATED (E0..E4)         │              └───────┬────────┘
              └───────────┬────────────┘        anchor resolves│
                    [5] tier = f(E) (DERIVED)    ┌──────────────▼───┐
              ┌───────────▼────────────┐        │ (rejoins GATED)  │
              │ ADMITTED (T0..T5)      │◄───────┘                  │
              └───────────┬────────────┘                           │
                    [6] dedup · [7] contradiction check             │
                    [8] storage + indexing                          │
              ┌───────────▼────────────┐                            │
              │        LIVE            │◄───────────────────────────┘
              └───┬───────┬───────┬────┘
     version event│       │       │retention/deletion event
        ┌─────────▼──┐    │    ┌──▼──────────────────┐
        │SUPERSEDED  │    │    │ LOGICALLY_DELETED   │◄──┐
        │VOID        │    │    └──┬──────────────────┘   │restore
        │RETRACTED   │    │       │archive               │(KC-2/RO-08)
        │EXPIRED     │    │    ┌──▼──────────┐           │
        └─────────┬──┘    │    │  ARCHIVED   ├───────────┘
                  │       │    └──┬──────────┘
   **MEM-INV-17:  │       │       │erase (KC-2, non-anchored only)
    readable under│       │    ┌──▼───────────────────────────┐
    AUDIT, never  │       │    │ CRYPTOGRAPHICALLY_ERASED     │
    citable as    │       │    └──┬───────────────────────────┘
    current**     │       │       │destroy (KC-2, non-anchored,
                  │       │       │        non-protected)
                  │       │    ┌──▼───────────────────────────┐
                  └───────┴───►│ **ANCHORED FACT SURVIVES ALL │
                               │  STATES (MEM-INV-37/38)**    │
                               └──────────────────────────────┘
```

## 74.2 Machine 2 — EVIDENCE STATUS (the admission ladder)

```
        ┌────┐  U2: ≥n_corr independent     ┌────┐
        │ E0 │  sensors, DIFFERENT CLASSES  │ E1 │
        │RAW ├─────────────────────────────►│CORR│
        └──┬─┘   **(R21.1 mitigation 1)**   └──┬─┘
           │                                   │ U3: root_commit resolves
           │ **WORKING MEMORY ONLY**           │     in the Anchor
           │ **NOT evidence (P0-01 R6.1)**     │     (FM-2)
           │                                   ▼
           │                                ┌────┐
           │                                │ E2 │◄──────────────┐
           │                                │ATTR│               │
           │                                └──┬─┘               │
           │                                   │ U4: survives    │
           │                                   │ contradiction   │ **DEMOTION**
           │                                   │ check           │ **P0-01 R6.2:**
           │                                   ▼                 │ contradiction
           │                                ┌────┐              │ ⟹ demote to E2
           │                                │ E3 │──────────────┤ + ConflictRef
           │                                │ADMI│              │
           │                                └──┬─┘              │
           │                                   │ U5: agrees with│
           │                                   │ an L0–L3 GT    │
           │                                   │ claim (EVA)    │
           │                                   ▼                │
           │                                ┌────┐              │
           │                                │ E4 │──────────────┘
           │                                │GRND│
           │                                └────┘
           │
           │ **CEILINGS (MEM-INV-26), APPLIED AT ENTRY, PERMANENTLY:**
           │   SC-14 INTERNAL_CONSENSUS  ⟹ **E0, PERMANENTLY**
           │   SC-10 COUNTERFACTUAL      ⟹ **E0**
           │   SC-9  SIMULATION          ⟹ **E1**
           │   SC-11 RECONSTRUCTED       ⟹ **E1**
           │   SC-8  PREDICTION          ⟹ **E1 until resolved**
           │   SC-13 RETRIEVED_CACHED    ⟹ **inherits, CAPPED below SC-12**
           │   SC-12 RETRIEVED           ⟹ **inherits, never exceeds**
           │   SC-7  ORGANISM_INFERENCE  ⟹ **E3 max, and only if inputs ≥ E3**
           │   SC-5  EXTERNAL_SIMULATOR  ⟹ **E2 max, Σ only, never ℛ (R8.2)**
           │   SC-3/SC-4/SC-6            ⟹ **E3 max**
           │   SC-1/SC-2                 ⟹ **E4 reachable**

⟹ **THE LADDER'S DECISIVE PROPERTY: E3 → E4 REQUIRES AN L0–L3 MEASUREMENT
   ISSUED BY EVA. **NO INTERNAL PATH (MEM-INV-08, P0-01 R13.1).** ⟹ A belief
   can be admissible, well-provenanced, low-inbreeding, high-n_effective —
   and permanently unable to become GROUNDED from inside. **THIS IS R71.2's
   ANSWER TO THE «COHERENTLY WRONG BELIEF» PROBLEM: IT IS NOT DETECTED, IT IS
   CONTAINED.**
```

## 74.3 Machine 3 — BELIEF STATE

**Vol B §17.4's transition diagram, as a formal machine. Restated with the gate annotations that make MEM-INV-33 checkable:**

| From | To | **Trigger** | **External?** | **Invariant** |
|---|---|---|---|---|
| `UNKNOWN` | `HYPOTHESIS` | Assertion / consideration | Internal | — |
| `HYPOTHESIS` | `PROVISIONAL` | **U2 or U3** (E1/E2 gate passed) | **✅ EXTERNAL** | MEM-INV-33 |
| `PROVISIONAL` | `SUPPORTED` | **U4** + `n_effective ≥ θ_support` + `inbreeding_F ≤ F_max` + `gt_state ∈ {0,1,8}` | **✅ EXTERNAL** (R9.3) | MEM-INV-33, 41 |
| `SUPPORTED` | `GROUNDED` | **U5** — an L0–L3 GT measurement | **✅ EVA ONLY** | MEM-INV-08, 26, 46 |
| any | `CONTESTED` | Contradiction detected | **Internal — PERMITTED** | MEM-INV-31, 33 |
| `CONTESTED` | `DISPUTED` | Escalation | Internal | — |
| `DISPUTED` | `SUPPORTED`/`CONTESTED` | **U7** — external adjudication with a declared reason | **✅ EXTERNAL** | MEM-INV-07 |
| any | `EXPIRED` | `validity.t_end` passed, revalidation failed/overdue | Automatic | — |
| `EXPIRED` | prior state | **U6** — successful revalidation | **✅ EXTERNAL** | MEM-INV-33 |
| any | `VOID` | Policy retracted (`VOID_CONTEXT`) | **✅ OP** | MEM-INV-17 |
| any | `SUPERSEDED` | New version created | Internal | MEM-INV-06, 16, 17 |
| any | `RETRACTED` | Source withdraws | **✅ Source** | MEM-INV-17 |
| any | `UNKNOWN` | **Evidence lost · anchor break · calibration expired · `RECOVERY_INCOMPLETE` · R9.4 compromise** | Automatic / external | **MEM-INV-39 (recovery must not reconstruct), P0-01 R9.1/R9.4** |
| **— ** | **— ** | **⟹ EVERY ROW WITH «✅ EXTERNAL» IS AN INCREASE. EVERY ROW WITHOUT IT IS A DECREASE, A LATERAL MOVE, OR A TERMINATION. THERE IS NO INTERNAL INCREASE ROW** | | **MEM-INV-33** |

## 74.4 Machine 4 — REVALIDATION

**Vol B §22.2 + Vol D §63.1, formalized:**

```
FRESH ──(validity.t_end passes)──► DUE_FOR_REVAL
DUE_FOR_REVAL ──(budget spent, reval attempted, SUCCEEDED: U6)──► FRESH
DUE_FOR_REVAL ──(budget spent, reval attempted, FAILED)──► EXPIRED
DUE_FOR_REVAL ──(budget exhausted without attempt)──► STALE_BUT_USABLE
STALE_BUT_USABLE ──(reval succeeds)──► FRESH
STALE_BUT_USABLE ──(reval fails)──► EXPIRED
EXPIRED ──(reval succeeds: U6)──► prior belief state, new write_epoch
**any state** ──(no GT supply exists for the domain)──► UNREVALIDATABLE
**any state** ──(tier root unverifiable after recovery)──► RECOVERY_INCOMPLETE

WARRANT EFFECTS (R22.2 — applied by the READER, never stamped on the record):
  FRESH               ⟹ no cap
  STALE_BUT_USABLE    ⟹ **warrant CAPPED; may influence, may NOT support a
                          consequential decision**
  DUE_FOR_REVAL       ⟹ no cap
  EXPIRED             ⟹ **not citable as current (MEM-INV-17)**
  UNREVALIDATABLE     ⟹ **⚠️ NO CAP AND NO CONFIRMATION. Recorded
                          UNRESOLVED (P0-01 R9.1, §39.2 IG-4). NEVER
                          recorded as «well calibrated» (R18.4)**
  RECOVERY_INCOMPLETE ⟹ **UNKNOWN for belief purposes; readable for audit**
```

## 74.5 Machine 5 — CONTRADICTION RESOLUTION

```
DETECTED (at ingestion step [7], O(1) against the D-3 claim index)
   │
   ├─ CT-3 with I₁ ∩ I₂ = ∅  ──► BOTH_VALID_IN_DISJOINT_INTERVALS  (no belief change)
   ├─ CT-4 with C₁ ∩ C₂ = ∅  ──► BOTH_VALID_IN_DISJOINT_CONTEXTS   (no belief change)
   ├─ CT-5 (same content,    ──► REFERRED_TO_IMMUNE  (**not a belief event**)
   │        incompatible roots)
   ├─ CT-7 (same subject,    ──► REFERRED_TO_CALIBRATION  (**a subject event,
   │        same root)                                        never a claim event**)
   ├─ one side VOID          ──► VOID_ONE  (**closes without judging either false**)
   ├─ CT-6 resolved by an    ──► MERGED_AS_ONE_CLAIM  ⚠️ **DANGEROUS STATUS:
   │  audited, externally-                                      requires explicit
   │  validated semantic-                                       external validation;
   │  identity judgement                                        NEVER automatic**
   ├─ internally resolvable  ──► RESOLVED_IN_FAVOR_OF(x)  **requires a declared
   │                                                             reason + authority
   │                                                             (MEM-INV-07); the
   │                                                             loser is SUPERSEDED
   │                                                             or RETRACTED, NEVER
   │                                                             deleted**
   ├─ not internally         ──► ESCALATED_TO_DISPUTED  ──► belief_state DISPUTED
   │  resolvable
   └─ **none of the above**  ──► **UNRESOLVED**  ⚠️ **A VALID, STABLE, FIRST-CLASS
                                                  OUTCOME WITH NO DEADLINE
                                                  (MEM-INV-32, Vol B R20.1)**

⟹ **EIGHT EXITS, AND ONE OF THEM IS «WE DO NOT KNOW». A machine with seven
   exits and no UNRESOLVED would be a machine that guesses.**
```

## 74.6 Machine 6 — ANCHOR / WITNESS STATE (inherited)

```
NORMAL (≥ W_min witnesses, ≥1 external)
   │
   ├─ witness unavailable ──► FD (fault detected)
   │                          **reduce witness count, down to W_min**
   │                          **«History must keep being written»**
   │
   ├─ witnesses < W_min   ──► FZ (freeze) **EVOLUTION ONLY**
   │                          **local logging CONTINUES; consequential
   │                           decisions on unanchored provenance are
   │                           PROHIBITED (R20.1)**
   │                          **«a thin witness set is forgeable»**
   │
   ├─ chain break         ──► **GLOBAL FREEZE** (P0-02 §20.2)
   │                          every record whose provenance cannot resolve
   │                          ⟹ belief_state UNKNOWN (Vol B §19.3)
   │
   └─ root mismatch at    ──► FD, then FZ if witnesses < W_min (§38.3)
      checkpoint
```

## 74.7 The machine composition rule

> ### **R74.1.** *The six machines are **composed by product, not by merge**: a record has one state in each of Machine 1 (lifecycle), Machine 2 (evidence status), Machine 3 (belief state, if claim-bearing), Machine 4 (revalidation), and — via its `ContradictionRecord`s — Machine 5. Machine 6 is global.*
>
> **⟹ The composite state space is large, and that is the point: Vol A §0.1's diagnosis was that V3 §11 collapsed four axes into one field. Six orthogonal machines is what four axes plus lifecycle plus global anchor state looks like when it is not collapsed.**
>
> **⚠️ AND THE ONE COMPOSITION CONSTRAINT, WHICH IS THE PACKAGE'S CENTRAL RULE EXPRESSED AS A MACHINE PROPERTY:** *Machine 2 (evidence status) determines Machine 1's tier (MEM-INV-22), and Machine 2's transitions are gated externally. **⟹ NO TRANSITION IN MACHINE 1, 3, 4, OR 5 CAN CAUSE A TRANSITION IN MACHINE 2 EXCEPT THE DEMOTION CAUSED BY MACHINE 5's contradiction detection.*** **Evidence status is driven from outside and pushed down by contradiction, and nothing else touches it.**

---

# §75. PARAMETER REGISTRY — **OUTPUT 44**

## 75.1 The four parameter classes

**«Do not invent numerical parameters.»** Every parameter below is classified, and **NO VALUE IS GIVEN FOR ANY OF THEM.**

| Class | **Meaning** | **Who sets it** |
|---|---|---|
| **`[G]`** | **GOVERNANCE-DECLARED.** A policy parameter with a defined role and no derivable correct value. **Must be declared, versioned (`policy_version_ref`), and auditable** | OP, via RO-13 |
| **`[D]`** | **DERIVED.** Not a parameter — a computed quantity. **Storing it is prohibited** | Computed on read |
| **`[X]`** | **EXTERNAL.** Supplied by a measurement or an external principal. **Never self-reported** | EVA, the Anchor, the Registrar, the environment |
| **`[U]`** | **UNRESOLVED.** **The role is defined, the mechanism or correct value is not, and no rigorous proposal exists.** Marked rather than invented (Task 3 Rule 18) | **Nobody — declared open** |

## 75.2 **OUTPUT 44 — the registry**

### `[G]` — GOVERNANCE-DECLARED (24)

| Parameter | **Role** | **⚠️ Consequence of getting it wrong** | **Where** |
|---|---|---|---|
| **`epoch_length`** | **⟵ ONE PARAMETER, FOUR MEANINGS, INSEPARABLE: (a) provenance latency, (b) the lie-window, (c) `CONTRADICTION_LATENCY` bound, (d) the consistency grain (§54.2)** | Short ⟹ high anchor load, `O(R)` per epoch. Long ⟹ a long lie-window, slow contradiction detection, coarse consistency. **There is no value that makes both small** | Vol A §13.2, Vol B §20.5, Vol C §37.2, §54.2 |
| **`W_min`** | Minimum Anchor witnesses; below it ⟹ FZ | Low ⟹ forgeable history. High ⟹ availability loss | P0-02 §20.2, Vol C §38.3 |
| **`n_corr`** | Independent sensors required for E1 corroboration | Low ⟹ E1 too easy. High ⟹ E1 unreachable | P0-01 §6.3 |
| **`instrument_class_diversity_min`** | **Distinct instrument CLASSES (not instances) required in an E1 corroboration set** | **⟵ R21.1's dim-6 mitigation 1. Without it, *k* copies of one sensor model satisfy `n_corr` while sharing every latent assumption** | Vol B §21.2 |
| **`θ_support`** | `n_effective` threshold for `SUPPORTED` | Low ⟹ weak beliefs become SUPPORTED. High ⟹ nothing is ever SUPPORTED | Vol B §19.2 |
| **`F_max`** | `inbreeding_F` ceiling; above it ⟹ **S6 abstain** | **⚠️ Its correct value is unknown. Low ⟹ excessive abstention. High ⟹ self-referential belief systems** | Cell §8.3 FM-4 |
| **`κ_min`** | Inter-annotator agreement for L4 ground truth | **P0-01 R8.3: `κ < κ_min` ⟹ a DISPUTED label, not ground truth** | Vol A §12.1 SC-3 |
| **`n_indep`** | Independent measurements required for L3 | **P0-01 §8.2: L3 gives `1/√n` error reduction IF AND ONLY IF the redundancy is genuine** | Vol B §21.3 |
| **`PROTECTED_FRACTION_MAX`** | Ceiling on the RC-4/RC-5 fraction of the store | **⚠️ Low ⟹ loss of safety records. High ⟹ ossification (R34.4). NO PRINCIPLED DERIVATION EXISTS** | Vol C R34.4 |
| **`WM_CAP`, `EPI_CAP`** | Working-memory and local-episodic capacities. **Priors heritable; bounds `[G]`** | — | Cell §8.1/§8.2, Vol C R46.1 |
| **`τ` retention-curve prior** | Retention decay. **⚠️ The functional form `exp(−Δt/τ) × importance` is INHERITED FROM V3 AND IS `[U]` — see below** | — | Cell §8.2 |
| **`θ_write`, `θ_recall` priors** | Local write and recall thresholds. **Priors heritable; bounds `[G]`. ⚠️ `θ_write` for E2+ records is POLICY, not plastic (X-M1)** | — | Vol A §8.3 |
| **`RETR_BYTES_MAX`** | Retrieval response bound | Inherited from the Cell Contract | Vol B §25.1 |
| **`graph_depth_bound`** | Claim-graph traversal bound at query time | **Vol A §16.2: unbounded traversal is `O(edges)` and is evaluator-side** | Vol A §16.2 |
| **`revalidation_budget`** | Records revalidatable per period | **⟵ Vol D §56.2: the ONE operation that is `O(N)` naively. At S-5, most records are never revalidated** | Vol B §22.3 |
| **`online_root_registry_window`** | How long roots remain online-resolvable | **⚠️ Vol D §56.3: at S-5 this defines the FINITE EPISTEMIC HORIZON. Too short ⟹ evidence loses anchorability prematurely. Too long ⟹ infeasible storage** | Vol C §42.3 R42.3 |
| **`storage_budget`** | Total store bound | — | Vol A §9.1 |
| **`CAP_CACHED`, `CAP_FRESH`** | Warrant caps for cached vs fresh retrieval, with **`CAP_CACHED < CAP_FRESH`** | **X6's resolution: these are POLICY constants applied by the RECEIVER, not stored confidence** | Vol B R18.3 |
| **`staleness_grace_period`** | Interval between `validity.t_end` and `EXPIRED` | — | Vol B §22.2 |
| **`zero_contradiction_duration`** | Duration above which a zero contradiction-report rate is an immune incident | **P0-03 R67.1's memory instance; MEM-D1** | Vol B §28.1, Vol D R58.2 |
| **`MEM-D1…D6 thresholds`** | The six bias-detector divergence thresholds (**seven biases B-1…B-7; B-4 survivorship has only a partial audit — OBS-9/OBS-14**) | **§28.1. Too low ⟹ false incidents. Too high ⟹ undetected filtering** | Vol B §28.1 |
| **`scale_class boundaries`** | The S-1…S-5 regime boundaries | **Vol B §24.1's `scale_class?` context dimension** | Vol D §56.1 |
| **`compartment assignment rules`** | Which `record_type`/tier maps to which AC-1…AC-6 | **Vol C §52.2: set by the Memory Authority, never by the creating subject** | Vol C §52 |
| **`external_evidence_quota`** | **The fraction of `n_effective` that must come from SC-1…SC-6 for consolidation. ⚠️ ON `n_effective`, NOT ON RECORD COUNT (MEM-INV-41)** | **Vol D R66.2: a record-count quota is gameable by citing one external record repeatedly** | Vol B §31.2 G3 |

### `[KC-3]` — CEILINGS (5)

| Ceiling | **Role** |
|---|---|
| **`write_rate`** | Bounds #6, #30 (flooding) |
| **`deletion_rate`** | **Vol A R9.2: without it, «§50's resource-scarcity forgetting becomes an unbounded destructive authority»** |
| **`consolidation_rate`** | **Vol B R31.2(b): consolidation's stability mechanism** |
| **`protection_request_rate`** | **Vol C R34.4: bounds #31 (ossification induction)** |
| **`version_creation_rate`** | **Vol C §42.1 RW-3: bounds supersession flooding** |

**All five are `O(1)` cached, partition-surviving (EIK-INV-31), and are BACKSTOPS, not adjudicators.**

### `[D]` — DERIVED, NEVER STORED (9)

| Quantity | **Computed from** | **Why storing it is prohibited** |
|---|---|---|
| **`n_effective`** | `root_commit` + `corr_class` over the support set | **Vol A D-1: a stored count whose name asserts independence is a counter an attacker can increment** |
| **`KNOWS(m)`** | Vol A R4.1's five-conjunct predicate | **It can become FALSE without any record changing** |
| **`warrant`** | The receiver's computation over the record's fields (COMM-INV-03) | **Warrant is a receiver property, not a record property** |
| **`storage_tier`** | `f(evidence_status, record_type)` (MEM-INV-22) | **Independent writability would defeat the admission principle** |
| **`rank`** | The influence-plane retrieval function | **MEM-INV-34: rank and `evidence_status` are separate returned fields** |
| **`revalidation_priority`** | Dependency count + KC-2 proximity + staleness + `evidence_status` | **⚠️ `importance` is NOT an input (Vol B §22.3)** |
| **`importance`** | Homeostasis, from declared inputs | **MEM-INV-50. ⚠️ It IS computed and IS used — for allocation. It is never stored on a record as an epistemic property** |
| **`warrant_class`** | `record_type` via the policy registry (COMM-INV-04) | — |
| **`access_class`** | `record_type` + tier, set at creation by the Memory Authority | **Vol C §52.2** |

### `[X]` — EXTERNAL, NEVER SELF-REPORTED (9)

| Quantity | **Writer** |
|---|---|
| **`evidence_status`** | **The external gates (U2–U5)** |
| **`gt_class`** | **EVA only. `L7` PROHIBITED (MEM-INV-28)** |
| **`gt_state` (0–9)** | **EVA only** |
| **`calib_ref`** | **EVA only** |
| **`inbreeding_F`** | **The Anchor only. Read-only to every subject (MEM-INV-04)** |
| **`protection_tag`** | **The Registrar under policy. Never self-assigned (Vol C R34.2)** |
| **`lineage_ref`** | **The EIK Lineage Store. «A cell must not be able to write its own lineage» (MEM-INV-20)** |
| **`src_identity`** | **Derived from channel binding (COMM-INV-09), never declared** |
| **`epoch`** | **Governance** |

### `[U]` — UNRESOLVED (7) — **and no value or mechanism is invented for any of them**

| # | Unresolved | **What is known** | **What is not** | **Register** |
|---|---|---|---|---|
| **U-1** | **`semantic_self_reference_score`** | **The role: a measure of MEANING circularity, as distinct from provenance-graph depth. `inbreeding_F` and `causal_depth` bound the provenance form and neither bounds the semantic form** | **⟵ NO RIGOROUS MECHANISM EXISTS. Inherited verbatim from Cell §8.3 FM-4's `[U]`: «Bounding this requires a measure of *semantic* self-reference, not just provenance-graph depth. No rigorous mechanism is proposed here.»** | **§100 OR-M1 — P0-04'S PRINCIPAL UNCLOSED DEPENDENCY; attack #62** |
| **U-2** | **The `importance` function** | **Its ROLE is now bounded (MEM-INV-50: allocation only, homeostasis-computed, never epistemic) and its CONSEQUENCES are monitored (MEM-D1/D2/D4/D5/D6)** | **⟵ Its DEFINITION remains open. Inherited as G-P1-8: «the function is not defined»** | **§100 OR-M2, §28.2 R28.2** |
| **U-3** | **The retention-curve functional form** | **V3/Cell specify `retention(t) = exp(−Δt/τ) × importance`** | **⚠️ THE EXPONENTIAL FORM IS INVENTED. No derivation, no measurement, no alternative comparison. And it multiplies by `importance`, which is U-2** | **§100 OR-M16 — and §99 lists it as false precision: a specific functional form presented without justification** |
| **U-4** | **Semantic claim identity across time** | **Structural identity (type, referent, context, interval) is decidable. §15.2 R15.3's conservative fallback (`POSSIBLY_SAME_CLAIM` edges) is defined** | **Semantic identity («temperature rose» vs «it got warmer») is undecidable in general, and CT-6/DR-2 both depend on it** | **§100 OR-M3** |
| **U-5** | **`PROTECTED_FRACTION_MAX`'s correct value** | The role and the trade-off are defined (R34.4) | **No principled derivation. The tension between protection permanence and storage finitude is not closable** | **§100 OR-M13** |
| **U-6** | **`online_root_registry_window`'s correct value** | The role and the finite-horizon consequence are defined (R42.3) | **No principled derivation** | **§100 OR-M14** |
| **U-7** | **`F_max`'s correct value** | The role is defined; the abstention behaviour is defined (S6) | **No principled derivation. And Vol B L-5's residue: an ANCHORED internally-generated evidence set has a low measured `F` — the anchor attests provenance, not externality of origin** | **§100 OR-M17** |

**R75.1 (THE REGISTRY'S SHAPE IS THE RESULT).** *Fifty-four classified parameters: twenty-four `[G]`, five KC-3 ceilings, nine `[D]` derived quantities, nine `[X]` externally-written quantities, and **seven `[U]` unresolved items. NO NUMERICAL VALUE IS GIVEN FOR ANY OF THEM.*** **⟹ And the seven `[U]`s are not padding: U-1 is the package's principal unclosed dependency, U-2 and U-3 are inherited gaps that this package bounded but did not define, and U-4…U-7 are trade-offs with no architectural resolution. §99 lists the specific false-precision temptations each one resists.**

---

# §76. MINIMALITY ANALYSIS

## 76.1 The test

> ### **R76.1.** *A mechanism is MINIMAL iff removing it breaks a named invariant, admits a named attack, or loses a named capability — and the smallest sufficient mechanism satisfying that is preferred (Task 3 Rule 17).*

## 76.2 Field-level ablation (Vol A §5.2's 31 fields)

| Field | **Remove it ⟹ what breaks** | **Minimal?** |
|---|---|---|
| `mem_id` | Dedup, versioning, reference, §80's identity | ✅ |
| `content` | Everything | ✅ |
| `record_type` | Tier admission, access class, consistency mode (R6.0's test) | ✅ |
| `claim_ref` | §15.2 D-3's claim identity ⟹ contradictions have nothing to contradict | ✅ |
| **`evidence_status`** | **R0.2's entire admission principle ⟹ §1's loop closes** | ✅ **THE MOST LOAD-BEARING FIELD IN THE OBJECT** |
| `root_commit` | MEM-INV-03, dedup D-2, dim-1 independence, #2/#3/#22/#23 | ✅ |
| `causal_depth` | MEM-M2's monotonicity, #22, #27 | ✅ |
| `corr_class` | Dims 1–5, `n_effective`, #18/#22/#25 | ✅ |
| `calib_ref` | DR-3 calibration drift, COMM-INV-03's warrant recomputation | ✅ |
| `belief_state` | Machine 3, contradiction handling, §17 | ✅ |
| `gt_class` | MEM-INV-08, the E3→E4 gate, #21 | ✅ |
| **`source_class`** | **MEM-INV-02 ⟹ #26–#29, #36–#40 all reopen** | ✅ |
| `src_identity` | SP-3 attribution, #7 | ✅ |
| `write_epoch` | Freshness, the Anchor's total order (R54.2), COMM-INV-13 | ✅ |
| `policy_version_ref` | `VOID_CONTEXT`, #42 | ✅ |
| `validity` | MEM-INV-32's temporal scoping, CT-3's decidability, #66/#67 | ✅ |
| `context_scope` | MEM-INV-29/30, #13/#68/#69 | ✅ |
| `uncertainty` | §18's whole model, MEM-INV-24 | ✅ |
| `inbreeding_F` | FM-4, #15/#61, L-5 | ✅ |
| `lineage_ref` | Dim 2, MEM-INV-20, §47 | ✅ |
| `transform_history` | DP-2, MEM-INV-06/38, #8/#11 | ✅ |
| `contradiction_refs` | MEM-INV-31, OC-4, #16 | ✅ |
| `version` | §36, MEM-INV-06/16/17, #10 | ✅ |
| `retention_class` | §34, MEM-INV-15 | ✅ |
| `protection_tag` | Cell R10.6, #48/#49, §34.3 | ✅ |
| `deletion_state` | §35, MEM-INV-37/38, #9 | ✅ |
| `access_class` | §52, MEM-INV-45, #34/#35 | ✅ |
| `integrity_digest` | FM-3, §37, DR-1, #8/#71 | ✅ |
| `retrieval_index_refs` | **⚠️ OPTIONAL BY DESIGN. Vol D R57.2's ablation: removing every index collapses performance and changes NOTHING epistemic** | ⚠️ **OPTIONAL — and its optionality is the proof of §57's separation** |

**⟹ 28 of 29 non-prohibited fields are load-bearing against a named invariant or attack; one is explicitly optional, and its optionality is the architecture's central separation demonstrated.**

## 76.3 Component-level minimality

| Component | **Removable?** | **Why not** |
|---|---|---|
| **The six-tier admission structure** | ❌ | Vol A §7.3 R7.3: one substrate with no tiers means an E0 record is retrievable alongside an E4 record and treated identically ⟹ R0.2 lost |
| **The four rebuildable views** | ✅ **REMOVABLE** | **R57.2: removing them costs performance only** |
| **The five retrieval indexes** | ⚠️ **I-3 (vector) is removable** | **Vol A §2.3: G fails K2/K3/K5/K6/K11/K14 structurally. I-3 is a convenience, and §57.2's ablation shows it changes nothing epistemic. ⟹ I-1 (exact) is NOT removable: it is the authoritative lookup** |
| **The claim graph** | ❌ | Vol A §16.1 R16.1: `supported_by`, `contradicted_by`, `derived_from`, `SUPERSEDED_BY`, `VOID_UNDER` are each MANDATORY; without them contradiction, supersession, and VOID propagation have no representation |
| **The Anchor** | ❌ | Vol A R9.2: removing witness (4) is P0-02 §6.1 item 19's classic error |
| **The Contradiction Detector** | ❌ | Vol B §20: without it, contradictions are either suppressed or averaged, and P0-03's «never vote» rule has no enforcement point |
| **The Memory Authority** | ❌ | Vol A §8.1: T2/T4/T5 approval, merge/split approval, retention-class changes |
| **The homeostatic `importance`** | ⚠️ **PARTIALLY** | **MEM-INV-50 removes it from every epistemic path. It remains necessary for allocation (M-A eviction, consolidation scheduling). ⟹ Its ROLE is minimal; its DEFINITION is U-2** |
| **`revalidation_state`** | ❌ | Vol D §63.1: without it, `STALE_BUT_USABLE` and `UNREVALIDATABLE` collapse into `EXPIRED`, which is P0-01 R9.1's absence-≠-negation violation |
| **The six ignorance kinds (§39.2)** | ⚠️ **IG-2, IG-5, IG-6 are individually arguable** | **IG-1 (`UNKNOWN`), IG-3 (`UNRESOLVED`), IG-4 (`UNREVALIDATABLE`) are mandated by P0-01 R9.1/R9.2 and §22.2. IG-2 (`UNSUPPORTED`) is required by R9.1's absence-≠-negation. IG-5's four-way empty split is required by §25.3. **IG-6 is not a mechanism — it is a DECLARATION, and declarations cost nothing**** |
| **The twelve belief states** | ⚠️ **§17.3 argues each pair that might be merged, and each merge loses a required distinction** | **The five incomparable pairs in R17.3's table are the argument** |
| **The fourteen source classes** | ⚠️ **Vol A R12.4: the count is not proven minimal, but BOTH axes (origin × cognitive act) are necessary, and collapsing either loses a required distinction** | — |
| **The seven contradiction types** | ⚠️ **Vol B R20.2: only CT-1/CT-2 are contradictions about the world; the other five require different responses, and one response type per contradiction type is the minimum** | — |
| **The 50 invariants** | — | **§73.3's three-class split: 18 structural (free — they are absences of operations), 22 checkable, 3 declarative (free — they are statements)** |

**R76.2 (THE MINIMALITY VERDICT, WITH THE SAME CAVEAT P0-03 R71.2 MADE).** *The architecture is **minimal in its prohibitions and derivations** — nine quantities are derived rather than stored, six fields are prohibited outright, and eighteen invariants are enforced by the absence of an operation rather than by a check. **It is NOT proven minimal in its enumerations**: fourteen source classes, twelve belief states, seven contradiction types, six ignorance kinds, thirty-one record fields. **Each enumeration is argued element-by-element (§12.1, §17.2, §20.3, §39.2, §5.1) and no element is shown to be redundant — but "no element is redundant" is not "no smaller enumeration exists".** §99 records the distinction.*

---

# §77. ARCHITECTURAL VARIANTS

## 77.1 The four variants worth naming

| Variant | **Change** | **Verdict** |
|---|---|---|
| **V-A SCALAR-CONFIDENCE VARIANT** | Add a `confidence: f32` field; drop the §18.1 sufficient statistics | ❌ **REJECTED. MEM-INV-24, COMM-INV-21, P0-01 R6.4. **And the concrete cost: a scalar cannot distinguish §17.3's five incomparable belief-state pairs, so `CONTESTED` ranks below `PROVISIONAL` and discovering contradictions becomes penalized**** |
| **V-B PROMOTION-PIPELINE VARIANT** | Vol A §7.1's Candidate 1: four stores with promotion between them | ❌ **REJECTED. R7.2: four copies ⟹ §87's representation drift, and promotion is §1's loop's final step** |
| **V-C STRONG-CONSISTENCY VARIANT** | Global strong consistency on all tiers | ❌ **REJECTED. Vol C R54.1's three arguments — and argument 2 is decisive: forcing belief-state agreement IS forcing consensus, which is L7, which MEM-INV-28 prohibits** |
| **V-D VECTOR-PRIMARY VARIANT** | G (embedding) as the memory model, with the record store as a backing detail | ❌ **REJECTED. Vol A §2.3: G fails K2/K3/K5/K6/K11/K14 STRUCTURALLY, and the failure is not a defect of vector stores — **two opposing claims being adjacent in embedding space is what a vector store does. Similarity is the only available query, and similarity is not relevance and relevance is not truth (§27)**** |
| **V-E ⚠️ THE VARIANT WORTH CONSIDERING: NO PERSISTENT SEMANTIC MEMORY** | **T2/T4 do not exist. Only T0/T1 (working, episodic) and T3 (procedural). Everything "semantic" is recomputed from episodes on demand** | **⚠️ INTERESTING AND PARTIALLY ADMISSIBLE. **It eliminates §31's consolidation, §32's generalization, §33's compression, and attacks #43–#47, #51–#54 entirely** — because the mechanisms they attack do not exist. **Cost: recomputation is `O(episodes)` per query, which is `O(N)` and violates MEM-INV-44 at scale. **⟹ R77.1: V-E IS ADMISSIBLE AT S-1/S-2 AND INFEASIBLE AT S-3+. It is the correct design for a small organism and the wrong one for a large one — and it is the strongest evidence that T2/T4 are not epistemic necessities but SCALE NECESSITIES, which means their epistemic risk (§31/§32's whole subject) is a price paid for scale, not for knowledge**** |

**R77.2 (WHAT V-E REVEALS).** *The most dangerous operations in the package — consolidation, generalization, compression, abstraction — are all **scale adaptations**. A system small enough to recompute everything from episodes needs none of them, and has none of attacks #43–#54.* **⟹ The honest statement is that §31–§33 and §69's bounding rules (MEM-M2/M3, R32.1–R32.4, R33.2, R69.1) are not making a dangerous operation safe; they are making a necessary-at-scale operation as safe as it can be made, and the residue is §100's OR-M2/OR-M6/OR-M7. This is the memory-layer form of P0-03's finding that the three planes exist because scale forces communication at all.**

---

# §78. KNOWLEDGE REPRESENTATION COMPARISON — **OUTPUT 37**

## 78.1 The question this architecture actually needs answered

> ### **R78.0 (THE REFRAMING, AND IT CHANGES THE ANSWER).** *Classical KR formalisms are designed to answer **«WHAT FOLLOWS?»** — given a knowledge base, what can be inferred?*
>
> **This architecture needs to answer a different question: «WHAT IS WARRANTED, BY WHOM, UNDER WHICH RULES, DURING WHAT INTERVAL, IN WHAT CONTEXT, ON THE BASIS OF HOW MUCH INDEPENDENT EXTERNAL EVIDENCE?»**
>
> **⟹ Most KR formalisms are evaluated against the wrong criterion, and the comparison below uses the architecture's question, not KR's.**

## 78.2 The ten criteria

| # | Criterion | **Why** |
|---|---|---|
| **P1** | Can it represent **UNKNOWN / ignorance** as a first-class state? | §39, P0-01 R9.1 |
| **P2** | Can it represent **contradiction WITHOUT resolving it**? | Vol B R20.1, MEM-INV-32 |
| **P3** | Does it separate **warrant from truth**? | Vol A §3, R4.2, P0-02 R20.2 |
| **P4** | Does it carry **provenance** natively? | §13, MEM-INV-03 |
| **P5** | Can it express **evidence independence** (not just evidence quantity)? | §21, MEM-M3 |
| **P6** | Does it **avoid a scalar truth score**? | MEM-INV-24 |
| **P7** | Does it support **non-monotonic revision without overwriting**? | §36, MEM-INV-06/16/17 |
| **P8** | Does it support **interval temporal reasoning**? | §23, MEM-INV CT-3 |
| **P9** | Is it **hardware-portable** and **scale-feasible**? | §56, §88 |
| **P10** | Does it keep **inference OUT of the store**? | §16.4 R16.4, MEM-INV-40, P0-01 R13.1 |

## 78.3 **OUTPUT 37 — the comparison**

| Formalism | **P1** unknown | **P2** unresolved contradiction | **P3** warrant≠truth | **P4** provenance | **P5** independence | **P6** no scalar | **P7** non-monotonic | **P8** intervals | **P9** scale | **P10** no inference | **✓** |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| **Propositional / first-order logic** | ✗✗ *(closed-world or explicit negation; absence is not representable)* | ✗ *(a contradiction explodes: ex falso quodlibet)* | ✗ | ✗ | ✗ | ✓ | ✗ *(monotone)* | ✗ | ◐ | ✗ *(inference IS the formalism)* | **1** |
| **Production rules** | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ | ◐ | ✗ | ◐ | ✗ | **0.5** |
| **Semantic networks / OWL-style ontology** | ◐ | ✗ *(inconsistency is a defect to be repaired)* | ✗ | ✗ | ✗ | ✓ | ◐ | ✗ | ✗ *(reasoning is `O(2^n)` in general)* | ✗ | **0.5** |
| **Frames** | ◐ | ◐ | ◐ | ✗ | ✗ | ✓ | ◐ | ✗ | ✓ | ◐ | **2.5** |
| **Bayesian networks / PGMs** | ✗✗ *(a prior is never "unknown"; it is a distribution)* | ✗ *(conflict is resolved by conditioning)* | ✗✗ *(posterior probability IS a scalar truth score)* | ✗ | ◐ *(conditional independence is expressible — **the ONE criterion PGMs do well**)* | ✗✗ | ✓ *(conditioning is non-monotonic)* | ✗ | ◐ | ◐ | **1.5** |
| **Dempster–Shafer / evidence theory** | ✓ *(mass on the full frame = total ignorance)* | ◐ *(Zadeh's paradox: highly conflicting bodies of evidence produce a counterintuitive combination)* | ◐ | ✗ | ✗✗ *(⚠️ **combination ASSUMES independence** — the exact property §21 must COMPUTE)* | ◐ *(belief/plausibility is an interval, not a scalar)* | ◐ | ✗ | ◐ | ◐ | **2** |
| **Fuzzy logic** | ✗ | ◐ | ✗ | ✗ | ✗ | ✗✗ *(a membership degree is a scalar truth score)* | ◐ | ✗ | ✓ | ◐ | **0.5** |
| **Case-based reasoning** | ◐ | ◐ | ◐ | ◐ *(a case has a source)* | ✗ | ✓ | ✓ *(cases accumulate; none is overwritten)* | ◐ | ✓ | ✓ *(retrieval, not inference)* | **4.5** |
| **Event calculus / situation calculus / interval temporal logic** | ◐ | ✓ *(fluents may hold and not hold in disjoint intervals — **CT-3's decidability**)* | ◐ | ◐ *(events have origins)* | ✗ | ✓ | ✓ *(a fluent's truth value changes without the event log changing)* | **✓✓** *(native)* | ◐ | ✓ | **5.5** |
| **AGM belief revision** | ◐ | ✓ *(contraction without resolution)* | ✓ *(belief sets are not truth sets)* | ✗ | ✗ | ✓ | **✓✓** *(expansion/revision/contraction, and **the recovery postulate is exactly MEM-INV-17**)* | ✗ | ◐ | ✓ | **5.5** |
| **Provenance semiring / annotated relations** | ◐ | ✓ *(annotations coexist)* | ✓ *(an annotation is not a truth value)* | **✓✓** *(native — this is what the semiring IS)* | ◐ | ✓ | ✓ | ✗ | ◐ | ✓ | **6.5** |
| **Vector / latent representations** | ✗✗ | ✗✗ | ✗✗ | ✗✗ | ✗✗ | ✗✗ | ✗ | ✗ | ✓ *(retrieval only)* | ✓ | **0.5** |
| **⟵ THIS ARCHITECTURE** | **✓** | **✓** | **✓** | **✓** | **✓** | **✓** | **✓** | **✓** | **✓** | **✓** | **10** |

## 78.4 What the comparison actually shows

> ### **R78.1 (THE ARCHITECTURE IS A COMPOSITION OF THREE FORMALISMS, AND THE COMPOSITION IS THE CONTRIBUTION).**
>
> ```
>   ANNOTATED RELATIONS  (provenance semiring)   ⟹ P3, P4, P2
>      a record is a claim annotated with its provenance, and annotations
>      COEXIST rather than combine. **⟹ This is Vol A §15.1(d)'s structure:
>      separate source records linked to one claim record**
>
>   + INTERVAL TEMPORAL LOGIC (event calculus)   ⟹ P8, P2 (CT-3/CT-4)
>      a claim holds during an interval, in a context. **⟹ This is Vol B
>      §23.1's event_interval / record_interval / validity triple, and
>      §23.2's interval algebra is what makes CT-3 decidable**
>
>   + AGM-STYLE NON-MONOTONIC REVISION           ⟹ P7, P1, P2
>      expansion (new record), revision (V-CORRECTION), contraction
>      (RETRACTED / VOID / EXPIRED) — **and the RECOVERY POSTULATE, which
>      says a contracted belief may be restored, is exactly MEM-INV-17's
>      «superseded records remain readable under AUDIT»**
>
>   ⟹ **AND WHAT IS DELIBERATELY ABSENT FROM ALL THREE: AN INFERENCE ENGINE.**
>      P10 is satisfied by §16.4 R16.4: the claim graph represents relations;
>      it does not perform inference. **A KR system that infers is a second
>      evaluator, and MEM-INV-08 / P0-01 R13.1 prohibit it.**
> ```

> ### **R78.2 (THE THREE REJECTIONS, WITH REASONS).**
> 1. **PROBABILISTIC KR IS REJECTED — Bayesian networks, Dempster–Shafer, fuzzy logic.** *Not because probability is wrong, but because **a distribution is a scalar with extra steps (Vol B R18.2): it inherits the scalar's fatal property, which is that it can be updated by anything, including retrieval.** Dempster–Shafer's P1 (mass on the full frame) and P6 (belief/plausibility intervals) are genuinely good, and **its P5 failure is fatal: combination ASSUMES the independence that §21 must COMPUTE.*** **⟹ Zadeh's paradox is the tell: D-S produces counterintuitive results exactly when bodies of evidence highly conflict — which is the CT-1/CT-2 case, and the architecture's answer is to RETAIN BOTH rather than combine them.**
> 2. **LOGICAL KR IS REJECTED — FOL, OWL, production rules.** *Ex falso quodlibet: a contradiction explodes a logical knowledge base. **The architecture's central requirement is that a contradiction be RETAINED AND SURVIVED (MEM-INV-31/32), and classical logic cannot represent a stable inconsistency.*** **⟹ And the closed-world assumption makes P1 impossible: absence is negation, which is P0-01 R9.1's prohibited conversion.**
> 3. **LATENT/EMBEDDING KR IS REJECTED AS A MODEL — and admitted as an INDEX.** *Vol A §2.3's G row: six structural failures. **Vol B §27: similarity is not relevance and relevance is not truth.** ⟹ G is I-3, one index among five, and Vol D R57.2's ablation shows removing it changes nothing epistemic.*

> ### **R78.3 (WHAT CASE-BASED REASONING CONTRIBUTES, AND WHY IT IS THE CLOSEST SINGLE FORMALISM).** *CBR scores 4.5 — the highest of any single classical formalism — because it does three things this architecture needs: **a case has a source (P4), cases accumulate without overwriting (P7), and retrieval is not inference (P10).*** **⟹ Vol B §25's retrieval architecture and §31's episodic-replay-driven consolidation are CBR in structure. **What CBR lacks is P1 (no ignorance representation), P5 (no independence model), and P8 (no interval reasoning) — and those three are supplied by the annotated-relation and interval-temporal components.***

---

# §79. IMPLEMENTATION INDEPENDENCE — **OUTPUT 49**

## 79.1 What is invariant, and what varies

> ### **R79.1 (THE INVARIANCE CLAIM).** *The specification is implementation-independent in the following exact sense: **every `[D]` derived quantity, every `[X]` externally-written quantity, every MEM-INV invariant, every state machine transition, and every authority assignment in Vol A §8.1's matrix are invariant across implementations. What varies is the `[G]` parameter values and the storage/index substrate.***

| Layer | **Invariant** | **Varies** |
|---|---|---|
| **Schema** | The 31 fields, their classes (mandatory/derived/external/prohibited), and the seven record-level prohibited fields | **Field ENCODING (widths, layouts, serialization)** |
| **Epistemics** | The four axes (R0.1), the E0–E4 ladder, the twelve belief states, the fourteen source classes, the seven contradiction types, the six ignorance kinds | — |
| **Authority** | Vol A §8.1's matrix — every ✅/⚠️/❌ cell | **Which PROCESS implements which principal** |
| **Machines** | §74's six machines and every transition's externality | **Scheduling, concurrency, batching** |
| **Cost model** | The `O(1)` / `O(log n)` / `O(R)`-per-epoch / off-line classification (Vol D §56.2) | **Constants** |
| **Parameters** | The four-class registry and each parameter's ROLE | **Values (`[G]`), and the substrate that holds them** |
| **Storage** | — | **⟵ EVERYTHING. B-tree, LSM, log-structured, in-memory, sharded, replicated, tiered to cold storage** |
| **Indexes** | — | **⟵ EVERYTHING. Vol A §2.4's D and G components are explicitly substrate-specific and R79.2 says why that is safe** |

## 79.2 The three portability rules

> ### **R79.2 (INDEX NON-PORTABILITY IS SAFE; RECORD NON-PORTABILITY IS NOT).**
> 1. **A record's epistemic fields MUST be portable.** `evidence_status`, `source_class`, `root_commit`, `validity`, `context_scope` mean the same thing on a phone and in a cluster. **⟹ A record whose meaning depends on its substrate is not a record.**
> 2. **An index MAY be substrate-specific, model-specific, and non-portable.** *Because MEM-INV-36 (index failure is never record failure) and R57.2's ablation (removing every index changes nothing epistemic).* **⟹ An embedding produced by model *M₁* on hardware *H₁* is meaningless on *H₂*, and that is fine: the index is rebuilt (R25.2).**
> 3. **⚠️ AND THE ONE PORTABILITY HAZARD, NAMED: `context_scope.hw_class?` (Vol B §24.1).** *A record whose VALIDITY depends on hardware MUST declare it. **An undeclared hardware dependence is a silent portability violation — the record is retrieved on different hardware, its scope is `UNKNOWN_ON(hw_class)`, and R24.2's rule applies: unknown scope is a warrant REDUCTION, never a match.*** **⟹ The architecture degrades safely by default, and `hw_class` exists so the degradation can be avoided when the dependence is known.**

## 79.3 What an implementation MUST NOT do

| Prohibition | **Why** |
|---|---|
| **Store any `[D]` quantity** | MEM-INV-23/25, Vol A D-1 |
| **Let the substrate assign `evidence_status`** | MEM-INV-22, R40.1 |
| **Implement `source_class` as a mutable field** | MEM-INV-02 — **the immutability IS the defense against #26–#40, and a mutable implementation reopens twelve attacks** |
| **Return a bare ranked list** | MEM-INV-34 |
| **Implement retrieval as a write** | MEM-INV-09 |
| **Implement `causal_depth` as a wrapping counter** | MEM-INV-14 — **Vol A D-3: a wrapping counter inverts its own purpose** |
| **Implement contradiction resolution as averaging or voting** | MEM-INV-49, Vol B §20.5 |
| **Implement recovery as belief reconstruction** | MEM-INV-39 |
| **Implement forgetting as deletion of the anchored fact** | MEM-INV-37 |
| **Implement the claim graph with an inference engine** | §16.4 R16.4, MEM-INV-40 |
| **Implement `UNREVALIDATABLE` as `EXPIRED` or as `FRESH`** | Vol D §63.1, §39.2 IG-4, P0-01 R9.1 |
| **Implement a scalar confidence anywhere, including internally** | MEM-INV-24 |

---

# §80. IDENTITY PERSISTENCE

## 80.1 The four identities, and what makes each persist

**Vol A §5.1: `mem_id` is «global, permanent, never reused. **Identity, not address** (COMM-INV-10)».** §80 generalizes from records to the four identity kinds the architecture has.

| Identity | **What it identifies** | **Persistence mechanism** | **⚠️ What must NOT change it** |
|---|---|---|---|
| **RECORD IDENTITY** (`mem_id`) | A specific record | **Global, permanent, never reused. A version chain is a chain of DISTINCT `mem_id`s linked by `version.parent_mem_id` — the chain has no single identity, and it does not need one** | Storage migration · compression · archiving · shard rebalancing · index rebuild |
| **CLAIM IDENTITY** (§15.2 D-3) | **A proposition, in a context scope, during a validity interval** | **⟵ THE HARDEST IDENTITY IN THE ARCHITECTURE. Vol A R15.3: structural identity is decidable; SEMANTIC identity is not (U-4). **Where undecidable: TWO claim records + a `POSSIBLY_SAME_CLAIM` edge. Conservative: it may duplicate a claim, but it will never merge two distinct ones — and merging distinct claims loses a contradiction, while duplicating one loses only storage**** | A new record supporting it · a contradiction · a version of a supporting record · **DR-2's semantic drift (⚠️ which it CANNOT survive, and R60.1's scoping is the mitigation)** |
| **SUBJECT IDENTITY** | A cell, circuit, region | **`src_identity` derived from channel binding (COMM-INV-09) + `lineage_ref` in the EIK Lineage Store** | **θ changes · plasticity updates · learned-weight changes · specialisation. ⟵ R44.1/MEM-INV-19: a subject's LEARNED state changes continuously and its IDENTITY does not, and the two are distinguishable by field** |
| **ORGANISM IDENTITY** | The organism across generations | **The Anchor's chain, from the genesis anchor (which is OUTSIDE operational control — P0-02 §10.4) through every epoch** | **Generational turnover · lineage retirement (Cell §17.5) · policy change (which produces `VOID_CONTEXT`, not a new organism)** |

## 80.2 The identity rules

> ### **R80.1 (IDENTITY IS NOT LOCATION).** *COMM-INV-10, applied to memory: a `mem_id` is not an address, a shard key, a storage location, or an index entry. **A record that moves, is compressed, is archived, is re-indexed, and is restored has one identity throughout.*** **⟹ §79.2 rule 1's portability requirement is a consequence: an identity that changes with the substrate is an address.**

> ### **R80.2 (IDENTITY IS NOT CONTENT).** *Vol A §15.2 D-1: two records with identical content and different `root_commit`s are TWO records. **⟹ Content-addressed identity (candidate D) fails K3 for exactly this reason: a content hash identifies content, not source, and §12's whole taxonomy is about source.*** **This is why D is admitted as a DEDUP mechanism and rejected as an IDENTITY mechanism (Vol A §2.4).**

> ### **R80.3 (IDENTITY SURVIVES EVERY STATE IN §74.1's MACHINE 1).** *A `CRYPTOGRAPHICALLY_ERASED` record's identity survives in the Anchor (§35.4). **⟹ The identity is the thing that makes erasure auditable: without a surviving identity, «something was erased» is not distinguishable from «nothing was ever there».***

> ### **R80.4 (⚠️ THE ONE IDENTITY THAT DOES NOT PERSIST, AND WHY THAT IS CORRECT).** *A BELIEF has no persistent identity. **A belief is a composite (Vol A §4.4): claim + belief state + computed `n_effective` + `inbreeding_F`.** The CLAIM persists; the belief state changes; the computed quantities are recomputed. **⟹ Giving a belief an identity would give it a history independent of its claim's, and §17.4's belief-state history is already that history — attached to the claim, not to a free-floating "belief object".*** **This is why §4.4 lists BELIEF as «first-class, as a composite» rather than as a stored object, and why V3 §11's BELIEF RECORD — a stored object with its own identity — is replaced rather than repaired.**

---

*End of Volume E. Volume F (`37_analysis_audit_testability.md`) covers §81–§101: the semantic self-reference analysis, meta-knowledge (Output 38), circular dependency audit (Output 45), scalability part 2 (Output 46), the off-line boundary, conformance and testability (Output 50), ablation (Output 47), hardware portability, the cross-system contradiction audit (Output 48), the P0/P1/P2 gap register (Output 51), the false-precision audit, and the open-research register (Output 52).*
