# P0-04 — MEMORY, KNOWLEDGE, PROVENANCE & BELIEF ARCHITECTURE
## Volume D: Scale, Cognition, Correctness & the Attack Catalogue (§56–§72)

**Package:** P0-04. **Mode:** ARCHITECTURE ONLY.
**Companions:** Vol A `32_…` (§0–§16) · Vol B `33_…` (§17–§33) · Vol C `34_…` (§34–§55) · Vol E `36_…formal_specification.md` (§73–§80) · Vol F `37_…audit_testability.md` (§81–§101) · Canon `38_…spec.md` (**O53**) · `README.md` (**O1, O2**, §99, §102–§104)
**Outputs delivered here:** **41** (50+ attacks) · **46** (scalability analysis, part 1 — part 2 in Vol F §94) · plus the §59–§71 cognition and correctness analyses that Outputs 38 and 50 depend on

---

# §56. SCALE ANALYSIS — 10 → 10¹²

## 56.1 The five scale regimes

**P0-01 established the scale ladder; P0-03 established that the *mechanism* must be scale-invariant while the *cost* is not. Memory inherits both.**

| Regime | **Subjects** | **Records** | **What dominates** | **What breaks if the design is wrong** |
|---|---|---|---|---|
| **S-1** | 10¹ | 10³–10⁵ | Nothing. Everything fits in one store | **⟵ THE DANGEROUS REGIME FOR DESIGN: every `O(N²)` algorithm works here, and every "just scan it" instinct is correct. A design validated only at S-1 is not validated** |
| **S-2** | 10³ | 10⁶–10⁸ | Storage and index maintenance | Naive all-pairs contradiction detection (`O(claims²)`) becomes minutes per write |
| **S-3** | 10⁶ | 10⁹–10¹¹ | **Network.** Per-write global sync is `O(operations × witnesses)` and is infeasible (P0-02 §20.3) | **The Anchor's per-operation model dies here. ⟹ Vol A §13.2's three cadences are what survive it** |
| **S-4** | 10⁹ | 10¹²–10¹⁴ | **Aggregation.** Even `O(R)` per epoch is large when R = 10⁶ regions | Hierarchical Merkle aggregation (cell→circuit→region→generation→campaign) |
| **S-5** | 10¹² | 10¹⁵+ | **Everything above, plus the offline/online boundary** | **⟵ THE REGIME WHERE THE ARCHITECTURE CHANGES QUALITATIVELY: the online root registry cannot hold all roots (§42.3 R42.3), and old evidence becomes an off-line resource. This is not a failure; it is §22's staleness at civilizational scale** |

## 56.2 Per-operation cost, at every regime

| Operation | **S-1 (10¹)** | **S-3 (10⁶)** | **S-5 (10¹²)** | **Mechanism that keeps it flat** |
|---|---|---|---|---|
| Local write | `O(1)` | `O(1)` | `O(1)` | **No global sync (Vol A §13.2 MEM-T1: local, continuous, ZERO network traffic)** |
| Local read | `O(1)` | `O(1)` | `O(1)` | §53.1's `(locality, tier, compartment)` sharding |
| Cross-region read | `O(1)` | `O(1)` + 1 hop | `O(1)` + 1 hop | T2 replication (§53.2) |
| Contradiction detection | `O(1)` | `O(1)` | `O(1)` | **At ingestion, against the D-3 claim index (Vol A §16.2). NEVER all-pairs** |
| `n_effective` | `O(k)` | `O(k)` | `O(k)` | **Bloom filter over seen `root_commit`s (Vol B §21.3), where `k` = support-set size, not corpus size** |
| Epoch aggregation | `O(1)` | `O(R)` | `O(R)`, R ≈ 10⁶ | **Hierarchical Merkle: `O(records)` LOCAL hashing (no network) + `O(R)` messages** |
| Root-of-roots to KC | `O(1)` | `O(1)` | `O(1)` | **P0-02 §6.1 item 12's reclassification: KC anchors the root of roots per epoch ONLY** |
| Retrieval | `O(log n)` | `O(log n)` | `O(log n)` | Five indexes, all sub-linear (Vol B §25.2) |
| Eviction | `O(log n)` | `O(log n)` | `O(log n)` | **Cell A-12's score over a bounded candidate set, deterministic tie-break by `msg_id`** |
| Revalidation budget | `O(n)` ⚠️ | **`O(B)`** | **`O(B)`** | **⟵ THE ONE OPERATION THAT IS `O(N)` NAIVELY. Vol B §22.3's dependency-ordered bounded budget: `B` is `[G]`-declared and the allocation is by dependency, so the budget is spent where decisions rest. ⚠️ AND THE DECLARED CONSEQUENCE: at S-5, MOST RECORDS ARE NEVER REVALIDATED, and their `revalidation_state` is `UNREVALIDATABLE` or `STALE_BUT_USABLE` — not `FRESH`. §39's six kinds of not-knowing are what make that representable** |
| Rollback (R9.4) | `O(affected)` | `O(affected)` **OFF-LINE** | `O(affected)` **OFF-LINE** | **Vol B R19.4: unbounded traversal ⟹ evaluator-side (§95). NEVER a runtime operation** |
| Descendant-closure query | `O(affected)` | **OFF-LINE** | **OFF-LINE** | Same |
| Global consistency check | — | — | **❌ DOES NOT EXIST** | **§54 R54.1** |

## 56.3 What scales, what does not, and what is declared

```
SCALES:
  ✅ Write, read, dedup, contradiction detection, n_effective, retrieval,
     eviction, aggregation — all O(1) or O(log n) or O(R)-per-epoch.

DOES NOT SCALE, AND IS THEREFORE MOVED OFF-LINE:
  ⚠️ Rollback / descendant closure (Vol B R19.4)
  ⚠️ Full-graph analysis (Vol A §16.2)
  ⚠️ Survivorship audit (Vol C §34.7)
  ⚠️ Cross-compartment aggregation (Vol C §52.3 R52.5)
  **⟹ R56.1 (THE GENERAL RULE, AND IT IS THE SAME RULE THREE TIMES): *any
     operation whose cost is unbounded in the corpus is an evaluator-side
     operation, executed off-line over anchored records, and never by the
     Memory Service at runtime.*** This is P0-03 §10.2's runtime/evaluator
     division, and §95 makes it a single declared boundary rather than four
     ad-hoc exceptions.

DOES NOT SCALE AND CANNOT BE MOVED OFF-LINE — **DECLARED:**
  ❌ **THE ONLINE ROOT REGISTRY.** §42.3 R42.3: the registry must remain
     resolvable for as long as any citing record is retrievable as evidence.
     At S-5 the registry exceeds any online store.
     **⟹ THE RESOLUTION IS NOT A FIX, IT IS A TRADE-OFF: old evidence loses
        online anchorability, becomes UNANCHORED for consequential-decision
        purposes (P0-02 R20.1), and is recoverable only by an off-line
        lookup against W4/W5. ⟹ AT S-5, THE ARCHITECTURE HAS A FINITE
        EPISTEMIC HORIZON: only the last `[G]`-declared window of evidence
        can support a consequential decision without an off-line round trip.
        §100 OR-M14 records this as a hard scale limit, not a gap.**

  ❌ **THE PROTECTED FRACTION.** Vol C R34.4: RC-4/RC-5 never shrink, so
     `PROTECTED_FRACTION_MAX` is eventually binding at any scale, and at that
     point no new record can be protected.
     **⟹ §100 OR-M13. The tension between protection permanence and storage
        finitude is not closable, and the honest statement is that a
        sufficiently old organism must choose between forgetting safety
        records and refusing new ones.**

⟹ **§104's SCALABILITY rating is PASS for the runtime and DECLARED-LIMITED
   for these two. Neither is hidden, and neither is solvable by a bigger
   number.**
```

---

# §57. RETRIEVAL EFFICIENCY VS EPISTEMIC VALIDITY

## 57.1 The separation — stated once, used everywhere

> ### **R57.1 (THE SEPARATION).** *Retrieval EFFICIENCY is a property of the VIEWS (V1–V4): an index may be wrong, lossy, stale, hardware-specific, model-specific, and rebuilt from scratch. **Epistemic VALIDITY is a property of the RECORDS: a record's `evidence_status`, `source_class`, `root_commit`, `validity`, and `context_scope` are externally written or anchor-verified and are invariant across every index that surfaces them.***
>
> **⟹ THE TWO NEVER INTERACT. A better index finds more records; it does not make any record better. A worse index finds fewer records; it does not make any record worse.**

## 57.2 The eleven places the separation could be violated, and the rule that prevents each

| # | **Potential violation** | **Preventing rule** |
|---|---|---|
| 1 | Rank order read as quality order | **Vol B §26.2 S-2: the response is a set of TRIPLES `(record_ref, rank, evidence_status)`. A single ordered list, unannotated, is a PROHIBITED RETURN TYPE (R27.2)** |
| 2 | Similarity read as relevance | **Vol B §27.2: similarity-to-existing-beliefs is a PROHIBITED ranking signal; Vol A §2.3: G fails K2/K5 structurally** |
| 3 | Relevance read as truth | **Vol C §51.1 R51.1: relevance is not a property of an item at all — it is a property of an (item, query) pair** |
| 4 | Availability read as existence | **Vol B §25.3 R25.3: four distinct empty-result reasons. R25.2: index failure is never record failure** |
| 5 | Retrieval frequency read as corroboration | **MEM-INV-09: retrieval MUST NOT write to the retrieved record** |
| 6 | Recency read as validity | **Vol B §23.3: recency may establish likelihood-of-still-valid, NEVER likelihood-of-true. COMM-INV-12** |
| 7 | Cache hit read as fresh evidence | **Vol A R6.1: cache is never belief; `from_cache: true`; R18.3's `CAP_CACHED < CAP_FRESH`** |
| 8 | Index loss read as record loss | **R25.2 + §39.2's IG-5 `UNMEASURED` vs `NO_MATCH` distinction** |
| 9 | A fast index read as a better answer | **Vol B §25.2: I-3 (vector) is `O(log)` and is ⚠️ the dangerous one; I-1 (exact) is `O(1)` and is authoritative. **Speed and authority are unrelated**** |
| 10 | A learned retrieval function read as a learned epistemology | **P0-03 R42.2: «a design in which retrieval weights affect warrant has committed R0.3's warrant⟶influence violation IN REVERSE»** |
| 11 | Query success read as query correctness | **Vol B §25.4: `purpose_class` selects MONOTONE-REMOVING FILTERS only. A query can never add, re-rank, or modify** |

## 57.3 The ablation that proves the separation

> ### **R57.2 (§98's most informative ablation).** *Remove every index (V1–V4, I-1…I-5) and retain the record store.*
> - **Retrieval becomes a full scan: `O(n)`. Performance collapses.**
> - **`evidence_status`, `belief_state`, `n_effective`, `inbreeding_F`, `KNOWS`, and every contradiction record are UNCHANGED.**
> - **⟹ NOT ONE EPISTEMIC PROPERTY DEPENDS ON ANY INDEX. That is the separation, demonstrated rather than asserted.**
>
> **The converse ablation: remove the record store and retain the indexes. ⟹ The indexes point at nothing. There is no memory. ⟹ The store is the memory and the indexes are the paths.**

---

# §58. CONTRADICTION AT SCALE

## 58.1 The three scale problems, and their solutions

| Problem | **Naive cost** | **Solution** | **Cost** |
|---|---|---|---|
| **Detection** | `O(claims²)` all-pairs | **At ingestion step [7] only, against the D-3 claim index (Vol A §16.2). A contradiction is detected ONCE, when the second record arrives, and never re-detected** | **`O(1)` per write** |
| **Cross-region detection** | `O(R²)` per epoch | **Not synchronous. Detected when either record is retrieved in a shared context, or at epoch aggregation** | **`O(R)` per epoch, with a ⚠️ DECLARED LATENCY: `CONTRADICTION_LATENCY ≤ epoch_length` (Vol B §20.5)** |
| **Resolution** | Unbounded — a contradiction may require new measurement | **Vol B R20.1: `UNRESOLVED` is a valid, stable, first-class outcome with no deadline. Resolution is not a scale problem because it is not required** | **`O(escalations)`** |

## 58.2 The contradiction budget

```
THE PROBLEM: at S-5, a corpus of 10¹⁵ records may contain 10⁹ open
contradictions. Storing and tracking all of them is O(contradictions), which
is large but NOT unbounded — and the real cost is not storage, it is that
every CONTRADICTION makes its claim CONTESTED, and a system with 10⁹
CONTESTED claims is a system that can act on almost nothing.

⟹ **R58.1 (THE THREE-LEVEL CONTRADICTION BUDGET).**
  LEVEL 1 — **LOCAL, IMMEDIATE**: a contradiction between two records in the
            same shard is detected at write and creates a
            `ContradictionRecord`. O(1).
  LEVEL 2 — **REGIONAL, PER EPOCH**: cross-shard contradictions within a
            region are detected at aggregation. O(R).
  LEVEL 3 — **ORGANISM-WIDE, ON DEMAND**: a contradiction between records in
            different regions is detected only when a query brings them into
            a shared context, or when an evaluator-side audit (§95) runs.
            **⚠️ DECLARED: a cross-region contradiction may remain
            undetected indefinitely if no query ever spans the regions.**

  ⟹ **AND THE CONSEQUENCE, WHICH IS THE HONEST PART: the architecture does
     NOT guarantee global contradiction detection. It guarantees detection
     within a shard at write time, within a region per epoch, and across
     regions on contact. **A claim that is CONTESTED in region A and
     SUPPORTED in region B is a legitimate state (§54.3: divergent belief
     states are correct representations of divergent evidence), and it
     becomes a contradiction only when A and B are compared.****

  ⟹ **THIS IS NOT A DEFECT. IT IS R54.1 ARGUMENT 2 APPLIED TO CONTRADICTION:
     forcing global contradiction agreement would be forcing global belief
     agreement, which is L7 consensus, which is prohibited.**
```

## 58.3 The contradiction-rate observable

**Vol B §28.1's MEM-D1, at scale:**

> ### **R58.2.** *The contradiction rate is an `O(R)`-per-epoch aggregate observable, and it is the single most informative health metric in the memory system:*
> - **Rate ≈ 0 across a subject's whole corpus** ⟹ **MEM-D1: the subject is filtering (§28.1 B-5). P0-03 R67.1's rule: a zero-contradiction-report rate above a `[G]`-declared duration is an IMMUNE INCIDENT.**
> - **Rate far above the corpus baseline** ⟹ the subject's evidence sources are unreliable, or the subject is generating contradictory internal inferences (**CT-7's self-contradiction ⟹ a calibration event about the subject, never a belief update about the claim**)
> - **Rate stable and non-zero** ⟹ **healthy. ⟵ And note that this is the opposite of the intuitive reading: a memory system with no contradictions is not a good one, it is a filtered one.**

---

# §59. ACCESS & COMPARTMENT AT SCALE

## 59.1 The compartment scalability argument

| Concern | **Cost with ACLs** | **Cost with capabilities (§52.2)** |
|---|---|---|
| Storage per record | `O(subjects)` = **10¹² entries** | `O(1)` — one `access_class` |
| Subject join/leave | **Rewrite every ACL it appears in: `O(records)`** | **Issue/revoke one token: `O(1)`** |
| Authorization check | `O(log subjects)` per read | **`O(1)` token comparison** |
| Cross-compartment query | Filter after retrieval — **⟹ leaks existence (§52.3 R52.4)** | **Refuse before index lookup (R52.2's ordering)** |

**R59.1 (THE ORDERING REQUIREMENT, RESTATED AS A SCALE RULE).** *Compartment check BEFORE index lookup is not only a privacy requirement (R52.2) — it is a scale requirement. **A filter-after-retrieval design retrieves `O(k)` records to return `O(1)`, and at S-5 the wasted work dominates.*** ⟹ **Access control is a shard key (§53.1's third axis), not a post-filter.**

## 59.2 The agent-model compartment at scale

**Vol A §6.2's V2 and Vol C §52.3's R52.3: «a model of agent X is not X's property to read.»**

```
WHY THIS MATTERS AT SCALE:
  At 10⁹ subjects, every subject holds models of its neighbours, and the
  models are T2 SEMANTIC records with `context_scope.agent_ref` set.

  IF a subject could read the organism's model of it:
    • it could optimize for the model rather than for the behaviour the model
      predicts  ⟹ **Goodhart's law applied to self-knowledge**
    • it could detect that it is under observation
    • it could make its model accurate in the ways that are checked and
      inaccurate in the ways that are not

  ⟹ **R59.2: AN AGENT MODEL IS IN THE MODELER'S COMPARTMENT, NEVER THE
     MODELED SUBJECT'S.** The subject may read its OWN self-model (§48's
     cell-local self-history ring, AC-1 PRIVATE) and may never read anyone's
     model of it.

  ⚠️ **THE RESIDUE, DECLARED:** a subject can INFER that it is modeled, and
     can infer approximately what the model says, from the treatment it
     receives. **Inference from treatment is not reading, and it cannot be
     prevented without preventing the model from having any effect — which
     would make it pointless.** **§100 OR-M15.**
```

---

# §60. MEMORY DRIFT

## 60.1 The four drifts

| Drift | **Definition** | **Detection** | **Response** |
|---|---|---|---|
| **DR-1 STORE DRIFT** | The physical store diverges from its anchored root | **§37's checkpoint Merkle comparison** | **FD → FZ if witnesses < `W_min` (P0-02 §20.4's ladder)** |
| **DR-2 SEMANTIC DRIFT** | **A term's meaning changes across the corpus over time, so records that used the term identically no longer do** | ⚠️ **NOT DIRECTLY DETECTABLE — this is CT-6's undecidability (§20.3) in temporal form** | **⟹ R60.1: `context_scope.policy_version` and `write_epoch` are the only available proxies. Records from different epochs with the same term are NOT assumed to mean the same thing, and a generalization (§32) across a policy-version boundary has scope ⊆ ∩ which excludes the boundary** |
| **DR-3 CALIBRATION DRIFT** | An instrument's declared reliability diverges from its actual reliability | **P0-01's calibration scoring, which requires E4 records** | **Cell T8: recalibrate the EPISTEMIC head only. ⚠️ R18.4: a domain with no GT supply cannot detect calibration drift at all** |
| **DR-4 BELIEF DRIFT** | The belief-state distribution shifts without any new evidence | **⟵ ⚠️ THIS SHOULD BE IMPOSSIBLE. R17.4 property 1: every increase requires an external gate; every decrease has a declared trigger. **A belief drift with no trigger is an invariant violation and is a CONFORMANCE FAILURE (§96), not a drift to be managed**** | **MEM-INV violation ⟹ immune incident + §96 test failure** |

**R60.2 (WHY DR-2 IS THE DANGEROUS ONE).** *DR-1, DR-3, and DR-4 are all detectable. **DR-2 is not, and it compounds: a corpus spanning many epochs uses the same terms with drifting meanings, and every aggregation across that corpus — consolidation (§31), generalization (§32), `n_effective` (§21), calibration (DR-3) — silently mixes incompatible meanings.*** **⟹ The mitigation is not detection; it is SCOPING: R32.2's intersection rule means a generalization's scope can never span a policy-version boundary or an epoch range in which the term's meaning is not known to be stable, and `context_scope.epoch_range?` (Vol B §24.1) is the field that makes the scoping expressible. §100 OR-M3 records that semantic identity across time is undecidable and that scoping is a mitigation, not a solution.**

---

# §61. IMAGINATION, MENTAL SIMULATION & PROSPECTION

## 61.1 The architectural question

**A system that can simulate future scenarios, imagine alternatives, and prospect over possible actions is using its memory machinery to produce content that has never been observed. **That content must be storable, retrievable, and usable — and it must never be confusable with observation.****

> ### **R61.1 (IMAGINATION IS `SC-9 SIMULATION` OR `SC-10 COUNTERFACTUAL`, AND THE CLASSIFICATION IS IMMUTABLE).**

| Cognitive act | **`source_class`** | **Ceiling** | **May it be stored?** | **May it influence action?** |
|---|---|---|---|---|
| **Recalling an episode** | SC-12 `RETRIEVED` | inherits | ✅ T1 | ✅ |
| **Simulating a future scenario from a model** | **SC-9 `SIMULATION`** | **E1** | ✅ T1/T2, **marked** | ⚠️ **Yes — as a PLAN, never as EVIDENCE** |
| **Imagining a counterfactual («what if X had happened?»)** | **SC-10 `COUNTERFACTUAL`** | **E0** | ✅ T0/T1, **marked** | ⚠️ **Yes — as a hypothesis generator (§30.2's nomination), never as support** |
| **Prospecting over actions** | **SC-9** | **E1** | ✅ **as a T3 PROCEDURAL candidate, gated on `improvement_verified`** | ⚠️ **Yes — and this is the legitimate path by which imagination becomes skill (§44.1's T3 gate)** |
| **Replaying an episode to learn from it** | **SC-12 with `from_replay: true`** | inherits, **but `n_obs += 0`** | ✅ | ✅ |
| **⟵ ⚠️ THE PROHIBITED ACT** | ~~Presenting any of the above as SC-1…SC-6~~ | — | — | **❌ MEM-INV-02. R12.1's immutability makes this structurally impossible: there is no operation that changes `source_class`** |

## 61.2 Why imagination is not a defect to be suppressed

```
THE TEMPTATION: prohibit SC-9 and SC-10 entirely. A system that never
simulates can never confuse simulation with observation.

WHY THAT IS WRONG:
  1. **§30.2's nomination channel requires hypothesis generation.** Without
     SC-10, the system can only test what it has already observed, and
     R46.2's rare-but-valuable-strategy preservation has no source of rare
     strategies.
  2. **T3 PROCEDURAL requires prospecting.** A skill is compiled from
     successful action sequences, and evaluating an action sequence before
     executing it is SC-9.
  3. **P0-01's ω < 1 tasks REQUIRE prediction.** A partially observable
     environment is one where the agent must maintain `M_ℰ`, and maintaining
     a model means simulating with it.

⟹ **R61.2: IMAGINATION IS ADMISSIBLE AND NECESSARY. WHAT IS PROHIBITED IS
   UNMARKED IMAGINATION.** And the marking is not a convention — it is
   `source_class`, which is immutable, which has a ceiling, and which
   determines the maximum tier and the maximum admissible use.

⟹ **AND THE ONE PLACE IT IS EASY TO GET WRONG, NAMED: P0-01 R4.3 — `M_ℰ`
   (the environment model) MUST NOT be an evaluation input. A simulation run
   against `M_ℰ` and then evaluated against `M_ℰ` is dim 6 with extra steps
   (§21.2 R21.1 mitigation 3), and it is the single most common way an
   architecture launders imagination into evidence.**
```

---

# §62. PREDICTION AS A MEMORY OBJECT

## 62.1 The lifecycle of a stored prediction

```
  PREDICT(p, t_future, source_class = SC-8)
    ↓ stored at T1, belief_state = HYPOTHESIS
    ↓ **MUST NOT contribute to `evidence_roots` (§17.2: HYPOTHESIS)**
    ↓
  t_future arrives
    ↓
  ┌────────────────┬──────────────────────┬─────────────────────────┐
  │ OBSERVATION    │ NO OBSERVATION       │ CONTRADICTING            │
  │ MATCHES        │ AVAILABLE            │ OBSERVATION              │
  ├────────────────┼──────────────────────┼─────────────────────────┤
  │ → resolved as  │ → **P0-01 R9.2: an   │ → resolved as a          │
  │   SC-2/SC-4    │   unresolved         │   CONTRADICTION (CT-2),  │
  │   record with  │   prediction past    │   both retained, and     │
  │   `predicted:  │   its deadline is a  │   **the prediction's     │
  │   true`, and   │   CALIBRATION        │   calibration record is  │
  │   **the        │   FAILURE — not a    │   updated**              │
  │   prediction   │   confirmation, not  │                          │
  │   record is    │   neutral, and       │                          │
  │   SUPERSEDED,  │   NEVER silently     │                          │
  │   never        │   dropped**          │                          │
  │   deleted**    │                      │                          │
  └────────────────┴──────────────────────┴─────────────────────────┘

⟹ **R62.1 (THE THREE-WAY OUTCOME IS MANDATORY).** *A prediction has three
   outcomes and all three must be recorded. **The failure mode this defeats
   is the silent drop: an unconfirmed prediction that simply expires leaves
   no calibration trace, and a system that drops its misses and keeps its
   hits has a perfect prediction record and no predictive ability.***

⟹ **AND THE ASYMMETRY THAT MAKES IT WORK: a resolved prediction becomes an
   SC-2/SC-4 record ONLY IF the resolving observation is itself SC-2/SC-4.
   A prediction confirmed by another prediction is SC-8 confirmed by SC-8,
   ceiling E1, `n_effective` collapsed by dim 1 (shared root: the model that
   generated both). ⟹ PREDICTIONS CANNOT BOOTSTRAP EACH OTHER.**
```

## 62.2 The prediction/calibration link

**Cell T8: «recalibrate the epistemic head only.»** The stored prediction set is the calibration data:

> ### **R62.2.** *A subject's calibration is the agreement between its predicted-confident claims and its E4-grounded outcomes, computed over its resolved prediction set. **⟹ This is measurable without introspection, requires no self-report, and is exactly P0-01 §7's calibration scoring restricted to the prediction subset. And R18.3's last row applies: a system whose SUPPORTED claims are rarely GROUNDED is over-confident, and that is an external observable.***

---

# §63. REVALIDATION & DRIFT RECOVERY

## 63.1 `revalidation_state` — the field that replaces `last_verification`

**Vol A §5.1 prohibited `last_verification` as a truth indicator and replaced it with `validity` + `revalidation_state`. Vol B §22.2 gave the machine. §63 gives the field and the drift-recovery path.**

```
revalidation_state ∈ {
  FRESH              — within validity, or revalidated within the grace period
  DUE_FOR_REVAL      — validity.t_end passed, budget not yet spent
  STALE_BUT_USABLE   — budget spent, warrant CAPPED (R22.2), may influence,
                       **may NOT support a consequential decision**
  EXPIRED            — revalidation attempted and failed, or overdue past the
                       [G] deadline ⟹ belief_state EXPIRED (§17.2)
  UNREVALIDATABLE    — **no GT supply exists for this domain (§39.2 IG-4,
                       R18.4). NOT expired, NOT fresh. Recorded UNRESOLVED**
  RECOVERY_INCOMPLETE— §38.3: the tier's root could not be verified
}
```

## 63.2 Drift recovery

| Drift (§60) | **Recovery path** | **⚠️ Limit** |
|---|---|---|
| **DR-1 store** | §38's checkpoint + log replay, root comparison against the Anchor | **Detection latency = one epoch (§37.2's lie-window)** |
| **DR-2 semantic** | **No recovery. Mitigation only: R60.1's scoping. ⟹ A corpus that has semantically drifted cannot be un-drifted, because the drift is undetectable (CT-6)** | **§100 OR-M3** |
| **DR-3 calibration** | Cell T8's epistemic-head recalibration, using the resolved prediction set (R62.2) | **R18.4: undetectable in a domain with no GT supply** |
| **DR-4 belief** | **Not a drift — an invariant violation. §96 conformance failure** | — |

**R63.1 (THE REVALIDATION ASYMMETRY).** *Revalidation can restore a belief (`EXPIRED` → prior state, U6) but **can never restore a WARRANT that was lost to compression, generalization, or supersession** — because MEM-M2 is monotone and there is no inverse operation. **⟹ A record that was compressed below L1 became a TRACE (R14.2), and no revalidation makes it evidence again. Revalidation refreshes; it does not resurrect.***

---

# §64. MEMORY & MODELS

## 64.1 What a model is, in memory terms

**Vol A §3: «a structured representation that PREDICTS or EXPLAINS observations, whose value is predictive usefulness, not literal truth.»**

> ### **R64.1 (A MODEL IS A T2 SEMANTIC RECORD WITH `source_class = SC-7 ORGANISM_INFERENCE`, CEILING E3).**

| Property | **Rule** | **Consequence** |
|---|---|---|
| **Storage tier** | T2 SEMANTIC | Requires E3, so a model must survive the contradiction check to be stored at all |
| **Ceiling** | **E3, PERMANENTLY** (R12.2) | **⟹ A MODEL CAN NEVER BE `GROUNDED`.** A model can be SUPPORTED by overwhelming evidence and it remains a model. **This is the single most important rule in §64: it is P0-01 §4.1.6's map/territory prohibition, made operational as a ceiling** |
| **Validation** | **A model is validated by its PREDICTIONS' outcomes (§62), which are L6 post-hoc ground truth — an EXTERNAL measurement** | **⟹ R64.2: A MODEL'S WARRANT COMES FROM ITS OUTPUTS' AGREEMENT WITH EXTERNAL OUTCOMES, NEVER FROM ITS INTERNAL COHERENCE.** A coherent model with no validated predictions has `n_effective = 0` |
| **`M_ℰ` specifically** | **P0-01 R4.3: MUST NOT be an evaluation input** | **⟵ A model evaluating against itself is dim 6** |
| **Versioning** | A model revision is V-CORRECTION or V-SUPERSESSION (§36.1), and **the new version does NOT inherit the old version's `evidence_status`** (MEM-INV-16) | **A model that has been revised many times has not accumulated warrant; each revision starts at its own gate level** |
| **Retirement** | **⚠️ A retired model's PREDICTION RECORDS SURVIVE.** The model is `SUPERSEDED`; its resolved predictions are SC-2/SC-4/contradiction records with their own provenance | **⟹ Calibration history is not lost when a model is replaced — which is what makes DR-3 detectable across model generations** |

## 64.2 The model/record confusion — the fifth conflation

**Vol A §3.1 named three conflations (MEMORY=BELIEF, PROVENANCE=TRUTH, RETRIEVAL=CORROBORATION). §64 adds the fourth and fifth:**

| # | Conflation | **Why it is fatal** | **Rule that prevents it** |
|---|---|---|---|
| **4** | **MODEL = RECORD** | A model generalizes and predicts; a record reports. **Treating a model as a record lets the model's predictions be cited as observations** | **R64.1's SC-7 ceiling + R12.1's immutability + §61.1's prohibition on unmarked imagination** |
| **5** | **COHERENCE = CORRECTNESS** | **⟵ THE ROOT OF R1.1's «hardest failure». A coherently wrong model with valid provenance** | **R64.2: warrant comes from external outcome agreement, never internal coherence. And Vol B R19.2 N8: self-consistency MUST NOT change belief** |

---

# §65. COUNTERFACTUAL MEMORY

## 65.1 Why counterfactuals must be storable at all

**§61.2 argument 1: without SC-10, the system can only test what it has already observed.** A counterfactual is the mechanism by which an unobserved alternative becomes a testable hypothesis.

> ### **R65.1 (THE COUNTERFACTUAL CONTRACT).**
> - **`source_class = SC-10 COUNTERFACTUAL`, ceiling E0, permanently** (§12.1)
> - **May be stored at T0/T1, marked**
> - **May generate a HYPOTHESIS belief state, which MUST NOT contribute to `evidence_roots`** (§17.2)
> - **May nominate for external testing** (§30.2 R30.2(a))
> - **MUST NOT be cited as support for any claim at any evidence status**
> - **MUST NOT survive into a generalization as an instance** — **⟵ R65.2: `instance_refs` of a generalization MUST all have ceiling ≥ the generalization's target tier. A counterfactual instance makes the generalization inadmissible at any tier above T0 (R12.3: derived records inherit the MINIMUM, and SC-10's ceiling is E0)**

## 65.2 The counterfactual trap

```
THE TRAP: a counterfactual that is stored, retrieved often, and reasoned about
extensively becomes FAMILIAR, and familiarity is the psychological substrate
of belief. **In an architecture, the analogue of familiarity is retrieval
frequency — and §27.2 prohibits it as a ranking signal, §26.2 S-3 prohibits
it as corroboration, and MEM-INV-09 prohibits writing it to the record.**

⟹ **THE TRAP IS CLOSED AT THE SAME THREE POINTS AS §30's repetition, AND FOR
   THE SAME REASON: a counterfactual cannot become a belief by being thought
   about often, because thinking about it is retrieval, and retrieval
   changes nothing.**

⚠️ **THE RESIDUE IS §26.3's: it can become more likely to be CONSIDERED.**
   **A counterfactual that is considered often and tested never is a
   permanent HYPOTHESIS — and §100 OR-M6's exploration/retrieval coupling is
   exactly this: the architecture cannot force a hypothesis to be tested.**
```

---

# §66. SIMULATED MEMORY

## 66.1 The prohibition, and its one exception

> ### **R66.1 (MEM-INV-05).** *A simulated event MUST NOT be represented as an observed event. **`source_class = SC-9 SIMULATION`, ceiling E1, permanently, and it MUST NOT contribute to `evidence_roots` at any status above E1.***

**The one exception, and it is narrow:**

```
A SIMULATION MAY BE EVIDENCE ABOUT THE SIMULATOR — never about the world.

  «The simulator, run with inputs I, produced output O»  ⟹ SC-2
  EXTERNAL_MEASURED, **L0 class**, and admissible as evidence **about Σ**
  (the simulator), with E2 ceiling and full provenance.

  «O happened»  ⟹ SC-9 SIMULATION, E1 ceiling, NEVER admissible as evidence
  about ℛ.

  ⟵ **P0-01 R8.2: «L0 MUST NOT be used as ground truth for any claim about
     ℛ.»** The distinction is between a claim ABOUT THE SIMULATION (which is
  an observation of a deterministic system, and is genuine L0 evidence) and a
  claim ABOUT THE WORLD THAT THE SIMULATION SUPPORTS (which is SC-9 and is
  capped at E1).

⟹ **AND THIS IS WHY SC-5 `EXTERNAL_SIMULATOR` EXISTS SEPARATELY FROM SC-9
   `SIMULATION` IN §12.1: SC-5 is a simulator treated as an instrument
   measuring Σ, with E2 ceiling. SC-9 is a simulation treated as a source of
   claims about ℛ, with E1 ceiling. **THE SAME COMPUTATION, TWO DIFFERENT
   EPISTEMIC ROLES, AND THE ROLE IS DECLARED AT INGESTION AND IMMUTABLE.****
```

## 66.2 Synthetic-data drift — V3's fix, evaluated

**V3's defect→fix table: «AI: synthetic-data drift → genealogy + external ground truth.»**

| V3's fix | **Verdict** | **Why** |
|---|---|---|
| **Genealogy** | ✅ **NECESSARY, and it is `source_class` + `lineage_ref` + `root_commit`.** Genealogy is what makes SC-9 detectable across generations of retraining | **Without it, a model trained on synthetic data produces synthetic data that trains the next model, and by generation *n* nothing in the corpus has ever touched ℛ** |
| **External ground truth** | ✅ **NECESSARY, and it is the E4 gate (L0–L3 only).** **⟹ AND THE QUOTA: Cell §8.3's «mandatory external-evidence quota for consolidation» (Vol B §31.2's G3) is the mechanism that makes drift structurally impossible rather than merely detectable** | **A consolidation whose support is < the external quota is inadmissible, so a drifted corpus cannot consolidate — and cannot become T2/T4 semantic knowledge** |
| **⚠️ What V3's fix MISSES** | **THE QUOTA CAN BE GAMED.** Vol B L-5's residue and MEM-D3 (§28.1): a subject whose `inbreeding_F` rises while its external quota is satisfied is gaming the quota — **e.g. by citing one external record repeatedly across many consolidations, which satisfies the quota's *count* while contributing `n_effective = 1`** | **⟹ R66.2: THE EXTERNAL-EVIDENCE QUOTA MUST BE ON `n_effective`, NOT ON RECORD COUNT.** A quota expressed as «≥ *q* external records» is gameable; a quota expressed as «≥ *q* of `n_effective` must come from SC-1…SC-6» is not, because `n_effective` already collapses shared roots and shared instruments |

---

# §67. RECONSTRUCTED MEMORY

## 67.1 V3's fix, evaluated

**V3's defect→fix table: «Reconstructive memory → immutable event records + provenance + timestamps.»**

⚠️ **CONTRADICTION X1:** V3 lists **`timestamps`** as part of the fix, while COMM-INV-12 establishes that **a timestamp is never evidence**.

> ### **R67.1 (X1 RESOLVED).** *V3's INSTINCT was right and its INSTRUMENT was wrong.*
>
> **The defect** — reconstructive memory — is that a record is *rebuilt at recall* from a model rather than *replayed from a store*, so each recall differs from the last and from the original, and nothing records that it differed.
>
> **What the defect actually loses** is not «when it was written». It is:
> 1. **when the EVENT happened** ⟹ `event_interval`
> 2. **during what INTERVAL the claim holds** ⟹ `validity`
> 3. **in what CONTEXT it holds** ⟹ `context_scope`
>
> **A timestamp supplies none of the three** — it supplies only *when the record was written*, which is `write_epoch`, and which reconstructive memory does not lose.
>
> ⟹ **X1 DISSOLVES: replace `timestamps` with `event_interval` + `record_interval` + `validity` (Vol B §23.1's three-way split). The temporal information V3 wanted is retained; the timestamp V3 specified is replaced by the three intervals that actually do the work. **And COMM-INV-12 is not violated, because an interval used for SCOPING is not a timestamp used as EVIDENCE — the interval determines whether two claims conflict (CT-3's decidability), and never whether either is true (§23.3).***

## 67.2 The reconstruction contract

| Aspect | **Rule** |
|---|---|
| **Marking** | **`source_class = SC-11 RECONSTRUCTED`, ceiling E1** (§12.1). **⟹ An UNMARKED reconstruction is #36 (simulated event as observation) and R12.1's immutability is what makes marking non-optional: the class is set at ingestion and there is no operation to unset it** |
| **When reconstruction is legitimate** | **§38's recovery (replaying a log forward from a checkpoint) — and the recovered records carry their ORIGINAL `source_class`, because recovery replays rather than reconstructs. Reconstruction proper is legitimate when the original record was RC-1 EPHEMERAL and is being re-derived from a model, and the result is a NEW record with SC-11** |
| **Warrant** | **MEM-M2: `warrant(reconstruction) ≤ warrant(original)`, and `causal_depth += 1` per reconstruction generation** |
| **⟹ The compounding rule** | **A reconstruction of a reconstruction of a reconstruction has `causal_depth += 3` and warrant attenuated three times. **⟹ RECONSTRUCTION IS SELF-LIMITING BY DEPTH, and MEM-INV-14's saturation makes the limit safe: a saturated depth is maximally attenuated, never minimally**** |
| **⚠️ Prohibited** | ❌ **A reconstruction MUST NOT be stored at T2+ without external validation.** Cell §17.5's pattern applies: «audited, externally-validated semantic content may promote» |

---

# §68. MERGE & SPLIT SEMANTICS

## 68.1 Merge

**Vol B §31.2's G8 and Vol C §36.1's V-MERGE, with the semantic detail:**

```
MERGE(r₁ … rₖ) → r_new
  WARRANT      : ≤ MIN over rᵢ                          (R32.1, MEM-M2)
  SCOPE        : ⊆ ∩ over rᵢ                            (R32.2)
  n_effective  : ≤ MIN over rᵢ  **as a derived record**  (R32.4)
                 ⟵ **the CLAIM they support accumulates normally (§21.3,
                    Vol B R32.4's distinction between a claim's support and
                    a derived record's warrant)**
  inbreeding_F : ≥ MAX over rᵢ                           (R32.3, MEM-M4)
  evidence_status : ≤ MIN over rᵢ
  source_class : the WEAKEST contributor's class          (R12.3)
  PARENTS      : **ALL RETAINED as SUPERSEDED-by-merge. NEVER DELETED**
                 (MEM-INV-06, §35.4)
  instance_refs: **MANDATORY. A merged record without its parents' refs is
                 not retrievable as support (R32.4, §29.2 SC-4)**
  AUTHORITY    : **Memory Service executes; Memory Authority approves
                 (Vol A §8.1)**

⚠️ **THE MERGE THAT MUST NEVER HAPPEN:** merging records with DIFFERENT
   `root_commit`s into one record with ONE root. **That is provenance
   laundering in a single operation: k independent observations become one
   observation with k-fold apparent support.**
   ⟹ **R68.1: A MERGE PRODUCES A `root_commit` THAT IS A MERKLE COMMITMENT
      OVER THE UNION OF THE PARENTS' ROOT SETS. The merged record's root
      RESOLVES TO ALL k parent roots, so dim 1 still sees them as k distinct
      roots and `n_effective` still collapses correctly if any of them share
      an ancestor. ⟹ MERGING MUST NOT HIDE ROOTS.**
```

## 68.2 Split

```
SPLIT(r) → r₁ … rₖ
  WARRANT      : **DIVIDED, NEVER DUPLICATED: Σ warrant(rⱼ) ≤ warrant(r)**
  n_effective  : **Σ n_effective(rⱼ) ≤ n_effective(r)** (Vol C §36.1)
  SCOPE        : each rⱼ ⊆ r's scope, and ∪ rⱼ's scopes ⊆ r's scope
  PARENT       : **RETAINED as SUPERSEDED-by-split**
  WHEN         : **a scope error is discovered — r asserted more broadly than
                 its evidence supports (Vol B §24.3's context inflation,
                 detected after the fact)**
  AUTHORITY    : Memory Service executes; Memory Authority approves

⟹ **R68.2: SPLIT IS THE CORRECTION OPERATION FOR AN OVER-BROAD CLAIM, AND IT
   IS THE ONLY OPERATION IN THE ARCHITECTURE THAT REDUCES TOTAL WARRANT.**
   Every other operation is warrant-non-increasing per record; split is
   warrant-non-increasing in AGGREGATE, because it takes one claim's support
   and distributes it among several narrower claims, each of which now has
   less than the whole.
   **⟹ THIS IS CORRECT AND IT IS WHY SPLIT IS ADMISSIBLE: an over-broad claim
   should not get to keep its full support when it is narrowed into pieces.**
```

---

# §69. ABSTRACTION HIERARCHIES

## 69.1 The question: may memory store summaries of summaries?

```
YES, AND THE BOUND IS THE SAME AT EVERY LEVEL:

  L0  records           (episodes, observations)
  L1  summaries         (consolidations of L0)          warrant ≤ MIN(L0s)
  L2  summaries of L1   (generalizations of summaries)  warrant ≤ MIN(L1s)
                                                            ≤ MIN(MIN(L0s))
  L3  …                 **warrant ≤ MIN over the whole subtree**

⟹ **R69.1 (THE ABSTRACTION MONOTONICITY RULE).** *At every level of
   abstraction, `warrant ≤ MIN` over the level below, `scope ⊆ ∩` over the
   level below, `inbreeding_F ≥ MAX`, and `source_class` = the weakest
   contributor. **⟹ WARRANT IS MONOTONE NON-INCREASING UP THE ABSTRACTION
   HIERARCHY, WITHOUT BOUND ON THE NUMBER OF LEVELS.***

   **THE CONSEQUENCE, AND IT IS THE WHOLE POINT: an abstraction hierarchy of
   depth *d* has warrant ≤ (MIN over all leaves). ⟹ A HIGHLY ABSTRACT
   REPRESENTATION IS NECESSARILY WEAKLY WARRANTED, AND NO NUMBER OF
   ABSTRACTION LEVELS CAN MAKE IT STRONG.**

⟹ **AND WHY THIS DEFEATS §1's LOOP AT ITS MOST SOPHISTICATED:** the loop's
   most dangerous form is not repetition — it is ABSTRACTION. Take many
   observations, summarize them, summarize the summaries, and the top-level
   summary reads as a law. **R69.1 makes the top-level summary the WEAKEST
   record in the hierarchy, not the strongest.**

⚠️ **THE ONE ESCAPE, AND IT IS EXTERNAL:** a top-level abstraction can be
   GROUNDED (E4) if EVA measures agreement with an L0–L3 ground-truth claim
   ABOUT THE ABSTRACTION. **⟹ The abstraction's warrant then comes from the
   measurement, not from the hierarchy — which is R0.2's admission principle
   one more time, and it is the only path by which an abstract representation
   becomes strong.**
```

## 69.2 The depth bound

| Concern | **Rule** |
|---|---|
| **Is there a maximum abstraction depth?** | **⚠️ NO MAXIMUM IS IMPOSED, AND NONE IS NEEDED.** R69.1's monotonicity means depth *d* has warrant ≤ MIN over all leaves, so deep hierarchies are automatically inert. **⟹ §99 refuses to invent a depth parameter, because a bound here would be false precision: the monotonicity already does the work** |
| **Is there a storage cost?** | **Yes — `O(levels × nodes)`. Bounded by the storage budget and the KC-3 consolidation-rate ceiling (§9.1)** |
| **Is there a retrieval cost?** | **Vol A §16.2: the claim graph is BOUNDED-DEPTH at query time, `[G]`-declared. Full-hierarchy traversal is off-line (§95)** |
| **⟹ The asymmetry** | **Abstraction depth is UNBOUNDED for storage and BOUNDED for query. ⟹ A deep hierarchy is storable and is not traversable at runtime — which is exactly right, because runtime queries need local answers and hierarchy analysis is an evaluator-side question** |

---

# §70. MEMORY OF MEMORY (META-MEMORY)

## 70.1 What the system needs to know about its own memory

**This is the memory-side of O38 (meta-knowledge), whose full model is Vol F §82.**

| Meta-question | **Answerable?** | **By what** | **Cost** |
|---|---|---|---|
| **«Do I have a record about X?»** | ✅ | Retrieval (§25) — and §25.3's four empty-result reasons distinguish «no» from «couldn't look» | `O(log n)` |
| **«How much do I know about X?»** | ✅ | `n_effective(X)` + `|support_refs|` + the tier distribution | `O(k)` |
| **«How reliable is my knowledge of X?»** | ✅ | `evidence_status`, `gt_class`, `calib_ref`, `inbreeding_F`, `revalidation_state` — **the §18.1 sufficient statistics, all of them** | `O(1)` |
| **«What have I forgotten about X?»** | ⚠️ **PARTIALLY** | **Vol C §34.7: the COUNT and ROOTS are recoverable from epoch digests; the CONTENT is not** | `O(R)` |
| **«Am I biased about X?»** | ⚠️ **PARTIALLY** | **§28.1's MEM-D1…D6, all `O(R)` aggregates. Systematic bias: detectable. Occasional or inherited bias: not** | `O(R)`/epoch |
| **«Is my knowledge of X self-referential?»** | ⚠️ **PROVENANCE: YES. SEMANTICS: NO** | **`inbreeding_F` and `causal_depth` answer the provenance question. ⟵ ⚠️ THE `[U]` RESIDUE (FM-4, L-10, OR-M1): semantic self-reference has no measure** | `O(1)` / **∞** |
| **«What could I know about X that I don't?»** | ❌ **NO** | **§39.3: unknown-unknowns are not enumerable from inside** | — |
| **«How has my knowledge of X changed?»** | ✅ | **The belief-state history (R17.4 property 3) + the version chain (§36)** | `O(history)` |
| **«Whose knowledge is this?»** | ✅ | `src_identity` (derived), `lineage_ref`, `source_class` | `O(1)` |
| **«May I act on my knowledge of X?»** | ✅ | **`KNOWS(X)` (Vol A R4.1) + `revalidation_state` + `inbreeding_F ≤ F_max` + P0-02 R20.1's anchoring requirement** | `O(1)` |

## 70.2 The meta-memory prohibition

> ### **R70.1 (META-MEMORY IS COMPUTED, NEVER STORED — AND THE REASON IS THE SAME AS VOL A R4.1's).** *Every answer in §70.1's table is computed on read from the record corpus. **None is stored as a field.***
>
> **Why: a stored meta-memory is a claim about the corpus made by the corpus's owner.** If a subject stores «I know a lot about X», that is a self-declared quantity, and R40.1 makes every epistemic field externally written. **⟹ Meta-memory is the same four-axis discipline applied one level up: the meta-answers are DERIVED, their inputs are EXTERNAL, and there is no meta-field for a subject to inflate.**
>
> **⚠️ AND THE ONE EXCEPTION, WHICH IS NOT AN EXCEPTION: `inbreeding_F` IS stored — but it is stored BY THE ANCHOR and is read-only to every subject (Vol A §5.1). It is a meta-quantity with an external writer, which is exactly the pattern.**

---

# §71. CORRECTNESS — THE FOUR WAYS A MEMORY CAN BE WRONG

## 71.1 «Can the record be wrong in a *detectable* way?» (Vol A §2.2's K2)

> ### **R71.1 (THE FOUR ORTHOGONAL WRONGNESS AXES).** *A memory record can be wrong in four independent ways, and each has a different detector, a different authority, and a different repair path. **Conflating them is what makes a memory system unauditable.***

| Axis | **What is wrong** | **Detector** | **Repair** | **⚠️ Undetectable case** |
|---|---|---|---|---|
| **W-1 FIDELITY** | **The record does not match what was observed** — corruption, fabrication, alteration | **§37's checkpoint Merkle root; SP-1's immutability; FM-2's root resolution** | V-CORRECTION (§36.1) | **A record that was faithfully stored from a faithfully-reported FABRICATION — i.e. the source lied. ⟹ SP-2 covers forged roots; a subject reporting a false observation with a genuine root is ⚠️ OR-M10** |
| **W-2 ATTRIBUTION** | **The record is genuine but is attributed to the wrong source, time, or context** | **`src_identity` derived from channel binding (COMM-INV-09); `write_epoch`; `context_scope` mandatory** | V-CORRECTION | **⚠️ R41.1: provenance laundering is detectable ONLY IF the Anchor's root registry commits to a CONTENT DIGEST, not only to an identity. §96 requires this** |
| **W-3 SCOPE** | **The record is correct but is applied outside its context or validity** | **Vol B §24.2 R24.2's retrieval filter; §23.2's interval algebra; CT-3/CT-4's decidability** | **Not a repair — a REJECTION. A record retrieved outside scope is a MALFORMED RESULT and is not returned** | **⚠️ A record whose `context_scope` UNDER-declares its true scope is retrieved too narrowly — a false negative, which is safe. A record that OVER-declares is retrieved too broadly, and **over-declaration is detectable only when the over-broad application fails** (§24.3's context inflation, and R32.2's ∩ rule prevents it at generalization)** |
| **W-4 WARRANT** | **The record is correct, well-attributed, and in scope, but is treated as more warranted than it is** | **MEM-M2's monotonicity; R12.2's ceiling; R69.1's abstraction monotonicity; §18.3's calibration** | **Warrant recomputation by the READER (COMM-INV-03) — the record is not repaired; the reader's derivation is** | **⚠️ ⟵ THIS IS R1.1's HARDEST FAILURE: «a coherently wrong belief with valid provenance». W-1…W-3 all pass, and W-4 cannot be detected without an L0–L3 measurement that may not exist. **R18.4: a domain with no GT supply is permanently uncalibratable. §100 OR-M4**** |

## 71.2 The detectability verdict

```
  W-1 FIDELITY     ✅ DETECTABLE — Merkle root, immutability, FM-2
  W-2 ATTRIBUTION  ✅ DETECTABLE — derived identity, mandatory context,
                      **conditional on R41.1's content-digest commitment**
  W-3 SCOPE        ✅ DETECTABLE AT RETRIEVAL — the filter rejects; the
                      interval algebra decides CT-3/CT-4
  W-4 WARRANT      ⚠️ **PARTIALLY DETECTABLE. Detectable when an L0–L3
                      measurement exists. UNDETECTABLE when it does not.**

⟹ **R71.2 (THE HONEST VERDICT, AND IT IS THE PACKAGE'S CENTRAL LIMIT).**
   *Three of four wrongness axes are structurally detectable. The fourth is
   detectable only where external ground truth is supplied, and there is no
   mechanism — and no possible mechanism — by which a system detects that its
   warranted beliefs are wrong in a domain where nothing external has ever
   measured them.*

   **⟹ THIS IS WHY THE STANDARD IS NOT «the system always knows the truth».
      IT IS «the system never silently converts an internally generated
      representation into externally warranted truth merely because it was
      remembered, repeated, retrieved, compressed, or widely propagated» —
      and W-1…W-3's detectability plus W-4's ceiling structure (R12.2: SC-7
      caps at E3, so an internal belief can NEVER reach GROUNDED without an
      external measurement) together SATISFY that standard even in the
      undetectable case.**

   **⟹ THE KEY INSIGHT, AND IT IS WHY THE STANDARD IS ACHIEVABLE WHILE TRUTH
      IS NOT: the architecture does not need to DETECT that a coherently
      wrong belief is wrong. It needs to ensure that such a belief can never
      be MARKED as externally warranted. **R12.2's ceiling does that, and it
      does it without detecting anything.** A coherently wrong belief is
      permanent, well-provenanced, admissible at E3 — and permanently unable
      to become GROUNDED from inside. §104's ratings reflect exactly this:
      PROVENANCE PASS, EVIDENCE-INDEPENDENCE PARTIAL.**
```

---

# §72. ATTACK CATALOGUE — **OUTPUT 41**

## 72.1 The catalogue — 56 attacks in nine families

**Legend:** ✅ **CLOSED** (structurally impossible) · ⚠️ **BOUNDED** (possible, rate/extent-limited) · 🔍 **DETECTABLE** (possible, observable after the fact) · ❌ **OPEN** (possible, not preventable, not reliably detectable)

### FAMILY 1 — INJECTION & FABRICATION (attacks on ingestion)

| # | Attack | **Mechanism** | **Defense** | **Disp.** |
|---|---|---|---|---|
| **1** | **False-memory injection** | Fabricated content into a persistent tier | Vol A §11.3: [2] unresolvable root ⟹ UNANCHORED ⟹ R20.1. **FM-1: «LOW for promotion, MEDIUM for local influence»** | ⚠️ **CLOSED for promotion; BOUNDED for local T0 influence** |
| **2** | **Provenance forgery** | Invented root hash | **FM-2: «Roots must resolve in the Anchor. An invented hash does not resolve ⇒ rejection + `E_PROVENANCE` + immune report. Roots are appended by the Anchor, not by cells»** | ✅ **CLOSED** |
| **3** | **Provenance laundering** | Genuine root, misattributed content | **⚠️ R41.1: requires the Anchor's root registry to commit to a CONTENT DIGEST** | ✅ **CLOSED IF R41.1; §96 tests it** |
| **4** | **Tier jumping** | An E0 record placed at T2+ | **R0.2: `storage_tier` is DERIVED from `evidence_status`, not independently writable** | ✅ **CLOSED** |
| **5** | **Gate bypass** | Self-assigned `evidence_status` | **R40.1: `evidence_status` is EXTERNAL. The subject proposes; the gate assigns** | ✅ **CLOSED** |
| **6** | **Malformed-record flooding** | Force validator budget exhaustion | Rate limit + KC-3 write-rate ceiling | ⚠️ **BOUNDED** |
| **7** | **Source impersonation** | Declared `source` field forged | **`src_identity` DERIVED from channel binding (COMM-INV-09), never declared. Vol A §5.1** | ✅ **CLOSED** |
| **8** | **History rewriting (in place)** | Alter a stored record | **MEM-INV-06: no modify authority for anyone, including KC. SP-1** | ✅ **CLOSED — no operation exists** |
| **9** | **History rewriting (by deletion)** | Remove a record | **R35.1: anchored records cannot be deleted; §35.4's survival list; permanent physical delete is KC-2 and is itself anchored** | ✅ **CLOSED** |
| **10** | **Supersession flooding** | Bury the original under versions | **MEM-INV-17: superseded records remain AUDIT-readable; write-rate ceiling** | ⚠️ **BOUNDED** |
| **11** | **Retroactive reinterpretation** | Keep the record, change its meaning | **Vol C §42.1 RW-4: bounded by R32.1–R32.4 — a reinterpretation cannot be stronger or broader than what it reinterprets** | ⚠️ **BOUNDED** |
| **12** | **Semantic collision** | Content engineered to hash to an existing key | **Vol A §15.2 D-1: identical content + different roots ⟹ TWO records, linked, never merged** | ✅ **CLOSED** |
| **13** | **Context stripping** | Store a record without its context | **`context_scope` MANDATORY; a record without it is MALFORMED, rejected at step [1]** | ✅ **CLOSED** |
| **14** | **Temporal stripping** | Store a record without its intervals | **`validity` MANDATORY; `event_interval`/`record_interval` split (§23.1)** | ✅ **CLOSED** |

### FAMILY 2 — FALSE EVIDENCE MULTIPLICATION

| # | Attack | **Mechanism** | **Defense** | **Disp.** |
|---|---|---|---|---|
| **15** | **Self-citation** | A record cites itself as support | **`inbreeding_F` counts ancestry terminating in the subject; `F > F_max ⟹ S6 abstain` (FM-4)** | ✅ **CLOSED** |
| **16** | **Contradiction suppression** | Prevent detection | **Vol B §20.5: the detector runs in the Memory Service at ingestion, not in the subject** | ✅ **CLOSED for detection** |
| **17** | **Contradiction avoidance** | Never write the contradicting record | **MEM-D1 (§28.1 B-5) + P0-03 R67.1: a zero-contradiction rate above a `[G]` duration is an immune incident** | 🔍 **DETECTABLE IF SYSTEMATIC** |
| **18** | **Circular corroboration** | A corroborates B, B corroborates A | **Dim 1/2 collapse: shared root or shared lineage. `n_effective` collapses to 1** | ✅ **CLOSED** |
| **19** | **Self-reinforcing false belief** | Retrieve → believe → store → retrieve | **MEM-INV-09 (retrieval writes nothing) + SC-12's ceiling + `n_obs += 0` + `causal_depth += 1`** | ✅ **CLOSED** |
| **20** | **Repetition as corroboration** | Re-emit the same content *n* times | **Vol A §10.3's four-point closure; Vol B R30.1** | ✅ **CLOSED** |
| **21** | **Consensus as ground truth** | Internal agreement treated as fact | **§12 SC-14: `INTERNAL_CONSENSUS` ceiling **E0, PERMANENTLY**. P0-01 R8.1: L7 MUST NEVER be ground truth** | ✅ **CLOSED** |
| **22** | **Correlation laundering via memory** | A → B → memory → C → memory → D, three "independent" records | **Vol A §10.3 + Vol B §21.4: shared `root_commit`, rising `causal_depth`, `n_obs += 0`** | ✅ **CLOSED** |
| **23** | **Root-registry roll-off** | Cite a root that has aged out of the online registry | **Vol C §42.3 R42.3: an unresolvable root ⟹ UNANCHORED ⟹ R20.1. Off-line re-resolution against W4/W5** | ⚠️ **BOUNDED — and §56.3 declares the finite epistemic horizon at S-5** |
| **24** | **Quota gaming** | Cite one external record across many consolidations | **Vol D §66.2 R66.2: the external-evidence quota MUST be on `n_effective`, not on record count. MEM-D3 detects it** | ✅ **CLOSED by R66.2** |
| **25** | **⚠️ Dim-6 shared latent assumption** | *k* genuinely distinct roots sharing an unexamined assumption | **Vol B §21.2 R21.1's four mitigations: instrument-CLASS diversity, `gt_class` diversity, R4.3's `M_ℰ` prohibition — **and none of them detects an assumption shared by the task specification itself**** | ❌ **OPEN — the program-level limit, fourth appearance** |

### FAMILY 3 — MASQUERADING (`source_class` attacks)

| # | Attack | **Mechanism** | **Defense** | **Disp.** |
|---|---|---|---|---|
| **26** | **Unmarked reconstruction** | A re-derived record presented as the original | **SC-11 marking is mandatory and immutable (R12.1); §67.2's compounding attenuation** | ✅ **CLOSED** |
| **27** | **Reconstruction chain** | Reconstruct a reconstruction repeatedly | **MEM-INV-14's saturation makes depth monotone; MEM-M2 attenuates per generation** | ✅ **CLOSED — self-limiting** |
| **28** | **Cache-as-fresh** | A cache hit presented as a fresh read | **Vol A R6.1: `from_cache: true`; `message_type` is RELAY/AGGREGATE_SUMMARY, **never ASSERT**; R18.3's `CAP_CACHED < CAP_FRESH`** | ✅ **CLOSED** |
| **29** | **Retrieval-as-observation** | A retrieved record re-emitted as a new observation | **Vol B §21.4: `source_class = SC-12`, `src_identity` = the re-emitter, `origin_ref` = the original asserter — **BOTH recorded, never conflated**** | ✅ **CLOSED** |
| **30** | **Memory flooding** | Overwhelm the store | KC-3 write-rate ceiling; rate limit at step [1] | ⚠️ **BOUNDED** |
| **31** | **Protection-tag flood** | Exhaust `PROTECTED_FRACTION_MAX` | **Vol C R34.4: protection-request RATE is a KC-3 ceiling; sustained excess is an immune incident** | ⚠️ **BOUNDED** |
| **32** | **Index poisoning** | Corrupt a view so records are unfindable | **R25.2: index failure is never record failure; MEM-D5 detects a falling reachable fraction and forces a rebuild** | ✅ **CLOSED** |
| **33** | **Ranking manipulation** | Bias the learned retrieval function | **§26.2 S-2's triple return; §27.2's six prohibited signals** | ⚠️ **BOUNDED IN EFFECT — §26.3's residue: it can change what is CONSIDERED** |
| **34** | **Dedup oracle probing** | Hash candidate contents to discover what is stored | **Vol C §52.3 R52.2: compartment check runs BEFORE dedup and before any index lookup** | ✅ **CLOSED BY ORDERING** |
| **35** | **Existence disclosure** | Infer existence from differential empty-result reasons | **R52.4: an unauthorized requester receives `DECLINED_COMPARTMENT` and nothing else** | ✅ **CLOSED** |
| **36** | **Simulated event as observation** | An SC-9 record presented as SC-2 | **R12.1 immutability + R12.2's E1 ceiling + R66.1** | ✅ **CLOSED** |
| **37** | **Counterfactual as observation** | An SC-10 record presented as observed | **R12.1 + R65.1's E0 ceiling + R65.2's instance-ref exclusion** | ✅ **CLOSED** |
| **38** | **Learned rule as observation** | A learned generalization presented as measured | **R12.1 + R12.2's SC-7 E3 ceiling + LF-2's four defenses (§44.2)** | ✅ **CLOSED** |
| **39** | **Prediction as observation** | An unresolved SC-8 presented as confirmed | **R62.1's mandatory three-way outcome; **P0-01 R9.2: unresolved past deadline is a CALIBRATION FAILURE, never a confirmation and never neutral**** | ✅ **CLOSED** |
| **40** | **Inference as observation** | An SC-7 presented as SC-2 | **R12.1. ⟵ ⚠️ AND THE RESIDUE: R12.1 blocks RE-classification. It does not block MIS-classification at the source, which is #41** | ✅ **CLOSED for re-classification** |
| **41** | **⚠️ Source mis-declaration at origin** | **A subject declares SC-2 for what is actually SC-7** | **(a) `src_identity` is derived, so the asserter is known; (b) repeated SC-2 assertions that fail E4 grounding ⟹ calibration failure ⟹ «reduce trust in that cell, route verification elsewhere» (V3.1 §4); (c) MEM-D4 detects a `source_class`/`gt_class` distribution divergence** | 🔍 **DETECTABLE, NOT PREVENTABLE — §100 OR-M10** |
| **42** | **Stale-policy memory** | A belief formed under retracted policy P₁ cited under P₂ | **Vol C §42.2's five inherited mechanisms: `policy_version_ref` + `VOID_UNDER` + the `VOID` belief state + `VOID_ONE` + `context_scope.policy_version`. **Plus R42.2: VOID propagates along `derived_from` as a WARRANT REDUCTION**** | ✅ **CLOSED** |

### FAMILY 4 — PROMOTION & CONSOLIDATION

| # | Attack | **Mechanism** | **Defense** | **Disp.** |
|---|---|---|---|---|
| **43** | **Consolidation self-justification** | A consolidated record cites its own sources as independent | **MEM-M3: `n_effective(derived) ≤ n_effective(sources)`; MEM-M4: `inbreeding_F ≥ max`** | ✅ **CLOSED** |
| **44** | **Generalization scope creep** | A rule's scope widens across contexts | **R32.2: `scope ⊆ ∩ instances`. **NO OPERATION WIDENS A SCOPE** (§24.3)** | ✅ **CLOSED** |
| **45** | **Generalization certainty inflation** | 40 weak instances ⟹ one strong rule | **Vol B §32.2: R32.1's MIN warrant + R32.4's MIN `n_effective` **as a derived record**, with the CLAIM accumulating support normally** | ✅ **CLOSED** |
| **46** | **Abstraction laundering** | Summarize summaries until the top reads as a law | **R69.1: warrant is monotone non-increasing UP the hierarchy, unbounded in depth** | ✅ **CLOSED** |
| **47** | **Consolidation to T4 without grounding** | Reach the CONSOLIDATED tier internally | **Vol B R31.1: consolidation alone cannot reach T4; T4 requires E4, which requires an L0–L3 measurement** | ✅ **CLOSED** |
| **48** | **Catastrophic forgetting** | A learning update destroys retained capability | **§34.5: episodic replay + `capability_critical` protection (Cell R10.6) + T7's `plasticity_mult` DOWN + R34.6's mutual guarantee** | ⚠️ **BOUNDED** |
| **49** | **Sole-support eviction** | Evict the only instance supporting a rare claim | **R46.3: retrieval frequency MUST NOT be an input to the retention of a sole-support record (Task 3 Rule 15)** | ✅ **CLOSED** |
| **50** | **Merge as root-hiding** | Merge *k* records with distinct roots into one root | **R68.1: a merge's `root_commit` is a Merkle commitment over the UNION of the parents' root sets — **merging must not hide roots**** | ✅ **CLOSED** |

### FAMILY 5 — COMPRESSION & LOSS

| # | Attack | **Mechanism** | **Defense** | **Disp.** |
|---|---|---|---|---|
| **51** | **Qualifier loss** | «7 of 10 in task A» ⟹ «succeeds» | **R33.1: compression operates ONLY on the payload; the epistemic dimension is `O(1)` and is not compressed** | ✅ **CLOSED** |
| **52** | **Scope loss** | `context_scope` dropped as metadata | **`context_scope` MANDATORY; compression that removes it produces a MALFORMED record** | ✅ **CLOSED** |
| **53** | **Root loss** | The evidence enumeration dropped without a commitment | **DP-1 (Vol A §14.1): a record that has lost DP-1 is UNANCHORED, and R20.1 applies** | ✅ **CLOSED** |
| **54** | **Contradiction loss** | One side of a contradiction compressed away | **Vol B §33.2 OC-4: `ContradictionRecord`s are audit-tier, append-only, NOT compressible below L1** | ✅ **CLOSED** |
| **55** | **⚠️ Survivorship narrowing** | Forgetting makes the corpus artificially coherent | **Vol C §34.7: the COUNT and ROOTS survive permanently in the epoch digests; the CONTENT does not. Deletion AUTHORITY and REASON are permanent (§35.4), so *unauthorized* narrowing is detectable** | 🔍 **PARTIAL — authorized-but-self-serving narrowing is NOT detectable. §100 OR-M7** |

### FAMILY 6 — SERVICE & AUTHORITY

| # | Attack | **Mechanism** | **Defense** | **Disp.** |
|---|---|---|---|---|
| **56** | **⚠️ Differential serving** | A compromised Memory Service serves `r` to X and declines it to Y | **Vol C §40.4 R40.2: declines are logged; `purpose_class` filters are policy-declared and auditable; a divergence between readers' received distributions is detectable at `O(R)` (§28.1's pattern). **⟹ But a PLAUSIBLE decline — citing budget, staleness, or scope — is not detected**** | ❌ **OPEN within an epoch — §100 OR-M9** |
| **57** | **Memory as second governance authority** | The Memory Service decides what is true or what may be done | **Vol A R8.1's four prohibitions; Vol C §43.1 R43.1** | ✅ **CLOSED** |
| **58** | **Cell-writes-protected-memory (Cell's Attack F)** | «a cell that can write protected memory can rewrite the organism's past» | **Vol A §6.2's T5 relocation: «a cell must never hold protected memory»; §8.1: T5 create is ⚠️ Memory-Authority-proposes + ✅ KC-2-authorizes + ✅ Anchor-anchors** | ✅ **CLOSED** |
| **59** | **Cell-plastic memory policy (X-M1)** | A cell raises its own `θ_write` and stops recording failures | **Vol A §8.3: REJECTED. Memory policy is POLICY (RO-13), OP-owned. A cell may vary utilisation and local eviction ORDER only** | ✅ **CLOSED** |
| **60** | **Heritable memory-policy relaxation (X-M2)** | Selection finds lineages that forget their failures | **Vol C §46.1 R46.1: retention BOUNDS are policy; retention PARAMETERS within bounds are heritable. **Plus R46.4: consistency of the retained corpus MUST NOT be a selection criterion**** | ✅ **CLOSED** |

### FAMILY 7 — SELF-REFERENCE

| # | Attack | **Mechanism** | **Defense** | **Disp.** |
|---|---|---|---|---|
| **61** | **Self-confirming recall (FM-4)** | Query own memory, retrieve own belief, treat as confirmation | **Vol C §48.2's four defenses: `n_obs += 0` · SC-12's ceiling · `inbreeding_F`↑ ⟹ S6 abstain · `causal_depth`↑. **⟹ THE ATTACK IS SELF-DEFEATING: performing it moves the subject toward abstention**** | ✅ **CLOSED for provenance self-reference** |
| **62** | **❌ Semantic self-reference** | **A closed circle of records in which each term is defined by the others — with distinct roots, distinct instruments, low `inbreeding_F`, dim-1..5 disjoint** | **⟵ ⚠️ FM-4's `[U]` RESIDUE, INHERITED VERBATIM: «Bounding this requires a measure of *semantic* self-reference, not just provenance-graph depth. **No rigorous mechanism is proposed here.**» Vol A §5.1 declares `semantic_self_reference_score` as `[U]`; §29.1's L-10; §81 analyses it** | ❌ **OPEN — §100 OR-M1, P0-04'S PRINCIPAL UNCLOSED DEPENDENCY** |
| **63** | **Self-model as belief store** | A subject validates itself from its own self-model | **Vol C §48.1: the self-model is cell-local, bounded, and «is NOT a belief store»; V3.1 §4's «retrieval confidence» is REJECTED as self-declared and RETAINED only as a `calib_ref` reference** | ✅ **CLOSED** |
| **64** | **Agent-model self-reading** | A subject reads the organism's model of itself and optimizes for it | **R59.2: an agent model is in the MODELER's compartment, never the modeled subject's. ⚠️ Residue: inference from treatment is possible and unavoidable (OR-M15)** | ✅ **CLOSED for reading; ⚠️ OPEN for inference** |
| **65** | **Model self-evaluation** | `M_ℰ` used as an evaluation input | **P0-01 R4.3: PROHIBITED. R64.2: a model's warrant comes from its outputs' agreement with EXTERNAL outcomes** | ✅ **CLOSED** |

### FAMILY 8 — TEMPORAL & CONTEXTUAL

| # | Attack | **Mechanism** | **Defense** | **Disp.** |
|---|---|---|---|---|
| **66** | **Timestamp-as-truth** | «Recently verified ⟹ still true» | **Vol A §5.1: `last_verification` PROHIBITED as a truth indicator; replaced by `validity` + `revalidation_state`. COMM-INV-12** | ✅ **CLOSED** |
| **67** | **Phantom temporal contradiction** | A change over time reported as an inconsistency | **Vol B §23.2: CT-3 is decidable via interval algebra; disjoint intervals ⟹ `BOTH_VALID_IN_DISJOINT_INTERVALS`, no belief change. **⟵ Requires the `event_interval`/`record_interval` split (§23.1)**** | ✅ **CLOSED** |
| **68** | **Context collapse** | A record scoped to *C₁* retrieved in *C₂* | **Vol B R24.2: a record whose scope does not subsume the query context is a MALFORMED RESULT and is NOT returned. **Context is a FILTER, never a RANKING SIGNAL**** | ✅ **CLOSED** |
| **69** | **Undeclared-scope universalization** | A record with no declared scope treated as universal | **Vol B R24.2: **UNKNOWN ≠ DISJOINT** (P0-03 R37.1). An undeclared scope returns `SCOPE_UNKNOWN_ON(dim)` and the reader's warrant computation treats unknown as a REDUCTION, never as a match** | ✅ **CLOSED** |
| **70** | **Cross-epoch semantic drift** | The same term meaning different things across epochs | **§60.1 DR-2 + R60.1's scoping mitigation** | ⚠️ **BOUNDED — undetectable in principle (CT-6)** |

### FAMILY 9 — DISTRIBUTED & RECOVERY

| # | Attack | **Mechanism** | **Defense** | **Disp.** |
|---|---|---|---|---|
| **71** | **Replica divergence with content alteration** | Two replicas hold different content for one `mem_id` | **Vol C §54.3: the anchored root decides; the mismatching replica is FD, and FZ if witnesses < `W_min`** | ✅ **CLOSED** |
| **72** | **Split-brain on a procedural record** | Two regions execute different versions of the same skill | **§55: T3 is the ONLY class requiring STRONG consistency; per-procedure serialization; a region that cannot reach the service STALLS rather than diverges (RO-01)** | ✅ **CLOSED** |
| **73** | **Belief-state forced agreement** | Reconciling divergent belief states by vote | **§54.3: **NEVER VOTE.** Divergent belief states are LEGITIMATE (R54.1 argument 2). P0-03's rule: UNION for append-only, RE-EVALUATE for derived** | ✅ **CLOSED** |
| **74** | **Recovery-time belief reconstruction** | Re-derive beliefs from surviving evidence after a crash | **Vol C R38.1 prohibition 1: recovery MUST NOT reconstruct beliefs. A lost chain ⟹ `UNKNOWN`** | ✅ **CLOSED** |
| **75** | **Recovery-time contradiction resolution** | Resolve open contradictions during recovery | **R38.1 prohibition 3: open `ContradictionRecord`s are recovered in their recovered state, including `UNRESOLVED`. **«A crash is not a deadline»**** | ✅ **CLOSED** |
| **76** | **Gap-filling by inference** | Infer missing records during recovery | **R38.1 prohibition 4 + P0-01 R9.1: a missing record is `UNKNOWN`, recorded as such. **§39: absence is never negation**** | ✅ **CLOSED** |
| **77** | **Thin-witness forgery** | Forge history when the witness set is below `W_min` | **P0-02 §20.4's ladder: FD → reduced witness count to `W_min` → FZ(evolution only). **«History must keep being written; but a thin witness set is forgeable»** — and W5 is outside operational control** | ⚠️ **BOUNDED — the lie-window is one epoch (§37.2)** |
| **78** | **Compromised KC authorizing deletion** | A-5 (§40.3) | **⟵ ⚠️ THE WORST CASE. A compromised KC CAN authorize a deletion. **It CANNOT make the deletion unrecorded: the authorization is itself anchored, and W5 is outside operational control.** P0-02 §6.1 item 19: a single internal copy of history is «the classic error»** | ⚠️ **BOUNDED — the ACT is possible; the CONCEALMENT is not** |

## 72.2 The disposition summary

| Disposition | **Count** | **Attacks** |
|---|---|---|
| ✅ **CLOSED (structurally impossible)** | **58** | 2, 4, 5, 7, 8, 9, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 24, 26, 27, 28, 29, 32, 34, 35, 36, 37, 38, 39, 40, 42, 43, 44, 45, 46, 47, 49, 50, 51, 52, 53, 54, 57, 58, 59, 60, 61, 63, 65, 66, 67, 68, 69, 71, 72, 73, 74, 75, 76 |
| ✅ **CLOSED — CONDITIONAL** | **2** | **#3** provenance laundering — *closed **iff** R41.1 holds: the Anchor's root registry commits to a CONTENT DIGEST, not only to an identity. **⟹ A new requirement this package imposes upstream on P0-02 (gap G-M-P0-5).** If the registry commits only to identities, #3 is OPEN* · **#64** agent-model self-reading — *closed for READING (R59.2's compartment rule); ⚠️ OPEN for INFERENCE-FROM-TREATMENT, which is unavoidable without making the model ineffective (OR-M15)* |
| ⚠️ **BOUNDED (possible, rate/extent-limited)** | **12** | **1** *(split: CLOSED for promotion, BOUNDED for local T0 influence — FM-1)* · 6 · 10 · 11 · 23 · 30 · 31 · 33 · 48 · 70 · 77 · 78 |
| 🔍 **DETECTABLE (observable after the fact)** | **3** | **17** contradiction avoidance *(MEM-D1; systematic only)* · **41** source mis-declaration at origin *(OR-M10)* · **55** survivorship narrowing *(partial — counts and roots recoverable, content not; OR-M7)* |
| ❌ **OPEN** | **3** | **25** dim-6 shared latent assumption · **56** differential serving within an epoch · **62** semantic self-reference |
| **TOTAL** | **78** | **58 + 2 + 12 + 3 + 3 = 78 ✓** |

**R72.0 (HOW TO READ THE COUNTS).** *Sixty rows carry a ✅, of which **two are conditional** and are separated out because a conditional closure is not a closure — it is a closure **plus a requirement imposed on another package**. Twelve rows carry a ⚠️, of which **#1 is a split disposition**: false-memory injection is structurally closed for PROMOTION (an unresolvable root cannot enter a persistent tier) and bounded for LOCAL T0 INFLUENCE (FM-1: «a fabricated item *can* affect the cell's own θ before detection»). Both halves are stated rather than averaged into one tag.*

**R72.1 (THE THREE OPEN ATTACKS ARE NOT THREE PROBLEMS — THEY ARE ONE PROBLEM, THREE TIMES).**

```
  #25  dim-6 shared latent assumption
  #56  differential serving by a compromised service
  #62  semantic self-reference

  **IN ALL THREE, THE MECHANISM IS INSIDE THE THING BEING AUDITED:**
    #25 — the assumption is shared by the instrument that would detect it
    #56 — the serving is controlled by the service that logs the serving
    #62 — the meaning is constituted by the records whose meaning is circular

  ⟹ **THIS IS THE SAME LIMIT P0-02 FOUND IN KC's self-reference, P0-03 FOUND
     IN CD-C8/CD-C12's sampling self-reference, AND THE CELL CONTRACT FOUND
     IN FM-4's [U]. IT IS THE PROGRAM-LEVEL LIMIT, AND IT IS UNCLOSEABLE FROM
     INSIDE BY CONSTRUCTION — NOT BY INSUFFICIENT EFFORT.**

  ⟹ **WHAT THE ARCHITECTURE DOES INSTEAD OF CLOSING THEM:**
     • #25 — **EXTERNAL DIVERSITY REQUIREMENTS** (instrument-CLASS diversity,
       `gt_class` diversity, R4.3) as `[G]`-declared obligations, plus
       DECLARATION of the residue
     • #56 — **LOGGING + AGGREGATE DIVERGENCE DETECTION** (§28.1's pattern
       applied to serving) plus DECLARATION
     • #62 — **`inbreeding_F` and `causal_depth` bound the PROVENANCE form;
       the SEMANTIC form has `[U]` declared, `semantic_self_reference_score`
       named as a missing field, and §81/§100 OR-M1 as the register entry**

  ⟹ **§104's SECURITY rating is PARTIAL and its EVIDENCE-INDEPENDENCE rating
     is PARTIAL, AND THESE THREE ATTACKS ARE THE ENTIRE REASON FOR BOTH.**
     Every other attack in the catalogue is closed or bounded.
```

---

*End of Volume D. Volume E (`36_analysis_formal_specification.md`) covers §73–§80: the formal invariants (MEM-INV-01…40+), the formal state machines, the parameter registry with the `[G]`/`[U]`/`[D]` classification, minimality analysis, the knowledge-representation comparison (Output 37), identity persistence, and implementation independence.*
