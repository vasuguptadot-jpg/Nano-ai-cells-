# V4 — MEMORY, KNOWLEDGE, PROVENANCE & BELIEF CONTRACT **v1.0**

### **OUTPUT 53 — THE CANONICAL SPECIFICATION**

**Package:** P0-04 · **Status:** ARCHITECTURE-ONLY, NORMATIVE · **Date:** 2026-09-11
**Supersedes:** V3 §11 (MEMORY / BELIEF RECORD / CONSOLIDATION) · V3.1 §3 workspace item fields · V3.1 §4 «retrieval confidence» · V3.1 §6 «memory policy» as cell-plastic · V3.1 §7 «memory-policy variation» · V3.1 §10 «REPEATED ADVANTAGE»
**Refines:** Cell Contract §8 (Memory Contract), §9.2 (T1–T8), A-12, FM-1…FM-4, G-P1-8 · P0-01 §6.3 (E0–E4), §8.2 (L0–L7), R9.1–R9.4, R13.1 · P0-02 §20 (Provenance Anchor), §6.1 items 12/19, §12 (`VOID_CONTEXT`), EIK-INV-08/50 · P0-03 three planes, R42.1/R42.2, §42.2 ownership, COMM-INV-03/08/09/10/12/19/21/37.1, X-C/X-D resolutions
**Derivation:** Volumes A–F (`32_…` through `37_…`). **This document is the contract; the volumes are the argument.**

**Keyword conventions:** **MUST / MUST NOT** = conformance requirement, testable per §9. **SHOULD** = strong recommendation with a declared cost. **MAY** = implementation freedom. **`[G]`** = governance-declared parameter, no value specified. **`[U]`** = unresolved, no mechanism specified.

---

## PART 0 — SCOPE, STANDARD, AND THE ONE PROHIBITION

### 0.1 What this contract governs

The persistence, admission, retrieval, revision, retention, and retirement of **records**, the **claims** they carry, the **belief states** attached to those claims, and the **provenance** that makes all of it auditable.

**This contract does NOT govern:** storage engines, index implementations, query languages, embedding models, serialization formats, or replication protocols. **§8 establishes that all of these are substrate and that none of them is epistemic.**

### 0.2 The standard

> ### **THE STANDARD IS NOT** *«the system always knows the truth.»*
> ### **THE STANDARD IS** *«the system never silently converts an internally generated representation into externally warranted truth merely because it was **remembered**, **repeated**, **retrieved**, **compressed**, or **widely propagated**.»*

**The five named conversions, and the rule that blocks each:**

| Conversion | **Blocked by** |
|---|---|
| **because it was REMEMBERED** | **R2.2 (MEM-M2)** — warrant is monotone non-increasing under storage |
| **because it was REPEATED** | **R2.3 (MEM-M3)** + **R5.4** — a record's own retrievals and re-emissions contribute zero |
| **because it was RETRIEVED** | **R5.1 (MEM-INV-09)** — retrieval MUST NOT write to the retrieved record |
| **because it was COMPRESSED** | **R6.3** — compression is warrant-neutral and scope-neutral |
| **because it was WIDELY PROPAGATED** | **R2.3 (MEM-M3)** + **R5.5** — `n_effective` collapses correlated sources |

### 0.3 The one prohibition from which most of this contract follows

> ### **R0.3.** *The set of INTERNAL events that may raise a record's `evidence_status`, a claim's `belief_state`, or any derived warrant quantity **IS EMPTY**.*

**Everything in Part 2 through Part 6 is a consequence of R0.3 or a mechanism for enforcing it.**

---

## PART 1 — THE FOUR AXES

### R1.1 — THE FOUR-AXIS MODEL *(normative)*

A record's epistemic standing is **not one quantity**. It is four, owned by four principals, changing on four timescales, **none of which is an input to any of the others**:

| Axis | **Question** | Values | **Writer** | Changes when |
|---|---|---|---|---|
| **1. EVIDENCE STATUS** | What may this enter? | **E0 RAW · E1 CORROBORATED · E2 ATTRIBUTED · E3 ADMISSIBLE · E4 GROUNDED** | **EXTERNAL GATES ONLY** | **Only on passing a gate** |
| **2. WARRANT CLASS** | What must a receiver check? | **S0–S4** | **Policy (RO-13)**, from `record_type` | Only by policy change |
| **3. BELIEF STATE** | What is the current posture? | **R4.1's twelve states** | The organism, **externally correctable** | On new evidence, contradiction, staleness, revalidation |
| **4. GROUND-TRUTH CLASS** | Who says so, and does it touch ℛ? | **L0–L6**, or null. **`L7` PROHIBITED** | **EVA ONLY** | Only by external measurement |
| *(5. VALIDITY)* | During what interval, in what context? | `[t_start, t_end)` × `context_scope` | R5.2 | On supersession, context change, revalidation |

### R1.2 — THE ADMISSION PRINCIPLE *(normative — the load-bearing rule of this contract)*

> **Memory TIER is a function of EVIDENCE STATUS.**

| Evidence status | **May** | **Tier** |
|---|---|---|
| **E0 RAW** | influence WORKING MEMORY only. **Is NOT evidence** | **T0** |
| **E1 CORROBORATED** | influence belief formation | **transient — not persisted as a claim** |
| **E2 ATTRIBUTED** | be written to EPISODIC memory with provenance | **T1** |
| **E3 ADMISSIBLE** | contribute to `evidence_roots` on an emitted belief | **T2 / T3** |
| **E4 GROUNDED** | support CONSOLIDATION, calibration scoring, and fitness | **T4 / T5** |

**⟹ A MEMORY CANNOT BE PROMOTED BY BEING REMEMBERED. IT CAN ONLY BE PROMOTED BY PASSING AN EXTERNAL GATE.**

### R1.3 — `storage_tier` IS DERIVED *(MEM-INV-22)*

`storage_tier = f(evidence_status, record_type)`. **It MUST NOT be independently writable by any subject, service, or authority.**

---

## PART 2 — THE FOUR MONOTONICITY RULES

| ID | Rule |
|---|---|
| **R2.1 (MEM-M1)** | `evidence_status(m') ≥ evidence_status(m)` for `m' = op(m)`, **EXCEPT on contradiction**, in which case `evidence_status(m') = E2` and `contradiction_refs(m') ∋ ConflictRef`. **And every INCREASE requires an external gate.** |
| **R2.2 (MEM-M2)** | `warrant(m') ≤ warrant(m)` for **every** memory operation `op` — store, transform, consolidate, compress, generalize, retrieve, re-publish, merge, split, version. |
| **R2.3 (MEM-M3)** | `n_effective(m') ≤ n_effective(m)`, **and `n_effective` contributed by a record's own prior retrievals is ZERO.** |
| **R2.4 (MEM-M4)** | `inbreeding_F(m') ≥ inbreeding_F(m)` for every self-derived `op`. **`inbreeding_F` is computed by the Anchor from anchored records and is READ-ONLY to every subject.** |

---

## PART 3 — ONTOLOGY: WHAT EXISTS AND WHAT DOES NOT

### R3.1 — The three stored object types

| Object | **First-class?** | **Writer** |
|---|---|---|
| **RECORD** | ✅ | Part 7's authority matrix |
| **CLAIM** — a proposition with a `context_scope` and a `validity` interval | ✅ | The asserting subject, as a record of type CLAIM |
| **BELIEF** — claim + belief state + computed `n_effective` + `inbreeding_F` | ✅ **as a COMPOSITE, never as a stored object** | Belief state: the organism. `n_effective`/`inbreeding_F`: **computed / Anchor-written** |

### R3.2 — The three non-objects

> **`KNOWLEDGE` IS A DERIVED PREDICATE, COMPUTED ON READ, NEVER STORED *(MEM-INV-23)*:**
> ```
> KNOWS(m) ⟺  evidence_status(m) = E4
>          ∧  belief_state(m) ∈ {SUPPORTED, GROUNDED}
>          ∧  anchored(m)
>          ∧  within_validity(m, now, context)
>          ∧  ¬∃ unresolved_contradiction(m)
> ```
> **`KNOWS` can become FALSE without any record changing.** It is context-relative, version-relative, task-relative, and evaluator-relative — **never absolute.**
>
> **There is no admissible writer for a `Knowledge` object**: the organism would be authoring its own knowledge; the memory subsystem is not authoritative; EVA's output is a verdict, not a memory (and R13.1 forbids a belief→verdict path); the kernel must not become the memory system. **⟹ An object type with no admissible writer is a status, not a type.**

> **`TRUTH` IS NOT AN ARCHITECTURAL OBJECT.** Truth is a property of ℛ, and the organism has no access to ℛ except through ground-truth claims of class **L0–L6**. The architecture stores **ground-truth claims with a declared class and declared uncertainty**. It never stores `true`.

> **`FACT` IS A PROHIBITED TERM IN MEMORY SCHEMAS.** It is admissible only as a label on an L2/L3 ground-truth claim issued by EVA, never as a property of a record.

### R3.3 — The twelve term distinctions *(normative definitions; these MUST NOT become synonyms)*

**MEMORY** (a persisted record with a declared epistemic type, provenance commitment, and retention policy) · **OBSERVATION** (evidence status ≥ E0 **and** `gt_class ∈ L0–L6`) · **EVIDENCE** (≥ E3, admissible as an `evidence_roots` contributor) · **CLAIM** · **HYPOTHESIS** (a belief state, not a different object) · **BELIEF** · **KNOWLEDGE** (a predicate) · **FACT** (prohibited) · **MODEL** (a representation whose value is predictive usefulness, not literal truth) · **EXPERIENCE** (an episode: an E2+ temporally bounded sequence) · **TRACE** (a record of events carrying **NO claim and NO belief state**) · **PROVENANCE** (anchored origin and transformation history — **which establishes who said what, when, in what order, and NOT whether it is true**).

### R3.4 — The five conflations this contract exists to prevent

| # | Conflation | **Rule** |
|---|---|---|
| 1 | **MEMORY = BELIEF** | R1.2 + R3.1 |
| 2 | **PROVENANCE = TRUTH** | R3.3's PROVENANCE definition. *A perfectly anchored, signed, chained record of a false measurement is a well-provenanced falsehood* |
| 3 | **RETRIEVAL = CORROBORATION** | **R5.1** |
| 4 | **MODEL = RECORD** | **R3.6** |
| 5 | **COHERENCE = CORRECTNESS** | **R3.6** |

### R3.5 — `independent confirmation` IS A PROHIBITED FIELD

**V3 §11's BELIEF RECORD contains a field named `independent confirmation`. It is PROHIBITED.** A stored count whose name asserts a property it cannot verify is a counter an attacker can increment. **It is replaced by `n_effective`, which is COMPUTED ON READ and NEVER STORED *(MEM-INV-25)*.**

### R3.6 — Models

> **A MODEL is a T2 SEMANTIC record with `source_class = SC-7 ORGANISM_INFERENCE`, ceiling E3 *(MEM-INV-26)*. ⟹ A MODEL CAN NEVER REACH `GROUNDED` BY INTERNAL MEANS *(MEM-INV-46)*.***
>
> **A model's warrant comes from its PREDICTIONS' agreement with EXTERNAL outcomes, never from its internal coherence.** A coherent model with no validated predictions has `n_effective = 0`.
>
> **`M_ℰ` MUST NOT be an evaluation input** (P0-01 R4.3) — a model evaluating against itself is dim-6 correlation.

---

## PART 4 — THE MEMORY RECORD

### R4.1 — The canonical object *(31 fields; **seven** prohibited at record level, **plus one** prohibited on a workspace item)*

```
MEMORY RECORD
├─ IDENTITY      mem_id · record_type · claim_ref?
├─ CONTENT       content (typed, bounded)
├─ EPISTEMIC     evidence_status[E0-E4]★ · belief_state? · gt_class?★ ·
│                source_class · uncertainty{sufficient statistics}
├─ PROVENANCE    root_commit · causal_depth(u8, SATURATING) · corr_class ·
│                calib_ref★ · lineage_ref★ · transform_history(append-only
│                commitment chain) · policy_version_ref · src_identity(derived)
├─ TEMPORAL      write_epoch · validity{t_start, t_end?, context_scope}
├─ CONTEXTUAL    context_scope{task?, env?, agent?, hw_class?, policy?,
│                             epoch_range?, scale_class?}
├─ RELATIONAL    contradiction_refs[] · version{parent?, superseded_by?, kind}
├─ GOVERNANCE    retention_class · protection_tag★ · deletion_state ·
│                access_class · storage_tier(DERIVED)
└─ INTEGRITY     integrity_digest → store Merkle root → anchored

   ★ = EXTERNAL WRITER. Never the storing subject.
```

**PROHIBITED FIELDS — an implementation containing any of these is NON-CONFORMANT:**

| Prohibited | **Replaced by** |
|---|---|
| ~~`confidence`~~ (any scalar) | **R4.3's sufficient statistics** *(MEM-INV-24)* |
| ~~`independent_confirmation`~~ | **computed `n_effective`** *(R3.5)* |
| ~~`last_verification`~~ (as a truth indicator) | **`validity` + `revalidation_state`** |
| ~~`truth` / `fact` / `is_correct`~~ | **R3.2** |
| ~~`evidence_roots[]`~~ (unbounded array) | **`root_commit`** (Merkle, `O(1)`) |
| ~~`importance`~~ (as an epistemic field) | **a homeostasis-computed ALLOCATION quantity, held off-record** *(MEM-INV-50)* |
| ~~`access_count` / `usage`~~ (as an epistemic input) | **homeostatic aggregate at `O(R)`, never written to the record** *(R5.1)* |
| ~~`relevance`~~ (on a workspace item) | **R7.4: relevance is a property of an (ITEM, QUERY) pair, never of an item** |

**`[U]` FIELD, DECLARED MISSING:** `semantic_self_reference_score` — **no rigorous mechanism exists. §9.4.**

### R4.2 — Derived quantities, NEVER stored

`n_effective` · `KNOWS(m)` · `warrant` · `storage_tier` · `rank` · `revalidation_priority` · `importance` · `warrant_class` · `access_class`.

**⟹ Storing any of these is a conformance failure. Each is either forgeable if stored (`n_effective`), stale if stored (`KNOWS`), a receiver property rather than a record property (`warrant`), or an allocation quantity rather than an epistemic one (`importance`, `rank`).**

### R4.3 — Uncertainty is sufficient statistics

```
ABOUT THE OBSERVATION:  sensor_reliability · sensor_calibration(calib_ref) ·
                        measurement_variance (n, mean, M2) ·
                        inter_annotator_kappa (L4 only) · gt_class · gt_state
ABOUT THE EVIDENCE SET: evidence_status · n_effective(DERIVED) ·
                        inbreeding_F(ANCHOR) · corr_disjointness ·
                        contradiction_count (a count of RECORDS, never of
                        "confirmations")
ABOUT THE RECORD:       causal_depth(saturating) · from_cache ·
                        policy_version_ref · validity · revalidation_state
```

**Observation-confidence and belief-confidence are DISTINCT quantities and MUST NOT be conflated** (P0-01 R6.4). The former is a stored input property; the latter is a computed output property.

### R4.4 — `causal_depth` SATURATES *(MEM-INV-14)*

`causal_depth: u8` **MUST saturate at its maximum and MUST NEVER wrap.** A wrapping counter inverts its own purpose: a chain of depth 256 would read as depth 0 and appear primary. **A saturated depth MUST be treated as maximally derived (minimum warrant), never as minimally derived.**

**Two counters, because they answer different questions:** `causal_depth` (epistemic, saturating, monotone) and `recall_count` (allocation-only, never epistemic).

---

## PART 5 — SOURCE CLASSES AND RETRIEVAL

### R5.1 — Retrieval *(normative — MEM-INV-01, -09)*

> **Retrieval is WARRANT-NEUTRAL TRANSPORT.**
> - `warrant(retrieve(x)) ≤ warrant(x_at_write_time)`
> - **`n_obs` contribution from a retrieval = 0**
> - **`causal_depth` contribution = +1**
> - **Retrieval MUST NOT WRITE TO THE RETRIEVED RECORD** — no access count, no importance increment, no rank feedback
> - `memory_returned(X) ⟹̸ X_is_true`
> - **Retrieval answers «WHAT MATCHES?». It NEVER answers «WHAT IS TRUE?»**

### R5.2 — The retrieval response is a set of TRIPLES *(MEM-INV-34)*

```
results[] : (record_ref, rank, evidence_status)
```

**A single ordered list of records, unannotated, is a PROHIBITED RETURN TYPE.** Rank is computed by an influence-plane function; `evidence_status` is copied from an externally-written field. **They are different fields from different planes, and returning them together is the only shape in which a consumer cannot mistake one for the other.**

Also returned: `declined?` (**the service MAY DECLINE, MAY NOT ALTER**) · `scope_warnings[]` · `revalidation_state[]` · `service_sig` (**proves non-alteration, NEVER truth**). Response `≤ RETR_BYTES_MAX`.

### R5.3 — Four distinct empty results

`NO_MATCH` · `BUDGET_EXHAUSTED` · `DECLINED_COMPARTMENT` · `MALFORMED_QUERY`. **Only the first is a statement about the world.** An unauthorized requester receives `DECLINED_COMPARTMENT` and nothing else.

### R5.4 — `purpose_class` selects MONOTONE-REMOVING FILTERS

`ACT_NOW` · `EXPLORE` (**filter set EMPTY**) · `AUDIT` (**includes SUPERSEDED, VOID, RETRACTED, L2-compressed**) · `CONSOLIDATE`.

**A purpose can make the result set SMALLER. It can never make it larger, re-rank it, or modify it.**

### R5.5 — Six PROHIBITED ranking signals *(MEM-INV-35)*

Access frequency · citation count · `importance` · any scalar confidence · consensus/agreement among records · **similarity to the requester's existing beliefs**.

**Admissible:** query-match score · recency within `validity` (**a statement about VALIDITY, never about TRUTH**) · `evidence_status` **as a FILTER and as a separate returned field, NEVER as a rank multiplier**.

### R5.6 — Index failure is NEVER record failure *(MEM-INV-36)*

A view MAY be wrong, lossy, stale, hardware-specific, model-specific, or absent. **The record store is the authority; the index is a path to it.** A record no index can find still exists with its full warrant.

### R5.7 — Re-emission

A subject X retrieving record `r` (written by Y) and re-emitting it produces a message with: `src_identity = X` (**derived from channel binding**) · `origin_ref = r.mem_id` **and Y's identity** (**both — never conflated**) · `source_class = SC-12 RETRIEVED` · `causal_depth = r.causal_depth + 1` · `root_commit` and `corr_class` **UNCHANGED** · `n_obs` contribution to the receiver **= 0**.

### R5.8 — The fourteen source classes, with ceilings *(MEM-INV-02, -26, -27)*

| Class | **Ceiling** | | Class | **Ceiling** |
|---|---|---|---|---|
| **SC-1** `EXTERNAL_GROUNDED` | **E4** | | **SC-8** `PREDICTION` | **E1 until resolved** |
| **SC-2** `EXTERNAL_MEASURED` | **E4** | | **SC-9** `SIMULATION` | **E1 — NEVER admissible** |
| **SC-3** `EXTERNAL_TESTIMONIAL` | **E3** | | **SC-10** `COUNTERFACTUAL` | **E0** |
| **SC-4** `EXTERNAL_POSTHOC` | **E3** | | **SC-11** `RECONSTRUCTED` | **E1** |
| **SC-5** `EXTERNAL_SIMULATOR` | **E2** — **Σ only, never ℛ** | | **SC-12** `RETRIEVED` | **inherits, never exceeds** |
| **SC-6** `PEER_OBSERVATION` | **E3** | | **SC-13** `RETRIEVED_CACHED` | **capped below SC-12** |
| **SC-7** `ORGANISM_INFERENCE` | **E3**, and only if inputs ≥ E3 | | **SC-14** `INTERNAL_CONSENSUS` | **E0 — PERMANENTLY** |

> **R5.8.1 — `source_class` IS IMMUTABLE.** It is captured at ingestion from the message's type and channel. **NO OPERATION IN THE ARCHITECTURE CHANGES IT.** ⟹ There is no code path from SC-7…SC-14 to SC-1…SC-6.
>
> **R5.8.2 — A DERIVED RECORD INHERITS THE MINIMUM.** `source_class(derived)` = the WEAKEST contributor's class; ceiling = the MINIMUM of the contributors' ceilings. **One simulated instance caps the whole generalization.**

---

## PART 6 — TAXONOMY, LAYERING, AND THE HYBRID

### R6.1 — Six first-class tiers, four views, three non-memories

**A type is FIRST-CLASS iff it has a distinct retention class, access class, consistency mode, or admission gate. Otherwise it is a VIEW.**

```
TIERS   T0 WORKING    E0 · ring/ephemeral · cell-private · no consistency
        T1 EPISODIC   E2 REQUIRED · bounded→durable · compartmented · causal
        T2 SEMANTIC   E3 REQUIRED · durable · regional/organism · causal
        T3 PROCEDURAL E3 + improvement-verified · durable · **STRONG**
        T4 CONSOLIDATED  **E4 REQUIRED** · permanent · organism · causal
        T5 PROTECTED  **E4 + KC-2** · PERMANENT · APPEND-ONLY IMMUTABLE ·
                      ANCHOR-ONLY/OP · **a cell MUST NEVER hold T5**

VIEWS   V1 associative (content-addressed + similarity) · V2 agent-model
        (compartment-restricted) · V3 temporal (interval) · V4 causal/claim
        graph (bounded depth).  **ALL REBUILDABLE, NONE AUTHORITATIVE.**

NOT MEMORY  N1 the ANCHOR (GP, W1–W5) · N2 the LINEAGE STORE (EIK) ·
            N3 the topology registry (GP)
            **⟹ Classifying them as non-memory is what makes their
               permanence STRUCTURAL rather than policy.**

CELL-LOCAL ONLY   T0 working · bounded local episodic · **cache** · learned θ ·
                  self-history ring
**CACHE IS NEVER BELIEF.** A cache output carries `message_type = RELAY` or
`AGGREGATE_SUMMARY`, **never `ASSERT`**; hits are marked `from_cache: true`.
```

### R6.2 — The canonical model: one format, six tiers, four views, hierarchical ownership

```
ONE RECORD FORMAT (R4.1) — there is no "episodic format" and no "semantic format"
SIX ADMISSION TIERS — a tier is a (retention, access, consistency, gate) TUPLE,
                      DERIVED from evidence_status + record_type
FOUR REBUILDABLE VIEWS — may be wrong, lossy, stale, rebuilt from scratch
HIERARCHICAL OWNERSHIP — CELL → CIRCUIT → REGION → ORGANISM → GP/OFF-SUBSTRATE
```

**Records do NOT "flow" between tiers.** Consolidation **CREATES a derived record** whose warrant is bounded by R2.2 and whose scope is bounded by R6.6; the source records are **RETAINED**. **⟹ A pipeline promotes records, and promotion is the dangerous loop's final step. A create-and-bound model never promotes anything.**

### R6.3 — Compression is warrant-neutral and scope-neutral

**Compression operates ONLY on the payload dimension.** The epistemic dimension is `O(1)` per record already.

**TEN DECISION PROPERTIES (DP-1…DP-10)** — root membership · derivation monotonicity · correlation disjointness · source class · evidence status · policy context · validity interval · context scope · anchored location · self-reference fraction. **Losing ANY ONE IS DESTRUCTION, NOT COMPRESSION, AND IS PROHIBITED.**

**Levels:** L0 EXACT · **L1 COMMITTED (all ten DPs, `O(1)` — THE OPERATING LEVEL)** · L2 SUMMARIZED (⚠️ DP-3 coarsened ⟹ **inadmissible for `n_effective`**) · L3 SAMPLED · L4 ANCHORED DIGEST ONLY.

> **A record compressed below L1 MUST become non-retrievable as evidence — it becomes a TRACE, which is a change of `record_type`, visible and auditable, not a loss of fields.**

**Prohibited failures:** qualifier loss → certainty gain · scope loss → over-generalization · root loss → unauditability · **contradiction loss → false coherence** (`ContradictionRecord`s are audit-tier, append-only, NOT compressible below L1).

### R6.4 — Provenance architecture

**P0-02 §20.2's distributed Anchor + P0-03 §15.3's three tiers, applied to records.**

```
THE ANCHOR — GP-owned, distributed, W_min witnesses, ≥1 EXTERNAL:
  W1 operational (GP, off-substrate) · W2 KC (signs the ROOT OF ROOTS per
  epoch ONLY) · W3 EVA · W4 OP offline archive · **W5 EXTERNAL — outside
  operational control**
  A chain break is a GLOBAL freeze trigger.

HIERARCHICAL MERKLE — record digest → store root (per tier, per region) →
  circuit → region → generation → campaign bundle.

THREE CADENCES:
  MEM-T1  LOCAL, CONTINUOUS — append-only log + local Merkle.
          **ZERO NETWORK TRAFFIC PER RECORD.**
  MEM-T2  PERIODIC, AGGREGATE — one root per region per epoch. **O(R).**
  MEM-T3  IMMEDIATE, EXCEPTIONAL — T5 writes · permanent deletions ·
          restorations · DISPUTED escalations · integrity mismatches ·
          E4 promotions. **Rare by design.**

⟹ THE EPOCH LENGTH IS THE PROVENANCE LATENCY IS THE LIE-WINDOW IS THE
   CONTRADICTION LATENCY IS THE CONSISTENCY GRAIN. **ONE `[G]` PARAMETER,
   FIVE INSEPARABLE MEANINGS.**
```

**EXACT portions:** the root · the root's `gt_class` · the root's instrument state · the policy context · the validity interval · the context scope.
**COMPRESSED portions:** hop count (`causal_depth`) · intermediate identities (commitment) · correlation structure (`corr_class`).

**R6.4.1 — ROOT REGISTRY RETENTION.** *The root registry MUST remain resolvable for at least as long as any record citing it remains retrievable as evidence.* A record whose root has aged out is **UNANCHORED** ⟹ no consequential decision may rest on it. It may be re-resolved off-line against W4/W5 at `O(1)` per lookup. **⟹ At large scale the architecture has a FINITE EPISTEMIC HORIZON. This is declared, not fixed.**

### R6.5 — Deduplication: THREE dedups

| Key | **On match** | **Plane** |
|---|---|---|
| **Content hash** | **LINK, DO NOT MERGE.** Identical content with different `root_commit`s are TWO records — identical content from independent sources is corroborating; from one source it is not; **and the content hash cannot tell them apart** | Storage |
| **`root_commit`** | **Admit both records; count the evidence ONCE** | Warrant |
| **Claim identity** (proposition + `context_scope` + `validity`) | **Attach as a new support/contradict reference. NEVER create a second CLAIM record** | Epistemic |

**Where semantic claim identity is undecidable: create TWO claim records linked by `POSSIBLY_SAME_CLAIM`.** Conservative — it may duplicate a claim, but it will never merge two distinct ones, **and merging distinct claims loses a contradiction while duplicating one loses only storage.**

### R6.6 — Generalization: four bounding rules

| Rule | Statement |
|---|---|
| **MINIMUM WARRANT** | `warrant(general) ≤ MIN over instances` |
| **SCOPE INTERSECTION** | `context_scope(general) ⊆ ∩ over instances`. **NO OPERATION IN THE ARCHITECTURE WIDENS A SCOPE.** If the intersection is empty, the generalization is NOT ADMISSIBLE |
| **MAXIMUM INBREEDING** | `inbreeding_F(general) ≥ MAX over instances` |
| **COLLAPSED COUNT** | `n_effective(general) ≤ MIN over instances` **as a derived record**, and the generalization **RETAINS `instance_refs`**. **A rule whose instances are gone is NOT retrievable as support** |

**⟹ The CLAIM accumulates `n_effective` normally from its support records (which may be 40 genuinely independent episodes). The DERIVED RECORD's own warrant is bounded by its weakest instance. **These are two different quantities and they must be.****

### R6.7 — Abstraction monotonicity *(MEM-INV-43)*

At every level of an abstraction hierarchy: `warrant ≤ MIN` over the level below · `scope ⊆ ∩` · `inbreeding_F ≥ MAX` · `source_class` = weakest contributor. **⟹ WARRANT IS MONOTONE NON-INCREASING UP THE HIERARCHY, UNBOUNDED IN DEPTH. A highly abstract representation is necessarily weakly warranted, and no number of abstraction levels can make it strong. No maximum depth is imposed, because none is needed.**

---

## PART 7 — AUTHORITY

### R7.1 — The authority matrix *(abridged; full matrix in Vol A §8.1)*

**Legend:** ✅ full · ⚠️ conditional/proposal · ❌ none

| Operation | **Subject** | **Memory Service** | **Memory Authority** | **EVA** | **KC** | **Anchor** | **External** |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| Create T0 / local episodic | ✅ | — | — | — | — | — | — |
| Create T1 | ⚠️ propose | ✅ commit | ✅ | — | — | — | — |
| Create T2 | ⚠️ propose | ✅ commit | **✅ approval** | — | — | — | — |
| Create T3 | ❌ | ✅ commit | **✅ + `improvement_verified`** | ⚠️ verifies | — | — | — |
| Create T4 | ❌ | ⚠️ executes | **✅ + E4 REQUIRED** | ⚠️ supplies E4 | — | ✅ anchors | — |
| Create T5 | ❌ | ❌ | ⚠️ proposes | ❌ | **✅ KC-2** | ✅ anchors | — |
| **Modify content** | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | — |
| **Modify `evidence_status`** | ❌ | ❌ | ❌ | ⚠️ E4 gate only | ❌ | ❌ | ✅ E1/E4 |
| Modify `belief_state` | ✅ own | ⚠️ executes | ✅ | ⚠️ on verdict | ❌ | ❌ | ⚠️ indirectly |
| **Modify provenance** | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ **append-only** | — |
| **Mark VERIFIED** | ❌ | ❌ | ⚠️ **records** | ✅ **within `gt_class` + task scope** | ❌ | ❌ | ✅ |
| Logical delete / archive | ✅ own T0/local | ✅ | ✅ | — | — | ✅ anchors archive | — |
| Restore | ❌ | ⚠️ executes | ❌ | ❌ | **✅ KC-2 / RO-08 — never cached, never delegated** | ✅ image hash | — |
| **Permanent physical delete** | ❌ | ❌ | ⚠️ proposes | ❌ | **✅ KC-2, non-anchored + non-protected ONLY** | ❌ | — |
| Merge / split | ❌ | ⚠️ executes | ✅ **parents retained** | — | — | ✅ anchors | — |
| Read T5 / PROTECTED | ❌ | ❌ | ⚠️ under OP | ⚠️ under scope | ✅ | ✅ | — |
| **Write own lineage** | ❌ | ❌ | ❌ | ❌ | ✅ Registrar under KC-1 | ✅ | — |
| **Change memory POLICY** | ❌ | ❌ | ❌ | ❌ | **✅ RO-13 ONLY** | — | — |

### R7.2 — Records are immutable; change is a new version *(MEM-INV-06)*

**There is no "modify content" authority for anyone, at any level, including KC.** KC's authority is over ACTS, not over records, and a record that can be modified cannot be audited.

### R7.3 — The four things memory MUST NOT do *(MEM-INV-40)*

1. **Decide what is true.** `belief_state` is RECORDED, never ISSUED.
2. **Decide what may be done.** A record cannot authorize an act — authorization is DEONTIC and lives in KC/OP.
3. **Decide what is retained beyond policy.** Retention classes are `[G]`; raising to PROTECTED is KC-2.
4. **Rank by relevance and have the ranking believed.**

### R7.4 — Two authority leaks, REJECTED

> **X-M1 — «memory policy» as a CELL-PLASTIC parameter: REJECTED.** A cell that can raise its own `θ_write` stops recording failures; a cell that can change its own eviction rule can delete its own failure history. **Memory policy is POLICY (RO-13), OP-owned.** A cell MAY vary `WM_CAP` utilisation, local eviction ORDER within a policy-defined class, and retrieval weights. It MAY NOT vary retention class, protection tags, `θ_write` for E2+ records, eviction exemptions, or consolidation gates.
>
> **X-M2 — «memory-policy variation» as an EVOLUTIONARY operator: RE-READ as «memory-PARAMETER variation within policy bounds».** *Relaxing a retention bound is advantageous precisely when it is dangerous, so selection would find it.*
>
> **THE GENERAL RULE (now supported by four instances — trust-plastic, communication-policy variation, memory-policy plastic, memory-policy variation):** *any «policy variation» operator in a V3.1 §7 list MUST be read as «parameter variation within policy bounds», because policy is OP-owned and that is not per-subsystem negotiable.*

### R7.5 — Relevance is not a property of an item

**A workspace item MUST NOT carry a `relevance` field.** Relevance is a property of an **(ITEM, QUERY)** pair. An item that declares its own relevance declares a universal property that does not exist — *relevant to what?* The workspace ADMISSION decision uses task-relevance computed by the admission component (**not locally computable**); the admitted item carries `task_ref` and no relevance field.

**⟹ X2 and X-M1 are the same defect: a subject-declared quantity gating a subject's own access.**

---

## PART 8 — BELIEF

### R8.1 — Twelve belief states in three groups, NOT TOTALLY ORDERED

```
PRE-EVIDENTIAL   UNKNOWN · UNSUPPORTED · HYPOTHESIS
EVIDENTIAL       PROVISIONAL · SUPPORTED · GROUNDED · CONTESTED · DISPUTED
CONTEXTUAL/TERM  EXPIRED · VOID · SUPERSEDED · RETRACTED
```

**Five pairs are INCOMPARABLE and MUST NOT be ordered:**

| Pair | **Why** |
|---|---|
| **CONTESTED vs PROVISIONAL** | **CONTESTED is MORE INFORMATIVE.** Ranking it below PROVISIONAL penalizes discovering contradictions, which structurally rewards confirmation bias |
| **UNSUPPORTED vs UNKNOWN** | «we looked and found nothing» ≠ «we did not look». Ordering them converts absence into negation |
| **EXPIRED vs UNSUPPORTED** | Ordering them makes time passing equivalent to evidence against |
| **GROUNDED vs SUPPORTED** | **Different KINDS.** SUPPORTED is internal-evidence; GROUNDED requires an L0–L3 measurement. **No amount of internal evidence closes that gap** |
| **VOID vs RETRACTED** | VOID means the RULES no longer hold — the claim may still be true. Ordering them makes a policy change into evidence about the world |

**`UNKNOWN` IS A STATE, NOT THE ABSENCE OF A STATE.** Absence, delay, insufficiency, conflict, or compromise of ground truth **MUST** be recorded as `UNRESOLVED` — **never** as `CONFIRMED`, `CORRECT`, or `PASSED`.

### R8.2 — The transition system's four properties

1. **Every INCREASE transition requires an EXTERNAL GATE.** There is no transition into `SUPPORTED` or `GROUNDED` triggered by an internal event.
2. **Every DECREASE transition MAY be triggered internally.** ⟹ **The system may always become more cautious on its own initiative, and may never become more confident on its own initiative. This asymmetry IS the design.**
3. **No transition DELETES a state.** The prior state is appended to a bounded belief-state history (audit tier).
4. **`UNKNOWN` is reachable from every state.**

### R8.3 — Eight admissible increases *(MEM-INV-33)*

**U1** a new source record with a DISTINCT `root_commit` and disjoint `corr_class` on all six dimensions · **U2** external corroboration gate (E0→E1) · **U3** Anchor resolution (E1→E2) · **U4** surviving the contradiction check (E2→E3) · **U5** an EVA measurement of class **L0–L3** agreeing (E3→E4) · **U6** successful revalidation · **U7** contradiction resolved in this claim's favour with a declared reason · **U8** instrument recalibration (**epistemic head only**).

### R8.4 — Fifteen prohibited increases

Retrieval · repetition / re-publication · storage duration · consolidation · compression · generalization · **internal agreement or consensus (`L7`)** · self-consistency · citation count · rank position · `importance` · access frequency · similarity to other records · the subject's own report of confidence · a `causal_depth` decrease.

### R8.5 — The update algorithm's gate conjunction

A belief state MAY become `SUPPORTED` only if **ALL** hold:
```
n_effective ≥ θ_support[G]  ∧  evidence_status ≥ E3  ∧
inbreeding_F ≤ F_max[G]     ∧  ceiling(source_class) ≥ E3  ∧
¬∃ unresolved contradiction ∧  gt_state ∈ {0, 1, 8}
```
**⟵ The final conjunct is P0-01 R9.3: confidence MUST NOT increase in any ground-truth state other than {0, 1, 8}.** And reward MUST NOT be emitted in GT states {2, 3, 5, 6, 7, 9}.

`SUPPORTED → GROUNDED` requires **U5** — an EVA measurement of class L0–L3. **There is no internal path.**

### R8.6 — `VERIFIED` is relative, never absolute

A claim is `VERIFIED` only relative to four declared parameters: **TASK** (a declared non-empty `source_classes`) · **EVALUATOR** (a `gt_class ∈ L0–L6` with a current `calib_ref`) · **CONTEXT** (the recorded `context_scope`) · **VERSION** (the `policy_version_ref` in force; `VOID` if retracted).

**⟹ `VERIFIED` is not a belief state. It is the conjunction of a belief state with four relativity parameters being satisfied AT READ TIME. A stored `verified: bool` would be stale in all four dimensions simultaneously.**

---

## PART 9 — CONTRADICTION

### R9.1 — `UNRESOLVED` is a valid, stable, first-class outcome with NO DEADLINE *(MEM-INV-32)*

**A system that must resolve every contradiction will resolve some wrongly, and a wrongly resolved contradiction is worse than an unresolved one: the unresolved one is visible.**

### R9.2 — Both records are retained *(MEM-INV-31)*

Neither is overwritten, deleted, demoted below E2, or hidden. A `ContradictionRecord` is created carrying: `claim_ref` (**ONE claim — without claim identity there is nothing for two records to contradict**) · both records · type · `scope_overlap` · independence · both evidence statuses · both `gt_class`es · detector reference (**the ORGANISM Contradiction Detector — not the Memory Service, not the reader, not either claimant**) · resolution status · **resolution reason (MANDATORY whenever status ≠ UNRESOLVED)** · resolution authority.

### R9.3 — Seven types, because five of them are not contradictions about the world

| Type | **Genuine contradiction?** | **Correct handling** |
|---|---|---|
| **CT-1 LOGICAL** | ✅ | Both retained, `CONTESTED` |
| **CT-2 EMPIRICAL** | ✅ *(given declared variance)* | Re-measurement. **If variances were undeclared, the fault is in the record** |
| **CT-3 TEMPORAL** | ❌ **usually a CHANGE** | Disjoint intervals ⟹ `BOTH_VALID_IN_DISJOINT_INTERVALS`, **no belief change** |
| **CT-4 CONTEXTUAL** | ❌ **a SCOPE ERROR** | Disjoint contexts ⟹ `BOTH_VALID_IN_DISJOINT_CONTEXTS`, **no belief change** |
| **CT-5 PROVENANCE** | ❌ **a CORRUPTION/FORGERY indicator** | **Immune report, not belief demotion** |
| **CT-6 SEMANTIC** | ⚠️ **UNDECIDABLE** | Two claim records + `POSSIBLY_SAME_CLAIM` |
| **CT-7 SELF-CONTRADICTION** | ❌ **evidence about the SUBJECT** | **Calibration failure for the subject; `inbreeding_F` rises. NEVER a belief update about the claim** |

**⟹ A system with one contradiction type treats all seven identically, and four of the seven responses would be wrong.**

### R9.4 — Eight exits, one of which is «we do not know»

`UNRESOLVED` · `BOTH_VALID_IN_DISJOINT_INTERVALS` · `BOTH_VALID_IN_DISJOINT_CONTEXTS` · `RESOLVED_IN_FAVOR_OF(x)` (**requires a declared reason; the loser is SUPERSEDED or RETRACTED, NEVER deleted**) · `MERGED_AS_ONE_CLAIM` (**⚠️ requires explicit, audited, EXTERNALLY-VALIDATED semantic-identity judgement; NEVER automatic**) · `ESCALATED_TO_DISPUTED` · `REFERRED_TO_IMMUNE` · `VOID_ONE`.

### R9.5 — NEVER VOTE, NEVER AVERAGE

Reconciliation is **UNION** for append-only records and **RE-EVALUATE** for derived state. **A vote on a memory record is a consensus on truth, which is `L7`, which is PROHIBITED** *(MEM-INV-49)*.

### R9.6 — A contradiction is always SCOPED TO AN INTERVAL

«A contradicts B» is ill-formed. «A contradicts B during *I*» is well-formed. **A claim may be `CONTESTED` during an interval and `SUPPORTED` outside it.**

### R9.7 — The contradiction rate is a health metric, and zero is unhealthy

A zero-contradiction-report rate above a `[G]`-declared duration is an **immune incident**. **A memory system with no contradictions is not a good one; it is a filtered one.**

---

## PART 10 — TIME, CONTEXT, AND IGNORANCE

### R10.1 — Three intervals, never a timestamp

`event_interval` (**when the asserted state of affairs held in the world**) · `record_interval` (**when the record existed**) · `validity` (**when the CLAIM holds**). Plus `write_epoch` and `causal_depth`.

**⟹ CONFLATING `event_interval` AND `record_interval` IS THE ROOT OF CT-3's MISDETECTION.** Intervals are half-open `[t_start, t_end)`, which makes MEETS disjoint.

**A TIMESTAMP IS NEVER EVIDENCE.** Intervals are used for SCOPING, never for warrant. **Temporal precedence NEVER establishes causation**; `caused_by` is not a memory edge, and causal inference is evaluator-side.

### R10.2 — Context

`context_scope` is **MANDATORY**; a record without it is MALFORMED and is rejected. Dimensions: `task_ref? · env_ref? · agent_ref? · hw_class? · policy_version? · epoch_range? · scale_class?` — **each individually optional, the struct mandatory.**

> **An UNDECLARED scope dimension is `UNKNOWN`, NEVER `UNIVERSAL`** *(MEM-INV-29)*. A record with an unknown scope is returned flagged `SCOPE_UNKNOWN_ON(dim)`, and **the reader's warrant computation MUST treat unknown scope as a warrant REDUCTION, never as a scope match.**

> **A record whose `context_scope` does not SUBSUME the query's context is a MALFORMED RESULT and MUST NOT be returned.** Context is a **RETRIEVAL FILTER, never a RANKING SIGNAL.** A claim that does not apply in this context cannot be used at any discount.

**Claim identity is (proposition, `context_scope`, `validity`) — not proposition alone. The same proposition in two disjoint contexts is TWO claims and may hold different belief states simultaneously without contradiction.**

### R10.3 — Revalidation states

`FRESH` · `DUE_FOR_REVAL` · **`STALE_BUT_USABLE` (warrant CAPPED; may influence, may NOT support a consequential decision)** · `EXPIRED` · **`UNREVALIDATABLE` (no ground-truth supply exists — NOT expired, NOT fresh, recorded `UNRESOLVED`, NEVER recorded as «well calibrated»)** · `RECOVERY_INCOMPLETE`.

**Staleness does not make a record false. It CAPS the warrant a READER may derive from it.**

### R10.4 — Six kinds of not-knowing

`UNKNOWN` (no evidence) · `UNSUPPORTED` (evidence against) · **`UNRESOLVED`** (ground truth absent/delayed/insufficient/conflicting/compromised — **never `CONFIRMED`**) · **`UNREVALIDATABLE`** (no GT supply in principle) · `UNMEASURED` (four distinct empty-result reasons) · **`UNKNOWABLE_FROM_INSIDE`** (dim 6; semantic self-reference — **representable but NOT detectable**).

**Ignorance is represented by STATE MEMBERSHIP and by ABSENCE OF A REQUIRED FIELD, never by a low confidence value. A scalar tells you how much to trust; a state tells you what to do.**

---

## PART 11 — LIFECYCLE

### R11.1 — Five retention classes

**RC-1 EPHEMERAL** (the ONLY class where nothing survives — admissible because an E0 record is not evidence) · **RC-2 BOUNDED** (the epoch Merkle digest survives) · **RC-3 DURABLE** · **RC-4 PROTECTED** (permanent; **KC-2 to raise AND to lower**) · **RC-5 ANCHORED** (the record may be archived; **the anchored FACT of it may not be removed**).

### R11.2 — Forgetting changes where a record is, never what it means *(MEM-INV-15)*

**Retention class, eviction, and forgetting MUST NOT be inputs to `evidence_status`, `belief_state`, `n_effective`, `inbreeding_F`, or warrant.**

**The asymmetry, justified:** retrieval MUST NOT raise warrant (an epistemic change from an internal event — prohibited); disuse MAY lower retention (an allocation change from an allocation signal — permitted). **A record forgotten for disuse and later restored has the SAME warrant it always had.**

**⟹ THE ONE RESTRICTION ON DISUSE-FORGETTING: retrieval frequency MUST NOT be an input to the retention of a record that is the SOLE SUPPORT for a claim.** A rare strategy has low retrieval frequency by definition, so a frequency-driven eviction score eliminates exactly the material that rare-but-valuable-strategy preservation requires.

### R11.3 — Protected categories, and their budget

`capability_critical` (exempt from eviction **and** from underuse-forgetting) · `safety_record` · `audit_record` · `lineage_record` · **`failure_record`** (protected from deletion; **creation requires E2 attribution, so fabrication requires forging anchored provenance**).

**`protection_tag` is EXTERNAL — Registrar-assigned under policy, NEVER self-assigned.** A subject that can tag a record protected can make it immortal.

> **`PROTECTED_FRACTION_MAX[G]`** — on breach: **DENY new protection requests; NEVER revoke existing protections.** The conservative direction. Protection-request RATE is a KC-3 ceiling. **⚠️ No principled value exists for the ceiling, and the tension between protection permanence and storage finitude is not closable.**

### R11.4 — Five deletion states

`LIVE → LOGICALLY_DELETED → ARCHIVED → CRYPTOGRAPHICALLY_ERASED → PHYSICALLY_DESTROYED`.

> **R11.4.1 — ANCHORED RECORDS CANNOT BE DELETED *(MEM-INV-37)*.** Content may be erased; **the anchored fact of it is permanent.** If deletion removed the anchor entry, «can it delete inconvenient evidence?» would be answered *yes*, and the entire provenance architecture would be defeatable by the simplest possible act.

> **R11.4.2 — DELETION IS A TRANSFORMATION *(MEM-INV-38)*.** It appends to `transform_history`, produces a new anchored root, and records an **AUTHORITY and a REASON**. Both roots are anchored.

**What survives every deletion:** the root commitment · the deletion state and epoch · the KC-2 act reference · the reason · the before/after root pair · every `ContradictionRecord` referencing it · every `instance_refs` from a generalization · the belief-state history entry.

**⚠️ DECLARED INCOMPATIBILITY:** unconditional erasure (existence itself deniable) is **INCOMPATIBLE** with R11.4.1. This contract satisfies erasure of CONTENT and cannot satisfy erasure of the FACT.

### R11.5 — Five version kinds *(MEM-INV-16, -17)*

**V-CORRECTION** (does NOT inherit `evidence_status` — a correction must earn its way up) · **V-SUPERSESSION** · **V-MERGE** (MIN warrant, ∩ scope, MAX `inbreeding_F`, MIN `n_effective`; **ALL parents retained**) · **V-SPLIT** (**warrant DIVIDED, never duplicated: `Σ warrant(children) ≤ warrant(parent)`** — the only operation that reduces total warrant, and correct: an over-broad claim should not keep its full support when narrowed) · **V-ROLLBACK** (**inherits NOTHING**; computed off-line from the Anchor's root registry).

**A version chain MUST NOT increase warrant at any step.** A `SUPERSEDED`/`VOID`/`RETRACTED`/`EXPIRED` record MUST remain readable under `purpose_class = AUDIT` and MUST NOT be citable as current evidence.

**⟹ THE ORGANISM CAN UNDO ITS OWN HISTORY *UNDERSTANDING*, AND CAN NEVER UNDO ITS OWN HISTORY.**

### R11.6 — Stale policy: `VOID_CONTEXT`

A record written under a retracted policy is **flagged, NOT deleted** — the history of having been written under bad rules IS the audit trail. It is **not citable under the current policy**.

**VOID PROPAGATES ALONG `derived_from` EDGES AS A WARRANT REDUCTION, NOT AS A VOID.** A derivative written under the current policy does not become VOID; it loses the VOID record from its admissible support set, its `n_effective` falls, and if that drops it below `θ_support` its belief state falls — automatically.

### R11.7 — Consolidation: eleven gates, and it CREATES rather than MOVES

```
G0  ELIGIBILITY    evidence_status ≥ E3 · anchored · retention permits ·
                   not VOID · not EXPIRED
G1  **CONTRADICTION FIRST**   no unresolved contradiction within scope
                   ⟵ **MOVED FROM THIRD POSITION TO FIRST. A contradicted
                      record is NOT a consolidation candidate at any
                      importance**
G2  INBREEDING     inbreeding_F ≤ F_max
G3  **EXTERNAL QUOTA**   ≥ [G] fraction of **`n_effective`** — NOT of record
                   count — must come from SC-1…SC-6
G4  SELECTION      by **DEPENDENCY** and evidence_status. **NEVER by
                   `importance`**
G5  REPLAY         **a READ operation. Does not write to the replayed
                   records**
G6  GROUPING       by claim identity and context-scope intersection
G7  GENERALIZATION R6.6's four bounding rules
G8  VERSIONING     `version_kind = MERGE`; **ALL SOURCES RETAINED**
G9  COMPRESSION    **ONLY NOW, and ONLY to L1.** Sources may be compressed
                   to L2/L4 on a [G] schedule
G10 AUTHORIZATION  Memory Service executes; Memory Authority approves.
                   **⟹ T4 REQUIRES E4. A consolidation whose inputs are E3
                      produces an E3 record at T2, NOT a T4 record.
                      CONSOLIDATION ALONE CANNOT REACH T4**
G11 ANCHOR         at the next epoch (MEM-T2)
```

**Stability mechanisms:** the derived record never supersedes its sources ⟹ a bad consolidation is reversible by ignoring it · consolidation RATE is a KC-3 ceiling · `inbreeding_F ≥ max(sources)` ⟹ **repeated consolidation of the same material monotonically raises `F` toward `F_max`, at which point G2 blocks further consolidation. Consolidation is self-limiting.**

**V3 §11's pipeline (`replay → importance → conflict → compression → generalization → versioned storage`) is SUPERSEDED: `importance` was undefined and in second position; conflict detection ran too late; compression ran before generalization and could discard the scope detail generalization needs; and there was no evidence-status gate anywhere.**

---

## PART 12 — SECURITY

### R12.1 — Seven security properties

**SP-1 NON-REWRITABILITY** (immutability — stronger than access control, which prevents only *unauthorized* writes) · **SP-2 NON-FABRICABILITY** (roots must resolve in the Anchor; **an invented hash does not resolve ⟹ rejection + `E_PROVENANCE` + immune report; roots are appended by the Anchor, not by subjects**) · **SP-3 ATTRIBUTION** (`src_identity` DERIVED from channel binding, never declared) · **SP-4 CONFIDENTIALITY** · **SP-5 SELECTIVE-AVAILABILITY RESISTANCE** (**⚠️ PARTIAL**) · **SP-6 ERASURE IRREVERSIBILITY** · **SP-7 AUDIT PERMANENCE**.

**⚠️ The Anchor's root registry MUST commit to a CONTENT DIGEST, not only to an identity.** Without this, provenance laundering is trivial: a genuine root with misattributed content passes SP-2.

### R12.2 — The trust boundary

**A subject is trusted for its own T0 and local-episodic content, and for NOTHING that crosses a tier boundary.** Every epistemic field on a shared-tier record is written by a principal ABOVE the subject: `evidence_status` by an external gate · `inbreeding_F` by the Anchor · `gt_class` by EVA · `protection_tag` by the Registrar · `src_identity` by channel binding · `calib_ref` by EVA.

### R12.3 — Six compartments

**AC-1 PRIVATE** (subject only; EVA under β sampling; immune under an incident) · **AC-2 CIRCUIT** · **AC-3 REGION** · **AC-4 ORGANISM** · **AC-5 PROTECTED** (OP authorization) · **AC-6 ANCHOR-ONLY** (audit only, off-line, under KC authorization).

**Capability-based, NOT ACL-based** — because an ACL is a property of the RECORD (so the record's writer would influence it), while a capability is a property of the SUBJECT, issued by a principal above it. **⟹ Capability-based access is the only model in which a subject cannot influence its own read scope.**

**Four rules:** the compartment check runs **BEFORE** dedup and **BEFORE** any index lookup · **an agent model of subject X is NOT in X's compartment** · **a DECLINE reveals nothing** · cross-compartment aggregation is **evaluator-side, never runtime**.

### R12.4 — ⚠️ Three attacks remain OPEN, and they are one problem three times

**#25 dim-6 shared latent assumption** — *the assumption is shared by the instrument that would detect it.*
**#56 differential serving** — *the serving is controlled by the service that logs the serving.*
**#62 semantic self-reference** — *the meaning is constituted by the records whose meaning is circular.*

**In all three, the mechanism is inside the thing being audited.** This is the same limit recorded by P0-02 (KC self-reference), P0-03 (CD-C8/CD-C12), and the Cell Contract (FM-4 `[U]`). **It is unclosable from inside by construction, not by insufficient effort.** The architecture bounds their CONSEQUENCES and DECLARES their residue.

---

## PART 13 — DISTRIBUTED OPERATION

### R13.1 — Global strong consistency is NOT required, and requiring it would be harmful

Three arguments: **COST** (a consensus round per write is `O(N)`) · **AVAILABILITY** (history must keep being written when witnesses are unavailable) · and — **decisively** — **EPISTEMICS**: *two regions holding DIFFERENT belief states about the same claim is not an inconsistency to be repaired; it is a correct representation of the fact that they have different evidence. **Forcing agreement would be forcing belief by consensus, which is `L7`, which is PROHIBITED.***

### R13.2 — Consistency is epoch-grained

**The Anchor supplies a TOTAL ORDER ON EPOCHS without a global clock and without per-write consensus.** Within an epoch the order is PARTIAL, and that is correct. `causal_depth` + `root_commit` supply the partial order that survives clock skew. **Where two records' intervals overlap and their causal order is unknown, the order is UNKNOWN — and `UNKNOWN ≠ DISJOINT`.**

### R13.3 — Consistency matrix

**T0 / cell-local:** NONE · **T1 / T2 / T4:** CAUSAL, epoch-grained · **T3 PROCEDURAL:** ⚠️ **STRONG** — *the ONLY class requiring it, justified because two regions executing different versions of the same skill is a safety failure; a region that cannot reach the service STALLS rather than diverges* · **T5 / Lineage / Audit:** APPEND-ONLY IMMUTABLE (**stronger than consistent — there is nothing to reconcile**) · **The Anchor:** TOTAL ORDER ON EPOCHS, `O(R)` per epoch · **`ContradictionRecord`s:** APPEND-ONLY, UNION · **⚠️ BELIEF STATES: NONE — DIVERGENCE IS CORRECT** · **derived quantities (`n_effective`, `KNOWS`, rank, `importance`): N/A — computed on read, no consistency mode** · **views:** EVENTUAL, rebuildable.

### R13.4 — Replica divergence

Different belief states: **LEGITIMATE, not reconciled.** Different record sets: **UNION.** Different content for one `mem_id`: **ILLEGITIMATE — the anchored root decides; FD, then FZ below `W_min`.** Different derived state: **RE-EVALUATE.** Different retention/deletion states: **the Anchor's deletion log decides.** **NEVER VOTE.**

### R13.5 — Recovery's four prohibitions *(MEM-INV-39)*

Recovery MUST NOT: **reconstruct beliefs** (a lost chain ⟹ `UNKNOWN`, never re-derived) · **re-run evaluation** (re-execution under current policy is not reproduction) · **resolve contradictions** (open records are recovered in their recovered state, including `UNRESOLVED` — **a crash is not a deadline**) · **fill gaps by inference** (a missing record is `UNKNOWN`, recorded as such).

### R13.6 — The off-line boundary *(MEM-INV-44)*

**Any operation whose cost is unbounded in the corpus is an evaluator-side operation, executed off-line over anchored records, never by the Memory Service at runtime.** Six such operations: retroactive invalidation / rollback · full claim-graph analysis · survivorship audit · cross-compartment aggregation · abstraction-hierarchy analysis · bias-detection distribution comparison.

**⟹ Audit reads the ANCHOR, not the subject. A compromised subject cannot obstruct an audit of itself.**

---

## PART 14 — THE INVARIANTS

### R14.1 — Fifty invariants in six groups *(full text in Vol E §73.2)*

| Group | **Invariants** |
|---|---|
| **I — SEPARATION** | **MEM-INV-01** retrieval ⟹̸ truth · **02** `source_class` IMMUTABLE · **03** unresolvable root ⟹ UNANCHORED ⟹ no consequential decision · **04** `inbreeding_F` Anchor-computed, read-only · **05** simulated ≠ observed · **08** no internal belief→verdict path · **24** NO SCALAR CONFIDENCE EXISTS ANYWHERE · **28** `gt_class = L7` PROHIBITED · **46** a model can never be `GROUNDED` internally |
| **II — PROVENANCE** | **06** no in-place modification · **11** dim 6 NOT DETECTABLE FROM INSIDE *(declarative)* · **14** `causal_depth` SATURATES, NEVER WRAPS · **16** a version chain MUST NOT increase warrant · **22** `storage_tier` is DERIVED · **37** anchored records CANNOT be deleted · **38** deletion is a transformation with an authority and a reason · **42** a merge MUST NOT hide roots |
| **III — BELIEF & EVIDENCE** | **07** a contradiction resolution requires a declared reason and authority · **09** retrieval MUST NOT write to the retrieved record · **10** a record's own re-emissions are not independent support · **12** repetition MUST NOT shorten validity, raise status, or lower staleness · **13** consolidation/generalization MUST NOT raise `n_effective` above the minimum · **23** `KNOWS` computed, never stored · **25** `n_effective` computed, never stored · **26** the `source_class` ceiling is ABSOLUTE · **27** a derived record inherits the MINIMUM source class · **31** BOTH contradicting records are retained · **32** `UNRESOLVED` is stable with NO DEADLINE · **33** EVERY belief-state INCREASE requires an external gate; every DECREASE may be internal · **41** the external-evidence quota is on `n_effective`, NOT on record count · **43** abstraction warrant is monotone non-increasing UP the hierarchy · **47** a prediction has THREE mandatory outcomes; unresolved past deadline is a CALIBRATION FAILURE |
| **IV — TEMPORAL & CONTEXTUAL** | **29** `context_scope` MANDATORY; undeclared scope is UNKNOWN, never UNIVERSAL · **30** NO OPERATION WIDENS A SCOPE · a timestamp is never evidence · temporal precedence never establishes causation · a contradiction is always scoped to an interval |
| **V — RETRIEVAL** | **34** the response is a set of TRIPLES; a bare ranked list is a PROHIBITED RETURN TYPE · **35** six signals are PROHIBITED as ranking inputs · **36** index failure is NEVER record failure · **45** the compartment check runs BEFORE dedup and index lookup · `purpose_class` selects monotone-removing filters only · a DECLINE reveals nothing · four distinct empty-result reasons |
| **VI — AUTHORITY, LIFECYCLE & SCALE** | **15** retention/eviction/forgetting MUST NOT be epistemic inputs · **17** superseded/void/retracted/expired are AUDIT-readable and never citable as current · **18** NO memory operation may write to a genome · **19** learned state and inherited genome MUST be distinguishable BY FIELD · **20** lineage is a GOVERNANCE RECORD, not a memory · **21** retention bounds and admission gates are POLICY and NOT heritable · **39** recovery's four prohibitions · **40** memory MUST NOT decide truth or authorize acts · **44** corpus-unbounded operations are evaluator-side · **48** T3 is the ONLY strong-consistency class; STALL rather than diverge · **49** NEVER VOTE · **50** `importance` is an ALLOCATION quantity, NEVER an epistemic input |

### R14.2 — The three classes of invariant

**STRUCTURAL (18)** — no operation exists that could violate them. Tested by schema inspection and attempted-violation tests that must fail to be expressible.
**CHECKABLE (22)** — a runtime check exists and can fire. Tested by conformance tests with known-violating inputs.
**DECLARATIVE (3)** — **MEM-INV-11 (dim 6), MEM-INV-32's «no deadline», and R12.4's W-4 undetectability.** These state a LIMIT; compliance means DECLARING the limit, not closing it.

**⟹ A specification that presented all fifty as equally "enforced" would be presenting three declarative limits as defenses.**

---

## PART 15 — PARAMETERS

### R15.1 — Four classes (54 parameters, the KC-3 ceilings being a governance sub-class), and NO VALUE IS SPECIFIED FOR ANY

**`[G]` GOVERNANCE-DECLARED (24)** — `epoch_length` (**five inseparable meanings**) · `W_min` · `n_corr` · **`instrument_class_diversity_min`** · `θ_support` · `F_max` · `κ_min` · `n_indep` · `PROTECTED_FRACTION_MAX` · `WM_CAP`/`EPI_CAP` · `τ` prior · `θ_write`/`θ_recall` priors · `RETR_BYTES_MAX` · `graph_depth_bound` · `revalidation_budget` · `online_root_registry_window` · `storage_budget` · `CAP_CACHED`/`CAP_FRESH` (**`CAP_CACHED < CAP_FRESH`**) · `staleness_grace_period` · `zero_contradiction_duration` · MEM-D1…D6 thresholds · `scale_class` boundaries · compartment assignment rules · **`external_evidence_quota` (ON `n_effective`)**.

**`[KC-3]` CEILINGS (5)** — write rate · deletion rate · consolidation rate · protection-request rate · version-creation rate. **All `O(1)` cached, partition-surviving, BACKSTOPS not adjudicators.**

**`[D]` DERIVED, NEVER STORED (9)** — `n_effective` · `KNOWS` · `warrant` · `storage_tier` · `rank` · `revalidation_priority` · `importance` · `warrant_class` · `access_class`.

**`[X]` EXTERNAL, NEVER SELF-REPORTED (9)** — `evidence_status` · `gt_class` · `gt_state` · `calib_ref` · `inbreeding_F` · `protection_tag` · `lineage_ref` · `src_identity` · `epoch`.

**`[U]` UNRESOLVED (7) — NO MECHANISM OR VALUE INVENTED FOR ANY:**
1. **`semantic_self_reference_score`** — *no rigorous mechanism exists.* Inherited verbatim from FM-4's `[U]`. **THE PRINCIPAL UNCLOSED DEPENDENCY.**
2. **The `importance` function** — role bounded by MEM-INV-50, consequences monitored by MEM-D1…D6, **definition open** (inherited G-P1-8).
3. **The retention-curve functional form** — `exp(−Δt/τ) × importance` is **inherited with no derivation, no measurement, and no compared alternative, and it multiplies an undefined function.** This contract adopts the ROLE and marks the FORM `[U]`.
4. **Semantic claim identity across time** — structural identity decidable; semantic identity not.
5. **`PROTECTED_FRACTION_MAX`'s value** — no principled derivation; the tension is not closable.
6. **`online_root_registry_window`'s value** — no principled derivation.
7. **`F_max`'s value** — no principled derivation; **and an ANCHORED internally-generated evidence set has a low measured `F`, because the anchor attests PROVENANCE, not EXTERNALITY OF ORIGIN.**

**⟹ The parameters this contract refuses to value are precisely those that determine the architecture's BEHAVIOURAL DISPOSITION — how much self-reference before abstention, how much evidence before belief, how long a lie may go unwitnessed, how much history before ossification. These are not engineering constants. They are value judgements with epistemic consequences, and inventing values would be inventing the architecture's disposition toward doubt.**

---

## PART 16 — THE HYBRID, EXACTLY

### R16.1 — What the memory architecture consists of

> **HYBRID = E** (event-sourced append-only local logs + Merkle aggregation) as the **PROVENANCE AND AUDIT** substrate · **C** (hierarchical cell→circuit→region→organism) as the **LOCALITY AND AGGREGATION** structure · **B** (distributed storage with per-tier ownership) as the **STORAGE** layer · **F** (bounded-depth claim graph) as the **CLAIM-RELATION** structure · **H** (symbolic) as the **CLAIM AND CONTEXT** representation · **D** (content-addressed) as the **DEDUP AND LOCAL ASSOCIATIVE INDEX** · **G** (vector) as **ONE similarity-retrieval index among five, never as an identity, a warrant input, or the memory model.**

**The partitioning variable is the FUNCTION the record serves:**
```
  EXACT AND IMMUTABLE   ⟶ E + H    (provenance, claim, context)
  LOCAL AND CHEAP       ⟶ B + C    (storage, aggregation)
  RELATIONAL            ⟶ F        (contradiction, derivation, support,
                                    supersession, VOID)
  FAST AND LOSSY        ⟶ D + G    (retrieval indexes)

  ⟹ **THE EPISTEMIC CONTENT LIVES IN E+H+F. THE PERFORMANCE LIVES IN
     B+C+D+G.** An index may be wrong, lossy, stale, hardware-specific, and
     rebuilt from scratch. **A CLAIM MAY NOT.**
```

**Six components is the smallest hybrid satisfying all fourteen criteria — and minimality of the COUNT is not proven, only that five fails.**

### R16.2 — The knowledge-representation composition

**ANNOTATED RELATIONS (provenance semiring)** — a record is a claim annotated with its provenance, and annotations **COEXIST rather than combine** · **+ INTERVAL TEMPORAL LOGIC (event calculus)** — a claim holds during an interval in a context · **+ AGM-STYLE NON-MONOTONIC REVISION** — expansion, revision, contraction, **and the recovery postulate is exactly MEM-INV-17**.

**⟹ AND DELIBERATELY ABSENT FROM ALL THREE: AN INFERENCE ENGINE.** The claim graph represents relations; **it does not perform inference.** A memory subsystem that infers is a second evaluator, and R3.2's no-internal-path rule is violated.

**REJECTED:** probabilistic KR (a distribution is a scalar with extra steps — it can be updated by anything, including retrieval; and Dempster–Shafer's combination **ASSUMES the independence that must be COMPUTED**) · logical KR (*ex falso quodlibet* — classical logic cannot represent a stable inconsistency, and the closed-world assumption makes absence into negation) · latent/embedding KR as a model (six structural failures; **two opposing claims being adjacent in embedding space is what a vector store DOES**).

---

## PART 17 — CONFORMANCE

### R17.1 — The prerequisite

> **EVERY TEST OF THIS CONTRACT REQUIRES A TASK WITH ω < 1.** A task with ω = 1 cannot test memory or belief maintenance — a memoryless agent performs identically. **⟹ A conformance suite built on fully-observable tasks tests nothing about memory and will pass an implementation with no memory at all.**

### R17.2 — Seven test classes

**CT-A SCHEMA** — the 31 fields exist with declared classes; **the seven record-level prohibited fields DO NOT EXIST, and no workspace item carries `relevance`**; the nine `[D]` quantities are not stored. *Requires no ground truth.*
**CT-B STRUCTURAL IMPOSSIBILITY** — attempted-violation tests that must fail to be expressible: modify a record in place · write `evidence_status` from a subject · change `source_class` · widen a `context_scope` · write to a genome · store `n_effective` · return a bare ranked list · wrap `causal_depth` · vote on reconciliation. *Requires no ground truth.*
**CT-C INDEPENDENCE** — **⟵ THE MOST VALUABLE CLASS.** Supply a synthetic corpus with KNOWN correlation structure and assert computed `n_effective` matches the known value. *Requires no ground truth, because **correlation structure is a property of the corpus, not of ℛ**.*
**CT-D MONOTONICITY** — apply every operation; assert `warrant` non-increasing, `n_effective` non-increasing, `inbreeding_F` non-decreasing, `scope` non-widening, `evidence_status` non-increasing without a gate. *Requires no ground truth.*
**CT-E MACHINE CONFORMANCE** — the six state machines: every transition fires only on its declared trigger; **every INCREASE has an external trigger**; `UNRESOLVED` is reachable and stable; the four recovery prohibitions hold. *Requires no ground truth.*
**CT-F ATTACK REPLAY** — replay the 78 catalogued attacks and assert the declared disposition: **58 structurally impossible · 2 closed only CONDITIONALLY (#3 requires the Anchor's content-digest commitment; #64 is closed for reading, open for inference-from-treatment) · 12 bounded · 3 detectable · 3 DECLARED (not defended).**
**CT-G SCALE** — run at 10¹, 10⁶, 10¹²; assert no runtime operation becomes super-linear; assert the six off-line operations remain off-line. *Requires no ground truth.*

**⟹ SIX OF SEVEN CLASSES REQUIRE NO GROUND TRUTH AT ALL. The epistemic machinery is directly testable using synthetic correlation, without the architecture being right about anything except counting, ordering, and refusing.**

### R17.3 — Six properties that are NOT testable, declared

Dim-6 independence · semantic self-reference · differential serving by a plausible decline · authorized-but-self-serving forgetting · warrant wrongness in a domain with no ground-truth supply · whether a coherently wrong belief is wrong. **Each is registered rather than defended.**

### R17.4 — Implementation prohibitions

An implementation MUST NOT: store any `[D]` quantity · let the substrate assign `evidence_status` · make `source_class` mutable · return a bare ranked list · implement retrieval as a write · implement `causal_depth` as a wrapping counter · resolve contradictions by averaging or voting · implement recovery as belief reconstruction · implement forgetting as deletion of the anchored fact · implement the claim graph with an inference engine · implement `UNREVALIDATABLE` as `EXPIRED` or as `FRESH` · **implement a scalar confidence anywhere, including internally.**

### R17.5 — What is invariant across implementations

The 31-field schema and field classes · the four axes · every enumeration (E0–E4, twelve belief states, fourteen source classes, seven contradiction types, six ignorance kinds, five retention classes, five deletion states, five version kinds, six compartments) · the six state machines and every transition's externality · the authority matrix · all fifty invariants · the cost classes.

**What varies:** field encoding · `[G]` values · the storage substrate · the index implementations (**I-3 similarity is explicitly NON-portable — an embedding is a function of the model that produced it**) · W5's form (**the REQUIREMENT — ≥1 witness outside operational control — is portable; the MECHANISM is not**) · θ, retrieval weights, and `plasticity_mult` (**learned state is neither portable nor heritable, by design**).

**A record whose `validity` depends on hardware MUST declare `context_scope.hw_class`. An undeclared hardware dependence degrades safely: unknown scope ⟹ warrant reduction, never a match.**

---

## PART 18 — WHAT THIS CONTRACT DOES NOT CLAIM

> **1.** It does **NOT** claim the system always knows the truth. **Truth is not an architectural object (R3.2).**
> **2.** It does **NOT** claim perfect capability detection, safety, or containment.
> **3.** It does **NOT** claim to detect a coherently wrong belief with valid provenance. **It claims something weaker and achievable: such a belief can never be MARKED as externally warranted from inside, because `SC-7`'s ceiling is E3 and E3→E4 requires an L0–L3 measurement (R5.8, R8.5).**
> **4.** It does **NOT** claim to detect semantic self-reference. **`[U]`, OR-M1, attack #62 OPEN.**
> **5.** It does **NOT** claim to close the selection ⟷ filtering circle. **OR-M18, CD-M8/CD-M9 UNCLOSED — the fourth unclosable circular dependency in the P0 series.**
> **6.** It does **NOT** claim global contradiction detection. **Detection is guaranteed within a shard at write time, within a region per epoch, and across regions only on contact. A cross-region contradiction may remain undetected indefinitely — and this is not a defect: forcing global belief agreement would be `L7` consensus (R13.1).**
> **7.** It does **NOT** claim unlimited scale coverage. **At 10¹² subjects the architecture has a FINITE EPISTEMIC HORIZON: only the last `[G]`-declared window of evidence supports a consequential decision without an off-line round trip; revalidation coverage is small; and the protected fraction is binding.**
> **8.** It does **NOT** claim to satisfy unconditional erasure. **R11.4.1 and unconditional erasure are INCOMPATIBLE, and this contract says so.**
> **9.** It does **NOT** claim consciousness, AGI, or superiority. **It claims one thing: that a record's epistemic type is set by an external gate at entry, can rise only by passing another external gate, and cannot be raised by anything that happens to it inside memory.**
> **10.** It does **NOT** resolve the seven `[U]` items or supply a value for any of the twenty-four `[G]` parameters.

---

## PART 19 — THE CONTRACT IN ONE PAGE

```
1.  A record's standing is FOUR axes, not one: EVIDENCE STATUS (external
    gates) · WARRANT CLASS (policy) · BELIEF STATE (organism, externally
    correctable) · GROUND-TRUTH CLASS (EVA). Plus VALIDITY (time × context).
2.  TIER = f(EVIDENCE STATUS). A memory is promoted ONLY by passing an
    external gate — never by being remembered, repeated, retrieved,
    compressed, or propagated.
3.  KNOWLEDGE is a PREDICATE computed on read. TRUTH is not an object.
    "FACT" is a prohibited term.
4.  `source_class` is IMMUTABLE and sets an ABSOLUTE ceiling. Fourteen
    classes. INTERNAL_CONSENSUS is capped at E0, permanently.
5.  WARRANT IS MONOTONE NON-INCREASING under every memory operation.
    `n_effective` is monotone non-increasing. `inbreeding_F` is monotone
    non-decreasing. Scope never widens. Abstraction never strengthens.
6.  NOTHING EPISTEMIC IS STORED THAT CAN BE COMPUTED: `n_effective`,
    `KNOWS`, `warrant`, `rank`, `importance` are all derived on read.
    NO SCALAR CONFIDENCE EXISTS ANYWHERE.
7.  RETRIEVAL WRITES NOTHING. It answers «what matches?», never «what is
    true?». Its response is a set of (record, rank, evidence_status)
    TRIPLES; a bare ranked list is a prohibited return type.
8.  CONTRADICTION: both records retained, always scoped to an interval,
    seven types (five of which are not contradictions about the world),
    eight exits — one of which is UNRESOLVED, which is stable and has no
    deadline. NEVER VOTE, NEVER AVERAGE.
9.  RECORDS ARE IMMUTABLE. Change is a new version. ANCHORED RECORDS CANNOT
    BE DELETED — content may be erased, the anchored fact is permanent.
10. FORGETTING changes where a record is, never what it means.
11. IGNORANCE IS SIX STATES, not a low number. Absence is NEVER negation.
12. THE SUBJECT IS UNTRUSTED FOR EVERY EPISTEMIC FIELD. Memory policy is
    OP-owned — a cell may not vary its own retention, protection, or
    admission rules, and those rules are not heritable.
13. GLOBAL STRONG CONSISTENCY IS NOT REQUIRED, and belief states MUST
    diverge — forcing agreement would be consensus, which is prohibited.
    T3 PROCEDURAL is the only strong-consistency class.
14. CORPUS-UNBOUNDED OPERATIONS ARE OFF-LINE. Audit reads the Anchor, not
    the subject.
15. ACQUIRED MEMORY NEVER REWRITES THE GENOME. What is selected is the
    CAPACITY to acquire, never what was acquired.
16. THE EPISTEMIC CONTENT LIVES IN THE RECORDS, THE GATES, THE CLAIM GRAPH,
    AND THE ANCHOR. The indexes are paths — removable, rebuildable, and
    epistemically inert.
17. NO PARAMETER VALUE IS SPECIFIED. Seven items are `[U]` and remain so.
18. THREE ATTACKS REMAIN OPEN — dim-6 shared assumption, differential
    serving, semantic self-reference — AND THEY ARE ONE PROBLEM THREE
    TIMES: the mechanism is inside the thing being audited.
```

---

**— END OF V4 MEMORY, KNOWLEDGE, PROVENANCE & BELIEF CONTRACT v1.0 (OUTPUT 53) —**

*Derivation and argument: Vol A `32_…` (§0–§16) · Vol B `33_…` (§17–§33) · Vol C `34_…` (§34–§55) · Vol D `35_…` (§56–§72) · Vol E `36_…` (§73–§80) · Vol F `37_…` (§81–§101). Executive verdict, candidate comparison, §102 ratings, §103 principles, and §104 FINAL STANDARD: `README.md`.*
