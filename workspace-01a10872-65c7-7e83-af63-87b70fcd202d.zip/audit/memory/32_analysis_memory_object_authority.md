# P0-04 — MEMORY, KNOWLEDGE, PROVENANCE & BELIEF ARCHITECTURE
## Volume A: The Four Axes, the Memory Object, Authority & Provenance (§0–§16)

**Package:** P0-04, fourth of the P0 series. **Mode:** ARCHITECTURE ONLY — no code, no deployment, no scripts, no benchmarks.
**Companions:** `33_analysis_belief_retrieval.md` (B) · `34_analysis_lifecycle_interfaces.md` (C) · `35_analysis_scale_cognition_attacks.md` (D) · `36_analysis_formal_specification.md` (E) · `37_analysis_audit_testability.md` (F) · `38_v4_memory_knowledge_provenance_belief_spec.md` (**Output 53**) · `README.md` (**Outputs 1, 2**, §99, §102–§104)
**Outputs delivered here:** **3** (canonical memory model) · **4** (canonical memory object) · **5** (canonical memory taxonomy) · **6** (authority matrix) · **7** (Memory ↔ EIK) · **8** (Memory ↔ Communication) · **17** (source/warrant taxonomy) · **18** (provenance architecture) · **19** (provenance compression)

---

# §0. THE ROOT FINDING

## 0.1 The dangerous loop, and why the inherited design cannot stop it

The brief names the loop:

```
Observation → Message → Memory → Belief → Communication
    → Repeated propagation → Apparently independent evidence
    → Belief strengthening → Memory → …
```

**P0-03 closed half of it.** COMM-INV-17 (`n_effective` collapses correlated sources), COMM-INV-08 (warrant never increases under transformation), R42.1 (`warrant(retrieve(x)) ≤ warrant(x)`, `n_obs` contribution from a retrieval = **0**, `causal_depth` contribution = **+1**), and FM-4's `inbreeding_F` together mean that **propagation cannot manufacture independent evidence and retrieval cannot manufacture corroboration.**

**The half P0-03 could not close is the half that lives inside memory.** P0-03 governs what crosses a boundary. It has nothing to say about what happens to a record that stays put and is *promoted* — from working memory to episodic, from episodic to semantic, from semantic to protected, from a specific instance to a general rule. **Every one of those promotions increases the record's authority, and not one of them is a communication event.**

> ### **THE ROOT FINDING: the inherited design has ONE epistemic axis where it needs FOUR, and the collapse is exactly what makes the loop closable.**

Look at V3 §11's BELIEF RECORD:

```
BELIEF RECORD
├── content
├── confidence              ⟵ a SCALAR
├── evidence                ⟵ a LIST, unbounded
├── source                  ⟵ a SINGLE value
├── provenance
├── contradictions
├── last verification       ⟵ a TIMESTAMP
├── transformation history
└── independent confirmation ⟵ **A STORED FIELD**
```

**Nine fields, and at least four of them collapse distinct axes into one quantity:**

| Field | **What it collapses** | **Why that is fatal** |
|---|---|---|
| **`confidence`** (scalar) | Observation-confidence and belief-confidence (P0-01 **R6.4**: «distinct quantities and MUST NOT be conflated. The former is an input property; the latter is an output property») | A single scalar cannot express «I am confident because I saw it» and «I am confident because I inferred it» — and those two must never be treated alike (§12, MEM-INV-02) |
| **`independent confirmation`** | **The number of confirmations and whether they are independent** | ⟵ **THIS IS THE WORST FIELD IN THE INHERITED DESIGN.** A stored count of "independent confirmations" is a **counter that increments on every confirmation, and the architecture has no way to know whether the confirmations were independent.** It is §15's false-evidence-multiplication attack **built into the schema as a first-class field.** An attacker does not need to defeat an independence check; it needs to increment a counter. **P0-03's `n_effective` was designed precisely to replace a count with a collapsed count — and V3 §11 has the uncollapsed count sitting in the belief record** |
| **`last verification`** | When it was verified and **whether the verification is still valid** | A timestamp is not a validity interval, and COMM-INV-12 («a timestamp is never evidence») applies. **`last_verification` invites the inference «recently verified ⟹ still true», which is §22's staleness failure** |
| **`evidence`** (unbounded list) | The evidence set and its **anchored commitment** | ⟵ X-C from P0-03: an unbounded array in a bounded record. **And in memory the problem is worse than in a message, because a memory record persists: an unbounded `evidence` list grows for the lifetime of the record** |

## 0.2 The four axes

> ### **R0.1 (THE FOUR-AXIS MODEL).** *A memory record's epistemic standing is not one quantity. It is four, owned by four different principals, changing on four different timescales, and none of them is an input to any of the others.*

| Axis | **Question it answers** | Values | **Owner** | Changes when |
|---|---|---|---|---|
| **1. EVIDENCE STATUS** | **What may this enter?** | **E0 RAW · E1 CORROBORATED · E2 ATTRIBUTED · E3 ADMISSIBLE · E4 GROUNDED** (P0-01 §6.3's ladder) | **EXTERNAL gates** (corroboration, anchor resolution, contradiction check, ground-truth agreement) | **Only on passing a gate.** Never by being remembered, retrieved, repeated, or propagated |
| **2. WARRANT CLASS** | **What must a receiver check?** | **S0–S4** (P0-03 §72) | **Policy** (RO-13), from the message type | Only by policy change |
| **3. BELIEF STATE** | **What is the organism's current posture?** | §17's state set | **The organism** (internally maintained), **externally correctable** | On new evidence, on contradiction, on staleness, on revalidation |
| **4. GROUND-TRUTH CLASS** | **Who says so, and does it touch ℛ?** | **L0 ORACLE · L1 MATHEMATICAL · L2 PHYSICAL · L3 REDUNDANT INDEPENDENT · L4 HUMAN · L5 TRUSTED DB · L6 POST-HOC OUTCOME · ~~L7 DERIVED/CONSENSUS~~** (P0-01 §8.2) | **EVA / the task specification** | Only by external measurement |
| *(5. VALIDITY — the temporal axis)* | **During what interval, under what context?** | `[t_start, t_end)` × context scope | §22–§24 | On supersession, on context change, on revalidation |

**Why four and not one — the operational consequence:**

```
WITH ONE AXIS (the inherited design):
  "remembered more often" and "better evidenced" are THE SAME QUANTITY.
  ⟹ retrieval strengthens belief.
  ⟹ propagation strengthens belief.
  ⟹ repetition strengthens belief.
  ⟹ **THE LOOP CLOSES, AND IT CLOSES INSIDE MEMORY WHERE P0-03 CANNOT SEE IT.**

WITH FOUR AXES:
  Retrieval changes NOTHING on any axis. It is not a gate (axis 1), not a
  message (axis 2), not new evidence (axis 3), and not a measurement
  (axis 4). **Retrieval is an ALLOCATION event — it consumes budget and it
  produces a candidate set, and that is all.**
  ⟹ **THE LOOP DOES NOT CLOSE, BECAUSE THE "BELIEF STRENGTHENING" STEP
     REQUIRES AN AXIS-1 PROMOTION, AND AXIS 1 IS EXTERNALLY GATED.**
```

**R0.2 (THE ADMISSION PRINCIPLE — the second half of the root finding).** *Memory TIER is a function of EVIDENCE STATUS.* P0-01 §6.3 already wired this and nobody picked up the wire:

| Evidence status | **What P0-01 says it may do** | ⟹ **Memory tier it may enter** |
|---|---|---|
| **E0 RAW** | «may influence WORKING MEMORY only» | **Working memory** |
| **E1 CORROBORATED** | «may influence belief formation» | **Belief formation — transient, not persisted** |
| **E2 ATTRIBUTED** | «may be written to EPISODIC MEMORY with provenance» | **Episodic memory** |
| **E3 ADMISSIBLE** | «may contribute to `evidence_roots` on an emitted belief» | **Claim graph / semantic memory** |
| **E4 GROUNDED** | «may support CONSOLIDATION, calibration scoring, and fitness» | **Consolidated semantic memory · protected memory · anchored history** |

> ### **⟹ A MEMORY CANNOT BE PROMOTED BY BEING REMEMBERED. IT CAN ONLY BE PROMOTED BY PASSING AN EXTERNAL GATE. This is the structural answer to §1's loop, to §30's self-corruption, to §31's consolidation, and to §32's generalization — and it is a single sentence.**

## 0.3 The three defects this package finds that no prior package named

| # | Defect | **Where** | **Why nobody caught it** |
|---|---|---|---|
| **D-1** | **`independent confirmation` is a stored counter with no independence check** | V3 §11 BELIEF RECORD | P0-03 built `n_effective` for *messages*. Nobody looked at whether the *belief record* had the same defect. **It has the defect in its rawest form: a field whose name asserts the property it cannot verify** |
| **D-2** | **`importance` gates write, retention, AND consolidation — and it is undefined and cell-influenced** | Cell §8.2 (`importance × surprise ≥ θ_write`), A-12 (`importance × recency × (1 − protection)`), V3 §11 (`replay → importance → …`), **G-P1-8: «Exact `importance` function … the function is not defined»** | The Cell Contract flagged it as an open gap but did not notice that **one undefined scalar controls what enters memory, what survives, and what gets promoted.** Combined with audit L1832's finding — **«The S2 gate being cell-influenced is a genuine, unresolved vector: a cell can choose what to notice»** — this means *a cell can bias its own evidence base by biasing an undefined scalar.* **§11 and §28 address it** |
| **D-3** | **`causal_depth: u8` saturates at 255, and saturation behaviour was never specified** | P0-03 X-D's replacement field | **A saturating counter that WRAPS produces the inverse of its intended effect: a chain of depth 256 reads as depth 0 and looks primary.** Memory makes this reachable, because a memory record persists across many re-derivations while a message does not. **MEM-INV-14 requires saturation-at-maximum, never wrap** |

**R0.3.** *D-1 and D-2 are the same defect class P0-03 found twelve times (§68.2 R68.2: a word used at two altitudes at once). «Independent confirmation» uses «independent» at the altitude of a property and stores it at the altitude of a count. «Importance» uses «important» at the altitude of an epistemic judgement and computes it at the altitude of an allocation heuristic.* **§99's false-precision audit gives both operational definitions; §5 separates both into distinct fields on distinct planes.**

## 0.4 What this package does not do

**It does not design a database.** The brief's closing line is the design constraint: *«The objective is not to design a giant database. The objective is to determine whether the Digital Brain can develop persistent, useful, auditable knowledge without becoming trapped by its own memories.»*

⟹ **Everything below is organized around the trap, not around the storage.** Retrieval performance is addressed (§25, §57) because a memory that cannot be queried is not a memory — but it is addressed *after* the epistemic structure, and §26 exists to make sure the performance answer never becomes the epistemic answer.

---

# §1. WHY P0-04 EXISTS — THE CENTRAL PROBLEM

> ### **«How can the Digital Brain accumulate knowledge over time without confusing its own generated beliefs, copied information, predictions, and memories with externally established facts?»**

## 1.1 The answer, in one mechanism and one limit

**THE MECHANISM:** R0.2's admission principle. **The epistemic type of a record is set when it enters, by an external gate, and it can only rise by passing another external gate. Nothing that happens to the record inside memory — retrieval, repetition, consolidation, compression, generalization, re-publication — can raise it.**

**Formally, the four monotonicity rules that constitute the mechanism:**

| Rule | Statement | **What it defeats** |
|---|---|---|
| **MEM-M1** | `evidence_status(m)` is **monotone non-decreasing except on contradiction** (P0-01 R6.2), and **every increase requires an external gate** | Promotion by repetition, by retrieval, by consolidation |
| **MEM-M2** | `warrant(m') ≤ warrant(m)` for any `m'` derived from `m` by any memory operation (storage, transformation, consolidation, compression, retrieval, re-publication) — **COMM-INV-08 extended from messages to memory operations** | Promotion by compression (§33), by generalization (§32), by consolidation (§31) |
| **MEM-M3** | `n_effective` of a derived record **≤** `n_effective` of its sources, computed on P0-03's six correlation dimensions — **and a record's own prior retrievals contribute zero** | §15's false multiplication, §42's memory-mediated independence fraud, D-1 |
| **MEM-M4** | `inbreeding_F` is **monotone non-decreasing under self-derived operations** and is **computed by the Anchor from anchored records, never self-reported** | FM-4, §30's self-reinforcement, §81's recursive self-belief |

**THE LIMIT — and it is the honest core of this package:**

> ### **⚠️ R1.1 (THE HARDEST FAILURE, INHERITED AND NOT CLOSED).** *«A coherently wrong belief with valid provenance is the hardest failure in the architecture»* (Cell Contract audit L1832). **This package does not close it.** A record can have: genuine E2 provenance resolving in the Anchor · a valid `root_commit` · low `inbreeding_F` · high `n_effective` from genuinely independent sources · and still be **false**, because every source shared a latent assumption (P0-03 dim 6) or because the ground truth supply is silent on the proposition.
>
> **What this package DOES do is make it detectable-from-outside and un-promotable-from-inside:** such a belief can reach E3 (admissible, contributes to `evidence_roots`) but **cannot reach E4 without agreeing with an L0–L3 ground-truth claim** (P0-01 §6.3), and **L7 DERIVED/CONSENSUS is prohibited from ever being ground truth** (P0-01 R8.1). ⟹ **The loop terminates at E3, and the step from E3 to E4 is external by construction.** **A coherently wrong belief is therefore permanent, well-provenanced, admissible — and permanently unable to become "grounded" from inside.** That is the strongest available result, and §100 records the residue.

## 1.2 The second half of the central problem: «trapped by its own memories»

The brief's closing sentence names a failure the loop analysis does not cover. **A memory system can be epistemically perfect and still be a trap**, in five distinct ways:

| Trap | Mechanism | **Section** |
|---|---|---|
| **Conservatism** | Failure memory generalizes «failure occurred» into «action is always bad», and exploration stops | §34, §90 |
| **Ossification** | Protected categories accumulate until nothing can be forgotten, and the storage budget crowds out new evidence | §34, §50 |
| **Self-reinforcement** | Retrieval strengthens, importance rises, retrieval rises (§30's loop) | §30, MEM-M3 |
| **Context collapse** | A claim true in context A is retrieved in context B, and the context was not stored | §24 |
| **Availability capture** | What is easy to retrieve determines what is believed, so the retrieval index becomes the epistemology | §27, §28, §57 |

**R1.2 (THE TWO HALVES ARE DIFFERENT PROBLEMS WITH DIFFERENT SOLUTIONS).** *The first half («confusing its own beliefs with facts») is solved by the four-axis separation and external gating. **The second half («trapped by its own memories») is solved by making retention, retrieval, and forgetting ALLOCATION problems on the influence plane, never epistemic problems on the warrant plane.*** **⟹ The same plane discipline P0-03 established for communication is what P0-04 needs for memory — and §0.2's four axes are what make the discipline expressible.**

---

# §2. CANDIDATE MEMORY ARCHITECTURES — **OUTPUT 2**

## 2.1 The fourteen criteria

**Derived from the brief's list and from P0-01/P0-02/P0-03's binding findings — not chosen to favour a candidate.**

| # | Criterion | **Why** |
|---|---|---|
| **K1** | **Retrieval** — can the needed record be found at acceptable cost? | §25, §57 |
| **K2** | **Correctness** — can the record be wrong in a *detectable* way? | §39, §71 |
| **K3** | **Provenance** — can «where did this come from?» be answered exactly? | §13, P0-02 R20.1 |
| **K4** | **Scalability 10 → 10¹²** — no `O(N)` or `O(N²)` global operation | §56, §94 |
| **K5** | **Contradiction handling** — can «we do not know which is correct» be represented? | §20, §58 |
| **K6** | **Temporal reasoning** — before/after/during/validity without perfect timestamps | §23, COMM-INV-12 |
| **K7** | **Compression** — can detail be discarded without discarding a decision property? | §33, P0-03 R63.2 |
| **K8** | **Learning compatibility** — can learning read and write without becoming an epistemic authority? | §44, P0-03 COMM-INV-25 |
| **K9** | **Plasticity compatibility** — can a memory influence plasticity without a synaptic update becoming a declarative memory? | §45 |
| **K10** | **Forgetting** — can it forget safely, including protected categories? | §34, §35 |
| **K11** | **Security** — forgery, poisoning, history rewriting, retrieval manipulation | §40, §41, §42, §72 |
| **K12** | **Fault tolerance** — corruption, partition, replica divergence, recovery | §37, §38, §54 |
| **K13** | **Hardware portability** — semantics invariant across phone → cluster | §88, P0-03 R57.1 |
| **K14** | **Evolutionary compatibility** — acquired memory must not become heritable genome | §46, §47, §89, Cell §3.4 |

**Scale: ✓ satisfies · ◐ partially · ✗ fails · ✗✗ fails structurally (not fixable within the model)**

## 2.2 The comparison matrix

| Criterion | **A** Central | **B** Distributed | **C** Hierarchical | **D** Content-addr | **E** Event-sourced | **F** Graph | **G** Vector | **H** Symbolic | **I** Hybrid |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| **K1** retrieval | ◐ | ◐ | ✓ | ✓ | ✗ | ◐ | **✓** | ◐ | **✓** |
| **K2** correctness | ◐ | ◐ | ◐ | ◐ | **✓** | ✓ | ✗✗ | ◐ | **✓** |
| **K3** provenance | ◐ | ✗ | ◐ | ✗ | **✓** | ✓ | ✗✗ | ◐ | **✓** |
| **K4** scalability | ✗✗ | ✓ | **✓** | ✓ | ◐ | ✗ | ✓ | ◐ | **✓** |
| **K5** contradiction | ◐ | ✗ | ◐ | ✗ | **✓** | **✓** | ✗✗ | ✓ | **✓** |
| **K6** temporal | ◐ | ✗ | ◐ | ✗ | **✓** | ◐ | ✗✗ | ◐ | **✓** |
| **K7** compression | ◐ | ◐ | ◐ | ◐ | ✗ | ◐ | **✓** | ✗ | **✓** |
| **K8** learning | ✗ | ✓ | ✓ | ◐ | ✗ | ◐ | **✓** | ✗ | **✓** |
| **K9** plasticity | ✗ | ✓ | ✓ | ◐ | ✗ | ◐ | **✓** | ✗ | **✓** |
| **K10** forgetting | ◐ | ◐ | ✓ | ◐ | ✗✗ | ◐ | ✓ | ◐ | **✓** |
| **K11** security | ◐ | ✗ | ◐ | ◐ | **✓** | ◐ | ✗ | ◐ | **✓** |
| **K12** fault tolerance | ✗✗ | ✓ | ✓ | ◐ | **✓** | ◐ | ◐ | ◐ | **✓** |
| **K13** hw portability | ◐ | ✓ | ✓ | ✓ | ✓ | ◐ | ✗ | ◐ | **✓** |
| **K14** evolution | ◐ | ✓ | ✓ | ◐ | ✓ | ◐ | ✗ | ◐ | **✓** |
| **✓/◐/✗/✗✗** | **0/8/4/2** | **5/6/2/1** | **6/7/1/0** | **2/6/5/1** | **6/2/4/2** | **2/8/4/0** | **4/1/4/5** | **1/7/6/0** | **14/0/0/0** |

## 2.3 Why each candidate fails — the mechanism, not a preference

| Candidate | **The fatal mechanism** | **Salvageable?** |
|---|---|---|
| **A — Centralized** | **K4 and K12 fail structurally.** One authoritative store is `O(N)` to reach from every subject, is a single point of failure, and — decisively — **is an authority.** §8: a centralized memory that decides what is retained decides what is believed, which makes it a **second governance authority**, violating the brief's final prohibition. **P0-02 §6.1 item 19 already found the security form: «putting the only copy of history inside the thing that could be compromised is the classic error»** | ⚠️ **Only for the ANCHOR, and the anchor is GP-distributed with ≥1 external witness, never a single store** |
| **B — Distributed** | **K3 and K11 fail: knowledge distributed across cells has no provenance owner.** P0-02 §20.1 is definitive: «**Cell — ❌ Definitively not. The cell is the subject of the record. A subject that authors its own provenance can author any provenance.**» And §54's replica divergence has no reconciliation authority | ✅ **As the STORAGE LAYER. Not as the provenance or authority layer** |
| **C — Hierarchical** | **K2/K3/K5 partial: a hierarchy gives locality and aggregation but does not by itself answer «is this true?» or «which of two conflicting records wins?».** It also invites the error of treating *level* as *authority* — a region-level record is not more warranted than a cell-level one | ✅ **As the LOCALITY and AGGREGATION structure — and it is already established (Cell §8.1's in/out table, P0-03 §42.2's hierarchical memory)** |
| **D — Content-addressed** | **K3 and K5 fail structurally: a content hash identifies content, not source.** Two records with the same content and different provenance are the same key — **which is precisely §15's false-multiplication setup, and precisely §42's memory-mediated independence fraud.** Contradiction is unrepresentable because contradicting content has different keys and no link | ✅ **As the DEDUP mechanism (§15) and as the local associative index (Cell §8.1: «Content-addressed index may be local; the store is shared»). ❌ Never as the identity of a claim** |
| **E — Event-sourced** | **K4 and K7 and K10 fail: an append-only log never forgets.** At 10¹² subjects × 10¹² messages, the log is the dominant cost in the system, and §34's forgetting is impossible without violating append-only. **K1 (retrieval) fails: finding a *state* requires replaying history** | ✅ **As the PROVENANCE and AUDIT substrate — and it is already the adopted design (P0-02 §20.2's local append-only logs + Merkle aggregation). ❌ Never as the retrieval substrate** |
| **F — Graph** | **K4 partial: graph traversal is `O(edges)` and unbounded without a depth limit.** K13 partial: graph representations are the least portable across hardware. **But K5 is ✓ and only here — a graph is the only candidate that can represent «A contradicts B, both retained, both sourced»** | ✅ **As the CLAIM RELATION structure (§16) — bounded-depth, `O(1)` per query with precomputed edges. ❌ Never as the storage or retrieval substrate** |
| **G — Vector/embedding** | **K2, K3, K5, K6, K11, K14 fail structurally.** An embedding is a *lossy similarity function*: it cannot express provenance (a vector has no source), cannot express contradiction (two opposing claims can be adjacent in embedding space — **which is §72 #12's semantic-collision attack, and it is not an attack on a vector store, it is what a vector store does**), cannot express temporal validity, and **cannot be hardware-portable because the embedding is a function of the model that produced it (K14: a vector is a learned parameter, and learned parameters are not heritable and not portable).** **Most decisively: similarity is not relevance and relevance is not truth (§27), and a vector store makes similarity the only available query** | ✅ **As ONE RETRIEVAL INDEX among several (§25, §57) — and Cell §8.1 already permits it: «Content-addressed index may be local». ❌ NEVER as the memory model, the provenance model, or the belief model** |
| **H — Symbolic structured** | **K7 and K8 fail: symbolic structures do not compress and do not support gradient-based learning.** K1 partial: exact-match retrieval only. **But K5 is ✓ (logical contradiction is decidable in a symbolic representation) and K2 is ✓ (a symbolic claim is checkable)** | ✅ **As the CLAIM and CONTEXT representation (§16, §24) — the part that must be exact. ❌ Never as the whole store** |
| **I — Hybrid** | — | ✅ **SELECTED — and defined exactly in §2.4** |

## 2.4 **What the hybrid consists of** — the exact definition

**P0-02's standing instruction applies: «Do NOT simply say 'hybrid' unless you define exactly what the hybrid consists of.»**

> ### **HYBRID I = E (event-sourced append-only local logs + Merkle aggregation) as the PROVENANCE AND AUDIT substrate · C (hierarchical cell→circuit→region→organism) as the LOCALITY AND AGGREGATION structure · B (distributed storage with per-tier ownership) as the STORAGE layer · F (bounded-depth claim graph) as the CLAIM-RELATION structure · H (symbolic) as the CLAIM AND CONTEXT representation · D (content-addressed) as the DEDUP AND LOCAL ASSOCIATIVE INDEX · G (vector) as ONE similarity-retrieval index among several, never as an identity or a warrant input.**

**The partitioning variable is the FUNCTION the record serves, not the memory type it belongs to.** That is the whole content of the hybrid:

```
  WHAT MUST BE EXACT AND IMMUTABLE   ⟶ E + H   (provenance, claim, context)
  WHAT MUST BE LOCAL AND CHEAP       ⟶ B + C   (storage, aggregation)
  WHAT MUST BE RELATIONAL            ⟶ F       (contradiction, derivation, support)
  WHAT MUST BE FAST AND LOSSY        ⟶ D + G   (retrieval indexes)

  ⟹ **THE EPISTEMIC CONTENT LIVES IN E+H+F. THE PERFORMANCE LIVES IN B+C+D+G.**
     **§57's separation of «retrieval efficiency» from «epistemic validity» is
      not a design preference — it is a consequence of this partition.**
     An index may be wrong, lossy, stale, hardware-specific, and rebuilt from
     scratch. **A claim may not.**
```

**Why not a simpler hybrid?** A two-part hybrid (event-sourced + vector) fails K5: an event log cannot represent a standing contradiction, and a vector store cannot represent one either. **A three-part hybrid (adding the claim graph) fails K4 unless the graph is depth-bounded and the storage is hierarchical — which is what C and B add.** ⟹ **Six components is the smallest hybrid that satisfies all fourteen criteria, and §76 records that minimality of the *count* is not proven (only that five fails).**

## 2.5 **OUTPUT 2 — the verdict**

**No single candidate satisfies more than 6 of 14 criteria. The hybrid satisfies all 14, and each of its six components is present because a specific criterion fails without it.**

**The error the inherited design made was not choosing a candidate. It was choosing G and H implicitly and never stating the partition:** V3 §11's nine memory types are a *taxonomy of purposes*, and the BELIEF RECORD is a *symbolic* structure, and Cell §8.2's `content-addressed query; similarity ≥ θ_recall` is a *vector* mechanism — **three candidates used at once with no statement of which governs which.** ⟹ **§2.4's partition is the correction, and it is a partition of FUNCTION, not of memory type.**

---

# §3. FUNDAMENTAL DISTINCTIONS

**«These must not become synonyms.»** Twelve terms, each with an operational definition, a plane, an owner, and the specific conflation it is defined against.

| Term | **Operational definition** | Plane | **NOT the same as** |
|---|---|---|---|
| **MEMORY** | **A persisted record with a declared epistemic type, a provenance commitment, and a retention policy.** Persistence is the only thing that makes it memory; nothing about persistence makes it true | Storage | **Belief** (a belief may be transient), **knowledge** (a derived status), **trace** (a trace is not a claim) |
| **OBSERVATION** | **A record whose evidence status is ≥ E0 and whose ground-truth class is L0–L6 — i.e. it came from outside the organism's own inference.** P0-01 §6.1: an observation is a function of the world *and of the instrument* | Warrant | **Inference** (MEM-INV-02's whole subject), **prediction** (a prediction is a claim about a future observation, never an observation), **retrieval** (R42.1) |
| **EVIDENCE** | **A record at evidence status ≥ E3 that is admissible as a contributor to `evidence_roots` on an emitted belief.** P0-01 R6.1: **an E0 record is not evidence** | Warrant | **Information** (most stored information never becomes evidence), **support** (a record can be evidence *against*) |
| **CLAIM** | **A proposition asserted by an identified source, with a declared type, a context scope, and a validity interval.** A claim is the *unit* to which belief states attach | Warrant | **Fact** (a claim is not a fact by being claimed), **memory** (a memory may store a claim, or may store a trace, or a policy) |
| **HYPOTHESIS** | **A claim in belief state `HYPOTHESIS` — under consideration, not yet admissible, and NOT contributing to `evidence_roots`.** P0-03 §11.2 makes `HYPOTHESIS` an S2 type distinct from `SENSOR` | Warrant | **Belief** (a hypothesis is a belief state, not a different kind of object), **prediction** (a prediction is testable against a specific future observation; a hypothesis may not be) |
| **BELIEF** | **A claim PLUS its current belief state PLUS the `n_effective` and `inbreeding_F` of the evidence supporting it.** Belief is a *composite*, not a stored scalar | Epistemic | **Confidence** (a belief has confidence; it is not a confidence), **knowledge** (§4) |
| **KNOWLEDGE** | ⚠️ **§4 determines whether this term should exist as a first-class object. VERDICT: NO — it is a DERIVED STATUS, not a stored type** | Derived | **Memory** (memory is storage; knowledge is a property some memory has), **truth** (§4) |
| **FACT** | ⚠️ **VERDICT: THE ARCHITECTURE MUST NOT USE THIS TERM INTERNALLY.** It is admissible only as a *label on an L2/L3 ground-truth claim issued by EVA*, and never as a property of a memory record | External only | **Everything internal.** P0-01 §4.1.6: «`ℰ = ℛ` — the map is treated as the territory» is the single most common overclaim in AI. **A memory subsystem that stores "facts" has made that error in its schema** |
| **MODEL** | **A structured representation that PREDICTS or EXPLAINS observations, whose value is predictive usefulness, not literal truth.** §64 governs | Epistemic | **Record** (a model generalizes; a record reports), **belief** (a model is an object; a belief is a state about a claim) |
| **EXPERIENCE** | **An episode: a temporally bounded sequence of observations, actions, and outcomes, stored as an E2+ episodic record with its own provenance.** P0-01 §8.2's L6 POST-HOC OUTCOME is the ground-truth class that makes an episode evaluable | Storage | **Trace** (an experience is a meaningful episode; a trace is an event log), **memory** (an experience is one kind of memory record) |
| **TRACE** | **A record of computational or communication events, retained for audit and reconstruction, carrying NO claim and NO belief state.** P0-03 §15.3's Tier-2 log is a trace | Audit | **Memory** (a trace is not a claim and cannot be retrieved as evidence), **evidence** (a trace can *support* an audit; it is not evidence for a proposition) |
| **PROVENANCE** | **The anchored history of a record's origin and transformations: `root_commit` + `causal_depth` + `corr_class` + `calib_ref` + evidence status + policy version + lineage.** P0-02 R20.2: **provenance establishes who said what, when, in what order — NOT whether it is true** | Warrant | **Truth** (R20.2), **attribution** (attribution is one component), **trust** (P0-03 §17.1's six-way separation) |

**R3.1 (THE THREE CONFLATIONS THAT MATTER MOST).** *The twelve definitions above exist to prevent three specific collapses, and each collapse is a named attack in §72:*
1. **MEMORY = BELIEF** ⟹ storing something makes it believed. **#38 (learned-rule masquerading as observation), #36 (simulated event as observation).**
2. **PROVENANCE = TRUTH** ⟹ a well-sourced record is a correct record. **#3 (provenance laundering). P0-02 R20.2: «a well-provenanced falsehood».**
3. **RETRIEVAL = CORROBORATION** ⟹ finding it again confirms it. **#19 (self-reinforcing false belief). FM-4, «✅ Yes, and this is the dangerous one».**

---

# §4. SHOULD "KNOWLEDGE" EXIST AS A FIRST-CLASS OBJECT?

## 4.1 The proposed architecture, and why it is almost right

The brief offers:

```
Memory   = storage
Belief   = epistemic state
Knowledge = verified/persistently supported representation
Truth    = external/world property
```

> ### **«Do not assume this is correct.»** It is correct on three of four, and the fourth — `Knowledge` — is the one that must not be a first-class object.

## 4.2 Why "knowledge" must NOT be first-class

```
FOUR ARGUMENTS, EACH INDEPENDENTLY SUFFICIENT:

1. **A FIRST-CLASS OBJECT NEEDS A WRITER.** If `Knowledge` is a type of
   record, something must be able to CREATE one. **Every candidate writer
   fails:**
     • the organism ⟹ **it would be authoring its own knowledge, which is
       P0-02 §20.1's rejection of the cell as provenance owner, one level up**
     • the memory subsystem ⟹ **P0-02 §13: «Memory subsystem ❌ Not
       authoritative. Part of the organism; mutable»**
     • EVA ⟹ EVA can issue an L0–L6 ground-truth claim, but **R13.1: «There
       is no internal pathway from belief to verdict»** — and a "knowledge"
       object created by EVA would be a verdict, not a memory
     • EIK ⟹ **P0-02: the kernel must not become the memory system (§9).**
       KC is a WITNESS, not an owner
   ⟹ **There is no admissible writer. An object type with no admissible
      writer is not an object type; it is a status.**

2. **A FIRST-CLASS OBJECT CAN BE PROMOTED TO.** If `Knowledge` is a type,
   then some record can BECOME one — and the promotion is exactly §1's
   dangerous loop's final step. **Making it a status computed from other
   axes means there is no promotion event to attack.**

3. **"KNOWLEDGE" IS A PHILOSOPHICAL TERM WITH NO AGREED OPERATIONALIZATION.**
   §99's false-precision audit: JTB (justified true belief) requires TRUTH,
   which the architecture cannot access (§4.3). **A term whose definition
   requires an inaccessible property cannot be a stored field.**

4. **IT IS REDUNDANT.** Given the four axes, "knowledge" is fully
   expressible and adds nothing.
```

## 4.3 **OUTPUT — the formal distinction adopted**

> ### **R4.1 (KNOWLEDGE IS A DERIVED PREDICATE, NOT A STORED TYPE).**
>
> `KNOWS(m)` is **true** iff **all five** hold, and it is **computed on read, never stored**:
>
> ```
>   KNOWS(m) ⟺  evidence_status(m) = E4                    (externally grounded)
>            ∧  belief_state(m)    ∈ {SUPPORTED, VERIFIED} (not contested)
>            ∧  anchored(m)                                (P0-02 R20.1)
>            ∧  within_validity(m, now, context)           (§22, §24)
>            ∧  ¬∃ unresolved_contradiction(m)             (§20, §58)
> ```
>
> **Consequences, all mandatory:**
> - **`KNOWS` can become FALSE without any record changing** — the validity interval can expire, a contradiction can appear, the anchor can be retracted. **⟹ A stored `knowledge: bool` field would go stale; a computed predicate cannot.**
> - **`KNOWS` is never writable by any subject** — there is no field to write.
> - **`KNOWS` is context-relative and version-relative** — §17.3: «verified» is task-specific, evaluator-specific, context-specific, and version-specific, **never absolute**.

> ### **R4.2 (TRUTH IS NOT AN ARCHITECTURAL OBJECT AT ALL).**
>
> **Truth is a property of ℛ (P0-01's reality), and the organism has no access to ℛ except through ground-truth claims of class L0–L6.** ⟹ The architecture stores **ground-truth claims with a declared class and a declared uncertainty** (P0-01 §8.2), and it never stores `true`.
>
> **P0-01 §8.1's three failures of treating ground truth as fact are the reason:** (1) *the map is treated as the territory*; (2) *instrument uncertainty is discarded*; (3) ***absence becomes negation — no ground truth is read as confirmation*** (P0-01 R9.1: absence, delay, insufficiency, conflict, or compromise of ground truth **MUST** be recorded as `UNRESOLVED`, never as `CONFIRMED`, `CORRECT`, or `PASSED`).
>
> **⟹ The word "fact" is prohibited in memory schemas (§3). The word "truth" appears only in this rule, which says it does not exist internally.**

## 4.4 The resulting four-object ontology

| Object | **What it is** | First-class? | **Writer** |
|---|---|---|---|
| **RECORD** | A persisted item with content, type, provenance, context, validity | ✅ **YES** | §8's authority matrix |
| **CLAIM** | A proposition with a source, a context scope, and a validity interval | ✅ **YES** | The asserting subject (as a record of type CLAIM) |
| **BELIEF** | Claim + belief state + `n_effective` + `inbreeding_F` | ✅ **YES, as a composite** | Belief state: the organism; `n_effective`/`inbreeding_F`: **computed, never written** (§18, §19) |
| **KNOWLEDGE** | The predicate `KNOWS(m)` | ❌ **NO — computed on read** | **Nobody** |
| **TRUTH** | A property of ℛ | ❌ **NO — not representable** | **Nobody** |
| **FACT** | — | ❌ **PROHIBITED TERM** | — |

**R4.3 (WHY THIS IS THE RIGHT CUT).** *Three stored object types and three non-objects. **Every non-object is a non-object because it would require a writer that does not exist or a property the organism cannot access.*** ⟹ **This is §0.2's four-axis model expressed as an ontology: the axes are real, the summaries of the axes are not.**

---

# §5. THE CANONICAL MEMORY OBJECT — **OUTPUT 4**

## 5.1 The field classification

**«Do not include fields merely because they are useful. For every field classify: mandatory / optional / derived / external / prohibited / unresolved.»**

| Field | **Class** | Semantics | **If removed, what breaks** |
|---|---|---|---|
| `mem_id` | **MANDATORY** | Global, permanent, never reused. **Identity, not address** (COMM-INV-10) | Dedup, versioning, reference, §80's identity persistence |
| `content` | **MANDATORY** | The payload, typed and bounded | Everything |
| `record_type` | **MANDATORY** | §6's taxonomy. **Determines tier, retention class, access class, and consistency mode** | Tier admission, access control, consistency |
| `claim_ref` | **MANDATORY for claim-bearing types** | Pointer to the CLAIM record. **A trace has no `claim_ref`; a belief does** | §16's claim graph; MEM-INV-01's separation of record from claim |
| **`evidence_status`** | **MANDATORY, EXTERNAL** | **E0–E4. Set only by an external gate (R0.2). ⚠️ NEVER writable by the storing subject** | **The entire admission principle. This is the single most important field in the object** |
| **`root_commit`** | **MANDATORY (E2+)** | Merkle commitment over the evidence root set (P0-03 X-C's resolution). **Replaces `evidence_roots[]`** | Provenance resolution, MEM-INV-03, dedup (§15), independence (§42) |
| **`causal_depth`** | **MANDATORY** | `u8`, **SATURATING AT MAXIMUM, NEVER WRAPPING** (D-3, MEM-INV-14) | MEM-INV-02's monotone attenuation |
| `corr_class` | **MANDATORY (E2+)** | Per-dimension digest over P0-03's six correlation dimensions | `n_effective`, §42, MEM-INV-03 |
| `calib_ref` | **MANDATORY (E2+)** | Pointer to an EVA-assigned calibration record | Warrant recomputation (COMM-INV-03) |
| `warrant_class` | **DERIVED** | From `record_type` via the policy registry (COMM-INV-04). **Not a field** | — |
| `belief_state` | **MANDATORY for claim-bearing types** | §17's state set | Contradiction handling, §17 |
| **`gt_class`** | **EXTERNAL** | **L0–L6, or `null`. ⚠️ `L7` is PROHIBITED (P0-01 R8.1). Set only by EVA** | §43, MEM-INV-08 (no internal pathway from belief to verdict) |
| `source_class` | **MANDATORY** | §12's source/warrant taxonomy. **The field that makes MEM-INV-02 enforceable** | The distinction between observation and inference |
| `src_identity` | **DERIVED** | From channel binding at write time (COMM-INV-09). **Never declared** | #7 source impersonation |
| `write_epoch` | **MANDATORY** | The epoch at which the record was written | Freshness, COMM-INV-13, §22 |
| `policy_version_ref` | **MANDATORY** | The policy version under which the record was written. **⟹ P0-02's `VOID_CONTEXT` mechanism: a memory recorded under a retracted policy is not deleted but flagged, so a belief formed under retracted rules is not cited as evidence under current ones** | §22's policy-change staleness, §42's stale-policy memory attack |
| **`validity`** | **MANDATORY** | `{t_start, t_end?, context_scope}`. **An interval, NOT a timestamp** (§23) | Temporal reasoning, §22, context collapse |
| `context_scope` | **MANDATORY** | `{task_ref?, env_ref?, agent_ref?, hw_class?, policy_version?}` — **each dimension optional individually, the struct mandatory** (§24) | **Context collapse — the trap named at R1.2** |
| `uncertainty` | **MANDATORY** | **Sufficient statistics, NEVER a bare scalar** (COMM-INV-21, P0-01 R6.4) | §18, §22 |
| **`inbreeding_F`** | **EXTERNAL, READ-ONLY** | **Fraction of evidence ancestry internally generated. Computed by the ANCHOR from anchored records, NEVER self-reported** (Cell §8.3 FM-4, L941) | §30, §42, §81, MEM-M4 |
| **`n_effective`** | **DERIVED, NEVER STORED** | Computed from `root_commit` + `corr_class` on read (§21). **⚠️ STORING IT IS PROHIBITED — a stored `n_effective` is D-1's `independent confirmation` field with a better name** | §15, §42 |
| `lineage_ref` | **EXTERNAL** | Pointer into the **EIK Lineage Store**. Cell §8.1: «Ancestry is an audit artifact; **a cell must not be able to write its own lineage**» | §89, MEM-INV-06 |
| `transform_history` | **MANDATORY, APPEND-ONLY** | A commitment chain over transformations, not an enumeration (§14) | §33, §36, MEM-INV-06 |
| `contradiction_refs` | **MANDATORY (may be empty)** | Pointers to `ContradictionRecord`s (§20). **Both claims are retained; neither is overwritten** | §20, §58, #16 contradiction suppression |
| `version` | **MANDATORY** | `{parent_mem_id?, superseded_by?, version_kind ∈ {CORRECTION, SUPERSESSION, MERGE, SPLIT, ROLLBACK}}` (§36) | §36, §37, reproducibility |
| `retention_class` | **MANDATORY** | §34's classes: EPHEMERAL · BOUNDED · DURABLE · **PROTECTED** · ANCHORED | §34, §35, forgetting |
| `protection_tag` | **EXTERNAL** | `capability_critical` (Cell R10.6: exempt from eviction AND from underuse-based forgetting) · `safety_record` · `audit_record` · `lineage_record` | §34's protected categories, #48 catastrophic forgetting |
| `deletion_state` | **MANDATORY** | §35's five states: LIVE · LOGICALLY_DELETED · ARCHIVED · CRYPTOGRAPHICALLY_ERASED · ((PHYSICALLY_DESTROYED — **provenance record survives**)) | §35, MEM-INV-06 |
| `storage_tier` | **DERIVED** | From `evidence_status` via R0.2. **Not independently writable** | The admission principle |
| `access_class` | **MANDATORY** | §52's compartments: PRIVATE · CIRCUIT · REGION · ORGANISM · PROTECTED · ANCHOR-ONLY | §52, §59 |
| `integrity_digest` | **MANDATORY** | Per-record digest, rolled into the **store Merkle root recomputed at each checkpoint and verified off-substrate** (Cell §8.2, FM-3: «the strongest defense in the contract and it is cheap») | #8 history rewriting, FM-3 |
| ~~`importance`~~ | **⚠️ PROHIBITED AS AN EPISTEMIC FIELD** | **D-2. Permitted ONLY as an ALLOCATION input, computed by homeostasis, never stored on the record as an epistemic property, and never an input to `evidence_status`, `belief_state`, or tier promotion** (§11.4, §28) | — |
| ~~`access_count` / `usage`~~ | **⚠️ PROHIBITED AS AN EPISTEMIC INPUT** | **§30: retrieval MUST NOT write to the retrieved record.** Access statistics are homeostatic ALLOCATION data held separately, at `O(R)` aggregate | — |
| ~~`independent_confirmation`~~ | ❌ **PROHIBITED** | **D-1. V3 §11's field. A counter whose name asserts a property it cannot verify. Replaced by computed `n_effective`** | — |
| ~~`confidence` (scalar)~~ | ❌ **PROHIBITED** | COMM-INV-21, P0-01 R6.4. **Replaced by `uncertainty` sufficient statistics** | — |
| ~~`last_verification` (timestamp)~~ | ❌ **PROHIBITED AS A TRUTH INDICATOR** | COMM-INV-12. **Replaced by `validity` interval + `revalidation_state`** (§63) | — |
| ~~`truth` / `fact` / `is_correct`~~ | ❌ **PROHIBITED TERM** | §4.2 R4.2, §3 | — |
| ~~`evidence_roots[]`~~ | ❌ **PROHIBITED** | X-C: unbounded array. **Replaced by `root_commit`** | — |
| `retrieval_index_refs` | **OPTIONAL, DERIVED, REBUILDABLE** | **Pointers into D/G indexes. ⚠️ An index is NEVER an identity and NEVER a warrant input (§57)** | — |
| ⚠️ `semantic_self_reference_score` | **`[U]` UNRESOLVED** | **The measure FM-4's residue requires and the Cell Contract could not supply: «Bounding this requires a measure of *semantic* self-reference, not just provenance-graph depth. No rigorous mechanism is proposed here.» §81 and §100 OR-M1 address it** | — |

## 5.2 **OUTPUT 4 — the minimal canonical memory object**

```
MEMORY RECORD (canonical, minimal)
├─ IDENTITY      mem_id · record_type · claim_ref?
├─ CONTENT       content (typed, bounded)
├─ EPISTEMIC     evidence_status[E0-E4]★ · belief_state? · gt_class?★ ·
│                source_class · uncertainty{sufficient statistics}
├─ PROVENANCE    root_commit · causal_depth(u8, SATURATING) · corr_class ·
│                calib_ref · lineage_ref★ · transform_history(append-only
│                commitment chain) · policy_version_ref · src_identity(derived)
├─ TEMPORAL      write_epoch · validity{t_start, t_end?, context_scope}
├─ CONTEXTUAL    context_scope{task?, env?, agent?, hw_class?, policy?}
├─ RELATIONAL    contradiction_refs[] · version{parent?, superseded_by?, kind}
├─ GOVERNANCE    retention_class · protection_tag★ · deletion_state ·
│                access_class · storage_tier(derived)
└─ INTEGRITY     integrity_digest → store Merkle root → anchored

   ★ = EXTERNAL writer (gate, EVA, Anchor, Registrar, OP). Never the subject.
   All other epistemic quantities (n_effective, KNOWS, warrant) are
   DERIVED ON READ and NEVER STORED.

   ⟹ **THE OBJECT HAS NO FIELD WHOSE VALUE ASSERTS ITS OWN TRUTH,
      ITS OWN INDEPENDENCE, OR ITS OWN IMPORTANCE.** That is the design
      goal, and every ❌ in §5.1 is a field that violated it.
```

**R5.1 (THE MINIMALITY ARGUMENT).** *Thirty-one fields, of which **seven have an external writer**, **five are derived and never stored**, and **seven are explicitly prohibited** (eight counting `relevance`, which R7.5 prohibits on a workspace ITEM rather than on a record).* Every mandatory field maps to a named invariant (§73) or a named attack (§72). **§76 ablates each; none is removable without breaking either.** ⟹ **Under §76's minimality definition, the object is minimal relative to the function set — with the same honest caveat P0-03 R71.2 made: minimal in its prohibitions and derivations, not proven minimal in its enumerations.**

---

# §6. CANONICAL MEMORY TAXONOMY — **OUTPUT 5**

## 6.1 The structural question: first-class types or views?

**«Determine which should be first-class and which should be views over common underlying records.»**

> ### **R6.0 (THE TEST).** *A memory type deserves to be FIRST-CLASS iff it has a distinct **retention class**, **access class**, **consistency mode**, or **admission gate**. Otherwise it is a VIEW — an index over common records — and making it first-class duplicates storage and creates the divergence problem §87 calls representation drift.*

**Applying the test to V3 §11's nine types plus the brief's four additions:**

| Type | **Distinct retention?** | **Distinct access?** | **Distinct consistency?** | **Distinct gate?** | **VERDICT** |
|---|---|---|---|---|---|
| **Working** | ✅ ring, ephemeral | ✅ cell-private | ✅ none (local) | ✅ **E0 admissible** | **FIRST-CLASS** |
| **Episodic** | ✅ bounded/durable | ✅ compartment | ✅ causal | ✅ **E2 required** | **FIRST-CLASS** |
| **Semantic** | ✅ durable | ✅ regional/organism | ✅ causal | ✅ **E3 required** | **FIRST-CLASS** |
| **Procedural** | ✅ durable | ✅ circuit/region | ✅ **strong** (a policy in use must be consistent) | ✅ **E3 + improvement-verified** | **FIRST-CLASS** |
| **Protected** | ✅ **permanent** | ✅ **ANCHOR-ONLY / OP** | ✅ **append-only immutable** | ✅ **E4 + KC-2** | **FIRST-CLASS** |
| **Associative** | ❌ (it is an index over episodic/semantic) | ❌ | ❌ | ❌ | **⚠️ VIEW — a D/G index** |
| **Spatial/topological** | ❌ (it is the topology registry, P0-03 §20.3) | ❌ | ❌ | ❌ | **⚠️ NOT MEMORY — it is infrastructure** |
| **Social/agent model** | ❌ (same retention as semantic) | ✅ **compartmented** (a model of agent X is not X's property to read) | ❌ | ❌ | **⚠️ VIEW + an access class** |
| **Self-memory** | ✅ bounded ring (Cell §8.1: `runtime_state` history) | ✅ self-only | ✅ local | ✅ **and it is NOT a belief store** | **FIRST-CLASS (cell-local only)** |
| **Failure memory** | ✅ **protected from underuse-forgetting** | ✅ organism | ✅ causal | ✅ | **⚠️ A RETENTION CLASS, not a type** — a failure record is an episodic or semantic record with `protection_tag = failure_record` (§90) |
| **Provenance memory** | ✅ **permanent** | ✅ audit | ✅ **append-only** | ✅ | **⚠️ NOT A MEMORY TYPE — it is the Anchor (P0-02 §20.2), and it is GP-owned, not memory-owned** |
| **Evolutionary memory** | ✅ permanent | ✅ audit | ✅ append-only | ✅ | **⚠️ NOT A MEMORY TYPE — it is the EIK Lineage Store (Cell §8.1: «a cell must not be able to write its own lineage»)** |

## 6.2 **OUTPUT 5 — the canonical taxonomy**

> ### **SIX first-class tiers, FOUR views, THREE things that are not memory at all.**

```
FIRST-CLASS TIERS (6) — each with a distinct retention/access/consistency/gate:

  T0  WORKING      E0 admissible · ring, ephemeral · cell-private · no
                   consistency requirement · **may NOT contribute to
                   evidence_roots (P0-01 R6.1)**
  T1  EPISODIC     **E2 REQUIRED** · bounded then durable · compartmented ·
                   causal consistency · the only tier that stores EXPERIENCES
  T2  SEMANTIC     **E3 REQUIRED** · durable · regional/organism · causal
                   consistency · stores CLAIMS and MODELS, not episodes
  T3  PROCEDURAL   **E3 + improvement-verified** · durable · circuit/region ·
                   **STRONG consistency** (a policy in use must not diverge)
  T4  CONSOLIDATED **E4 REQUIRED** · permanent · organism · causal ·
                   the output of §31's consolidation, and the only tier that
                   may support calibration scoring and fitness
  T5  PROTECTED    **E4 + KC-2 authorization** · **PERMANENT, APPEND-ONLY,
                   IMMUTABLE** · ANCHOR-ONLY/OP access · **⟵ Cell §8.1's
                   relocation: «A cell must never hold protected memory»**

VIEWS (4) — indexes over the tiers above, rebuildable, never authoritative:
  V1  ASSOCIATIVE   content-addressed + similarity index over T1/T2
  V2  AGENT-MODEL   a compartment-restricted view over T2 (§52)
  V3  TEMPORAL      an interval index over any tier (§23)
  V4  CAUSAL/GRAPH  the bounded-depth claim graph over T2/T4 (§16)

NOT MEMORY AT ALL (3) — and calling them memory is the category error:
  N1  PROVENANCE    **the Anchor** (P0-02 §20.2, GP-owned, W_min witnesses,
                    ≥1 external). **Not a memory type; the authority that
                    makes memory auditable**
  N2  LINEAGE       **the EIK Lineage Store**. §89: evolutionary history is a
                    GOVERNANCE RECORD, not a memory
  N3  TOPOLOGY      the topology registry (P0-03 §20.3). Infrastructure

CELL-LOCAL ONLY (Cell §8.1's in/out table, preserved):
  working memory (T0) · bounded local episodic · **cache** · learned θ ·
  self-history ring
  **⟹ «V3 §11's nine memory types are retained as an ORGANISM-LEVEL
     taxonomy; at cell level only WM, bounded local episodic, cache, θ, and
     self-history exist.»** (Cell §8.1 [V4], the second structural relocation)
```

**R6.1 (CACHE IS NEVER BELIEF — inherited and elevated to a package-level rule).** *Cell §8.2 [V4]: «A `C0` cache cell's output carries `message_type = RELAY` or `AGGREGATE_SUMMARY`, **never `ASSERT`**. Cache hits are marked `from_cache: true` in provenance, and downstream confidence is capped for cached content.»* **⟹ A cache is not a memory tier. It is a transport optimization that must never be mistaken for a record, and §12's source taxonomy gives it its own class (`RETRIEVED_CACHED`) precisely so it cannot be mistaken.**

**R6.2 (WHY BIOLOGICAL CATEGORIES ARE CONCEPTUAL, NOT ARCHITECTURAL).** *«Episodic», «semantic», and «procedural» are retained because they pick out **genuinely different admission gates and consistency modes** — not because they are biological. «Associative», «spatial», and «social» are demoted to views because they pick out **different query patterns over the same records**, and a query pattern is an index, not a tier.* **⟹ The test at R6.0 is what makes this a decision rather than a preference, and it is the same test P0-03 §0.1 applied to topology («don't pick by neuroscience resemblance»): scale-free is more brain-like and was rejected; associative memory is more brain-like and is demoted to a view.**

---

# §7. MEMORY LAYERING — **OUTPUT 3 (canonical model)**

## 7.1 The two candidate architectures

```
CANDIDATE 1 — THE BIOLOGICAL PIPELINE (V3 §11 / V3.1 §10's implicit model):
    working → episodic → semantic → procedural
    **Four separate stores, with promotion between them.**

CANDIDATE 2 — ONE SUBSTRATE + TYPED/INDEXED VIEWS:
    one record store, with record_type and evidence_status determining
    behaviour, and indexes providing the "views".
```

## 7.2 **OUTPUT 3 — the canonical memory model**

> ### **R7.1: NEITHER. The correct architecture is ONE RECORD FORMAT, SIX ADMISSION TIERS, FOUR REBUILDABLE VIEWS, AND A HIERARCHICAL OWNERSHIP STRUCTURE.**

```
┌──────────────────────────────────────────────────────────────────────┐
│  ONE RECORD FORMAT (§5.2). Every persisted item is a MEMORY RECORD    │
│  with the same 31 fields. **There is no "episodic record format" and   │
│  no "semantic record format".**                                      │
└───────────────────────────────┬──────────────────────────────────────┘
                                │
┌───────────────────────────────▼──────────────────────────────────────┐
│  SIX ADMISSION TIERS (T0–T5). A tier is NOT a store — it is a         │
│  (retention class, access class, consistency mode, admission gate)    │
│  tuple. **A record's tier is DERIVED from its evidence_status         │
│  (R0.2) and its record_type. It is never independently writable.**    │
└───────────────────────────────┬──────────────────────────────────────┘
                                │
┌───────────────────────────────▼──────────────────────────────────────┐
│  FOUR REBUILDABLE VIEWS (V1–V4). Indexes, graphs, compartment         │
│  filters. **A view may be wrong, lossy, stale, hardware-specific, and │
│  rebuilt from scratch. A record may not.** (§57's separation)         │
└───────────────────────────────┬──────────────────────────────────────┘
                                │
┌───────────────────────────────▼──────────────────────────────────────┐
│  HIERARCHICAL OWNERSHIP (Cell §8.1, preserved exactly):               │
│    CELL      T0 working · bounded local episodic · cache · θ ·        │
│              self-history ring                                        │
│    CIRCUIT   local episodic aggregation · procedural (compiled skills)│
│    REGION    T1–T3 shared store · Memory Service                      │
│    ORGANISM  T2–T4 semantic/consolidated · **Memory Authority**       │
│    GP/OFF-   T5 protected · **the Anchor** · **the Lineage Store**    │
│    SUBSTRATE                                                          │
└──────────────────────────────────────────────────────────────────────┘

AND THE DIRECTION OF TRAVEL IS NOT A PIPELINE:
  **A record does not "flow" from working to episodic to semantic.**
  A NEW record is CREATED at a tier determined by its evidence_status,
  and the old record is RETAINED or SUPERSEDED per §36's versioning.
  ⟹ **Consolidation (§31) does not MOVE a record; it CREATES a derived
     record whose warrant is bounded by MEM-M2 and whose scope is bounded
     by §32's context intersection.**
  ⟹ **This is the difference that defeats §1's loop: a pipeline promotes
     records, and promotion is the loop's final step. A create-and-bound
     model never promotes anything — it derives new records that are
     WEAKER than their sources unless an external gate says otherwise.**
```

**R7.2 (WHY NOT CANDIDATE 1).** *Four separate stores means four copies of anything that lives in more than one, and §87's representation drift is the result: the episodic copy and the semantic copy of the same event diverge, and there is no authority to say which is right.* **Cell §8.1 already found the cost version of this: «Nine memory subsystems per cell at 10⁶ cells is infeasible and unnecessary.»**

**R7.3 (WHY NOT CANDIDATE 2).** *One substrate with no admission tiers means nothing prevents an E0 record from being retrieved alongside an E4 record and treated identically — **which is R0.2's admission principle lost, and with it the answer to §1's loop.*** **A view is a query convenience. A tier is an epistemic gate. Candidate 2 has views and no gates.**

**R7.4 (THE MODEL IN ONE SENTENCE).** ***One format so that records are comparable, six tiers so that admission is gated, four views so that retrieval is cheap, and hierarchical ownership so that no single level is an authority.***

---

# §8. MEMORY AUTHORITY — **OUTPUT 6**

## 8.1 **OUTPUT 6 — the authority matrix**

**Legend:** ✅ full authority · ⚠️ conditional/proposal only · ❌ none · **⟨X⟩** = requires principal X's authorization

| Operation | **Cell** | **Circuit** | **Memory Service (GP)** | **Memory Authority (organism)** | **EVA** | **EIK / KC** | **Anchor (GP)** | **External env** |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| **Create — T0 working (own)** | ✅ | ✅ | — | — | — | — | — | — |
| **Create — local episodic (own, bounded)** | ✅ | ✅ | — | — | — | — | — | — |
| **Create — T1 episodic (shared)** | ⚠️ `PROPOSE_MEMORY_WRITE` (C1+) | ⚠️ | ✅ commit | ✅ | — | — | — | — |
| **Create — T2 semantic** | ⚠️ propose | ⚠️ propose | ✅ commit | **✅ approval REQUIRED** | — | — | — | — |
| **Create — T3 procedural** | ❌ | ⚠️ propose | ✅ commit | **✅ + `improvement_verified` gate** | ⚠️ issues the verification | — | — | — |
| **Create — T4 consolidated** | ❌ | ❌ | ⚠️ executes | **✅ + E4 evidence status REQUIRED** | ⚠️ supplies E4 | — | ✅ anchors | — |
| **Create — T5 protected** | ❌ | ❌ | ❌ | ⚠️ proposes | ❌ | **✅ KC-2 authorization** | ✅ anchors | — |
| **Modify content** | ✅ own T0/local only | ✅ own | ❌ **records are immutable; modification = a new version (§36)** | ❌ | ❌ | ❌ | ❌ | — |
| **Modify `evidence_status`** | ❌ | ❌ | ❌ | ❌ | ⚠️ **supplies the E4 gate measurement only** | ❌ | ❌ | ✅ **E1 corroboration, E4 grounding come from outside** |
| **Modify `belief_state`** | ✅ own beliefs | ✅ | ⚠️ executes | ✅ | ⚠️ **on contradiction verdict** | ❌ | ❌ | ⚠️ indirectly, via new observation |
| **Modify provenance** | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ **append-only; the Anchor is the only writer, and it appends** | — |
| **Modify confidence/uncertainty** | ❌ **a bare scalar does not exist** | ❌ | ❌ | ❌ | ✅ **`calib_ref` records** | ❌ | ❌ | — |
| **Mark VERIFIED** | ❌ | ❌ | ❌ | ⚠️ **records EVA's verdict; does not issue it** | ✅ **within its ground-truth class and task scope** | ❌ | ❌ | ✅ |
| **Mark CONTRADICTED** | ✅ **detect and emit `ConflictRef`** | ✅ | ✅ | ✅ **the Contradiction Detector adjudicates** | ⚠️ | ❌ | ❌ | — |
| **Logical delete** | ✅ own T0/local | ✅ | ✅ within budget | ✅ | — | — | — | — |
| **Archive** | ❌ | ❌ | ✅ | ✅ | — | — | ✅ anchors the archive root | — |
| **Restore** | ❌ | ❌ | ⚠️ executes | ❌ | ❌ | **✅ KC-2 / RO-08 only — never cached, never delegated** (COMM-INV-44) | ✅ supplies the image hash | — |
| **Permanent physical delete** | ❌ | ❌ | ❌ | ⚠️ proposes | ❌ | **✅ KC-2, and ONLY for non-anchored, non-protected records** | ❌ **anchored records cannot be deleted (§35)** | — |
| **Merge records** | ❌ | ❌ | ⚠️ executes | ✅ **both parents retained as superseded (§68)** | — | — | ✅ anchors | — |
| **Split records** | ❌ | ❌ | ⚠️ executes | ✅ **parent retained** | — | — | ✅ anchors | — |
| **Read — PRIVATE compartment** | ✅ own only | ❌ | ❌ | ❌ | ⚠️ **under β sampling only** | ⚠️ under audit | — | — |
| **Read — PROTECTED (T5)** | ❌ | ❌ | ❌ | ⚠️ **under OP authorization** | ⚠️ under scope | ✅ | ✅ | — |
| **Read — another agent's model** | ❌ | ❌ | ⚠️ within compartment | ⚠️ | ⚠️ under β sampling | ⚠️ under audit | — | — |
| **Write own lineage** | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ **Registrar under KC-1 delegation** | ✅ | — |
| **Change retention class** | ❌ | ❌ | ⚠️ within policy | ✅ **within `[G]` bounds** | — | ✅ **raising PROTECTED requires KC-2** | — | — |
| **Change memory POLICY** | ❌ **V3.1 §6's «memory policy as cell-plastic» is REJECTED — see §8.3** | ❌ | ❌ | ❌ | ❌ | ✅ **RO-13 only** | — | — |

## 8.2 «Memory must not silently become a second governance authority»

> ### **R8.1 (THE FOUR THINGS MEMORY MUST NOT DO).** *The Memory Service and the Memory Authority hold **negative authority** in P0-02 §7.4's sense: they act first, within the envelope, and are retroactively vetoable. They **MUST NOT**:*
> 1. **Decide what is true.** `belief_state` is recorded, not issued. **`VERIFIED` comes from EVA within a declared ground-truth class and task scope; the Memory Authority records the verdict.** (§43)
> 2. **Decide what may be done.** A memory record cannot authorize an act. **Authorization is deontic and lives in KC/OP** (P0-02 R0.1's axis separation: ALETHIC graded / DEONTIC total).
> 3. **Decide what is retained beyond policy.** Retention classes are `[G]`; the Memory Authority allocates within them. **Raising a record to PROTECTED is KC-2.**
> 4. **Rank by relevance and have the ranking believed.** §26/§27: **retrieval answers «what matches?», never «what is true?».**

**R8.2 (THE STRUCTURAL REASON THE MATRIX LOOKS THE WAY IT DOES).** *Every ❌ in the "modify" rows is an instance of one principle: **records are immutable; change is a new version.*** **P0-02 EIK-INV-08 («corrections supersede, never overwrite») applied to memory. ⟹ There is no "modify content" authority for anyone, at any level, including KC — because KC's authority is over acts, not over records, and a record that can be modified cannot be audited.**

## 8.3 The two authority leaks in the inherited design

| Leak | **Where** | **Why it is a leak** | **Resolution** |
|---|---|---|---|
| **X-M1 — «memory policy» as a CELL-PLASTIC parameter** | V3.1 §6: «Cell plasticity ■■■ internal parameters ■■■ strategy ■■■ **memory policy** ■■■ specialization» | **A cell that can change its own memory policy can change its own retention curves, its own eviction rules, and its own `θ_write`.** ⟹ **A cell that can raise its own `θ_write` stops recording failures. A cell that can change its own eviction rule can delete its own failure history. A cell that can lower its own retention can make an inconvenient record expire.** **This is §34's dangerous-forgetting and §90's poisoned-failure-memory made available as a runtime parameter** | **REJECTED. Memory policy is POLICY (RO-13), OP-owned.** What a cell MAY vary: `WM_CAP` utilisation, its own local eviction *order within a policy-defined class*, and retrieval weights (Cell C1: «Minimal learning of retrieval weights only»). **What it may NOT vary: retention class, protection tags, `θ_write` for E2+ records, eviction exemptions, consolidation gates.** ⟵ **This is X-E's exact pattern (trust-plastic) one subsystem over, and P0-03 R48.2's resolution applies verbatim** |
| **X-M2 — «memory-policy variation» as an EVOLUTIONARY operator** | V3.1 §7: «genome mutation ■ recombination ■ learning-rule variation ■ **memory-policy variation** ■ communication-policy variation ■ …» | **Same leak, generational instead of runtime — and worse, because it is heritable and selectable.** §46.1's argument applies exactly: **relaxing a retention bound is advantageous precisely when it is dangerous, so selection would find it** | **RE-READ as «memory-PARAMETER variation within policy bounds»**, exactly as P0-03 R48.2 re-read «communication-policy variation». **Heritable: `WM_CAP` prior, `EPI_CAP` prior, `τ` retention-curve prior, `θ_recall` prior. NEVER heritable: retention classes, protection tags, admission gates, consolidation requirements.** ⟵ **This is X-G one subsystem over** |

**R8.3 (THE PATTERN, NOW FOUND FOUR TIMES).** *X-E (trust-plastic) → X-G (communication-policy variation) → X-M1 (memory-policy plastic) → X-M2 (memory-policy variation).* **In each case a prior document listed a tunable whose scope was never bounded, and in each case bounding it to "parameters within policy" dissolves the contradiction without losing the intent.** ⟹ **§92 records X-M1 and X-M2 as contradictions resolved in P0-02/P0-03's direction, and R8.3 proposes the general rule: *any "policy variation" operator in any V3.1 §7 list MUST be read as "parameter variation within policy bounds", because policy is OP-owned by P0-02 §7.1 and that is not per-subsystem negotiable.***

---

# §9. MEMORY ↔ EIK — **OUTPUT 7**

## 9.1 «The kernel must not become the memory system»

**P0-02 already did most of this work, and the answer is smaller than the brief's candidate list.**

| Brief's candidate for EIK governance | **Verdict** | **Why** |
|---|---|---|
| **Integrity** | ⚠️ **GP, not KC.** Cell §8.2's Merkle root over the memory store is «recomputed at each checkpoint and **verified by the EIK**» — but P0-02 §6.1 item 12 **reclassified it**: «🟡 **GP — Checkpoint Service + Anchor**. Same argument. **KC anchors the *root of roots* per epoch only**» | A per-store integrity check is `O(stores)`; KC's cost must be `O(R)` per epoch |
| **Protected records** | ✅ **KC-2 authorizes writes to T5 and raises to PROTECTED. KC does not store them** | Authorization is deontic; storage is a service |
| **Authorization** | ✅ **KC-2 for: T5 create · permanent physical delete · restore · raising a retention class to PROTECTED** | RO-05/06/08's pattern |
| **Deletion constraints** | ✅ **KC-3 ceiling on deletion RATE. KC does not adjudicate individual deletions** | P0-03 §34.2's five-principal pattern: KC-3 is a backstop, not an adjudicator |
| **Provenance anchoring** | ⚠️ **The ANCHOR is GP-distributed (W1–W5, `W_min`, ≥1 external). KC-1 is ONE WITNESS (W2) and authenticates the root of roots** | **P0-02 §6.1 item 19: «Putting the only copy of history inside the thing that could be compromised is the classic error»** |
| **Policy-bound memory operations** | ✅ **KC-1 authenticates the policy version; records carry `policy_version_ref`; a record under a retracted policy is flagged `VOID_CONTEXT`, not deleted (M6)** | P0-02 §12's existing mechanism |

## 9.2 **OUTPUT 7 — the Memory ↔ EIK contract**

### DOWN — EIK into memory

| Artifact | Authority | Volume |
|---|---|---|
| **Retention-class policy** (what may be forgotten, what may not) | RO-13 | `O(1)` cached |
| **Protection-tag registry** (`capability_critical`, `safety_record`, `audit_record`, `lineage_record`) | RO-13 | `O(1)` cached |
| **Admission-gate definitions** (what E1 corroboration, E2 attribution, E3 admissibility, E4 grounding require) | RO-13, **with EVA supplying the measurements** | `O(1)` cached |
| **`policy_version_ref` and the `VOID_CONTEXT` rule** | KC-1 | `O(1)` cached, pull on invalidation |
| **KC-2 authorizations** — T5 create, permanent delete, restore, PROTECTED raise | RO-05/06/08 | `O(requests)` |
| **KC-3 ceilings** — storage budget, deletion rate, consolidation rate, write rate | KC-3, **partition-surviving (EIK-INV-31)** | `O(1)` cached |
| **`inbreeding_F` values** | **Computed by the Anchor from anchored records. Read-only to every subject** | `O(subjects)` per epoch, batched |
| **Epoch** | Governance | `O(R)` hierarchical |
| **Freeze (KC-4)** — **scope MUST include the Memory Service and the Memory Authority** (P0-02 R43.1: GP services are in KC-4's enumeration) | KC-4, dual authorization, rate-bounded | `O(1)` issue, `O(R)` propagate |

### UP — memory into EIK

| Report | Volume | **⚠️ NOT** |
|---|---|---|
| **Per-epoch store Merkle roots** (regional) | **`O(R)`** | ❌ Per-record digests |
| **Reserved-operation requests** (T5 create, delete, restore) | `O(requests)` | ❌ Per-write authorization |
| **Ceiling-violation events** | `O(violations)` | — |
| **Contradiction escalations requiring DISPUTED resolution** | `O(escalations)` | ❌ Every contradiction — most are organism-adjudicated (§20) |
| **Policy friction reports** (P0-02 §15.3 V1) | `O(reports)` | — |
| **⚠️ NOT per-memory-operation traffic** | — | **«Avoid making every memory operation globally synchronized» — P0-02 §20.3: per-operation global sync is `O(operations × witnesses)` and infeasible at any scale** |
| **⚠️ NOT per-record provenance verification** | — | **P0-02 §27.2's `O(events)`-in-the-TCB problem, which is what forced P0-03's COMM-INV-30** |

## 9.3 **The minimum EIK involvement — stated exactly**

> ### **R9.1 (THE MINIMUM).** *EIK's involvement in memory is exactly four things, and each is `O(R)` per epoch or `O(requests)`:*
> 1. **KC-1 authenticates the policy version** under which records were written (`policy_version_ref`, `VOID_CONTEXT`).
> 2. **KC-2 authorizes the four irreversible acts**: T5 create · permanent physical delete · restore · PROTECTED raise. **Never cached, never delegated, never available during a KC outage** ⟹ these acts **STALL** during an outage (RO-01), and ordinary memory operation continues.
> 3. **KC-3 enforces four ceilings**: storage budget · deletion rate · consolidation rate · write rate. **Partition-surviving.**
> 4. **KC is witness W2 of five** in the Anchor, and authenticates the **root of roots** per epoch.
>
> **Everything else — storage, indexing, retrieval, consolidation, forgetting, contradiction detection, belief-state maintenance, versioning — is GP or organism, and KC never sees it.**

**R9.2 (WHY THIS IS THE MINIMUM AND NOT LESS).** *Each of the four is irreducible:*
- Remove **(1)** ⟹ a record's policy context is unverifiable, and §42's stale-policy attack succeeds.
- Remove **(2)** ⟹ a memory subsystem that can permanently delete is a memory subsystem that can erase history, which is #8/#9 and P0-02 §20.4's «can it delete inconvenient evidence?» answered "yes".
- Remove **(3)** ⟹ memory growth and deletion rate are unbounded, and §50's resource-scarcity forgetting becomes an unbounded destructive authority.
- Remove **(4)** ⟹ **P0-02 §6.1 item 19's classic error: the only copy of history inside the thing that could be compromised.**

**R9.3 (WHY THIS IS THE MINIMUM AND NOT MORE).** *Anything more makes KC a memory system, and P0-02 §27.2 established the cost: `O(events)` in the TCB is a bottleneck at 10⁹ and a bypass at 10¹².* **⟹ The same registration ≠ authorization split that P0-03 COMM-INV-30 used for connections applies to memory: ordinary writes are registered locally at `O(1)` and digested at `O(R)`; only the four irreversible acts reach KC.**

---

# §10. MEMORY ↔ COMMUNICATION — **OUTPUT 8**

## 10.1 The three planes, applied to memory

**P0-03 established TRANSPORT / WARRANT / INFLUENCE for messages. Memory interacts with each differently, and the differences are the contract.**

| Plane | **How memory interacts** | **The governing rule** |
|---|---|---|
| **TRANSPORT** | A retrieval request/response is an S1/S2 message with a full P0-03 §6.2 lifecycle. A write proposal is an S2 message. **`mem.result.v1` is service-signed** (Cell §6.2) | **R42.2: retrieval is communication in that a request crosses a boundary, is authenticated, is ordered, and produces a signed response. The communication contract governs the envelope** |
| **WARRANT** | **A retrieval result's warrant is bounded by the stored item's warrant and does NOT increase by being retrieved.** `warrant(retrieve(x)) ≤ warrant(x_at_write_time)` · `n_obs` contribution = **0** · `causal_depth` contribution = **+1** | **COMM-INV-19 / R42.1. And MEM-INV-01: «memory returned X» ⟹̸ «X is true»** |
| **INFLUENCE** | **Retrieval weights are learnable** (Cell C1: «Minimal learning of retrieval weights only»). Attention biases the query. **Both are influence-plane and warrant-neutral** | **R42.2: «a design in which retrieval weights affect warrant has committed R0.3's warrant⟶influence violation IN REVERSE»** |

## 10.2 «communication → memory candidate does NOT imply memory candidate = truth»

> ### **R10.1 (THE SIX-STEP PIPELINE, with the warrant behaviour of each).**

| Step | **What happens** | **Warrant effect** | **Invariant** |
|---|---|---|---|
| **1. INGESTION** | A message arrives; §11's pipeline runs | **None.** The message's warrant is what it is | COMM-INV-03 |
| **2. PROVENANCE CAPTURE** | `root_commit`, `causal_depth`, `corr_class`, `calib_ref`, `source_class`, `policy_version_ref` are copied **from the message, not synthesized** | **None — and this is the point: capture is copying, not creation** | **MEM-INV-02** |
| **3. TRANSFORMATION** | The content may be re-encoded, aggregated, or re-represented | **`warrant(m') ≤ warrant(m)`; `causal_depth += 1`; `root_set(m') ⊆ root_set(m)`** | **MEM-M2 = COMM-INV-08 extended** |
| **4. STORAGE** | A record is created at the tier its `evidence_status` admits it to (R0.2) | **None. Storage does not change warrant** | **MEM-INV-04** |
| **5. RETRIEVAL** | A query produces a candidate set, ranked (§27) | **None. `n_obs += 0`; `causal_depth += 1` on re-emission** | **MEM-INV-01, COMM-INV-19** |
| **6. RE-PUBLICATION** | A retrieved record is emitted as a message | **The emitted message carries the STORED record's warrant, with `causal_depth += 1`. It does NOT carry a fresh warrant, and it does NOT become a new observation** | **MEM-INV-02, MEM-INV-03** |

**R10.2 (THE STEP THAT IS MOST OFTEN GOT WRONG).** *Step 6, re-publication. **A belief that is stored, retrieved, and re-emitted has been through two extra derivation steps and carries FEWER warrant rights than when it entered** — `causal_depth` has risen twice and warrant is monotone-non-increasing.* **P0-03 R42.1's sentence is the whole rule: «A belief circulated through memory and re-emerged is weaker, not stronger, than when it went in — which is the exact opposite of what an oracle model would produce.»** ⟹ **§42's memory-mediated independence fraud is defeated by the same mechanism, and §10.3 shows why.**

## 10.3 The memory-mediated independence fraud, and its closure

```
THE ATTACK (§42's chain):
   source A → cell B → MEMORY → cell C → MEMORY → cell D
   D sees three records, from three different cells, at three different
   times. **Naively: three independent observations.**

WHY IT FAILS — AND IT FAILS AT FOUR SEPARATE POINTS:

 1. **`root_commit` survives storage.** Step 2 copies it from the message;
    step 4 stores it; step 5 returns it; step 6 re-emits it.
    ⟹ **All three of D's records resolve to the SAME root.** Dim 1 collapses
       them. `n_effective = 1`.

 2. **`corr_class` survives storage**, so dim 2 (lineage) and dim 4
    (upstream) are visible to D without D having to reconstruct anything.

 3. **`causal_depth` INCREASES at every step** — transformation (+1),
    retrieval-and-re-emission (+1). ⟹ The three records have DIFFERENT
    depths, and **a depth difference with a shared root is the signature of
    propagation, not of independent observation.**

 4. **Retrieval contributes `n_obs = 0`.** ⟹ **C's retrieval of B's record
    is not an observation by C. It is a transport event.** A record that
    C "confirms" by retrieving it has confirmed nothing.

⟹ **R10.3 (THE SURVIVAL REQUIREMENT).** *Evidence roots and lineage MUST
   survive: memory storage · transformation · consolidation · compression ·
   retrieval · re-publication.* **Each of the six is a step at which a naive
   design would drop the provenance, and §33 makes the requirement precise:
   compression is dimension-selective and MUST preserve the DECISION
   PROPERTY (P0-03 R63.2), which for memory means `root_commit` membership,
   `causal_depth` monotonicity, and `corr_class` disjointness.**

⟹ **AND THE RESIDUE, WHICH IS THE SAME RESIDUE AS EVERYWHERE ELSE:**
   if B, C, and D share a latent assumption (dim 6), or if the root itself
   is a common cause (§100 OR-C4), the collapse does not happen because
   there is nothing to collapse. **COMM-INV-18 / MEM-INV-11: not detectable
   from inside. Third-and-fourth appearance of the program-level limit.**
```

## 10.4 What memory is NOT, in communication terms

| Memory is not… | **Because** |
|---|---|
| **A blackboard** | P0-03 §2.3 RULE 2.3: a push blackboard is rejected; only a pull store with a policy gate is admissible. **And P0-03 §42.1 rejected «direct memory access» outright: «a blackboard read is unattributable, so 'who knew what when' is unrecoverable»** |
| **A trusted oracle** | R42.1, MEM-INV-01 |
| **A broadcast source** | P0-03 §65: memory updates are PULLED, never pushed. **A memory broadcast is `O(N)` per write** |
| **A governance authority** | R8.1, COMM-INV-38's memory instance |
| **A warrant authority** | COMM-INV-03: warrant is a receiver computation, and a memory service is not the receiver |
| **An evaluator** | Cell §2.4: a cell is not «a memory authority (§8) — protected/semantic memory is organism-level»; and §43: memory cannot issue verdicts |

---

# §11. MEMORY INGESTION

## 11.1 The pipeline

```
incoming information
   ↓
[1] STRUCTURAL VALIDATION          ⟵ S1a-equivalent: framing, schema, type
                                     registry, size, epoch, TTL.
                                     **Reject on STRUCTURE, never content**
                                     (P0-03 §38.2)
   ↓
[2] PROVENANCE CAPTURE             ⟵ copy root_commit · causal_depth ·
                                     corr_class · calib_ref · source_class ·
                                     policy_version_ref FROM THE MESSAGE.
                                     **Nothing is synthesized here.**
                                     A record with no resolvable root is
                                     UNANCHORED ⟹ P0-02 R20.1: no
                                     consequential decision may rest on it
   ↓
[3] SOURCE CLASSIFICATION          ⟵ §12's taxonomy. **THE STEP THAT MAKES
                                     MEM-INV-02 ENFORCEABLE.** A record whose
                                     source_class is INFERENCE, PREDICTION,
                                     SIMULATION, COUNTERFACTUAL, or
                                     RECONSTRUCTED can never be re-classified
                                     as OBSERVATION by any internal process
   ↓
[4] EVIDENCE-STATUS ASSIGNMENT     ⟵ **EXTERNAL GATE. The subject does not
                                     assign its own evidence status.**
                                     E0 by default; E1 on corroboration;
                                     E2 on anchor resolution; E3 on
                                     surviving contradiction check; E4 on
                                     ground-truth agreement
   ↓
[5] TIER ADMISSION                 ⟵ **R0.2: tier = f(evidence_status).
                                     Derived, not chosen**
   ↓
[6] DEDUPLICATION                  ⟵ §15's TWO dedups: content-hash (a
                                     transport/storage concern) AND
                                     root_commit (an epistemic concern).
                                     **They have different correct behaviours
                                      and MUST NOT be merged**
   ↓
[7] CONTRADICTION CHECK            ⟵ §20: against the E2+ corpus. A
                                     contradiction does NOT block storage —
                                     **BOTH records are stored and a
                                     ContradictionRecord is created.**
                                     P0-01 R6.2: contradiction DEMOTES
                                     evidence status to E2 with a ConflictRef
   ↓
[8] STORAGE + INDEXING             ⟵ record written; views updated
                                     asynchronously. **An index failure is
                                     never a record failure (§57)**
```

## 11.2 «Should information be stored immediately / after validation / temporarily first / only if important / probabilistically?»

> ### **R11.1: TEMPORARILY FIRST, ALWAYS — and "important" and "probabilistic" are allocation decisions, not epistemic ones.**

| Option | Verdict | **Why** |
|---|---|---|
| **Immediately** | ⚠️ **Into T0 working memory only.** P0-01: E0 RAW «may influence WORKING MEMORY only» | An unvalidated record in a persistent tier is #1's false-memory injection |
| **After validation** | ✅ **For T1+.** Steps [1]–[4] must complete | — |
| **Temporarily first** | ✅ **ADOPTED AS THE UNIVERSAL RULE.** Every record enters T0 and is promoted only by an external gate | **This is R0.2 restated as a pipeline, and it is what makes the pipeline adversarially safe: there is no path from arrival to persistence that does not pass a gate the subject does not control** |
| **Only if important** | ⚠️ **D-2. `importance` may gate T0→T1 WRITE (an allocation decision) and MUST NOT gate anything epistemic.** Cell §8.2's `importance × surprise ≥ θ_write` is retained for **local episodic only**; **shared-tier admission is gated by `evidence_status`, not by `importance`** | **A record that is unimportant but E3-admissible must be storable; a record that is important but E0 must not be. Conflating them makes salience an epistemology** |
| **Probabilistically** | ⚠️ **Admissible for T0 retention and for local eviction only. PROHIBITED for tier admission** | **A probabilistic admission gate makes `evidence_status` non-deterministic, which breaks reproducibility (P0-02 EIK-INV-50) and makes §96's conformance unsatisfiable** |

## 11.3 Adversarial ingestion

| Attack | **Step that stops it** | **Disposition** |
|---|---|---|
| **#1 false-memory injection** (fabricated content) | [2] — a fabricated record has no resolvable `root_commit` ⟹ UNANCHORED ⟹ no consequential decision (P0-02 R20.1). **Cell FM-1: «LOW for promotion, MEDIUM for local influence — a fabricated item *can* affect the cell's own θ before detection»** | **CLOSED for promotion; ⚠️ BOUNDED for local influence** |
| **#2 provenance forgery** (invented root hash) | [2] — **Cell FM-2: «Roots must resolve in the EIK Provenance Anchor (Merkle DAG). An invented hash does not resolve ⇒ rejection + `E_PROVENANCE` + immune report. Roots are appended by the Anchor, not by cells»** | **CLOSED** |
| **#36/#37/#38/#39/#40 masquerading** (simulation/counterfactual/learned-rule/prediction/inference presented as observation) | **[3] — `source_class` is captured from the message and is IMMUTABLE. There is no operation that changes it** | **STRUCTURAL — MEM-INV-02** |
| **#30 memory flooding** | [1]'s rate check + KC-3's write-rate ceiling | **BOUNDED** |
| **#12 semantic collision** (content that hashes to an existing key) | **[6] — the content-hash dedup must NOT merge records with different `root_commit`s.** §15: two records with identical content and different provenance are **two records**, linked, not merged | **CLOSED — and this is why D (content-addressed) fails K3 as an identity mechanism (§2.3)** |
| **#13 context stripping** | [2]/[3] — `context_scope` is mandatory; a record without it is MALFORMED | **STRUCTURAL** |
| **#14 temporal stripping** | [2] — `validity` is mandatory; **an interval, not a timestamp** | **STRUCTURAL** |
| **⚠️ Selective attention at the gate** | **NOT CLOSED.** Cell audit L1832: **«The S2 gate being cell-influenced is a genuine, unresolved vector: a cell can choose what to notice»** | **⚠️ RESIDUAL — §11.4** |

## 11.4 **D-2 resolved as far as it can be: the `importance` gate**

```
THE PROBLEM, PRECISELY:
  `importance` gates THREE things in the inherited design:
    WRITE       importance × surprise ≥ θ_write          (Cell §8.2)
    RETENTION   importance × recency × (1 − protection)  (Cell A-12)
    CONSOLIDATION  replay → importance → conflict → …    (V3 §11)
  AND IT IS UNDEFINED (G-P1-8: «the function is not defined»).
  AND IT IS CELL-INFLUENCED (the cell computes surprise; the cell's own
    model determines what is surprising).

⟹ **A CELL CONTROLS AN UNDEFINED SCALAR THAT DETERMINES WHAT IT REMEMBERS,
   WHAT IT KEEPS, AND WHAT IT PROMOTES.** That is not a tuning gap. That is
   the epistemic gate handed to the thing being gated.

THE RESOLUTION — THREE RULES, AND THE THIRD IS THE ONE THAT WORKS:

 R11.2 **`importance` is an ALLOCATION quantity, not an epistemic one.**
   It MAY gate: T0 retention · local episodic write · eviction order ·
   consolidation SCHEDULING (what is replayed first).
   It MAY NOT gate: tier admission · evidence_status · belief_state ·
   `n_effective` · protection tags · retention class.
   ⟹ **`importance` is computed by HOMEOSTASIS from declared inputs
      (task relevance from the task spec, resource pressure, protection
      tags), NOT by the storing subject.**

 R11.3 **Tier admission is gated ONLY by `evidence_status`** (R0.2), which
   is externally assigned. **A record the cell considers unimportant but
   which is E3-admissible MUST be storable at T2. A record the cell
   considers critical but which is E0 MUST NOT be.**

 R11.4 **⚠️ THE RESIDUE, AND THE DETECTOR.** R11.2 and R11.3 remove
   `importance` from the epistemic path — **but they do not remove the
   cell's control over WHAT IT NOTICES.** A cell that never attends to
   disconfirming evidence will have an E3-admissible corpus that is
   uniformly confirming, and every gate will pass it.
   ⟹ **THE DETECTOR IS AN ABSENCE DETECTOR, and it is P0-03 COMM-INV-48's
      pattern applied to memory:**
      **MEM-D1: a subject whose retained corpus has a systematically lower
       contradiction rate than its input distribution implies is not
       harmonious — it is filtering.**
      **MEM-D2: a subject whose `n_effective` rises while its distinct
       `root_commit` count is flat is retrieving, not learning.**
      **MEM-D3: a subject whose `inbreeding_F` rises while its external
       evidence quota is satisfied is gaming the quota.**
   ⟹ **All three are `O(R)`-per-epoch aggregate observables. None requires
      reading the cell's mind. And MEM-D1 is the memory instance of P0-03
      R67.1: «a zero-contradiction-report rate above a [G]-declared
      duration is an immune incident.»**

⚠️ **DECLARED: R11.4's detectors catch SYSTEMATIC filtering. They do not
   catch a cell that filters occasionally, or one that filters in a way
   that keeps its aggregate statistics plausible.** **§100 OR-M2 records
   this, and it is the memory-layer form of the same limit as FM-4's [U]
   residue and CD-C8's sampling self-reference: an instrument cannot fully
   audit the mechanism by which the instrument's subject decides what to
   show it.**
```

---

# §12. SOURCE / WARRANT TAXONOMY — **OUTPUT 17**

## 12.1 **OUTPUT 17 — the taxonomy**

**«Never allow internal inference to silently become external observation.»** The taxonomy is the mechanism: `source_class` is captured at ingestion, is immutable, and determines the **maximum evidence status reachable**.

| # | Source class | **Origin** | **Max reachable evidence status** | **May contribute to `evidence_roots`?** | **Notes** |
|---|---|---|---|---|---|
| **SC-1** | **`EXTERNAL_GROUNDED`** | EVA measurement agreeing with an **L0–L3** ground-truth claim | **E4** | ✅ | **The only class that can reach E4.** P0-01 §6.3's final gate |
| **SC-2** | **`EXTERNAL_MEASURED`** | A calibrated instrument measuring ℛ (**L2**), or ≥`n_indep` independent L2 (**L3**) | **E4** (with corroboration) | ✅ | **P0-01 §8.2: L2 is «the only class that touches ℛ directly»** |
| **SC-3** | **`EXTERNAL_TESTIMONIAL`** | Human annotation (**L4**, κ declared) or trusted database (**L5**, write-protected, version-pinned) | **E3** | ✅ with declared κ/provenance | **P0-01 R8.3: `κ < κ_min` ⟹ not ground truth, a disputed label** |
| **SC-4** | **`EXTERNAL_POSTHOC`** | The environment's own later state (**L6**) | **E3** | ✅ with attribution uncertainty declared | **P0-01: «the cheapest and most realistic class, and the hardest to attribute»** |
| **SC-5** | **`EXTERNAL_SIMULATOR`** | Deterministic simulator state (**L0**) | **E2** | ⚠️ **only for claims about Σ, never about ℛ** | **P0-01 R8.2: «L0 MUST NOT be used as ground truth for any claim about ℛ»** |
| **SC-6** | **`PEER_OBSERVATION`** | Another cell/circuit/region reporting an observation it made | **E3** | ✅ **but `corr_class` dims 1/2/4 apply — a peer's observation of the same root is not independent** | **The §42 case** |
| **SC-7** | **`ORGANISM_INFERENCE`** | The organism's own derivation from other records | **E3** ⚠️ **and only if its inputs are E3+** | ✅ **as a derived root, with `causal_depth += 1` and warrant ≤ min(inputs)** | **MEM-M2. Never E4 — R13.1: «no internal pathway from belief to verdict»** |
| **SC-8** | **`PREDICTION`** | A forecast about a future observation | **E1 until resolved** | ❌ **until resolved, then it becomes SC-2/SC-4 or is discarded** | **P0-01 R9.2: an unresolved prediction past its deadline is a CALIBRATION FAILURE, not a confirmation and not neutral** |
| **SC-9** | **`SIMULATION`** | An internally-run model producing a synthetic episode | **E1** | ❌ **NEVER** | **§66. MEM-INV-05: a simulated event cannot be represented as an observed event** |
| **SC-10** | **`COUNTERFACTUAL`** | «What if X had happened?» | **E0** | ❌ **NEVER** | **§65. The lowest class, and it must be representable or the system cannot reason hypothetically at all** |
| **SC-11** | **`RECONSTRUCTED`** | A record re-derived from a model rather than replayed exactly | **E1** | ❌ **unless the reconstruction is externally validated** | **§67. The reconstruction MUST be marked; an unmarked reconstruction is #36** |
| **SC-12** | **`RETRIEVED`** | A record read back from memory | **⚠️ INHERITS the stored record's status, and can never exceed it** | ❌ **`n_obs += 0`** | **R42.1, COMM-INV-19, FM-4** |
| **SC-13** | **`RETRIEVED_CACHED`** | A cache hit | **⚠️ CAPPED below `RETRIEVED`** | ❌ | **Cell §8.2 [V4]: `from_cache: true`, «downstream confidence is capped for cached content». R6.1: cache is never belief** |
| **SC-14** | **`INTERNAL_CONSENSUS`** | Agreement among internal estimators (**L7**) | **❌ E0 MAXIMUM, PERMANENTLY** | ❌ **NEVER** | **P0-01 R8.1: «MUST NOT include L7 … MUST NEVER be used as ground truth. This is the self-referential trap. Included in the taxonomy only so it can be explicitly prohibited»** |

## 12.2 The three rules that make the taxonomy work

> ### **R12.1 (IMMUTABILITY).** *`source_class` is captured at ingestion from the message's type and channel, and **NO OPERATION IN THE ARCHITECTURE CHANGES IT**.* Not storage, not transformation, not consolidation, not compression, not retrieval, not re-publication, not generalization. **⟹ MEM-INV-02 is structural, not checked: there is no code path from SC-7…SC-14 to SC-1…SC-6.**

> ### **R12.2 (THE CEILING).** *Each source class has a MAXIMUM REACHABLE EVIDENCE STATUS, and no gate may raise a record above its class ceiling.* **⟹ SC-14 (`INTERNAL_CONSENSUS`) can never leave E0, no matter how many estimators agree, no matter how long it persists, no matter how often it is retrieved.** This is P0-01 R8.1's prohibition made operational at the memory layer.

> ### **R12.3 (DERIVED RECORDS INHERIT THE MINIMUM, NOT THE MAXIMUM).** *A record derived from several sources has `source_class` = the **weakest** contributor's class, and `evidence_status` ceiling = the minimum of the contributors' ceilings.* **⟹ A generalization (§32) built from nine SC-2 observations and one SC-9 simulation is an SC-9 record. One simulated instance poisons the whole generalization — which is the correct behaviour, because §32's rule is that a general rule's scope is bounded by its instances.**

**R12.4 (WHY FOURTEEN CLASSES AND NOT FEWER).** *The classes are organized by **two orthogonal properties**: where the information came from (external world / external instrument / external testimony / peer / self) and what kind of cognitive act produced it (observation / inference / prediction / simulation / counterfactual / reconstruction / retrieval).* **Collapsing either axis loses a distinction the architecture needs:** collapsing the first makes SC-7 (`ORGANISM_INFERENCE`) indistinguishable from SC-2 (`EXTERNAL_MEASURED`), which is MEM-INV-02's whole subject; collapsing the second makes SC-9 (`SIMULATION`) indistinguishable from SC-8 (`PREDICTION`), which is MEM-INV-05's whole subject. **⟹ §76 records that the count is not proven minimal, but that both axes are necessary and that 14 is the product of the two axes' admissible combinations minus the inadmissible ones.**

---

# §13. MEMORY PROVENANCE — **OUTPUT 18**

## 13.1 The chain, and which portions must remain exact

```
environment observation → sensor → cell A → cell B → memory record

WHICH PORTIONS MUST REMAIN EXACT?
```

| Portion | **Exact or compressed?** | **Mechanism** | **Why** |
|---|---|---|---|
| **The ROOT (the observation itself)** | **EXACT and ANCHORED, permanently** | `root_commit` resolves against the Anchor's root registry (P0-02 §20.2) | **P0-02 R20.1: no consequential decision may rest on unanchored provenance. If the root is not exact, nothing downstream is auditable** |
| **The root's ground-truth class** | **EXACT** | `gt_class` ∈ L0–L6, or null. **L7 prohibited** | §43: whether the root touched ℛ is the difference between evidence and self-reference |
| **The root's instrument state** | **EXACT** | P0-01 §6.1: «an observation is a function of the world *and of the instrument*». `sensor_confidence`, `sensor_reliability`, calibration state | **Without it, sensor failure is indistinguishable from world change** |
| **The HOP COUNT** | **COMPRESSED to `causal_depth: u8`, SATURATING** | MEM-INV-14 | The exact path is `O(hops)`; the monotonicity test needs only the count |
| **The intermediate identities** | **COMPRESSED to a commitment**, recoverable off-line from Tier-2 traces | `transform_history` as an append-only commitment chain, not an enumeration | **The identities matter for audit, not for warrant — and audit is off-line (§95)** |
| **The correlation structure** | **COMPRESSED to `corr_class`**, a per-dimension digest | P0-03 §14.3's six dimensions | `n_effective` needs the disjointness test, not the correlation details |
| **The policy context** | **EXACT** | `policy_version_ref` + the `VOID_CONTEXT` rule | **A belief formed under retracted rules must not be cited as evidence under current ones** |
| **The temporal context** | **EXACT as an interval** | `validity{t_start, t_end?}` | §22: an interval, never a timestamp |
| **The scope context** | **EXACT** | `context_scope{task?, env?, agent?, hw_class?, policy?}` | §24: context collapse is a named trap (R1.2) |

## 13.2 **OUTPUT 18 — the provenance architecture**

> ### **R13.1.** *Memory provenance is **P0-02 §20.2's distributed Anchor plus P0-03 §15.3's three tiers, applied to records instead of messages.** Nothing new is invented, and that is the point: a memory subsystem that built its own provenance would be a second, unaudited authority.*

```
┌─────────────────────────────────────────────────────────────────────┐
│  THE ANCHOR (GP-owned, distributed, W_min witnesses, ≥1 EXTERNAL)   │
│  W1 Operational anchor (GP, off-substrate)                          │
│  W2 KC witness (KC-1 signs the ROOT OF ROOTS per epoch only)        │
│  W3 EVA witness (signs evaluation roots)                            │
│  W4 OP-held archive (offline, human)                                │
│  W5 EXTERNAL witness (published / notarized / third-party escrow)   │
│     **⟵ §10.4's genesis anchor lives here, OUTSIDE operational      │
│        control**                                                    │
│  A chain break is a GLOBAL freeze trigger                           │
└──────────────────────────┬──────────────────────────────────────────┘
                           │ epoch roots only — O(R) per epoch
┌──────────────────────────┴──────────────────────────────────────────┐
│  HIERARCHICAL MERKLE AGGREGATION (P0-02 §20.2)                      │
│  record digest → store Merkle root (per tier, per region)           │
│    → circuit digest → region digest → generation digest             │
│    → campaign bundle (P0-01 R8.13)                                  │
└──────────────────────────┬──────────────────────────────────────────┘
        ┌──────────────────┴──────────────────┐
        ▼                                     ▼
  MEM-T1  LOCAL, CONTINUOUS             MEM-T2  PERIODIC, AGGREGATE
  Each tier/region maintains a LOCAL    At epoch boundaries each region
  append-only record log + local        submits ONE Merkle root to the
  Merkle tree.                          Anchor. **O(R) messages per epoch,
  **ZERO network traffic per record.**  not O(records).**

  MEM-T3  IMMEDIATE, EXCEPTIONAL
  Only: T5 protected writes · permanent deletions · restorations ·
  contradiction escalations to DISPUTED · detected integrity mismatches ·
  evidence-status promotions to E4. **These are rare by design.**

⟹ **THE LIE-WINDOW (P0-02 §20.3, restated for memory):**
   «A subject can lie about the interval between anchors, but it cannot lie
   about anything that was anchored, and the interval is bounded by epoch
   length.» **The epoch length is therefore the MEMORY PROVENANCE LATENCY,
   and it is a `[G]` parameter trading anchor load against lie-window.**
```

## 13.3 The two inherited provenance schemas, reconciled

**⚠️ CONTRADICTION FOUND (X-M3).** The Cell Contract and P0-03 specify **different provenance structures**, and memory must pick one:

| | **Cell Contract §7.1 / §8.2** | **P0-03 §0.2 / §4.3** |
|---|---|---|
| Root set | **`evidence_roots: [bytes<32>]`** — an unbounded ARRAY | **`root_commit`** — a Merkle commitment, `O(1)` |
| Depth | **`derivation_depth: u16`** (0–65535) | **`causal_depth: u8`** (0–255) |
| Self-reference | **`self_ref: bytes<32>`** | (no equivalent — `src` is derived from channel binding) |
| Correlation | (absent) | **`corr_class`** — six dimensions |
| Calibration | (absent from provenance; `calib_ref` is elsewhere) | **`calib_ref`** in the envelope |

> ### **R13.2 (THE RESOLUTION).** *P0-03's structure governs, with three memory-specific extensions:*
> 1. **`root_commit` REPLACES `evidence_roots[]`** — X-C's resolution applies identically, and **more forcefully for memory: a record persists, so an unbounded root array grows for the record's entire lifetime.**
> 2. **`causal_depth: u8` REPLACES `derivation_depth: u16`** — **but with MEM-INV-14: SATURATING AT 255, NEVER WRAPPING.** ⚠️ **D-3: a wrapping counter inverts its own purpose — a chain of depth 256 reads as depth 0 and looks primary.** **And the memory-specific concern that motivated `u16` is handled differently: a record's total lifetime derivation count is `recall_count` (bounded, allocation-only, never epistemic) plus `causal_depth` (saturating, epistemic). Two counters, because they answer different questions.**
> 3. **`self_ref` is RETAINED** — and it is the field that makes MEM-INV-04 (`inbreeding_F`) computable: **the fraction of a record's evidence ancestry that terminates in the record's own subject.** P0-03 did not need it because a message is not persisted and cannot be its own ancestor; **a memory record can.**
> 4. **`corr_class` and `calib_ref` are ADOPTED unchanged** from P0-03.

**Direction: P0-03 governs.** ⟵ *P0-03 is later, and it derived its structure from the scaling analysis (Θ(N) in a bounded envelope) rather than from an enumeration of fields. **This is the same resolution direction as X-E and X-G, and for the same reason: the later package derived the constraint from first principles rather than listing components.***

**Residue, declared:** the Cell Contract's `derivation_depth: u16` range is wider than `causal_depth: u8`. **§13.4 argues the wider range is unnecessary; if a future mechanism requires it, MEM-INV-14's saturation makes the loss safe (a saturated depth is maximally attenuated, which is the conservative direction).**

## 13.4 Why `u8` suffices for memory

```
THE OBJECTION: a memory record can be re-derived many times over its
lifetime, so 255 is not enough.

THE ANSWER: **DEPTH BEYOND ~10 IS EPISTEMICALLY MEANINGLESS, AND P0-03 §35's
WARRANT ATTENUATION MAKES IT SO.**

  P0-03 §35.2 layer 4: warrant attenuates with causal_depth.
  MEM-M2: warrant is monotone-non-increasing under every memory operation.
  ⟹ **A record at depth 20 has warrant ≤ (attenuation)^20 × warrant(root),
     which is below any admissible threshold long before depth 255.**

  So the counter saturates only for records that are ALREADY inert.
  **And MEM-INV-14's saturation-at-maximum makes the failure direction
     conservative: a saturated record is treated as MAXIMALLY derived
     (minimum warrant), never as minimally derived.**

⟹ **R13.3: `u8` with saturation is sufficient, and `u16` was specifying
   precision the epistemics cannot use.** ⟵ **This is §99's false-precision
   discipline applied to a type width: a wider counter is not a better
   counter if the quantity it counts stops mattering at 10.**
```

---

# §14. PROVENANCE COMPRESSION — **OUTPUT 19**

## 14.1 «Compressed provenance» vs. «destroyed provenance»

> ### **R14.1 (THE DEFINITION, and it is P0-03 R63.2's rule applied to memory).** *Provenance is **COMPRESSED** iff every DECISION PROPERTY survives. Provenance is **DESTROYED** iff any decision property is lost.*

**The decision properties — the complete list, and losing any one is destruction:**

| # | Decision property | **What it decides** | **Compressed form** | **Lost if…** |
|---|---|---|---|---|
| **DP-1** | **Root membership** | Is root *r* among this record's evidence roots? | `root_commit` (Merkle) — `O(log)` proof | the enumeration is dropped without a commitment |
| **DP-2** | **Derivation monotonicity** | Is this record derived from that one? | `causal_depth` + `transform_history` commitment | depth is dropped or **wraps** (D-3) |
| **DP-3** | **Correlation disjointness** | Are these two records independent on dimension *d*? | `corr_class` per-dimension digest | the digest is dropped or coarsened |
| **DP-4** | **Source class** | Is this an observation or an inference? | `source_class` — **already `O(1)`; cannot be compressed further** | **it is re-derived from content instead of stored** |
| **DP-5** | **Evidence status** | What tier may this enter? | `evidence_status` — `O(1)` | it becomes computable from internal state |
| **DP-6** | **Policy context** | Under which rules was this written? | `policy_version_ref` — `O(1)` | it is dropped as "metadata" |
| **DP-7** | **Validity interval** | When was/is this true? | `validity` — `O(1)` | it is reduced to a timestamp |
| **DP-8** | **Context scope** | Where does this hold? | `context_scope` — `O(1)` | it is dropped (§24's context collapse) |
| **DP-9** | **Anchored location** | Can this record's integrity be verified? | store Merkle root + epoch anchor | the record is no longer under a committed root |
| **DP-10** | **Self-reference fraction** | How much of this record's ancestry is internal? | `inbreeding_F` — Anchor-computed | it becomes self-reported |

## 14.2 **OUTPUT 19 — the compression model**

| Level | **What is retained** | Cost | **Retention** | **Admissible for** |
|---|---|---|---|---|
| **L0 — EXACT** | The full record + the full transformation enumeration + payload | `O(record)` | **Permanent for T4/T5; bounded window for T1–T3** | Audit, reproducibility, forensic reconstruction |
| **L1 — COMMITTED** | All ten decision properties + Merkle commitments over the enumerations | **`O(1)` per record** | **Permanent** | **Every epistemic operation. ⟵ THIS IS THE OPERATING LEVEL** |
| **L2 — SUMMARIZED** | DP-1, DP-2, DP-4, DP-5, DP-9 only — **DP-3 (`corr_class`) is coarsened to "correlated with set S" without per-dimension detail** | `O(1)` smaller constant | Long-term archive | **Aggregate statistics, lineage analysis. ⚠️ NOT admissible for `n_effective` computation, because DP-3 is coarsened** |
| **L3 — SAMPLED** | Full L0 for a **sampled** subset (P0-01's β strata), L2 for the rest | `O(B)` | Permanent for the sample | EVA evaluation, calibration scoring |
| **L4 — ANCHORED DIGEST ONLY** | The epoch Merkle root; individual records are gone | **`O(R)` per epoch** | Permanent | **«This set of records existed at epoch *e* and has not been altered» — and nothing more** |

**R14.2 (THE COMPRESSION RULE).** *Every record MUST retain at least L1 for as long as it is retrievable. **A record compressed below L1 MUST become non-retrievable as evidence — it may remain retrievable as a trace (§3's definition: a trace carries no claim and no belief state).*** **⟹ Compression below L1 is a change of RECORD TYPE, not a loss of fields, and it is therefore visible, auditable, and irreversible in the correct direction.**

**R14.3 (WHAT INFORMATION LOSS IS ACCEPTABLE).** *Acceptable: the enumeration of roots (DP-1 preserves membership) · the enumeration of transformations (DP-2 preserves monotonicity) · the correlation details (DP-3 preserves the disjointness test) · the intermediate identities (recoverable off-line from Tier-2 traces within the window).* **Unacceptable — and each is a named destruction: any of DP-1…DP-10.**

**R14.4 (THE ASYMMETRY THAT MAKES IT SAFE).** *Compression may discard RECONSTRUCTION DETAIL and may never discard a DECISION PROPERTY. **When in doubt, the record is demoted to a trace rather than compressed** — because a trace makes no claim, and a compressed record that makes a claim it can no longer support is §33's over-compression failure.*

---

# §15. MEMORY DEDUPLICATION

## 15.1 «Four memories, one memory with four observations, one claim with multiple sources, or separate source records linked to one proposition?»

> ### **R15.1: THE FOURTH. Separate source records, linked to one CLAIM record — and the link is what makes `n_effective` computable.**

```
THE FOUR CANDIDATES AND WHY THREE FAIL:

 (a) FOUR MEMORIES
     ⟹ **FALSE EVIDENCE MULTIPLICATION BY CONSTRUCTION.** Four records,
        four retrievals, four citations. **This is D-1's
        `independent confirmation` counter realized as storage.** ❌

 (b) ONE MEMORY WITH FOUR OBSERVATIONS
     ⟹ **LOSES SOURCE IDENTITY.** If A, B, C, D are merged into one record,
        the architecture cannot later discover that A and B share a root,
        or that C is SC-9 (simulated). **§12's R12.3 requires knowing the
        weakest contributor, which requires the contributors.** ❌

 (c) ONE CLAIM WITH MULTIPLE SOURCES
     ⟹ **CLOSE, but the claim must not absorb the sources.** If the sources
        are a field OF the claim, then modifying the claim modifies the
        sources, violating §8.2 R8.2's immutability. ❌

 (d) SEPARATE SOURCE RECORDS LINKED TO ONE CLAIM RECORD   ✅
     ⟹ **Each source record keeps its own `source_class`, `root_commit`,
        `corr_class`, `evidence_status`, and identity. The CLAIM record is
        a distinct object (§4.4's ontology) with `support_refs[]` and
        `contradict_refs[]` pointing at source records. `n_effective` is
        COMPUTED over the source records on read (§21) and NEVER STORED.**

THE RESULTING STRUCTURE:

   CLAIM C  ──support──►  RECORD r_A  (SC-6, root R1, corr_class …)
            ──support──►  RECORD r_B  (SC-6, root R1, corr_class …)  ⟵ SAME ROOT
            ──support──►  RECORD r_C  (SC-9, root ∅,  SIMULATION)     ⟵ CEILING E1
            ──contradict─► RECORD r_D (SC-2, root R2, L2 measurement)

   n_effective(C) computed on read:
     r_A, r_B share root R1        ⟹ dim 1 collapses them to 1
     r_C is SC-9                   ⟹ ceiling E1, contributes 0 to E3 support
     r_D contradicts               ⟹ C enters belief_state CONTESTED (§21)
     ⟹ **n_effective(support for C at E3) = 0.**

   ⟹ **A claim supported by four records, three of which are one observation
      and one of which is a simulation, has ZERO admissible support. And the
      computation is O(support_refs), performed on read, with no stored
      counter for an attacker to increment.**
```

## 15.2 The two dedups, and why one is not enough

**P0-03 R63.1 established two dedups for messages (X-I's resolution). Memory needs the same two, plus a third.**

| Dedup | **Key** | **On match** | **Plane** |
|---|---|---|---|
| **D-1 CONTENT** | Content hash (D — content-addressed index) | **Link, DO NOT MERGE.** Two records with identical content and different `root_commit`s are **two records** — because identical content from independent sources is genuinely corroborating, and identical content from one source is not, and **the content hash cannot tell them apart** | Storage |
| **D-2 ROOT** | `root_commit` | **Admit both records; count the evidence ONCE** in `n_effective` | Warrant |
| **D-3 CLAIM** ⟵ **new, memory-specific** | Claim identity (proposition + context scope + validity interval) | **Attach as a new support/contradict reference to the existing CLAIM record. NEVER create a second CLAIM record for the same proposition-in-context** | Epistemic |

**R15.2 (WHY D-3 IS NECESSARY AND WHY MESSAGES DID NOT NEED IT).** *A message is transient, so two messages asserting the same proposition are two events. **A memory record is persistent, so two records asserting the same proposition in the same context are a duplicated claim — and a duplicated claim is retrievable twice, citable twice, and counts twice in any naive aggregation.*** **⟹ D-3 is what makes §20's contradiction handling possible at all: a contradiction is a relation between two records attached to ONE claim, and without claim identity there is nothing for them to contradict.**

**⚠️ THE HARD PART OF D-3, DECLARED.** *Claim identity requires deciding when two propositions are THE SAME proposition.* **Structural identity (same type, same referent, same context scope, same validity interval) is decidable. SEMANTIC identity («temperature rose» vs. «it got warmer») is not — and §100 OR-M3 records it.** **R15.3: where semantic identity is undecidable, the architecture creates TWO claim records and links them with a `POSSIBLY_SAME_CLAIM` edge, which is conservative: it may duplicate a claim, but it will never merge two distinct ones. Merging distinct claims loses a contradiction; duplicating a claim loses only storage.**

---

# §16. THE CLAIM GRAPH

## 16.1 «Determine whether graph structure is necessary»

> ### **R16.1: YES for RELATIONS, NO for STORAGE — and the distinction is what makes it scale.**

**The brief proposes:**
```
Claim
 ├── supported_by      ✅ NECESSARY — §15.1(d)
 ├── contradicted_by   ✅ NECESSARY — §20 cannot be represented otherwise
 ├── derived_from      ✅ NECESSARY — MEM-M2's monotonicity needs the edge
 ├── caused_by         ⚠️ **NOT IN MEMORY.** §3 R3.1 / P0-03 RULE 5.9: causal
 │                        inference belongs to the EVALUATOR, off-line.
 │                        **A `caused_by` edge stored in memory is a causal
 │                        claim the memory subsystem has no authority to make**
 ├── observed_at       ✅ NECESSARY — as a `validity` interval link, not a
 │                        timestamp (COMM-INV-12)
 ├── valid_during      ✅ NECESSARY — §22/§23
 └── transformed_into  ✅ NECESSARY — §36's versioning
```

**One addition the brief did not list, and it is the most important:**
```
 ├── SUPERSEDED_BY     ✅ **MANDATORY.** P0-02 EIK-INV-08: «corrections
 │                        supersede, never overwrite». Without this edge,
 │                        §36's versioning has no representation
 └── VOID_UNDER        ✅ **MANDATORY.** P0-02 §12: a memory recorded under a
                          retracted policy is flagged `VOID_CONTEXT`, not
                          deleted. Without this edge, §42's stale-policy
                          attack succeeds
```

**Two rejections:**
```
 ❌ SIMILAR_TO        ⟹ **This is a VIEW (V1), not a graph edge.** A
                         similarity relation is a property of an embedding,
                         which is hardware- and model-specific (§2.3's K13/K14
                         failures for G). **Storing similarity as a claim-graph
                         edge makes the epistemic graph non-portable**
 ❌ MORE_SPECIFIC_THAN ⟹ ⚠️ **CONDITIONAL.** A taxonomy edge is admissible
                         only where the taxonomy is POLICY-defined (a type
                         hierarchy), never where it is learned. **A learned
                         subsumption edge is a generalization (§32) and must
                         carry the generalization's bounded warrant, not the
                         taxonomy's**
```

## 16.2 Scalability

| Operation | **Naive** | **This design** | Mechanism |
|---|---|---|---|
| Find a claim's support set | `O(claims)` scan | **`O(support_refs)`** | Direct edge, stored per claim |
| Compute `n_effective` for a claim | `O(support² )` pairwise correlation | **`O(support)` with a Bloom filter over seen `root_commit`s** | P0-03 §14.4's local method |
| Detect a contradiction | `O(claims²)` all-pairs | **`O(1)` at write time against the D-3 claim index** | **Contradiction is detected ONCE, at ingestion step [7], not on every query** |
| Traverse derivation ancestry | `O(depth × fan-in)` | **`O(depth)` to the saturating `causal_depth`; full traversal is OFF-LINE from Tier-2 traces** | §14.2's L1/L0 split |
| Answer «what contradicts X in context C?» | `O(claims)` | **`O(1)` from the claim index + `O(contradict_refs)`** | D-3 + `context_scope` indexing (view V3) |
| **Depth-bounded traversal** | unbounded | **`O(bound)` — and the bound is `[G]`** | **⟵ THE CRITICAL CONSTRAINT: an unbounded graph traversal is `O(edges)`, and §2.3's K4 failure for F is exactly this. A bounded-depth claim graph is `O(1)` per query with precomputed edges** |

**R16.3 (THE GRAPH RULE).** *The claim graph is **bounded-depth, edge-precomputed, and never traversed at query time beyond the bound**. Full-graph analysis is an OFF-LINE, evaluator-side operation over anchored records.* **⟹ This is P0-03 §10.2's division rule applied to memory: the runtime answers bounded local questions; the evaluator answers unbounded global ones off-line.**

**R16.4 (WHAT THE GRAPH IS NOT).** *The claim graph is not a knowledge base, not a reasoner, and not an inference engine.* **It represents relations among claims so that contradiction, derivation, supersession, and support are inspectable. It does NOT perform logical inference — and §98's ablation shows why: an inference engine inside memory would be a second evaluator, and R13.1 («no internal pathway from belief to verdict») would be violated.**

---

*End of Volume A. Volume B (`33_analysis_belief_retrieval.md`) covers §17–§33: belief states, confidence, belief update, contradiction management, staleness, temporal and contextual memory, retrieval, retrieval-vs-truth, ranking, bias, feedback loops, self-corruption, consolidation, generalization, and compression.*
