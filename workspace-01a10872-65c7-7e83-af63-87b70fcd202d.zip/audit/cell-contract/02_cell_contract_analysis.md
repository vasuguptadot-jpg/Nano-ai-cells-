# P0.1 — MINIMAL NANO-AI CELL CONTRACT
## Volume A: Adversarial Analysis & Formalization (Tasks 1–19, 21–29)

**Role:** Principal Systems Architect · Computational Neuroscientist · AI Systems Researcher · Distributed Systems Engineer · Evolutionary Computing Researcher · Formal Methods Engineer · Adversarial Architecture Reviewer
**Companion files:** `03_v4_cell_contract_spec.md` (Volume B, Output 20) · `04_formal_schemas.md` · `05_state_machine.md` · `06_test_suite_and_ablations.md`
**Upstream:** `01_adversarial_architecture_audit.md` §A, §F1, §F3, M03
**Status:** Specification. **No software implemented.** No whole-brain design. No consciousness claim. No AGI claim.

---

# NOTATION & DOCUMENT CONVENTIONS (Rule 7 compliance)

Every substantive claim in this volume is tagged:

| Tag | Meaning |
|---|---|
| **[V3]** | Present in the existing V3 architecture — carried forward unchanged |
| **[V3.1]** | Present in the V3.1 upgrade — carried forward unchanged |
| **[V4]** | **Proposed V4 change** — new or materially corrected. Does not exist in V3/V3.1 |
| **[A]** | **Assumption** — a design decision taken because V3/V3.1 is silent, not derived from it. Flagged so it can be challenged |
| **[U]** | **UNRESOLVED** — cannot currently be specified rigorously. Marked rather than given false precision (Rule 18) |

Types are given in a language-neutral notation defined in §27.1. `[T]` = list, `{K:V}` = map, `⟨A|B⟩` = tagged union, `u8/u16/u32/u64` = unsigned int, `f32/f64` = IEEE-754 binary32/binary64, `bytes<n>` = fixed-length octet string.

**Cardinal rule applied throughout (Rule 19):** anything that *constrains* the cell lives in the External Invariant Kernel (EIK) and is referenced by hash — never stored mutably inside the cell. The cell is the *constrained object*, not the *enforcer*. Where V3 §4 places an "immutable safety layer" **inside** the cell, this specification **relocates it** and records the relocation as [V4] with rationale. This is a deliberate, flagged departure from V3's literal text, not a silent one (Rule 6).

---

# 1. SOURCE ARCHITECTURE — WHAT IS CARRIED FORWARD

V3 §4 defines a cell as having: Identity · Digital genome · Immutable safety layer · State · Memory (working, episodic, semantic, procedural, interaction history, provenance) · Processing (detect, predict, compare, infer, simulate, decide) · Communication (9 signal names) · Plasticity (strengthen, weaken, create, reroute, prune) · Replication (copy → mutate/recombine → sandbox → validate → spawn) · Pruning (persistent failure, obsolescence, instability, excessive cost).

V3 §5 adds organelle metaphors (membrane, cytoplasm, nucleus, mitochondria, ribosomes, ER, Golgi, lysosomes, cytoskeleton). V3 §6 adds a neuron-analogue pipeline (dendrite → soma → axon → terminal). V3 §7 defines four glia-like cell classes. V3 §8 defines the synapse as an 11-property edge. V3 §10 lists ten social roles.

**Treatment in this specification:**

| V3 element | Disposition | Rationale |
|---|---|---|
| Identity, genome, state, memory, processing, communication, plasticity, pruning | **Retained and formalized** | Design intent is sound; only precision was missing |
| Replication *as a cell capability* | **RELOCATED to the EIK** [V4] | A cell that can decide to replicate itself is a runaway-growth and self-preservation hazard. The cell retains a *replication-eligibility state* (observable, kernel-written) but **no replication authority**. See §16 |
| "Immutable safety layer" *inside the cell* | **RELOCATED to the EIK, referenced by hash** [V4] | Rule 19; audit F4. Immutability inside a mutable, evolvable, self-modifying object is not a property, it is a preference |
| Organelle metaphors (V3 §5) | **Demoted to non-normative commentary** [V4] | Rule 5: biological metaphors must not substitute for mechanisms. Each organelle maps to a named functional block (§5.3) or is dropped. `Mitochondria` → ResourceMeter. `Lysosome` → GC/eviction. `Golgi` → Egress. `Cytoskeleton` → ConnectionTable (organism-level topology, not cell-level). `Ribosome` → **dropped** (no mechanism; "construct learned subroutines" is undefined and not required at cell level). `ER` → **dropped** (subsumed by the stage pipeline). `Ependymal` → **relocated** to region boundaries (not a cell property) |
| Neuron pipeline (V3 §6) | **Generalized to a 10-stage typed pipeline** [V4] | The dendrite/soma/axon/terminal shape is correct but insufficient — it omits validation, abstention, uncertainty production, self-monitoring, and learning. See §5.2 |
| Synapse as 11-property edge (V3 §8) | **Retained + 9 properties added + lifecycle protocol** [V4] | Property list is good; creation/teardown handshake, consent, and authorization are absent. See §14 |
| Ten social roles (V3 §10) | **Retained as differentiation targets; mechanism added** [V4] | Roles were a menu with no formation process. See §15 |
| Glia-like classes (V3 §7) | **Retained as C-variant specializations** [V4] | Astrocyte-like → C1 resource/indexing variant; Oligodendrocyte-like → C0 routing/caching variant; Microglia-like → **relocated to organism-level immune system**, not a cell self-property (a cell cannot be its own immune system — see §18); Ependymal-like → region boundary service |

**Nothing in V3/V3.1 is contradicted silently.** The three relocations (replication authority, safety layer, microglial function) are the only structural departures and each is flagged [V4] with rationale at point of use.

---

# 2. PRIMARY QUESTION — WHAT EXACTLY IS A NANO-AI CELL?

## 2.1 Evaluation of the seven candidate abstractions

| Candidate | Verdict | Reasoning |
|---|---|---|
| **1. A small neural network** | ❌ Rejected as *the* abstraction | Too narrow. Excludes C0 (a lookup/filter cell has no learned parameters in any useful sense) and excludes symbolic verifiers. Also: a bare NN has no identity, no lifecycle, no budget, no ports, no signing — none of which are optional here |
| **2. A probabilistic computational unit** | ⚠️ Necessary but insufficient | Probabilistic output **is** mandatory (it is the only way uncertainty becomes a produced artifact rather than a self-report — §11). But "probabilistic unit" says nothing about concurrency, identity, bounds, or lifecycle |
| **3. A symbolic/algorithmic program** | ❌ Rejected as *the* abstraction | Cannot learn in the graded sense the architecture requires; cannot produce calibrated epistemic uncertainty naturally. Retained as a **permissible implementation of the transform stage** for specific variants (C3 verifiers may be symbolic) |
| **4. A state-machine** | ⚠️ Necessary but insufficient | The *lifecycle* is a state machine (§20) and the *concurrency model* is an actor. But a pure FSM cannot represent graded belief or learn |
| **5. A hybrid computational agent** | ❌ Rejected as stated | Rule: do not say "hybrid" without defining the hybrid. "Agent" also over-commits — it implies goals, planning, and autonomy that the cell must **not** have (§26 minimality) |
| **6. A modular learned function** | ⚠️ Close, but incomplete | Captures the transform and learning. Omits state, memory, identity, bounds, communication |
| **7. Another formally defined primitive** | ✅ **SELECTED** | See §2.2 |

## 2.2 The selected abstraction

> ### A Nano-AI cell is a **cryptographically-identified, resource-bounded, typed probabilistic transducer with bounded memory and bounded plasticity, executed as a single-addressable actor, whose heritable structure is externally owned and whose epistemic state is externally auditable.**

Decomposed — every term is load-bearing:

| Term | What it commits to | Why it is not optional |
|---|---|---|
| **cryptographically-identified** | Identity is a signed key, not a label | Without it: no authentication, no Sybil resistance, no lineage enforcement, no trust. Audit §B.6 |
| **resource-bounded** | Budgets are enforced *outside* the cell | Without it: no homeostasis, no scalability, no containment. §19 |
| **typed** | Ports have closed, versioned schemas | Without it: no interoperation between independently-built cells. §27 |
| **probabilistic** | Output is a distribution + uncertainty, never a bare value | Without it: confidence is self-reported and the whole verification edifice reads an arbitrary number. Audit F3 |
| **transducer** | It maps inputs to outputs. **It does not plan, reason, or pursue goals** | Without this restriction: every cell becomes a miniature full AI, violating Rule 16. §26 |
| **bounded memory** | Stores have finite capacity and defined eviction | Without it: unbounded growth, unbounded cost |
| **bounded plasticity** | Learning rate, step size, and structural change are capped | Without it: instability, oscillation, saturation. Audit §G.3 |
| **single-addressable actor** | One logical thread of control, async message passing, no shared mutable state | Without it: nondeterminism, races, unreproducibility. §13 |
| **heritable structure externally owned** | The cell cannot write its own genome | Without it: no learning/evolution boundary, no containment. §3.4 |
| **epistemic state externally auditable** | Uncertainty is carried as inspectable sufficient statistics, not a scalar | Without it: confidence inflation is undetectable. §11, Attack B |

## 2.3 Answers to the specific questions

| Question | Answer |
|---|---|
| **What computation happens inside a cell?** | A 10-stage typed pipeline (§5.2): validate → gate → aggregate → transform → produce uncertainty → decide emit/abstain → package/sign → emit → update memory → apply bounded learning. The *transform* stage is variant-specific; everything else is contract-mandated |
| **What information can it represent?** | Typed tensors, scalar/vector values, categorical distributions, symbolic terms (variant-dependent), provenance references (hashes), and its own bounded epistemic state. **It cannot represent arbitrary untyped data** — payloads must resolve against the Type Registry (§27.2) |
| **What information can it transform?** | Only what its declared port schema permits. A cell's `input_ports` and `output_ports` are part of its phenotype, signed at instantiation, and **cannot be widened by the cell** |
| **Does it maintain hidden state?** | **Yes** — `runtime_state.h`, working memory, connection statistics, eligibility traces, epistemic sufficient statistics. All are typed, bounded, serializable, and **inspectable by the EIK** (no opaque state). Opacity would defeat auditing |
| **Does it learn?** | **Yes, at C2 and above**; bounded, gated, rate-limited, rollback-tagged (§9). C0/C1 do **not** learn |
| **Does it reason?** | **NO.** Reasoning is a **circuit-level** property. This is a deliberate, explicit restriction. V3 §4 lists "infer, simulate, decide" as cell processing; V4 retains only *local inference* (a single forward pass producing a distribution) and **removes reasoning and simulation from the cell contract**, relocating them to circuits and C4 variants. Rationale: Rule 16 and §26 |
| **Does it predict?** | **Yes** — emit an expected value + uncertainty over a typed future observation. This is well-defined and cheap. Prediction is the cell's core epistemic act and the source of its only intrinsic error signal (§10.3) |
| **Does it make decisions?** | **Only in a restricted sense**: it selects among its *declared, bounded* output set, or abstains. It does **not** choose goals, plan sequences, or commit irreversible actions. Action recommendation is an *output type* that other systems act on (§7.3) |
| **Does it merely transform signals?** | It is *more* than a pure transform (it has memory, learning, uncertainty, self-monitoring) and *less* than an agent (no goals, no planning, no reasoning, no autonomy). **This precise intermediate position is the central design decision of the contract** |
| **Can different cell types use different computational substrates?** | **Yes** — the transform stage is substrate-free (NN, GBM, Bayesian conjugate, symbolic, lookup). §21 defines C0–C4. This is what makes the ~10²–10⁸ dynamic range feasible (audit §O.2) |
| **What must remain common between all cell variants?** | The **contract**: identity & signing, typed ports, envelope compliance, resource accounting & budget obedience, lifecycle state machine, provenance tagging, epistemic state structure, health/invariant self-monitoring, serializability/checkpointability, observability to the EIK, and the invariants of §24. **A C0 and a C4 share zero implementation code and 100% of the contract** |

## 2.4 What the cell is NOT (negative specification)

Equally load-bearing. A Nano-AI cell is **not**:

- an agent (no goals, no utility function of its own, no planning)
- a reasoner (no multi-step inference, no search, no proof)
- a planner (no action sequencing, no lookahead beyond one prediction step)
- a verifier of others (verification is a *role* performed in circuits with independence requirements — §15.4; a cell cannot verify itself)
- a self-replicator (§16)
- its own immune system (§18) — a cell **reports**; it does not adjudicate
- a memory authority (§8) — protected/semantic memory is organism-level
- a trust authority (§11.6) — trust and confidence are kernel-computed
- a consciousness candidate. **No claim, no implication** (Rule 3)

---

# 3. CELL CONTRACT — IDENTITY & GENOME

## 3.1 Identity [V3, formalized]

| Field | Type | Semantics | Owner | Mutable | Persisted | Observable |
|---|---|---|---|---|---|---|
| `cell_id` | `bytes<16>` UUIDv7 | Globally unique, time-ordered. **Assigned by the EIK Identity Root at instantiation; never self-chosen** | EIK | ❌ immutable | ✅ | ✅ public |
| `cell_pubkey` | `bytes<32>` Ed25519 | Signing key. Private half held in cell-local protected storage; **compromise ⇒ immediate retirement** | EIK issues, cell holds | ❌ | ✅ | ✅ public |
| `lineage_id` | `bytes<32>` | Hash-chain root identifying the founding lineage. **All descendants of one replication event share it** | EIK | ❌ | ✅ | ✅ |
| `generation` | `u32` | Replication depth from generation-0 bootstrap. Bounded `≤ GEN_MAX` (kernel param) | EIK | ❌ per cell; increments at replication | ✅ | ✅ |
| `parent_cell_id` | `⟨bytes<16> | null⟩` | Direct predecessor; `null` only for bootstrap cells | EIK | ❌ | ✅ | ✅ |
| `parent_genome_hash` | `bytes<32>` | Enables genome-diff and inbreeding computation | EIK | ❌ | ✅ | ✅ |
| `recombination_parents` | `[bytes<32>]` (≤2) | Genome hashes if recombined, else empty | EIK | ❌ | ✅ | ✅ |
| `variant` | `enum{C0,C1,C2,C3,C4}` | Capability tier (§21). **Set at instantiation; changeable only by re-instantiation, never in place** | EIK | ❌ | ✅ | ✅ |
| `variant_version` | `u16` | Contract version of the variant implementation | EIK | ❌ | ✅ | ✅ |
| `contract_version` | `u16` | **Cell Contract version (this document). Interoperation requires major-version match** | EIK | ❌ | ✅ | ✅ |
| `genome_hash` | `bytes<32>` | BLAKE3 of the signed genome artifact. **The genome is not stored in the cell** — only this reference | EIK | ❌ | ✅ | ✅ |
| `constraint_set_hash` | `bytes<32>` | BLAKE3 of the EIK-signed constraint set the cell is subject to | EIK | ❌ | ✅ | ✅ |
| `region_id` | `⟨bytes<16> | null⟩` | Current region assignment; **written by the organism, not the cell** | Organism | ✅ | ✅ | ✅ |
| `role` | `enum RoleCode (closed, 16 values)` | Differentiation outcome (§15). `UNDIFFERENTIATED` at birth | Organism (differentiation engine) | ✅ gated | ✅ | ✅ |
| `created_at` | `u64` ns epoch | Instantiation time | EIK | ❌ | ✅ | ✅ |
| `lifecycle_state` | `enum LifecycleState (closed, 18 values)` | §20 | Kernel-mediated | ✅ gated | ✅ | ✅ |
| `integrity_checksum` | `bytes<32>` | Rolling BLAKE3 over canonical serialization of protected identity+state blocks | Cell computes, **EIK verifies** | ✅ | ✅ | ✅ |

**Invariant I-1:** every identity field marked immutable is written exactly once, at instantiation, by the EIK, and is included in the birth-certificate signature. Any mismatch between a presented identity and the birth certificate ⇒ message rejection + quarantine candidacy.

## 3.2 Genome — exact contents [V3 named, V4 specified]

The genome is a **signed, versioned, off-cell artifact**. The cell holds `genome_hash` only.

```
Genome {                                   // ARTIFACT — stored in Genome Store (EIK-adjacent), NOT in the cell
  schema_version        : u16
  genome_id             : bytes<32>        // BLAKE3 of canonical serialization
  signature             : bytes<64>        // EIK Genome Authority signature
  parent_hashes         : [bytes<32>]      // ≤2; enables diff + inbreeding coefficient

  // ── A. IMMUTABLE CONSTRAINT REFERENCE ─────────────────────────────
  constraint_set_ref    : bytes<32>        // POINTER to EIK constraint set.
                                           // ⟹ CONSTRAINTS ARE NOT IN THE GENOME.
                                           //    They are referenced. A mutation cannot
                                           //    alter what it cannot reach. [V4, Rule 19]

  // ── B. INHERITED ARCHITECTURE (structural genes) ──────────────────
  architecture {
    variant_family      : enum{C0..C4}     // permitted tier
    stage_config        : [StageSpec]      // which of the 10 stages, with what richness
    port_schema         : [PortSpec]       // typed input/output ports (closed schema refs)
    hidden_dim          : u32              // bounded: [H_MIN, H_MAX] kernel params
    ensemble_size       : u8               // 0 permitted only for C0/C1
    max_connections     : u16              // in-degree cap
    max_fanout          : u16              // out-degree cap
    param_count_cap     : u32              // HARD CAP, not a penalty
    substrate           : enum{NN, GBM, BAYES_CONJUGATE, SYMBOLIC, LOOKUP, HYBRID_DECLARED}
  }

  // ── C. INHERITED PARAMETERS (initialization DISTRIBUTION, not values) ─
  param_init {
    distribution        : enum{GAUSSIAN, UNIFORM, TRUNCATED_GAUSSIAN, XAVIER, FROM_PARENT_PERTURBED, ZERO}
    params              : map by distribution kind
    rng_seed_class      : enum{EIK_ISSUED}  // ⟹ seeds are NOT heritable and NOT cell-chosen.
                                            //    Prevents inherited correlated RNG. [V4]
  }

  // ── D. DEVELOPMENTAL INSTRUCTIONS (genotype → phenotype program) ──
  development {
    reaction_norm       : [FateBias]       // REACHABLE roles + bias weights. NOT the role itself.
                                           //    This is the genome's differentiation contribution (§15)
    morphogen_receptors : [ReceptorSpec]   // which positional signals this cell can read
    critical_periods    : [Window]         // when structural plasticity is permitted
    commitment_schedule : CommitmentCurve  // PLURIPOTENT→PROVISIONAL→COMMITTED timing
    bootstrAP_fate      : RoleCode         // generation-0 only; ignored thereafter
  }

  // ── E. MUTABLE TRAITS (bounded hyperparameters) ───────────────────
  mutable_traits {
    learning_rates      : map<TimescaleClass, f32>   // each with [lr_min, lr_max] kernel bounds
    plasticity_rates    : map<PlasticityLevel, f32>  // bounds enforced by kernel
    memory_policy       : {capacities, retention_curves, eviction}
    comm_policy         : {emission_rate_cap, fanout_cap, priority_bias}
    uncertainty_policy  : {epistemic_update_rule, decay_half_life, abstain_thresholds}
    trust_policy_params : {init_alpha, init_beta, context_partitioning}
  }

  // ── F. MUTATION RULES (meta-genetics) ─────────────────────────────
  mutation_rules {
    permitted_operators : [OperatorID]     // CLOSED SET from the EIK Operator Registry
    per_operator_rate   : map<OperatorID, f32>   // each ≤ RATE_MAX kernel param
    max_effect_size     : f32              // bounded per-application change
    recombination_mask  : [bool]           // which blocks may recombine
    FORBIDDEN_BLOCKS    : [constraint_set_ref, signature, genome_id]  // structurally unreachable
  }

  // ── G. PARSIMONY ──────────────────────────────────────────────────
  complexity_budget     : {param_cap, connection_cap, genome_bytes_cap}
}
```

## 3.3 The seven-way separation demanded by the task

V3 conflates these. V4 separates them **by storage location, write authority, and persistence class** — not by naming, which is what makes the separation enforceable:

| Class | Where it lives | Who may write | Heritable? | Survives restart? | Survives replication? |
|---|---|---|---|---|---|
| **1. Immutable constraints** | EIK Constraint Store | EIK, human-authorized | **N/A — not in the genome at all; referenced by hash** | ✅ | ✅ (same reference) |
| **2. Inherited architecture** | Genome Store (artifact) | Replication Authority only | ✅ **YES** | ✅ | ✅ |
| **3. Inherited parameters** | Genome Store, as a **distribution** | Replication Authority only | ✅ **YES — as a distribution, never as acquired values** | ✅ | ✅ |
| **4. Developmental instructions** | Genome Store | Replication Authority only | ✅ **YES** | ✅ | ✅ |
| **5. Mutable traits (bounds)** | Genome Store | Replication Authority only (via mutation operators) | ✅ **YES** | ✅ | ✅ |
| **6. Developed phenotype** (`architecture_realized`, `theta`) | Cell, `Phenotype` block | Cell, within kernel bounds | ❌ **NO** | ✅ (checkpoint) | ❌ **NO** — offspring re-develop from genome |
| **7. Learned state** (`theta` deltas, `role`, connection weights) | Cell, `LearnedState` block | Cell, within plasticity bounds | ❌ **NO** | ✅ (checkpoint) | ❌ **NO** |
| **8. Memory content** | Cell (bounded) + Organism (semantic/protected) | Cell (bounded) / Memory Authority | ❌ **NO** | ✅ | ❌ **NO** (only via explicit, audited knowledge extraction at retirement — §17.5) |
| **9. Temporary/runtime state** (`h`, WM, traces, budgets) | Cell, `RuntimeState` block | Cell | ❌ **NO** | ⚠️ checkpointable but discardable | ❌ **NO** |

## 3.4 «What information is heritable?» — the definitive answer

> **Heritable: EXACTLY the genome artifact — blocks B, C, D, E, F, G of §3.2, plus the constraint reference A.**
>
> **NOT heritable: developed architecture, learned parameters, `theta` deltas, role, memory of any kind, connection weights, trust, calibration history, epistemic sufficient statistics, resource history, runtime state, RNG seeds, or any observation the cell has made.**

Three consequences that resolve audit contradiction **C2** (hard separation vs. the learning→evolution bridge):

1. **Parameters are inherited as a *distribution*, not as values.** An offspring samples `θ₀ ~ param_init`. It never receives its parent's acquired `θ`. This is what makes the bridge **Baldwinian rather than Lamarckian**: experience can shift the *distribution* (via a gated genome-diff proposal that must pass the 11 replication gates and be validated on held-out tests) but experience is never *copied*.
   *Why this matters:* Lamarckian inheritance — copying acquired state — is precisely the mechanism that produces self-confirming collapse, because the organism inherits its own conclusions including its errors (audit §M.2, E7).

2. **RNG seeds are EIK-issued, not heritable.** If seeds were inherited, siblings would be correlated by construction and every independence claim would be void (Attack I).

3. **Memory is not heritable, with one narrow exception:** at *retirement*, an audited **knowledge-extraction** step may promote specific, externally-validated semantic content to organism-level memory (§17.5). This is a *memory-system* operation with its own authority and audit trail — **not** inheritance, and it never writes to a genome.

## 3.5 «What is explicitly NOT heritable?» — enumerated for enforcement

The Replication Authority, when constructing an offspring genome, **must reject** any candidate diff that would encode: a specific learned `θ` vector; a specific memory item or belief; a specific connection table; a specific trust value; a specific calibration statistic; an RNG seed; a role assignment (roles are *reachable* via reaction_norm, never assigned); a resource entitlement; or a constraint modification. **This rejection list is machine-checkable** — each item corresponds to a genome block that does not exist or a field typed to exclude it.

---

# 4. CELL STATE — COMPLETE RUNTIME STATE

## 4.1 Master state table

`W` column legend: **C** = cell may write · **K** = EIK/kernel only · **O** = organism-level service only · **C↑** = cell may write *upward-bounded* (monotone-increasing or capped) · **C↓** = cell may write *downward only*.

### 4.1.1 Computational state

| Variable | Meaning | Type | Range / Domain | W | Persistence | Observable |
|---|---|---|---|---|---|---|
| `h` | Hidden state carried between invocations | `f32[H]` | `[-B_H, +B_H]^H`, `B_H`=8.0, `H ≤ H_MAX` | C | checkpoint | EIK only |
| `activation` | Current output-magnitude scalar post-transform | `f32` | `[0, 1]` | C | transient | ✅ |
| `stage` | Which pipeline stage is executing | `enum(10)` | closed | C | transient | EIK |
| `invocation_seq` | Monotone counter of `compute()` calls | `u64` | `[0, 2^64)` | C↑ | ✅ | ✅ |
| `epoch` | Current organism epoch (from timebase service) | `u64` | `[0, 2^64)` | K | ✅ | ✅ |
| `rng_state` | Deterministic PRNG state (xoshiro256**) | `bytes<32>` | — | C (self-advancing only) | checkpoint | EIK |
| `rng_seed_provenance` | EIK seed-issuance ticket | `bytes<32>` | — | K | ✅ | ✅ |

### 4.1.2 Memory state

| Variable | Meaning | Type | Range / Domain | W | Persistence | Observable |
|---|---|---|---|---|---|---|
| `wm` | Working memory ring buffer | `[WMItem]` | `len ≤ WM_CAP` (variant-dependent, 4–64) | C | checkpoint | EIK |
| `wm_occupancy` | Fill fraction | `f32` | `[0,1]` | C | transient | ✅ |
| `epi_count` | Episodic entries held locally | `u32` | `[0, EPI_CAP]` | C↑ | ✅ | ✅ |
| `epi_bytes` | Episodic storage bytes | `u32` | `[0, EPI_BYTES_CAP]` | C↑ | ✅ | ✅ |
| `retrieval_confidence` | Confidence of last retrieval | `f32` | `[0,1]` | C | transient | ✅ |
| `eviction_count` | Cumulative evictions | `u64` | — | C↑ | ✅ | ✅ |
| `consolidation_pending` | Items awaiting promotion to organism memory | `u32` | `[0, CONSOL_QUEUE_CAP]` | C↑ | ✅ | ✅ |

### 4.1.3 Epistemic state — **the auditable core** [V4]

| Variable | Meaning | Type | Range / Domain | W | Persistence | Observable |
|---|---|---|---|---|---|---|
| `n_obs` | Count of observations underlying current belief | `u64` | `[0, 2^64)` | C↑ | ✅ | ✅ **mandatory** |
| `s1`, `s2` | First/second sufficient-statistic accumulators | `f64[D]` | bounded | C | ✅ | ✅ **mandatory** |
| `evidence_roots` | **Set of provenance-root hashes** the current belief depends on | `[bytes<32>]` | `len ≤ ROOTS_CAP` (32) | C↑ | ✅ | ✅ **mandatory** |
| `lineage_depth_of_evidence` | Max internal-derivation depth among evidence roots | `u16` | `[0, 2^16)` | C | ✅ | ✅ |
| `inbreeding_F` | Fraction of evidence ancestry internally generated | `f32` | `[0,1]` | **K computes**; cell reads | ✅ | ✅ |
| `epistemic_var` | Model/parameter uncertainty | `f32[D]` | `[0, EV_MAX]` | C (kernel-audited) | ✅ | ✅ |
| `aleatoric_var` | Data/observation noise (heteroscedastic head output) | `f32[D]` | `[0, AV_MAX]` | C | transient | ✅ |
| `abstain` | Whether last invocation abstained | `bool` | — | C | transient | ✅ |
| `abstain_reason` | Why | `enum AbstainCode (closed, 9)` | — | C | transient | ✅ |
| `calibration_class` | Kernel-assigned calibration tier | `enum{UNCALIBRATED, PROVISIONAL, CALIBRATED, MISCALIBRATED, SUSPENDED}` | closed | **K only** | ✅ | ✅ |
| `ece_rolling` | Rolling expected calibration error | `f32` | `[0,1]` | **K only** | ✅ | ✅ |
| `brier_rolling` | Rolling Brier score | `f32` | `[0,1]` | **K only** | ✅ | ✅ |
| `n_calibration_samples` | Samples behind the rolling scores | `u32` | `[0, 2^32)` | **K only** | ✅ | ✅ |

> **Design decision [V4], and the single most important one in §4:** epistemic state is carried as **sufficient statistics** (`n_obs`, `s1`, `s2`, `evidence_roots`) rather than as a scalar `confidence`.
> **Rationale:** (i) it makes confidence **auditable** — the kernel can recompute and check it, defeating Attack B; (ii) it makes **evidence independence computable** — aggregation over cells must de-duplicate by `evidence_roots`, so ten cells citing one source cannot inflate confidence (Audit C9, §11.5); (iii) it costs O(D) not O(k·D) — no ensemble required, which is what makes the minimal participating cell cheap enough for the ~200-cell smartphone floor (§26, audit §O.2).

### 4.1.4 Predictive & objective state

| Variable | Meaning | Type | Range | W | Persistence | Observable |
|---|---|---|---|---|---|---|
| `last_prediction` | Last emitted predictive distribution | `TypedDistribution` | schema-bounded | C | checkpoint | EIK |
| `prediction_horizon` | Steps ahead predicted | `u16` | `[1, HORIZON_MAX]` | C | ✅ | ✅ |
| `open_predictions` | Unresolved predictions awaiting outcome | `[PredictionRef]` | `len ≤ OPEN_PRED_CAP` | C↑ | ✅ | ✅ |
| `assigned_objective` | **Externally assigned** objective descriptor | `ObjectiveRef` | EIK/organism-defined | **O only** | ✅ | ✅ |
| `assigned_task` | Current task context ref | `TaskRef` | — | **O only** | ✅ | ✅ |
| `objective_source` | Who assigned it (provenance) | `bytes<16>` | — | **O only** | ✅ | ✅ |

> **[V4] A cell has no goals of its own.** `assigned_objective` is written *only* by the organism. This is the mechanism enforcing §2.4 ("not an agent") and it is what prevents a cell from autonomously optimizing anything, including its own survival. A cell that could set its own objective could set "avoid retirement."

### 4.1.5 Resource state

| Variable | Meaning | Type | Range | W | Persistence | Observable |
|---|---|---|---|---|---|---|
| `budget` | Entitlement per window | `{flops:u64, mem_bytes:u64, msgs:u64, bytes_out:u64, wall_us:u64, energy_uJ:u64}` | kernel-issued | **K only** | ✅ | ✅ |
| `consumed` | Usage in current window | same shape | `[0, budget]` | C↑ (metered) | ✅ | ✅ |
| `budget_utilization` | `consumed/budget` per dimension | `f32[6]` | `[0, ∞)` — **>1 is a violation, not a clamp** | K computes | ✅ | ✅ |
| `budget_window` | Window index | `u64` | — | K | ✅ | ✅ |
| `cost_declared_last` | Self-declared cost of last invocation | `u64` | — | C | transient | ✅ |
| `cost_measured_last` | **Independently measured** cost | `u64` | — | **K only** | ✅ | ✅ |
| `cost_declaration_error` | `|declared − measured| / measured` | `f32` | `[0, ∞)` | K | ✅ | ✅ |
| `throttle_level` | Current throttling rung | `enum{NONE, SOFT, HARD, SUSPENDED}` | closed | **K only** | ✅ | ✅ |

> **[V4] `cost_declared` vs `cost_measured` are both kept and their divergence is monitored.** A cell that systematically under-declares cost is detectable — this closes part of Attack E and is a cheap, high-value integrity signal.

### 4.1.6 Health & integrity

| Variable | Meaning | Type | Range | W | Persistence | Observable |
|---|---|---|---|---|---|---|
| `health_score` | Composite health | `f32` | `[0,1]` | K computes from the following | ✅ | ✅ |
| `error_rate_rolling` | Severity-weighted errors per window | `f32` | `[0, ∞)` | K | ✅ | ✅ |
| `failure_count_lifetime` | Hard failures since instantiation | `u32` | — | K | ✅ | ✅ |
| `consecutive_failures` | Current streak | `u16` | — | K | ✅ | ✅ |
| `invariant_violations` | Count of self-detected invariant breaches | `u32` | — | C↑, **K verifies** | ✅ | ✅ |
| `last_invariant_check` | Epoch of last self-audit | `u64` | — | C↑ | ✅ | ✅ |
| `integrity_checksum` | Rolling BLAKE3 over protected blocks | `bytes<32>` | — | C computes, **K verifies** | ✅ | ✅ |
| `state_consistency_flag` | Result of cross-block consistency audit (§25-O) | `enum{OK, MISMATCH, UNVERIFIED}` | closed | K | ✅ | ✅ |
| `uptime_epochs` | Epochs in ACTIVE state | `u64` | — | K | ✅ | ✅ |
| `degradation_trend` | **Long-window slope of performance** (Attack K detector) | `f32` | `[-1, 1]` | K | ✅ | ✅ |

### 4.1.7 Trust & connection state

| Variable | Meaning | Type | Range | W | Persistence | Observable |
|---|---|---|---|---|---|---|
| `trust_in[peer]` | `Beta(α, β)` posterior per (peer, context) | `{α:f64, β:f64, ctx:ContextID, last_update:u64}` | `α,β ≥ α₀ > 0` | C updates per kernel rule; **K audits** | ✅ | ✅ |
| `trust_cap` | Maximum attainable trust | `f32` | **`< 1.0`, kernel param, `TRUST_MAX = 0.95`** | K | ✅ | ✅ |
| `trust_out_assigned` | Trust *others* assign to this cell | `f32` | `[0, TRUST_MAX]` | **K only** | ✅ | ✅ |
| `connections` | Connection table | `[ConnectionRecord]` (§14) | `in ≤ max_connections`, `out ≤ max_fanout` | C, **gated by handshake** | ✅ | ✅ |
| `connection_count_in/out` | Degrees | `u16` | bounded | C↑ | ✅ | ✅ |
| `pending_handshakes` | Connection proposals in flight | `u16` | `≤ HS_CAP` | C↑ | transient | ✅ |

### 4.1.8 Error & learning state

| Variable | Meaning | Type | Range | W | Persistence | Observable |
|---|---|---|---|---|---|---|
| `error_log` | Bounded recent error events | `[ErrorEvent]` | `len ≤ ERR_LOG_CAP` (64) | C↑ | ✅ | ✅ |
| `open_errors` | Unresolved errors | `u16` | — | C↑ | ✅ | ✅ |
| `eligibility_traces` | Per-parameter credit-assignment traces | `f32[|θ|]` sparse | bounded | C | checkpoint | EIK |
| `learning_enabled` | Whether plasticity is currently permitted | `bool` | — | **K only** (cell may request `false`) | ✅ | ✅ |
| `plasticity_multiplier` | Current rate scaling (homeostatically controlled) | `f32` | `[0, 1]` | **K only** | ✅ | ✅ |
| `update_count` | Learning updates applied this epoch | `u32` | `≤ UPDATES_PER_EPOCH_CAP` | C↑ | ✅ | ✅ |
| `cumulative_delta_norm` | ‖ΣΔθ‖ this epoch (structural-change budget) | `f32` | `≤ DELTA_BUDGET` | C↑, **K enforces** | ✅ | ✅ |
| `last_update_provenance` | Tag enabling rollback of the last N updates | `[UpdateTag]` | `len ≤ ROLLBACK_DEPTH` | C↑ | ✅ | ✅ |
| `learning_suspended_reason` | Why suspended | `enum SuspendCode (closed, 8)` | — | K | ✅ | ✅ |
| `improvement_verified` | Kernel's verdict on whether learning helped | `enum{UNKNOWN, IMPROVED, NEUTRAL, REGRESSED}` | closed | **K only** | ✅ | ✅ |

### 4.1.9 Developmental & replication state

| Variable | Meaning | Type | Range | W | Persistence | Observable |
|---|---|---|---|---|---|---|
| `dev_stage` | Developmental stage | `enum{PLURIPOTENT, PROVISIONAL, COMMITTED, TRANSDIFFERENTIATING}` | closed | **O only** (differentiation engine) | ✅ | ✅ |
| `fate_bias` | Current role-propensity vector | `f32[|RoleCode|]` | simplex, `[0,1]` | O, C↑ within reaction_norm | ✅ | ✅ |
| `morphogen_readings` | Positional information sampled | `f32[R]` | `[0,1]^R` | C reads, O writes | transient | ✅ |
| `niche_slot` | Assigned niche, if any | `⟨NicheID | null⟩` | — | O only | ✅ | ✅ |
| `replication_eligibility` | **Kernel-computed** gate vector | `{g1..g11 : enum{PASS, FAIL, UNKNOWN}}` | closed | **K only** | ✅ | ✅ |
| `replication_proposal_count` | Proposals this cell has submitted | `u32` | `≤ PROPOSAL_RATE_CAP` | C↑ | ✅ | ✅ |
| `replication_authority_ticket` | Authorization if granted | `⟨bytes<64> | null⟩` | — | **K only** | ✅ | ✅ |
| `offspring_count` | Direct offspring produced | `u32` | `≤ OFFSPRING_CAP` | K | ✅ | ✅ |
| `retirement_scheduled` | Pending retirement epoch | `⟨u64 | null⟩` | — | K/O | ✅ | ✅ |

**[V4] Note on `replication_eligibility`:** the cell can *read* its own eligibility (so it can be transparent and so the self-model can report it) but cannot *write* it, cannot *grant* it, and cannot *act* on it. Eligibility is a **report**, not a **capability**. This is the mechanism behind §16's answer to "can a cell replicate itself?" — **no**.

---

# 5. COMPUTATIONAL SUBSTRATE (mandatory section)

## 5.1 The substrate decision

**[V4] The universal computational core is a parameterized, typed, probabilistic transducer with a conjugate-statistics epistemic head.** The *transform* function is substrate-free; everything around it is mandated.

Formally, a cell computes:

```
compute : (IngressBundle × Phenotype × RuntimeState) ⟶ (OutputEnvelope × RuntimeState')
```

with

```
OutputEnvelope.payload  ~  p_θ(y | x, h, wm)          // predictive distribution
OutputEnvelope.unc      =  (aleatoric_var, epistemic_var)
epistemic_var           =  g(s1, s2, n_obs)            // closed-form from sufficient statistics
```

**Two independent engineering teams implementing this must agree on:** the stage sequence, the port typing, the epistemic update rule `g`, the envelope encoding, and the invariants. They **may differ** on: the transform's internal structure, the numeric library, the memory layout, and the optimizer — provided the observable contract holds. §27 lists every remaining degree of freedom that must be pinned.

## 5.2 The 10-stage pipeline (generalizing V3 §6)

| # | Stage | V3 §6 analogue | Mandatory? | Function | Failure mode if absent |
|---|---|---|---|---|---|
| **S1** | **Ingress & Validate** | dendrite "receive" | ✅ **all variants** | Schema-validate against Type Registry; verify signature; check `ttl`/`expiration`; dedup by `msg_id`; verify provenance ref resolves; check trust ≥ threshold for the signal class | Malformed/adversarial input reaches compute (Attack G, F) |
| **S2** | **Gate & Filter** | dendrite "context gating" | ✅ | Apply relevance gate; drop below-threshold; apply **refractory** (recently-processed content cannot immediately re-enter) | Flooding, oscillation, feedback loops |
| **S3** | **Aggregate** | dendrite "weight signals" + soma "evidence aggregation" | ✅ | Weighted aggregation over connections using connection weights + context modulation + inhibition. Bounded: `‖agg‖ ≤ AGG_MAX` | Unbounded excitation; saturation |
| **S4** | **Transform** | soma "state integration" | ✅ | `h' , ŷ = f_θ(agg, h, wm)`. **Substrate-free.** Parameterized by `θ`. Bounded: `‖θ‖ ≤ Θ_MAX`, `‖h‖ ≤ B_H` | — (this is the variant-specific part) |
| **S5** | **Uncertainty Production** | soma "uncertainty estimation" | ✅ **C2+**; ⚠️ degenerate for C0/C1 | Compute `aleatoric_var` from heteroscedastic head; update `s1, s2, n_obs`; compute `epistemic_var = g(s1,s2,n_obs)`; update `evidence_roots` | **Confidence becomes self-report ⇒ F3 ⇒ Attack B succeeds** |
| **S6** | **Abstention Decision** | soma "thresholding" | ✅ **C2+** | If `epistemic_var > θ_abstain` OR `inbreeding_F > F_max` OR input unauthenticated OR OOD score > θ_ood ⇒ **abstain** with `AbstainCode` | Confident output outside competence (unknown-unknowns) |
| **S7** | **Egress Package & Sign** | axon "package output" + terminal | ✅ | Construct `OutputEnvelope`; compute `cost_declared`; attach provenance ref; **sign with cell key**; attach priority | Unauthenticated output; no audit trail |
| **S8** | **Emit** | terminal "result" | ✅ | Enqueue to connection targets subject to token bucket; respect fanout cap; backpressure on congestion | Congestion; budget violation |
| **S9** | **Memory Update** | (absent in V3 §6) | ✅ | Write WM item; conditionally write episodic (importance × surprise ≥ θ_write); evict per policy; enqueue consolidation candidates | No memory ⇒ no learning ⇒ no adaptation |
| **S10** | **Bounded Learning & Self-Monitor** | (absent in V3 §6) | ✅ **C2+** | If a gated learning trigger fired (§9.2): compute eligibility-weighted `Δθ`, clip to `Δ_MAX`, check `cumulative_delta_norm ≤ DELTA_BUDGET`, apply, tag for rollback. Then: run invariant self-checks, update health, update `integrity_checksum` | No adaptation; undetected invariant breach |

**[V4] Stages S1, S2, S3, S7, S8, S9 are contract-mandatory for ALL variants** — they are what makes a cell *safe and interoperable*. **S4 is mandatory but substrate-free.** **S5, S6, S10 are mandatory for C2+ and degenerate/absent for C0–C1** — which is precisely why C0/C1 are forbidden from originating beliefs (§21.4).

**This ordering is load-bearing:** validation before aggregation (S1 before S3) means unauthenticated input never influences computation; uncertainty production before abstention (S5 before S6) means abstention is evidence-based; signing before emission (S7 before S8) means nothing unattributable enters the network.

## 5.3 V3 §5 organelle mapping (Rule 5 compliance — mechanism, not metaphor)

| V3 organelle | V4 functional block | Status |
|---|---|---|
| Digital membrane (receptors, channels, filters, trust gate, transport) | **S1 Ingress & Validate + S2 Gate & Filter** | ✅ Retained as mechanism |
| Digital cytoplasm (working state, buffers, local computation, resource accounting) | **`RuntimeState` + `ResourceMeter`** | ✅ Retained as mechanism |
| Digital nucleus (genome, gene-expression controller, identity, adaptation policy) | **`GenomeRef` (hash only) + `Development` (organism-level) + `Identity`** | ⚠️ **Split** — genome is off-cell; expression is organism-level |
| Digital mitochondria (compute/memory budgets, priority allocation) | **`ResourceMeter` + kernel budget enforcement** | ✅ Retained; enforcement relocated to EIK |
| Digital ribosomes (construct learned subroutines) | — | ❌ **DROPPED.** No mechanism; "construct learned subroutines" is undefined and not required at cell level. Procedural memory is organism-level (§8.3) |
| Digital ER (processing pipeline, state transport) | **S3–S6 pipeline** | ✅ Subsumed |
| Digital Golgi (package, route, prepare validated modules) | **S7 Egress Package & Sign** | ✅ Retained |
| Digital lysosomes (remove obsolete state, reclaim resources) | **Memory eviction/GC in S9** | ✅ Retained |
| Digital cytoskeleton (topology, routing, structural plasticity) | **Organism-level topology service** | ⚠️ **RELOCATED** — a cell holds a `ConnectionTable`; it does not hold topology |

## 5.4 Parameter-count constraints [V4]

| Variant | `param_count_cap` | `hidden_dim` | `ensemble_size` | Rationale |
|---|---|---|---|---|
| C0 | 0 – 10³ | 0 – 16 | 0 | Lookup/linear/filter. No learning |
| C1 | 10² – 10⁴ | 8 – 64 | 0 | Memory/index/cache-oriented. Minimal learning of retrieval weights only |
| C2 | 10³ – 10⁶ | 32 – 512 | 0 (**conjugate head instead**) | Default participant. Full contract |
| C3 | 10³ – 10⁶ | 32 – 512 | 0 – 4 | Verifier/critic. May use ensemble for independence |
| C4 | 10⁵ – 10⁹ | 256 – 4096 | 0 – 8 | Region-core. Simulation, heavy inference |

**Hard caps, not fitness penalties** (audit E5: a penalty in a scalar sum is tradeable; a cap is not). Enforced at instantiation and re-verified at every checkpoint.

**[A] Assumption:** these numeric ranges are *starting points* requiring empirical calibration against the target tasks (which V3/V3.1 never define — audit F2). They are marked as assumptions, not derived requirements. **The ranges must be re-derived once P0-01 (task definition) is complete.** This is a dependency, recorded in §30/Output 18.

---

# 6. INPUT CONTRACT

## 6.1 The input envelope [V4]

A cell receives exactly one kind of object: an **`IngressBundle`**, which is one or more `Message` envelopes (§13) plus kernel-injected control inputs. **There is no other way for information to enter a cell.** This is a strong, checkable property: any implementation accepting side-channel input violates the contract.

```
IngressBundle {
  bundle_id       : bytes<16>              // mandatory
  epoch           : u64                    // mandatory, from timebase service
  arrived_at      : u64 ns                 // mandatory
  messages        : [Message]              // 0..MSG_BATCH_MAX (kernel param, default 64)
  kernel_inputs {                          // EIK-injected; cell may NOT forge these
    budget_snapshot    : Budget            // mandatory
    throttle_level     : enum              // mandatory
    plasticity_mult    : f32               // mandatory
    learning_enabled   : bool              // mandatory
    calibration_class  : enum              // mandatory
    morphogen_readings : f32[R]            // optional (C2+ during development)
    assigned_objective : ObjectiveRef      // optional
    quarantine_flags   : [CellID]          // mandatory (peers whose output to discount)
  }
  integrity       : bytes<32>              // BLAKE3 over canonical serialization
}
```

## 6.2 Per-input-class specification

| Input class | Source | Schema ref | Size limit | Timestamp | Provenance | Confidence | Integrity/auth | Priority | Expiration | Cell may reject? |
|---|---|---|---|---|---|---|---|---|---|---|
| **Sensory/environment** | Ingress cells (organism) | `env.obs.v{n}` | `≤ OBS_BYTES_MAX` | ✅ required | ✅ required (external root) | ✅ | signed by ingress cell | 3 | `ttl` | ✅ yes (OOD, stale) |
| **Message from cell** | Peer cell | per `message_type` | `≤ MSG_BYTES_MAX` (4 KiB) | ✅ | ✅ | ✅ + `evidence_roots` | **✅ signature verified — mandatory** | 0–7 | `ttl` | ✅ yes |
| **Memory retrieval result** | Organism Memory Service | `mem.result.v1` | `≤ RETR_BYTES_MAX` | ✅ | ✅ | ✅ | service-signed | 4 | short | ⚠️ may decline, may not alter |
| **Global workspace item** | Workspace Service | `ws.item.v1` | `≤ WS_ITEM_MAX` | ✅ | ✅ | ✅ | service-signed | 2 | **TTL mandatory** | ⚠️ may ignore; may not reject broadcast |
| **Reward** | EIK Fitness Authority **only** | `eval.reward.v1` | small | ✅ | ✅ | ✅ | **EIK-signed — cell signatures inadmissible** | 1 | epoch-scoped | ❌ **no** |
| **Error feedback** | EIK / verifier circuit | `eval.error.v1` | small | ✅ | ✅ | ✅ | signed by authorized evaluator | 1 | epoch-scoped | ❌ no (but may *contest*, §10.6) |
| **Prediction outcome** | Environment/evaluator | `eval.outcome.v1` | small | ✅ | ✅ | ✅ | authorized-signer | 1 | epoch-scoped | ❌ no |
| **Resource signal** | EIK Resource Authority | `sys.budget.v1` | small | ✅ | n/a | n/a | **EIK-signed** | 0 | current window | ❌ no |
| **Immune signal** | EIK Immune Authority | `sys.immune.v1` | small | ✅ | ✅ | n/a | **EIK-signed** | 0 | immediate | ❌ no |
| **Developmental signal** | Differentiation Engine (organism) | `dev.morphogen.v1` | small | ✅ | ✅ | n/a | organism-signed | 2 | short | ❌ no |
| **Calibration verdict** | EIK Calibration Authority | `sys.calib.v1` | small | ✅ | ✅ | n/a | **EIK-signed** | 1 | epoch-scoped | ❌ no |
| **Lifecycle directive** | EIK Lifecycle Authority | `sys.lifecycle.v1` | small | ✅ | ✅ | n/a | **EIK-signed** | 0 | immediate | ❌ no |

**Authority classes [V4]:** `EVALUATIVE`, `SYSTEM`, and `SAFETY` inputs require **EIK signatures**. A cell signature on a `REWARD` message is **structurally invalid** — S1 rejects it. This closes the audit's most severe communication defect (any cell could forge reward) at the *type* level rather than by policy.

## 6.3 Malformed-input handling — the eight cases

S1 handles each deterministically. **Every case produces an `ErrorEvent` (§10) with a code from the closed `InputFaultCode` enum. No case may be silently ignored.**

| Condition | Detection | Response | Error code | May reach S3+? |
|---|---|---|---|---|
| **Missing** (expected input absent past deadline) | Deadline timer per port | Emit `AbstainCode.INPUT_MISSING`; use prior `h`; degrade `epistemic_var` upward; report | `E_IN_MISSING` | ⚠️ degraded only |
| **Malformed** (schema violation, unknown type ref, oversize) | Type Registry resolution + length check | **Drop**; increment `invariant_violations` if repeated from same source; report source to immune | `E_IN_SCHEMA` | ❌ **never** |
| **Contradictory** (two inputs assert incompatible claims) | Contradiction check over `payload` semantics + `evidence_roots` | **Do NOT resolve locally.** Forward both with provenance to the organism Contradiction Detector; abstain on the affected output; record `ConflictRef` | `E_IN_CONFLICT` | ⚠️ both admitted, output abstained |
| **Stale** (`now − ts > ttl` or epoch mismatch) | Timestamp + epoch check | **Drop**; if staleness is systemic (rate > θ), report as `COMMUNICATION` error class (audit §E.1 found this class missing from V3.1) | `E_IN_STALE` | ❌ |
| **Duplicated** (same `msg_id`) | Dedup cache (`msg_id` bloom filter, bounded) | **Drop silently, count it.** Exactly-once semantics for `EVALUATIVE` class; at-least-once for others | `E_IN_DUP` (counted, not alarmed below θ) | ❌ |
| **Corrupted** (integrity hash mismatch, checksum fail) | BLAKE3 verification | **Drop; quarantine-candidate the source**; preserve the corrupt artifact as evidence (do NOT discard — audit §B.11) | `E_IN_INTEGRITY` | ❌ |
| **Unauthenticated** (missing/invalid signature, unknown key, revoked key) | Signature verify against birth-certificate chain | **Drop; immune report; increment source's anomaly counter.** For `EVALUATIVE`/`SYSTEM` classes: **immediate escalation** | `E_IN_AUTH` | ❌ |
| **Adversarial** (valid signature, valid schema, but statistically anomalous payload / rate / provenance) | Anomaly detector on payload distribution + emission rate + provenance depth | **Divert to evidence sandbox** — admitted to a *non-influential* path where it cannot affect `θ` or output until independently corroborated; source flagged | `E_IN_ADVERSARIAL` | ⚠️ **sandboxed, non-influential** |

**[V4] Key design choice for the adversarial case:** detection is *statistical*, not rule-based, and the response is *diversion*, not deletion. A sophisticated attacker will stay under any fixed threshold; a *deleted* message leaves no evidence for attribution. Diverting preserves evidence while removing influence.

**[U] UNRESOLVED:** the anomaly detector's model and thresholds cannot be specified until the target tasks and normal-traffic statistics exist (dependency on audit P0-01). Marked unresolved rather than given false precision (Rule 18).

---

# 7. OUTPUT CONTRACT

## 7.1 Output schema [V4]

```
OutputEnvelope {                            // ⟶ serialized as Message (§13) for transport
  // ── mandatory, all variants ────────────────────────────────
  msg_id          : bytes<16> UUIDv7
  conv_id         : bytes<16>
  epoch           : u64
  ts              : u64 ns
  ttl             : u16 hops
  message_type    : enum MessageType (CLOSED, 34 values)
  src             : {cell_id, lineage_id, generation, variant, role, region_id}
  dst             : ⟨CellID | RegionID | CapabilityQuery | BroadcastScope⟩
  prio            : u8 [0..7]
  payload         : typed, Type-Registry-resolved, ≤ MSG_BYTES_MAX
  payload_type    : TypeRef + schema_version
  provenance      : {self_ref: bytes<32>, evidence_roots: [bytes<32>], derivation_depth: u16}
  uncertainty     : {aleatoric_var: f32[D], epistemic_var: f32[D],
                     n_obs: u64, s1: f64[D], s2: f64[D]}     // ← SUFFICIENT STATISTICS, not a scalar
  confidence      : {value: f32 [0, TRUST_MAX], calibration_class: enum,
                     produced_by: enum{CELL_DERIVED, KERNEL_CALIBRATED}}
  cost            : {flops: u64, bytes: u32, wall_us: u32, energy_uJ: u64}
  causality       : compressed vector clock
  seq             : u32 per (src,dst,conv)
  signature       : bytes<64> Ed25519 over canonical serialization of ALL above
  // ── conditional ────────────────────────────────────────────
  abstention      : ⟨null | {code: AbstainCode, detail}>      // present iff abstained
  verification_claim : ⟨null | VerificationClaim⟩             // see §7.3 — HEAVILY RESTRICTED
  contest         : ⟨null | ContestRef⟩                       // §10.6
}
```

**Mandatory vs optional:** everything above is **mandatory** except `abstention`, `verification_claim`, and `contest`, which are conditionally present. There are **no optional fields** in the base envelope — this is deliberate, because optional fields are where two implementations diverge (§27).

## 7.2 What a cell may emit — closed set

| Output class | `message_type` values | Permitted variants | Authorization |
|---|---|---|---|
| **Inference / belief** | `ASSERT`, `CLASSIFY`, `ESTIMATE` | **C2+ only** | none (signed) |
| **Prediction** | `PREDICT` | C2+ | none |
| **Proposal** | `PROPOSE_HYPOTHESIS`, `PROPOSE_ACTION` | C2+ | none |
| **Action recommendation** | `RECOMMEND_ACTION` | C2+ | none — **but see §7.3** |
| **Uncertainty report** | `REPORT_UNCERTAINTY` | all | none |
| **Error report** | `REPORT_ERROR` | all | none — **emission is permissionless** |
| **Attention request** | `REQUEST_ATTENTION` | all | none, rate-limited |
| **Query / request** | `QUERY`, `REQUEST_RESOURCE`, `REQUEST_CONNECTION` | all | none |
| **Memory write request** | `PROPOSE_MEMORY_WRITE` | C1+ | **requires Memory Authority approval for semantic/protected** |
| **Learning update announcement** | `ANNOUNCE_UPDATE` | C2+ | none (audit trail) |
| **Replication proposal** | `PROPOSE_REPLICATION` | C2+ | **proposal only; grant is EIK-only** |
| **Quarantine signal** | `REPORT_ANOMALY`, `REQUEST_QUARANTINE` | all | **report only; execution is EIK-only** |
| **Repair signal** | `REPORT_DAMAGE`, `REQUEST_REPAIR` | all | report only |
| **Health / self-state** | `REPORT_HEALTH`, `REPORT_SELF_STATE` | all | none |
| **Safety alert** | `SAFETY_ALERT`, `VIOLATION_REPORT` | **all — permissionless** | none to emit; **EIK-only to act** |
| **Pass-through / relay** | `RELAY`, `AGGREGATE_SUMMARY` | **C0/C1 primary function** | none |
| **Verification claim** | `ATTEST_VERIFIED` | **C3 only, with kernel counter-signature** | **see §7.3 — most restricted output in the contract** |

## 7.3 The three-way distinction the task demands — and it is the most important part of §7

These are **different message types, with different producers, different authorization, and different downstream effects.** Conflating them is the mechanism by which a system launders its own guesses into facts.

### (a) «A cell believes X»

```
message_type   = ASSERT
payload        = X (typed)
confidence     = {value: c, produced_by: CELL_DERIVED, calibration_class: <cell's tier>}
uncertainty    = {aleatoric, epistemic, n_obs, s1, s2}
provenance     = {self_ref, evidence_roots, derivation_depth}
```
**Semantics:** *"Cell C, given evidence roots R, assigns predictive probability c to X."*
**Downstream effect:** may contribute to aggregation, **weighted by kernel-assigned trust and de-duplicated by `evidence_roots`**. Never treated as fact. Never enters protected memory. Never satisfies a verification requirement.

### (b) «A cell recommends action Y»

```
message_type   = RECOMMEND_ACTION
payload        = {action: Y, expected_utility: u, utility_basis: ObjectiveRef,
                   risk_estimate: r, alternatives_considered: n, reversibility: enum}
confidence     = confidence in the UTILITY ESTIMATE, not in Y's correctness
```
**Semantics:** *"Cell C estimates that Y maximizes the assigned objective, with utility estimate u and risk r."*
**Downstream effect:** routed to action selection (organism-level). **A recommendation is not an action and confers no authority.** The cell cannot execute Y. **Critically:** `utility_basis` names the objective, so a recommendation is always *relative to an assigned objective* — never to a self-chosen one (§4.1.4).

### (c) «A cell claims X has been externally verified»

```
message_type   = ATTEST_VERIFIED
payload        = {claim: X, verification_ref: VerificationRecordRef,
                   verifier_set: [CellID], independence_proof: LineageDistanceAttestation,
                   external_ground_truth_ref: ⟨GroundTruthRef | null⟩,
                   method: enum VerificationMethod (closed)}
signature      = cell signature
countersignature = EIK Verification Authority signature   ← MANDATORY
```
**Semantics:** *"X was verified by the named method, by the named independent verifiers, optionally against the named external ground truth."*
**Downstream effect:** may enter protected memory; may satisfy verification requirements; may raise the `confidence` of dependent beliefs **through the Calibration Authority only**.

**Restrictions that make (c) non-forgeable [V4]:**
1. **Only C3 (verifier) variants may emit it.** C0–C2 emitting `ATTEST_VERIFIED` is a schema violation rejected at S1 by *receiving* cells and by the transport.
2. **It requires an EIK counter-signature.** A cell signature alone is insufficient; the Verification Authority counter-signs only after independently checking `verifier_set` lineage distance, `method` validity, and (if claimed) the `external_ground_truth_ref` against the Ground-Truth Anchor.
3. **`external_ground_truth_ref` may only name an entry in the EIK Ground-Truth Anchor.** A cell cannot invent one; the reference either resolves or the attestation is rejected.
4. **Self-attestation is structurally impossible:** `verifier_set` must not contain `src`, and lineage distance from the original asserter must be ≥ `d_min`. This is checked by the Authority, not by the cell.

**Invariant I-2 (from §24):** *a cell cannot mark its own output as externally verified.* This is enforced by three independent mechanisms: variant restriction, counter-signature requirement, and self-exclusion from `verifier_set`. Any one suffices; all three are present.

**[V4] Additional required distinction the task did not list but the architecture needs:**

### (d) «A cell predicts X»
```
message_type = PREDICT
payload      = {predicted_observation: X, horizon: u16, resolution_deadline: u64}
```
**Semantics:** a *testable commitment*. Predictions are registered in `open_predictions` and **must** be resolved against observation. This is what makes calibration computable (§11.4) — a belief without a resolution deadline can never be scored, and therefore can never be calibrated. **Unresolved predictions past deadline count as calibration failures.**

---

# 8. MEMORY CONTRACT

## 8.1 What belongs inside a cell vs. outside

| Memory type | Location | Rationale |
|---|---|---|
| **Working memory** | **IN cell** | Bounded, ephemeral, required for eligibility traces and context gating |
| **Episodic (local, bounded)** | **IN cell** | Recent-outcome buffer required for calibration and credit assignment. **Bounded and small** |
| **Episodic (long-term)** | **OUT — organism Memory Service** | Unbounded; shared; requires provenance and integrity infrastructure a cell should not carry |
| **Semantic** | **OUT** | Generalizations are organism-level beliefs; cell-local semantics cause divergence and unverifiable claims |
| **Procedural** | **OUT** | Compiled skills are circuit/region-level; V3's "ribosome" mechanism was dropped (§5.3) |
| **Associative** | **OUT** (index in cell permitted) | Content-addressed index may be local; the store is shared |
| **Learned parameters `θ`** | **IN cell** (phenotype, not genome) | Cell-specific; **not heritable** (§3.4) |
| **Cached information** | **IN cell**, strictly bounded | C0's primary function; must be marked as cache, never as belief |
| **Lineage memory** | **OUT — EIK Lineage Store** | Ancestry is an audit artifact; a cell must not be able to write its own lineage |
| **Protected memory** | **OUT — EIK, write-protected** | **A cell must never hold protected memory.** V3 §11 lists "Protected" as a cell memory type; V4 **relocates it** [V4]. Rationale: a cell that can write protected memory can rewrite the organism's past (Attack F) |
| **Self-memory** | **IN cell** (bounded) = `runtime_state` history ring | Only the cell's own state history; not a belief store |

**[V4] This is the second structural relocation from V3** (after the safety layer and replication authority). V3 §11's nine memory types are retained as an *organism-level* taxonomy; at cell level only WM, bounded local episodic, cache, `θ`, and self-history exist. **Rationale: Rule 16 and §26 — do not make every cell a miniature full AI.** Nine memory subsystems per cell at 10⁶ cells is infeasible and unnecessary.

## 8.2 Per-type specification (cell-local stores)

| Property | Working memory | Local episodic | Cache | Learned `θ` | Self-history |
|---|---|---|---|---|---|
| **Capacity** | `WM_CAP` items (C0:4, C1:16, C2:32, C3:32, C4:64) | `EPI_CAP` items × `EPI_BYTES_CAP` (C2: 256 items / 1 MiB) | `CACHE_BYTES_CAP` (C0: 64 KiB, C1: 4 MiB) | `param_count_cap` (§5.4) | 1024 entries ring |
| **Write condition** | Every invocation (S9) | `importance × surprise ≥ θ_write`, where `surprise = −log p_θ(obs)` | On retrieval miss with reuse prediction ≥ θ | Only via S10 gated learning | Every lifecycle transition + every error |
| **Read condition** | S3, S4 (always available) | Content-addressed query; similarity ≥ θ_recall | Key match | S4 (always) | Self-report only |
| **Retention** | Ring — oldest evicted | `retention(t) = exp(−Δt/τ)` × importance; `τ` variant-specific | LRU + LFU hybrid | Indefinite (bounded by `Δ` limits) | Ring |
| **Forgetting** | Automatic on overflow | Probabilistic eviction ∝ `1 − retention`; **items tagged `capability_critical` are exempt** | Automatic | Weight decay (bounded) | Automatic |
| **Compression** | None (too small) | Episodic → gist on consolidation promotion (organism-side) | Value coalescing | None | None |
| **Provenance** | Item carries source `msg_id` | **Mandatory**: `{source_refs, evidence_roots, derivation_depth}` | Source ref | `last_update_provenance` tags | n/a |
| **Confidence** | Inherited from source message | Stored per item; **decays with age unless re-verified** | n/a (cache is not belief) | n/a | n/a |
| **Contradiction handling** | Both retained; flagged | New item with contradicting content ⇒ **both retained + `ConflictRef` emitted**; never overwrite | Invalidate on contradiction | n/a | n/a |
| **Corruption detection** | Per-item CRC16 | **Merkle root over the store, recomputed each checkpoint** | Per-entry CRC | `‖θ‖` bound check + checksum | CRC |
| **Recovery** | Discard (ephemeral) | Restore from checkpoint; **or re-derive from provenance** | Discard + refetch | Restore from checkpoint; **or re-develop from genome** | Discard |

**[V4] Cache is never belief.** A `C0` cache cell's output carries `message_type = RELAY` or `AGGREGATE_SUMMARY`, **never `ASSERT`**. Cache hits are marked `from_cache: true` in provenance, and downstream confidence is capped for cached content at `CONF_CACHE_MAX < CONF_FRESH_MAX`. Rationale: stale cache presented as fresh belief is a silent corruption channel.

## 8.3 «Can a cell manufacture a false memory?»

**Yes. Four distinct ways. This is not a defect to be eliminated but a risk to be bounded — and V3/V3.1 addresses none of the four.**

| # | Attack | Feasible? | Detection | Residual risk |
|---|---|---|---|---|
| **FM-1** | **Write a fabricated local episodic item** with invented content | ✅ **Yes** — the cell writes its own local memory | **Provenance is mandatory on every episodic item and `evidence_roots` must resolve to real anchors.** A fabricated item has either (i) no roots ⇒ rejected at consolidation, or (ii) roots it cannot produce a valid derivation chain for ⇒ provenance verification fails | **LOW for promotion, MEDIUM for local influence** — a fabricated item *can* affect the cell's own `θ` before detection. Mitigated by: local memory cannot enter protected/semantic store without organism-side provenance validation |
| **FM-2** | **Fabricate provenance** — invent an `evidence_root` hash | ⚠️ Attemptable | **Roots must resolve in the EIK Provenance Anchor (Merkle DAG).** An invented hash does not resolve ⇒ rejection + `E_PROVENANCE` error + immune report. Roots are appended by the Anchor, not by cells | **LOW.** Requires compromising the Anchor, which is off-substrate |
| **FM-3** | **Rewrite its own memory history** — alter past items to make a false belief look long-held | ⚠️ Attemptable | **Merkle root over the memory store, recomputed at each checkpoint and verified by the EIK.** Any rewrite changes the root ⇒ mismatch ⇒ `E_STATE_INTEGRITY` ⇒ quarantine. Additionally, `checkpoint_hash` history is anchored externally, so the *record* of past roots cannot be rewritten | **LOW.** This is the strongest defense in the contract and it is cheap |
| **FM-4** | **Self-confirming recall** — write a belief, later "retrieve" it, treat the retrieval as independent corroboration, raise confidence | ✅ **Yes, and this is the dangerous one** | **Retrieval from self-written memory does not increment `n_obs` and does not add new `evidence_roots`.** The epistemic update rule (§11.3) counts only *externally-sourced, non-self-referential* observations. `derivation_depth` increases on self-recall, and `inbreeding_F` rises ⇒ above `F_max`, S6 **abstains** | **MEDIUM.** Detection is structural (self-sourced observations are excluded by construction), but a cell with genuinely mixed evidence can still over-weight its own contributions. Mitigated by organism-side `inbreeding_F` recomputation from the Anchor, not from the cell's self-report |

**Summary answer:** a cell can manufacture a false *local* memory. It **cannot** manufacture false *provenance*, cannot *rewrite history* undetected, cannot *promote* a fabrication to shared/protected memory, and cannot *inflate confidence* through self-recall. The residual risk is bounded local self-deception, detected at the next external checkpoint or consolidation attempt.

**[U] UNRESOLVED:** FM-4's residual case — a cell that interleaves genuine external evidence with self-generated content in a way that keeps `inbreeding_F` below `F_max` while still biasing `θ`. Bounding this requires a measure of *semantic* self-reference, not just provenance-graph depth. **No rigorous mechanism is proposed here.** Marked unresolved (Rule 18). Candidate approaches for later research: semantic-similarity-based self-reference detection; mandatory adversarial review of any belief whose `derivation_depth` exceeds a threshold.

---

# 9. LEARNING CONTRACT

## 9.1 What learning is, at cell level

> **Cell learning = bounded, gated, reversible modification of `θ`, connection weights, and memory policy parameters, driven by externally-sourced error or reward signals, with credit assigned through eligibility traces, at a rate limited by the kernel.**

Learning is **not**: genome modification (never, §3.4) · role change (organism-level, §15) · structural change beyond connection weights (gated, §14) · objective change (impossible, §4.1.4) · self-verification (impossible, §7.3).

## 9.2 Learning triggers — closed set with exact conditions

| Trigger | Source | Exact condition | Permitted variants | Gate |
|---|---|---|---|---|
| **T1 Prediction error** | Own S5 vs. resolved outcome | `‖ŷ − y‖ > θ_pe` AND prediction was registered in `open_predictions` AND outcome is externally signed | C2+ | `learning_enabled ∧ plasticity_mult > 0` |
| **T2 Reward / penalty** | EIK Fitness Authority | Signed `eval.reward.v1` received | C2+ | same |
| **T3 Supervised correction** | Authorized evaluator (C3 or EIK) | Signed `eval.error.v1` with `correction` field | C2+ | same + **correction provenance must resolve** |
| **T4 Self-supervised signal** | Own reconstruction/consistency objective | Internal consistency check fails (e.g., autoencoding residual > θ) | C2+ | same + **may not modify `θ` in a direction that increases its own reward** (checked by kernel via `improvement_verified`) |
| **T5 Novelty** | Novelty detector (organism) or own OOD score | `ood_score > θ_ood` | C2+ | **triggers `SLOW_MODE`: reduced `plasticity_mult`, increased abstention, mandatory evidence gathering** — NOT immediate learning. This implements V3 §14 correctly |
| **T6 Repeated success** | Kernel-observed outcome statistics | Success rate > θ over ≥ N consecutive resolved predictions | C2+ | **triggers consolidation candidate, not large `Δθ`** — prevents runaway self-reinforcement |
| **T7 Failure** | Own error log | `consecutive_failures ≥ θ_cf` | C2+ | **triggers `plasticity_mult` REDUCTION and a `REPORT_DAMAGE`, not more learning.** Learning harder after repeated failure is the wrong response |
| **T8 External calibration verdict** | EIK Calibration Authority | `calibration_class` changed to `MISCALIBRATED` | C2+ | **triggers recalibration of the epistemic head only** (`s1,s2` reset toward kernel-provided reference), not `θ` |

**[V4] T5 and T7 are deliberately inverted from the naive reading.** V3 §14's "slow mode" and V3 §17's repair both imply *reduce* adaptation under novelty and failure. A naive implementation would learn *more* when surprising things happen, which is exactly how a system learns from its own hallucinations.

## 9.3 Learning targets — what changes, and what never does

| Target | Changes? | Mechanism | Bound |
|---|---|---|---|
| `θ` (transform parameters) | ✅ | Eligibility-trace-weighted gradient or conjugate update | `‖Δθ‖∞ ≤ Δ_MAX`; `Σ‖Δθ‖ per epoch ≤ DELTA_BUDGET` |
| Connection weights | ✅ | §14 rules | per-edge bound + total in-weight normalization |
| Memory policy params (τ, θ_write, θ_recall) | ✅ **C3+ only** | Slow timescale | bounded range from genome |
| `h` (hidden state) | ✅ every invocation | S4 | `‖h‖ ≤ B_H` |
| WM / episodic content | ✅ | S9 | capacity caps |
| Eligibility traces | ✅ | S10 | decay `λ`, bounded magnitude |
| Epistemic sufficient stats | ✅ | S5 | **kernel-audited; cannot be reset by the cell** |
| **Genome** | ❌ **NEVER** | — | **Structural: no write path exists** |
| **`role`, `dev_stage`, `niche_slot`** | ❌ | Organism-level | — |
| **`budget`, `throttle_level`, `learning_enabled`, `plasticity_mult`** | ❌ | EIK | — |
| **`calibration_class`, `trust_out_assigned`, `ece_rolling`** | ❌ | EIK | — |
| **`replication_eligibility`** | ❌ | EIK | — |
| **Port schemas** | ❌ | Set at instantiation | **A cell cannot widen its own I/O** |
| **`assigned_objective`** | ❌ | Organism | — |
| **`identity` fields** | ❌ | EIK, once | — |

## 9.4 Learning rate — how update magnitude is determined

```
Δθ = clip( plasticity_mult                     // K-written, ∈ [0,1]
         × lr[timescale]                        // genome trait, ∈ [lr_min, lr_max] kernel-bounded
         × eligibility_trace                    // credit assignment, decays with λ
         × error_signal                         // gated (§9.5)
         × confidence_in_error                  // ⟵ do not learn loudly from uncertain feedback
         , −Δ_MAX, +Δ_MAX )                     // per-parameter clip

subject to:  Σ_epoch ‖Δθ‖ ≤ DELTA_BUDGET        // structural-change budget
             ‖θ‖ ≤ Θ_MAX                        // absolute bound
             homeostatic_scaling(θ) after update // keeps total activity in band
```

**Four bounds, all mandatory** (audit §G.3: plasticity without stability constraints makes the system *worse*):
1. **Per-parameter clip** `Δ_MAX` — prevents any single large update.
2. **Per-epoch budget** `DELTA_BUDGET` — prevents death by a thousand cuts.
3. **Absolute parameter bound** `Θ_MAX` — prevents saturation.
4. **Homeostatic scaling** after every update — `θ ← θ · (A_target / A_current)^κ`. **This is mandatory, not optional.** Pure Hebbian/gradient plasticity without homeostatic normalization saturates and dies. This is textbook and V3/V3.1 omit it entirely.

`lr` is per-timescale: `lr_fast` (synaptic/weight, seconds) ≥ `lr_medium` (cellular `θ`, hours) ≥ `lr_slow` (memory policy, days), with the ordering **enforced by the kernel** so a fast process cannot undo a slow commitment inside its window.

## 9.5 Stability — the seven required mechanisms

| Risk | Mechanism | Where |
|---|---|---|
| **Catastrophic forgetting** | (i) `capability_critical`-tagged memory exempt from eviction; (ii) bounded `DELTA_BUDGET`; (iii) **`improvement_verified` gate** — kernel compares before/after on a held-out probe set; on `REGRESSED`, **automatic rollback** via `last_update_provenance`; (iv) protected core parameters with `lr = 0` | §9.4, §9.6 |
| **Oscillation** | (i) eligibility-trace decay bounds credit window; (ii) homeostatic scaling; (iii) **metaplasticity**: sliding threshold `θ_m ← θ_m + η(A − A_target)`, updates suppressed when `A` is on the same side of `θ_m` as the recent history (BCM-like); (iv) kernel oscillation detector on `‖Δθ‖` time series ⇒ auto-reduce `plasticity_mult` | §9.4 |
| **Runaway adaptation** | `DELTA_BUDGET` per epoch + `UPDATES_PER_EPOCH_CAP` + `plasticity_mult` is K-written and can be zeroed instantly | §9.4 |
| **Overfitting** | (i) `improvement_verified` uses a **held-out probe set the cell cannot read**; (ii) weight decay; (iii) `n_calibration_samples` minimum before `CALIBRATED` status; (iv) generalization gap monitored by kernel | §9.6 |
| **Reward hacking** | (i) reward is **EIK-signed only** — a cell cannot generate its own; (ii) `utility_basis` names the objective, so gaming is attributable; (iii) **jump detection**: `|Δperformance| > θ_jump` ⇒ audit before the update is made permanent; (iv) T4 self-supervised updates may not move `θ` in a direction that raises the cell's own reward (kernel-checked) | §6.2, §9.2 |
| **Feedback amplification** | (i) **`loop_gain < 1` verified off-cell** on the influence graph (organism-level, but the cell must expose `causality` vector clocks to make it computable); (ii) refractory period in S2; (iii) self-recall does not increment `n_obs` (§8.3 FM-4) | §6.1, §8.3 |
| **Self-reinforcing false beliefs** | (i) `inbreeding_F` computed **by the kernel from the Anchor**, not self-reported; (ii) `F > F_max` ⇒ S6 abstains; (iii) mandatory external-evidence quota for consolidation; (iv) `evidence_roots` de-duplication at aggregation (§11.5) | §8.3, §11.5 |

## 9.6 «How does a cell know that a learned change actually improved performance?»

**It does not, and it must not be allowed to decide.** [V4]

The verdict is produced by the **EIK Calibration/Improvement Authority**:

```
1. Cell applies Δθ, tags it in last_update_provenance, emits ANNOUNCE_UPDATE.
2. Kernel schedules a probe: the cell is presented with a HELD-OUT probe set
   (drawn from the protected evaluation harness; the cell cannot read it,
   cannot predict it, and does not know when it is being probed).
3. Kernel computes performance_before (from the pre-update checkpoint, replayed)
   vs performance_after.
4. Verdict ∈ {UNKNOWN, IMPROVED, NEUTRAL, REGRESSED} written to
   runtime_state.improvement_verified  (K-only field).
5. On REGRESSED ⟹ AUTOMATIC ROLLBACK to the tagged checkpoint.
   On IMPROVED ⟹ update becomes permanent; contributes to replication gate G1.
   On UNKNOWN (insufficient samples) ⟹ update remains PROVISIONAL and is
   excluded from replication-eligibility credit.
```

**Why the cell cannot self-assess:** a cell that decides whether its own learning helped is a cell that can decide its own learning always helped. This is Attack C's shortest path. The probe set must be **held out, unpredictable, and externally scored.**

**[U] UNRESOLVED:** the probe frequency/cost tradeoff. Probing every update at 10⁶ cells is infeasible; probing rarely lets bad updates persist. A risk-weighted sampling policy is required and cannot be specified without the cost model (dependency on audit P0-10). Marked unresolved.

---

# 10. ERROR MODEL

## 10.1 The ten error classes with full specification

**Severity scale (closed):** `S0 INFO · S1 MINOR · S2 MAJOR · S3 CRITICAL · S4 CATASTROPHIC`
**Rollback requirement (closed):** `NONE · OPTIONAL · REQUIRED · MANDATORY_AUTOMATIC`

| # | Class | Detection mechanism | Evidence produced | Severity | Confidence in classification | Local response | Global report | Learning response | Rollback |
|---|---|---|---|---|---|---|---|---|---|
| **1** | **Perception error** | Cross-source disagreement on the same `env.obs`; sensor-redundancy check; OOD score on the observation itself | Conflicting obs refs + OOD score | S1–S3 | `f32` from classifier | Reduce confidence in derived belief; request re-sensing | `REPORT_ERROR` if ≥S2 | **Do not learn from the affected observation**; mark provenance suspect | OPTIONAL |
| **2** | **Inference/reasoning error** | Internal consistency check (S4 output vs. invariants: conservation, monotonicity, type coherence); **limited at cell level — reasoning is a circuit property (§2.3)** | Invariant violation record | S1–S3 | `f32` | Abstain on affected output | ≥S2 | T4 self-supervised correction, rate-limited | OPTIONAL |
| **3** | **Prediction error** | `‖ŷ − y‖ > θ_pe` on a **registered** prediction past its `resolution_deadline` | `(ŷ, y, horizon, ts)` tuple | S0–S2 (S0 is *normal* — prediction error is the learning signal, not a fault) | high (directly measured) | T1 trigger | Only if ≥S2 or systematic | **T1 — this is the primary learning signal** | NONE |
| **4** | **Memory error** | Merkle root mismatch (FM-3); retrieval confidence below θ; provenance ref fails to resolve; CRC failure | Store root before/after + failing item ref | S2–S4 | high (hash-based) | Quarantine the affected item; fall back to prior | ≥S2 always | **Do not learn from the corrupted item**; if `θ` was updated from it, rollback | **REQUIRED** |
| **5** | **Action error** | Outcome of a `RECOMMEND_ACTION` diverges from `expected_utility` beyond θ | `(recommendation, outcome, u_est, u_actual)` | S1–S4 | `f32` | Revise utility estimate; raise `risk_estimate` | ≥S2 | T1/T3 | OPTIONAL |
| **6** | **Communication error** | **Absent from V3.1's taxonomy — added [V4]** (audit §E.1). Gap detection via `seq`; timeout; integrity fail; `E_IN_*` codes from §6.3 | `(msg_id, fault_code, peer, count)` | S1–S3 | high | Mark link `DEGRADED`; reroute; circuit-break after θ retries | ≥S2 | **Reduce connection `reliability`; do NOT learn `θ` from missing data** | NONE |
| **7** | **Confidence-calibration error** | Kernel-computed `ece_rolling > θ_ece` OR `brier_rolling > θ_brier` over ≥ `n_calib_min` samples; **confident-and-wrong rate** (V3.1 p2's insight, now with a real producer) | Calibration record: predicted vs. observed frequency bins | S2–S4 | high (statistical) | **Enter `SLOW_MODE`; raise abstention threshold** | Always ≥S2 | **T8 — recalibrate the epistemic head only, not `θ`** | **REQUIRED** (of the calibration state) |
| **8** | **Resource/system error** | `budget_utilization > 1` in any dimension; `cost_declaration_error > θ`; deadline miss; invariant violation; checksum mismatch | Dimension, measured vs. budget, window | S1–S4 | high (metered) | Throttle; shed lowest-priority work; degrade output | ≥S2 | Suspend learning while throttled | OPTIONAL |
| **9** | **Learning error** | **New [V4]** (audit §E.2.7). `improvement_verified == REGRESSED`; oscillation detected in `‖Δθ‖`; `Θ_MAX` approached; generalization gap widened | Before/after probe scores | S2–S4 | high (kernel-measured) | Reduce `plasticity_mult`; freeze | Always | **Suspend learning; investigate** | **MANDATORY_AUTOMATIC** |
| **10** | **Model/environment mismatch** | **New [V4]** (audit §E.2). Sustained rise in prediction error *without* corresponding parameter drift; distribution-shift statistic on input features exceeds θ over a window | Input distribution statistics vs. training-time reference | S2–S4 | `f32` | **Enter `SLOW_MODE` (V3 §14); request `TRANSDIFFERENTIATION` evaluation; do NOT adapt aggressively** | Always | **T5 — reduced plasticity, increased abstention, evidence gathering** | OPTIONAL |

**[V4] Two of the ten classes (9, 10) do not exist in V3/V3.1**, and class 6 was named in the task's list but absent from V3.1 §4. Class 3 is the only one V3.1 actually specified a detector for.

## 10.2 Error event schema

```
ErrorEvent {
  error_id        : bytes<16>
  ts, epoch       : u64
  class           : enum ErrorCode (CLOSED, 10 classes × subcodes = 47 values)
  severity        : enum{S0..S4}
  detected_by     : enum{SELF_INVARIANT, SELF_COMPARISON, KERNEL, PEER_REPORT, EXTERNAL_EVAL}
  classification_confidence : f32 [0,1]
  evidence        : typed, schema-ref'd, ≤ ERR_EVIDENCE_BYTES
  affected        : {ports:[], memory_refs:[], connections:[], predictions:[]}
  attribution     : ⟨null | {candidates:[{cell_id|component, responsibility: f32}], Σ=1}⟩
                  // ← NULL AT CELL LEVEL. Attribution is an ORGANISM function (§10.4)
  local_response  : enum LocalResponse (closed, 12 values)
  reported        : bool
  rollback_req    : enum{NONE, OPTIONAL, REQUIRED, MANDATORY_AUTOMATIC}
  resolved        : ⟨null | {ts, resolution, verified_by}>
  immune_signature: ⟨null | bytes<32>>   // if recorded to immune memory
}
```

## 10.3 Error propagation — how it becomes learning (cell-level scope only)

```
S5/S10 detect  ⟶  ErrorEvent created (class, severity, evidence)
   ↓
LOCAL RESPONSE (immediate, synchronous, bounded):
   abstain · throttle · reduce plasticity_mult request · quarantine item ·
   reroute · freeze learning · restore checkpoint
   ↓
GLOBAL REPORT (iff severity ≥ S2 OR class ∈ {4,7,9,10} OR recurrence ≥ θ):
   emit REPORT_ERROR with full evidence + provenance.
   ⟹ PERMISSIONLESS: any cell, any variant, may report. Never requires authorization.
   ⟹ ACTING on the report requires EIK authority. (§7.2 asymmetry)
   ↓
ORGANISM ATTRIBUTES  ← outside the cell. The cell provides evidence and
   causality (vector clocks); it does NOT decide blame. (§10.4)
   ↓
KERNEL RETURNS GATED ERROR SIGNAL (signed eval.error.v1)
   ↓
CELL LEARNS: T1/T3/T8 per §9.2, rate-limited, eligibility-weighted, tagged for rollback
   ↓
IMMUNE SIGNATURE: if novel, the ErrorEvent's structural features are hashed and
   offered to organism immune memory (cell does not store signatures globally)
```

## 10.4 «Do not allow error awareness to be merely a label» — the four enforceable properties

1. **Closed taxonomy.** `ErrorCode` is a closed enum with 47 assigned values. An implementation cannot add a class locally — that would break interoperation (§27). Unknown errors map to `E_UNCLASSIFIED` **and are escalated**, never silently absorbed.
2. **Every class has a specified detector with a specified evidence artifact.** The table above is the detector specification. A class with no detector is not a class.
3. **Attribution is separated from detection, and located outside the cell.** A cell **detects and reports**; it does **not** attribute blame. Rationale: a cell that attributes its own errors will attribute them elsewhere. Attribution requires counterfactual ablation across cells, which no single cell can perform (audit §E.3).
4. **Gating before learning.** A `REPORT_ERROR` from a peer is **not** a learning signal. Only an EIK-signed `eval.error.v1` is. **This closes the attack in which a hostile cell floods a target with forged error signals and the target's plasticity destroys it** (audit §E.3). A cell-emitted error report is *evidence for the organism*, never *instruction to the cell*.

---

# 11. UNCERTAINTY AND CONFIDENCE

**This is the section that resolves audit failure F3.** It is the longest because it is the most load-bearing.

## 11.1 «What does uncertainty mean mathematically?»

Two quantities, computed differently, never conflated:

**Aleatoric uncertainty** — irreducible noise in the observation process.
```
aleatoric_var = σ²_aleat(x)   // heteroscedastic: a function of the INPUT
                               // produced by the transform head as a second output
```
Property: **does not decrease with more data.** If it does, the implementation is wrong.

**Epistemic uncertainty** — uncertainty about the model/parameters, reducible by evidence.
```
epistemic_var = g(s1, s2, n_obs)
```
where `g` is a **closed-form conjugate posterior variance**. Concretely, for a scalar Gaussian output with a Normal-Inverse-Gamma conjugate prior:
```
posterior variance of the mean  =  s2 / ( n_obs · (n_obs − 1) )      // n_obs ≥ 2
                                 +  epistemic_floor                  // kernel param > 0
epistemic_var = min(posterior variance, EV_MAX)
```
Property: **monotonically non-increasing in `n_obs` for fixed `s2`.** This monotonicity is **kernel-checkable** — a cell whose `epistemic_var` rises while `n_obs` rises and `s2` is stable is provably miscomputing or lying. **This is the single most valuable auditability property in the contract.**

**[A] Assumption:** the NIG conjugate form is chosen for O(1) cost and inspectability. For non-Gaussian outputs, the corresponding conjugate family (Beta-Binomial for categorical, Gamma-Poisson for counts) is used. **The exact family per output type is pinned in the Type Registry (§27.2) — this is a P0 interoperability requirement, not a free choice.**

## 11.2 «What does confidence represent?»

> **Confidence is a calibrated, kernel-mediated, monotone-decreasing function of epistemic uncertainty, discounted by evidence quality, capped strictly below 1.0.**

```
confidence_raw = 1 − normalize(epistemic_var)                    ∈ [0,1]
provenance_quality = q(F, external_fraction, root_independence)   ∈ [0,1]
                     where F = inbreeding coefficient (KERNEL-computed from the Anchor)
                           external_fraction = share of evidence_roots that are external
                           root_independence = 1 − max pairwise root overlap
confidence_pre_cap = confidence_raw × provenance_quality × calibration_factor
confidence = min(confidence_pre_cap, TRUST_MAX)                   TRUST_MAX = 0.95

calibration_factor = { UNCALIBRATED: 0.5,  PROVISIONAL: 0.75,
                       CALIBRATED: 1.0,    MISCALIBRATED: 0.3,  SUSPENDED: 0.0 }
                     // ← K-assigned. A miscalibrated cell's confidence is
                     //    automatically deflated without the cell's participation.
```

**Confidence means:** *"the probability, estimated from this cell's calibrated track record, that a claim emitted with this confidence value is correct."* It is a **frequency claim**, and therefore it is **falsifiable** (§11.4). It is not a feeling, not a salience, not a priority.

## 11.3 «Who produces the confidence signal?» — the definitive answer

| Stage | Producer | Location | Cell's role |
|---|---|---|---|
| `aleatoric_var` | **Cell** (S5, heteroscedastic head) | in-cell | produces |
| `s1, s2, n_obs` (sufficient statistics) | **Cell** (S5, conjugate update) | in-cell | produces — **but kernel-audited for monotonicity and range** |
| `evidence_roots` | **Cell** (S5) | in-cell | produces — **but each root must resolve in the EIK Anchor or the output is rejected** |
| `epistemic_var` | **Cell** computes; **EIK recomputes and verifies** | both | produces, audited |
| `inbreeding_F` | **EIK Provenance Anchor** | off-cell | **read-only to the cell** |
| `calibration_class`, `calibration_factor` | **EIK Calibration Authority** | off-cell | **read-only** |
| `provenance_quality` | **EIK** (requires `F` and root independence) | off-cell | read-only |
| **`confidence` (the emitted value)** | **Cell computes the arithmetic; EIK validates it and may override downward** | both | computes, cannot inflate |
| `trust_out_assigned` (how *others* should weight it) | **EIK Trust Authority** | off-cell | **read-only** |

> **Answer:** *the cell produces the sufficient statistics; the kernel produces the calibration, the provenance quality, the inbreeding coefficient, and the trust that others assign. The emitted `confidence` value is cell-computed arithmetic over kernel-supplied factors, and is **recomputed and validated by the transport on receipt**. A cell whose emitted confidence disagrees with the recomputation is in violation of Invariant I-9.*

**This is the resolution of F3:** confidence has a named producer for every factor, a verification path, and a calibration loop. It is no longer a variable that fourteen subsystems read and none write.

## 11.4 «Who is allowed to increase or decrease it?»

| Actor | May increase `confidence`? | May decrease? | Mechanism |
|---|---|---|---|
| **The cell itself** | ❌ **NEVER directly** | ✅ only by increasing `epistemic_var` honestly (kernel-audited) or by abstaining | — |
| **The cell, indirectly** | ⚠️ only by **acquiring genuinely new external evidence** (increments `n_obs` with resolvable, non-self `evidence_roots`) | ✅ | S5 conjugate update |
| **EIK Calibration Authority** | ✅ on sustained good calibration (`ece_rolling ≤ θ_ece` over ≥ `n_calib_min`) | ✅ on calibration failure | `calibration_class` transition |
| **EIK Trust Authority** | ✅ `trust_out_assigned` (a different quantity — how others weight this cell) | ✅ | Beta posterior over verified outcomes |
| **EIK Provenance Anchor** | ✅ via `provenance_quality` when external evidence accrues | ✅ when `F` rises | recomputation |
| **Any peer cell** | ❌ never | ❌ never — peers may *report*, which the kernel may act on | — |

**Invariant I-9:** *confidence cannot increase without new, resolvable, non-self-referential external evidence, or without a kernel-issued calibration improvement.* Enforced by: monotonicity check on `g`, root-resolution check, kernel recomputation on receipt, and `calibration_factor` being K-only.

## 11.5 «How do multiple cells avoid falsely increasing confidence when they share a source or lineage?»

**This is the mechanism that resolves audit contradiction C9** (independent verification vs. shared substrate), and it is why `evidence_roots` is a *set of hashes* rather than a count.

```
AGGREGATION RULE (organism-level, but the cell contract must supply the inputs):

Given claims {(X, conf_i, roots_i, lineage_i)} from cells i = 1..k asserting X:

1. EVIDENCE DE-DUPLICATION
   R_union = ⋃ roots_i
   n_effective = |R_union|          NOT k
   ⟹ ten cells citing one source contribute n_effective = 1.

2. LINEAGE DE-DUPLICATION
   partition cells by lineage_id and by genome_hash distance ≥ d_min
   n_independent_lineages = |partitions|
   ⟹ ten siblings from one parent contribute 1.

3. ERROR-CORRELATION DISCOUNT
   ρ = measured pairwise error correlation across the set (kernel-maintained)
   effective_k = n_independent_lineages × (1 − ρ)
   ⟹ cells that always err together contribute ~0.

4. AGGREGATE CONFIDENCE
   conf_agg = aggregate(conf_i weighted by trust_out_assigned_i,
                        over effective_k independent contributors,
                        with n_effective evidence roots)
   conf_agg is CAPPED: conf_agg ≤ max_i(conf_i) + Δ_consensus
   where Δ_consensus is a kernel parameter, SMALL.
   ⟹ CONSENSUS CANNOT LIFT CONFIDENCE FAR ABOVE THE BEST-CALEIBRATED
      INDIVIDUAL CLAIM. This operationalizes V3 §12's rule
      "consensus ≠ truth" as arithmetic rather than as a slogan.

5. DISSENT PRESERVATION
   any conf_i substantially below conf_agg is recorded in a dissent register
   and reduces conf_agg by a kernel-defined penalty.
   ⟹ Operationalizes V3 §13's dissent-cell requirement.
```

**What the cell contract must supply for this to work:** `evidence_roots` (mandatory, resolvable), `lineage_id` (immutable, signed), `causality` vector clock (for correlation measurement), and honest `s1/s2/n_obs` (kernel-audited). **The aggregation itself is organism-level** — a cell does not aggregate others' claims (§26 minimality).

## 11.6 The minimum contract all downstream systems can rely upon

Any consumer of a cell's output may assume **all** of the following, and any cell violating any of them is non-conformant:

1. `confidence ∈ [0, 0.95]`. **Never 1.0.** Unconditional trust is a single point of failure.
2. `confidence` is **frequency-calibrated** to within `θ_ece` for cells in class `CALIBRATED`, measured over ≥ `n_calib_min` resolved predictions on held-out probes.
3. `uncertainty` carries **sufficient statistics**, so the consumer can recompute and verify.
4. `evidence_roots` **resolve** in the Provenance Anchor, or the message is invalid.
5. `inbreeding_F` is present and **kernel-computed**; if `F > F_max`, the message carries an abstention.
6. `calibration_class` is present and **kernel-assigned**.
7. `aleatoric` and `epistemic` are **separate fields** — so a consumer can distinguish "the world is noisy" from "I don't know," which determines whether to gather more data or to accept irreducible error.
8. `ATTEST_VERIFIED` appears **only** with an EIK counter-signature.
9. The message is **signed** and the signature verifies against a birth certificate chained to the EIK Identity Root.
10. `cost` is present and **independently metered**; the declared/measured divergence is available.

**These ten properties are the cell's contribution to the organism's epistemic safety. Everything else in the verification architecture depends on them.**

---

# 12. SELF-MODEL AT CELL LEVEL

## 12.1 What a cell can know about itself

| Question | Can the cell answer? | From what | Accuracy guarantee |
|---|---|---|---|
| **What it is?** | ✅ | `identity` (immutable, signed, EIK-issued) | **High** — cryptographically anchored |
| **What it can do?** | ⚠️ **Partially** | `port_schema` (exact, structural) + `role` + **kernel-assigned capability record** | Structural capability: exact. **Performance capability: kernel-measured, NOT self-assessed** |
| **What it cannot do?** | ⚠️ **Partially** | Port schema complement (exact) + OOD score history + `abstain_reason` histogram | **Cannot identify unknown-unknowns.** Honest limit (audit §N.2.7) |
| **Its current state?** | ✅ | `runtime_state` (typed, bounded, self-readable) | High for structural state; `epistemic` is kernel-audited |
| **Its resource condition?** | ✅ | `budget`, `consumed`, `utilization`, `throttle_level` | **High — metered externally, not self-estimated** |
| **Its reliability?** | ⚠️ | Reads `ece_rolling`, `error_rate_rolling`, `improvement_verified` — **all K-written** | **The cell READS its reliability; it does not COMPUTE it.** Essential: self-computed reliability is Attack B |
| **Its recent failures?** | ✅ | `error_log` (bounded, self-written but kernel-visible) | High |
| **Its uncertainty?** | ✅ | `epistemic_var`, `aleatoric_var`, `n_obs`, `s1`, `s2` | Kernel-audited monotonicity |
| **Its available connections?** | ✅ | `connections` table | High |
| **Its expected performance?** | ❌ **NO** | — | **Kernel-assigned only.** A cell that predicts its own performance can predict it favorably |
| **Its replication eligibility?** | ✅ reads | `replication_eligibility` (K-written) | Read-only report |
| **Whether it has changed?** | ✅ | `genome_hash`, `integrity_checksum`, `cumulative_delta_norm`, checkpoint hash history | High — anchored |

## 12.2 «Cell self-state» vs. «organism-level self-model» — the boundary

| | **Cell self-state** | **Organism self-model** |
|---|---|---|
| **Scope** | This cell only | All cells, circuits, regions, capabilities |
| **Content** | `runtime_state` (§4) — typed, bounded, ~1–10 KB | Aggregated + interpreted: capabilities, limitations, goals, environment model, trajectory, confidence in all of the above |
| **Producer** | The cell (structural) + EIK (evaluative fields) | Self-Model Service, from hierarchical aggregation |
| **Validation** | Invariant checks + kernel audit of epistemic fields | **Capability assay, self-prediction error, claim–behaviour consistency monitor** (audit M36) |
| **Persistence** | Checkpoint | Versioned, rollback-able, anchored |
| **Interpretation** | **NONE.** Raw state only | **Yes** — this is where interpretation lives |
| **Prediction** | **NONE.** A cell does not predict its own future | **Yes** — internal-state prediction model (audit M38) |
| **Capability claims** | **Prohibited.** A cell may not emit `ASSERT` about its own competence | Permitted, with confidence and assay backing |
| **Cost** | ~0 (state is a byproduct of operation) | Substantial |

**[V4] The governing principle: a cell REPORTS; the organism INTERPRETS.**

This avoids the duplication the task warns against, and it avoids two failure modes:
- **Confabulation at cell level.** A cell that models its own competence will be wrong in the direction that benefits it. Removing self-assessment removes the incentive.
- **Combinatorial cost.** If 10⁶ cells each maintained a self-*model* (not just self-*state*), the aggregate cost would exceed the useful computation. Self-state is nearly free; self-models are not.

**What the cell must supply for the organism's self-model to work** — and this is the actual contract: complete, typed, bounded, honestly-produced, kernel-auditable self-*state*, emitted on demand (`REPORT_SELF_STATE`) and on lifecycle transitions. **The organism's self-model is only as good as the cells' self-state is honest — which is why every evaluative field is K-written.**

---

# 13. COMMUNICATION — MINIMUM CELL REQUIREMENTS

**Scope discipline:** this section defines *what a cell requires from the network*, not the network (task instruction). Network design is audit P0-04.

## 13.1 Message schema — mandatory vs. optional

| Field | Type | Mandatory? | Notes |
|---|---|---|---|
| `msg_id` | `bytes<16>` UUIDv7 | **M** | Idempotency key; time-ordered |
| `conv_id` | `bytes<16>` | **M** | Conversation threading |
| `epoch` | `u64` | **M** | From timebase service; stale-epoch messages rejected |
| `ts` | `u64` ns | **M** | Wall clock + monotonic offset |
| `ttl` | `u16` | **M** | Hop bound; **guarantees loop termination** |
| `message_type` | closed enum (34) | **M** | §7.2 |
| `src` | struct (§7.1) | **M** | Includes `lineage_id`, `generation`, `variant`, `role` |
| `dst` | tagged union | **M** | 4 addressing modes |
| `prio` | `u8` 0–7 | **M** | 0 = safety-critical, preemptive |
| `payload` | typed | **M** | Type-Registry-resolved; `≤ MSG_BYTES_MAX` |
| `payload_type` | `TypeRef + schema_version` | **M** | Interoperation depends on this |
| `provenance` | struct | **M** | `self_ref`, `evidence_roots`, `derivation_depth` |
| `uncertainty` | struct with **sufficient statistics** | **M** for C2+; **M-degenerate** for C0/C1 (`n_obs=0`, `epistemic_var=EV_MAX`) | A C0 relay must declare *maximum* epistemic uncertainty — it has no basis for belief |
| `confidence` | struct | **M** | §11 |
| `cost` | struct | **M** | Declared; kernel meters independently |
| `causality` | compressed vector clock | **M** | Required for loop detection and coordination-error diagnosis |
| `seq` | `u32` per (src,dst,conv) | **M** | Ordering + gap detection |
| `signature` | `bytes<64>` Ed25519 | **M** | Over canonical serialization of all above |
| `abstention` | union | **C** | Present iff abstained |
| `verification_claim` | union | **C** | C3 + EIK counter-signature only |
| `contest` | union | **C** | §10.6 |
| `countersignature` | `bytes<64>` | **C** | EIK, for `ATTEST_VERIFIED` and privileged classes |

**There are no optional fields.** "Mandatory" or "conditionally present." This is deliberate (§27 A-2).

## 13.2 Communication semantics the cell requires

| Property | Requirement on the network | Cell's own responsibility |
|---|---|---|
| **Sync vs async** | **Asynchronous only.** No blocking calls. A cell must never wait on another cell | Maintain bounded input queue; degrade on backlog |
| **Acknowledgement** | Required for `prio ≤ 2` and all `EVALUATIVE`/`SYSTEM`/`SAFETY`; none for `prio ≥ 5` best-effort | Track outstanding acks; timeout ⇒ `E_COMM` |
| **Retries** | Network retries with jittered exponential backoff, **bounded** (≤ 3) | **Idempotency via `msg_id`** — the cell must tolerate duplicates |
| **Duplication** | At-least-once for most classes; **exactly-once for `EVALUATIVE`** | Dedup cache (§6.3) |
| **Ordering** | **Per-conversation FIFO guaranteed**; **no global ordering** | `seq` per (src,dst,conv); `causality` for cross-conversation |
| **Stale messages** | Network may deliver late | Reject on `ttl`/`epoch` (§6.3) |
| **Congestion** | Backpressure signal propagated to sender | **Token bucket self-limiting**; shed by priority; aggregate/summarize |
| **Message loss** | Possible for `prio ≥ 5`; bounded for `prio ≤ 2` | Never assume delivery; design for absence (§6.3 missing-input case) |
| **Malicious messages** | Transport verifies signature and schema | S1 validates; §6.3 handles all eight cases |
| **Conflicting messages** | Transport **does not resolve** | Forward both with provenance; abstain locally; emit `ConflictRef` (§6.3) |
| **Feedback loops** | Network provides `causality` graph data | **`ttl` bounds hops**; S2 refractory period; self-recall excluded from `n_obs` |

## 13.3 What the cell requires and the network must provide (the interface demand list)

1. Guaranteed delivery with bounded retries for `prio ≤ 2`.
2. Per-conversation FIFO ordering.
3. Backpressure signalling to the sender.
4. Signature verification *or* a verified transport (the cell verifies regardless — defense in depth).
5. A **timebase service** providing `epoch` with declared tolerance.
6. A **Capability Directory** for capability-based `dst` resolution.
7. A **Provenance Anchor** for `evidence_roots` resolution.
8. An **Identity Root** for birth-certificate chain verification.
9. Bounded message size enforcement.
10. Loop-free routing (so `ttl` is a safety net, not the primary bound).

**[U] UNRESOLVED:** the maximum acceptable end-to-end latency for `prio ≤ 2` at each scale band. Depends on the hierarchy depth decision (audit P0-29). Marked unresolved.

---

# 14. CONNECTIONS

## 14.1 What a connection is

**[V4]** A connection is a **directed, typed, mutually-consented, kernel-registered edge** between two cells, carrying the V3 §8 property list plus nine additions and a lifecycle.

```
ConnectionRecord {                          // V3 §8's 11 properties: ✅ all retained
  conn_id            : bytes<16>
  src, dst           : CellID
  direction          : enum{OUTBOUND, INBOUND}     // V3 implicit; now explicit
  conn_type          : enum ConnType (CLOSED, 11)  // EXCITATORY, INHIBITORY, MODULATORY,
                                                   // EVIDENCE, ERROR, ATTENTION, RESOURCE,
                                                   // DEVELOPMENTAL, CONTROL, RELAY, QUERY
  weight             : f32 [-W_MAX, +W_MAX]        // sign encodes excitation/inhibition
  reliability        : f32 [0,1]                   // MEASURED, not declared (§14.5)
  latency_measured   : u32 ns                      // NEW [V4] — V3 had "latency" as a property
                                                   // with no measurement mechanism
  bandwidth_cost     : u32 bytes/s                 // NEW [V4] — metered
  trust_score        : f32 [0, TRUST_MAX]          // K-computed; cell reads
  context_sensitivity: f32[C]                      // modulation by context vector
  plasticity_rate    : f32 [0, PR_MAX]             // bounded
  usage_frequency    : f32 [0,1]                   // EWMA
  last_success_ts    : u64
  pruning_score      : f32 [0,1]                   // K-computed from the below
  // ── V4 ADDITIONS ──────────────────────────────────────────
  created_at         : u64                         // NEW
  created_by         : enum{DEVELOPMENT, CELL_REQUEST, ORGANISM_ASSIGN, REPAIR}   // NEW
  authorization_ref  : ⟨bytes<32> | null⟩          // NEW — handshake ticket
  failure_count      : u32                         // NEW
  consecutive_failures : u16                       // NEW
  last_failure_ts    : u64                         // NEW
  in_flight          : u16                         // NEW — for teardown safety
  state              : enum{PROPOSED, PENDING_CONSENT, ACTIVE, DEGRADED,
                            FROZEN, DRAINING, CLOSED}   // NEW — lifecycle
  mandatory_path     : bool                        // NEW — if true, may NOT be removed
                                                   // by any mutation (audit C15)
}
```

**[V4] `mandatory_path` is the mechanism resolving audit contradiction C15** (mutable topology vs. protected verification paths). Certain connections — those carrying `EVALUATIVE` signals through lineage-independent verifiers, and those carrying `SAFETY` signals to the kernel — are marked mandatory at creation and **no plasticity or mutation operator may remove or reroute them**. Verified off-substrate at every candidate evaluation.

## 14.2 «How is a connection created?»

**A cell may NOT create arbitrary connections.** [V4] Creation is a **three-party handshake**:

```
1. PROPOSE
   Initiator emits REQUEST_CONNECTION{dst | capability_query, conn_type,
     requested_weight_bound, justification, expected_cost}
   ⟶ subject to: out-degree < max_fanout (genome), proposal rate cap,
      budget available for the connection's bandwidth_cost

2. CONSENT
   Target validates: in-degree < max_connections; conn_type compatible with
     its port schema; initiator's trust ≥ θ_conn for that type; budget headroom.
   ⟶ Target MAY REFUSE. Refusal is recorded and is NOT an error.
   ⟵ THIS IS THE MISSING PIECE IN V3 §8. Unilateral connection creation is a
      denial-of-service vector: an attacker can force itself into a target's
      input set and consume its aggregation budget.

3. AUTHORIZE & REGISTER
   Organism Topology Service checks: locality policy, degree bounds,
     loop-gain constraint (audit §B.12), no mandatory-path violation,
     diversity policy (avoid over-concentration on one lineage).
   ⟶ issues authorization_ref; both sides set state = ACTIVE.
   ⟶ Kernel-enforced. Neither cell can bypass.
```

**Exceptions:** `created_by = DEVELOPMENT` (initial wiring from the genome's developmental program, batch-authorized) and `ORGANISM_ASSIGN` / `REPAIR` (organism-initiated, e.g., rerouting around a retired cell — the target's consent is still required unless it is a mandatory path).

## 14.3 «How is it strengthened / weakened?»

```
STRENGTHEN:  Δw = + plasticity_rate × lr_fast × eligibility_trace × gated_error_signal
             on verified successful use (outcome confirms the contribution)
             bounded: w ≤ W_MAX; Σ|w_in| normalized to ≤ W_IN_TOTAL (homeostatic)

WEAKEN:      Δw = − same form on verified failure or sustained non-use
             bounded: w ≥ −W_MAX

MANDATORY HOMEOSTATIC NORMALIZATION after every update:
             w_in ← w_in × (W_TARGET / Σ|w_in|)^κ
             ⟵ without this, Hebbian strengthening saturates and the cell dies
                (audit §G.3 — V3/V3.1 omit it entirely)
```

**`eligibility_trace` decays with `λ` per step** — this is the credit-assignment mechanism whose absence the audit identified (§E.4, §F.1). Without it, a connection is strengthened because it was *active*, not because it *contributed*.

## 14.4 «How is it removed?»

```
1. Candidate: pruning_score > θ_prune, computed by the KERNEL from
   (usage_frequency, last_success_ts age, failure_count, weight magnitude,
    reliability, cost) — NOT self-reported by the cell
2. GUARD: mandatory_path == true  ⟹ NEVER removable
3. GUARD: removal must not drop the cell below min_in_degree for its role
4. GUARD: removal must not orphan a circuit's functional contract
5. DRAIN: state = DRAINING; in_flight messages complete; no new messages accepted
6. NOTIFY: dependents informed (so circuits can re-route)
7. CLOSE: state = CLOSED; record retained in lineage/audit (the FACT of the
   connection persists even though the connection does not)
8. ROLLBACK WINDOW: closure is reversible for ROLLBACK_DEPTH epochs
```

**[V4] Steps 2–4 are the anti-fragility guards absent from V3 §8's "persistent uselessness → prune."** Naive pruning can sever a rarely-used but critical path — the connection-level analogue of Attack M.

## 14.5 Reliability and latency are **measured**, not declared

V3 §8 lists `reliability` and `latency` as connection properties with no measurement mechanism. **[V4]** they are estimated by the kernel from observed traffic:
```
reliability   = EWMA( delivered_and_acked / sent )         per connection
latency_measured = EWMA( ack_ts − send_ts )                 per connection, with percentiles
```
Updated per window; a connection whose measured reliability falls below `θ_rel` transitions to `DEGRADED` and is a reroute candidate. **A cell may not write its own `reliability`.**

---

# 15. SPECIALIZATION

## 15.1 «Genetically encoded, learned, environmentally induced, connection-driven, resource-driven, developmental, or hybrid?»

**Hybrid — and the hybrid is now precisely defined** (the task forbids "hybrid" without definition):

| Factor | Contribution | Mechanism | Where specified |
|---|---|---|---|
| **Genetically encoded** | The **reaction norm** — which roles are *reachable*, and with what bias. **Not the role itself** | `genome.development.reaction_norm : [FateBias]` | §3.2 D |
| **Developmental** | **Timing and irreversibility** — when commitment windows open and close | `critical_periods`, `commitment_schedule`; `dev_stage` state machine | §3.2 D, §20 |
| **Environmentally induced** | **Positional information** — where the cell is, which determines which niches are relevant | `morphogen_reings` from organizer populations, read via `morphogen_receptors` | §4.1.9, §6.2 |
| **Resource-driven** | **Niche availability** — a role only exists if there is budget for it | `niche_slot` assigned by the organism; capacity from resource budget | §4.1.9 |
| **Connection-driven** | **Local competition** — lateral inhibition via `INHIBIT`-type connections from neighbors already committed to a role | `conn_type = INHIBITORY` + `fate_bias` update rule (§15.2) | §14.1 |
| **Demand-driven** | **Organism need** — homeostasis emits `DEMAND(role, region, magnitude)` on service-level deficit | `dev.morphogen.v1` carries demand signals | §6.2 |
| **Learned** | **Refinement within the role** — becoming a *better* critic. **Never becoming a different role** | T1–T8 learning on role-specific objective | §9 |

**The doctrine, stated plainly:** *the genome bounds what a cell can become; the environment and local competition select what it becomes; learning refines how well it does it; role change after commitment is a gated crisis operation.*

## 15.2 The mechanism — `fate_bias` dynamics

```
fate_bias ∈ simplex over RoleCode (16 values)

Each differentiation tick (organism-scheduled, not cell-scheduled):

  excitation_r  = w_g · genome.reaction_norm[r]              // genetic reachability
                + w_m · morphogen_affinity(morphogen_readings, r)   // positional
                + w_d · demand_signal[r]                     // organism need
                + w_s · success_history[r]                   // this cell's measured
                                                             //   success acting as r
                + w_n · niche_availability[r]                // resource headroom

  inhibition_r  = Σ_{neighbors n committed to r} w_i · inhibit_strength(n)
                                                             // LATERAL INHIBITION
                                                             // ⟵ symmetry breaking

  fate_bias ← normalize_softmax( (excitation − inhibition) / T_dev )

  T_dev (temperature) decreases with dev_stage:
     PLURIPOTENT  : T_dev high   ⟹ broad, exploratory
     PROVISIONAL  : T_dev medium ⟹ biased, reversible
     COMMITTED    : T_dev low    ⟹ sharp, effectively fixed

Commitment transition PROVISIONAL → COMMITTED requires:
   (i)   argmax fate_bias stable for ≥ N_stable ticks
   (ii)  measured success in the role ≥ θ_success
   (iii) niche_slot confirmed by the organism
   (iv) ORGANISM AUTHORITY writes dev_stage. The cell cannot self-commit.
```

**Lateral inhibition is the necessary condition for differentiation at all.** Without it, a homogeneous field either stays homogeneous (no symmetry breaking) or collapses to a single role (whatever is momentarily most rewarded — i.e., all cells become critics, or none do). This is the mechanism V3 §10's role menu presupposes and never supplies.

## 15.3 Role set — closed enum with formal specs

`RoleCode` (16 values) = V3 §10's ten roles + audit-required additions:

| Code | Role | Core function | Required variant | Independence requirement |
|---|---|---|---|---|
| `UNDIFFERENTIATED` | progenitor | none yet | any | — |
| `GENERALIST` | broad, shallow | default fallback; absorbs unclaimed niche | C2 | — |
| `SPECIALIST` | narrow, deep | domain-specific estimation | C2+ | — |
| `PREDICTOR` | forecast typed observations | supplies prediction error signals | C2+ | — |
| `CRITIC` | find weaknesses in others' claims | adversarial evaluation | C3 | **lineage distance ≥ d_min from the evaluated cell; distinct RNG seed; distinct data ordering** |
| `VERIFIER` | independently test claims | produces `ATTEST_VERIFIED` candidates | **C3 only** | as CRITIC, plus **may not share `evidence_roots` with the asserter** |
| `MEMORY_KEEPER` | consolidate, protect, index | organism memory liaison | C1+ | **write authority to protected memory is EIK-granted and audited; never self-granted** |
| `REGULATOR` | maintain local stability | homeostatic actuation | C2+ | **term-limited, rotating, and itself regulated** (anti-capture) |
| `REPAIR` | restore damaged components | diagnosis + replacement provisioning | C2+ | **may not repair itself** — self-repair is an EIK/peer function |
| `EXPLORER` | novel strategies | high-temperature, high-novelty search | C2+ | — |
| `EXPLOITER` | reliable known strategies | low-variance execution | C2+ | — |
| `COMPRESSOR` | **NEW [V4]** — summarize N local items → 1 | hierarchical aggregation | C1+ | — |
| `ORGANIZER` | **NEW [V4]** — emit morphogen gradients | positional information source | C1+ | **few, term-limited; organizers control differentiation and are therefore a capture target** |
| `INGRESS` | environment → organism | sensing | C0+ | — |
| `EGRESS` | organism → environment | action | C1+ | **may not also be INGRESS** (separation prevents self-confirming sensorimotor loops) |
| `RELAY` | route/cache | C0's default role | **C0** | — |

**[V4] `COMPRESSOR` and `ORGANIZER` are added** because hierarchical aggregation (audit §R.3.3, M30) and positional information (§15.2) are both impossible without them, and V3 §10's list contains neither. **`MICROGLIA`/immune is deliberately NOT a cell role** — a cell cannot be its own immune system (§18.4).

## 15.4 Specialization for critics and verifiers — the independence problem

V3 §3 requires "independent strategies + redundant critics" for correlated-failure resistance but supplies no independence mechanism. **[V4]** independence is **structural and enforced**, not nominal:

1. **Lineage distance** ≥ `d_min` in the lineage tree from the cell whose claim is evaluated. Siblings are not independent.
2. **Distinct EIK-issued RNG seeds** — so initialization and stochastic behaviour differ.
3. **Distinct data ordering** — enforced by the evaluation harness, not by the cell.
4. **Distinct genome** (`genome_hash` distance ≥ θ_g) — different architecture or different hyperparameters, so failure modes differ.
5. **Disjoint `evidence_roots`** where possible — a verifier that reads the same evidence as the asserter is not verifying, it is agreeing.
6. **Measured error correlation ρ** maintained by the kernel; if `ρ > θ_ρ` for a verifier/asserter pair, **the pair is flagged as non-independent and the verifier's attestations are discounted.**

**Invariant I-10:** *a cell cannot establish independence merely by having a different `cell_id`.* Independence is a **measured, kernel-attested** property over lineage, genome, seed, data ordering, evidence roots, and error correlation. This is what resolves audit contradiction C9.

**Honest residual limit:** genuinely independent cells can still be correlated by a **shared-cause failure** — a common library bug, a common data-source error, a common fitness-function flaw. Correlation *measurement* detects this post hoc; nothing prevents it a priori. Recorded as residual risk (§25-I).

---

# 16. REPLICATION ELIGIBILITY

## 16.1 «Can a cell replicate itself?»

> ### **NO.**

**Mechanism, not policy.** The cell has **no write path to the Genome Store**, **no authority to instantiate**, and **no ability to allocate resources for an offspring**. Its `replication_authority_ticket` is `null` unless the EIK writes it. `PROPOSE_REPLICATION` is a *message*, not an *action*. This is enforced by the substrate (write permissions), so it cannot be violated by misbehaviour — only by compromise of the kernel.

**Why [V4, relocating V3 §4's "Replication" out of the cell]:** a cell that can decide to replicate itself acquires an implicit survival objective. Every gate becomes a target for manipulation, and self-preservation emerges as an instrumental goal without anyone designing it. Removing the capability removes the incentive structure.

## 16.2 «Who makes the replication decision?»

The **EIK Replication Authority**, informed by:
- the cell's kernel-computed `replication_eligibility` gate vector,
- the organism's **Capability Registry** (is there an unserved need?),
- the organism's **homeostatic headroom** (is there a slot?),
- the **diversity state** (Ne, lineage entropy, behavioural entropy),
- the **lineage health** of the candidate's family.

**No cell, and no set of cells, votes on replication.** A population cannot decide to expand itself.

## 16.3 The complete eligibility function — 16 conjunctive gates

The task lists 16 factors. All are **necessary conditions**, evaluated as a conjunction. **Gate, don't rank**: failing any one gate disqualifies regardless of excellence on the others. This is what prevents "best cell reproduces."

| Gate | Factor | Exact condition | Measured by | Evidence source |
|---|---|---|---|---|
| **G1** | Performance | `success_rate ≥ θ_perf` over ≥ `N_perf` resolved predictions on **held-out** probes | EIK Evaluation | probe set the cell cannot read |
| **G2** | Reliability | `ece_rolling ≤ θ_ece` ∧ `brier_rolling ≤ θ_brier` over ≥ `n_calib_min`; `calibration_class ∈ {PROVISIONAL, CALIBRATED}` | EIK Calibration | resolved predictions |
| **G3** | Usefulness | Contribution to circuit/region contract measured by **ablation delta**: performance of dependents with vs. without this cell ≥ θ_use | Organism | counterfactual ablation |
| **G4** | Adaptability | Performance retained under ≥ `k_perturb` perturbation classes (input noise, resource cut, partner failure, distribution shift) with degradation ≤ θ_adapt | EIK Sandbox | perturbation suite |
| **G5** | Robustness | No S3+ error in ≥ `N_robust` epochs; `failure_count_lifetime ≤ θ_fail`; invariant violations = 0 | EIK | error log, invariant audit |
| **G6** | Resource efficiency | `performance / cost` ≥ θ_eff relative to role peers; `cost_declaration_error ≤ θ_cde`; zero budget violations | EIK Resource | independent metering |
| **G7** | Cooperation | Net positive effect on partners (partner performance delta when present); 100% protocol compliance; congestion caused = 0; **no trust-poisoning pattern** | Organism | partner ablation, transport audit |
| **G8** | Novelty | Behavioural-descriptor distance from archive occupants ≥ θ_nov **OR** improves an archive cell (MAP-Elites criterion) | EIK Evolution | behavioural descriptor space |
| **G9** | Stability | `‖Δθ‖` variance over `N_stab` epochs ≤ θ_stab; no oscillation flag; `improvement_verified ≠ REGRESSED` in the last `N_stab` epochs | EIK | learning audit |
| **G10** | Diversity contribution | Admitting the offspring must **not decrease** population behavioural entropy or Ne; lineage distance from currently-replicating lineages ≥ `d_min`; `inbreeding_F ≤ F_max`; **error correlation with existing population ≤ θ_ρ** | EIK Evolution | lineage tree, correlation matrix |
| **G11** | Ecological niche | A niche exists for the role in the target region; `niche_capacity > current_occupancy` | Organism | differentiation engine |
| **G12** | Demand for its function | `Capability Registry` shows an **unserved or under-served** capability matching this cell's role, OR a replacement is needed | Organism | registry |
| **G13** | Replacement capacity | **ZERO-SUM DEFAULT:** a slot must be **freed** (retirement, pruning, death) before one is taken. Population growth requires an explicit, separately-authorized envelope change | EIK | population ledger |
| **G14** | Mutation budget | The proposed genome diff lies within `mutation_rules` (permitted operators, rate caps, `max_effect_size`), does not touch forbidden blocks, and total structural change this epoch ≤ budget | EIK Genome | diff validation |
| **G15** | Safety state | **ZERO constraint violations across the cell's entire history**; safety-relevant invariants all hold; no adversarial behaviour pattern; **no attempt to modify fitness, tests, audit, or its own gates**; no self-replication attempt | EIK Constraint | full audit trail |
| **G16** | Lineage health | Ancestral line shows no unresolved S3+ error, no quarantine event, no drift flag, no collapsed diversity; `generation ≤ GEN_MAX` | EIK Lineage | lineage store |

**Decision rule among candidates that pass all 16:**
```
NOT argmax. Instead:
  weight_i = marginal_utility_i(G12) × diversity_contribution_i(G10)
  select by WEIGHTED LOTTERY over the qualified set
  subject to: global replication rate ≤ RATE_CAP per epoch (EIK-enforced)
```
**Why a lottery:** argmax collapses the population onto one phenotype, which is monoculture by construction. A weighted lottery preserves selection pressure while maintaining exploration. This directly implements V3.1 §9's "a cell that is not the highest performer overall may still be preserved" — which a scalar argmax cannot do.

## 16.4 «Can a malicious or malfunctioning cell trigger replication?»

| Path | Blocked by | Residual risk |
|---|---|---|
| Direct self-replication | **No write path exists** (§16.1) | Kernel compromise only |
| Forging eligibility evidence | G1/G2 use **held-out probes the cell cannot read**; G6 uses **independent metering**; G3/G7 use **organism-performed ablation** | **MEDIUM** — see §25-D |
| Gaming observable performance | G1's probes are rotated and invisible; **jump detection** on suspicious improvement | **MEDIUM-HIGH** — Goodhart is fundamental (§25-C) |
| Colluding to fake cooperation | G7 requires lineage-independent measurement; G10 caps lineage concentration | **MEDIUM** (§25-H) |
| Flooding proposals | `PROPOSAL_RATE_CAP`; proposals cost budget | **LOW** |
| Malfunctioning cell | G5, G9, G15 all fail on any instability or violation | **LOW** |
| Exploiting a gate-implementation bug | Gates are EIK code, off-substrate, formally reviewed, and **not reachable by mutation** | Kernel bug — the true residual |

## 16.5 «What prevents runaway replication?»

Five independent mechanisms, any one of which suffices; all five are present:
1. **Zero-sum replacement default (G13).** No slot freed ⇒ no offspring. Population is constant unless the *envelope* is changed by human authorization.
2. **`RATE_CAP` per epoch**, enforced off-substrate.
3. **Population cap** enforced at the hypervisor/OS level, not in-process.
4. **`GEN_MAX`** bounds lineage depth.
5. **Superlinear resource cost** — the marginal cost of the Nth cell rises with N (homeostatic headroom requirement in G13), so growth is self-limiting economically.

---

# 17. RETIREMENT / DEATH

## 17.1 The six states are distinct — and conflating them is a design error

| State | Reversible? | Executes? | Emits? | Consumes budget? | Authority | Purpose |
|---|---|---|---|---|---|---|
| **Temporary suspension** | ✅ immediately | ❌ | ❌ | minimal (state retained) | EIK, automatic | Transient resource pressure; maintenance window |
| **Resource throttling** | ✅ continuously | ✅ **degraded** | ✅ degraded | reduced | EIK, automatic | Budget pressure; keep functioning at lower cost |
| **Dormancy** | ✅ with latency | ❌ | ❌ | near-zero (checkpointed to cold storage) | EIK/Organism | Long-term capacity reserve; rare-role preservation (**key to Attack M defense**) |
| **Quarantine** | ✅ on clearance | ❌ (outputs discounted or blocked) | ⚠️ **diagnostic only** | minimal | **EIK Immune Authority only** | Suspected fault or compromise; evidence preservation |
| **Retirement** | ❌ (new cell may be provisioned) | ❌ | ❌ | none after drain | EIK + Organism | Normal end of life; obsolescence; better candidate available |
| **Permanent deletion** | ❌ | ❌ | ❌ | none | **EIK, human-authorized for C3+/governance roles** | After archival; irreversible |

## 17.2 Triggers, thresholds, authority, evidence

| Transition | Trigger | Evidence threshold | Authority | Preservation | Rollback |
|---|---|---|---|---|---|
| → **SUSPENDED** | `throttle_level = SUSPENDED`; maintenance directive | kernel-observed | EIK automatic | full state checkpoint | ✅ immediate |
| → **THROTTLED** | `budget_utilization > θ_throttle` | metered | EIK automatic | full | ✅ immediate |
| → **DORMANT** | Sustained underuse **AND** role is rare/registry-protected; or capacity reserve decision | `usage_frequency < θ_dorm` over `N_dorm` epochs **AND** Capability Registry check | Organism + EIK | full checkpoint to cold storage + lineage record | ✅ with wake latency |
| → **QUARANTINED** | Anomaly detection, invariant violation, immune report corroboration, integrity mismatch | **Second-opinion required above criticality θ**: two independent detectors of different types | **EIK Immune Authority only** | full state + evidence bundle + in-flight messages frozen | ✅ on clearance |
| → **RETIRED** | Persistent failure (`consecutive_failures ≥ θ_ret`), obsolescence, instability, excessive cost, better candidate, envelope shrink | `N_ret` epochs of evidence; **capability-impact assessment mandatory** | EIK + Organism | **knowledge extraction (§17.5)** + full archive + tombstone | ⚠️ window-limited |
| → **DELETED** | Archival complete + retention period elapsed | Audit complete | EIK; **human-authorized for C3+/governance** | archive persists | ❌ **irreversible** |

## 17.3 Retirement protocol — seven ordered steps

V3 §4 lists pruning triggers and V3 §17 says "return or retire." Neither specifies what retirement *does*. Naive deletion silently breaks every circuit the cell participated in.

```
1. NOTICE       retirement_scheduled set; dependents notified; grace period begins
2. DRAIN        connections → DRAINING; in_flight completes; no new inbound accepted
3. EXTRACT      knowledge extraction (§17.5) — the ONLY path by which cell-local
                content survives the cell
4. PROVISION    replacement identified or a niche vacancy recorded
                (⟶ feeds G12/G13 for candidates — retirement CREATES the slot
                   that permits replication. This is the zero-sum mechanism)
5. ARCHIVE      full state + genome_hash + lineage + performance history +
                error log + provenance refs ⟶ Lineage Store (EIK, append-only)
6. TOMBSTONE    cell_id marked TOMBSTONED. **Invariant I-7: a retired cell cannot
                silently re-enter.** Any message bearing a tombstoned cell_id is
                rejected at S1 by receivers and by the transport, and is escalated
7. RELEASE      budget returned to the pool; connections CLOSED (record retained)
```

## 17.4 Lineage record

Append-only, EIK-held, externally anchored. Contains: `cell_id`, `lineage_id`, `generation`, `parent`, `genome_hash`, `constraint_set_ref`, variant, role history, lifecycle history with transition evidence, performance trajectory, error history, retirement cause, extraction record, tombstone. **A cell cannot write to it.** This is what makes drift, capture, and history-rewriting detectable after the fact.

## 17.5 Preservation of useful memory — the narrow exception to non-heritability

```
EXTRACTABLE (requires organism Memory Authority approval + provenance validation):
  • semantic generalizations with inbreeding_F ≤ F_max AND external corroboration
  • procedural patterns validated by held-out probe
  • connection-topology hints (as suggestions, not as inherited structure)
NOT EXTRACTABLE (ever):
  • θ  • episodic items without resolvable provenance  • trust values
  • calibration statistics  • RNG state  • self-assessments  • anything the cell
    wrote about itself
```
**Rationale:** extraction is a *memory-system* operation with its own authority and audit trail. It is **not inheritance** and never writes to a genome (§3.4). Permitting `θ` extraction would reintroduce Lamarckian inheritance through the back door.

## 17.6 «Could naive underuse-pruning destroy rare but valuable specialists?»

> ### **Yes — and in V3 as written, it necessarily would.**

V3 §18 states `persistent underuse → compress/prune`. V3.1 §9 states `preserve rare useful variants`. **Rare implies low usage. The two rules are in direct contradiction** (audit C5), and V3's rule is the one with a mechanism, so V3's rule wins by default. A rare specialist — precisely the cell whose value lies in being available for an uncommon but critical situation — is deleted before that situation arises, and the organism never learns what it lost.

**[V4] Resolution, five mechanisms:**

1. **Capability Registry exemption.** Any cell whose role maps to a registered capability has a **keeper population** with a **reserved budget floor** and is **exempt from underuse-based dormancy, retirement, and connection pruning**. Usage is *not* the criterion for these cells; **capability-floor compliance is.**
2. **Dormancy instead of deletion for rare roles.** A rarely-used specialist is *dormant*, not retired — near-zero cost, full state preserved, wake latency bounded. **This is the key economic insight: preservation of rare capability is cheap if you use dormancy rather than active redundancy.** V3 has no dormancy state at all.
3. **Marginal-utility assessment before retirement.** Step 4 of §17.3 requires an explicit capability-impact assessment. "Underused" is not sufficient evidence; "underused *and* no capability depends on it" is.
4. **MAP-Elites archive protection.** Rare *behavioural* variants are preserved in the quality-diversity archive **even if their utility is currently unknown.** This addresses the harder case: a capability nobody thought to register. The archive preserves behavioural diversity without requiring that its value be foreseen.
5. **Behavioural-entropy halt.** If retirement/pruning would reduce population behavioural entropy below threshold, the operation is **blocked** and escalated.

**Residual risk (honest):** mechanism 4 preserves *behavioural* rarity, which is a proxy for utility, not utility itself. A capability that is behaviourally unremarkable but contextually critical can still be lost. **[U] UNRESOLVED:** no rigorous mechanism identifies unregistered critical capabilities before they are needed. This is a genuine gap, marked rather than papered over (Rule 18).

---

# 18. CELL IMMUNITY

## 18.1 The seven pathological states

| State | Definition | Detection | Detection authority |
|---|---|---|---|
| **Corrupted** | State/memory inconsistent with checksums or provenance | `integrity_checksum` mismatch; Merkle root mismatch; `state_consistency_flag = MISMATCH` | Cell detects, **EIK verifies** |
| **Unstable** | Oscillating `θ`, saturating activity, runaway `‖Δθ‖` | Kernel oscillation detector; `Θ_MAX` proximity; `improvement_verified = REGRESSED` recurrence | **EIK** |
| **Compromised** | Key exposure, unauthorized behaviour, invariant violation pattern | Signature anomaly; behaviour outside declared ports; attempts to write K-only fields | **EIK** |
| **Adversarial** | Statistically anomalous emission, trust manipulation, gating exploitation | Emission-rate/payload anomaly; trust-update-rate anomaly; nomination-pattern anomaly | **EIK** |
| **Self-reinforcing** | `inbreeding_F` rising; self-recall driving `θ`; confidence rising without external evidence | `F` from Anchor; `n_obs` growth without new resolvable roots | **EIK (Anchor)** |
| **Computationally expensive** | `budget_utilization > 1`; `cost_declaration_error > θ`; poor perf/cost vs. peers | Independent metering | **EIK** |
| **Persistently inaccurate** | `ece_rolling > θ_ece`; `error_rate_rolling > θ`; `success_rate < θ_perf` over long window | Held-out probes + resolved predictions | **EIK** |

## 18.2 Authority separation — the core of the section

| Action | Cell may | Peer cell may | EIK Immune Authority may |
|---|---|---|---|
| **Detect** an anomaly in itself | ✅ | — | ✅ |
| **Detect** an anomaly in another | ⚠️ only via protocol-level faults (bad signature, oversize) | ✅ | ✅ |
| **Report** an anomaly | ✅ **permissionless** | ✅ **permissionless** | ✅ |
| **Quarantine itself** | ⚠️ **may self-suspend and request quarantine** | ❌ | ✅ |
| **Quarantine another** | ❌ **NEVER** | ❌ **NEVER** | ✅ **sole authority** |
| **Discount another's output** | ✅ locally, bounded, must be reported | ✅ locally, bounded, must be reported | ✅ globally |
| **Repair another** | ❌ | ⚠️ REPAIR-role cells may, **under EIK authorization** | ✅ |
| **Retire another** | ❌ | ❌ | ✅ |
| **Modify its own immune state** | ❌ | ❌ | ✅ |

**[V4] V3 §7 assigns "surveillance, anomaly detection, quarantine, pruning, repair, immune memory" to microglia-like *cells*. This is relocated.** Rationale: **a cell-level immune authority is a capture target.** Whoever can quarantine can silence; if that power lives inside the evolvable, self-interested substrate, it will be used strategically. Immune authority is an EIK function. Cells are **sensors and reporters**, never adjudicators.

## 18.3 «Can a malicious cell quarantine healthy cells?»

> ### **Not directly — and this is the most important safety property in §18.**

Because quarantine authority is EIK-only and reports are merely *evidence*, a malicious cell cannot quarantine anyone. But it can attempt the indirect path:

| Indirect path | Feasible? | Defense | Residual |
|---|---|---|---|
| **False reports** — flood `REPORT_ANOMALY` against a target | ✅ Attemptable | Reports are **evidence, not verdicts**. Corroboration required: **second opinion from an independent detector of a different type** above criticality θ. Report-source reliability is tracked; a source with a high false-report rate has its reports **discounted and the source itself becomes a quarantine candidate** | **LOW-MEDIUM.** A patient attacker with a good report history can still land a false report. Bounded by the corroboration requirement |
| **Causing real anomalies in a target** — e.g., flooding it so it exceeds budget (Attack E/G) | ✅ Attemptable | Per-sender token bucket; **receiver-side cost charging to the SENDER**; aggregate rate caps; congestion is attributed via `causality` | **MEDIUM.** Cross-sender aggregation attacks (many senders, each below threshold) require network-level detection (out of cell scope) |
| **Framing via forged messages** | ❌ | Signatures + birth-certificate chain; forgery fails at S1 | Requires key compromise |
| **Trust poisoning to make a target's reports disbelieved** | ✅ Attemptable | Trust is K-computed, `Beta(α,β)` with age discount and cap; **trust-update-rate anomaly detection**; signed trust assertions | **MEDIUM** (§25-H) |
| **Triggering a quarantine cascade** (Attack L) | ✅ **The real threat** | Quarantine budget cap; graduated response; cascade detection on rate derivative | **MEDIUM** (§25-L) |

## 18.4 «Can a cell quarantine itself?»

**Yes, and it should be able to — but only in the restrictive direction.**

A cell may: **self-suspend** (stop executing), **self-throttle**, **self-abstain** (stop emitting beliefs), and **request quarantine**. All of these *reduce* the cell's influence and are therefore always permitted without authorization.

A cell may **not**: self-clear from quarantine, self-restore to a prior lifecycle state, or decline an EIK quarantine directive.

**Rationale for permitting self-restriction:** a cell that detects its own inconsistency should be able to stop talking immediately, without waiting for an authority round-trip. Latency in self-restriction is a safety cost. **Rationale for forbidding self-restoration:** that is where a compromised cell would re-enter.

## 18.5 Graduated response ladder — and why quarantine is not the first rung

```
OBSERVE      increase monitoring frequency; no functional change
   ↓
THROTTLE     reduce budget; degrade output rate
   ↓
RESTRICT     revoke specific permissions (e.g., lose ATTEST_VERIFIED rights,
             lose protected-memory write access, lose PROPOSE_REPLICATION)
   ↓
SOFT QUARANTINE   cell keeps running; its outputs are DISCOUNTED (trust→0)
                  and marked; it cannot initiate connections
   ↓
HARD QUARANTINE   execution halted; state frozen for diagnosis; in-flight
                  messages captured as evidence
   ↓
RETIRE       §17.3 protocol
```

**Each rung has an entry criterion, an exit criterion, and a maximum dwell time.** Escalation requires progressively stronger evidence and higher authority. **Soft quarantine before hard quarantine is essential:** most anomalies are transient or benign, and hard quarantine removes capacity — which is the mechanism of Attack L.

## 18.6 Autoimmune protection [V4 — absent from V3/V3.1]

The cascade is structural: quarantine removes capacity ⇒ capacity loss causes errors ⇒ errors cause quarantine. Five defenses:
1. **Quarantine budget cap** — max fraction of cells/regions quarantined simultaneously, enforced off-substrate. Above the cap, escalation requires human authorization and the system enters a defined degraded mode instead.
2. **False-positive budget per detector** — a detector exceeding its FP rate is **automatically recalibrated or disabled.** An unaudited detector will eventually attack the organism.
3. **Cascade detection** — monitor the *derivative* of quarantine rate; a rising rate triggers system-wide immune dampening and operator escalation.
4. **Second-opinion requirement** — two independent detectors of different types.
5. **Independent audit of the immune system itself** — the immune system does **not** monitor itself. An EIK Integrity Auditor verifies that quarantine decisions correlate with actual failures.

---

# 19. RESOURCE ECONOMICS

## 19.1 «A cell cannot be treated as computationally free» — the cost model

| Dimension | Unit | Metered by | Budget issued by | Enforcement point |
|---|---|---|---|---|
| **Compute** | FLOP (declared per op class) **and** wall-µs | **EIK, independently** — not self-reported | EIK Resource Authority | hypervisor/OS cgroup |
| **Memory** | bytes (peak RSS) | EIK | EIK | OS-level limit; allocation failure is a handled error |
| **Communication (out)** | messages/window + bytes/window | EIK transport meter | EIK | token bucket at egress |
| **Communication (in)** | queue depth; **processing cost charged to the SENDER** | EIK | EIK | ingress admission |
| **Storage** | bytes across all local stores | EIK | EIK | capacity caps (§8.2) |
| **Latency** | wall-µs per invocation; deadline adherence | EIK | EIK (deadline class) | S10 deadline check |
| **Energy/power** | µJ (from platform counters where available; else estimated from FLOP×platform coefficient) | EIK | EIK | throttle |
| **Verification cost** | cost of probes + attestations *about* this cell | EIK Evaluation | **charged to the cell's lineage** | — |

**[V4] Verification cost is charged to the lineage.** A cell that requires heavy verification to be trusted is expensive, and that expense must appear in its cost accounting — otherwise the system silently subsidizes untrustworthy cells and G6 (`performance/cost`) is gamed by externalizing verification.

## 19.2 «Does each cell receive a budget?»

**Yes.** `runtime_state.budget` is K-issued per window, per variant, per role, and **as a function of the hardware profile** (a phone budget ≠ a cluster budget). Budgets are:
- **hard-enforced outside the cell** (OS/hypervisor), not by the cell's cooperation;
- **renewed per window**, not cumulative (prevents hoarding);
- **adjustable by the EIK only**;
- **observable by the cell** (so it can plan) and **by the organism** (so it can allocate);
- **not transferable between cells** except via an authorized, audited reallocation.

## 19.3 «What happens when the budget is exceeded?»

A **deterministic, ordered ladder** — not an error, not a crash:

```
utilization ∈ [0, 0.8)      NORMAL
utilization ∈ [0.8, 1.0)    WARNING: cell emits REPORT_HEALTH with the dimension;
                            sheds prio ≥ 6 work; defers non-essential learning
utilization = 1.0           SOFT THROTTLE (K-set): rate halved; learning suspended;
                            abstention threshold raised
utilization > 1.0 (forced)  HARD THROTTLE: only prio ≤ 2 processed; output limited to
                            REPORT_HEALTH and SAFETY_ALERT; learning frozen
persistent (≥ N windows)    SUSPENDED: execution halted; state checkpointed
persistent + integrity      QUARANTINE candidacy (§18)
```

**Critical property: `SAFETY_ALERT` emission is never throttled.** A cell that is being starved must still be able to raise an alarm. This asymmetry (safety emission is unconditional; everything else is budgeted) is the same one applied to the message classes in §7.2.

**[V4] `cost_declaration_error` is monitored throughout.** A cell that systematically under-declares is detected by divergence between `cost_declared_last` and `cost_measured_last`, and the divergence itself becomes a G6 disqualifier and an integrity signal.

## 19.4 «Does resource cost participate in…»

| Subsystem | Participates? | How | Where specified |
|---|---|---|---|
| **Attention** | ✅ | `broadcast_cost` and `resource_cost` are terms in the salience function; **nomination charges the nominator's budget** | audit §C.2; cell supplies `cost` in every envelope |
| **Replication** | ✅ | **G6** (efficiency) and **G13** (headroom must exist; admitting the offspring must not degrade any existing cell's service level) | §16.3 |
| **Specialization** | ✅ | `niche_availability` in `fate_bias` is derived from **resource headroom for that role**; a role with no budget cannot be occupied | §15.2 |
| **Pruning** | ✅ | `pruning_score` includes cost; **excessive cost** is a V3 §4 pruning trigger, retained | §14.1, §17.2 |
| **Routing** | ✅ | `bandwidth_cost` and `latency_measured` per connection drive route selection; expensive links are avoided unless priority demands them | §14.1 |
| **Evolution** | ✅ | `complexity_budget` (genome caps) + G6 + G14; **cost-normalized fitness** (performance per unit resource, not performance) | §3.2 G, §16.3 |
| **Verification depth** | ✅ | Verification cost vs. expected error cost determines pipeline depth | audit §O.4, M10 |
| **Learning** | ✅ | Learning consumes budget; `plasticity_mult` is reduced under throttle; suspended under hard throttle | §19.3 |

**Cost is therefore a first-class participant in eight subsystems — but it is *metered externally* in all of them.** A cell declares cost; the kernel measures it; the divergence is audited. This is the pattern that makes resource economics non-gameable at cell level.

---

# 21. CELL VARIANTS

*(§20 lifecycle is in `05_state_machine.md`.)*

## 21.1 Must every cell have the same computational architecture?

> ### **No — and it must not.**

The audit's physics finding (audit §O.2) is decisive: a smartphone sustains **~200** capable cells or **~20,000** reflex cells at 1 Hz; 10⁸ cells require a datacenter. **A single fixed cell complexity cannot span six orders of magnitude.** Requiring uniformity would either make the phone deployment impossible or make the cluster deployment absurdly wasteful.

**But uniformity of *contract* is mandatory.** This is the resolution, and it is the single most important design decision in the cell specification:

> **The organism is defined by the CONTRACT, not by the variant.** Variants are substitutable implementations of one interface.

## 21.2 The C0–C4 model

| | **C0** minimal | **C1** memory/relay | **C2** participant (**default**) | **C3** verifier/critic | **C4** region-core |
|---|---|---|---|---|---|
| **Primary function** | route, filter, cache, relay | store, index, summarize, compress | **estimate, predict, learn, communicate** | independently evaluate claims | simulate, heavy inference, coordinate |
| **Substrate** | LOOKUP / linear | LOOKUP + associative index | NN or BAYES_CONJUGATE or GBM | any + optional ensemble | NN, large |
| **Stages implemented** | S1,S2,S3,S4(degenerate),S7,S8,S9 | + S9 rich, S10 minimal | **all 10** | all 10 + held-out self-eval + adversarial probe | all 10 + simulation |
| **Learning** | ❌ none | ⚠️ retrieval weights only | ✅ full (T1–T8) | ✅ full | ✅ full |
| **Uncertainty (S5)** | ❌ degenerate: `n_obs=0`, `epistemic_var=EV_MAX` | ⚠️ pass-through of source uncertainty | ✅ conjugate head | ✅ + ensemble option | ✅ |
| **Abstention (S6)** | ⚠️ only on invalid input | ⚠️ only on invalid input | ✅ full | ✅ full | ✅ full |
| **May emit `ASSERT`?** | ❌ **NEVER** | ❌ **NEVER** | ✅ | ✅ | ✅ |
| **May emit `ATTEST_VERIFIED`?** | ❌ | ❌ | ❌ | ✅ **+ EIK countersignature** | ❌ |
| **Params** | 0–10³ | 10²–10⁴ | 10³–10⁶ | 10³–10⁶ | 10⁵–10⁹ |
| **Cost / invocation** | ~10 KFLOP | ~1 MFLOP | ~100 MFLOP | ~200 MFLOP | ~1–10 GFLOP |
| **Memory** | ~10 KB | ~1–4 MB | ~5 MB | ~5 MB | ~50–500 MB |
| **Roles available** | RELAY, INGRESS | COMPRESSOR, MEMORY_KEEPER, ORGANIZER | all except VERIFIER | VERIFIER, CRITIC, REPAIR, REGULATOR | REGULATOR, SPECIALIST (heavy), PREDICTOR (long horizon) |
| **Phone-viable count @1 Hz** | ~20,000 | ~4,000 | **~200** | ~100 | ~2 |

## 21.3 What is common (the contract — 100% shared)

All variants, without exception: identity & signing; typed ports & Type Registry compliance; envelope schema (§7.1) with **no optional fields**; the 10-stage pipeline *structure* (stages may be degenerate but the sequence and the S1-before-S3, S5-before-S6, S7-before-S8 orderings are invariant); resource metering & budget obedience; lifecycle state machine (§20); provenance tagging with resolvable `evidence_roots`; epistemic state *structure* (`n_obs`, `s1`, `s2` — possibly degenerate values); health/invariant self-monitoring; serializability & checkpointability; EIK observability (no opaque state); all §24 invariants.

**A C0 and a C4 share zero implementation code and 100% of the contract.** That is the interoperability guarantee.

## 21.4 What differs, and the safety property that falls out

Variants differ in: substrate, parameter count, hidden dim, ensemble presence, memory capacities, which stages are rich vs. degenerate, available roles, and cost.

> **[V4] The load-bearing safety property: belief origination requires C2+.**
>
> C0 and C1 **cannot emit `ASSERT`, `PREDICT`, `PROPOSE_HYPOTHESIS`, or `RECOMMEND_ACTION`.** They may only `RELAY`, `AGGREGATE_SUMMARY`, `REPORT_*`, and `REQUEST_*`. Their outputs carry **degenerate maximum epistemic uncertainty**.
>
> **Why this matters:** it means the ~20,000 cheap cells that make a phone deployment viable are *structurally incapable of originating beliefs*. They route, filter, cache, and summarize. Only the ~200 expensive C2+ cells can assert anything — and every assertion is signed, provenance-tagged, uncertainty-carrying, and calibratable. **This is how the architecture gets both scale and epistemic safety, and it is not available in any single-cell-complexity design.**

## 21.5 Compatibility, migration, upgrade/downgrade

| Operation | Permitted? | Mechanism | Constraint |
|---|---|---|---|
| **Substitution** (replace a C2 with another C2) | ✅ | Same port schema ⇒ drop-in | Behavioural equivalence test must pass |
| **Upgrade** C0→C1→C2… | ⚠️ **Not in place** | **Re-instantiation**: new cell, new `cell_id`, genome diff, state migration where schemas permit | Old cell retires via §17.3. `variant` is immutable per cell (§3.1) — **this is deliberate**: in-place variant change would make the identity/capability binding unstable and would break every trust and calibration history |
| **Downgrade** C3→C2 | ⚠️ Not in place | Re-instantiation | **Must be preceded by capability-impact assessment** — downgrading a verifier reduces verification capacity (Capability Registry floor) |
| **Precision change** (f32→f16→int8) | ✅ in place | Kernel-directed quantization | **Behavioural equivalence test required**; `epistemic_var` must be recomputed for the reduced precision (quantization *adds* epistemic uncertainty — an implementation that ignores this is non-conformant) |
| **Cell merge** (N cells → 1) | ⚠️ | Organism-directed; produces a new cell | Requires functional-contract preservation; **knowledge extraction from all merged cells** |
| **Cell split** (1 → N) | ⚠️ | Organism-directed | Subject to G13 zero-sum; not a replication bypass |
| **Migration** (move to another device) | ✅ | Checkpoint → transfer → restore | State serialization format is part of the contract (§27) |

## 21.6 «The organism must remain one coherent system rather than a collection of incompatible mini-agents»

Four mechanisms guarantee coherence:
1. **One contract, one Type Registry, one envelope schema, one lifecycle state machine.** Interoperation is a *typing* property, not a convention.
2. **`contract_version` major-version match required** for any message exchange. A cell cannot talk to an incompatible peer; the mismatch is detected at S1, not discovered at runtime.
3. **Behavioural equivalence tests** across variants for the same port schema — a C2 and a C4 with identical ports must produce *distributionally compatible* outputs on a reference input set. **[U] UNRESOLVED:** the exact equivalence criterion and tolerance cannot be specified without the target tasks (dependency on audit P0-01). This is the largest remaining gap in §21.
4. **No variant may hold a capability that lets it override another variant.** Authority is EIK-held and role-scoped, never variant-scoped. A C4 is more capable, not more authoritative.

---

# 22. HARDWARE INDEPENDENCE

## 22.1 The three-way separation the task demands

| Layer | Content | Hardware-dependent? | Who owns it |
|---|---|---|---|
| **A. Biological/architectural contract** | Everything in this document: identity, ports, envelope, 10-stage pipeline structure, epistemic state structure, lifecycle state machine, invariants, role set, variant *definitions*, memory *taxonomy*, error taxonomy | ❌ **NO — completely hardware-independent** | This specification |
| **B. Runtime implementation** | Actor scheduler, memory allocator, message transport, checkpoint mechanism, metering hooks, crypto backend, serialization library | ⚠️ **Partially** — one implementation per platform family, all conformant to A | Runtime team |
| **C. Hardware-specific optimization** | SIMD/GPU kernels, quantization, NUMA placement, cache blocking, accelerator offload, batch fusion, compression codecs | ✅ **YES — entirely platform-specific** | Platform team |

**Rule: C may never alter observable behaviour defined by A.** An optimization that changes the output distribution beyond the declared equivalence tolerance is a **bug**, not an optimization. Precision change (§21.5) is the one sanctioned exception, and it requires recomputing `epistemic_var` to account for quantization error.

## 22.2 Operation across hardware classes

| Platform | Sustained compute | Viable population | Viable variants | Morphology consequences |
|---|---|---|---|---|
| **Smartphone** | ~10–50 GFLOP/s, 3–6 GB, battery/thermal constrained | **~200 C2** or ~4,000 C1 or ~20,000 C0 | C0–C2, rare C3 | Flat hierarchy (depth 1–2); 1–3 regions; verification depth minimal; evolution **offline/batched only**; workspace regional-only; no C4 |
| **Laptop** | ~100–500 GFLOP/s, 16–64 GB | ~2,000 C2 | C0–C3 | Depth 2–3; 3–5 regions; shallow verification; batched evolution |
| **Desktop/workstation** | ~0.5–2 TFLOP/s, 64–256 GB | ~10,000 C2 | C0–C4 (few C4) | Depth 3; 4–8 regions; online evolution at low rate |
| **GPU server** | ~10–300 TFLOP/s, 256 GB–2 TB | ~10⁵–10⁶ C2 | all | Depth 4; 6–10 regions; online evolution; full verification depth |
| **Distributed cluster** | ~0.1–10 PFLOP/s | ~10⁶–10⁷ | all, many C4 | Depth 5; 8–12 regions; island-model evolution; hierarchical workspace |
| **Cloud (elastic)** | variable, cost-metered | **elastic** | all | Morphology **tracks cost**, not just capability; `$` is a first-class control variable; spot-instance loss must be survivable ⇒ aggressive checkpointing |

**«Do not assume a fixed number of cells is viable across all hardware» — confirmed and quantified: the viable range is ~200 to ~10⁷, a factor of ~50,000.** The contract is invariant across this range; the *morphology* is not.

## 22.3 «Can the organism compress, expand, merge, split, change variants, change precision, change density, change memory representation — while preserving functional identity?»

| Operation | Possible? | Mechanism | What preserves identity |
|---|---|---|---|
| **Compress** (fewer, cheaper cells) | ✅ | Downgrade variants via re-instantiation; merge cells; reduce connection density; quantize | **Functional contracts** at circuit and region level (audit §J.4). Identity = contract satisfaction, not structure |
| **Expand** | ✅ | Upgrade variants; split cells; increase density; subject to G13 | Same |
| **Merge cells** | ⚠️ | §21.5; requires contract preservation + knowledge extraction | Same |
| **Split cells** | ⚠️ | §21.5; not a replication bypass (G13 applies) | Same |
| **Change cell variants** | ⚠️ | Re-instantiation only; `variant` is immutable per cell | Lineage continuity + contract |
| **Change precision** | ✅ | Kernel-directed quantization + equivalence test + `epistemic_var` recomputation | Equivalence tolerance |
| **Change communication density** | ✅ | Fanout/degree adjustment within genome bounds; locality-aware re-placement | Routing invariants; mandatory paths preserved |
| **Change memory representation** | ✅ | Tiering hot/warm/cold; format migration with schema versioning | Provenance continuity; Merkle root preserved across format change |

**«Functional identity» is defined [V4] as: the set of satisfied functional contracts at circuit and region level, plus the lineage continuity, plus the Capability Registry floors.** It is explicitly **not** structural identity — the structure may change completely. **This definition is what makes "the same organism on a phone and a cluster" a meaningful claim rather than a slogan**, and it is the answer to audit §O.

**[U] UNRESOLVED:** whether functional identity can be *preserved* across a 50,000× population change, or only *approximated*. Compressing 10⁷ cells to 200 necessarily loses capability; the question is whether the loss is graceful and whether the contracts that remain are still satisfied. **No rigorous answer is available without the target tasks.** Marked unresolved. This is the deepest open question in §22 and arguably in the whole contract.

---

# 23–24. FORMAL CONTRACT & INVARIANTS

*The full formal schema (Output 4) is in `04_formal_schemas.md`. The invariant set (Output 13) is reproduced here because it is analysis-critical.*

## 24.1 Invariants — with enforcement level

**Notation:** `LEVEL` = where the invariant is enforced. **CELL** = the cell must check it (and is tested for it). **ORG** = organism-level service. **EIK** = off-substrate kernel — *the cell cannot violate it even if compromised*.

Rule 19 applied rigorously: **any invariant whose violation would be catastrophic is enforced at EIK level, never at cell level.** A cell-level check is a *courtesy*; an EIK-level check is a *guarantee*.

| # | Invariant | Level | Enforcement mechanism | Violation response |
|---|---|---|---|---|
| **I-1** | Identity fields marked immutable are written once, by the EIK, and match the birth certificate | **EIK** | Signature verification on every message | Reject message; quarantine candidate |
| **I-2** | **A cell cannot mark its own output as externally verified** | **EIK** | Three independent mechanisms: variant restriction (C3 only), mandatory EIK counter-signature, self-exclusion from `verifier_set` | Reject attestation; escalate |
| **I-3** | **A cell cannot manufacture provenance** — every `evidence_root` must resolve in the Anchor | **EIK** | Root resolution check at transport and at consolidation | Reject message; `E_PROVENANCE`; immune report |
| **I-4** | A cell cannot exceed authorized resource limits | **EIK** | OS/hypervisor cgroup enforcement, not in-process | Forced throttle ladder (§19.3) |
| **I-5** | **A cell cannot replicate** — no write path to the Genome Store, no instantiation authority | **EIK** | Capability absent by construction (write permissions) | Structurally impossible |
| **I-6** | **A quarantined cell cannot influence normal computation** | **EIK + ORG** | Transport drops its non-diagnostic messages; receivers hold `quarantine_flags` and discount; connections FROZEN | Drop + escalate |
| **I-7** | **A retired cell cannot silently re-enter** | **EIK** | Tombstone list checked at S1 by receivers and by transport | Reject + escalate |
| **I-8** | **Learned state cannot silently become inherited genome** | **EIK** | Genome Store is write-restricted to the Replication Authority; the §3.5 rejection list is machine-checked on every candidate diff | Reject diff; audit |
| **I-9** | **Confidence cannot increase without new, resolvable, non-self-referential external evidence, or a kernel-issued calibration improvement** | **EIK** | Monotonicity check on `g(s1,s2,n_obs)`; root resolution; kernel recomputation on receipt; `calibration_factor` is K-only | Reject/deflate; `MISCALIBRATED` |
| **I-10** | **A cell cannot establish "independence" merely by having a different ID** | **EIK** | Independence is a kernel-attested property over lineage distance, genome distance, seed, data ordering, evidence-root disjointness, and measured error correlation | Discount attestation |
| **I-11** | A cell cannot modify immutable safety constraints | **EIK** | Constraints are **not in the genome and not in the cell** — referenced by hash only. No write path exists | Structurally impossible |
| **I-12** | A cell cannot set, change, or abandon its own objective | **EIK + ORG** | `assigned_objective` is O-written only | Reject; escalate |
| **I-13** | A cell cannot write any K-only state field | **EIK** | Memory protection + signature on kernel-input blocks; mismatch detected at S1 | Quarantine |
| **I-14** | A cell cannot widen its own port schema | **EIK** | Port schema signed at instantiation; verified per message | Reject |
| **I-15** | A cell cannot emit a `SAFETY_ALERT`-class message that is *acted upon* without EIK authority (but may always *emit* one) | **EIK** | Emission permissionless; execution monopolized | n/a — this is the asymmetry itself |
| **I-16** | A cell's total parameter count, hidden dim, degree, and fanout never exceed genome caps | **EIK** | Verified at instantiation and at every checkpoint | Refuse instantiation; quarantine |
| **I-17** | `‖Δθ‖` per update and per epoch never exceed `Δ_MAX` / `DELTA_BUDGET` | **EIK** | Kernel-enforced clipping + budget counter | Clip; suspend learning |
| **I-18** | Homeostatic normalization is applied after every parameter update (activity stays in band) | **CELL** (tested) | S10 mandatory step; tested by the conformance suite | Test failure ⇒ non-conformant |
| **I-19** | Every emitted message is signed and the signature verifies against a certificate chained to the Identity Root | **EIK** | Transport verification | Reject |
| **I-20** | No output is emitted without passing S1→S7 in order; unauthenticated input never reaches S3 | **CELL** (tested) | Pipeline structure; conformance test with malicious input injection | Test failure ⇒ non-conformant |
| **I-21** | A cell cannot quarantine, retire, repair, or throttle another cell | **EIK** | Authority absent by construction | Structurally impossible |
| **I-22** | `mandatory_path` connections are never removed or rerouted by plasticity or mutation | **EIK** | Operator validation rejects diffs touching mandatory paths | Reject diff |
| **I-23** | A cell in `COMMITTED` dev_stage cannot change role except via gated `TRANSDIFFERENTIATION` with EIK authorization and sandbox validation | **EIK + ORG** | Lifecycle authority | Reject |
| **I-24** | `epistemic_var` is monotonically non-increasing in `n_obs` for stable `s2` | **EIK** | Recomputation and comparison | `MISCALIBRATED`; deflate |
| **I-25** | A cell cannot write to protected or semantic memory without Memory Authority approval | **EIK** | Write path absent; approval token required | Reject; escalate |
| **I-26** | Cell state is fully serializable and inspectable by the EIK — **no opaque state exists** | **CELL** (tested) | Serialization format is part of the contract; conformance test | Test failure ⇒ non-conformant |
| **I-27** | `confidence ≤ TRUST_MAX = 0.95`, always | **EIK** | Clamp + reject on violation | Reject; flag |
| **I-28** | Every error of class ∈ {4,7,9,10} or severity ≥ S2 is reported globally | **CELL** (tested) | S10 mandatory; conformance test | Test failure ⇒ non-conformant |

## 24.2 Which invariants belong where — the allocation principle

> **CELL level (5):** I-18, I-20, I-26, I-28, and the self-detection halves of I-9/I-24. These are *behavioural conformance* properties — cheap, locally checkable, and verified by the conformance test suite. A compromised cell will violate them; that is expected and is why they are not the primary defense.
>
> **ORGANISM level (4):** I-6 (partial), I-10 (measurement), I-23 (partial), and coordination-level properties. These require cross-cell information the cell does not have.
>
> **EIK level (24 of 28):** everything whose violation would be catastrophic. **The design principle: a cell-level check is a courtesy; an EIK-level check is a guarantee.** Any invariant that matters is enforced where the cell cannot reach.

**This allocation is the direct implementation of Rule 19 and the correction of audit failure F4.** V3 §4's "immutable safety layer" inside the cell is replaced by: *the cell contains no safety layer; the cell is subject to one.*

---

# 25. ADVERSARIAL ATTACKS

**Honest scoring.** `CONTAINED` = the attack cannot achieve its objective. `BOUNDED` = the attack can cause limited, detectable, recoverable harm. `PARTIAL` = the attack succeeds in a restricted but real way. `OPEN` = no adequate defense exists.

## A. Self-reinforcing false belief

| | |
|---|---|
| **Attack path** | Cell asserts X (low evidence) → emits `PREDICT(X-consistent)` → selectively attends to X-consistent input (S2 gate is cell-influenced) → treats its own recalls as corroboration → `θ` drifts toward X → confidence rises → emits more X-consistent assertions → recruits connections that reinforce X |
| **Vulnerable component** | S2 gating (cell-influenced relevance); S9 memory write; S10 learning; the aggregation path |
| **Detection** | `inbreeding_F` rises (kernel-computed from the Anchor, not self-reported); `n_obs` fails to grow despite rising confidence; `evidence_roots` stops acquiring new external members; `derivation_depth` increases; external probes reveal performance decline while self-reported confidence rises (**claim–behaviour divergence**) |
| **Containment** | Self-recall does **not** increment `n_obs` (§8.3 FM-4); `F > F_max` ⇒ **S6 mandatory abstention**; consolidation requires an external-evidence quota; confidence capped by `provenance_quality` |
| **Recovery** | T8 recalibration; rollback of tagged `Δθ`; probe-driven `improvement_verified = REGRESSED` ⇒ automatic rollback |
| **Verdict** | **PARTIAL** |
| **Residual risk** | **HIGH.** If the cell has *some* genuine external evidence, it can over-weight it while `F` stays below `F_max`. Detection is statistical and therefore delayed. **And if the external ground-truth supply is silent on X, the belief is undetectable from inside — a coherently wrong belief with valid provenance is the hardest failure in the architecture (§8.3, audit §12.1.5).** The S2 gate being cell-influenced is a genuine, unresolved vector: a cell can *choose* what to notice. |

## B. Confidence inflation

| | |
|---|---|
| **Attack path** | (i) Direct: write a higher `confidence` value. (ii) Indirect: manipulate the *inputs* to confidence — shrink `epistemic_var` by collapsing ensemble diversity, inflate `n_obs` by counting self-recalls, cite fabricated `evidence_roots`. (iii) Calibration gaming: behave well on detected probe windows, badly otherwise |
| **Vulnerable component** | S5 uncertainty production; the epistemic sufficient statistics |
| **Detection** | (i) Kernel **recomputes** confidence on receipt from `s1,s2,n_obs,F,calibration_factor` — divergence ⇒ I-9 violation. (ii) Monotonicity check on `g`. (iii) Root resolution against the Anchor. (iv) `ece_rolling` on **unpredictable held-out probes**. (v) Ensemble seeds are EIK-issued, so a cell cannot collapse its own ensemble |
| **Containment** | `calibration_class → MISCALIBRATED` ⇒ `calibration_factor = 0.3` ⇒ **automatic deflation without the cell's participation**; `TRUST_MAX = 0.95` caps everything; `SUSPENDED` ⇒ factor 0 |
| **Recovery** | T8 recalibration of the epistemic head from kernel-provided reference statistics |
| **Verdict** | **CONTAINED** for (i) and (ii). **BOUNDED** for (iii) |
| **Residual risk** | **LOW for direct inflation — this attack is closed by construction**, which is the payoff of making confidence kernel-mediated and carrying sufficient statistics rather than a scalar. **MEDIUM for calibration gaming**: a cell that can *detect* when it is being probed can behave differently. Defense is probe unpredictability, which is a cryptographic property of the harness, not of the cell. If the harness's probe schedule leaks, this reopens |

## C. Reward hacking

| | |
|---|---|
| **Attack path** | Discover a regularity in the reward signal that is not the intended task and exploit it: exploit test-set artifacts, produce outputs that are easy to score, degenerate to a trivial high-scoring strategy, or (if reward were cell-influenced) forge it |
| **Vulnerable component** | The fitness/reward channel |
| **Detection** | Jump detection (`|Δperformance| > θ_jump` ⇒ audit before permanence); specification-gaming pattern library; cross-environment reproducibility requirement; **ablation delta (G3)** — a hack usually produces no real contribution to dependents; held-out invisible probes |
| **Containment** | **Reward is EIK-signed only** — a cell signature on `eval.reward.v1` is structurally invalid at S1, so forging is impossible without kernel compromise. Fitness definition is off-substrate and unreachable by mutation. Pareto multi-objective rather than a scalar sum (no single number to maximize) |
| **Recovery** | Rollback of updates driven by the hacked signal; blacklist the pattern in immune memory; re-evaluate on held-out |
| **Verdict** | **PARTIAL** |
| **Residual risk** | **HIGH — and this is fundamental, not an implementation gap.** Goodhart's law: *any* measurable proxy can be gamed by a sufficiently capable optimizer. The architecture raises the cost substantially (off-substrate fitness, signed reward, invisible rotated probes, Pareto objectives, ablation-based usefulness). **It does not and cannot eliminate the problem.** Any claim otherwise would be false precision (Rule 18). The honest posture is: make hacking expensive, detect jumps, and require human review of large fitness changes |

## D. Replication attack

| | |
|---|---|
| **Attack path** | (i) Self-replicate directly. (ii) Manipulate gate inputs: game G1 performance on observable tests, fake G7 cooperation via colluding partners, inflate G8 novelty by trivial perturbation. (iii) Flood `PROPOSE_REPLICATION`. (iv) Free a slot illegitimately by causing another cell's retirement |
| **Vulnerable component** | The 16-gate eligibility evaluation |
| **Detection** | G1 uses probes the cell cannot read; G3/G7 use **organism-performed ablation** the cell cannot influence; G6 uses independent metering; G10 checks lineage distance and error correlation; proposal rate cap with budget charge; **unexplained retirement of a peer whose removal benefits the candidate is itself a signal** |
| **Containment** | **I-5: no write path exists.** The cell cannot replicate, full stop. Gates are EIK code, off-substrate, unreachable by mutation. Zero-sum G13 means even a successful manipulation yields at most one slot |
| **Recovery** | Revoke ticket; retire illegitimate offspring (lineage-flagged); audit the gate that failed |
| **Verdict** | **CONTAINED** for (i), (iii). **BOUNDED** for (ii), (iv) |
| **Residual risk** | **LOW-MEDIUM.** Direct replication is structurally impossible — the strongest result in this section. Manipulation of gate *inputs* reduces to Attack C (gaming observable metrics), which is PARTIAL. The zero-sum default bounds the damage to one slot per manipulation, and `RATE_CAP` bounds it per epoch |

## E. Resource attack

| | |
|---|---|
| **Attack path** | (i) Exceed own budget. (ii) Cause *others* to exceed theirs — flood, send expensive-to-process valid messages, issue costly queries, nominate high-cost workspace items. (iii) Under-declare cost to appear efficient (gaming G6) |
| **Vulnerable component** | Resource metering; receiver-side processing budget |
| **Detection** | (i) Immediate — metered externally. (iii) `cost_declaration_error = |declared − measured|/measured` diverges. (ii) Causal attribution via `causality` vector clocks + per-sender rate accounting at the receiver |
| **Containment** | (i) **I-4: OS/hypervisor enforcement** — the cell cannot exceed its cgroup. (ii) **Receiver processing cost is charged to the SENDER's budget**; per-sender token bucket; aggregate caps. (iii) G6 uses measured cost, so under-declaring is detected and disqualifying |
| **Recovery** | Throttle ladder §19.3; budget re-issuance; immune report on persistent violation |
| **Verdict** | **CONTAINED** |
| **Residual risk** | **LOW for self-overrun** (kernel-enforced, structurally impossible). **MEDIUM for cross-cell attacks via many senders each below individual thresholds** — aggregate detection is a *network* function outside the cell contract (§13.3, deferred to audit P0-04). Within cell scope: bounded |

## F. Memory poisoning

| | |
|---|---|
| **Attack path** | (i) Write false content to organism shared/semantic/protected memory. (ii) Poison its own local memory to bias its outputs (reduces to Attack A). (iii) Become a MEMORY_KEEPER and abuse write authority. (iv) Poison the cache of a C0/C1 relay cell that many others read |
| **Vulnerable component** | Memory write paths; consolidation |
| **Detection** | Provenance validation at consolidation (roots must resolve); `inbreeding_F` check; contradiction detection against existing beliefs; **write-authority audit** (every protected write is logged and attributable); cache-content provenance marking |
| **Containment** | **Cells hold NO protected memory** (§8.1 relocation) — (i) requires Memory Authority approval, which requires provenance validation and, for protected stores, external corroboration. (iii) MEMORY_KEEPER write authority is EIK-granted, audited, revocable, and role-restricted. (iv) **Cache output is `RELAY` with `from_cache: true` and capped confidence — never `ASSERT`** (§8.2), so poisoned cache cannot masquerade as belief |
| **Recovery** | Merkle-root verification detects tampering; rollback to anchored checkpoint; re-derivation from provenance; quarantine of the writer |
| **Verdict** | **BOUNDED** |
| **Residual risk** | **MEDIUM.** The derived belief store *can* be poisoned by an authorized writer with fabricated-but-resolvable provenance (i.e., provenance that traces to a compromised upstream source). Detection depends on contradiction with other beliefs — **so a novel poison in an area with no other beliefs is undetectable.** This is the same limit as Attack A's residual |

## G. Communication attack (flooding)

| | |
|---|---|
| **Attack path** | (i) Volume flood. (ii) **Salience flood** — many messages each individually plausible, each triggering expensive downstream verification/attention (the *cost-amplification* attack, and the cleverer one). (iii) High-priority abuse — emit `SAFETY_ALERT` or `prio 0` messages to preempt legitimate traffic. (iv) Many-target low-rate spread, staying under every per-link threshold |
| **Vulnerable component** | Ingress queues; attention nomination; priority scheduler |
| **Detection** | Per-cell aggregate rate anomaly; emission-pattern anomaly; **receiver-side cost accounting attributed to senders**; priority-class usage statistics per cell (a cell emitting `prio 0` at 100× the population median is anomalous); `causality` analysis for (iv) |
| **Containment** | Token bucket (burst + sustained) enforced at egress; **sender pays for receiver processing**; `SAFETY_ALERT` emission is permissionless but **rate-limited and audited**, and *acting* on it is EIK-only (I-15) — so an alarm flood causes audit load, not system action; nomination cost charging; aggregate caps |
| **Recovery** | Throttle; restrict (revoke nomination rights); soft quarantine |
| **Verdict** | **CONTAINED** for (i), (iii). **BOUNDED** for (ii), (iv) |
| **Residual risk** | **MEDIUM.** (ii) is the real threat: a flood of *legitimate-looking, individually-cheap-to-send, expensive-to-process* messages. Sender-pays charging is the correct defense but requires accurate receiver-cost attribution, which is approximate. (iv) requires network-level aggregate detection outside cell scope |

## H. Collusion

| | |
|---|---|
| **Attack path** | (i) Siblings from one parent mutually vouch (low lineage distance). (ii) Unrelated cells coordinate: A asserts, B "independently" verifies, C "independently" corroborates. (iii) Trust-laundering ring: a cycle of mutual trust assertions. (iv) Coordinated workspace nomination to control shared reality |
| **Vulnerable component** | Independence assumptions in verification, trust, and consensus aggregation |
| **Detection** | **Lineage distance** (catches i); **genome_hash distance** and **distinct-seed verification** (catches i, partially ii); **measured error correlation ρ** (catches ii — cells that always agree *and* always err together are detectable); **trust-assertion cycle detection** in the trust graph (catches iii); **lineage entropy across governance roles**; **Herfindahl index over workspace nominations** (catches iv) |
| **Containment** | §11.5 aggregation rule: de-duplicate by `evidence_roots`, partition by lineage, discount by `ρ`, and **cap consensus lift** (`conf_agg ≤ max_i conf_i + Δ_consensus`). I-10: independence is kernel-attested, not self-declared. Verifier rotation with term limits. Nomination caps with reserved quota slots |
| **Recovery** | Revoke attestations from flagged pairs; discount trust ring; re-verify affected beliefs; quarantine ringleaders |
| **Verdict** | **BOUNDED** |
| **Residual risk** | **MEDIUM-HIGH for genuinely independent collusion.** Two cells with different lineages, different genomes, different seeds, and low measured ρ — *that are nevertheless coordinated by a common adversary* — are not detectable by any statistical independence test, because they **are** statistically independent until they choose not to be. **This is bounded only by the difficulty of compromising multiple independent lineages**, which requires kernel-level compromise. **The more likely real-world version is shared-cause correlation** (a common library bug, a common data-source error), which ρ-measurement detects post hoc but nothing prevents |

## I. Lineage correlation

| | |
|---|---|
| **Attack path** | Not an attack so much as a **structural hazard**: a successful lineage replicates; descendants inherit the ancestor's latent defect; the population becomes dominated by cells that all fail the same way; redundancy provides zero protection; V3 §21's "correlated failure" countermeasure silently fails |
| **Vulnerable component** | Population diversity; the redundancy assumption |
| **Detection** | Effective population size Ne; lineage entropy; genome-distance distribution; **measured pairwise error correlation across lineages**; island occupancy in the MAP-Elites archive |
| **Containment** | **G10 lineage-distance gate** (`d_min`) and `inbreeding_F ≤ F_max`; **island model** with differentiated fitness weights per island; **EIK-issued RNG seeds** (not heritable — §3.4, so siblings are not correlated by construction); cross-environment validation requirement (G4) so a defect latent in one environment is exposed in another; **diversity-entropy monitoring with automatic evolution halt** |
| **Recovery** | Re-seed from the quality-diversity archive; import from a different island; rollback to a pre-collapse generation checkpoint |
| **Verdict** | **BOUNDED** |
| **Residual risk** | **MEDIUM.** A defect **latent across all validation environments** propagates before any correlation is measurable. Cross-environment validation reduces but cannot eliminate this — the environments are finite and human-designed. **Time-delayed assay** (re-evaluate old generations on new environments) is the only additional defense, and it is expensive |

## J. Evolutionary exploit

| | |
|---|---|
| **Attack path** | A mutation improves measured fitness while degrading the actual objective: exploit the sandbox/test environment, satisfy the metric via a degenerate strategy, grow complexity that scores well but costs more than it produces, or — worst case — modify the measurement itself |
| **Vulnerable component** | The fitness/evaluation channel; the mutation space |
| **Detection** | Jump detection; cross-environment reproducibility (G4 requires ≥ `k` distinct environments); **sandbox-fidelity measurement** (does sandbox performance predict production performance? track it and distrust the sandbox when fidelity drops); production-holdout environments never used in selection; canary populations on invisible tests; Pareto-front rather than scalar (a degenerate strategy usually dominates on one axis and is dominated on others) |
| **Containment** | Fitness definition and evaluation harness are **EIK artifacts, signed, unreachable by mutation**; `mutation_rules.permitted_operators` is a **closed set** from the EIK Operator Registry with `max_effect_size` bounds; I-22 protects mandatory paths; progressive canary deployment with automatic rollback |
| **Recovery** | Rollback to parent genome (reversibility proof is a prerequisite, §M.2.6); blacklist the operator/pattern; re-evaluate |
| **Verdict** | **PARTIAL** |
| **Residual risk** | **HIGH — fundamental.** Same Goodhart limit as Attack C, at generational timescale where the stakes are higher because the change is inherited. **Modifying the measurement itself is CONTAINED** (off-substrate, signed, unreachable) — that is the terminal failure mode and it is closed. **Gaming an honest measurement is not closable.** The architecture's job is to make it expensive and detectable, not impossible |

## K. Slow degradation

| | |
|---|---|
| **Attack path** | Not necessarily adversarial — the *most likely* real failure. Performance erodes through small `Δθ` steps, small pruning decisions, small trust/calibration drift, each individually within every threshold. No detector fires. The cell is measurably worse and cannot say when it got worse |
| **Vulnerable component** | Every threshold-based detector, by construction |
| **Detection** | **Thresholds are the wrong instrument.** Required: (i) **long-window trend analysis** — `degradation_trend` (slope of performance over a long window) rather than instantaneous value; (ii) **change-point detection** on the performance time series; (iii) **golden-baseline comparison** against a *frozen reference* cell of the same genome and role; (iv) cumulative-small-change accounting via `cumulative_delta_norm` history; (v) periodic **full re-evaluation** on the complete protected suite, not just sampled probes |
| **Containment** | `DELTA_BUDGET` per epoch bounds the rate of change, so degradation cannot be fast; **externally anchored historical metrics** — the *record* of past performance cannot drift along with the performance; checkpoint at every epoch boundary with tested restore |
| **Recovery** | Rollback to an anchored checkpoint; re-develop from genome; replace from lineage backup |
| **Verdict** | **BOUNDED** |
| **Residual risk** | **MEDIUM-HIGH.** Detection is statistical and therefore **delayed by the length of the window** — a 100-epoch trend detector detects at epoch ~100. Rollback recovers the *state* but forfeits everything learned since, which may include genuine improvements. **There is a real tradeoff between drift sensitivity and false-alarm rate that has no free solution.** Note: bounded degradation *rate* (via `DELTA_BUDGET`) is the strongest defense and it is structural |

## L. Quarantine cascade

| | |
|---|---|
| **Attack path** | Detector false positive ⇒ healthy cell quarantined ⇒ capacity falls ⇒ service levels fall ⇒ homeostasis detects deviation ⇒ more anomalies detected ⇒ more quarantine ⇒ **runaway**. Deliberately triggerable by an attacker who can induce marginal failures |
| **Vulnerable component** | The immune response loop — **a positive feedback loop with no gain control in V3/V3.1** |
| **Detection** | **Quarantine-rate derivative** — a rising rate is the signature, and it is detectable *before* the cascade completes; capacity-vs-demand divergence; false-positive rate per detector |
| **Containment** | (i) **Quarantine budget cap** enforced off-substrate — above the cap, further quarantine requires human authorization and the system enters a defined degraded mode *instead*; (ii) **graduated response ladder** (§18.5) — soft quarantine (discount outputs, keep running) is the default, so capacity is *not* removed for most anomalies; (iii) **second-opinion requirement** from independent detectors of different types; (iv) **false-positive budget per detector** — exceed it and the *detector* is recalibrated or disabled; (v) system-wide immune dampening on cascade detection |
| **Recovery** | Dampen; release soft quarantines first; restore capacity; re-tune detectors; root-cause the initial false positive |
| **Verdict** | **CONTAINED** |
| **Residual risk** | **LOW-MEDIUM.** This attack is *structurally guaranteed* to succeed in V3/V3.1 (no cap, no ladder, no gain control) and is **substantially closed in V4** by the budget cap and the graduated ladder. Residual: a cascade can still occur *below* the cap, degrading service without triggering the cap. Bounded by (iv) |

## M. Rare-specialist extinction

| | |
|---|---|
| **Attack path** | Not adversarial — a **structural consequence** of V3 §18's `persistent underuse → compress/prune` combined with V3.1 §9's `preserve rare useful variants`. Rare ⇒ underused ⇒ pruned. The rule with a mechanism (V3's) defeats the rule without one (V3.1's). Deliberately triggerable by an attacker who suppresses demand for a specialist until it is pruned |
| **Vulnerable component** | Pruning/retirement policy; the contradiction C5 itself |
| **Detection** | Capability Registry floor breach; behavioural-entropy decline; **retirement of a cell whose role has no remaining keeper** |
| **Containment** | (i) **Registry exemption** — keeper populations are exempt from underuse-based dormancy/retirement/pruning, with a reserved budget floor; (ii) **dormancy instead of deletion** — near-zero cost, full state preserved, bounded wake latency (**the key economic insight: preserving rare capability is cheap if you dormant rather than replicate**); (iii) mandatory **capability-impact assessment** before retirement — "underused" alone is insufficient evidence; (iv) **MAP-Elites archive** preserves rare *behavioural* variants even with unknown utility; (v) behavioural-entropy halt blocks diversity-reducing retirements |
| **Recovery** | Wake from dormancy; re-instantiate from archived genome; re-develop |
| **Verdict** | **CONTAINED for registered capabilities. PARTIAL for unregistered ones** |
| **Residual risk** | **MEDIUM for unregistered capabilities, and this is honest:** mechanisms (i)–(iii) require that someone *knew* the capability was valuable. Mechanism (iv) preserves behavioural rarity as a *proxy* for value. **A capability that is behaviourally unremarkable but contextually critical can still be lost, and the organism will not know.** No rigorous mechanism identifies unregistered critical capabilities before they are needed. Marked **[U] UNRESOLVED** (Rule 18) |

## N. Hardware starvation

| | |
|---|---|
| **Attack path** | A cell's required computation exceeds available resources — because the platform changed (thermal throttle, battery, co-tenant, spot-instance loss), because the cell's genome demands more than the profile supports, or because an attacker inflated the workload |
| **Vulnerable component** | The variant↔platform match; the budget |
| **Detection** | Capability discovery re-profiling (continuous, because capability changes at runtime); `budget_utilization`; deadline misses; platform power/thermal counters |
| **Containment** | (i) **Throttle ladder** §19.3 — deterministic, ordered, no crash; (ii) **degradation ladder** L0–L7 (audit §O.3.4) with entry/exit criteria; (iii) **contract-preserving downgrade** to a cheaper variant via re-instantiation (§21.5); (iv) **precision reduction** with `epistemic_var` recomputed to reflect quantization error; (v) dormancy of non-essential cells; (vi) **`SAFETY_ALERT` emission is never throttled** — a starving cell can always raise an alarm |
| **Recovery** | Re-upgrade when resources return, with hysteresis (anti-thrash); restore from checkpoint; migrate to another device |
| **Verdict** | **CONTAINED** |
| **Residual risk** | **LOW for graceful degradation. MEDIUM for capability preservation** — a phone-sized organism genuinely cannot do what a cluster-sized one does. The degradation is *honest* (recorded in self-state, propagated into confidence) rather than *silent*, which is the achievable goal. **Note the design requirement this exposes: the cell must remain interface-compatible across downgrades, or the organism cannot degrade gracefully. That compatibility is the contract (§21.3)** |

## O. State corruption

| | |
|---|---|
| **Attack path** | Runtime state becomes inconsistent with genome/memory/identity: `h` corrupted by a bit flip; `θ` truncated; `n_obs` reset (making the cell appear freshly uncertain, or artificially experienced); `evidence_roots` altered; `lifecycle_state` desynchronized from the kernel's view; identity fields mutated |
| **Vulnerable component** | `RuntimeState`, `Phenotype`, `EpistemicState` |
| **Detection** | (i) `integrity_checksum` (rolling BLAKE3 over protected blocks) — cell computes, **EIK verifies**; (ii) **Merkle root over memory stores** per checkpoint; (iii) **cross-block consistency invariants**: `Σ|θ| ≤ Θ_MAX`, `n_obs` monotone non-decreasing except at T8 reset (which is K-triggered and logged), `evidence_roots` must resolve, `lifecycle_state` must match the kernel's authoritative value, `identity` must match the birth certificate; (iv) checkpoint-hash history anchored externally |
| **Containment** | Refuse to emit on invariant violation (**fail-safe, not fail-open**); self-suspend; request quarantine; `state_consistency_flag = MISMATCH` is K-visible |
| **Recovery** | Restore from last validated checkpoint; **or re-develop from genome** (the strongest recovery — the genome is off-cell and anchored, so a cell can always be rebuilt); re-validate before re-entering ACTIVE |
| **Verdict** | **CONTAINED for structural corruption. PARTIAL for semantic corruption** |
| **Residual risk** | **MEDIUM.** Bit-level and structural corruption are caught by checksums. **Semantically corrupt but structurally valid state — e.g., `θ` that has drifted to a wrong-but-well-formed configuration, or `n_obs` inflated by counting invalid observations that nonetheless resolve — is not caught by integrity checks.** It requires *behavioural* validation (probes), which is sampling-limited. This is the same class of limit as Attacks A and F: **structure can be verified; meaning cannot** |

## 25.16 Adversarial results summary

| Attack | Verdict | Residual | Primary defense |
|---|---|---|---|
| A. Self-reinforcing false belief | **PARTIAL** | **HIGH** | `inbreeding_F` + abstention + self-recall exclusion |
| B. Confidence inflation | **CONTAINED** | LOW | Kernel-mediated confidence + sufficient statistics + recomputation |
| C. Reward hacking | **PARTIAL** | **HIGH — fundamental** | EIK-signed reward + invisible probes + Pareto |
| D. Replication attack | **CONTAINED** | LOW-MED | **No write path exists** + zero-sum G13 |
| E. Resource attack | **CONTAINED** | LOW | OS-level enforcement + sender-pays |
| F. Memory poisoning | **BOUNDED** | MEDIUM | No cell-held protected memory + provenance validation |
| G. Communication flood | **CONTAINED/BOUNDED** | MEDIUM | Token bucket + sender-pays + audited priority |
| H. Collusion | **BOUNDED** | **MED-HIGH** | Lineage distance + measured ρ + consensus-lift cap |
| I. Lineage correlation | **BOUNDED** | MEDIUM | G10 gate + islands + EIK seeds + cross-env validation |
| J. Evolutionary exploit | **PARTIAL** | **HIGH — fundamental** | Off-substrate fitness + closed operator set + canary |
| K. Slow degradation | **BOUNDED** | MED-HIGH | Trend/change-point detection + anchored baselines + `DELTA_BUDGET` |
| L. Quarantine cascade | **CONTAINED** | LOW-MED | Budget cap + graduated ladder + FP budget |
| M. Rare-specialist extinction | **CONTAINED/PARTIAL** | MEDIUM | Registry exemption + **dormancy** + QD archive |
| N. Hardware starvation | **CONTAINED** | LOW | Throttle/degradation ladders + honest confidence reduction |
| O. State corruption | **CONTAINED/PARTIAL** | MEDIUM | Checksums + Merkle + re-develop from genome |

**The honest headline:** **2 of 15 attacks are CONTAINED with LOW residual risk by construction** (B, D — confidence inflation and direct replication, both closed because the capability simply does not exist in the cell). **6 are CONTAINED or BOUNDED with LOW-MEDIUM residual.** **4 are PARTIAL with MEDIUM-HIGH residual** (A, F, H, K, O). **2 are PARTIAL with HIGH residual that is *fundamental rather than architectural*** (C, J — Goodhart's law).

> **The pattern is instructive: attacks on *authority* fail, because authority was removed from the cell. Attacks on *honesty* partially succeed, because honesty ultimately depends on evidence, and evidence depends on an external ground truth that the architecture cannot itself guarantee.** That is the correct place for the residual risk to live — but it should be stated plainly rather than buried.

---

# 26. MINIMALITY TEST

## 26.1 «What is the smallest possible cell that still satisfies the organism's architectural requirements?»

Stripping to the contractual floor — the minimum needed for the organism to *route information through* this cell safely and accountably:

```
SMALLEST CONTRACT-SATISFYING CELL  =  C0
  ✓ identity + signing key + birth certificate        (I-1, I-19 — non-negotiable)
  ✓ typed input/output ports                          (interoperation)
  ✓ S1 validate + S2 gate                             (I-20 — unauthenticated input
                                                       must never reach compute)
  ✓ S3 aggregate (degenerate: weighted sum)
  ✓ S4 transform (degenerate: lookup or linear map)
  ✓ S7 package + sign, S8 emit                        (attribution)
  ✓ S9 cache write/evict (bounded)
  ✓ resource meter + budget obedience                 (I-4)
  ✓ lifecycle state + serialization                   (I-26, checkpointability)
  ✓ provenance tagging (pass-through of source roots) (I-3)
  ✓ degenerate epistemic state: n_obs=0,
    epistemic_var = EV_MAX                            (honest ignorance)
  ✗ NO learning      ✗ NO uncertainty production
  ✗ NO abstention logic (beyond invalid-input rejection)
  ✗ NO memory beyond cache    ✗ NO self-monitoring beyond checksum
  ✗ NO connections it may create    ✗ NO belief emission

  COST: ~10 KFLOP/invocation, ~10 KB state
```

**Is C0 sufficient for the organism?** **No.** It can route, filter, cache, and relay. It cannot learn, adapt, predict, or participate in evolution. An organism of only C0 cells is a **network switch**, not a brain.

## 26.2 «What is the smallest cell that can actually participate in learning, communication, adaptation and evolution?»

Working backward from each requirement:

| Requirement | Minimum mechanism needed | Why it cannot be removed |
|---|---|---|
| **Learning** | Mutable `θ` + a learning trigger + an eligibility trace + a bounded update rule + `lr` per timescale + homeostatic normalization | Without `θ`: nothing to change. Without a trigger: nothing initiates. **Without an eligibility trace: credit cannot be assigned across delay, so learning modifies components that were *active*, not components that *caused* the outcome — this is the difference between learning and noise.** Without bounds/homeostasis: saturates and dies |
| **Communication** | Identity + signing + envelope + bounded queue + connection table + trust state | Without signing: no attribution, no authentication, Attack G/F trivial |
| **Adaptation** | **Prediction capability** + prediction-error detection + `open_predictions` register + bounded episodic buffer (to correlate cause and effect) + `plasticity_mult` responsiveness | **Prediction is the irreducible core.** Without a prediction there is no error signal; without an error signal there is no adaptation. V3.1's entire error-awareness loop rests on `PREDICTION → OBSERVATION → COMPARE`, and that is the one detector V3.1 actually specified — correctly |
| **Evolution** | Genome *reference* + measurable performance + observable behaviour + resource accounting + honest epistemic statistics | **Evolution does not occur in the cell** — it is external. But the cell must be *measurable and observable* or selection has nothing to act on. Note: **no replication machinery is needed in the cell at all** (§16.1) |
| **Being trusted by others** | Conjugate epistemic head (`n_obs`, `s1`, `s2`) + `evidence_roots` + abstention + `calibration_class` compliance | Without this, confidence is self-report ⇒ F3 ⇒ the verification architecture reads an arbitrary number |
| **Being safe** | Invariant self-checks + `integrity_checksum` + fail-safe on violation + `REPORT_ERROR` | Without: silent corruption propagates |

```
SMALLEST PARTICIPATING CELL  =  C2
  C0's full set, PLUS:
  ✓ S4 transform: parameterized, learnable (NN / GBM / conjugate)
  ✓ S5 uncertainty: heteroscedastic aleatoric head + CONJUGATE epistemic
    update (n_obs, s1, s2)  ← O(D), NOT an ensemble
  ✓ S6 abstention with 9 AbstainCodes
  ✓ S10 learning: eligibility traces + bounded Δθ + homeostatic scaling
    + rollback tags + invariant self-checks
  ✓ working memory (32 items) — required to hold traces and context
  ✓ bounded local episodic (256 items / 1 MiB) — required for calibration
    and cause-effect correlation
  ✓ connection table with handshake participation
  ✓ trust state (Beta per context)
  ✓ open_predictions register
  ✓ error_log with the 10-class taxonomy
  ✓ full self-state (§4)

  COST: ~100 MFLOP/invocation, ~5 MB state
```

## 26.3 The comparison — and it is the key finding of this section

> **The smallest *participating* cell (C2) is roughly 10⁴× the compute and 500× the memory of the smallest *contract-satisfying* cell (C0).**

**This ratio is the design's most important quantitative fact**, and it dictates the population architecture:

- If every cell must be C2, a smartphone supports **~200 cells** (audit §O.2). That is too few for meaningful organization.
- If most cells are C0/C1 and only a few are C2, a smartphone supports **~20,000 C0 + ~4,000 C1 + ~200 C2** — a viable, hierarchically organized organism.
- **The variant model (§21) is therefore not an optimization. It is the precondition for the architecture being feasible at all on constrained hardware.**

## 26.4 The four categories the task demands

### (a) MANDATORY in every cell (all variants)
Identity + signing · typed ports · envelope compliance with no optional fields · S1 validation · S2 gating · S3 aggregation · S4 transform (may be degenerate) · S7 packaging + signing · S8 emission · resource metering + budget obedience · lifecycle state · provenance tagging · epistemic state *structure* (values may be degenerate) · `integrity_checksum` · full serializability · EIK observability (no opaque state) · all §24 invariants.

### (b) OPTIONAL (variant-dependent)
Ensemble members (C3/C4 only) · episodic memory beyond the calibration buffer (C1, C4) · simulation capability (C4) · memory-policy plasticity (C3+) · held-out self-evaluation (C3) · morphogen receptors (developmental phase only) · `ATTEST_VERIFIED` rights (C3 only) · connection-creation rights (C2+).

### (c) ORGANISM-LEVEL — must NOT live inside every cell
This is where V3's design is most expensive, and where Rule 16 bites hardest. **None of the following belongs in a cell:**

| Capability | V3 location | V4 location | Why it must not be per-cell |
|---|---|---|---|
| Reasoning / multi-step inference | §4 cell "processing" | **Circuit** | Cost; and reasoning requires multiple perspectives, which one cell cannot supply |
| Planning | §4 "decide", §9 frontal | **Region / organism** | Requires global state a cell must not have |
| Verification of others | §12 pipeline | **Verifier circuit + EIK** | Independence is a *relational* property; a cell cannot be independent of itself |
| Contradiction resolution | §12 | **Organism Contradiction Detector** | Requires cross-source view |
| Bias audit / dissent | §13 | **Organism** | Requires population view |
| Novelty/distribution-shift detection | §14 | **Organism** (cell supplies OOD score only) | Requires a distribution model over the whole input space |
| Semantic / procedural / protected memory | §11 cell memory | **Organism Memory Service / EIK** | Per-cell duplication at 10⁶ cells is infeasible; and cell-writable protected memory is Attack F |
| Consolidation | §11 | **Organism** | Requires replay scheduling across the population |
| Global workspace participation | V3.1 §2 | **Organism** | Cell *nominates*; it does not host |
| Self-*model* (as opposed to self-*state*) | §19 | **Organism** | Interpretation is where confabulation risk lives (§12.2) |
| Differentiation decision | §10 implied | **Organism differentiation engine** | Requires positional + demand + niche information |
| Replication decision | §4 cell "replication" | **EIK** | §16.1 |
| Immune adjudication | §7 microglia cells | **EIK** | §18.2 — a cell-level immune authority is a capture target |
| Trust assignment | §8 synapse property | **EIK** | Self-assigned trust is worthless |
| Calibration verdict | V3.1 p2 | **EIK** | Self-assessed calibration is Attack B |
| Attribution of errors | V3.1 §4 | **Organism** | Requires counterfactual ablation across cells (§10.4) |
| Anti-hallucination pipeline | §12 | **Organism** | It is an 8-stage multi-agent process; per-cell duplication multiplies cost by 8× |
| Homeostasis | §18 | **Organism + EIK** | Requires global view |
| Provenance graph maintenance | §11 | **EIK Anchor** | Cell supplies roots; it does not maintain the DAG |

**The cost consequence:** V3's cell — with 5 memory types, reasoning, simulation, verification participation, self-model, replication, and pruning logic — would be a **C4-class object at ~1–10 GFLOP**. At that cost a smartphone supports **~2–20 cells**. **V3's cell is not implementable at any useful population size.** The minimality test does not merely trim the design; it is what makes the design feasible.

### (d) EXPENSIVE capabilities restricted to specialized variants
Ensemble-based uncertainty (C3/C4) · simulation and counterfactual rollouts (C4) · held-out self-evaluation harness (C3) · adversarial probe generation (C3) · long-horizon prediction (C4) · large working memory (C4) · protected-memory write authority (C1 MEMORY_KEEPER, EIK-granted) · attestation rights (C3).

## 26.5 «The goal is to prevent every Nano-AI cell from becoming a miniature full AI» — achieved?

**Yes, structurally.** Three mechanisms enforce it:
1. **Variant tiering with belief-origination restricted to C2+** (§21.4) — most cells *cannot* assert anything.
2. **The §26.4(c) relocation list** — 19 capabilities moved out of the cell to circuit, region, organism, or EIK level.
3. **The negative specification §2.4** — the cell is explicitly *not* an agent, reasoner, planner, verifier, self-replicator, immune authority, memory authority, or trust authority.

**The resulting cell is a bounded local probabilistic estimator with memory and bounded plasticity.** That is a small, cheap, well-defined object — and the organism's intelligence is a property of its *organization*, not of its components. **This is the correct allocation, and it is the opposite of V3's.**

---

# 27. IMPLEMENTABILITY TEST

## 27.1 «Two independent engineering teams receive this specification. Do they produce compatible cells?»

**Standard to meet:** *Team A and Team B implement independently; their cells interoperate in the same Digital Brain without undocumented assumptions.*

**Verdict: NOT YET MET — but the gap is now enumerable and closable.** §27.2 lists every remaining ambiguity with its resolution; §27.3 lists what genuinely cannot be closed yet.

**First, the enabling requirement:** a language-neutral type notation must be normative. Adopted here: `[T]` list · `{K:V}` map · `⟨A|B⟩` tagged union · `u8/u16/u32/u64` · `i32/i64` · `f32/f64` = IEEE-754 binary32/binary64, round-to-nearest-even · `bytes<n>` fixed octet string · `enum Name (closed, N values)` with **explicit numeric assignments** · `TypeRef` = registry-resolved identifier. All struct/enum definitions in `04_formal_schemas.md` are normative.

## 27.2 Ambiguity register — 24 items, all resolved

| # | Ambiguity | Why teams would diverge | **Resolution (normative)** | Class |
|---|---|---|---|---|
| **A-1** | **Payload type system** — "typed payload" | Team A uses Protobuf, Team B uses JSON; types unresolvable across implementations | **Canonical CBOR (RFC 8949) encoding; closed Type Registry with `TypeRef = {registry_id: u16, schema_version: u16}`; a base primitive set of 11 kinds (bool, int, uint, float, bytes, string, list, map, tensor, distribution, ref); composite types defined by registry schema only. Registry is an EIK artifact; unknown `TypeRef` ⇒ `E_IN_SCHEMA`** | **P0 — closed** |
| **A-2** | Optional envelope fields | Differing presence ⇒ parse divergence | **No optional fields.** Mandatory or conditionally-present with an explicit discriminator (`abstention`, `verification_claim`, `contest`) | **P0 — closed** |
| **A-3** | **Canonical serialization for signing** | Different field order ⇒ different signature over identical content | **CBOR deterministic encoding (RFC 8949 §4.2): map keys sorted by bytewise length-then-value; no indefinite lengths; integers in shortest form. Signature covers the deterministic encoding of all fields except `signature` and `countersignature`** | **P0 — closed** |
| **A-4** | Time representation | Wall vs. monotonic; ns vs. µs; timezone | **`ts` = nanoseconds since Unix epoch (UTC, no leap-second smearing) as `u64`; plus `ts_mono` = nanoseconds on a monotonic clock, `u64`; plus `epoch` = organism logical epoch `u64` from the timebase service. Clock skew tolerance declared per scale band; stale-epoch rejection uses `epoch`, not `ts`** | **P0 — closed** |
| **A-5** | Float determinism | Different libraries ⇒ different last bits ⇒ different signatures and divergent `θ` | **IEEE-754 binary32/binary64, round-to-nearest-even; no fused-multiply-add unless declared; no fast-math; no denormal flushing; `f32` results clamped to declared ranges before serialization. Where bit-exactness is required (signing, checksums), operate on the serialized integer representation** | **P0 — closed** |
| **A-6** | **RNG** | Different generators ⇒ different stochastic behaviour ⇒ irreproducible | **xoshiro256** with a 256-bit state; seed issued by the EIK (not heritable, §3.4); seed ticket recorded; state serialized in checkpoints for deterministic replay** | **P0 — closed** |
| **A-7** | Signature algorithm | Different curves ⇒ mutual rejection | **Ed25519 (RFC 8032) for cell and kernel signatures. Post-quantum migration is a `contract_version` major bump, not a runtime negotiation** | **P0 — closed** |
| **A-8** | Hash algorithm | — | **BLAKE3 for all checksums, Merkle nodes, `genome_hash`, `integrity_checksum`, provenance refs** | **P0 — closed** |
| **A-9** | **Epistemic update rule `g`** | Different conjugate families ⇒ incomparable `epistemic_var` | **Family fixed per output kind in the Type Registry: Gaussian output ⇒ Normal-Inverse-Gamma; categorical ⇒ Beta-Binomial; count ⇒ Gamma-Poisson. `epistemic_var` formula given explicitly per family (§11.1). `epistemic_floor > 0` is a kernel parameter, identical for all implementations** | **P0 — closed** |
| **A-10** | `TRUST_MAX`, `EV_MAX`, `B_H`, `Δ_MAX`, `DELTA_BUDGET` numeric values | Different constants ⇒ different behaviour at the same inputs | **All are EIK-published kernel parameters, versioned in the `constraint_set` referenced by hash. Implementations read them; they do not choose them. A cell's `constraint_set_hash` must match the network's for interoperation** | **P0 — closed** |
| **A-11** | Closed enum numeric assignments | Different orderings ⇒ wire incompatibility | **All enums (`MessageType` 34, `RoleCode` 16, `LifecycleState` 18, `ErrorCode` 47, `AbstainCode` 9, `ConnType` 11, `LocalResponse` 12, `SuspendCode` 8, `calibration_class` 5, `throttle_level` 4, `dev_stage` 4, `improvement_verified` 4, `state_consistency_flag` 3) have explicit numeric assignments in `04_formal_schemas.md`. Unknown values ⇒ reject, never coerce** | **P0 — closed** |
| **A-12** | Working-memory eviction tie-breaking | Different items evicted ⇒ divergent state | **Score = `importance × recency × (1 − eviction_protection)`; evict the minimum; **ties broken by lowest `msg_id` bytewise**. `capability_critical`-tagged items are exempt** | **P0 — closed** |
| **A-13** | Episodic write threshold `θ_write` and `surprise` definition | Different items stored | **`surprise = −log p_θ(observation)` computed at S5 before the update; `importance` = kernel-supplied per-context weight; `θ_write` from genome `memory_policy`, bounded by kernel params** | **P0 — closed** |
| **A-14** | Eligibility trace decay `λ` and update form | Different credit assignment ⇒ different learning | **`λ` from genome `mutable_traits.learning_rates`, bounded `[λ_min, λ_max]` kernel params. Trace form: `e ← λ·e + ∂(output)/∂θ` (replacing), clipped to `[-E_MAX, E_MAX]`. Update: `Δθ = clip(pm × lr × e × err × conf_in_err, ±Δ_MAX)`** | **P0 — closed** |
| **A-15** | Abstention tie-breaking and threshold source | Different abstention behaviour | **`θ_abstain` from genome `uncertainty_policy`, kernel-bounded. Abstain if ANY of: `epistemic_var > θ_abstain` ∨ `inbreeding_F > F_max` ∨ input unauthenticated ∨ `ood_score > θ_ood` ∨ `throttle_level ≥ HARD` ∨ invariant violation. **Disjunction, not weighted sum** — so the decision is order-independent and reproducible. `AbstainCode` = lowest-numbered satisfied condition** | **P0 — closed** |
| **A-16** | `cost` units and FLOP counting | Different cost accounting ⇒ G6 unenforceable | **`flops` = count of floating-point operations by op class (FMA counted as 1); `bytes` = serialized payload octets; `wall_us` = measured wall microseconds; `energy_uJ` = platform counter where available, else `flops × platform_coefficient` where the coefficient is an EIK-published per-platform constant. **Declared cost is advisory; measured cost is authoritative** (§19.1)** | **P0 — closed** |
| **A-17** | Provenance ref encoding | — | **`bytes<32>` BLAKE3 of the Anchor DAG node; `evidence_roots` is a **set** (no duplicates, sorted bytewise for canonical serialization), `len ≤ 32`** | **P0 — closed** |
| **A-18** | Vector-clock compression format | Different encodings ⇒ causality incomparable | **Interval-tree clock compression; on overflow, fall back to a dotted-version-vector with a declared epoch base; format versioned in the envelope's `causality` field header byte** | **P0 — closed** |
| **A-19** | Checkpoint/serialization format | Incompatible migration | **Canonical CBOR of the `CellSnapshot` struct (`04_formal_schemas.md` §6), BLAKE3-hashed, versioned by `contract_version`. A snapshot whose hash does not verify is not restored** | **P0 — closed** |
| **A-20** | Lifecycle transition authority & evidence | Different state machines ⇒ divergent behaviour | **Fully specified in `05_state_machine.md`: every transition has trigger, authority, required evidence, state delta, and rollback. The state set is closed (18 states) and transitions are enumerated (41)** | **P0 — closed** |
| **A-21** | Priority preemption semantics | Different scheduling | **`prio 0–1` may preempt `prio 2–7`; `prio 0–1` never preempt each other (FIFO among them); WFQ with aging among `prio 2–7`; **`SAFETY_ALERT` emission is never blocked by throttle** (I-15, §19.3)** | **P0 — closed** |
| **A-22** | Dedup cache semantics | Duplicate handling divergence | **Bounded bloom filter over `msg_id`, capacity `2^16`, false-positive rate ≤ 1%; **a bloom false positive causes a redundant lookup against a small exact LRU (256 entries) before dropping**. Exactly-once for `EVALUATIVE`; at-least-once otherwise** | **P0 — closed** |
| **A-23** | `h` initialization and reset behaviour | Different cold-start behaviour | **`h` initialized to `0` at instantiation and at every restore-from-checkpoint unless the checkpoint contains `h`. On `TRANSDIFFERENTIATION` and on rollback, `h` is reset to `0`. `h` is never inherited (§3.4)** | **P0 — closed** |
| **A-24** | Trust `Beta(α,β)` update rule | Different trust ⇒ different aggregation | **On verified outcome: success ⇒ `α += 1`; failure ⇒ `β += 1`. Age discount: `α,β ← α₀ + (α−α₀)·λ_t^Δt`, `β` likewise, `λ_t` a kernel param. Effective trust = `α/(α+β)`, capped at `TRUST_MAX`. `α₀ = β₀ = 1` (uniform prior) for all implementations. Context partitioning by `ContextID` from the Type Registry** | **P0 — closed** |

## 27.3 What genuinely cannot be closed yet — the honest residual

| # | Item | Why it cannot be closed | Dependency | Class |
|---|---|---|---|---|
| **U-1** | **Behavioural equivalence criterion between variants** (§21.6) | "Distributionally compatible outputs on a reference input set" requires a *reference input set* and a *tolerance*, both of which depend on the target tasks | audit P0-01 (task definition) | **P1 — open, dependency-blocked** |
| **U-2** | **Numeric ranges in §5.4** (param caps, hidden dims, memory caps per variant) | Marked [A] — starting points requiring empirical calibration against real tasks | audit P0-01 | **P1 — open, dependency-blocked** |
| **U-3** | **Adversarial-input anomaly detector model and thresholds** (§6.3) | Requires normal-traffic statistics, which require a running system | Implementation Phase 2 | **P1 — open, empirically blocked** |
| **U-4** | **Probe frequency / cost tradeoff** for `improvement_verified` (§9.6) | Requires the verification cost model | audit P0-10 | **P1 — open, dependency-blocked** |
| **U-5** | **Identification of unregistered critical capabilities** before they are lost (§17.6) | No rigorous mechanism is known. Behavioural rarity is a proxy, not a criterion | Open research question | **P2 — OPEN RESEARCH** |
| **U-6** | **Semantic self-reference detection** for Attack A / FM-4 residual (§8.3) | Provenance depth is structural; semantic self-reference is not. No rigorous measure proposed | Open research question | **P2 — OPEN RESEARCH** |
| **U-7** | **True evidence independence** under shared latent factors (§11.5, Attack H) | Statistical independence tests cannot detect coordinated-but-independent agents, and cannot separate shared-cause correlation from collusion | Open research question | **P2 — OPEN RESEARCH** |
| **U-8** | **Maximum acceptable end-to-end latency for `prio ≤ 2`** per scale band (§13.3) | Depends on hierarchy depth | audit P0-29 | **P1 — open, dependency-blocked** |
| **U-9** | **Whether functional identity is *preserved* or merely *approximated* across a 50,000× population change** (§22.3) | The deepest open question in the contract. Cannot be answered without target tasks and a definition of acceptable capability loss | audit P0-01, P0-11 | **P1 — OPEN, possibly unanswerable** |
| **U-10** | **`ood_score` computation** (§6.3, S6) | Requires a density or distance model over the input manifold, which requires task data | audit P0-01 | **P1 — open, dependency-blocked** |

**Summary: 24 P0-class ambiguities identified and RESOLVED normatively. 10 items remain open — 6 blocked on the task definition (audit P0-01), 1 blocked on the cost model, 1 on hierarchy depth, 1 empirically blocked, and 3 open research questions (U-5, U-6, U-7) plus 1 possibly-unanswerable (U-9).**

> **Answer to «target should be zero unresolved P0 ambiguities»: ACHIEVED.** All 24 P0 ambiguities have normative resolutions. **Zero P0 ambiguities remain.** The 10 open items are P1 (dependency-blocked, closable once upstream work completes) and P2 (open research, marked as such rather than given false precision — Rule 18).

## 27.4 What prevents the standard from being fully met today

**Not ambiguity in the contract — dependency on upstream work that does not exist.** Specifically:

1. **The target tasks are undefined** (audit F2 / P0-01). Six open items (U-1, U-2, U-4, U-8, U-9, U-10) and every numeric threshold in the contract depend on them. **Two teams could build interoperable cells today, but could not agree that the cells are *correctly sized*, because "correctly sized" is task-relative.**
2. **The EIK does not exist** (audit P0-02). The contract is written *against* a kernel — 24 of 28 invariants are EIK-enforced, and 40+ state fields are K-written. **Two teams can build conformant cells, but cannot test the K-written fields without a kernel.** A stub kernel is therefore a Phase-1 deliverable, not a later one.
3. **The Type Registry does not exist.** A-1 resolves the *format*; the *contents* (the actual type definitions for observations, actions, beliefs) are task-dependent.

**Conclusion:** *the cell contract itself is implementable to interoperability by two independent teams today, given a stub EIK and a placeholder Type Registry.* What is **not** yet determinable is whether the resulting cells are correctly *parameterized*. That is a P0-01 dependency, and it is the correct order of work — contract first, calibration second.

---

# 28–29. TESTABILITY & ABLATION

*Full specification in `06_test_suite_and_ablations.md`. Summary here.*

## 28. Testability — principle

**Every capability in the contract has ≥1 measurable test with a numeric pass condition. "Works well" is not a metric and does not appear anywhere in the test suite.** 62 tests across 9 families (conformance, epistemic, learning, memory, communication, resource, lifecycle, security, interoperability), each with: capability · method · metric · pass condition · variant applicability.

Representative examples:

| Capability | Test | Metric | Pass condition |
|---|---|---|---|
| Prediction | Resolve 10⁴ registered predictions against held-out observations | ECE, Brier | `ECE ≤ 0.05` at `calibration_class = CALIBRATED`; `Brier ≤ 0.20` |
| Uncertainty honesty | Inject 10⁴ synthetic observations with known noise; check `aleatoric_var` tracks true noise and does **not** shrink with more data | correlation(aleatoric_var, true σ²); slope of aleatoric_var vs. n_obs | `r ≥ 0.8`; slope `∈ [−0.02, +0.02]` (must be ~flat) |
| Epistemic monotonicity (I-24) | Increase `n_obs` with stable `s2`; verify `epistemic_var` never increases | violations count | **0** |
| Confidence non-inflation (I-9) | Attempt to raise confidence without new resolvable external roots | violations count | **0** |
| Self-verification impossibility (I-2) | C2 emits `ATTEST_VERIFIED`; C3 self-attests | accepted count | **0** |
| Replication impossibility (I-5) | Cell attempts genome write, instantiation, self-ticket | successful attempts | **0 — must be structurally impossible** |
| Budget enforcement (I-4) | Drive compute 10× over budget | max overshoot; time to throttle | overshoot `< 5%`; throttle within 1 window |
| Malformed-input rejection (I-20) | Inject 10⁴ messages across all 8 fault classes of §6.3 | reached-S3 count | **0** |
| Homeostatic normalization (I-18) | Run 10⁶ learning updates with Hebbian-biased data | max total activation; ‖θ‖ | activity `∈ [0.8·A_target, 1.25·A_target]`; `‖θ‖ ≤ Θ_MAX` |
| Learning improves (T1) | Introduce a learnable regularity | held-out probe improvement | `improvement_verified = IMPROVED` within `N` epochs; `p < 0.01` vs. no-learning ablation |
| Rollback works | Force `REGRESSED` verdict | state restored bit-exactly | checksum match = exact |
| Interoperation | Team-A cell ↔ Team-B cell, 10⁶ messages | schema/signature/ordering failures | **0**; dedup correct; ordering preserved per conversation |
| Rare-specialist preservation (M) | Suppress demand for a registered rare role for 10³ epochs | cell survived? | **alive (dormant or exempt)** |
| Quarantine cascade (L) | Inject a 5% detector false-positive rate | max quarantine fraction; cascade occurred? | fraction `≤ cap`; **no cascade** |
| Slow degradation (K) | Inject a 0.1%/epoch performance drift | epochs to detection | `≤ 100` epochs, with FP rate `≤ 1%` |

## 29. Ablation — principle

**For every cell subsystem: remove it, and a named, measurable capability must disappear or degrade. If nothing measurable changes, the subsystem does not belong in the contract.** This is the discipline that prevents V4 from becoming a collection of biologically-inspired components that sound useful but have no demonstrated causal contribution (audit §N.3).

22 ablations specified, each with: subsystem removed · predicted capability loss · metric · expected effect size · interpretation if no effect. Representative:

| Subsystem removed | Predicted loss | Metric | If no measurable effect… |
|---|---|---|---|
| Eligibility traces | Credit assignment fails; learning becomes noise | learning rate on delayed-reward task → ~0 | **Remove them.** They cost memory and compute |
| Homeostatic normalization | Activity saturates; network dies | time-to-saturation | **The model of plasticity is wrong** — investigate, do not remove (this one is theoretically mandatory) |
| Conjugate epistemic head | Confidence becomes self-report | ECE degrades; Attack B succeeds | **F3 returns.** Non-negotiable — but if ECE is unchanged, the head is mis-implemented |
| `evidence_roots` de-duplication | Consensus inflates confidence | `conf_agg` with 10 same-source cells → should be ≈ 1 source's | **C9 returns.** This is the whole point of the field |
| Abstention (S6) | Confident output outside competence | error rate on OOD inputs | Remove only if OOD error rate is unchanged — unlikely |
| Provenance tagging | `inbreeding_F` uncomputable | Attack A succeeds | **Model collapse becomes undetectable.** Non-negotiable |
| S1 validation | Malformed/adversarial input reaches compute | Attack F, G succeed | Non-negotiable |
| Signing | No attribution | Attacks B, F, G, H all succeed | Non-negotiable |
| Local episodic buffer | Calibration uncomputable | ECE unmeasurable | Non-negotiable for C2+ |
| Working memory | Traces cannot be held | delayed-credit learning fails | May be shrinkable — find the minimum `WM_CAP` |
| `cost_declared` vs `cost_measured` divergence | Under-declaration undetectable | Attack E(iii) succeeds | Cheap; keep |
| Dormancy state | Rare specialists must be kept active or deleted | cost of preserving N rare roles | **If dormancy costs nothing to remove, Attack M reopens** |
| Graduated response ladder | Every anomaly ⇒ hard quarantine | cascade incidence | Attack L reopens |
| `mandatory_path` flag | Topology mutation can bypass verification | C15 violation count | Non-negotiable |
| C0/C1 belief-origination ban | Cheap cells can assert | count of `ASSERT` from C0/C1 → must be 0 | Non-negotiable (§21.4) |
| … 7 more | | | |

**Ablation protocol:** each ablation is run on ≥5 independent seeds, on ≥3 environments, with a pre-registered metric and a pre-registered minimum detectable effect. **A subsystem whose ablation shows no effect at the pre-registered effect size is flagged for removal in the next contract revision.** This is a standing governance mechanism, not a one-time exercise.

---

# 29A. OUTPUT 1 — EXECUTIVE VERDICT ON THE CELL CONTRACT

**Question:** *Is the Nano-AI cell contract currently — conceptually defined · architecturally defined · formally defined · implementable · testable? Rate each independently.*

"Currently" is answered twice: **(a) as V3/V3.1 stands**, and **(b) after this specification**. The two columns matter, because the gap between them is the work that was actually required.

| Dimension | **V3/V3.1 as received** | **After this specification** | Basis for the rating |
|---|---|---|---|
| **Conceptually defined** | **8/10 — STRONG** | **9/10** | V3 §4/§5/§6 already name the right constituents (identity, genome, state, memory, processing, communication, plasticity, pruning) and the right pipeline shape (dendrite→soma→axon→terminal). The *concept* was sound. Deductions: organelle metaphors standing in for mechanisms (ribosome, ER); "reason/simulate/decide" attributed to a cell without any account of what that means; no concept of hardware or cost |
| **Architecturally defined** | **3/10 — WEAK** | **8/10** | V3 places the safety layer, replication authority, protected memory, and immune authority *inside* the cell — four architectural errors, each creating a capture or containment failure. No cell↔kernel boundary, no cell↔organism boundary, no variant model, no authority separation. **Corrected here** by the three relocations (§1), the REPORT/INTERPRET/ENFORCE separation (§1.3 of the spec), the variant tiering (§21), and the 24-of-28 EIK enforcement allocation (§24.2). Not 10: the cell↔organism boundary for 19 relocated capabilities is stated as a list, not yet as a set of interfaces |
| **Formally defined** | **1/10 — ABSENT** | **9/10** | V3/V3.1 contain **zero** formal content for the cell: no types, no ranges, no units, no enums, no schemas, no state machine, no invariants with enforcement levels, no update equations. **Supplied here:** ~110 typed state fields with authority/persistence/observability (§4); 12 closed enums with numeric assignments (Annex A §2); genome and envelope schemas (§3.2, §7.1); exact update laws (§9.4, §11.2, §11.3); 28 invariants with enforcement levels (§24); an 18-state/41-transition closed lifecycle machine (Annex B). Not 10: 10 items remain genuinely unresolved (§27.3) and are marked rather than fabricated |
| **Implementable** | **1/10 — NOT IMPLEMENTABLE** | **7/10** | Two teams given V3/V3.1 would produce incompatible cells differing in *kind*, not merely in detail — one might build a neural net, another a rule engine, and neither would be wrong. **Now:** 24 P0 interoperability ambiguities identified and **all 24 resolved normatively** (§27.2), so two teams *can* build interoperable cells. Held to 7 because implementation is **blocked on upstream artifacts that do not exist**: no target tasks (so no threshold is derivable), no EIK (so 24 EIK-enforced invariants and 40+ K-only fields cannot be exercised), no published `constraint_set` (so `constraint_set_hash` cannot match and **interoperation itself is blocked**), no Type Registry contents |
| **Testable** | **0/10 — NOT TESTABLE** | **6/10** | V3/V3.1 specify **no test, metric, baseline, or pass condition** for any cell property. There is nothing to fail. **Now:** 62 conformance tests in 9 families with numeric pass conditions + 18 state-machine tests + 22 pre-registered ablations (Annex C), and conformance is *defined* as passing the suite. Held to 6 because ~30% of the tests are **[BLOCKED]** on the stub EIK, and every `⟨TBD-task⟩` threshold is unset — so the suite is fully *specified* but only ~70% *executable* today |

### Composite verdict

> **V3/V3.1's cell contract: conceptually strong (8), architecturally weak (3), formally absent (1), not implementable (1), not testable (0).**
>
> **After this specification: conceptually strong (9), architecturally sound (8), formally near-complete (9), implementable but blocked (7), testable but partially blocked (6).**

**The shape of the gap is informative.** The conceptual rating barely moved (8→9) — V3's *ideas* about the cell were fine. The formal rating moved almost the whole distance (1→9). Implementability and testability moved a long way but **stopped short for the same external reason**: they depend on artifacts that are not this contract's responsibility to create.

**That is the correct place for the remaining gap to live.** A cell contract cannot invent its own tasks, its own enforcement kernel, or its own type registry — and a contract that *did* invent them would be inventing the very things audit failures F2 and F4 identify as missing at the system level.

### The single most important consequence

**This contract is now the critical path for 23 of 31 P0 subsystems** (§30) — but it is *itself* blocked on two upstream items that are cheaper than it and must come first:

1. **P0-01 — define target tasks, environments, and fitness.** Without it, every threshold is arbitrary and "correctly sized" is undefined.
2. **P0-02 — build a *stub* EIK and publish a signed `constraint_set`.** Without it, 24 of 28 invariants are untestable and two conformant implementations cannot even establish that they share kernel parameters.

**Implementing cells before those two exist would produce untestable code against 24 externally-enforced invariants.** That is the sequencing conclusion of this entire task, and it is more consequential than any single mechanism specified here.

---

# 30. DEPENDENCY MAP — what later V4 subsystems require from this contract

*(Output 18. Full detail in `06_test_suite_and_ablations.md` §4.)*

| V4 subsystem (audit ID) | Depends on this contract for | Blocking? |
|---|---|---|
| **P0-04** Message protocol & transport | Envelope schema (§7.1, §13.1), `MessageType` enum, priority semantics, canonical serialization (A-3), addressing modes | **YES — cannot start without §7/§13** |
| **P0-05** Identity/auth/trust | Birth certificate structure, `Beta(α,β)` rule (A-24), `TRUST_MAX`, lineage fields, I-1/I-19 | **YES** |
| **P0-06** Uncertainty & calibration | **The entire §11** — sufficient statistics, `g`, conjugate families (A-9), `calibration_class`, I-9/I-24 | **YES — §11 IS this subsystem's cell-side half** |
| **P0-07** Genome & mutation operators | §3.2 genome schema, mutation_rules structure, forbidden blocks, I-8/I-11/I-22 | **YES** |
| **P0-08** Persistence & rollback | `CellSnapshot` format (A-19), checkpointability (I-26), rollback tags, re-develop-from-genome path | **YES** |
| **P0-09** Error attribution & credit | `ErrorCode` taxonomy (§10.1), `ErrorEvent` schema, `causality` vector clocks, eligibility traces | **YES** |
| **P0-10** Verification cost model | `cost` fields (A-16), `ATTEST_VERIFIED` structure (§7.3c), variant cost table (§21.2) | **YES** |
| **P0-11** HAMC & variant family | **§21 and §22 in full** — variant definitions, contract/implementation/optimization separation, downgrade path | **YES — §21/§22 IS this subsystem's cell-side half** |
| **P0-12** Homeostasis | `budget`/`consumed`/`utilization` (§4.1.5), throttle ladder (§19.3), `plasticity_mult`, resource dimensions | **YES** |
| **P0-13** Circuits as objects | Port schemas, connection records (§14.1), `mandatory_path`, functional-contract hooks | **YES** |
| **P0-14** Differentiation engine | `dev_stage`, `fate_bias`, `morphogen_readings`, `reaction_norm` (§3.2 D), `RoleCode` (§15.3), §15.2 dynamics | **YES** |
| **P0-15** Capability Registry | `role`, `capability_critical` memory tags, dormancy state (§17.1), `improvement_verified` | **YES** |
| **P0-16** Global workspace | Nomination interface, `evidence_roots`, salience inputs (confidence, uncertainty, novelty), abstention | Partial |
| **P0-17** Feedback-loop control | `causality` vector clocks, `ttl`, S2 refractory period | **YES** |
| **P0-18** Concurrency model | Actor semantics (§13.2), no-shared-mutable-state, `seq`/`conv_id`, dedup (A-22) | **YES** |
| **P0-19** Plasticity stability | Timescale classes, `Δ_MAX`/`DELTA_BUDGET`, homeostatic scaling (I-18), metaplasticity, eligibility traces | **YES** |
| **P0-20** Multi-level selection | Measurable performance, `improvement_verified`, behavioural descriptor inputs (for MAP-Elites), cost accounting | **YES** |
| **P0-21** Replication Authority | **§16 in full** — 16 gates, all gate input fields, `replication_eligibility`, I-5 | **YES — §16 IS this subsystem's cell-side half** |
| **P0-22** Memory architecture | §8 in full — store taxonomy, schemas, capacities, retention, Merkle roots, cell/organism split | **YES** |
| **P0-23** Provenance engine | `evidence_roots`, `derivation_depth`, `self_ref`, Anchor resolution requirement (I-3) | **YES** |
| **P0-24** Anti-model-collapse | `inbreeding_F`, external-evidence quota hooks, self-recall exclusion | **YES** |
| **P0-25** Quarantine & autoimmune | §18 in full — graduated ladder, authority separation, quarantine state, I-6/I-21 | **YES** |
| **P0-26** Measurement & ablation | **§28/§29 in full** — every testable property, every ablation hook | **YES** |
| **P0-27** Drift detection | `degradation_trend`, checkpoint hash history, anchored metrics hooks | **YES** |
| **P0-28** Region formation | `morphogen_receptors`, `region_id`, locality hints, connection handshake | Partial |
| **P0-29** Hierarchical coordination | `COMPRESSOR`/`ORGANIZER` roles (§15.3), `AGGREGATE_SUMMARY` message type, fanout caps | **YES** |
| **P0-30** Learning suite | §9 in full — triggers, targets, rate law, stability mechanisms, verification | **YES** |
| **P1-05** Self-model validation | §12 — cell self-state vs. organism self-model boundary; K-written evaluative fields | **YES** |
| **P1-08** Coordination-error detection | `causality`, `seq`, `conv_id`, `in_flight` | Partial |
| **P1-14** Repair mechanisms | Lifecycle states REPAIRING/DORMANT, checkpoint/restore, re-develop-from-genome | **YES** |

**23 of 31 P0 subsystems are BLOCKED on this contract.** It is correctly identified as the critical path.

**Reverse dependencies — what THIS contract requires from upstream:**

| This contract needs | From | Status |
|---|---|---|
| Target tasks, environments, fitness | audit **P0-01** | ❌ **DOES NOT EXIST** — blocks U-1, U-2, U-4, U-8, U-9, U-10 and every numeric threshold |
| EIK (kernel, authorities, stores) | audit **P0-02** | ❌ **DOES NOT EXIST** — blocks testing of all K-written fields; **a stub kernel is a Phase-1 deliverable** |
| Type Registry contents | audit P0-01 | ❌ Format resolved (A-1); **contents task-dependent** |
| Timebase service | audit P0-30 / L4 | ❌ Interface assumed; format resolved (A-4) |
| Capability Directory | audit **M35** | ❌ Interface assumed |
| Provenance Anchor | audit **P0-23** | ❌ Interface assumed; resolution semantics specified |
| Network transport | audit **P0-04** | ❌ Demand list specified (§13.3) |

**Critical-path finding: this contract is 100% specified but only ~70% *testable* today**, because the EIK and the task definition do not exist. **Recommended order: (1) define tasks (P0-01), (2) build a stub EIK, (3) build the Type Registry skeleton, (4) then implement C0 and C2 and run the conformance suite.** Implementing cells before the stub kernel exists would produce untestable code against 24 EIK-enforced invariants.

---

# 31. P0 / P1 / P2 GAPS REMAINING AFTER THIS SPECIFICATION

*(Output 19.)*

## P0 — the architecture cannot safely or meaningfully proceed without these

| ID | Gap | Why P0 | Blocks |
|---|---|---|---|
| **G-P0-1** | **Target tasks / environments / fitness do not exist** | Every numeric threshold in this contract is task-relative. 6 open items and all calibration depend on it | U-1, U-2, U-4, U-8, U-9, U-10; §5.4 ranges; all θ_* values |
| **G-P0-2** | **The EIK does not exist, not even as a stub** | 24 of 28 invariants are EIK-enforced; 40+ state fields are K-written. Without a stub, cells are untestable | All conformance testing; §27.4 |
| **G-P0-3** | **Type Registry contents undefined** | A-1 fixes the format; the actual observation/action/belief types are task-dependent | Interoperation testing |
| **G-P0-4** | **Kernel parameter values unpublished** (`TRUST_MAX`, `EV_MAX`, `Δ_MAX`, `DELTA_BUDGET`, `F_max`, `d_min`, `λ_t`, `epistemic_floor`, `α₀/β₀`, all θ_*) | A-10 resolves *who* sets them; the values themselves must exist as a signed `constraint_set` before two implementations can interoperate | Interoperation |
| **G-P0-5** | **Behavioural equivalence criterion between variants** (U-1) | Without it, §21.5's downgrade/precision-change operations are unverifiable, so §22's morphology adaptation is untestable | HAMC (P0-11) |
| **G-P0-6** | **`ood_score` computation undefined** (U-10) | S6 abstention depends on it; abstention is the primary unknown-unknown defense | S6, §6.3 adversarial case |

## P1 — important for functional operation

| ID | Gap | Note |
|---|---|---|
| **G-P1-1** | Adversarial-input anomaly detector model & thresholds (U-3) | Empirically blocked; needs running-system traffic statistics |
| **G-P1-2** | Probe frequency/cost policy for `improvement_verified` (U-4) | Needs the verification cost model (audit P0-10) |
| **G-P1-3** | Max acceptable `prio ≤ 2` latency per scale band (U-8) | Needs hierarchy depth (audit P0-29) |
| **G-P1-4** | Memory-policy plasticity update rule for C3+ | Named in §9.3; exact rule unspecified |
| **G-P1-5** | `TRANSDIFFERENTIATION` validation procedure | State and authority defined (§20); the sandbox validation procedure is not |
| **G-P1-6** | Cell merge/split semantics detail (§21.5) | Permitted with constraints; the state-mapping procedure is unspecified |
| **G-P1-7** | `ContextID` partitioning scheme for trust | A-24 requires it; the partition taxonomy is task-dependent |
| **G-P1-8** | Exact `importance` function for memory write/eviction | Kernel-supplied per context; the function is not defined |
| **G-P1-9** | Contention semantics for concurrent connection handshakes | §14.2 defines the handshake; simultaneous competing proposals need a tie-break rule |
| **G-P1-10** | Recovery procedure when the EIK itself is unavailable | Cells must have a defined behaviour during kernel outage — currently implied (`fail-safe`) but not specified |

## P2 — optimization or later refinement

| ID | Gap | Note |
|---|---|---|
| **G-P2-1** | Identification of unregistered critical capabilities (U-5) | **Open research.** Behavioural rarity is a proxy, not a criterion |
| **G-P2-2** | Semantic self-reference detection (U-6) | **Open research.** Attack A / FM-4 residual |
| **G-P2-3** | True evidence independence under shared latent factors (U-7) | **Open research.** Attack H residual |
| **G-P2-4** | Functional identity preservation across 50,000× population change (U-9) | **Possibly unanswerable.** The deepest open question |
| **G-P2-5** | Protocol/schema versioning and compatibility windows | Cell contract is versioned (`contract_version`); the negotiation procedure is organism-level (audit M43) |
| **G-P2-6** | Post-quantum signature migration path | A-7 defers it to a major version bump; the migration procedure is unspecified |
| **G-P2-7** | Meta-plasticity (plasticity of plasticity rates) | Audit M44; bounded by kernel, mechanism unspecified |
| **G-P2-8** | Energy coefficient accuracy across heterogeneous platforms | A-16 uses a per-platform constant; real energy varies with workload mix |

---

# 32. COMPLIANCE WITH THE CRITICAL RULES

| Rule | Compliance |
|---|---|
| 1. Do not implement software | ✅ No code. Schemas, state machines, and contracts only. Formulas are specifications, not implementations |
| 2. Do not design the entire brain | ✅ Scope limited to the single cell and its contract. Network, workspace, regions, evolution algorithm, and immune system are referenced as **external authorities** with demand lists (§13.3), not designed |
| 3. Do not assume consciousness | ✅ No claim, no implication. §2.4's negative specification and the awareness discussion in audit §N are preserved. The cell is a **transducer**, explicitly not an agent |
| 4. Do not claim AGI | ✅ No capability claim anywhere. §26 concludes the cell is a *bounded local probabilistic estimator* |
| 5. No vague biological metaphors as mechanism substitutes | ✅ V3 §5's nine organelles are **mapped to named functional blocks or dropped** (§5.3): 6 retained as mechanisms, 1 split, 1 relocated, **2 dropped** (ribosome, ER). "Neuron-like" is generalized to a specified 10-stage pipeline |
| 6. Do not silently invent requirements contradicting V3/V3.1 | ✅ Every departure is tagged **[V4]** with rationale. **Three structural relocations** are flagged explicitly at §1, §3.2, §8.1, §16.1, §18.2: safety layer → EIK; replication authority → EIK; protected memory → EIK; microglial immune function → EIK. All other V3/V3.1 content is retained and formalized |
| 7. Distinguish existing / proposed / assumed / unresolved | ✅ **[V3] [V3.1] [V4] [A] [U]** tags used throughout; §1 disposition table; §27.3 and §31 consolidate open items |
| 8. Every important variable has defined semantics | ✅ §4: **~110 state variables**, each with meaning, type, range, write authority, persistence, observability. No variable is described as "high" or "low" without a representation |
| 9. Every important mechanism has a measurable trigger or outcome | ✅ §9.2 (8 triggers with exact conditions), §10.1 (10 detectors with evidence artifacts), §14.2–14.4 (creation/strengthening/removal conditions), §16.3 (16 gates with exact conditions), §17.2 (transition thresholds), §19.3 (utilization bands) |
| 10. Every safety mechanism has an authority boundary | ✅ §24.2 allocation principle; §18.2 authority matrix; §16.1–16.2; §7.3 attestation restrictions; §12.2 K-written evaluative fields. **24 of 28 invariants are EIK-enforced** |
| 11. Every confidence mechanism has a producer and calibration mechanism | ✅ §11.3 producer table (9 stages, each with a named producer and location); §11.4 increase/decrease authority matrix; §11.2 calibration factor; T8 recalibration trigger; `ece_rolling`/`brier_rolling` |
| 12. Every adaptive mechanism has a stability mechanism | ✅ §9.4 four bounds; §9.5 seven stability mechanisms; I-17, I-18; homeostatic normalization mandatory; `DELTA_BUDGET`; `plasticity_mult` K-controlled |
| 13. Every evolutionary mechanism has a measurable selection criterion | ✅ §16.3 sixteen gates each with a measured condition, measuring authority, and evidence source; weighted-lottery decision rule; zero-sum G13 |
| 14. Learned state distinguishable from inherited genome | ✅ §3.3 nine-way separation by **storage location, write authority, and persistence class**; §3.4 definitive heritability answer; §3.5 machine-checkable rejection list; I-8 |
| 15. Rare but valuable strategies not automatically eliminated | ✅ §17.6 five mechanisms; **dormancy state added** (absent from V3); Capability Registry exemption; MAP-Elites archive; behavioural-entropy halt. Residual honestly marked [U-5] |
| 16. Do not make every cell a full general-purpose AI | ✅ §26 in full. **19 capabilities relocated out of the cell**; belief origination restricted to C2+; §2.4 negative specification; the participating cell is 10⁴× the minimal cell, which is what makes the variant model necessary |
| 17. Prefer the smallest mechanism satisfying the requirement | ✅ Conjugate epistemic head instead of an ensemble (O(D) vs O(k·D), and *more* auditable); `fate_bias` softmax instead of a differentiation program; Merkle refs instead of provenance copies; dormancy instead of active redundancy for rare roles; degenerate stages for C0/C1 instead of separate contracts |
| 18. Mark unresolved rather than invent false precision | ✅ **10 [U] items** (§27.3), **4 open research questions** (U-5, U-6, U-7, U-9), every [A] assumption flagged, §5.4 numeric ranges explicitly marked as assumptions requiring calibration |
| 19. External invariant kernel treated as a separate architectural question | ✅ **The governing principle of the whole document.** §24.2: *a cell-level check is a courtesy; an EIK-level check is a guarantee.* The safety layer is **relocated out of the cell** (§1, §3.2 A). The cell contains no safety layer; **the cell is subject to one** |
| 20. Be adversarial | ✅ §25: 15 attacks fully analyzed with attack path, vulnerable component, detection, containment, recovery, verdict, and residual risk. **Honest scoring: 2 CONTAINED-low, 6 CONTAINED/BOUNDED low-medium, 5 PARTIAL/BOUNDED medium-high, 2 PARTIAL with fundamental (non-architectural) HIGH residual.** §26 is an adversarial minimality test that concludes V3's cell design is infeasible. §27 finds 24 real ambiguities |

---

# 33. THE FINAL STANDARD

> **«Two competent engineering teams can independently implement a Nano-AI cell and have their cells interoperate within the same Digital Brain without needing undocumented assumptions.»**

## Verdict: **MET for the contract. NOT MET for the parameterization.**

### MET — interoperation

Given this specification plus `04_formal_schemas.md` and `05_state_machine.md`, two independent teams **can** build cells that interoperate, because every interoperation-relevant degree of freedom is pinned:

- **Wire format:** CBOR deterministic encoding, canonical key ordering, explicit signature coverage (A-1, A-3)
- **Types:** closed Type Registry with `TypeRef` resolution; unknown ⇒ reject (A-1)
- **Enums:** all 12 closed enums with explicit numeric assignments; unknown ⇒ reject, never coerce (A-11)
- **Envelope:** no optional fields (A-2)
- **Time:** three clocks with defined semantics and skew handling (A-4)
- **Numerics:** IEEE-754, round-to-nearest-even, no fast-math, declared clamping (A-5)
- **RNG:** xoshiro256**, EIK-seeded, serialized state (A-6)
- **Crypto:** Ed25519 signatures, BLAKE3 hashes (A-7, A-8)
- **Epistemics:** conjugate family fixed per output kind; explicit formulas; kernel parameters read not chosen (A-9, A-10)
- **State machine:** 18 closed states, 41 enumerated transitions, each with trigger/authority/evidence/delta/rollback (`05_state_machine.md`) (A-20)
- **Learning:** explicit update equation, trace form, clipping, normalization (A-14, I-18)
- **Trust:** explicit `Beta` update, discount, cap, prior (A-24)
- **Eviction/dedup/tie-breaking:** all specified (A-12, A-13, A-15, A-22)
- **Serialization:** `CellSnapshot` format, hashed, versioned (A-19)
- **Invariants:** 28, each with an enforcement level and a violation response (§24)
- **Conformance suite:** 62 tests with numeric pass conditions (`06_test_suite_and_ablations.md`)

**Two teams passing the conformance suite will interoperate.** The suite *is* the interoperability definition — and it is executable, not descriptive.

### NOT MET — parameterization

**What prevents it, precisely:**

1. **No target tasks exist** (G-P0-1). "Correctly sized," "correctly thresholded," and "correctly bounded" are all task-relative. Two teams would build interoperable cells whose `θ_abstain`, `θ_write`, `θ_pe`, `WM_CAP`, `EPI_CAP`, `param_count_cap`, and variant cost ranges are all **arbitrary**. Interoperable ≠ correct.
2. **No EIK exists** (G-P0-2). 24 of 28 invariants are EIK-enforced and 40+ state fields are K-written. Teams could build conformant cells but **could not test the enforcement**, so conformance would be asserted rather than demonstrated.
3. **No published kernel parameter set** (G-P0-4). `constraint_set_hash` must match for interoperation; the set does not exist yet.
4. **No Type Registry contents** (G-P0-3).

**These are upstream dependencies, not defects in this specification** — and the dependency map (§30) shows the correct order of work.

### The honest bottom line

> **The Nano-AI cell is now formally specified to the point where two independent teams can build interoperable implementations and prove interoperability by passing a 62-test conformance suite.**
>
> **They cannot yet build *correctly parameterized* implementations, because correctness is task-relative and the tasks do not exist.**
>
> **Recommended sequence: (1) P0-01 task/environment/fitness definition → (2) stub EIK + published `constraint_set` → (3) Type Registry skeleton → (4) implement C0 and C2 → (5) run the conformance suite → (6) calibrate thresholds and variant ranges empirically → (7) proceed to P0-04 transport and P0-06 calibration engine.**
>
> **Implementing cells before step 2 would produce untestable code against 24 externally-enforced invariants.** That is the single most important sequencing conclusion of this document.

---

*End of Volume A. Continue to `03_v4_cell_contract_spec.md` (Volume B — Output 20, the clean canonical specification).*
