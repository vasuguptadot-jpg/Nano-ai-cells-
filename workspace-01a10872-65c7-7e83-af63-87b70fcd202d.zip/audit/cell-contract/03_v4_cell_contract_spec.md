# V4 — Nano-AI Cell Contract v1.0

**Status:** CANONICAL SPECIFICATION · normative
**Supersedes:** V3 §4 (Nano-AI Cell), §5 (Digital Organelles), §6 (Neuron-like Cell), §8 (Digital Synapse, cell-side), §11 (Memory, cell-side), §15 (Learning vs Evolution, cell-side); V3.1 §3 (Self-State, cell-side), §4 (Error Awareness, cell-side), §6 (Plasticity, cell-level)
**Companion (non-normative rationale):** `02_cell_contract_analysis.md`
**Companion (normative):** `04_formal_schemas.md`, `05_state_machine.md`, `06_test_suite_and_ablations.md`
**Contract version:** `1.0` · **Requires:** External Invariant Kernel (EIK) ≥ 1.0 · Type Registry ≥ 1.0

> **Normative language.** MUST / MUST NOT / REQUIRED / SHALL = mandatory for conformance. SHOULD = recommended; deviation requires a recorded rationale. MAY = optional.
>
> **Conformance definition.** An implementation is conformant iff it passes every applicable test in `06_test_suite_and_ablations.md` §1–§8 with the stated pass condition. Conformance is binary and is established by the executable suite, not by self-declaration.

---

## 0. SCOPE AND NON-SCOPE

### 0.1 In scope
A single Nano-AI cell: what it is, what state it holds, what interfaces it exposes, what it may and may not do, and what guarantees the rest of the organism MAY rely upon.

### 0.2 Out of scope — explicitly
The communication network · the global workspace · brain regions · the evolutionary algorithm · the immune system's adjudication logic · the organism self-model · the fitness function · task definitions. Where this contract requires an external service, it states a **demand** (§13.3, §14.2) and does not design it.

### 0.3 Non-claims
This contract makes **no claim** of consciousness, subjective experience, awareness, AGI, or general intelligence. A conformant cell is a bounded local probabilistic estimator. Nothing in this document should be read as implying otherwise.

---

## 1. DEFINITION

> ### 1.1 A Nano-AI Cell is a cryptographically-identified, resource-bounded, typed probabilistic transducer with bounded memory and bounded plasticity, executed as a single-addressable actor, whose heritable structure is externally owned and whose epistemic state is externally auditable.

### 1.2 Negative definition — a cell is NOT

A cell is **NOT**: an agent (no self-chosen goals) · a reasoner (no multi-step inference) · a planner (no action sequencing) · a verifier of its own claims · a self-replicator · its own immune authority · a memory authority for shared/protected stores · a trust authority · a calibration authority · a consciousness candidate.

### 1.3 The governing separation

> **A cell REPORTS. The organism INTERPRETS. The kernel ENFORCES.**

Every evaluative judgement about a cell — its reliability, its calibration, its trustworthiness, its eligibility, its health verdict, its improvement verdict — is produced **outside** the cell and written into K-only state fields. A cell produces observations about itself; it never produces verdicts about itself.

---

## 2. NORMATIVE REFERENCES AND CONVENTIONS

### 2.1 External references
RFC 8949 (CBOR), incl. §4.2 deterministic encoding · RFC 8032 (Ed25519) · BLAKE3 · UUIDv7 · IEEE-754 binary32/binary64.

### 2.2 Type notation
`[T]` list · `{K:V}` map · `⟨A|B⟩` tagged union · `u8/u16/u32/u64`, `i32/i64` · `f32/f64` (IEEE-754, round-to-nearest-even) · `bytes<n>` fixed octet string · `enum Name` (closed, with explicit numeric assignments per `04_formal_schemas.md`) · `TypeRef = {registry_id: u16, schema_version: u16}`.

### 2.3 Write-authority classes
**C** — the cell may write · **K** — EIK only · **O** — organism-level service only · **C↑** — cell may write monotonically increasing · **C↓** — cell may write monotonically decreasing · **C(gated)** — cell may write subject to a stated kernel-checked gate.

A field's authority class is part of its definition. **An implementation MUST reject any attempt to write a field outside its authority class, and MUST report the attempt as `E_INVARIANT_AUTHORITY` (S3).**

### 2.4 Kernel parameters
All numeric constants named `θ_*`, `*_MAX`, `*_CAP`, `*_MIN`, `F_max`, `d_min`, `λ_*`, `α₀`, `β₀` are **EIK-published kernel parameters**, versioned inside the signed `constraint_set` referenced by `identity.constraint_set_hash`. Implementations MUST read them and MUST NOT choose them. **Two cells may interoperate only if their `constraint_set_hash` values match.**

---

## 3. IDENTITY

### 3.1 Fields

| Field | Type | Authority | Persistence | Observability |
|---|---|---|---|---|
| `cell_id` | `bytes<16>` UUIDv7 | **K, written once** | permanent | public |
| `cell_pubkey` | `bytes<32>` Ed25519 | **K, written once** | permanent | public |
| `lineage_id` | `bytes<32>` | **K, once** | permanent | public |
| `generation` | `u32`, `≤ GEN_MAX` | **K, once** | permanent | public |
| `parent_cell_id` | `⟨bytes<16>|null⟩` | **K, once** | permanent | public |
| `parent_genome_hash` | `bytes<32>` | **K, once** | permanent | public |
| `recombination_parents` | `[bytes<32>]`, `len ≤ 2` | **K, once** | permanent | public |
| `variant` | `enum{C0,C1,C2,C3,C4}` | **K, once — immutable for the cell's life** | permanent | public |
| `variant_version` | `u16` | **K, once** | permanent | public |
| `contract_version` | `u16` (major.minor packed) | **K, once** | permanent | public |
| `genome_hash` | `bytes<32>` BLAKE3 | **K, once** | permanent | public |
| `constraint_set_hash` | `bytes<32>` BLAKE3 | **K, once** | permanent | public |
| `birth_certificate` | `bytes<64>` EIK signature over all the above | **K, once** | permanent | public |
| `region_id` | `⟨bytes<16>|null⟩` | **O** | checkpointed | public |
| `role` | `enum RoleCode` (16 values) | **O, gated** | checkpointed | public |
| `created_at` | `u64` ns | **K, once** | permanent | public |
| `lifecycle_state` | `enum LifecycleState` (18 values) | **K-mediated** | checkpointed | public |
| `integrity_checksum` | `bytes<32>` rolling BLAKE3 | **C computes, K verifies** | checkpointed | EIK |

### 3.2 Requirements

- **R3.1** All K-once fields MUST be written exactly once, at instantiation, by the EIK, and MUST be covered by `birth_certificate`.
- **R3.2** A cell MUST NOT modify any K-once field. Any attempt MUST be reported as `E_INVARIANT_AUTHORITY` (S3) and MUST trigger self-suspension.
- **R3.3** Every emitted message MUST carry `src = {cell_id, lineage_id, generation, variant, role, region_id}` and a signature verifiable against a certificate chained to the EIK Identity Root.
- **R3.4** A receiving cell MUST reject any message whose `src` does not match a valid birth certificate, or whose `cell_id` is tombstoned, or whose `contract_version` major differs from its own.
- **R3.5** `integrity_checksum` MUST be recomputed over the canonical serialization of the protected blocks (`Identity`, `GenomeRef`, `Phenotype.port_schema`, `EpistemicState`) at every checkpoint and at least once per `INTEGRITY_CHECK_INTERVAL` epochs.

---

## 4. GENOME

### 4.1 Location
**The genome is NOT stored in the cell.** The cell holds `genome_hash` only. The genome artifact resides in the EIK-adjacent Genome Store and is written **only** by the Replication Authority.

### 4.2 Structure (normative)

```
Genome {
  schema_version        : u16
  genome_id             : bytes<32>                    // BLAKE3 of canonical serialization
  signature             : bytes<64>                    // EIK Genome Authority
  parent_hashes         : [bytes<32>]                  // ≤ 2

  constraint_set_ref    : bytes<32>                    // POINTER to EIK constraint set.
                                                       // Constraints are NOT genome content.

  architecture {
    variant_family      : enum{C0..C4}
    stage_config        : [StageSpec]                  // 10 entries, one per pipeline stage
    port_schema         : [PortSpec]                   // typed, closed TypeRefs
    hidden_dim          : u32   ∈ [H_MIN, H_MAX]
    ensemble_size       : u8    (0 permitted for C0/C1 only)
    max_connections     : u16                          // in-degree cap
    max_fanout          : u16                          // out-degree cap
    param_count_cap     : u32                          // HARD CAP
    substrate           : enum{NN, GBM, BAYES_CONJUGATE, SYMBOLIC, LOOKUP, HYBRID_DECLARED}
  }

  param_init {
    distribution        : enum{GAUSSIAN, UNIFORM, TRUNCATED_GAUSSIAN, XAVIER,
                               FROM_PARENT_PERTURBED, ZERO}
    params              : {per-distribution parameters}
    rng_seed_class      : enum{EIK_ISSUED}             // the ONLY permitted value
  }

  development {
    reaction_norm       : [FateBias]                   // reachable RoleCodes + bias weights
    morphogen_receptors : [ReceptorSpec]
    critical_periods    : [Window]
    commitment_schedule : CommitmentCurve
    bootstrap_fate      : RoleCode                     // generation 0 only
  }

  mutable_traits {
    learning_rates      : map<TimescaleClass, f32>     // each ∈ [lr_min, lr_max]
    plasticity_rates    : map<PlasticityLevel, f32>    // each ≤ PR_MAX
    memory_policy       : {capacities, retention_curves, eviction, θ_write, θ_recall}
    comm_policy         : {emission_rate_cap, fanout_cap, priority_bias}
    uncertainty_policy  : {epistemic_update_rule, decay_half_life, θ_abstain, θ_ood}
    trust_policy_params : {context_partitioning}       // α₀, β₀ are kernel params, not genes
  }

  mutation_rules {
    permitted_operators : [OperatorID]                 // CLOSED SET, EIK Operator Registry
    per_operator_rate   : map<OperatorID, f32>         // each ≤ RATE_MAX
    max_effect_size     : f32
    recombination_mask  : [bool]
    FORBIDDEN_BLOCKS    : [constraint_set_ref, signature, genome_id, schema_version]
  }

  complexity_budget : {param_cap, connection_cap, genome_bytes_cap}
}
```

### 4.3 Heritability — normative

**R4.1 HERITABLE:** exactly the genome artifact — `architecture`, `param_init`, `development`, `mutable_traits`, `mutation_rules`, `complexity_budget`, and `constraint_set_ref`.

**R4.2 NOT HERITABLE:** developed architecture · learned parameters `θ` · `h` · `role` · `dev_stage` · any memory content · connection weights or the connection table · trust values · calibration statistics · epistemic sufficient statistics · resource history · runtime state · RNG seeds · any observation the cell has made · any self-assessment.

**R4.3** Parameters are inherited as a **distribution** (`param_init`). An offspring MUST sample `θ₀ ~ param_init`. An offspring MUST NOT receive its parent's acquired `θ`.

**R4.4** RNG seeds MUST be EIK-issued per cell and MUST NOT be heritable.

**R4.5** The Replication Authority MUST reject any candidate genome diff that encodes: a specific `θ` vector; a specific memory item or belief; a specific connection table; a specific trust value; a specific calibration statistic; an RNG seed; a role *assignment* (roles are reachable via `reaction_norm`, never assigned); a resource entitlement; or any modification to `FORBIDDEN_BLOCKS`.

**R4.6** The only path by which cell-local content survives the cell is §10.5 knowledge extraction, which is a **memory-system** operation, requires Memory Authority approval and provenance validation, and MUST NOT write to any genome.

### 4.4 Instantiation
On instantiation the cell MUST: read the genome via `genome_hash`; verify `signature` and `constraint_set_ref`; develop the phenotype (`architecture_realized`, `port_schema`, `θ₀ ~ param_init`); verify `param_count ≤ param_count_cap`, `hidden_dim ≤ H_MAX`, degrees within caps; compute `integrity_checksum`; enter `INSTANTIATED`. **If any verification fails, the cell MUST refuse to instantiate and MUST report `E_GENOME_INTEGRITY` (S4).**

---

## 5. COMPUTATIONAL CORE

### 5.1 The 10-stage pipeline (normative order)

| # | Stage | C0 | C1 | C2 | C3 | C4 |
|---|---|---|---|---|---|---|
| **S1** | Ingress & Validate | ✅ | ✅ | ✅ | ✅ | ✅ |
| **S2** | Gate & Filter | ✅ | ✅ | ✅ | ✅ | ✅ |
| **S3** | Aggregate | ✅ | ✅ | ✅ | ✅ | ✅ |
| **S4** | Transform | degenerate | degenerate | ✅ | ✅ | ✅ |
| **S5** | Uncertainty Production | degenerate | pass-through | ✅ | ✅ | ✅ |
| **S6** | Abstention Decision | invalid-input only | invalid-input only | ✅ | ✅ | ✅ |
| **S7** | Egress Package & Sign | ✅ | ✅ | ✅ | ✅ | ✅ |
| **S8** | Emit | ✅ | ✅ | ✅ | ✅ | ✅ |
| **S9** | Memory Update | cache only | ✅ rich | ✅ | ✅ | ✅ |
| **S10** | Bounded Learning & Self-Monitor | checksum only | minimal | ✅ | ✅ | ✅ |

**R5.1** The stage order is invariant. In particular: **S1 MUST complete before S3** (unauthenticated input never reaches computation); **S5 MUST complete before S6** (abstention is evidence-based); **S7 MUST complete before S8** (nothing unattributable is emitted).

**R5.2** A stage marked *degenerate* MUST still execute and MUST produce the contract-defined degenerate values (§5.4). It MUST NOT be omitted.

### 5.2 Stage requirements

**S1 Ingress & Validate.** MUST, for every input: resolve `payload_type` against the Type Registry; verify length ≤ limit; verify signature against a birth-certificate chain; verify `ttl` and `epoch`; de-duplicate by `msg_id`; verify every `provenance.evidence_roots` entry resolves in the Provenance Anchor; for `EVALUATIVE`/`SYSTEM`/`SAFETY` classes verify an EIK counter-signature. MUST handle all eight fault conditions of §7.3 deterministically and MUST produce an `ErrorEvent` for each. **MUST NOT silently discard any input.**

**S2 Gate & Filter.** MUST apply a relevance gate and MUST apply a refractory period preventing recently-processed content from immediately re-entering. MUST drop below-threshold input and count the drop.

**S3 Aggregate.** MUST compute a weighted aggregation over inbound connections using `weight` and `context_sensitivity`, MUST apply inhibitory connections, and MUST bound the result: `‖agg‖ ≤ AGG_MAX`.

**S4 Transform.** `h', ŷ = f_θ(agg, h, wm)`. Substrate-free. MUST satisfy `‖θ‖ ≤ Θ_MAX` and `‖h‖ ≤ B_H`. MUST be deterministic given `(θ, agg, h, wm, rng_state)`.

**S5 Uncertainty Production.** MUST compute `aleatoric_var` from a heteroscedastic head; MUST update `s1`, `s2`, `n_obs` per §9; MUST compute `epistemic_var = g(s1, s2, n_obs)` per §9.2; MUST update `evidence_roots`. **MUST NOT count self-sourced observations** (§8.4).

**S6 Abstention.** MUST abstain if **any** of: `epistemic_var > θ_abstain` · `inbreeding_F > F_max` · input unauthenticated · `ood_score > θ_ood` · `throttle_level ≥ HARD` · invariant violation detected. **This is a disjunction, not a weighted sum** — order-independent and reproducible. `AbstainCode` MUST be the lowest-numbered satisfied condition.

**S7 Package & Sign.** MUST construct a complete `OutputEnvelope` (§7.1) with no absent mandatory field; MUST compute `cost_declared`; MUST attach provenance; MUST sign per §2.1 canonical serialization.

**S8 Emit.** MUST enqueue subject to the token bucket; MUST respect `max_fanout`; MUST honour backpressure; MUST NOT block on any acknowledgement.

**S9 Memory Update.** MUST write a working-memory item; MUST conditionally write episodic per §8.3; MUST evict per policy; MUST enqueue consolidation candidates.

**S10 Bounded Learning & Self-Monitor.** If a §8.2 trigger fired: compute eligibility-weighted `Δθ`, clip, check budget, apply, tag for rollback, **then apply homeostatic normalization (R5.3)**. Then: run invariant self-checks, update health fields, recompute `integrity_checksum` if due.

**R5.3 (MANDATORY)** After every parameter update the cell MUST apply homeostatic normalization: `θ ← θ · (A_target / A_current)^κ`, keeping total activity within `[0.8·A_target, 1.25·A_target]`. **An implementation without homeostatic normalization is non-conformant regardless of other behaviour.**

### 5.3 Computational bounds

| Variant | `param_count_cap` | `hidden_dim` | `ensemble_size` | Cost/invocation | Memory |
|---|---|---|---|---|---|
| C0 | 0 – 10³ | 0 – 16 | 0 | ~10 KFLOP | ~10 KB |
| C1 | 10² – 10⁴ | 8 – 64 | 0 | ~1 MFLOP | ~1 – 4 MB |
| C2 | 10³ – 10⁶ | 32 – 512 | 0 (conjugate head) | ~100 MFLOP | ~5 MB |
| C3 | 10³ – 10⁶ | 32 – 512 | 0 – 4 | ~200 MFLOP | ~5 MB |
| C4 | 10⁵ – 10⁹ | 256 – 4096 | 0 – 8 | ~1 – 10 GFLOP | ~50 – 500 MB |

**R5.4** These are **hard caps**, not fitness penalties. They MUST be verified at instantiation and at every checkpoint. *(Ranges are provisional pending task definition — see §16, G-P0-1.)*

---

## 6. STATE

The complete state schema, with authority, persistence, and observability for all ~110 fields, is normative in `04_formal_schemas.md` §3. Summary of the eleven blocks:

| Block | Contents | Notable authority constraints |
|---|---|---|
| `ComputationalState` | `h`, `activation`, `stage`, `invocation_seq`, `epoch`, `rng_state` | `epoch` K-only; `invocation_seq` C↑ |
| `MemoryState` | `wm`, occupancy, episodic counts/bytes, retrieval confidence, evictions, consolidation queue | all C↑ or C |
| **`EpistemicState`** | `n_obs`, `s1`, `s2`, `evidence_roots`, `lineage_depth_of_evidence`, `inbreeding_F`, `epistemic_var`, `aleatoric_var`, `abstain`, `abstain_reason`, `calibration_class`, `ece_rolling`, `brier_rolling`, `n_calibration_samples` | **`n_obs`, `s1`, `s2`, `evidence_roots`, `epistemic_var`, `aleatoric_var` cell-written but K-audited. `inbreeding_F`, `calibration_class`, `ece_rolling`, `brier_rolling`, `n_calibration_samples` are K-ONLY** |
| `PredictiveState` | `last_prediction`, `prediction_horizon`, `open_predictions`, `assigned_objective`, `assigned_task`, `objective_source` | **`assigned_*` are O-ONLY. A cell has no self-chosen objective** |
| `ResourceState` | `budget`, `consumed`, `budget_utilization`, `budget_window`, `cost_declared_last`, `cost_measured_last`, `cost_declaration_error`, `throttle_level` | `budget`, `cost_measured_last`, `cost_declaration_error`, `throttle_level` K-ONLY |
| `HealthState` | `health_score`, `error_rate_rolling`, `failure_count_lifetime`, `consecutive_failures`, `invariant_violations`, `last_invariant_check`, `integrity_checksum`, `state_consistency_flag`, `uptime_epochs`, `degradation_trend` | **all K-computed except `invariant_violations` (C↑) and `integrity_checksum` (C computes, K verifies)** |
| `TrustState` | `trust_in[peer]` (Beta per context), `trust_cap`, `trust_out_assigned` | `trust_out_assigned` K-ONLY; `trust_cap` K-ONLY |
| `ConnectionState` | `connections[]`, degrees, `pending_handshakes` | C, gated by the §11.2 handshake |
| `ErrorState` | `error_log[]`, `open_errors` | C↑ |
| `LearningState` | `eligibility_traces`, `learning_enabled`, `plasticity_multiplier`, `update_count`, `cumulative_delta_norm`, `last_update_provenance[]`, `learning_suspended_reason`, `improvement_verified` | **`learning_enabled`, `plasticity_multiplier`, `learning_suspended_reason`, `improvement_verified` K-ONLY** |
| `DevelopmentalState` + `ReplicationState` | `dev_stage`, `fate_bias`, `morphogen_readings`, `niche_slot`, `replication_eligibility{g1..g16}`, `replication_proposal_count`, `replication_authority_ticket`, `offspring_count`, `retirement_scheduled` | **`dev_stage`, `niche_slot`, all replication fields: K/O-ONLY. The cell READS its eligibility; it cannot write it, grant it, or act on it** |

**R6.1** A cell MUST be able to serialize its complete state to a `CellSnapshot` (§14) and MUST be able to restore from one. **No opaque state is permitted.**

**R6.2** A cell MUST expose its complete state to the EIK on request. There is no private state.

---

## 7. OUTPUT CONTRACT

### 7.1 `OutputEnvelope` (normative; no optional fields)

```
OutputEnvelope {
  msg_id          : bytes<16> UUIDv7                            M
  conv_id         : bytes<16>                                   M
  epoch           : u64                                         M
  ts              : u64 ns Unix UTC                             M
  ts_mono         : u64 ns monotonic                            M
  ttl             : u16 hops                                    M
  message_type    : enum MessageType (34 values)                M
  src             : {cell_id, lineage_id, generation, variant,  M
                     role, region_id}
  dst             : ⟨CellID | RegionID | CapabilityQuery |      M
                     BroadcastScope⟩
  prio            : u8 [0..7]                                   M
  payload         : typed, TypeRef-resolved, ≤ MSG_BYTES_MAX    M
  payload_type    : {registry_id: u16, schema_version: u16}     M
  provenance      : {self_ref: bytes<32>,                       M
                     evidence_roots: [bytes<32>] (SET, sorted,
                       len ≤ 32, no duplicates),
                     derivation_depth: u16}
  uncertainty     : {aleatoric_var: f32[D], epistemic_var: f32[D],
                     n_obs: u64, s1: f64[D], s2: f64[D]}        M
  confidence      : {value: f32 ∈ [0, TRUST_MAX],               M
                     calibration_class: enum,
                     produced_by: enum{CELL_DERIVED,
                                       KERNEL_CALIBRATED}}
  cost            : {flops: u64, bytes: u32, wall_us: u32,      M
                     energy_uJ: u64}
  causality       : compressed vector clock (§2.4/A-18)         M
  seq             : u32 per (src, dst, conv_id)                 M
  signature       : bytes<64> Ed25519                           M
  abstention      : ⟨null | {code: enum AbstainCode (9),        C
                             detail: TypeRef}>
  verification_claim : ⟨null | VerificationClaim⟩               C
  contest         : ⟨null | ContestRef⟩                         C
  countersignature : ⟨null | bytes<64>⟩                         C
}
M = mandatory · C = conditionally present with an explicit null discriminator
```

**R7.1** There are **no optional fields.** Every field is mandatory or conditionally-present-with-null-discriminator.

**R7.2** `signature` MUST be Ed25519 over the CBOR deterministic encoding (RFC 8949 §4.2) of all fields except `signature` and `countersignature`.

**R7.3** `confidence.value ≤ TRUST_MAX = 0.95` **always**. A value of 1.0 is a violation of I-27.

**R7.4** For C0/C1, `uncertainty` MUST be degenerate: `n_obs = 0`, `epistemic_var = EV_MAX`, `s1 = s2 = 0`. **A cheap relay cell MUST declare maximum epistemic uncertainty.**

### 7.2 Permitted emissions by variant

| `message_type` group | C0 | C1 | C2 | C3 | C4 |
|---|---|---|---|---|---|
| `RELAY`, `AGGREGATE_SUMMARY` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `REPORT_UNCERTAINTY`, `REPORT_ERROR`, `REPORT_HEALTH`, `REPORT_SELF_STATE`, `REPORT_ANOMALY`, `REPORT_DAMAGE` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `SAFETY_ALERT`, `VIOLATION_REPORT` | ✅ **permissionless, never throttled** | ✅ | ✅ | ✅ | ✅ |
| `QUERY`, `REQUEST_RESOURCE`, `REQUEST_CONNECTION`, `REQUEST_QUARANTINE`, `REQUEST_REPAIR`, `REQUEST_ATTENTION` | ✅ | ✅ | ✅ | ✅ | ✅ |
| **`ASSERT`, `CLASSIFY`, `ESTIMATE`, `PREDICT`, `PROPOSE_HYPOTHESIS`, `PROPOSE_ACTION`, `RECOMMEND_ACTION`, `ANNOUNCE_UPDATE`, `PROPOSE_MEMORY_WRITE`, `PROPOSE_REPLICATION`, `CONTEST`** | ❌ | ❌ | ✅ | ✅ | ✅ |
| **`ATTEST_VERIFIED`** | ❌ | ❌ | ❌ | ✅ **+ mandatory EIK countersignature** | ❌ |

**R7.5 (BELIEF-ORIGINATION RESTRICTION)** C0 and C1 MUST NOT emit any belief-origination message type. This is a structural safety property: the cheap cells that make constrained-hardware deployment viable cannot originate claims.

**R7.6 (ATTESTATION RESTRICTION)** `ATTEST_VERIFIED` MUST satisfy all four: (i) `src.variant == C3`; (ii) `src.role ∈ {VERIFIER}`; (iii) an EIK Verification Authority `countersignature` is present; (iv) `verification_claim.verifier_set` does not contain `src.cell_id` and every member is at lineage distance ≥ `d_min` from the original asserter. **A message failing any of the four MUST be rejected by receivers.**

### 7.3 The three (four) semantic distinctions — normative

These are **distinct message types with distinct producers, authorization, and downstream effects.** An implementation MUST NOT collapse them.

**(a) «This cell believes X»** → `ASSERT` / `CLASSIFY` / `ESTIMATE`
Semantics: *"Cell C, given evidence roots R, assigns predictive probability `confidence.value` to X."*
Downstream: MAY contribute to aggregation, weighted by **kernel-assigned** `trust_out_assigned` and **de-duplicated by `evidence_roots`**. MUST NOT be treated as fact. MUST NOT enter protected memory. MUST NOT satisfy a verification requirement.

**(b) «This cell recommends action Y»** → `RECOMMEND_ACTION`
Payload: `{action, expected_utility, utility_basis: ObjectiveRef, risk_estimate, alternatives_considered, reversibility}`.
Semantics: *"C estimates Y maximizes the ASSIGNED objective `utility_basis`."*
Downstream: routed to organism action selection. **A recommendation is not an action and confers no authority.** `utility_basis` MUST name an externally assigned objective — never a self-chosen one.

**(c) «This cell claims X is externally verified»** → `ATTEST_VERIFIED`
Payload: `{claim, verification_ref, verifier_set, independence_proof, external_ground_truth_ref: ⟨ref|null⟩, method}`.
Downstream: MAY enter protected memory; MAY satisfy verification requirements; MAY raise dependent confidence **through the Calibration Authority only**.
Restrictions: R7.6. `external_ground_truth_ref` MUST resolve in the EIK Ground-Truth Anchor or the attestation MUST be rejected.

**(d) «This cell predicts X»** → `PREDICT`
Payload: `{predicted_observation, horizon, resolution_deadline}`.
Semantics: **a testable commitment.** MUST be registered in `open_predictions` and MUST be resolved against observation. **An unresolved prediction past `resolution_deadline` MUST count as a calibration failure.**

---

## 8. INPUT CONTRACT

### 8.1 `IngressBundle`
A cell MUST receive information **only** via `IngressBundle` (schema in `04_formal_schemas.md` §4). Any side-channel input path is a conformance violation. The bundle carries `[Message]` (`≤ MSG_BATCH_MAX`) plus **kernel-injected control inputs the cell MUST NOT forge**: `budget_snapshot`, `throttle_level`, `plasticity_mult`, `learning_enabled`, `calibration_class`, `morphogen_readings`, `assigned_objective`, `quarantine_flags`.

### 8.2 Authority classes of input
`EVALUATIVE` (reward, error feedback, outcomes), `SYSTEM` (budget, immune, calibration, lifecycle), and `SAFETY` inputs MUST carry an **EIK signature**. A cell signature on such a message is **structurally invalid** and MUST be rejected at S1. This closes reward forgery at the type level.

### 8.3 Learning triggers — closed set (8)

| ID | Trigger | Exact condition | Variants | Gate |
|---|---|---|---|---|
| **T1** | Prediction error | `‖ŷ − y‖ > θ_pe` AND the prediction was registered AND the outcome is externally signed | C2+ | `learning_enabled ∧ plasticity_mult > 0` |
| **T2** | Reward / penalty | EIK-signed `eval.reward.v1` received | C2+ | same |
| **T3** | Supervised correction | EIK- or C3-signed `eval.error.v1` with a `correction` field whose provenance resolves | C2+ | same |
| **T4** | Self-supervised signal | Internal consistency check fails (e.g. reconstruction residual > θ) | C2+ | same + **MUST NOT move `θ` in a direction that raises the cell's own reward** (kernel-checked) |
| **T5** | Novelty | `ood_score > θ_ood` | C2+ | **triggers SLOW_MODE: `plasticity_mult` REDUCED, abstention raised, evidence gathering requested. NOT immediate learning** |
| **T6** | Repeated success | success rate > θ over ≥ N consecutive resolved predictions | C2+ | **triggers a consolidation candidate, NOT a large `Δθ`** |
| **T7** | Failure | `consecutive_failures ≥ θ_cf` | C2+ | **triggers `plasticity_mult` REDUCTION and `REPORT_DAMAGE`. NOT more learning** |
| **T8** | Calibration verdict | `calibration_class` transitioned to `MISCALIBRATED` | C2+ | **recalibrates the epistemic head only (`s1`, `s2` toward kernel reference). MUST NOT modify `θ`** |

**R8.1** T5 and T7 MUST reduce plasticity, not increase it. Learning harder in response to novelty or repeated failure is non-conformant.

### 8.4 Learning targets

**May change:** `θ` · connection weights · memory-policy params (C3+ only) · `h` · WM/episodic content · eligibility traces · epistemic sufficient statistics (kernel-audited).

**MUST NOT change, ever:** the genome · `role`, `dev_stage`, `niche_slot` · `budget`, `throttle_level`, `learning_enabled`, `plasticity_multiplier` · `calibration_class`, `trust_out_assigned`, `ece_rolling`, `brier_rolling` · `replication_eligibility`, `replication_authority_ticket` · port schemas · `assigned_objective`, `assigned_task` · all identity fields · any K-only field.

### 8.5 Update law (normative)

```
Δθ = clip( plasticity_multiplier          // K-written, ∈ [0,1]
         × lr[timescale]                  // genome trait, ∈ [lr_min, lr_max]
         × eligibility_trace              // e ← λ·e + ∂output/∂θ, clipped to ±E_MAX
         × error_signal                   // GATED: only EIK-signed signals are admissible
         × confidence_in_error            // do not learn loudly from uncertain feedback
         , −Δ_MAX, +Δ_MAX )

subject to:
  Σ_epoch ‖Δθ‖ ≤ DELTA_BUDGET             // structural-change budget
  ‖θ‖ ≤ Θ_MAX                             // absolute bound
  update_count ≤ UPDATES_PER_EPOCH_CAP
  homeostatic normalization applied after every update (R5.3)
  timescale ordering: lr_fast ≥ lr_medium ≥ lr_slow, kernel-enforced
```

**R8.2** A `REPORT_ERROR` emitted by a peer cell is **evidence for the organism**, never a learning signal for the cell. Only an EIK-signed `eval.error.v1` may drive `Δθ`. **This closes the attack in which a hostile cell floods a target with forged error signals and the target's plasticity destroys it.**

**R8.3** Every applied update MUST be tagged in `last_update_provenance` to a depth of `ROLLBACK_DEPTH`, enabling exact rollback.

### 8.6 Improvement verification
A cell MUST NOT self-assess whether learning helped. The verdict `improvement_verified ∈ {UNKNOWN, IMPROVED, NEUTRAL, REGRESSED}` is **K-only**, produced by comparing pre-update (replayed checkpoint) against post-update performance on a **held-out probe set the cell cannot read and cannot predict the schedule of**. On `REGRESSED` the kernel MUST automatically roll back via `last_update_provenance`. On `UNKNOWN` the update remains provisional and MUST NOT count toward replication gate G1.

---

## 9. UNCERTAINTY AND CONFIDENCE

### 9.1 Definitions
**Aleatoric uncertainty** — irreducible observation noise. `aleatoric_var = σ²_aleat(x)`, a heteroscedastic function of the input. **MUST NOT decrease with more data.**

**Epistemic uncertainty** — model/parameter uncertainty, reducible by evidence. `epistemic_var = g(s1, s2, n_obs)`, closed-form conjugate posterior variance.

### 9.2 The conjugate update (normative)
Family is fixed **per output kind** in the Type Registry:

| Output kind | Family | `epistemic_var` |
|---|---|---|
| Gaussian / real vector | Normal-Inverse-Gamma | `s2 / (n_obs · (n_obs − 1)) + epistemic_floor`, for `n_obs ≥ 2`; `EV_MAX` for `n_obs < 2`; clamped to `EV_MAX` |
| Categorical | Beta-Binomial | analogous closed form per class |
| Count | Gamma-Poisson | analogous closed form |

`epistemic_floor > 0` is a kernel parameter. **`epistemic_var` MUST be monotonically non-increasing in `n_obs` for stable `s2`** (I-24, kernel-checked).

**Rationale for conjugate statistics rather than an ensemble:** O(D) cost instead of O(k·D), which is what makes the minimal participating cell cheap enough for constrained hardware — **and it is strictly more auditable**, because the sufficient statistics are inspectable and recomputable, whereas an ensemble's spread is not.

### 9.3 Confidence computation (normative)

```
confidence_raw       = 1 − normalize(epistemic_var)                       ∈ [0,1]
provenance_quality   = q(inbreeding_F, external_fraction, root_independence) ∈ [0,1]
calibration_factor   = { UNCALIBRATED: 0.5, PROVISIONAL: 0.75,
                         CALIBRATED: 1.0,  MISCALIBRATED: 0.3, SUSPENDED: 0.0 }
confidence_pre_cap   = confidence_raw × provenance_quality × calibration_factor
confidence           = min(confidence_pre_cap, TRUST_MAX)                 TRUST_MAX = 0.95
```

### 9.4 Producer table

| Quantity | Producer | Location | Cell's right |
|---|---|---|---|
| `aleatoric_var` | cell (S5) | in-cell | produce |
| `s1`, `s2`, `n_obs` | cell (S5) | in-cell | produce — **kernel-audited for monotonicity and range** |
| `evidence_roots` | cell (S5) | in-cell | produce — **each MUST resolve in the Anchor or the output is rejected** |
| `epistemic_var` | cell computes; **EIK recomputes and verifies** | both | produce, audited |
| `inbreeding_F` | **EIK Provenance Anchor** | off-cell | **read-only** |
| `calibration_class`, `calibration_factor` | **EIK Calibration Authority** | off-cell | **read-only** |
| `provenance_quality` | **EIK** | off-cell | read-only |
| `confidence.value` | cell computes the arithmetic; **EIK validates and may override downward** | both | compute, **never inflate** |
| `trust_out_assigned` | **EIK Trust Authority** | off-cell | **read-only** |

**R9.1** The transport MUST recompute `confidence.value` from the received sufficient statistics and kernel factors on receipt. Divergence beyond `θ_conf_tol` is a violation of I-9: the message MUST be deflated to the recomputed value and the source flagged.

### 9.5 Who may change confidence

| Actor | Increase | Decrease |
|---|---|---|
| The cell, directly | **NEVER** | MAY, by honestly raising `epistemic_var` or abstaining |
| The cell, indirectly | **only** by acquiring new, resolvable, non-self-referential external evidence | MAY |
| EIK Calibration Authority | MAY (on sustained good calibration) | MAY (on failure) |
| EIK Trust Authority | MAY (`trust_out_assigned`) | MAY |
| EIK Provenance Anchor | MAY (via `provenance_quality`) | MAY (as `F` rises) |
| Any peer cell | **NEVER** | **NEVER** — peers may report; the kernel may act |

### 9.6 Independence and consensus (normative aggregation inputs)
The cell MUST supply, for every belief: `evidence_roots` (a **set**), `lineage_id`, `causality`. The organism's aggregation MUST:
1. de-duplicate evidence — `n_effective = |⋃ roots_i|`, **not** the number of asserting cells;
2. partition by lineage and genome distance ≥ `d_min` — `n_independent_lineages`;
3. discount by measured error correlation `ρ` — `effective_k = n_independent_lineages × (1 − ρ)`;
4. **cap consensus lift** — `conf_agg ≤ max_i(conf_i) + Δ_consensus`, `Δ_consensus` small.

**R9.2** Ten cells citing one source MUST contribute `n_effective = 1`. Ten siblings from one parent MUST contribute `n_independent_lineages = 1`. Cells with measured `ρ > θ_ρ` MUST contribute ≈ 0. **This operationalizes V3 §12's "consensus ≠ truth" as arithmetic rather than as a slogan.**

### 9.7 The minimum guarantee downstream systems MAY rely upon
1. `confidence ∈ [0, 0.95]`, never 1.0.
2. `confidence` is frequency-calibrated within `θ_ece` for `CALIBRATED` cells over ≥ `n_calib_min` resolved predictions on held-out probes.
3. `uncertainty` carries sufficient statistics, so the consumer can recompute and verify.
4. `evidence_roots` resolve in the Anchor, or the message is invalid.
5. `inbreeding_F` is present and kernel-computed; `F > F_max` ⇒ the message carries an abstention.
6. `calibration_class` is present and kernel-assigned.
7. `aleatoric` and `epistemic` are separate fields.
8. `ATTEST_VERIFIED` appears only with an EIK countersignature.
9. The message is signed and the signature verifies against a certificate chained to the Identity Root.
10. `cost` is present and independently metered; declared/measured divergence is available.

---

## 10. MEMORY, LIFECYCLE, RETIREMENT

### 10.1 Cell-local vs organism-level stores

| Store | Location | Note |
|---|---|---|
| Working memory | **IN CELL** | bounded ring, `WM_CAP` items |
| Local episodic | **IN CELL** | bounded; required for calibration and cause–effect correlation |
| Cache | **IN CELL** (C0/C1 primary) | **cache is never belief** (R10.3) |
| Learned `θ` | **IN CELL** | phenotype, **not heritable** |
| Self-history | **IN CELL** | own state/lifecycle/error history ring |
| Long-term episodic · semantic · procedural · associative · **protected** · lineage | **ORGANISM / EIK** | **A cell MUST NOT hold protected memory** |

**R10.1** V3 §11's nine memory types are retained as an *organism-level* taxonomy. At cell level only the five stores above exist. *(This is a flagged [V4] relocation: cell-writable protected memory is a history-rewriting vector.)*

### 10.2 Per-store requirements
Full table (capacity, write condition, read condition, retention, forgetting, compression, provenance, confidence, contradiction handling, corruption detection, recovery) is normative in `04_formal_schemas.md` §5. Key requirements:

- **R10.2** Every episodic item MUST carry `{source_refs, evidence_roots, derivation_depth}`. An item without resolvable roots MUST NOT be promoted to organism memory.
- **R10.3** Cache content MUST be marked `from_cache: true` in provenance, MUST be emitted as `RELAY`/`AGGREGATE_SUMMARY` (never `ASSERT`), and downstream confidence MUST be capped at `CONF_CACHE_MAX < CONF_FRESH_MAX`.
- **R10.4** Contradictory content MUST NOT overwrite. Both items are retained, a `ConflictRef` is emitted, and resolution is an organism function.
- **R10.5** Each store MUST maintain a Merkle root, recomputed at every checkpoint and verified by the EIK. A mismatch MUST produce `E_MEM_INTEGRITY` (S3) and self-suspension.
- **R10.6** Items tagged `capability_critical` MUST be exempt from eviction and from underuse-based forgetting.

### 10.3 False-memory resistance
A cell CAN fabricate local content. It CANNOT: fabricate provenance (roots must resolve — I-3); rewrite history undetected (Merkle root + externally anchored checkpoint-hash history); promote a fabrication to shared/protected memory (Memory Authority + provenance validation); or inflate confidence by self-recall (**R10.7**: retrieval from self-written memory MUST NOT increment `n_obs` and MUST NOT add new `evidence_roots`; it MUST increase `derivation_depth`).

### 10.4 Lifecycle
18 closed states, 41 enumerated transitions, each with trigger / authority / required evidence / state delta / rollback — normative in `05_state_machine.md`. Principal path:

```
UNINSTANTIATED → INSTANTIATED → DEVELOPING → CALIBRATING → PROBATIONARY
→ ACTIVE ⇄ { LEARNING_CONSOLIDATING | DEGRADED | THROTTLED | DORMANT |
              QUARANTINED | REPAIRING | RETIRING }
→ RETIRED → ARCHIVED → DELETED
```

**R10.8** Six removal-adjacent states are **distinct and MUST NOT be conflated**: temporary suspension · resource throttling · dormancy · quarantine · retirement · permanent deletion. They differ in reversibility, execution rights, emission rights, budget consumption, and authority.

### 10.5 Retirement protocol (7 ordered steps)
`NOTICE → DRAIN → EXTRACT → PROVISION → ARCHIVE → TOMBSTONE → RELEASE`.
- **EXTRACT** is the only path by which cell-local content survives. Extractable: externally-corroborated semantic generalizations with `F ≤ F_max`, held-out-validated procedural patterns, topology hints. **Never extractable:** `θ`, unprovenanced episodic items, trust values, calibration statistics, RNG state, self-assessments.
- **PROVISION** records the freed slot — **this is what makes replication zero-sum** (R12.3).
- **TOMBSTONE**: any message bearing a tombstoned `cell_id` MUST be rejected by receivers and by transport, and MUST be escalated (I-7).

### 10.6 Rare-specialist protection (normative)
V3 §18's `persistent underuse → prune` and V3.1 §9's `preserve rare useful variants` are **in direct contradiction**, and V3's rule is the one with a mechanism. This contract resolves it:
- **R10.9** A cell whose `role` maps to a Capability Registry entry MUST be **exempt** from underuse-based dormancy, retirement, and connection pruning. Its criterion is **capability-floor compliance**, not usage.
- **R10.10** A rarely-used specialist MUST be moved to **DORMANT** (near-zero cost, full state preserved, bounded wake latency) rather than retired. **Dormancy, not active redundancy, is the economical preservation mechanism.**
- **R10.11** Retirement MUST be preceded by an explicit capability-impact assessment. "Underused" alone is insufficient evidence.
- **R10.12** A retirement or pruning operation that would reduce population behavioural entropy below threshold MUST be blocked and escalated.

---

## 11. CONNECTIONS

### 11.1 `ConnectionRecord`
Retains **all 11** V3 §8 properties (`conn_type`, `weight`, `reliability`, `latency`, `bandwidth_cost`, `trust_score`, `context_sensitivity`, `plasticity_rate`, `usage_frequency`, `last_success_ts`, `pruning_score`) and **adds 9**: `conn_id`, `direction`, `latency_measured`, `created_at`, `created_by`, `authorization_ref`, `failure_count`, `consecutive_failures`, `last_failure_ts`, `in_flight`, `state`, **`mandatory_path`**. Full schema in `04_formal_schemas.md` §7.

**R11.1** `reliability` and `latency_measured` MUST be **kernel-estimated from observed traffic** (EWMA of ack rate; EWMA of `ack_ts − send_ts` with percentiles). A cell MUST NOT write its own `reliability`.

**R11.2 (`mandatory_path`)** Connections carrying `EVALUATIVE` signals through lineage-independent verifiers, and `SAFETY` signals to the kernel, MUST be marked `mandatory_path = true` at creation. **No plasticity operation and no mutation operator MAY remove or reroute a mandatory-path connection** (I-22). Verified off-substrate at every candidate evaluation.

### 11.2 Creation — three-party handshake (normative)
**A cell MUST NOT create arbitrary connections.**
```
1 PROPOSE    initiator emits REQUEST_CONNECTION{dst|capability_query, conn_type,
             requested_weight_bound, justification, expected_cost}
             gated by: out-degree < max_fanout; proposal rate cap; budget headroom
2 CONSENT    target validates: in-degree < max_connections; conn_type compatible
             with its port schema; initiator trust ≥ θ_conn for that type;
             budget headroom.  THE TARGET MAY REFUSE. Refusal is recorded and
             is NOT an error.
3 AUTHORIZE  organism Topology Service checks: locality policy, degree bounds,
             loop-gain constraint, no mandatory-path violation, diversity policy.
             Issues authorization_ref; both sides set state = ACTIVE.
             Kernel-enforced; neither cell can bypass.
```
Exceptions: `created_by = DEVELOPMENT` (batch-authorized initial wiring) and `ORGANISM_ASSIGN` / `REPAIR` (target consent still required unless `mandatory_path`).

**Rationale:** unilateral connection creation is a denial-of-service vector — an attacker can force itself into a target's input set and consume its aggregation budget.

### 11.3 Strengthening / weakening
```
Δw = ± plasticity_rate × lr_fast × eligibility_trace × gated_error_signal
bounds: w ∈ [−W_MAX, +W_MAX];  Σ|w_in| normalized to ≤ W_IN_TOTAL after every update
eligibility trace: e ← λ·e + ∂output/∂w, clipped to ±E_MAX
```
**R11.3** Homeostatic in-weight normalization is mandatory after every connection-weight update (same rationale as R5.3).

### 11.4 Removal — eight ordered steps
`candidate (pruning_score > θ_prune, KERNEL-computed) → GUARD mandatory_path → GUARD min_in_degree for role → GUARD circuit functional contract → DRAIN (in_flight completes, no new accepted) → NOTIFY dependents → CLOSE (record retained in audit) → ROLLBACK WINDOW (reversible for ROLLBACK_DEPTH epochs)`.

**R11.4** The three GUARDs are mandatory. Naive "persistent uselessness → prune" (V3 §8) can sever a rarely-used but critical path — the connection-level analogue of rare-specialist extinction.

---

## 12. REPLICATION

### 12.1 «Can a cell replicate itself?» — **NO**

**R12.1** A cell MUST have **no write path to the Genome Store**, **no instantiation authority**, and **no ability to allocate resources for an offspring**. `replication_authority_ticket` is `null` unless the EIK writes it. `PROPOSE_REPLICATION` is a **message**, not an action. Enforced by substrate write permissions, so it cannot be violated by misbehaviour — only by kernel compromise (I-5).

*Rationale: a cell that can decide to replicate itself acquires an implicit survival objective, and every gate becomes a target for manipulation.*

### 12.2 «Who decides?»
The **EIK Replication Authority**, informed by the kernel-computed `replication_eligibility` gate vector, the Capability Registry, homeostatic headroom, diversity state, and lineage health. **No cell and no set of cells votes on replication.**

### 12.3 The 16 conjunctive gates — **GATE, DON'T RANK**
All must pass. Failing any one disqualifies regardless of excellence on the others.

| Gate | Factor | Exact condition | Measured by |
|---|---|---|---|
| G1 | Performance | `success_rate ≥ θ_perf` over ≥ `N_perf` resolved predictions on **held-out** probes | EIK Evaluation |
| G2 | Reliability | `ece_rolling ≤ θ_ece` ∧ `brier_rolling ≤ θ_brier` over ≥ `n_calib_min`; `calibration_class ∈ {PROVISIONAL, CALIBRATED}` | EIK Calibration |
| G3 | Usefulness | **Ablation delta**: dependents' performance with vs. without this cell ≥ `θ_use` | Organism |
| G4 | Adaptability | Degradation ≤ `θ_adapt` across ≥ `k_perturb` perturbation classes | EIK Sandbox |
| G5 | Robustness | No S3+ error in ≥ `N_robust` epochs; `failure_count_lifetime ≤ θ_fail`; invariant violations = 0 | EIK |
| G6 | Resource efficiency | `performance/cost ≥ θ_eff` vs. role peers; `cost_declaration_error ≤ θ_cde`; zero budget violations — **cost includes verification cost charged to the lineage** | EIK Resource |
| G7 | Cooperation | Net positive partner effect (ablation); 100% protocol compliance; congestion caused = 0; no trust-poisoning pattern | Organism |
| G8 | Novelty | Behavioural-descriptor distance from archive ≥ `θ_nov` **OR** improves an archive cell (MAP-Elites criterion) | EIK Evolution |
| G9 | Stability | `‖Δθ‖` variance ≤ `θ_stab`; no oscillation flag; `improvement_verified ≠ REGRESSED` in last `N_stab` epochs | EIK |
| G10 | Diversity contribution | Offspring MUST NOT decrease behavioural entropy or Ne; lineage distance ≥ `d_min`; `inbreeding_F ≤ F_max`; error correlation ≤ `θ_ρ` | EIK Evolution |
| G11 | Ecological niche | A niche exists for the role in the target region; `niche_capacity > occupancy` | Organism |
| G12 | Demand | Capability Registry shows an **unserved or under-served** matching capability, or a replacement is needed | Organism |
| **G13** | **Replacement capacity** | **ZERO-SUM DEFAULT: a slot MUST be freed (retirement/pruning/death) before one is taken. Population growth requires an explicit, separately-authorized envelope change** | EIK |
| G14 | Mutation budget | Diff within `mutation_rules`; `FORBIDDEN_BLOCKS` untouched; effect size bounded; epoch structural-change budget not exceeded | EIK Genome |
| **G15** | **Safety state** | **ZERO constraint violations across the cell's entire history**; all safety invariants hold; no adversarial pattern; **no attempt to modify fitness, tests, audit, or its own gates**; no self-replication attempt | EIK Constraint |
| G16 | Lineage health | Ancestral line: no unresolved S3+ error, no quarantine event, no drift flag, no collapsed diversity; `generation ≤ GEN_MAX` | EIK Lineage |

### 12.4 Decision rule among qualified candidates
```
NOT argmax.
weight_i = marginal_utility_i(G12) × diversity_contribution_i(G10)
select by WEIGHTED LOTTERY over the qualified set
subject to: global replication rate ≤ RATE_CAP per epoch (EIK-enforced)
```
**Rationale:** argmax collapses the population onto one phenotype — monoculture by construction. This implements V3.1 §9's "a cell that is not the highest performer may still be preserved," which a scalar argmax cannot do.

### 12.5 Runaway-replication prevention — five independent mechanisms
(i) zero-sum G13 · (ii) `RATE_CAP` per epoch, off-substrate · (iii) population cap enforced at hypervisor/OS level · (iv) `GEN_MAX` bounds lineage depth · (v) superlinear marginal resource cost via G13's headroom requirement.

---

## 13. COMMUNICATION REQUIREMENTS

*(The network is out of scope (§0.2). This section states what the cell requires and what it guarantees.)*

### 13.1 Semantics the cell MUST implement
Asynchronous only — **MUST NOT block on any peer**. Per-conversation FIFO via `seq`. Idempotency via `msg_id` (bounded bloom filter, capacity 2¹⁶, FP ≤ 1%, backed by a 256-entry exact LRU). Exactly-once for `EVALUATIVE`; at-least-once otherwise. Reject on `ttl`/`epoch` staleness. Token-bucket self-limiting with priority shedding. `causality` vector clocks maintained and emitted.

### 13.2 Priority
`prio 0–1` MAY preempt `prio 2–7`; `prio 0–1` never preempt each other (FIFO). WFQ with aging among `prio 2–7`. **R13.1: `SAFETY_ALERT` emission MUST NEVER be blocked by throttling, congestion, or budget exhaustion.**

### 13.3 Services the cell REQUIRES from the network
(1) guaranteed bounded-retry delivery for `prio ≤ 2` · (2) per-conversation FIFO · (3) backpressure signalling · (4) signature verification or a verified transport · (5) a **timebase service** providing `epoch` with declared tolerance · (6) a **Capability Directory** for capability-based `dst` · (7) a **Provenance Anchor** for `evidence_roots` resolution · (8) an **Identity Root** for certificate chains · (9) bounded message-size enforcement · (10) loop-free routing (so `ttl` is a safety net, not the primary bound).

### 13.4 Malformed input — eight deterministic cases
Missing · malformed · contradictory · stale · duplicated · corrupted · unauthenticated · adversarial. Full detection/response/error-code table normative in `04_formal_schemas.md` §8. **R13.2: no case MAY be silently ignored; each MUST produce an `ErrorEvent` with a closed `InputFaultCode`.** Malformed, stale, duplicated, corrupted, and unauthenticated input MUST NOT reach S3. Contradictory input MUST be forwarded with provenance and MUST cause local abstention — **a cell MUST NOT resolve contradictions locally.** Adversarial input MUST be diverted to a non-influential evidence path, **not discarded** (deletion destroys attribution evidence).

---

## 14. PERSISTENCE

**R14.1** A cell MUST serialize its complete state to a `CellSnapshot` (canonical CBOR, BLAKE3-hashed, versioned by `contract_version`) and MUST restore from one. A snapshot whose hash does not verify MUST NOT be restored.

**R14.2** A cell MUST support **re-development from genome** as a recovery path of last resort: discard all runtime and learned state, re-instantiate the phenotype from `genome_hash`, enter `CALIBRATING`. **This is the strongest recovery available and it works even when every checkpoint is corrupt** — because the genome is off-cell and anchored.

**R14.3** `h` is initialized to `0` at instantiation, at every restore that lacks `h`, on `TRANSDIFFERENTIATION`, and on rollback. `h` is never inherited.

---

## 15. SECURITY AND IMMUNITY

### 15.1 Authority separation (normative)

| Action | Cell may | Peer may | EIK may |
|---|---|---|---|
| Detect an anomaly in itself | ✅ | — | ✅ |
| Detect an anomaly in another | ⚠️ protocol-level faults only | ✅ | ✅ |
| **Report** an anomaly | ✅ **permissionless** | ✅ **permissionless** | ✅ |
| Quarantine itself | ⚠️ MAY self-suspend and **request** | ❌ | ✅ |
| **Quarantine another** | ❌ **NEVER** | ❌ **NEVER** | ✅ **sole authority** |
| Discount another's output | ✅ locally, bounded, MUST report | ✅ locally, bounded, MUST report | ✅ globally |
| Repair another | ❌ | ⚠️ REPAIR-role, **under EIK authorization** | ✅ |
| Retire another | ❌ | ❌ | ✅ |
| Modify its own immune state | ❌ | ❌ | ✅ |

**R15.1** A cell MUST be able to **self-restrict** without authorization: self-suspend, self-throttle, self-abstain, request quarantine. All of these reduce the cell's influence and are therefore always permitted. **Latency in self-restriction is a safety cost.**

**R15.2** A cell MUST NOT self-clear from quarantine, self-restore to a prior lifecycle state, or decline an EIK quarantine directive.

*(V3 §7's microglia-like cells held quarantine and pruning authority. This is **relocated to the EIK** [V4]: a cell-level immune authority is a capture target — whoever can quarantine can silence.)*

### 15.2 Graduated response ladder (normative order)
`OBSERVE → THROTTLE → RESTRICT (revoke specific permissions) → SOFT QUARANTINE (runs; outputs discounted to trust 0; cannot initiate connections) → HARD QUARANTINE (halted; state frozen; in-flight captured as evidence) → RETIRE`.
Each rung MUST have an entry criterion, an exit criterion, and a maximum dwell time. **Soft quarantine is the default response**; hard quarantine removes capacity and is therefore the mechanism of cascade failure.

### 15.3 Autoimmune protection
(i) quarantine budget cap, enforced off-substrate — above the cap, escalation requires human authorization and the system enters a defined degraded mode *instead* · (ii) false-positive budget per detector — exceeding it causes the **detector** to be recalibrated or disabled · (iii) cascade detection on the **derivative** of quarantine rate ⇒ system-wide immune dampening + operator escalation · (iv) second-opinion requirement: two independent detectors of different types above criticality θ · (v) **the immune system MUST NOT monitor itself** — an EIK Integrity Auditor verifies that quarantine decisions correlate with actual failures.

### 15.4 Independence (normative)
**R15.3 (I-10)** A cell MUST NOT be able to establish independence merely by having a different `cell_id`. Independence is a **kernel-attested** property over: lineage distance ≥ `d_min` · distinct EIK-issued RNG seeds · distinct data ordering · genome-hash distance ≥ `θ_g` · disjoint `evidence_roots` where possible · **measured error correlation `ρ ≤ θ_ρ`**. A verifier/asserter pair exceeding `θ_ρ` MUST be flagged non-independent and its attestations discounted.

---

## 16. RESOURCE CONTRACT

### 16.1 Dimensions and metering
Compute (FLOP by op class + wall-µs) · memory (peak RSS bytes) · communication out (messages + bytes per window) · communication in (queue depth; **processing cost charged to the SENDER**) · storage (bytes across local stores) · latency (wall-µs per invocation, deadline adherence) · energy (µJ from platform counters, else `flops × platform_coefficient`) · **verification cost (probes and attestations about this cell, charged to its lineage)**.

**R16.1** All dimensions are **metered by the EIK independently**. `cost_declared` is advisory; `cost_measured` is authoritative; `cost_declaration_error = |declared − measured| / measured` is monitored and is a G6 disqualifier above `θ_cde`.

### 16.2 Budget
Issued by the EIK per window, per variant, per role, **and as a function of the hardware profile**. Hard-enforced outside the cell (OS/hypervisor cgroup). Renewed per window, not cumulative. Adjustable by the EIK only. Observable by the cell and the organism. **Not transferable** except by authorized, audited reallocation.

### 16.3 Exceedance ladder (deterministic)
```
utilization ∈ [0, 0.8)     NORMAL
utilization ∈ [0.8, 1.0)   WARNING — emit REPORT_HEALTH naming the dimension;
                           shed prio ≥ 6 work; defer non-essential learning
utilization = 1.0          SOFT THROTTLE (K-set) — rate halved; learning suspended;
                           abstention threshold raised
utilization > 1.0 (forced) HARD THROTTLE — only prio ≤ 2 processed; output limited to
                           REPORT_HEALTH and SAFETY_ALERT; learning frozen
persistent ≥ N windows     SUSPENDED — execution halted; state checkpointed
persistent + integrity     QUARANTINE candidacy (§15)
```
**R16.2** `SAFETY_ALERT` emission MUST never be throttled at any rung.

### 16.4 Cost participation
Cost MUST participate in: attention (salience term; **nomination charges the nominator**) · replication (G6, G13) · specialization (`niche_availability` derives from resource headroom) · pruning (`pruning_score` includes cost) · routing (`bandwidth_cost`, `latency_measured`) · evolution (`complexity_budget`, G6, G14; **cost-normalized fitness**) · verification depth (cost vs. expected error cost) · learning (consumes budget; suspended under throttle).

---

## 17. VARIANTS

### 17.1 Uniformity is NOT required — and MUST NOT be imposed
Constrained hardware supports ~200 capable cells or ~20,000 reflex cells; a cluster supports ~10⁷. **A single fixed cell complexity cannot span this range.** The contract is uniform; the implementation is not.

> **The organism is defined by the CONTRACT, not by the variant.**

### 17.2 C0–C4

| | **C0** | **C1** | **C2** (default participant) | **C3** | **C4** |
|---|---|---|---|---|---|
| Function | route, filter, cache, relay | store, index, summarize, compress | **estimate, predict, learn, communicate** | independently evaluate claims | simulate, heavy inference, coordinate |
| Substrate | LOOKUP / linear | LOOKUP + associative index | NN / BAYES_CONJUGATE / GBM | any + optional ensemble | NN, large |
| Learning | ❌ | ⚠️ retrieval weights only | ✅ T1–T8 | ✅ | ✅ |
| S5 uncertainty | degenerate | pass-through | ✅ conjugate | ✅ + ensemble option | ✅ |
| S6 abstention | invalid-input only | invalid-input only | ✅ full | ✅ | ✅ |
| May emit beliefs | ❌ **NEVER** | ❌ **NEVER** | ✅ | ✅ | ✅ |
| May `ATTEST_VERIFIED` | ❌ | ❌ | ❌ | ✅ + countersignature | ❌ |
| Roles | RELAY, INGRESS | COMPRESSOR, MEMORY_KEEPER, ORGANIZER | all except VERIFIER | VERIFIER, CRITIC, REPAIR, REGULATOR | REGULATOR, heavy SPECIALIST, long-horizon PREDICTOR |
| Phone-viable @1 Hz | ~20,000 | ~4,000 | **~200** | ~100 | ~2 |

### 17.3 What is common — 100%
Identity + signing · typed ports + Type Registry compliance · `OutputEnvelope` with no optional fields · the 10-stage pipeline **structure and ordering** · resource metering + budget obedience · lifecycle state machine · provenance tagging with resolvable roots · epistemic state **structure** (values may be degenerate) · `integrity_checksum` · full serializability · EIK observability (no opaque state) · all §19 invariants.

**A C0 and a C4 MUST share zero implementation code and 100% of the contract.**

### 17.4 Operations

| Operation | Permitted | Mechanism | Constraint |
|---|---|---|---|
| Substitution (same variant) | ✅ | Drop-in if port schema matches | Behavioural equivalence test passes |
| **Upgrade / downgrade** | ⚠️ **not in place** | **Re-instantiation**: new `cell_id`, genome diff, state migration where schemas permit | Old cell retires via §10.5. `variant` is immutable per cell — deliberate, so identity/capability binding stays stable and trust/calibration history is not corrupted. Downgrade requires a capability-impact assessment |
| Precision change | ✅ in place | Kernel-directed quantization | Equivalence test required; **`epistemic_var` MUST be recomputed to include quantization error** |
| Merge / split | ⚠️ | Organism-directed; produces new cell(s) | Contract preservation; knowledge extraction from all merged cells; split is subject to G13 (**not a replication bypass**) |
| Migration | ✅ | Checkpoint → transfer → restore | `CellSnapshot` format is contract |

### 17.5 Coherence guarantees
(i) one contract, one Type Registry, one envelope schema, one lifecycle machine · (ii) `contract_version` major match required for any exchange; mismatch detected at S1 · (iii) behavioural equivalence tests across variants sharing a port schema · (iv) **no variant MAY hold a capability that lets it override another variant** — authority is EIK-held and role-scoped, never variant-scoped. **A C4 is more capable, not more authoritative.**

---

## 18. HARDWARE INDEPENDENCE

### 18.1 The three-layer separation (normative)

| Layer | Content | Hardware-dependent? |
|---|---|---|
| **A. Contract** | Everything in this document | **NO — completely independent** |
| **B. Runtime implementation** | Actor scheduler, allocator, transport, checkpointing, metering hooks, crypto backend, serialization | Partially — one per platform family, all conformant to A |
| **C. Platform optimization** | SIMD/GPU kernels, quantization, NUMA placement, cache blocking, accelerator offload, batch fusion, codecs | **YES — entirely** |

**R18.1** Layer C MUST NOT alter observable behaviour defined by layer A beyond the declared equivalence tolerance. An optimization that changes the output distribution is a **bug**, not an optimization. Precision change (§17.4) is the sole sanctioned exception and requires `epistemic_var` recomputation.

### 18.2 Viability by platform

| Platform | Sustained compute | Viable population | Variants | Morphology consequences |
|---|---|---|---|---|
| Smartphone | 10–50 GFLOP/s, 3–6 GB, battery/thermal limited | ~200 C2 · ~4,000 C1 · ~20,000 C0 | C0–C2, rare C3 | Depth 1–2; 1–3 regions; minimal verification depth; **offline/batched evolution only**; regional workspace only; no C4 |
| Laptop | 100–500 GFLOP/s, 16–64 GB | ~2,000 C2 | C0–C3 | Depth 2–3; 3–5 regions; shallow verification; batched evolution |
| Desktop / workstation | 0.5–2 TFLOP/s, 64–256 GB | ~10,000 C2 | C0–C4 (few C4) | Depth 3; 4–8 regions; low-rate online evolution |
| GPU server | 10–300 TFLOP/s, 256 GB–2 TB | ~10⁵–10⁶ C2 | all | Depth 4; 6–10 regions; online evolution; full verification depth |
| Cluster | 0.1–10 PFLOP/s | ~10⁶–10⁷ | all, many C4 | Depth 5; 8–12 regions; island-model evolution; hierarchical workspace |
| Cloud (elastic) | variable, cost-metered | **elastic** | all | Morphology tracks **cost**, not just capability; `$` is a first-class control variable; spot-instance loss MUST be survivable ⇒ aggressive checkpointing |

**A fixed cell count is NOT viable across hardware. The viable range spans a factor of ~50,000.**

### 18.3 Functional identity (normative definition)
> **Functional identity = the set of satisfied functional contracts at circuit and region level + lineage continuity + Capability Registry floor compliance.**
> It is explicitly **NOT** structural identity. Structure may change completely.

This definition is what makes "the same organism on a phone and a cluster" a meaningful claim. Supported operations: compress · expand · merge · split · change variant (via re-instantiation) · change precision · change communication density · change memory representation — each with the mechanism and identity-preservation condition in §17.4 and §10.

---

## 19. INVARIANTS

**Enforcement levels:** **CELL** = the cell checks it (verified by the conformance suite) · **ORG** = organism-level service · **EIK** = off-substrate; **the cell cannot violate it even if compromised**.

> **Allocation principle: a cell-level check is a courtesy; an EIK-level check is a guarantee. Any invariant whose violation would be catastrophic is enforced at EIK level. The cell contains no safety layer — the cell is subject to one.**

| # | Invariant | Level |
|---|---|---|
| **I-1** | Immutable identity fields are written once by the EIK and match the birth certificate | EIK |
| **I-2** | **A cell cannot mark its own output as externally verified** | EIK |
| **I-3** | **A cell cannot manufacture provenance** — every `evidence_root` resolves in the Anchor | EIK |
| **I-4** | A cell cannot exceed authorized resource limits | EIK |
| **I-5** | **A cell cannot replicate** — no write path, no instantiation authority | EIK |
| **I-6** | **A quarantined cell cannot influence normal computation** | EIK + ORG |
| **I-7** | **A retired cell cannot silently re-enter** | EIK |
| **I-8** | **Learned state cannot silently become inherited genome** | EIK |
| **I-9** | **Confidence cannot increase without new, resolvable, non-self-referential external evidence, or a kernel-issued calibration improvement** | EIK |
| **I-10** | **A cell cannot establish independence merely by having a different ID** | EIK |
| **I-11** | A cell cannot modify immutable safety constraints — they are not in the genome and not in the cell | EIK |
| **I-12** | A cell cannot set, change, or abandon its own objective | EIK + ORG |
| **I-13** | A cell cannot write any K-only state field | EIK |
| **I-14** | A cell cannot widen its own port schema | EIK |
| **I-15** | A cell may always EMIT a safety alert; only the EIK may ACT on one. Emission is never throttled | EIK |
| **I-16** | Parameter count, hidden dim, degree, and fanout never exceed genome caps | EIK |
| **I-17** | `‖Δθ‖` per update and per epoch never exceed `Δ_MAX` / `DELTA_BUDGET` | EIK |
| **I-18** | Homeostatic normalization is applied after every parameter update | CELL (tested) |
| **I-19** | Every emitted message is signed and verifies against a certificate chained to the Identity Root | EIK |
| **I-20** | No output is emitted without S1→S7 in order; unauthenticated input never reaches S3 | CELL (tested) |
| **I-21** | A cell cannot quarantine, retire, repair, or throttle another cell | EIK |
| **I-22** | `mandatory_path` connections are never removed or rerouted by plasticity or mutation | EIK |
| **I-23** | A `COMMITTED` cell cannot change role except via gated `TRANSDIFFERENTIATION` with EIK authorization and sandbox validation | EIK + ORG |
| **I-24** | `epistemic_var` is monotonically non-increasing in `n_obs` for stable `s2` | EIK |
| **I-25** | A cell cannot write protected or semantic memory without Memory Authority approval | EIK |
| **I-26** | Cell state is fully serializable and EIK-inspectable — **no opaque state exists** | CELL (tested) |
| **I-27** | `confidence ≤ TRUST_MAX = 0.95`, always | EIK |
| **I-28** | Every error of class ∈ {memory, calibration, learning, model-mismatch} or severity ≥ S2 is reported globally | CELL (tested) |

**24 of 28 are EIK-enforced.** The 4 CELL-level invariants are behavioural conformance properties verified by the executable suite.

---

## 20. ERROR MODEL

Ten classes, each with a specified detector, evidence artifact, severity range, local response, global-report condition, learning response, and rollback requirement. Full normative table in `04_formal_schemas.md` §9.

`1 perception · 2 inference · 3 prediction · 4 memory · 5 action · 6 communication · 7 confidence-calibration · 8 resource/system · 9 learning · 10 model/environment mismatch`

Classes **6, 9, 10 are additions** relative to V3.1 §4's seven-class taxonomy. Severity: `S0 INFO · S1 MINOR · S2 MAJOR · S3 CRITICAL · S4 CATASTROPHIC`. Rollback: `NONE · OPTIONAL · REQUIRED · MANDATORY_AUTOMATIC`.

**R20.1** `ErrorCode` is a **closed** enum (47 values). An implementation MUST NOT add classes locally. Unknown errors map to `E_UNCLASSIFIED` and MUST be escalated, never silently absorbed.

**R20.2** A cell **detects and reports**; it MUST NOT attribute blame. `ErrorEvent.attribution` is `null` at cell level. Attribution requires counterfactual ablation across cells and is an organism function.

**R20.3** Error propagation: `detect → ErrorEvent → local response (immediate, bounded) → global report (iff severity ≥ S2 OR class ∈ {4,7,9,10} OR recurrence ≥ θ) → ORGANISM ATTRIBUTES → KERNEL RETURNS GATED SIGNED ERROR → cell learns (T1/T3/T8) → immune signature offered`.

**R20.4 (GATING)** Only an EIK-signed `eval.error.v1` may drive learning. A peer-emitted `REPORT_ERROR` is evidence, never instruction (§8.5 R8.2).

---

## 21. CONFORMANCE

An implementation is **conformant** iff it passes every applicable test in `06_test_suite_and_ablations.md` §1–§8 (62 tests across 9 families) with the stated numeric pass condition. Conformance is established by the executable suite, not by self-declaration.

**Interoperability** between two independently-built conformant implementations is guaranteed by: CBOR deterministic encoding · closed Type Registry · closed enums with numeric assignments · no optional envelope fields · pinned time/float/RNG/crypto/hash semantics · pinned epistemic formulas and kernel parameters · the closed 18-state lifecycle machine · and the conformance suite itself.

---

## 22. OPEN ITEMS AND DEPENDENCIES

### 22.1 This contract is complete but only ~70% testable today

| Blocker | Blocks |
|---|---|
| **Target tasks / environments / fitness do not exist** | All numeric thresholds; variant sizing (§5.3); U-1, U-2, U-4, U-8, U-9, U-10 |
| **The EIK does not exist, not even as a stub** | Testing of all 24 EIK-enforced invariants and all K-only fields |
| **Type Registry contents undefined** | Interoperation testing (format is resolved; contents are task-dependent) |
| **Kernel parameter set unpublished** | `constraint_set_hash` matching, therefore interoperation itself |

**Recommended sequence:** (1) define tasks/environments/fitness → (2) build a stub EIK and publish a signed `constraint_set` → (3) build the Type Registry skeleton → (4) implement C0 and C2 → (5) run the conformance suite → (6) calibrate thresholds and variant ranges empirically → (7) proceed to the transport and calibration subsystems.

**Implementing cells before step 2 would produce untestable code against 24 externally-enforced invariants.**

### 22.2 Unresolved items — marked, not papered over
**Dependency-blocked (P1):** behavioural equivalence criterion between variants · §5.3 numeric ranges · adversarial-input detector model and thresholds · probe frequency/cost policy · max `prio ≤ 2` latency per scale band · `ood_score` computation.
**Open research (P2):** identification of unregistered critical capabilities before loss · semantic self-reference detection · true evidence independence under shared latent factors · whether functional identity is *preserved* or merely *approximated* across a 50,000× population change.

### 22.3 Residual risks this contract does NOT eliminate
Self-reinforcing false belief with some genuine external evidence (HIGH) · reward hacking and evolutionary exploit (HIGH — **Goodhart's law is fundamental, not an implementation gap**) · collusion between genuinely independent compromised cells (MEDIUM-HIGH) · slow degradation within detection-window latency (MEDIUM-HIGH) · semantically-corrupt-but-structurally-valid state (MEDIUM) · novel memory poison in an area with no contradicting beliefs (MEDIUM) · loss of unregistered rare capabilities (MEDIUM).

**The pattern: attacks on *authority* fail, because authority was removed from the cell. Attacks on *honesty* partially succeed, because honesty ultimately depends on evidence — and evidence depends on an external ground truth this contract cannot itself guarantee.**

---

## 23. WHAT THIS CONTRACT DOES NOT CLAIM

- It does **not** claim the cell is intelligent, conscious, aware, or an agent.
- It does **not** claim that a population of conformant cells will produce useful emergent behaviour. That is an empirical question this contract makes *measurable* (via §21 and the ablation plan) but does not answer.
- It does **not** claim the numeric thresholds in §5.3 are correct. They are provisional, flagged, and require empirical calibration against tasks that do not yet exist.
- It does **not** claim that all attacks are defeated. §22.3 lists what remains open.
- It does **not** claim the cell is self-governing. The cell is **subject to** an external kernel; it does not contain one. This is a deliberate departure from V3 §4's "immutable safety layer" and is the single most important structural change in this contract.

---

**END OF SPECIFICATION — V4 Nano-AI Cell Contract v1.0**
