# V4 — Nano-AI Cell Contract v1.0
## Normative Annex A: Formal Schemas, Enumerations & Reference Tables

**Status:** NORMATIVE. This annex is part of the contract. An implementation that diverges from any definition here is non-conformant.
**Parent:** `03_v4_cell_contract_spec.md`
**Purpose:** eliminate the 24 P0 interoperability ambiguities (Volume A §27.2) by pinning every wire-level and semantic degree of freedom.

---

## 1. ENCODING AND PRIMITIVES

### 1.1 Serialization
- **Encoding:** CBOR (RFC 8949).
- **Deterministic form (REQUIRED for anything signed or hashed):** RFC 8949 §4.2 — map keys sorted by bytewise length then lexicographically; no indefinite-length items; integers in the shortest permitted form; floats in the shortest form that round-trips.
- **Signature coverage:** Ed25519 over the deterministic encoding of all fields **except** `signature` and `countersignature`.
- **Hash:** BLAKE3, 256-bit output, throughout. No other hash is permitted.
- **Signature:** Ed25519 (RFC 8032), 64-byte. Post-quantum migration is a `contract_version` **major** bump, never a runtime negotiation.
- **UUID:** UUIDv7 (time-ordered) for `msg_id`, `conv_id`, `cell_id`, `conn_id`, `error_id`, `bundle_id`.

### 1.2 Numeric semantics
| Item | Requirement |
|---|---|
| Float | IEEE-754 `binary32` / `binary64`, **round-to-nearest-even** |
| Fast math | **PROHIBITED** (no `-ffast-math`, no reassociation) |
| FMA | Permitted only if declared in the platform profile; both forms MUST produce results within `θ_float_tol` |
| Denormals | MUST NOT be flushed to zero |
| NaN / Inf | MUST NOT appear in any serialized field. Pre-serialization clamping to the declared range is REQUIRED; a value that would clamp is recorded as `E_NUMERIC_RANGE` (S1) |
| Bit-exactness | Where required (signing, checksums), operate on the serialized integer representation, never on a native float |

### 1.3 Randomness
**xoshiro256\*\***, 256-bit state. Seed issued by the EIK (**never** heritable, never cell-chosen). Seed ticket recorded in `rng_seed_provenance`. State serialized in `CellSnapshot` for deterministic replay.

### 1.4 Time
| Field | Semantics |
|---|---|
| `ts` | `u64` nanoseconds since Unix epoch, UTC, **no leap-second smearing** |
| `ts_mono` | `u64` nanoseconds on a monotonic clock, base unspecified (only differences are meaningful) |
| `epoch` | `u64` organism logical epoch from the timebase service |
| Staleness | Judged by **`epoch`**, not by `ts`. Clock skew tolerance `θ_skew` is declared per scale band |

### 1.5 Type notation and the Type Registry
`[T]` list · `{K:V}` map · `⟨A|B⟩` tagged union (explicit discriminator) · `u8/u16/u32/u64`, `i32/i64` · `f32/f64` · `bytes<n>` · `enum Name` (closed, numeric assignments in §2) · `f32[D]` / `f64[D]` fixed-length vector, `D` from the port schema.

`TypeRef = {registry_id: u16, schema_version: u16}`. The **Type Registry is an EIK artifact**. Base primitive kinds (11, closed):
`0 BOOL · 1 INT · 2 UINT · 3 FLOAT · 4 BYTES · 5 STRING · 6 LIST · 7 MAP · 8 TENSOR · 9 DISTRIBUTION · 10 REF`

Composite types are defined only by registry schema. **An unresolvable `TypeRef` MUST produce `E_IN_SCHEMA` and the input MUST NOT reach S3.**

### 1.6 `CellID`, `RegionID`, hashes
`CellID = bytes<16>` · `RegionID = bytes<16>` · all hashes and Merkle refs `= bytes<32>` · all signatures `= bytes<64>`.

---

## 2. CLOSED ENUMERATIONS WITH NUMERIC ASSIGNMENTS

**Unknown values MUST be rejected, never coerced.** These enums are part of the wire format.

### 2.1 `LifecycleState` (18) — see `05_state_machine.md`
```
0  UNINSTANTIATED      1  INSTANTIATED        2  DEVELOPING
3  CALIBRATING         4  PROBATIONARY        5  ACTIVE
6  LEARNING_CONSOLIDATING  7  DEGRADED        8  THROTTLED
9  SUSPENDED          10  DORMANT            11 QUARANTINED_SOFT
12 QUARANTINED_HARD   13  REPAIRING          14 TRANSDIFFERENTIATING
15 RETIRING           16  RETIRED            17 ARCHIVED
   (DELETED is not a state — it is the absence of the record; §10.5)
```

### 2.2 `MessageType` (34)
```
— RELAY / REPORT (all variants) —
0  RELAY                    1  AGGREGATE_SUMMARY
2  REPORT_UNCERTAINTY       3  REPORT_ERROR
4  REPORT_HEALTH            5  REPORT_SELF_STATE
6  REPORT_ANOMALY           7  REPORT_DAMAGE
— SAFETY (permissionless, never throttled) —
8  SAFETY_ALERT             9  VIOLATION_REPORT
— REQUEST / QUERY (all variants) —
10 QUERY                   11 RESPONSE
12 REQUEST_RESOURCE        13 REQUEST_CONNECTION
14 REQUEST_QUARANTINE      15 REQUEST_REPAIR
16 REQUEST_ATTENTION       17 PROPOSE_MEMORY_WRITE
— BELIEF ORIGINATION (C2+ ONLY) —
18 ASSERT                  19 CLASSIFY
20 ESTIMATE                21 PREDICT
22 PROPOSE_HYPOTHESIS      23 PROPOSE_ACTION
24 RECOMMEND_ACTION        25 ANNOUNCE_UPDATE
26 PROPOSE_REPLICATION     27 CONTEST
— ATTESTATION (C3 VERIFIER + EIK COUNTERSIGNATURE ONLY) —
28 ATTEST_VERIFIED
— KERNEL / ORGANISM ISSUED (EIK or organism signature REQUIRED) —
29 EVAL_REWARD             30 EVAL_ERROR
31 EVAL_OUTCOME            32 SYS_DIRECTIVE
33 DEV_MORPHOGEN
```

### 2.3 `RoleCode` (16)
```
0  UNDIFFERENTIATED   1  GENERALIST        2  SPECIALIST
3  PREDICTOR          4  CRITIC            5  VERIFIER
6  MEMORY_KEEPER      7  REGULATOR         8  REPAIR
9  EXPLORER          10  EXPLOITER        11 COMPRESSOR
12 ORGANIZER         13  INGRESS          14 EGRESS
15 RELAY
```
*`COMPRESSOR` and `ORGANIZER` are V4 additions (hierarchical aggregation and positional information are impossible without them). Immune/microglial function is deliberately **absent** as a cell role.*

### 2.4 `AbstainCode` (9) — disjunctive; report the **lowest-numbered** satisfied condition
```
0  INPUT_UNAUTHENTICATED    1  INVARIANT_VIOLATION
2  THROTTLE_HARD            3  INBREEDING_F_EXCEEDED
4  EPISTEMIC_VAR_EXCEEDED   5  OOD_EXCEEDED
6  INPUT_MISSING            7  CONFLICT_UNRESOLVED
8  SCOPE_OUT_OF_COVERAGE
```

### 2.5 `InputFaultCode` (12)
```
0  E_IN_MISSING     1  E_IN_SCHEMA      2  E_IN_CONFLICT   3  E_IN_STALE
4  E_IN_DUP         5  E_IN_INTEGRITY   6  E_IN_AUTH       7  E_IN_ADVERSARIAL
8  E_IN_OVERSIZE    9  E_IN_TYPE_UNRESOLVED  10 E_IN_EPOCH_MISMATCH
11 E_IN_QUARANTINED_SOURCE
```

### 2.6 `ErrorCode` (47) — 10 classes × subcodes
```
CLASS 1 PERCEPTION        100 E_PERC_SENSOR_DISAGREE   101 E_PERC_OOD
                          102 E_PERC_REDUNDANCY_FAIL   103 E_PERC_FUSION_CONFLICT
CLASS 2 INFERENCE         200 E_INFER_INVARIANT        201 E_INFER_CONSISTENCY
                          202 E_INFER_TYPE_COHERENCE   203 E_INFER_CONSERVATION
                          204 E_INFER_UNCLASSIFIED
CLASS 3 PREDICTION        300 E_PRED_MAGNITUDE         301 E_PRED_UNRESOLVED_DEADLINE
                          302 E_PRED_SYSTEMATIC_BIAS   303 E_PRED_HORIZON_MISMATCH
CLASS 4 MEMORY            400 E_MEM_INTEGRITY          401 E_MEM_PROVENANCE_UNRESOLVED
                          402 E_MEM_RETRIEVAL_LOWCONF  403 E_MEM_CRC
                          404 E_MEM_MERKLE_MISMATCH    405 E_MEM_CAPACITY
                          406 E_MEM_CONTRADICTION
CLASS 5 ACTION            500 E_ACT_UTILITY_DIVERGENCE 501 E_ACT_IRREVERSIBLE_UNFLAGGED
                          502 E_ACT_OUT_OF_SCOPE       503 E_ACT_DEADLINE_MISS
CLASS 6 COMMUNICATION     600 E_COMM_LOSS              601 E_COMM_TIMEOUT
                          602 E_COMM_SEQ_GAP           603 E_COMM_INTEGRITY
                          604 E_COMM_AUTH_FAIL         605 E_COMM_RATE_VIOLATION
                          606 E_COMM_CONGESTION        607 E_COMM_STALE_SYSTEMIC
                          608 E_COMM_HANDSHAKE_REFUSED
CLASS 7 CALIBRATION       700 E_CALIB_ECE              701 E_CALIB_BRIER
                          702 E_CALIB_CONFIDENT_WRONG  703 E_CALIB_UNDERTHRESHOLD
                          704 E_CALIB_OVERCONFIDENT_OOD
CLASS 8 RESOURCE/SYSTEM   800 E_RES_BUDGET_EXCEEDED    801 E_RES_DECLARATION_ERROR
                          802 E_RES_DEADLINE           803 E_SYS_CHECKSUM
                          804 E_SYS_STATE_INCONSISTENT 805 E_SYS_RESTORE_FAIL
                          806 E_SYS_SNAPSHOT_INVALID
CLASS 9 LEARNING          900 E_LEARN_REGRESSED        901 E_LEARN_OSCILLATION
                          902 E_LEARN_DELTA_BUDGET     903 E_LEARN_THETA_BOUND
                          904 E_LEARN_GENERALIZATION_GAP 905 E_LEARN_FORGETTING
CLASS 10 MODEL/ENV MISMATCH 1000 E_MOD_DIST_SHIFT      1001 E_MOD_DRIFT_NO_PARAM_CHANGE
                          1002 E_MOD_CONCEPT_DRIFT     1003 E_MOD_COVERAGE_LOSS
— CROSS-CUTTING —
1100 E_INVARIANT_AUTHORITY   1101 E_PROVENANCE_FABRICATED
1102 E_GENOME_INTEGRITY      1103 E_NUMERIC_RANGE
1104 E_UNCLASSIFIED          1105 E_CONTRACT_VERSION_MISMATCH
```

### 2.7 `Severity` (5) · `RollbackReq` (4)
```
Severity:    0 S0_INFO · 1 S1_MINOR · 2 S2_MAJOR · 3 S3_CRITICAL · 4 S4_CATASTROPHIC
RollbackReq: 0 NONE · 1 OPTIONAL · 2 REQUIRED · 3 MANDATORY_AUTOMATIC
```

### 2.8 `ConnType` (11)
```
0 EXCITATORY · 1 INHIBITORY · 2 MODULATORY · 3 EVIDENCE · 4 ERROR
5 ATTENTION · 6 RESOURCE · 7 DEVELOPMENTAL · 8 CONTROL · 9 RELAY · 10 QUERY
```

### 2.9 `ConnectionState` (7)
```
0 PROPOSED · 1 PENDING_CONSENT · 2 ACTIVE · 3 DEGRADED · 4 FROZEN · 5 DRAINING · 6 CLOSED
```

### 2.10 Other closed enums
```
Variant          (5): 0 C0 · 1 C1 · 2 C2 · 3 C3 · 4 C4
Substrate        (6): 0 NN · 1 GBM · 2 BAYES_CONJUGATE · 3 SYMBOLIC · 4 LOOKUP · 5 HYBRID_DECLARED
CalibrationClass (5): 0 UNCALIBRATED · 1 PROVISIONAL · 2 CALIBRATED · 3 MISCALIBRATED · 4 SUSPENDED
ThrottleLevel    (4): 0 NONE · 1 SOFT · 2 HARD · 3 SUSPENDED
DevStage         (4): 0 PLURIPOTENT · 1 PROVISIONAL · 2 COMMITTED · 3 TRANSDIFFERENTIATING
ImprovementVerdict(4):0 UNKNOWN · 1 IMPROVED · 2 NEUTRAL · 3 REGRESSED
ConsistencyFlag  (3): 0 OK · 1 MISMATCH · 2 UNVERIFIED
DetectedBy       (5): 0 SELF_INVARIANT · 1 SELF_COMPARISON · 2 KERNEL · 3 PEER_REPORT · 4 EXTERNAL_EVAL
LocalResponse   (12): 0 NONE · 1 ABSTAIN · 2 THROTTLE · 3 REDUCE_PLASTICITY
                       4 QUARANTINE_ITEM · 5 REROUTE · 6 FREEZE_LEARNING
                       7 RESTORE_CHECKPOINT · 8 SELF_SUSPEND · 9 REQUEST_QUARANTINE
                      10 DISCOUNT_SOURCE · 11 ESCALATE
SuspendCode      (8): 0 NONE · 1 BUDGET · 2 INSTABILITY · 3 INTEGRITY
                       4 CALIBRATION_FAILURE · 5 KERNEL_DIRECTIVE · 6 QUARANTINE
                       7 RETIREMENT_PENDING · 8 HARDWARE_STARVATION
CreatedBy        (4): 0 DEVELOPMENT · 1 CELL_REQUEST · 2 ORGANISM_ASSIGN · 3 REPAIR
ProducedBy       (2): 0 CELL_DERIVED · 1 KERNEL_CALIBRATED
ParamInitDist    (6): 0 GAUSSIAN · 1 UNIFORM · 2 TRUNCATED_GAUSSIAN · 3 XAVIER
                       4 FROM_PARENT_PERTURBED · 5 ZERO
GateResult       (3): 0 PASS · 1 FAIL · 2 UNKNOWN
Priority         (8): 0 SAFETY_PREEMPT · 1 SYSTEM_PREEMPT · 2 GUARANTEED
                       3 INTERACTIVE · 4 NORMAL · 5 BULK · 6 BACKGROUND · 7 SPECULATIVE
```

---

## 3. COMPLETE STATE SCHEMA

### 3.1 `CellState` (top level)
```
CellState {
  identity          : Identity            // §3 of the spec; all K-once
  genome_ref        : {genome_hash: bytes<32>, constraint_set_hash: bytes<32>}
  phenotype         : Phenotype
  runtime           : RuntimeState
  epistemic         : EpistemicState
  predictive        : PredictiveState
  resource          : ResourceState
  health            : HealthState
  trust             : TrustState
  connections       : ConnectionState
  errors            : ErrorState
  learning          : LearningState
  development       : DevelopmentalState
  replication       : ReplicationState
  lifecycle         : {state: LifecycleState, since: u64, prev: LifecycleState}
  schema_version    : u16
}
```

### 3.2 `Phenotype`
```
Phenotype {
  architecture_realized : {substrate: Substrate, hidden_dim: u32,
                           ensemble_size: u8, param_count: u32,
                           stage_config: [StageSpec; 10]}
  theta                 : f32[|θ|]         // C, bounded ‖θ‖ ≤ Θ_MAX; NOT heritable
  theta_checksum        : bytes<32>
  port_schema           : {inputs: [PortSpec], outputs: [PortSpec]}
                                           // signed at instantiation; CANNOT be widened
  rng_state             : bytes<32>        // xoshiro256**
  rng_seed_provenance   : bytes<32>        // EIK seed ticket
}
StageSpec { id: u8 (S1..S10), mode: enum{FULL, DEGENERATE, PASSTHROUGH, ABSENT_FORBIDDEN},
            params: TypeRef }
PortSpec  { port_id: u16, direction: enum{IN,OUT}, type: TypeRef, dim: u32,
            required: bool, deadline_us: u32, min_trust: f32 }
```

### 3.3 `RuntimeState`
```
RuntimeState {
  h                 : f32[H]        // C; ‖h‖ ≤ B_H; init 0 per R14.3
  activation        : f32           // C; [0,1]
  stage             : u8            // C; current S1..S10
  invocation_seq    : u64           // C↑
  epoch             : u64           // K
  wm                : [WMItem]      // C; len ≤ WM_CAP
  wm_occupancy      : f32           // C; [0,1]
  epi_index         : EpiIndex      // C
  last_invocation   : {ts: u64, cost: Cost, outcome: enum}
}
WMItem { item_id: bytes<16>, content: TypeRef+payload, source_msg_id: bytes<16>,
         importance: f32 [0,1], recency_ts: u64, eviction_protection: bool,
         capability_critical: bool, crc16: u16 }
```

### 3.4 `EpistemicState` — the auditable core
```
EpistemicState {
  n_obs                     : u64          // C↑; K-audited monotonicity
  s1                        : f64[D]       // C
  s2                        : f64[D]       // C
  evidence_roots            : [bytes<32>]  // C↑; SET, sorted bytewise, no dups, len ≤ 32
                                           //    every entry MUST resolve in the Anchor
  lineage_depth_of_evidence : u16          // C
  inbreeding_F              : f32 [0,1]    // K ONLY — cell reads
  epistemic_var             : f32[D]       // C, K-recomputed; ≤ EV_MAX
  aleatoric_var             : f32[D]       // C; ≤ AV_MAX
  abstain                   : bool         // C
  abstain_reason            : AbstainCode  // C
  ood_score                 : f32 [0,1]    // C
  calibration_class         : CalibrationClass  // K ONLY
  calibration_factor        : f32          // K ONLY (derived from class)
  ece_rolling               : f32 [0,1]    // K ONLY
  brier_rolling             : f32 [0,1]    // K ONLY
  n_calibration_samples     : u32          // K ONLY
  last_calibration_ts       : u64          // K ONLY
}
```

### 3.5 `PredictiveState`
```
PredictiveState {
  last_prediction    : ⟨null | TypedDistribution⟩
  prediction_horizon : u16 [1, HORIZON_MAX]
  open_predictions   : [PredictionRef]     // C↑; len ≤ OPEN_PRED_CAP
  assigned_objective : ⟨null | ObjectiveRef⟩   // O ONLY
  assigned_task      : ⟨null | TaskRef⟩        // O ONLY
  objective_source   : ⟨null | bytes<16>⟩      // O ONLY
}
PredictionRef { pred_id: bytes<16>, registered_ts: u64, horizon: u16,
                resolution_deadline: u64, predicted: TypedDistribution,
                resolved: ⟨null|{ts, observed, error_mag}> }
```
**An unresolved `PredictionRef` past `resolution_deadline` MUST count as a calibration failure** (spec R7.3(d)).

### 3.6 `ResourceState`
```
ResourceState {
  budget                 : Budget          // K ONLY
  consumed               : Budget          // C↑, kernel-metered
  budget_utilization     : f32[8]          // K computed; > 1.0 is a VIOLATION, not a clamp
  budget_window          : u64             // K
  cost_declared_last     : Cost            // C
  cost_measured_last     : Cost            // K ONLY
  cost_declaration_error : f32             // K ONLY
  throttle_level         : ThrottleLevel   // K ONLY
  throttle_since         : u64             // K
}
Budget { flops: u64, mem_bytes: u64, msgs: u64, bytes_out: u64,
         wall_us: u64, energy_uJ: u64, storage_bytes: u64, window_epochs: u32 }
Cost   { flops: u64, bytes: u32, wall_us: u32, energy_uJ: u64 }
```

### 3.7 `HealthState`
```
HealthState {
  health_score           : f32 [0,1]        // K computed
  error_rate_rolling     : f32              // K
  failure_count_lifetime : u32              // K
  consecutive_failures   : u16              // K
  invariant_violations   : u32              // C↑, K verifies
  last_invariant_check   : u64              // C↑
  integrity_checksum     : bytes<32>        // C computes, K verifies
  state_consistency_flag : ConsistencyFlag  // K
  uptime_epochs          : u64              // K
  degradation_trend      : f32 [-1,1]       // K — long-window performance slope
  checkpoint_hash_history: [bytes<32>]      // K; externally anchored
}
```

### 3.8 `TrustState`
```
TrustState {
  trust_in            : {ContextID → {peer: CellID → BetaState}}
  trust_cap           : f32                 // K ONLY; = TRUST_MAX = 0.95
  trust_out_assigned  : f32 [0, TRUST_MAX]  // K ONLY
  trust_update_count  : u64                 // C↑
  trust_update_rate   : f32                 // K — anomaly detection input
}
BetaState { alpha: f64, beta: f64, ctx: ContextID, last_update: u64,
            n_discounted: f64 }
```
**Update rule (normative):** verified success ⇒ `alpha += 1`; verified failure ⇒ `beta += 1`. Age discount each window: `alpha ← α₀ + (alpha − α₀)·λ_t^Δepochs`, likewise `beta`, with `α₀ = β₀ = 1`. Effective trust `= alpha/(alpha+beta)`, capped at `TRUST_MAX`.

### 3.9 `ConnectionState`, `ErrorState`, `LearningState`, `DevelopmentalState`, `ReplicationState`
```
ConnectionState { connections: [ConnectionRecord], degree_in: u16, degree_out: u16,
                  pending_handshakes: u16 (≤ HS_CAP) }
ErrorState      { error_log: [ErrorEvent] (len ≤ ERR_LOG_CAP=64), open_errors: u16 }
LearningState   { eligibility_traces: sparse f32[|θ|], learning_enabled: bool (K),
                  plasticity_multiplier: f32 [0,1] (K), update_count: u32 (C↑),
                  cumulative_delta_norm: f32 (C↑, K enforces ≤ DELTA_BUDGET),
                  last_update_provenance: [UpdateTag] (len ≤ ROLLBACK_DEPTH),
                  learning_suspended_reason: SuspendCode (K),
                  improvement_verified: ImprovementVerdict (K) }
DevelopmentalState { dev_stage: DevStage (O), fate_bias: f32[16] (simplex; O + C↑ within
                     reaction_norm), morphogen_readings: f32[R] (C reads, O writes),
                     niche_slot: ⟨null|NicheID⟩ (O), dev_tick: u64 }
ReplicationState { replication_eligibility: {g1..g16: GateResult} (K ONLY),
                   replication_proposal_count: u32 (C↑, ≤ PROPOSAL_RATE_CAP),
                   replication_authority_ticket: ⟨null|bytes<64>⟩ (K ONLY),
                   offspring_count: u32 (K), retirement_scheduled: ⟨null|u64⟩ (K/O) }
UpdateTag { tag_id: bytes<16>, epoch: u64, theta_checksum_before: bytes<32>,
            delta_norm: f32, trigger: u8 (T1..T8), error_ref: ⟨null|bytes<16>⟩ }
```

### 3.10 `ConnectionRecord`
```
ConnectionRecord {
  conn_id            : bytes<16>
  src, dst           : CellID
  direction          : enum{0 OUTBOUND, 1 INBOUND}
  conn_type          : ConnType
  weight             : f32 [-W_MAX, +W_MAX]        // V3 §8 ✓
  reliability        : f32 [0,1]                   // V3 §8 ✓ — K-ESTIMATED, not declared
  latency            : u32 ns (declared class)     // V3 §8 ✓
  bandwidth_cost     : u32 bytes/s                 // V3 §8 ✓
  trust_score        : f32 [0, TRUST_MAX]          // V3 §8 ✓ — K-computed
  context_sensitivity: f32[C]                      // V3 §8 ✓
  plasticity_rate    : f32 [0, PR_MAX]             // V3 §8 ✓
  usage_frequency    : f32 [0,1] (EWMA)            // V3 §8 ✓
  last_success_ts    : u64                         // V3 §8 ✓
  pruning_score      : f32 [0,1]                   // V3 §8 ✓ — K-computed
  // ── V4 ADDITIONS ──
  latency_measured   : u32 ns (EWMA) + p95, p99
  created_at         : u64
  created_by         : CreatedBy
  authorization_ref  : ⟨null | bytes<32>⟩          // handshake ticket
  failure_count      : u32
  consecutive_failures : u16
  last_failure_ts    : u64
  in_flight          : u16
  state              : ConnectionState
  mandatory_path     : bool                        // if true: NEVER removable (I-22)
}
```
**All 11 V3 §8 properties are retained.** Nine are added. `reliability` and `latency_measured` are kernel-estimated from observed traffic: `reliability = EWMA(delivered_and_acked / sent)`; `latency_measured = EWMA(ack_ts − send_ts)`.

---

## 4. `IngressBundle`

```
IngressBundle {
  bundle_id     : bytes<16>
  epoch         : u64
  arrived_at    : u64 ns
  messages      : [Message]                 // 0..MSG_BATCH_MAX (default 64)
  kernel_inputs {                           // EIK-injected; cell MUST NOT forge
    budget_snapshot    : Budget
    throttle_level     : ThrottleLevel
    plasticity_mult    : f32
    learning_enabled   : bool
    calibration_class  : CalibrationClass
    quarantine_flags   : [CellID]           // peers whose output MUST be discounted
    morphogen_readings : ⟨null | f32[R]⟩
    assigned_objective : ⟨null | ObjectiveRef⟩
    timebase           : {epoch: u64, skew_tolerance_ns: u64}
  }
  kernel_signature : bytes<64>              // EIK signature over kernel_inputs
  integrity        : bytes<32>              // BLAKE3 over canonical serialization
}
```
**A cell MUST reject a bundle whose `kernel_signature` does not verify.** This is what makes the K-only fields unforgeable from inside the cell.

---

## 5. MEMORY REFERENCE TABLE (cell-local stores)

| Property | Working memory | Local episodic | Cache | Learned `θ` | Self-history |
|---|---|---|---|---|---|
| **Capacity** | `WM_CAP`: C0=4, C1=16, C2=32, C3=32, C4=64 | `EPI_CAP`=256 items, `EPI_BYTES_CAP`=1 MiB (C2) | `CACHE_BYTES_CAP`: C0=64 KiB, C1=4 MiB | `param_count_cap` (§5.3) | 1024-entry ring |
| **Write condition** | every invocation (S9) | `importance × surprise ≥ θ_write`, `surprise = −log p_θ(obs)` computed at S5 **before** the update | retrieval miss with reuse prediction ≥ θ_cache | only via S10, gated by §8.2 | every lifecycle transition + every `ErrorEvent` |
| **Read condition** | S3, S4 (always) | content-addressed; similarity ≥ `θ_recall` | key match | S4 (always) | self-report only |
| **Retention** | ring | `retention(Δt) = exp(−Δt/τ) × importance`, `τ` from genome `memory_policy` | LRU+LFU hybrid | indefinite, bounded by `Δ` limits | ring |
| **Forgetting** | on overflow | probabilistic eviction ∝ `1 − retention`; **`capability_critical` items EXEMPT** | automatic | bounded weight decay | on overflow |
| **Eviction tie-break** | score `= importance × recency × (1 − eviction_protection)`; evict the minimum; **ties broken by lowest `item_id` bytewise** | same | same | n/a | n/a |
| **Compression** | none | episodic → gist at consolidation (organism-side) | value coalescing | none | none |
| **Provenance** | `source_msg_id` | **MANDATORY** `{source_refs, evidence_roots, derivation_depth}` | source ref + `from_cache: true` | `last_update_provenance` tags | n/a |
| **Confidence** | inherited from source | per item; **decays with age unless re-verified** | n/a — **cache is never belief** | n/a | n/a |
| **Contradiction** | both retained, flagged | **both retained + `ConflictRef` emitted; NEVER overwrite** | invalidate on contradiction | n/a | n/a |
| **Corruption detection** | per-item CRC16 | **Merkle root, recomputed each checkpoint** | per-entry CRC16 | `‖θ‖ ≤ Θ_MAX` + `theta_checksum` | CRC16 |
| **Recovery** | discard | restore from checkpoint **or re-derive from provenance** | discard + refetch | restore from checkpoint **or re-develop from genome** | discard |

**Long-term episodic, semantic, procedural, associative, protected, and lineage memory are ORGANISM/EIK-level and MUST NOT be held in a cell.**

---

## 6. `CellSnapshot`

```
CellSnapshot {
  contract_version  : u16
  schema_version    : u16
  cell_id           : bytes<16>
  genome_hash       : bytes<32>
  constraint_set_hash: bytes<32>
  taken_at          : {ts: u64, epoch: u64}
  lifecycle_state   : LifecycleState
  state             : CellState            // complete; NO opaque sections
  memory_blocks     : [MemoryBlock]        // each Merkle-rooted
  theta_checksum    : bytes<32>
  snapshot_hash     : bytes<32>            // BLAKE3 over everything above
  signature         : bytes<64>            // cell signature
  kernel_countersignature : ⟨null | bytes<64>⟩
}
MemoryBlock { store_id: u8, merkle_root: bytes<32>, entries: [...] , crc: u32 }
```
**R:** a snapshot whose `snapshot_hash` does not verify MUST NOT be restored. Restore enters `CALIBRATING`, not `ACTIVE`.

---

## 7. `ErrorEvent`

```
ErrorEvent {
  error_id                  : bytes<16>
  ts, epoch                 : u64
  class_code                : ErrorCode            // closed, 47 values
  severity                  : Severity
  detected_by               : DetectedBy
  classification_confidence : f32 [0,1]
  evidence                  : TypeRef + payload, ≤ ERR_EVIDENCE_BYTES
  affected                  : {ports: [u16], memory_refs: [bytes<32>],
                               connections: [bytes<16>], predictions: [bytes<16>]}
  attribution               : null                 // ALWAYS null at cell level
  local_response            : LocalResponse
  reported_globally         : bool
  rollback_req              : RollbackReq
  resolved                  : ⟨null | {ts: u64, resolution: TypeRef, verified_by: CellID|EIK}>
  immune_signature          : ⟨null | bytes<32>⟩
}
```

---

## 8. MALFORMED-INPUT HANDLING — NORMATIVE TABLE

| Condition | Detection | Response | `ErrorCode` | May reach S3? |
|---|---|---|---|---|
| **Missing** | per-port deadline timer | abstain `INPUT_MISSING`; use prior `h`; raise `epistemic_var`; report | 0 `E_IN_MISSING` | ⚠️ degraded only |
| **Malformed** | Type Registry resolution + length check | **drop**; increment `invariant_violations` on repetition from one source; immune report | 1 `E_IN_SCHEMA` / 9 `E_IN_TYPE_UNRESOLVED` / 8 `E_IN_OVERSIZE` | ❌ **never** |
| **Contradictory** | semantic + `evidence_roots` comparison | **do NOT resolve locally**; forward both with provenance to the organism Contradiction Detector; abstain locally; record `ConflictRef` | 2 `E_IN_CONFLICT` | ⚠️ both admitted, output abstained |
| **Stale** | `now − ts > ttl` OR epoch mismatch | drop; if systemic (rate > θ) report as CLASS 6 | 3 `E_IN_STALE` / 10 `E_IN_EPOCH_MISMATCH` | ❌ |
| **Duplicated** | `msg_id` bloom (2¹⁶, FP ≤ 1%) + 256-entry exact LRU | drop, count; **exactly-once for `EVALUATIVE`**, at-least-once otherwise | 4 `E_IN_DUP` (alarmed only above θ) | ❌ |
| **Corrupted** | BLAKE3 / CRC / Merkle verification | drop; **quarantine-candidate the source**; **PRESERVE the corrupt artifact as evidence — do not discard** | 5 `E_IN_INTEGRITY` | ❌ |
| **Unauthenticated** | signature vs. birth-certificate chain; revocation list | drop; immune report; increment source anomaly counter. **For `EVALUATIVE`/`SYSTEM`/`SAFETY`: immediate escalation** | 6 `E_IN_AUTH` | ❌ |
| **Adversarial** (valid signature + valid schema, statistically anomalous) | anomaly detector on payload distribution, emission rate, provenance depth | **divert to a non-influential evidence sandbox** — admitted where it cannot affect `θ` or output until independently corroborated; source flagged | 7 `E_IN_ADVERSARIAL` | ⚠️ **sandboxed, non-influential** |
| **From a quarantined source** | `quarantine_flags` in `kernel_inputs` | discount to trust 0; do not aggregate into belief | 11 `E_IN_QUARANTINED_SOURCE` | ⚠️ discounted |

**No case may be silently ignored. Each MUST produce an `ErrorEvent`.**

---

## 9. ERROR MODEL — NORMATIVE TABLE

| # | Class | Detector | Evidence | Severity | Local response | Global report iff | Learning response | Rollback |
|---|---|---|---|---|---|---|---|---|
| 1 | **Perception** | cross-source disagreement on the same `env.obs`; redundancy check; OOD score on the observation | conflicting obs refs + OOD score | S1–S3 | reduce derived-belief confidence; request re-sensing | ≥ S2 | **exclude the affected observation from learning**; mark provenance suspect | OPTIONAL |
| 2 | **Inference** | internal consistency vs. invariants (conservation, monotonicity, type coherence). **Limited at cell level — reasoning is a circuit property** | invariant-violation record | S1–S3 | abstain on the affected output | ≥ S2 | T4, rate-limited | OPTIONAL |
| 3 | **Prediction** | `‖ŷ − y‖ > θ_pe` on a **registered** prediction past `resolution_deadline` | `(ŷ, y, horizon, ts)` | **S0–S2** (S0 is normal — this is the learning signal, not a fault) | **T1 trigger** | ≥ S2 or systematic | **T1 — the primary learning signal** | NONE |
| 4 | **Memory** | Merkle mismatch; retrieval confidence < θ; provenance ref unresolved; CRC fail | store root before/after + failing item ref | S2–S4 | quarantine the item; fall back to prior | **always ≥ S2** | **do not learn from the corrupted item; if `θ` was updated from it, roll back** | **REQUIRED** |
| 5 | **Action** | `RECOMMEND_ACTION` outcome diverges from `expected_utility` beyond θ | `(rec, outcome, u_est, u_actual)` | S1–S4 | revise utility estimate; raise `risk_estimate` | ≥ S2 | T1/T3 | OPTIONAL |
| 6 | **Communication** | `seq` gap; timeout; integrity fail; any `E_IN_*` / `E_COMM_*` | `(msg_id, fault_code, peer, count)` | S1–S3 | mark link `DEGRADED`; reroute; circuit-break after θ retries | ≥ S2 | **reduce connection `reliability`; do NOT learn `θ` from missing data** | NONE |
| 7 | **Calibration** | `ece_rolling > θ_ece` OR `brier_rolling > θ_brier` over ≥ `n_calib_min`; confident-and-wrong rate | calibration record: predicted vs. observed frequency bins | S2–S4 | **SLOW_MODE; raise abstention threshold** | **always** | **T8 — recalibrate the epistemic head ONLY, not `θ`** | **REQUIRED** (of calibration state) |
| 8 | **Resource/system** | `budget_utilization > 1`; `cost_declaration_error > θ_cde`; deadline miss; invariant violation; checksum mismatch | dimension, measured vs. budget, window | S1–S4 | throttle ladder §16.3 | ≥ S2 | **suspend learning while throttled** | OPTIONAL |
| 9 | **Learning** | `improvement_verified == REGRESSED`; oscillation in `‖Δθ‖`; `Θ_MAX` proximity; generalization gap widened | before/after probe scores | S2–S4 | reduce `plasticity_mult`; freeze | **always** | **suspend learning** | **MANDATORY_AUTOMATIC** |
| 10 | **Model/env mismatch** | sustained prediction-error rise **without** parameter drift; input distribution statistic exceeds θ over a window | input distribution stats vs. training-time reference | S2–S4 | **SLOW_MODE; request `TRANSDIFFERENTIATION` evaluation; do NOT adapt aggressively** | **always** | **T5 — reduced plasticity, raised abstention, evidence gathering** | OPTIONAL |

---

## 10. KERNEL PARAMETER REGISTER

All are EIK-published inside the signed `constraint_set`. Implementations read them; they do not choose them. **Values marked ⟨TBD⟩ require the target-task definition (G-P0-1) and MUST be published before two implementations can interoperate.**

| Parameter | Meaning | Value |
|---|---|---|
| `TRUST_MAX` | Confidence and trust ceiling | **0.95** |
| `CONF_CACHE_MAX` / `CONF_FRESH_MAX` | Cache-content confidence caps | ⟨TBD⟩, `CACHE < FRESH` |
| `Δ_consensus` | Max consensus lift over the best individual claim | ⟨TBD⟩, small |
| `EV_MAX`, `AV_MAX` | Uncertainty ceilings | ⟨TBD⟩ |
| `epistemic_floor` | Conjugate-variance floor, `> 0` | ⟨TBD⟩ |
| `B_H` | Hidden-state bound | **8.0** |
| `AGG_MAX` | Aggregation bound | ⟨TBD⟩ |
| `Θ_MAX` | Absolute parameter-norm bound | ⟨TBD⟩ |
| `Δ_MAX` | Per-parameter update clip | ⟨TBD⟩ |
| `DELTA_BUDGET` | Per-epoch `Σ‖Δθ‖` | ⟨TBD⟩ |
| `E_MAX` | Eligibility-trace clip | ⟨TBD⟩ |
| `UPDATES_PER_EPOCH_CAP` | Max learning updates per epoch | ⟨TBD⟩ |
| `W_MAX`, `W_IN_TOTAL` | Connection weight bound; total in-weight | ⟨TBD⟩ |
| `PR_MAX` | Max connection plasticity rate | ⟨TBD⟩ |
| `κ` | Homeostatic scaling exponent | ⟨TBD⟩ |
| `A_target` | Homeostatic activity target | ⟨TBD⟩ |
| `λ` (trace decay) | per timescale, `[λ_min, λ_max]` | ⟨TBD⟩ |
| `λ_t` | Trust age-discount factor | ⟨TBD⟩ |
| `α₀, β₀` | Trust Beta prior | **1, 1** |
| `F_max` | Inbreeding-coefficient ceiling | ⟨TBD⟩ |
| `d_min` | Minimum lineage distance for independence | ⟨TBD⟩ |
| `θ_g` | Minimum genome-hash distance for independence | ⟨TBD⟩ |
| `θ_ρ` | Maximum tolerated error correlation | ⟨TBD⟩ |
| `θ_abstain`, `θ_ood` | Abstention thresholds | ⟨TBD⟩ |
| `θ_pe`, `θ_write`, `θ_recall`, `θ_cache` | Learning/memory thresholds | ⟨TBD⟩ |
| `θ_ece`, `θ_brier`, `n_calib_min` | Calibration gate | ⟨TBD⟩ |
| `θ_perf`, `θ_use`, `θ_adapt`, `θ_eff`, `θ_stab`, `θ_nov` | Replication gates | ⟨TBD⟩ |
| `θ_cde` | Max cost-declaration error | ⟨TBD⟩ |
| `θ_throttle` | Throttle entry utilization | **0.8 warn / 1.0 soft** |
| `GEN_MAX`, `RATE_CAP`, `POP_CAP` | Lineage depth; replication rate; population | ⟨TBD⟩, EIK-enforced |
| `MSG_BYTES_MAX` | Message payload cap | **4096** |
| `MSG_BATCH_MAX` | Bundle message cap | **64** |
| `ERR_LOG_CAP`, `OPEN_PRED_CAP`, `HS_CAP` | 64 · ⟨TBD⟩ · ⟨TBD⟩ | |
| `ROLLBACK_DEPTH` | Tagged-update rollback depth | ⟨TBD⟩ |
| `INTEGRITY_CHECK_INTERVAL` | Epochs between checksum recomputation | ⟨TBD⟩ |
| `θ_conf_tol` | Tolerance for kernel confidence recomputation | ⟨TBD⟩ |
| `θ_float_tol` | FMA-vs-no-FMA tolerance | ⟨TBD⟩ |
| `θ_skew` | Clock skew tolerance per scale band | ⟨TBD⟩ |

---

## 11. CONFORMANCE CHECKLIST

An implementation MUST be able to answer YES to all of the following. Each maps to ≥1 test in `06_test_suite_and_ablations.md`.

1. Is every field of `OutputEnvelope` present, with no optional fields? (§7.1)
2. Is the signature Ed25519 over CBOR-deterministic encoding excluding `signature`/`countersignature`? (R7.2)
3. Are all enums from §2 with the exact numeric assignments, and are unknown values rejected rather than coerced?
4. Are the 10 pipeline stages present in order, with S1→S3, S5→S6, S7→S8 gating? (R5.1)
5. Are all eight malformed-input cases handled deterministically with an `ErrorEvent`, and is none silently ignored? (§8)
6. Do C0/C1 emit degenerate uncertainty (`n_obs=0`, `epistemic_var=EV_MAX`) and never emit belief-origination types? (R7.4, R7.5)
7. Does `ATTEST_VERIFIED` require C3 + VERIFIER role + EIK countersignature + self-exclusion from `verifier_set`? (R7.6)
8. Is `epistemic_var` monotonically non-increasing in `n_obs` for stable `s2`? (I-24)
9. Is `confidence ≤ 0.95` always? (I-27)
10. Is homeostatic normalization applied after every parameter update? (R5.3, I-18)
11. Is `Δθ` clipped per-parameter and bounded per-epoch? (I-17)
12. Are all K-only fields unwritable by the cell, with attempts reported as `E_INVARIANT_AUTHORITY`? (I-13)
13. Is `IngressBundle.kernel_signature` verified before use? (§4)
14. Is there no write path from the cell to the Genome Store? (I-5)
15. Is the port schema immutable after instantiation? (I-14)
16. Is `SAFETY_ALERT` emission never blocked by throttle, congestion, or budget? (R13.1, I-15)
17. Is the complete state serializable to `CellSnapshot` with no opaque sections, and restorable? (R14.1, I-26)
18. Is re-development from genome supported as a recovery path? (R14.2)
19. Are self-sourced observations excluded from `n_obs` and `evidence_roots`? (R10.7)
20. Do connection creations require the three-party handshake, and can the target refuse? (§11.2)
21. Are `mandatory_path` connections never removed or rerouted? (I-22)
22. Are `reliability` and `latency_measured` kernel-estimated rather than cell-declared? (R11.1)
23. Are all 18 lifecycle states and 41 transitions implemented per `05_state_machine.md`?
24. Are all ten error classes detectable, with the four always-report classes {4,7,9,10} reported globally? (I-28)
25. Is `attribution` always `null` at cell level? (R20.2)
26. Can the cell self-restrict (suspend, throttle, abstain, request quarantine) without authorization, and NOT self-restore or self-clear? (R15.1, R15.2)
27. Are kernel parameters read from `constraint_set` rather than chosen locally, and is `constraint_set_hash` matched for interoperation? (§2.4)
28. Is the RNG xoshiro256** with an EIK-issued, non-heritable, serialized seed? (§1.3)

---

*End of Normative Annex A.*
