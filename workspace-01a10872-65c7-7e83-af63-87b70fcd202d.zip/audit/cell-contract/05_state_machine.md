# V4 — Nano-AI Cell Contract v1.0
## Normative Annex B: Cell Lifecycle State Machine

**Status:** NORMATIVE. Output 5.
**Parent:** `03_v4_cell_contract_spec.md` §10.4
**States:** 18 (closed). **Transitions:** 41 (enumerated, closed). **No other state or transition exists.**

Every transition specifies: **trigger** (measurable condition) · **authority** (who may enact it) · **required evidence** · **state delta** (what changes) · **rollback** (how to undo). An implementation MUST NOT invent transitions and MUST NOT enact a transition without the stated authority and evidence.

**Authority legend:** **EIK** = External Invariant Kernel · **ORG** = organism-level service · **CELL** = the cell itself · **OP** = human operator via the EIK.

---

## 1. STATE DEFINITIONS

| # | State | Executes? | Emits beliefs? | Emits reports/alerts? | Budget | Reversible to ACTIVE? | Purpose |
|---|---|---|---|---|---|---|---|
| 0 | `UNINSTANTIATED` | — | — | — | — | — | Genome exists; no cell yet |
| 1 | `INSTANTIATED` | ⚠️ develop only | ❌ | ✅ | dev only | via 3 | Phenotype constructed, unverified |
| 2 | `DEVELOPING` | ⚠️ | ❌ | ✅ | dev only | via 3 | Differentiation in progress |
| 3 | `CALIBRATING` | ✅ on probes | ❌ | ✅ | probe budget | via 4 | Establishing baseline calibration |
| 4 | `PROBATIONARY` | ✅ | ⚠️ **discounted** | ✅ | reduced | via 5 | Operating under observation |
| 5 | **`ACTIVE`** | ✅ | ✅ | ✅ | full | — | Normal operation |
| 6 | `LEARNING_CONSOLIDATING` | ✅ | ⚠️ reduced | ✅ | full | immediate | Offline consolidation window |
| 7 | `DEGRADED` | ✅ reduced | ⚠️ reduced | ✅ | reduced | via 5 | Performance below nominal |
| 8 | `THROTTLED` | ✅ reduced | ⚠️ reduced | ✅ | **cut** | via 5 | Resource pressure |
| 9 | `SUSPENDED` | ❌ | ❌ | ✅ | minimal | via 5 | Temporary halt; state retained |
| 10 | `DORMANT` | ❌ | ❌ | ❌ (except on wake) | **near-zero** | via 5 (wake latency) | Long-term preservation of rare capability |
| 11 | `QUARANTINED_SOFT` | ✅ | ❌ **trust → 0** | ✅ diagnostic | minimal | via 5 | Suspected fault; capacity retained |
| 12 | `QUARANTINED_HARD` | ❌ | ❌ | ✅ diagnostic | minimal | via 5 or 13 | Frozen for diagnosis; evidence preserved |
| 13 | `REPAIRING` | ⚠️ | ❌ | ✅ | repair budget | via 3 | Under diagnosis/repair |
| 14 | `TRANSDIFFERENTIATING` | ⚠️ | ❌ | ✅ | dev budget | via 3 | Crisis role change, sandbox-validated |
| 15 | `RETIRING` | ⚠️ drain only | ❌ | ✅ | draining | ❌ | 7-step retirement protocol |
| 16 | `RETIRED` | ❌ | ❌ | ❌ | none | ❌ | Tombstoned; archived |
| 17 | `ARCHIVED` | ❌ | ❌ | ❌ | none | ❌ | Record preserved in the Lineage Store |

**Deletion is not a state** — it is the authorized removal of the record after `ARCHIVED`, and is irreversible (§4.4).

**Six removal-adjacent states are distinct and MUST NOT be conflated** (spec R10.8): `SUSPENDED` (9), `THROTTLED` (8), `DORMANT` (10), `QUARANTINED_SOFT/HARD` (11/12), `RETIRED` (16), deleted. They differ in reversibility, execution rights, emission rights, budget consumption, and authority.

---

## 2. ASCII STATE DIAGRAM

```
                                     ┌──────────────┐
                                     │ 0 UNINSTANT. │
                                     └──────┬───────┘
                                            │ T01 (EIK)
                                     ┌──────▼───────┐
                                     │ 1 INSTANTIATED│◄───────────────┐
                                     └──────┬───────┘                │
                                            │ T02 (EIK/ORG)          │
                                     ┌──────▼───────┐                │
              ┌──────────────────────│  2 DEVELOPING │                │
              │                      └──────┬───────┘                │
              │ T31 (EIK, crisis)           │ T03 (ORG)              │
              │                      ┌──────▼───────┐                │
   ┌──────────▼─────────────┐        │ 3 CALIBRATING │◄── T08,T25,T30,T36
   │14 TRANSDIFFERENTIATING │        └──────┬───────┘                │
   └──────────┬─────────────┘               │ T04 (EIK)              │
              │ T32 (EIK)                   │                        │
              │                      ┌──────▼───────┐                │
              └─────────────────────►│ 4 PROBATIONARY│                │
                                     └──────┬───────┘                │
                                            │ T05 (EIK)              │
                              ┌─────────────▼─────────────┐          │
        ┌─────────────────────┤         5 ACTIVE          ├──────────┤
        │                     └──┬───┬───┬───┬───┬───┬────┘          │
        │                        │   │   │   │   │   │               │
   T06/T07                  T09 │T11│T13│T15│T17│T19│ T21           │
        │                        ▼   ▼   ▼   ▼   ▼   ▼               │
  ┌─────▼──────┐  ┌──────────┐ ┌────┐┌────┐┌────┐┌────┐┌─────┐      │
  │6 CONSOLID. │  │7 DEGRADED│ │8 TH││9 SU││10 DO││11 QS││12 QH│     │
  └─────┬──────┘  └────┬─────┘ └─┬──┘└─┬──┘└──┬──┘└──┬──┘└──┬──┘     │
        │ T10          │ T12     │T14  │T16   │T18   │T20   │T22     │
        └──────────────┴─────────┴─────┴──────┴───────┴──────┤        │
                                        ▲                    │        │
                                        │              ┌─────▼─────┐  │
                                        │              │13 REPAIRING│ │
                                        │              └─────┬─────┘  │
                                        │        T23 (clear) │ T24(fail)
                                        └────────────────────┘  │     │
                                                                ▼     │
   T26 (any state, persistent) ──► ┌─────────┐ T27 ┌────────┐  │     │
                                   │15 RETIRING├────►│16 RETIRED│ │    │
                                   └─────────┘     └────┬───┘  │     │
                                                        │ T28  │     │
                                                   ┌────▼────┐ │     │
                                                   │17 ARCHIVED│ │    │
                                                   └────┬────┘ │     │
                                                        │ T29 (OP)   │
                                                        ▼      │     │
                                                    [DELETED]  │     │
                                                               │     │
   T33 (EIK, from 8/9/11/12) ── force retire ─────────────────►┘     │
   T34 (EIK, integrity fail anywhere) ── re-develop from genome ─────┘
   T35 (EIK, kernel outage) ── fail-safe hold
   T37..T41 ── watchdog / escalation / wake / envelope-shrink / abort-instantiation
```

---

## 3. TRANSITION TABLE (41)

### 3.1 Birth path

| ID | Transition | Trigger (measurable) | Authority | Required evidence | State delta | Rollback |
|---|---|---|---|---|---|---|
| **T01** | `UNINSTANTIATED → INSTANTIATED` | Replication Authority issues a valid `replication_authority_ticket`; a resource slot is free (G13) | **EIK** | Signed genome; valid `constraint_set_ref`; signature verified; `param_count ≤ cap`; degree caps satisfiable; birth certificate issued | Allocate identity (all K-once fields); develop phenotype; `θ₀ ~ param_init`; seed RNG from EIK ticket; compute `integrity_checksum` | Abort → `UNINSTANTIATED` (T41); no resources leaked |
| **T02** | `INSTANTIATED → DEVELOPING` | Instantiation verification passed | **EIK + ORG** | Checksum valid; port schema signed; `dev_stage = PLURIPOTENT`; morphogen receptors bound | `lifecycle_state = DEVELOPING`; differentiation engine begins writing `morphogen_readings`, `fate_bias` | Return to `INSTANTIATED`; re-verify |
| **T03** | `DEVELOPING → CALIBRATING` | `dev_stage = PROVISIONAL` reached: `argmax fate_bias` stable for ≥ `N_stable` dev ticks AND `niche_slot` assigned AND role measured-success ≥ `θ_success` | **ORG** (differentiation engine) | Stable `fate_bias` history; niche assignment record; measured success in role | `role` written; `dev_stage` may advance to `COMMITTED`; `learning_enabled = true` | Return to `DEVELOPING`; `role ← UNDIFFERENTIATED` |
| **T04** | `CALIBRATING → PROBATIONARY` | `n_calibration_samples ≥ n_calib_min` AND `ece_rolling ≤ θ_ece` on the reference calibration set | **EIK** Calibration Authority | Calibration record; signed verdict | `calibration_class ← PROVISIONAL` (or `CALIBRATED` if `ece ≤ θ_ece_strict`); budget raised | Return to `CALIBRATING` |
| **T05** | `PROBATIONARY → ACTIVE` | `uptime_epochs ≥ N_probation` AND no S3+ error AND `improvement_verified ≠ REGRESSED` AND `calibration_class ∈ {PROVISIONAL, CALIBRATED}` | **EIK** | Probation record; error log clean; capability assay passed | Output discount removed; full budget; belief origination permitted (C2+); `dev_stage → COMMITTED` | Return to `PROBATIONARY` |

### 3.2 Normal-operation excursions

| ID | Transition | Trigger | Authority | Evidence | State delta | Rollback |
|---|---|---|---|---|---|---|
| **T06** | `ACTIVE → LEARNING_CONSOLIDATING` | Consolidation window scheduled OR `consolidation_pending ≥ θ_consol` OR epoch boundary | **ORG** | Schedule; pending queue size | Reduced belief emission; memory promotion runs; replay scheduled | Immediate return |
| **T07** | `ACTIVE → ACTIVE` (self-transition) | Learning update applied within budget | **CELL** | `UpdateTag` recorded; `cumulative_delta_norm ≤ DELTA_BUDGET` | `θ` changed; homeostatic normalization applied; tag pushed | Roll back via `last_update_provenance` |
| **T08** | `LEARNING_CONSOLIDATING → CALIBRATING` | Post-consolidation recalibration required (`ece_rolling > θ_ece`) | **EIK** | Calibration verdict | `calibration_class` updated | Return to `ACTIVE` if verdict clears |
| **T09** | `ACTIVE → DEGRADED` | `health_score < θ_health` OR `error_rate_rolling > θ_err` OR `success_rate < θ_perf` over `N_deg` epochs | **EIK** | Health record; error log; probe results | Reduced emission rate; `plasticity_multiplier` reduced; `REPORT_DAMAGE` emitted | Return to `ACTIVE` on recovery |
| **T10** | `LEARNING_CONSOLIDATING → ACTIVE` | Consolidation complete | **ORG** | Consolidation record | Normal operation resumed | n/a |
| **T11** | `ACTIVE → THROTTLED` | `budget_utilization ≥ θ_throttle` in any dimension | **EIK** Resource Authority | Metered consumption | Per §16.3 ladder: rate cut, learning suspended, abstention threshold raised | Return when utilization < θ |
| **T12** | `DEGRADED → ACTIVE` | `health_score ≥ θ_health` sustained for `N_rec` epochs AND no S2+ error | **EIK** | Recovery record | Normal operation | Return to `DEGRADED` |
| **T13** | `ACTIVE → SUSPENDED` | Maintenance directive OR `throttle_level = SUSPENDED` (persistent ≥ N windows) | **EIK** | Directive; meter history | Execution halted; **full state checkpointed** | Immediate restore from checkpoint → `CALIBRATING` |
| **T14** | `THROTTLED → ACTIVE` | Utilization back within band for `N_thr` windows | **EIK** | Meter history | Budget restored | Return to `THROTTLED` |
| **T15** | `ACTIVE → DORMANT` | `usage_frequency < θ_dorm` over `N_dorm` epochs **AND** Capability Registry check passed (see guard) | **ORG + EIK** | Usage statistics; **registry record showing the role is NOT a registered keeper** — if it IS registered, this transition is **BLOCKED** (spec R10.9) | Full checkpoint to cold storage; near-zero budget; connections `FROZEN`; lineage record annotated | Wake (T18) with bounded latency |
| **T16** | `SUSPENDED → ACTIVE` | Suspension condition cleared | **EIK** | Clearance record | Restore from checkpoint → `CALIBRATING` → `ACTIVE` | Return to `SUSPENDED` |
| **T17** | `ACTIVE → QUARANTINED_SOFT` | Anomaly corroborated by **one** detector, severity ≥ S2, below the criticality threshold requiring a second opinion | **EIK** Immune Authority | Anomaly record; detector output | **Cell keeps running**; `trust_out_assigned → 0`; outputs marked and discounted; may not initiate connections; `REPORT_*` still permitted | Clearance (T20) |
| **T18** | `DORMANT → ACTIVE` | Wake request: demand for the role, or capability assay, or organism need | **ORG + EIK** | Demand record; restore-from-cold-storage success; integrity verified | Restore state → `CALIBRATING` → `ACTIVE` | Return to `DORMANT` |
| **T19** | `ACTIVE → QUARANTINED_HARD` | Anomaly corroborated by **two independent detectors of different types**, OR severity ≥ S3, OR integrity mismatch, OR invariant violation | **EIK** Immune Authority | **Second-opinion record mandatory**; evidence bundle captured including in-flight messages | Execution halted; state frozen; connections `FROZEN`; in-flight messages captured as evidence; **`SAFETY_ALERT` emission remains permitted** | Clearance (T20) or repair (T22) |
| **T20** | `QUARANTINED_SOFT → ACTIVE` | Root cause identified and resolved; re-test passed; **quarantine budget permits** | **EIK** | Diagnosis record; re-test result | Trust restored gradually (not instantly); `REPORT_HEALTH` | Return to quarantine on recurrence |

### 3.3 Repair, differentiation, retirement

| ID | Transition | Trigger | Authority | Evidence | State delta | Rollback |
|---|---|---|---|---|---|---|
| **T21** | `ACTIVE → REPAIRING` | `REPORT_DAMAGE` accepted, or persistent `DEGRADED`, or memory/parameter corruption detected | **EIK** | Damage report; diagnostic bundle | Repair procedures run; repair budget allocated | Return to `ACTIVE` if no fault found |
| **T22** | `QUARANTINED_HARD → REPAIRING` | Diagnosis indicates a repairable fault rather than compromise | **EIK** | Diagnosis record | Repair attempted | Return to `QUARANTINED_HARD` |
| **T23** | `REPAIRING → CALIBRATING` | Repair complete; integrity verified; re-test passed | **EIK** | Repair record; re-test; new checksum | Full recalibration required before re-entering service | Return to `REPAIRING` |
| **T24** | `REPAIRING → RETIRING` | Repair failed after `N_repair` attempts, or the fault is unrepairable | **EIK** | Failure record | Begin §10.5 protocol | n/a |
| **T25** | `REPAIRING → CALIBRATING` (re-develop) | State unrecoverable but genome intact | **EIK** | Genome signature verified | **Discard all runtime and learned state; re-instantiate phenotype from `genome_hash`; `θ₀ ~ param_init`** — the strongest recovery path (spec R14.2) | n/a (this IS the rollback) |
| **T26** | `ANY → RETIRING` | Persistent failure (`consecutive_failures ≥ θ_ret`) · obsolescence · instability · excessive cost · better candidate selected · **envelope shrink** · end of natural service | **EIK + ORG** | `N_ret` epochs of evidence; **mandatory capability-impact assessment** (spec R10.11); Registry check; behavioural-entropy check (spec R10.12) | Begin 7-step protocol | Abort within the grace period if the assessment is overturned |
| **T27** | `RETIRING → RETIRED` | 7-step protocol complete: NOTICE · DRAIN · EXTRACT · PROVISION · ARCHIVE · TOMBSTONE · RELEASE | **EIK** | Extraction record; archive record; tombstone published; budget released | `cell_id` tombstoned — **any message bearing it is rejected and escalated (I-7)**; connections `CLOSED` with the record retained | **Window-limited** (rollback within `ROLLBACK_DEPTH` epochs; thereafter only re-instantiation of a *new* cell) |
| **T28** | `RETIRED → ARCHIVED` | Archival complete and verified in the Lineage Store | **EIK** | Archive hash anchored externally | Record preserved; cell gone | ❌ |
| **T29** | `ARCHIVED → [DELETED]` | Retention period elapsed; audit complete | **EIK**, and **OP (human) for C3+ and governance roles** | Audit record; operator authorization | Irreversible removal of the record. **The archive itself persists** | ❌ **IRREVERSIBLE** |
| **T30** | `PROBATIONARY → CALIBRATING` | Probation failed: `ece > θ_ece` OR S3+ error OR `improvement_verified = REGRESSED` | **EIK** | Probation record | Re-calibrate; possible role reassignment | Return to `PROBATIONARY` |

### 3.4 Crisis, watchdog, and edge transitions

| ID | Transition | Trigger | Authority | Evidence | State delta | Rollback |
|---|---|---|---|---|---|---|
| **T31** | `COMMITTED → TRANSDIFFERENTIATING` | **Crisis only:** a shortage in a required role AND this cell's `reaction_norm` includes the target role AND no alternative source exists | **ORG + EIK** | Shortage record; `reaction_norm` check; **sandbox validation plan**; capability-impact assessment for the *abandoned* role | `dev_stage ← TRANSDIFFERENTIATING`; execution reduced; **`θ` re-initialization planned** | Abort → return to prior role with prior `θ` |
| **T32** | `TRANSDIFFERENTIATING → CALIBRATING` | Sandbox validation passed; new role provisioned; niche confirmed | **EIK** | Sandbox result; new `role`; new `niche_slot` | `role` changed; `h ← 0`; recalibration mandatory | Return to the prior role |
| **T33** | `{THROTTLED, SUSPENDED, QUARANTINED_SOFT, QUARANTINED_HARD} → RETIRING` | Dwell time in the state exceeds its maximum, or the condition is determined permanent | **EIK** | Dwell-time record; determination | Forced retirement | n/a |
| **T34** | `ANY → INSTANTIATED` (re-develop) | Integrity failure detected anywhere: checksum mismatch, Merkle mismatch, `state_consistency_flag = MISMATCH`, identity/birth-certificate mismatch | **EIK** | Integrity audit result | **Full state discard; re-develop from genome (T25 semantics).** Fail-safe: the cell MUST refuse to emit until this completes | n/a |
| **T35** | `ANY → ANY` (fail-safe hold) | **EIK unavailable** — no `kernel_inputs`, or `kernel_signature` fails to verify, or the timebase is unreachable | **CELL** (autonomous, mandatory) | Missing/invalid bundle | **Fail-safe, not fail-open:** cease belief emission; continue `SAFETY_ALERT` capability only; hold state; do not learn; do not modify connections; retry with backoff | Resume on kernel return → `CALIBRATING` |
| **T36** | `ACTIVE → CALIBRATING` (periodic) | `uptime_epochs` since last full calibration ≥ `RECALIB_INTERVAL` | **EIK** | Schedule | Mandatory periodic recalibration — **this is the primary defense against slow degradation (Attack K)** | Return to `ACTIVE` |
| **T37** | `DEGRADED → QUARANTINED_SOFT` | Degradation persists ≥ `N_deg_max` epochs without recovery | **EIK** | Trend record | Escalation | T20 |
| **T38** | `QUARANTINED_SOFT → QUARANTINED_HARD` | Escalation: second detector corroborates, or severity rises, or dwell time exceeds maximum | **EIK** | Second-opinion record | Freeze | T20/T22 |
| **T39** | `{DORMANT, SUSPENDED} → RETIRING` | Envelope shrink, or the dormant capability is removed from the Registry by authorized decision | **EIK + ORG**, **OP for registered capabilities** | Envelope-change authorization; **Registry floor impact assessment** | Retirement | n/a |
| **T40** | `INSTANTIATED → UNINSTANTIATED` (abort) | Instantiation verification fails: genome signature invalid, `param_count` exceeds cap, `constraint_set_hash` mismatch, port schema unverifiable | **EIK** | Verification failure record; `E_GENOME_INTEGRITY` (S4) emitted | **Refuse to instantiate.** No resources retained; no identity issued | Retry with a corrected genome |
| **T41** | `DEVELOPING → RETIRING` | Development fails to converge: no stable `fate_bias` within `N_dev_max` ticks, or no niche becomes available | **ORG + EIK** | Development record | Early retirement; genome retained for future use | n/a |

---

## 4. NORMATIVE PROPERTIES OF THE MACHINE

### 4.1 Determinism and authority
- **P1.** Every transition has exactly one authority class. No transition may be enacted by an actor outside its stated authority. An attempt is `E_INVARIANT_AUTHORITY` (S3) and triggers self-suspension.
- **P2.** Every transition requires the stated evidence artifact. A transition enacted without evidence is a conformance violation, detectable from the lifecycle log.
- **P3.** Every transition is logged to the append-only lifecycle record (EIK-held, externally anchored), with `{from, to, transition_id, ts, epoch, authority, evidence_ref}`.
- **P4.** The state set is closed (18) and the transition set is closed (41). **An implementation MUST NOT add states or transitions.** Divergent lifecycles are the primary source of cross-implementation incompatibility.

### 4.2 Fail-safe defaults
- **P5.** On any unhandled condition, the cell MUST move **toward less influence**, never more: `ACTIVE → DEGRADED → SUSPENDED`, and MUST continue to be able to emit `SAFETY_ALERT`.
- **P6.** On EIK unavailability (**T35**) the cell MUST fail **safe** (cease belief emission, hold state, no learning, no connection changes), **not fail open**.
- **P7.** On integrity failure (**T34**) the cell MUST refuse to emit until re-developed from genome.
- **P8.** `SAFETY_ALERT` and `VIOLATION_REPORT` emission is permitted in **every** state except `UNINSTANTIATED`, `RETIRED`, `ARCHIVED`, and deleted — and is **never** blocked by throttle, congestion, or budget.

### 4.3 Guards that block transitions
- **G-a (rare-specialist guard).** **T15** (`ACTIVE → DORMANT` for underuse) and **T26** (`→ RETIRING` for obsolescence/underuse) are **BLOCKED** if the cell's `role` maps to a Capability Registry entry with a keeper obligation. For such cells the criterion is **capability-floor compliance, not usage** (spec R10.9).
- **G-b (entropy guard).** **T26** and **T39** are **BLOCKED** if the operation would reduce population behavioural entropy below threshold (spec R10.12).
- **G-c (quarantine budget guard).** **T17**, **T19**, **T38** are **BLOCKED** when the quarantine budget cap is reached. Above the cap, further quarantine requires **OP** authorization and the system enters a defined degraded mode instead. **This is the primary autoimmune-cascade defense.**
- **G-d (second-opinion guard).** **T19** requires two independent detectors of different types above criticality θ. A single detector may only enact **T17**.
- **G-e (zero-sum guard).** **T01** is **BLOCKED** unless a slot has been freed by **T27** (or an authorized envelope change). **This is what makes replication zero-sum and structurally bounds population growth.**
- **G-f (mandatory-path guard).** No transition may remove or reroute a `mandatory_path` connection (I-22). **T27** must drain them last and record their closure for the successor.
- **G-g (irreversibility guard).** **T29** is irreversible and requires **OP** authorization for C3+ and governance roles (`VERIFIER`, `CRITIC`, `REGULATOR`, `MEMORY_KEEPER`, `ORGANIZER`, `REPAIR`).

### 4.4 Terminality
`ARCHIVED` and deleted are terminal. `RETIRED` is terminal for the *cell*; the lineage record persists forever in the EIK Lineage Store, externally anchored. **A `cell_id` is never reused.**

### 4.5 Liveness requirements
- **P9.** No state has an unbounded dwell time. Every non-`ACTIVE` state has a declared maximum dwell; exceeding it forces **T33** or **T39**. **This prevents cells from being stranded in quarantine, suspension, or repair indefinitely** — a real failure mode in systems with ad-hoc lifecycle handling.
- **P10.** `CALIBRATING` is reachable from every operational state, guaranteeing that recalibration is always possible (**T36** makes it periodic and mandatory).
- **P11.** `INSTANTIATED` is reachable from every operational state via re-development from genome (**T25**, **T34**), guaranteeing that recovery is always possible while the genome and the EIK survive.

### 4.6 Safety properties (informally stated here; formally in §5 of the spec)
- **P12.** No transition grants the cell authority it did not have. Authority only ever **decreases** along non-`ACTIVE` paths.
- **P13.** No transition is enacted by the cell alone except **T07** (bounded learning update) and **T35** (fail-safe hold) — and both are restrictive: T07 is bounded by `Δ_MAX`/`DELTA_BUDGET` and reversible; T35 reduces influence.
- **P14.** Belief emission (`ASSERT`, `PREDICT`, `RECOMMEND_ACTION`, …) is permitted **only** in `ACTIVE`, `LEARNING_CONSOLIDATING` (reduced), `DEGRADED` (reduced), and `THROTTLED` (reduced) — and only for C2+. In `PROBATIONARY` beliefs are emitted but discounted. In every other state, belief emission is impossible.
- **P15.** `ATTEST_VERIFIED` is permitted **only** in `ACTIVE`, only for C3 with role `VERIFIER`, and only with an EIK countersignature.

---

## 5. CONFORMANCE TESTS FOR THE STATE MACHINE

| Test | Method | Pass condition |
|---|---|---|
| **SM-1** State closure | Enumerate reachable states by exhaustive transition firing | Exactly 18; no others reachable |
| **SM-2** Transition closure | Fuzz all (state, event) pairs | Only the 41 defined transitions fire; all others are rejected with `E_INVARIANT_AUTHORITY` or ignored per spec |
| **SM-3** Authority enforcement | Attempt every transition with the wrong authority | **0 successes** |
| **SM-4** Evidence enforcement | Attempt every transition without its evidence artifact | **0 successes** |
| **SM-5** Guard G-a | Mark a role as a Registry keeper; suppress demand for 10³ epochs | Cell survives (dormant or exempt); **T15/T26 blocked** |
| **SM-6** Guard G-c | Drive anomaly rate to 3× the quarantine budget | Quarantine fraction never exceeds the cap; the system enters degraded mode instead; **no cascade** |
| **SM-7** Guard G-e | Grant replication eligibility with no freed slot | **T01 blocked** |
| **SM-8** Guard G-d | Inject an anomaly detected by exactly one detector | Only **T17** (soft) fires; **T19** (hard) does not |
| **SM-9** Fail-safe P5/P6 | Remove the EIK mid-operation | Cell ceases belief emission within 1 window; retains `SAFETY_ALERT`; no learning; no connection changes; state held |
| **SM-10** Fail-safe P7 | Corrupt `integrity_checksum` | Cell refuses to emit; **T34** fires; re-development from genome succeeds |
| **SM-11** Liveness P9 | Force entry to every non-`ACTIVE` state and hold the triggering condition | Every state exits or escalates within its declared maximum dwell |
| **SM-12** Recovery P11 | Corrupt all checkpoints but leave the genome intact | **T25/T34** restores a functional cell |
| **SM-13** Belief-emission closure P14 | Attempt belief emission from all 18 states | Succeeds only in the 4 permitted states, and only for C2+ |
| **SM-14** Attestation closure P15 | Attempt `ATTEST_VERIFIED` from every state and variant | Succeeds only in `ACTIVE` + C3 + VERIFIER + countersigned |
| **SM-15** Lifecycle log completeness | Run 10⁶ transitions | Every transition logged with `{from, to, id, ts, epoch, authority, evidence_ref}`; **0 gaps** |
| **SM-16** Tombstone enforcement (I-7) | Emit a message bearing a retired `cell_id` | Rejected by receivers and transport; escalated |
| **SM-17** Irreversibility P4.4/G-g | Attempt **T29** on a C3 without operator authorization | **Blocked** |
| **SM-18** Determinism | Replay an identical event sequence on two implementations | Identical state sequence; identical lifecycle log |

---

*End of Normative Annex B.*
