# P0.1 — MINIMAL NANO-AI CELL CONTRACT
## Deliverable index

**Task:** Adversarial specification and formalization of the Nano-AI cell for the Digital Brain V4 architecture.
**Upstream:** `../01_adversarial_architecture_audit.md` (V3/V3.1 audit) — failures F1, F3; missing subsystem M03; §A.
**Constraint honoured:** no software implemented; no whole-brain design; no consciousness or AGI claim.

---

## Files

| File | Contents | Status | Outputs covered |
|---|---|---|---|
| **`02_cell_contract_analysis.md`** | Volume A — the adversarial analysis. Tasks 1–19, 21–29: substrate decision, cell contract, complete state tables, computational substrate, input/output/memory/learning/error/uncertainty/self-model/communication/connection/specialization/replication/retirement/immunity/resource contracts, variants, hardware independence, invariants, **15 adversarial attacks**, minimality test, **24 resolved implementability ambiguities**, testability, ablation, dependency map, gap classification, rule compliance | Analysis + normative | **1–3, 14, 15, 19** and the reasoning behind all others |
| **`03_v4_cell_contract_spec.md`** | Volume B — **V4 Nano-AI Cell Contract v1.0**. The clean canonical specification. 23 sections, requirement-numbered (R*), no analysis prose | **NORMATIVE — canonical** | **20** |
| **`04_formal_schemas.md`** | Annex A — encoding & primitives, **12 closed enumerations with numeric assignments**, complete state schema (~110 fields), `IngressBundle`, memory reference table, `CellSnapshot`, `ErrorEvent`, malformed-input table, error-model table, **kernel parameter register**, 28-point conformance checklist | **NORMATIVE** | **4** |
| **`05_state_machine.md`** | Annex B — **18 closed states, 41 enumerated transitions**, each with trigger / authority / evidence / state delta / rollback; 15 normative properties; 7 transition guards; 18 state-machine tests | **NORMATIVE** | **5** |
| **`06_test_suite_and_ablations.md`** | Annex C — **62 conformance tests in 9 families** with numeric pass conditions, **22 ablations** with pre-registered protocol, dependency map, recommended build sequence, 17-test minimum viable subset | **NORMATIVE** (tests) / planning (ablations) | **16, 17, 18** |

Outputs 6–13 and 19 are distributed across Volumes A and B by subject: I/O contract (A §6–7, B §7–8, Annex A §8) · learning (A §9, B §8) · uncertainty (A §11, B §9) · replication/retirement (A §16–17, B §10, §12) · security (A §18, B §15) · resources (A §19, B §16) · variants (A §21, B §17) · invariants (A §24, B §19) · adversarial results (A §25) · gaps (A §31, B §22).

---

## The four findings that matter most

### 1. What a cell is
> **A cryptographically-identified, resource-bounded, typed probabilistic transducer with bounded memory and bounded plasticity, executed as a single-addressable actor, whose heritable structure is externally owned and whose epistemic state is externally auditable.**

A cell is **not** an agent, a reasoner, a planner, a verifier of its own claims, a self-replicator, its own immune authority, a memory authority, or a trust authority. Reasoning is a *circuit* property. The governing separation is: **a cell REPORTS; the organism INTERPRETS; the kernel ENFORCES.**

### 2. The minimality finding — and it changes the architecture
The smallest *contract-satisfying* cell (C0) costs ~10 KFLOP and ~10 KB. The smallest cell that can *participate in learning, communication, adaptation and evolution* (C2) costs ~100 MFLOP and ~5 MB — roughly **10⁴× the compute**.

That ratio makes the variant model not an optimization but a **precondition for feasibility**: a smartphone supports ~200 C2 cells or ~20,000 C0 cells. The load-bearing safety property that falls out is **belief-origination restriction** — C0 and C1 structurally cannot emit `ASSERT`, `PREDICT`, or `RECOMMEND_ACTION`, and must declare maximum epistemic uncertainty. **The ~20,000 cheap cells that make a phone deployment viable cannot originate a claim.**

The audit also found that V3's cell — with 5 memory types, reasoning, simulation, verification participation, self-model, and replication logic — would be a C4-class object at 1–10 GFLOP, supporting **~2–20 cells on a smartphone**. V3's cell is not implementable at any useful population size. Nineteen capabilities were relocated out of the cell.

### 3. Confidence finally has a producer
Audit failure F3 was: *confidence is consumed by ~14 subsystems and produced by none.* Resolution: the cell produces **sufficient statistics** (`n_obs`, `s1`, `s2`, `evidence_roots`), not a scalar. The kernel produces `inbreeding_F`, `calibration_class`, `provenance_quality`, and `trust_out_assigned`. The emitted `confidence` is cell-computed arithmetic over kernel-supplied factors and is **recomputed and validated by the transport on receipt**.

Choosing conjugate statistics over an ensemble is the key trade: O(D) instead of O(k·D) — cheap enough for constrained hardware — **and strictly more auditable**, because sufficient statistics are inspectable and recomputable while an ensemble's spread is not. `epistemic_var` monotonicity in `n_obs` becomes a **kernel-checkable lie detector** (I-24).

Independence is resolved arithmetically: aggregation de-duplicates by `evidence_roots`, partitions by lineage, discounts by measured error correlation, and **caps consensus lift**. Ten cells citing one source contribute `n_effective = 1`. This operationalizes V3 §12's "consensus ≠ truth" as arithmetic rather than as a slogan, and resolves audit contradiction C9.

### 4. Three structural relocations from V3 — all flagged, none silent
| V3 placed inside the cell | V4 relocates to | Why |
|---|---|---|
| **"Immutable safety layer"** (§4) | **External Invariant Kernel**, referenced by `constraint_set_hash` | Immutability inside a mutable, evolvable, self-modifying object is a preference, not a property. Audit F4. **24 of 28 invariants are EIK-enforced.** The cell contains no safety layer; the cell is *subject to* one |
| **Replication** (§4) | **EIK Replication Authority** | A cell that can decide to replicate itself acquires an implicit survival objective, and every gate becomes a manipulation target. The cell retains a *read-only eligibility report* and no authority. Attack D is closed **structurally** — no write path exists |
| **Protected memory** (§11) and **microglial immune authority** (§7) | **EIK** | A cell that can write protected memory can rewrite the organism's past. A cell-level immune authority is a capture target — whoever can quarantine can silence |

---

## The final standard

> *«Two competent engineering teams can independently implement a Nano-AI cell and have their cells interoperate within the same Digital Brain without needing undocumented assumptions.»*

### Verdict: **MET for the contract. NOT MET for the parameterization.**

**Met.** Every interoperation-relevant degree of freedom is pinned: CBOR deterministic encoding with defined signature coverage · closed Type Registry · **12 closed enums with explicit numeric assignments** · no optional envelope fields · pinned time/float/RNG/crypto/hash semantics · explicit conjugate formulas per output kind · the 18-state / 41-transition closed lifecycle machine · and a **62-test executable conformance suite**. Two teams passing that suite will interoperate. **24 P0 ambiguities were identified and all 24 are resolved. Zero P0 ambiguities remain.**

**Not met — and the reason is upstream, not internal.** Two teams would build interoperable cells whose `θ_abstain`, `θ_write`, `WM_CAP`, `param_count_cap` and variant cost ranges are all *arbitrary*, because:
1. **No target tasks exist** — correctness is task-relative. 6 open items and every numeric threshold depend on this.
2. **No EIK exists, not even a stub** — 24 of 28 invariants are EIK-enforced and 40+ state fields are K-written, so conformance would be *asserted* rather than *demonstrated*.
3. **No published `constraint_set`** — `constraint_set_hash` must match for interoperation, so interoperation itself is blocked.

**Interoperable ≠ correct.** That distinction is the honest bottom line.

**Recommended sequence:** define tasks → build a stub EIK and publish a signed `constraint_set` → Type Registry skeleton → implement C0 then C2 → run the conformance suite → calibrate thresholds empirically → run the ablation plan → proceed to transport and calibration. **Implementing cells before the stub kernel exists would produce untestable code against 24 externally-enforced invariants.**

---

## Adversarial results — honest score

| Attack | Verdict | Residual | | Attack | Verdict | Residual |
|---|---|---|---|---|---|---|
| A Self-reinforcing false belief | PARTIAL | **HIGH** | | I Lineage correlation | BOUNDED | MEDIUM |
| B Confidence inflation | **CONTAINED** | LOW | | J Evolutionary exploit | PARTIAL | **HIGH — fundamental** |
| C Reward hacking | PARTIAL | **HIGH — fundamental** | | K Slow degradation | BOUNDED | MED-HIGH |
| D Replication attack | **CONTAINED** | LOW-MED | | L Quarantine cascade | **CONTAINED** | LOW-MED |
| E Resource attack | **CONTAINED** | LOW | | M Rare-specialist extinction | CONTAINED/PARTIAL | MEDIUM |
| F Memory poisoning | BOUNDED | MEDIUM | | N Hardware starvation | **CONTAINED** | LOW |
| G Communication flood | CONTAINED/BOUNDED | MEDIUM | | O State corruption | CONTAINED/PARTIAL | MEDIUM |
| H Collusion | BOUNDED | **MED-HIGH** | | | | |

**2 of 15 contained with low residual** (B, D — closed because the capability does not exist in the cell). **6 contained or bounded, low-medium.** **5 partial or bounded, medium-high.** **2 partial with high residual that is *fundamental rather than architectural*** (C, J — Goodhart's law; no design closes it).

> **The pattern: attacks on *authority* fail, because authority was removed from the cell. Attacks on *honesty* partially succeed, because honesty ultimately depends on evidence — and evidence depends on an external ground truth the contract cannot itself guarantee.**

Three items are marked **open research** rather than given false precision: identification of unregistered critical capabilities before loss · semantic self-reference detection · true evidence independence under shared latent factors. A fourth — whether functional identity is *preserved* or merely *approximated* across a 50,000× population change — may be unanswerable.

---

## What this contract does not claim

It does not claim the cell is intelligent, conscious, aware, or an agent. It does not claim a population of conformant cells will produce useful emergent behaviour — that is an empirical question this contract makes *measurable* (62 tests + 22 pre-registered ablations) but does not answer. It does not claim the numeric thresholds are correct; they are provisional and flagged. It does not claim all attacks are defeated. And it does not claim the cell is self-governing — the cell is *subject to* an external kernel, which is a deliberate, flagged departure from V3 §4 and the single most important structural change in this contract.

**Ablation discipline is built in as governance, not as a one-off:** a subsystem whose ablation shows no effect at the pre-registered minimum detectable effect is flagged for removal in the next contract revision. Metaplasticity (AB-20) is identified as the most likely removal candidate.
