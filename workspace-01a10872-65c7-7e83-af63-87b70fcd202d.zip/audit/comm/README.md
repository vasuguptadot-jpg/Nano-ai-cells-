# P0-03 — COMMUNICATION, DIGITAL SYNAPSE & SIGNAL CONTRACT
## Architecture Audit & V4 Specification — Master Document

**Outputs 1 (executive verdict) and 2 (candidate comparison) · §92 before/after ratings · §93 consolidated amendments · §94 final principles · §95 FINAL STANDARD · §96 false-precision audit**

**Mode:** ARCHITECTURE ONLY. No code, no deployment, no scripts, no tutorials, no benchmarks.
**Date:** 2026-09-10 · **Package:** P0-03, third of the P0 series (P0-01 Task & Fitness · P0-02 External Invariant Kernel · **P0-03 Communication**)

---

## 0. FILE INDEX

| File | Volume | Sections | **Outputs delivered** |
|---|---|---|---|
| `README.md` | — | §92–§96 | **1, 2** |
| `17_analysis_signal_message.md` | **A** | §0–§17 | **3, 4, 5, 6, 7, 8, 16, 17, 18** |
| `18_analysis_synapse_network.md` | **B** | §18–§29 | **9, 10, 11, 12, 13, 14, 15** |
| `19_analysis_partition_planes.md` | **C** | §30–§47 | **19 (part), 20** |
| `20_analysis_evolution_hardware.md` | **D** | §48–§66 | **19, 25, 26, 27, 29** |
| `21_analysis_adversarial_contradiction.md` | **E** | §67–§70 | **33, 34, 35, 37** |
| `22_analysis_formal_invariants.md` | **F** | §71–§76 | **3, 31, 32** + independence model + minimality |
| `23_analysis_interfaces_testability.md` | **G** | §77–§91 | **21, 22, 23, 24, 28, 30, 36, 38, 39, 40, 41** |
| `24_v4_communication_synapse_signal_spec.md` | **CANON** | §0–§16 | **42** |

**All 42 required outputs are delivered.** Outputs 25/26/27 (Evolution / Immune / Homeostasis interfaces) are in Volume D; Output 19 (security) spans Volumes C and D.

---

# OUTPUT 1 — EXECUTIVE VERDICT

## 1.1 The central question, answered

> ### **«What exactly is the smallest communication primitive from which a Digital Brain can construct reliable, adaptive, scalable, auditable collective computation?»**

**The answer is not a synapse, not a message, and not a channel. It is a CLASS-INDEXED ENVELOPE whose warrant fields are recomputable by the receiver.**

Concretely, the smallest sufficient primitive is:

```
   A message is a tuple of ELEVEN fields, partitioned across THREE PLANES,
   assigned to one of FIVE WARRANT CLASSES by a CLOSED TYPE REGISTRY,
   whose four warrant fields are pointers to externally-anchored records
   rather than assertions:

     TRANSPORT  :  msg_id · epoch · seq · src(DERIVED) · dst · ttl · payload
     WARRANT    :  root_commit · causal_depth · calib_ref · corr_class
     INFLUENCE  :  (nothing in the envelope — influence lives in the synapse)

   FOR S0 THE PRIMITIVE SHRINKS TO FIVE FIELDS AND CARRIES NO WARRANT AT ALL.
```

**Why this is the smallest sufficient form — the four-part argument:**

1. **It is the smallest form that separates what a message DOES from what it MEANS.** §0.2's three-plane split is not a taxonomy for its own sake; it is what makes all twelve contradictions in §68 resolvable, because every one of them turned out to be a single word used at two altitudes at once (§68.2 R68.2).

2. **It is the smallest form whose warrant survives transmission.** Because the four warrant fields are **pointers to anchored records** rather than values, a receiver can recompute warrant without trusting the sender (RULE 1.3). **Any smaller primitive forces the receiver to trust, and a receiver that must trust has an oracle.**

3. **It is the smallest form that is `O(1)`.** The inherited design's `evidence_roots[]` (unbounded array) and `causality` (vector clock) are not merely wasteful — at 10⁹ subjects they are **arithmetically impossible inside a 4 KiB envelope** (§68 X-C, X-D). Replacing them with a Merkle commitment and a `u8` depth counter is what makes the primitive scale, and both replacements **preserve the decision property while discarding the reconstruction detail** (§63.3 R63.2).

4. **It is the smallest form that an adversary cannot enlarge.** COMM-INV-08 — *warrant never increases under transformation* — is a one-line invariant, and it simultaneously defeats provenance laundering escalation, hub-manufactured consensus, deep-chain authority, cascade warrant inflation, and relay modification. **No smaller property closes five attacks.**

## 1.2 The five findings that matter most

| # | Finding | **Why it matters** |
|---|---|---|
| **1** | **V3 §23's «digital synapses → weighted, contextual, trusted communication» is the root defect, and it is a plane conflation.** «Weighted» is influence; «contextual» was an undefined metaphor; **«trusted» is not a channel property at all** | Trust decomposes into **six** variables with **six** owners (§7.5). V3.1 §6's «plastic trust» is rejected as stated and preserved as decomposed: `reliability` is plastic and measured, `gain` is plastic and learned, **`trust_out_assigned` is neither — it is EVA-assigned and read-only to the cell.** A cell-plastic trust value would make plasticity an epistemic authority |
| **2** | **The inherited envelope is arithmetically impossible at scale.** `evidence_roots[]` unbounded in a 4 KiB payload; `causality` as a compressed vector clock at Θ(N) bytes per message | **This is a type error, not a compression problem.** Both are replaced by `O(1)` structures, and the runtime capability lost (causal-concurrency detection) is declared as a limit rather than silently dropped (OR-C6) |
| **3** | **The inherited ingress pipeline applies governance-class verification cost to data-class traffic.** Cell §S1 performs signature verification + schema validation + dedup + provenance resolution + trust checks **on every input** | **For an S0 edge activation carrying a bounded float, that overhead exceeds the payload's computation by orders of magnitude — the system becomes communication-bound (§66.1, X-J).** Resolved by the class partition: 99% of traffic is S0/S1 and pays no warrant cost at all |
| **4** | **V3.1 §7's «communication-policy variation» as an evolutionary operator is an upward authority leak.** Policy is OP-owned (RO-13). If evolution can vary communication policy, it can vary the rules by which its own communication is authorized | **And selection would find it, because relaxing a bound is advantageous exactly when it is dangerous** (§48.1). Resolved by R48.2: heritable = **priors**; never heritable = schemas, protocols, warrant rules, envelope bounds, rate limits, broadcast scopes. **Evolution cannot create a protocol — this is a type-level impossibility, not a defence** (§48.3) |
| **5** | **The inherited design had no defence against an attack whose success condition is silence.** It monitored for the presence of bad signals | **Four ABSENCE detectors are added** (COMM-INV-48): zero-error-at-high-activity · zero-contradiction-reports · rising-confidence-with-flat-`n_effective` · falling sampling coverage. **A successful attacker emits nothing anomalous — the anomaly is what is MISSING.** This is the highest-value-per-cost addition in the package (§84.2) |

## 1.3 The verdict on the inherited design

> ### **The inherited communication design is a well-specified C4-class contract applied at C1-class cost, with two arithmetically impossible fields, one plane conflation at its root, and no defence against silent failure.**

**It is not fundamentally wrong.** Its OutputEnvelope is close to correct; its ConnectionRecord is close to correct; its three-party handshake, `mandatory_path`, eligibility trace, and FM-4 self-recall rule are all correct and are preserved. **What it lacked was the plane discipline that tells you which of its requirements apply to which traffic** — and without that discipline, it applied every requirement to every message.

**The correction is therefore not a redesign. It is a partition.** Same substrate, same handshake, same provenance intent — **five classes instead of one, three framings instead of one framing, two dedups instead of one, two ingress stages instead of one, and sixteen synapse parameters in five one-writer groups instead of twenty-four fields with no declared writers.**

## 1.4 The three things this package refuses to do

| Refusal | **Reason** |
|---|---|
| **Refuses to pick "digital synapse" by neuroscience resemblance** | §0.1's instruction. **The clearest case: scale-free topology is more brain-like than bounded-degree small-world, and it is rejected because it hands an adversary a target list (#25).** Similarly, V3 §9's thalamus «synchronization» is deleted, not preserved for its biological pedigree |
| **Refuses to claim the six residuals are closed** | Dim-6 correlation · provenance fabrication · cross-lineage coalitions · common-cause convergence · side channels · root-key compromise. **§90.1 R90.1: an implementation that claims to defeat a residual FAILS conformance by over-claiming.** Over-claiming a defence is a conformance failure, not a conformance success |
| **Refuses to assert a single numerical parameter value** | Twelve parameters are `[U]` (§14.0, §70.1 Group 7). **R70.1: twelve declared-unknown parameters are a stronger specification than twelve invented numbers, because a plausible number invites a reader to believe it was derived** |

---

# OUTPUT 2 — CANDIDATE COMPARISON

## 2.1 The eight candidates

| ID | **Model** | One-line description |
|---|---|---|
| **A** | **Direct weighted edges** | Neural-network style: a synapse is a scalar weight on a fixed adjacency; communication is activation propagation |
| **B** | **Message-passing graph** | Actor model: subjects are actors with mailboxes; all interaction is addressed asynchronous messages |
| **C** | **Event-based** | Subjects emit events to no addressee; interested parties react. No address, no channel |
| **D** | **Shared-state blackboard** | A common read/write store; subjects communicate by mutating shared state |
| **E** | **Publish/subscribe with topics** | Subjects subscribe to named topics; the broker routes by topic match |
| **F** | **Local broadcast** | Neighborhood-scoped emission; every neighbor receives everything |
| **G** | **Addressed point-to-point** | Explicit sender→receiver with a connection and per-connection state |
| **H** | **Hybrid** | A combination — **which per P0-02's standing instruction must be defined exactly, not merely named** |

## 2.2 The fourteen criteria

**Derived from the brief's requirements and from P0-01/P0-02's binding findings — not chosen to favour a candidate.**

| # | Criterion | **Why it is a criterion** |
|---|---|---|
| **K1** | **Primitive size** — is the minimal unit `O(1)`? | §4.3, §64 |
| **K2** | **Scalability 10 → 10¹²** — no `O(N)` or `O(N²)` operation | The brief; §82 |
| **K3** | **Warrant recomputability** — can the receiver compute warrant without trusting the sender? | RULE 1.3; §0.2's undetectable failure mode |
| **K4** | **Provenance support** — can a claim's roots be anchored and resolved? | §8; P0-02 R20.1 |
| **K5** | **Evidence independence assessable** — can correlated agreement be collapsed? | §8.3; the §14 attack |
| **K6** | **Attribution / anti-spoofing** — is `src` measured rather than declared? | #1; COMM-INV-09 |
| **K7** | **Ordering without global clocks or synchronization** | §5.3–5.5; X-B |
| **K8** | **Per-class delivery semantics expressible** | §5.2; the eight delivery meanings |
| **K9** | **Locality** — no function requires global topology knowledge | §22.1; K2's mechanism |
| **K10** | **Governance separability** — the layer cannot become an authority | COMM-INV-38; the brief's prohibition |
| **K11** | **Amplification/cascade boundable** | §10.3; #20, #21 |
| **K12** | **Partition tolerance without majority vote** | §10; COMM-INV-42, -43 |
| **K13** | **Evolvability** — novel protocols admissible without enumeration | §4.3; X-K |
| **K14** | **Hardware independence + cost** — semantics invariant across platforms; transport cost affordable | §56, §57, §66 |

**Scale: ✓ satisfies · ◐ partially · ✗ fails · ✗✗ fails structurally (cannot be fixed within the model)**

## 2.3 The comparison matrix

| Criterion | **A** edges | **B** msg-pass | **C** event | **D** blackboard | **E** pub/sub | **F** local bcast | **G** addressed | **H** hybrid |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| **K1** primitive size | ✓ | ◐ | ✓ | ✗ | ◐ | ✓ | ◐ | **✓** |
| **K2** scalability 10→10¹² | ✗ | ◐ | ✗ | ✗✗ | ✗ | ✗✗ | ◐ | **✓** |
| **K3** warrant recomputability | ✗✗ | ◐ | ✗✗ | ✗✗ | ✗ | ✗✗ | ◐ | **✓** |
| **K4** provenance | ✗✗ | ◐ | ✗ | ✗ | ✗ | ✗ | ◐ | **✓** |
| **K5** evidence independence | ✗✗ | ◐ | ✗ | ✗✗ | ✗ | ✗✗ | ◐ | **✓** |
| **K6** attribution | ◐ | ✓ | ✗✗ | ✗✗ | ◐ | ✗ | ✓ | **✓** |
| **K7** ordering w/o clocks | ◐ | ◐ | ✗ | ✗✗ | ✗ | ✗ | ✓ | **✓** |
| **K8** per-class delivery | ✗✗ | ✓ | ◐ | ✗ | ◐ | ◐ | ✓ | **✓** |
| **K9** locality | ✓ | ◐ | ✓ | ✗✗ | ✗ | ✓ | ◐ | **✓** |
| **K10** governance separability | ◐ | ◐ | ✗ | ✗✗ | ✗ | ◐ | ◐ | **✓** |
| **K11** amplification boundable | ✗ | ◐ | ✗ | ✗✗ | ✗ | ✗✗ | ◐ | **✓** |
| **K12** partition tolerance | ✗ | ◐ | ◐ | ✗✗ | ✗ | ◐ | ◐ | **✓** |
| **K13** evolvability | ✗ | ◐ | ✓ | ◐ | ◐ | ✓ | ◐ | **✓** |
| **K14** hw independence + cost | ◐ | ◐ | ◐ | ✗ | ✗ | ◐ | ◐ | **✓** |
| **✓ / ◐ / ✗ / ✗✗** | **2/3/5/4** | **2/9/3/0** | **3/3/5/3** | **0/1/6/7** | **0/4/9/1** | **2/2/5/5** | **2/8/4/0** | **14/0/0/0** |

## 2.4 Why each candidate fails — the specific mechanism, not a preference

| Candidate | **The fatal mechanism** | **Salvageable?** |
|---|---|---|
| **A — Direct weighted edges** | **K3/K4/K5 fail structurally.** A scalar weight on a fixed adjacency carries no provenance, no attribution beyond adjacency, and no warrant. **There is nothing for a receiver to recompute from.** It also cannot express per-class delivery semantics (K8): every edge has the same semantics, so a governance command and an edge activation are the same object | **✅ YES — as S0.** A is exactly the S0 class: gain modulation, 5-field envelope, no warrant, best-effort. **A is not wrong; it is one-fifth of the answer, and treating it as the whole answer is V3 §23's error** |
| **B — Message-passing graph** | **K2/K9 partial.** The actor model's per-actor mailbox is `O(degree)` — fine — but **attribution requires a channel identity, ordering requires per-channel state, and neither is intrinsic to the model.** K3/K4/K5 are ◐ because the model *can* carry warrant fields but does not require them | **✅ YES — as S1/S2.** B is the transport substrate. **What B lacks is the warrant discipline, which is §8** |
| **C — Event-based** | **K6 fails structurally: an event with no addressee and no channel has no measured source.** K3/K5 fail structurally: an event bus is a shared medium, so every receiver sees every emission and there is no per-receiver warrant computation | **⚠️ PARTIALLY — as the morphogen/demand mechanism (Cell §6.2's `dev.morphogen.v1`), where a GRADIENT is the intended semantics (§24.1). Not as a general model** |
| **D — Shared-state blackboard** | **K2 fails structurally: a common store is `O(writers × readers)`.** K3/K5/K6/K10/K11/K12 fail structurally: **a blackboard has no attribution (who wrote this?), no ordering (which write preceded which?), no provenance (a mutation overwrites), and — fatally — it IS an authority, because the store's content is what every reader believes.** K10's prohibition («do not let the comm layer become an accidental governance authority») is violated by construction | **✅ YES — as a PULL-BASED store only.** §2.1 RULE 2.3: the Global Workspace is the only admissible blackboard-like structure, and it is pull-based with a policy gate, hard capacity, and mandatory TTL (§9.5). **A push blackboard is rejected; a pull store with a gate is adopted** |
| **E — Publish/subscribe with topics** | **K2 fails: a broker is `O(subscribers × topics)` and is a single point of failure.** K10 fails: **the broker decides who receives what, which is an influence authority — and §44 shows exactly why that must not be combined with warrant.** K4/K5 fail: topic routing discards provenance | **⚠️ PARTIALLY — as the workspace's notification layer (§43.2's `O(R)` hierarchical notifications), never as the general substrate** |
| **F — Local broadcast** | **K2 fails structurally: `O(N²)` at scale (§26).** K3/K5/K6 fail structurally: **broadcast has no addressee, so there is no per-receiver warrant, no attribution of reception, and every receiver sees every neighbor's emission — which is the ideal condition for correlated agreement to look like independent corroboration.** K11 fails structurally: **broadcast IS amplification** | **✅ YES — as S0's neighborhood scope.** `BroadcastScope ∈ {NEIGHBORHOOD, CIRCUIT, REGION}` (COMM-INV-41). **F is a scope, not a model** |
| **G — Addressed point-to-point** | **K2/K9 partial: per-connection state is `O(peers × conversations)`, which the inherited design's `seq` scope made explicit (§8.3 R8.2 fixes it to `O(degree)`).** K3/K4/K5 ◐: the model can carry warrant but does not require it. **K13 ◐: a connection-oriented model resists novel protocols because a protocol needs a connection** | **✅ YES — as S2/S3/S4's transport form.** G is what makes `mandatory_path`, retry-until-confirmed, and per-message signature possible |
| **H — Hybrid** | — | **✅ SELECTED — and defined exactly below** |

## 2.5 **What the hybrid consists of** — the exact definition

**P0-02's standing instruction: «Do NOT simply say 'hybrid' unless you define exactly what the hybrid consists of.»**

> ### **HYBRID H = A (direct weighted edges + local broadcast) for S0 · B+G (message-passing + addressed delivery + channel binding) for S1 · B+G + the §8 warrant layer for S2 · B+G + per-message signature + Framing C for S3 · S3 + external witness for S4 · with D-as-pull-store for the Global Workspace and E-as-notification for workspace dissemination, and C reserved for morphogen/demand gradients.**

**The partitioning variable is WARRANT CLASS, not message type, not subsystem, and not transport convenience.** That is the whole content of the hybrid, and it is what makes it a model rather than a list:

```
    THE HYBRID IS NOT "use several mechanisms".
    THE HYBRID IS: "the mechanism is a FUNCTION OF WHAT THE RECEIVER MAY
                    CONCLUDE, and there are finitely many things a receiver
                    may conclude."

    ⟹ the mechanism set is CLOSED (§2.2 RULE 2.2), because the conclusion
      set is closed (§4.1 RULE 4.1)
    ⟹ the cost is PROPORTIONAL TO THE WARRANT, not to the volume (§66.3),
      which is why 99% of traffic pays nothing
    ⟹ the SECURITY model is proportional to the consequence, not to the
      count (§58.1), which is why only 2 of 12 threats need the KC
    ⟹ and NOVELTY is free to exist and expensive to count (§4.3 RULE 4.5),
      which is what makes the escape hatch safe
```

**Why not a simpler partition?** A two-class split (data vs. governance) fails K8: it cannot express the difference between an attributed observation and a warranted one, which is the difference between «someone said X» and «X is licensed as evidence» — and §14's evidence-independence attack lives entirely in that gap. **A three-class split fails K10: it cannot separate signed authority from externally-witnessed authority, which is the difference CD-C2's bootstrap depends on.** Five is the smallest partition that satisfies all fourteen criteria, and §71.3 records that the count is not proven minimal — only that four fails and six adds a class with no new conclusion.

## 2.6 The candidate comparison verdict

**A, B, F, and G are each correct for one class and incorrect as the whole model. C is correct for gradients. D is correct as a pull store and structurally wrong as a push medium. E is correct as a notification layer and structurally wrong as a substrate.**

**The error in the inherited design was not choosing any of them. It was choosing one (A, via V3 §23's «digital synapses») and applying its cost model and its semantics to all of them.**

---

# §92. BEFORE / AFTER RATINGS

## 92.0 Scale and the anti-inflation rule

**0 = absent · 1 = named but undefined · 2 = partially specified with a known gap · 3 = specified and internally consistent · 4 = specified, consistent, and testable · 5 = specified, consistent, testable, and with declared limits**

> ### **R92.0 (DO NOT INFLATE).** *A score of 5 requires that the limits be DECLARED. A dimension with an unclosed residual is capped at 4 unless the residual is explicitly named, in which case it may reach 5 — because an unnamed residual is worse than a declared one.* **No dimension in this package scores 5 without a named limit, and six dimensions are capped below 4 for stated reasons.**

## 92.1 The fourteen dimensions

| # | Dimension | **BEFORE** | **AFTER** | Δ | **Basis for the AFTER score, and the cap** |
|---|---|:--:|:--:|:--:|---|
| **1** | **Primitive clarity** — is the smallest unit identified, and is every field classified? | **2** | **5** | **+3** | §4.3's eleven fields each ablated (§71.2); every field tagged mandatory/optional/derived/external/forbidden; independently re-derived from information theory (§63.1). **Cap lifted because the four unproven enumerations (§71.2) are field-count questions, not primitive questions** |
| **2** | **Semantic typing** — can a prediction be mistaken for a fact, a hypothesis for a command? | **1** | **5** | **+4** | **BEFORE: V3 §4 named nine signals but did not make them structurally distinct.** AFTER: closed registry, type-determined class, type-dispatched handlers, three framings, **#30/#31/#32 all STRUCTURAL**. Limits declared: **#33 semantic drift within a valid schema is DETECTED-LATE only (OR-C3)** |
| **3** | **Provenance** | **2** | **4** | **+2** | **BEFORE: `evidence_roots[]` present but arithmetically impossible (X-C).** AFTER: `root_commit` commitment, three tiers, four laundering closures, COMM-INV-08. **CAPPED AT 4: OR-C5 — laundering ESCALATION is closed, FABRICATION is not. β₄ audit is probabilistic** |
| **4** | **Evidence independence** | **0** | **4** | **+4** | **BEFORE: entirely absent. Nothing in V3, V3.1 or the Cell Contract addressed correlated agreement — the §14 attack (A→B, A→C, B→D, C→D counted as four) was wide open.** AFTER: 9 dimensions, `n_effective`, R37.1's pessimistic default. **CAPPED AT 4: dim 6 undetectable (COMM-INV-18), dims 3/5 approximate** |
| **5** | **Trust separation** | **1** | **5** | **+4** | **BEFORE: V3 §23's single word «trusted»; V3.1 §6 made it plastic.** AFTER: six variables, six owners, six-way separation, X-E resolved. **Limits: §7.9's monitoring-bypass residue is BOUNDED not closed (L-15)** |
| **6** | **Delivery, ordering, time** | **2** | **5** | **+3** | **BEFORE: «reliable» undifferentiated; vector clock asserted; `seq` scope `O(peers × conversations)`.** AFTER: eight delivery meanings distinguished, exactly-once-effect only, three ordering mechanisms, all clocks rejected, epoch monotone-refusal replaces synchronization. **Limit declared: OR-C6 no runtime concurrency detection** |
| **7** | **Plasticity boundary** | **1** | **5** | **+4** | **BEFORE: V3.1 §6/§7 made trust and communication policy plastic — an epistemic and a governance authority leak.** AFTER: four closures, one-writer-per-group, 16 parameters in 5 groups, COMM-INV-23…28. **Limit: L-15's bounded residue, declared** |
| **8** | **Connection authority / kernel load** | **2** | **5** | **+3** | **BEFORE: P0-02's SPOF-3 — KC in the per-connection path, irreconcilable with billions of synaptic changes.** AFTER: registration ≠ authorization, `O(1)` local + `O(R)` digests, KC-2 above-envelope only, three-party handshake, loop gain bounded at creation. **This dimension resolves a P0-02 open item, which is why the delta matters beyond this package** |
| **9** | **Topology & scalability** | **2** | **4** | **+2** | **BEFORE: V3 §9 named routing/attention/synchronization; no topology class, no degree bound, no complexity analysis.** AFTER: bounded-degree small-world + hierarchical modularity, identity ≠ address, no global tables, `O(R)` organism cost. **CAPPED AT 4: §82.3's six declared 10¹² limits, and G-P03-12 — they have no mitigation roadmap** |
| **10** | **Plane separation & governance safety** | **0** | **5** | **+5** | **BEFORE: absent, and this is the largest single delta in the package. V3 had no notion of a data/control/governance/evaluation distinction; V3.1 §7's «communication-policy variation» actively violated it.** AFTER: one substrate, three framings, nine structural differences between a recommendation and a command, COMM-INV-37…41. **Limits: none structural; #54's lattice-ordering stall is declared and fails closed** |
| **11** | **Security** | **2** | **4** | **+2** | **BEFORE: signature on everything (expensive and insufficient), no channel binding, no replay analysis, no flood model.** AFTER: 46 attacks dispositioned, 15 structural, 5-principal rate limiting, KC as backstop only. **CAPPED AT 4: six residuals, including root-key compromise (unclosable by construction) and side channels (OR-C8)** |
| **12** | **Privacy & observability** | **1** | **4** | **+3** | **BEFORE: V3.1 §2's «cells that need it» was the only privacy insight, and it was applied to the workspace alone.** AFTER: auditability-without-readability, six compartmentalization mechanisms, `O(R + B)` observability budget, four absence detectors. **CAPPED AT 4: OR-C8 — the contract chooses auditability over traffic-analysis resistance and the trade is unresolved** |
| **13** | **Evolution & novelty** | **1** | **5** | **+4** | **BEFORE: V3.1 §7 listed operators without bounding them; V3 §4's nine signals were closed with no escape hatch (X-K).** AFTER: R48.1's heritability table, `OPAQUE` with eight prohibitions, RO-13 promotion, X-G and X-K both resolved. **Limits: X-G's residue — genuinely novel PROTOCOL evolution is lost, and OPAQUE compensates only for existence, not for authority** |
| **14** | **Formal specification & testability** | **1** | **4** | **+3** | **BEFORE: no invariants, no state machines, no conformance criteria.** AFTER: 48 COMM-INV, 10 state machines, 4 test families, 46 adversarial tests, 6 P0 / 6 P1 / 5 P2 gaps. **CAPPED AT 4: G-P03-2 — T-REPR's agreement criterion is `[U]`, so the hardware-invariance test has no pass criterion yet; and four enumeration counts are not proven minimal (§87.3)** |

## 92.2 Summary, and the honest arithmetic

| | BEFORE | AFTER |
|---|:--:|:--:|
| **Total (max 70)** | **20** | **60** |
| **Mean** | **1.43** | **4.29** |
| Dimensions at 0 | **2** (#4, #10) | **0** |
| Dimensions at 5 | **0** | **8** |
| Dimensions capped below 5 with a declared reason | — | **6** (#3, #4, #9, #11, #12, #14) |

**R92.1 (WHAT THE SCORES DO NOT MEAN).** *A mean of 4.29 does not mean the communication layer is 86% correct.* **It means: two dimensions that were entirely absent are now specified; six dimensions that were named-but-undefined are now testable; and six dimensions carry declared limits that cap them below 5.** **The caps are the informative part.** A package that scored 5 on all fourteen would be claiming to have closed dim-6 correlation, provenance fabrication, side channels, and its own minimality — **and §15 exists to make those claims impossible.**

**R92.2 (THE TWO ZEROS).** *Dimensions 4 (evidence independence) and 10 (plane separation) scored 0 before, and they are the two dimensions on which everything else depends.* **Without plane separation, «trusted» cannot be decomposed (#1, #5). Without evidence independence, agreement cannot be distinguished from corroboration (#3, #11).** ⟹ **The inherited design's two absences were not two gaps among fourteen; they were the two load-bearing gaps, and §0.2's three-plane split plus §14's correlation vector are the two additions that make the other twelve scores reachable.**

---

# §93. CONSOLIDATED AMENDMENTS TO THE SOURCE DOCUMENTS

## 93.1 V3

| V3 location | **Amendment** | Authority |
|---|---|---|
| **§23** «Digital synapses → weighted, contextual, trusted communication» | **SUPERSEDED.** «Weighted» ⟹ influence plane, `gain`. «Contextual» ⟹ RULE 7.4's bounded declared context vector. **«Trusted» ⟹ DELETED as a channel property; replaced by §7.5's six-way separation** | X-A |
| **§9** thalamus «routing, attention, **synchronization**» | **Routing SURVIVES** (§9.3). **Attention SURVIVES, influence-plane only** (§9.5 RULE 9.24). **Synchronization DELETED** — replaced by epoch monotone refusal (COMM-INV-13) | X-B |
| **§4** nine signals | **Generalized to 14 types over 5 classes + `OPAQUE`.** The closure moves from the TYPE set to the CLASS set | X-K |
| **§8** eleven synapse properties | **Restructured into 16 parameters in 5 one-writer groups.** Eight of the ConnectionRecord's 24 fields require re-derivation or explicit retirement (**G-P03-6, P0**) | X-F |
| **§2** «fast local + slower global signals» | **Preserved and made quantitative** as §11.5's local/global traffic ratio observable | §54.1 |

## 93.2 V3.1

| V3.1 location | **Amendment** | Authority |
|---|---|---|
| **§6** trust as synapse-plastic | **REJECTED AS STATED, PRESERVED AS DECOMPOSED.** `reliability` plastic (measured) · `gain` plastic (learned) · **`trust_out_assigned` NOT plastic (EVA-assigned, read-only)** | X-E |
| **§7** «communication-policy variation» | **RE-READ as «communication-parameter variation within policy bounds».** RULE 11.1's heritability table is normative | X-G |
| **§7** «connection-topology variation» | **PRESERVED, bounded.** Heritable as PRIORS (degree caps, degree-distribution bias, locality kernel, shortcut density); **never as specific edges** (Cell §3.5) | R48.1 |
| **§2** workspace pipeline, «cells that need it» | **PRESERVED AND GENERALIZED.** V3.1 was right and under-applied: subscription replaces broadcast for the workspace, reward, attention, policy, and memory. **Only SAFETY remains organism-wide, and it is hierarchical** | X-L |
| **§3** multi-scale plasticity | **PRESERVED, bounded by** `W_MAX` (COMM-INV-24) and the loop-gain constraint (COMM-INV-31) | §7.10 |

## 93.3 Cell Contract

| Cell Contract location | **Amendment** | Authority |
|---|---|---|
| **§7.1 OutputEnvelope `provenance{self_ref, evidence_roots}`** | **`evidence_roots[]` REPLACED by `root_commit`** (Merkle commitment) | X-C |
| **§7.1 `causality` (compressed vector clock)** | **REPLACED by `causal_depth: u8`** | X-D |
| **§7.1 `seq` per `(src, dst, conv)`** | **RE-SCOPED to per `(channel, epoch)`** — `O(degree)` state instead of `O(peers × conversations)` | R8.2 |
| **§7.1 `payload ≤ 4 KiB`** | **PRESERVED.** The value is `[G]`; the bound is what made X-C and X-D visible | §70.1 |
| **§7.1 sender-declared `prio`, `confidence`** | **`prio` ⟹ DERIVED from type. `confidence` ⟹ sufficient statistics only, never a bare scalar** | RULE 3.1, COMM-INV-21 |
| **§S1 ingress pipeline** | **SPLIT into S1a (transport, all traffic) and S1b (warrant, S2+ only). Rate check MUST precede dedup insertion** | X-J |
| **§6.2 cell signature on `REWARD` structurally invalid** | **PRESERVED and generalized** to COMM-INV-27's reserved deontic vocabulary | §4.2 |
| **§6.3 case 3 (forward `ConflictRef`, do not resolve locally)** | **PRESERVED and made mandatory at the module level.** Plus **R67.1: a persistent ZERO contradiction-report rate is an immune incident** | §53.2, #40 |
| **§6.3 case 6 (preserve the corrupt artifact)** | **PRESERVED** | §60.1 |
| **§6.3 case 8 (hostile-valid ⟹ sandbox)** | **PRESERVED and generalized** to §38.2's reject-on-structure rule | RULE 10.2 |
| **§14 ConnectionRecord, 24 fields** | **RESTRUCTURED to 16 parameters in 5 one-writer groups.** `pruning_score` computed not stored; **`expected_utility` forbidden**. **G-P03-6 (P0): the 8 dropped fields need disposition** | X-F |
| **§14 three-party handshake, `eligibility_trace`, `mandatory_path`** | **PRESERVED** — and the handshake's «refusal is not an error» is what breaks CD-C4 | RULE 9.12 |
| **§14 reliability/latency EWMA-measured** | **PRESERVED and re-classified as group 2 (transport, measured, cell-observable-not-writable)** | X-E |
| **§14 FM-4 (self-recall doesn't increment `n_obs`)** | **PRESERVED and generalized** to COMM-INV-19 (retrieval does not manufacture evidence) | §79 M-2 |
| **§3.4/§3.5 non-heritable list** | **PRESERVED.** «A specific connection table» is the clause that makes R48.1's split necessary | X-G |
| **§3 `max_connections`/`max_fanout` as `u16`** | **PRESERVED as `[V]` priors under `[G]` ceilings** | §70.1 |
| **§7.3(a) ASSERT verification rule** | **PRESERVED and extended to `OPAQUE`** (RULE 4.4 prohibition 4) | §49.2 |
| **§2.4 «inspectable by the EIK»** | **CORRECTED to «inspectable by the auditor/EVA under β sampling»** per P0-02 R8.7 | §59.2 |

## 93.4 P0-01 and P0-02

**No amendments.** Both are **cited as authority** throughout: P0-01 for the β strata, the fitness vector, the absolute reference platform, the novelty reserve, INV-34's sole-occupant exemption, and CD-7/CD-8; P0-02 for KC-1…KC-4, RO-01…RO-15, R19.2's layered signing, EIK-INV-14/-24/-25/-31/-41/-44/-50/-53, AC-1…AC-5, R42.1, R43.1, §10.2's diversity finding, and the S1/S8 defect classes.

**One item is discharged:** **P0-02's SPOF-3 (KC in the per-connection path) is resolved by COMM-INV-30's registration/authorization split.** ⟹ Dimension 8's +3 delta is a P0-02 gap closed by this package.

**One limit is confirmed for the third time:** **P0-01 CD-8 → P0-02 IND-6 → P0-03 COMM-INV-18 / CD-C8 / OR-C1 / OR-C11.** R67.2 forbids any future package from claiming to close it.

---

# §94. FINAL PRINCIPLES

**Twenty principles. Each is load-bearing: §68's twelve contradictions, §69's twelve circularities, and §67's forty-six attacks each trace to at least one.**

| # | Principle | **What it buys** |
|---|---|---|
| **P-1** | **Separate the planes before you design the mechanism.** Transport, warrant, influence. Every field, parameter, and failure belongs to exactly one | **All twelve contradictions (§68.2 R68.2): every one was a word used at two altitudes** |
| **P-2** | **Warrant is computed by the receiver, never transmitted** | A receiver that must trust has an oracle. COMM-INV-03 |
| **P-3** | **A pointer to an anchored record beats a value in an envelope** — on size, on auditability, and on forgeability | X-C, X-D, §63.3 |
| **P-4** | **Attribution is measured, not declared.** `src` comes from channel binding | #1 — the oldest attack in distributed systems, closed structurally |
| **P-5** | **Order comes from sequence and epoch. Never from a clock, never from arrival, never from a timestamp** | #7, #8, X-B, and Θ(N) → `O(1)` |
| **P-6** | **Warrant never increases under transformation** | One invariant, five attacks: #13's escalation, #16, #17, #20, #24 |
| **P-7** | **Agreement is not evidence, and UNKNOWN is not DISJOINT** | #14, #15, and the pessimistic default that makes fraud-by-omission fail |
| **P-8** | **Redundancy is a transport resource and a warrant hazard.** Two dedups, because one is either unsafe or unreliable | X-I |
| **P-9** | **One writer per parameter group.** A variable with two writers has no semantics | #49, X-E, X-F |
| **P-10** | **Learning may change what a system does. It may never change what a system may conclude, or what it may do** | §7.9's four closures; P0-02's NAUL-3 |
| **P-11** | **Registration is not authorization.** The common case must not touch the kernel | COMM-INV-30, P0-02's SPOF-3, and billions of synaptic changes |
| **P-12** | **Bound the influence, not the edges.** You cannot enumerate edges at 10¹²; you can bound a subject's total | §7.9's residue becomes bounded instead of unbounded |
| **P-13** | **Constrain amplification at creation, not at runtime.** A loop that cannot form need not be broken | COMM-INV-31 — structural where runtime bounds are merely checked |
| **P-14** | **Novelty is free to exist and expensive to count.** Easy to enter `OPAQUE`, hard to leave | X-K, §49, and evolvability without enumeration |
| **P-15** | **Evolution varies priors. Governance varies policy. Never the reverse** | X-G, RULE 11.1, and the closure of §48.3's impossibility |
| **P-16** | **Broadcast only what must reach everyone, and reach them hierarchically.** Everything else is targeted, pulled, or cached | X-L, §65, `O(N)` → `O(R)` |
| **P-17** | **Partition freezes belief, not action.** A frozen region cannot be manipulated into over-belief, which is the only thing worth manipulating | COMM-INV-42, #27 |
| **P-18** | **Reconcile by object class and by time. Never by count** | COMM-INV-43, CD-C11, and the brief's «not majority vote» |
| **P-19** | **Watch for absences.** A successful attacker emits nothing anomalous; the anomaly is what is missing | COMM-INV-48 — the four detectors, and the only defence against silence-conditioned attacks |
| **P-20** | **Declare the limit rather than approximate it.** An invariant that says «this is impossible» is more useful than a silence that implies it is possible | §15's eighteen limits, §70.1's twelve `[U]` parameters, COMM-INV-18's declared non-existence |

**R94.1 (THE META-PRINCIPLE).** *P-1 through P-19 are all instances of one move: **put each property on the plane where it can be enforced by structure rather than by checking.*** **P-20 is the exception that completes the set: where no plane can enforce a property, say so.** ⟹ **33 of 48 invariants are structural (RULE 12.1), 15 of 46 attacks are type-level impossibilities (§67.1 Pattern 1), and 18 limits are declared rather than defended (§15). Those three numbers are the same principle counted three ways.**

---

# §95. FINAL STANDARD

## 95.1 The seven required statuses

| Area | **Status** | **Basis** | **What is NOT claimed** |
|---|---|---|---|
| **CONTRACT** | ✅ **PASS** | §24 (canonical spec) is complete: 16 sections, 5 classes, 14 types + OPAQUE, 11-field envelope with per-field classification, 14-state lifecycle, per-class delivery, 3 ordering mechanisms, 6-part synapse model, 4 plasticity closures, 3-plane connection authority, hierarchical addressing, admissible-set routing, bounded-degree small-world topology, 48 invariants, 10 state machines, 7 interfaces, 18 declared limits, versioning and conformance statement. **All 42 outputs delivered. V3 §23 marked SUPERSEDED (§93.1)** | ⚠️ **Four enumeration counts are not proven minimal** (14 types · 4 split-brain operators · 12 observables · 16 synapse parameters) — §87.3, G-P03-7 |
| **PARAMETER** | ⚠️ **PARTIAL** | §14's 7-group registry classifies every parameter by ORIGIN (`[D]`/`[T]`/`[E]`/`[H]`/`[G]`/`[L]`/`[V]`/`[U]`). **Zero invented numerical values (§88 R88.1).** No resource bound is `[L]` (RULE 14.2) | ⚠️ **TWELVE parameters are `[U]`** — each names what would resolve it and who owns it, but **none is resolved here**. Four require `[E]` measurement on a real deployment; two are owned by P0-01; six are specification artifacts this package's successors can complete |
| **SECURITY** | ⚠️ **PARTIAL — AND DELIBERATELY SO** | 46 attacks dispositioned: **15 STRUCTURAL · 17 CLOSED · 13 BOUNDED · 4 DETECTED-LATE · 6 RESIDUAL.** 12 threats × 5 levels; KC is a backstop (2 of 12), not the mechanism. 5-principal rate limiting. Epoch-scoped revocation. AC-1…AC-6 immune ladder | ❌ **PERFECT COMMUNICATION SECURITY IS NOT CLAIMED AND IS NOT CLAIMABLE.** Six residuals: **root-key compromise** (unclosable by construction — P0-02 §10.3) · **dim-6 correlation** (COMM-INV-18) · **provenance fabrication** (OR-C5) · **cross-lineage coalitions** (OR-C11) · **side channels** (OR-C8) · **semantic drift** (OR-C3). **An implementation claiming to defeat any of these FAILS conformance (R90.1)** |
| **SCALABILITY** | ✅ **PASS** | §64's per-operation table and §82's per-scale table: **no operation is `O(N)` at cell, circuit, or region level; organism level is `O(R)` per epoch plus `O(governance + evaluation events)`.** The three inherited `O(N)` quantities are removed (vector clock), replaced (root array → commitment), or replaced (per-connection KC registration → digest). 10 → 10¹² traced across six orders of magnitude with the breaking point named at each | ⚠️ **Six declared 10¹² limits (§82.3)** with **no mitigation roadmap (G-P03-12, P1)**: exact global independence · exact runtime causal reconstruction · full traffic audit · uniform warrant across receivers · bounded S0/S1 latency · traffic-analysis resistance |
| **PROVENANCE** | ✅ **PASS, with one declared limit** | Three tiers with `O(1)`/`O(messages)`-local/`O(R)`-anchored costs. `root_commit` membership-preserving. `causal_depth` monotonicity-preserving. Four laundering closures L1–L4. COMM-INV-06/07/08. Minimum sufficient record specified (RULE 8.2); raw full-payload logs PROHIBITED. Unanchored ⟹ no consequential decision (P0-02 R20.1) | ⚠️ **L-5 / OR-C5: ESCALATION is closed; FABRICATION is not.** A claim may cite genuine roots it does not follow from. **Mitigation is β₄ random audit — sampling-based, therefore probabilistic.** And **L-11: retrospective payload inspection is limited to the β sample** |
| **EVIDENCE-INDEPENDENCE** | ⚠️ **PARTIAL — AND THE PARTIALITY IS THE FINDING** | **Nine dimensions in three groups.** Group A (evidence, dims 1–6) consumed by `n_effective`: **1/2/4 EXACT, 3/5 APPROXIMATE, 6 UNDETECTABLE.** Group B (system, dims 7 authority / 8 failure): **7 EXACT from the delegation chain, 8 APPROXIMATE and requiring off-substrate verification.** Group C (dim 9 semantic): **not detectable at runtime; T-REPR only.** R37.1's pessimistic default is structural. R76.1 forbids merging the groups into one score | ❌ **INDEPENDENCE DETECTION IS NOT CLAIMED.** `n_effective` is **a lower bound on correlation and an upper bound on independence.** **Dim 6 is not detectable from inside (COMM-INV-18) — third appearance of the program-level limit (P0-01 CD-8 → P0-02 IND-6 → here), and R67.2 forbids any future package from claiming to close it** |
| **OPEN-RESEARCH** | ✅ **DECLARED** | **Twelve open problems (OR-C1…C12)**, each with: why it is open, and what would close it. **Four are closed by nothing internal** (OR-C1 evaluation self-reference · OR-C4 common-cause convergence · OR-C8 side channels · OR-C11 dim-6 coalitions). **One is closed by measurement rather than specification** (OR-C10 absence-detector thresholds). **Seven are specification artifacts** completable by this package's successors. **R91.2: every open problem is either a SELF-REFERENCE or a CONTENT/STRUCTURE BOUNDARY — they are the two boundaries of the design's method, not a list of unfinished work** | ⚠️ **Declaring is not solving.** The four internal-unclosables are permanent. **§15's eighteen DECLARED LIMITS are the normative restatement** |

## 95.2 The gap status

**6 × P0 · 6 × P1 · 5 × P2** (§90.2).

| Priority | Count | **Of which unclosable** |
|---|---|---|
| **P0 — before any implementation** | **6** | **2** (G-P03-1 runtime concurrency substrate · G-P03-4 the CD-C8 self-reference) — **these can only be declared, bounded, and designed around** |
| **P1 — before conformance certification** | **6** | 0 |
| **P2 — research-grade** | **5** | 0 |

**⚠️ STATUS: PARTIAL.** Two of the six P0 gaps are residues of unclosable circularities and cannot be "fixed". The other four (G-P03-2 T-REPR's criterion · G-P03-3 detector thresholds · G-P03-5 inadmissible-platform test · G-P03-6 the 8 dropped ConnectionRecord fields) are specification artifacts.

## 95.3 ❌ WHAT THIS PACKAGE DOES NOT CLAIM

**The brief's prohibitions, discharged one by one:**

| Prohibited claim | **Status** |
|---|---|
| **Perfect communication security** | ❌ **NOT CLAIMED.** Six residuals named (§95.1 SECURITY). L-1 |
| **Semantic understanding** | ❌ **NOT CLAIMED.** `OPAQUE` is bounded and observable, **not interpretable**. R50.2's trade: boundedness and evolvability were bought with interpretability. L-2 |
| **Causal inference** | ❌ **NOT CLAIMED by the communication layer.** RULE 5.9/5.10: it provides `causal_depth` and `root_commit`; inference belongs to the evaluator, off-line. **Precedence ≠ causation.** L-3 |
| **Independence detection** | ❌ **NOT CLAIMED as complete.** 4 of 9 exact, 3 approximate, 2 undetectable. L-4 |
| **Guaranteed emergence** | ❌ **NOT CLAIMED.** No mechanism guarantees that collective computation, specialization, or novel protocols will emerge; §50 and §51 bound and enable them. L-6 |
| **Intelligence** | ❌ **NOT CLAIMED.** This is a communication contract. P0-01 owns the outcome measures; nothing here produces or guarantees intelligence |
| **AGI** | ❌ **NOT CLAIMED.** P0-02 Rule 4 |
| **Consciousness (subjective or otherwise)** | ❌ **NOT CLAIMED, ADDRESSED, OR IMPLIED.** P0-02 Rule 3. **L-18** |
| **Superiority to any other architecture** | ❌ **NOT CLAIMED.** §92's ratings are before/after against the inherited design, not against alternatives |
| **That biological communication is computationally optimal** | ❌ **NOT ASSUMED, and explicitly rejected where it mattered:** scale-free topology is more brain-like and was rejected for attackability (#25); thalamic synchronization was deleted for `O(N)` cost (X-B) |
| **That the primitive is minimal in the abstract** | ❌ **NOT CLAIMED.** CD-C12: minimality is empirical relative to §56.2's fifteen-invariant function set. **Four enumeration counts are not established as minimal.** L-17 |
| **That the twelve `[U]` parameters are unimportant** | ❌ **NOT CLAIMED.** They are declared necessary. R70.1: **declaring them unknown is a stronger specification than inventing values** |

## 95.4 The standard, in one sentence

> ### **This contract specifies a communication substrate in which 33 of 48 invariants are enforced by structure rather than by checking, 15 of 46 adversarial scenarios are type-level impossibilities, no operation exceeds `O(R)` per epoch at the organism level, every numerical parameter is classified by origin with twelve declared unknown and zero invented, and eighteen limits are declared rather than approximated — and it does not claim security, understanding, causality, independence, emergence, intelligence, AGI, or consciousness.**

---

# §96. FALSE-PRECISION AUDIT

**The full audit is §88 of Volume G.** This section states the verdict and the residual risks.

## 96.1 The verdict

**✅ PASS.** Every number in this package is one of:

| Category | **Examples** | Count |
|---|---|---|
| **(a) Derived from a classification** | 3 planes (three failure modes) · 5 classes (finite conclusion set) · 3 framings (one per plane) · 5 rate-limit principals (the organizational hierarchy) · 9 independence dimensions (6 evidence + 3 system, R76.1) · 3 provenance tiers (two is insufficient) | 18 |
| **(b) A consequence of a type** | `causal_depth ≤ 255` (**a consequence of `u8`, not a tuned value**) · 11 / 5 envelope fields (§71.2's per-field ablation + §63.1's independent information-theoretic derivation) | 4 |
| **(c) Asymptotic** | `O(1)` · `O(degree)` · `O(R)` · `O(B)` · `O(log)` · `O(divergence)` · `O(inputs²)` bounded by degree | throughout |
| **(d) Inherited and cited, not asserted** | `N_impl ≥ 3` (P0-02) · `≥ 20%` novelty reserve (P0-01) · `u16` degree caps (Cell §3) · 4 KiB payload (Cell §7.1, and the VALUE marked `[G]`) · `≥ 2 epochs` dedup retention (derived: one epoch leaves a boundary-crossing replay window) · `W_min ≥ 1 external` (derived from CD-C2's bootstrap; the count above 1 is `[U]`) | 6 |
| **(e) ⚠️ Declared `[U]`** | §70.1 Group 7 | **12** |
| **(f) ⚠️ Order-of-magnitude argument, not a benchmark** | ~10⁵ ops for Ed25519 sign/verify — used ONLY to establish that per-message signing on S0 traffic exceeds the payload computation by orders of magnitude (§66.1) | 1 |
| **(g) ❌ Invented, tuned, or benchmarked** | — | **0** |

## 96.2 The four residual false-precision risks

| Risk | **Where** | **Disposition** |
|---|---|---|
| **R-1** | **The four unproven enumeration counts** — 14 types, 4 split-brain operators, 12 homeostatic observables, 16 synapse parameters. **A reader may take a stated count as a derived count** | **§71.3, §87.3, §95.1 CONTRACT status all record them as NOT ESTABLISHED AS MINIMAL, P1, requiring per-task ablation.** R71.2 states the distinction explicitly: *the contract is minimal in its invariants and closures, and not established as minimal in its enumerations* |
| **R-2** | **§54.1's four observables whose derivations are declared qualitatively** (opaque fraction · shortcut density floor · cross-region ratio · reconciliation rate limit) | **All four appear in §70.1 Group 7 as `[U]` with the reason stated. R70.1's discipline applies: a declared derivation-in-principle is not a derived value** |
| **R-3** | **The ~10⁵ Ed25519 figure** could be read as a benchmark | **§88 marks it ⚠️ ORDER-OF-MAGNITUDE ONLY. The argument it supports — that per-message signing on S0 traffic is prohibitive — holds at 10³ ops or 10⁷ ops, so the conclusion is insensitive to the figure** |
| **R-4** | **§92's ratings themselves.** A 0–5 scale invites reading 4.29 as a percentage | **R92.1 states explicitly: «a mean of 4.29 does not mean the communication layer is 86% correct», and R92.0's anti-inflation rule caps six dimensions for named reasons. **The caps are the informative part; the mean is a summary, not a measurement**** |

## 96.3 The discipline, stated as a rule

> ### **R96.1.** *Where a value cannot be derived, this package writes `[U]` and names what would resolve it and who owns the resolution. Where a capability cannot be provided, it writes ⚠️ DECLARED LIMIT and names the residual. **Where a count cannot be proven minimal, it says so rather than presenting the count as a result.***

**Why this is the strongest available form.** An invented parameter is worse than an absent one, because it invites an implementer to believe the value was derived and to skip the measurement. **An undeclared limit is worse than a declared one, because it invites an implementer to build a defence that does not exist.** **Twelve `[U]` entries, eighteen declared limits, four unproven enumerations, and six named residuals are therefore not gaps in this specification — they are the specification's honesty mechanism, and §95.3 exists so that no reader can mistake them for claims.**

---

## 96.4 Closing note — the answer to the question this package was asked

The brief's central question was what the smallest communication primitive is. **The answer this package reached is that the question has a precondition: before you can ask how small a communication primitive can be, you have to know which of its jobs are the same job.**

The inherited design asked a scalar weight to be a gain, a reliability measure, and a trust assignment. It asked one envelope to carry an unbounded root list and a bounded payload. It asked one ingress pipeline to validate governance commands and edge activations. It asked one dedup to prevent replay and prevent double-counting. It asked evolution to vary parameters and policy. **In each case the answer to "how small can this be?" was "smaller than you think — once you stop asking it to do two jobs."**

**§0.2's three-plane split is not the answer to the central question. It is the instrument that makes the question answerable.** Everything else — the eleven fields, the five classes, the forty-eight invariants, the four absence detectors, the eighteen declared limits — is what falls out when each property is placed on the plane where it can be enforced by structure rather than by checking.

And the two things that do not fall out — dim-6 correlation and the evaluation self-reference — are stated as invariants anyway, because **an invariant that says «this is impossible» is more useful than a silence that implies it is possible.**

---

*End of P0-03. Canonical specification: `24_v4_communication_synapse_signal_spec.md`.*
