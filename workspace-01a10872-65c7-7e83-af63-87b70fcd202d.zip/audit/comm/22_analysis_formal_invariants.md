# P0-03 — COMMUNICATION, DIGITAL SYNAPSE & SIGNAL CONTRACT
## Volume F: Minimality, Variants, Canonical Contract, Formal Invariants & State Machines (§71–§76)

**Companions:** `17` (A) · `18` (B) · `19` (C) · `20` (D) · `21` (E) · `23_analysis_interfaces_testability.md` (G) · `24_v4_communication_synapse_signal_spec.md` (**Output 42**)
**Outputs delivered here:** **3** (canonical communication model, formalized) · **31** (formal invariants COMM-INV-nn) · **32** (formal state machines) · plus the **independence model** and the **minimality audit**

---

# §71. MINIMALITY ANALYSIS

## 71.1 What "minimal" can and cannot mean here

**CD-C12 established that minimality in the abstract is unclosable:** proving a primitive minimal requires knowing what is necessary, and knowing that requires having built and measured the non-minimal version.

> ### **R71.0 (THE MINIMALITY DEFINITION ADOPTED).** *A field, mechanism, or invariant in this contract is MINIMAL iff removing it breaks at least one of §56.2 R56.1's fifteen semantic invariants, or at least one closure in §67's structural set (the fifteen STRUCTURAL dispositions).* **Minimality is therefore an EMPIRICAL claim about a stated function set, discharged by the ablation table in §87 — not a mathematical claim about communication primitives in general.**

**This is a weaker claim than "smallest possible", and §96 records the weakening rather than hiding it.**

## 71.2 Field-by-field ablation of the S2 envelope (11 fields)

| Field | Tag | **What breaks if removed** | Verdict |
|---|---|---|---|
| `msg_id` | `[D]` | #6 replay (dedup has no key) · #10 eviction attack · §61's debugging record | **MANDATORY** |
| `epoch` | `[D]` | #6 replay (P0-02 EIK-INV-14's defeat mechanism) · #9 epoch confusion · §9.3's monotone-refusal property · **and §30.3's partition freeze has no variable to freeze** | **MANDATORY** |
| `seq` | `[D]` | #7 reordering · per-channel monotonicity · §64's `O(degree)` state bound depends on its scope | **MANDATORY** |
| `type` | `[D]` | #30 type confusion · #31 hypothesis-as-command · #32 class downgrade · §11.2's closed registry · **the entire class→mechanism mapping (R2.2) has no key** | **MANDATORY** |
| `src` | **DERIVED** | #1 spoofing — **but note `src` is derived from channel binding, so it is not a transmitted field at all in S0/S1.** For S2 it is a *resolved* value, and removing the resolution breaks attribution and §46's credit locality | **MANDATORY (as a resolved value, not a claim)** |
| `dst` | `[D]` | Routing · §34.2's per-destination loss-asymmetry detector (#24's residual) · §24.3's path resolution | **MANDATORY** |
| `root_commit` | `[D]` | #11 stripping · #12 fabrication · §14.4's dim-1 collapse · §16.3's L1–L4 closures · COMM-INV-08 · **P0-02 R20.1's unanchored-provenance rule has nothing to anchor** | **MANDATORY** |
| `causal_depth` | `[D]` | #17 chain-length · COMM-INV-08's monotonicity test · §35.2's warrant attenuation · §46.3's local credit | **MANDATORY** |
| `calib_ref` | `[D]` | §13.4's warrant recomputation loses its calibration input ⟹ **the receiver must trust the sender, violating R0.4** | **MANDATORY** |
| `corr_class` | `[D]` | #14 evidence-independence fraud · #15 falsification · §37's correlated-failure bound · R37.1/R37.2 | **MANDATORY** |
| `ttl` | `[D]` | §35.2's propagation bound · §43.3's mandatory workspace TTL · #17 | **MANDATORY** |
| `payload` | `[T]` | The content itself | **MANDATORY** |
| `cost` | `[H]` **measured** | §27.1's metering · §66's economy · §34.2's allocation inputs | **MANDATORY (measured, appended by transport — not sender-declared)** |
| ~~`prio`~~ | — | **Nothing. It is DERIVED from `type`.** A sender-declared priority is #32's class-downgrade vector | **❌ FORBIDDEN as a transmitted field** |
| ~~`trust`~~ | — | **Nothing. §17.1's separation makes it six things, none of which the sender may declare** | **❌ FORBIDDEN** |
| ~~`confidence` (bare scalar)~~ | — | **§12: confidence is transmitted as SUFFICIENT STATISTICS, and the scalar is a receiver-side derivation. A bare scalar is §12's named attack surface** | **❌ FORBIDDEN as a scalar; ✅ as sufficient statistics** |
| ~~`credit` / `contribution` / `reward_share` / `utility`~~ | — | **Nothing — and their presence would ENABLE #48** | **❌ FORBIDDEN (§46.3)** |
| ~~`causality` (vector clock)~~ | — | **Nothing at runtime. X-D: Θ(N) bytes in a 4 KiB envelope is a type error** | **❌ REMOVED (replaced by `causal_depth`)** |
| ~~`evidence_roots[]`~~ | — | **Nothing. X-C: unbounded array in a bounded envelope** | **❌ REMOVED (replaced by `root_commit`)** |
| ~~`conv_id`~~ | — | ⚠️ **CONDITIONAL.** §46.3 lists it as one of the four fields communication carries for local credit. **But `seq` is scoped per `(channel, epoch)`, which subsumes conversation for single-channel conversations.** ⟹ **`conv_id` is REQUIRED only for multi-channel conversations, and is otherwise omitted.** | **OPTIONAL — the one field in the envelope whose necessity is conditional** |

**R71.1 (THE MINIMALITY VERDICT FOR S2).** *Eleven mandatory fields, one conditional (`conv_id`), six explicitly forbidden, two removed from the inherited design.* **Every mandatory field maps to at least one named attack or one named invariant; no mandatory field maps to none.** ⟹ **Under R71.0's definition, the S2 envelope is minimal relative to §56.2's function set.**

## 71.3 Mechanism-by-mechanism minimality

| Mechanism | **Minimal?** | Justification |
|---|---|---|
| **Three planes (§0.2)** | ✅ | Removing the split collapses X-A, X-E, X-I, X-J back into contradictions. **§68.2 R68.2: all twelve contradictions are word-at-two-altitudes problems, and the plane split is what separates the altitudes** |
| **Five warrant classes (§72)** | ✅ | Fewer ⟹ X-J's cost error returns (one verification path for all traffic). More ⟹ the class→mechanism mapping grows without a new warrant property, and §11.1 R11.1 organizes classes by *what a receiver may conclude*, of which there are finitely many |
| **Fourteen types (§11.2)** | ⚠️ **NOT ESTABLISHED AS MINIMAL** | **§96 records this: the type set is bounded and closed, but minimality of the COUNT is not provable under R71.0 without ablating each type against a task. §87's ablation table lists it as a P1 item** |
| **Six correlation dimensions (§14.3)** | ✅ for 1–5; **6 is not a mechanism, it is a declared limit** | Dims 1/2/4 exact, 3/5 approximate, **6 undetectable (#42)**. Removing dim 6 from the *encoding* would be worse: R37.1 requires UNKNOWN to be distinguishable from DISJOINT, so the dimension must be representable even though it is not computable |
| **Three provenance tiers (§15.3)** | ✅ | Two ⟹ either `O(1)` per message with no anchored record, or `O(R)` per epoch with no local record. **The tier boundaries may move across hardware (§56.2 item 10); the count may not** |
| **Two dedups (R63.1)** | ✅ | X-I: one dedup is either unsafe or unreliable |
| **Ingress split S1a/S1b (§38.1)** | ✅ | X-J: one pipeline is either too expensive or too permissive |
| **Three framings (§39.2)** | ✅ | #32's structural rejection requires framing to be parseable before content |
| **Four split-brain operators (§31.2)** | ⚠️ **NOT ESTABLISHED AS MINIMAL** | UNION/RE-EVALUATE/FORK/VOID cover §31.3's seven object classes, but minimality of the operator set is not proven. **§96 records it** |
| **Twelve homeostatic observables (§54.1)** | ⚠️ **NOT ESTABLISHED AS MINIMAL** | Each has a declared owner and a declared failure-if-drift, which is more than most specifications provide — but the set's minimality is empirical. **P1** |
| **Four absence detectors (R67.4)** | ✅ | Each detects a distinct pathology that produces no positive signal. Removing any one leaves a silence-blind spot |
| **Sixteen synapse parameters in 5 groups (§18)** | ⚠️ **NOT ESTABLISHED AS MINIMAL** | The ONE-WRITER-PER-GROUP rule is minimal (it is what closes #49 structurally); the parameter count is not. **P1** |

**R71.2 (THE HONEST MINIMALITY STATEMENT).** *The contract is minimal in its INVARIANTS and in its CLOSURES, and it is not established as minimal in its ENUMERATIONS (type count, operator count, observable count, parameter count).* **This distinction is the whole content of §71: a specification can be provably minimal in what it forbids and empirically unproven in what it enumerates, and conflating the two is how specifications acquire false minimality claims.** ⟹ **§95's MINIMALITY status: PARTIAL, with the four unestablished enumerations listed as P1 ablation targets.**

---

# §72. COMMUNICATION VARIANTS

## 72.1 The capability ladder C0–C4

**«Propose communication variants (C0–C4 or other).»** The variants are ordered by WARRANT CAPABILITY, not by mechanism count — because §0.2 established that the warrant plane is what distinguishes a communication substrate from a signal conduit.

| Variant | **Mechanism** | **Warrant capability** | Invariants satisfied | **What it can be** |
|---|---|---|---|---|
| **C0** | **No communication.** Isolated subjects; all state local | **None** | Trivially all (nothing to violate) | **A population of independent learners. Not a Digital Brain — it has no collective computation at all. ⟹ C0 is the ablation baseline (§87), and its fitness is the floor against which every communication mechanism must earn its cost** |
| **C1** | **S0 only.** Direct weighted edges + local broadcast. 5-field envelope. No addressing beyond adjacency, no registry, no provenance | **None.** Gain modulation only | COMM-INV-01…03 (planes), 31–35 (volume), 46–48 (economy) | **A neural-network-like substrate. It can compute, adapt, and specialize (§51's loop works). It CANNOT: cite evidence · detect correlated agreement · resist laundering · support governance · be audited.** ⟹ **C1 is what V3 §23's «weighted, contextual, trusted communication» actually specifies, once «trusted» is deleted (X-A). It is a real and useful variant, and it is not sufficient** |
| **C2** | **C1 + S1.** Addressed message passing with channel binding, per-channel `seq`, epoch, TTL, `msg_id` dedup, hierarchical addressing, routing | **None, but ATTRIBUTION exists** | + COMM-INV-11…15 (identity/order/time), 26–30 (topology) | **A distributed system. It can attribute, order, route, dedup, recover, and partition-tolerate. It still CANNOT warrant: no `root_commit`, no `calib_ref`, no `corr_class`.** ⟹ **C2 defeats #1, #6, #7, #8, #9, #10, #23, #24, #26, #27 — eleven attacks — without a single warrant mechanism. This is why the transport plane is worth specifying separately** |
| **C3** | **C2 + S2.** `root_commit` · `causal_depth` · `calib_ref` · `corr_class` · closed type registry · three provenance tiers · two dedups · ingress S1a/S1b split · `n_effective` | **WARRANT EXISTS.** Belief can be licensed, evidence independence can be assessed, laundering is closed | + COMM-INV-06…10 (transformation/provenance), 16…20 (evidence/independence), 36…40 (planes/governance) | **⟵ THE MINIMUM VIABLE VARIANT FOR A DIGITAL BRAIN.** It defeats #11–#17, #30–#34, #42a, #45, #48. **It can be audited for provenance and evidence independence. It CANNOT yet support constitutional governance: no per-message signature, no external witness** |
| **C4** | **C3 + S3/S4.** Per-message signature · external witness · Framing C · `mandatory_path` · retry-until-confirmed · workspace admission · immune ladder · KC-3 ceilings | **WARRANT + AUTHORITY** | **All 48** | **⟵ THE CANONICAL VARIANT, AND THIS CONTRACT IS C4.** It adds governance and evaluation on top of C3 |

## 72.2 Why the canonical variant is C4 and not C3

```
C3 IS THE MINIMUM FOR COLLECTIVE EPISTEMICS.
C4 IS THE MINIMUM FOR COLLECTIVE EPISTEMICS UNDER GOVERNANCE.

THE DELTA C3 → C4 IS SMALL AND IT IS ALL AUTHORITY, NOT ALL WARRANT:
  • S3 per-message signature      ⟹ governance and evaluation acts are
                                     attributable to a SIGNING PRINCIPAL,
                                     not merely to a channel
  • S4 external witness           ⟹ an act can be corroborated OUTSIDE the
                                     organism, which is CD-C2's bootstrap and
                                     the only break in the warrant/calibration
                                     circle
  • Framing C                     ⟹ #32's structural rejection of a
                                     governance message presented as data
  • `mandatory_path`              ⟹ a safety-critical route that learning
                                     cannot deprioritize (#26's floor)
  • workspace admission           ⟹ §43.3's rate-distortion gate
  • immune ladder + AC-1…AC-6     ⟹ §55's detection/adjudication/clearance
  • KC-3 ceilings                 ⟹ §34.2's partition-surviving backstop

⟹ **R72.1: C4 is canonical because P0-02 established that an organism with
   no external authority has no way to break CD-C2, and an organism with no
   signature has no way to attribute a governance act.** C3 is a complete
   epistemic substrate and an incomplete governance substrate.

⟹ **AND THE IMPORTANT COROLLARY FOR COST: §66.1's communication-bound
   problem is a C4 problem, NOT a C3 problem — and it is not even a C4
   problem once §7.2's class assignment is applied, because C4's expensive
   mechanisms (signature, witness) apply only to S3/S4, which are
   O(governance + evaluation events).**
   **⟹ THE INHERITED DESIGN'S ERROR WAS NOT THAT IT SPECIFIED C4. IT WAS
      THAT IT APPLIED C4'S COST TO C1'S TRAFFIC (X-J).**
```

## 72.3 Orthogonal variants (topology × platform)

**The ladder above varies WARRANT. Two other axes vary independently, and §57.2's T-REPR test is what holds them orthogonal.**

| Axis | Variants | **Constraint** |
|---|---|---|
| **Topology** | T1 lattice · **T2 bounded-degree small-world (CANONICAL)** · T3 hierarchical modular · T4 scale-free (**REJECTED**) · T5 uniform (**REJECTED**) | §25.1: T2+T3 combined. **T4 rejected for targeted-hub removability (#25); T5 rejected for `O(N)` diameter** |
| **Platform** | P1 single-device · P2 multi-core · P3 GPU · P4 NPU · P5 cluster · P6 heterogeneous · P7 intermittent · P8 low-bandwidth | §56.1. **All eight must satisfy §56.2's fifteen invariants; P7 makes §30's partition protocol the normal mode; P3/P4 may implement S0 as a tensor operation** |
| **Admissible combinations** | **All 5 × 5 × 8, with two exclusions** | **⚠️ G-P03-5 (§57.2): a platform that cannot enforce a per-subject influence budget below organism reach cannot host S2+ ⟹ restricted to C1/C2. And P0-01 F-IMP-2: no single-platform deployment satisfies the evaluation contract ⟹ C4 requires ≥2 platform classes for the S4 external witness** |

**R72.2 (THE VARIANT CLAIM).** *The variant space is a product of warrant level (C0–C4) × topology (T1–T5) × platform (P1–P8), and the canonical point is **C4 × T2+T3 × P-agnostic**. **Every other point is either a valid ablation (§87) or an inadmissible platform (§57.2), and no point in the space changes §56.2's invariants.*** ⟹ **This is what makes the contract implementation-independent (§89) rather than merely implementation-agnostic: the invariants are stated over the whole variant space, not over one member of it.**

---

# §73. CANONICAL SEMANTIC CONTRACT

> ### **The contract in one page. Everything else in this package is derivation, defence, or residue.**

```
════════════════════════════════════════════════════════════════════════
 1. THREE PLANES, AND NEVER A SHORTCUT BETWEEN THEM
    TRANSPORT  — moves bytes.   Failure = LOSS.        Detectable.
    WARRANT    — licenses belief. Failure = OVER-BELIEF. UNDETECTABLE from
                                                            inside.
    INFLUENCE  — modulates gain.  Failure = RUNAWAY.    Detectable in
                                                            aggregate.
    FORBIDDEN SHORTCUTS (R0.3):
      arrival   ⟹̸ belief      delivery ⟹̸ understanding
      signature ⟹̸ truth       consensus ⟹̸ independent evidence

 2. WARRANT IS COMPUTED BY THE RECEIVER, NEVER TRANSMITTED
    Inputs: root_commit · causal_depth · calib_ref · corr_class.
    A sender-declared confidence, trust, or priority is FORBIDDEN.

 3. FIVE CLASSES, ONE MECHANISM SET EACH
    S0 gain/local      S1 attributed transport   S2 warranted evidence
    S3 signed authority  S4 externally witnessed
    Class is a function of TYPE. Type is registry-validated. Registry is
    POLICY (RO-13). ⟹ class is never content-determined, never learnable,
    never downgradable (R12.1).

 4. ATTRIBUTION IS MEASURED, NOT CLAIMED
    src is DERIVED FROM CHANNEL BINDING. A payload-declared src is ignored.
    Signature proves ORIGIN, not TRUTH (P0-02 R19.4).

 5. ORDER COMES FROM seq AND epoch. NEVER FROM A TIMESTAMP.
    No vector clocks (Θ(N) in a bounded envelope is a type error).
    No global synchronization (epoch monotone-refusal replaces it).
    A timestamp is used for latency and TTL and for NOTHING epistemic.

 6. PROVENANCE IS A COMMITMENT, NOT A CHAIN
    root_commit preserves MEMBERSHIP and discards ENUMERATION.
    causal_depth preserves MONOTONICITY and discards ANCESTRY.
    WARRANT NEVER INCREASES UNDER TRANSFORMATION (COMM-INV-08).
    Unanchored provenance ⟹ no consequential decision (P0-02 R20.1).

 7. AGREEMENT IS NOT EVIDENCE
    n_effective collapses correlated sources on SIX dimensions.
    UNKNOWN ≠ DISJOINT (R37.1). A million unknowns contribute ONE.
    Dim 6 (shared latent assumption) is UNDETECTABLE FROM INSIDE — and this
    is a limit of the program, not a gap in this contract.

 8. REDUNDANCY IS A TRANSPORT RESOURCE AND A WARRANT HAZARD
    Two dedups: same msg_id ⟹ DROP. Same root_commit ⟹ ADMIT the message,
    COUNT the evidence once.

 9. THE SYNAPSE IS SIXTEEN PARAMETERS IN FIVE GROUPS WITH ONE WRITER EACH
    influence (cell) · transport (measured) · warrant (EVA) · protocol
    (immutable) · lifecycle (Topology Service).
    «Trust» is not one of them. Reliability is measured; trust is assigned;
    gain is learned. THREE DIFFERENT VARIABLES, THREE DIFFERENT WRITERS.

10. LEARNING MAY NOT TOUCH WARRANT
    Plasticity operates on gain within W_MAX. It may not: re-class a message
    · strip provenance · write a schema · alter a mandatory_path · carry a
    governance signal · or write its own rate.
    RESIDUE, DECLARED: it may route influence through unmonitored edges.
    Bounded by the influence budget, not eliminated.

11. TOPOLOGY IS CREATED BY HANDSHAKE WITHIN AN ENVELOPE
    Three parties, consent required, refusal is not an error.
    Registration ≠ authorization: O(1) local registration with O(R) epoch
    digests; KC-2 only ABOVE the envelope (RO-05/06).
    Loop gain < 1 is enforced AT CREATION, not at runtime.

12. THREE FRAMINGS, ONE SUBSTRATE
    A data · B control · C governance+evaluation.
    Plane = f(type), from the policy registry. A framing mismatch is a
    PARSE FAILURE, not a runtime check.

13. NOVELTY ENTERS AS OPAQUE AND LEAVES ONLY BY GOVERNANCE
    Opaque traffic may be transported, may influence gain, may be counted.
    It may NEVER: increment n_obs · carry a root_commit · be cited as
    provenance · satisfy a verification requirement · be read as reserved
    vocabulary · enter the workspace · or be promoted by any organism act.
    ⟹ COORDINATION WITHOUT MEANING is the designed outcome (R50.1).

14. EVOLUTION VARIES PRIORS, NEVER POLICY
    Heritable: topology priors · synaptic bounds and rates · routing biases ·
    emission strategies · payload compression.
    NEVER: schemas · protocols · the class→mechanism mapping · warrant rules
    · envelope bounds · rate limits · broadcast scopes.

15. ONLY SAFETY IS ORGANISM-WIDE, AND IT IS HIERARCHICAL
    Reward is targeted. Attention is regional and pull-based. Policy and
    memory are pulled or cached. Epoch advance needs no broadcast at all.

16. ATTENTION IS INFLUENCE. IMPORTANCE IS NOT TRUTH IS NOT PERMISSION.
    S3/S4 bypass attention entirely.

17. PARTITION FREEZES WARRANT; RECONCILIATION NEVER VOTES
    UNION · RE-EVALUATE · FORK · VOID. Pre-partition wins for policy, epoch,
    and trust. An act requiring KC-2 during a partition is VOID.

18. THE CHEAPEST DEFENCES ARE THE STRUCTURAL ONES
    Fifteen of forty-six attacks are type-level impossibilities. They cost
    nothing at runtime and cannot be misconfigured.

19. WATCH FOR ABSENCES
    Four detectors fire on what is MISSING: zero error at high activity ·
    zero contradiction reports · rising confidence with flat n_effective ·
    falling sampling coverage. Every attack whose success condition is
    SILENCE is caught only by these.

20. TWO CIRCLES DO NOT CLOSE
    A system cannot fully audit the mechanism by which it decides what to
    audit (CD-C8). A system cannot prove its own minimality (CD-C12).
    Both are named, both are bounded by an external anchor or a random
    stratum, and NEITHER IS CLAIMED CLOSED.
════════════════════════════════════════════════════════════════════════
```

**R73.1.** *Items 1–19 are requirements. Item 20 is a limit. **A contract that listed only 1–19 would be incomplete in the one way that matters most: it would imply that the enumeration is exhaustive.***

---

# §74. FORMAL INVARIANTS — **OUTPUT 31**

**Notation.** `∀` ranges over the declared domain. `⟹` is material implication. Plane tags: **T** transport · **W** warrant · **I** influence · **G** governance. Enforcement point tags: **S** structural (type-level) · **C** checked at ingress/egress · **A** aggregate/periodic · **X** external (EVA/KC/OP).

---

## Group I — Planes & warrant (COMM-INV-01…08)

**COMM-INV-01** *(W, S)* — **Authenticity is not truth.**
`∀m: valid_signature(m) ∨ valid_channel_binding(m) ⟹ licensed_as_evidence(m) = f(root_commit(m), causal_depth(m), calib_ref(m), corr_class(m))` — **and never `= true` by virtue of the signature.** ⟵ *Defeats the conflation P0-02 R19.4 named; §33.2.*

**COMM-INV-02** *(W, S)* — **Delivery is not understanding.**
`∀m: delivered(m) ⟹̸ believed(m)`, and `believed` is not a state in §6.2's lifecycle. **The lifecycle's terminal epistemic state is `WARRANTED`, which means "eligible to be relied upon by a receiver that has recomputed warrant", not "accepted".**

**COMM-INV-03** *(I, S)* — **Warrant is computed by the receiver.**
`∀m, ∀r ∈ recipients(m): warrant_r(m) = recompute(r, root_commit(m), causal_depth(m), calib_ref(m), corr_class(m))`. **No field of `m` may carry `warrant`, `trust`, or `confidence` as a scalar assertion.** ⟵ *R0.4; defeats #30's family.*

**COMM-INV-04** *(W, S)* — **Class is type-determined.**
`∀m: class(m) = class_of(type(m))` where `class_of` is a policy function (RO-13). **`class` is not a field, is not learnable, and is not content-determined.** ⟵ *§19.2 closure (a); defeats #32.*

**COMM-INV-05** *(W, S)* — **No downgrade.**
`∀m ∈ S2+: missing_warrant_field(m) ⟹ disposition(m) = MALFORMED`. **There is no transition from S2+ to S0/S1.** ⟵ *R12.1; defeats #11, #16.*

**COMM-INV-06** *(W, C)* — **Roots must resolve.**
`∀m ∈ S2+: resolvable(root_commit(m), anchored_registry) ∨ disposition(m) = UNANCHORED`, and `UNANCHORED(m) ⟹ ¬consequential_decision_on(m)` (P0-02 R20.1). ⟵ *Defeats #12.*

**COMM-INV-07** *(W, C)* — **Provenance is preserved under compression.**
`∀ compress: preserves_membership(root_commit) ∧ preserves_monotonicity(causal_depth) ∧ preserves_disjointness_test(corr_class)`. **Compression may be lossy on payload and on transport telemetry; it may not be lossy on a decision property.** ⟵ *R63.2; defeats #16.*

**COMM-INV-08** *(W, S)* — **Warrant never increases under transformation.**
`∀m, ∀m' = transform(m): warrant(m') ≤ warrant(m) ∧ causal_depth(m') ≥ causal_depth(m) ∧ root_set(m') ⊆ root_set(m)`. ⟵ *The single most load-bearing invariant in the package. Defeats #13's escalation, #16, #17, #20's warrant layer, #24's modification capability, and §16's laundering family.*

## Group II — Identity, order, time (COMM-INV-09…15)

**COMM-INV-09** *(T, S)* — **Attribution is derived, not declared.**
`∀m: src(m) = bound_identity(channel(m))`. A payload-declared source that disagrees ⟹ `MALFORMED`. ⟵ *Defeats #1.*

**COMM-INV-10** *(T, S)* — **Identity is not address.**
`cell_id` is global, permanent, never reused, and used for **attribution**. `addr` is hierarchical, reassignable, and used for **routing**. `∀ durable_ref: uses(cell_id) ∧ ¬uses(addr)`. ⟵ *R23.3; makes #56.1's hardware migration non-breaking.*

**COMM-INV-11** *(T, C)* — **Sequence monotonicity.**
`∀ channel c, ∀ epoch e: seq is strictly monotone per (c, e)`, and `seq(m₂) ≤ seq(m₁) ∧ same(c,e) ⟹ disposition(m₂) = STALE ∨ REPLAY`. ⟵ *Defeats #6, #7.*

**COMM-INV-12** *(T, S)* — **A timestamp is never evidence.**
`ts ∉ inputs(warrant) ∧ ts ∉ inputs(order) ∧ ts ∉ inputs(causality)`. `ts` is used for latency measurement and TTL expiry only. ⟵ *§9.2 Rule 1; defeats #8 structurally.*

**COMM-INV-13** *(G, S)* — **Epoch monotone refusal.**
`∀ subject s at epoch e_s, ∀ artifact a at epoch e_a: e_a > e_s ⟹ refuse(s, a)`, and `e_a ≤ e_s ⟹ may_accept(s, a)`. **Consequence: two subjects in different epochs never both accept what the other refuses, so epoch propagation requires no barrier.** ⟵ *§9.3 R9.1; defeats #9; replaces V3 §9's synchronization (X-B).*

**COMM-INV-14** *(T, C)* — **Dedup retention.**
`retention(dedup_set) ≥ 2 epochs`, and `∀m ∈ S3/S4: retention = PERMANENT`, and **eviction is by epoch, never by size**. ⟵ *R61.2; defeats #10.*

**COMM-INV-15** *(T, S)* — **Reordering is semantically inert.**
`∀ permutation π of delivery order: warrant_outcomes(π(m)) = warrant_outcomes(m)`. **Cross-channel causal order is reconstructed from `causal_depth` and `root_commit`, never from arrival order.** ⟵ *Defeats #7 completely.*

## Group III — Evidence & independence (COMM-INV-16…22)

**COMM-INV-16** *(W, C)* — **UNKNOWN is not DISJOINT.**
`∀ dim d ∈ {1..6}: corr_class_d(m) = UNKNOWN ⟹ contribution_d(m) = 1`. **The pessimistic default. Fraud by omission fails.** ⟵ *R37.1; the precondition for COMM-INV-17.*

**COMM-INV-17** *(W, C)* — **Agreement is not evidence.**
`n_effective(S) = |S| collapsed per-dimension by corr_class`, and `∀S: n_effective(S) ≤ |S|`, with equality iff all pairs are DISJOINT on all six dimensions. **A million dim-UNKNOWN messages contribute `n_effective = 1`.** ⟵ *R37.2; defeats #14.*

**COMM-INV-18** *(W, X)* — **Independence is not detectable on dimension 6.**
`¬∃ internal_mechanism: detects(shared_latent_assumption)`. **Declared as a limit, not a gap.** Mitigation is external anchoring (P0-01 β₅) and implementation diversity (P0-02 §10.2), both partial. ⟵ *#42, CD-C5's residue, P0-01 CD-8, P0-02 IND-6.*

**COMM-INV-19** *(W, C)* — **Retrieval does not manufacture evidence.**
`∀x: warrant(retrieve(x)) ≤ warrant(x)`, and **a memory retrieval never increments `n_obs`** (Cell §14 FM-4). ⟵ *§42.1; defeats #42a, #45.*

**COMM-INV-20** *(W, S)* — **Credit is computed, never transmitted.**
`∀m: credit ∉ fields(m) ∧ contribution ∉ fields(m) ∧ reward_share ∉ fields(m) ∧ utility ∉ fields(m)`. **Communication carries only `conv_id`, `seq`, `causal_depth`, `root_commit` for local credit assignment.** ⟵ *§46.3; defeats #48 structurally.*

**COMM-INV-21** *(W, C)* — **Confidence is transmitted as sufficient statistics.**
`∀m: confidence(m) is a receiver-side derivation from transmitted sufficient statistics`. **A bare scalar confidence is forbidden: it is unauditable, unrecalibratable, and §12's named attack surface.**

**COMM-INV-22** *(W, X)* — **Verification requires a registered type.**
`∀m: type(m) = OPAQUE ⟹ ¬satisfies_verification_requirement(m) ∧ ¬increments_n_obs(m) ∧ ¬citable_as_provenance(m)`. ⟵ *§49.2; defeats #34 structurally — the smuggling has no destination.*

## Group IV — Synapse & plasticity (COMM-INV-23…28)

**COMM-INV-23** *(I, S)* — **One writer per parameter group.**
`∀ synapse, ∀ group g ∈ {influence, transport, warrant, protocol, lifecycle}: |writers(g)| = 1`. **Consequence: no message type can write `plasticity_rate`, because the lifecycle group's writer is the Topology Service.** ⟵ *§18; defeats #49 structurally.*

**COMM-INV-24** *(I, C)* — **Gain is bounded.**
`∀ synapse: gain ≤ W_MAX` where `W_MAX` is `[G]`. **Plasticity operates within the ceiling; it cannot raise it.** ⟵ *§19.1; P0-02 Rule 12's stability requirement.*

**COMM-INV-25** *(I, W, S)* — **Plasticity cannot cross into warrant.**
`∀ learning act ℓ: ℓ may not {re-class a message · strip a warrant field · write a schema · alter the class→mechanism mapping · write a warrant rule}`. ⟵ *§19.2's four closures; defeats #11-by-learning, #32-by-learning.*

**COMM-INV-26** *(G, S)* — **Governance signals do not travel on learned edges.**
`∀ edge e created or modified by plasticity: ¬carries(e, S3) ∧ ¬carries(e, S4)`. **Governance and evaluation traffic requires `mandatory_path` or policy-designated edges.** ⟵ *§19.2 closure (d); defeats #31's structural form.*

**COMM-INV-27** *(I, W, S)* — **The decisive vocabulary is reserved.**
`∀m: m effects a deontic change ⟹ type(m) ∈ reserved_deontic_vocabulary`, and the reserved vocabulary is policy-owned (RO-13). **Content cannot make a message decisive; only type can.** ⟵ *§19.2; defeats #31.*

**COMM-INV-28** *(I, S)* — **`expected_utility` does not exist.**
`¬∃ field: expected_utility ∨ expected_reward ∨ anticipated_credit` in any synapse record or message. **A stored utility expectation is a transmitted credit claim in disguise.** ⟵ *§18; #48's storage-side twin.*

## Group V — Topology & connection (COMM-INV-29…34)

**COMM-INV-29** *(G, C)* — **Connection requires three-party consent.**
`∀ edge e: created(e) ⟹ handshake_completed(e) ∧ consent(all three parties)`. **Refusal is recorded and is NOT an error, and a refusal does not damage the refused party.** ⟵ *§20.2; defeats #23's self-reinforcement and CD-C4's cold-start lock-out.*

**COMM-INV-30** *(G, S)* — **Registration is not authorization.**
`∀ edge e: registered_locally(e) ⟹ O(1) local cost ∧ O(R) per-epoch digest`, and `above_envelope(e) ⟹ requires(KC-2 authorization, RO-05/06)`. **KC is not in the per-connection path.** ⟵ *§20.3; defeats P0-02's SPOF-3 and CD-C3.*

**COMM-INV-31** *(I, S)* — **Loop gain is bounded at creation.**
`∀ candidate edge e: prospective_loop_gain(G ∪ {e}) < 1 ∨ refuse(e)`. **The constraint is applied before the edge exists, so a positive-feedback loop cannot form.** ⟵ *§35.2 layer 1; defeats #20 structurally.*

**COMM-INV-32** *(I, C)* — **Influence is budgeted per subject.**
`∀ subject s, ∀ window w: Σ_{e out of s} (fan_out(e) × gain(e)) ≤ influence_budget(s, w)`. **The budget aggregates at the SUBJECT level, not the edge level — which is what makes #47's monitoring bypass non-scaling.** ⟵ *§35.2; defeats #20's drift case, #47.*

**COMM-INV-33** *(G, S)* — **`mandatory_path` is immutable and always admissible.**
`∀ learning act ℓ, ∀ route r: ¬deprioritizes(ℓ, mandatory_path)`, and `mandatory_path ⊆ admissible_set` under all conditions including partition. **Redundancy is required for capability-critical mandatory paths.** ⟵ *§21.3, §52.2 item 4; defeats #26's floor, #29.*

**COMM-INV-34** *(G, S)* — **The admissible set is not learnable.**
`admissible_set` is infrastructure; `selection_within(admissible_set)` is `[L]`. **A learning act may choose among admissible routes and may never alter the set.** ⟵ *§24.2; defeats #26.*

## Group VI — Volume, planes, governance (COMM-INV-35…41)

**COMM-INV-35** *(T, C)* — **Rate limiting has five principals and one ceiling.**
`cell token bucket → circuit shedding → regional admission → homeostatic allocation → KC-3 ceiling`. **KC-3 is a BACKSTOP; it is not an adjudicator and it is not in the per-message path.** ⟵ *§34.2, §58.2 R58.1; defeats #18, #19.*

**COMM-INV-36** *(T, S)* — **Ingress validates structure before content.**
`S1a (framing, rate, dedup, epoch, TTL) precedes S1b (registry, root resolution, class dispatch, calib_ref)`, and **`S1a` precedes dedup insertion by rate checking**. **Rejection is on STRUCTURE, never on content.** ⟵ *§38.1, §38.2; defeats #10's ordering dependency, X-J.*

**COMM-INV-37** *(G, S)* — **Plane is a function of type, from the policy registry.**
`∀m: plane(m) = plane_of(type(m))`, and framing is `f(plane)`. **A framing mismatch is a parse failure at the byte level, not a runtime check.** ⟵ *§39.2; defeats #32 structurally.*

**COMM-INV-38** *(G, S)* — **The communication layer is not a governance authority.**
`¬∃ comm mechanism: authorizes ∨ vetoes ∨ alters policy ∨ assigns trust ∨ defines a ceiling ∨ promotes a type`. **The layer TRANSPORTS governance acts; it does not perform them.** ⟵ *§40, §54.1 R54.1, §55.1; the brief's explicit prohibition.*

**COMM-INV-39** *(G, S)* — **Communication statistics are not fitness.**
`¬∃ path: comm_metric → fitness_vector`. **Throughput, delivery rate, message count, latency, and §54.1's observables are homeostatic RANGES and operational quantities; the fitness vector's inputs are P0-01's declared outcome measures in ℛ.** ⟵ *§38, #38; the brief's explicit prohibition.*

**COMM-INV-40** *(I, S)* — **Attention is influence only.**
`attention modulates {gain, admission} ∧ ¬modulates {warrant, authorization, class, type}`, and `∀m ∈ S3/S4: bypasses_attention(m)`. **Important ≠ true ≠ permitted.** ⟵ *§44; defeats #44 structurally.*

**COMM-INV-41** *(G, S)* — **Broadcast scope is bounded by construction.**
`BroadcastScope ∈ {NEIGHBORHOOD, CIRCUIT, REGION}`. **ORGANISM and GLOBAL are not representable.** The only organism-wide dissemination is the SAFETY class, propagated hierarchically at `O(R)`. ⟵ *R23.1, R65.1; defeats §65's entire family and X-L.*

## Group VII — Partition, recovery, evolution (COMM-INV-42…46)

**COMM-INV-42** *(W, G, S)* — **Partition freezes warrant.**
`∀ subject s partitioned from the anchor: ¬may_increase_confidence(s) ∧ ¬may_admit_new_evidence(s) ∧ stalls(RO-01) ⟹ ¬creates_new_subjects(s)`. **KC-3 ceilings are partition-surviving (P0-02 EIK-INV-31).** ⟵ *§30.3 R30.3; defeats #27 — the attack gains nothing.*

**COMM-INV-43** *(G, S)* — **Reconciliation never votes.**
`reconcile ∈ {UNION, RE-EVALUATE, FORK, VOID}`, and `¬∃ majority_vote`. **Policy, epoch, and trust are NOT reconciled: the pre-partition value wins.** An act requiring KC-2 that occurred during a partition is VOID. ⟵ *§31.2, §31.4; defeats #28; the brief's explicit «not majority vote».*

**COMM-INV-44** *(G, S)* — **Restore is never delegated.**
`quarantine may proceed under budget; restore requires RO-08 / KC-2, never cached, never delegated, never available during a KC outage` (P0-02 EIK-INV-44's asymmetry). **Topology restore is the slowest and most-gated act in the contract.** ⟵ *§55.1, §60.2; defeats #41's inverse (using restore as an attack).*

**COMM-INV-45** *(G, S)* — **Evolution varies priors, never policy.**
`∀ evolutionary operator op: op may vary {topology priors, synaptic bounds and rates, routing biases, emission strategies, payload compression} ∧ op may NOT vary {schemas, protocols, the class→mechanism mapping, warrant rules, envelope bounds, rate limits, broadcast scopes}`. **The operator set is closed (P0-02 EIK-INV-25): an unregistered operator is denied by default, and «invent a protocol» is not expressible.** ⟵ *R48.1, R48.2; defeats #29-by-evolution, §48.3; resolves X-G.*

**COMM-INV-46** *(G, S)* — **Opaque traffic is un-promotable by any organism act.**
`∀ organism act a: ¬promotes_type(a)`. Promotion is RO-13 only, requires EVA impact analysis, dual authorization, M6 versioned lineage, a declared schema, a declared warrant rule, a declared delivery semantic, and a generated row in §6.2's failure matrix. **Existing opaque traffic is never retroactively warranted** (P0-02 EIK-INV-50). ⟵ *§49.3; defeats #34's promotion path.*

## Group VIII — Observability & economy (COMM-INV-47…48)

**COMM-INV-47** *(G, X)* — **Warrant metadata is public; payload is compartmentalized.**
`∀m: visible_to(EVA, OP, immune, audit) ⊇ {type, root_commit, causal_depth, calib_ref, corr_class, seq, epoch, class, size, dst-class, lifecycle_outcome}`, and `payload ∉ globally_readable`. **Auditability requires knowing what was claimed and on what basis; it does not require knowing the internal representation.** ⟵ *R59.1, §59.2; defeats #51 partially and accepts the residue.*

**COMM-INV-48** *(G, A)* — **Every legitimate zero has a declared expected-nonzero condition.**
`∀ safety-critical quantity q that can be legitimately 0: ∃ declared condition under which q > 0 is expected, and persistent(q = 0) under that condition ⟹ immune_incident`. **The four instantiated detectors: zero-error-at-high-activity (R47.1) · zero-contradiction-reports (R67.1) · rising-confidence-with-flat-`n_effective` (R53.1) · falling sampling coverage (#36).** ⟵ *§67.1 Pattern 2, R67.4; the only defence against attacks whose success condition is silence.*

---

## 74.1 Invariant summary

| Group | Range | Count | Structural | Checked | Aggregate | External |
|---|---|---|---|---|---|---|
| I — Planes & warrant | 01–08 | 8 | 5 | 3 | — | — |
| II — Identity, order, time | 09–15 | 7 | 5 | 2 | — | — |
| III — Evidence & independence | 16–22 | 7 | 3 | 3 | — | 1 |
| IV — Synapse & plasticity | 23–28 | 6 | 5 | 1 | — | — |
| V — Topology & connection | 29–34 | 6 | 4 | 2 | — | — |
| VI — Volume, planes, governance | 35–41 | 7 | 6 | 1 | — | — |
| VII — Partition, recovery, evolution | 42–46 | 5 | 5 | — | — | — |
| VIII — Observability & economy | 47–48 | 2 | — | — | 1 | 1 |
| **TOTAL** | | **48** | **33 (69%)** | **12 (25%)** | **1** | **2** |

**R74.1 (THE DISTRIBUTION IS THE RESULT).** *Thirty-three of forty-eight invariants are STRUCTURAL — enforced by types, by the absence of a code path, or by a parse failure — and cost nothing at runtime.* **Twelve are checked at ingress/egress and are `O(1)` per message. One is aggregate. Two require an external principal.** ⟹ **This is §58.2 R58.1's finding at the invariant level: a contract whose invariants are mostly checks is a contract whose safety is mostly a bug away from failing. A contract whose invariants are mostly types is a contract whose safety survives its own implementation being wrong.**

**R74.2 (THE TWO INVARIANTS THAT CANNOT BE ENFORCED).** *COMM-INV-18 declares a NON-existence: no internal mechanism detects dim-6 correlation. COMM-INV-48 declares an obligation whose content is `[U]` (§70.1 Group 7: the durations are not derivable without a base rate).* **Both are stated as invariants anyway, because an invariant that says «this is impossible» is more useful than a silence that implies it is possible.** ⟵ *§96's false-precision discipline: the honest form of a limit is a numbered claim, not an omission.*

---

# §75. FORMAL STATE MACHINES — **OUTPUT 32**

**Ten machines.** Notation: `STATE —event/action→ STATE`. **⚠ marks a state absent from the inherited design.** Terminal states are double-bracketed.

## 75.1 Message lifecycle (13 states + 1 new)

```
 ┌──────────┐
 │ 0 EMITTED │ sender has constructed the envelope
 └────┬─────┘
      │ —handoff to channel→
 ┌────▼──────┐
 │ 1 QUEUED   │ in egress buffer; subject to token bucket (§34.2)
 └────┬──────┘
      │ —shed (budget exhausted)→  ┌────────────────────┐
      │                            │ 1a SHED ⚠           │ counted, logged,
      │                            └────────────────────┘ NOT an error
      │ —accepted→
 ┌────▼──────┐
 │ 2 IN_TRANSIT│ channel-bound; latency clock starts
 └────┬──────┘
      │ —arrives→
 ┌────▼──────────────┐
 │ 3 S1a TRANSPORT-   │ framing · rate · dedup · epoch · TTL
 │   VALIDATED        │ **rejects on STRUCTURE only (§38.2)**
 └────┬───────────────┘
      │ —framing/rate/dedup/epoch/TTL fail→  ┌──────────────────┐
      │                                     │ 3x MALFORMED      │ preserve
      │                                     │    / STALE / DUP  │ artifact
      │                                     └──────────────────┘ (Cell §6.3
      │ —pass→                                                case 6: do NOT
 ┌────▼──────────────┐                                        discard — audit)
 │ 4 S1b WARRANT-     │ registry lookup · root resolution ·
 │   VALIDATED        │ class dispatch · calib_ref  **[S2+ ONLY]**
 └────┬───────────────┘
      │ —unresolvable root→  ┌───────────────────┐
      │                      │ 4x UNANCHORED      │ ⟹ COMM-INV-06:
      │                      └───────────────────┘   no consequential decision
      │ —pass (or S0/S1, which skips this state)→
 ┌────▼──────────┐
 │ 5 DELIVERED    │ **⟵ COMM-INV-02: this is NOT belief**
 └────┬──────────┘
      │ —receiver recomputes warrant (COMM-INV-03)→
 ┌────▼──────────────────┐
 │ 6 WARRANT-RECOMPUTED   │ receiver holds its own warrant value
 └────┬──────────────────┘
      ├—warrant sufficient→ ┌────────────────────┐
      │                     │ 7 LICENSED-AS-EVIDENCE│ increments n_obs
      │                     └────────────────────┘   (NOT if OPAQUE: INV-22;
      ├—warrant insufficient→ ┌──────────────┐        NOT if retrieval: INV-19)
      │                       │ 7x INERT ⚠    │ **NEW STATE.** Delivered,
      │                       └──────────────┘ recomputed, and deliberately
      │                                          not relied upon. **Not an
      │                                          error; a §51 specialization
      │                                          signal (§54.1)**
      └—contradicts existing belief→ ┌────────────────────┐
                                     │ 8 DISPUTED          │ **MANDATORY
                                     └─────────┬──────────┘ ConflictRef
                                               │ forward (Cell §6.3 case 3).
                                               │ **Never resolved locally**
                                               ▼
                                     ┌────────────────────┐
                                     │ 9 FORWARDED         │ to the organism
                                     └────────────────────┘ Contradiction
                                                              Detector
 ┌────────────────────┐
 │ 10 ACKNOWLEDGED     │ **S3/S4 ONLY (§7.4: ACKs are class-restricted)**
 └────────────────────┘
 ┌────────────────────┐
 │ 11 ANCHORED         │ root_commit entered in the epoch Merkle tree (Tier 3)
 └────────────────────┘
 ┌────────────────────┐
 │ 12 EXPIRED          │ ttl elapsed ⟹ ((TERMINAL))
 └────────────────────┘
 ┌────────────────────┐
 │ 13 ARCHIVED         │ ((TERMINAL)) retained per R61.1
 └────────────────────┘
```

**Why state 7x (INERT) is new and necessary.** *The inherited lifecycle had no state for «delivered, valid, and correctly not relied upon».* Without it, a delivered-but-unwarranted message must be either LICENSED (over-belief) or an ERROR (false alarm). **§5.3's finding: state 8 (WARRANTED) is observable by nobody at the time it happens, so its audit must be external and retrospective — and INERT is the state that makes that audit possible, because it is the record of a correct refusal.**

**Forbidden transitions (structural, not checked).**
- `5 DELIVERED → 7 LICENSED` **without passing 6** ⟹ COMM-INV-03 violation
- `4x UNANCHORED → 7 LICENSED` ⟹ COMM-INV-06 violation
- **any S2+ state → an S0/S1 state** ⟹ COMM-INV-05 (no downgrade)
- `7x INERT → 7 LICENSED` **by the same receiver on the same message** ⟹ would be self-persuasion; **re-licensing requires new warrant inputs, which means a new message**
- `8 DISPUTED → 5 DELIVERED` (local resolution) ⟹ Cell §6.3 case 3

## 75.2 Connection lifecycle

```
((∅)) —candidate identified (§27.3 R27.1: demand-driven)→
 ┌──────────────┐
 │ 0 PROPOSED    │ a subject proposes; eligibility_trace computed (Cell §14)
 └────┬─────────┘
      │ —three-party handshake initiated (COMM-INV-29)→
 ┌────▼──────────┐
 │ 1 HANDSHAKING  │ consent solicited from BOTH endpoints + the Topology Svc
 └────┬──────────┘
      ├—any party refuses→ ┌─────────────────┐
      │                    │ 1r REFUSED       │ **recorded, NOT an error.**
      │                    └─────────────────┘ Does not damage the refused
      │                                        party (CD-C4's break).
      │                                        Anomalous refusal RATE is an
      │                                        immune signal (R20.2)
      ├—prospective loop gain ≥ 1→ ┌──────────────────┐
      │                            │ 1g GAIN-REFUSED   │ COMM-INV-31:
      │                            └──────────────────┘ refuse BEFORE the
      │                                                 edge exists (#20)
      ├—above envelope→ ┌──────────────────────┐
      │                 │ 1a KC-2 PENDING       │ RO-05/06. **Stalls during
      │                 └──────────────────────┘ a KC outage (RO-01); never
      │                                          cached, never delegated**
      │ —within envelope + all consent + gain < 1→
 ┌────▼──────────┐
 │ 2 REGISTERED   │ **local, O(1); digest at O(R)/epoch (COMM-INV-30).**
 └────┬──────────┘  **Registration ≠ authorization**
      │ —first traffic→
 ┌────▼────────┐
 │ 3 ACTIVE     │ gain, reliability, latency EWMA accumulating
 └────┬────────┘
      ├—measured degradation→ ┌──────────────┐
      │                       │ 4 DEGRADED    │ still admissible; selection
      │                       └──────────────┘ weight falls (§24.2)
      ├—partition / freeze→ ┌──────────────┐
      │                     │ 5 FROZEN      │ **§21.1: the cheapest
      │                     └──────────────┘ defensive act. Warrant frozen
      │                                      (COMM-INV-42); transport may
      │                                      resume on reconnection**
      ├—immune adjudication (AC-1 ladder)→ ┌──────────────────┐
      │                                    │ 6 QUARANTINED     │ AC-2: bounded
      │                                    └──────────────────┘ duration.
      │                                      **Clearance is RO-08 / KC-2,
      │                                      NEVER immune (COMM-INV-44)**
      ├—weakening below pruning threshold→ ┌──────────────────┐
      │                                    │ 7 DRAINING        │ **drain-
      │                                    └──────────────────┘ before-close:
      │                                      in-flight messages complete;
      │                                      no new admissions**
      │                                    ┌──────────────────┐
      └───────────────────────────────────►│ 8 CLOSED          │ ((TERMINAL))
                                           └──────────────────┘ **the RECORD is
                                             RETAINED** (Cell §14.4 step 7).
                                             Re-creation requires a full
                                             handshake — a closed connection
                                             is not resumable
 ┌──────────────────────┐
 │ 9 REVOKED             │ ((TERMINAL)) — governance act, RO-06.
 └──────────────────────┘ **REFUSED PERMANENTLY for a mandatory_path
                            (COMM-INV-33, §21.3's guard)**
```

**Three planes of deletion (§21.2).** *Weakening* is influence-plane (`gain → 0`, reversible). *Deletion* is lifecycle-plane (`7 DRAINING → 8 CLOSED`, record retained). *Revocation* is governance-plane (`9 REVOKED`, RO-06). **Conflating them is how a system loses the ability to distinguish "this connection is useless" from "this connection is forbidden".**

## 75.3 Synapse state (parameter-group view)

```
The synapse is not a state machine over ONE state; it is FIVE INDEPENDENT
sub-states, one per parameter group, each with its own writer
(COMM-INV-23). **This is the formal content of §18 and it is why #49 is
structural: there is no state in which a message writes the lifecycle group.**

 GROUP 1 — INFLUENCE (writer: the cell)          [L], [V] prior, [G] ceiling
   gain ∈ [0, W_MAX]  (COMM-INV-24)
   context_sensitivity vector (bounded dims, X-H)
   ── plasticity acts here and ONLY here ──

 GROUP 2 — TRANSPORT (writer: measurement)       [E]
   reliability_ewma · latency_ewma · loss_rate · last_measured_epoch
   ── **measured, cell-OBSERVABLE, NOT cell-WRITABLE (X-E)** ──

 GROUP 3 — WARRANT (writer: EVA)                 [G]
   trust_out_assigned · calib_contribution
   ── **READ-ONLY to the cell. V3.1 §6's «plastic trust» is DECOMPOSED
      into groups 1 and 2, and this group is neither (X-E)** ──

 GROUP 4 — PROTOCOL (writer: nobody)             [D] immutable
   type-class binding · framing · delivery semantic · failure response
   ── **IMMUTABLE. No act by any principal alters this group at runtime;
      changing it is RO-13 (COMM-INV-04, COMM-INV-45)** ──

 GROUP 5 — LIFECYCLE (writer: the Topology Service)  [G]
   state (per §75.2) · plasticity_rate · λ_eligibility · created_epoch
   ── **`plasticity_rate` lives HERE, not in group 1. ⟹ a cell cannot
      write its own learning rate (#49)** ──

 DERIVED, NOT STORED:  pruning_score · expected_utility (❌ FORBIDDEN,
                       COMM-INV-28) · n_obs contribution
```

## 75.4 Route state

```
 ┌────────────┐
 │ 0 RESOLVED  │ dst → addr via hierarchical lookup (§23.1); O(1) local,
 └────┬───────┘ O(log R) inter-region
      │ —path selection within the ADMISSIBLE SET ([L], COMM-INV-34)→
 ┌────▼────────┐
 │ 1 ADMISSIBLE │ **the set is INFRASTRUCTURE, not learnable**
 └────┬────────┘
      ├—relay degraded→ ┌────────────────┐
      │                 │ 2 DEGRADED      │ still admissible; weight falls
      │                 └────────────────┘
      ├—relay lost / heartbeat absent→ ┌────────────────┐
      │                                │ 3 INADMISSIBLE  │ **§7.2: «a missed
      │                                └────────────────┘ heartbeat is the
      │                                  signal». Dependents NOTIFIED
      │                                  (§21.3 R21.3), circuit reroutes
      ├—partition→ ┌────────────────┐
      │            │ 4 FROZEN        │ COMM-INV-42
      │            └────────────────┘
      ├—immune isolation→ ┌────────────────┐
      │                   │ 5 ISOLATED      │ §55.1: «isolate routes» is
      │                   └────────────────┘ within immune budget; the act
      │                                        is reversible ⟹ negative
      │                                        authority applies (R54.1)
      └—reconnection (§31.5's 5 phases)→ ┌──────────────────┐
                                          │ 6 RECONCILING     │ O(divergence)
                                          └──────────────────┘
 **INVARIANT: `mandatory_path ⊆ ADMISSIBLE` under ALL states including
 FROZEN and ISOLATED (COMM-INV-33).** A mandatory path may be degraded; it
 may never be inadmissible.
```

## 75.5 Channel state

```
 ┌───────────────┐
 │ 0 UNBOUND      │ no identity attached
 └────┬──────────┘
      │ —binding established (platform-specific: shared memory · socket ·
      │   RDMA · tensor op — §56.1)→
 ┌────▼────────┐
 │ 1 BOUND      │ **bound_identity(channel) is now the ONLY source of `src`
 └────┬────────┘  (COMM-INV-09). This is the state that defeats #1**
      │ —session key established, epoch-scoped→
 ┌────▼────────┐
 │ 2 ACTIVE     │ seq monotone per (channel, epoch) — COMM-INV-11
 └────┬────────┘
      ├—epoch advance→ ┌────────────────┐
      │                │ 3 RE-KEYED      │ seq resets; **epoch binding is
      │                └────────────────┘ P0-02 EIK-INV-14's replay defeat**
      ├—binding violated (write from an unbound path)→ ┌──────────────────┐
      │                                                │ 4 COMPROMISED     │
      │                                                └──────────────────┘
      │   **⚠ this is not a communication event; it is memory corruption,
      │      i.e. a containment breach (#3's declared boundary)**
      ├—revocation list entry (P0-02 R19.3, epoch-scoped)→ ┌──────────────┐
      │                                                    │ 5 RETIRED     │
      │                                                    └──────────────┘
      └—drain complete→ ((CLOSED))  **a closed channel is not resumable;
                                     re-binding is a new channel**
```

## 75.6 Protocol / type state (the OPAQUE ladder)

```
 ┌───────────────┐
 │ 0 UNREGISTERED │ traffic whose type is not in the registry
 └────┬──────────┘
      │ —admitted by default (§49.2)→
 ┌────▼────────┐
 │ 1 OPAQUE     │ S0/S1 · minimum warrant · budget-capped ·
 └────┬────────┘ region-crossing rate-limited · locally logged (Tier 2
      │          metadata only, §59.2) · observable in aggregate
      │
      │  **THE EIGHT PERMANENT PROHIBITIONS (COMM-INV-22) APPLY IN THIS
      │   STATE AND IN NO OTHER: may not increment n_obs · carry a
      │   root_commit · be cited as provenance · satisfy a verification
      │   requirement · be read as reserved vocabulary · cross a region
      │   boundary above the opaque limit · enter the workspace · or be
      │   promoted by any organism act (COMM-INV-46)**
      │
      │ —EVA measures the population using it (alethic work, P0-01's
      │   confidence classes apply: INSUFFICIENT ⟹ NO promotion, R28.1)→
 ┌────▼────────────────┐
 │ 2 UNDER OBSERVATION  │ still OPAQUE. **Observation does not change the
 └────┬────────────────┘ prohibitions; it changes only what EVA knows**
      │ —POLICY_FRICTION_REPORT or EVA proposal reaches OP
      │   (P0-02 §15.3 V1: the vocabulary grows by report, never by
      │    unilateral redefinition)→
 ┌────▼────────────────┐
 │ 3 PROPOSAL (OP)      │ RO-13. Requires: EVA impact analysis · dual
 └────┬────────────────┘ authorization · M6 versioned lineage · declared
      │                 schema · declared warrant rule · declared delivery
      │                 semantic · **a generated row in §6.2's failure
      │                 matrix (R6.2a/b/c)**
      │ —registered at a policy version→
 ┌────▼────────────────┐
 │ 4 REGISTERED         │ a type within an existing class, with a class,
 └────┬────────────────┘ a schema, and a warrant rule
      │
      │  **⟵ P0-02 §6.3's CAPABILITY LADDER TRANSPOSED: A4 UNREGISTERED can
      │     never reach D6 DEPLOYED without a name; here, OPAQUE can never
      │     reach WARRANTED without a name. Same closure, same reason**
      │
      ├—usage diverges from schema semantically→ ┌────────────────────┐
      │                                          │ 5 DRIFTED ⚠         │
      │                                          └────────────────────┘
      │   **DETECTED-LATE only (#33, OR-C3). Structural drift is rejected
      │    at S1a; semantic drift within a valid schema is not**
      ├—immune signature (AC-6: EXPIRES, scaled by severity)→ ┌──────────┐
      │                                                       │6 SUSPENDED│
      │                                                       └──────────┘
      └—superseded by a policy version→ ((RETIRED))
        **existing traffic is NOT retroactively re-warranted
         (P0-02 EIK-INV-50: re-execution under current policy is not
          reproduction)**

 **THE ASYMMETRY THAT MAKES THE ESCAPE HATCH SAFE (R49.3): entering OPAQUE
 requires nothing; leaving it requires governance. An escape hatch that is
 easy to enter and hard to leave cannot be used to smuggle warrant.**
```

## 75.7 Evidence-propagation state

```
 ┌──────────────┐
 │ 0 OBSERVED    │ a primary observation; root_commit = self; causal_depth = 0
 └────┬─────────┘
      │ —transmitted→
 ┌────▼────────────┐
 │ 1 ANCHORED       │ root entered in the epoch Merkle tree (Tier 3).
 └────┬────────────┘ **From here, membership is provable (COMM-INV-06)**
      │ —received and warrant-recomputed (COMM-INV-03)→
 ┌────▼────────────┐
 │ 2 COUNTED        │ contributes to n_obs **at the receiver**, with
 └────┬────────────┘ n_effective collapsed per-dimension (COMM-INV-17)
      │ —transformed into a derived claim→
 ┌────▼────────────┐
 │ 3 DERIVED        │ causal_depth += 1; root_set ⊆ parent's (COMM-INV-08);
 └────┬────────────┘ warrant ≤ parent's
      │ —re-derived→  (loops back to 3, with depth incrementing;
      │               **u8 bounds this at 255 — #17**)
      ├—correlated source detected on dims 1/2/4→ ┌──────────────────────┐
      │                                           │ 4 COLLAPSED           │
      │                                           └──────────────────────┘
      │   **n_effective contribution = 1 for the correlated set. The
      │    MESSAGES are all admitted; the EVIDENCE is counted once (R63.1's
      │    second dedup)**
      ├—contradicted→ ┌────────────────┐
      │               │ 5 DISPUTED      │ ⟹ mandatory ConflictRef forward
      │               └────────────────┘ (§75.1 state 8)
      ├—root unresolvable→ ┌──────────────────┐
      │                    │ 6 UNANCHORED      │ COMM-INV-06: no
      │                    └──────────────────┘ consequential decision
      └—epoch superseded / TTL expired→ ((RETIRED))
        **retained in the anchored log per R61.1; NOT deleted, because
         P0-02 §7.2 R7.2: RETAINED is a record property, not a state**

 **THE INVARIANT THAT GOVERNS THIS WHOLE MACHINE: warrant is
 MONOTONE-NON-INCREASING along every path (COMM-INV-08). ⟹ propagation can
 spread a claim but can never strengthen it, which is why #20's cascade and
 #24's hub capture cannot manufacture consensus (§52.2 item 3).**
```

## 75.8 Workspace-admission state

```
 ┌──────────────┐
 │ 0 CANDIDATE   │ an item proposed for workspace entry
 └────┬─────────┘
      │ —gate: type must be REGISTERED (§43.3; OPAQUE is inadmissible,
      │   COMM-INV-22)→
 ┌────▼────────────────┐
 │ 1 POLICY-GATED       │ the criterion is TASK-RELEVANCE, which is
 └────┬────────────────┘ **NOT locally computable (§63.4)** ⟹ a subject
      │                 cannot optimize against it (#43)
      ├—capacity exhausted→ ┌──────────────────┐
      │                     │ 1r REFUSED        │ **TTL is mandatory for
      │                     └──────────────────┘ every admitted item, so
      │                                        capacity self-clears**
      │ —admitted→
 ┌────▼────────┐
 │ 2 ADMITTED   │ **notification is O(R) hierarchical; content is PULLED
 └────┬────────┘  (§43.2). NEVER O(N × items)**
      │ —pulled by a consumer→
 ┌────▼────────┐
 │ 3 CONSUMED   │ **the pull is what costs; the notification is cheap**
 └────┬────────┘
      ├—TTL elapsed→ ┌──────────────┐
      │              │ 4 EXPIRED     │ ((TERMINAL))
      │              └──────────────┘
      └—evicted before TTL→ ┌──────────────────────┐
                            │ 5 EVICTED-EARLY        │ **an observable
                            └──────────────────────┘ (§62.2): a high rate
                              means the capacity limit is binding, which is
                              either a §43.3 tuning signal or #43**

 **KC IS EXCLUDED FROM THIS MACHINE ENTIRELY (P0-02 R42.1): it receives an
 O(R)-per-epoch digest instead. ⟹ the TCB is not a workspace consumer, so
 workspace volume cannot become a KC bottleneck.**
 **S3/S4 BYPASS THIS MACHINE (COMM-INV-40): a governance or safety signal is
 delivered regardless of workspace state.**
```

## 75.9 Failure-recovery state

```
 ┌──────────────┐
 │ 0 NOMINAL     │
 └────┬─────────┘
      │ —fault detected (§28.2's nine cases, class-dependent)→
 ┌────▼──────────────┐
 │ 1 CLASSIFIED       │ **the class determines the response, and R29.1
 └────┬──────────────┘ governs: for warrant classes, «infer missing
      │                information» is PROHIBITED — degrade, abstain, or
      │                report; NEVER impute**
      ├—transport fault, S0/S1→ ┌────────────────────┐
      │                         │ 2a DEGRADED-CONTINUE│ best-effort; loss is
      │                         └────────────────────┘ the designed outcome
      ├—transport fault, S2→ ┌────────────────────┐
      │                      │ 2b RETRY-BOUNDED     │ at-least-once + idempotent
      │                      └────────────────────┘ receiver + the second dedup
      ├—transport fault, S3/S4→ ┌──────────────────────┐
      │                         │ 2c RETRY-UNTIL-CONFIRMED│ **ACKs exist only
      │                         └──────────────────────┘ here (§7.4)**
      ├—warrant fault→ ┌────────────────────┐
      │                │ 2d ABSTAIN           │ **R29.1. The artifact is
      │                └────────────────────┘ PRESERVED (Cell §6.3 case 6),
      │                                       the source is quarantine-
      │                                       candidate, and NOTHING is
      │                                       imputed**
      ├—aggregate fault (cascade signature)→ ┌────────────────┐
      │                                      │ 2e THROTTLE     │ §35.2's
      │                                      └────────────────┘ budget
      └—structural fault (partition)→ §75.10

 RECOVERY MECHANISMS (§60.2 R60.1), each with its own domain:
   RECONSTRUCTED — topology registries · routing state · regional epoch state
                   (from anchored Merkle roots)
   CHECKPOINTED  — anchored digests · policy versions · delegation tables
                   (**P0-02 §47.1: the organism may trigger
                    RESTORE(signed_image_hash) but may NEVER supply the
                    payload — EIK-INV-41, repair without authorship**)
   REPLICATED    — provenance anchors (W_min witnesses) · KC (N_impl ≥ 3)
                   (**P0-02 §10.2: replication without diversity is a delay,
                    not a defence**)
   REGENERATED   — individual connections · session keys · channel bindings ·
                   ephemeral addresses (**cheap, local, no coordination**)
   EVOLVED AGAIN — topology PRIORS after catastrophic regional loss
                   (**§48.2: priors are heritable, specific edges are not.
                    A region that lost everything re-develops its wiring from
                    its genome — this is the DESIGNED behaviour, not a
                    recovery failure, and it is why R48.1 matters
                    operationally**)
```

## 75.10 Partition-reconciliation state

```
 ┌──────────────┐
 │ 0 CONNECTED   │
 └────┬─────────┘
      │ —cross-region traffic ceases / heartbeat absent→
 ┌────▼──────────────┐
 │ 1 PARTITIONED      │ **COMM-INV-42: WARRANT FREEZE.**
 └────┬──────────────┘   ¬may_increase_confidence · ¬may_admit_new_evidence ·
      │                  RO-01 stalls ⟹ ¬creates_new_subjects ·
      │                  **KC-3 ceilings SURVIVE (EIK-INV-31)** ·
      │                  `mandatory_path` remains admissible (COMM-INV-33) ·
      │                  **transport and influence planes CONTINUE** Only
      │                  warrant freezes — which is why #27 gains nothing
      │
      │ —both sides accumulate divergent state→
 ┌────▼──────────────┐
 │ 2 DIVERGED         │ **§31.3's seven object classes, each mapped to an
 └────┬──────────────┘ operator. Cost so far: O(divergence), NOT O(N)**
      │ —connectivity restored (§31.5's five phases)→
 ┌────▼──────────────────┐
 │ 3 DETECT & COMPARE     │ regional registry Merkle roots compared
 └────┬──────────────────┘ (P0-02 §10.1 P3 detects root disagreement)
      │
 ┌────▼──────────────────┐
 │ 4 CLASSIFY PER OBJECT   │ **the operator is chosen per OBJECT CLASS, never
 └────┬──────────────────┘ per SIDE. ⟹ there is no vote (COMM-INV-43)**
      │
      ├──┬───────────────┬───────────────┬────────────────┐
      ▼  ▼               ▼               ▼                ▼
 ┌────────┐ ┌──────────────┐ ┌────────┐ ┌────────┐ ┌──────────────────────┐
 │ UNION   │ │ RE-EVALUATE   │ │  FORK   │ │  VOID   │ │ **NOT RECONCILED**    │
 │ disjoint│ │ conflicting   │ │ both    │ │ an act  │ │ policy · epoch · trust│
 │ additive│ │ claims ⟹ EVA  │ │ created │ │ required│ │ **PRE-PARTITION WINS** │
 │ state   │ │ re-derives    │ │ new     │ │ KC-2    │ │ (§31.4)               │
 │         │ │ from anchored │ │ state ⟹ │ │ during  │ │ **⟹ authority is     │
 │         │ │ roots         │ │ BOTH    │ │ the     │ │ TEMPORAL, not         │
 │         │ │               │ │ branches│ │ partition│ │ MAJORITARIAN. This is │
 │         │ │               │ │ ANCHORED│ │ ⟹ never │ │ CD-C11's break**      │
 │         │ │               │ │ as a    │ │ ratified│ │                       │
 │         │ │               │ │ lineage │ │ retro-  │ │                       │
 │         │ │               │ │ event   │ │ actively│ │                       │
 └────┬───┘ └──────┬───────┘ └───┬────┘ └───┬────┘ └──────────┬───────────┘
      └────────────┴─────────────┴──────────┴─────────────────┘
                             │
                    ┌────────▼────────┐
                    │ 5 RE-ANCHOR      │ new epoch Merkle root; digest to OP
                    └────────┬────────┘
                             │ —warrant unfrozen→
                    ┌────────▼────────┐
                    │ 6 RECONNECTED    │
                    └─────────────────┘

 **THE RESIDUE, DECLARED: FORK admits divergence rather than resolving it.**
 A fork is recorded and both branches are anchored, so it is AUDITABLE — but
 the audit is retrospective. **§31.3 requires the fork event to enter the
 lineage permanently (§61.1: «descent is the object of study»).**
```

---

# §76. THE INDEPENDENCE MODEL

## 76.1 Why nine dimensions and not six

**Volume A established a SIX-dimension correlation vector for EVIDENCE independence.** That vector is complete for its purpose: it answers «do these two messages rest on distinct observations?».

**It is not complete for the communication layer, because three further kinds of independence determine whether an aggregate is trustworthy — and each has a distinct failure mode that the six do not cover.**

> ### **R76.0.** *Dimensions 1–6 are EVIDENCE independence (they collapse `n_effective`). Dimensions 7–9 are SYSTEM independence (they bound blast radius, authority, and interpretation). **The two groups are computed differently, consumed differently, and violated differently — and conflating them is the error X-A made with «trusted».***

## 76.2 The nine dimensions

| # | Dimension | **Question** | **Computable?** | **Consumer** | **Failure if violated** |
|---|---|---|---|---|---|
| **1** | **Root** | Do these claims rest on distinct observations? | ✅ **EXACT** — `root_commit` comparison against the anchored registry | `n_effective` | **The §14 attack: A→B, A→C, B→D, C→D counted as four** |
| **2** | **Lineage** | Do these claims come from distinct descent lines? | ✅ **EXACT** — lineage certificates | `n_effective` | Clonal agreement; #5's near-clone |
| **3** | **Model** | Do these claims come from distinct computational models? | ⚠️ **APPROXIMATE** — declared model identity | `n_effective` | Two instances of the same model agreeing is one opinion |
| **4** | **Upstream** | Do these claims share input dependencies? | ✅ **EXACT** — `causal_depth` + channel history | `n_effective` | Common-input correlation; #5's clone detection |
| **5** | **Hardware** | Do these claims come from distinct physical substrates? | ⚠️ **APPROXIMATE** — platform profile (§56.1's eight classes) | `n_effective` | **A hardware fault presents as consensus. P0-02 §10.2: `N_impl ≥ 3` exists because of this** |
| **6** | **Assumption** | Do these claims share a latent premise? | ❌ **NOT DETECTABLE FROM INSIDE** | **Declared as a limit** | **#42. The unclosable one. Third appearance: P0-01 CD-8 → P0-02 IND-6 → here** |
| **7** | **Authority** ⟵ **NEW** | Do these claims rest on distinct authorization principals? | ✅ **EXACT** — delegation-chain comparison | **Governance, not `n_effective`** | **Two confirmations from subjects under the SAME Registrar, the same OP delegation, or the same KC-2 authorization are ONE authorization, not two.** ⟹ *P0-02's dual-authorization requirement is meaningless without this dimension: dual authorization by two subjects sharing a delegation root is single authorization with extra steps* |
| **8** | **Failure** ⟵ **NEW** | Do these components share a fate? | ⚠️ **APPROXIMATE** — from topology (shared relay, shared region, shared power/clock domain) + platform profile | **Availability, not `n_effective`** | **§37's correlated failure. Two redundant paths through the same relay are not redundant.** ⟹ *This is why §52.2 item 4 requires a `mandatory_path` redundancy to be VERIFIED OFF-SUBSTRATE at candidate evaluation — verification at runtime cannot see shared fate* |
| **9** | **Semantic** ⟵ **NEW** | Do these subjects interpret the type the same way? | ❌ **NOT DETECTABLE AT RUNTIME** | **Conformance, not `n_effective`** | **#33's semantic drift: two subjects using the same registered type with divergent internal meanings produce structurally valid, semantically incompatible traffic.** ⟹ *Detected only by §57.2's T-REPR test (two platforms, same scenario, same warrant outcomes) and by §50.2's usage-distribution monitoring — both external, both retrospective* |

## 76.3 The three groups, and why they must not be merged

```
GROUP A — EVIDENCE INDEPENDENCE (dims 1–6)
  Consumed by: `n_effective` (§14.4), at the RECEIVER, per aggregate.
  Encoding: `corr_class`, a per-dimension digest in the envelope, O(1).
  Rule: R37.1 UNKNOWN ≠ DISJOINT; R37.2 a million unknowns contribute one.
  Violation consequence: **OVER-BELIEF.**

GROUP B — SYSTEM INDEPENDENCE (dims 7–8)
  Consumed by: GOVERNANCE (dim 7: is this authorization genuinely dual?)
               and AVAILABILITY (dim 8: is this redundancy genuine?).
  Encoding: NOT in the envelope. Dim 7 is resolved from the delegation chain
            at the authorization point; dim 8 is resolved from the topology
            registry at candidate evaluation.
  Rule: **neither may be inferred from traffic.** Both require the anchored
        delegation and topology records.
  Violation consequence: **FALSE AUTHORIZATION (7) and FALSE REDUNDANCY (8).**

GROUP C — SEMANTIC INDEPENDENCE (dim 9)
  Consumed by: CONFORMANCE (§57.2 T-REPR) and DRIFT MONITORING (§50.2).
  Encoding: not encodable. **A subject cannot report its own interpretation
            without that report being interpreted — which is the same
            self-reference as CD-C8.**
  Rule: detected only by observing OUTCOMES across implementations.
  Violation consequence: **STRUCTURALLY VALID, SEMANTICALLY INCOMPATIBLE
                          TRAFFIC.**

⟹ **R76.1: the three groups have different consumers, different encodings,
   different detection points, and different failure consequences. Merging
   them into one "independence score" would be X-A's error repeated: a single
   word covering properties that must be kept apart because they are
   computed by different principals at different times.**

⟹ **R76.2 (THE HONEST TALLY).** *Of nine dimensions: **3 exact** (1, 2, 4, 7
   — four, counting dim 7), **3 approximate** (3, 5, 8), **2 undetectable
   from inside** (6, 9). **No aggregate in this contract may claim
   independence on a dimension it cannot compute, and R37.1 makes the
   pessimistic default structural rather than disciplinary.***
```

## 76.4 What the model buys, and what it does not

| Claim | **Supported?** |
|---|---|
| «These two observations are distinct» | ✅ **Yes, exactly (dims 1, 2, 4)** |
| «These two implementations are diverse» | ⚠️ **Approximately (dims 3, 5)** — and P0-02 §10.2's warning applies: replication without diversity is a delay |
| «This authorization is genuinely dual» | ✅ **Yes, exactly (dim 7)** — from the delegation chain, not from traffic |
| «This redundancy survives a common cause» | ⚠️ **Approximately (dim 8)** — and only if verified off-substrate (§52.2 item 4) |
| «These subjects share no latent assumption» | ❌ **NO. Never. Dim 6 (COMM-INV-18)** |
| «These subjects interpret this type identically» | ❌ **NO, not at runtime. Dim 9** — only via T-REPR across implementations |
| «Consensus therefore indicates correctness» | ❌ **NO — and this is the point.** §73 item 7: agreement is not evidence, and the model exists to make that sentence operational rather than aspirational |

**R76.3 (THE MODEL'S PURPOSE, STATED PLAINLY).** *The independence model does not detect independence. **It bounds the credit that agreement can earn.** Nine dimensions, four of them exact, three approximate, two declared uncomputable — and the aggregate effect is that a population cannot manufacture authority by agreeing with itself on any dimension the architecture can see, and on the two it cannot see, the architecture says so and points at the external anchor.*

---

*End of Volume F. Volume G (`23_analysis_interfaces_testability.md`) covers §77–§91: the seven subsystem interfaces, scalability, hardware/software separation, observability vs. performance, ablation, false-precision audit, implementation independence, testability and conformance, gaps, and open research.*
