# P0-03 — COMMUNICATION, DIGITAL SYNAPSE & SIGNAL CONTRACT
## Volume A: The Communication Primitive (§0–§17)

**Package:** `/home/user/audit/comm/` · **Companions:** `18_analysis_synapse_network.md` (B) · `19_analysis_partition_planes.md` (C) · `20_analysis_evolution_hardware.md` (D) · `21_analysis_adversarial_contradiction.md` (E) · `22_analysis_formal_invariants.md` (F) · `23_analysis_interfaces_testability.md` (G) · `24_v4_communication_synapse_signal_spec.md` (**Output 42**, canonical) · `README.md` (Outputs 1–2, §93–§96)
**Outputs delivered here:** **3** (canonical communication model) · **4** (minimal signal/message) · **5** (message taxonomy) · **6** (lifecycle state machine) · **7** (delivery semantics) · **8** (ordering/time/causality) · **16** (provenance) · **17** (evidence independence) · **18** (trust/authenticity)
**Status:** Architecture only. **No implementation, no code, no protocol library, no benchmark.**

---

# §0. ARCHITECTURAL CONTEXT — AND THREE ADVERSARIAL FINDINGS

## 0.1 What the record actually says

The brief instructs: *attack the communication architecture before improving it, and do not accept the existing digital-synapse model unless it survives.* The record is four documents deep.

**V3 §8 defines the synapse as an 11-property edge:**

> «DIGITAL SYNAPSE — SOURCE → TARGET ├── connection type ├── weight ├── reliability ├── latency ├── bandwidth cost ├── trust score ├── context sensitivity ├── plasticity rate ├── usage frequency ├── last-success timestamp └── pruning probability»

**V3 §4 defines communication as nine signal names:** «excitation, inhibition, reward, error, attention, novelty, state, request, warning.» **V3 §2 supplies the one genuinely good communication design decision in the source:** «Slow signaling → fast local + slower global signals.» **V3 §7 supplies a compression role** («OLIGODENDROCYTE-LIKE → frequent-path caching, communication compression, fast routing») **and V3 §9 supplies a routing role that this package must reject** («Thalamus-like → routing, attention, **synchronization**»).

**V3 summarizes the whole thing in one line, and that line contains the central defect of this package:**

> «**Digital synapses → weighted, contextual, trusted communication**» — V3 §23

**V3.1 adds five scales of structural plasticity** («Synapse plasticity — weight · reliability · **trust** · context sensitivity · Cell plasticity · Connection plasticity — create · reroute · strengthen · prune · Circuit plasticity — recruit cells · release cells · create pathways · reorganize subnetworks · Regional plasticity — change population composition · change functional roles · allocate resources · form new subcircuits»), **makes communication policy an evolutionary operator** («Variation can include: … **communication-policy variation** · **connection-topology variation**»), and **specifies the workspace** («LOCAL CELL STATE ↓ SALIENT INFORMATION ↓ ATTENTION / RELEVANCE GATE ↓ GLOBAL WORKSPACE ↓ {Memory · Critics · Planners · **Regulators**} ↓ COLLECTIVE INTERPRETATION ↓ ACTION / LEARNING», with «Each globally broadcast item should carry source, timestamp, confidence, provenance, relevance, and uncertainty»).

**The Cell Contract (P0) supplied a full envelope** — `OutputEnvelope` with 20+ mandatory fields including `causality: compressed vector clock`, `provenance: {self_ref, evidence_roots: [bytes<32>], derivation_depth}`, `signature: bytes<64> Ed25519 over canonical serialization of ALL above`, `seq: u32 per (src,dst,conv)`, `payload ≤ MSG_BYTES_MAX (4 KiB)` — a **CLOSED 34-value `MessageType` enum**, a **CLOSED 11-value `ConnType` enum**, a `ConnectionRecord` with 11 V3 properties + 9 additions, a **three-party handshake** (PROPOSE → CONSENT → AUTHORIZE & REGISTER, «Kernel-enforced. Neither cell can bypass»), `mandatory_path`, `eligibility_trace`, and the rule «**Exactly-once semantics for `EVALUATIVE` class; at-least-once for others**».

**P0-01 established** the evidence ladder E0–E4, the GT ladder L0–L6, `L3 REDUNDANT INDEPENDENT` with **R8.5 «`L3` MUST declare its independence argument. "Three sensors" is not independence»**, the confidence classes `INSUFFICIENT/PROVISIONAL/ESTABLISHED/DISPUTED` with **R28.2 «a disputed fitness is not averaged»**, **R22.3/R23.2's correlational-vs-causal split**, and twelve circular dependencies CD-1…CD-12.

**P0-02 established** the alethic/deontic axis separation, the 4-capability Kernel Core, the **15 reserved operations** — including **RO-05 CREATE_CONNECTION and RO-06 MODIFY_CONNECTION, where the cell is `E` (executes) within envelope and KC is `A` (authorizes) only *above* envelope** — the two typed channels, **R19.2's layered signing** («PER-MESSAGE: **NOT SIGNED.** Instead: authenticated channel binding… **The Cell Contract's per-message signature requirement is the specific item that does not survive scale**»), and the workspace rule (**R42.1: KC must not participate in workspace broadcast**; **§42.3: KC receives a bounded workspace DIGEST, `O(R)` per epoch**).

## 0.2 Finding 1 — the Cell Contract's envelope contains a field that cannot exist

> ### **`causality : compressed vector clock` is not a scalability concern. It is a type error.**

```
A vector clock over a population of N participants requires Θ(N) entries to
represent exactly. Every "compressed vector clock" scheme in the literature
trades exactness for size — and the trade is precisely what makes it
unsuitable here, because the Cell Contract uses this field for EVIDENCE
reasoning, where the exactness is the point.

THE ARITHMETIC, WITHOUT INVENTED NUMBERS:
  The envelope declares `payload ≤ MSG_BYTES_MAX`, and the Cell Contract
  states MSG_BYTES_MAX = 4 KiB.
  A vector-clock entry needs (participant_id, counter). At 10⁶ participants
  the ID alone exceeds 4 KiB for any ID width ≥ 5 bytes. At the brief's
  stated range of 10⁹–10¹² it exceeds it by three to six orders of magnitude.

⟹ **THE FIELD'S DECLARED TYPE HAS NO BOUNDED REPRESENTATION INSIDE THE
   MESSAGE THAT DECLARES IT.** Two independent teams implementing this
   envelope would produce mutually unreadable messages — which is exactly
   the failure §89's implementation-independence test exists to detect, and
   exactly what P0-03 §1 warns about ("two implementations may create
   incompatible cells").

AND THE SAME DEFECT APPEARS IN A SECOND FIELD:
  `provenance : {self_ref, evidence_roots: [bytes<32>], derivation_depth}`
  **`evidence_roots` is an unbounded array inside a 4 KiB envelope.** With
  fan-in f and derivation depth d, the root set grows without a dedup rule;
  the Cell Contract specifies dedup by root EQUALITY (FM-4, §11.3) but no
  bound on the set's CARDINALITY.

⟹ **TWO MANDATORY FIELDS OF THE CANONICAL MESSAGE ENVELOPE ARE UNBOUNDED.**
   This is the single most concrete defect in the prior communication design,
   and it is fixable (§4.3, §15.3) without losing any property the fields
   were introduced to provide.
```

**R0.1 (THE BOUND RULE).** *Every field of a communication primitive must have a representation whose size is bounded by a constant or by a declared function of the message's own class — never by the population size `N`, the derivation depth, or the fan-in.* **A field whose size is `O(N)` in an `O(1)`-sized message is not a field; it is an unimplemented intention.**

## 0.3 Finding 2 — «exactly-once» is claimed for the one class that cannot have it

> The Cell Contract specifies: «**Duplicated** (same `msg_id`) → **Drop silently, count it.** **Exactly-once semantics for `EVALUATIVE` class**; at-least-once for others.»

**Exactly-once *delivery* is not achievable in an asynchronous network with failures.** This is not an implementation difficulty; it is the two-generals result — a sender cannot know that its message was received without a confirmation that itself may be lost, so any protocol achieving certainty of receipt requires unbounded retry, and any protocol bounding retry admits duplicates or losses. **A contract that promises exactly-once delivery promises something no implementation can deliver, and will therefore be implemented as something else — differently, by each team.**

**But the mechanism the Cell Contract actually specifies is correct, and only its name is wrong.** It has: `msg_id` (UUIDv7) · a bounded dedup cache (bloom filter) · per-`(src,dst,conv)` `seq` · and `E_IN_DUP` handling. **That combination delivers at-least-once *transmission* with idempotent *processing*, which yields exactly-once *effect*.**

**R0.2 (THE DELIVERY VOCABULARY CORRECTION).** *Exactly-once is a property of **EFFECT**, never of **DELIVERY**.* The contract must state, per class: the delivery guarantee (**at-most-once / at-least-once / best-effort**) and separately whether the receiver's application of the message is **idempotent**. **«Exactly-once» alone is prohibited as a specification term** — it is P0-02 §34's false-precision defect applied to delivery. **This is a specification defect (P0-02's S9 class), not a design defect: the mechanism survives, the claim does not.**

## 0.4 Finding 3 — the root cause: four things called one name

> ### **V3's own summary line — «weighted, contextual, trusted communication» — names four distinct kinds of property and presents them as one.**

```
"WEIGHTED"      → how much this input changes the receiver's state
"CONTEXTUAL"    → how that amount varies with context
"TRUSTED"       → what the receiver may CONCLUDE from the content
"COMMUNICATION" → whether bytes arrived, in order, intact

THESE ARE NOT FOUR PROPERTIES OF ONE OBJECT. THEY ARE THREE DIFFERENT
KINDS OF QUESTION, AND THE CELL CONTRACT'S `ConnectionRecord` ASKS ALL
THREE IN ONE STRUCTURE:

  weight, context_sensitivity, plasticity_rate, usage_frequency   ⟶ INFLUENCE
  trust_score, (evidence_roots, confidence, calibration_class)    ⟶ WARRANT
  reliability, latency_measured, bandwidth_cost, in_flight,
  failure_count, consecutive_failures, state, ttl, seq            ⟶ TRANSPORT
```

**This is P0-03's central result, and it is structurally the same kind of finding as P0-02's.** P0-02 found that the inherited EIK conflated two axes (alethic and deontic) because both were "off-substrate," and that 7 of 9 cross-system contradictions dissolved once the axes were separated. **P0-03 finds that the inherited communication layer conflates three planes because all three are properties of "a connection," and that the same dissolution occurs.**

## 0.5 The three planes — stated precisely

```
╔════════════════════════════════════════════════════════════════════════╗
║ TRANSPORT PLANE — "did it arrive?"                                      ║
║                                                                        ║
║   Concerns: framing · integrity · ordering · duplication · loss ·       ║
║             latency · cost · addressing · routing · channel identity    ║
║   Vocabulary: delivered / lost / duplicated / reordered / late /        ║
║               corrupt / authenticated-channel                           ║
║   Producer: the transport mechanism                                     ║
║   Failure mode: LOSS — **DETECTABLE.** A lost message produces a gap in  ║
║     `seq`, a timeout, or a checksum failure. The plane can audit itself ║
║   Mutable by: hardware, topology, routing policy. **Hardware-defined.** ║
╚════════════════════════════════════════════════════════════════════════╝
╔════════════════════════════════════════════════════════════════════════╗
║ WARRANT PLANE — "what may the receiver conclude?"                       ║
║                                                                        ║
║   Concerns: semantic type · evidence roots · derivation depth ·         ║
║             calibration class · correlation dimensions · whether this   ║
║             message may serve as evidence, as a request, or as a claim  ║
║   Vocabulary: warrants / does not warrant / is evidence for / is a      ║
║               claim by / is derived from / is correlated with           ║
║   Producer: **NEITHER sender NOR transport.** Warrant is COMPUTED BY    ║
║     THE RECEIVER from warrant metadata plus receiver-side knowledge,    ║
║     and AUTHORITATIVELY by EVA for consequential aggregation            ║
║   Failure mode: **OVER-BELIEF — UNDETECTABLE FROM INSIDE.** A receiver   ║
║     that treats four copies of one observation as four independent      ║
║     observations produces NO error signal. It is, from its own          ║
║     perspective, well-calibrated on abundant evidence. **This is        ║
║     structurally identical to P0-02's deontic failure mode**            ║
║   Mutable by: POLICY ONLY (RO-13). **Never by learning, never by        ║
║     evolution, never by the sender, never by transport.**               ║
╚════════════════════════════════════════════════════════════════════════╝
╔════════════════════════════════════════════════════════════════════════╗
║ INFLUENCE PLANE — "how much does it change things?"                     ║
║                                                                        ║
║   Concerns: gain · eligibility · plasticity rate · routing preference · ║
║             attention modulation · fan-out · aggregate effect on the    ║
║             receiver's state and on network dynamics                    ║
║   Vocabulary: strengthens / weakens / modulates / amplifies / saturates ║
║   Producer: the receiver's learning subsystem, within bounds            ║
║   Failure mode: **RUNAWAY — DETECTABLE BUT ONLY IN AGGREGATE.**         ║
║     Saturation, oscillation, and cascade are visible in population      ║
║     statistics, not in any single message                               ║
║   Mutable by: learning and evolution, **within ceilings enforced below  ║
║     reach (P0-02 KC-3)**. Hardware-adaptive, task-adaptive              ║
╚════════════════════════════════════════════════════════════════════════╝
```

**R0.3 (PLANE SEPARATION — the foundational rule of this contract).** *Transport, warrant, and influence are three distinct planes. No mechanism may derive a warrant conclusion from a transport fact, an influence quantity from a warrant fact, or a transport guarantee from an influence quantity.*

**Why R0.3 is not a relabelling — the four violations it forbids, each of which exists in the record:**

| Violation | Where it exists | What R0.3 forbids | Consequence if permitted |
|---|---|---|---|
| **Transport ⟶ warrant** | V3 §8's `trust score` is a *connection* property, and the Cell Contract's S1 checks «trust ≥ threshold for the signal class» using it | **«It arrived reliably, therefore it is credible» is invalid.** Reliability is about the channel; warrant is about the claim | A noisy-but-honest source is discounted and a reliable-but-wrong source is believed. **Reliability is attacker-controllable by simply not dropping packets** |
| **Warrant ⟶ influence** | V3.1 §6 lists **`trust`** under «Synapse plasticity» — i.e., learnable | **«This is well-warranted, therefore strengthen the edge» makes warrant a learnable quantity.** The Cell Contract correctly forbids it (`trust_score`: «K-computed; cell reads»; `trust_out_assigned`: «**read-only**») — **V3.1 and the Cell Contract directly contradict each other, and the Cell Contract is right** | A cell can raise its own influence by convincing itself its inputs are trustworthy. **Self-confirming recall (Cell Contract FM-4) becomes self-confirming trust** |
| **Influence ⟶ warrant** | «weighted, contextual, **trusted**» in one phrase; V3 §8's `weight` and `trust score` as sibling properties of one edge | **«This edge is strong, therefore its evidence counts more» is invalid.** Gain is about state change; warrant is about licensing | **Amplification becomes belief.** §35's cascade attack and §36's false-consensus attack both require exactly this step, and both are closed if the step is forbidden |
| **Influence ⟶ transport** | `plasticity_rate` and `latency`/`bandwidth_cost` as co-equal edge properties | **«Learning may retune the transport guarantee» is invalid** | A learned routing preference that bypasses a `mandatory_path` (Cell Contract §14.1) is a governance bypass created by ordinary plasticity — **§19's central question, answered structurally** |

**R0.4 (THE COROLLARY THAT DOES THE MOST WORK).** *Because warrant is neither produced by the sender nor by the transport, and because it is computed by the receiver, **the receiver must be able to recompute it independently**.* This is §13's question — «Can the receiver independently recompute epistemic reliability?» — and R0.3 makes the answer **mandatory rather than optional**: if warrant were sender-declared, recomputation would be redundant; because warrant is receiver-computed, **a message that does not carry enough metadata for recomputation cannot carry warrant at all.** ⟹ **§4's minimal primitive is derived from this requirement, and §13's rejection of scalar confidence follows from it.**

## 0.6 What this package must not do

| Instruction | Compliance mechanism |
|---|---|
| **Do not assume biological communication is computationally optimal** | §2 scores all eight alternatives on fourteen criteria and rejects the biological default where it loses. **V3 §9's «thalamus-like synchronization» is rejected (§9.4)** |
| **Do not make every communication event globally visible** | §15.3's three-tier provenance; §62/§86's observability budget; **`O(1)` in-message commitment + `O(R)` per-epoch anchor** |
| **Do not make EIK inspect every synaptic operation** | §20/§78: connection formation within envelope is **unreserved** (P0-02 RO-05's `E`), and §0.4's plane separation shows why: **transport-plane acts are not governance acts** |
| **Do not require perfect global synchronization** | §9: physical time is advisory; `seq` + `epoch` are authoritative; **no mechanism requires synchronized clocks** |
| **Do not equate messages with truth / trust with correctness / consensus with independent evidence** | §5's eight delivery meanings · §17's six-way separation · §14/§36's copy-vs-common-cause distinction · **COMM-INV-01/02/03** |
| **Do not solve scalability by hand-waving** | §64/§84: complexity per level per operation, with every `O(N)`-or-worse item either eliminated or explicitly justified |
| **Do not invent numerical values** | §70: every parameter carries a class, an owner, a derivation procedure, and a wrong-value consequence. **Zero numerical values are asserted** |

---

# §1. WHY P0-03 EXISTS — THE CENTRAL QUESTION

## 1.1 The question, restated precisely

> **«What exactly is the smallest communication primitive from which a Digital Brain can construct reliable, adaptive, scalable, auditable collective computation?»**

**Restated in terms of §0.5, because the original phrasing hides the difficulty:** the question asks for one object, but the four adjectives belong to different planes.

| Adjective | Plane | Who can supply it |
|---|---|---|
| **reliable** | Transport | The mechanism (retransmission, ordering, integrity) |
| **adaptive** | Influence | Learning and evolution, within ceilings |
| **scalable** | Transport + Influence | Local addressing, hierarchical aggregation, budget bounds |
| **auditable** | **Warrant** | **Provenance commitments + anchored logs + external evaluation** |

**⟹ No single object supplies all four, and any object that tries becomes the Cell Contract's `OutputEnvelope` — 20+ mandatory fields, two of them unbounded (§0.2), one of them cryptographically infeasible at scale (P0-02 R19.2).**

**R1.1 (THE REFORMULATION).** *The smallest communication primitive is not one object but **one object plus a class partition**: a minimal transport envelope whose warrant content is determined by its class, where the cheapest class carries no warrant at all.* **§72's five classes (S0–S4) are not an optimization layered onto a universal envelope; they are the answer to the minimality question, because the minimal envelope is the one appropriate to the cheapest class.**

## 1.2 Why underspecified communication is more dangerous than underspecified computation

The brief lists eleven consequences. They reduce to three, and the third is the one that matters:

```
1. INTEROPERABILITY FAILURE. Two teams build incompatible cells. **Concrete
   and already realized: §0.2's unbounded fields guarantee it.**

2. AMBIGUITY PROPAGATION. "Learning", "plasticity", "circuit formation",
   "specialization" all become ambiguous because they are defined over
   connections, and connections are ambiguous.

3. **THE SILENT ONE: EVIDENCE INDEPENDENCE BECOMES AMBIGUOUS, AND ITS
   FAILURE IS UNDETECTABLE.**
   
   Every other consequence produces a malfunction. This one produces a
   *confident* malfunction. If communication does not carry enough structure
   to distinguish four copies of one observation from four independent
   observations, then:
     • the organism's confidence rises without bound on finite evidence
     • P0-01's L3 REDUNDANT INDEPENDENT class is awarded for copies
     • the Cell Contract's `n_obs` counter increments on duplicates
     • EVA receives aggregates whose independence argument is false
     • **and no component in the system has any signal that this happened**
   
   ⟹ **This is §0.5's warrant-plane failure mode, and it is why this package
      is a safety package rather than a networking package.** P0-02 established
      that a deontic error is undetectable from inside. P0-03 establishes
      that a WARRANT error is undetectable from inside. **Two of the three
      planes have silent failure modes, and the communication layer is where
      the second one lives.**
```

**R1.2.** *The primary purpose of the communication contract is not to move data. It is to make the difference between **one observation and many copies of one observation** representable, cheaply, at every scale.* **Every design decision in this package is tested against R1.2 first and against throughput second.**

---

# §2. DO NOT ASSUME «DIGITAL SYNAPSE» — **OUTPUT 2**

## 2.1 The fourteen criteria

The brief supplies them; three need operational definitions before they can score anything, because otherwise they collapse into each other.

| Criterion | Operational definition used here |
|---|---|
| **Expressivity** | How many distinct communication relations can be represented *without overloading one field*? (V3's `weight` represents at least five — §18) |
| **Auditability** | Can an external party reconstruct *who claimed what, on what evidence, when* — **without reading payloads**? (§59's auditability-without-readability) |
| **Plasticity** | Can the relation adapt at runtime **without adapting its guarantee class**? (R0.3's influence⟶transport prohibition) |
| **Emergence** | Can novel communication relations arise **that were not enumerated**? (§49) |
| The other ten | As the brief states them |

## 2.2 The eight alternatives scored

**Legend:** ✅ good · ⚠️ qualified · ❌ poor · **—** not applicable. **The `W` column is the decisive one: does the alternative make the copy-vs-independent distinction representable (R1.2)?**

| | **A. Direct weighted edges** | **B. Message-passing graph** | **C. Event-based** | **D. Shared-state / blackboard** | **E. Pub/sub topics** | **F. Local broadcast** | **G. Addressed** | **H. Hybrid** |
|---|---|---|---|---|---|---|---|---|
| **Expressivity** | ❌ One scalar per edge; five meanings collapsed (§18) | ✅ Typed payloads | ✅ Typed events | ⚠️ State is untyped by default | ✅ Topic + type | ❌ No addressee, no type discipline | ✅ | ✅ |
| **Locality** | ✅✅ Perfect | ⚠️ Requires a route | ⚠️ Requires a bus | ❌ **Global by construction** | ⚠️ Topic scope | ✅✅ Perfect | ❌ Requires global address | ✅ |
| **Latency** | ✅✅ Minimum | ⚠️ Framing cost | ⚠️ Dispatch cost | ✅ Read is local | ⚠️ Broker hop | ✅✅ Minimum | ⚠️ Route resolution | ✅ |
| **Bandwidth** | ✅✅ No headers | ❌ Headers per message | ❌ | ✅✅ No duplication | ⚠️ Fan-out duplication | ⚠️ Duplication to all | ✅ Point-to-point | ✅ |
| **Auditability** | ❌ **No record exists.** An edge write leaves no artifact | ✅ Per-message record | ✅✅ Ordered event log | ❌ **Worst: reads leave no trace, so who-knew-what-when is unrecoverable** | ⚠️ Publication logged, reads not | ❌ | ✅ | ✅ |
| **Provenance** | ❌ Cannot carry any | ✅ Per message | ✅ | ❌ **State has no origin; last writer wins** | ⚠️ Per publication | ❌ | ✅ | ✅ |
| **`W` — copy vs independent** | ❌ **Cannot represent it.** An edge has no source history | ⚠️ Possible if messages carry roots | ⚠️ | ❌ **Actively destroys it: a value read by 1000 cells has no per-reader provenance** | ⚠️ | ❌ | ⚠️ | ✅ **The only one that can, and only because B/G carry roots** |
| **Security** | ⚠️ No per-message authenticity possible | ✅ Per-message or per-channel | ✅ | ❌ **No writer attribution ⇒ no accountability** | ✅ Per-topic ACL | ❌ Anyone in range | ✅ | ✅ |
| **Plasticity** | ✅✅ Edges are the natural plasticity substrate | ⚠️ Schema is fixed | ⚠️ | ❌ | ⚠️ | ⚠️ | ⚠️ | ✅ |
| **Scalability** | ✅ `O(degree)` | ✅ `O(messages)` | ⚠️ Bus contention | ❌ **`O(N)` coupling: every reader depends on every writer** | ⚠️ `O(subscribers × topics)` | ✅ `O(neighborhood)` | ❌ **`O(N)` addressing unless hierarchical** | ✅ |
| **Async operation** | ✅✅ | ✅✅ | ✅ | ⚠️ **Race conditions are the semantics** | ✅ | ✅ | ✅ | ✅ |
| **Hardware portability** | ✅✅ Maps to any substrate | ✅ | ⚠️ Needs an event bus | ⚠️ Needs shared memory | ⚠️ Needs a broker | ✅✅ | ⚠️ | ✅ |
| **Fault tolerance** | ⚠️ Edge loss is silent | ✅ Loss detectable by `seq` gap | ✅ | ❌ **Corruption is indistinguishable from a legitimate write** | ⚠️ Broker is a SPOF | ⚠️ | ⚠️ Route failure | ✅ |
| **Emergence** | ✅ New edges are free | ❌ **Closed schema blocks novel types** | ❌ | ✅ | ⚠️ New topics | ✅ | ❌ | ⚠️ |
| **Evolvability** | ✅✅ | ⚠️ | ⚠️ | ⚠️ | ⚠️ | ✅ | ⚠️ | ✅ |
| **Score** | **5✅ 5⚠️ 5❌** | **9✅ 5⚠️ 1❌** | **6✅ 5⚠️ 2❌** | **2✅ 5⚠️ 8❌** | **3✅ 9⚠️ 1❌** | **5✅ 4⚠️ 4❌** | **5✅ 3⚠️ 4❌** | — |

## 2.3 The four results that are not obvious from the table

**RESULT 1 — D (shared-state / blackboard) is not merely weak; it is disqualifying for a warrant-bearing substrate.**

> A blackboard has **no per-reader provenance and no writer attribution by construction.** A value in shared state was written by *someone* at *some time*, and neither is recoverable from the value. **This makes R1.2 unsatisfiable: 1000 cells reading the same value cannot distinguish "we each observed this" from "we each read what one of us wrote."** That is §36's false-consensus attack with no attacker required.
>
> **D is nevertheless ACCEPTED in exactly one narrow form (§43): the global workspace as an admission-controlled, provenance-carrying, pull-based store** — where the item retains `source`, `provenance`, and `ttl` (V3.1 §2 already requires this: «Each globally broadcast item should carry source, timestamp, confidence, provenance, relevance, and uncertainty»), and where **reading is logged**. *A blackboard whose items carry provenance and whose reads are observable is not a blackboard; it is a pub/sub store with admission control — i.e., E.* **D is rejected as a mechanism and survives only by becoming E.**

**RESULT 2 — A (weighted edges) wins on cost and loses on auditability, and the loss is not recoverable.**

> An edge write leaves **no artifact**. There is nothing to log, nothing to anchor, nothing to replay. **A is therefore inadmissible for any warrant-bearing traffic, and admissible for influence-only traffic** — which is precisely §72's S0 class. **A is not the substrate of the brain; it is the substrate of the brain's cheapest 99% of traffic.** V3's «fast local + slower global signals» (§2) is this insight, correctly had and never developed.

**RESULT 3 — B's weakness (closed schema blocks emergence) and G's weakness (`O(N)` addressing) are both solved by the same move: separate the type set from the addressing scheme.** B's schema is closed over **warrant classes**, not over content (§49's `OPAQUE` class). G's addressing becomes **hierarchical** (§23), so global addresses are `O(log R)` to resolve and regional addresses are the common case.

**RESULT 4 — no single alternative satisfies R1.2 and scalability together.** A/F are scalable and cannot represent provenance. B/G/C can represent provenance and are scalable only with hierarchical addressing and channel-level authentication. **D and E cannot represent per-reader provenance at all.** ⟹ **The answer must be a composition, and the composition rule must be stated — which is what the standing instruction demands.**

## 2.4 **OUTPUT 2 — the selected architecture, defined exactly**

> ### **H (HYBRID) — and the hybrid is a *partition of mechanisms by warrant class*, not a menu of interchangeable options.**

**The standing rule from Task 3 applies verbatim: «Do NOT simply say 'hybrid' unless you define exactly what the hybrid consists of.»** It consists of this:

| Class (§72) | Mechanism | Addressing | Authentication | Provenance | Why this and not another |
|---|---|---|---|---|---|
| **S0 BARE** (influence-only) | **A** — direct weighted edge write/activation, **plus F** local broadcast for neighborhood modulation | **Local only** — no address leaves the neighborhood | **None.** No identity required | **None.** S0 carries no warrant and cannot become evidence | A/F are the only mechanisms with `O(1)` cost and zero header. **S0's guarantee is that it cannot be believed**, which requires no machinery |
| **S1 TYPED** (request/response/status) | **B** — message-passing over an authenticated channel | **G** addressed, or **E** capability-query (`dst : CapabilityQuery`, already in the Cell Contract) | **Channel binding** under a delegation certificate (P0-02 R19.2) | Type + `src` only. **No roots** | B supplies typing; channel binding supplies authenticity at `O(1)` amortized. Roots are unnecessary because S1 makes no evidential claim |
| **S2 WARRANTED** (evidence/prediction/assertion) | **B** + **G** | **G** addressed; regional aggregation via **E** | Channel binding **+ root commitment signature at aggregation boundaries** | **`root_commit` + `causal_depth` + `calib_class_ref`** (§15.3) | **This is the class R1.2 exists for.** The commitment is `O(1)`; exact roots live in the anchor |
| **S3 AUTHORIZED** (evaluative/governance/safety/immune) | **C** — discrete, ordered, individually signed events | **G**, resolved authoritatively | **Per-message signature** (P0-02 R19.2 retains signatures for governance-class messages) | Full: roots, signer, epoch, `seq` | C's ordered event log is the only alternative whose auditability is ✅✅, and S3 is rare enough to pay for it |
| **S4 ANCHORED** (constitutional/fitness/deployment/rollback) | **C** + external witness | **G** | Per-message signature **+ anchor append + `W_min` witnesses** (P0-02 §20.2) | **Exact, permanent, append-only** | P0-02's provenance tiers; **the only class where infinite retention is affordable because the volume is `O(governance events)`** |
| **Workspace** | **E** — pull-based subscription with regional relays (**D rejected, §2.3 Result 1**) | Topic/region-scoped | Service signature per item (Cell Contract `ws.item.v1`, retained) | Per item: source, provenance, TTL (V3.1 §2's list, retained) | **V3.1 said «globally available to the cells that need it» — that is subscription, not broadcast.** The Cell Contract's «may not reject broadcast» is the defect (§68 X-E) |

**R2.1 (THE COMPOSITION RULE).** *A mechanism is admissible only at the warrant classes where its cost and its guarantees match. No mechanism is available at all classes, and no class may use a mechanism whose auditability is weaker than the class's warrant requires.*

**R2.2 (WHAT THE HYBRID IS NOT).** *It is not "cells may choose their preferred mechanism."* The class→mechanism mapping is **policy** (P0-02 L2), authenticated by KC-1, and **not learnable or evolvable** (§19, §48). **A cell may choose what to send; it may not choose how sending is warranted.** ⟵ This is the single sentence that prevents §48's «can evolution create a communication protocol that bypasses EIK?» from having a positive answer.

## 2.5 «Do not choose one merely because it resembles neuroscience»

**Three places where the biological default loses and is rejected:**

| Biological default | Rejected because | Replaced by |
|---|---|---|
| **V3 §9 «Thalamus-like → routing, attention, *synchronization*»** | **Synchronization is a global coordination requirement.** §9.4 shows no communication mechanism in this contract requires synchronized clocks, and P0-02 §26 established that no global synchronization exists. A thalamic synchronizer would be the architecture's only `O(N)` coordination point | **Epoch-scoped coarse ordering (governance-issued) + per-channel `seq`.** Routing and attention survive; synchronization is deleted |
| **Broadcast neuromodulation as a general mechanism** (V3 §4's «attention», «novelty», «reward», «state» as signal types implies wide-area signaling) | §65's broadcast audit: a global reward broadcast is `O(N)` per event, and **P0-01 R6.7 already makes reward EVA-only**, so it is not a cell signal at all | **Hierarchical broadcast: region-scoped modulation digests, `O(R)` per epoch, pulled not pushed (§45, §65)** |
| **Uniform local connectivity (cortical column ideal)** | §52: uniform connectivity has no hubs, and hubless topologies have `O(N)` diameter — **latency becomes infeasible at 10⁹**. Small-world structure is *computationally* required, not biologically imitated | **Bounded-degree small-world with hub influence budgets (§25, §52)** |

**R2.3.** *Biological plausibility is not evidence of computational adequacy.* Where V3's biology-derived choices survive (§2's two-tier latency, §14's locality, §52's small-world structure), they survive because they were independently scored, not because they are biological.

---

# §3. SIGNAL VS MESSAGE VS STATE VS CONNECTION VS SYNAPSE — **OUTPUT 3**

## 3.1 The five terms, separated

| Term | Definition | Plane | Lifetime | Owner | **Not to be confused with** |
|---|---|---|---|---|---|
| **SIGNAL** | **A transient computational event: the occurrence of a value at a port at a step.** It has no independent existence apart from its emission and reception | Influence (+ transport at emission) | One step to `ttl` hops | Emitter | A message. **A signal need not be a message: an S0 edge activation is a signal that is never serialized** |
| **MESSAGE** | **A structured communication object: a serialized, typed, bounded, transportable envelope.** It exists as an artifact and can be logged, replayed, and anchored | Transport | Creation → terminal lifecycle state (§6) | Sender creates; transport owns in flight; receiver owns on arrival | A signal. **A message is a signal that has been given a transport existence** |
| **STATE** | **Persistent information held by a component.** It is not transmitted; it is read and written | Any | Until overwritten, evicted, or retired | The holder | A message. **State that is transmitted becomes a message; a message that is retained becomes state. The conversion is where provenance is most often lost (§16)** |
| **CONNECTION** | **A relationship through which communication may occur: a registered, typed, directed, bounded edge with a lifecycle** | Transport (+ influence parameters attached) | Handshake → CLOSED, with the *fact* retained after closure (Cell Contract §14.4 step 7) | **Both endpoints jointly (consent) + the Topology Service (registration)** | A synapse. **A connection is the relationship; a synapse is the parameter set attached to it** |
| **SYNAPSE** | **See §3.2 — the answer is "a protocol object AND a mutable parameter AND a learned relationship, but NOT a routing relationship and NOT a physical analogy"** | **All three planes, and this is the problem** | — | Split (§3.2) | Everything |

## 3.2 «Is a synapse a physical analogy, a protocol object, a mutable parameter, a routing relationship, a learned relationship, or all of the above?»

> ### **It is three of the five, and the fact that V3 treats it as all five is the defect §0.4 identified.**

| Candidate | Verdict | Reasoning |
|---|---|---|
| **Physical analogy** | ❌ **REJECTED** | Task-3 Rule 5: «no vague biological metaphors as mechanism substitutes.» V3 §8's eleven properties are not analogical — they are a specification. **Calling it a synapse adds nothing and costs precision**, because the biological synapse is bidirectional in modulation, chemically graded, and structurally plastic on timescales this contract does not model |
| **Protocol object** | ✅ **YES — the connection half** | `conn_id`, `src`, `dst`, `direction`, `conn_type`, `state`, `authorization_ref`, `in_flight`, `mandatory_path` are protocol facts: they are registered, consented to, and lifecycle-managed |
| **Mutable parameter** | ✅ **YES — the influence half** | `weight`, `context_sensitivity`, `plasticity_rate`, `usage_frequency`, `eligibility_trace` are learnable quantities with bounds |
| **Routing relationship** | ❌ **REJECTED as a property of the synapse** | Routing is a **transport-plane** function over addresses and topology (§24). Making it a synaptic property is what allows «learning created a route that bypasses a mandatory path» (§19.3, R0.3's influence⟶transport violation). **A synapse may be a routing *input*; it may not own routing** |
| **Learned relationship** | ⚠️ **PARTIALLY — and the boundary is the whole of §19** | Influence parameters: learned. Protocol object: **not learned** (creation is a handshake, deletion has guards, `conn_type` is fixed at creation, `mandatory_path` is immutable). Warrant rules: **never learned** (policy, RO-13) |

**R3.1 (THE SYNAPSE DECOMPOSITION).** *A "synapse" is not one object. It is:*
```
   CONNECTION  = the protocol object        (transport plane, registered,
                                             consented, lifecycle-managed,
                                             NOT learnable except by
                                             handshake/pruning protocol)
 + SYNAPTIC PARAMETERS = the mutable set    (influence plane, learnable
                                             within bounds)
 + WARRANT CLASS of the conn_type           (warrant plane, POLICY,
                                             immutable by learning)
 + MEASURED CHANNEL STATISTICS              (transport plane, MEASURED not
                                             declared: reliability, latency,
                                             failure counts — Cell §14.5)
 + ASSIGNED TRUST                           (warrant plane, EXTERNALLY
                                             assigned, cell read-only)
```
**⟹ Five components, three planes, three different mutability rules, three different owners.** **V3 §8's flat 11-property list and V3.1 §6's «synapse plasticity: weight, reliability, trust, context sensitivity» both collapse this structure — and V3.1's inclusion of `reliability` and `trust` in the plastic set is a category error, because reliability is *measured* (Cell Contract §14.5: «A cell may not write its own `reliability`») and trust is *assigned* (§7.2 of the Cell Contract: `trust_out_assigned` is «EIK Trust Authority, off-cell, **read-only**»).**

**R3.2 (THE CORRECTION TO V3.1 §6).** *Synapse plasticity operates on **`weight`, `context_sensitivity`, `plasticity_rate`, and `eligibility_trace` only.** `reliability` is measured by the transport layer; `trust` is assigned by the warrant authority. **Neither is plastic, and a learning rule that modifies either is malformed and rejected at the type level.*** ⟵ This resolves the V3.1↔Cell-Contract contradiction in favour of the Cell Contract, and §68 records it as X-A2.

## 3.3 **OUTPUT 3 — the canonical communication model**

```
╔═══════════════════════════════════════════════════════════════════════╗
║                    THE CANONICAL COMMUNICATION MODEL                   ║
║                                                                        ║
║  A communication event is a TRIPLE (signal, message-class, warrant)    ║
║  evaluated over THREE PLANES, of which only two are failure-silent:    ║
║                                                                        ║
║      ┌─────────────┐                                                   ║
║      │   SIGNAL    │ a value occurs at a port                          ║
║      └──────┬──────┘                                                   ║
║             │ class determined by TYPE (policy-fixed, §72)             ║
║             ▼                                                          ║
║      ┌─────────────┐   TRANSPORT:  framing · integrity · order ·       ║
║      │  MESSAGE    │               duplication · loss · cost · route   ║
║      │  (S0…S4)    │   ⟶ failure = LOSS, **detectable**                ║
║      └──────┬──────┘                                                   ║
║             │ arrives; receiver computes WARRANT from                  ║
║             │ warrant-metadata + receiver-side knowledge (R0.4)        ║
║             ▼                                                          ║
║      ┌─────────────┐   WARRANT:    type · roots · depth · calib ·      ║
║      │  WARRANT    │               correlation dimensions              ║
║      │  VERDICT    │   ⟶ failure = OVER-BELIEF, **UNDETECTABLE**       ║
║      └──────┬──────┘                                                   ║
║             │ licensed conclusion (≠ sender's claim, INV-14)           ║
║             ▼                                                          ║
║      ┌─────────────┐   INFLUENCE:  gain · eligibility · attention ·    ║
║      │ STATE /     │               fan-out · budget                    ║
║      │ LEARNING    │   ⟶ failure = RUNAWAY, **detectable in aggregate**║
║      └─────────────┘                                                   ║
║                                                                        ║
║  THE THREE PROHIBITED SHORTCUTS (R0.3):                                ║
║    transport ⟶̸ warrant     ("it arrived reliably ⇒ it is credible")    ║
║    warrant   ⟶̸ influence   ("it is well-warranted ⇒ strengthen it")    ║
║    influence ⟶̸ warrant     ("this edge is strong ⇒ its evidence        ║
║                                counts more")                           ║
║    influence ⟶̸ transport   ("learning retuned the guarantee")          ║
║                                                                        ║
║  THE ONE PERMITTED FLOW:                                               ║
║    warrant ⟶ influence is permitted ONLY as a POLICY-defined prior,    ║
║    never as a runtime inference. (A policy may say "S3 messages get      ║
║    priority in aggregation". A receiver may not say "this seems          ║
║    trustworthy so I'll weight it more".)                                ║
╚═══════════════════════════════════════════════════════════════════════╝
```

**R3.3 (THE CANONICAL SEMANTIC CHAIN — §73's answer, stated here because everything depends on it).**

```
   message → transport → receiver → INTERPRETATION → belief/state update

   AND THE CHAIN HAS A MANDATORY FIFTH ELEMENT THAT THE BRIEF'S VERSION
   OMITS, AND ITS OMISSION IS THE DEFECT:

   message → transport → receiver → interpretation → **WARRANT CHECK** →
            belief/state update

   **The warrant check is not a step the receiver may skip, and it is not a
   step the sender may perform on the receiver's behalf.** Its output is one
   of four values:

     LICENSED-AS-EVIDENCE   may increment n_obs, may enter aggregation with
                            full weight for its class
     LICENSED-AS-CLAIM      may be represented, may NOT increment n_obs,
                            may NOT satisfy a verification requirement
     LICENSED-AS-INFLUENCE  may affect state/gain, may NOT be represented
                            as a belief at all (S0)
     NOT-LICENSED           rejected or sandboxed (§6.3's eight cases)

   ⟹ **The communication layer must NOT silently imply message = truth or
      message = instruction.** It doesn't, because the warrant check is a
      distinct, mandatory, typed step whose four outcomes are enumerated.
```

---

# §4. THE MINIMAL COMMUNICATION PRIMITIVE — **OUTPUT 4**

## 4.1 The derivation method

The brief lists seventeen candidate fields and instructs: *do not automatically include every field; classify each as mandatory / optional / derived / external / forbidden; explain why.* **The derivation rule is R1.2 plus R0.4:**

> **A field is MANDATORY if and only if removing it makes either (a) the copy-vs-independent distinction unrepresentable, or (b) the message's transport undecidable, or (c) the message's class indeterminate.**
> **A field is FORBIDDEN if its presence would let the sender assert something only an external authority may assert.**
> **A field is DERIVED if it is computable from other fields or from the channel.**
> **A field is EXTERNAL if it is supplied by a party other than the sender.**
> **Everything else is OPTIONAL — and §4.4 argues there should be almost none.**

## 4.2 The seventeen candidates, classified

| Field | Class | **Plane** | Why |
|---|---|---|---|
| **source identity** | **MANDATORY** | Transport + Warrant | Without it there is no attribution, no dedup, no correlation-dimension computation (§14), and no accountability. **It is the one field that cannot be derived** |
| **destination identity** | ⚠️ **CONDITIONALLY MANDATORY** | Transport | Mandatory for addressed classes (S2+). **Absent for S0** (an edge activation has an implicit destination: the edge) and **for local broadcast** (destination = neighborhood, implicit). *Requiring a destination on S0 would add cost to the cheapest 99% of traffic for no warrant gain* |
| **timestamp** | **EXTERNAL, ADVISORY — never authoritative** | Transport | **A self-declared timestamp is attacker-controlled (§58's timing manipulation).** Authoritative order comes from `seq` (per channel) and `epoch` (governance-issued). The timestamp is retained **only** for latency measurement between parties with a declared drift bound, and is `UNKNOWN` otherwise (§9.3). **COMM-INV-12** |
| **sequence number** | **MANDATORY** | Transport | Dedup, gap detection, per-channel order. **Without it, replay is undetectable (§32) and loss is undetectable.** Scope: per `(channel, epoch)` — *not* per `(src,dst,conv)` as the Cell Contract has it, because per-conversation scope requires the receiver to hold state per conversation, which is `O(peers × conversations)` (§8.3) |
| **message type** | **MANDATORY** | **Warrant** | **This is the field that determines the class (§72), and therefore determines every guarantee the message carries.** Without it, R3.3's warrant check has no input |
| **payload** | **MANDATORY** | — | Trivially. Bounded by the class's size limit |
| **provenance** | ⚠️ **MANDATORY FROM S2 UPWARD AS A BOUNDED COMMITMENT; ABSENT BELOW** | Warrant | §15.3: `root_commit: bytes<32>` + `causal_depth: u8`. **Not the Cell Contract's unbounded `evidence_roots: [bytes<32>]` array (§0.2).** S0/S1 carry no provenance because they make no evidential claim |
| **confidence / statistics** | ⚠️ **SUFFICIENT STATISTICS ONLY; SCALAR CONFIDENCE FORBIDDEN IN CELL-GENERATED MESSAGES** | Warrant | §13. **The Cell Contract already got this right** («`uncertainty: {aleatoric_var, epistemic_var, n_obs, s1, s2}` ← **SUFFICIENT STATISTICS, not a scalar**») and this contract preserves it. `confidence.value` with `produced_by: CELL_DERIVED` is **retained but demoted to a claim, never a warrant input** |
| **context** | **OPTIONAL, class-scoped** | Influence | Context modulates gain (`context_sensitivity`). It is not a warrant input and must not be one — **otherwise a sender could manufacture warrant by asserting favorable context** |
| **priority** | **DERIVED FROM TYPE, not sender-asserted** | Transport | **§38's false-urgency attack.** A sender-declared priority is an attention-hijacking channel. Priority is a function `type → prio` fixed by policy; the sender may not set it. *The Cell Contract's `prio : u8 [0..7]` as a mandatory sender-populated field is corrected here* |
| **urgency** | **FORBIDDEN as a distinct field** | — | Urgency is priority plus TTL, both derived. **A separate urgency field is a second false-urgency channel** |
| **TTL** | **MANDATORY (hop-count form)** | Transport | Bounds propagation (§35). **Hop-count, not wall-clock** — because wall-clock TTL depends on the advisory timestamp. `ttl: u16 hops` is retained from the Cell Contract |
| **causal metadata** | **MANDATORY, `O(1)`** | Warrant | **`causal_depth: u8` (saturating) replaces `compressed vector clock`.** §10.3 shows why the vector clock is unnecessary, not merely expensive |
| **resource cost** | **EXTERNAL (metered), never sender-declared** | Transport | **The Cell Contract already found this: «`cost_declared` vs `cost_measured` are both kept and their divergence is monitored»** — but the *declared* value is used for admission. **Correction: the declared value is a REQUEST parameter (for connection proposals, where it is a commitment); on a message, cost is metered by the transport and attributed by EVA (§7.4 X4's defence)** |
| **integrity / authentication** | **DERIVED FROM CLASS** | Transport | **S0: none. S1/S2: channel binding (P0-02 R19.2). S3/S4: per-message signature.** Not a sender-populated field — a property of the channel and the class |
| **policy information** | **EXTERNAL — referenced, never carried** | Warrant | **`policy_version_ref: bytes<32>`, not the policy.** Carrying policy in a message would make every message a potential rule-change channel (§19.3, NAUL-3). **This is P0-02 Channel 1's hash-pointer mechanism applied to messages** |
| **lineage information** | **DERIVED — from the source identity, not carried separately** | Warrant | `src` already contains `{cell_id, lineage_id, generation, variant, role, region_id}` in the Cell Contract. **A separate lineage field is a second, forgeable copy of information already authenticated.** One representation, one place |

## 4.3 **OUTPUT 4 — the minimal primitive, per class**

**The S0 envelope (the answer to "smallest possible"):**

```
S0 BARE SIGNAL — 5 fields, no serialization in the common case
  ┌─────────────────────────────────────────────────────────────┐
  │ edge_id / port_id    (implicit in the connection)            │
  │ value                (typed, bounded: ‖v‖ ≤ AGG_MAX)         │
  │ step                 (local monotone counter, u32)           │
  │ [ttl_hops]           (only if the signal may propagate)      │
  │ [context_mod]        (only if the edge is context-sensitive) │
  └─────────────────────────────────────────────────────────────┘
  WARRANT: NONE. An S0 signal CANNOT become evidence, CANNOT increment
           n_obs, CANNOT satisfy a verification requirement, CANNOT be
           cited as provenance. **This is a type-level property, not a
           policy check** (§72, COMM-INV-07).
  COST:    O(1), no header, no authentication, no logging.
  ⟵ **This is what "fast local signals" (V3 §2) actually costs, and it is
     affordable at 10¹² because it carries nothing.**
```

**The S2 envelope (the warrant-bearing workhorse — the answer to R1.2):**

```
S2 WARRANTED MESSAGE — 11 fields, all O(1)-bounded
  ┌───────────────────────────────────────────────────────────────┐
  │ msg_id       : bytes<16>   (UUIDv7 — dedup key)               │
  │ channel_id   : bytes<8>    (the authenticated channel; gives  │
  │                             src, epoch, drift bound by        │
  │                             inheritance — NOT repeated inline)│
  │ seq          : u32         (per (channel, epoch))             │
  │ type         : TypeRef     (closed warrant-class registry)    │
  │ payload      : typed, ≤ class size limit                      │
  │ payload_type : TypeRef + schema_version                       │
  │ root_commit  : bytes<32>   ← **Merkle commitment over the     │
  │                             evidence-root SET. O(1) regardless│
  │                             of set cardinality. Membership is │
  │                             provable in O(log |set|) against  │
  │                             the anchored set**                │
  │ causal_depth : u8          (saturating at 255)                │
  │ calib_ref    : bytes<8>    ← pointer to the producer's        │
  │                             EXTERNALLY-ASSIGNED calibration   │
  │                             class record. **Not a self-declared│
  │                             number**                          │
  │ corr_class   : bytes<8>    ← the correlation-dimension digest │
  │                             (§14.3): lineage · model · hw ·   │
  │                             protocol · task. **O(1)**         │
  │ ttl_hops     : u16                                            │
  └───────────────────────────────────────────────────────────────┘
  DERIVED (not carried): src identity, lineage, region, epoch, priority,
                         cost, authentication, timestamp
  WARRANT: LICENSED-AS-EVIDENCE **subject to the receiver's independent
           recomputation** (§13.4) using root_commit ∩ its own root set,
           corr_class ∩ its own correlation dimensions.
```

**R4.1 (THE SIZE CLAIM, QUALITATIVE — no invented numbers per §96).** *The S2 envelope is bounded by a constant independent of `N`, of derivation depth, of fan-in, and of evidence-root cardinality.* **This is what the Cell Contract's envelope is not (§0.2), and it is achieved by three substitutions: `root_commit` for `evidence_roots[]` · `causal_depth` for `compressed vector clock` · `channel_id` inheritance for inline `src`/`epoch`/`ts`/`signature`.**

**R4.2 (WHAT THE SUBSTITUTIONS COST — stated, not hidden).**

| Substitution | Gains | **Costs** |
|---|---|---|
| `root_commit` for `evidence_roots[]` | `O(1)` size; unbounded root cardinality | **The receiver cannot enumerate the roots from the message.** It can prove *membership* of a specific root (`O(log)`) and detect *disjointness* only probabilistically unless the root sets are anchored. **⟹ §14.4: independence checking requires the anchored root registry, not the message alone** |
| `causal_depth` for vector clock | `O(1)` size; no `O(N)` field | **Exact causal ancestry is not reconstructible from the message.** It is reconstructible from the anchored log (§10.3, §61) at `O(log)` per query. **⟹ causal reconstruction becomes an off-line, evaluator-side operation — which is where P0-01 §23.2 already puts it** |
| `channel_id` inheritance | No per-message signature for S0–S2 (P0-02 R19.2) | **Attribution granularity is the channel, not the message.** A compromised channel authenticates everything sent on it. **⟹ §58: channel compromise is bounded by channel scope (per-connection or per-region) and by epoch binding (P0-02 EIK-INV-14)** |

## 4.4 «Do not automatically include every field» — the four fields deliberately excluded

| Excluded | Why |
|---|---|
| **`priority` as a sender-set field** | §38's false-urgency attack. **Derived from `type` by policy** |
| **`trust` / `reliability` as message fields** | R3.2: trust is assigned externally, reliability is measured. **A message asserting its own trustworthiness is the warrant-plane form of self-verification, which the Cell Contract already forbids (§7.3)** |
| **`verification_claim` on ordinary messages** | The Cell Contract restricts `ATTEST_VERIFIED` to «C3 only, with kernel counter-signature» — correct, and preserved. **But it is not a field of the *minimal* primitive; it is an S3/S4 type** |
| **`credit` / `reward` / `contribution`** | **§46/§47: a message carrying its own credit value is a reward-hacking channel.** Credit is computed by the learning subsystem from local eligibility traces plus evaluator signals, and authoritatively by EVA when causal (P0-01 §23.2). **FORBIDDEN as a cell-generated field** |

**R4.3 (THE ANTI-ENVELOPE RULE).** *The communication primitive must not become a giant universal envelope (§71).* **The test applied to every field: does its absence make R1.2 unsatisfiable, transport undecidable, or class indeterminate? If no, it does not belong in the primitive — it belongs in a class-specific extension, an external record, or nowhere.**

---

# §5. COMMUNICATION SEMANTICS — THE EIGHT MEANINGS OF «DELIVERED»

## 5.1 The eight states, defined

> **«Do not equate delivered = understood, or received = believed.»** The eight are distinct, and **each has a different observer, a different failure mode, and a different plane.**

| # | State | Definition | **Plane** | Who can observe it | Failure mode | **Does it imply the next?** |
|---|---|---|---|---|---|---|
| **1** | **TRANSMITTED** | The sender's transport accepted the serialized message for sending | Transport | Sender only | Never left the buffer | ❌ |
| **2** | **RECEIVED** | Bytes arrived at the receiver's transport and passed the integrity check | Transport | Receiver | Loss, corruption | ❌ |
| **3** | **PARSED** | The bytes conform to the declared `payload_type` schema and the class's structural constraints | Transport | Receiver | Malformation (§6.3 case 2) | ❌ |
| **4** | **AUTHENTICATED** | The channel binding (S1/S2) or signature (S3/S4) verifies, and the signer is authorized **for this type** | Transport + Warrant | Receiver | Forgery, revocation, **type/authority mismatch** | ❌ |
| **5** | **ACCEPTED** | The message was admitted past the receiver's ingress policy: not stale, not duplicate, not over-budget, not sandboxed | Transport + Influence | Receiver | Rejection, sandboxing (§6.3 case 8) | ❌ |
| **6** | **PROCESSED** | The receiver computed over the payload (aggregated, transformed, stored) | Influence | Receiver | Resource exhaustion mid-computation | ❌ |
| **7** | **INTEGRATED** | The processing **changed the receiver's state** — `θ`, memory, workspace, or an outgoing signal | Influence | Receiver | **Processed-but-inert: a message may be processed and produce no state change** | ❌ |
| **8** | **WARRANTED** | The receiver's independent warrant check (§13.4) returned LICENSED-AS-EVIDENCE, and the message **contributed to a belief** | **Warrant** | **Receiver, and externally only via the anchored record** | **OVER-BELIEF (§0.5's silent failure)** | **terminal** |

## 5.2 The three equations the brief forbids, and why each is a real defect

**«delivered = understood»** — states 2/3 vs 6/7. **A message can be delivered and parsed and produce zero state change** (an already-known fact, a saturated aggregator, an out-of-context signal). **A transport that reports "delivered" as success has reported a fact about itself, not about communication.** ⟹ **COMM-INV-06's first half: a delivery confirmation is not evidence of anything beyond delivery.**

**«received = believed»** — state 2 vs state 8. **This is the equation that makes §36's false-consensus attack work.** If reception implies belief, then flooding implies consensus. ⟹ **State 8 requires an independent warrant computation (R0.4), and that computation may return NOT-LICENSED for a perfectly received message.**

**«acknowledged = correct»** — the implicit equation in the Cell Contract's `reliability = EWMA(delivered_and_acked / sent)`. **An ACK attests to states 2–5, never to 8.** A channel with 100% ACK rate and 0% warrant is a perfectly reliable channel carrying worthless claims. ⟹ **R0.3's transport⟶warrant prohibition, and §28's rule that latency and reliability must not be collapsed into trust.**

## 5.3 The asymmetry that makes the eight states usable

```
STATES 1–7 ARE OBSERVABLE BY THE PARTICIPANTS.
STATE 8 IS OBSERVABLE BY NOBODY AT THE TIME IT HAPPENS.

  The receiver does not know whether its warrant computation was correct —
  if it did, the computation would be unnecessary. **This is §0.5's silent
  failure mode restated: over-belief is invisible to the over-believer.**

⟹ THEREFORE: state 8's AUDIT must be external and retrospective.
   The anchored record (§15.3, §61) preserves root_commit + corr_class +
   calib_ref + the receiver's declared aggregation, so that EVA can
   RECOMPUTE what the warrant should have been and compare.

⟹ **COMM-INV-06 (full): a communication-layer success metric may never be
   used as an epistemic success metric. Delivery statistics are transport
   observables; warrant correctness is an evaluator observable, computed
   retrospectively from anchored records.**

⟹ AND THE PRACTICAL CONSEQUENCE FOR §62/§86: the observability budget
   must be spent on WARRANT metadata (roots, correlation class, calibration
   ref, aggregation declarations), NOT on payload content. **Auditing what
   was believed is more valuable than auditing what was said** — and it is
   also cheaper, because warrant metadata is O(1) while payloads are not.
```

---

# §6. MESSAGE LIFECYCLE — **OUTPUT 6**

## 6.1 «Do not assume this sequence is correct»

The brief's candidate is `CREATED → AUTHENTICATED → QUEUED → TRANSMITTED → RECEIVED → VALIDATED → ACCEPTED → PROCESSED → ARCHIVED/EXPIRED`. **Three defects:**

| Defect | Why it matters |
|---|---|
| **AUTHENTICATED before QUEUED, on the sender side** | The sender cannot authenticate its own message; authentication is a receiver-side (or channel-side) act. **Placing it third implies a sender-side authentication state that does not exist** |
| **No rejection, quarantine, sandbox, retry, replay, or duplication states** | The brief requires all six. The Cell Contract's §6.3 eight malformed-input cases each need a lifecycle home, and «Drop» is not a state |
| **ARCHIVED and EXPIRED merged** | **Archival is a warrant-plane act (the record persists as evidence); expiry is a transport-plane act (the message may no longer be acted upon).** A message may expire and still be archived — and for §32's replay defence, **the expired message's `msg_id` must remain in the dedup set long after expiry**, which means expiry does not terminate the record |

## 6.2 **OUTPUT 6 — the lifecycle state machine**

```
                      ┌──────────┐
                      │ CREATED  │  sender constructs; class fixed by TYPE
                      └────┬─────┘  (policy; sender may not choose class)
              ┌────────────┼─────────────┐
              ▼            ▼             ▼
        ┌──────────┐ ┌──────────┐  ┌──────────────┐
        │ ADMITTED │ │ SHED     │  │ REJECTED_LOCAL│
        │ (budget, │ │ (over    │  │ (malformed at │
        │  rate ok)│ │  budget) │  │  creation)    │
        └────┬─────┘ └──────────┘  └──────────────┘
             ▼        terminal:       terminal:
        ┌──────────┐  counted,        ErrorEvent
        │ QUEUED   │  observable      (E_OUT_*)
        └────┬─────┘
             ▼
        ┌──────────────┐
        │ TRANSMITTED  │──────┐
        └────┬─────────┘      │ loss detected (seq gap / timeout)
             │                ▼
             │          ┌───────────┐    class permits retry?
             │          │ IN_FLIGHT │───►┌──────────┐
             │          │ _UNKNOWN  │    │ RETRYING │──► back to QUEUED
             │          └─────┬─────┘    └────┬─────┘   (bounded by
             │                │               │          retry_budget)
             │                ▼               ▼
             │          ┌───────────┐   ┌──────────┐
             │          │ ABANDONED │   │ EXHAUSTED│  terminal: reported
             │          └───────────┘   └──────────┘  as E_COMM_LOSS
             ▼                                        (**NOT as success**)
        ┌──────────┐
        │ RECEIVED │  bytes intact at receiver transport
        └────┬─────┘
             ▼
        ┌───────────┐  schema + class-structural + size + ttl + epoch
        │ STRUCTURAL│──fail──►┌────────────┐
        │ _VALID    │         │ MALFORMED  │ terminal: E_IN_SCHEMA,
        └────┬──────┘         └────────────┘  never reaches S3+
             ▼
        ┌──────────────┐ channel binding (S1/S2) or signature (S3/S4)
        │ AUTHENTICATED│──fail──►┌───────────────┐
        └────┬─────────┘         │ UNAUTHENTICATED│ terminal: E_IN_AUTH,
             │                   └───────────────┘  immune report;
             ▼                                      **immediate escalation
        ┌──────────┐                                for S3/S4 classes**
        │ DEDUPED  │──duplicate──►┌────────────┐
        └────┬─────┘              │ DUPLICATE  │ terminal: counted,
             │                    └────────────┘ **msg_id RETAINED in the
             ▼                                     dedup set past expiry
        ┌──────────┐                               (§32's replay defence)**
        │ FRESH    │──stale──►┌──────────┐
        └────┬─────┘          │ EXPIRED  │ terminal for ACTION;
             │                └──────────┘ **archival continues**
             ▼
        ┌──────────────┐  receiver's admission policy: rate, sandbox,
        │ ACCEPTED     │  quarantine_flags (Cell §6.1), priority budget
        └────┬─────────┘
             ├──────────────►┌───────────────┐
             │               │ SANDBOXED     │ admitted to a NON-INFLUENTIAL
             │               │ (E_IN_ADVER-  │ path: cannot affect θ or
             │               │  SARIAL)      │ output until independently
             │               └───────┬───────┘ corroborated (Cell §6.3
             │                       │         case 8) — **evidence
             │                       ▼         PRESERVED, influence REMOVED**
             │               ┌───────────────┐
             │               │ QUARANTINED   │ immune-adjudicated (P0-02
             │               │               │ §8.2 AC-1..AC-5): budgeted,
             │               └───────┬───────┘ evidence-typed, bounded
             │                       │         duration, **detector ≠
             ▼                       ▼         adjudicator**
        ┌──────────┐          ┌──────────────┐
        │PROCESSED │          │ RELEASED /   │
        └────┬─────┘          │ CLEARED      │ (EVA retest + KC-2 RO-08)
             │                └──────────────┘
             ▼
        ┌────────────┐  state actually changed
        │ INTEGRATED │──────────────┐
        └────┬───────┘              │ no state change
             │                      ▼
             │                ┌───────────┐
             │                │ INERT     │ processed, no effect.
             │                └───────────┘ **Counted: an inert-message
             ▼                                 rate is a §51 specialization
        ┌──────────────┐                       signal, not a failure**
        │ WARRANTED /  │  §13.4's independent recomputation returned
        │ NOT-WARRANTED│  LICENSED-AS-EVIDENCE, or did not
        └────┬─────────┘
             ├───────────────────────┐
             ▼                       ▼
        ┌──────────┐          ┌──────────────┐
        │ ARCHIVED │          │ ANCHORED     │ S3/S4 only: append to the
        │ (local   │          │ (external    │ provenance log with W_min
        │  digest) │          │  witnesses)  │ witnesses (P0-02 §20.2)
        └──────────┘          └──────────────┘
             terminal for the MESSAGE OBJECT; **the RECORD persists**
```

## 6.3 The state inventory the brief requires

| Category | States | Notes |
|---|---|---|
| **Required** | CREATED · QUEUED · TRANSMITTED · RECEIVED · STRUCTURAL_VALID · AUTHENTICATED · DEDUPED · FRESH · ACCEPTED · PROCESSED · INTEGRATED · WARRANTED/NOT-WARRANTED · terminal | **Thirteen, and the sequence is not the brief's candidate** |
| **Optional (class-dependent)** | ADMITTED (only where a budget exists) · INERT · ARCHIVED · **ANCHORED (S3/S4 only)** | S0 skips CREATED→QUEUED entirely in the common case (an edge activation is not serialized) |
| **Failure** | SHED · REJECTED_LOCAL · IN_FLIGHT_UNKNOWN · ABANDONED · EXHAUSTED · MALFORMED · UNAUTHENTICATED · EXPIRED | **Eight, one per Cell Contract §6.3 case plus two transport cases** |
| **Retry** | RETRYING · EXHAUSTED | **Bounded by `retry_budget`; exhaustion is reported as `E_COMM_LOSS` and NEVER as success (COMM-INV-06)** |
| **Rejection** | REJECTED_LOCAL · MALFORMED · UNAUTHENTICATED | Rejection produces an `ErrorEvent`; **no case may be silently ignored** (Cell Contract §6.3's rule, preserved) |
| **Quarantine** | SANDBOXED · QUARANTINED · RELEASED/CLEARED | **Three, and they are distinct:** SANDBOXED is receiver-local and non-influential (Cell §6.3 case 8); QUARANTINED is immune-adjudicated under budget (P0-02 §8.2); RELEASED requires EVA retest **plus KC-2 RO-08** — **the sender may not release itself, and the detector may not either (AC-3)** |
| **Expiration** | EXPIRED | **Terminal for ACTION, not for RECORD.** The `msg_id` remains in the dedup set (§32) |
| **Replay** | **DUPLICATE** | **A replayed message reaches DUPLICATE and stops. It never reaches PROCESSED.** The defence is `msg_id` + `seq` + epoch binding (P0-02 EIK-INV-14) |
| **Duplication** | DUPLICATE (transport-level) · **CONFLATED (warrant-level)** | **⟵ THE SECOND IS NEW AND IS THE IMPORTANT ONE.** Two *distinct* messages (`msg_id` differs) carrying the *same evidence root* are not transport duplicates — dedup will not catch them. **They are warrant-level conflations, and only §14's root-set intersection catches them.** *A lifecycle that has no state for this is a lifecycle that cannot implement R1.2* |

**R6.1 (THE STATE THE BRIEF'S CANDIDATE MISSES).** *CONFLATED is a warrant-plane lifecycle outcome, not a transport one.* Two messages may both be AUTHENTICATED, DEDUPED, FRESH, ACCEPTED, PROCESSED, and INTEGRATED — and still be **jointly warrant-defective**, because they share a root. **The lifecycle must therefore have a post-INTEGRATION warrant step (§6.2's WARRANTED/NOT-WARRANTED) whose input is the receiver's *aggregate* root set, not the individual message's.** ⟵ This is the mechanism by which §14's A→B, A→C, B→D, C→D problem is actually solved, and it is invisible in any lifecycle that ends at PROCESSED.

---

# §7. DELIVERY SEMANTICS — **OUTPUT 7**

## 7.1 The six semantics, and which are achievable

| Semantic | Definition | **Achievable?** | Cost |
|---|---|---|---|
| **at-most-once** | Sent once; may be lost; never duplicated | ✅ Trivially | None. **Loss is the price** |
| **at-least-once** | Retried until acknowledged; may be duplicated | ✅ | Retry budget + receiver dedup state |
| **exactly-once (delivery)** | Delivered precisely once | ❌ **IMPOSSIBLE** in an asynchronous network with failures | — **§0.3: the two-generals result. Any contract promising this will be implemented as something else, differently by each team** |
| **exactly-once (effect)** | At-least-once delivery + idempotent receiver application + dedup | ✅ | `msg_id` dedup set + idempotent handlers |
| **best-effort** | No guarantee; no retry; loss not even detected | ✅ | None. **Loss is undetected, which is worse than at-most-once** |
| **deterministic delivery** | Delivery is a function of declared inputs | ⚠️ **Only for S3/S4 on non-partitioned paths** | Requires ordered, signed, anchored channels |
| **probabilistic delivery** | Delivery succeeds with measurable probability | ✅ **This is what S0/S1 actually have** | Requires measured `reliability` (Cell §14.5) to be meaningful |

**R7.1 (THE VOCABULARY RULE).** *A delivery semantic is specified as a PAIR: (delivery guarantee, idempotence requirement).* **«Exactly-once» alone is prohibited (§0.3 R0.2).** The four admissible pairs: `(at-most-once, —)` · `(at-least-once, idempotent)` · `(best-effort, —)` · `(ordered-at-least-once, idempotent + seq)`.

## 7.2 **OUTPUT 7 — the per-class assignment**

**«Do not force one delivery semantic onto all communication.»** The assignment is derived from **irreversibility of the consequence of loss** and **warrant class**, not from importance:

| Traffic | Class | **Delivery** | **Idempotent?** | Ordering | **Derivation** |
|---|---|---|---|---|---|
| **Ordinary neural-like signals** (excitation, inhibition, modulation) | S0 | **best-effort** | n/a | **none** | Loss is normal and is *information* — a biological substrate loses signals constantly and the computation is robust to it. **Retrying an S0 signal would triple the cheapest traffic in the system to fix a non-problem.** ⟵ V3 §2's «fast local» is exactly this |
| **Local broadcast / neighborhood modulation** | S0 | best-effort | n/a | none | Same |
| **REQUEST / RESPONSE** | S1 | **at-most-once** with a **timeout visible to the requester** | yes (by `msg_id`) | per-channel | A lost request produces a timeout, which the requester handles. **Retrying automatically would let a requester amplify load (§34)** |
| **STATUS / HEARTBEAT** | S1 | **best-effort** | n/a | none | **A missed heartbeat is the signal.** Retrying a liveness probe defeats its purpose: the receiver needs to know that the sender went quiet, not that the transport worked |
| **Learning signals** (prediction error, gated reward delivery, correction) | S1–S2 | **at-least-once + idempotent** | **yes, mandatory** | per-channel | **A lost learning signal biases `θ` silently; a duplicated one double-updates unless idempotent.** The Cell Contract's `eligibility_trace` + `Δ_MAX` + `DELTA_BUDGET` bounds make a single loss recoverable but a systematic loss not |
| **Evidence / assertion / prediction** | S2 | **at-least-once + idempotent** | **yes, mandatory** | per-channel | **Dedup is not optional: a duplicated evidence message that increments `n_obs` twice is §14's attack with no attacker** |
| **Provenance records** | S2–S4 | **at-least-once + idempotent + append-only** | yes | **causal (append order)** | Append-only makes duplicates detectable by content hash; **P0-02 EIK-INV-08: corrections supersede, never overwrite** |
| **Memory writes** | S2–S3 | **at-least-once + idempotent (by write-id)** | **yes, mandatory** | **per-target total** | **Two concurrent writes to one slot must serialize; a duplicated write must not double-apply.** Conflict resolution is §42's, not the transport's |
| **Evaluator messages** (verdicts, fitness, GT, outcomes) | **S3** | **ordered-at-least-once + idempotent + signed** | yes | **per-source total** | **P0-01 R6.7 `source = EVA_ONLY`; a lost verdict is a missing input and P0-02 EIK-INV-17 applies (uncertainty is never permission) — so loss must be DETECTED, which rules out best-effort** |
| **Governance messages** (permission, denial, freeze, ceiling, policy) | **S3/S4** | **ordered-at-least-once + idempotent + signed + ACKed** | yes | **epoch-total** | **P0-02 §26.5: irreversible-class decisions serialize at ROOT.** A reordered freeze/permit pair is a safety failure |
| **Safety commands** (freeze, halt, quarantine-execute) | **S3** | **ordered-at-least-once + signed + ACKed + retry-until-confirmed** | **yes, and the ACK is mandatory** | **epoch-total** | **The one place where unbounded retry is justified: the cost of a lost freeze exceeds the cost of retries.** P0-02 §6.2's row «KC-4 unreachable ⇒ `ES` + HALT by OP» presupposes that the freeze command's loss is detected |
| **Homeostatic signals** (demand, congestion, allocation) | S1 | **best-effort with periodic re-assertion** | n/a | none | **A homeostatic signal is a *level*, not an *event*.** Losing one is corrected by the next. **Retrying individually is the wrong mechanism; re-asserting periodically is the right one** ⟵ and this is why §7.4 rejects per-signal ACKs for modulation |
| **Immune signals** (anomaly, quarantine, discount) | S2–S3 | at-least-once + idempotent; **S3 when executing** | yes | per-source | **Detection may be best-effort; execution may not.** P0-02 §8.2's detect/adjudicate/clear split maps onto class |

## 7.3 The three consequences that follow from the table

**R7.2 (RETRY IS A PRIVILEGE, NOT A DEFAULT).** *Only classes whose loss is consequential may retry, and every retry consumes the sender's influence budget (§35).* **An unrestricted retry mechanism is a flooding amplifier that requires no malice** — a partition causes loss, loss causes retry, retry causes congestion, congestion causes loss. **This is §34's flooding attack arising from correct behaviour, and the budget is the only structural defence.**

**R7.3 (IDEMPOTENCE IS A RECEIVER OBLIGATION, NOT A TRANSPORT PROPERTY).** *Every class marked «idempotent: yes» imposes a requirement on the receiver's handler, and a receiver that does not satisfy it violates the contract regardless of what the transport does.* **⟹ §90: idempotence is a conformance-testable property of the receiver (apply the same `msg_id` twice; assert identical post-state), and it is one of the few communication properties that is mechanically testable without a network.**

**R7.4 (THE ACK COST LEDGER).** *ACKs are required only for S3/S4 and for classes marked «ACKed» above.* **The Cell Contract's `reliability = EWMA(delivered_and_acked / sent)` per connection implies ACKs on ordinary traffic, which would roughly double message count at every scale.** **Correction: reliability for S0/S1 is estimated from *aggregate* channel statistics (per-epoch digests, `O(R)`), not from per-message ACKs.** ⟵ This is P0-02 §49.2's technique 4 (Merkle/aggregate) applied to transport telemetry, and §68 records the original as contradiction X-I.

---

# §8. ORDERING

## 8.1 «Do not introduce distributed-systems mechanisms without demonstrating the problem they solve»

**Applying that instruction to the Cell Contract's `causality : compressed vector clock` — the mechanism fails the test.**

| Problem a vector clock solves | **Does this architecture have that problem?** |
|---|---|
| Determining whether two events at different participants are concurrent or causally related, **exactly** | ❌ **No.** A receiver aggregates whatever arrives in its window. It does not need to know whether message X and message Y are concurrent; it needs to know whether they **share evidence roots** (warrant) and whether either is **stale** (TTL/epoch). **Neither question requires a vector clock** |
| Detecting a causal-order violation (processing an effect before its cause) | ⚠️ **Partially — and `causal_depth: u8` suffices.** A message whose `causal_depth` exceeds the receiver's window bound is rejected as over-derived. Exact ancestry is not needed for this test |
| Reconstructing causal ancestry for attribution | ✅ **Yes — but rarely, and off-line.** P0-01 §23.2: causal attribution is REQUIRED only for pruning/retirement and for the fitness components that need it; **learning is explicitly CORRELATIONAL**. ⟹ **Reconstruction is an evaluator-side, retrospective operation over the anchored log (§61), not a per-message field** |
| Total order for consensus | ✅ **Yes — but only for the reserved set.** P0-02 §26.5 serializes irreversible-class decisions at ROOT: `O(governance events)`, not `O(messages)` |

**R8.1 (THE ORDERING VERDICT).** *The architecture requires three ordering mechanisms and no more:*
```
  1. PER-CHANNEL SEQUENCE (`seq`, u32, per (channel_id, epoch))
     ⟹ dedup, gap detection, per-channel order. **O(1) state per channel.**
     NECESSARY: without it, replay (§32) and loss (§29) are undetectable.

  2. EPOCH-SCOPED COARSE ORDER (`epoch`, governance-issued per P0-02)
     ⟹ freshness, mass-revocation (P0-02 R19.3), stale rejection.
     NECESSARY: without it, a valid old message is indistinguishable from a
     valid new one, and TTL alone depends on the advisory timestamp (§9).

  3. TOTAL ORDER, ONLY FOR S3/S4 GOVERNANCE AND SAFETY CLASSES
     ⟹ P0-02 §26.5's serialization of irreversible decisions.
     NECESSARY and BOUNDED: O(governance events).

  REJECTED: vector clocks (any form), Lamport clocks as message fields,
            total order for data-plane traffic, causal order for S0/S1.
  **Each is rejected because no problem in this architecture requires it —
    and each would cost O(N) space or O(N) coordination.**
```

## 8.2 The seven concurrency cases

| Case | Detected by | Response | **Ordering mechanism required** |
|---|---|---|---|
| **Asynchronous cells** | — | **Normal.** No mechanism needed; the receiver aggregates within a window | None |
| **Concurrent messages** | `seq` on distinct channels | Both admitted; **warrant computed jointly (§6.1 R6.1's CONFLATED check)** | Per-channel `seq` |
| **Delayed messages** | `ttl_hops` + `epoch` | EXPIRED → terminal for action, retained for record | Epoch |
| **Duplicated messages** | `msg_id` dedup set | DUPLICATE → counted, dropped | `msg_id` |
| **Reordered messages** | `seq` gap | **For S0/S1: process out of order; the computation is window-based.** For S3/S4: hold until ordered | Per-channel `seq`; total order for S3/S4 only |
| **Stale messages** | `epoch` mismatch or `ttl` exceeded | EXPIRED. **If staleness is systemic (rate > θ), report as the `COMMUNICATION` error class** (Cell Contract §6.3 case 4 — the class audit §E.1 found missing from V3.1) | Epoch |
| **Conflicting messages** | Payload semantics + `root_commit` intersection | **«Do NOT resolve locally»** (Cell Contract §6.3 case 3, preserved). Forward both with provenance to the organism Contradiction Detector; **abstain on the affected output**; record a `ConflictRef`. **If the conflict is between evaluator verdicts: DISPUTED, never averaged (P0-01 R28.2)** | None — conflict is a warrant-plane fact, not an ordering fact |

## 8.3 The state-cost correction

> The Cell Contract scopes `seq` as «per (src,dst,conv)». **That requires the receiver to hold a counter per (peer, conversation) pair — `O(peers × conversations)` state per cell, which at high degree exceeds the cell's own `bounded memory` allocation.**

**R8.2.** *`seq` is scoped per `(channel_id, epoch)`, where a channel is a connection or a regional bus — `O(degree)` state per cell, which the genome already bounds via `max_connections` and `max_fanout`.* **Conversation linkage is preserved by `conv_id` as a payload-level correlation field, not as a transport-level sequencing scope.** ⟵ A transport mechanism whose state cost exceeds the memory budget of the component implementing it is not implementable, and §0.2's rule (R0.1) applies to state as well as to fields.

---

# §9. TIME MODEL — **OUTPUT 8 (part 1)**

## 9.1 The six times

| Time | Definition | Source | **Authoritative for** | **Never authoritative for** |
|---|---|---|---|---|
| **Physical time** | Wall-clock at a hardware platform | Local oscillator, drift-bounded | Latency measurement **between parties with a declared drift bound** | **Ordering, freshness, or evidence of anything.** A self-declared timestamp is attacker-controlled (§58) |
| **Logical time** | `seq` per `(channel, epoch)` | Transport | Per-channel order, dedup, gap detection | Cross-channel order |
| **Event time** | The step at which a signal was emitted | Emitter's local counter | Correlating a signal with the emitter's state at emission | Anything global |
| **Processing time** | The step at which a receiver integrated a signal | Receiver's local counter | Eligibility traces (§46), credit assignment | Ordering |
| **Observation time** | When a GT-bearing observation occurred | **The environment / Task Authority (P0-01)** | Grounding an evidence root | — |
| **Evaluation time** | The epoch/window an evaluation covers | **EVA (P0-01)** | Fitness validity and expiry (P0-01 R27.2) | Anything inside the organism |

## 9.2 «Determine what happens when clocks disagree»

```
RULE 1 — **A MESSAGE'S OWN TIMESTAMP IS NEVER EVIDENCE.**
  It is a claim by the sender about its own oscillator. It may be used to
  compute latency ONLY when both endpoints declare a drift bound; otherwise
  the computed latency is `UNKNOWN`, and a receiver that treats `UNKNOWN`
  latency as low latency has fabricated a measurement.

RULE 2 — **ORDER COMES FROM `seq` AND `epoch`, NEVER FROM `ts`.**
  Two messages with inverted `ts` and correct `seq` are correctly ordered.
  Two messages with correct `ts` and no `seq` relationship are UNORDERED,
  and no mechanism may infer order from `ts`.

RULE 3 — **EPOCH IS THE ONLY GLOBAL TIME, AND IT IS COARSE.**
  Issued by governance (P0-02), so it is authenticated and monotone.
  Epoch advance is a mass-revocation event (P0-02 R19.3). **⟹ The epoch
  cadence is a safety/latency trade-off (P0-02 K-03), and this package
  adds a second consideration: the epoch bounds the staleness window and
  therefore the replay window (§32).**

RULE 4 — **DIVERGENCE IS AN OBSERVABLE, NOT AN ERROR.**
  Measured drift between declared-bounded parties is reported as a transport
  statistic. Drift beyond the declared bound ⟹ the pair loses latency
  measurement capability (reverts to `UNKNOWN`) **and the channel's
  freshness guarantee weakens to epoch-only**. **No halt, no rejection:
  a clock disagreement narrows what may be inferred, it does not stop
  communication.** ⟵ This is P0-02 EIK-INV-17's "uncertainty is never
  permission" applied to time: uncertain time never becomes certain order.
```

## 9.3 «Does the architecture require synchronized clocks?»

> ### **NO. It requires four things, none of which is synchronization.**

| Requirement | Needed? | Why |
|---|---|---|
| **Synchronized clocks** | ❌ **NO** | No mechanism in §8 or §9 depends on cross-party `ts` comparison. **V3 §9's «thalamus-like synchronization» is deleted (§2.5)** |
| **Bounded clock drift** | ⚠️ **Only for latency measurement, and only pairwise** | `latency_measured = EWMA(ack_ts − send_ts)` (Cell §14.5) is meaningful only under a declared bound. **Without a bound the value is `UNKNOWN`, and that is an acceptable state** |
| **Logical clocks** | ✅ **YES — per-channel `seq`** | §8.1 item 1. **This is the only ordering mechanism on the data plane** |
| **Causal timestamps** | ⚠️ **`causal_depth: u8` only** | §10.3. A saturating counter, not a timestamp |
| **No global time** | ⚠️ **Epoch is global but coarse and governance-issued** | Not a clock — a counter with authenticated transitions |

**R9.1 (THE SYNCHRONIZATION-FREEDOM CLAIM, AND ITS LIMIT).** *No communication mechanism in this contract requires global clock synchronization, and §84 confirms that no `O(N)` coordination operation exists.* **The limit: epoch transitions must propagate, and propagation is not instantaneous. During propagation, parties may disagree about the current epoch. §9.2 Rule 3 + P0-02 EIK-INV-14 resolve this: a message bound to epoch `e` is refused at a party that has advanced to `e+1`, and accepted at a party still at `e`. ⟹ Epoch advance is therefore *monotone-restrictive*: disagreeing parties never both accept a message the other refuses, which is the property that makes the disagreement safe.**

---

# §10. CAUSALITY — **OUTPUT 8 (part 2)**

## 10.1 «Can a message establish that A caused B?»

> ### **No. It can establish three weaker things, and the contract must name them correctly.**

| Relation | Establishable from communication metadata? | Mechanism |
|---|---|---|
| **Temporal precedence** («A preceded B») | ✅ Yes | `seq` within a channel; `epoch` across channels; `event time` at the emitter |
| **Dependency** («B's computation consumed A») | ✅ **Yes — and this is the strongest available claim** | `causal_depth` + `root_commit` membership + the receiver's anchored aggregation declaration |
| **Intervention** («changing A changes B, with all else fixed») | ❌ **No.** Requires ablation | **P0-01 §22.3 Tier 3 counterfactual ablation — EVA's, `O(n × episode)`, off-substrate** |
| **Inferred causality** («a model believes A caused B») | ⚠️ As a *claim*, yes; as a fact, no | A `HYPOTHESIS`-typed message (S2). **It is a claim, and §12's typing prevents it from being read as a fact** |
| **Externally established causality** | ✅ **Only by EVA** | P0-01 R22.3: **«Where the true causal structure is unknown and cannot be ablated, credit assignment is declared `CORRELATIONAL` and the resulting fitness carries elevated uncertainty. Pretending correlation is causation is the specific error this rule prevents»** |

**R10.1 (THE FIELD RENAMING).** ***The Cell Contract's `causality : compressed vector clock` field is misnamed, and the misnaming is a false-precision defect (P0-02 §34).*** **It carries dependency information, not causal information.** ⟹ **Renamed `dependency`, with `causal_depth: u8` + `root_commit: bytes<32>`.** *A field named `causality` invites every consumer to reason causally from it, and causal reasoning from dependency metadata is precisely P0-01 R22.3's prohibited error.*

## 10.2 What belongs in the communication layer vs. the epistemic layer

| Item | **Communication layer** | **Evaluator / epistemic layer** |
|---|---|---|
| Precedence | ✅ `seq`, `epoch` | — |
| Dependency | ✅ `causal_depth`, `root_commit`, aggregation declarations | Consumes them |
| **Intervention / ablation** | ❌ **Never** | ✅ **P0-01 §22.3 Tier 3, the only causal mechanism in the architecture** |
| Correlation estimation | ❌ | ✅ EVA |
| Credit assignment (authoritative) | ❌ **§46: forbidden as a message field (§4.4)** | ✅ EVA, when causal; the learning subsystem when correlational and provisional |
| Eligibility traces | ✅ **Local, per-connection, λ-decayed** (Cell §14.3) | Consumed by learning; **not a causal claim** |
| Causal reconstruction | ❌ **Not per-message** | ✅ **Off-line, from the anchored log (§61)** |

**R10.2 (THE DIVISION RULE).** *The communication layer carries **bounded dependency metadata sufficient to reconstruct causality off-line**; it never carries a causal claim, and never carries enough state to compute one on-line.* **This is why §0.2's vector-clock removal loses nothing: causal reconstruction was never a per-message operation, and P0-01 §23.2 already assigns it to the evaluator at `O(n × episode)`.**

## 10.3 What the vector clock's removal actually costs

```
LOST: the ability to determine, from two messages alone, whether they are
      causally related or concurrent — exactly, on-line, without a query.

RETAINED:
  • whether B's derivation is deeper than A's (`causal_depth`)
  • whether A and B share any evidence root (`root_commit` intersection,
    probabilistic from the message, exact against the anchored set)
  • whether A and B are in the same epoch and channel (`seq`, `epoch`)
  • full ancestry, retrospectively, from the anchored log

⟹ **THE LOST CAPABILITY IS "exact on-line concurrency determination."**
   **NO MECHANISM IN THIS CONTRACT USES IT.** §8.2's seven cases were each
   checked: none requires it. §14's independence check requires root-set
   disjointness, which `root_commit` + the anchored registry supply. §46's
   credit assignment requires eligibility traces (local) and, when causal,
   ablation (EVA). §31's split-brain reconciliation requires per-object
   ownership rules, not concurrency determination.

⟹ **R10.3: a mechanism whose output no consumer reads is not a safety
   margin; it is an O(N) field in an O(1) message (§0.2).** Removing it is
   a correctness improvement, not a trade.
```

---

# §11. INFORMATION TYPES — **OUTPUT 5**

## 11.1 The nineteen candidates, adjudicated

**The brief's instruction: «determine which types belong in the canonical contract. Avoid creating an unbounded taxonomy.»** The adjudication criterion is **warrant class**, not subject matter — because a taxonomy organized by subject matter grows without bound, while a taxonomy organized by *what the receiver is licensed to conclude* is bounded by the number of distinct licensings.

| Candidate | **In contract?** | Class | **Adjudication** |
|---|---|---|---|
| **SENSOR** | ✅ | S2 | An observation with an external root. **P0-01 R6.1: an observation at E0 MUST NOT contribute to `evidence_roots`** — so SENSOR is S2 only after passing P0-01's E0→E4 gates |
| **FEATURE** | ⚠️ **Subsumed** | S1/S2 | A derived representation is a SENSOR or an ASSERT depending on whether it makes an evidential claim. **A separate FEATURE type would let a derived quantity inherit SENSOR's warrant (§16's provenance laundering)** ⟵ **REJECTED as a distinct type; this is the most important rejection in the table** |
| **PREDICTION** | ✅ | S2 | **The cell's core epistemic act** (Cell Contract §10.3: «Prediction is the irreducible core»). Distinct from ASSERT because a prediction is *resolvable* — it has a `resolution_deadline` and produces the primary learning signal (Cell §10 case 3, T1) |
| **ERROR** | ✅ | S2 | **Prediction–observation discrepancy.** **Must be distinguished from a fault report** (§29's `E_IN_*` codes are transport faults, S1). Cell Contract T1/T3 gating: «a `REPORT_ERROR` from a peer is **not** a learning signal. Only an EIK-signed `eval.error.v1` is» — **preserved, with «EIK-signed» corrected to «EVA-signed» per P0-02 R8.7** |
| **EVIDENCE** | ⚠️ **Not a type — a warrant outcome** | — | **REJECTED as a message type.** Evidence is what a receiver *concludes* about a message (§5.1 state 8), not what a sender *declares*. **A type called EVIDENCE would let a sender assert evidential status, violating R0.4** ⟵ **the second most important rejection** |
| **HYPOTHESIS** | ✅ | S2 | A candidate interpretation. **Distinct from ASSERT: a hypothesis is not a claim about the world, it is a proposal for one.** §12's typing prevents hypothesis→command and hypothesis→fact confusion |
| **REQUEST** | ✅ | S1 | Request for computation/information. **Carries no warrant; creates an obligation on the responder, which is why it is rate-limited (§34)** |
| **RESPONSE** | ✅ | S1/S2 | **Class depends on content:** a factual response is S2; a service acknowledgement is S1 |
| **COMMAND** | ⚠️ **Heavily restricted** | **S3** | **A cell may not issue a COMMAND.** The Cell Contract already establishes this: `RECOMMEND_ACTION` is «a recommendation is not an action and confers no authority». **⟹ COMMAND exists only as a governance/evaluator/service type, and a cell-generated message of type COMMAND is malformed at the type level (§12.3)** |
| **STATUS** | ✅ | S1 | Internal state report. **§12: STATUS may not be interpreted as EVIDENCE** — the brief names this confusion explicitly, and the type partition enforces it |
| **RESOURCE** | ✅ | S1 | Resource information. **Demand signals are S1 and best-effort with periodic re-assertion (§7.2)** |
| **ATTENTION** | ✅ | S1 | **Attention request/modulation. Operates on the INFLUENCE plane only (§44).** V3 §4's «attention» signal, correctly retained but plane-restricted |
| **REWARD** | ✅ **but producer-restricted** | **S3** | **P0-01 R6.7 `source = EVA_ONLY`; the reward channel is closed.** The Cell Contract's «Reward | EIK Fitness Authority only … EIK-signed — cell signatures inadmissible» is **preserved in mechanism, corrected in principal (EVA, per P0-02 R8.7)**. **A cell-generated REWARD is structurally invalid at ingress** |
| **PLASTICITY** | ⚠️ **Split** | S1 / policy | **A plasticity *signal* (gated error, eligibility trigger) is S1 and is a learning input. A plasticity *rule* is policy (RO-13) and is not a message at all.** ⟵ V3.1 §6's «learning-rule variation» as an evolutionary operator conflates these (§68 X-G) |
| **GOVERNANCE** | ✅ | **S3/S4** | **P0-02 Channel 1 (policy identity) and Channel 2 consequences.** §40's «Cell A recommends freeze» vs «EIK authorizes freeze» is a **type-level** distinction, not a policy check |
| **IMMUNE** | ✅ | S2 (detect) / **S3 (execute)** | **P0-02 §8.2's three-way split: detection unrestricted (S2), adjudication budgeted (S2), execution authorized (S3), clearance KC-2/RO-08 (S3)** |
| **MEMORY** | ✅ | S2/S3 | Read requests S1; write requests S2; **protected/semantic writes S3 with Memory Authority approval** (Cell Contract §7.2's `PROPOSE_MEMORY_WRITE` restriction, preserved) |
| **HEARTBEAT** | ✅ | S1 | Liveness. **Best-effort; a missed heartbeat is the signal (§7.2)** |
| **OTHER** | ✅ **as `OPAQUE`, with minimum warrant** | **S0/S1** | **§49: the escape hatch that keeps the taxonomy bounded without requiring designers to enumerate the future.** An `OPAQUE` message may be transported and may influence; **it may never warrant** |

## 11.2 **OUTPUT 5 — the canonical taxonomy**

**Fourteen types across five classes, plus one escape. Not nineteen, and the reduction is the point.**

```
S0  BARE (influence-only, no warrant, no provenance)
    ─ ACTIVATION        edge signal: excitation / inhibition / modulation
    ─ NEIGHBORHOOD      local broadcast: attention modulation, morphogen

S1  TYPED (transport-authenticated, no evidential warrant)
    ─ REQUEST           QUERY · REQUEST_RESOURCE · REQUEST_CONNECTION
    ─ RESPONSE          service acknowledgement, retrieval result envelope
    ─ STATUS            REPORT_HEALTH · REPORT_SELF_STATE · HEARTBEAT
    ─ RESOURCE          demand · congestion · allocation (best-effort,
                        periodically re-asserted)
    ─ ATTENTION         REQUEST_ATTENTION · attention modulation
    ─ LEARNING_LOCAL    gated error signal · eligibility trigger ·
                        ANNOUNCE_UPDATE
    ─ OPAQUE            §49's escape class: transported, budget-capped,
                        **minimum warrant, un-promotable except by RO-13**

S2  WARRANTED (carries root_commit + causal_depth + calib_ref + corr_class)
    ─ OBSERVATION       SENSOR, post-P0-01-E-gates
    ─ ASSERT            a claim about the world (Cell §7.3(a))
    ─ PREDICTION        resolvable, with resolution_deadline
    ─ HYPOTHESIS        a proposal for an interpretation
    ─ ERROR_EVIDENTIAL  prediction–observation discrepancy
    ─ RECOMMEND         action recommendation (**confers no authority**)
    ─ IMMUNE_DETECT     anomaly report (**report only**)
    ─ MEMORY_PROPOSE    PROPOSE_MEMORY_WRITE

S3  AUTHORIZED (signed, epoch-bound, per-message signature)
    ─ VERDICT           EVA fitness / evaluation / outcome / GT-bearing
                        (**source = EVA_ONLY**, P0-01 R6.7)
    ─ REWARD            (**EVA-signed; cell signatures structurally invalid**)
    ─ GOVERNANCE        KC-2 decision: PERMIT · DENY · DEFER · FREEZE ·
                        ESCALATE · HALT (P0-02's six outputs)
    ─ SAFETY            SAFETY_ALERT · VIOLATION_REPORT · freeze/halt command
    ─ IMMUNE_EXECUTE    quarantine execution · restore (**RO-08, KC-2 sole**)
    ─ ATTESTATION       ATTEST_VERIFIED (**C3 only + countersignature**)

S4  ANCHORED (S3 + append-only anchor + W_min witnesses)
    ─ POLICY            constitutional / policy artifact (P0-02 Channel 1)
    ─ PROVENANCE_ROOT   epoch Merkle root, genesis anchor, lineage record
    ─ LIFECYCLE         RO-01…RO-04, RO-09, RO-10 decisions
```

**R11.1 (THE BOUNDEDNESS ARGUMENT).** *The taxonomy is bounded because it is organized by **what the receiver is licensed to conclude**, and there are finitely many licensings.* **A taxonomy organized by subject matter is unbounded** — every new domain adds types, and §49's novel-protocol problem becomes unsolvable. **Organized by warrant, a novel domain adds `OPAQUE` traffic and, if it earns warrant, a new type *within an existing class* — which is a policy change (RO-13), not a protocol change.** ⟵ **This is the mechanism by which «emergent protocols remain bounded without requiring designers to enumerate every future protocol» (§94's principle) is actually achieved.**

**R11.2 (THE TWO REJECTIONS THAT MATTER MOST).** *`FEATURE` and `EVIDENCE` are not types.* **`FEATURE` because a derived representation must not inherit an observation's warrant (§16); `EVIDENCE` because evidential status is a receiver's conclusion, not a sender's declaration (R0.4).** *Both rejections are type-level closures of attacks that would otherwise require detection: §67's #10 (provenance laundering) and #11 (evidence amplification).*

---

# §12. SEMANTIC TYPING

## 12.1 «Can the communication layer prevent prediction-interpreted-as-fact?»

> ### **Yes for three of the four confusions, by type partition. No for the fourth, and the fourth is the deep one.**

| Confusion | Prevented? | Mechanism |
|---|---|---|
| **prediction interpreted as fact** | ✅ **YES — type-level** | `PREDICTION` and `ASSERT` are distinct types with distinct schemas: a PREDICTION **must** carry `resolution_deadline` and a typed future-observation reference, and an ASSERT **must not**. **A message that is structurally a prediction cannot be parsed as an assertion** — the schemas are disjoint, not merely differently labelled |
| **hypothesis interpreted as command** | ✅ **YES — type-level + class-level** | `HYPOTHESIS` is S2; `COMMAND`-bearing types (`GOVERNANCE`, `SAFETY`, `IMMUNE_EXECUTE`) are S3. **An S2 message cannot be processed by an S3 handler, because the S3 handler requires a signature the S2 class does not carry (§7.2).** The confusion is a *class* error, and class is not sender-selectable (§72) |
| **status interpreted as evidence** | ✅ **YES — type-level** | `STATUS` is S1 and carries **no `root_commit`**. **A message without a root commitment cannot increment `n_obs`, because the warrant check (§13.4) has no input.** ⟵ This is R1.2 operating as a structural closure rather than a policy check |
| **an S2 claim interpreted as *correct*** | ❌ **NO — and no communication layer can** | **Typing establishes what kind of claim is being made, never whether the claim is true.** §17's separation and COMM-INV-01/02. **This is OR-1-class: a limit, not a gap** |

## 12.2 The six typing requirements

| Requirement | Mandatory? | **Why** |
|---|---|---|
| **type** | ✅ **MANDATORY** | Determines class, which determines every guarantee (§72). **The single most load-bearing field** |
| **semantic schema** (`payload_type` + `schema_version`) | ✅ **MANDATORY** | The Cell Contract's Type Registry resolution, preserved. **Without it, `PARSE` (§5.1 state 3) is undefined and two implementations diverge — §89's first agreement item** |
| **unit** | ✅ **MANDATORY for quantitative payloads** | **A unitless number is not a quantity.** Two teams using different normalizations produce silently incomparable values, and the divergence appears as a *measurement disagreement* rather than a *unit error* — the hardest class of bug to find. **This is P0-01's «a metric without a CI is inadmissible» applied to units** |
| **domain** (valid range / type of the quantity) | ✅ **MANDATORY** | Bounds checking is a §38 defence: an out-of-domain payload is rejected at PARSE, before interpretation. **Prevents the «computationally expensive content» attack from reaching compute** |
| **representation** (encoding, endianness, precision) | ✅ **MANDATORY at the protocol layer; hardware-invariant** | §56/§85: **a signal must retain its meaning when transport changes.** Representation is part of the semantic contract, not the transport |
| **expected interpretation** | ⚠️ **DERIVED from type — never sender-declared** | **A sender-declared "expected interpretation" is a warrant claim, and R0.4 forbids the sender from making one.** The type registry maps `type → permitted interpretations`, and that mapping is policy |
| **uncertainty representation** | ✅ **MANDATORY for S2+: sufficient statistics, not a scalar** | §13. The Cell Contract's `{aleatoric_var, epistemic_var, n_obs, s1, s2}` is correct and is preserved |

## 12.3 «The system must preserve the distinction between what a sender says and what the receiver concludes»

```
THE MECHANISM IS THREEFOLD, AND ALL THREE ARE STRUCTURAL:

1. **THE TYPE IS THE SENDER'S; THE WARRANT IS THE RECEIVER'S.**
   A sender declares `type = ASSERT`. The receiver computes
   WARRANTED / NOT-WARRANTED. **These are different objects held by
   different parties, and the contract never permits one to be written
   into the other's field.** (§5.1 states 3 vs 8)

2. **THE CONCLUSION IS A DISTINCT, REPRESENTABLE OBJECT.**
   The receiver's aggregation produces a claim of its own, with its OWN
   `root_commit` (the union of its inputs' roots), its OWN `causal_depth`
   (max of inputs + 1), and its OWN `calib_ref` (its own, not its inputs').
   **⟹ A derived claim does not inherit its inputs' warrant; it derives a
   weaker one (§16, COMM-INV-08's monotone non-amplification).**

3. **DISAGREEMENT IS REPRESENTABLE.**
   `NOT-WARRANTED` is a first-class outcome, and so is `CONFLATED` (§6.1
   R6.1) and `DISPUTED` (P0-01 R28.2). **A receiver that cannot represent
   "I got this and I do not believe it" has no way to hold the distinction
   at all** — and a receiver that cannot represent "these two agree but are
   not independent" cannot implement R1.2.
```

**R12.1 (THE MALFORMED-TYPE RULE).** *A message whose declared `type` is not in the closed registry for the class the sender is authorized to emit is **MALFORMED**, not downgraded.* **Downgrading is the dangerous alternative: a message that fails to authenticate as S3 and is silently processed as S2 has had its warrant *reduced* by an attacker-controlled action, and the reduction is invisible.** ⟹ **COMM-INV-05's converse: a class may never be reduced by stripping or failing fields, only by an authorized re-typing.** *This closes §67's #9 (provenance stripping) and #8 (semantic type confusion) structurally.*

---

# §13. CONFIDENCE / UNCERTAINTY TRANSMISSION

## 13.1 «What epistemic information can travel through communication?»

| Item | May travel? | **Class** | Attack surface if permitted |
|---|---|---|---|
| **Raw sufficient statistics** (`n_obs`, `s1`, `s2`, variance decomposition) | ✅ **YES — PREFERRED** | S2 | **Low.** They are *inputs to* a confidence judgement, not the judgement. A forged statistic produces a *recomputably wrong* aggregate, which is detectable by the receiver's own recomputation (R0.4) |
| **Evidence roots** (as a bounded commitment) | ✅ **YES — MANDATORY for S2+** | S2 | **Low for forgery** (a commitment to a nonexistent root fails resolution); **medium for omission** (§67 #9) — closed by R12.1 |
| **Provenance** (bounded: `root_commit` + `causal_depth`) | ✅ **YES** | S2 | See §15 |
| **Sender calibration class** — **as a POINTER, not a value** | ✅ **YES, as `calib_ref`** | S2 | **A self-declared calibration class is a warrant claim.** `calib_ref` points to an **externally-assigned** record (Cell Contract: `calibration_class`, `produced_by: KERNEL_CALIBRATED`; P0-02 R8.7 renames the producer to EVA). **The receiver resolves the pointer and reads the assignment; it never trusts an inline value** |
| **Trust metadata** | ❌ **FORBIDDEN in cell-generated messages** | — | **§17: trust is assigned, not claimed.** A message asserting its own trustworthiness is self-verification, forbidden by Cell Contract §7.3 and by R0.3's warrant⟶influence prohibition |
| **Uncertainty distribution** | ✅ Yes, as sufficient statistics | S2 | Low |
| **Likelihood** | ⚠️ **Only relative to a declared model** | S2 | **A likelihood without its model is not a number.** `payload_type` + `schema_version` supply the model reference; **a likelihood whose model is unspecified is MALFORMED** |
| **Posterior** | ❌ **FORBIDDEN** | — | **A posterior is a conclusion, and transmitting it as data collapses §12.3's sender/receiver distinction.** A posterior may be transmitted as an `ASSERT` *payload* (a claim), never as an epistemic metadata field |
| **Scalar confidence** | ⚠️ **PERMITTED AS A CLAIM, PROHIBITED AS A WARRANT INPUT** | S2 | **§13.2 — the analysis the brief demands** |

## 13.2 «Do not simply transmit a scalar confidence value without analyzing its attack surface»

```
A SCALAR CONFIDENCE c ∈ [0,1] ATTACHED TO A CLAIM X HAS FIVE ATTACK
SURFACES, AND THEY COMPOUND:

1. **INFLATION.** The sender sets c = 1.0. **Cost to the attacker: zero.**
   Detection: only by comparing c against the sender's realized accuracy —
   which requires an external calibration record (i.e., `calib_ref`), which
   means the scalar contributed nothing that the pointer did not.

2. **STRATEGIC DEFLATION.** The sender sets c low on claims it wants
   discounted and high on claims it wants believed, **decoupling c from
   actual uncertainty entirely.** Detection: requires per-sender calibration
   history ⟹ external ⟹ again the scalar is not the mechanism.

3. **AGGREGATION DOMINATION.** In a weighted aggregate, a high-c message
   dominates regardless of its evidence base. **A single forged high-c claim
   outweighs ten genuine low-c claims.** ⟵ **This is §35's amplification
   attack executed with one field instead of ten thousand cells, and it is
   the most efficient attack in the entire suite.**

4. **CALIBRATION LAUNDERING.** A derived message reports the *maximum* (or
   the mean) of its inputs' confidences. Either choice is wrong: the mean
   of correlated confidences overstates; the maximum of chained confidences
   overstates more. **Without sufficient statistics there is no correct
   aggregation rule for a scalar** — which is exactly why the Cell Contract
   chose statistics.

5. **THE UNFALSIFIABILITY PROBLEM.** A scalar c carries no information about
   *what it is confidence in*. c = 0.9 about a type, about a value, about a
   ranking, and about a causal claim are different quantities with different
   aggregation rules. **A single scalar field cannot distinguish them, so a
   receiver cannot know which rule to apply.**

⟹ **VERDICT: a scalar confidence is a valid CLAIM and an invalid WARRANT
   INPUT.** It may travel inside an `ASSERT` payload as part of what is
   being asserted ("I assign predictive probability 0.9 to X" — Cell
   Contract §7.3(a)'s semantics, which is exactly right). **It may not
   travel as envelope metadata that the receiver's aggregation consumes.**

⟹ **AND THE CELL CONTRACT ALREADY MADE THIS DECISION CORRECTLY:**
   «uncertainty : {aleatoric_var: f32[D], epistemic_var: f32[D], n_obs: u64,
   s1: f64[D], s2: f64[D]}  // ← **SUFFICIENT STATISTICS, not a scalar**»
   **This contract preserves it and adds the reason: sufficient statistics
   are AGGREGATABLE and RECOMPUTABLE; a scalar is neither.**
```

## 13.3 The aggregation property that makes statistics mandatory

```
SUFFICIENT STATISTICS COMPOSE:
   Two independent observations with (n₁, s1₁, s2₁) and (n₂, s1₂, s2₂)
   aggregate to (n₁+n₂, s1₁+s1₂, s2₁+s2₂) — **exactly, with no loss, and
   with no knowledge of the underlying distribution beyond its exponential
   family form.**

A SCALAR DOES NOT COMPOSE:
   c₁ and c₂ aggregate to ... what? **There is no correct answer without
   knowing n₁, n₂, and the correlation between them.** Every rule
   (mean, max, product, Bayesian update with an assumed prior) embeds an
   assumption the message does not carry.

⟹ **THE DEEPER POINT, AND IT IS R1.2 AGAIN:**
   Two observations with the SAME sufficient statistics but the SAME root
   must aggregate to (n, s1, s2) — **NOT to (2n, 2·s1, 2·s2).**
   **Sufficient statistics make the aggregation exact; `root_commit`
   intersection makes it honest.** Neither suffices alone:
     • statistics without roots ⟹ copies double-count (§14's attack)
     • roots without statistics ⟹ dedup works but aggregation is undefined

⟹ **R13.1: an S2 message MUST carry both. This is why the minimal warrant
   envelope (§4.3) has eleven fields and not nine.**
```

## 13.4 «Can the receiver independently recompute epistemic reliability?»

> ### **YES — and R0.4 makes this mandatory rather than desirable. The recomputation has four inputs, all receiver-side or external, none sender-asserted.**

```
RECOMPUTE(sender's claim) requires:
  1. `root_commit`  ∩  the receiver's own root set
     ⟹ **how much of this claim is new to me?** A claim whose roots are a
        subset of what I already hold adds ZERO independent evidence,
        regardless of its statistics.
  2. `corr_class`  vs  the receiver's correlation dimensions (§14.3)
     ⟹ **is this claim from a source that fails when I fail?** Same lineage,
        same model class, same hardware class, same upstream ⟹ correlated.
  3. `calib_ref`  →  the EXTERNALLY-ASSIGNED calibration record
     ⟹ **what is this producer's realized accuracy on this type?** Not its
        opinion of itself. Resolved against a registry the sender cannot
        write (Cell Contract: `trust_out_assigned` read-only; P0-02 R8.7: EVA)
  4. `causal_depth`
     ⟹ **how many derivations stand between this claim and an observation?**
        P0-01 R15.6's monotone non-amplification applies: warrant class
        cannot increase with depth.

**ALL FOUR ARE COMPUTABLE WITHOUT TRUSTING ANY SENDER-ASSERTED EPISTEMIC
QUANTITY.** The sender supplies pointers and commitments; the receiver
supplies its own state; the registry supplies the assignments.

⟹ **R13.2 (THE RECOMPUTATION RULE).** *A receiver MUST be able to compute
   the warrant of any S2+ message from (message warrant metadata) +
   (receiver state) + (external registries). A message whose warrant depends
   on a sender-asserted epistemic quantity is malformed.*

⟹ **AND THE LIMIT, STATED (§91 OR-C1):** recomputation detects COPY
   correlation exactly (root intersection) and COMMON-CAUSE correlation only
   to the extent that `corr_class` dimensions are complete. **Model-class and
   latent-assumption correlation are not self-declarable and not verifiable
   from inside** — P0-02's IND-6, in communication form. **Declared, not
   solved.**
```

---

# §14. EVIDENCE INDEPENDENCE — **OUTPUT 17**

## 14.1 The problem, exactly

```
   A ──────► B ──────┐
   │                 ├──► D
   └──────► C ──────┘

D receives four apparently different signals:
  1. from A (directly)
  2. from B (A's information, transformed)
  3. from C (A's information, transformed differently)
  4. its own aggregation of 2 and 3

**All four originate from A.** If D counts them as four observations:
   n_obs   : 1  →  4
   s1, s2  : scaled by 4
   confidence class: INSUFFICIENT → ESTABLISHED   (P0-01 §12's ladder)
   warrant : NOT LICENSED → LICENSED-AS-EVIDENCE

**AND NO ERROR SIGNAL IS PRODUCED ANYWHERE.** D is, by every internal
measure, better informed than it was. **This is §0.5's warrant-plane failure
and §1.2's reason this is a safety package.**
```

## 14.2 «Do not assume different senders = independent evidence»

**The Cell Contract's existing defence, and precisely how far it reaches:**

| Mechanism (Cell Contract) | What it catches | **What it misses** |
|---|---|---|
| **Dedup by `evidence_roots`** — «de-duplicated by `evidence_roots`» (§7.3(a)) | **Exact copies and messages citing identical roots** ⟹ catches paths 1 and 4 above if the roots are preserved verbatim | **Transformed evidence whose root set was rewritten.** §16's provenance laundering: B re-roots its output in *its own* observation and cites A only as context |
| **`derivation_depth`** | Unbounded chains (a depth limit rejects over-derived claims) | **Width.** Depth 1 from a single root, fanned out to a million receivers, is still one observation |
| **FM-4 self-confirming recall** — «Retrieval from self-written memory does not increment `n_obs` and does not add new `evidence_roots`» | **Self-sourced corroboration.** This is the sharpest mechanism in the Cell Contract and is preserved unchanged | Cross-subject correlation: two *different* subjects sourcing the same upstream |
| **`inbreeding_F`** rising with `derivation_depth`, with abstention above `F_max` | Long derivation chains within a lineage | **Shallow but wide correlation** — the actual attack above is depth 2 and width 10⁶ |
| **FM-3 Merkle anchoring** | Rewriting history | **Nothing about independence** — anchoring proves what was claimed, not that claims were independent |

**R14.1 (THE FINDING).** ***Root-equality deduplication catches copies. It does not catch common causes.*** **The A→B→D / A→C→D attack survives the Cell Contract's defences whenever B and C re-root their outputs (§16), and re-rooting is not an attack — it is what a legitimate transformation does.** ⟹ **This is contradiction X-C in §68, and it is the most consequential defect this package finds.**

## 14.3 The correlation vector — six dimensions

> **R14.2.** *Two messages are independent if and only if they are disjoint on **all** of the correlation dimensions that apply to the claim being aggregated. Root-disjointness is one dimension of six.*

| # | Dimension | **Representation in `corr_class`** | Detectable? | **What defeats detection** |
|---|---|---|---|---|
| **1** | **Root** — same originating observation | `root_commit` intersection (exact against the anchored registry, probabilistic from the message alone) | ✅ **EXACT** | Root rewriting (§16) — closed by COMM-INV-08's root-inheritance rule |
| **2** | **Lineage** — same genome ancestry | `lineage_id` + `generation` (already in `src`) | ✅ **EXACT** | Lineage cloning (§67 #37) — closed by P0-02's Registrar-issued lineage certificates |
| **3** | **Model** — same transform architecture / same `genome.variant` | `variant` + `model_class` digest | ⚠️ **APPROXIMATE** | **Two different variants exhibiting the same learned bias.** `variant` is a *syntactic* identifier; bias is *semantic* |
| **4** | **Upstream source** — same sensor, same feed, same GT class | `sensor_id` / GT source class (P0-01 L0–L6) at the root | ✅ for declared sources | **An undeclared common upstream** — two sensors of the same physical phenomenon behind different interfaces |
| **5** | **Hardware** — same device, same accelerator, same fault domain | `hardware_class` digest | ⚠️ **APPROXIMATE** | **P0-01 F-IMP-2 / P0-02 G-P02-5: hardware class is deployment-specific and often unknown to the cell** |
| **6** | **Protocol / designer assumptions** — same implementation, same reading of the same spec | `impl_class` digest | ❌ **NOT DETECTABLE FROM INSIDE** | **P0-02's IND-6 (latent assumptions) and IND-9.** Two implementations by two teams from one specification correlate in ways neither can report |

**R14.3 (THE HONEST CLASSIFICATION).** *Dimensions 1, 2, and 4 are exactly detectable. Dimensions 3 and 5 are approximately detectable. **Dimension 6 is not detectable from inside the system at all** — and §14.6 shows that this is the dimension that actually defeats `n_eval ≥ 3` evaluator independence.* **Any claim of "independence" in this architecture MUST name which dimensions it holds on** (P0-02 R35.1's rule, adopted verbatim).

## 14.4 The mechanism, and where it lives

```
IN THE MESSAGE (O(1)):
   root_commit : bytes<32>   Merkle commitment over the root SET
   corr_class  : bytes<8>    digest of (lineage, variant/model_class,
                                        sensor/GT class, hardware_class,
                                        impl_class)

IN THE RECEIVER (O(local state)):
   On aggregation, compute for each input pair:
     root_overlap    = |roots_i ∩ roots_j|      (exact against the anchored
                                                 registry; Bloom-approximate
                                                 locally)
     corr_match      = hamming distance over the corr_class dimensions
     independence    = (root_overlap = 0) AND (corr_match ≥ θ_indep on
                                               dimensions 1,2,4)
                                               **AND dimensions 3,5,6
                                               DECLARED, NOT ASSUMED**

IN THE ANCHOR (O(R) per epoch):
   The root registry: epoch Merkle root over all emitted root commitments.
   **This is what makes root_overlap EXACT rather than probabilistic, and it
   is why §15.3's three-tier pattern is not optional.**

IN EVA (authoritative):
   **For any CONSEQUENTIAL aggregation** — promotion, pruning, retirement,
   fitness (P0-01 §23.2) — independence is recomputed by EVA from the
   anchored registry, NOT taken from the organism's self-report.
   ⟵ P0-01 R8.5: «`L3` MUST declare its independence argument.»
   ⟵ Cell Contract FM-4: «Mitigated by organism-side `inbreeding_F`
      recomputation **from the Anchor, not from the cell's self-report**»
```

**R14.4 (THE AGGREGATION RULE).** *An aggregate's effective sample size is **not** the count of its inputs. It is the count of its **independence-distinct** inputs, computed over dimensions 1, 2, and 4 exactly, with dimensions 3, 5, and 6 declared.* **A receiver that reports `n_obs = 4` for four messages sharing one root has violated COMM-INV-03, and the violation is detectable by EVA from the anchor — which is what makes it a bounded rather than an open defect.**

## 14.5 The nine mechanisms the brief lists, adjudicated

| Mechanism | Adopted? | Form |
|---|---|---|
| **Evidence roots** | ✅ | `root_commit` (bounded commitment, not an unbounded array — §0.2) |
| **Lineage** | ✅ | Already in `src`; enters `corr_class` |
| **Provenance** | ✅ | §15 — bounded in-message, exact in-anchor |
| **Source deduplication** | ✅ | `msg_id` for transport duplicates; **`root_commit` intersection for warrant duplicates. Two different mechanisms for two different problems, and conflating them is the Cell Contract's defect** |
| **Correlated evidence** | ✅ | `corr_class` dimensions 3, 5, 6 |
| **Common-cause evidence** | ✅ | `corr_class` dimension 4 (upstream/GT source) |
| **Copied messages** | ✅ | `msg_id` dedup |
| **Transformed evidence** | ✅ | §16 — **root inheritance is mandatory under transformation; re-rooting requires a new observation** |
| **Derived evidence** | ✅ | `causal_depth` + COMM-INV-08's monotone non-amplification |

## 14.6 «Many cells agreeing because they copied one source» vs. «many cells independently deriving the same conclusion»

> ### **§36's question. The discriminator is the correlation vector, and it has a hard limit that must be stated rather than smoothed over.**

```
VIRAL PROPAGATION (copied):
  root_commit sets OVERLAP heavily
  corr_class dimensions 1,2 MATCH
  arrival times CLUSTER (propagation has a wavefront)
  causal_depth INCREASES monotonically along the propagation path
  ⟹ **DETECTABLE, EXACTLY, on dimensions 1 and 2.**

INDEPENDENT CONVERGENCE:
  root_commit sets DISJOINT
  corr_class dimensions 1,2,4 DISJOINT
  arrival times UNCORRELATED
  causal_depth UNCORRELATED
  ⟹ **DISTINGUISHABLE FROM VIRAL PROPAGATION ON THE OBSERVABLES ABOVE.**

THE HARD LIMIT — AND IT IS THE SAME LIMIT P0-01 AND P0-02 FOUND:
  Two populations with DISJOINT roots, DISJOINT lineage, and DISJOINT
  sensors can still converge because they share **dimension 6**: the same
  designers' latent assumptions about what the world is like.

  **They will then produce the same wrong conclusion, from genuinely
  independent evidence, with high confidence, and every observable in this
  contract will correctly report them as independent.**

  ⟹ This is P0-01's CD-8 (sim-to-real: «internally coherent, mutually
     consistent fitness, zero relationship to ℛ, **no internal signal
     detectable**») at the communication layer.
  ⟹ And it is why P0-01's INV-43 (the real-world suite is non-empty) and
     P0-02's §46.3 (the real-world anchor is a GOVERNANCE requirement) are
     load-bearing for THIS package too: **the real-world anchor is the only
     dimension-6-disjoint input the architecture has.**

⟹ **R14.5: the architecture can distinguish copied agreement from
   independently-derived agreement on dimensions 1, 2, and 4 exactly. It
   CANNOT distinguish independently-derived agreement from commonly-biased
   agreement. The second distinction requires an input the system does not
   contain, and §91 OR-C4 records it as a limit rather than a gap.**
```

---

# §15. PROVENANCE PRESERVATION — **OUTPUT 16**

## 15.1 «Does every evidence-bearing message need full provenance?»

**No — and the answer differs by field, which is why the question as posed is a false binary.**

| Field | **S0** | **S1** | **S2** | **S3/S4** |
|---|---|---|---|---|
| source | implicit (the edge) | via `channel_id` | via `channel_id` | explicit + signed |
| source lineage | ❌ | ❌ | via `corr_class` | ✅ explicit |
| transformation history | ❌ | ❌ | **`causal_depth` only** | ✅ full, in the anchor |
| evidence root | ❌ | ❌ | **`root_commit` (commitment)** | ✅ exact set, anchored |
| timestamp | ❌ | advisory | advisory + `epoch` | ✅ signed, `epoch`-bound |
| originating observation | ❌ | ❌ | **reachable via the anchor** | ✅ |
| intermediary transformations | ❌ | ❌ | **count only (`causal_depth`)** | ✅ enumerated in the anchor |

## 15.2 «A brain with billions of messages cannot retain infinite provenance»

**The five-way classification the brief requires:**

| Category | What | **Why** |
|---|---|---|
| **MUST REMAIN EXACT** | Evidence-root **membership** (provable against a commitment) · signer identity for S3/S4 · `epoch` · `seq` · the reserved-operation decision record (P0-02) · S4 lifecycle/constitutional records | **Exactness is required wherever a consequential decision depends on it.** P0-02 R20.1: «no consequential decision may rest on unanchored provenance» |
| **MAY BE COMPRESSED** | The root **set** → a Merkle commitment (`O(1)`, membership provable in `O(log)`) · the transformation **chain** → `causal_depth` + anchored links · the correlation vector → an 8-byte digest | **Compression must be lossless on the WARRANT dimension and lossy only on the payload dimension (§63.3's rule).** A commitment is exactly this: it loses the enumeration and preserves membership |
| **MAY BE SUMMARIZED** | Per-epoch per-region traffic digests (`O(R)`) · aggregate root registries · inert/duplicate/shed counters · channel reliability statistics | **P0-02 §20.3's three-tier pattern.** Summaries are observability, not warrant |
| **MUST REMAIN CRYPTOGRAPHICALLY ANCHORED** | Epoch Merkle roots · the root registry · S3/S4 records · the genesis anchor · lineage certificates · policy lineage | **P0-02 §20.2's `W_min` witnesses with ≥1 outside operational control (EIK-INV-27)** |
| **MAY BE DISCARDED** | S0/S1 payloads after `ttl` · per-message transport telemetry after aggregation · duplicate records after the dedup window · **the `msg_id` set may NOT be discarded before the replay window closes (§32)** | **Discard is permitted only where no warrant and no replay defence depends on it** |

## 15.3 **OUTPUT 16 — the three-tier provenance model**

```
TIER 1 — IN-MESSAGE, O(1), EVERY S2+ MESSAGE
   root_commit : bytes<32>   Merkle root over this message's evidence-root set
   causal_depth: u8          saturating derivation counter
   calib_ref   : bytes<8>    pointer to the EXTERNALLY-ASSIGNED calibration record
   corr_class  : bytes<8>    correlation-dimension digest (§14.3)
   ⟹ **Constant size. Independent of N, of root cardinality, of depth.**
   ⟹ Supports: §13.4's receiver recomputation, §14.4's independence check,
                R12.1's no-downgrade rule.

TIER 2 — LOCAL/REGIONAL, CONTINUOUS, ZERO NETWORK TRAFFIC
   Per-subject and per-region append-only event logs with local Merkle trees,
   retaining: (msg_id, type, channel, seq, epoch, root_commit, causal_depth,
               dst-class, outcome-state from §6.2, cost_measured).
   **NOT payloads** (§59's auditability-without-readability, §86's budget).
   ⟹ O(events) local. Supports: exact causal reconstruction OFF-LINE (§10.3),
                                  replay-window enforcement (§32),
                                  §61's minimum sufficient record.

TIER 3 — ANCHORED, PERIODIC, O(R) PER EPOCH
   Regional Merkle roots → the distributed Anchor, with W_min witnesses of
   which ≥1 is outside operational control (P0-02 §20.2, EIK-INV-27).
   Plus: the epoch ROOT REGISTRY (all emitted root commitments), which is
   what makes Tier-1 membership proofs EXACT rather than probabilistic.
   ⟹ O(R) per epoch + O(governance events). **Never O(messages).**

⟹ **R15.1 (THE LIE-WINDOW, INHERITED AND BOUNDED).** Between anchors, a
   subject's Tier-2 log is organism-owned and can misrepresent recent
   history. **P0-02 R20.1 applies verbatim: no consequential decision may
   rest on unanchored provenance.** ⟹ The lie-window is bounded by what a
   lie can be USED FOR, not by its duration — which is the stronger
   guarantee, and the one that survives an unbounded epoch length.

⟹ **R15.2 (WHAT THIS COSTS).** Tier 1's commitment cannot be enumerated
   from the message. **A receiver can prove that root r ∈ commit, but cannot
   list the commit's contents without the anchor.** ⟹ Exact independence
   checking (§14.4) requires Tier-3 access, which is epoch-delayed.
   **Local checking is Bloom-approximate and may produce FALSE INDEPENDENCE
   (two disjoint-looking commits whose sets actually overlap).** ⟹
   **COMM-INV-03's enforcement is therefore two-stage: local approximate,
   anchored exact — and any consequential aggregation waits for the anchored
   stage.** (§14.4's EVA recomputation.)
```

---

# §16. MESSAGE TRANSFORMATION — AND PROVENANCE LAUNDERING

## 16.1 «Is C receiving A's evidence, or B's claim about A's evidence?»

> ### **B's claim. Always. And the contract must say so in the type system, not in a comment.**

```
A → B → C.  B transforms A's message and emits to C.

WHAT C ACTUALLY RECEIVES:
  • a message SIGNED/BROADCAST by B, on B's channel
  • whose payload is B's transform of A's content
  • whose sufficient statistics are **B's**, computed by B's aggregation rule
  • whose calibration class is **B's** (`calib_ref` → B's record)
  • whose `causal_depth` is A's + 1
  • whose `root_commit` **MUST include A's roots** (COMM-INV-08)

⟹ **C receives B's CLAIM, WARRANTED BY B'S CALIBRATION, RESTING ON A'S
   ROOTS.** Three distinct provenances, and conflating any two is a defect:
     A's roots      → what the claim is ABOUT      (evidence provenance)
     B's statistics → how strongly B asserts it    (production provenance)
     B's calib_ref  → how accurate B usually is    (producer provenance)

⟹ **AND THIS IS WHY §11.2 REJECTED `FEATURE` AS A TYPE.** A "feature" is
   B's transform of A's observation. If it travels as type SENSOR, it
   inherits SENSOR's warrant — **which is A's warrant, not B's.** The
   transform's reliability becomes invisible, and B's error is attributed
   to the world rather than to B. **Typing a derived quantity as an
   observation is the most common provenance defect in measurement systems,
   and the type partition closes it.**
```

## 16.2 The five required definitions

| Term | Definition | **Rule** |
|---|---|---|
| **Original provenance** | The evidence-root set of the originating observation(s) | **Inherited under transformation, never dropped (COMM-INV-08)** |
| **Transformation** | A function applied by B to A's payload, producing B's payload | Must be declared by `type` + `payload_type`. **An undeclared transformation is laundering** |
| **Derived claim** | B's assertion, warranted by B's calibration, resting on inherited roots | **Warrant class ≤ the minimum of the inputs' classes** (P0-01 R15.6 monotone non-amplification) |
| **Inherited uncertainty** | The inputs' sufficient statistics, propagated through B's aggregation rule | **B's aggregate must be no tighter than its inputs justify.** A transform that reduces `epistemic_var` without adding an observation is fabricating precision |
| **Transformation reliability** | **B's externally-assigned calibration class *for that transform type*** | **Not B's general reliability.** A cell accurate at classification may be inaccurate at aggregation. **`calib_ref` is therefore typed: `(producer, type) → calibration record`** |

## 16.3 Provenance laundering — the four forms and their closures

| Form | Attack | **Closure** |
|---|---|---|
| **L1 ROOT DROPPING** | B emits A's content with **no** `root_commit`, presenting it as its own observation | **R12.1: an S2 message without `root_commit` is MALFORMED, not downgraded.** A transform must either carry inherited roots or carry a *new* root — and a new root requires a new observation (P0-01 R6.1's E0 prohibition) |
| **L2 ROOT REWRITING** | B replaces A's roots with **its own** observation record, making A's content appear freshly sourced | **COMM-INV-08: roots are inherited under transformation. A new root may be ADDED (B's own observation) but an inherited root may not be REMOVED.** Removal is detectable: the anchored Tier-2 log records B's inputs, so a claim whose roots do not include its inputs' roots is inconsistent with the log |
| **L3 DEPTH RESETTING** | B sets `causal_depth = 0` on a depth-5 derivation, making a heavily-derived claim look like an observation | **`causal_depth` is monotone non-decreasing along a chain and is checked at ingress: a message whose depth is less than any of its declared inputs' depths is MALFORMED.** *Saturating at 255, and saturation is itself a rejection condition for warrant-bearing classes* |
| **L4 TYPE ESCALATION** | B re-emits A's `HYPOTHESIS` as an `ASSERT`, or A's `STATUS` as an `OBSERVATION` | **§12.1's type partition + §12.3's rule that a derived claim's class ≤ min(inputs).** **Type escalation across a transform is a class increase, and class increase requires RO-13 (§72).** ⟵ This is P0-02's «A4 UNREGISTERED can never reach D6 DEPLOYED» in communication form: **promotion is earned by governance, never by propagation** |

**R16.1 (THE LAUNDERING PRINCIPLE).** *Provenance laundering is the acquisition of warrant by transformation. Every form is closed by the same rule: **warrant may be inherited, preserved, or weakened by a transform; it may never be increased.** * **This is P0-01 R15.6/R15.7 (monotone non-amplification, no upward flow) applied to the communication layer, and it is the reason the alethic lattice extends naturally to messages: a message occupies a rung, and transformation can only move it down.**

---

# §17. TRUST VS PROVENANCE — **OUTPUT 18**

## 17.1 «Do not conflate trusted sender with true information, or known provenance with correct information»

**The six-way separation the brief requires:**

| Concept | Definition | **Producer** | **Plane** | Can it be forged? | Does it imply the next? |
|---|---|---|---|---|---|
| **IDENTITY** | Which subject this is: `cell_id`, `lineage_id`, `generation`, `variant`, `region_id` | **Registrar (GP), under KC-1 delegation** (P0-02 §2.3) | Transport | ❌ Not without key compromise | ❌ |
| **AUTHENTICITY** | This message was produced by that identity (or by a channel bound to it) | Channel binding (S1/S2) · signature (S3/S4) | Transport | ❌ Not without key compromise | ❌ **⟵ THE CRITICAL NON-IMPLICATION** |
| **PROVENANCE** | What this message is derived from: `root_commit`, `causal_depth`, transformation type | Sender (commitments), verified against the anchor | **Warrant** | ⚠️ **Omission is possible; fabrication fails resolution** | ❌ |
| **RELIABILITY** | How often this channel delivers intact and on time | **Measured by transport** (Cell §14.5: «A cell may not write its own `reliability`») | Transport | ⚠️ **Yes — by simply not dropping packets (§5.2)** | ❌ |
| **EPISTEMIC TRUTH** | Whether the claim corresponds to ℛ | **Nobody, in general.** EVA measures *agreement with ground truth* (P0-01 L0–L6); truth itself is L0 | **Alethic, external** | — | — |
| **AUTHORIZATION** | Whether this subject may perform this operation | **KC-2** (P0-02) | **Deontic, external** | ❌ Not without root compromise | ❌ |

## 17.2 **OUTPUT 18 — the trust/authenticity model**

```
THE FOUR IMPLICATIONS THAT HOLD:
   authenticity  ⟹ identity is as claimed
   authorization ⟹ the authorizing principal permitted this operation
   provenance    ⟹ the derivation is as declared (**if it resolves**)
   reliability   ⟹ the channel has historically delivered

THE SIX IMPLICATIONS THAT DO NOT HOLD — AND EACH IS AN ATTACK IF ASSUMED:
   authenticity  ⟹̸ truth          **«A perfectly authentic malicious message
                                     remains malicious» (§33). COMM-INV-01**
   provenance    ⟹̸ correctness    **«Known provenance ≠ correct information».
                                     A fully-provenanced claim can be wrong,
                                     and its provenance makes the error
                                     *traceable*, not *absent*. COMM-INV-02**
   reliability   ⟹̸ trustworthiness **§5.2: an ACK attests to states 2–5,
                                     never to 8. A 100%-reliable channel
                                     carrying worthless claims is reliable.
                                     R0.3's transport⟶warrant prohibition**
   identity      ⟹̸ competence     **A correctly-identified C0 cell is still
                                     a C0 cell. Cell Contract §15's
                                     capability classes are not identity**
   consensus     ⟹̸ independence   **§14/§36. COMM-INV-03**
   propagation   ⟹̸ authority      **§40. A cell-generated message that is
                                     relayed by ten million cells is still
                                     cell-generated. COMM-INV-04 — and this
                                     is P0-02's NAUL-1 applied to
                                     communication: knowledge of a rule is
                                     not a licence under it, and relaying a
                                     governance-shaped message is not
                                     issuing one**
```

**R17.1 (THE TRUST VOCABULARY RULE).** *The word «trust» is prohibited without a subscript.* The admissible forms: **`trust_authenticity`** (transport, verifiable) · **`trust_reliability`** (transport, measured) · **`trust_out_assigned`** (warrant, externally assigned — the Cell Contract's existing term, preserved) · **`trust_epistemic`** (alethic, EVA's, never transmitted as a scalar). **V3 §8's flat «trust score» and V3.1 §6's plastic «trust» are both prohibited forms** — the first because it is unqualified, the second because it makes a warrant quantity learnable (R3.2).

**R17.2 (WHERE EACH QUANTITY LIVES — the anti-conflation table).**

| Quantity | **May be written by** | **May be read by** | **May be learned?** | **May be inherited?** |
|---|---|---|---|---|
| `weight` / gain | The cell (within bounds) | The cell | ✅ **Yes — this is plasticity** | ❌ Not heritable (Cell Contract §3.4: «connection weights» are explicitly NOT heritable) |
| `context_sensitivity` | The cell | The cell | ✅ | ❌ |
| `plasticity_rate` | Genome (priors) + policy (bounds) | The cell | ⚠️ Within policy bounds | ✅ **As a prior, not as a value** (§68 X-G) |
| `reliability` | **Transport measurement only** | Cell (read), EVA | ❌ **Measured, not learned** (Cell §14.5) | ❌ |
| `latency_measured` | **Transport measurement only** | Cell (read) | ❌ | ❌ |
| `trust_out_assigned` | **EVA** (P0-02 R8.7) | Cell (**read-only**), organism | ❌ **V3.1 §6's «synapse plasticity: trust» is REJECTED (R3.2)** | ❌ |
| `calibration_class` | **EVA** | Cell (read-only) | ❌ | ❌ |
| `pruning_score` | **Organism Topology Service** (not «the kernel» — §68 X-A1) | Cell (read) | ❌ | ❌ |
| `mandatory_path` | **Set at creation, by policy** | All | ❌ **Immutable by any operator** (Cell §14.1) | ✅ As a structural prior |
| `conn_type` | **Set at creation** | All | ❌ **Immutable for the connection's life** (§19) | ✅ |
| `root_commit` | The producing cell | All | ❌ | ✅ **Inherited under transformation (COMM-INV-08)** |

---

*End of Volume A. Volume B (`18_analysis_synapse_network.md`) covers §18–§29: synaptic weight decomposition, the plasticity boundary, connection creation/deletion authority, locality, addressing, routing, topology, the `O(N²)` constraint, bandwidth and latency economics, and communication failure.*
