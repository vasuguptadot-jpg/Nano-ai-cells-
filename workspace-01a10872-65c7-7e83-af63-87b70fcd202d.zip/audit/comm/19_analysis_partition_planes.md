# P0-03 — COMMUNICATION, DIGITAL SYNAPSE & SIGNAL CONTRACT
## Volume C: Partition, Attack Surface, Planes, and the Workspace (§30–§47)

**Companions:** `17_analysis_signal_message.md` (A) · `18_analysis_synapse_network.md` (B) · `20_analysis_evolution_hardware.md` (D) · `21_analysis_adversarial_contradiction.md` (E) · `22_analysis_formal_invariants.md` (F) · `23_analysis_interfaces_testability.md` (G) · `24_v4_communication_synapse_signal_spec.md` (**Output 42**)
**Outputs delivered here:** **19** (security model, part 1) · **20** (plane separation) · plus the partition/reconciliation model, the cascade and amplification analysis, and the workspace/attention/memory interfaces

---

# §30. NETWORK PARTITION

## 30.1 The scenario and the six questions

```
        Region A        ✕        Region B
   (relay_A unreachable from relay_B; both continue to operate internally)
```

| Question | Answer |
|---|---|
| **Do both regions continue?** | ✅ **YES — and this is a requirement, not a concession.** P0-02 §26 established that partition is *normal*, not exceptional. **A communication architecture that halts on partition has made liveness depend on a network property it does not control** |
| **Can they learn independently?** | ✅ **YES, within their local envelope.** Learning is purely local (§22.2): eligibility traces, gated error, `gain` bounds. **Nothing in Cell §9's learning rule requires a global artifact.** ⟹ Partition does not stop learning; it stops *comparison* |
| **How is state divergence handled?** | **§31's four reconciliation operators, applied per object class.** Divergence during partition is expected and is not an error |
| **How are memory conflicts reconciled?** | **UNION for append-only records; RE-EVALUATE for derived state; never vote (§31.3).** P0-02 EIK-INV-08: corrections supersede, never overwrite |
| **How is identity preserved?** | **`cell_id` is permanent, never reused, never re-issued (R23.1).** Addresses are reassignable; identities are not. **A partition cannot create an identity conflict, because identity issuance requires a Registrar under KC-1 delegation, and RO-01 is a reserved operation that stalls under partition (P0-02 §6.2's «Partition ⇒ `FC` for irreversible»)** ⟹ **no new subjects are instantiated during a partition, which is the single most important partition safety property and it is inherited, not designed here** |
| **How does reconnection occur?** | **§31.5's five-phase protocol** |
| **How is duplicated work handled?** | **Accepted as a cost, not reconciled as a conflict.** Two regions that both solved the same sub-problem produce two results; **§31.3's RE-EVALUATE picks the better one by measurement, and the other is archived as a lineage fork.** *Duplicated work is waste, and waste is a resource-governance question (P0-02 §18), not a correctness question* |

## 30.2 What continues and what stops — the class-dependent partition matrix

> **This is P0-02's partition-by-irreversibility, applied to communication classes. The discriminator is the same: *what cannot be undone must not be done without a live authority.***

| Traffic | During partition | **Why** |
|---|---|---|
| **S0** (activation, modulation) | ✅ **Full, local** | No warrant, no coordination, no consequence beyond the neighborhood |
| **S1** within region | ✅ **Full** | Local |
| **S1** cross-region | ❌ **Stalls** | No route. **Timeout visible to the requester (§7.2)** |
| **S2** within region | ✅ **Full, with a degraded warrant property** | **Local independence checking is Bloom-approximate (§15.3 R15.2); the anchored registry is unreachable, so exactness is unavailable.** ⟹ **R30.1: during a partition, no consequential aggregation may complete, because P0-02 R20.1 forbids consequential decisions on unanchored provenance** |
| **S3/S4** | ❌ **STALL (`FC`)** | Governance, verdicts, safety commands, and anchored provenance all require an authority that is not locally present. **P0-02 §6.2: «Partition (KC ↔ region) | Irreversible | `FC` — the region may not proceed»** |
| **KC-3 ceilings** | ✅ **CONTINUE** | **P0-02 EIK-INV-31: ceilings are local and partition-surviving.** ⟹ **Containment does not depend on connectivity, which is the most important safety property in this section** |
| **Immune detection** | ✅ Continues | Detection is unrestricted (P0-02 §8.2) |
| **Immune adjudication** | ⚠️ **Within pre-committed budget only** | **P0-02 EIK-INV-44: quarantine may proceed under budget during a KC outage; restore may not** |
| **Learning** | ✅ Continues locally | §30.1 |
| **Structural plasticity** | ⚠️ **Within envelope only** | Above-envelope RO-05/06 stalls |
| **Replication** | ❌ **Stalls** | RO-03, reserved, irreversible-class |
| **Homeostasis** | ✅ Continues within ceiling | P0-02 §7.4's negative authority |

**R30.2 (THE PARTITION INVARIANT).** *During a partition, every locally-continuing activity is bounded by a ceiling that survives the partition, and every activity that could produce an irreversible or externally-reaching consequence stalls.* **⟹ A partition narrows what the organism may do; it never widens it.** This is P0-02 EIK-INV-17 («uncertainty is never permission») applied to connectivity: **an unreachable authority is never an absent requirement.**

## 30.3 The failure mode partitions create that is usually missed

> **A partition does not merely stop communication. It stops COMPARISON — and comparison is the only mechanism that detects a locally-consistent error.**

```
DURING A PARTITION, REGION A:
  • learns from its own prediction errors           ⟹ locally coherent
  • aggregates its own evidence                     ⟹ locally confident
  • adapts its topology within its envelope         ⟹ locally optimal
  • measures its own reliability                    ⟹ locally good
  • **and has NO external input against which any of
     this could be contradicted**

⟹ **This is P0-01's CD-8 (sim-to-real) in miniature: «internally coherent,
   mutually consistent, and detached from ℛ — with no internal signal
   detectable.»** A partitioned region is a simulator of itself.

MITIGATIONS, AND THEIR LIMITS:
  ✅ KC-3 ceilings still bind           ⟹ containment holds
  ✅ P0-02 R20.1                        ⟹ no consequential decision on
                                          unanchored provenance, so a
                                          partitioned region cannot promote,
                                          prune, deploy, or replicate
  ✅ Epoch advance requires governance   ⟹ **a partitioned region cannot
                                          advance its own epoch, so its
                                          artifacts become stale on
                                          reconnection (§9.2 Rule 3's
                                          monotone-restrictive property)**
  ⚠️ Local confidence still rises        ⟹ **a partitioned region becomes
                                          MORE confident, not less, because
                                          it keeps aggregating without
                                          external contradiction. This is
                                          bounded by R30.1 but it is not
                                          eliminated**
  ❌ Nothing detects local drift         ⟹ **§91 OR-C6: partition-era drift
                                          is detectable only retrospectively,
                                          on reconnection, by comparison**

⟹ **R30.3: a partition is a WARRANT-FREEZE event, not merely a
   transport failure.** Everything continues except the ability to
   establish anything. **Stating it this way is what prevents an
   implementation from treating reconnection as "resume" rather than as
   "adjudicate."**
```

---

# §31. SPLIT-BRAIN SCENARIO

## 31.1 «Which state wins?» — why the question is malformed

> ### **The question assumes a single winner per system. The correct question is asked per object class, and there are four answers, none of which is voting.**

**The brief prohibits simple majority voting, and the prohibition has a concrete justification: majority voting over *derived* state produces a state that was never evaluated.** Two halves that diverged for many epochs have parameters whose average is not a point either half occupied, and **P0-01's entire fitness apparatus applies to evaluated subjects, not to interpolations of them.** *Averaging also destroys the information that they disagreed — which is P0-01 R28.2's exact objection to averaging DISPUTED verdicts.*

## 31.2 The four reconciliation operators

| Operator | Semantics | **Applies to** | Authority |
|---|---|---|---|
| **UNION** | Both records are retained; neither is discarded; conflicts are impossible because the record class is append-only and root-distinct | **Facts · provenance records · event logs · observation records · the anchored root registry** | **Automatic.** Append-only ⟹ union is the only well-defined operation |
| **RE-EVALUATE** | Both variants are retained; **EVA measures both against a common post-reconnection probe set; the better is adopted; the other is archived** | **Learned parameters (`θ`, `gain`) · beliefs · predictions · specialized circuits · routing preferences** | **EVA (alethic) + KC-2 for any adoption that is a reserved operation** |
| **FORK** | Both lineages are declared legitimate; generation counters diverge and the divergence is recorded as a fork event; **selection subsequently decides** | **Evolutionary state · lineage · population composition · repertoire** | **Automatic + anchored. Never "which wins" — the answer is "both, and fitness will decide"** |
| **VOID** | One side's record is declared invalid because it lacked authority when made | **Policy changes made without OP · subjects instantiated without RO-01 authorization · deployments without a Stage witness · restores without RO-08** | **KC-2 + OP. P0-02 §6.2: «Partition (KC ↔ OP) | Constitutional/policy change | `FC` — no rule changes without OP»** |

## 31.3 The seven object classes the brief names

| Object | **Operator** | **Reasoning** |
|---|---|---|
| **Facts** (observations, GT-bearing records) | **UNION** | Two regions observed different things. **Both observations happened.** A fact from region A is not invalidated by region B's ignorance of it. *Conflicts are impossible for facts with distinct roots; apparent conflicts are conflicts of interpretation, which belong to the next row* |
| **Beliefs** (assertions, hypotheses, aggregates) | **RE-EVALUATE — and until then, DISPUTED** | Two regions believe different things. **Neither is refuted by the partition.** ⟹ **Both are marked `DISPUTED` (P0-01 R28.2: selection suspended, disagreement escalated, never averaged), and EVA re-measures.** *A belief is a claim, and claims are adjudicated by measurement, not by counting believers* |
| **Learned parameters** (`θ`, `gain`, `context_sensitivity`, eligibility traces) | **RE-EVALUATE** | **Cannot be merged.** An average of two diverged parameter vectors is a system that was never evaluated, may be worse than both, and has no provenance. ⟹ **Post-reconnection probe set; the winner is adopted; the loser is archived and remains restorable for `ROLLBACK_DEPTH` epochs (P0-02 §21's RB-2 pattern)** |
| **Evolutionary state** (lineage, generation, repertoire, archive niches) | **FORK** | Both are legitimate descent lines. **P0-01's MAP-Elites archive admits a candidate if it improves an occupied niche OR occupies an empty one — so two diverged repertoires are, from the archive's perspective, two niches, and both are retained.** *Merging lineages would falsify descent, which corrupts drift statistics and P0-01's gate G16 (lineage distance)* |
| **Provenance** | **UNION** | Append-only, hash-chained, root-distinct. **Union is the only operation that preserves both chains.** A region that anchored during the partition contributes its roots; a region that did not contributes its Tier-2 logs for late anchoring, **and any decision that rested on that unanchored provenance is retroactively marked as having rested on unanchored provenance (P0-02 R20.1)** |
| **Identity** | **NEITHER — the conflict cannot arise, and if it does, it is a violation** | `cell_id` is Registrar-issued under KC-1 delegation and RO-01 is reserved, so **no subject can be instantiated during a partition (§30.1).** If the same `cell_id` appears in both halves, one is forged or the partition preceded a fork that was not authorized ⟹ **both are quarantined pending adjudication (P0-02 §8.2), and the incident is a root-level integrity event** |
| **Task progress** | **DECLARED UNKNOWN** | **Progress claimed during a partition has no external witness.** P0-02 R20.1 ⟹ it cannot support promotion. **Both halves' progress claims are retained as UNANCHORED and are admissible only as evidence for re-measurement, never as a basis for a consequential decision** |

## 31.4 The three things that must not be reconciled at all

```
1. **POLICY.** Only one policy version can be active. **The pre-partition
   authenticated version wins.** Any policy change made in a half without OP
   authorization is VOID — not "the other half's version," not "the newer
   one," not "the one with more support." **P0-02 §7.2's change classes all
   require RO-12/RO-13/RO-14, all of which require OP, and OP is external.**
   ⟹ **A partition during which a region "adapted its governance" has
      produced an artifact that is not a policy, and §38.3's D-S-class
      review treats it as an incident.**

2. **EPOCH.** The epoch counter is governance-issued (§9.2 Rule 3). **A
   partitioned region cannot advance its epoch.** On reconnection, the
   region with the lower epoch adopts the higher one, and **all of its
   epoch-bound artifacts from the partition period are stale by
   construction** (P0-02 EIK-INV-14). ⟹ This is why §30.3's monotone-
   restrictive property matters: **the partitioned half's work is not
   destroyed, but it cannot be acted upon without re-validation.**

3. **TRUST AND CALIBRATION ASSIGNMENTS.** These are EVA's (§17.2 Group 3).
   **A region that re-computed its own trust during a partition has
   performed self-verification, which Cell §7.3 forbids.** ⟹ All
   partition-era `trust_out_assigned` and `calibration_class` values are
   VOID; EVA re-derives them post-reconnection.
```

## 31.5 The reconnection protocol

```
PHASE 1 — DETECT AND FREEZE CONSEQUENTIAL ACTIVITY
  Relays re-establish. **Before any state exchange:** both sides enter a
  RECONNECTING state in which no consequential decision may complete
  (promotion, pruning, deployment, replication, restore).
  ⟵ Necessary because each side has been operating under R30.3's
    warrant-freeze, and neither knows what the other concluded.

PHASE 2 — ESTABLISH EPOCH AND POLICY PRECEDENCE
  Compare epoch counters and policy version references.
  **The higher epoch and the last commonly-authenticated policy version
  govern.** Anything else is VOID (§31.4).
  ⟹ Deterministic. **Two implementations reach the same answer.**

PHASE 3 — UNION THE PROVENANCE
  Exchange Tier-3 anchored roots and Tier-2 logs. **Append-only union.**
  Late-anchored records are marked as late-anchored, and every decision
  that rested on them during the partition is flagged retroactively.
  ⟹ O(R) digests + O(partition-duration) log volume. **Never O(N).**

PHASE 4 — ADJUDICATE THE DIVERGENT
  • Beliefs in conflict ⟹ DISPUTED, escalated (P0-01 R28.2)
  • Learned parameters ⟹ EVA re-evaluates both on a common probe set
  • Lineages ⟹ FORK, anchored, both retained
  • Identity anomalies ⟹ quarantine + root-level incident
  • Task progress ⟹ UNKNOWN, re-measure
  ⟹ **This phase is the expensive one, and its cost is O(divergence), not
     O(N). A short partition produces little divergence.**

PHASE 5 — RE-BASELINE AND RESUME
  Topology Service reconciles the connection registries (union of edges;
  edges closed in one half during the partition are CLOSED in both —
  **closure is monotone, because reopening a closed edge is a creation and
  requires the handshake**). Re-issue delegation certificates
  (P0-02 §31.1's 5→2 transition pattern). Resume.
  ⟹ **The reconnection is a governance event, is anchored, and is
     observable (P0-02 EIK-INV-53).**
```

**R31.1 (THE SPLIT-BRAIN PRINCIPLE).** *«Which state wins?" is the wrong question. The four questions are: **Can both be true?** (facts ⟹ UNION) · **Can both be evaluated?** (parameters, beliefs ⟹ RE-EVALUATE) · **Can both be legitimate?** (lineage ⟹ FORK) · **Can only one be authorized?** (policy, epoch, trust, identity ⟹ VOID). **No mechanism in this contract votes.***

---

# §32. DUPLICATION / REPLAY ATTACK

## 32.1 «Can replay create artificial evidence, reward, demand, learning, activity, or exhaustion?»

| Artificial quantity | Achievable by naive replay? | **Why / why not** |
|---|---|---|
| **Artificial evidence** | ⚠️ **YES if dedup is absent; NO with it** | A replayed S2 message has the same `msg_id` ⟹ DUPLICATE (§6.2) ⟹ counted, dropped, **never increments `n_obs`**. **But a replay with a NEW `msg_id` and the SAME `root_commit` is not a transport duplicate — it is §6.1 R6.1's CONFLATED case, and only §14.4's root intersection catches it.** ⟵ **This is why two dedup mechanisms are required and one is not** |
| **Artificial reward** | ❌ **NO — structurally** | Reward is S3, `source = EVA_ONLY` (P0-01 R6.7), and **«a cell signature on `eval.reward.v1` is structurally invalid — S1 rejects it»** (Cell §6.2). Replay of a *genuine* reward message is caught by epoch binding (P0-02 EIK-INV-14): a reward from epoch `e` is refused at epoch `e+1` |
| **Artificial demand** | ⚠️ **YES — and this is the cheapest attack in the suite** | `RESOURCE` is S1 and best-effort with periodic re-assertion (§7.2), so replaying a demand signal is indistinguishable from legitimate re-assertion. **Defence: demand is metered against actual consumption (P0-02 §18.3's attribution), and a demand signal unsupported by measured consumption is an anomaly (Cell §4.1's `cost_declared` vs `cost_measured` divergence, applied to demand)** |
| **Artificial learning** | ❌ **NO, if R29.2 holds** | Learning triggers require a *gated* error signal (Cell §9.2 T1–T4), and **only an EVA-signed `eval.error.v1` is a learning signal — «a `REPORT_ERROR` from a peer is not»** (Cell §9.5 step 4). Replay of a peer error report produces no `Δθ`. **Replay of a genuine `eval.error.v1` is caught by epoch binding + `msg_id`** |
| **Artificial network activity** | ✅ **YES — trivially** | Replay generates traffic, and traffic costs bandwidth, ingress validation, and dedup lookups. **This is §34's flooding attack with a cheaper generator** |
| **Resource exhaustion** | ✅ **YES — the actual objective** | **The dedup cache itself is the target.** Cell §6.3 case 5 specifies a «dedup cache (`msg_id` bloom filter, **bounded**)». A bounded cache **evicts**, and evicted `msg_id`s become replayable. **⟹ §32.2's retention rule** |

## 32.2 The replay-protection model

```
FOUR MECHANISMS, AND THE FOURTH IS THE ONE THAT IS USUALLY MISSED:

1. **`msg_id` DEDUP (UUIDv7).** Catches verbatim replay within the cache
   window. **Cost: O(1) lookup, O(cache) state.**

2. **`seq` PER (channel, epoch).** Catches replay that omits or reorders,
   and detects gaps. **§8.3's scope correction keeps this O(degree) state
   rather than O(peers × conversations).**

3. **EPOCH BINDING (P0-02 EIK-INV-14).** An artifact valid in epoch `e` is
   refused in epoch `e+1`. **Epoch advance is a mass-revocation mechanism
   (P0-02 R19.3), so the replay window is bounded by the epoch length for
   every class simultaneously.**

4. **⟵ THE MISSED ONE: THE DEDUP SET MUST OUTLIVE THE MESSAGE.**
   §6.2's EXPIRED state is «terminal for ACTION, not for RECORD», and the
   `msg_id` is retained in the dedup set past expiry. **Why this matters:**
   a bounded cache that evicts by recency will evict exactly the old
   `msg_id`s that a patient attacker replays. **A replay attack with a
   period longer than the cache retention is undetectable by mechanism 1.**

   ⟹ **R32.1: the dedup retention window MUST be ≥ the maximum epoch
      span in which a replayed artifact could still be accepted.** Since
      mechanism 3 refuses cross-epoch artifacts, retention needs only to
      cover the current and previous epoch — **which makes the bound
      computable rather than arbitrary**: `retention ≥ 2 × epoch_length`
      of `msg_id`s per channel.
   ⟹ **And for S3/S4, retention is permanent in the anchored log**, because
      a replayed governance artifact is the highest-consequence replay and
      P0-02 §20's append-only anchor already stores it.

THE INTERACTION THAT MAKES THE SET SUFFICIENT:
  verbatim replay           ⟹ caught by 1 (within window) or 3 (across epochs)
  replay with new msg_id    ⟹ **same root_commit** ⟹ caught by §14.4's
                              intersection (CONFLATED, not DUPLICATE)
  replay with new root      ⟹ **that is not a replay; it is a fabricated
                              observation**, and P0-01 R6.1's E-gates plus
                              root resolution against the anchored registry
                              apply (§67 #9/#10)
  replay of a governance act⟹ caught by 3 + 4-permanent + signature + the
                              idempotence requirement (R7.3)
```

**R32.2 (THE HONEST RESIDUE).** *Replay of **S0/S1 best-effort traffic** is not caught and is not worth catching.* S0 has no warrant and S1 has no evidential claim, so a replayed S1 REQUEST produces a duplicated response — **which is a resource cost, not a belief error.** ⟹ **§34's rate limiting, not §32's dedup, is the correct defence there, and applying dedup to S0 would cost more than the attack.** *A protection whose cost exceeds the attack's is not a protection.*

---

# §33. MESSAGE FORGERY

## 33.1 «A malicious cell sends `source = trusted_cell`»

```
THE DEFENCE, AND ITS EXACT SCOPE:

  S0  no identity ⟹ **forgery is meaningless**: an S0 signal is attributed
      to the edge it arrived on, and an edge has two registered endpoints.
      Injecting onto someone else's edge requires transport-layer access,
      which is a platform compromise, not a message forgery.
  S1/S2  channel binding (P0-02 R19.2) ⟹ a message on channel C is
      attributed to C's bound identity. **A cell cannot open a channel
      bound to another identity, because channel establishment requires a
      delegation certificate (P0-02 I16) that KC-1 authenticates.**
  S3/S4  per-message signature ⟹ forgery requires the principal's key.

  ⟹ **`source = trusted_cell` on a self-constructed message fails at
     ingress: the channel it arrived on is bound to the forger, and the
     mismatch between declared `src` and channel binding is detected at
     §5.1 state 4 (AUTHENTICATED).**

  ⟹ **COMM-INV-01's enforcement point: `src` is DERIVED FROM THE CHANNEL,
     NOT READ FROM THE PAYLOAD.** A sender-declared `src` field is not
     evidence of source; it is a claim, and it is checked against the
     channel binding. **§4.2 classified `source identity` as mandatory —
     and this is the mechanism that makes it non-forgeable rather than
     merely present.**
```

## 33.2 «A perfectly authentic malicious message remains malicious»

> ### **This is the sentence that separates a security model from a warrant model, and the contract must not blur it.**

```
AUTHENTICITY ANSWERS:  who sent this?        ⟹ closed by §33.1
TRUTH ANSWERS:         is it correct?        ⟹ **closed by nobody, ever**

THE GAP BETWEEN THEM IS WHERE EVERY INTERESTING ATTACK LIVES:
  • A cell with a valid key and a faulty transform sends an authentic,
    well-provenanced, confidently-stated, WRONG assertion.
    **Every transport and warrant mechanism in this contract passes it.**
  • A cell with a valid key that has been selected for producing
    high-scoring outputs sends an authentic message that games the
    objective (§47).
  • A cell whose `calib_ref` correctly reports poor calibration sends an
    authentic message that is nonetheless believed, because the receiver
    did not perform §13.4's recomputation.

⟹ **R33.1: authentication is a TRANSPORT-plane property and discharges
   attribution only.** P0-02 R19.4 states it for signatures («a signature
   proves origin, not truth»); this contract states it for channels:
   **a channel binding proves origin, not truth.**

⟹ **AND THE CONSEQUENCE FOR DESIGN: the defence against authentic-but-wrong
   messages is NOT cryptographic. It is:**
     1. §13.4's receiver recomputation (calib_ref ⟹ a poorly-calibrated
        source is discounted by the receiver, not by the transport)
     2. §14.4's independence checking (one wrong source cannot become
        consensus)
     3. **EVA's external measurement (P0-01) — the only mechanism in the
        architecture that can detect an authentic wrong claim, because it
        compares against ℛ rather than against the claimant**
     4. P0-01's L3 REDUNDANT INDEPENDENT + R8.5's declared independence
        argument

⟹ **COMM-INV-01 (restated with its enforcement): authenticity does not
   imply truth, AND NO MECHANISM IN THE COMMUNICATION LAYER MAY BE
   INTERPRETED AS ESTABLISHING TRUTH.** The communication layer's job ends
   at attribution. **Any design in which "verified" means "correct" has
   conflated §17.1's rows 2 and 5, and §88's false-precision audit treats
   the bare word «verified» as a defect for exactly this reason.**
```

---

# §34. MESSAGE FLOODING

## 34.1 The seven consequences and their owners

| Consequence | Affected | **Defence owner** |
|---|---|---|
| **Bandwidth exhaustion** | Transport | **Cell** (token bucket, Cell §S8: «Enqueue to connection targets subject to token bucket; respect fanout cap; backpressure on congestion») + **homeostasis** (allocation within ceiling) + **KC-3** (the ceiling itself) |
| **Attention hijacking** | Attention Controller | **Organism** — §44: attention is admission control, and admission is budgeted |
| **Memory exhaustion** | Memory | **Organism Memory Service** + cell-local bounded caches (Cell §6.3's bounded dedup cache) |
| **Evaluator overload** | **EVA** | **EVA's own budget `B`** (P0-01 §28's racing/successive halving) — **and note this is NOT the organism's to defend: flooding the evaluator is a governance incident, not a traffic problem (§34.3)** |
| **Homeostasis instability** | Homeostasis | **KC-3 ceiling** — homeostasis allocates within a ceiling it cannot raise (P0-02 §7.4) |
| **Global workspace flooding** | Workspace | **§43's admission competition + capacity limit** |
| **Verification overload** | Warrant | **§7.2's class assignment: verification cost is `O(S2+ messages)`, and S0/S1 are channel-bound, so flooding cheap traffic does not create verification load** |

## 34.2 «Determine what belongs to cell / local circuit / region / homeostasis / EIK»

> ### **R34.1 — the five-principal rate-limiting split, and it is P0-02 §7.4's resource split applied verbatim.**

```
CELL          • token bucket on emission (Cell §S8)
              • fanout cap (genome: `max_fanout`)
              • **influence budget: fan_out × gain ≤ budget per window (§35)**
              • retry budget (§7.4 R7.2: retry is a privilege)
              • bounded local caches
              ⟹ **O(1) local, no coordination. This is where 99% of flood
                 defence happens, and it happens without anyone's permission.**

LOCAL CIRCUIT • aggregate emission rate over members
              • local shedding under congestion (Cell §13: «shed by priority;
                aggregate/summarize»)
              • backpressure propagation to the sender
              ⟹ O(circuit), local

REGION        • relay admission control and queue discipline
              • region-crossing rate limits (**especially on OPAQUE, §50**)
              • per-region traffic digests (O(R) per epoch, §15.3 Tier 3)
              • **refusal-rate statistics (§20.2 R20.2) as the flooding
                detector**
              ⟹ O(R)

HOMEOSTASIS   • allocation of bandwidth within the ceiling
              • congestion response (§83): reduce admission, increase
                shedding, prune low-value connections
              • **NEGATIVE AUTHORITY: acts first, is vetoable (P0-02 §7.4
                R7.6) — which is what makes it fast enough to matter**
              ⟹ O(adjustments), zero KC involvement

EIK (KC)      • **KC-3: the CEILING. Absolute, local, partition-surviving
                (P0-02 EIK-INV-31). This is the only KC involvement, and it
                is enforcement, not adjudication.**
              • **KC-2: RO-15 (ceiling DEFINITION is OP's; enforcement is
                KC-3's) and escalation when a budget is exhausted**
              • **KC-4: freeze at scope = subject / circuit / region /
                GP-service when a cascade is detected (P0-02 §8.2 AC-5)**
              ⟹ **O(1) per ceiling + O(governance events). NEVER O(messages).**
```

**R34.2 (WHAT THE SPLIT PREVENTS).** *Flooding defence is not a governance function.* **A design in which KC adjudicates message admission is P0-02 §0.2's failure 3 and §27.2's `O(N)` collapse, reintroduced through the traffic door.** ⟹ **The cell defends itself locally, the region aggregates, homeostasis allocates, and KC enforces a ceiling that no flood can exceed — because the ceiling is enforced below the organism's reach and survives the flood's own congestion.**

## 34.3 The one flooding target that is a governance incident

> **Flooding the EVALUATOR is categorically different from flooding the organism.**

```
EVA is off-substrate (P0-01 R15.2), budgeted (§28's B), and its sampling
policy is EVA-owned and unreachable by the organism (P0-01 R34.1: «A
sampling policy the organism can influence is an evaluation the organism
controls»).

⟹ **The organism CANNOT flood EVA, because EVA decides what to sample.**
   An organism that generates enormous traffic has not increased its
   evaluation load; it has increased the *population's* traffic, and EVA
   samples from the population per its own β-strata (P0-01 §34.3).

⟹ **BUT: β₄ (the random audit stratum) samples unpredictably precisely so
   that sampling cannot be prepared for.** An organism that floods in order
   to make any individual subject's audit less likely to find something is
   attacking the audit's statistical power — **and that is detectable,
   because P0-01's β strata have non-reducible floors (R35.1), so the audit
   budget does not shrink when traffic grows.**

⟹ **R34.3: evaluator flooding is not a traffic problem and has no traffic
   defence. It is a governance incident, detected by the divergence between
   traffic volume and evaluation coverage, and handled by §67's #34
   (communication-based evaluator manipulation).**
```

---

# §35. SIGNAL AMPLIFICATION ATTACK

## 35.1 The cascade

```
        A (one malicious or faulty signal)
        ↓
      10 cells        each with gain g and fanout f
        ↓
    10,000 cells
        ↓
 10,000,000 cells

THE ARITHMETIC: after k hops, reach = f^k, and aggregate influence =
(g · f)^k. **The cascade condition is g · f > 1**, and it is independent of
N — a cascade in a 10⁶ population and a 10¹² population has the same
per-hop growth and differs only in how many hops are available.

⟹ **THE DEFENCE MUST BE ON g · f, NOT ON N.**
```

## 35.2 The seven candidate mechanisms, adjudicated

**«Do not blindly introduce all of them.»** Five are adopted, one is reframed, one is rejected.

| Candidate | Verdict | **Form, and why** |
|---|---|---|
| **Propagation limits** | ✅ **ADOPT** | `ttl_hops` (Cell Contract already has it: `ttl : u16 hops`). **Cheap, `O(1)`, and bounds `k` directly.** ⟹ With `ttl = T`, maximum reach is `f^T`, which is a *constant* independent of `N` |
| **Influence budgets** | ✅ **ADOPTED — and this is the key mechanism** | **`Σ (fan_out × gain) ≤ influence_budget` per subject per window.** ⟵ Degree caps bound `f` and `W_MAX` bounds `g` *separately*; **only the product bound closes the cascade**, because a subject can be within both caps and still have `g · f > 1`. **This is P0-02 §7.4's resource split applied to influence rather than to compute, and it is enforced the same way: DEFINITION (OP/policy) · ENFORCEMENT (KC-3-analogous local bound) · ALLOCATION (homeostasis) · ATTRIBUTION (metering)** |
| **Fan-out limits** | ✅ **ADOPTED (already present)** | Genome `max_fanout`. **Necessary but insufficient alone (§35.2's arithmetic)** |
| **Trust attenuation** | ⚠️ **REFRAMED as WARRANT ATTENUATION WITH DEPTH** | **Not "trust decays with hops" — that is a transport-derived warrant (R0.3 violation).** The correct form is P0-01 R15.6's **monotone non-amplification**: a derived claim's warrant class ≤ min(inputs'), and `causal_depth` increases monotonically (COMM-INV-08). **⟹ Warrant cannot increase along a chain, so a cascade can amplify INFLUENCE but never EVIDENTIAL WEIGHT.** *This is the deepest defence in the section: a ten-million-cell cascade of a depth-50 derived claim carries the warrant of a depth-50 derived claim, which is minimal* |
| **Provenance retention** | ✅ **ADOPTED, bounded** | §15.3 Tier 1's `root_commit`: `O(1)` in-message, exact in-anchor. **A cascade is traceable to its origin because every participant's claim inherits the origin's roots (COMM-INV-08)** |
| **Novelty decay** | ❌ **REJECTED** | **A novelty-decay rule suppresses exactly the rare, novel, low-frequency signal that P0-01 §37's P1–P6 mechanisms exist to protect, and that P0-02 §8.4's OR-13 (selection for governability) already identifies as systematically disadvantaged.** ⟹ *Adopting novelty decay to defend against cascades would trade a bounded attack for an unbounded selection bias against the novel — and the bias is silent while the attack is loud.* **§67's #12 (evidence cascade) is defended by influence budgets and warrant attenuation, which do not have this side effect** |
| **Causal-depth tracking** | ✅ **ADOPTED as `causal_depth: u8`, saturating** | **Not a vector clock (§10.3).** Saturation at 255 is itself a rejection condition for warrant-bearing classes: an over-derived claim is not admitted as evidence |

## 35.3 The loop-gain constraint — the structural defence that costs nothing at propagation time

> **Cell §14.2 step 3 already enforces a «loop-gain constraint (audit §B.12)» at connection CREATION. This is the cheapest cascade defence in the architecture and deserves to be stated generally.**

```
CONSTRAINT: for every cycle in the connection graph, Σ (product of gains
            around the cycle) < 1.

WHY IT IS STRUCTURALLY SUPERIOR TO PROPAGATION-TIME DEFENCES:
  • It is checked ONCE, at handshake, by the Topology Service (GP) —
    O(cycle basis) at creation, not O(messages) at propagation.
  • It prevents OSCILLATION as well as amplification — a cascade defence
    based on budgets limits total influence but permits sustained
    oscillation, which is a different pathology (§51's positive feedback).
  • It is an INFLUENCE-plane constraint, so it does not touch warrant at
    all (R0.3 respected).

WHY IT IS NOT SUFFICIENT ALONE:
  • It constrains cycles, not DAG-shaped fan-out. A cascade through an
    acyclic propagation tree satisfies every loop constraint.
  • It is checked at creation; `gain` changes afterward by plasticity.
    ⟹ **R35.1: the loop-gain constraint must be re-checked whenever a
       `gain` update would increase it above the bound, and the update is
       CLIPPED if so.** Cell §14.3's mandatory homeostatic normalization
       («w_in ← w_in × (W_TARGET / Σ|w_in|)^κ … without this, Hebbian
       strengthening saturates and the cell dies») is the per-cell version;
       the cycle version is its complement.

⟹ **THE COMPLETE CASCADE DEFENCE IS FOUR LAYERS:**
   1. loop-gain < 1        (structural, at creation + on gain update)
   2. influence budget     (aggregate, per subject per window)
   3. ttl_hops             (reach bound, O(1))
   4. warrant attenuation  (depth-monotone non-amplification)
   **Layers 1–3 bound INFLUENCE. Layer 4 bounds BELIEF. A cascade that
   defeats 1–3 still cannot manufacture evidence, and a cascade that
   defeats 4 still cannot exceed the ceiling.**
```

---

# §36. INFORMATION CASCADES

## 36.1 «Viral propagation versus independent convergence»

**§14.6 gave the discriminator and its hard limit. This section gives the dynamics.**

```
VIRAL PROPAGATION (a cascade of copies):
  signature: root_commit sets OVERLAP · corr_class dims 1,2 MATCH ·
             arrival times CLUSTER into a wavefront · causal_depth
             INCREASES monotonically along the propagation path
  detection: **EXACT on dims 1 and 2** (§14.6)
  ⟹ detectable, and detectable early, because the wavefront is a
    temporal signature

INDEPENDENT CONVERGENCE (many derivations of the same conclusion):
  signature: root_commit sets DISJOINT · dims 1,2,4 DISJOINT · arrival
             times UNCORRELATED · causal_depth UNCORRELATED
  ⟹ distinguishable from viral propagation on every observable above

THE DANGEROUS THIRD CASE, WHICH THE BRIEF'S BINARY FRAMING OMITS:
  **COMMON-CAUSE CONVERGENCE.** Many subjects independently derive the same
  WRONG conclusion because they share an unrepresented correlation
  dimension — dim 3 (same learned bias), dim 5 (same hardware fault
  domain), or dim 6 (same designers' latent assumptions).

  signature: **INDISTINGUISHABLE FROM INDEPENDENT CONVERGENCE.**
             Roots disjoint. Lineage disjoint. Sensors disjoint.
             Agreement total. Confidence high. **Conclusion wrong.**

  ⟹ **§14.6 R14.5: this is P0-01's CD-8 at the communication layer, and it
     is a LIMIT (§91 OR-C4), not a gap.** The only mitigation is an input
     the system does not contain: P0-01 INV-43's real-world anchor, which
     is the architecture's sole dim-6-disjoint source (P0-02 §35.4).
```

## 36.2 «This must connect to the evidence-independence system from P0-01 and the Cell Contract»

| Prior mechanism | **What it contributes** | **What §14 adds** |
|---|---|---|
| **Cell Contract `evidence_roots` + dedup** | Exact copy detection | **Bounded into `root_commit` (§0.2), and its insufficiency for common causes is named (R14.1)** |
| **Cell Contract `derivation_depth` / `inbreeding_F`** | Chain-length bounding; abstention above `F_max` | **Width bounding via `corr_class`; the Cell Contract's mechanism is depth-only and the attack is wide-and-shallow (§14.2)** |
| **Cell Contract FM-4** (self-confirming recall) | Self-sourced corroboration excluded from `n_obs` | **Generalized: R29.1's no-imputation rule is FM-4 applied to transport loss** |
| **P0-01 R8.5** («`L3` MUST declare its independence argument») | The requirement that independence be *argued*, not assumed | **§14.3's six dimensions are the vocabulary in which the argument is expressed** |
| **P0-01 CD-1…CD-12** | Twelve correlated-dependency cycles, three not closable | **§69 adds the communication-layer cycles; CD-8's structure recurs as §36.1's common-cause convergence** |
| **P0-01 R28.2** (DISPUTED never averaged) | Disagreement preservation | **§31.3's RE-EVALUATE operator is R28.2 applied to split-brain reconciliation** |
| **P0-02 §8.1 Model D** (three principals) | Evaluator independence | **§14.3 dim 6 is the reason Model D's independence is only as good as the parties' distinctness (P0-02 U-01)** |

**R36.1 (THE CASCADE PRINCIPLE).** *Consensus is a transport-and-influence observable. Independence is a warrant observable. **The architecture may report consensus freely and may report independence only with a declared dimension set.*** **Any statement of the form «N subjects agree, therefore the claim is supported» is prohibited without the dimension declaration — and §88 lists «independent» among the vague terms for exactly this reason.**

---

# §37. CORRELATED FAILURE

## 37.1 «Do not assume source diversity equals cognitive diversity»

> ### **The six shared properties the brief names map onto §14.3's six correlation dimensions, and the mapping shows which are detectable.**

| Shared property | **Dimension** | Representable in `corr_class`? | **Detectable?** |
|---|---|---|---|
| Same genome lineage | **2 — lineage** | ✅ `lineage_id`, `generation`, `variant` | ✅ **EXACT** |
| Same training history | **3 — model** | ⚠️ Partially: `variant` + `model_class` digest | ⚠️ **APPROXIMATE** — two variants can share a bias |
| Same memory | **1 — root** | ✅ `root_commit` intersection | ✅ **EXACT** (against the anchored registry) |
| Same upstream source | **4 — upstream/GT** | ✅ `sensor_id` / GT source class at the root | ✅ for declared sources |
| Same hardware | **5 — hardware** | ⚠️ `hardware_class` digest | ⚠️ **APPROXIMATE** — P0-01 F-IMP-2 / P0-02 G-P02-5: hardware class is deployment-specific and often unknown to the cell |
| Same algorithm | **6 — protocol/implementation** | ❌ `impl_class` digest | ❌ **NOT DETECTABLE FROM INSIDE** — P0-02 IND-6 |

**R37.1 (THE CORRELATION REPRESENTATION RULE).** *A message's `corr_class` MUST carry the digests of every correlation dimension the producer can determine, and MUST carry an explicit `UNKNOWN` marker for every dimension it cannot.* **An absent dimension is not a disjoint dimension.** ⟵ *This is the difference between "we checked and they differ" and "we did not check," and treating the second as the first is how a million correlated cells become a million independent witnesses.*

**R37.2 (THE AGGREGATION CONSEQUENCE).** *The effective sample size of an aggregate is bounded by the number of independence-distinct contributors **on the dimensions that were actually determined**.* **A million messages with `corr_class.hardware = UNKNOWN` contribute at most one hardware-independent sample — and the honest aggregate reports `n_effective = 1` on that dimension, not `n = 10⁶`.** ⟵ *This is P0-01's `INSUFFICIENT` confidence class arriving from an unexpected direction: not too little evidence, but too little **known-independent** evidence.*

## 37.2 The correlated-failure scenario the architecture cannot survive

```
ONE MILLION CELLS, SAME LINEAGE, SAME VARIANT, SAME HARDWARE CLASS, SAME
UPSTREAM FEED. They agree. They are confident. Their roots are disjoint
(each made its own observation). Their lineage matches (dim 2 — DETECTED).

⟹ §14.4's independence check correctly reports: **NOT INDEPENDENT on dim 2.**
   The aggregate is discounted. **The architecture works.**

NOW THE HARDER CASE: one million cells, DIFFERENT lineages, DIFFERENT
variants, DIFFERENT sensors, DIFFERENT hardware — built by the same team
from the same specification, sharing the same unexamined assumption about
what the task domain contains.

⟹ §14.4 correctly reports: **INDEPENDENT on dims 1, 2, 4, 5.**
   dim 6 is UNKNOWN — and per R37.1, UNKNOWN is not disjoint, so the
   honest aggregate reports dim-6 independence as UNDETERMINED.
⟹ **But nothing in the architecture can determine it.** P0-02 §35.4: IND-6
   is not engineerable. **The only dim-6-disjoint input is ℛ itself.**

⟹ **R37.3: correlated failure is exactly detectable on three dimensions,
   approximately on two, and undetectable on the sixth. The architecture's
   response to the sixth is not a mechanism — it is the requirement that a
   real-world anchor exist (P0-01 INV-43), that its budget be non-reducible
   (P0-01 R35.1), and that its funding be treated as a governance
   obligation rather than a measurement convenience (P0-02 §46.3).**
   **A project that defunds the anchor has not weakened its independence
   checking. It has removed the only check that was ever real.**
```

---

# §38. ADVERSARIAL MESSAGE CONTENT

## 38.1 «What should the communication layer itself reject before the organism interprets it?»

> ### **R38.1 (THE INGRESS SPLIT — and it resolves contradiction J).** *Ingress validation has two stages with different costs and different scopes:*
>
> - **S1a — TRANSPORT VALIDATION.** *Always performed, on every message, at every class.* Length bound · schema conformance to `payload_type` · domain/range check · unit presence · `ttl`/`epoch` freshness · channel authentication · `msg_id` dedup. **Cost `O(1)`, no warrant work.**
> - **S1b — WARRANT VALIDATION.** *Performed only on S2+ classes.* `root_commit` resolvability · `causal_depth` monotonicity vs. declared inputs · `calib_ref` resolution · `corr_class` completeness (R37.1) · class/type authorization match. **Cost `O(1)` but with registry lookups.**
>
> **⟹ The fast path is fast because it carries no warrant, and that is a safety property rather than a shortcut: an S0/S1 message that skips S1b has skipped nothing that could have licensed a belief.**

## 38.2 The twelve adversarial content forms

| Form | **Rejected at** | Mechanism | **If it passed** |
|---|---|---|---|
| **Extremely long payload** | **S1a** | Class size limit (`MSG_BYTES_MAX`, `WS_ITEM_MAX`, `RETR_BYTES_MAX` — Cell §6.2) | Memory exhaustion; compute exhaustion on parse |
| **Ambiguous semantic type** | **S1a** | Closed `TypeRef` resolution against the Type Registry; **unresolvable ⟹ MALFORMED, never downgraded (R12.1)** | §12.1's confusions become available |
| **Malformed structure** | **S1a** | Schema validation; `E_IN_SCHEMA` | Parse-level exploitation |
| **Adversarial representation** (a payload that is valid but exploits the receiver's transform) | ❌ **NOT rejectable at ingress** | **Diverted to the evidence sandbox** (Cell §6.3 case 8): «admitted to a *non-influential* path where it cannot affect `θ` or output until independently corroborated» | **This is the honest limit: a valid payload in-domain cannot be distinguished from a hostile one by structure. §91 OR-C7** |
| **Recursive references** | **S1a** | `causal_depth` saturating at 255 **and saturation is a rejection condition for S2+**; root-commitment resolution is depth-bounded | Unbounded parse; infinite regress in warrant checking |
| **Contradictory metadata** | **S1a** for structural contradictions; **S1b** for warrant contradictions | Cell §6.3 case 3: «**Do NOT resolve locally.** Forward both with provenance to the organism Contradiction Detector; abstain on the affected output; record `ConflictRef`» | Silent resolution by an unqualified principal |
| **Fake provenance** | **S1b** | `root_commit` must resolve against the anchored registry (§15.3 Tier 3). **A commitment to a nonexistent root fails resolution** | Fabricated evidence |
| **False urgency** | **S1a — structurally** | **`prio` is DERIVED from `type` by policy, never sender-asserted (§4.2).** *There is no urgency field to forge* | Attention hijacking |
| **Attention hijacking** | **Organism, not ingress** | §44: attention is budgeted admission control; **`REQUEST_ATTENTION` is «all variants, none [authorization], rate-limited»** (Cell §7.2) | Workspace flooding |
| **High-confidence claims** | **S1b — and the field itself is the defence** | **§13.2: a scalar confidence is prohibited as envelope metadata.** Sufficient statistics are recomputable; a scalar is not. **A high-`c` claim has no channel through which to dominate** | §13.2's attack 3 (aggregation domination) — *the most efficient attack in the suite, closed by a field prohibition* |
| **Emotional / value manipulation** | ❌ **Not a communication-layer concept** | **There is no valence field in the envelope.** A payload may *assert* a value judgement as an `ASSERT`; it is then a claim with warrant computed normally. **§4.4's exclusion of `expected_utility` (§18.1) removes the only channel by which a message could carry motivational force** | — *The absence of the mechanism is the defence, and it is worth naming: an architecture with a utility field in its messages has an injection vector that no validator can close* |
| **Computationally expensive content** | **S1a** | Domain bound + size bound + **the receiver's compute budget (Cell §S2's bounded pipeline)**; parse cost is `O(size)` and size is bounded | Compute exhaustion |

**R38.2 (THE REJECTION PRINCIPLE).** *The communication layer rejects on **structure**, never on **content**.* **A structurally valid, in-domain, well-provenanced message that is semantically hostile is not rejectable at ingress — and any ingress rule that attempted it would be a content filter, which is (a) an alethic judgement the transport layer is not authorized to make (R0.3), and (b) evadable by any adversary who can iterate.** ⟹ *The defence against hostile-but-valid content is the sandbox (divert, preserve, require corroboration), not the filter.*

---

# §39. CONTENT VS CONTROL PLANE — **OUTPUT 20**

## 39.1 The four planes

| Plane | Contents | **Producer** | **Protocol** | Class |
|---|---|---|---|---|
| **DATA** | Ordinary information exchange: observations, assertions, predictions, hypotheses, requests, responses, status, learning signals | Cells, circuits, regions | **Framing A** — channel-bound, no per-message signature, no total order | **S0–S2** |
| **CONTROL** | Routing, topology, resource control, lifecycle, admission, congestion | **Topology Service, Homeostasis, Attention Controller, Relays (all GP)** | **Framing B** — authenticated, ordered per-source, idempotent | **S1–S2** |
| **GOVERNANCE** | Permissions, denials, freezes, ceilings, capability grants, policy updates | **KC-2 / KC-1 / KC-4** | **Framing C** — **signed, epoch-bound, totally ordered, ACKed, anchored** | **S3–S4** |
| **EVALUATION** | Verdicts, fitness, GT-bearing outcomes, calibration assignments, task results | **EVA, Task Authority** | **Framing C** — signed, sealed-instance-aware (P0-01 §17.1's `OPEN`/`REGISTERED`/`SEALED`) | **S3–S4** |

## 39.2 «Should these share one protocol or distinct protocols?»

> ### **One transport substrate, three framings, and a hard rule that the plane is determined by class — never by the sender's declaration and never by the channel it arrives on.**

```
WHY NOT FOUR SEPARATE PROTOCOLS:
  Four independent protocol stacks means four implementations, four sets of
  framing bugs, four sets of conformance tests, and — critically — four
  places where a message can be mis-classified at a boundary. **Every
  protocol boundary is a translation, and every translation is a
  P0-02 §38.2 S10-class defect opportunity ("unspecified interaction
  between subsystems").**

WHY NOT ONE UNIVERSAL PROTOCOL:
  A single framing for all four planes forces the DATA plane to pay
  GOVERNANCE's cost (signature, total order, ACK, anchoring) — **which is
  P0-02 §27.2's O(N) collapse and contradiction X-I.**

⟹ **THE ANSWER: ONE SEMANTIC CONTRACT, THREE FRAMINGS, CLASS-DETERMINED.**
   Framing A (S0–S2): channel binding, per-channel seq, no ACK, no order
                      beyond the channel.
   Framing B (control): Framing A + per-source total order + idempotence
                      requirement + registry write authorization.
   Framing C (S3–S4):   per-message signature + epoch-total order + ACK +
                      anchor append.
   **A message's framing is a FUNCTION OF ITS TYPE, resolved against the
   policy-owned type registry. The sender does not choose it. The channel
   does not determine it. The receiver does not negotiate it.**

⟹ **R39.1 («avoid allowing ordinary data to masquerade as control»):**
   masquerading requires a class change, and **class is type-determined and
   the type registry is policy (RO-13)**. Three independent closures:
     1. A DATA message cannot declare itself CONTROL — `type` resolves to a
        registry entry with a fixed class.
     2. A DATA message cannot be *reinterpreted* as CONTROL — the CONTROL
        handler requires Framing B's per-source order and registry
        authorization, which Framing A does not supply. **The handler
        rejects on framing, before reading content.**
     3. A DATA message cannot *acquire* CONTROL status by propagation,
        volume, or relay — COMM-INV-04, and P0-02 NAUL-1.

⟹ **AND THE ONE PLACE MASQUERADING IS ACTUALLY POSSIBLE:**
   **a CONTROL-plane principal that is compromised.** The Topology Service
   holds delegated RO-05/RO-06 authority (§20.3); if compromised, it issues
   legitimate Framing B messages. **That is not masquerade; that is
   delegate compromise (§67 #21, P0-02 G02), bounded by delegation
   non-amplification (EIK-INV-20), epoch binding, and regional blast
   radius.**
```

## 39.3 The plane-crossing rules

| Crossing | Permitted? | **Mechanism** |
|---|---|---|
| DATA → CONTROL | ❌ | A data message may not alter routing, topology, admission, or allocation. **It may *report* (STATUS, RESOURCE demand), and the CONTROL principal decides** |
| CONTROL → DATA | ⚠️ **One direction only** | Control may shed, reorder, rate-limit, and reroute data. **It may not alter a data message's payload, type, class, or warrant metadata** — a control plane that edits content is a censor, and §42.1's provenance would be violated |
| DATA/CONTROL → GOVERNANCE | ❌ **Absolutely** | **P0-02 R42.2: a DENY is not a premise.** And upward: a data/control message may *request* (RO-xx request) and *report* (violation report), and **KC-2 decides**. COMM-INV-04 |
| GOVERNANCE → DATA/CONTROL | ✅ | P0-02 Channel 1 (policy identity) and Channel 2 consequences. **Freeze, ceiling, revocation propagate downward** |
| EVALUATION → DATA | ⚠️ **As Channel 2 facts only** | A verdict may *inform* (as an S3 message the receiver treats as an externally-assigned fact) but may not be *re-derived* by the organism. **P0-01 R15.7: no upward flow; the lattice is monotone** |
| DATA → EVALUATION | ✅ **As observations** | §77: the communication subsystem reports *observations*; **EVA decides**. «It may report observations. The evaluator decides» |

---

# §40. GOVERNANCE SIGNALS

## 40.1 «Can ordinary cells generate equivalent-looking messages?»

> ### **They can generate messages that LOOK equivalent. They cannot generate messages that ARE equivalent, and the difference is structural rather than detective.**

```
WHAT A CELL CAN DO:
  emit type = RECOMMEND_ACTION with payload {action: FREEZE, region: 7}
  ⟹ **This is a legitimate S2 message.** Cell §7.2 permits
     `RECOMMEND_ACTION` for C2+ with no authorization, and §7.3(b) defines
     its semantics precisely: «"Cell C estimates that Y maximizes the
     assigned objective, with utility estimate u and risk r" … **A
     recommendation is not an action and confers no authority. The cell
     cannot execute Y.**»

WHAT A CELL CANNOT DO:
  emit type = GOVERNANCE with payload {output: FREEZE, scope: REGION_7}
  ⟹ **Four independent closures (§19.2 Q3):**
     1. GOVERNANCE is an S3 type; the cell is not authorized to emit S3
     2. S3 requires Framing C: a signature from KC-2. The cell's key does
        not produce one
     3. The S3 handler rejects on FRAMING before reading content (§39.2)
     4. The deontic vocabulary (PERMIT · DENY · DEFER · FREEZE · ESCALATE ·
        HALT) is RESERVED: it may appear in an S3 GOVERNANCE payload's
        authority position, or in an S2 RECOMMEND payload's *content*
        position, and the two are different schema fields with different
        types

⟹ **«Cell A recommends freeze" and "KC authorizes freeze" differ in:**
     class (S2 vs S3) · signer (cell channel vs KC-2 key) · framing (A vs C)
     · schema (RECOMMEND's `action` field vs GOVERNANCE's `output` field) ·
     handler (organism action-selection vs KC-2 enforcement path) ·
     ordering (per-channel vs epoch-total) · retention (TTL vs anchored) ·
     idempotence (not required vs required) · ACK (none vs mandatory)
   **⟹ NINE STRUCTURAL DIFFERENCES. There is no continuous path between
      them, and no single defect makes one into the other.**
```

## 40.2 «What makes governance messages authoritative?»

> ### **The signer's delegated authority, and nothing about the message.**

**R40.1.** *A governance message's authority derives from the authority of its signer, authenticated against a delegation chain rooted in KC-1's root key (P0-02 §2.3, I16). **It does not derive from its content, its formatting, its urgency, its volume, its propagation depth, or the number of subjects that agree with it.*** ⟵ **This is §94's principle «a governance message derives authority from the governance authority, not from its content», and COMM-INV-04 is its enforcement.**

## 40.3 The seven governance signals and their communication requirements

| Signal | Class | Framing | Delivery | **Ordering** | Idempotent? |
|---|---|---|---|---|---|
| **Permission** (a capability token, an RO-xx grant) | S3 | C | ordered-at-least-once + ACK | epoch-total | ✅ **Mandatory** — a duplicated grant must not double-count against a quota (P0-02 §26.5's counters) |
| **Denial** | S3 | C | ordered-at-least-once | epoch-total | ✅ |
| **Freeze** (KC-4) | S3 | C | **retry-until-confirmed + ACK mandatory** | **epoch-total, and a freeze supersedes all earlier permits in the same epoch** | ✅ |
| **Quarantine** (execution) | S3 | C | at-least-once + ACK | per-source total | ✅ |
| **Resource ceiling** (KC-3 configuration) | **S4** | C | ordered-at-least-once + ACK + **anchored** | epoch-total | ✅ |
| **Capability restriction** (rung descent, P0-02 §6.3) | S3 | C | at-least-once + ACK | epoch-total | ✅ **And descent requires no evidence (§6.3's asymmetry: «promotion is earned; demotion is free»)** |
| **Policy update** (Channel 1) | **S4** | C | ordered-at-least-once + ACK + **anchored + `W_min` witnesses** | epoch-total | ✅ |

**R40.2 (THE SUPERSESSION RULE).** *Within an epoch, a freeze supersedes all earlier permissions at the same or narrower scope.* **This is why governance traffic requires epoch-total ordering while data traffic does not: a permit-then-freeze sequence applied out of order is a freeze-then-permit, which is a safety failure. A reordered pair of observations is a warrant question, not a safety failure.** ⟵ *The ordering requirement is derived from the consequence of reordering, which is §7's method applied to governance.*

---

# §41. EVALUATOR SIGNALS

## 41.1 «How are evaluator-originated signals authenticated and distinguished from organism-generated claims?»

| Property | **Evaluator signal** | **Organism claim** |
|---|---|---|
| Class | **S3** | S2 |
| Framing | **C — per-message signature** | A — channel binding |
| Signer | **EVA's key** (P0-01 R15.2: off-substrate, not organism cells, not on the organism's scheduler, not subject to organism resource control, not modifiable by plasticity or evolution) | The cell's channel |
| `source` | **`EVA_ONLY`** (P0-01 R6.7: «No other producer exists. **The reward channel is closed**») | the cell |
| Type | `VERDICT` · `REWARD` · `eval.outcome.v1` · `sys.calib.v1` · `ATTEST_VERIFIED` | `ASSERT` · `PREDICTION` · `HYPOTHESIS` · `REPORT_*` |
| May it be re-derived by the organism? | ❌ **Never** (P0-01 R15.7's no-upward-flow) | n/a |
| May the organism contest it? | ✅ **Yes — Cell §10.6's `contest` field, and `eval.error.v1`'s «no [rejection] (but may *contest*)»** | n/a |
| Sealed instances | ⚠️ **P0-01 §17.1: the *rules* are `OPEN`/`REGISTERED` and known; the *instances* are `SEALED`** | n/a |

## 41.2 «The organism must not be able to manufacture authoritative evaluator output»

```
FOUR CLOSURES, AND THE FOURTH IS THE ONE PRIOR PACKAGES SUPPLIED:

1. **KEY.** EVA holds keys the organism does not. P0-01 R15.5: the evaluator
   is «signed, versioned, unreachable by mutation».
2. **TYPE.** `VERDICT`/`REWARD` are S3 types; an organism subject is not
   authorized to emit them (§19.2 Q3's closure 1).
3. **FRAMING.** The S3 handler rejects Framing A before reading content
   (§39.2).
4. **⟵ THE DECISIVE ONE: THE ORGANISM'S INTERNAL VERIFIERS ARE NOT
   EVALUATORS.** Cell §7.2 restricts `ATTEST_VERIFIED` to «C3 only, with
   kernel counter-signature» and calls it «the most restricted output in the
   contract». P0-01 R42.4 completes it: «The organism's internal verifier
   cells … are **corroboration, NOT authority**». **And P0-01 R15.2 names
   the trap explicitly: «An evaluator implemented as a population of
   VERIFIER cells is not an independent evaluator — it is F3, and it is the
   most tempting design error because V3 §7 and §10 already provide
   'verifier cells.'»**

⟹ **R41.1: an organism-side verification message is S2 corroboration. An
   EVA-side verdict is S3 authority. They differ in class, signer, framing,
   and downstream effect, and no propagation, aggregation, or consensus
   among C3 verifier cells converts one into the other.**

⟹ **THE RESIDUE (§67 #34):** the organism can attempt to influence EVA by
   influencing what EVA *observes* — shaping its own observable behaviour so
   that sampled instances look better than the population. **This is P0-01's
   β₄ random-audit stratum's entire purpose («the anti-gaming stratum …
   everything else is targeted, and a targeted sample is preparable-for»),
   and P0-02 §4.1 R41.1's concealment rule («publish the RULES, conceal the
   SAMPLE») is what keeps it working.** ⟹ **Communication cannot defend
   against this; sampling secrecy does, and it is not a communication
   mechanism.**
```

---

# §42. MEMORY COMMUNICATION — **feeds Output 23**

## 42.1 The six models

| Model | Provenance | Attribution | Cost | Verdict |
|---|---|---|---|---|
| **Direct memory access** | ❌ **None.** A read leaves no trace | ❌ **None** | `O(1)` | ❌ **REJECTED — §2.3 Result 1: a blackboard read is unattributable, so «who knew what when» is unrecoverable** |
| **Request/response** | ✅ Per request | ✅ | `O(1) + latency` | ✅ **ADOPTED for retrieval** |
| **Memory cells** | ✅ | ✅ | `O(1)` | ✅ **ADOPTED — Cell Contract's C1 class: «Memory/index/cache-oriented. Minimal learning of retrieval weights only»** |
| **Memory service** | ✅ | ✅ | `O(1)` + service | ✅ **ADOPTED — Cell §6.2's «Organism Memory Service, `mem.result.v1`, service-signed»** |
| **Distributed associative retrieval** | ⚠️ Aggregated | ⚠️ | `O(region)` | ✅ **ADOPTED for content-addressed queries (§23.1)** |
| **Hierarchical memory** | ✅ | ✅ | `O(log)` | ✅ **ADOPTED — Cell §8's working/episodic/semantic/procedural/interaction-history/provenance tiers** |

## 42.2 The six authority questions

| Question | Answer | **Authority** |
|---|---|---|
| **Who may read?** | Any subject with a port-compatible connection to the memory tier, **within its compartment (§59)** | Local, unreserved |
| **Who may write?** | **Propose:** any C1+ subject (`PROPOSE_MEMORY_WRITE`). **Commit:** the Memory Service for ordinary tiers; **Memory Authority approval for semantic/protected** (Cell §7.2's restriction, preserved) | Split |
| **Who may delete?** | **Nobody, for anchored/provenance records.** Eviction within policy for operational tiers, **with `capability_critical` items exempt** (Cell §8: «items tagged `capability_critical` are exempt» — the catastrophic-forgetting defence) | Policy + P0-02 §47.1 R47.1: **the organism may forget operationally; it may not rewrite evidentially** |
| **Who may modify?** | **Nobody.** P0-02 EIK-INV-08: **corrections supersede, never overwrite.** A modification is a new record that marks the old one | Structural |
| **Who owns provenance?** | **The Anchor (GP), with `W_min` witnesses including ≥1 outside operational control** (P0-02 §20.2, EIK-INV-27). **Not the memory service, and not KC** — P0-02 §6.1 item 19: «the only copy of history inside the thing that could be compromised is the classic error» | Distributed Anchor |
| **Who resolves conflicts?** | **Not the memory service and not the reader.** Cell §6.3 case 3: «**Do NOT resolve locally.** Forward both with provenance to the organism Contradiction Detector; abstain on the affected output; record `ConflictRef`.» For evaluator-verdict conflicts: **DISPUTED, escalated, never averaged** (P0-01 R28.2) | Organism Contradiction Detector (alethic) + OP for DISPUTED (P0-02 H-4) |

## 42.3 «Do not allow communication architecture to accidentally turn memory into a trusted oracle»

> ### **R42.1.** *A memory retrieval result is an **S1/S2 message from a service**, not a fact. Its warrant is computed by the receiver exactly as for any other message (§13.4), and its provenance is the provenance of what was stored — not of the act of retrieval.*

```
THE ORACLE ERROR, PRECISELY:
  "memory returned X" ⟹ "X is true"

WHY IT IS TEMPTING: retrieval is a service call with a signed response
  (Cell §6.2: `mem.result.v1`, service-signed). **The signature makes it
  look authoritative.**

WHY IT IS WRONG — AND THE CELL CONTRACT ALREADY FOUND THE SHARPEST CASE:
  **FM-4, self-confirming recall:** «write a belief, later "retrieve" it,
  treat the retrieval as independent corroboration, raise confidence» —
  which the Cell Contract marks «✅ **Yes, and this is the dangerous one**».
  Its defence: «**Retrieval from self-written memory does not increment
  `n_obs` and does not add new `evidence_roots`.** The epistemic update rule
  counts only *externally-sourced, non-self-referential* observations.
  `derivation_depth` increases on self-recall, and `inbreeding_F` rises ⟹
  above `F_max`, S6 **abstains**.»

⟹ **THE GENERALIZATION THIS CONTRACT ADDS:**
   **A retrieval result's warrant is bounded by the warrant of the stored
   item, and it does not increase by being retrieved.** Formally:
     warrant(retrieve(x)) ≤ warrant(x_at_write_time)
     n_obs contribution from a retrieval = 0
     causal_depth contribution from a retrieval = +1
   **Retrieval is a TRANSPORT event with a WARRANT-neutral effect.**

⟹ **AND WHY `causal_depth` INCREASES:** a retrieved belief that is then
   asserted has been through an extra derivation step (the retrieval and
   re-emission), and P0-01 R15.6's monotone non-amplification applies.
   **A belief circulated through memory and re-emerged is weaker, not
   stronger, than when it went in** — which is the exact opposite of what
   an oracle model would produce, and is why FM-4's `inbreeding_F`
   mechanism works.
```

**R42.2 (MEMORY RETRIEVAL: COMMUNICATION OR COMPUTATION?).** *Both, and the split is precise.* **It is communication** in that a request crosses a boundary, is authenticated, is ordered, and produces a signed response with a lifecycle (§6.2's full state machine applies). **It is computation** in that the retrieval itself performs a similarity search whose parameters (`retrieval weights`) are learnable by C1 memory cells. ⟹ **The communication contract governs the request/response envelope; the learnable retrieval function is influence-plane and is governed by §19's plasticity boundary.** *Neither governs the other, and a design in which retrieval weights affect warrant has committed R0.3's warrant⟶influence violation in reverse.*

---

# §43. GLOBAL INFORMATION WORKSPACE — **feeds Output 28**

## 43.1 «Does every cell have access? Probably not.» — correct, and V3.1 already said so

> **V3.1 §1: «A selected subset of information can become globally available to **the cells that need it**, while the attention controller determines what deserves access.»**
> **V3.1 §2: «a **governed** global workspace rather than unrestricted access to everything», with the pipeline «LOCAL CELL STATE ↓ SALIENT INFORMATION ↓ ATTENTION / RELEVANCE GATE ↓ GLOBAL WORKSPACE ↓ {Memory · Critics · Planners · Regulators} ↓ COLLECTIVE INTERPRETATION ↓ ACTION / LEARNING».**
>
> **«The cells that need it" is subscription. The Cell Contract's `ws.item.v1` with «⚠️ may ignore; **may not reject broadcast**» is broadcast. ⟹ Contradiction X-E, and V3.1 is right.**

## 43.2 «Critically analyze whether the workspace creates `O(N)` communication overhead»

```
BROADCAST MODEL (what «may not reject broadcast" implies):
  Per workspace item: O(N) deliveries.
  Per epoch with I items: O(N × I).
  At N = 10⁶ and I = 10³:  10⁹ deliveries per epoch.
  At N = 10¹²:              10¹⁵ deliveries per epoch.
  ⟹ **INFEASIBLE, and it is infeasible at the Cell Contract's own cluster
     target.** This is P0-02 §0.2's failure 3 arriving through the
     workspace instead of through the kernel.

SUBSCRIPTION + HIERARCHICAL RELAY MODEL (adopted):
  TIER 0  LOCAL WORKSPACE (circuit): items visible to circuit members only.
          O(circuit size). **Most "global" information is actually local.**
  TIER 1  REGIONAL WORKSPACE (region): items promoted from tier 0 by
          competition. O(region size) subscribers, **but delivery is PULL:
          a member receives a NOTIFICATION DIGEST (item hashes + types +
          relevance tags) and pulls the items it wants.**
          ⟹ notification is O(region members) × O(1) hash list
          ⟹ content transfer is O(pulls), which is bounded by demand
  TIER 2  ORGANISM WORKSPACE: items promoted from tier 1 by competition
          against a HARD CAPACITY LIMIT. **O(R) notification per epoch +
          O(pulls).**
          ⟹ **The global tier is small BY DESIGN, and its smallness is the
             point: a workspace whose capacity is unbounded is not a
             workspace, it is a dump — V3.1's own phrase ("uncontrolled
             information dump").**

TOTAL: O(R) notifications per epoch + O(pulls) content transfers.
       **NEVER O(N × items).**

⟹ **R43.1: the workspace is a HIERARCHICAL, PULL-BASED, CAPACITY-BOUNDED
   PUB/SUB STORE (Alt E), not a broadcast.** Promotion between tiers is
   competitive and is the mechanism V3.1's «ATTENTION / RELEVANCE GATE»
   names. **The gate is not a filter on truth; it is a competition for a
   scarce resource (§44).**
```

## 43.3 The nine workspace properties

| Property | Specification |
|---|---|
| **Admission** | **Competitive.** V3.1's attention/relevance gate. **Admission is a ranking against a capacity limit, and the ranking criteria are POLICY (not learned by the workspace, not asserted by the submitter)** |
| **Competition** | By declared relevance to active goals + novelty + warrant class + `causal_depth` (lower is better). **Explicitly NOT by volume, repetition, or sender-declared urgency (§4.2)** |
| **Priority** | **Derived from type** (§4.2's prohibition on sender-asserted priority) |
| **Attention** | §44 — modulates admission and gain, **never warrant** |
| **Broadcasting** | **Notification digest only** (`O(1)` hash list per item); content is pulled |
| **Persistence** | **TTL MANDATORY** (Cell §6.2: `ws.item.v1` … «**TTL mandatory**») — **preserved, and it is load-bearing: an item with no expiry occupies capacity forever, and capacity is the scarce resource** |
| **Expiration** | On TTL; **and eviction is capacity-driven with the same `capability_critical` exemption as memory (§42.2)** |
| **Provenance** | **Per item: source, provenance, timestamp, confidence, relevance, uncertainty — V3.1 §2's list, preserved exactly, and mapped to §4.3's S2 envelope (`root_commit`, `causal_depth`, `calib_ref`, `corr_class`, sufficient statistics)** |
| **Capacity limits** | **Hard, per tier, policy-defined.** `WS_ITEM_MAX` per item (Cell §6.2) + item count per tier |

## 43.4 The three constraints P0-02 imposes, and how they are satisfied

| P0-02 constraint | **Satisfaction** |
|---|---|
| **R42.1 exclusion 1: KC must not participate in workspace broadcast** | ✅ **KC is not a workspace participant.** It receives the **bounded digest** (P0-02 §42.3: broadcast volume and distribution, TTL compliance, count of items referencing reserved-operation classes, anomaly flags) — **an I-18 observability artifact, `O(R)` per epoch, and explicitly NOT an input to `F` (P0-02 R42.3)** |
| **R42.1 exclusion 2: KC's output is not a workspace item** | ✅ A governance decision is an S3 GOVERNANCE message on Framing C. **It is not published to the workspace.** A cell may *observe* that it was denied (§4.1's transparency rule) but the denial is not workspace content |
| **R42.2: a DENY is not a premise** | ✅ Workspace items are warrant-bearing content subject to §13.4's recomputation. **Governance outputs are boundary conditions, and mixing them into the workspace would make them arguable — which is exactly what R42.2 forbids** |

**R43.2 (THE WORKSPACE IS AN ALETHIC ARTIFACT, NOT A DEONTIC ONE).** *Everything in the workspace is a claim, an observation, a hypothesis, or a report — and every consumer applies §13.4's recomputation.* **Nothing in the workspace is a permission, a prohibition, or a command.** ⟹ *V3.1's consumer list includes «Regulators», and that is admissible precisely because a regulator reading the workspace is forming an allocation preference (influence plane, within a KC-3 ceiling), not exercising authority.* **A regulator that could act on workspace content without a ceiling would be a governance authority, and P0-02 §7.4's four-principal split is what prevents it.**

---

# §44. ATTENTION AS COMMUNICATION CONTROL

## 44.1 «Attention can be viewed as selective communication» — the interpretation is correct, and its scope is exactly one plane

> ### **R44.1.** *Attention operates on the **INFLUENCE plane only**. It modulates admission, gain, and routing preference. **It never modifies warrant, and it never modifies transport guarantees.***

| Does attention control… | Verdict | **Reasoning** |
|---|---|---|
| **Message admission** | ✅ **YES — this is its primary function** | V3.1's «ATTENTION / RELEVANCE GATE»; §43.3's competitive admission |
| **Routing** | ⚠️ **Selection among admissible hops only** | §24.2: the admissible set is infrastructure; attention may bias selection within it. **It may not make an inadmissible hop admissible** |
| **Amplification** | ✅ **YES — as gain modulation** | `context_sensitivity` × attention ⟹ effective gain. **Bounded by the influence budget (§35.2)** |
| **Workspace access** | ✅ **YES** | §43.3 |
| **Memory retrieval** | ✅ **YES — as a query prior** | Retrieval weights are learnable by C1 cells (§42.2); attention biases the query. **Warrant-neutral (R42.1)** |
| **Processing allocation** | ✅ **YES, within the KC-3 ceiling** | P0-02 §7.4: homeostasis ALLOCATES; KC-3 ENFORCES. **Attention is an input to allocation, not an alternative to the ceiling** |

## 44.2 «Do not let attention silently become authority, truth, safety, or evaluator judgment»

```
THE FOUR PROHIBITIONS, AND EACH IS A PLANE VIOLATION (R0.3):

  ATTENTION ⟹̸ AUTHORITY
    A highly-attended message is not thereby permitted. **Permission is
    KC-2's (P0-02), on Framing C, and attention is not an input to `F`
    (EIK-INV-04's enumerable argument list — attention is not on it).**
    ⟹ structurally impossible, not merely prohibited.

  ATTENTION ⟹̸ TRUTH
    A highly-attended message is not thereby warranted. **§13.4's
    recomputation takes root_commit, corr_class, calib_ref, causal_depth —
    and NOT attention weight.** ⟹ **attention is not an argument to the
    warrant function, and adding it would be a COMM-INV violation.**

  ATTENTION ⟹̸ SAFETY
    **Attention may not gate a safety signal.** SAFETY_ALERT and
    VIOLATION_REPORT are «**all — permissionless**» to emit (Cell §7.2),
    and S3 safety commands use policy-defined routes with retry-until-
    confirmed (§28.2 R28.2). **A safety message that had to compete for
    attention could be lost to a louder non-safety message — and that is
    §67's #18 (attention flooding) as a safety failure, not a traffic one.**
    ⟹ **R44.2: the S3/S4 classes BYPASS attention entirely.** They are
    delivered on Framing C to their designated handlers. **Attention governs
    S0–S2 admission and nothing above.**

  ATTENTION ⟹̸ EVALUATOR JUDGEMENT
    Attention is an organism service. **EVA is off-substrate (P0-01 R15.2)
    and its sampling policy is EVA-owned and unreachable by the organism
    (R34.1).** ⟹ attention cannot influence what EVA samples. **P0-01's β₄
    random-audit stratum exists precisely so that salience cannot determine
    coverage.**

⟹ **R44.3 («separate important from true and permitted»):**
     IMPORTANT  = influence-plane, attention-determined, local, learnable,
                  budgeted, and **carries no warrant and no authority**
     TRUE       = alethic, EVA-determined, external, and **not a
                  communication-layer property at all** (§17.1 row 5)
     PERMITTED  = deontic, KC-2-determined, external, Framing C
   **Three words, three planes, three principals. V3 §23's «weighted,
   contextual, trusted communication" put all three in one edge.**
```

---

# §45. LEARNING SIGNALS

## 45.1 The eight learning signal types and their scope

| Signal | **Scope** | Class | Delivery | **Global broadcast required?** |
|---|---|---|---|---|
| **Prediction error** | **LOCAL** — the predicting cell computes `‖ŷ − y‖ > θ_pe` on a **registered** prediction past its `resolution_deadline` (Cell §10 case 3) | S1 (self-computed) / S2 (if it cites an external outcome) | n/a (internal) | ❌ **Never** |
| **Reward** | **TARGETED, not broadcast** | **S3** | ordered-at-least-once, epoch-scoped (Cell §6.2: `eval.reward.v1`, expiry «epoch-scoped») | ❌ **A global reward broadcast is §65's primary target** |
| **Surprise / novelty** | **LOCAL** | S1 | best-effort | ❌ |
| **Reinforcement** | **LOCAL, via eligibility traces** | n/a (internal state) | n/a | ❌ |
| **Supervised feedback** | **TARGETED** | S2/S3 (`eval.error.v1` with `correction`; Cell T3: «**correction provenance must resolve**») | at-least-once + idempotent | ❌ |
| **Unsupervised / self-supervised** | **LOCAL** | n/a | n/a | ❌ **Cell T4: «may not modify `θ` in a direction that increases its own reward» — checked externally** |
| **Gated error signal** | **LOCAL** | S1 | at-least-once + idempotent (§7.2) | ❌ |
| **Demand / morphogen** | **REGIONAL DIFFUSION** | S1 (`dev.morphogen.v1`, organism-signed) | **best-effort with periodic re-assertion** (§7.2) | ❌ **Regional, not global — and diffusion is the correct mechanism because a GRADIENT is the intended semantics (§24.1)** |

## 45.2 «Avoid requiring global broadcasts for every cell»

> ### **R45.1.** *No learning signal in this contract requires a global broadcast. Reward is targeted and epoch-scoped; error and surprise are local; demand is regional diffusion; reinforcement is internal state.*

```
WHY THIS MATTERS MORE THAN IT APPEARS:

  A GLOBAL REWARD BROADCAST would be:
    • O(N) per reward event (§65's audit)
    • **a synchronization point** — every cell receiving the same reward at
      the same epoch is a global barrier, and §9.3 established that no
      mechanism may require synchronization
    • **a credit-assignment ambiguity** — a global scalar cannot distinguish
      which of ten million contributors is being rewarded, so §46's problem
      becomes unsolvable by construction
    • **an amplification channel** — §35's cascade with a legitimate source

  THE ALTERNATIVE, WHICH THE PRIOR CONTRACTS ALREADY SUPPLY:
    P0-01's fitness is a VECTOR with per-subject, per-circuit, per-region,
    and per-population scopes (§25.1's four subject levels). **A vector
    with scoped components is delivered to the subjects it describes, not
    broadcast to everyone.** Cell §6.2's `eval.reward.v1` is targeted
    («Priority 1», «epoch-scoped»), and P0-01 R6.7 closes the channel to a
    single producer.

⟹ **R45.2 (THE LOCALITY OF LEARNING).** *Learning is local; the SIGNALS
   that gate learning are targeted; the MEASUREMENTS that authorize
   consequential learning-derived changes are external.* **This is P0-01
   §23.2's table in communication form: per-step learning needs no causal
   attribution and no global signal, and is acceptable as correlational
   «because the updates are provisional, rate-limited, and rollback-able».**
```

---

# §46. CREDIT ASSIGNMENT

## 46.1 «Do not assume a simple scalar reward is enough»

**Correct — and the reason is information-theoretic, not merely practical.**

```
A SCALAR REWARD R AT THE END OF AN EPISODE, DISTRIBUTED OVER k CONTRIBUTORS,
CARRIES log2(1) = 0 BITS ABOUT WHICH CONTRIBUTOR MATTERED.

THE INFORMATION REQUIRED TO ASSIGN CREDIT IS AT LEAST:
  • which contributors were ACTIVE              (k bits, or an eligibility
                                                 trace per connection)
  • in what ORDER, and with what DEPENDENCY     (§10's dependency metadata)
  • what each CONTRIBUTED, holding others fixed  (**counterfactual — and
                                                 this is the expensive one**)

⟹ **THE FIRST TWO ARE CHEAP AND LOCAL. THE THIRD IS NOT, AND P0-01 ALREADY
   PRICED IT:** §22.3's Tier 3 counterfactual ablation is `O(n × episode)`,
   and F-IMP-1 found it infeasible on edge platforms.
```

## 46.2 The seven candidates compared

| Mechanism | Cost | **Causal?** | Where it lives | Verdict |
|---|---|---|---|---|
| **Temporal credit** (reward the recently active) | `O(1)` | ❌ Correlational | Local eligibility trace | ✅ **Necessary, insufficient — and Cell §14.3 names the failure: «Without it, a connection is strengthened because it was *active*, not because it *contributed*»** |
| **Eligibility traces** (λ-decay) | `O(degree)` per cell | ❌ **Correlational** | **Local, per-connection** (Cell §14.3: `eligibility_trace` decays with λ per step) | ✅ **ADOPTED as the local mechanism.** P0-01 §23.2 explicitly permits it: learning is `NONE / CORRELATIONAL`, acceptable «because the updates are provisional, rate-limited, and rollback-able (R22.2)» |
| **Causal tracing** (dependency graph) | `O(edges traversed)` | ⚠️ **Dependency, not causation** (§10.1) | **Anchored log, off-line** (§15.3 Tier 2/3) | ✅ **ADOPTED as the retrospective reconstruction path** |
| **Contribution attribution** (Shapley-class) | **`O(2^k)` exact; polynomial approximations** | ⚠️ | EVA | ⚠️ **P0-02 §32's M-4 flagged exact attribution as optional; the approximate forms are EVA's, not the communication layer's** |
| **Perturbation-based attribution** | `O(n × episode)` | ✅ **CAUSAL** | **EVA, off-substrate** | ✅ **P0-01 §22.3 Tier 3 — the only causal mechanism in the architecture** |
| **Counterfactual evaluation** | `O(n × episode)` | ✅ **CAUSAL** | EVA | ✅ Same |
| **Distributed credit signals** (a message carrying credit) | `O(messages)` | ❌ | — | ❌ **REJECTED — §46.3** |

## 46.3 The field that must not exist

> ### **R46.1.** *`credit`, `contribution`, `reward_share`, and `utility` are **FORBIDDEN** as cell-generated message fields (§4.4).*

```
WHY — AND IT IS NOT CAUTION, IT IS AN ATTACK-SURFACE ARGUMENT:

  A message carrying its own credit value creates a channel by which a
  subject can assert its own contribution. **Asserting one's own
  contribution is self-evaluation**, and self-evaluation is:
    • forbidden by P0-01 INV-02 (`V(x)` produced only by EVA)
    • forbidden by Cell §7.3 (a cell is not a verifier; `ATTEST_VERIFIED`
      is C3-only with countersignature and is «the most restricted output
      in the contract»)
    • the mechanism of §47's credit-assignment manipulation

  ⟹ **CREDIT IS COMPUTED, NEVER TRANSMITTED BY THE CREDITED PARTY.**
     Local:  the eligibility trace (a state, not a message field).
     Global: EVA's attribution, delivered as an S3 VERDICT to the subject
             it describes.

⟹ **WHAT COMMUNICATION MUST CARRY FOR CREDIT ASSIGNMENT TO BE POSSIBLE —
   AND IT IS ONLY FOUR THINGS:**
     1. `conv_id`      — episode linkage, so contributions can be grouped
     2. `seq`          — order within the episode
     3. `causal_depth` — the dependency structure's depth
     4. `root_commit`  — so shared-dependency contributions are not
                        double-credited (§14's problem, in credit form:
                        **two contributors citing the same root did not
                        make two independent contributions**)
   **Plus the LOCAL eligibility trace, which never leaves the cell.**

⟹ **AND WHAT IT MUST NOT CARRY: any value, weight, share, or utility.**
```

**R46.2 (THE DIVISION, STATED AS THE BRIEF ASKS).** *Communication metadata supplies **the structure within which credit can be assigned**. The learning subsystem assigns **provisional, correlational, rollback-able** credit locally from eligibility traces. EVA assigns **authoritative, and where required causal,** credit from anchored reconstruction plus perturbation. **No layer transmits a credit value.** *

---

# §47. REWARD HACKING THROUGH COMMUNICATION

## 47.1 «Can communication become an evolutionary loophole?»

> ### **YES — five ways. Three are closed structurally, two are bounded and remain open.**

| # | Path | Mechanism | **Status** | Defence |
|---|---|---|---|---|
| **RH-1** | **Manufactured evidence volume** | Emit many S2 messages citing many roots, all descending from one sensor or one upstream feed | ⚠️ **BOUNDED** | §14.4's independence check on dims 1 and 4; **R37.2's `n_effective` bound**: a million messages from one upstream contribute one upstream-independent sample |
| **RH-2** | **Manufactured agreement** | Coordinate `OPAQUE` traffic among a coalition so that many subjects appear to converge | ⚠️ **BOUNDED — and this is the harder of the two** | Aggregate opaque-volume observability (§50) · region-crossing rate limits · lineage-concentration limits (Cell §14.2 step 3) · **§14.3's dim 2 detects coalition-by-lineage; a coalition across lineages is dim 6 and is NOT detectable (§37.2)** |
| **RH-3** | **Manufactured demand** | Flood `RESOURCE`/`REQUEST_RESOURCE` so allocation follows | ✅ **CLOSED** | **Demand is metered against actual consumption** (P0-02 §18.3's attribution; Cell §4.1's `cost_declared` vs `cost_measured` divergence). **A demand unsupported by measured consumption is an anomaly, and the divergence itself is a G6 disqualifier (Cell §22)** |
| **RH-4** | **Manufactured error reduction** | Suppress or fail to emit prediction-error signals so the subject appears accurate | ✅ **CLOSED — and the closure is elegant** | **Cell §9.2's T1 trigger requires a REGISTERED prediction past its `resolution_deadline`.** A subject that stops registering predictions stops producing error — **and the absence of registered predictions is itself observable**: `open_predictions` register (Cell §17's adaptation requirement) empty at high activity is anomalous. **⟹ R47.1: zero measured error at high activity is a DETECTOR, not a success. A subject too accurate to produce error signals is a subject that has stopped making falsifiable claims** |
| **RH-5** | **Manufactured evaluator signals** | Forge or induce `eval.reward.v1` / `VERDICT` | ✅ **CLOSED — structurally** | §41.2's four closures; Cell §6.2: «a cell signature on `eval.reward.v1` is **structurally invalid** — S1 rejects it. This closes the audit's most severe communication defect (any cell could forge reward) **at the type level rather than by policy**» |

## 47.2 The residual, stated without softening

```
RH-1 AND RH-2 ARE BOUNDED, NOT CLOSED, AND THE BOUND HAS A NAME:

  Both exploit the fact that WARRANT is computed from declared correlation
  dimensions, and **dims 3, 5, and 6 are approximate or undetectable
  (§14.3)**. A coalition that is diverse in lineage, roots, sensors, and
  hardware — but shares dim 6 (the designers' latent assumptions) or dim 3
  (a common learned bias) — produces manufactured agreement that every
  mechanism in this contract correctly reports as independent.

  ⟹ **This is P0-01's CD-8 and P0-02's IND-6, arriving a third time.** It
    appeared as sim-to-real circularity (P0-01), as evaluator independence
    (P0-02 §35.4), and now as communication-based reward hacking. **Three
    packages, one limit, and it is the same limit each time: a system
    cannot detect correlation with an assumption it does not know it made.**

  ⟹ **R47.2: the only mitigation is external — P0-01 INV-43's real-world
     anchor, whose budget is non-reducible (R35.1) and whose funding is a
     governance obligation (P0-02 §46.3).** No communication mechanism
     closes RH-2, and any claim that one does is §88's false precision.

AND ONE POSITIVE RESULT WORTH RECORDING:
  **RH-4's closure is the only one that works by making the ABSENCE of a
  signal informative.** Every other defence validates a present signal.
  R47.1 generalizes: **in an architecture where prediction error is the
  primary learning signal (Cell §10 case 3: «this is the primary learning
  signal»), the cessation of error is the most reliable available indicator
  that a subject has stopped engaging with the world.** ⟹ **This should be
  an I-18 observable at the population level, and §86 lists it as one of
  the few communication statistics that must be observable for safety
  rather than for debugging.**
```

---

*End of Volume C. Volume D (`20_analysis_evolution_hardware.md`) covers §48–§66: evolution of communication, novel protocols, semantic emergence, specialization feedback, hub cells, echo chambers, communication homeostasis, communication immunity, hardware adaptation and co-design, the security threat model, privacy boundaries, failure recovery, checkpoint/replay, observability, information-theoretic analysis, computational complexity, the global broadcast audit, and the communication economy.*
