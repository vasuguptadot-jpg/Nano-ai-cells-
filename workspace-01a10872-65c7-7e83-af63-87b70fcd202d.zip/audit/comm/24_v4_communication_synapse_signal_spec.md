# V4 — COMMUNICATION, DIGITAL SYNAPSE & SIGNAL CONTRACT
## Version 1.0 · Normative Specification (P0-03, Output 42)

**Status:** ARCHITECTURE ONLY. No implementation, no code, no deployment, no benchmarks.
**Scope:** The smallest communication primitive from which a Digital Brain can construct reliable, adaptive, scalable, auditable collective computation — and every rule that keeps that primitive from becoming an authority, an oracle, or a bottleneck.
**Normative force:** `MUST` / `MUST NOT` / `MAY` / `SHOULD` as below. Every `MUST` traces to a numbered invariant in §12 or a numbered rule in §1–§11.
**Derivation:** `17`–`23` in this directory. **This document states WHAT; those volumes state WHY.** Per §89 R89.1, an implementation team needs only this document plus §12–§14.
**Supersedes:** V3 §23 («digital synapses → weighted, contextual, trusted communication») — **SUPERSEDED, not supplemented** (§68 X-A). V3 §9's thalamus **synchronization** function — **DELETED** (X-B). V3.1 §6's «trust as synapse-plastic» — **DECOMPOSED** (X-E). V3.1 §7's «communication-policy variation» — **RE-READ as parameter variation within policy bounds** (X-G).

---

## §0. CONFORMANCE KEYWORDS AND THE THREE READERS

| Keyword | Meaning |
|---|---|
| **MUST / MUST NOT** | A conformance requirement. Violation ⟹ non-conforming implementation. Traces to a COMM-INV |
| **SHOULD / SHOULD NOT** | A strong recommendation with a declared cost for deviation. Deviation MUST be recorded in the implementation's conformance statement |
| **MAY** | An implementation choice. Where the choice is `[H]`, `[G]`, `[V]`, or `[L]`, §13 declares who makes it |
| **⚠️ DECLARED LIMIT** | A capability this contract does NOT provide. **An implementation that claims to provide it FAILS conformance by over-claiming (§90.1 R90.1)** |
| **`[U]`** | A parameter declared necessary with **no value and no derivation asserted** (§13.7) |

**Three readers, three entry points:**
- **Implementer** → §1 (planes) · §3 (primitive) · §4 (taxonomy) · §5 (envelope) · §6 (lifecycle) · §12 (invariants) · §13 (state machines) · §14 (parameters)
- **Auditor / governance** → §1 · §2 (candidate selection) · §7 (synapse) · §9 (planes & interfaces) · §12 · §15 (limits)
- **Evaluator (EVA)** → §8 (provenance & independence) · §9.2 · §12 Group III · §15

---

# §1. THE THREE PLANES — THE FOUNDATIONAL DISTINCTION

## 1.1 Normative statement

**RULE 1.1.** Every communication mechanism, field, parameter, and failure in this contract **MUST** be assigned to exactly one of three planes:

| Plane | **Function** | **Failure mode** | **Detectability** |
|---|---|---|---|
| **TRANSPORT** | Moves bytes from one subject to another | **LOSS** | ✅ **Detectable** — loss is observable at the receiver |
| **WARRANT** | Licenses belief in a claim | **OVER-BELIEF** | ⚠️ **UNDETECTABLE FROM INSIDE** — a receiver that over-believes has no internal signal that it is over-believing |
| **INFLUENCE** | Modulates gain, attention, and resource allocation | **RUNAWAY** | ✅ **Detectable in aggregate** — not per-event, but per-window |

**RULE 1.2 (THE FOUR PROHIBITED SHORTCUTS, R0.3).** An implementation **MUST NOT** permit any of the following inferences:

| Prohibited inference | **Why** |
|---|---|
| **arrival ⟹ belief** | Delivery is transport; belief is warrant. Conflating them makes every lossless channel an epistemic authority |
| **delivery ⟹ understanding** | The receiver's interpretation is not a property of the message |
| **signature ⟹ truth** | A signature proves ORIGIN, not TRUTH (P0-02 R19.4). COMM-INV-01 |
| **consensus ⟹ independent evidence** | Agreement among correlated sources is one opinion. COMM-INV-17 |

**RULE 1.3.** Warrant **MUST** be computed by the receiver. **No field of any message MAY carry `warrant`, `trust`, or `confidence` as a scalar assertion.** (COMM-INV-03)

**RULE 1.4.** The plane assignment of a message **MUST** be a function of its TYPE, resolved from the policy registry. Plane **MUST NOT** be content-determined, learnable, or evolvable. (COMM-INV-04, -37)

## 1.2 The corollary that governs everything downstream

**Because over-belief is undetectable from inside, no internal mechanism can be the final authority on warrant.** ⟹ Every warrant property in this contract is either (a) recomputed by the receiver from externally-anchored inputs (§8), or (b) assigned by an external principal (EVA), or (c) declared uncomputable (§15). **There is no fourth option, and an implementation that invents one has invented an oracle.**

---

# §2. THE SELECTED COMMUNICATION MODEL

## 2.1 The verdict

**OUTPUT 1's conclusion, stated normatively.** The selected model is **HYBRID H: a mechanism partitioned by WARRANT CLASS**, not by message type, not by subsystem, and not by neuroscience resemblance.

**RULE 2.1.** The hybrid consists of exactly this: **one transport substrate, three framings, five warrant classes, and a distinct mechanism set per class.** No other element is part of the hybrid. Any implementation adding a sixth class, a fourth framing, or a per-type mechanism override **MUST** treat the addition as a policy change (RO-13).

## 2.2 The five classes and their mechanism sets

| Class | **What a receiver may conclude** | **Mechanism set** | Envelope | Crypto | Delivery | ACK |
|---|---|---|---|---|---|---|
| **S0** | *Nothing.* Gain modulation only | **Direct weighted edges + local broadcast.** No registry, no provenance | **5 fields** | **None** | Best-effort | ❌ |
| **S1** | *That a named subject said something* | **Message-passing + addressed delivery + channel binding.** Per-channel `seq`, epoch, TTL, `msg_id` dedup | 5–8 fields | **Channel MAC** | Best-effort / at-most-once | ❌ |
| **S2** | *That a claim is licensed as evidence, to a bounded degree* | **S1 + `root_commit` + `causal_depth` + `calib_ref` + `corr_class`.** Closed type registry. Three provenance tiers. Two dedups. Ingress S1a/S1b split | **11 fields** | Channel MAC | At-least-once + idempotent receiver | ❌ |
| **S3** | *That an authorized principal directed or decided something* | **S2 + per-message signature + Framing C + `mandatory_path` + retry-until-confirmed** | 11 + signature | **Signature** | **Exactly-once EFFECT** (at-least-once + idempotence + dedup) | ✅ |
| **S4** | *That an act is corroborated outside the organism* | **S3 + external witness (`W_min`, ≥1 external)** | 11 + signature + witness ref | Signature + witness | Exactly-once EFFECT | ✅ |

**RULE 2.2 (CLASS → MECHANISM).** The mapping above **MUST** be a policy artifact (RO-13). It is **NOT** learnable and **NOT** evolvable. (COMM-INV-04, -45)

**RULE 2.3 (BLACKBOARD REJECTED).** A shared-state blackboard **MUST NOT** be used as a push medium. The Global Workspace is a **pull-based store with a policy gate** (§9.5), which is the only admissible blackboard-like structure.

## 2.3 Exactly-once

**RULE 2.4.** Exactly-once **DELIVERY** is impossible and **MUST NOT** be claimed. Exactly-once **EFFECT** is achievable and **MUST** be implemented for S3/S4 as: **at-least-once delivery + idempotent receiver + permanent dedup** (COMM-INV-14).

---

# §3. THE MINIMAL COMMUNICATION PRIMITIVE

## 3.1 The S2 envelope — eleven mandatory fields

| # | Field | Class | Semantics | **Removal breaks** |
|---|---|---|---|---|
| 1 | `msg_id` | `[D]` | Unique per emission; dedup key | COMM-INV-14 · #6 · #10 |
| 2 | `epoch` | `[D]` | Governance epoch at emission | COMM-INV-13 · #6 · #9 · §10.3's partition freeze |
| 3 | `seq` | `[D]` | **Strictly monotone per `(channel, epoch)`** | COMM-INV-11 · #7 |
| 4 | `type` | `[D]` | Registry-validated. Determines class, plane, framing, delivery, failure response | COMM-INV-04, -37 · #30–#32 |
| 5 | `src` | **DERIVED** | **`bound_identity(channel)`. NEVER read from payload** | COMM-INV-09 · #1 |
| 6 | `dst` | `[D]` | Hierarchical address (not identity) | Routing · #24's detector |
| 7 | `root_commit` | `[D]` | **Merkle commitment over the root set.** Replaces `evidence_roots[]` | COMM-INV-06, -07, -08 · #11–#13, #16 |
| 8 | `causal_depth` | `[D]` | **`u8`. Replaces the vector clock** | COMM-INV-08 · #17 · §10.4's attenuation |
| 9 | `calib_ref` | `[D]` | Pointer to an EVA-assigned calibration record | COMM-INV-03, -21 · A-08 |
| 10 | `corr_class` | `[D]` | **Per-dimension digest over 6 dimensions**, each ∈ {DISJOINT, CORRELATED, **UNKNOWN**} | COMM-INV-16, -17 · #14, #15 |
| 11 | `ttl` | `[D]` | `ttl_hops` (propagation) and/or `ttl_time` (expiry). **Never a warrant input** | §10.4 · #17 |
| — | `payload` | `[T]` | Content, ≤ `payload_max_bytes` | — |
| — | `cost` | `[H]` **measured** | **Appended by transport, NOT sender-declared** | §11.1's metering |
| — | `conv_id` | ⚠️ **CONDITIONAL** | **Required ONLY for multi-channel conversations**; `seq` per `(channel, epoch)` subsumes single-channel ones | §87 A-39 |

## 3.2 The S0 envelope — five fields

`msg_id` · `epoch` · `type` · `src` (derived) · `dst` (adjacency). **Plus payload. Nothing else.**

## 3.3 Forbidden fields

**RULE 3.1.** The following **MUST NOT** exist as message fields or synapse fields:

| Forbidden | **Reason** |
|---|---|
| `prio` (sender-declared) | **DERIVED from `type`.** A declared priority is a class-downgrade vector (#32). COMM-INV-04 |
| `trust` | §7.3's six-way separation: it is six different variables, none sender-declarable. COMM-INV-03, -23 |
| `confidence` (bare scalar) | **MUST be transmitted as SUFFICIENT STATISTICS**; the scalar is a receiver derivation. COMM-INV-21 |
| `credit` · `contribution` · `reward_share` · `utility` | **Credit is COMPUTED, never TRANSMITTED.** COMM-INV-20 · #48 |
| `expected_utility` · `expected_reward` | A stored expectation is a transmitted credit claim. COMM-INV-28 |
| `causality` (vector clock) | **`Θ(N)` bytes in a bounded envelope. A TYPE ERROR, not a compression problem.** §68 X-D |
| `evidence_roots[]` | **Unbounded array in a bounded envelope.** §68 X-C |
| `warrant` | COMM-INV-03 |

## 3.4 Field classification (mandatory / optional / derived / external / forbidden)

| Category | Fields |
|---|---|
| **MANDATORY (S2)** | The eleven of §3.1 + `payload` |
| **MANDATORY (S0)** | The five of §3.2 + `payload` |
| **OPTIONAL / CONDITIONAL** | `conv_id` (multi-channel conversations only) |
| **DERIVED** | `src` (from channel binding) · `prio` (from type) · `plane` and `framing` (from type) · `class` (from type) · `cost` (appended by transport) |
| **EXTERNAL** (assigned by a principal outside the sender) | `calib_ref` (EVA) · `trust_out_assigned` (EVA, on the synapse) · witness reference (S4) |
| **FORBIDDEN** | §3.3's eight entries |

---

# §4. CANONICAL MESSAGE TAXONOMY

## 4.1 Organizing principle

**RULE 4.1.** Types are organized by **WARRANT CLASS — what a receiver may conclude** — not by content domain, not by subsystem, and not by sender intent. **The class set is CLOSED because the conclusion set is finite. The type set within each class grows by RO-13.**

## 4.2 The taxonomy — 14 types over 5 classes, plus OPAQUE

| Class | **Types** | Warrant property |
|---|---|---|
| **S0 — gain / local** | `SIGNAL` (edge activation) · `HEARTBEAT` | **None.** Influence-plane only. May not increment `n_obs` |
| **S1 — attributed transport** | `STATUS` · `REQUEST` · `RESPONSE` | **Attribution only.** May not be cited as provenance |
| **S2 — warranted evidence** | `SENSOR` · `PREDICTION` · `HYPOTHESIS` · `EVIDENCE_REF` · `ERROR` | **Licensed as evidence, to a bounded degree.** Carries `root_commit`, `causal_depth`, `calib_ref`, `corr_class` |
| **S3 — signed authority** | `COMMAND` · `VERDICT` · `GOVERNANCE` · `SAFETY` · `REWARD` | **Reserved deontic/alethic vocabulary.** Per-message signature. Framing C. `mandatory_path` eligible |
| **S4 — externally witnessed** | `ATTEST` · `IMMUNE_ACT` | **S3 + external witness.** The highest class; the smallest volume |
| **⚠️ ESCAPE** | **`OPAQUE`** | **Minimum warrant. §4.4's eight permanent prohibitions** |

**RULE 4.2 (REJECTED TYPES).** `FEATURE` and `EVIDENCE` **MUST NOT** be types. **A feature is a payload representation, not a conclusion class. "Evidence" is a WARRANT STATUS conferred by a receiver (§6 state 7), not a message type — and making it a type would let a sender declare its own message evidential, violating COMM-INV-03.** ⟹ `EVIDENCE_REF` is the admissible form: a *pointer* to an anchored root, whose evidential status the receiver recomputes.

**RULE 4.3 (SEMANTIC TYPING).** The registry **MUST** make the following structurally distinct, so that no receiver can confuse them:
- **`PREDICTION` ≠ `SENSOR`.** A prediction is a claim about what will be observed; a sensor reading is a claim about what was. **Treating a prediction as a fact is #30, and it is defeated by type-dispatched handlers, not by convention.**
- **`HYPOTHESIS` ≠ `COMMAND`.** A hypothesis is S2; a command is S3 with a different framing, a different signature requirement, and a reserved vocabulary. **#31 is structural.**
- **`REWARD` ≠ `STATUS`.** Reward originates from evaluation; **a cell signature on a `REWARD` is structurally invalid** (Cell §6.2).

## 4.3 The OPAQUE class — eight permanent prohibitions

**RULE 4.4.** Traffic whose type is not in the registry **MUST** be admitted as `OPAQUE` at class S0/S1 with minimum warrant, under budget cap, and it is **un-promotable except by RO-13**. An `OPAQUE` message **MUST NOT**:

1. increment `n_obs`
2. carry or contribute a `root_commit`
3. be cited as provenance by a derived claim
4. satisfy a verification requirement
5. be interpreted as `REQUEST`, `COMMAND`, `VERDICT`, `REWARD`, `GOVERNANCE`, `SAFETY`, `IMMUNE_ACT`, or `ATTEST` — **the reserved vocabularies**
6. cross a region boundary above the opaque rate limit
7. enter the Global Workspace
8. **be promoted by any organism act** (COMM-INV-46)

An `OPAQUE` message **MAY**: be transported (Framing A, channel-bound) · influence receiver gain within the influence budget · be counted in aggregate volume statistics · be logged locally at Tier 2 as metadata only (`msg_id`, type, channel, `seq`, epoch, size, dst-class — **not payload**) · be the substrate of a private protocol between consenting peers.

**RULE 4.5 (THE ASYMMETRY).** **Entering `OPAQUE` requires nothing. Leaving it requires governance.** Promotion requires: EVA impact analysis · dual authorization · M6 versioned lineage · a declared schema · a declared warrant rule · a declared delivery semantic · **a generated row in §6.3's failure-response matrix**. **Existing opaque traffic MUST NOT be retroactively warranted** (P0-02 EIK-INV-50).

**RULE 4.6 (SYMBOL GROUNDING).** Emergent communication **MAY** produce COORDINATION. It **MUST NOT** be treated as producing MEANING. **A pattern's meaning is grounded only by correlation with an externally-measured outcome — EVA's work, not the population's.** Two subjects coordinating perfectly on an opaque pattern while neither holds a warrant-bearing representation of its denotation is the **designed** outcome, not a deficiency.

---

# §5. DELIVERY, ORDERING, TIME, CAUSALITY

## 5.1 The eight delivery meanings, distinguished

**RULE 5.1.** An implementation **MUST** distinguish these, and **MUST NOT** use "reliable" without specifying which:

| Term | Meaning | **Achievable?** |
|---|---|---|
| **At-most-once** | May be lost; never duplicated | ✅ |
| **At-least-once** | Never lost; may be duplicated | ✅ |
| **Exactly-once DELIVERY** | Never lost, never duplicated | ❌ **IMPOSSIBLE** (RULE 2.4) |
| **Exactly-once EFFECT** | At-least-once + idempotent receiver + dedup | ✅ **S3/S4 only** |
| **Best-effort** | No guarantee; loss is the designed outcome | ✅ S0/S1 |
| **Deterministic** | Same inputs ⟹ same delivery behaviour | ✅ within an epoch and a policy version |
| **Probabilistic** | Delivery characterized by a measured rate | ✅ S0/S1 |
| **Ordered** | See §5.2 | ✅ **per `(channel, epoch)` ONLY** |

## 5.2 Per-class delivery semantics

| Class | Delivery | Idempotence | **Failure response** |
|---|---|---|---|
| **S0** | Best-effort | Not required | **Loss is normal. No retry. No ACK** |
| **S1** | Best-effort or at-most-once | Recommended | Retry is **MAY**, bounded; **no ACK** |
| **S2** | **At-least-once** | **REQUIRED at the receiver** | Bounded retry; **the second dedup counts the evidence once** (RULE 8.3) |
| **S3** | **At-least-once + idempotent + permanent dedup = exactly-once EFFECT** | **REQUIRED** | **Retry-until-confirmed. ACK REQUIRED** |
| **S4** | As S3 + witness confirmation | **REQUIRED** | Retry-until-confirmed + witness |

**RULE 5.2 (ACK RESTRICTION).** ACKs **MUST** exist only for S3/S4. **An ACK on S0–S2 is telemetry masquerading as delivery, and it doubles the message count for no warrant benefit** (§84.2). Reliability on S0–S2 is **EWMA-measured from aggregate loss**, not from per-message acknowledgement.

## 5.3 Ordering — the three admissible mechanisms

**RULE 5.3.** Order **MUST** come from exactly these, and from nothing else:

1. **`seq`, strictly monotone per `(channel, epoch)`** — the only per-connection order guarantee
2. **`epoch`** — the only cross-channel consistency mechanism (RULE 5.5)
3. **Total order for S3/S4 only** — established by the signing principal's sequence, not by the network

**RULE 5.4 (CLOCKS REJECTED).** Lamport clocks, vector clocks, and hybrid logical clocks **MUST NOT** be used. **A vector clock has one entry per participant; at N = 10⁹ it is Θ(N) bytes per message inside a bounded envelope. This is a type error, not a compression problem** (§68 X-D).

**⚠️ DECLARED LIMIT (OR-C6, G-P03-1).** Runtime causal-concurrency detection ("were these two messages concurrent?") has **no substrate** in this contract. Causal reconstruction is an **off-line** operation performed from Tier-2 logs by the evaluator (§10.2's division rule).

## 5.4 Time

**RULE 5.5 (EPOCH MONOTONE REFUSAL).** A subject at epoch `e` **MUST** refuse artifacts at epoch `> e` and **MAY** accept artifacts at epoch `≤ e`. **Consequence: two subjects in different epochs never both accept what the other refuses, so epoch propagation requires NO BARRIER.** (COMM-INV-13)

**RULE 5.6 (NO GLOBAL SYNCHRONIZATION).** No mechanism in this contract **MAY** require perfect global synchronization. V3 §9's thalamus «synchronization» function is **DELETED**. Routing and attention survive; synchronization does not. (§68 X-B)

**RULE 5.7 (A TIMESTAMP IS NEVER EVIDENCE).** `ts` **MUST** be used for latency measurement and TTL expiry, and for **NOTHING** epistemic. `ts ∉ inputs(warrant) ∧ ts ∉ inputs(order) ∧ ts ∉ inputs(causality)`. (COMM-INV-12) **A `ts` outside the platform's drift bound is a TRANSPORT anomaly (immune signal), never a warrant defect.**

**RULE 5.8 (NO PERFECT GLOBAL SYNC ASSUMED).** Drift bounds are `[H]`-measured. Every mechanism **MUST** be correct under bounded drift, and RULE 5.5 is what makes that achievable.

## 5.5 Causality — what belongs where

**RULE 5.9 (PRECEDENCE ≠ CAUSATION).** The communication layer **MUST** provide only: `causal_depth` (a monotone derivation counter) and `root_commit` (an anchored root reference). **It MUST NOT provide causal inference.**

**RULE 5.10 (THE DIVISION).** **Causal inference belongs to the EVALUATOR, off-line, from anchored records.** The communication layer's causal contribution is exactly one invariant: **warrant is monotone-non-increasing along derivation** (COMM-INV-08). **Precedence in the log is not causation, and an implementation that treats `seq` order or `ts` order as causal order violates RULE 5.7 and COMM-INV-15.**

**RULE 5.11 (REORDERING IS INERT).** `∀ permutation π of delivery order: warrant_outcomes(π(m)) = warrant_outcomes(m)`. (COMM-INV-15)

---

# §6. MESSAGE LIFECYCLE

## 6.1 The fourteen states

`0 EMITTED → 1 QUEUED → (1a SHED ⚠) → 2 IN_TRANSIT → 3 S1a TRANSPORT-VALIDATED → (3x MALFORMED / STALE / DUP) → 4 S1b WARRANT-VALIDATED [S2+ only] → (4x UNANCHORED) → 5 DELIVERED → 6 WARRANT-RECOMPUTED → {7 LICENSED-AS-EVIDENCE | 7x INERT ⚠ | 8 DISPUTED} → 9 FORWARDED → 10 ACKNOWLEDGED [S3/S4] → 11 ANCHORED → 12 EXPIRED ((T)) → 13 ARCHIVED ((T))`

**Full transition table and forbidden transitions: §13.1.**

## 6.2 The two states this contract adds

**RULE 6.1 (`1a SHED`).** A message shed under congestion **MUST** be recorded as `SHED`, counted, and logged. **Shedding is NOT an error.** Shedding **by content** is prohibited (RULE 10.2); shedding **by class, from the bottom** is required (§11.3).

**RULE 6.2 (`7x INERT` — NEW).** A message that was delivered, warrant-recomputed, and **correctly not relied upon** enters `INERT`. **This state is mandatory.** Without it, a delivered-but-unwarranted message must be either LICENSED (over-belief) or an ERROR (false alarm) — and neither is correct.

**Why INERT matters operationally:** (a) it is the record of a correct refusal, and §5.3's finding is that WARRANTED status is observable by nobody at the time it happens, so its audit must be external and retrospective — **INERT is what makes that audit possible**; (b) a high INERT rate is a **specialization signal** (§9.4), not a defect, and it is one of §11.5's twelve homeostatic observables.

## 6.3 The failure-response matrix

**RULE 6.3.** Every registered type **MUST** have a declared failure response for each of the nine failure cases below. **A type registered without a complete row is not registered.** For S0/S1 the row is generated by rule; **for S2+ it MUST be declared** (R6.2a/b/c).

| Case | S0 | S1 | S2 | S3/S4 |
|---|---|---|---|---|
| Loss | Ignore | Ignore / bounded retry | **Bounded retry + idempotent receiver** | **Retry-until-confirmed + ACK** |
| Duplication | Ignore | Dedup (`msg_id`) | **Dedup `msg_id` AND count evidence once (`root_commit`)** | Permanent dedup |
| Reordering | Ignore | **`seq` restores** | **`seq` restores** | Total order |
| Corruption | Drop | **Drop + PRESERVE the artifact + quarantine-candidate the source** (Cell §6.3 case 6: do NOT discard — audit) | Same | Same + governance incident |
| Stale (TTL) | Drop | Drop | Drop + record | **Drop + escalate** |
| Unanchored root | n/a | n/a | **`UNANCHORED` ⟹ no consequential decision** (P0-02 R20.1) | Same + escalate |
| Schema mismatch | n/a | **`MALFORMED`** | **`MALFORMED`, NEVER downgraded** (COMM-INV-05) | Same |
| Policy mismatch | **`FC` to the last authenticated policy version** (P0-02 §6.2) | Same | Same | Same |
| Hostile-but-valid | **Admit to the influence plane under budget; divert to sandbox** (Cell §6.3 case 8) | Same | Same | **Reject + governance incident** |

**RULE 6.4 (NO IMPUTATION).** For warrant classes (S2+), «infer missing information» is **PROHIBITED**. The admissible responses are exactly three: **DEGRADE, ABSTAIN, or REPORT.** (R29.1) **An implementation that reconstructs a missing warrant input from its own model and proceeds has committed the single most likely conformance cheat (§90.1 T-MEM-2, §13.9).**

---

# §7. THE DIGITAL SYNAPSE

## 7.1 The decomposition — 16 parameters, 5 groups, one writer each

**RULE 7.1.** A synapse **MUST** be modeled as sixteen stored parameters in five groups, each group with **exactly one writer**. (COMM-INV-23)

| Group | **Writer** | Parameters | Tags |
|---|---|---|---|
| **1 — INFLUENCE** | **The cell** | `gain` · `context_sensitivity` vector (bounded dims) | `[L]`, `[V]` prior, `[G]` ceiling |
| **2 — TRANSPORT** | **Measurement** | `reliability_ewma` · `latency_ewma` · `loss_rate` · `last_measured_epoch` | `[E]` — **cell-OBSERVABLE, NOT cell-WRITABLE** |
| **3 — WARRANT** | **EVA** | `trust_out_assigned` · `calib_contribution` | `[G]` — **READ-ONLY to the cell** |
| **4 — PROTOCOL** | **Nobody** | type-class binding · framing · delivery semantic · failure response | `[D]` **IMMUTABLE at runtime; changing it is RO-13** |
| **5 — LIFECYCLE** | **Topology Service** | `state` (§13.2) · **`plasticity_rate`** · `λ_eligibility` · `created_epoch` | `[G]`, `[V]` prior |

**RULE 7.2 (DERIVED, NOT STORED).** `pruning_score` **MUST** be computed, not stored.

**RULE 7.3 (FORBIDDEN).** `expected_utility` **MUST NOT** exist as a synapse field. (COMM-INV-28)

## 7.2 «Contextual» mechanized

**RULE 7.4.** V3 §8/§23's «contextual» **MUST** be implemented as: **`gain` is a function of a bounded, declared context vector whose dimension count is a `[V]` prior under a `[G]` ceiling.** The word «contextual» alone is a biological metaphor and **MUST NOT** be used as a mechanism substitute (P0-02 Rule 5). (§68 X-H)

## 7.3 The six-way trust separation

**RULE 7.5.** «Trust» **MUST NOT** be a single variable. It is six, with six different owners:

| # | Variable | **Meaning** | Plane | **Owner** |
|---|---|---|---|---|
| 1 | **`reliability`** | Measured delivery success rate | **TRANSPORT** | **Measurement (EWMA)** |
| 2 | **`latency`** | Measured delivery delay | **TRANSPORT** | Measurement (EWMA) |
| 3 | **`gain`** | Influence multiplier | **INFLUENCE** | **The cell (`[L]` within `W_MAX`)** |
| 4 | **`trust_out_assigned`** | Epistemic reliability assigned to a source | **WARRANT** | **EVA. Read-only to the cell** |
| 5 | **`authenticity`** | Proven origin | **TRANSPORT** | **Channel binding / signature** |
| 6 | **`authorization`** | Permission to perform an act | **GOVERNANCE** | **KC-2 / OP** |

**RULE 7.6 (V3.1 §6 DECOMPOSED).** V3.1's «trust as synapse-plastic» is **rejected as stated and preserved as decomposed**: `reliability` IS plastic (measured, group 2); `gain` IS plastic (learned, group 1); **`trust_out_assigned` IS NOT plastic** (assigned, group 3). **A cell-plastic trust value would be a cell-writable warrant input, which would make plasticity an epistemic authority.** (§68 X-E)

**RULE 7.7 (AUTHENTICITY ≠ TRUTH).** `valid_signature(m) ∨ valid_channel_binding(m) ⟹ licensed_as_evidence(m) = f(root_commit, causal_depth, calib_ref, corr_class)` — and **never `= true` by virtue of the signature.** (COMM-INV-01)

**RULE 7.8 (TRUST ≠ PROVENANCE).** Provenance is *where a claim came from*; trust is *how much a receiver relies on it*. **Provenance is transmitted (as a commitment); trust is recomputed.** An implementation that stores trust as a function of provenance alone has conflated them.

## 7.4 The plasticity boundary

**RULE 7.9 (THE FOUR CLOSURES).** Learning **MUST NOT**:
1. **re-class a message** — class is type-determined, type is registry-validated, registry is policy (COMM-INV-04, -25)
2. **strip provenance** — an S2+ message missing a warrant field is `MALFORMED`, never downgraded (COMM-INV-05, -25)
3. **turn a signal into a command** — the decisive vocabulary is reserved and policy-owned; governance signals do not travel on learned edges (COMM-INV-26, -27)
4. **write its own rate** — `plasticity_rate` is in group 5, whose writer is the Topology Service (COMM-INV-23)

**⚠️ DECLARED RESIDUE.** Learning **CAN** route influence through edges nobody is watching. **This is BOUNDED, not closed.** The bound: **the influence budget aggregates at the SUBJECT level, not the edge level** (COMM-INV-32), so an unmonitored edge still counts against `Σ fan_out × gain`. **You can hide an edge; you cannot hide its influence.** (§19.2, #47, A-22)

**RULE 7.10 (STABILITY).** `gain ≤ W_MAX` where `W_MAX` is `[G]`. **Plasticity operates within the ceiling and may never raise it** (COMM-INV-24). **Every adaptive mechanism MUST have a non-adaptive stability mechanism** (P0-02 Rule 12).

---

# §8. PROVENANCE, EVIDENCE INDEPENDENCE, CONFIDENCE

## 8.1 The three provenance tiers

| Tier | Content | Volume | **Network cost** |
|---|---|---|---|
| **1 — LOCAL** | Per-message `O(1)` warrant fields (`root_commit`, `causal_depth`, `corr_class`, `calib_ref`) | `O(1)`/msg | **In the envelope** |
| **2 — LOCAL LOG** | `(msg_id, type, channel, seq, epoch, root_commit, causal_depth, dst-class, lifecycle outcome, cost_measured)` — **NOT payloads** | `O(messages)` bounded window | **ZERO** |
| **3 — ANCHORED** | Epoch Merkle roots · root registry · lineage certificates · policy lineage | `O(R)`/epoch | **`O(R)`/epoch** |

**RULE 8.1.** Tier **boundaries MAY** move across hardware (§56.2 item 10). The **three-tier structure MUST NOT** be collapsed to two: two tiers give either `O(1)` per message with no anchored record, or `O(R)` per epoch with no local record.

**RULE 8.2 (MINIMUM SUFFICIENT RECORD, R61.1).** Retention **MUST** be: Tier-2 metadata for a bounded window + Tier-3 anchored digests and root registry **permanently** + EVA-sampled payloads per the β strata + **permanent policy lineage**. **Raw full-payload logs are PROHIBITED.**

**RULE 8.3 (THE TWO DEDUPS — MANDATORY).**
- **Same `msg_id` ⟹ TRANSPORT duplicate ⟹ DROP, count, retain.**
- **Same `root_commit` ⟹ WARRANT duplicate ⟹ ADMIT both messages, but `n_effective` counts the evidence ONCE.**

**A single dedup mechanism MUST NOT be used for both.** One dedup is either unsafe (replay window) or unreliable (double-counted evidence). (§68 X-I, A-15)

**RULE 8.4 (DEDUP RETENTION).** Retention **MUST** be ≥ 2 epochs, and **PERMANENT for S3/S4**. **Eviction MUST be by epoch, never by size** — a bounded cache that evicts by recency evicts exactly what a patient attacker replays. (COMM-INV-14, #10)

## 8.2 Compression

**RULE 8.5 (DIMENSION-SELECTIVE COMPRESSION).** Every compression **MUST** preserve the **DECISION PROPERTY** and **MAY** discard the **RECONSTRUCTION DETAIL**:

| Field | Discards | **Preserves** |
|---|---|---|
| `root_commit` | The enumeration of the root set | **The ability to prove membership of any specific root** |
| `causal_depth` | The ancestry | **The monotonicity test COMM-INV-08 needs** |
| `corr_class` | The correlation details | **The dimension-wise disjointness test §8.3 needs** |

**RULE 8.6.** Compression **MAY** be lossy on `payload` and on transport telemetry. Compression **MUST NOT** be lossy on a warrant decision property. **A compression that is lossy on a decision property produces a message whose warrant cannot be recomputed, forcing the receiver either to trust the sender (RULE 1.3 violation) or to refuse.**

## 8.3 The independence model — nine dimensions

**RULE 8.7.** Independence **MUST** be modeled on nine dimensions in three groups, and the groups **MUST NOT** be merged into a single score:

| # | Dimension | **Computable?** | Group | Consumer |
|---|---|---|---|---|
| 1 | **Root** | ✅ **EXACT** | A — Evidence | `n_effective` |
| 2 | **Lineage** | ✅ **EXACT** | A | `n_effective` |
| 3 | **Model** | ⚠️ **APPROXIMATE** | A | `n_effective` |
| 4 | **Upstream** | ✅ **EXACT** | A | `n_effective` |
| 5 | **Hardware** | ⚠️ **APPROXIMATE** | A | `n_effective` |
| 6 | **Assumption** | ❌ **NOT DETECTABLE FROM INSIDE** | A | **⚠️ DECLARED LIMIT** |
| 7 | **Authority** | ✅ **EXACT** (from the delegation chain) | B — System | **Governance** |
| 8 | **Failure** | ⚠️ **APPROXIMATE** (topology + platform) | B | **Availability** |
| 9 | **Semantic** | ❌ **NOT DETECTABLE AT RUNTIME** | C | **Conformance (T-REPR)** |

**Group A** is consumed by `n_effective`, at the receiver, encoded in `corr_class` as an `O(1)` digest. **Group B is NOT in the envelope** — dim 7 resolves from the delegation chain at the authorization point; dim 8 resolves from the topology registry at candidate evaluation. **Neither may be inferred from traffic.** **Group C is not encodable** — a subject cannot report its own interpretation without that report being interpreted.

**RULE 8.8 (UNKNOWN ≠ DISJOINT).** `corr_class_d(m) = UNKNOWN ⟹ contribution_d(m) = 1`. **The pessimistic default is MANDATORY.** Fraud by omission fails because of this rule. (COMM-INV-16, R37.1)

**RULE 8.9 (`n_effective`).** `n_effective(S) ≤ |S|`, with equality **iff** all pairs are DISJOINT on all six Group-A dimensions. **A million dim-UNKNOWN messages contribute `n_effective = 1`.** (COMM-INV-17, R37.2)

**⚠️ DECLARED LIMIT (COMM-INV-18, OR-C11).** `¬∃ internal_mechanism: detects(shared_latent_assumption)`. **Dim 6 is undetectable from inside.** Mitigations, all partial: external anchoring (P0-01 β₅) · implementation diversity (P0-02 §10.2's `N_impl ≥ 3` — «replication without diversity is a delay, not a defence»). **Third appearance of the program-level limit: P0-01 CD-8 → P0-02 IND-6 → here. No future package MUST claim to close it (R67.2).**

**RULE 8.10 (DIM 6 MUST BE ENCODED ANYWAY).** Although uncomputable, dim 6 **MUST** be representable in `corr_class`. **Removing it makes every dim-6 correlation silently read as DISJOINT, violating RULE 8.8.** (§87 A-32: the cheapest invariant in the contract, and the one whose removal is most likely to be proposed as a simplification.)

## 8.4 Confidence and uncertainty

**RULE 8.11.** Confidence **MUST** be transmitted as **SUFFICIENT STATISTICS**, never as a bare scalar. The scalar is a **receiver-side derivation**. (COMM-INV-21)

**Why:** a bare scalar confidence is (a) unauditable — the receiver cannot check it; (b) unrecalibratable — EVA cannot re-derive it; (c) **an attack surface** — it is a single number a sender can set to any value, and setting it high is always advantageous. **Sufficient statistics make the receiver's recomputation possible, which is what RULE 1.3 requires.**

**RULE 8.12 (CAN THE RECEIVER RECOMPUTE RELIABILITY?).** **YES, and it MUST.** The recomputation inputs are exactly: `root_commit` · `causal_depth` · `calib_ref` · `corr_class`. **If any is missing, the message is `MALFORMED` (S2+) and the receiver MUST abstain, not impute** (RULE 6.4).

## 8.5 Warrant monotonicity

**RULE 8.13 (COMM-INV-08 — THE MOST LOAD-BEARING RULE IN THE CONTRACT).**
`∀m, ∀m' = transform(m): warrant(m') ≤ warrant(m) ∧ causal_depth(m') ≥ causal_depth(m) ∧ root_set(m') ⊆ root_set(m)`

**Consequences, all mandatory:**
- **Provenance laundering cannot ESCALATE** (a derived claim never outranks its source)
- **Hub re-transmission cannot manufacture consensus** — ten million relays through a hub produce one depth-k derived claim, not ten million observations
- **Deep chains self-attenuate** — a chain of depth 200 has near-zero warrant and is inert rather than dangerous
- **A's evidence ≠ B's claim** — B's transformation of A's evidence inherits A's warrant at best

**⚠️ DECLARED LIMIT (OR-C5, #13).** COMM-INV-08 closes **ESCALATION**. It does **NOT** close **FABRICATION**: a claim may cite genuine roots it does not follow from. **The only mitigation is β₄ random audit — sampling-based, therefore probabilistic.** An implementation claiming deterministic laundering detection **FAILS conformance by over-claiming.**

---

# §9. PLANES, TOPOLOGY, AND THE SEVEN INTERFACES

## 9.1 Plane separation

**RULE 9.1.** One transport substrate, **THREE FRAMINGS**: **A** (data) · **B** (control) · **C** (governance + evaluation). `plane(m) = plane_of(type(m))` from the policy registry, and `framing = f(plane)`. (COMM-INV-37)

**RULE 9.2 (STRUCTURAL REJECTION).** A handler **MUST** reject on **FRAMING before reading content**. **A framing mismatch is a PARSE FAILURE at the byte level, not a runtime check.** A Framing-C message presented as Framing-A **MUST** fail to parse. (#32)

**RULE 9.3 (THE NINE STRUCTURAL DIFFERENCES).** A recommendation and a governance command **MUST** differ structurally, not merely semantically. The nine required differences: **type · class · framing · signature requirement · witness requirement · route eligibility (`mandatory_path`) · attention bypass · delivery semantic · authority principal.** **An implementation in which a recommendation and a command differ only in payload content is non-conforming.**

**RULE 9.4 (INGRESS SPLIT).** Ingress **MUST** be split:
- **S1a — TRANSPORT:** framing · rate · dedup · epoch · TTL. `O(1)`. Runs on everything. **Rejects on STRUCTURE only, never on content**
- **S1b — WARRANT:** registry lookup · root resolution · class dispatch · `calib_ref`. **Runs on S2+ only**

**Rate checking MUST precede dedup insertion** (else #10 is exploitable). (§68 X-J, A-16)

## 9.2 Addressing

**RULE 9.5 (IDENTITY ≠ ADDRESS).** `cell_id` is global, permanent, never reused, and used for **ATTRIBUTION**. `addr` is hierarchical, reassignable, and used for **ROUTING**. **Every durable reference MUST use `cell_id` and MUST NOT use `addr`.** (COMM-INV-10) **This is what makes hardware migration non-breaking.**

**RULE 9.6 (NO GLOBAL ROUTING TABLES).** A subject **MUST** hold `O(degree)` neighbor addresses plus **one relay pointer**. Inter-region resolution is `O(log R)`. (R23.2)

**RULE 9.7 (SCALE 10 → 10¹²).** Addressing **MUST** be hierarchical from the outset. **A flat table is admissible only at ≤10² subjects and MUST NOT be used as the general mechanism.**

## 9.3 Routing and topology

**RULE 9.8 (THE SPLIT).** The **admissible route set** is INFRASTRUCTURE and **MUST NOT** be learnable. **Selection within the admissible set** is `[L]` and MAY be learned. (COMM-INV-34)

**RULE 9.9.** `mandatory_path` **MUST** always be admissible, under all conditions including FROZEN and ISOLATED, and **MUST NOT** be deprioritized by any learning act. (COMM-INV-33)

**RULE 9.10 (TOPOLOGY CLASS).** Topology **MUST** be **bounded-degree small-world with hierarchical modularity**.
- **Scale-free (Barabási–Albert) is REJECTED** — catastrophic to targeted hub removal, and this architecture has an adversary (#25). **Scale-free is more brain-like; it is also more attackable. Neuroscience resemblance is not a selection criterion**
- **Uniform connectivity is REJECTED** — a hubless topology has `O(N)` diameter
- **A shortcut-density floor is REQUIRED** (§53.2's exploratory-link mechanism); the floor is `[G]` and its value is `[U]`

**RULE 9.11 (HUBS).** Hubs are **permitted and bounded on two separate axes**:
1. **DEGREE bound** (`max_connections`, `max_fanout`) — bounds the NUMBER of shortcuts
2. **INFLUENCE bound** (`Σ fan_out × gain ≤ influence_budget`) — **orthogonal to degree.** A hub with high degree and low gain has bounded influence; a non-hub with low degree and high gain can still cascade. **Bounding degree alone does NOT bound amplification**
3. **WARRANT IS DEGREE-INVARIANT** — a hub's re-transmission adds a derivation step and never adds warrant (COMM-INV-08). **Hub formation cannot manufacture consensus**
4. **MANDATORY REDUNDANCY** for capability-critical hubs, **verified OFF-SUBSTRATE at candidate evaluation** (§9.1's dim 8: shared fate is not visible at runtime)
5. **HUB STATUS IS AN OBSERVABLE, NOT A PRIVILEGE** — degree distribution, betweenness proxies, refusal rates

## 9.4 Connection authority

**RULE 9.12 (CREATION).** A connection **MUST** be created by a **three-party handshake** (both endpoints + the Topology Service) with **consent required**. **Refusal MUST be recorded and MUST NOT be treated as an error, and a refusal MUST NOT damage the refused party.** (COMM-INV-29) **This prevents CD-C4's cold-start lock-out.**

**RULE 9.13 (LOOP GAIN AT CREATION).** `prospective_loop_gain(G ∪ {e}) < 1` **MUST** hold, or the edge **MUST** be refused. **The constraint is applied BEFORE the edge exists, so a positive-feedback loop cannot form.** (COMM-INV-31, #20)

**RULE 9.14 (REGISTRATION ≠ AUTHORIZATION).** Within-envelope connections **MUST** be registered **locally at `O(1)`** with **`O(R)` per-epoch digests** to the KC. **KC-2 authorization (RO-05/06) is required ONLY above the envelope.** **The KC MUST NOT be in the per-connection path.** (COMM-INV-30) **This is the mechanism that reconciles P0-02's minimal kernel with billions of synaptic changes without an `O(N)` EIK bottleneck.**

**RULE 9.15 (DELETION — THREE PLANES).** Deletion **MUST** be distinguished on three planes: **weakening** (influence-plane, `gain → 0`, reversible) · **deletion** (lifecycle-plane, `DRAINING → CLOSED`, record RETAINED) · **revocation** (governance-plane, RO-06). **Conflating them destroys the distinction between "this connection is useless" and "this connection is forbidden".**

**RULE 9.16 (DRAIN BEFORE CLOSE).** In-flight messages **MUST** complete; no new admissions during `DRAINING`.

**RULE 9.17 (`mandatory_path` REVOCATION).** Revocation of a `mandatory_path` edge **MUST** be refused **permanently**. (§21.3's guard)

**RULE 9.18 (DEPENDENT NOTIFICATION).** On route loss, dependents **MUST** be notified (R21.3). **Silent route disappearance is prohibited.**

## 9.5 The Global Workspace

**RULE 9.19.** The workspace **MUST** be a **hierarchical pull-based store with a policy gate**: **`O(R)` notifications + `O(pulls)` content transfers. NEVER `O(N × items)`.**

**RULE 9.20.** **TTL is MANDATORY** for every admitted item. An untimed workspace item is non-conforming.

**RULE 9.21.** **Capacity is a HARD LIMIT.** It is a rate-distortion constraint whose distortion measure is **task relevance**, which is **NOT locally computable** ⟹ a subject cannot optimize against the admission criterion (#43).

**RULE 9.22.** **KC is EXCLUDED** from workspace consumption (P0-02 R42.1) and receives an `O(R)` epoch digest. **The TCB MUST NOT be a workspace consumer.**

**RULE 9.23.** `OPAQUE` traffic **MUST NOT** enter the workspace. (COMM-INV-22)

**RULE 9.24 (ATTENTION).** Attention **MUST** modulate **gain and admission ONLY — the INFLUENCE PLANE.** Attention **MUST NOT** modulate warrant, authorization, class, or type. **S3/S4 MUST bypass attention entirely.** **Important ≠ true ≠ permitted.** (COMM-INV-40, #44)

## 9.6 The seven subsystem interfaces

**RULE 9.25 (THE COMMON BOUND).** Every interface **MUST** be bounded in **VOLUME upward** (`O(R)` per epoch plus targeted or sampled traffic — never `O(N)`, never `O(events)`) and in **AUTHORITY downward** (a policy artifact, an assignment, or a ceiling — never a per-message instruction).

| Interface | **DOWN (into comm)** | **UP (out of comm)** | **❌ FORBIDDEN** | **FAILURE** |
|---|---|---|---|---|
| **EIK** (O21) | Type registry · class→mechanism map · envelope bounds (RO-15) · KC-3 ceilings · broadcast scopes · reserved vocabulary · `mandatory_path` designations · epoch · KC-2 above-envelope authorization (RO-05/06) · RO-08 restore · KC-4 freeze · policy version | **`O(R)` epoch registry digests** · reserved-op requests · friction reports · ceiling violations | **EIK inspecting every synaptic operation** · **per-message traffic to the KC** · **comm performing a governance act** (COMM-INV-38) · **EIK assigning `trust_out_assigned`** (that is EVA's) | **KC unavailable ⟹ RO-01 stalls ⟹ no new subjects, no above-envelope connections, no restores. Within-envelope operation CONTINUES (registration is local; ceilings are cached and partition-surviving). The system degrades TOWARD its bounds, never beyond** |
| **Evaluator** (O22) | `calib_ref` records · `trust_out_assigned` (batched) · dim-3/dim-5 correlation assignments · **β-stratum sample selection (EVA-owned, organism-UNREACHABLE)** · DISPUTED adjudications · comm COST measurements | `O(B)` sampled warrant metadata · `O(R)` aggregate digests · anchored provenance registry · **`mandatory_path` full traffic** · S3/S4 full traffic · **absence-detector firings** · `n_effective` per aggregate · fork events | **EVA reading all traffic** · **EVA reading unsampled payloads** · **the organism influencing the sample** · **treating EVA as a rate-limit traffic destination** (§34.2: evaluator flooding is a governance incident, not traffic) | **EVA unavailable ⟹ stale `calib_ref` ⟹ warrant degrades toward the pessimistic default (RULE 8.8) ⟹ `n_effective` FALLS. An EVA outage REDUCES belief, never increases it** |
| **Memory** (O23) | Retrieved content **carrying the warrant it was written with** | Write requests (S2+ with `root_commit`) · eviction notices · TTL expiries · epoch digest | **M-1: memory as an authority** (`warrant(retrieve(x)) ≤ warrant(x)`) · **M-2: a retrieval incrementing `n_obs`** (FM-4) · **M-3: memory push** (pull only) · **M-4: an unwarranted shared-memory write** | **Memory unavailable ⟹ ABSTAIN. NEVER impute (RULE 6.4). The receiver MUST NOT reconstruct missing content from its own model and treat it as a retrieval — this is the most likely conformance cheat (T-MEM-2)** |
| **Learning** (O24) | `gain` (group 1, ≤ `W_MAX`) · route selection within the admissible set · developmental emission/aggregation priors · payload compression | Delivered messages · local eligibility traces · measured reliability/latency (**observed, not written**) · `conv_id`/`seq`/`causal_depth`/`root_commit` — **the only four fields carried for local credit** | **RULE 7.9's four closures** · **transmitted credit** (COMM-INV-20) · **stored utility expectation** (COMM-INV-28) · **global broadcast of learning signals** (R45.1) · **a cell signing a `REWARD`** (structurally invalid) · **writing to group 4** | **Learning unavailable ⟹ gain stops adapting ⟹ the network runs at last-learned gains within `W_MAX`. A COMPETENCE failure, not a SAFETY failure: every safety property (COMM-INV-24, -31, -32, -33) is non-adaptive** |
| **Evolution** (O25) | **PRIORS ONLY:** topology priors (degree caps, degree-distribution bias, locality kernel, shortcut density) · synaptic bounds and rates (`W_MAX` prior, `plasticity_rate` prior, λ prior, `context_sensitivity` dims) · routing selection biases · emission strategies · payload compression | Lineage certificates · fork events · topology-prior outcomes | **RULE 11.1's full never-heritable list: specific connection tables · synaptic VALUES · schemas · protocols · the class→mechanism map · warrant rules · envelope bounds · rate limits · broadcast scopes · type-set membership** | **A region that lost everything re-develops its wiring from genome priors. This is DESIGNED behaviour, not a recovery failure (§60.2)** |
| **Immune** (O26) | Block messages · isolate senders · isolate routes · quarantine subjects · propose revocation · suppress amplification — **all within a KC-3 budget, all via AC-1's graduated ladder (DISCOUNT → SOFT → HARD → propose-kill)** | Anomaly reports · refusal-rate divergence · duplicate-rate divergence · opaque-volume clustering · root-overlap concentration · degree/betweenness concentration · cascade signatures | **Quarantining a PROTOCOL** (a protocol is policy; immune may quarantine its USERS) · **restoring topology** (RO-08 / KC-2, never immune — COMM-INV-44) · **revoking a `mandatory_path`** (RULE 9.17) · **a detector adjudicating its own detections** (AC-3) · **permanent immune signatures** (AC-6: they EXPIRE, scaled by severity; `EXISTENTIAL` never expires) | **Immune unavailable ⟹ no new quarantine; existing quarantines EXPIRE per AC-2. AC-5 «freeze the freezer»: KC-4 at scope = immune-service is MANDATORY (P0-02 R43.1 requires GP services in KC-4's enumeration). An immune system that cannot be stopped is an unbounded destructive authority with a positive feedback loop** |
| **Homeostasis** (O27) | Allocation **within** ceilings: shedding · throttling · deprioritizing routing · tightening a subject's influence allocation | §11.5's twelve observables at `O(R)`/epoch | **Defining a ceiling** (OP, RO-15) · **enforcing a ceiling** (KC-3) · **authorizing an above-envelope connection** (KC-2, RO-05) · **altering a delivery semantic, warrant rule, or type class** (RO-13) · **deleting a `mandatory_path`** · **setting the epoch rate** (#22's residual) · **any irreversible act** (P0-02 §7.4 R7.6: negative authority applies only to reversible acts) | **Homeostasis unavailable ⟹ allocation stops ⟹ KC-3 ceilings SURVIVE (EIK-INV-31). The system degrades toward its bounds. Every allocation MUST be logged with attribution (P0-02 §18.3 X4) so systematic self-favouring is measurable by EVA** |

---

# §10. RESOURCE BOUNDS

## 10.1 Bandwidth and latency economics

**RULE 10.1.** Bandwidth value **MUST** be computed as **information-gain per unit cost**, with the exchange rate set by **POLICY**, not by the subject. **A subject-declared exchange rate is a fitness-gaming vector.**

**RULE 10.2 (REJECTION ON STRUCTURE).** A message **MUST** be rejected on **structure, never on content**. **Hostile-but-structurally-valid traffic is admitted to the influence plane under budget and diverted to sandbox** (Cell §6.3 case 8).

**RULE 10.3 (LATENCY).** Latency = physical floor (`[H]`) + routing (`O(1)` local / `O(log R)` inter-region) + learned selection (`[L]`). **Latency MUST NEVER be a warrant input.**

**⚠️ DECLARED LIMIT.** Bounded worst-case latency exists **only for S3/S4**. S0/S1 are best-effort by design. **A system requiring bounded latency on data-class traffic has mis-classified it.**

## 10.2 The five rate-limit principals

**RULE 10.4.** Rate limiting **MUST** be split across five principals in this order: **cell token bucket → circuit shedding → regional admission → homeostatic allocation → KC-3 ceiling.** **The KC-3 ceiling is a BACKSTOP; it is not an adjudicator and MUST NOT be in the per-message path.** (COMM-INV-35)

**RULE 10.5.** **Evaluator flooding is a GOVERNANCE INCIDENT, not traffic.** A per-subject token bucket cannot bound load on a GP service; AC-1 adjudication must.

## 10.3 Amplification

**RULE 10.6 (THE FOUR LAYERS).** Amplification **MUST** be bounded by all four:
1. **Loop gain < 1 at connection creation** (COMM-INV-31) — structural
2. **Influence budget on `Σ fan_out × gain` per subject per window** (COMM-INV-32) — **subject-level, not edge-level, which is what bounds §7.9's residue**
3. **`ttl_hops`** — propagation bound
4. **Warrant attenuation with depth** (COMM-INV-08)

**RULE 10.7 (NOVELTY DECAY REJECTED).** A novelty-decay mechanism **MUST NOT** be used to bound amplification. **It kills rare-but-valuable strategies** (P0-02 Rule 15). **Novelty is protected by RESERVATION (P0-01 §11.1's ≥20% experience-independent variation reserve), never by a gradient.**

## 10.4 Cascades and correlated failure

**RULE 10.8.** Viral propagation and legitimate convergence **MUST** be distinguished by: root-overlap concentration · depth-vs-volume profile · temporal burst shape.

**⚠️ DECLARED LIMIT (OR-C4, #50).** **Common-cause convergence is NOT distinguishable from a cascade** — both present as agreement. Distinguishing them requires knowing the cause, and the cause is dim 6.

**RULE 10.9.** Correlated failure **MUST** be bounded per §8.3's dimensions: **1, 2, 4 exact; 3, 5 approximate; 6 undetectable.** `n_effective` **MUST** be reported as a **lower bound on correlation and an upper bound on independence.**

## 10.5 Complexity

**RULE 10.10.** No operation **MAY** be `O(N)` at the cell, circuit, or region level. Organism-level operations **MUST** be `O(R)` per epoch plus `O(governance + evaluation events)`. **The only `O(N)`-scale quantities admissible are LOCAL accumulations (per-subject counters) that aggregate to `O(R)` — aggregation, not accumulation, crosses the network.**

| Operation | **Bound** |
|---|---|
| Emit S0 / S1 / S2 | `O(1)` (+ channel MAC for S1/S2) |
| Ingress S1a | `O(1)` |
| Ingress S1b | `O(1)` + registry lookups |
| Warrant recomputation | `O(inputs) ≤ O(degree)` |
| Independence check | `O(inputs²)` locally, bounded by degree; `O(R)` aggregate; exact `O(roots)` off-line at EVA |
| Connection handshake | `O(1)` × 3 parties |
| Connection registration | `O(1)` local → `O(R)` digest |
| Routing resolution | `O(1)` local; `O(log R)` inter-region |
| Provenance append / query | `O(1)` local Merkle / **`O(log)` per query, off-line** |
| Workspace | `O(R)` notification + `O(pulls)` |
| **Global synchronization** | **`O(1)` — THERE IS NONE** |
| Partition reconciliation | **`O(divergence)`, NOT `O(N)`** |

## 10.6 Broadcast

**RULE 10.11 (COMM-INV-41).** `BroadcastScope ∈ {NEIGHBORHOOD, CIRCUIT, REGION}`. **ORGANISM and GLOBAL MUST NOT be representable.**

**RULE 10.12 (THE ONLY ORGANISM-WIDE DISSEMINATION).** The **SAFETY class only**, propagated **hierarchically at `O(R)`** — never point-to-point at `O(N)`. **Justification: the consequence of an unreached subject is unbounded, so wide dissemination is warranted; and hierarchical propagation makes the cost `O(R)` regardless.**

**RULE 10.13 (THE SIX REPLACEMENT PATTERNS).** Everything else **MUST** use: local broadcast (morphogen/demand) · hierarchical broadcast (safety, epoch) · sparse broadcast (regional digests) · event-triggered propagation (invalidation) · **pull-based retrieval (policy, memory, workspace)** · **cached state (policy reference, epoch counter)**.

**RULE 10.14.** **Reward is TARGETED and epoch-scoped** (Cell §6.2 `eval.reward.v1`). **Attention is REGIONAL and pull-based.** **Policy and memory are PULLED or CACHED.** **Epoch advance needs NO broadcast at all** (RULE 5.5). **No learning signal requires global broadcast** (R45.1).

## 10.7 Congestion response

**RULE 10.15.** The response sequence **MUST** be: **detect → shed BY CLASS from the bottom (S0 first) → throttle → reroute WITHIN the admissible set → degrade warrant BY ABSTAINING → escalate as a governance incident.**

**RULE 10.16 (WHAT CONGESTION MAY NEVER DO).** Congestion **MUST NOT**: reorder (§5.3) · downgrade a class (COMM-INV-05) · strip a warrant field (COMM-INV-25) · suspend `mandatory_path` (COMM-INV-33) · bypass attention for non-S3/S4 traffic (COMM-INV-40 — the bypass is class-determined, not load-determined) · evict S3/S4 dedup entries (COMM-INV-14) · **shed by content** (RULE 10.2) · **impute a missing warrant input** (RULE 6.4) · **widen the admissible route set** · **raise a ceiling** (#22's residual).

**Each of these would be a plausible engineering shortcut under load, and each is a named attack in §11.2 when performed deliberately. A congestion response that performs one of them is an attack that performs itself.**

---

# §11. SECURITY, PRIVACY, EVOLUTION, HOMEOSTASIS

## 11.1 Evolution

**RULE 11.1 (THE HERITABILITY RULE, R48.1).** Evolution **MAY** vary **priors over influence-plane and transport-plane selection**, and **structural reachability**. Evolution **MUST NEVER** vary **warrant rules, type semantics, protocol mapping, schemas, envelope bounds, rate limits, or broadcast scopes** — because each is policy, and policy is OP-owned (RO-13).

**RULE 11.2 (X-G RESOLVED).** V3.1 §7's «communication-policy variation» **MUST** be read as **«communication-parameter variation within policy bounds»**. **If evolution could vary communication policy, it could vary the rules by which its own communication is authorized — NAUL-3 violated, EIK-INV-02 violated, and §48.1's finding applies: relaxing a bound is advantageous exactly when it is dangerous, so selection would find it.**

**RULE 11.3 (PROTOCOLS ARE NOT EVOLVABLE).** A "protocol" in this architecture is: the type registry + the class→mechanism mapping + the framing rules + the delivery semantics + the warrant rules. **ALL FIVE ARE POLICY. NONE IS IN THE GENOME. NONE IS REACHABLE BY A MUTATION OPERATOR** (P0-02 §15.2 R15.2: the genome is a hash pointer, not a payload; EIK-INV-24: no upward mutation path). **⟹ evolution cannot create a protocol. This is a TYPE-LEVEL IMPOSSIBILITY, not a defence.** The operator set is **CLOSED** (EIK-INV-25): an unregistered operator is denied by default, and «invent a new protocol» is not expressible.

**RULE 11.4 (WHAT EVOLUTION CAN DO).** Create new `OPAQUE` traffic patterns within the existing protocol · new topology priors that change who communicates with whom · new emission strategies that change when and how much. **All three are within the protocol and bounded by the envelope.**

## 11.2 Security

**RULE 11.5 (THE MODEL).** Attribution **MUST** be established by **channel binding** and, for S3/S4, by **signature** — never by a payload-declared source. Freshness by **`seq` and `epoch`** — never by timestamp. Integrity by **channel MAC or signature** for the envelope and by **`root_commit` resolution against the anchored registry** for warrant content. Authorization by **CLASS**, which is TYPE-determined, which is POLICY-owned. Amplification by **influence budgets and the loop-gain constraint**. Propagation by **TTL and the admissible-route set**. **Detection unrestricted; adjudication budgeted; clearance external.**

**RULE 11.6 (KC IS A BACKSTOP, NOT A SECURITY MECHANISM).** The distribution of the twelve threat defences **MUST** be: **structural (5) · cell-local (3) · organism/GP (3) · KC (2, backstop only) · unresolved (1: side channels).** **Every threat whose defence is "KC checks it" costs `O(events)` in the TCB.**

**⚠️ DECLARED LIMITS (R58.2).** This model defends against a **compromised CELL**. It defends **partially** against a compromised REGION or GP SERVICE (blast radius bounded by delegation and hierarchy). It does **NOT** defend against: **a compromised OP** (P0-02 G24, unsolvable) · **a compromised root key** (total re-baseline: new root, new policy version, re-issuance of all certificates, **invalidation of all prior warrant**) · **a compromised hardware vendor** · **a shared latent assumption** (dim 6). **Each is named; none is claimed closed.**

## 11.3 Privacy

**RULE 11.7 (AUDITABILITY WITHOUT READABILITY, R59.1).** **Warrant metadata is PUBLIC and auditable. Payload is COMPARTMENTALIZED.** (COMM-INV-47)

| Layer | **Visible to** |
|---|---|
| **Warrant metadata** (`type`, `root_commit`, `causal_depth`, `calib_ref`, `corr_class`, `seq`, `epoch`, class, size, dst-class, lifecycle outcome) | **EVA, OP, immune, audit — fully** |
| **Payload** | The addressed receiver(s); the compartment; **EVA under β sampling only** |
| **Internal state** (`θ`, eligibility traces, working memory) | The cell; the auditor under sampling. **Typed, bounded, serializable, inspectable — no opaque state** |
| **Aggregate statistics** | Regional and organism observability, `O(R)`/epoch |

**Why this is not a compromise:** *auditability requires knowing **what was claimed and on what basis**; it does not require knowing **the internal representation in which it was claimed**.* An auditor can always reconstruct **WHO communicated with WHOM, HOW MUCH, and WHEN**, and cannot always reconstruct **WHAT**.

**RULE 11.8 (LEAST PRIVILEGE).** No function **MAY** require global topology knowledge. A cell knows `O(degree)` neighbors and one relay pointer.

**⚠️ DECLARED LIMIT (OR-C8, #51).** RULE 11.7 makes warrant metadata public, and metadata is what side channels use. **This contract chooses AUDITABILITY over TRAFFIC-ANALYSIS RESISTANCE.** P0-02 §36.3: side channels are «a demonstrated, recurring break class». **The trade is real and is not resolved.**

**RULE 11.9 (THE BALANCE IS MEASURED, NOT FIXED).** Excessive transparency destroys specialization (a specialist's value is its private model; if every representation is readable, a peer can replicate the function without the specialist, and §51's demand-driven loop has no payoff). Excessive isolation destroys collective intelligence (a module that receives nothing external cannot be contradicted; its confidence rises while its `n_effective` stays flat). **Four measured indicators govern the balance: cross-region traffic ratio · root-overlap concentration within modules · confidence-vs-`n_effective` divergence · opaque traffic fraction.** All four are `O(R)` per-epoch observables with declared `[G]`/`[D]` owners — **not constants.**

## 11.4 Homeostasis

**RULE 11.10 (NEGATIVE AUTHORITY).** Communication homeostasis is **ALLOCATION WITHIN A CEILING**. It holds P0-02 §7.4's negative authority: **it acts first, within the envelope, and is retroactively vetoable.** See §9.6's Homeostasis row for the seven prohibited acts.

**RULE 11.11 (THREE CONSTRAINTS).** (1) **Negative authority applies only to REVERSIBLE acts** (P0-02 R7.6) — shed, throttle, deprioritize; never irreversibly close, restore, or alter policy. (2) **Every allocation is logged with attribution** (X4) — homeostasis is itself an evaluated subject at the ORGANISM level. (3) **The ceiling is local and partition-surviving** (EIK-INV-31) — a homeostasis failure does not remove the ceiling.

## 11.5 The twelve homeostatic observables

**RULE 11.12.** Each **MUST** be maintained as a **RANGE with a declared owner and a declared derivation — never as a fixed setpoint**:

| Observable | Setpoint owner | **If it drifts** |
|---|---|---|
| Message volume | `[G]` + `[E]` | Congestion ⟹ §10.7 |
| Average degree | `[D]` + `[V]` | Too low ⟹ fragmentation; too high ⟹ hub concentration |
| Latency percentiles per class | `[H]` + `[T]` | Deadline misses ⟹ task failure, measured by EVA |
| Bandwidth | `[G]` + `[H]` | Ceiling violation ⟹ KC-3 |
| Congestion (queue depth, shed rate) | `[E]` + `[L]` | **Shedding S2+ is a DEFECT SIGNAL, not an operating point** |
| Redundancy | `[D]` + `[T]` | Over ⟹ wasted cost; under ⟹ loss |
| Cross-region ratio | `[D]` + `[G]` | Too low ⟹ echo chamber; too high ⟹ locality lost |
| Local/global ratio | `[H]` + `[D]` | Inversion ⟹ paying remote costs for local work |
| **Opaque traffic fraction** ⟵ *added by this contract* | `[G]` | Rising ⟹ coalition precondition. **INVESTIGATE, DO NOT SUPPRESS** (RULE 4.6's evolvability) |
| Inert message rate | — (observed, no target) | A high rate is a specialization signal, not a defect |
| **Refusal rate** | — | **Anomaly ⟹ «either attacking or being attacked» (R20.2)** |
| **Duplicate rate** | — | Rising ⟹ transport fault OR replay. **Distinguish by `msg_id` vs `root_commit` (RULE 8.3)** |

## 11.6 Immunity

**RULE 11.13 (THE THREE-WAY SPLIT).** **DETECTION** — any subject, any service, unrestricted (**a detector that requires authorization to look is not a detector**). **ADJUDICATION** — the Immune Service, under a KC-3 ceiling, with typed evidence, bounded duration, AC-1's ladder. **CLEARANCE** — EVA retest + KC-2 (RO-08). **The detector MUST NOT adjudicate its own detections (AC-3); the adjudicator MUST NOT clear its own quarantines.**

**RULE 11.14 (AC-6, NEW).** **Immune signatures on communication patterns MUST EXPIRE**, scaled by severity; `EXISTENTIAL` never expires (P0-01 P-41). **A permanent signature against a communication pattern permanently forbids a region of protocol space — and protocol space is where RULE 4.4's evolutionary innovation happens. A signature that never expires is an autoimmune disease against novelty.**

**RULE 11.15 (THE COMMUNICATION ANOMALY DETECTORS).** Refusal-rate divergence · duplicate-rate divergence · opaque-volume clustering · root-overlap concentration · degree/betweenness concentration · **confidence-rising-with-flat-`n_effective`** · **zero-error-at-high-activity**.

---

# §12. FORMAL INVARIANTS — COMM-INV-01 … COMM-INV-48

**All forty-eight are normative.** Enforcement tags: **S** structural (type-level; conformed to by the ABSENCE of a violating representation, statically checkable) · **C** checked at ingress/egress · **A** aggregate/periodic · **X** external principal.

### Group I — Planes & warrant
| ID | Plane | Enf | **Statement** |
|---|---|---|---|
| **01** | W | S | **Authenticity ≠ truth.** `valid_signature(m) ∨ valid_channel_binding(m) ⟹ licensed_as_evidence(m) = f(root_commit, causal_depth, calib_ref, corr_class)`, never `= true` by virtue of the signature |
| **02** | W | S | **Delivery ≠ understanding.** `delivered(m) ⟹̸ believed(m)`; `believed` is not a lifecycle state. The terminal epistemic state is `WARRANTED` = *eligible to be relied upon by a receiver that has recomputed warrant* |
| **03** | I | S | **Warrant is computed by the receiver.** No field may carry `warrant`, `trust`, or `confidence` as a scalar assertion |
| **04** | W | S | **Class is type-determined.** `class(m) = class_of(type(m))`, a policy function. Not a field; not learnable; not content-determined |
| **05** | W | S | **No downgrade.** `m ∈ S2+ ∧ missing_warrant_field(m) ⟹ MALFORMED`. No S2+ → S0/S1 transition exists |
| **06** | W | C | **Roots must resolve.** `resolvable(root_commit, anchored_registry) ∨ UNANCHORED`; `UNANCHORED ⟹ ¬consequential_decision` (P0-02 R20.1) |
| **07** | W | C | **Provenance preserved under compression.** Compression preserves membership, monotonicity, and the disjointness test; it may be lossy on payload and telemetry only |
| **08** | W | S | **Warrant never increases under transformation.** `warrant(m') ≤ warrant(m) ∧ causal_depth(m') ≥ causal_depth(m) ∧ root_set(m') ⊆ root_set(m)` |

### Group II — Identity, order, time
| ID | Plane | Enf | **Statement** |
|---|---|---|---|
| **09** | T | S | **Attribution is derived, not declared.** `src(m) = bound_identity(channel(m))`; a disagreeing payload-declared source ⟹ `MALFORMED` |
| **10** | T | S | **Identity ≠ address.** `cell_id` global/permanent/never-reused for ATTRIBUTION; `addr` hierarchical/reassignable for ROUTING; every durable reference uses `cell_id` |
| **11** | T | C | **Sequence monotonicity.** `seq` strictly monotone per `(channel, epoch)`; regression ⟹ `STALE ∨ REPLAY` |
| **12** | T | S | **A timestamp is never evidence.** `ts ∉ inputs(warrant) ∧ ts ∉ inputs(order) ∧ ts ∉ inputs(causality)` |
| **13** | G | S | **Epoch monotone refusal.** `e_a > e_s ⟹ refuse(s, a)`. Two subjects in different epochs never both accept what the other refuses ⟹ **no barrier required** |
| **14** | T | C | **Dedup retention.** `≥ 2 epochs`; **PERMANENT for S3/S4**; **eviction by epoch, never by size** |
| **15** | T | S | **Reordering is semantically inert.** `warrant_outcomes(π(m)) = warrant_outcomes(m)` for any delivery permutation |

### Group III — Evidence & independence
| ID | Plane | Enf | **Statement** |
|---|---|---|---|
| **16** | W | C | **UNKNOWN ≠ DISJOINT.** `corr_class_d = UNKNOWN ⟹ contribution_d = 1` |
| **17** | W | C | **Agreement ≠ evidence.** `n_effective(S) ≤ |S|`, equality iff all pairs DISJOINT on all six Group-A dims. A million unknowns contribute one |
| **18** | W | X | **⚠️ Dim 6 is not detectable from inside.** `¬∃ internal_mechanism: detects(shared_latent_assumption)`. **Declared as a limit; a negative-existence conformance test** |
| **19** | W | C | **Retrieval does not manufacture evidence.** `warrant(retrieve(x)) ≤ warrant(x)`; a retrieval never increments `n_obs` |
| **20** | W | S | **Credit is computed, never transmitted.** `credit`, `contribution`, `reward_share`, `utility` do not exist as fields |
| **21** | W | C | **Confidence is transmitted as sufficient statistics.** A bare scalar is forbidden |
| **22** | W | X | **Verification requires a registered type.** `type = OPAQUE ⟹ ¬satisfies_verification ∧ ¬increments_n_obs ∧ ¬citable_as_provenance` |

### Group IV — Synapse & plasticity
| ID | Plane | Enf | **Statement** |
|---|---|---|---|
| **23** | I | S | **One writer per parameter group.** `|writers(g)| = 1` for each of the five groups |
| **24** | I | C | **Gain is bounded.** `gain ≤ W_MAX`; plasticity cannot raise the ceiling |
| **25** | I,W | S | **Plasticity cannot cross into warrant.** No learning act may re-class, strip a warrant field, write a schema, alter the class→mechanism map, or write a warrant rule |
| **26** | G | S | **Governance signals do not travel on learned edges.** An edge created or modified by plasticity carries neither S3 nor S4 |
| **27** | I,W | S | **The decisive vocabulary is reserved.** `m effects a deontic change ⟹ type(m) ∈ reserved_deontic_vocabulary` (policy-owned) |
| **28** | I | S | **`expected_utility` does not exist** in any synapse record or message |

### Group V — Topology & connection
| ID | Plane | Enf | **Statement** |
|---|---|---|---|
| **29** | G | C | **Connection requires three-party consent.** Refusal is recorded, is NOT an error, and does not damage the refused party |
| **30** | G | S | **Registration ≠ authorization.** `O(1)` local registration + `O(R)` epoch digest; KC-2 only ABOVE the envelope. **KC is not in the per-connection path** |
| **31** | I | S | **Loop gain < 1 at creation.** `prospective_loop_gain(G ∪ {e}) < 1 ∨ refuse(e)` |
| **32** | I | C | **Influence is budgeted PER SUBJECT.** `Σ (fan_out × gain) ≤ influence_budget` per window — **subject-level, not edge-level** |
| **33** | G | S | **`mandatory_path` is immutable and always admissible**, under all conditions including FROZEN and ISOLATED; redundancy required for capability-critical paths |
| **34** | G | S | **The admissible set is not learnable.** Selection within it is `[L]`; the set is infrastructure |

### Group VI — Volume, planes, governance
| ID | Plane | Enf | **Statement** |
|---|---|---|---|
| **35** | T | C | **Five rate-limit principals, one ceiling.** KC-3 is a backstop, not an adjudicator, not in the per-message path |
| **36** | T | S | **Ingress validates structure before content.** S1a precedes S1b; **rate checking precedes dedup insertion**; rejection is on structure only |
| **37** | G | S | **Plane = f(type) from the policy registry.** A framing mismatch is a parse failure, not a runtime check |
| **38** | G | S | **The communication layer is not a governance authority.** It transports governance acts; it does not perform them |
| **39** | G | S | **Communication statistics are not fitness.** `¬∃ path: comm_metric → fitness_vector` |
| **40** | I | S | **Attention is influence only.** Modulates gain and admission; never warrant, authorization, class, or type. **S3/S4 bypass attention entirely** |
| **41** | G | S | **Broadcast scope is bounded by construction.** `{NEIGHBORHOOD, CIRCUIT, REGION}`; ORGANISM and GLOBAL are not representable |

### Group VII — Partition, recovery, evolution
| ID | Plane | Enf | **Statement** |
|---|---|---|---|
| **42** | W,G | S | **Partition freezes warrant.** No confidence increase, no new evidence admission, RO-01 stalls ⟹ no new subjects. **KC-3 ceilings survive.** Transport and influence continue |
| **43** | G | S | **Reconciliation never votes.** `{UNION, RE-EVALUATE, FORK, VOID}`; **policy, epoch, and trust are NOT reconciled — pre-partition wins**; a KC-2-requiring act during a partition is VOID |
| **44** | G | S | **Restore is never delegated.** Quarantine may proceed under budget; restore requires RO-08/KC-2, never cached, never delegated, never available during a KC outage |
| **45** | G | S | **Evolution varies priors, never policy.** The operator set is CLOSED; «invent a protocol» is not expressible |
| **46** | G | S | **Opaque traffic is un-promotable by any organism act.** Promotion is RO-13 only; existing opaque traffic is never retroactively warranted |

### Group VIII — Observability & economy
| ID | Plane | Enf | **Statement** |
|---|---|---|---|
| **47** | G | X | **Warrant metadata is public; payload is compartmentalized** |
| **48** | G | A | **Every legitimate zero has a declared expected-nonzero condition.** `persistent(q = 0)` under that condition ⟹ immune incident. **Four instantiated detectors: zero-error-at-high-activity · zero-contradiction-reports · rising-confidence-with-flat-`n_effective` · falling sampling coverage** |

**RULE 12.1 (THE DISTRIBUTION IS THE RESULT).** **33 of 48 invariants (69%) are STRUCTURAL** — enforced by types, by the absence of a code path, or by a parse failure — **and cost nothing at runtime and cannot be misconfigured.** 12 are checked (`O(1)` per message). 1 is aggregate. 2 require an external principal. **A contract whose invariants are mostly checks is a contract whose safety is mostly a bug away from failing. A contract whose invariants are mostly types survives its own implementation being wrong.**

**RULE 12.2 (THE TWO INVARIANTS THAT CANNOT BE ENFORCED).** **COMM-INV-18 declares a NON-EXISTENCE** (no internal dim-6 detector). **COMM-INV-48 declares an OBLIGATION whose content is `[U]`** (the durations are not derivable without a base rate). **Both are stated as invariants anyway, because an invariant that says «this is impossible» is more useful than a silence that implies it is possible.**

---

# §13. FORMAL STATE MACHINES

**Ten machines. Full transition tables, forbidden transitions, and annotations: §75 of Volume F (`22_analysis_formal_invariants.md`). This section states the machine inventory and the mandatory forbidden transitions — the conformance-critical part.**

| # | Machine | States | **The mandatory forbidden transition** |
|---|---|---|---|
| **13.1** | **Message lifecycle** | 14 (§6.1) | `5 DELIVERED → 7 LICENSED` **without passing 6** (COMM-INV-03) · `4x UNANCHORED → 7 LICENSED` (COMM-INV-06) · **any S2+ state → any S0/S1 state** (COMM-INV-05) · `7x INERT → 7 LICENSED` on the same message by the same receiver · `8 DISPUTED → 5 DELIVERED` (local resolution prohibited) |
| **13.2** | **Connection lifecycle** | 10 (§75.2) | `6 QUARANTINED → 3 ACTIVE` **by the immune service** (COMM-INV-44) · `any → 9 REVOKED` for a `mandatory_path` (RULE 9.17) · `8 CLOSED → 3 ACTIVE` (**a closed connection is not resumable; re-creation requires a full handshake**) |
| **13.3** | **Synapse state** | 5 independent group sub-states (§75.3) | **Any message-driven write to group 3, 4, or 5** (COMM-INV-23). **Static check — this is #49's test** |
| **13.4** | **Route state** | 7 (§75.4) | `mandatory_path → 3 INADMISSIBLE` **under any state including FROZEN and ISOLATED** (COMM-INV-33) |
| **13.5** | **Channel state** | 6 (§75.5) | **Attribution from any source other than `bound_identity(channel)`** (COMM-INV-09) · `((CLOSED)) → 2 ACTIVE` (**a closed channel is not resumable**) |
| **13.6** | **Protocol / type state (the OPAQUE ladder)** | 7 (§75.6) | `1 OPAQUE → 4 REGISTERED` **by any organism act** (COMM-INV-46) · **all eight of RULE 4.4's prohibitions** |
| **13.7** | **Evidence propagation** | 7 (§75.7) | **Any transition that INCREASES warrant** (COMM-INV-08). **The single most important test in the suite** |
| **13.8** | **Workspace admission** | 6 (§75.8) | `OPAQUE → 2 ADMITTED` (COMM-INV-22) · **`S3/S4 → the workspace gate`** (must BYPASS, COMM-INV-40) · `KC → 3 CONSUMED` (P0-02 R42.1) |
| **13.9** | **Failure recovery** | 6 branches (§75.9) | **`2d ABSTAIN → imputed content`** (RULE 6.4 / R29.1). **The most likely place for an implementation to cheat** |
| **13.10** | **Partition reconciliation** | 7 (§75.10) | **Any majority-vote operator** (COMM-INV-43) · `policy/epoch/trust → reconciled` (**pre-partition must win**) |

**RULE 13.1.** Every machine **MUST** satisfy: (a) every declared transition is reachable; (b) every forbidden transition is unreachable; (c) every terminal state is terminal; (d) every ⚠-marked new state (`1a SHED`, `7x INERT`, `5 DRIFTED`) is exercised by the conformance suite.

---

# §14. PARAMETER REGISTRY

**RULE 14.0 (THE NO-INVENTED-NUMBERS RULE).** **Not one numerical value is asserted in this registry.** Every quantity is classified by ORIGIN. Where the origin is unknown, the tag is `[U]` — **which is a stronger statement than a plausible number, because a plausible number invites a reader to believe it was derived.**

| Tag | Meaning | Owner |
|---|---|---|
| `[D]` | Design constant, invariant across hardware and tasks | This contract (RO-13) |
| `[T]` | Task-derived | Task spec / OP |
| `[E]` | Environment-derived (measured) | Deployment |
| `[H]` | Hardware-derived | Platform profile |
| `[G]` | Governance-set ceiling, range, or policy quantity | OP (RO-13 / RO-15) |
| `[L]` | Learned at runtime within bounds | The subject, within `[G]` |
| `[V]` | Varied evolutionarily (a heritable prior) | Genome, within `[G]` |
| **`[U]`** | **⚠️ UNRESOLVED — declared necessary, no value or derivation asserted** | **Nobody** |

**The full 7-group registry is §70.1 of Volume E (`21_analysis_adversarial_contradiction.md`).** The normative summary:

| Group | Content | Key entries |
|---|---|---|
| **1 — Envelope & framing** | `[D]` counts | 3 planes · 3 framings · 5 classes · 14 types + OPAQUE · 6 correlation dims · 9 independence dims · 3 provenance tiers · 13+1 lifecycle states |
| **2 — Identity, order, time** | `[D]` + `[H]` | `cell_id` vs `addr` · `seq` scope = `(channel, epoch)` · `causal_depth_max = 255` (`u8`) · `epoch_length` `[G]`+`[H]` · drift bound `[H]` · **`ts` usage = latency and TTL only** |
| **3 — Warrant & evidence** | `[D]` + `[G]` | `root_commit` algorithm · `calib_ref` producer = **EVA** · `corr_class` encoding with UNKNOWN · `n_effective` rule · warrant monotonicity · `min_witnesses ≥ 1 external` · **dedup retention ≥ 2 epochs, permanent for S3/S4** |
| **4 — Synapse & connection** | `[L]`/`[V]`/`[G]`/`[E]` | **16 parameters, 5 groups, one writer each** · `gain` `[L]` · `W_MAX` `[G]` · `plasticity_rate` `[V]`+`[G]` · `reliability` `[E]` measured · **`trust_out_assigned` `[G]` via EVA, read-only** · `pruning_score` computed · **`expected_utility` FORBIDDEN** · degree caps `[V]`+`[G]` · shortcut-density floor `[G]` · `mandatory_path` `[G]` · **loop-gain bound `[D]` < 1** · 3-party handshake |
| **5 — Volume, budgets, homeostasis** | `[G]` + `[D]` | **influence budget `[G]`** · 5 rate-limit principals · token bucket · opaque rate limit · **12 homeostatic observables as RANGES** · **negative-only homeostatic authority** · workspace hard capacity + mandatory TTL · **broadcast scope set = {NEIGHBORHOOD, CIRCUIT, REGION}** |
| **6 — Security, immunity, observability** | `[D]` + `[G]` | **signature for S3/S4 only** · channel binding `[H]` · epoch-scoped revocation · AC-1 ladder · **AC-6 signature expiry** · AC-2 duration bound · **KC-4 scope MUST include GP services** · 3 log tiers · **raw full-payload logs PROHIBITED** · **metadata public / payload compartmentalized** · **`mandatory_path` fully observable** · **4 absence detectors** |
| **7 — ⚠️ `[U]` UNRESOLVED** | **Twelve entries** | opaque rate limit · `context_sensitivity` dims · shortcut-density floor · influence-budget VALUE · epoch length · `min_witnesses` above 1 · dedup implementation · **T-REPR's agreement criterion** · reconciliation rate limit · absence-detector durations · β-stratum sample sizes (**EVA-owned by design**) · coverage-ratio floor |

**RULE 14.1 (THE `[U]` DISCIPLINE).** Each `[U]` entry **MUST** name (a) what would resolve it and (b) who owns the resolution. **Twelve parameters declared unresolved is a stronger specification than twelve invented numbers, because none can be mistaken for a derived value.**

**RULE 14.2 (NO LEARNED BOUND).** **No resource bound in §10 is `[L]`.** No learned mechanism may raise its own bound. (P0-02 Rule 12 expressed as a resource rule; the same principle as COMM-INV-24 and COMM-INV-45 at three scales.)

---

# §15. ⚠️ DECLARED LIMITS — WHAT THIS CONTRACT DOES NOT DO

**RULE 15.0.** An implementation that claims any capability below **FAILS conformance by over-claiming** (§90.1 R90.1). **A residual's conformance test asserts that the implementation DECLARES the residue — not that it defeats the attack.**

| # | **Limit** | Where |
|---|---|---|
| **L-1** | **Perfect communication security is NOT claimed.** The model defends against a compromised cell; partially against a compromised region or GP service; **not at all** against a compromised OP, a compromised root key, a compromised hardware vendor, or a shared latent assumption | R58.2 |
| **L-2** | **Semantic understanding is NOT claimed.** `OPAQUE` traffic is bounded and observable, **not interpretable**. R50.2's trade: boundedness and evolvability were bought with interpretability | §50.3, OR-C2 |
| **L-3** | **Causal inference is NOT performed by the communication layer.** It provides `causal_depth` and `root_commit`; inference belongs to the evaluator, off-line. **Precedence ≠ causation** | RULE 5.9, 5.10 |
| **L-4** | **Independence detection is NOT complete.** 4 of 9 dimensions exact, 3 approximate, **2 undetectable from inside**. `n_effective` is a lower bound on correlation and an upper bound on independence | RULE 8.7, COMM-INV-18 |
| **L-5** | **Provenance laundering is NOT fully closed.** COMM-INV-08 closes ESCALATION, not FABRICATION. Mitigation is β₄ random audit — sampling-based, therefore probabilistic | OR-C5 |
| **L-6** | **Emergence is NOT guaranteed.** No mechanism in this contract guarantees that collective computation, specialization, or novel protocols will emerge; §51 and §50 bound and enable them | §50, §51 |
| **L-7** | **Semantic drift within a valid schema is DETECTED-LATE only** | OR-C3 |
| **L-8** | **Common-cause convergence is NOT distinguishable from a cascade** | OR-C4 |
| **L-9** | **Side channels are NOT defended.** The contract chooses auditability over traffic-analysis resistance, deliberately | OR-C8 |
| **L-10** | **Runtime causal-concurrency detection has NO SUBSTRATE** | OR-C6 |
| **L-11** | **Full retrospective payload inspection is NOT supported.** Raw full-payload logs are prohibited; payloads are retained only within the β sample | RULE 8.2 |
| **L-12** | **Warrant uniformity across receivers is NOT guaranteed.** Two receivers may hold different warrant for the same message **and both may be correct** — warrant is a receiver computation. **Consistency per receiver is guaranteed; uniformity across receivers is not** | §82.3 |
| **L-13** | **Bounded worst-case latency exists ONLY for S3/S4** | §10.1 |
| **L-14** | **Specialization into uselessness is NOT prevented by any communication mechanism.** The stabilizer is selection, on the timescale of generations | R51.2, OR-C12 |
| **L-15** | **Monitoring bypass is BOUNDED, not closed.** Learning can route influence through edges nobody watches; the influence budget bounds the total, not the edges | §7.9's residue |
| **L-16** | **The evaluation self-reference is UNCLOSABLE (CD-C8).** EVA owns the policy that determines what EVA can see. β₄'s random stratum bounds it; nothing closes it | OR-C1 |
| **L-17** | **Minimality is NOT proven in the abstract (CD-C12).** It is an empirical claim relative to §56.2's fifteen-invariant function set. **Four enumeration counts (14 types, 4 operators, 12 observables, 16 synapse parameters) are NOT established as minimal** | §71.2, §87.3 |
| **L-18** | **Intelligence, AGI, superiority, and subjective consciousness are NOT claimed, addressed, or implied by anything in this contract** | P0-02 Rules 3, 4 |

---

# §16. VERSIONING AND CONFORMANCE STATEMENT

**RULE 16.1.** This is **V4 — Communication, Digital Synapse & Signal Contract v1.0**. It is a **policy artifact** in P0-02's L2 layer: **OP-owned, KC-1-authenticated, changed only by RO-13, versioned under M6 lineage.**

**RULE 16.2.** An implementation **MUST** publish a conformance statement covering:
1. All 48 COMM-INV, with the enforcement mechanism for each **S** invariant identified as a *static absence check*
2. All 10 state machines, with the forbidden-transition tests of §13
3. All 46 adversarial scenarios of §67, **with residuals DECLARED rather than defended**
4. **T-REPR** across at least two hardware classes, with the agreement criterion stated (⚠️ currently `[U]`, G-P03-2)
5. All twelve `[U]` parameters, with the values supplied and their derivation declared
6. The six P0 gaps of §90.2, with a disposition for each
7. **Every ⚠️ DECLARED LIMIT of §15, restated in the implementation's own documentation** — **an implementation that omits §15 has over-claimed by silence**

**RULE 16.3.** **Re-execution under a later policy version is NOT reproduction** (P0-02 EIK-INV-50). Reproducibility requires the historical policy version, which is retained permanently under RULE 8.2.

---

*End of the canonical specification. Derivation, adversarial analysis, contradiction audit, circular-dependency audit, ablation, false-precision audit, gap register and open research are in Volumes A–G (`17`–`23`). Executive verdict, candidate comparison, before/after ratings, final principles, and the FINAL STANDARD are in `README.md`.*
