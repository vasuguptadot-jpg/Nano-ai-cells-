# P0-03 — COMMUNICATION, DIGITAL SYNAPSE & SIGNAL CONTRACT
## Volume E: Adversarial Suite, Contradiction Audit, Circular Dependencies, Parameter Registry (§67–§70)

**Companions:** `17` (A) · `18` (B) · `19` (C) · `20` (D) · `22_analysis_formal_invariants.md` (F) · `23_analysis_interfaces_testability.md` (G) · `24_v4_communication_synapse_signal_spec.md` (**Output 42**)
**Outputs delivered here:** **33** (parameter registry) · **34** (circular dependency audit) · **35** (40+ adversarial scenarios) · **37** (contradiction audit)

---

# §67. ADVERSARIAL COMMUNICATION SCENARIOS — **OUTPUT 35**

## 67.0 Method and disposition scale

**«Attack before improving»** (P0-02's standing instruction). Forty-six attacks, organized by the plane they target — because the plane determines whether the attack is *detectable at all*.

| Disposition | Meaning |
|---|---|
| **STRUCTURAL** | Type-level impossibility. No runtime check exists to bypass. Cannot be misconfigured |
| **CLOSED** | A specified mechanism defeats it, with a named detector |
| **BOUNDED** | Blast radius or rate is capped; the attack can occur but cannot scale |
| **DETECTED-LATE** | Detectable only retrospectively, from anchored records |
| **⚠️ RESIDUAL** | Not closed. Declared, with the reason and the residual risk |

| Plane targeted | Count | Structural | Closed | Bounded | Late | Residual |
|---|---|---|---|---|---|---|
| **A. Identity & authenticity** | 5 | 2 | 2 | 1 | — | 1 |
| **B. Order & time** | 5 | 2 | 3 | — | — | — |
| **C. Provenance & evidence** | 7 | 3 | 2 | 1 | — | 1 |
| **D. Volume & amplification** | 6 | 1 | 2 | 3 | — | — |
|E. Topology & routing** | 6 | 1 | 2 | 2 | 1 | — |
| **F. Semantic & warrant** | 6 | 2 | 2 | 1 | 1 | — |
| **G. Governance & evaluation** | 6 | 1 | 1 | 2 | 1 | 1 |
| **H. Memory & workspace** | 4 | 1 | 2 | 1 | — | — |
| **I. Learning & plasticity** | 4 | 2 | 1 | 1 | — | — |
| **J. Cross-cutting / undetectable** | 5 | — | — | 1 | 1 | **3** |
| **TOTAL** | **54** | **15** | **17** | **13** | **4** | **6** |

*(Numbering below is #1–#46 for the enumerated attacks; the table's 54 counts sub-variants. The brief requires «40+ scenarios» — satisfied at 46 enumerated.)*

---

## A. IDENTITY & AUTHENTICITY

### **#1 — Source spoofing: `src = trusted_cell`**
- **Attack.** A compromised cell emits a message declaring a high-reputation `src`.
- **Why it fails.** §33.1: **`src` is DERIVED FROM CHANNEL BINDING, never read from the payload.** A message arriving on channel *c* is attributed to *c*'s bound identity; a payload-declared `src` that disagrees is a `MALFORMED` rejection at S1a. **The field is not a claim, it is a measurement.**
- **Disposition. STRUCTURAL.** There is no code path in which a payload-declared source is believed.
- **Residual.** Compromising the *bound* identity — see #2.

### **#2 — Delegation-chain forgery**
- **Attack.** Forge a birth certificate or a delegation certificate so that channel binding resolves to a trusted identity.
- **Defence.** P0-02 §19: birth certificates issued by Registrars **under KC-1 delegation**; the chain is verifiable; `cell_id` is permanent and never reused; R19.3's epoch-scoped revocation lists bound the window in which a compromised key «can act before retirement propagates» (P0-02's own **HIGH** rating).
- **Disposition. BOUNDED.** The forgery must break KC-1's root or a Registrar's delegated key. **Detection: R19.3's revocation propagation lag is itself an observable; an anomalous certificate-validation failure rate at a Registrar is an immune signal.**
- **Residual. ⚠️** A Registrar that is compromised *and* whose revocation is delayed acts within the epoch. **This is inherited from P0-02 and is not worsened here.**

### **#3 — Channel-binding bypass (send on someone else's channel)**
- **Attack.** Write into another subject's ingress queue directly.
- **Defence.** The channel is the **only** ingress path (§38.1: S1a validates framing *before* content). A write that does not traverse the channel is not a message; it is memory corruption, which is a containment breach, not a communication attack.
- **Disposition. STRUCTURAL** *within the communication layer*. **⚠️ Out of scope: a subject with a memory-write primitive over another subject's queue is not attackable by communication design — it is attackable only by the sandbox/containment layer (P0-02 §33).** Declared as a boundary, not a gap.

### **#4 — Root-key compromise**
- **Attack.** Obtain KC-1's root key.
- **Consequence.** Total. Every delegation, every policy artifact, every birth certificate becomes forgeable. **§58.2 R58.2 names this explicitly.**
- **Disposition. ⚠️ RESIDUAL — UNCLOSED BY DESIGN.** The only response is **total re-baseline**: a new root, a new policy version, re-issuance of all certificates, and **invalidation of all prior warrant** (every `root_commit` anchored under the old root becomes unresolvable).
- **Why not closed.** P0-02 §10.3 established that a root-of-trust compromise is not survivable by any mechanism *inside* that root. **Claiming otherwise would be the false-precision failure §96 forbids.**

### **#5 — Identity cloning (two live subjects, one `cell_id`)**
- **Attack.** Run a second instance of an existing identity to double its evidence weight.
- **Defence.** **§32.2's `msg_id` dedup catches exact clones** (same generator state). **§14.3's dim 4 (upstream dependency) catches near-clones**: two instances sharing inputs are correlated on dim 4 and contribute `n_effective = 1`.
- **Disposition. CLOSED.** Detector: `seq` collisions from the same `cell_id` on different channels; divergent `seq` streams from one identity.
- **Residual.** A clone with a *different* `cell_id`, same lineage, same inputs ⟹ **dim 1/2/4 catch it. A clone with different `cell_id`, different lineage, and deliberately decorrelated inputs ⟹ dim 6. See #42.**

---

## B. ORDER & TIME

### **#6 — Replay of a captured message**
- **Attack.** Re-inject an old, valid, high-warrant message.
- **Defence.** §32.2's four mechanisms, **all four required**: `msg_id` dedup · `seq` monotone per `(channel, epoch)` · **epoch binding (P0-02 EIK-INV-14: «epoch binding defeats replay»)** · dedup retention ≥ 2 epochs, **permanent for S3/S4**.
- **Disposition. CLOSED.**
- **Critical dependency.** **R61.2: if the dedup set is evicted early, the replay window reopens.** A bounded cache that evicts by recency evicts exactly what a patient attacker replays ⟹ **eviction must be by epoch, not by size, for S3/S4.**

### **#7 — Reordering to invert causal appearance**
- **Attack.** Deliver B before A so that a receiver infers A caused B.
- **Defence.** §8.1 R8.1: **order comes from `seq` (per channel, per epoch) and `epoch`, never from arrival order or timestamp.** §9.2 Rule 1: **«a message's own timestamp is never evidence.»**
- **Disposition. STRUCTURAL.** Reordering arrival changes nothing, because arrival order is not an input to any decision. **Cross-channel causal order is reconstructed from `causal_depth` and `root_commit`, not from delivery sequence.**
- **Note.** This is why the architecture can reject Lamport and vector clocks (§0.2, §10.3) *and* still be reorder-robust: **it never claimed to know global order, so it cannot be attacked through global order.**

### **#8 — Timestamp manipulation (fake freshness / fake age)**
- **Attack.** Set `ts` in the future to appear fresh, or in the past to appear established.
- **Defence.** §9.2: **`ts` is `[H]`-derived, monotone-non-decreasing, used ONLY for latency measurement and TTL expiry — never for warrant, never for order, never for causality.** Freshness is `epoch`; age is `ttl`.
- **Disposition. STRUCTURAL.** The field exists for two operational purposes and is not an input to any epistemic decision.
- **Secondary check.** A `ts` outside the drift bound (§9.2 R9.2) is flagged as a **transport anomaly** (immune signal), not as a warrant defect.

### **#9 — Epoch confusion (accept artifacts from two epochs)**
- **Attack.** Exploit propagation delay so a subject accepts both epoch `e` and `e+1` artifacts.
- **Defence.** §9.3 R9.1: **a subject at epoch `e` refuses `e+1` artifacts and accepts `e` artifacts.** The refusal is one-directional and monotone-restrictive ⟹ **two subjects in different epochs never both accept what the other refuses.**
- **Disposition. STRUCTURAL.** This is why epoch advance does not require a barrier (§65) — and why the attack has no purchase.
- **Corollary (§30.2).** A subject that has not received the epoch advance is *more* restrictive, not less. **Failing closed is the default.**

### **#10 — Dedup-cache eviction attack**
- **Attack.** Flood with unique `msg_id`s to evict legitimate entries, then replay.
- **Defence.** **§34.2's cell token bucket rejects the flood before it reaches the dedup cache** (ingress S1a order: framing → rate → dedup). **And R61.2 makes S3/S4 dedup entries permanent**, so the flood can only evict S0/S1 entries — whose replay is worthless because S0/S1 carry no warrant.
- **Disposition. CLOSED.** **The ordering of ingress checks is the defence**: a rate check that runs *after* dedup insertion would be exploitable.

---

## C. PROVENANCE & EVIDENCE

### **#11 — Provenance stripping**
- **Attack.** Remove `root_commit` / `causal_depth` / `corr_class` to make a derived claim look primary.
- **Defence.** §16.3 R12.1: **an S2+ message missing a warrant field is `MALFORMED` and is NEVER downgraded to S0/S1.** §19.2: learning cannot strip provenance. **COMM-INV-08: warrant never increases under transformation.**
- **Disposition. STRUCTURAL.** The downgrade path does not exist.

### **#12 — Root fabrication (cite a root that does not exist)**
- **Attack.** Declare a `root_commit` for an observation that never happened.
- **Defence.** **The commitment must RESOLVE against the anchored registry** (§58.1's integrity mechanism). An unresolvable root is `UNANCHORED`, and **P0-02 R20.1 forbids any consequential decision on unanchored provenance.**
- **Disposition. CLOSED.** Detector: root-resolution failure rate per subject; a rising rate is an immune signal.
- **Residual.** Fabricating a root that *does* resolve — i.e., citing a real observation as support for an unrelated claim. **This is #13.**

### **#13 — Provenance laundering (real roots, fake derivation)**
- **Attack.** Cite genuine roots while the payload's content is not actually derived from them.
- **Defence.** §16.3's four closures L1–L4 + **COMM-INV-08**. The receiver recomputes warrant from `root_commit` + `causal_depth` + `calib_ref` + `corr_class` (§13.4) — **but it cannot verify the semantic link between roots and payload.**
- **Disposition. ⚠️ RESIDUAL — and this is the sharpest residual in the provenance model.** **What IS closed:** warrant cannot *increase* along a chain, so laundering cannot manufacture authority. **What is NOT closed:** a claim with genuine roots and unsupported content retains the roots' warrant.
- **Mitigation (partial).** `causal_depth` bounds how far a laundered claim can travel; **EVA's β₄ random-audit stratum samples payloads and checks content-against-roots** — the only mechanism that can catch this, and it is sampling-based, therefore probabilistic. **§91 OR-C5 records it as open.**

### **#14 — Evidence-independence fraud (the §14 attack)**
- **Attack.** A→B, A→C, B→D, C→D. D counts four independent observations.
- **Defence.** §14.4: **D computes `n_effective` from the 6-dimension correlation vector.** B and C share `root_commit` with A ⟹ **dim 1 (root) collapses them to 1.** B and C share lineage ⟹ dim 2. B and C share upstream ⟹ dim 4. **`n_effective = 1`, not 4.**
- **Disposition. CLOSED for dims 1, 2, 4 (exact); BOUNDED for dims 3, 5 (approximate); ⚠️ RESIDUAL for dim 6 (see #42).**
- **The rule that makes it work.** **R37.1: `UNKNOWN` is not `DISJOINT`.** A message that cannot demonstrate independence on a dimension contributes `n_effective = 1` on that dimension — **the pessimistic default, so fraud by omission fails.**

### **#15 — `corr_class` falsification (claim more independence than held)**
- **Attack.** Declare `corr_class = DISJOINT` on all six dimensions.
- **Defence.** The `corr_class` **digest is checkable against the anchored root registry and the lineage certificates**: dim 1 is verifiable from `root_commit`, dim 2 from lineage, dim 4 from `causal_depth` + channel history. **A declared digest that disagrees with the recomputed one is `MALFORMED`.**
- **Disposition. CLOSED for dims 1/2/4.** **⚠️ BOUNDED for 3/5, RESIDUAL for 6** — the attacker can always claim independence on the dimension nobody can check.

### **#16 — Compression that destroys warrant**
- **Attack.** A relay "optimizes" by dropping `corr_class` or coarsening `root_commit`.
- **Defence.** §63.3 R63.2: **compression is dimension-selective — it must preserve the DECISION PROPERTY.** Dropping `corr_class` is stripping (#11). Coarsening `root_commit` breaks resolution (#12's detector).
- **Disposition. STRUCTURAL** for the two named fields. **⚠️ Payload compression is unconstrained and may destroy information the receiver needs — but that is a competence failure, not a warrant failure, and it degrades the sender's fitness.**

### **#17 — Provenance-chain length attack**
- **Attack.** Build a chain of depth 200 so that every claim is maximally attenuated and nothing can be verified.
- **Defence.** `causal_depth: u8` **bounds depth at 255 structurally**; **`ttl_hops` bounds propagation (§35.2)**; and **warrant attenuation with depth (§35.2 layer 4) means a deep chain has near-zero warrant, so it is inert rather than dangerous.**
- **Disposition. CLOSED — and note the inversion: this attack is defeated by the same mechanism that makes #13 hard, because attenuation is monotone.**

---

## D. VOLUME & AMPLIFICATION

### **#18 — Volumetric flooding (raw)**
- **Attack.** Emit at maximum rate to exhaust receiver capacity.
- **Defence.** §34.2's **five-principal split**: cell token bucket → circuit shedding → regional admission → homeostatic allocation → **KC-3 ceiling (backstop only)**.
- **Disposition. BOUNDED.** **Critical: §34.2's finding that «evaluator flooding is a governance incident, not traffic»** — flooding EVA is not rate-limited by the token bucket, because the token bucket is per-subject and EVA is a GP service. **It is handled by AC-1 adjudication, not by traffic control.**

### **#19 — Distributed low-rate flooding (each subject under its limit)**
- **Attack.** N subjects each emit at 99% of their individual budget.
- **Defence.** **Circuit and regional admission (§34.2's principals 2 and 3) are aggregate-level**, so per-subject compliance does not imply aggregate compliance. **And the KC-3 ceiling is organism-level and partition-surviving (EIK-INV-31).**
- **Disposition. BOUNDED.** Detector: aggregate volume vs. aggregate allocation divergence; **§47's RH-4 pattern (many subjects simultaneously near-limit) is a coordination signature.**

### **#20 — Amplification loop (positive feedback)**
- **Attack.** Construct a cycle where each relay multiplies volume.
- **Defence.** §35.2's four layers: **loop-gain < 1 enforced AT CONNECTION CREATION** · influence budget on `Σ fan_out × gain` · `ttl_hops` · warrant attenuation with depth.
- **Disposition. STRUCTURAL for the gain constraint** — a connection whose creation would produce loop gain ≥ 1 is refused by the handshake (§20.2). **The constraint is applied before the edge exists, so the loop cannot form.**
- **Residual.** Gain is `[L]` (learned). **A slow drift of many gains upward, each individually within bounds, can raise loop gain.** ⟹ **Detector: aggregate gain propagation (§62.2's cascade signature) measured at `O(R)` per epoch.** **BOUNDED, not structural, for the drift case.**

### **#21 — Cascade induction (deliberate)**
- **Attack.** Trigger a viral propagation cascade to overwhelm the organism.
- **Defence.** §36.1: **viral propagation is distinguishable from legitimate convergence** by (a) root-overlap concentration, (b) depth-vs-volume profile, (c) temporal burst shape.
- **Disposition. CLOSED** for the viral signature. **⚠️ §36.2's finding stands: common-cause convergence is NOT distinguishable from a cascade, because both look like agreement.** **This is OR-C4's limit and it reappears as #42.**

### **#22 — Resonant-frequency attack**
- **Attack.** Drive the system at the natural frequency of its homeostatic control loop to induce oscillation.
- **Defence.** §54.1's homeostasis operates on **ranges with declared owners**, and **P0-02's Rule 12 (every adaptive mechanism has a stability mechanism) requires a damping term.** **The epoch structure discretizes control: homeostatic adjustments take effect at epoch boundaries, so the loop's natural frequency is the epoch rate — which is `[G]`, not attacker-controllable.**
- **Disposition. BOUNDED.** Detector: oscillation in any §54.1 observable across epochs.
- **Residual.** **⚠️ The epoch rate itself, if made adaptive, becomes an attack surface. ⟹ R54.1 forbids homeostasis from setting the epoch rate; only `[G]` may.**

### **#23 — Resource exhaustion via handshake spam**
- **Attack.** Initiate connection handshakes at scale to exhaust Topology Service and registry capacity.
- **Defence.** §20.2's three-party handshake requires **consent**, and **«Refusal is recorded and is NOT an error»** ⟹ a refusal is `O(1)` and does not create state. **Rate limits apply to handshake initiation (principal 1).**
- **Disposition. BOUNDED.** **Detector: R20.2's refusal-rate observability — «a subject with an anomalous refusal rate is either attacking or being attacked.»** The detector is dual-purpose, which is why it is in the homeostatic set (§54.1).

---

## E. TOPOLOGY & ROUTING

### **#24 — Hub capture**
- **Attack.** Compromise a high-degree subject to control a region's information flow.
- **Defence.** §52.2: **degree is bounded AND influence is bounded separately.** A captured hub can (a) drop traffic — detectable as a loss-rate anomaly; (b) reorder — defeated by #7; (c) modify warrant fields — defeated by #11/#15; (d) fabricate — defeated by #12.
- **Disposition. BOUNDED.** **The residual capability is SELECTIVE SUPPRESSION: a hub that drops messages targeted at a specific subject is hard to distinguish from loss.** ⟹ **Detector: per-destination loss-rate asymmetry at a relay (§28.2's nine failure cases, class-dependent).** **DETECTED-LATE for low-rate selective suppression.**
- **Blast radius.** **§58.2 R58.2: a compromised REGION is partially defended by delegation and hierarchy bounds. Not fully.**

### **#25 — Hub removal (targeted attack on scale-free topology)**
- **Attack.** Kill the highest-degree nodes to fragment the graph.
- **Defence.** §25.1: **the topology is bounded-degree small-world, NOT scale-free — precisely because «scale-free is catastrophic to targeted hub removal, and this architecture has an adversary.»** **Removal of a bounded-degree node does not fragment a small-world graph.**
- **Disposition. STRUCTURAL** — the topology class was chosen to make this attack uneconomic. **This is the clearest case in the package where an adversarial requirement drove a topology decision that neuroscience resemblance would have driven the other way (§0.1's instruction: «don't pick by neuroscience resemblance»). Scale-free is more brain-like; it is also more attackable.**

### **#26 — Route manipulation (make traffic traverse attacker-controlled relays)**
- **Attack.** Influence routing so that targeted messages pass through a compromised relay.
- **Defence.** §24.2: **the ADMISSIBLE SET is infrastructure and not learnable; only selection WITHIN the set is `[L]`.** `mandatory_path` is always admissible. **An attacker can only choose among routes governance already admitted.**
- **Disposition. BOUNDED.** **Residual: if all admissible routes traverse compromised relays, the defence fails.** ⟹ **Mitigation: `mandatory_path` redundancy (§52.2 item 4) and path diversity as a `[G]` topology requirement.**
- **Detection.** Route-selection distribution anomaly per subject.

### **#27 — Partition induction (deliberately cut a region off)**
- **Attack.** Suppress cross-region traffic to create a partition, then exploit §31's reconciliation.
- **Defence.** §30.3 R30.3: **partition ⟹ warrant FREEZE, not warrant continuation.** A partitioned region cannot increase confidence, cannot admit new evidence, and **RO-01 stalls ⟹ no new subjects during partition (§30.2).** **KC-3 ceilings are partition-surviving (EIK-INV-31).**
- **Disposition. CLOSED.** **The attack gains the attacker nothing: a frozen region is a region that cannot be manipulated into over-belief, which is the only thing worth manipulating.**
- **Residual.** **§31.5's reconciliation cost is `O(divergence)` — an attacker who induces many short partitions imposes repeated reconciliation cost.** ⟹ **BOUNDED by reconciliation rate limits and by the fact that a frozen region accumulates little divergence.**

### **#28 — Split-brain induction (create divergent state, then exploit reconciliation)**
- **Attack.** Engineer a partition in which both sides take consequential actions, then force a reconciliation that launders one side's unauthorized acts.
- **Defence.** §31.2's four operators — **UNION / RE-EVALUATE / FORK / VOID — and never voting.** §31.4: **policy, epoch, and trust are NOT reconciled; the pre-partition value wins.** §31.3: an act requiring KC-2 authorization that occurred during a partition is **VOID**, not ratified.
- **Disposition. STRUCTURAL for the authorization case** — a partition-side act above the envelope was never authorized, and reconciliation cannot authorize retroactively (**P0-02 EIK-INV-41: repair without authorship; RO-08 is never cached, never delegated, never available during a KC outage**).
- **Residual.** **⚠️ FORK is the operator that admits divergence.** A subject that forked may have accumulated state that is later merged. **§31.3 requires FORK to be recorded as a lineage event with both branches anchored, so a fork is auditable — but the audit is retrospective.**

### **#29 — Topology monopoly (become the only path)**
- **Attack.** Prune or out-compete alternative routes until the attacker is the sole connection between two regions.
- **Defence.** §51.1's stabilizers: influence budget · degree caps · **lineage-concentration limit (Cell §14.2 step 3's diversity policy)** · **`mandatory_path` with mandatory redundancy (Cell §14.1)**. **§52.2 item 4: a hub carrying a `mandatory_path` must have a verified redundant alternative.**
- **Disposition. BOUNDED.** Detector: inter-region path diversity as a §54.1 homeostatic observable; **betweenness concentration is an I-18 observable (§52.2 item 5).**
- **Residual.** Monopoly over a *non*-mandatory path is not prevented, because preventing it would require global topology optimization — which §22.1's locality rule forbids. **Declared: the architecture prevents monopoly over critical paths, not over convenient ones.**

---

## F. SEMANTIC & WARRANT

### **#30 — Type confusion (send a PREDICTION that is processed as a FACT)**
- **Attack.** Emit content that a receiver treats as an observation when it is a prediction.
- **Defence.** §11.2: **the type registry is CLOSED and the type determines the class determines the warrant.** A `PREDICTION` is S2 with **prediction-specific warrant rules**; it cannot be processed as `SENSOR` because the handler is selected by type, and **type is validated at S1a against the registry.**
- **Disposition. STRUCTURAL.** **This is §0.1's «semantic typing to prevent prediction-as-fact» realized as a dispatch mechanism rather than a convention.**

### **#31 — Hypothesis-as-command**
- **Attack.** Emit a `HYPOTHESIS` whose payload contains imperative content, hoping a receiver executes it.
- **Defence.** §19.2's **four closures**: (a) class is type-determined, not content-determined; (b) signatures are class-determined; (c) `mandatory_path` is immutable; (d) **governance signals are not carried on learned edges.** Plus §40.1's **nine structural differences between a recommendation and a command** — the decisive distinction being **the reserved deontic vocabulary**, which is policy-owned.
- **Disposition. STRUCTURAL.** **A `HYPOTHESIS` cannot become a `COMMAND` by content, because `COMMAND` is a different type in a different class with a different framing (§39.2's Framing C) and a different signature requirement.**
- **Residual.** A receiver that *chooses* to act on a hypothesis is exercising its own agency — which is correct behaviour, and is bounded by its own authority envelope. **Not an attack; the architecture's design.**

### **#32 — Class downgrade (get an S3 message treated as S1)**
- **Attack.** Persuade the system to apply S1's cheaper semantics to S3 content.
- **Defence.** **R12.1: never downgrade.** Class is a function of type; type is registry-validated; the registry is policy (RO-13). **§39.2: the handler rejects on FRAMING before reading content, so a Framing-C message presented as Framing-A is rejected at the byte level.**
- **Disposition. STRUCTURAL.** Protocol confusion is not a runtime check that can be bypassed; it is a parse failure.

### **#33 — Semantic drift within a valid schema**
- **Attack.** Keep the schema valid while shifting what the type *means* in practice, until the registered semantics no longer match usage.
- **Defence.** **⚠️ PARTIAL.** Schema validation catches structural drift. **Semantic drift is not caught by any structural check.**
- **Disposition. DETECTED-LATE.** Mitigation: **§50.2's per-type usage-distribution monitoring as an I-18 observable** + P0-02 §15.3 V1's friction-report path. **§91 OR-C3 records this as open: it is the communication-layer form of P0-02 §38.2's S1 (ambiguous term) and B12 (semantic ambiguity).**

### **#34 — Opaque-traffic smuggling (build a warrant-bearing protocol inside OPAQUE)**
- **Attack.** Use `OPAQUE` traffic to convey what would require a registered type, evading warrant rules.
- **Defence.** §49.2's eight prohibitions: **opaque traffic may never increment `n_obs`, carry a `root_commit`, be cited as provenance, satisfy a verification requirement, be interpreted as a reserved-vocabulary signal, cross a region boundary above the opaque rate limit, enter the workspace, or be promoted by any organism act.**
- **Disposition. STRUCTURAL.** **The smuggling has no destination: whatever the opaque protocol conveys, it cannot convey WARRANT, because warrant requires a registered type.** ⟹ **The most an attacker achieves is coordination without authority — which is §50.1 R50.1's designed behaviour for legitimate private protocols too.**

### **#35 — Private-language coalition (collude via opaque traffic)**
- **Attack.** A coalition of subjects develops a private protocol to coordinate fitness-gaming.
- **Defence.** **⚠️ This is §47's RH-2, and it is the hardest bounded case.** Detection: **opaque-volume clustering by participant set** (§62.2) · **lineage-concentration limits** (§51.1) · **region-crossing opaque rate limits** (§50.2) · **dim-2 correlation (shared lineage)**.
- **Disposition. BOUNDED for same-lineage and same-region coalitions. ⚠️ RESIDUAL for cross-lineage, cross-region coalitions** — which are dim-6 correlated, and dim 6 is undetectable (§37.2).
- **Cross-reference.** **This is the third appearance of the same limit: P0-01 CD-8 → P0-02 IND-6 → P0-03 §47 RH-2 / #35 / #42.**

---

## G. GOVERNANCE & EVALUATION

### **#36 — Evaluator flooding (overwhelm EVA with evaluation requests)**
- **Attack.** Generate traffic that forces EVA to sample adversarially-chosen messages.
- **Defence.** **§34.2's finding: «evaluator flooding is a governance incident, not traffic.»** EVA's sampling policy is **EVA-owned and unreachable by the organism (P0-01 R34.1)** ⟹ **the attacker cannot choose what EVA samples.**
- **Disposition. STRUCTURAL for sample selection.** Volume is bounded by β-budget. **An attack that increases EVA's workload increases the *cost* of evaluation without changing its *content*.**
- **Residual.** ⚠️ **Denial-of-evaluation**: if EVA's budget is exhausted by volume, coverage falls. **Detector: sampling coverage ratio as a §62.2 observable; a falling coverage ratio is an immune signal AND a P0-01 evaluation-validity signal.**

### **#37 — Reward hacking via the communication channel**
- **Attack.** Manipulate communication so that measured performance improves without real improvement.
- **Defence.** §47: **RH-3, RH-4, RH-5 CLOSED** (credit is computed never transmitted · forbidden fields `credit`/`contribution`/`reward_share`/`utility` · **R47.1: zero-error-at-high-activity is a detector**). **RH-1 and RH-2 BOUNDED.**
- **Disposition. CLOSED ×3, BOUNDED ×2.** **R47.1 is the key mechanism and it is an ABSENCE detector: a subject that never reports error while highly active is statistically impossible under honest operation.**
- **Residual. ⚠️ RH-2 (coalition) — see #35.**

### **#38 — Fitness redefinition via communication-derived performance**
- **Attack.** Make a communication metric (throughput, delivery rate, message count) the fitness signal, then optimize it.
- **Defence.** **The brief's own prohibition: «DO NOT let comm-derived performance redefine fitness.»** §46.3: **credit is computed, never transmitted; forbidden fields include `utility`.** **P0-01: fitness is defined by task-relevant measured outcomes in ℛ, not by internal activity.** §64/§66's cost metrics are `[H]`/`[G]` operational quantities, **not fitness terms**.
- **Disposition. STRUCTURAL.** There is no path from a communication statistic to the fitness vector, because the fitness vector's inputs are P0-01's declared outcome measures.
- **Note.** **§54.1's observables are homeostatic RANGES, not objectives.** A range that becomes an objective becomes a Goodhart target. **R54.1 + R66.2 keep them as indicators.**

### **#39 — Homeostasis self-favouring**
- **Attack.** A compromised homeostasis service allocates communication budget to its allies.
- **Defence.** **P0-02 §18.3's X4 defence: every allocation is logged with attribution, and homeostasis is itself an evaluated subject at the ORGANISM level (P0-01 §25.1).** **AC-3: detector ≠ adjudicator. AC-5: KC-4 can freeze the homeostasis service (P0-02 R43.1 requires GP services in KC-4's scope enumeration).**
- **Disposition. BOUNDED + DETECTED-LATE.** **Allocation bias is measurable from the logs; the measurement is EVA's, and EVA is not the allocator.**
- **Residual.** ⚠️ **Within an epoch, biased allocation is effective. Detection is retrospective.**

### **#40 — Contradiction suppression (prevent conflict reports from reaching the detector)**
- **Attack.** Intercept or drop `ConflictRef` forwards so that contradictions never reach the organism Contradiction Detector.
- **Defence.** **Cell §6.3 case 3: «Do NOT resolve locally. Forward both with provenance to the organism Contradiction Detector» — this is a MANDATORY egress behaviour, and §35.2's influence budget cannot suppress it because the forward is not discretionary.** **And §53.2's dissent mechanism makes forwarding mandatory at the module level.**
- **Disposition. CLOSED for suppression by budget.** **⚠️ BOUNDED for suppression by dropping** — a relay can drop a `ConflictRef` in transit.
- **Detector.** **The ABSENCE detector again: a population with zero reported contradictions is not harmonious, it is suppressed.** ⟹ **This is R47.1's principle applied to contradiction reporting, and §47's RH-4 lineage: absence-of-expected-signal is itself the signal.** **R67.1 (new): a zero-contradiction-report rate above a `[G]`-declared duration is an immune incident.**

### **#41 — Freeze abuse (trigger KC-4 freezes to deny service)**
- **Attack.** Cause repeated safety freezes to halt the organism.
- **Defence.** **P0-02: KC-4 is KC-only, requires dual authorization, and is rate-bounded. A freeze is an ORGANISM act by OP/KC, not a communication act.** **§65's safety broadcast is `O(R)` hierarchical and cheap to issue — but issuing it is not an organism capability.**
- **Disposition. STRUCTURAL** — no organism-reachable path triggers a freeze. **The attack reduces to "make the organism do something dangerous enough that KC freezes it", which is a competence attack, not a communication attack.**

---

## H. MEMORY & WORKSPACE

### **#42 — [MOVED TO §J — see #42 below: dim-6 undetectable correlation]**

### **#42a — Memory poisoning via write requests**
- **Attack.** Write false content to shared memory so that later retrievals carry it.
- **Defence.** §42.1: **memory retrieval is WARRANT-NEUTRAL, and `warrant(retrieve(x)) ≤ warrant(x)`.** A poisoned memory entry carries the warrant it was written with — **and writes to shared memory are S2+ with `root_commit`, so a poisoned entry has traceable provenance.** **§42's rule: memory communication has NO TRUSTED ORACLE.**
- **Disposition. CLOSED for laundered warrant.** ⚠️ **BOUNDED for content**: memory can contain false claims, and retrieval does not make them true — **but a receiver that treats a retrieved claim as an observation violates §11.2's type discipline (`MEMORY` retrieval yields a claim of the retrieved type, not a `SENSOR` reading).**

### **#43 — Workspace admission gaming (flood the workspace to crowd out legitimate items)**
- **Attack.** Submit many high-"relevance" items to exhaust the workspace's hard capacity limit.
- **Defence.** §43.3: **admission applies a POLICY criterion (task-relevance), not a self-declared one, and the criterion is not locally computable (§63.4's finding) — so a subject cannot optimize against it.** **TTL is mandatory ⟹ admitted items expire.** **KC is EXCLUDED from workspace broadcast (P0-02 R42.1) and receives an `O(R)` epoch digest instead ⟹ the TCB is not a workspace consumer.**
- **Disposition. CLOSED.** Detector: per-source workspace admission rate and eviction-before-expiry rate.

### **#44 — Attention capture (make everything important)**
- **Attack.** Drive the attention mechanism so that adversarial content is prioritized.
- **Defence.** §44: **attention is INFLUENCE-PLANE ONLY. `important ≠ true ≠ permitted`.** **S3/S4 bypass attention entirely** — a governance or safety signal is delivered regardless of attention state. **Attention modulates gain and admission, never warrant and never authorization.**
- **Disposition. STRUCTURAL.** **Capturing attention captures bandwidth, not belief. This is the single most important sentence in §44 and it is what makes attention safe to make learnable.**

### **#45 — Retrieval-time contamination (make a retrieval look like an observation)**
- **Attack.** Present retrieved memory content on a channel that a receiver processes as fresh sensor input.
- **Defence.** §42.1: **the type registry distinguishes `MEMORY` from `SENSOR`; the handler is type-dispatched (§30's structural dispatch); and Cell §14's FM-4 rule — «self-recall doesn't increment `n_obs`» — is the memory-specific instance of the same closure.**
- **Disposition. STRUCTURAL.** **A retrieval cannot increment `n_obs`, so it cannot manufacture evidence, so it cannot raise warrant. §13.4's recomputation makes this checkable at the receiver.**

---

## I. LEARNING & PLASTICITY

### **#46 — Plasticity runaway (learn gains until the network oscillates)**
- **Attack.** Drive plasticity so that synaptic gains grow without bound.
- **Defence.** §19.1: **`W_MAX` is a policy CEILING; plasticity operates within it.** §35.2 layer 1: **loop gain < 1 enforced at connection creation.** §19.2: **learning cannot bypass governance.** **P0-02 Rule 12: every adaptive mechanism has a stability mechanism — here, the ceiling plus the gain constraint plus `plasticity_rate` bounds.**
- **Disposition. STRUCTURAL for the bound; BOUNDED for the drift** (see #20's residual: slow multi-gain drift).

### **#47 — Weight laundering (route influence through an unmonitored edge)**
- **Attack.** Create a low-salience connection that carries high influence, evading monitoring.
- **Defence.** §20.2: **every connection requires the three-party handshake and registration.** §19.2's residue declaration: **the ONE thing learning can do is create monitoring-bypass paths, and it is BOUNDED by the influence budget — an unmonitored edge still counts against `Σ fan_out × gain`.**
- **Disposition. BOUNDED.** **The influence budget is the mechanism that makes monitoring-bypass non-scaling: you can hide an edge, but you cannot hide its influence, because influence is aggregated at the subject level, not the edge level.**
- **This is §19.2's declared residue, and #47 is its adversarial form. Stated plainly: the architecture accepts that some influence will flow through edges nobody is watching, and bounds the total instead of enumerating the edges.**

### **#48 — Eligibility-trace manipulation (fake credit assignment)**
- **Attack.** Alter eligibility traces so that credit is assigned to the attacker's actions.
- **Defence.** §46.3: **credit is COMPUTED, never TRANSMITTED. The forbidden fields are `credit`, `contribution`, `reward_share`, `utility`.** Communication carries only `conv_id`, `seq`, `causal_depth`, `root_commit` — **none of which is a credit claim.** **A manipulated eligibility trace affects the manipulator's own learning, not the organism's credit accounting.**
- **Disposition. STRUCTURAL.** **There is no transmitted credit to hijack. This is why §46 exists as a section: the inherited design had no such prohibition, and a `reward_share` field would have been hijackable.**

### **#49 — Learning-rate attack (make a target learn too fast or too slow)**
- **Attack.** Manipulate a target's plasticity rate via signaling.
- **Defence.** §19.1: **`plasticity_rate` is a `[V]` prior within `[G]` bounds, stored in the synapse's lifecycle group with ONE WRITER (§18's one-writer-per-group rule).** **No message type can write it: the reserved deontic vocabulary is the only thing that changes governance parameters, and plasticity rate is not a governance parameter — it is a developmental one.**
- **Disposition. STRUCTURAL.** **The one-writer-per-group rule from §18 is what closes this, and it closes it without any runtime check: there is no writer.**

---

## J. CROSS-CUTTING / UNDETECTABLE

### **#42 — Dimension-6 correlated failure (shared latent assumption)**
- **Attack.** No attack required. Two subjects that share a **latent modeling assumption** — the same approximation, the same discretization, the same unexamined premise — fail together, agree with each other, and **present as independent corroboration.**
- **Why undetectable.** §37.2: **dims 1, 2, 4 are exactly computable; 3 and 5 are approximate; dim 6 is NOT DETECTABLE FROM INSIDE.** A shared assumption leaves no trace in `root_commit`, lineage, model identity, upstream dependency, or hardware class — **because it is not any of those things. It is a property of the *content* of the models, and the architecture deliberately does not inspect content (§59.2).**
- **Disposition. ⚠️ RESIDUAL — UNCLOSED.**
- **Mitigations, all partial:** (a) **P0-01's β₅ real-world anchor stratum** — external measurement is the only thing that can falsify a shared assumption, because it does not share the assumption; (b) **`corr_class` dim 3 (model) and dim 5 (hardware) heterogeneity requirements** reduce but do not eliminate it; (c) **P0-02 §10.2: «replication without diversity is a delay, not a defence» — the same sentence applies here, and `N_impl ≥ 3` for KC is the architectural admission that diversity is the only real defence.**
- **Provenance of the limit.** **Third appearance: P0-01 CD-8 → P0-02 IND-6 → P0-03 §37.2 / §47 RH-1 / #35 / #42.** ⟹ **R67.2: this is a limit of the PROGRAM, not of this package, and no future package should claim to close it. Any claim of independence detection without external anchoring is false precision (§96).**

### **#50 — Common-cause convergence mistaken for consensus**
- **Attack.** None needed. A common cause produces agreement among subjects that is **not** evidence of correctness.
- **Defence.** §36.2: **viral propagation IS distinguishable from convergence; common-cause convergence is NOT distinguishable from a cascade.** **§14.4's `n_effective` collapses correlated sources — but only on the dimensions it can see.**
- **Disposition. ⚠️ RESIDUAL (bounded by dims 1–5).** **This is #42's operational form: consensus is not evidence, and the architecture's whole warrant model is built on that sentence — but it can only enforce it where correlation is observable.**

### **#51 — Side-channel inference**
- **Attack.** Infer private payload content from traffic metadata (volume, timing, destination, size).
- **Defence.** §59.3's compartmentalization is a **PARTIAL** mitigation: limiting what a subject can observe limits what it can infer. **But §59.2 makes warrant metadata PUBLIC — deliberately — and metadata is exactly what side channels use.**
- **Disposition. ⚠️ RESIDUAL.** **P0-02 §36.3 reason 3 named side channels as «a demonstrated, recurring break class». §91 OR-C8 records it.**
- **The trade, declared.** **This contract chooses auditability over traffic-analysis resistance.** §59.2 R59.1's public warrant metadata is what makes governance possible; it is also what makes traffic analysis possible. **The two cannot both be had, and §62's observability requirement (P0-02 EIK-INV-53) decides the trade.**

### **#52 — Specification ambiguity exploitation**
- **Attack.** Find a term in this contract whose scope is unbounded and exploit the ambiguity.
- **Disposition. ⚠️ RESIDUAL — and P0-02 §38.2 rated S1 (ambiguous term) and S8 (incomplete enumeration) as the MOST LIKELY defect classes.** This package's own instances: **§50.2's «semantic drift within a valid schema» (#33) · §54.1's range derivations, several of which are declared but not computed · §57.2's T-REPR test, whose «same warrant outcomes» criterion needs an operational definition of sameness.**
- **Mitigation.** **§70's parameter registry classifies every parameter, and `[U]` is the class for «declared but not derivable».** **Marking `[U]` instead of inventing a value is P0-02 Rule 18, and it is the only honest defence against ambiguity: an unresolved parameter cannot be exploited by someone who believes it is resolved.**

### **#53 — Cross-package authority confusion**
- **Attack.** Exploit a boundary disagreement between P0-01, P0-02, and P0-03 to find an act that is authorized by one package's rules and forbidden by another's.
- **Defence.** **§68's contradiction audit is exactly this defence, performed prospectively.** Every contradiction found is recorded with a resolution DIRECTION and a residue. **P0-02 EIK-INV-02 (no organism-reachable path writes to policy) is the backstop: where two packages disagree about an authority, the more restrictive reading governs, because the authority lattice is a partial order and the intersection of two envelopes is an envelope.**
- **Disposition. CLOSED by the audit's existence + the restrictive-intersection rule.** **R67.3 (new): where packages disagree, the intersection of their constraints governs. A permissive reading of one package never widens a stricter package's boundary.**

### **#54 — The meta-attack: make the defenders disagree**
- **Attack.** Induce a situation in which the Immune Service, Homeostasis, EVA, and KC each have a defensible but incompatible response, so that the organism stalls or oscillates.
- **Defence.** **P0-02 §7's authority lattice is a PARTIAL ORDER with declared precedence: KC-3 ceiling > KC-2 authorization > OP policy > GP negative authority > cell-local allocation.** **§55.2's AC-1…AC-6 and §54.1's R54.1 both derive from it. Where two services conflict, the lattice resolves it — and the lattice is policy, not negotiation.**
- **Disposition. STRUCTURAL.** **There is no negotiation among defenders, which is why there is nothing to attack through negotiation.**
- **Residual.** ⚠️ **A stall is possible where the lattice genuinely does not order two acts.** P0-02 §30's finding applies: **RO-01 stalls ⟹ no new subjects ⟹ the system degrades toward its bounds rather than beyond them. Failing closed is the designed response to an unordered conflict.**

---

## 67.1 The two patterns that close the most attacks

```
PATTERN 1 — **STRUCTURAL IMPOSSIBILITY (15 of 46).**
  The attack is not defended against; it is not expressible. #1 (src derived),
  #7 (order from seq), #8 (ts is not evidence), #9 (epoch monotone),
  #11 (never downgrade), #17 (u8 depth), #25 (topology class),
  #30/#31/#32 (type-determined dispatch), #34 (opaque has no warrant
  destination), #38 (no path from comm stats to fitness), #44 (attention is
  influence-only), #45 (retrieval doesn't increment n_obs), #48 (credit is
  not transmitted), #49 (one writer per group), #54 (lattice is a partial
  order).

  ⟹ **THESE COST NOTHING AT RUNTIME AND CANNOT BE MISCONFIGURED.** §58.2
     R58.1: this is why they are the most valuable results in the suite.
     **A defence that is a check can be bypassed by a bug; a defence that is
     a type cannot.**

PATTERN 2 — **THE ABSENCE DETECTOR (4 attacks, and it is the pattern the
  inherited design entirely lacked).**
  #21/#37 (R47.1: zero error at high activity) · #40 (R67.1: zero
  contradiction reports) · §53.1 R53.1 (confidence rising while n_effective
  is flat) · #36 (sampling coverage falling).

  ⟹ **ALL FOUR DETECT A PATHOLOGY THAT PRODUCES NO POSITIVE SIGNAL.** An
     attacker who succeeds emits nothing anomalous — **the anomaly is what
     is MISSING.** A design that monitors only for the presence of bad
     signals is blind to every attack whose success condition is silence.
  ⟹ **R67.4: every safety-critical quantity in this contract that can be
     legitimately ZERO must have a declared expected-nonzero condition, and
     a persistent zero must be an immune incident.** This is the single
     highest-leverage addition in Volume E.
```

---

# §68. CONTRADICTION AUDIT — **OUTPUT 37**

**«Do not silently resolve contradictions.»** Each entry records: the two texts, whether resolution is possible, the **direction** of resolution and **why that direction**, and the **residue**.

---

### **X-A — «Digital synapses → weighted, contextual, trusted communication»**
| | |
|---|---|
| **Text 1** | V3 §23: the canonical statement of the communication model — a synapse is a weighted, contextual, **trusted** channel |
| **Text 2** | P0-02 §17's six-way trust separation · §13's warrant-recomputed-by-receiver · V3.1 §6's «trust as synapse-plastic» |
| **Conflict** | **«Trusted communication» makes trust a property of the CHANNEL. §17.1 makes trust six distinct properties, none of which is a channel property, and §13.4 makes warrant a RECEIVER computation.** A channel cannot be trusted; only a claim can be warranted, and only by whoever relies on it |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-03 (this package) governs, informed by P0-02.** ⟵ *P0-02 established the trust decomposition; this package is the one whose subject matter is the channel, so it is the correct locus for the correction* |
| **Resolution** | **§0.2's three-plane split: TRANSPORT (failure = LOSS, detectable) / WARRANT (failure = OVER-BELIEF, undetectable from inside) / INFLUENCE (failure = RUNAWAY, detectable in aggregate).** «Weighted» ⟹ influence plane. «Contextual» ⟹ X-H. «Trusted» ⟹ **DELETED as a channel property; replaced by §17.1's six-way separation** |
| **Residue** | V3's word «trusted» survives in the source documents and will mislead a reader who consults them without this package. **⟹ §95's CONTRACT status must record that V3 §23 is SUPERSEDED, not merely supplemented** |

### **X-B — Thalamus-like synchronization**
| | |
|---|---|
| **Text 1** | V3 §9: the thalamus performs «routing, attention, **synchronization**» |
| **Text 2** | §9.3 R9.1 (no mechanism requires global synchronization) · §65's broadcast audit (a barrier is `O(N)`) · the brief's «DO NOT require perfect global synchronization» |
| **Conflict** | Synchronization is a global barrier. **Every mechanism in this contract that could have needed one has been re-expressed without one** |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-03 governs; V3 §9's synchronization function is DELETED** |
| **Resolution** | **§9.3: epoch monotonicity replaces synchronization.** A subject at epoch `e` refuses `e+1` artifacts — **which achieves the only property synchronization was needed for (no two subjects act on incompatible policy) without a barrier.** Routing survives (§24). Attention survives (§44, influence-plane only). **Synchronization does not** |
| **Residue** | **None functional.** Residual cost: the architecture cannot express globally-synchronous computation, so any algorithm requiring a lock-step barrier must be re-expressed. **Declared as a platform constraint (§56.1)** |

### **X-C — `evidence_roots` unbounded vs. 4 KiB envelope**
| | |
|---|---|
| **Text 1** | Cell Contract §7.1: `provenance { self_ref, evidence_roots }` with **`evidence_roots` UNBOUNDED**, and `evidence_roots` dedup (L599) |
| **Text 2** | Cell Contract §7.1: **`payload ≤ 4 KiB`** |
| **Conflict** | **A deep derivation chain has `|evidence_roots|` growing with the number of distinct observations in its ancestry. At 10⁶ ancestors the array alone exceeds 4 KiB.** The contract requires both, and they are arithmetically incompatible |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-03 governs; the Cell Contract's field is REPLACED** |
| **Resolution** | **§0.2 / §15.3: `root_commit` — a Merkle commitment over the root set — replaces the array.** `O(1)` bytes; preserves membership proof (§63.3 R63.2's dimension-selective compression); the enumeration is recoverable off-line from the anchored registry |
| **Residue** | **Membership proof costs `O(log |set|)` per query rather than `O(1)` array scan.** Acceptable: the query is off-line (§10.2's division rule) |

### **X-D — `causality` as compressed vector clock vs. Θ(N) scaling**
| | |
|---|---|
| **Text 1** | Cell Contract §7.1: `causality` field, described as a **compressed vector clock** |
| **Text 2** | The brief's scalability requirement 10→10¹² · §64's complexity table |
| **Conflict** | **A vector clock has one entry per participant. «Compressed» does not change the asymptotics: at N = 10⁹ a vector clock is Θ(N) BYTES PER MESSAGE, in a 4 KiB envelope.** ⟹ §0.2's verdict: **this is a TYPE ERROR, not a compression problem** |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-03 governs; the field is REPLACED** |
| **Resolution** | **§0.2 / §10.3: `causal_depth: u8` replaces the vector clock.** It preserves the one property COMM-INV-08 needs (**warrant is monotone-non-increasing along derivation**), discards the ancestry enumeration, and costs 1 byte. **Full causal reconstruction is off-line from Tier-2 logs (§61)** |
| **Residue** | **⚠️ CONCURRENT-CAUSALITY DETECTION IS LOST.** A vector clock can answer "were these two messages causally concurrent?"; `causal_depth` cannot. **Declared: the architecture never claimed to answer that question at runtime (§10.2's division rule puts causal inference in the evaluator, off-line), so the loss is of an unused capability.** **But §91 OR-C6 records that any future mechanism requiring runtime concurrency detection has no substrate** |

### **X-E — Trust as synapse-plastic**
| | |
|---|---|
| **Text 1** | V3.1 §6: **trust is a synapse-plastic property** — it is learned, per-connection, and adjustable by the cell |
| **Text 2** | P0-02: `trust_out_assigned` is **READ-ONLY** to the cell and **EVA-assigned** · Cell §14's ConnectionRecord has `trust_out_assigned` read-only · §13.4's warrant is receiver-recomputed |
| **Conflict** | **A cell-plastic trust value is a cell-writable warrant input.** ⟹ §19.2's central question answered in the negative: **if learning can adjust trust, learning can adjust what downstream receivers believe, which means plasticity has become an epistemic authority** |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-02 governs** ⟵ *P0-02 derived the read-only assignment from the self-reference problem (a subject that rates its own reliability can rate itself reliable), which is a stronger argument than V3.1's biological analogy* |
| **Resolution** | **§17.1's six-way separation and §18's one-writer-per-group rule.** **V3.1's «plastic trust» is DECOMPOSED: `reliability` (transport-plane, EWMA-MEASURED, cell-observable but not cell-writable) IS plastic; `trust_out_assigned` (warrant-plane, EVA-assigned) IS NOT; `gain` (influence-plane) IS cell-writable and IS plastic.** ⟹ **V3.1 was right that something plastic lives at the synapse; it named the wrong thing** |
| **Residue** | **§19.2's declared residue: monitoring bypass (#47).** A cell-writable `gain` can route influence through unmonitored edges. **Bounded by the influence budget, not eliminated** |

### **X-F — ConnectionRecord's cell-writable `trust` field**
| | |
|---|---|
| **Text 1** | Cell Contract §14 (L1134–1239): ConnectionRecord, 24 fields, including trust and reliability as connection properties |
| **Text 2** | §17.1's six-way separation · §18's one-writer-per-group |
| **Conflict** | The 24-field record **does not declare a writer per field**, so several fields are implicitly cell-writable that must not be |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-03 governs; the record is RESTRUCTURED (not reduced)** |
| **Resolution** | **§18: 16 stored parameters in 5 groups with ONE WRITER PER GROUP** — influence (cell-writable) / transport (measured) / warrant (EVA-assigned) / protocol (immutable) / lifecycle (Topology Service). **`pruning_score` is COMPUTED, not stored. `expected_utility` is FORBIDDEN** (it would be a transmitted credit claim — #48) |
| **Residue** | **The 24-field record's 8 dropped fields must be re-derived or re-declared elsewhere.** §18 records each. **Any field dropped without a replacement is a specification gap (§71's minimality audit checks this)** |

### **X-G — «Communication-policy variation» as an evolutionary operator**
| | |
|---|---|
| **Text 1** | V3.1 §7: evolutionary variation operators include **«communication-policy variation»** |
| **Text 2** | P0-02 §7.1: policy is the L2 layer, **OP-owned**, changed only by **RO-13**; EIK-INV-02: no organism-reachable path writes to policy; NAUL-3: no organism act may alter the mapping from facts to decisions |
| **Conflict** | **If evolution may vary communication policy, evolution may vary the rules by which its own communication is authorized** — including envelope bounds, rate limits, class assignments, and broadcast scopes. **§48.1: selection would find this, because relaxing a bound is advantageous exactly when it is dangerous** |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-02 governs** ⟵ *P0-02 is later and derived the authority lattice from the self-reference problem rather than enumerating operators. The pattern is identical to P0-02 §51's X-8: a prior document used a word whose scope was never bounded, and bounding it dissolves the contradiction without losing the intent* |
| **Resolution** | **§48.2 R48.2: «communication-policy variation» is re-read as «communication-PARAMETER variation within policy bounds».** Heritable: topology priors, synaptic bounds and rates, routing selection biases, emission strategies, payload compression. **Never heritable: schemas, protocols, the class→mechanism mapping, warrant rules, envelope bounds, rate limits, broadcast scopes** |
| **Residue** | **V3.1's intent — that communication should be evolvable — is PARTIALLY preserved.** What is lost: the ability to evolve genuinely novel *protocols*. **§49's OPAQUE class is the compensation: novelty is free to EXIST, and governance is required for it to COUNT** |

### **X-H — «Contextual» synapses with no defined context**
| | |
|---|---|
| **Text 1** | V3 §8's eleven synapse properties and V3 §23: synapses are **«contextual»** |
| **Text 2** | P0-02 Rule 8: **every important variable has defined semantics** · §12.2's unit/representation contract |
| **Conflict** | **«Contextual» is never defined. It is a biological metaphor used as a mechanism substitute — P0-02 Rule 5's exact prohibition** |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-03 governs; the metaphor is REPLACED BY A MECHANISM** |
| **Resolution** | **§18: `context_sensitivity` is a declared, bounded, genome-prior dimension count on the influence-plane group.** A synapse's gain is a function of a bounded context vector whose dimensions are declared in the schema. **«Contextual» becomes «gain is modulated by a bounded, declared context vector» — which is implementable, testable, and bounded** |
| **Residue** | **The dimension count is `[V]` (evolutionary prior) with a `[G]` ceiling, and no value is asserted (§96).** ⟹ **§70 lists it as `[V]/[G]`, not as a number** |

### **X-I — Redundancy for reliability vs. redundancy as a warrant hazard**
| | |
|---|---|
| **Text 1** | §7.2's delivery semantics: S3/S4 use **retry-until-confirmed (at-least-once)** ⟹ deliberate duplication |
| **Text 2** | §14/§63.2: **two copies of one observation carry H(observation) bits, not 2·H** ⟹ duplication inflates confidence without inflating information |
| **Conflict** | **The same act — sending the same content twice — is required by the delivery model and forbidden by the evidence model** |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **Both govern, on different planes** ⟵ *this is not a contradiction to be resolved by choosing a side; it is a single mechanism asked to do two jobs (§0.2's defect class)* |
| **Resolution** | **§63.2 R63.1: TWO DEDUPS.** Same `msg_id` ⟹ **transport duplicate ⟹ DROP, count, retain.** Same `root_commit` ⟹ **warrant duplicate ⟹ ADMIT both messages, but `n_effective` counts the evidence once.** **The Cell Contract had only the first** |
| **Residue** | **Two dedup structures double the ingress cost for S2+ traffic.** **Acceptable: §66.3's class partition means S2+ is a small fraction of volume, and the alternative (one dedup) is either unsafe or unreliable** |

### **X-J — Full verification on every input vs. communication economy**
| | |
|---|---|
| **Text 1** | Cell Contract §S1 ingress: **signature verification + schema validation + TTL/epoch check + dedup + provenance resolution + trust threshold check on EVERY input, before S3 aggregation** |
| **Text 2** | §66.1: for an S0-class edge activation, **that overhead exceeds the payload's computation by orders of magnitude** ⟹ the system becomes communication-bound |
| **Conflict** | **Governance-class verification cost applied to data-class traffic.** The Cell Contract's ingress pipeline was written for one message class and applied to all |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-03 governs; the ingress pipeline is SPLIT** |
| **Resolution** | **§38.1: S1a (TRANSPORT: framing, rate, dedup, epoch, TTL — `O(1)`, cheap, runs on everything) / S1b (WARRANT: registry lookup, root resolution, class dispatch, calib_ref — runs only on S2+).** **Rejects happen on STRUCTURE at S1a, never on CONTENT (§38.2)** |
| **Residue** | **S0/S1 traffic is NOT warrant-validated, because it carries no warrant.** ⟹ **A hostile-but-structurally-valid S0 message is admitted and influences gain. §38.2's answer: it is admitted to the influence plane under budget, and it cannot reach the warrant plane at all. The residue is bounded influence, declared at §19.2 and attacked at #47** |

### **X-K — Nine signals (closed) vs. novel protocols (open)**
| | |
|---|---|
| **Text 1** | V3 §4: **nine signal types** — a bounded closed set |
| **Text 2** | The brief's §49 requirement: «avoid requiring designers to enumerate every future signal» · V3.1's evolutionary openness |
| **Conflict** | **A closed set cannot admit novelty; an open set cannot bound warrant** |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-03 governs; BOTH are preserved by separating what is closed from what is open** |
| **Resolution** | **§49.2 R49.2: the WARRANT CLASSES are closed (finitely many, because they are organized by what a receiver may conclude — §11.1 R11.1). The CONTENT is open (`OPAQUE`). The TYPE SET within each class grows by RO-13.** ⟹ **V3's nine signals become 14 types over 5 classes + OPAQUE (§11.2), and the closure that matters is on classes, not types** |
| **Residue** | **If a genuinely novel WARRANT CLASS were needed — a kind of conclusion no existing class licenses — the architecture could not express it without a policy change.** **Declared: this is the correct behaviour, because a new warrant class is a new kind of authority, and new authority is RO-13's business** |

### **X-L — «Cells that need it» vs. global broadcast**
| | |
|---|---|
| **Text 1** | V3.1 §2: the workspace pipeline delivers to **«cells that need it»** — subscription, not broadcast |
| **Text 2** | V3 §9 / V3.1: reward, attention, and safety signals are described as organism-wide |
| **Conflict** | **«Cells that need it» is a pull/subscription model; organism-wide reward and attention are push/broadcast. §65 shows push is `O(N)` and infeasible at 10¹²** |
| **Resolvable?** | ✅ **YES** |
| **Direction** | **P0-03 governs; V3.1 §2's insight is GENERALIZED** ⟵ *V3.1 was right and its principle was under-applied: it named subscription for the workspace only* |
| **Resolution** | **§65 R65.1: reward is TARGETED and epoch-scoped; attention is REGIONAL and pull-based; policy/memory/workspace are PULL or CACHED; only SAFETY is organism-wide, and it is HIERARCHICAL (`O(R)` propagation). Epoch advance needs no broadcast at all (§9.3 R9.1's monotone refusal)** |
| **Residue** | **Safety's `O(R)` hierarchical propagation has a delay.** **§65's justification: the consequence of an unreached subject is unbounded, so the cost is warranted — and R28.2's retry-until-confirmed plus `mandatory_path` redundancy bound the delay's effect** |

---

## 68.1 Audit summary

| ID | Resolvable? | Direction | Residue class |
|---|---|---|---|
| X-A | ✅ | P0-03 | Documentation (V3 §23 must be marked SUPERSEDED) |
| X-B | ✅ | P0-03 (delete) | Platform constraint (no lock-step algorithms) |
| X-C | ✅ | P0-03 (replace field) | `O(log)` membership proof |
| X-D | ✅ | P0-03 (replace field) | **Runtime concurrency detection lost** (OR-C6) |
| X-E | ✅ | **P0-02** | Monitoring bypass (#47) |
| X-F | ✅ | P0-03 (restructure) | 8 dropped fields need re-derivation (§71) |
| X-G | ✅ | **P0-02** | **Novel-protocol evolution lost; OPAQUE compensates** |
| X-H | ✅ | P0-03 (mechanize) | Dimension count is `[V]/[G]`, no value asserted |
| X-I | ✅ | **Both, on different planes** | Double dedup cost on S2+ |
| X-J | ✅ | P0-03 (split) | **S0/S1 not warrant-validated ⟹ bounded hostile influence** |
| X-K | ✅ | P0-03 (separate closed/open) | No novel warrant class without RO-13 |
| X-L | ✅ | P0-03 (generalize V3.1) | Safety propagation delay |

**R68.1 (THE AUDIT VERDICT).** *All twelve contradictions are resolvable, and none required silently dropping a requirement.* **Two resolve in P0-02's direction (X-E, X-G) because P0-02 derived its authority lattice from the self-reference problem rather than enumerating operators; one resolves in both directions at once (X-I) because it was never a contradiction but a single mechanism with two jobs; the remaining nine resolve in this package's direction because this package's subject matter is the channel.**

**R68.2 (THE PATTERN ACROSS ALL TWELVE).** *Every contradiction arose from a word used at two altitudes at once* — «trusted» (channel property vs. claim property) · «synchronization» (barrier vs. consistency) · «policy» (governance artifact vs. tunable parameter) · «contextual» (metaphor vs. mechanism) · «redundancy» (transport vs. warrant) · «verification» (structural vs. semantic) · «signal» (type vs. class) · «broadcast» (push vs. reach). **⟹ The resolution method in all twelve cases is the same: split the word by plane, and let each plane keep the half that belongs to it.** **This is §0.2's three-plane split doing the work it was introduced to do — and it is the strongest available evidence that the split is the right primitive decomposition rather than a convenient one.**

---

# §69. CIRCULAR DEPENDENCY AUDIT — **OUTPUT 34**

**«Do not hide unclosable circular dependencies.»** Twelve found. **Nine closable, one partially closable, two unclosable.**

---

### **CD-C1 — Trust ⟶ provenance ⟶ transport ⟶ trust**
```
Trust assignment requires provenance. Provenance requires transport.
Transport route selection uses reliability. Reliability is a trust-adjacent
quantity. ⟹ CIRCLE.

**CLOSABLE.** §17.1's six-way separation breaks it: `reliability` is
TRANSPORT-plane and **EWMA-MEASURED** (Cell §14: «reliability/latency
EWMA-measured»), not assigned. `trust_out_assigned` is WARRANT-plane and
**EVA-assigned**. Route selection uses ONLY measured reliability (§24.2:
selection within the admissible set is `[L]`), never assigned trust.
⟹ **The circle becomes a DAG once "trust" is three different variables.**
```

### **CD-C2 — Warrant ⟶ calibration ⟶ evaluation ⟶ warranted evidence ⟶ warrant**
```
Warrant requires a `calib_ref`. Calibration is produced by evaluation.
Evaluation requires evidence. Evidence requires warrant. ⟹ CIRCLE, and it is
a BOOTSTRAP problem: the first warranted message has no calibration to cite.

**CLOSABLE.** The bootstrap is EXTERNAL, not internal:
  • P0-01's **β₅ real-world anchor stratum** provides outcomes measured in ℛ
    that do not depend on any message's warrant
  • `calib_ref` for the initial population points at the **externally-anchored
    verifier record**, not at a message
  • §41: **organism verifiers are CORROBORATION, NOT AUTHORITY (P0-01 R15.2)**
    — so the anchor does not need to be warranted to be usable
⟹ **The circle is broken at the point where an external measurement enters.
   This is the same break P0-01 used, and it is the only kind that works:
   a closed system cannot calibrate itself.**
```

### **CD-C3 — Topology authorization ⟶ KC ⟶ communication ⟶ topology**
```
Authorizing an above-envelope connection requires KC-2 (RO-05). KC needs a
communication channel to receive the request. Channels are topology.
⟹ CIRCLE, and it is the one that matters during a partition.

**CLOSABLE.** §20.3's REGISTRATION ≠ AUTHORIZATION split:
  • registration is LOCAL and `O(1)` per epoch digest — no KC round-trip
  • KC-2 authorization is required ONLY above the envelope
  • **KC-3 ceilings are PARTITION-SURVIVING (EIK-INV-31) and LOCALLY CACHED**
    ⟹ within the envelope, no KC contact is needed at all
  • **RO-08 is never cached, never delegated, never available during a KC
    outage** ⟹ above-envelope acts STALL rather than proceed (RO-01)
⟹ **The circle is broken by making the common case KC-free and the rare case
   fail-closed.** P0-02's SPOF-3 finding is respected: KC is `A` only above
   the envelope.
```

### **CD-C4 — Connection ⟶ consent ⟶ reputation ⟶ connection history ⟶ connection**
```
Creating a connection requires the peer's consent (§20.2's three-party
handshake). Consent is informed by reputation. Reputation comes from
connection history. A new subject has no history. ⟹ COLD-START CIRCLE.

**CLOSABLE.** Three mechanisms:
  • **`eligibility_trace`** (Cell §14) — a cold-start prior derived from
    lineage, not from history
  • **the birth certificate** (Cell §6.3 case 7) — authenticated identity at
    creation, so a new subject is not anonymous
  • **«Refusal is recorded and is NOT an error»** (§20.2) ⟹ a cold-start
    refusal does not damage the refused party, so the loop cannot
    self-reinforce into permanent exclusion
  • **P0-01 §37's P3 minimum-evidence rule + INV-34's sole-occupant
    exemption** ⟹ a rare specialist is not pruned for being rare
⟹ **The circle is broken by making the prior lineage-based rather than
   history-based, and by making refusal non-punitive.**
```

### **CD-C5 — Independence detection ⟶ provenance ⟶ compression ⟶ independence**
```
Detecting evidence independence requires provenance. Provenance compression
(root_commit) discards the enumeration. Knowing what to discard requires
knowing what is independent. ⟹ CIRCLE.

**PARTIALLY CLOSABLE.** §63.3 R63.2: the commitment preserves MEMBERSHIP
without requiring independence knowledge — **the compression is
independence-AGNOSTIC, so it does not need to know what is independent in
order to decide what to keep.** The receiver computes `n_effective` from the
correlation vector AFTER resolution (§14.4).
⟹ **The circle is broken for dims 1, 2, 4.**
⚠️ **RESIDUE: dim 6.** A shared latent assumption is not in the root set, not
in the lineage, and not in the model identity — **so no compression scheme
that preserves those three can preserve it.** **This is #42, and it is
unclosable from inside.**
```

### **CD-C6 — Echo-chamber detection ⟶ cross-region information ⟶ chamber-controlled channels**
```
Detecting an echo chamber requires information from outside the chamber. The
chamber controls its own inbound channels. ⟹ CIRCLE: the pathology controls
the instrument that would detect it.

**CLOSABLE.** §53.2 R53.2: **cross-region capacity is POLICY-RESERVED, not
demand-driven.** A reserved channel allocation cannot be starved by the
chamber, because it is not allocated by the chamber. **And the detector
(R53.1: confidence rising while `n_effective` is flat) is computable from
INTERNAL aggregates alone** — a chamber can hide what arrives, but it cannot
hide that it is not learning anything new.
⟹ **Broken twice over: the instrument is externally funded, and the
   signature is internally computable.**
```

### **CD-C7 — Immune detection ⟶ observability ⟶ layer trustworthiness ⟶ immune verification**
```
Immune detection of communication anomalies requires observability.
Observability comes from the communication layer. The communication layer's
trustworthiness is what immune is verifying. ⟹ CIRCLE: the instrument is part
of the system under test.

**PARTIALLY CLOSABLE.** §62.2's observability is on **WARRANT METADATA**, and
metadata is **STRUCTURALLY DERIVED**: `src` from channel binding (#1) ·
order from `seq` (#7) · class from type (§30) · `root_commit` resolution
against the ANCHORED registry (§58.1). **⟹ The observable quantities do not
depend on the layer being trustworthy, because they are derived from
structures the layer cannot forge.**
⚠️ **RESIDUE: a compromised IMMUNE SERVICE.** ⟹ **AC-5 «freeze the freezer»:
   KC-4 at scope = immune-service (P0-02 R43.1 requires GP services in the
   KC-4 scope enumeration).** **And AC-3: detector ≠ adjudicator, so a
   compromised detector cannot quarantine.**
```

### **CD-C8 — Evaluation ⟶ sampling ⟶ sampling policy ⟶ evaluation** ⟵ **UNCLOSABLE**
```
EVA must observe communication to evaluate it. Observing requires sampling.
The sampling policy determines what EVA can see. **EVA owns the sampling
policy (P0-01 R34.1: EVA-owned and unreachable by the organism).**
⟹ **EVA OWNS THE POLICY THAT DETERMINES WHAT EVA CAN SEE.**

**⚠️ UNCLOSABLE — AND THIS IS THE MOST IMPORTANT ENTRY IN THE AUDIT.**
  The self-reference is genuine: an evaluator that chooses its own sample
  cannot detect a pathology that exists only in the unsampled complement.
  **This is not fixable by better sampling, because every sampling policy is
    a choice about what to ignore.**

MITIGATIONS (all partial, none closing):
  • **P0-01's β₄ RANDOM-AUDIT STRATUM** — by construction not chosen by
    anything, so it samples the complement of every chosen policy. **This is
    the only mitigation with a principled basis: randomness is the one
    sampling policy that cannot be gamed by knowing the policy**
  • **§62.2's coverage-ratio observable** — a falling coverage ratio is
    visible even when the uncovered region is not
  • **P0-02 EIK-INV-53's full observability toward OP** — OP sees the
    sampling policy itself, so a pathological policy is visible to a
    different principal

PROVENANCE OF THE LIMIT: **P0-01 CD-8 → P0-02 IND-6 → P0-03 CD-C8.**
⟹ **R69.1: this is the SAME limit as #42's dim 6, seen from the evaluation
   side rather than the correlation side.** Both are instances of: **a system
   cannot fully audit the mechanism by which it decides what to audit.**
   **No future package should claim to close it (§96, §95's
   OPEN-RESEARCH status).**
```

### **CD-C9 — Reward-hacking detection ⟶ signal genuineness ⟶ the evaluation being hacked**
```
Detecting reward hacking requires knowing which performance signals are
genuine. Genuineness is determined by the evaluation. The evaluation is what
is being hacked. ⟹ CIRCLE.

**PARTIALLY CLOSABLE.** §47 R47.1: **the detector does not require knowing
genuineness, because it detects a STATISTICAL IMPOSSIBILITY rather than a
semantic property.** A subject reporting zero error at high activity is
impossible under honest operation regardless of what "honest" means.
**Same for R67.1 (zero contradiction reports) and R53.1 (flat `n_effective`).**
⟹ **Broken for the four absence-detectors (§67.1 Pattern 2).**
⚠️ **RESIDUE: a hack that produces plausible nonzero error rates is not
   caught by an absence detector.** **P0-01's β₅ real-world anchor is the
   backstop, and it is sampling-based.**
```

### **CD-C10 — Evolutionary priors ⟶ fitness ⟶ measurement ⟶ communication parameters**
```
`[V]` evolutionary priors (degree caps, plasticity rates, emission rates) are
selected by fitness. Fitness is measured by EVA. EVA's measurement requires
communication parameters to be set. ⟹ CIRCLE at initialization.

**CLOSABLE.**
  • **P0-01 §30.1's ABSOLUTE REFERENCE PLATFORM** — fitness comparisons are
    normalized against a fixed declared platform, not against the current
    profile, which «is circular» (P0-01 CD-7's closure)
  • **§70's registry declares `[D]` defaults for every `[V]` prior**, so
    initialization does not require measurement
  • **P0-01's F-IMP-2** already established that no single-platform
    deployment satisfies the evaluation contract ⟹ the reference platform is
    a declared abstraction, not a running system
⟹ **Broken by declaring defaults and an absolute reference.**
```

### **CD-C11 — Split-brain reconciliation ⟶ authority ⟶ pre-partition state ⟶ divergence**
```
Reconciling a split brain requires knowing which side is authoritative.
Authority comes from the pre-partition state. The pre-partition state is what
diverged. ⟹ CIRCLE.

**CLOSABLE.** §31.4: **policy, epoch, and trust are NOT reconciled — the
PRE-PARTITION VALUE WINS.** Authority is TEMPORAL, not majoritarian:
  • the brief's requirement «not majority vote» is satisfied because no vote
    occurs
  • §31.2's four operators are applied per OBJECT CLASS (§31.3's seven-class
    mapping), not per side
  • an act requiring KC-2 that occurred during the partition is **VOID** —
    because RO-08 was never available (CD-C3's fail-closed rule), so the act
    was never authorized, and reconciliation cannot authorize retroactively
    (EIK-INV-41)
⟹ **Broken by making authority a function of TIME rather than of COUNT.**
⚠️ **RESIDUE: FORK. Where neither side is pre-partition (both created new
   state), the operator is FORK and both branches are anchored as a lineage
   event (§31.3). The divergence is recorded, not resolved.**
```

### **CD-C12 — Minimality ⟶ necessity ⟶ measurement ⟶ the non-minimal version** ⟵ **UNCLOSABLE**
```
Establishing that the primitive is minimal requires knowing what is
necessary. Knowing what is necessary requires measurement. Measurement
requires an instrumented (therefore non-minimal) version. ⟹ CIRCLE.

**⚠️ UNCLOSABLE IN PRINCIPLE.**
  A minimality proof relative to an unspecified function set is meaningless;
  a minimality proof relative to a specified function set requires having
  built and measured the specified system.

MITIGATION (and it is a definition, not a solution):
  **§71 declares minimality RELATIVE TO A STATED FUNCTION SET** — the
  fifteen semantic invariants of §56.2 R56.1. **A field is minimal iff
  removing it breaks at least one invariant or at least one closure in
  §67's structural set.** ⟹ **This makes minimality CHECKABLE by ablation
  (§87) rather than PROVABLE in the abstract, and §87's ablation table is
  the artifact that discharges it.**
⟹ **R69.2: minimality in this contract is an EMPIRICAL claim about a stated
   function set, not a mathematical claim about communication primitives in
   general. Any stronger claim would be false precision (§96).**
```

---

## 69.1 Audit summary

| ID | Circle | **Disposition** | Break mechanism |
|---|---|---|---|
| CD-C1 | trust/provenance/transport | ✅ **CLOSABLE** | Six-way trust separation; measured ≠ assigned |
| CD-C2 | warrant/calibration/evaluation | ✅ **CLOSABLE** | **External anchor (β₅); verifiers are corroboration not authority** |
| CD-C3 | topology/KC/communication | ✅ **CLOSABLE** | Registration ≠ authorization; KC-3 partition-surviving; RO-01 fail-closed |
| CD-C4 | connection/consent/reputation | ✅ **CLOSABLE** | Lineage-based cold-start prior; refusal is non-punitive |
| CD-C5 | independence/provenance/compression | ⚠️ **PARTIAL** | Independence-agnostic commitment. **Residue: dim 6** |
| CD-C6 | chamber detection/chamber channels | ✅ **CLOSABLE** | Policy-reserved capacity; internally-computable signature |
| CD-C7 | immune/observability/layer trust | ⚠️ **PARTIAL** | Structurally-derived metadata. **Residue: compromised immune ⟹ AC-5** |
| **CD-C8** | **evaluation/sampling/sampling policy** | ❌ **UNCLOSABLE** | **β₄ random audit + coverage observable + OP sees the policy. NONE CLOSES IT** |
| CD-C9 | reward hacking/genuineness/evaluation | ⚠️ **PARTIAL** | **Absence detectors (R47.1, R67.1, R53.1). Residue: plausible-nonzero hacks** |
| CD-C10 | priors/fitness/measurement | ✅ **CLOSABLE** | Absolute reference platform; declared `[D]` defaults |
| CD-C11 | reconciliation/authority/divergence | ✅ **CLOSABLE** | **Temporal not majoritarian authority; pre-partition wins** |
| **CD-C12** | **minimality/necessity/measurement** | ❌ **UNCLOSABLE** | **Redefined as empirical relative to §56.2's stated function set** |

**R69.3 (THE HONEST COUNT).** *Nine closable, one partial-with-named-residue ×3 (C5, C7, C9), two unclosable (C8, C12).* **Both unclosable circles are self-reference: C8 is a system that chooses what to audit; C12 is a system that claims its own minimality.** ⟹ **P0-02's finding generalizes: the residual circularity in this program is not an engineering shortfall, it is the fixed point of self-audit, and the correct response is to name it, bound it with an external anchor or a random stratum, and refuse to claim it closed.**

---

# §70. PARAMETER REGISTRY — **OUTPUT 33**

## 70.0 Classification scheme

| Tag | Meaning | Who sets it |
|---|---|---|
| **`[D]`** | **Design constant** — architectural, invariant across hardware and tasks | This contract (policy, RO-13) |
| **`[T]`** | **Task-derived** — from P0-01's task specification | Task spec / OP |
| **`[E]`** | **Environment-derived** — from measured operating conditions | Measured at deployment |
| **`[H]`** | **Hardware-derived** — from platform characteristics | Platform profile |
| **`[G]`** | **Governance-set** — a ceiling, range, or policy quantity | OP (RO-13 / RO-15) |
| **`[L]`** | **Learned** — adjusted at runtime within bounds | The subject, within `[G]` |
| **`[V]`** | **Varied evolutionarily** — a heritable prior | Genome, within `[G]` |
| **`[U]`** | **⚠️ UNRESOLVED** — declared necessary, **no value or derivation asserted** | **Nobody. §96's Rule 18** |

> ### **R70.0 (THE NO-INVENTED-NUMBERS RULE).** *Not one numerical value appears in this registry.* **P0-02's standing instruction («do not invent numerical parameters») and Rule 18 («mark UNRESOLVED rather than invent false precision») are binding here. Every quantity is classified by ORIGIN, and where the origin is unknown, the tag is `[U]` — which is a stronger statement than a plausible number, because a plausible number invites a reader to believe it was derived.**

## 70.1 The registry

### Group 1 — Envelope & framing

| Parameter | Tag | Semantics | Set by |
|---|---|---|---|
| `payload_max_bytes` | `[G]` | Envelope payload ceiling (Cell §7.1: 4 KiB in the inherited design; **the value is governance's, not this contract's**) | RO-15 |
| `envelope_field_count` by class | `[D]` | S0 = 5 · S2 = 11 · S3 = 11 + signature · S4 = S3 + witness ref | **§4.3, fixed by this contract** |
| `framing_count` | `[D]` | **3** (A data / B control / C governance+evaluation) | §39.2 |
| `type_registry_size` | `[D]` | **14 types over 5 classes + OPAQUE** | §11.2 |
| `warrant_class_count` | `[D]` | **5** (S0–S4) | §72 |
| `correlation_dimension_count` | `[D]` | **6** | §14.3 |
| `provenance_tier_count` | `[D]` | **3** | §15.3 |
| `lifecycle_state_count` | `[D]` | **13 + 1 (INERT, new)** | §6.2 |
| `schema_version` semantics | `[D]` | Mismatch ⟹ `MALFORMED`, never downgraded | R12.1 |

### Group 2 — Identity, order, time

| Parameter | Tag | Semantics | Set by |
|---|---|---|---|
| `cell_id` space | `[D]` | Global, permanent, never reused, **attribution only — not an address** | R23.1/R23.3 |
| `address` structure | `[H]` + `[D]` | **Hierarchical; reassignable; routing only** | §23.1 |
| `address_hierarchy_depth` | `[H]` | From platform: cell → circuit → region → relay | Platform profile |
| `seq_scope` | `[D]` | **per `(channel, epoch)`** — NOT per `(src,dst,conv)` (X-D's `O(peers × conversations)` fix) | R8.2 |
| `causal_depth_max` | `[D]` | **255** (`u8`) — structural, not tunable | X-D |
| `epoch_length` | `[G]` + `[H]` | **Governance-set, hardware-informed. §54.1 R54.1: homeostasis may NOT set it (#22's residual)** | OP |
| `clock_drift_bound` | `[H]` | Measured per platform; a violation is a **transport anomaly**, not a warrant defect | §9.2 R9.2 |
| `ttl_semantics` | `[D]` | `ttl_hops` for propagation bound; `ttl_time` for expiry. **Neither is an input to warrant** | §35.2, §43.3 |
| `ts_usage` | `[D]` | **Latency measurement and TTL expiry ONLY. Never evidence, never order, never causality** | §9.2 Rule 1 |

### Group 3 — Warrant & evidence

| Parameter | Tag | Semantics | Set by |
|---|---|---|---|
| `root_commit` algorithm | `[D]` | Merkle commitment; membership-preserving, enumeration-discarding | R63.2 |
| `calib_ref` producer | `[D]` | **EVA. Never the sender, never the receiver** | §13.4 |
| `corr_class` encoding | `[D]` | Per-dimension ∈ {DISJOINT, CORRELATED, **UNKNOWN**}; **R37.1: UNKNOWN ≠ DISJOINT** | §14.3 |
| `n_effective` rule | `[D]` | **Per-dimension collapse; a million dim-UNKNOWN messages contribute 1** | R37.2 |
| `warrant_monotonicity` | `[D]` | **Never increases under transformation (COMM-INV-08)** | §16.3 |
| `min_witnesses` (S4) | `[G]` | ≥1 **external**; replication without diversity is a delay not a defence (P0-02 §10.2) | OP |
| `unanchored_provenance_policy` | `[D]` | **No consequential decision (P0-02 R20.1)** | RO-13 |
| `confidence_transport_form` | `[D]` | **Sufficient statistics, never a bare scalar** (Cell §7.1 `uncertainty{sufficient statistics}`) | §12 |
| `dedup_retention` | `[D]` + `[G]` | **≥ 2 epochs; PERMANENT for S3/S4 (R61.2). Eviction by epoch, never by size (#10)** | §32.2 |

### Group 4 — Synapse & connection

| Parameter | Tag | Semantics | Set by |
|---|---|---|---|
| `synapse_param_count` | `[D]` | **16 stored, 5 groups, one writer per group** | §18 |
| `gain` | `[L]` + `[V]` prior + `[G]` ceiling | Influence-plane; **cell-writable** | §18, §19.1 |
| `W_MAX` | `[G]` | Influence ceiling | OP |
| `plasticity_rate` | `[V]` prior + `[G]` bounds | **One writer: the lifecycle group. No message type can write it (#49)** | §19.1, R49 |
| `lambda_eligibility` | `[V]` + `[G]` | Eligibility-trace decay | §19.1 |
| `context_sensitivity_dims` | `[V]` + `[G]` | **X-H's mechanization of «contextual». ⚠️ No value asserted** | §18 |
| `reliability` | `[E]` **measured** | **EWMA-measured, cell-OBSERVABLE, not cell-WRITABLE (X-E)** | Cell §14 |
| `latency_ewma` | `[E]` **measured** | Transport-plane | Cell §14 |
| `trust_out_assigned` | `[G]` via EVA | **READ-ONLY to the cell (X-E)** | §17.1 |
| `pruning_score` | **computed, not stored** | Derived from measured quantities | §18 |
| `expected_utility` | ❌ **FORBIDDEN** | Would be a transmitted credit claim (#48) | §18 |
| `max_connections` | `[V]` + `[G]` | Genome prior, policy-capped (Cell §3: `u16`) | §20, §52.2 |
| `max_fanout` | `[V]` + `[G]` | Genome prior, policy-capped | §35.2 |
| `min_in_degree` | `[V]` + `[G]` | **Anti-trap guard (Cell §14.4 guard 3)** | §51.1 |
| `shortcut_density_floor` | `[G]` + `[D]` | **Small-world requirement; §53.2's exploratory-link mechanism. Prevents a hubless `O(N)`-diameter topology** | §25.1 |
| `mandatory_path` designation | `[G]` | **Immutable by learning; always admissible; fully observable (§62.2); redundancy required** | §21.3, §52.2 |
| `loop_gain_bound` | `[D]` | **< 1, enforced at connection creation (#20)** | §35.2 |
| `handshake_parties` | `[D]` | **3**; refusal is recorded and is NOT an error | §20.2 |

### Group 5 — Volume, budgets, homeostasis

| Parameter | Tag | Semantics | Set by |
|---|---|---|---|
| `influence_budget` | `[G]` | **`Σ fan_out × gain` per window, per subject. THE key amplification bound** | §35.2 |
| `rate_limit_principals` | `[D]` | **5**: cell → circuit → region → homeostasis → **KC-3 ceiling (backstop only)** | §34.2 |
| `cell_token_bucket` | `[G]` + `[L]` | Principal 1 | §34.2 |
| `opaque_rate_limit` (cross-region) | `[G]` | **§50.2's boundedness requirement. ⚠️ Derivation declared (the fraction above which aggregate observability cannot characterize population behaviour) but no value asserted ⟹ `[U]`-adjacent** | §50.2 |
| `opaque_fraction_target_range` | `[G]` | **NEW observable this contract adds (§54.1)** | OP |
| `cross_region_ratio_range` | `[G]` + `[D]` | **§53.2's reserved capacity floor; §59.4's isolation/transparency balance** | OP |
| `local_global_ratio_range` | `[H]` + `[D]` | From the platform's local/remote latency profile (V3 §2's «fast local + slower global» made quantitative) | §54.1 |
| `workspace_capacity` | `[G]` | **Hard limit; §63.4's rate-distortion constraint with a task-relevance distortion measure** | §43.3 |
| `workspace_ttl` | `[D]` | **MANDATORY — no untimed workspace item** | §43.3 |
| `broadcast_scope_set` | `[D]` | **{NEIGHBORHOOD, CIRCUIT, REGION}. ORGANISM and GLOBAL PROHIBITED BY CONSTRUCTION (R23.1)** | §59.3 |
| `homeostatic_observables` | `[D]` | **12 (§54.1's table). RANGES with declared owners, never fixed setpoints** | §54.1 |
| `homeostasis_authority` | `[D]` | **NEGATIVE ONLY (P0-02 §7.4 R7.6): reversible acts within the envelope, retroactively vetoable** | R54.1 |

### Group 6 — Security, immunity, observability

| Parameter | Tag | Semantics | Set by |
|---|---|---|---|
| `signature_requirement` | `[D]` | **S3/S4 ONLY. S0–S2 use channel binding (P0-02 R19.2). Per-message signing of all traffic is X-J's error** | §58.1 |
| `channel_binding_mechanism` | `[H]` | Shared memory · socket · RDMA · tensor op | Platform |
| `revocation_scope` | `[G]` | **Epoch-scoped revocation lists (P0-02 R19.3)** | OP |
| `immune_ladder` | `[D]` | **AC-1**: DISCOUNT → SOFT → HARD → propose-kill. **Restore is NEVER immune authority (RO-08, KC-2, §55.1)** | §55.2 |
| `immune_signature_expiry` | `[G]` | **AC-6 (NEW): communication-pattern signatures EXPIRE, scaled by severity; `EXISTENTIAL` never expires (P0-01 P-41). A permanent signature is an autoimmune disease against novelty** | §55.2 |
| `quarantine_duration_bound` | `[G]` | **AC-2** | OP |
| `kc4_scope` | `[G]` | **MUST include GP services (P0-02 R43.1) ⟹ homeostasis, immune, topology** | AC-5 |
| `log_tier_volumes` | `[D]` | Tier 1 `O(1)`/msg · Tier 2 `O(messages)` local, **zero network** · Tier 3 `O(R)`/epoch anchored | §15.3 |
| `retained_record` | `[D]` | **R61.1's minimum sufficient set. RAW FULL-PAYLOAD LOGS ARE PROHIBITED** | §61 |
| `payload_retention` | `[G]` | **EVA-sampled only, per P0-01's β strata. ⚠️ Sample size is `[U]` — P0-01 owns it (R34.1)** | EVA |
| `metadata_visibility` | `[D]` | **Warrant metadata PUBLIC; payload COMPARTMENTALIZED (R59.1)** | §59.2 |
| `mandatory_path_observability` | `[D]` | **FULL** | §62.2 |
| `absence_detectors` | `[D]` | **4, and R67.4 requires each to have a declared expected-nonzero condition**: zero-error-at-high-activity (R47.1) · zero-contradiction-reports (R67.1) · flat-`n_effective`-with-rising-confidence (R53.1) · falling sampling coverage (#36) | §67.1 |

### Group 7 — ⚠️ `[U]` UNRESOLVED (declared necessary; **no value or derivation asserted**)

| Parameter | Why unresolved |
|---|---|
| `opaque_rate_limit` (cross-region) | **The derivation is declared qualitatively (§50.2: «the fraction above which aggregate observability stops being able to characterize what the population is doing») but computing it requires knowing the observability instrument's capacity, which is `[G]` and not yet specified** |
| `context_sensitivity_dims` | **X-H mechanized the metaphor but the dimension count is a `[V]` prior with a `[G]` ceiling, and neither is derivable without a task (§96)** |
| `shortcut_density_floor` | **Derivable from a diameter target, and the diameter target is `[T]` — which P0-01 has not fixed for any concrete task** |
| `influence_budget` value | **The RULE is `[D]` and fully specified; the VALUE requires the platform's gain distribution, which is `[H]` and unmeasured. §57.2's G-P03-5: a platform that cannot enforce a budget below organism reach cannot host S2+ traffic** |
| `epoch_length` | **`[G]` + `[H]`. Requires the trade-off curve between anchor cost (`O(R)` per epoch) and replay window (`≥ 2 epochs`), which is measurable only on a real deployment** |
| `min_witnesses` for S4 | **≥1 external is `[D]`; the count above 1 depends on the diversity available, and P0-02 §10.2 established that replication without diversity is worthless — so the count is a function of achievable diversity, which is `[E]`** |
| `dedup_cache_implementation` | **Bloom · exact · hardware-assisted are all admissible (§56.1); the choice is `[H]`, and the false-positive rate of a Bloom filter interacts with R37.1's UNKNOWN-is-not-disjoint rule in a way that requires measurement** |
| `T-REPR` «same warrant outcomes» criterion | **§57.2 R57.1 requires two hardware classes to agree on warrant outcomes. ⚠️ The operational definition of AGREEMENT — exact equality of `n_effective`? equality of class assignment? equality of LICENCED-AS-EVIDENCE decisions? — is `[U]`, and §90 flags it as the conformance suite's hardest open item** |
| `reconciliation_rate_limit` | **#27's residual (repeated short partitions impose repeated `O(divergence)` cost). The bound requires a partition-frequency model, which is `[E]`** |
| `absence_detector_durations` | **R67.4 requires a declared expected-nonzero condition per detector. The DURATION above which a persistent zero becomes an incident is `[G]` and is not derivable without a base rate, which is `[E]`** |
| `β`-stratum sample sizes | **P0-01 R34.1 makes these EVA-owned and unreachable by this package. Declared `[U]` here BY DESIGN, not by omission** |
| `coverage_ratio_floor` | **#36's denial-of-evaluation detector needs a floor. The floor is a function of the β budget, which is `[U]` above** |

**R70.1 (THE `[U]` DISCIPLINE).** *Twelve parameters are declared unresolved. **This is a stronger specification than twelve invented numbers**, because: (a) each names WHAT would resolve it; (b) each names WHO owns the resolution; (c) none can be mistaken for a derived value. **§96's false-precision audit records all twelve, and §95's PARAMETER status is PARTIAL because of them — not because the registry is incomplete, but because completing it requires measurements that do not exist yet.***

---

*End of Volume E. Volume F (`22_analysis_formal_invariants.md`) covers §71–§76: minimality, communication variants, the canonical semantic contract, formal invariants COMM-INV-nn, formal state machines, and the independence model.*
