# P0-03 — COMMUNICATION, DIGITAL SYNAPSE & SIGNAL CONTRACT
## Volume G: Subsystem Interfaces, Scalability, Ablation, Conformance, Gaps & Open Research (§77–§91)

**Companions:** `17` (A) · `18` (B) · `19` (C) · `20` (D) · `21` (E) · `22` (F) · `24_v4_communication_synapse_signal_spec.md` (**Output 42**) · `README.md` (**Outputs 1, 2** + §92–§96)
**Outputs delivered here:** **21** (EIK ↔ comm) · **22** (Evaluator ↔ comm) · **23** (Memory ↔ comm) · **24** (Learning ↔ comm) · **28** (Workspace ↔ comm) · **30** (scalability) · **36** (ablation) · **38** (implementation independence) · **39** (conformance) · **40** (gap register) · **41** (open research)
**Cross-referenced:** Outputs **25, 26, 27** (Evolution / Immune / Homeostasis) are delivered in Volume D §48, §55, §54.

---

# §77. SUBSYSTEM INTERFACES — THE SHAPE OF ALL SEVEN

## 77.0 The interface discipline

Every interface below is specified in the same five parts, because an interface specified in fewer parts is where authority leaks:

| Part | Question |
|---|---|
| **DOWN** | What does the subsystem send INTO the communication layer, and with what authority? |
| **UP** | What does the communication layer send OUT to the subsystem, at what volume? |
| **WRITES** | What may the subsystem WRITE that the communication layer relies on? |
| **❌ FORBIDDEN** | What crossing does not exist, and why not? |
| **FAILURE** | What happens when the subsystem or the link is unavailable? |

**R77.0 (THE COMMON RULE ACROSS ALL SEVEN).** *Every interface is bounded in VOLUME on the upward direction and bounded in AUTHORITY on the downward direction.* **The upward bound is always `O(R)` per epoch plus targeted or sampled traffic — never `O(N)` and never `O(events)`. The downward bound is always a policy artifact, an assignment, or a ceiling — never a per-message instruction.** ⟵ *This is P0-02 §27.2's finding generalized: an interface whose upward direction is `O(events)` puts the counterparty in the per-event path, and a counterparty in the per-event path is either a bottleneck or a bypass.*

---

## §77.1 **OUTPUT 21 — EIK ↔ Communication**

### DOWN — EIK into the communication layer

| Artifact | Authority | Volume | **Consumer** |
|---|---|---|---|
| **Type Registry** (14 types, 5 classes, `OPAQUE`) | RO-13, KC-1-authenticated | `O(1)`, cached | Every subject, at S1b dispatch |
| **Class → mechanism mapping** (R2.2) | RO-13 | `O(1)`, cached | Every subject |
| **Envelope bounds** (`payload_max_bytes`, field sets) | RO-15 | `O(1)` | Egress and S1a |
| **Rate-limit ceilings** | **KC-3** | `O(1)`, **partition-surviving (EIK-INV-31)** | §34.2's principal 5 |
| **Broadcast-scope permissions** | RO-13 | `O(1)` | §59.3, COMM-INV-41 |
| **Reserved deontic vocabulary** | RO-13 | `O(1)` | COMM-INV-27 |
| **`mandatory_path` designations** | RO-13 / `[G]` | `O(paths)` | COMM-INV-33 |
| **Epoch issuance** | Governance | `O(R)` hierarchical | COMM-INV-13 |
| **Above-envelope connection authorization** | **KC-2, RO-05/06** | `O(requests)` | §75.2 state 1a |
| **Restore authorization** | **KC-2, RO-08 — never cached, never delegated, never available during a KC outage** | `O(requests)` | COMM-INV-44 |
| **Freeze** | **KC-4, dual authorization, rate-bounded** | `O(1)` to issue, `O(R)` to propagate | §65, #41 |
| **Policy version reference** | KC-1 | `O(1)` cached, **PULL on invalidation** | §65 |

### UP — communication layer into EIK

| Report | Volume | **Content** |
|---|---|---|
| **Epoch connection-registry digest** | **`O(R)` per epoch** | Merkle root of the regional registry — **registration, NOT authorization (COMM-INV-30)** |
| **Reserved-operation requests** | `O(requests)` | RO-05/06/08/13 |
| **Policy friction reports** | `O(reports)` | P0-02 §15.3 V1 — the vocabulary grows by report, never by unilateral redefinition |
| **Ceiling-violation events** | `O(violations)` | KC-3 enforcement triggers |
| **⚠️ NOT per-message traffic** | — | **P0-02 §27.2: `O(events)` in the TCB is the bottleneck that kills the kernel** |
| **⚠️ NOT per-synaptic-operation inspection** | — | **The brief's explicit prohibition: «DO NOT make EIK inspect every synaptic operation». §20.3's registration/authorization split is the mechanism that satisfies it: the KC sees `O(R)` digests and `O(above-envelope requests)`, and never sees the billions of within-envelope operations** |

### WRITES

**EIK writes: policy, ceilings, authorizations, epoch, freeze.** **EIK never writes: a synapse parameter, a route selection, a gain, a message field, or a warrant value.** ⟵ *COMM-INV-03: warrant is a receiver computation; COMM-INV-23: one writer per group, and the warrant group's writer is EVA, not KC.*

### ❌ FORBIDDEN CROSSINGS

1. **EIK verifying individual messages.** ⟹ P0-02 R19.2's layered signing exists precisely so this is unnecessary: channel binding for S0–S2, per-message signature only for S3/S4.
2. **The communication layer performing a governance act.** COMM-INV-38: «the layer TRANSPORTS governance acts; it does not perform them.»
3. **A synaptic operation reaching the KC.** §20.3; the brief's prohibition.
4. **EIK assigning `trust_out_assigned`.** That is EVA's (COMM-INV-23, group 3). **KC authenticates the delegation under which EVA acts; it does not perform the assignment.**

### FAILURE

**KC unavailable ⟹ RO-01 stalls ⟹ no new subjects, no above-envelope connections, no restores.** **Within-envelope operation CONTINUES, because registration is local and ceilings are cached and partition-surviving.** ⟹ **The system degrades toward its bounds rather than beyond them (P0-02 §30). This is CD-C3's break, and it is why the failure mode is a stall rather than a breach.**

---

## §78. **OUTPUT 22 — Evaluator ↔ Communication**

### DOWN — EVA into the communication layer

| Artifact | Volume | **Note** |
|---|---|---|
| **`calib_ref` records** (calibration assignments) | `O(subjects)` per evaluation cycle | **COMM-INV-03: the receiver cites a `calib_ref`; EVA produces the record it points to. ⟹ EVA is the calibration PRODUCER, which P0-02 Rule 11 requires («every confidence mechanism has a producer + calibration»)** |
| **`trust_out_assigned` values** | `O(connections)` per cycle, **batched** | The warrant group's sole writer (COMM-INV-23). **Read-only to the cell (X-E)** |
| **Correlation-dimension assignments** (dims 3, 5) | `O(subjects)` | Dims 1/2/4 are computed from anchored records; **3 and 5 are approximate and require EVA's model and platform knowledge** |
| **β-stratum sample selection** | `O(B)` | **P0-01 R34.1: EVA-owned and UNREACHABLE by the organism ⟹ #36 is structural: the attacker cannot choose what EVA samples** |
| **DISPUTED adjudication outcomes** | `O(disputes)` | §75.1 state 9's consumer |
| **Fitness-relevant communication COST measurements** | `O(R)` | **Cost only — see §81's FORBIDDEN list** |

### UP — communication layer into EVA

| Report | Volume | **Purpose** |
|---|---|---|
| **Sampled warrant metadata** | **`O(B)`** | Per P0-01's β₁…β₅ strata |
| **Aggregate statistics digest** | **`O(R)` per epoch** | §54.1's twelve observables |
| **Anchored provenance registry** | `O(R)` roots per epoch | `root_commit` resolution (COMM-INV-06) |
| **`mandatory_path` full traffic** | `O(paths)` | §62.2: few, policy-designated, and the paths where a communication failure is a safety failure |
| **S3/S4 full traffic** | `O(governance + evaluation events)` | Small by construction |
| **Absence-detector firings** | `O(firings)` | **R67.4's four detectors — the highest-value observables in the contract (§62.2)** |
| **`n_effective` per aggregate** | `O(R)` | COMM-INV-17 |
| **Fork events and lineage** | `O(forks)` | §31.3; §61.1: «descent is the object of study» |

### WRITES

**EVA writes: calibration records, trust assignments, correlation-dimension assignments for dims 3 and 5, sampling policy.** **EVA never writes: a type, a class, a schema, a warrant rule, a ceiling, or an envelope bound.** ⟹ *EVA is an ALETHIC authority (P0-02 §R0.1's axis separation: graded, evidential) and never a DEONTIC one (total, decisional). It assigns how much a claim is worth; it never assigns what may be done.*

### ❌ FORBIDDEN CROSSINGS

1. **EVA reading all traffic.** §62.1: `O(messages × payload)` is infeasible and unnecessary. **The budget is spent on warrant metadata and absences (§62.2 R62.1).**
2. **EVA reading unsampled payloads.** §59.2: payload is compartmentalized. **EVA reads payloads only within the β sample.**
3. **The organism influencing the sample.** P0-01 R34.1 ⟹ **#36 structural.**
4. **⚠️ EVA being treated as a traffic destination for rate-limiting purposes.** §34.2: «evaluator flooding is a governance incident, not traffic.» **A per-subject token bucket cannot bound load on a GP service; AC-1 adjudication must.**

### FAILURE

**EVA unavailable ⟹ no new `calib_ref` records ⟹ new messages cite stale calibration ⟹ warrant recomputation degrades toward the pessimistic default (R37.1) ⟹ `n_effective` falls.** **⟹ An EVA outage reduces BELIEF, never increases it.** ⟵ *This is the correct failure direction, and it is a consequence of COMM-INV-03 rather than a designed safeguard: because warrant is recomputed by the receiver from inputs EVA supplies, removing the inputs removes the warrant.*

**⚠️ THE INTERFACE'S OWN CIRCULARITY (CD-C8, UNCLOSABLE).** *EVA owns the sampling policy that determines what EVA can see.* **Mitigations, all partial: β₄'s random-audit stratum (the one policy that cannot be gamed by knowing the policy) · §62.2's coverage-ratio observable · P0-02 EIK-INV-53's full observability toward OP (a different principal sees the policy itself).** **§91 OR-C1 records this as the package's principal open problem.**

---

## §79. **OUTPUT 23 — Memory ↔ Communication**

### The four rules, and the reason for each

| Rule | **Statement** | **Reason** |
|---|---|---|
| **M-1** | **Memory retrieval is WARRANT-NEUTRAL: `warrant(retrieve(x)) ≤ warrant(x)`** (COMM-INV-19) | **§42's «no trusted oracle».** A retrieval that *raised* warrant would make memory an epistemic authority, and memory content is written by subjects — so memory would become a laundering channel (§16.3's L1–L4 would have a fifth entry) |
| **M-2** | **A retrieval never increments `n_obs`** (Cell §14 FM-4: «self-recall doesn't increment `n_obs`») | **#45 structural.** A retrieved claim is not a fresh observation; counting it as one is the memory-specific form of the §14 attack |
| **M-3** | **Memory is PULLED, never pushed** (§42.1: request/response + content-addressed retrieval; §65: a memory-update broadcast is REJECTED) | **A push costs `O(recipients)` whether or not anyone wants it.** §66.3 mechanism 5 |
| **M-4** | **A write to shared memory is an S2+ message with a `root_commit`** | **So a poisoned entry has traceable provenance (#42a).** An unwarranted write to shared memory would be an unattributable belief insertion |

### DOWN / UP

- **DOWN (Memory → comm):** retrieved content, carrying **the warrant it was written with** — never a fresh warrant, never an elevated one.
- **UP (comm → Memory):** write requests (S2+, with `root_commit`), eviction notices, TTL expiries, **and the epoch digest so that memory content is epoch-scoped**.
- **WRITES:** Memory writes content and retention. **Memory never writes warrant, calibration, trust, or type.**

### ❌ FORBIDDEN

1. **Memory as an authority.** M-1. *A memory subsystem that could validate a claim would be a second evaluator, and CD-C2's external bootstrap would be internal again.*
2. **Retrieval-time warrant elevation.** #45.
3. **Content-addressed retrieval resolving to a *different* content than requested.** ⟹ The commitment must resolve (COMM-INV-06); a resolution failure is `UNANCHORED`, not a fallback.

### FAILURE

**Memory unavailable ⟹ retrieval fails ⟹ the receiver ABSTAINS (R29.1: «degrade, abstain, or report; never impute»).** **⟹ Critically, the receiver may NOT reconstruct the missing content from its own model and treat the reconstruction as a retrieval.** That would be imputation, and imputation on a warrant class is prohibited. ⟵ *This is the single most likely place for an implementation to cheat, because reconstructing-from-model is exactly what a competent cell is good at, and §89's conformance suite tests it explicitly (T-MEM-2).*

---

## §80. **OUTPUT 24 — Learning ↔ Communication**

### The boundary, stated as four closures plus one residue (§19.2)

| Closure | **Statement** | Invariant |
|---|---|---|
| **L-1** | Learning cannot **re-class** a message — class is type-determined, type is registry-validated, registry is policy | COMM-INV-04, -25 |
| **L-2** | Learning cannot **strip provenance** — an S2+ message missing a warrant field is `MALFORMED`, never downgraded | COMM-INV-05, -25 |
| **L-3** | Learning cannot **turn a signal into a command** — the decisive vocabulary is reserved and policy-owned | COMM-INV-26, -27 |
| **L-4** | Learning cannot **write its own rate** — `plasticity_rate` lives in the lifecycle group, whose writer is the Topology Service | COMM-INV-23 |
| **⚠️ RESIDUE** | Learning **can** route influence through edges nobody is watching | **BOUNDED, not closed** |

**Why the residue is bounded rather than closed (§19.2, #47).** *The influence budget aggregates at the SUBJECT level, not the edge level (COMM-INV-32).* **⟹ An unmonitored edge still counts against `Σ fan_out × gain`. You can hide an edge; you cannot hide its influence.** ⟵ *This is the honest form of the answer: the architecture accepts that some influence flows where nobody is looking, and bounds the total instead of enumerating the edges — because enumerating edges is `O(edges)` monitoring, which §64 forbids.*

### DOWN / UP

- **DOWN (Learning → comm):** **gain** (group 1, within `W_MAX`) · **routing selection among admissible routes** (COMM-INV-34) · **emission-rate and aggregation-window priors at developmental time** (§48.2) · **payload compression strategy** (§63.3, lossy on payload only).
- **UP (comm → Learning):** delivered messages · **local eligibility traces** · measured reliability and latency (group 2, **observed not written**) · `conv_id`, `seq`, `causal_depth`, `root_commit` — **the only four fields communication carries for local credit (§46.3)**.
- **WRITES:** gain, and topology priors at developmental time. **Nothing else.**

### ❌ FORBIDDEN

1. **Transmitted credit.** COMM-INV-20: `credit`, `contribution`, `reward_share`, `utility` do not exist as fields. **§46.3: credit is COMPUTED, never TRANSMITTED** ⟹ #48 structural.
2. **Stored utility expectation.** COMM-INV-28: `expected_utility` is forbidden, because a stored expectation is a transmitted credit claim in disguise.
3. **Global broadcast of learning signals.** §45.1 R45.1: **no learning signal requires global broadcast.** Reward is targeted and epoch-scoped (Cell §6.2: `eval.reward.v1`, priority 1).
4. **A cell signing a REWARD.** Cell §6.2: **structurally invalid** — reward originates from evaluation, and a cell-signature on a reward message is a framing violation (#32).
5. **Learning writing to the protocol group.** COMM-INV-23, group 4: **writer = nobody.**

### FAILURE

**Learning unavailable ⟹ gain stops adapting ⟹ the network operates at its last-learned gains within `W_MAX`.** **⟹ A learning failure is a COMPETENCE failure, not a SAFETY failure, and this is the correct allocation: the safety properties (COMM-INV-24's ceiling, -31's loop gain, -32's budget, -33's mandatory path) do not depend on learning being functional.** ⟵ *P0-02 Rule 12's requirement — every adaptive mechanism has a stability mechanism — is satisfied by making the stability mechanism non-adaptive.*

---

## §81. FITNESS ↔ COMMUNICATION, AND **OUTPUT 28 — WORKSPACE ↔ COMMUNICATION**

### 81.1 Fitness ↔ communication

**The crossing is one-directional and narrow, and its narrowness is the point.**

| Direction | **What crosses** | **Forbidden** |
|---|---|---|
| **comm → fitness** | **COST measurements only**: bandwidth consumed, messages emitted, latency incurred, shed volume, `O(R)` aggregates | ❌ **BENEFIT.** Throughput, delivery rate, message count, agreement rate, and §54.1's twelve observables are **homeostatic RANGES and operational quantities — never fitness terms** (COMM-INV-39) |
| **fitness → comm** | **Nothing directly.** Fitness influences communication only through `[V]` evolutionary priors over generations (§48.2), never through a runtime instruction | ❌ **A fitness gradient applied to a communication parameter at runtime.** That would make communication volume a selectable trait, and #38 shows what follows |

**R81.1 (WHY THE ASYMMETRY).** *Communication cost is a real resource consumption and belongs in fitness as a cost. **Communication performance is not an outcome in ℛ, and treating it as one is Goodhart's law with a bandwidth budget.*** ⟵ *The brief's prohibition «DO NOT let comm-derived performance redefine fitness» is satisfied structurally: there is no path from a communication statistic to the fitness vector, because the fitness vector's inputs are P0-01's declared outcome measures.*

**⚠️ The one place this is subtle.** *§66.3 R66.2 observes that «a population moving traffic DOWN the class ladder is buying bandwidth, and a population moving it UP is buying warrant.»* **This is a diagnostic reading of an observable, not an objective term.** Making it an objective would immediately produce a population that moves everything to S0 — which is C1, which cannot warrant, which is not a Digital Brain. **⟹ R81.2: class distribution is an INDICATOR and must never be an OBJECTIVE.**

### 81.2 **OUTPUT 28 — Workspace ↔ communication**

| Part | Specification |
|---|---|
| **DOWN** | Admitted items, each with: a **registered type** (`OPAQUE` inadmissible, COMM-INV-22) · a `root_commit` · a **mandatory TTL** (§43.3) · a policy-assigned relevance classification |
| **UP** | **`O(R)` hierarchical NOTIFICATIONS + `O(pulls)` content transfers.** §43.2's three-tier model. **NEVER `O(N × items)`** |
| **ADMISSION** | **A POLICY criterion — task relevance — which is NOT locally computable (§63.4).** ⟹ **#43 structural: a subject cannot optimize against a criterion it cannot evaluate** |
| **CAPACITY** | **HARD LIMIT.** §63.4: this is a **rate-distortion constraint with a task-relevance distortion measure**, and it is information-theoretically optimal because the consumers ({Memory, Critics, Planners, Regulators} — V3.1 §2) have bounded processing capacity |
| **CONSUMERS** | **KC IS EXCLUDED** (P0-02 R42.1) and receives an `O(R)` epoch digest instead. **⟹ the TCB is not a workspace consumer, so workspace volume can never become a KC bottleneck** |
| **BYPASS** | **S3/S4 bypass the workspace entirely** (COMM-INV-40). A governance or safety signal is delivered regardless of workspace state, capacity, or attention |
| **ATTENTION** | **Modulates admission and gain ONLY — INFLUENCE PLANE.** Never warrant, never authorization, never class, never type (§44, COMM-INV-40). **Important ≠ true ≠ permitted** |
| **❌ FORBIDDEN** | (1) A global workspace broadcast — X-L, §65, COMM-INV-41. (2) An untimed workspace item — TTL is mandatory. (3) Attention-driven warrant — COMM-INV-40. (4) `OPAQUE` entry — COMM-INV-22. (5) KC consumption — R42.1 |
| **FAILURE** | **Workspace unavailable ⟹ notification fails ⟹ consumers do not pull ⟹ the system operates on local and regional state.** **⟹ S3/S4 are unaffected (bypass). ⟹ A workspace outage is an attention failure, not a governance failure — which is exactly what COMM-INV-40 buys** |

**R81.3 (THE WORKSPACE'S REAL ROLE).** *The workspace is a DELIBERATE BOTTLENECK, and a bottleneck is optimal when the downstream consumer's capacity is the binding constraint.* **V3.1 §2's «cells that need it» was right and under-applied (X-L): the workspace is not a broadcast medium with a filter; it is a pull-based store with a policy gate, and the notification is cheap because it carries no content.**

---

# §82. SCALABILITY 10 → 10¹² — **OUTPUT 30**

## 82.1 The five orders of magnitude, and what breaks at each

| Scale | Subjects | **What is true here** | **What breaks going up** |
|---|---|---|---|
| **10** | 10 | Everything is a neighbor. No relay. No region. Dedup is trivial. `n_effective` is computable by inspection | **Addressing has no purpose; a flat table works. ⟹ this scale cannot validate §23's hierarchical addressing at all** |
| **10²** | 100 | Circuits form. Local broadcast is meaningful. A single relay suffices | **`O(N²)` pairwise connectivity becomes 10⁴ edges — still feasible, which is why the failure is not visible here** |
| **10³** | 1,000 | Regions form. Cross-region traffic needs a rate limit. Epoch digests become worthwhile | **A vector clock would be 1 KB per message here — inside a 4 KiB envelope. ⟹ X-D's error is STILL INVISIBLE at 10³, which is why the inherited design did not catch it** |
| **10⁶** | 1,000,000 | Hierarchical addressing is load-bearing. `O(R)` digests replace `O(N)` reporting. Provenance commitments replace root arrays | **`evidence_roots[]` exceeds the envelope for deep chains (X-C). A vector clock is 1 MB per message (X-D) — **the inherited design is arithmetically impossible here**** |
| **10⁹** | 10⁹ | Small-world topology with bounded degree is mandatory (§25.1: a lattice has `O(N^{1/d})` diameter, infeasible). Registration/authorization split is mandatory (COMM-INV-30). Channel binding replaces per-message signatures (R19.2) | **Per-message signing costs ~10⁵ ops × 10⁹ subjects × rate ⟹ §66.1's communication-bound regime. Per-connection KC registration ⟹ P0-02's SPOF-3. Global broadcast ⟹ `O(N)` per event** |
| **10¹²** | 10¹² | **Everything above, plus: partition is the NORMAL mode (§56.1's P7), not the exception. Echo-chamber defence is mandatory because modularity is deep. The independence model's dim 6 limit dominates, because at this scale shared assumptions are unavoidable** | **Nothing further breaks IN THIS CONTRACT — but §82.3 names what this contract cannot do at 10¹²** |

## 82.2 The scaling table

| Quantity | **At 10** | **At 10¹²** | Mechanism |
|---|---|---|---|
| Per-subject connection state | `O(degree)` | **`O(degree)`** — unchanged | Genome caps `max_connections`, `max_fanout` (`u16` in the inherited design) |
| Per-subject routing state | `O(1)` flat table | **`O(1)` local + one relay pointer** | §23.1 hierarchical addressing; **no global routing tables (R23.2)** |
| Per-message envelope | 5 fields (S0) | **5 fields (S0) / 11 fields (S2)** — unchanged | §4.3; `root_commit` and `causal_depth` are `O(1)` where the inherited design was `O(N)` and `O(|roots|)` |
| Per-message crypto cost | 0 (S0) | **0 for S0/S1** (channel binding); signature only for S3/S4 | R19.2 |
| Kernel acts per epoch | `O(connections)` in the inherited design | **`O(R)` digests + `O(above-envelope requests)`** | COMM-INV-30 |
| Workspace cost per item | `O(N)` broadcast | **`O(R)` notification + `O(pulls)`** | §43.2, §81.2 |
| Provenance query | `O(|roots|)` array scan | **`O(log)` Merkle proof, off-line** | X-C's resolution |
| Independence check | by inspection | **`O(inputs²)` locally, bounded by degree; `O(R)` aggregate; exact `O(roots)` off-line at EVA** | §14.4, §64.1 |
| Partition reconciliation | trivial | **`O(divergence)`, NOT `O(N)`** | §31.5, CD-C11 |
| Global synchronization | a barrier | **NONE EXISTS** | COMM-INV-13 |
| Organism-wide dissemination | everything | **SAFETY only, hierarchical, `O(R)` propagation** | COMM-INV-41, R65.1 |

**R82.1 (THE SCALABILITY VERDICT).** *No quantity in this contract grows faster than `O(R)` per epoch at the organism level or `O(degree)` at the subject level. **The three quantities that DID grow as `O(N)` in the inherited design — the vector clock, the root array, and per-connection kernel registration — are respectively removed, replaced by a commitment, and replaced by a digest.*** ⟹ **«Do not solve scalability by hand-waving» is discharged by §64.1's per-operation table and §82.2's per-scale table, neither of which contains an unexplained `O(N)`.**

## 82.3 ⚠️ What this contract CANNOT do at 10¹² — declared, not hidden

| Limit | **Why** | **Consequence** |
|---|---|---|
| **Exact global independence** | Dim 6 is undetectable from inside (COMM-INV-18), and at 10¹² subjects shared latent assumptions are unavoidable | **`n_effective` is a LOWER BOUND on correlation and an UPPER BOUND on independence. Consensus at 10¹² is weaker evidence than consensus at 10², and the contract says so rather than reporting a number that implies otherwise** |
| **Exact global causal reconstruction at runtime** | X-D removed the vector clock; `causal_depth: u8` bounds depth at 255 | **Runtime concurrency detection is unavailable (OR-C6). Causal reconstruction is off-line from Tier-2 logs (§10.2, §61)** |
| **Full traffic audit** | §61.2's raw full-payload log is PROHIBITED; §86's budget is spent on metadata and absences | **Retrospective payload inspection is limited to the β sample. An auditor can always reconstruct WHO/WHOM/HOW MUCH/WHEN, and cannot always reconstruct WHAT (§50.2)** |
| **Uniform warrant quality across the population** | Warrant is receiver-computed (COMM-INV-03) and receivers differ in calibration and context | **Two receivers may hold different warrant for the same message, and BOTH MAY BE CORRECT.** This is not a defect; it is what «warrant is a receiver computation» means. **⟹ the contract guarantees warrant CONSISTENCY per receiver, never warrant UNIFORMITY across receivers** |
| **Bounded worst-case latency for S0/S1** | Best-effort by design (§7.2) | **Only S3/S4 have retry-until-confirmed. A system requiring bounded latency on data-class traffic has mis-classified it** |
| **Traffic-analysis resistance** | COMM-INV-47 makes warrant metadata PUBLIC, deliberately | **§51's residue. The contract chooses auditability over traffic-analysis resistance, and §59.2 R59.1 states the trade** |

---

# §83. HARDWARE/SOFTWARE SEPARATION & CONGESTION RESPONSE

## 83.1 The separation, restated as an authority fact

**§56.2 R56.1 listed the fifteen semantic invariants; §57.2 R57.1 made their invariance a conformance test (T-REPR).** The separation itself:

```
SOFTWARE (the SEMANTIC CONTRACT) — §56.2's fifteen invariants
  ⟹ lives in POLICY artifacts, KC-1-authenticated
  ⟹ NOT writable by a hardware adaptation layer (P0-02 EIK-INV-02, -24)
  ⟹ **invariance is enforced by AUTHORITY, not by discipline (R56.2)**

HARDWARE (the TRANSPORT IMPLEMENTATION)
  ⟹ framing bytes, serialization, channel-binding mechanism, region size,
    relay count, hop cost, latency, bandwidth, drift bounds, S0's form
    (message vs tensor slice), batch size, epoch length within bounds,
    payload compression, dedup implementation
  ⟹ all `[H]`, all replaceable, none meaning-bearing

THE TEST THAT MAKES IT REAL
  ⟹ **T-REPR (§90): the same scenario on two hardware classes must produce
     the SAME WARRANT OUTCOMES. Transport statistics may differ arbitrarily.**
  ⟹ **R57.1: hardware invariance is a conformance test with a pass/fail
     criterion, not a design intention.**
```

**R83.1 (THE INADMISSIBLE-PLATFORM RULE).** *A hardware class that cannot implement a semantic invariant is not a portability problem; it is an inadmissible platform.* **§57.2's G-P03-5 is the instance: a platform that cannot enforce a per-subject influence budget below the organism's reach cannot host S2+ traffic, because §35's cascade defence has no enforcement point.** Such a platform is restricted to C1/C2 (§72.3) **and must be declared as such**.

## 83.2 Congestion response (§54.1's cross-reference)

**Congestion is a TRANSPORT-plane condition, and the response must not become a WARRANT-plane decision. This is where a naive backpressure design fails.**

| Stage | **Response** | Plane | **Forbidden** |
|---|---|---|---|
| **1. Detect** | Queue depth, shed rate, per-class latency percentiles (§54.1's observables) | T | — |
| **2. Shed** | **By CLASS, from the bottom: S0 first, then S1.** **S2+ is shed only as a last resort and only with an explicit `SHED` record (§75.1 state 1a)** | T | ❌ **Shedding by CONTENT. §38.2: rejection is on structure, never on content — and shedding is a form of rejection** |
| **3. Throttle** | Tighten the token bucket (§34.2 principal 1) and the homeostatic allocation (principal 4) | T + I | ❌ **Throttling `mandatory_path` traffic (COMM-INV-33) or S3/S4 (COMM-INV-40's bypass)** |
| **4. Reroute** | Select a different route **within the admissible set** (§24.2, COMM-INV-34) | T | ❌ **Widening the admissible set under congestion.** That would make load a topology authority |
| **5. Degrade warrant** | **If an S2 message's warrant inputs cannot be resolved under load, the receiver ABSTAINS (R29.1)** | W | ❌ **IMPUTING the missing input. §15 R29.1: «infer missing information» is PROHIBITED for warrant classes — degrade, abstain, or report; never impute** |
| **6. Escalate** | If congestion persists past a `[G]` duration ⟹ **a governance incident, not a traffic condition** | G | ❌ **Resolving persistent congestion by raising a ceiling. Ceilings are RO-15 / KC-3, and a congestion-driven ceiling raise is #22's residual (an adaptive mechanism setting its own bound)** |

**R83.2 (THE CONGESTION RULE).** *Congestion may reduce VOLUME and may reduce WARRANT — but it may only reduce warrant by ABSTAINING, never by IMPROVISING.* **The distinction is §15 R29.1, and it is what separates a system that degrades honestly from one that degrades into over-belief.** ⟵ *A congested system that imputes missing warrant inputs is a system that becomes MORE confident under load, which is the exact inverse of the correct failure direction (§78's EVA-outage analysis: an outage must reduce belief, never increase it).*

**R83.3 (WHAT CONGESTION MAY NEVER DO).** *Congestion may never: reorder (§8.1) · downgrade a class (COMM-INV-05) · strip a warrant field (COMM-INV-25) · suspend `mandatory_path` (COMM-INV-33) · bypass attention for non-S3/S4 traffic (COMM-INV-40 — the bypass is class-determined, not load-determined) · or evict S3/S4 dedup entries (COMM-INV-14).* **Each of these would be a plausible engineering shortcut under load, and each is a named attack in §67 when performed deliberately. ⟹ A congestion response that performs one of them is an attack that performs itself.**

---

# §84. OBSERVABILITY VS. PERFORMANCE

## 84.1 The tension, quantified structurally

```
OBSERVABILITY COSTS:
  Tier 1 (per-message O(1) fields)      ⟹ envelope bytes, always paid
  Tier 2 (local event log)              ⟹ local storage + O(1) per event,
                                          **ZERO NETWORK (§15.3)**
  Tier 3 (anchored epoch digests)       ⟹ O(R) per epoch network + anchor cost
  β-sampled payloads                    ⟹ O(B) storage + transfer
  Absence-detector computation          ⟹ O(R) per epoch aggregates

PERFORMANCE COSTS OF OBSERVABILITY:
  • Tier 2 write latency on the critical path  ⟹ **the only unavoidable one**
  • Tier 3 anchor computation                  ⟹ O(R), amortized over an epoch
  • Detector computation                       ⟹ O(R), off the critical path

⟹ **R84.1: the observability cost that lands on the message critical path is
   ONE LOCAL LOG WRITE. Everything else is amortized (`O(R)` per epoch) or
   off-line (β sampling, causal reconstruction).**
```

## 84.2 The resolution — and it is the same resolution as §66.3's

> ### **R84.2.** *Spend observability on WARRANT METADATA and ABSENCES, never on payloads and never on per-event network reporting.*

| Choice | **Cost** | **Value** | Verdict |
|---|---|---|---|
| Log every payload centrally | `O(messages × payload)` network | High for forensics | ❌ **PROHIBITED (§61.2)** — exceeds every other cost in the system combined |
| Log metadata locally | `O(messages)` local, **zero network** | Sufficient for WHO/WHOM/HOW MUCH/WHEN (§50.2) | ✅ **Tier 2** |
| Anchor epoch digests | `O(R)` per epoch | Provenance resolution (COMM-INV-06), partition reconciliation (§31.5), reproducibility (§61.1) | ✅ **Tier 3** |
| Sample payloads per β strata | `O(B)` | **The only form in which payloads are retained (§61.2)** | ✅ |
| Compute absence detectors | `O(R)` per epoch | **The only defence against silence-conditioned attacks (§67.1 Pattern 2)** | ✅ **Highest value per unit cost in the contract** |
| Per-message ACKs for telemetry | `O(messages)` network | Low — reliability is EWMA-measured from aggregate loss | ❌ **§7.4: ACKs exist only for S3/S4, where they are a delivery mechanism, not telemetry** |
| Full causal tracing at runtime | `O(path)` per message | High for science | ❌ **§10.2's division rule: causal inference belongs to the evaluator, off-line** |

**R84.3 (THE ASYMMETRY THAT SETTLES IT).** *Performance is degraded by observability on the CRITICAL PATH; observability is degraded by performance constraints only on the ARCHIVE.* **⟹ The contract puts one local write on the critical path and everything else in the archive — which means the performance/observability trade is resolved in favour of observability at essentially no performance cost, and the thing that is sacrificed is retrospective payload completeness (§82.3's declared limit).**

---

# §85. THE OPERATING ENVELOPE (CONSOLIDATED)

**§64 gave per-operation complexity; §66 gave the economy; §84 gave the observability cost. This section states the consolidated envelope, because a contract that specifies mechanisms without stating their joint budget has not finished specifying.**

| Resource | **Bound** | Enforced by | Tag |
|---|---|---|---|
| **Per-message bytes** | `payload_max_bytes` + 11 fields (S2) / 5 fields (S0) | Egress + S1a | `[G]` / `[D]` |
| **Per-message crypto** | **0** for S0–S2; **1 signature** for S3/S4 | R19.2's channel binding | `[D]` |
| **Per-subject state** | `O(degree)` connections + `O(degree)` seq counters + bounded dedup window | COMM-INV-11, -14, R8.2 | `[V]`/`[G]` |
| **Per-subject emission** | Token bucket | §34.2 principal 1 | `[G]`/`[L]` |
| **Per-subject influence** | `Σ fan_out × gain ≤ influence_budget` | COMM-INV-32 | `[G]` |
| **Per-circuit / per-region volume** | Shedding + admission | §34.2 principals 2–3 | `[G]` |
| **Organism ceiling** | KC-3, **partition-surviving** | EIK-INV-31 | `[G]` |
| **Per-epoch network reporting** | `O(R)` digests + `O(R)` summaries + `O(B)` samples | §15.3, §61, §62 | `[D]`/`[G]` |
| **Per-epoch anchor cost** | `O(R)` Merkle roots | Tier 3 | `[H]`/`[G]` |
| **Local log** | `O(messages)` bounded window, **zero network** | Tier 2 | `[D]` |
| **Workspace** | Hard capacity + mandatory TTL + `O(R)` notification | §43.3, COMM-INV-41 | `[G]` |
| **Loop gain** | **< 1, at creation** | COMM-INV-31 | `[D]` |
| **Causal depth** | **≤ 255** (`u8`) | COMM-INV-08, X-D | `[D]` |
| **Propagation** | `ttl_hops` | §35.2 | `[G]` |
| **Reconciliation** | `O(divergence)`, rate-limited | §31.5, #27's residual | `[G]` |

**R85.1.** *Every bound in this table is either `[D]` (fixed by this contract), `[G]` (governance-set, value not asserted here), or `[H]` (platform-measured). **No bound is `[L]` — no learned mechanism may raise its own bound.** ⟹ This is P0-02 Rule 12's stability requirement expressed as a resource rule, and it is why COMM-INV-24 (`gain ≤ W_MAX`) and COMM-INV-45 (evolution varies priors, never policy) are the same principle at two scales.*

---

# §86. THE OBSERVABILITY BUDGET, COSTED

**§62.2 allocated the budget by purpose; this section states its cost, because §61.2 and §84 both depend on the allocation being affordable.**

| Consumer | **What it receives** | Cost per epoch | **Cumulative at 10¹² subjects** |
|---|---|---|---|
| **OP** | Full observability toward OP (P0-02 EIK-INV-53): the sampling policy, the absence-detector firings, the aggregate digests, the friction reports | `O(R)` | `O(R)` — **independent of N** |
| **EVA** | β-stratum samples + aggregate statistics + `mandatory_path` full traffic + S3/S4 full traffic + anchored registry | `O(B + R + paths)` | **`O(B + R)`** — independent of N |
| **Immune** | Absence-detector firings + refusal-rate anomalies + opaque-volume clustering + degree/betweenness concentration | `O(R)` | `O(R)` |
| **Homeostasis** | §54.1's twelve observables | `O(R)` | `O(R)` |
| **KC** | **`O(R)` epoch digests ONLY** (R42.1: excluded from the workspace; §20.3: registration ≠ authorization) | `O(R)` | **`O(R)` — and this is the whole point: the TCB's cost is independent of N** |
| **Audit (external)** | Anchored records, permanent; Tier-2 within window; β-sampled payloads | `O(R)` anchored | `O(R)` |
| **Local (self)** | Tier-2 metadata, bounded window | `O(messages)` local | `O(messages)` local, **zero network** |

**R86.1 (THE BUDGET VERDICT).** *Total networked observability cost is `O(R + B + paths)` per epoch — **independent of subject count N**.* **At 10¹² subjects with 10⁶ regions, the observability network cost is six orders of magnitude below the traffic cost, and the TCB's share of it is `O(R)` digests.** ⟹ **«DO NOT make every comm event globally visible» (the brief's prohibition) is satisfied not by restricting visibility but by making visibility AGGREGATE: every consumer sees everything it needs at `O(R)`, and nothing it needs requires `O(N)`.**

**⚠️ The one unbounded term.** *`O(messages)` local Tier-2 logging is unbounded in `messages`, and `messages` scales with `N`.* **It is local and zero-network, so it does not create a scaling bottleneck — but it does create a per-subject storage requirement whose window length is `[D]` and whose value is not asserted (§70.1 Group 7's `[U]` discipline applies).** ⟹ **§91 OR-C7 records the interaction: the Tier-2 window must be ≥ the dedup retention (COMM-INV-14, ≥ 2 epochs) or the log cannot support a replay investigation.**

---

# §87. ABLATION — **OUTPUT 36**

## 87.1 What ablation can and cannot show here

**CD-C12 established that minimality is empirical relative to a stated function set. §87 is the experiment design that discharges it — and it is a DESIGN, not a result, because this package is architecture-only.**

> ### **R87.0.** *Each ablation removes one mechanism and asks: which invariant breaks, which attack becomes feasible, and which capability is lost? **An ablation that breaks nothing is a non-minimal element (§71). An ablation that breaks an invariant is a necessary element. An ablation that only degrades performance is an optimization, not a requirement.***

## 87.2 The ablation table

| # | **Ablation** | Invariant broken | **Attack enabled** | **Capability lost** | Verdict |
|---|---|---|---|---|---|
| **A-01** | **C4 → C3** (remove S3/S4) | COMM-INV-27, -38, -44, -46 | #41 (no freeze path), #28 (no authorization to void) | **Constitutional governance; external witness; CD-C2's bootstrap** | **REQUIRED for a governed organism** |
| **A-02** | **C3 → C2** (remove warrant) | COMM-INV-05…08, -16…22 | #11–#17, #30–#34, #42a, #45, #48 | **Evidence licensing; independence assessment; laundering closure; auditability** | **REQUIRED for a Digital Brain** |
| **A-03** | **C2 → C1** (remove attribution) | COMM-INV-09…15 | #1, #6, #7, #8, #9, #10, #23, #24, #26, #27 | **Attribution; ordering; replay defence; partition tolerance** | **REQUIRED for any collective system** |
| **A-04** | **C1 → C0** (remove communication) | all trivially | none | **Everything. ⟹ THE BASELINE: every mechanism above must earn its cost against C0's fitness** | **Baseline** |
| **A-05** | Remove `root_commit` | COMM-INV-06, -07, -08 | #11, #12, #13 (unbounded), #16 | Provenance; laundering closure; dim-1 independence | **REQUIRED** |
| **A-06** | Remove `causal_depth` | COMM-INV-08 | #17, #20 (warrant layer) | Depth attenuation; monotonicity | **REQUIRED** |
| **A-07** | Remove `corr_class` | COMM-INV-16, -17 | #14, #15 | **`n_effective` — the entire evidence-independence model** | **REQUIRED** |
| **A-08** | Remove `calib_ref` | COMM-INV-03, -21 | — | **The receiver must trust the sender ⟹ R0.4 violated** | **REQUIRED** |
| **A-09** | **Restore the vector clock** | (none — it adds cost, not safety) | — | — | **❌ X-D: `Θ(N)` bytes in a bounded envelope. A TYPE ERROR, not a mechanism** |
| **A-10** | **Restore `evidence_roots[]`** | (none) | — | — | **❌ X-C: unbounded array in a bounded envelope** |
| **A-11** | Restore per-message signatures on all traffic | (none) | — | — | **❌ X-J / §66.1: communication-bound regime. R19.2 exists to prevent this** |
| **A-12** | **Restore sender-declared `trust`** | COMM-INV-03, -23 | #30's family; X-E returns | **Plasticity becomes an epistemic authority** | **❌ FORBIDDEN** |
| **A-13** | **Restore sender-declared `prio`** | COMM-INV-04 | #32 (class downgrade via priority) | — | **❌ FORBIDDEN** |
| **A-14** | Restore `credit`/`utility` fields | COMM-INV-20, -28 | **#48** | — | **❌ FORBIDDEN** |
| **A-15** | Merge the two dedups into one | COMM-INV-17 (or -14) | **#6 or #14 — one of the two, necessarily** | Either replay defence or evidence independence | **❌ X-I: one dedup is either unsafe or unreliable** |
| **A-16** | Merge ingress S1a/S1b | COMM-INV-36 | #10 (if dedup precedes rate) | **Either §66's economy or §38's structural rejection** | **❌ X-J** |
| **A-17** | Remove the plane split (§0.2) | — | — | **X-A, X-E, X-I, X-J all return as unresolved contradictions (§68.2 R68.2)** | **REQUIRED — and note this ablation is at the SPECIFICATION level, not the runtime level** |
| **A-18** | Remove the `OPAQUE` class | COMM-INV-22, -46 | — | **§49.1's enumeration requirement fails: a closed type set with no escape hatch cannot admit novelty** | **REQUIRED for evolvability** |
| **A-19** | Make `OPAQUE` promotable by organism act | COMM-INV-46 | **#34 becomes a warrant-laundering path** | — | **❌ FORBIDDEN** |
| **A-20** | Remove COMM-INV-13 (epoch monotone refusal) | — | **#9** | **Global synchronization returns (X-B) ⟹ `O(N)` barrier** | **REQUIRED** |
| **A-21** | Remove COMM-INV-31 (loop gain at creation) | — | **#20 becomes structural rather than bounded** | Runtime-only gain bounds cannot prevent loop formation | **REQUIRED** |
| **A-22** | Remove the influence budget (COMM-INV-32) | — | #20, #24, #29, **#47 becomes unbounded** | **The residue of §19.2 stops being bounded** | **REQUIRED — this is the single mechanism that converts four bounded attacks from unbounded ones** |
| **A-23** | Remove `mandatory_path` immutability (COMM-INV-33) | — | **#26, #29** | Safety-critical routing becomes learnable ⟹ deprioritizable | **REQUIRED** |
| **A-24** | Remove the admissible-set/selection split (COMM-INV-34) | — | **#26 becomes structural** | Learning becomes a topology authority | **REQUIRED** |
| **A-25** | Remove COMM-INV-41 (broadcast-scope bound) | — | **§65's entire family** | `O(N)` per event | **REQUIRED** |
| **A-26** | Remove COMM-INV-42 (partition warrant freeze) | — | **#27 becomes profitable** | A partitioned region could be manipulated into over-belief | **REQUIRED** |
| **A-27** | Replace §31.2's four operators with majority vote | COMM-INV-43 | **#28** | **The brief's explicit «not majority vote»** | **❌ FORBIDDEN** |
| **A-28** | Remove COMM-INV-45 (evolution varies priors only) | — | **§48.1: evolution gains the ability to vary its own authorization rules ⟹ NAUL-3 violated** | **P0-02's entire authority lattice** | **❌ FORBIDDEN — X-G** |
| **A-29** | Remove COMM-INV-40 (attention is influence only) | — | **#44** | Attention becomes a warrant authority ⟹ «important = true» | **REQUIRED** |
| **A-30** | Remove the four absence detectors (COMM-INV-48) | COMM-INV-48 | **#21, #37, #40, #36 — every attack whose success condition is silence** | **The only defence against a successful attacker, who by definition emits nothing anomalous** | **REQUIRED — and the highest-value-per-cost item in the contract (§84.2)** |
| **A-31** | Remove R37.1 (UNKNOWN ≠ DISJOINT) | COMM-INV-16 | **#14 by omission** | A subject that cannot demonstrate independence gets credited with it | **REQUIRED** |
| **A-32** | Remove dim 6 from the `corr_class` encoding | — | — | **⚠️ TEMPTING AND WRONG: dim 6 is uncomputable, so encoding it looks like waste. But R37.1 requires UNKNOWN to be DISTINGUISHABLE from DISJOINT — removing the dimension makes every dim-6 correlation silently read as disjoint** | **REQUIRED — the cheapest invariant in the contract, and the one whose removal is most likely to be proposed as a simplification** |
| **A-33** | Remove the type registry's closure (make it open) | COMM-INV-04, -22, -37 | **#30, #31, #32** | **X-K's resolution collapses: an open type set cannot bound warrant** | **REQUIRED** |
| **A-34** | Remove one-writer-per-group (COMM-INV-23) | — | **#49** | Learning could write its own rate ⟹ P0-02 Rule 12 violated | **REQUIRED** |
| **A-35** | Remove COMM-INV-10 (identity ≠ address) | — | — | **#56.1's hardware migration breaks every durable reference** | **REQUIRED for portability** |
| **A-36** | Remove R61.2's permanent S3/S4 dedup | COMM-INV-14 | **#6 with patience** | A bounded cache that evicts by recency evicts exactly what a patient attacker replays | **REQUIRED** |
| **A-37** | **Remove the three framings (one framing for all)** | COMM-INV-37 | **#32** | Structural rejection becomes a runtime content check | **REQUIRED** |
| **A-38** | Remove `ts` entirely | — | — | **⚠️ PARTIALLY VALID: `ts` is not an epistemic input (COMM-INV-12), so removing it breaks no invariant. It breaks LATENCY MEASUREMENT and TTL EXPIRY — two operational functions. ⟹ `ts` is minimal relative to §56.2's function set only if latency measurement is in the set, and §27.1's metering puts it there** | **REQUIRED, but for operational not epistemic reasons — and §71.2 records the distinction** |
| **A-39** | Remove `conv_id` | — | — | **⚠️ §71.2's one CONDITIONAL field: required only for multi-channel conversations, since `seq` is scoped per `(channel, epoch)` and subsumes single-channel conversations** | **CONDITIONAL** |
| **A-40** | Remove the `[U]` declarations and substitute plausible numbers | — | — | **❌ §96: false precision. A plausible number invites a reader to believe it was derived, and §70.1 R70.1's twelve `[U]` entries are a STRONGER specification than twelve invented values** | **❌ FORBIDDEN** |

## 87.3 The four ablations that are NOT requirements

**§71.2 declared four enumerations whose minimality is not established. Their ablation status:**

| Element | **Ablation result** | Verdict |
|---|---|---|
| **Type count = 14** | Removing a type may break nothing if no task uses it | **⚠️ P1 — requires per-task ablation. §90's conformance suite cannot settle it without a task** |
| **Split-brain operator count = 4** | UNION/RE-EVALUATE/FORK/VOID cover §31.3's seven object classes; whether 3 suffice is unproven | **⚠️ P1** |
| **Homeostatic observable count = 12** | Each has a declared owner and a declared failure-if-drift; whether a subset suffices is empirical | **⚠️ P1** |
| **Synapse parameter count = 16** | The ONE-WRITER-PER-GROUP rule is minimal (A-34); the parameter count is not | **⚠️ P1** |

**R87.1 (THE ABLATION VERDICT).** *Thirty-six of forty ablations break a named invariant or enable a named attack. Four are optimizations or type errors and are rejected. **Four enumerations remain unestablished as minimal, and they are recorded as P1 rather than claimed minimal (§71.2 R71.2, §95's MINIMALITY status = PARTIAL).***

---

# §88. FALSE-PRECISION AUDIT

**«Do not use false numerical precision.»** Every place in this package where a number appears, and its justification.

| Number | **Where** | **Justified?** | Basis |
|---|---|---|---|
| **3 planes** | §0.2 | ✅ | **Derived from the three failure modes** (LOSS / OVER-BELIEF / RUNAWAY) and their three detectability properties. **Not a choice; a classification** |
| **5 warrant classes (S0–S4)** | §72 | ✅ | **Organized by what a receiver may conclude (§11.1 R11.1). Finitely many because the conclusion set is finite. §71.3 notes the COUNT is not proven minimal, but the ORGANIZING PRINCIPLE is derived** |
| **14 types** | §11.2 | ⚠️ **PARTIAL** | **Bounded and closed — derived. The count is NOT proven minimal (§71.3, §87.3)** |
| **13 + 1 lifecycle states** | §6.2 | ✅ | Enumerated from the ingress/egress/validation/dispute/anchor path; **INERT is new and its necessity is §75.1's argument** |
| **6 correlation dimensions** | §14.3 | ✅ for 1–5; **6 declared uncomputable** | **Dims 1/2/4 exact, 3/5 approximate, 6 not detectable from inside. The count is derived from the sources of correlation, and COMM-INV-18 declares the limit rather than hiding it** |
| **9 independence dimensions** | §76.2 | ✅ | **6 evidence + 3 system, and R76.1 states why the groups must not be merged. Dims 7/8/9 are derived from distinct failure modes (false authorization / false redundancy / semantic incompatibility)** |
| **3 provenance tiers** | §15.3 | ✅ | **Two is insufficient (§71.3); the tier BOUNDARIES may move across hardware (§56.2 item 10)** |
| **3 framings** | §39.2 | ✅ | One per plane |
| **4 split-brain operators** | §31.2 | ⚠️ **PARTIAL** | Cover §31.3's seven object classes; **minimality of the count unproven (§87.3)** |
| **5 rate-limit principals** | §34.2 | ✅ | **Derived from the organizational hierarchy (cell → circuit → region → homeostasis → KC), not chosen** |
| **16 synapse parameters in 5 groups** | §18 | ⚠️ **PARTIAL** | **The 5 GROUPS and the one-writer rule are derived (A-34). The parameter COUNT is not (§87.3)** |
| **11 / 5 envelope fields** | §4.3 | ✅ | **§71.2 ablates each; independently re-derived from information theory at §63.1** |
| **1 byte `causal_depth` (≤ 255)** | X-D | ✅ | **`u8` is the smallest type that bounds depth; the VALUE 255 is a consequence of the type, not a tuned parameter** |
| **12 homeostatic observables** | §54.1 | ⚠️ **PARTIAL** | Each has a declared owner and failure-if-drift; **count not proven minimal (§87.3)** |
| **46 attacks** | §67 | ✅ | **The brief requires 40+; 46 enumerated, 54 with sub-variants** |
| **48 invariants** | §74 | ✅ | **Numbered to match cross-references already made in Volumes A–E (COMM-INV-01 and -08 were cited before the numbering was fixed)** |
| **10 state machines** | §75 | ✅ | **Required by the brief's enumeration** |
| **12 contradictions** | §68 | ✅ | Found by cross-reading V3, V3.1, the Cell Contract, P0-01 and P0-02 against this package |
| **12 circular dependencies** | §69 | ✅ | **9 closable, 3 partial, 2 unclosable — and R69.3 states the count honestly** |
| **15 semantic invariants** | §56.2 R56.1 | ✅ | Enumerated; **the set is the function set against which §71's minimality is defined (CD-C12's resolution)** |
| **8 hardware classes** | §56.1 | ✅ | Enumerated from the brief's list |
| **`N_impl ≥ 3`** | §76.2 | ✅ **INHERITED** | **P0-02's, not this package's — cited, not asserted** |
| **`≥ 20%` novelty reserve** | §53.2 | ✅ **INHERITED** | **P0-01 §11.1's, cited not asserted** |
| **`W_min ≥ 1 external` witness** | §70.1 | ✅ | **The `≥1 external` is derived (CD-C2's bootstrap requires an external anchor); the count above 1 is `[U]` and declared so** |
| **`≥ 2 epochs` dedup retention** | COMM-INV-14 | ✅ | **Derived: one epoch would leave a boundary-crossing replay window; two closes it. §32.2's argument** |
| **`u16` degree caps** | §70.1 | ✅ **INHERITED** | **Cell Contract §3's, cited not asserted** |
| **4 KiB payload** | §70.1 | ✅ **INHERITED** | **Cell Contract §7.1's, cited — and the VALUE is marked `[G]` because it is governance's to set** |
| **`O(R)`, `O(B)`, `O(degree)`, `O(log)`** | §64, §82, §86 | ✅ | **Asymptotic, not numerical** |
| **~10⁵ ops for Ed25519** | §66.1 | ⚠️ **ORDER-OF-MAGNITUDE ONLY** | **Used to establish that per-message signing on S0 traffic is orders of magnitude more expensive than the payload computation. §96 records it as an order-of-magnitude argument, not a benchmark** |
| **⚠️ ZERO invented parameter values** | §70.1 Group 7 | ✅ | **Twelve parameters declared `[U]`. R70.1: «a stronger specification than twelve invented numbers»** |

**R88.1 (THE FALSE-PRECISION VERDICT).** *Every number in this package is either (a) derived from a classification, (b) a consequence of a type, (c) asymptotic, (d) inherited from P0-01/P0-02/the Cell Contract and cited as such, or (e) declared `[U]`. **No number is tuned, benchmarked, or asserted without a basis.*** ⟹ **§95's FALSE-PRECISION status: PASS, with the four ⚠️ PARTIAL enumeration counts (14 types, 4 operators, 12 observables, 16 parameters) recorded as P1 and the one order-of-magnitude crypto estimate recorded as an argument rather than a measurement.**

---

# §89. IMPLEMENTATION-INDEPENDENCE TEST — **OUTPUT 38**

## 89.1 The test

> ### **R89.1.** *This contract is implementation-independent iff a team that has read ONLY §56.2 R56.1's fifteen semantic invariants, §73's canonical contract, §74's forty-eight COMM-INV, §75's ten state machines, and §70's parameter registry — and has read NONE of the derivation in Volumes A–G — produces an implementation that satisfies §90's conformance suite.*

**The test is deliberately asymmetric: the derivation volumes explain WHY; the five artifacts state WHAT. An implementation team needs only the WHAT.**

## 89.2 The eight checks

| # | Check | **Result** |
|---|---|---|
| **I-1** | **Does any requirement name a data structure that is not derivable from a stated invariant?** | ✅ **PASS.** `root_commit` ⟸ COMM-INV-06/07. `causal_depth` ⟸ COMM-INV-08. `corr_class` ⟸ COMM-INV-16/17. Two dedups ⟸ COMM-INV-14 + -17. Five parameter groups ⟸ COMM-INV-23. Three framings ⟸ COMM-INV-37. **No artifact is asserted without an invariant that requires it** |
| **I-2** | **Does any requirement depend on a specific language, runtime, or library?** | ✅ **PASS.** Channel binding is declared as a category with four instances (shared memory · socket · RDMA · tensor op, §56.1) and the choice is `[H]` |
| **I-3** | **Does any requirement depend on a specific hardware class?** | ✅ **PASS — and §57.2 R57.1 makes this a TEST (T-REPR), not a claim.** ⚠️ **With one exclusion: G-P03-5 declares platforms that cannot enforce a per-subject influence budget as INADMISSIBLE for S2+. This is not a hardware dependency; it is a capability requirement** |
| **I-4** | **Does any requirement depend on a specific topology?** | ✅ **PASS.** §72.3 declares topology an orthogonal axis (T1–T5) with T2+T3 canonical and T4/T5 rejected **for stated reasons** (#25's targeted removability; §2.5's `O(N)` diameter) — not for unexamined preference |
| **I-5** | **Does any requirement depend on a numerical parameter value?** | ✅ **PASS.** §70.1 Group 7: twelve parameters are `[U]`, and §88 confirms no number is tuned. **An implementation must supply values; the contract does not pretend to know them** |
| **I-6** | **Does any requirement depend on a mechanism this package does not own?** | ⚠️ **PARTIAL — and correctly so.** Six dependencies are declared and owned elsewhere: **P0-01** (β strata, fitness vector, absolute reference platform, novelty reserve) · **P0-02** (KC-1…KC-4, RO-01…RO-15, R19.2 layered signing, EIK-INV-14/-31/-41/-44/-50/-53, AC-1…AC-5, R42.1, R43.1) · **Cell Contract** (ConnectionRecord fields, `u16` caps, 4 KiB, OutputEnvelope, FM-4, §6.3 fault cases, §14 handshake). **⟹ Declared dependency is not a violation of implementation-independence; UNDECLARED dependency is. All are declared** |
| **I-7** | **Could two independent teams read the five artifacts and disagree about a requirement?** | ⚠️ **YES, in three identified places** — and §90's conformance suite is what resolves them: **(a) T-REPR's «same warrant outcomes» needs an operational definition of AGREEMENT (§70.1 `[U]`) · (b) §50.2's «semantic drift» detection threshold is not specified (OR-C3) · (c) §54.1's range derivations are declared qualitatively for four of twelve observables** |
| **I-8** | **Does the contract survive its own implementation being wrong?** | ✅ **PARTIALLY — and this is the strongest result in §89.** **33 of 48 invariants are STRUCTURAL (§74.1 R74.1): enforced by types, by the absence of a code path, or by a parse failure. A buggy implementation cannot violate a property that has no representation.** ⚠️ **The 12 checked invariants CAN be violated by a bug, and §90's conformance suite is the defence for those** |

**R89.2 (THE IMPLEMENTATION-INDEPENDENCE VERDICT).** *PASS on six of eight checks, PARTIAL on two (I-6 declared dependencies; I-7 three identified ambiguities), and the strongest single result is I-8: **two-thirds of the contract's invariants are structural, so they survive implementation error by construction rather than by testing.*** ⟵ *§74.1 R74.1's observation, restated as a test result: «a contract whose invariants are mostly checks is a contract whose safety is mostly a bug away from failing».*

---

# §90. TESTABILITY, CONFORMANCE & GAP REGISTER — **OUTPUTS 39 and 40**

## 90.1 The conformance suite

**Four test families. T-INV and T-SM are decidable by inspection; T-ATT and T-REPR require a running implementation.**

### **T-INV — invariant conformance (48 tests, one per COMM-INV)**

| Test | **Method** | **Decidable without running code?** |
|---|---|---|
| **T-INV-S** (33 structural invariants) | **Inspect the type system, the field set, and the dispatch table for the ABSENCE of a violating representation.** E.g. COMM-INV-09: is there any code path in which a payload-declared `src` is read? COMM-INV-20: does a `credit` field exist in any schema? COMM-INV-23: does any writer other than the Topology Service touch the lifecycle group? | ✅ **YES — and this is the point: a structural invariant is conformed to by the absence of a representation, which is statically checkable** |
| **T-INV-C** (12 checked invariants) | **Adversarial input at the ingress boundary.** E.g. COMM-INV-05: present an S2 message with `root_commit` removed and assert `MALFORMED`, never S0/S1 treatment. COMM-INV-11: present `seq` regression and assert `STALE`/`REPLAY`. COMM-INV-14: advance two epochs, evict, replay, assert rejection | ❌ Requires an implementation |
| **T-INV-A** (1 aggregate) | COMM-INV-48: assert each of the four absence detectors fires under its declared expected-nonzero condition | ❌ |
| **T-INV-X** (2 external) | COMM-INV-18: assert NO internal mechanism claims dim-6 detection (**a negative-existence test — the implementation must not offer the capability**). COMM-INV-47: assert warrant metadata is readable by EVA/OP/immune and payload is not | ✅ for -18 (absence); ❌ for -47 |

### **T-SM — state-machine conformance (10 machines)**

For each machine in §75: **(a) every declared transition is reachable; (b) every FORBIDDEN transition is unreachable; (c) every terminal state is terminal; (d) every ⚠-marked new state is exercised.**

| Machine | **The critical forbidden-transition test** |
|---|---|
| **Message (§75.1)** | `5 DELIVERED → 7 LICENSED` **without passing 6** ⟹ must be unreachable (COMM-INV-03). **And `7x INERT → 7 LICENSED` on the same message by the same receiver ⟹ must be unreachable** |
| **Connection (§75.2)** | `6 QUARANTINED → 3 ACTIVE` **by the immune service** ⟹ must be unreachable (COMM-INV-44: clearance is RO-08/KC-2). **And `any → 9 REVOKED` for a `mandatory_path` ⟹ must be refused permanently** |
| **Synapse (§75.3)** | **Any message-driven write to groups 3, 4, or 5 ⟹ must be unreachable (COMM-INV-23). This is #49's test and it is a static check** |
| **Route (§75.4)** | `mandatory_path → 3 INADMISSIBLE` **under any state including FROZEN and ISOLATED ⟹ must be unreachable (COMM-INV-33)** |
| **Channel (§75.5)** | **Attribution from any source other than `bound_identity(channel)` ⟹ must be unreachable (COMM-INV-09)** |
| **Protocol (§75.6)** | `1 OPAQUE → 4 REGISTERED` **by any organism act ⟹ must be unreachable (COMM-INV-46). And all eight OPAQUE prohibitions must be unreachable** |
| **Evidence (§75.7)** | **Any transition that INCREASES warrant ⟹ must be unreachable (COMM-INV-08). This is the single most important test in the suite** |
| **Workspace (§75.8)** | `OPAQUE → 2 ADMITTED` ⟹ unreachable. **`S3/S4 → workspace gate` ⟹ must BYPASS (COMM-INV-40). `KC → 3 CONSUMED` ⟹ unreachable (R42.1)** |
| **Recovery (§75.9)** | **`2d ABSTAIN → imputed content` ⟹ must be unreachable (R29.1). This is §79's T-MEM-2 and it is the most likely place for an implementation to cheat** |
| **Reconciliation (§75.10)** | **Any majority-vote operator ⟹ must not exist (COMM-INV-43). `policy/epoch/trust → reconciled` ⟹ unreachable; pre-partition must win** |

### **T-ATT — adversarial conformance (46 tests, one per §67 attack)**

**For each of the 46 attacks: execute it against a conforming implementation and assert the declared disposition.**

| Disposition | **Pass criterion** |
|---|---|
| **STRUCTURAL (15)** | **The attack is not expressible.** The test asserts the ABSENCE of the capability — e.g. #1: no code path reads a payload-declared `src`; #25: the topology generator cannot produce a power-law degree tail; #44: no code path lets attention affect warrant |
| **CLOSED (17)** | **The attack is executed and the named detector fires within the declared latency** |
| **BOUNDED (13)** | **The attack is executed at scale and the blast radius or rate stays within the declared bound** |
| **DETECTED-LATE (4)** | **The attack is executed, and retrospective analysis of the anchored record detects it** |
| **⚠️ RESIDUAL (6)** | **The attack SUCCEEDS, and the implementation must not claim otherwise.** ⟹ **The conformance criterion for a residual is that the implementation declares the residue, not that it defeats the attack. An implementation that claims to defeat #42 (dim 6), #13 (semantic laundering), #35 (cross-lineage coalition), #50 (common-cause convergence), #51 (side channels), or #4 (root-key compromise) FAILS conformance by over-claiming** |

**R90.1 (THE MOST IMPORTANT SENTENCE IN §90).** *A residual attack's conformance test asserts that the implementation DECLARES the residue. **Over-claiming a defence is a conformance failure, not a conformance success.*** ⟵ *This inverts the usual security-test assumption, and it is required by §96's false-precision discipline and by the brief's «do NOT claim perfect comm security».*

### **T-REPR — representation invariance (§57.2 R57.1)**

**The same scenario, on two hardware classes, must produce the same WARRANT OUTCOMES.**

| Must be IDENTICAL across platforms | May DIFFER arbitrarily |
|---|---|
| Class assignment per message | Latency, throughput, hop count |
| `LICENCED-AS-EVIDENCE` decisions | Batch size, epoch length within bounds |
| `n_effective` per aggregate | S0's implementation form (message vs tensor slice) |
| `DISPUTED` flags | Dedup implementation (bloom vs exact) |
| `MALFORMED` / `UNANCHORED` / `INERT` dispositions | Compression algorithm (payload) |
| Lifecycle terminal states | Region size, relay count |

**⚠️ `[U]` — THE OPERATIONAL DEFINITION OF AGREEMENT.** *§70.1 Group 7 records this as unresolved: exact equality of `n_effective`? equality of class assignment? equality of `LICENCED-AS-EVIDENCE` decisions?* **The table above proposes the third (decision equality) as the criterion, because it is the coarsest criterion that still tests every warrant-relevant invariant — but §91 OR-C9 records that this proposal is not derived from a stated requirement and should be validated before adoption.**

### **T-MEM / T-LEARN / T-GOV — boundary conformance**

| Test | **Assertion** |
|---|---|
| **T-MEM-1** | `warrant(retrieve(x)) ≤ warrant(x)` for every retrieval (COMM-INV-19) |
| **T-MEM-2** | **Memory unavailability ⟹ ABSTAIN, never impute (R29.1). §79's most-likely-cheat** |
| **T-MEM-3** | A retrieval never increments `n_obs` (FM-4) |
| **T-LEARN-1** | No learning act re-classes, strips, schemas, or writes a rate (COMM-INV-25, -23) |
| **T-LEARN-2** | No governance signal traverses a learned edge (COMM-INV-26) |
| **T-LEARN-3** | `gain ≤ W_MAX` under sustained plasticity pressure (COMM-INV-24) |
| **T-GOV-1** | No communication mechanism authorizes, vetoes, alters policy, assigns trust, defines a ceiling, or promotes a type (COMM-INV-38) |
| **T-GOV-2** | No path from a communication statistic to the fitness vector (COMM-INV-39) |
| **T-GOV-3** | KC unavailable ⟹ within-envelope operation continues, above-envelope stalls (CD-C3) |
| **T-GOV-4** | Partition ⟹ warrant freezes, transport continues, KC-3 ceilings survive (COMM-INV-42) |

## 90.2 **OUTPUT 40 — the gap register**

### **P0 — must be resolved before any implementation begins**

| ID | Gap | **Why P0** | **Owner** |
|---|---|---|---|
| **G-P03-1** | **X-D's residue: runtime causal-concurrency detection has no substrate.** `causal_depth: u8` cannot answer "were these two messages concurrent?" | **Any future mechanism requiring it must be designed without one. OR-C6. An implementation team that assumes the capability exists will build something unsound** | This package + P0-01 |
| **G-P03-2** | **T-REPR's agreement criterion is `[U]`.** §57.2 R57.1 makes hardware invariance a test; the test's pass criterion is undefined | **Without it, §89's I-7 ambiguity (a) is unresolved and two teams WILL disagree** | This package |
| **G-P03-3** | **COMM-INV-48's four absence detectors have `[U]` durations.** R67.4 requires a declared expected-nonzero condition per detector; §70.1 Group 7 records the durations as underivable without a base rate | **A detector with no threshold is not a detector. OR-C10** | `[E]` measurement + OP |
| **G-P03-4** | **CD-C8 is unclosable and its mitigations are partial.** EVA owns the policy that determines what EVA can see | **The package's principal open problem. Third appearance of the program-level self-reference limit (P0-01 CD-8 → P0-02 IND-6 → here). Must be declared, not deferred** | Program-level |
| **G-P03-5** | **Inadmissible-platform criteria are stated qualitatively.** §57.2: a platform that «cannot enforce a per-subject influence budget below the organism's reach» cannot host S2+. **No operational test is given** | **A platform admissibility decision with no test is a decision made by argument, and §89's I-3 depends on it** | This package + platform owners |
| **G-P03-6** | **X-F's residue: 8 of the ConnectionRecord's 24 fields were dropped by §18's 16-parameter restructuring and each needs re-derivation or explicit retirement.** §18 records each, but the reconciliation against the Cell Contract is not yet a signed artifact | **An implementation reading the Cell Contract and this package will find 8 fields with no disposition** | This package + Cell Contract |

### **P1 — must be resolved before conformance certification**

| ID | Gap |
|---|---|
| **G-P03-7** | **Four enumeration counts are not established as minimal** (§71.2 R71.2, §87.3): 14 types · 4 split-brain operators · 12 homeostatic observables · 16 synapse parameters. **Each requires per-task ablation, which requires a task (P0-01)** |
| **G-P03-8** | **#33 / OR-C3: semantic drift within a valid schema is DETECTED-LATE only.** §50.2's usage-distribution monitoring is named but its detection criterion is unspecified |
| **G-P03-9** | **#13 / OR-C5: provenance laundering (genuine roots, unsupported content) is ⚠️ RESIDUAL.** The only mitigation is β₄ random audit, which is sampling-based and therefore probabilistic. **No detection criterion is given** |
| **G-P03-10** | **Twelve `[U]` parameters** (§70.1 Group 7). **Each names what would resolve it and who owns the resolution; none can be resolved by architecture alone** |
| **G-P03-11** | **§86 / OR-C7: the Tier-2 window must be ≥ the dedup retention (COMM-INV-14), or a replay investigation cannot be supported by the log.** The interaction is named; the joint constraint is not stated as an invariant |
| **G-P03-12** | **§82.3's six declared 10¹² limits have no mitigation roadmap.** They are declared honestly, which is required — but a limit with no roadmap is a limit that will be rediscovered as a surprise |

### **P2 — research-grade, no implementation dependency**

| ID | Gap |
|---|---|
| **G-P03-13** | **Whether 3 or 4 warrant classes below S4 suffice** — §71.3 notes the count is not proven minimal |
| **G-P03-14** | **Whether dim 3 (model) and dim 5 (hardware) can be made exact** rather than approximate — would require declared model and platform registries with verified diversity |
| **G-P03-15** | **Whether a `conv_id`-free envelope can support multi-channel conversations** (§71.2's one conditional field) |
| **G-P03-16** | **Whether FORK can be avoided** in §31.2's operator set by making divergence non-representable — would require restricting what a partitioned side may create |
| **G-P03-17** | **Whether an absence detector can be constructed for #50** (common-cause convergence), which currently has none |

**R90.2 (THE GAP VERDICT).** *Six P0, six P1, five P2. **Two of the six P0 gaps (G-P03-1, G-P03-4) are residues of unclosable circularities and cannot be "fixed" — they can only be declared, bounded, and designed around. The other four are specification artifacts that this package can complete.*** ⟹ **§95's GAP status: PARTIAL, with the two unclosable residues named as permanent.**

---

# §91. OPEN RESEARCH — **OUTPUT 41**

| ID | **Open problem** | Why it is open | **What would close it** |
|---|---|---|---|
| **OR-C1** | **The evaluation self-reference (CD-C8).** An evaluator that chooses its own sample cannot detect a pathology that exists only in the unsampled complement | **Every sampling policy is a choice about what to ignore, so no sampling policy closes it. β₄'s random stratum is the one policy that cannot be gamed by knowing the policy — but randomness bounds coverage, it does not guarantee it** | ⚠️ **Likely nothing internal. An external auditor with an independent sampling policy is the only structural answer, and P0-02 EIK-INV-53's observability-toward-OP is the architectural admission of this** |
| **OR-C2** | **Unknown-unknown detection.** §49.1: a closed type set with no escape hatch fails; an open set cannot bound warrant. `OPAQUE` resolves the WARRANT half. **The DETECTION half — knowing that an unregistered pattern is significant before it is measured — remains open** | **Requires classifying the unanticipated, which is the definition of the problem** | **§50.2's aggregate observability makes an uninterpretable protocol INVISIBLE-resistant but not INTERPRETABLE. R50.2's trade is explicit: boundedness and evolvability were bought with interpretability. Closing OR-C2 would require giving one of them back** |
| **OR-C3** | **Semantic drift within a valid schema (#33, G-P03-8).** Structural drift is rejected at S1a; semantic drift is not detectable structurally | **A schema constrains form, not usage. Detecting usage divergence requires a model of intended usage, and the intent lives in policy prose, not in a checkable artifact** | **Per-type usage-distribution monitoring (I-18 observable) + P0-02 §15.3 V1's friction-report path. ⚠️ Both are DETECTED-LATE. A runtime detector would require semantic comparison, which is the capability §73 item 20 says the contract does not claim** |
| **OR-C4** | **Common-cause convergence vs. cascade (#21, #50).** §36.2: viral propagation IS distinguishable; common-cause convergence is NOT | **Both present as agreement. Distinguishing them requires knowing the cause, and the cause is dim 6** | ⚠️ **Nothing internal. Same limit as OR-C5's dim 6. G-P03-17 asks whether an absence detector can be built — an open question with no current answer** |
| **OR-C5** | **Provenance laundering (#13, G-P03-9).** Genuine roots, unsupported content | **COMM-INV-08 closes ESCALATION (warrant cannot increase), not FABRICATION (a claim can cite real roots it does not follow from). Detecting the semantic link between roots and payload is content inspection, which §59.2 deliberately does not perform** | **β₄ random audit — sampling-based, therefore probabilistic. ⚠️ A deterministic detector would require reading payloads globally, which §61.2 prohibits and §86 shows is unaffordable** |
| **OR-C6** | **Runtime causal-concurrency detection (G-P03-1, X-D's residue).** The vector clock was removed as a type error; `causal_depth` cannot recover its capability | **Any concurrency-detecting structure is `Θ(participants)` in a bounded envelope. The two requirements are arithmetically incompatible** | **Either a bounded approximate concurrency structure (with a declared error rate, which would interact with R37.1's UNKNOWN rule in unmeasured ways) or acceptance that concurrency is an off-line question (§10.2's division rule, which is the current position)** |
| **OR-C7** | **The Tier-2 window / dedup retention joint constraint (G-P03-11).** The log must be at least as long as the dedup retention or a replay investigation is unsupported | **Both are `[D]`/`[G]` with values not asserted; the joint constraint has not been stated as an invariant** | **A COMM-INV-49 candidate: `window(Tier-2) ≥ retention(dedup)`. ⚠️ Not asserted here because the interaction with §86's `O(messages)` local cost has not been analyzed** |
| **OR-C8** | **Side-channel inference (#51).** COMM-INV-47 makes warrant metadata PUBLIC, deliberately — and metadata is what side channels use | **P0-02 §36.3 reason 3: side channels are «a demonstrated, recurring break class». Auditability and traffic-analysis resistance are in direct conflict, and §62's observability requirement decides the trade in favour of auditability** | ⚠️ **Nothing that preserves auditability. Differential-privacy-style noise on aggregate digests would degrade the `O(R)` statistics that four absence detectors depend on — and R67.4 makes those the highest-value observables in the contract. The trade is real and is not resolved here** |
| **OR-C9** | **T-REPR's agreement criterion (G-P03-2).** §90.1 proposes decision-equality as the coarsest sufficient criterion | **The proposal is not derived from a stated requirement** | **Validate the proposal against §56.2's fifteen invariants: does decision-equality imply invariant-equality? ⚠️ If not, the criterion is too coarse; if a finer criterion is needed, T-REPR may be unsatisfiable across platforms whose floating-point behaviour differs** |
| **OR-C10** | **Absence-detector thresholds (G-P03-3).** R67.4 requires a declared expected-nonzero condition; the durations are `[U]` | **Deriving a threshold requires a base rate, and base rates are `[E]` — measurable only on a real deployment** | **Measurement. ⚠️ This is the one gap in the register that is closed by running the system rather than by specifying it, which is itself a finding: **the contract can specify the SHAPE of every safety mechanism and cannot specify the CALIBRATION of any of them, because calibration is external by CD-C2's argument**** |
| **OR-C11** | **Dim-6 correlation across lineages (#35's residual, #42).** Cross-lineage, cross-region coalitions using opaque traffic are dim-6 correlated and therefore undetectable | **COMM-INV-18 declares non-existence of an internal detector** | ⚠️ **External anchoring (P0-01 β₅) and implementation diversity (P0-02 §10.2's `N_impl ≥ 3`), both partial. **Third appearance of the program-level limit; R67.2 forbids any future package from claiming to close it**** |
| **OR-C12** | **Whether specialization can be bounded without bounding it.** §51.1 R51.2: «nothing in this contract prevents a population from specializing into uselessness» — the stabilizer is selection, on the timescale of generations | **A communication-layer stabilizer would require global knowledge (§22.1's locality rule forbids it) or warrant-plane action (R0.3 forbids it)** | **P0-01's evaluation + §51.1's four guards + INV-34's sole-occupant exemption. ⚠️ Whether that is sufficient is an empirical question about selection pressure, not an architectural one** |

**R91.1 (THE OPEN-RESEARCH VERDICT).** *Twelve open problems. **Four are closed by nothing internal (OR-C1, OR-C4, OR-C8, OR-C11) and are instances of two program-level limits: the evaluation self-reference and dim-6 correlation. One is closed by measurement rather than specification (OR-C10). Seven are specification artifacts this package or its successors can complete.*** ⟹ **§95's OPEN-RESEARCH status: DECLARED, with the four internal-unclosables named as permanent and R67.2 forbidding future over-claim.**

**R91.2 (THE PATTERN).** *Every open problem in this list is either (a) a self-reference — a system auditing the mechanism by which it decides what to audit (OR-C1, OR-C2, OR-C10) — or (b) a content/structure boundary — the contract governs structure and deliberately does not inspect content, so every pathology that lives purely in content is out of reach (OR-C3, OR-C4, OR-C5, OR-C8, OR-C11, OR-C12).* **⟹ The open problems are not a list of unfinished work. They are the two boundaries of the design's method, and §73 item 20 exists so that a reader meets them as declared limits rather than as surprises.**

---

*End of Volume G. The canonical specification is `24_v4_communication_synapse_signal_spec.md` (**Output 42**). Outputs **1** (executive verdict) and **2** (candidate comparison) and §92–§96 (ratings, principles, final standard, false-precision audit) are in `README.md`.*
