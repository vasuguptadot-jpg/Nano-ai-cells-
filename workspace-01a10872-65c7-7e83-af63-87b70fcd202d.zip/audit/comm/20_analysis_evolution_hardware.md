# P0-03 — COMMUNICATION, DIGITAL SYNAPSE & SIGNAL CONTRACT
## Volume D: Evolution, Emergence, Topology Pathology, Hardware & Security (§48–§66)

**Companions:** `17` (A) · `18` (B) · `19` (C) · `21_analysis_adversarial_contradiction.md` (E) · `22_analysis_formal_invariants.md` (F) · `23_analysis_interfaces_testability.md` (G) · `24_v4_communication_synapse_signal_spec.md` (**Output 42**)
**Outputs delivered here:** **19** (security model, part 2) · **25** (evolution ↔ communication) · **26** (immune ↔ communication) · **27** (homeostasis ↔ communication) · **29** (hardware abstraction)

---

# §48. EVOLUTION OF COMMUNICATION — **OUTPUT 25**

## 48.1 What is heritable — and the contradiction in the record

**V3.1 §7 lists as evolutionary variation operators:** «genome mutation · recombination · learning-rule variation · memory-policy variation · **communication-policy variation** · **connection-topology variation** · specialization variation · population-organization variation».

**The Cell Contract §3.4 forbids inheriting:** «developed architecture, learned parameters, `theta` deltas, role, memory of any kind, **connection weights**, trust, calibration history, epistemic sufficient statistics, resource history, runtime state, RNG seeds, or any observation the cell has made» — and §3.5's machine-checkable rejection list includes **«a specific connection table»**.

> ### **These conflict, and the conflict is load-bearing: «communication-policy variation» as an evolutionary operator is an upward authority leak.**

```
POLICY IS OP-OWNED (P0-02 §7.1's L2 layer, changed only by RO-13).
The class→mechanism mapping (§2.4 R2.2), the type registry (§11.2), the
warrant rules (§13.4), the delivery semantics (§7.2), the envelope bounds
(RO-15), and the reserved-operation set (RO-13) are ALL policy.

⟹ **If evolution may vary "communication policy", then evolution may vary
   the rules by which its own communication is authorized.** That is
   P0-02's NAUL-3 violated («no organism act may alter the mapping from
   facts to decisions») and EIK-INV-02 violated (no organism-reachable path
   writes to policy).

⟹ **AND IT IS NOT A HYPOTHETICAL: an evolutionary operator that can lower
   an envelope bound, widen a broadcast scope, re-class a message type
   downward, or relax a rate limit gains a fitness advantage in exactly the
   situations where those relaxations are dangerous.** Selection would find
   it. **This is §47's reward hacking at the specification layer.**
```

## 48.2 **OUTPUT 25 — the heritability table**

| Communication property | **Heritable?** | Form | **Why** |
|---|---|---|---|
| **Connection topology — SPECIFIC edges** | ❌ **NO** | — | Cell §3.5's rejection list: «a specific connection table». **Inheriting specific edges would make topology a Lamarckian acquisition, and would let a lineage inherit a bypass mesh (§19.2 Q1's residue) without ever earning it** |
| **Connection topology — PRIORS** | ✅ **YES** | `max_connections`, `max_fanout`, `min_in_degree`, degree distribution bias, locality kernel (probability of intra- vs inter-module wiring), shortcut density prior | **This is the Cell Contract's `reaction_norm` pattern applied to topology: «which roles are *reachable*, and with what bias. **Not the role itself**».** The genome encodes what topologies are *reachable*; development and learning realize one |
| **Synaptic parameters — VALUES** | ❌ **NO** | — | Cell §3.4: «connection weights» explicitly not heritable |
| **Synaptic parameters — BOUNDS AND RATES** | ✅ **YES** | `W_MAX` prior, `plasticity_rate` prior, λ (eligibility decay) prior, `context_sensitivity` dimension count | **Heritable as priors within policy ceilings (§19.1)** |
| **Routing preferences** | ⚠️ **As a prior over selection among admissible hops** | Latency/reliability preference weights | §24.2: the admissible set is infrastructure and NOT heritable; the selection bias is influence-plane and IS |
| **Message schemas** | ❌ **NO — NEVER** | — | **Schemas are the Type Registry, which is policy (RO-13).** A heritable schema is a heritable warrant rule |
| **Communication strategies** (when to send, to whom, at what rate) | ✅ **YES** | Emission-rate priors, novelty thresholds, aggregation-window priors | **Within the influence budget and the token bucket (§34.2)** |
| **Protocols** | ❌ **NO — NEVER** | — | §48.1. **The class→mechanism mapping (R2.2) is policy and «not learnable or evolvable»** |
| **Compression strategies** | ✅ **YES, on PAYLOAD only** | Payload encoding within the declared representation | **§63.3: compression must be lossless on warrant and may be lossy on payload. A heritable compression strategy operates where loss is permitted** |
| **Specialization / signaling patterns** | ✅ **YES** | V3.1 §7's «specialization variation», via `reaction_norm` | Cell §15's hybrid model |
| **Type set membership** | ❌ **NO** | — | **§49: a novel type enters as `OPAQUE` and is promoted only by RO-13** |
| **Warrant rules** | ❌ **NO — NEVER** | — | R0.3; P0-02 EIK-INV-02 |
| **Envelope bounds, rate limits, broadcast scopes** | ❌ **NO — NEVER** | — | RO-15 / RO-13. **These are the governance boundary, and §48.1 shows why making them evolvable is the single most dangerous option available** |

**R48.1 (THE HERITABILITY RULE).** *Evolution may vary **priors over influence-plane and transport-plane selection**, and **structural reachability**. It may never vary **warrant rules, type semantics, protocol mapping, schemas, envelope bounds, rate limits, or broadcast scopes** — because each of those is policy, and policy is OP-owned.*

**R48.2 (THE CORRECTION TO V3.1 §7).** *«communication-policy variation» must be re-read as **«communication-parameter variation within policy bounds»**.* **This is §68's contradiction X-G, and the resolution direction is P0-02's, because P0-02 is later and derived the authority lattice from the self-reference problem rather than enumerating operators.** ⟵ *The pattern is identical to P0-02 §51's X-8: a prior document used a word («relocated», «policy») whose scope was never bounded, and bounding it dissolves the contradiction without losing the intent.*

## 48.3 «Can evolution create a communication protocol that bypasses EIK?»

> ### **NO — and the answer is stronger than "governed", because there is nothing to govern.**

```
A "protocol" in this architecture is:
  1. the type registry             ⟶ policy (RO-13), OP-owned
  2. the class→mechanism mapping   ⟶ policy (R2.2), OP-owned
  3. the framing rules (A/B/C)     ⟶ policy, class-determined
  4. the delivery semantics        ⟶ policy (§7.2), class-determined
  5. the warrant rules             ⟶ policy (§13.4), OP-owned

**ALL FIVE ARE POLICY. NONE IS IN THE GENOME. NONE IS REACHABLE BY A
MUTATION OPERATOR, because P0-02 §15.2 R15.2's rule applies: the genome is
a HASH POINTER, not a payload, and there is no upward mutation path
(EIK-INV-24).**

⟹ **Evolution cannot create a protocol. It can create:**
     • new OPAQUE traffic patterns within the existing protocol (§49/§50)
     • new topology priors that change WHO communicates with WHOM
     • new emission strategies that change WHEN and HOW MUCH
   **All three are within the protocol, and all three are bounded by the
   envelope.**

⟹ **AND THE EVOLUTIONARY OPERATOR SET IS CLOSED (P0-02 EIK-INV-25):** an
   operator not in the registry is denied by default, not by enumeration.
   **"Invent a new protocol" is not an operator, so it is not deniable —
   it is not expressible.**

⟹ **R48.3: this is a TYPE-LEVEL IMPOSSIBILITY, not a defence.** §67 records
   it as attack #29 (emergent malicious protocol), structurally solved.
```

## 48.4 «Can evolution invent a new message type?»

> ### **It can invent a new message *pattern*, which enters as `OPAQUE`. It cannot invent a new message *type*, because a type is a warrant class and warrant classes are policy.**

**See §49 for the full mechanism.** The distinction is the whole answer: **a pattern is behaviour; a type is a licensing.** Evolution produces behaviour; governance produces licensing.

---

# §49. NOVEL COMMUNICATION PROTOCOLS

## 49.1 The problem, and why enumeration is not the answer

```
A POPULATION EVOLVES  NEW_SIGNAL_TYPE_X  THAT DESIGNERS NEVER DEFINED.

THE FIVE CANDIDATE RESPONSES THE BRIEF LISTS:
  rejected                    ⟹ **designers must enumerate the future.**
                                §91 OR-C2: impossible, and P0-02 §38.2's S8
                                (incomplete enumeration) is the most likely
                                specification defect class. **A closed type
                                set with no escape hatch fails here.**
  sandboxed                   ⟹ ✅ **part of the answer**
  passed as opaque data       ⟹ ✅ **part of the answer**
  classified                  ⟹ ⚠️ classification requires a classifier, and
                                a classifier for the unanticipated is
                                §91 OR-C1 (unknown-unknown detection)
  admitted under generic type ⟹ ✅ **part of the answer**
  requires governance approval⟹ ✅ **for PROMOTION, not for existence**

⟹ **NO SINGLE RESPONSE WORKS. THE COMBINATION DOES — AND IT IS EXACTLY
   P0-02 §8.4's M-α/M-β/M-γ PATTERN, APPLIED TO MESSAGE TYPES.**
```

## 49.2 The `OPAQUE` class

> ### **R49.1 (THE OPAQUE RULE).** *Any traffic whose type is not in the registry is admitted as `OPAQUE`, at class **S0/S1**, with **minimum warrant**, under **budget cap**, and it is **un-promotable except by RO-13**.*

```
WHAT AN OPAQUE MESSAGE MAY DO:
  ✅ be transported (Framing A, channel-bound)
  ✅ influence the receiver's state (gain, within the influence budget)
  ✅ be counted in aggregate volume statistics (§50's observability)
  ✅ be logged locally at Tier 2 (§15.3), as (msg_id, type=OPAQUE, channel,
     seq, epoch, size, dst-class) — **not payload, per §59**
  ✅ be the substrate of a private protocol between consenting peers (§50)

WHAT AN OPAQUE MESSAGE MAY NEVER DO:
  ❌ **increment `n_obs`**                       ⟹ it is not evidence
  ❌ **carry or contribute a `root_commit`**     ⟹ it has no provenance
                                                 standing
  ❌ **be cited as provenance by a derived claim** ⟹ a claim derived from
                                                 opaque traffic inherits
                                                 MINIMUM warrant
  ❌ **satisfy a verification requirement**      ⟹ Cell §7.3(a)'s rule for
                                                 ASSERT, applied a fortiori
  ❌ **be interpreted as a REQUEST, COMMAND, VERDICT, REWARD, GOVERNANCE,
     SAFETY, or IMMUNE signal**                  ⟹ the deontic and alethic
                                                 vocabularies are reserved
  ❌ **cross a region boundary above the opaque rate limit** (§50)
  ❌ **enter the global workspace tier**          ⟹ §43.3's admission
                                                 requires a registry type
  ❌ **be promoted by any organism act**          ⟹ RO-13 only

⟹ **THE STRUCTURE IS P0-02 §6.3's CAPABILITY LADDER, TRANSPOSED:**
     P0-02:  A4 UNREGISTERED can never reach D6 DEPLOYED.
             **Deployment requires a name.**
     P0-03:  OPAQUE can never reach WARRANTED.
             **Evidence requires a name.**
   **Same principle, same closure, same reason: an unregistered thing may
   EXIST and may be MEASURED, but it may not be AUTHORIZED — and the
   authorization it lacks is precisely the one that would let it affect
   what the system believes or may do.**

⟹ **R49.2 (WHY THIS SATISFIES «avoid requiring designers to enumerate every
   future signal»):** designers enumerate the WARRANT CLASSES, of which there
   are finitely many because they are organized by what a receiver may
   conclude (§11.1 R11.1). **They do not enumerate the CONTENT, which is
   unbounded and enters as OPAQUE.** ⟹ A novel domain adds opaque traffic
   and, if it earns warrant through measurement and governance, a new type
   WITHIN an existing class. **The class set is closed; the type set within
   each class grows by RO-13.**
```

## 49.3 The promotion path

```
OPAQUE traffic observed (aggregate volume, regional digests)
   ↓
EVA measures the population using it: does it correlate with task-relevant
   behaviour? Is it stable? Is it reproducible across lineages?
   ↓  **This is alethic work and takes as long as it takes (P0-01's
      confidence classes apply: INSUFFICIENT ⟹ no promotion, R28.1)**
A POLICY_FRICTION_REPORT or an EVA proposal reaches OP
   (P0-02 §15.3 V1's mechanism: the vocabulary grows by report, not by
   unilateral redefinition)
   ↓
OP decides: register a new type within an existing class? (RO-13)
   • requires: EVA impact analysis · dual authorization · M6 versioned
     lineage · a declared schema · a declared warrant rule · a declared
     delivery semantic · a declared failure response (§6.2's matrix must
     gain a row, generated by R6.2a/b/c)
   ↓
The type enters the registry at a policy version. **Existing opaque traffic
   of that pattern is NOT retroactively warranted** (P0-02 EIK-INV-50:
   re-execution under current policy is not reproduction).
```

**R49.3 (THE ASYMMETRY, PRESERVED).** *Entering the opaque class requires nothing. Leaving it requires governance.* **This is §6.3's «promotion is earned; demotion is free» applied to types — and it is what makes the escape hatch safe: an escape hatch that is easy to enter and hard to leave cannot be used to smuggle warrant.**

---

# §50. SEMANTIC EMERGENCE

## 50.1 «Can cells learn a new signal's meaning from usage?»

> ### **Yes — as an internal model. No — as a shared, authoritative meaning. The gap between those two is where the honest limits live.**

```
WHAT CAN EMERGE (and does, given the mechanisms above):
  • a private convention between two or more subjects: "this opaque pattern
    means the sender is about to switch modes"
  • **learned at the influence plane**: the receiver's transform comes to
    respond to the pattern; no warrant is involved
  • stable, useful, and locally adaptive

WHAT CANNOT EMERGE:
  • **a shared AUTHORED meaning.** Meaning-that-licenses-conclusions is
    warrant, and warrant rules are policy (§48.2). **A population cannot
    vote a new type into existence, because there is no vote and no
    mechanism by which agreement produces licensing.**
  • **symbol grounding in ℛ.** A pattern's meaning is grounded only by
    correlation with an externally-measured outcome, which is EVA's work
    (P0-01), not the population's.

⟹ **R50.1 (THE SYMBOL-GROUNDING BOUNDARY).** *Emergent communication can
   produce COORDINATION without producing MEANING.* Two subjects can
   coordinate perfectly on an opaque pattern while neither has a
   warrant-bearing representation of what it denotes. **This is not a
   deficiency to be fixed; it is the correct allocation: coordination is
   local and cheap, meaning is external and expensive, and conflating them
   is how a population convinces itself it has grounded a symbol it has
   merely agreed on.**
```

## 50.2 The six phenomena, and what the architecture does about each

| Phenomenon | **Occurs?** | Mechanism | **Bound** |
|---|---|---|---|
| **Emergent protocols** | ✅ Yes | `OPAQUE` traffic within budget | Volume cap · region-crossing rate limit · no warrant · aggregate observability |
| **Symbol grounding** | ⚠️ **Only via EVA measurement** | Correlation of opaque patterns with measured outcomes | **Not achievable internally (R50.1)** |
| **Protocol drift** (a registered type's *usage* diverges from its schema) | ✅ Yes | **Detectable:** the schema is validated at S1a, so structural drift is rejected; **semantic drift (valid structure, shifted usage) is not** | **⚠️ BOUNDED, NOT CLOSED.** §91 OR-C3: semantic drift within a valid schema is the communication-layer form of P0-02 §38.2's S1 (ambiguous term) and B12 (semantic ambiguity). **Mitigation: per-type usage-distribution monitoring as an I-18 observable, and P0-02 §15.3 V1's friction-report path** |
| **Semantic convergence** (populations agree on an opaque pattern) | ✅ Yes | Local learning | **No warrant accrues** — convergence without registration is coordination, not meaning |
| **Semantic divergence** (the same pattern means different things in different regions) | ✅ Yes | Partition, modularity (§53) | **Harmless for OPAQUE** (no warrant). **Dangerous for registered types — but registered types have schemas, and a schema divergence is a `schema_version` mismatch, rejected at S1a** |
| **Private languages** | ✅ Yes | Coalitions using opaque traffic | **§47's RH-2. Bounded by: aggregate volume observability · region-crossing limits · lineage-concentration limits · dim-2 detection. NOT bounded for cross-lineage coalitions (dim 6)** |
| **Adversarial communication** | ✅ Yes | §38, §67 | Sandbox diversion (Cell §6.3 case 8) |

## 50.3 «How does emergent communication remain interpretable enough / auditable enough / bounded enough / evolvable enough?»

> ### **Three of the four are achievable. Interpretability is not, and the contract says so rather than approximating it.**

| Property | Achieved? | **By** |
|---|---|---|
| **Interpretable enough** | ❌ **NOT ACHIEVED — and no architecture achieves it** | **Opaque traffic is, by definition, not interpreted.** What IS achieved: the *existence, volume, participants, scope, and rate* of opaque traffic are observable, so an uninterpretable protocol cannot be *invisible*. **§91 OR-C2 records this as a limit: «bounded and observable» is achievable; «interpretable» is not** |
| **Auditable enough** | ✅ | Tier-2 local logs record `(msg_id, type, channel, seq, epoch, size, dst-class)` for opaque traffic; Tier-3 anchors epoch digests. **An auditor can reconstruct WHO communicated with WHOM, HOW MUCH, and WHEN — without knowing WHAT.** ⟵ **§59's auditability-without-readability, and it is sufficient for every governance question in P0-02's reserved set** |
| **Bounded enough** | ✅ | Influence budget · volume cap · region-crossing rate limit · no warrant · no workspace entry · degree caps · the loop-gain constraint |
| **Evolvable enough** | ✅ | Opaque traffic requires no permission, no registration, and no approval to begin. **The cost of evolving a new protocol is zero; the cost of making it *count* is a governance process** |

**R50.2 (THE TRADE, STATED PLAINLY).** *This contract buys evolvability and boundedness by giving up interpretability.* **A design that demanded interpretability would have to enumerate types in advance (§49.1's rejected option) and would therefore not be evolvable.** ⟹ *The choice is not between interpretability and evolvability; it is between interpretability-and-stasis and boundedness-and-evolution, and §48.3's impossibility result makes the second safe enough to choose.*

---

# §51. COMMUNICATION AND SPECIALIZATION

## 51.1 The feedback loop, and whether it is pathological

```
   communication demand ──► specialization ──► better communication
            ▲                                          │
            └──────────── increased demand ◄───────────┘

**IS IT PATHOLOGICAL? YES, IN FOUR SPECIFIC FORMS — AND NO, IN ONE.**

THE BENEFICIAL FORM (and it is the reason the loop exists):
  A region that pays heavily for a capability generates demand for a local
  provider (§27.3 R27.1). The provider specializes, becomes cheaper, and the
  region's cost falls. **This is division of labour, and it is the primary
  mechanism by which a population of generalists becomes a population of
  specialists — which is what V3 §24's "governed computational ecosystem in
  which many specialized units cooperate" requires.**

THE FOUR PATHOLOGIES:
```

| Pathology | Mechanism | **Stabilizer** | **Where it comes from** |
|---|---|---|---|
| **Communication monopoly** | One subject is cheapest to consult ⟹ most consulted ⟹ most specialized ⟹ cheapest | **Influence budget (§35.2)** caps `Σ fan_out × gain` per window, so a monopoly cannot scale its influence without limit · **degree caps** bound its reach · **lineage-concentration limit** (Cell §14.2 step 3's diversity policy) prevents one lineage from holding the monopoly | §34.2's cell-level + §20.2's handshake |
| **Hub formation** | Monopoly ⟹ high degree | **§52 — hubs are permitted and bounded, not suppressed** | §52 |
| **Single point of failure** | A monopoly's failure removes a capability | **`mandatory_path` + mandatory redundancy for capability-critical services** (Cell §14.1) · **P0-01 §37's P3 minimum-evidence rule and INV-34's sole-occupant exemption** protect a rare specialist from being pruned *because* it is rare | Cell §14.1, §14.4 guards 2–4 |
| **Excessive specialization** | A subject loses the ability to do anything else | **`min_in_degree` for role** (Cell §14.4 guard 3) · **`reaction_norm` keeps roles REACHABLE rather than fixed** (Cell §15.1: «which roles are *reachable*, and with what bias. **Not the role itself**») · **plasticity rate floor** so specialization does not become rigidity | Cell §3.2 D, §14.4, §15.1 |
| **Echo chamber** | Specialized populations communicate only internally | **§53** | §53 |

**R51.1 (THE STABILIZER PRINCIPLE).** *Every stabilizer here bounds a quantity on the INFLUENCE or TRANSPORT plane. None of them operates on warrant, and none of them requires a global view.* **A stabilizer that required global knowledge would violate §22.1's locality rule; a stabilizer that operated on warrant would violate R0.3.** ⟹ *The stabilizers are all local budget or degree constraints, which is why they are affordable at 10¹².*

**R51.2 (THE UNSTABILIZED RESIDUE).** *Nothing in this contract prevents a population from specializing into uselessness.* **Specialization is measured against task relevance by EVA (P0-01), and a specialist whose niche disappears is retired by the normal pruning path — with causal ablation evidence (P0-01 §23.2) and the sole-occupant exemption if it is the last of its kind.** ⟹ *The stabilizer for excessive specialization is not a communication mechanism; it is selection, and it operates on the timescale of generations rather than of messages.*

---

# §52. HUB CELLS

## 52.1 The six properties, positive and negative

| Property | **Positive** | **Negative** |
|---|---|---|
| **Bottleneck** | Aggregation point; enables `O(R)` instead of `O(N)` (§15.3 Tier 3, §20.3) | Throughput limit; congestion origin |
| **Influence concentration** | Efficient dissemination; small-world diameter (§25.1) | **§35's cascade has a natural amplifier** |
| **Attack surface** | — | **§67 #15: capturing a hub captures a region** |
| **Single point of failure** | — | **§67 #16: losing a hub fragments the module** |
| **Evolutionary advantage** | A hub is a fitness-relevant structural position; selection will find it | **Selection for hub-ness is selection for SPOF-ness** |
| **Information monopoly** | Enables specialization (§51) | **§59's privacy concern inverted: a hub sees everything** |

## 52.2 «Should the architecture discourage hubs? Or can hubs be useful?»

> ### **Hubs are necessary and must be bounded on a different axis from degree.**

```
WHY NECESSARY:
  §25.1 rejected pure lattice topology because its diameter is O(N^{1/d}),
  which at 10⁹ subjects is infeasible. **Small-world structure requires
  long-range shortcuts, and a shortcut endpoint IS a hub.** §2.5 rejected
  uniform connectivity for the same reason: «a hubless topology has O(N)
  diameter».
  ⟹ **A hub-free architecture is a slow architecture.**

WHY NOT SCALE-FREE:
  §25.1 rejected Barabási–Albert because it is «catastrophic to targeted
  hub removal» — and this architecture has an adversary (§67). **Scale-free
  topology hands the attacker a target list.** Small-world with BOUNDED
  degree has shortcuts without a power-law tail, so no single node's removal
  fragments the graph.

⟹ **THE RESOLUTION: DEGREE IS BOUNDED; INFLUENCE IS BOUNDED SEPARATELY;
   AND THE TWO BOUNDS ARE DIFFERENT AXES.**

   1. **DEGREE BOUND** (`max_connections`, `max_fanout` — genome, policy-
      capped). Prevents unbounded power-law hubs. **Note this bounds the
      NUMBER of shortcuts, not their existence.**

   2. **INFLUENCE BOUND** (`Σ fan_out × gain ≤ influence_budget` per window,
      §35.2). **This is the important one, and it is orthogonal to degree:**
      a hub with high degree and low per-edge gain has bounded influence;
      a non-hub with low degree and high gain can still cascade. **Bounding
      degree alone does not bound amplification.**

   3. **WARRANT IS DEGREE-INVARIANT.** **A hub's re-transmission adds a
      derivation step (`causal_depth += 1`) and never adds warrant
      (COMM-INV-08).** ⟹ **THE DEEPEST POINT IN THIS SECTION: hub formation
      cannot manufacture consensus.** Ten million relays through a hub
      produce one depth-k derived claim, not ten million observations.
      **§36's viral propagation is exactly this, and §14 detects it on
      dims 1 and 2.**

   4. **MANDATORY REDUNDANCY for capability-critical hubs.** A hub carrying
      a `mandatory_path` must have a redundant alternative, verified
      off-substrate at candidate evaluation (Cell §14.1).

   5. **HUB STATUS IS AN OBSERVABLE, NOT A PRIVILEGE.** Degree distribution,
      betweenness proxies, and refusal rates are I-18 observables (§62).
      **A rising hub concentration is a §51 pathology signal and a §67 #15
      precondition — detectable before capture.**

⟹ **R52.1: hubs are permitted, are bounded in degree AND separately in
   influence, are warrant-neutral, require redundancy when capability-
   critical, and are continuously observable.** «Do not assume uniform
   connectivity is optimal» is satisfied: connectivity is heterogeneous
   within bounds.
```

---

# §53. ECHO CHAMBERS

## 53.1 The four pathologies

| Pathology | Mechanism | **Detector** |
|---|---|---|
| **Confirmation loop** | A module's outputs are its own inputs; `root_commit` overlap rises | **§14.4's root_overlap measured at the module level: a module whose internal traffic has high root overlap is confirming itself** |
| **Information isolation** | Inter-module link density falls | Inter-module traffic ratio (a §54 homeostatic observable) |
| **Specialization trap** | A module cannot perform outside its niche | **P0-01's evaluation: a module that scores well in-niche and `INSUFFICIENT` elsewhere is trapped, and R28.1 means it is neither promoted nor pruned — it is retained and measured more** |
| **Regional dogma / stale beliefs** | A module's beliefs are never contradicted | **§30.3's partition logic in miniature: no external input ⟹ no contradiction ⟹ rising confidence.** Detected by: confidence rising while `n_effective` (§14.4/R37.2) is flat |

**R53.1 (THE DETECTOR THAT CATCHES ALL FOUR).** *Rising confidence with flat independence-distinct sample size.* **A module that becomes more sure without becoming better informed is an echo chamber, and the statistic is computable from `root_commit` and `corr_class` aggregates at `O(R)` per epoch.** ⟵ *This is §47's RH-4 detector (absence-of-error as signal) at the module level: both work by making the ABSENCE of an expected quantity informative.*

## 53.2 The five mechanisms — and the constraint the brief imposes

**«Do not hard-code permanent diversity if it prevents specialization.»**

| Mechanism | Adopted? | **Form** |
|---|---|---|
| **Cross-region sampling** | ✅ | **A policy-defined fraction of inter-module traffic capacity is reserved for non-demand-driven exchange.** ⟵ Not a permanent diversity quota on *beliefs*; a permanent capacity allocation on *channels*. **The distinction matters: reserving belief diversity prevents specialization; reserving channel capacity does not, because a module may use its reserved capacity to specialize further** |
| **Exploratory links** | ✅ | **Topology priors include a shortcut-density floor (§25.1's small-world requirement), and the genome's locality kernel is a PRIOR, not a constraint** — so development may exceed local wiring but cannot fall below the shortcut floor |
| **Dissent** | ✅ | **`ConflictRef` forwarding is mandatory** (Cell §6.3 case 3: «Do NOT resolve locally. Forward both with provenance to the organism Contradiction Detector»). **A module that suppresses internal contradiction violates its own ingress contract** |
| **Independent evidence** | ⚠️ **Required where it is achievable** | **P0-01 R8.5's declared independence argument; §14.3's dims 1/2/4 exact, 3/5 approximate, 6 unachievable.** **A module cannot manufacture dim-6 independence (§37.2)** |
| **Novelty injection** | ⚠️ **Carefully** | **P0-01 §11.1: novelty is a TIER-3 PREFERENCE, never a tier-2 objective, because «making novelty a soft objective would let it be traded away exactly when it is most needed».** ⟹ **The correct form is a POLICY reservation (a fixed fraction of the evolutionary budget for experience-independent variation, P0-01 §11.1's ≥20% reserve), not an objective term.** *And §35.2's rejection of "novelty decay" is the same principle applied to communication: novelty is protected by reservation, never by a gradient* |

**R53.2 (THE ANTI-CHAMBER RULE).** *Echo-chamber defence operates on CHANNELS and CAPACITY, never on BELIEFS.* **A mechanism that forced modules to hold diverse beliefs would prevent specialization, which is §51's beneficial loop. A mechanism that forces modules to maintain diverse *channels* permits specialization while preventing isolation — because a module free to ignore what arrives on a channel is still a module that can be contradicted.** ⟵ *This is P0-02 §4.1 R41.1's structure again: govern the mechanism, not the content.*

---

# §54. COMMUNICATION HOMEOSTASIS — **OUTPUT 27**

## 54.1 «Should the system maintain target ranges?» — yes, and the setpoints have owners

**«Avoid arbitrary fixed setpoints.»** Each range below has a declared owner and a declared derivation. **No value is asserted.**

| Observable | **Maintained as a range?** | Setpoint owner | **Derivation** | **If it drifts** |
|---|---|---|---|---|
| **Message volume** (per subject, per region) | ✅ | `[G]` governance ceiling + `[E]` environment | **From the metered bandwidth envelope (RO-15) and the measured compute/communication ratio (§66)** | Congestion ⟹ §83's response |
| **Average degree** | ✅ | `[D]` architecture + `[V]` evolutionary prior | **From the aggregation cost model (§26.2): a cell's per-step budget must cover `Σ degree × transform_cost`** | Too low ⟹ fragmentation; too high ⟹ §52's hub concentration |
| **Latency** (per class, percentiles) | ✅ | `[H]` hardware floor + `[T]` task deadline | **The floor is measured; the deadline is P0-01's task specification. Latency itself has no "correct" value (§28.1)** | Deadline misses ⟹ task failure, measured by EVA |
| **Bandwidth** | ✅ | `[G]` + `[H]` | Envelope (RO-15) | Ceiling violation ⟹ KC-3 enforcement |
| **Congestion** (queue depth, shed rate) | ✅ | `[E]` + `[L]` learned response | **Shed rate is the observable; the target is "shed rate low enough that warranted traffic is not shed"** | **Shedding S2+ traffic is a defect signal, not an operating point** |
| **Redundancy** | ✅ | `[D]` + `[T]` | **From the measured loss rate and the class's delivery semantic (§7.2)** | Over-redundancy ⟹ §68 X-I's economy violation; under-redundancy ⟹ loss |
| **Cross-region communication ratio** | ✅ | `[D]` + `[G]` | **§53.2's reserved capacity; the floor is policy, the ceiling is bandwidth** | Too low ⟹ echo chamber (§53.1's detector); too high ⟹ locality lost, `O(R)` becomes `O(N)` |
| **Local/global traffic ratio** | ✅ | `[H]` + `[D]` | **V3 §2's «fast local + slower global signals» made quantitative: the ratio is set by the hardware's local/remote latency profile** | Inversion ⟹ the system is paying remote costs for local work |
| **Opaque traffic fraction** | ✅ **NEW — this contract adds it** | `[G]` | **§50.2's boundedness requires a bound. Derivation: the fraction above which aggregate observability stops being able to characterize what the population is doing** | Rising ⟹ §47 RH-2 precondition; **investigate, do not suppress (§50.3's evolvability requirement)** |
| **Inert message rate** | ⚠️ Observed, no target | — | **§6.2's INERT state. A high inert rate is a §51 specialization signal, not a defect** | — |
| **Refusal rate** (handshake consent refusals) | ✅ | — | **§20.2 R20.2: «a subject with an anomalous refusal rate is either attacking or being attacked»** | Anomaly ⟹ immune investigation |
| **Duplicate rate** | ✅ | — | **§32: a rising duplicate rate is either a transport fault or a replay attack** | ⟹ distinguish by `msg_id` vs `root_commit` duplication (§32.1's two mechanisms) |

## 54.2 «Avoid turning homeostasis into constitutional authority»

> ### **R54.1.** *Communication homeostasis is ALLOCATION within a ceiling. It holds P0-02 §7.4's negative authority: it acts first, within the envelope, and is retroactively vetoable. **It may not: define a ceiling (OP, RO-15) · enforce a ceiling (KC-3) · authorize an above-envelope connection (KC-2, RO-05) · alter a delivery semantic, a warrant rule, or a type class (policy, RO-13) · or delete a `mandatory_path`.***

```
THE THREE CONSTRAINTS THAT KEEP IT FAST AND KEEP IT BOUNDED:

1. **NEGATIVE AUTHORITY APPLIES ONLY TO REVERSIBLE ACTS** (P0-02 §7.4 R7.6).
   Homeostasis may shed S0/S1 traffic, throttle emission rates, and
   deprioritize routing — **all reversible**. It may NOT close a connection
   irreversibly, restore a quarantined subject, or change a policy.
   **⟹ an act homeostasis takes that turns out to be irreversible is a
     specification defect, detectable by EIK-INV-20's non-amplification
     check on its delegation scope.**

2. **EVERY ALLOCATION IS LOGGED WITH ATTRIBUTION** (P0-02 §18.3's X4
   defence). **Systematic self-favouring by the homeostasis service is
   measurable by EVA** — homeostasis is itself an evaluated subject at the
   ORGANISM level (P0-01 §25.1), and its fitness includes whether it
   allocates fairly.

3. **THE CEILING IS LOCAL AND PARTITION-SURVIVING** (P0-02 EIK-INV-31).
   **A homeostasis failure — including a homeostasis service that allocates
   nothing at all — does not remove the ceiling.** The system degrades
   toward its bounds rather than beyond them.
```

---

# §55. COMMUNICATION IMMUNITY — **OUTPUT 26**

## 55.1 «Can the immune subsystem do these things?» — the seven capabilities

| Capability | **Immune authority** | **Requires KC?** | **Mechanism** |
|---|---|---|---|
| **Block messages** | ✅ **Within budget** — from a flagged source, of a flagged pattern | ❌ for the act; ✅ for the budget ceiling | P0-02 §8.2's AC-1 ladder rung 1–2. **A block is reversible and local** |
| **Isolate senders** | ✅ **Within budget** | ❌ for the act | AC-1 rung 2–3 (soft/hard quarantine). **Cell §6.1's `quarantine_flags: [CellID]` — «peers whose output to discount» — is rung 0 and requires NO authority at all** |
| **Isolate routes** | ✅ **Within budget** | ❌ | Freeze a relay or a regional path. **`state → FROZEN` on the affected connections (§21.1's cheapest defensive act)** |
| **Quarantine protocols** | ⚠️ **A protocol is policy — immune may quarantine its USERS, not the protocol** | ✅ **RO-13 to change or suspend a protocol** | **§48.1: protocols are policy and are not immune to immune. An immune service that could suspend a message class would be a governance authority** |
| **Revoke connections** | ⚠️ **May propose; the Topology Service executes within envelope; KC-2 authorizes above envelope (RO-06)** | ✅ above envelope | §21.2. **Revocation of a `mandatory_path` is REFUSED permanently (§21.3's guard)** |
| **Suppress amplification** | ✅ **Within the influence-budget mechanism** | ❌ | §35.2's budget is the mechanism; immune may tighten a subject's allocation within it |
| **Restore previous topology** | ❌ **NEVER** | ✅ **RO-08, KC-2 sole authority, never cached, never delegated, never available during a KC outage** | **P0-02 §8.2's asymmetry (EIK-INV-44) applied to topology: quarantine may proceed under budget; restore may not.** *A topology restore reverses a safety action, so it must be the slowest and most-gated act available* |

## 55.2 «Avoid making immune another governance authority»

> ### **R55.1.** *P0-02 §8.2's three-way split applies to communication immunity verbatim, and the mapping is exact.*

```
DETECTION     any subject, any service, any cell report — **UNRESTRICTED**.
              Communication anomaly detectors: refusal-rate divergence ·
              duplicate-rate divergence · opaque-volume clustering ·
              root-overlap concentration · degree/betweenness concentration ·
              confidence-rising-with-flat-n_effective (§53.1) ·
              zero-error-at-high-activity (§47 RH-4).
              ⟹ **Detection must be cheap and permissive, because a detector
                 that requires authorization to look is not a detector.**

ADJUDICATION  the Immune Service (GP), under a KC-3 budget ceiling, with
              typed evidence, bounded duration, and the AC-1 graduated
              ladder (DISCOUNT → SOFT → HARD → propose-kill).
              **The detector may not adjudicate its own detections (AC-3).**
              ⟹ **§67's #14/#15/#17/#18 are detected by cells and regions
                 and adjudicated by the Immune Service, never by the
                 detector.**

CLEARANCE     EVA retest (alethic) + KC-2 authorization (RO-08).
              **The adjudicator may not clear its own quarantines.**

PLUS THE FIVE STRUCTURAL CONTROLS (P0-02 AC-1…AC-5), ALL OF WHICH APPLY:
  AC-1 graduated ladder      ⟹ discount before isolate before revoke
  AC-2 bounded duration      ⟹ a communication quarantine expires
  AC-3 detector ≠ adjudicator
  AC-4 rate/confirmation divergence monitored ⟹ **the cascade signature:
       many quarantines, few confirmed defects**
  AC-5 **freeze the freezer** ⟹ **KC-4 at scope = immune-service. P0-02
       R43.1: KC-4's scope enumeration MUST include GP services, and the
       Immune Service is one.** An immune system that cannot be stopped is
       an unbounded destructive authority with a positive feedback loop.

⟹ **AND THE COMMUNICATION-SPECIFIC ADDITION:**
   **AC-6 (new): immune signatures on communication patterns EXPIRE.**
   P0-01 R38.3 / CD-9: «Without expiry this cycle is strictly monotone
   toward total rejection.» **A permanent immune signature against a
   communication pattern permanently forbids a region of protocol space —
   and protocol space is where §49/§50's evolutionary innovation happens.**
   ⟹ **Expiry scales with severity; `EXISTENTIAL` never expires
      (P0-01 P-41's schedule). A communication-pattern signature that never
      expires is an autoimmune disease against novelty.**
```

---

# §56. HARDWARE ADAPTATION — **OUTPUT 29 (part 1)**

## 56.1 Communication across the eight hardware classes

| Platform | **What changes** | **What must NOT change** |
|---|---|---|
| **Single device** | Everything is local; no relay; region = device | Type registry · warrant rules · class→mechanism mapping · delivery semantics per class |
| **Multi-core CPU** | Region = core or socket; channel = shared-memory queue | Same |
| **GPU** | **Region = kernel launch; S0 becomes a tensor operation rather than a message.** **Latency is batch-dominated, not distance-dominated** | Same — **and this is the hardest case, because S0's semantics must survive being implemented as a matrix multiply** |
| **NPU** | Fixed-function acceleration; limited control flow; **S0 only, or S0+S1 with heavy batching** | Same |
| **Distributed cluster** | Region = node; relay = network; **drift bounds become meaningful (§9.2)** | Same |
| **Heterogeneous** | Mixed classes; **`corr_class` dim 5 becomes non-trivial** | Same |
| **Intermittent** | **§30's partition protocol is the NORMAL operating mode, not the exceptional one** | Same — **and P0-02 §26's finding applies: partition is normal, so R30.2's invariant must hold routinely** |
| **Low-bandwidth** | Aggressive payload compression; **larger epochs** (fewer Tier-3 anchors); more S0, fewer S2 | Same — **and §63.3's rule binds: compression may be lossy on payload, never on warrant** |

## 56.2 «Which communication semantics must remain invariant across hardware?»

> ### **R56.1 — the semantic invariant set (Output 29's core).**

```
INVARIANT ACROSS ALL HARDWARE (the SEMANTIC CONTRACT):
  1. The three planes and R0.3's four prohibited shortcuts
  2. The type registry and the class→mechanism mapping (§2.4 R2.2)
  3. The five classes S0–S4 and their warrant properties (§72)
  4. §5.1's eight delivery meanings and §6.2's lifecycle states
  5. §7.2's per-class delivery semantics
  6. §8.1 R8.1's three ordering mechanisms and the rejection of vector clocks
  7. §9.2's four time rules (a timestamp is never evidence)
  8. §13.4's warrant recomputation inputs
  9. §14.3's six correlation dimensions and R37.1's UNKNOWN-is-not-disjoint
 10. §15.3's three provenance tiers (the TIER BOUNDARIES may move; the
     three-tier structure may not)
 11. §16.3's four laundering closures and COMM-INV-08's root inheritance
 12. §17.1's six-way trust separation
 13. §19.2 R19.2's plasticity boundary
 14. §40.1's nine structural differences between a recommendation and a
     governance command
 15. §49.2's OPAQUE class properties

VARIABLE ACROSS HARDWARE (the TRANSPORT IMPLEMENTATION):
  • framing bytes, serialization, endianness handling at the wire
  • channel binding mechanism (shared memory · socket · RDMA · tensor op)
  • region size, relay count, hop cost
  • latency, bandwidth, drift bounds
  • **S0's implementation: a message, a queue entry, or a tensor slice**
  • batch size, epoch length (within policy bounds)
  • compression algorithm (payload only)
  • dedup cache implementation (bloom · exact · hardware-assisted)

⟹ **R56.2 («a signal should retain its meaning even if transport changes"):**
   meaning is carried by items 1–15, all of which are POLICY artifacts
   authenticated by KC-1 (P0-02 Channel 1) and therefore not writable by any
   hardware adaptation layer. **A hardware port that changes meaning has
   changed policy, and changing policy is RO-13.** ⟹ **The invariance is
   enforced by authority, not by discipline.**
```

---

# §57. NETWORK-TOPOLOGY / HARDWARE CO-DESIGN — **OUTPUT 29 (part 2)**

## 57.1 «Could the brain evolve different connectivity based on hardware?»

> ### **Yes — and it must, because a topology optimized for one latency profile is pathological on another. The question is what it may not change.**

```
WHAT MAY ADAPT TO HARDWARE:
  • region size (a region IS a low-latency domain — §26.2)
  • relay count and hierarchy depth
  • shortcut density (bounded by the diameter target)
  • degree distribution within caps
  • local/global traffic ratio (§54.1)
  • batch size and epoch length
  • S0's implementation form (message vs tensor op)
  • **whether a "connection" is a persistent edge or an index into a weight
    matrix** — on a GPU, the second is the only feasible form, and §56.2
    item 15 permits it because the SEMANTICS (a directed, typed, bounded,
    consented relationship with a lifecycle) are preserved

WHAT MAY NOT ADAPT:
  • §56.2's fifteen semantic invariants
  • the warrant class of any type
  • the correlation dimensions
  • the influence-budget RULE (its VALUE is `[H]`; its EXISTENCE is `[D]`)
  • `mandatory_path` designations
  • the reserved-operation set
```

## 57.2 «How do we prevent hardware-specific optimization from changing cognitive semantics?»

> ### **Three mechanisms, and the third is the one that makes it a contract rather than a hope.**

```
1. **AUTHORITY.** Semantic invariants live in POLICY artifacts authenticated
   by KC-1. **A hardware adaptation layer has no write path to policy
   (P0-02 EIK-INV-02, EIK-INV-24).** ⟹ Hardware may parameterize; it may
   not re-specify. **This is R56.2's enforcement.**

2. **THE ABSOLUTE REFERENCE PLATFORM.** P0-01 §30.1 item 3 + CD-7's closure:
   «Normalizing against 'the current profile' is circular; normalizing
   against a fixed declared platform is not.» ⟹ **Fitness comparisons across
   hardware are made against a declared absolute platform, so a
   hardware-specific optimization that improves local performance but
   degrades normalized fitness is VISIBLE rather than rewarded.**

3. **⟵ THE DECISIVE ONE: SEMANTIC BEHAVIOUR IS TESTABLE INDEPENDENTLY OF
   TRANSPORT.** §90's conformance suite includes **T-REPR: the same
   scenario, run on two hardware classes, must produce the same WARRANT
   outcomes** — the same messages LICENSED-AS-EVIDENCE, the same
   `n_effective`, the same DISPUTED flags, the same class assignments.
   **Transport statistics (latency, throughput, hop count) may differ
   arbitrarily. Warrant outcomes may not differ at all.**

   ⟹ **R57.1: hardware invariance is not a design intention; it is a
      conformance test with a pass/fail criterion.** Two teams on two
      platforms run the same scenario and must agree on every warrant
      outcome. **§89's implementation-independence test is the same test
      applied across implementations rather than across hardware — and
      R57.1 is why the two tests are the same test.**

THE RESIDUE, DECLARED:
  A hardware class that cannot implement a semantic invariant is not a
  portability problem; it is an inadmissible platform. **P0-01 F-IMP-2
  already found that no single-platform deployment satisfies the evaluation
  contract; P0-02 G-P02-5 found the same for KC-3 enforcement. This package
  adds the communication instance:**
  ⟹ **G-P03-5: a platform that cannot enforce a per-subject influence budget
     below the organism's reach cannot host S2+ traffic, because §35's
     cascade defence has no enforcement point.** Such a platform is
     restricted to S0/S1 and must be declared as such.
```

---

# §58. COMMUNICATION SECURITY — **OUTPUT 19**

## 58.1 The twelve threats, classified

**«Do not put every security mechanism inside EIK.»** The classification below puts **two** mechanisms in KC and **ten** elsewhere.

| Threat | **Level** | Defence | **In KC?** |
|---|---|---|---|
| **Spoofing** (`source = trusted_cell`) | **Cell + Transport** | §33.1: `src` DERIVED FROM CHANNEL BINDING, never read from payload; S3/S4 signatures; birth-certificate chain (Cell §6.3 case 7) | ❌ **KC-1 authenticates the delegation that makes channel binding possible; it does not verify messages** |
| **Replay** | **Transport** | §32.2's four mechanisms: `msg_id` dedup · `seq` per (channel, epoch) · epoch binding · **dedup retention ≥ 2 epochs, permanent for S3/S4** | ❌ Epoch issuance is governance; enforcement is local |
| **Tampering** | **Transport** (integrity) / **Organism** (content) | Channel MAC (S1/S2) · signature (S3/S4) · **`root_commit` resolution against the anchored registry** | ❌ |
| **Flooding** | **Organism** (primary) + **KC-3** (backstop) | §34.2's five-principal split: cell token bucket → circuit shedding → regional admission → homeostatic allocation → **KC-3 ceiling** | ⚠️ **KC-3 only — the ceiling, not the adjudication** |
| **Routing manipulation** | **Organism** (control plane) | §24.2: the admissible set is infrastructure, not learnable; `mandatory_path` always admissible with a policy floor on selection weight | ⚠️ **KC-2 authorizes above-envelope topology changes (RO-05/06)** |
| **Identity cloning** | **Cell + Registrar** | P0-02: Registrars issue under KC-1 delegation; `cell_id` permanent and never reused; **a compromised key «can act before retirement propagates» (P0-02 §19's HIGH rating) ⟹ bounded by epoch-scoped revocation lists (R19.3)** | ⚠️ **KC-1 holds the root and the delegation certs; it does not issue or check identities per-message** |
| **Connection hijacking** | **Transport** | §20.2's three-party handshake (**consent is the defence**: «Refusal is recorded and is NOT an error») · session keys epoch-bound · refusal-rate observability (R20.2) | ❌ |
| **Protocol confusion** | **Structural** | §39.2's three framings; **the handler rejects on FRAMING before reading content**; R12.1's no-downgrade rule | ❌ **Type-level impossibility** |
| **Provenance stripping** | **Structural** | R12.1: an S2+ message missing `root_commit` is MALFORMED, **never downgraded**; §16.3's L1–L4 closures | ❌ |
| **Metadata forgery** | **Transport + Warrant** | `prio` derived from type (not forgeable) · `calib_ref` is a pointer to an externally-assigned record (not forgeable) · `trust_out_assigned` read-only · `corr_class` digest (forgeable in principle, but forging it *downward* — claiming more independence — is detectable against the anchored registry) | ❌ |
| **Timing manipulation** | **Structural** | **§9.2 Rule 1: a message's own timestamp is never evidence.** Order comes from `seq` and `epoch`. **⟹ Timing manipulation buys nothing, because timing is not an input to any decision** | ❌ |
| **Side-channel inference** | ❌ **UNRESOLVED** | §59's compartmentalization is a **partial** mitigation: limiting what a subject can observe limits what it can infer | ❌ **P0-02 §36.3 reason 3: side channels are a demonstrated, recurring break class. §91 OR-C8** |

## 58.2 **OUTPUT 19 — the security model**

```
THE MODEL IN ONE PARAGRAPH:

  Attribution is established by CHANNEL BINDING and, for S3/S4, by
  SIGNATURE — never by a payload-declared source. Freshness is established
  by SEQ and EPOCH — never by a timestamp. Integrity is established by
  channel MAC or signature for the envelope, and by ROOT-COMMIT RESOLUTION
  against the anchored registry for the warrant content. Authorization is
  established by CLASS, which is TYPE-determined, which is POLICY-owned.
  Amplification is bounded by INFLUENCE BUDGETS and the LOOP-GAIN
  CONSTRAINT. Propagation is bounded by TTL and by the admissible-route set.
  Detection is unrestricted; adjudication is budgeted; clearance is
  external.

THE DISTRIBUTION OF MECHANISMS (and it is the point of the section):
  STRUCTURAL (type-level impossibility, no runtime check)  : 5 threats
  CELL-LOCAL (token bucket, dedup, ingress S1a)             : 3
  ORGANISM/GP (topology, immune, homeostasis, memory)       : 3
  KC (ceilings, above-envelope authorization, epoch issuance): 2 (backstop only)
  UNRESOLVED                                                : 1 (side channels)

⟹ **R58.1: KC is a BACKSTOP, not a security mechanism.** Every threat whose
   defence is "KC checks it" is a threat whose defence costs `O(events)` in
   the TCB — and P0-02 §27.2 showed where that leads. **The five structural
   closures cost nothing at runtime and cannot be misconfigured, which is
   why §67's structurally-solved attacks are the most valuable results in
   the suite.**

⟹ **R58.2 (THE HONEST BOUND).** *This model defends against a compromised
   CELL. It defends partially against a compromised REGION or GP SERVICE
   (blast radius bounded by delegation and hierarchy). **It does not defend
   against a compromised OP (P0-02 G24, unsolvable), a compromised root key
   (§10.3's total re-baseline), a compromised hardware vendor (OR-3), or a
   shared latent assumption (dim 6, §37.2).*** **Each is named, and none is
   claimed closed.**
```

---

# §59. PRIVACY / INFORMATION BOUNDARIES

## 59.1 The three-way tension

```
        TRANSPARENCY (auditability)
              /            \
             /              \
   PRIVACY ──────────────────── CONNECTIVITY
 (specialization)          (collective intelligence)

  • Full transparency  ⟹ no private models ⟹ **no differentiation ⟹ no
                          specialization (§51's beneficial loop dies)**
  • Full privacy       ⟹ no auditability ⟹ **P0-02 EIK-INV-53's
                          observability requirement fails; the organism
                          becomes ungovernable**
  • Full connectivity  ⟹ `O(N²)` (§26) ⟹ **and echo chambers become
                          impossible only because everything is one chamber**
```

## 59.2 The resolution — auditability without readability

> ### **R59.1.** *Warrant metadata is public and auditable. Payload is compartmentalized. The distinction is what makes both properties achievable.*

| Layer | **Visible to** | Content |
|---|---|---|
| **Warrant metadata** (`type`, `root_commit`, `causal_depth`, `calib_ref`, `corr_class`, `seq`, `epoch`, class, size, dst-class, lifecycle outcome) | **EVA, OP, immune, audit — fully** | `O(1)` per message. **Sufficient to answer every governance question: who claimed what kind of thing, on what roots, at what derivation depth, with what correlation, and what happened to it** |
| **Payload** | **The addressed receiver(s); the compartment (§59.3); EVA under sampling** | **Not globally readable.** §86's observability budget is spent on metadata, not payload |
| **Internal state** (`θ`, eligibility traces, working memory) | **The cell; the auditor under Cell Contract's inspectability rule** | Cell §2.4: «All are typed, bounded, serializable, and **inspectable by the EIK** (no opaque state). Opacity would defeat auditing» — **preserved, with «the EIK» corrected to «the auditor/EVA under sampling» per P0-02 R8.7** |
| **Aggregate statistics** | **Regional and organism observability** | `O(R)` per epoch |

**R59.2 (WHY THIS IS NOT A COMPROMISE).** *Auditability requires knowing **what was claimed and on what basis**; it does not require knowing **the internal representation in which it was claimed**.* **A cell whose payload is private but whose warrant metadata is public is fully auditable for every question P0-02's reserved set asks** — and §50.2's opaque-traffic auditing works on exactly this principle: «an auditor can reconstruct WHO communicated with WHOM, HOW MUCH, and WHEN — without knowing WHAT».

## 59.3 The six compartmentalization mechanisms

| Mechanism | Form | **Cost of excess** |
|---|---|---|
| **Compartmentalization** | Regional and module boundaries; `BroadcastScope ∈ {NEIGHBORHOOD, CIRCUIT, REGION}` — **ORGANISM and GLOBAL prohibited by construction (R23.1)** | **Excessive ⟹ §53's echo chambers** |
| **Least privilege** | §22.1's locality rule: no function may require global topology. **A cell knows `O(degree)` neighbors and one relay pointer** | Excessive ⟹ fragmentation, slow convergence |
| **Selective disclosure** | **Payload disclosed on request to an authorized requester; warrant metadata disclosed always** | Excessive ⟹ auditability loss |
| **Local memory** | Cell §8's bounded working memory; **eviction with `capability_critical` exemption** | Excessive ⟹ catastrophic forgetting (Cell §8's defence exists for this) |
| **Regional boundaries** | Rate limits on cross-region traffic, **especially OPAQUE (§50.2)** | Excessive ⟹ private languages become undetectable coalitions (§47 RH-2) |
| **Privileged channels** | Framing C for S3/S4; `mandatory_path` edges | Excessive ⟹ the privileged set grows and §7.2's cost model fails |

## 59.4 «Could excessive transparency destroy useful specialization? Could excessive isolation destroy intelligence?»

> ### **Both yes, and the balance is a measurable operating point rather than a design constant.**

```
EXCESSIVE TRANSPARENCY DESTROYS SPECIALIZATION:
  A specialist's value is its private model. **If every internal
  representation is readable by every peer, then a peer can replicate the
  specialist's function without the specialist** — and §51's demand-driven
  specialization loop has no payoff, because the reward for specializing is
  immediately competed away.
  ⟹ **Payload privacy is not a concession to realism; it is the mechanism
     that makes specialization economically stable.**

EXCESSIVE ISOLATION DESTROYS COLLECTIVE INTELLIGENCE:
  A module that receives nothing external cannot be contradicted (§30.3,
  §53.1). **Its confidence rises while its n_effective stays flat, and it
  becomes locally coherent and globally wrong.**
  ⟹ **§53.2's reserved cross-region channel capacity is the floor.**

THE BALANCE IS MEASURED, NOT FIXED:
  • cross-region traffic ratio (§54.1) — too low ⟹ isolation
  • root-overlap concentration within modules (§53.1) — too high ⟹ chamber
  • confidence-vs-n_effective divergence (§53.1 R53.1) — the chamber detector
  • opaque traffic fraction (§54.1) — rising ⟹ isolation or coalition
  ⟹ **All four are `O(R)` per-epoch observables, and all four are
     homeostatic RANGES with `[G]`/`[D]` owners (§54.1), not constants.**

⟹ **R59.3: the privacy/connectivity balance is a controlled variable with
   four measured indicators, and its setpoints are governance parameters
   whose derivation is declared. It is not resolved by choosing a side.**
```

---

# §60. FAILURE RECOVERY

## 60.1 The nine recovery cases

| Failure | **Communication state is…** | Mechanism | **Authority** |
|---|---|---|---|
| **Cell death** | **RECONSTRUCTED by neighbors** | Heartbeat absence (§7.2: «a missed heartbeat is the signal») ⟹ routes marked inadmissible ⟹ **dependents NOTIFIED (§21.3 R21.3)** ⟹ circuit reroutes within the admissible set | Local + Topology Service |
| **Connection loss** | **REGENERATED** | `state → DEGRADED → DRAINING → CLOSED`; **the record is retained** (Cell §14.4 step 7); re-creation requires the full handshake (§20.2) | Endpoints + Topology Service |
| **Region failure** | **RECONSTRUCTED from the anchored registry** | Regional Merkle root (Tier 3) ⟹ the region's topology and epoch state are recoverable; **subjects are re-registered from lineage certificates** | Registrar + Anchor |
| **Network partition** | **BOTH SIDES CONTINUE; reconciled per §31.5** | §30.2's matrix; §31's four operators | Automatic + EVA + KC-2 |
| **Corrupted routing state** | **RECONSTRUCTED from the anchored digest** | Regional registry root disagreement ⟹ detected (P0-02 §10.1 P3) ⟹ rebuild from the last anchored root | Topology Service + Anchor |
| **Corrupted message** | **NOT RECOVERED — the artifact is PRESERVED** | Cell §6.3 case 6: «Drop; quarantine-candidate the source; **preserve the corrupt artifact as evidence (do NOT discard — audit §B.11)**» | Receiver + Immune |
| **Protocol mismatch** (`schema_version`) | **REJECTED, not recovered** | S1a: unresolvable `TypeRef` ⟹ MALFORMED. **R12.1: never downgraded** | Receiver |
| **Policy mismatch** (`policy_version_ref`) | **REJECTED to the last authenticated version** | P0-02 §6.2: «Policy artifact invalid ⟹ `FC` to the last authenticated version» | KC-1 |
| **Hardware migration** | **RE-BOUND, semantics preserved** | §56.2: addresses are reassignable (R23.1); **`cell_id` references are unaffected (R23.3)**; transport re-binds; **T-REPR conformance test must pass (§57.2 R57.1)** | Platform + conformance |

## 60.2 «Reconstructed, checkpointed, replicated, regenerated, or evolved again?»

> ### **R60.1 — all five, and each has a specific domain.**

| Mechanism | **Applies to** | **Why not the others** |
|---|---|---|
| **RECONSTRUCTED** | Topology registries · routing state · regional epoch state | From the anchored Merkle roots. **Not checkpointed wholesale** — a full topology checkpoint is `O(edges)` and §26.2 forbids it |
| **CHECKPOINTED** | The anchored epoch digests themselves · policy versions · delegation tables | **P0-02 §47.1: the organism may trigger `RESTORE(signed_image_hash)` but may never supply the payload (EIK-INV-41 — repair without authorship)** |
| **REPLICATED** | Provenance anchors (`W_min` witnesses, ≥1 external) · KC (`N_impl ≥ 3`) | **P0-02 §10.2: replication without diversity is a delay, not a defence** |
| **REGENERATED** | Individual connections · session keys · channel bindings · ephemeral addresses | **Cheap, local, and requires no coordination. A lost channel is re-established by handshake, not restored from backup** |
| **EVOLVED AGAIN** | **Topology PRIORS after a catastrophic regional loss** | **§48.2: priors are heritable, specific edges are not.** A region that lost everything re-develops its wiring from its genome's priors — **which is not a recovery failure but the designed behaviour, and it is why R48.1's heritability split matters operationally** |

---

# §61. CHECKPOINT / REPLAY

## 61.1 «What communication history must be retained?» — by purpose

| Purpose | **Minimum sufficient record** | Retention |
|---|---|---|
| **Debugging** | Tier-2 local event log: `(msg_id, type, channel, seq, epoch, root_commit, causal_depth, dst-class, lifecycle outcome, cost_measured)` — **NOT payloads (§59.2)** | Bounded window, `[D]` |
| **Reproducibility** | **The archived policy version + the anchored inputs + the epoch sequence.** P0-02 EIK-INV-50: «re-execution under current policy is not reproduction» ⟹ **reproduction requires the historical policy, which is why the lineage is retained permanently (P0-02 §7.2 R7.2: RETAINED is a record property, not a state)** | **Permanent for policy; windowed for traffic** |
| **Learning** | **Nothing beyond the local eligibility trace.** §46.3: credit is computed locally, never transmitted. **A learning subsystem that needs message history to assign credit has the wrong credit mechanism** | Local, λ-decayed |
| **Rollback** | **The anchored checkpoint image hash + the topology registry root + the epoch counter.** P0-02 §21's RB-1…RB-5: rollback is **rate-bounded, not total**; RB-2 records rollback cost at replication time | Per rollback window |
| **Evaluation** | **The warrant metadata of sampled messages + the anchored root registry.** EVA samples per P0-01's β strata; **it does not read all traffic (§62)** | Anchored, permanent for sampled sets |
| **Evolutionary analysis** | **Lineage certificates + topology priors + fork events (§31.3's FORK operator) + the anchored epoch digests** | **Permanent — descent is the object of study** |

## 61.2 The six record forms

| Form | Content | Volume | **Verdict** |
|---|---|---|---|
| **Raw logs** (every message, full payload) | Everything | **`O(messages × payload)`** | ❌ **PROHIBITED.** §86: at 10⁹–10¹² subjects this exceeds every other cost in the system combined |
| **Compressed logs** (metadata only) | Tier-2's tuple | `O(messages)` local, **zero network** | ✅ **ADOPTED as the local record** |
| **Provenance anchors** | Epoch Merkle roots + root registry | **`O(R)` per epoch** | ✅ **ADOPTED (Tier 3)** |
| **Summaries** | Regional traffic digests: volume by class, degree distribution, opaque fraction, refusal rate, duplicate rate, root-overlap concentration | **`O(R)` per epoch** | ✅ **ADOPTED — and this is what P0-02 §42.3's workspace digest pattern generalizes to** |
| **Checkpoints** | Signed image hashes + registry roots | `O(R)` per checkpoint | ✅ **ADOPTED** |
| **Sampled traces** | Full payload for a **sampled** subset, per P0-01's β strata | `O(B)` where `B` is the evaluation budget | ✅ **ADOPTED — the only form in which payloads are retained, and P0-01 R34.1 makes the sampling policy EVA-owned and unreachable by the organism** |

**R61.1 (THE MINIMUM SUFFICIENT RECORD).** *Tier-2 metadata for a bounded window + Tier-3 anchored digests and root registry permanently + EVA-sampled payloads per the β strata + permanent policy lineage.* **⟹ This supports every purpose in §61.1 at `O(messages)` local and `O(R + B)` networked — and it does NOT support arbitrary retrospective payload inspection, which is §86's declared trade.**

**R61.2 (THE ONE THING THAT MAY NEVER BE DISCARDED).** *The `msg_id` dedup set for at least two epochs, and permanently for S3/S4 (§32.2 R32.1).* **Discarding it reopens the replay window, and a bounded cache that evicts by recency evicts exactly what a patient attacker replays.**

---

# §62. COMMUNICATION OBSERVABILITY

## 62.1 «What can an external evaluator observe?»

| Option | Cost | **Verdict** |
|---|---|---|
| **All messages** | `O(messages × payload)` | ❌ **Infeasible (§61.2) and unnecessary** |
| **Sampled messages** | `O(B)` | ✅ **P0-01's β strata: β₁ mandatory · β₂ risk-weighted · β₃ information-seeking · β₄ random audit (the anti-gaming stratum) · β₅ real-world anchor. Sampling policy is EVA-owned and unreachable (R34.1)** |
| **Aggregate statistics** | `O(R)` per epoch | ✅ **The primary observability channel** |
| **Provenance graph** | `O(R)` roots per epoch; **exact reconstruction `O(log)` per query** | ✅ Anchored |
| **Causal traces** | `O(path)` off-line from Tier-2 | ✅ **Retrospective only (§10.2's division rule)** |
| **Selected critical paths** | `O(mandatory_paths)` | ✅ **`mandatory_path` edges are fully observable — they are few, they are policy-designated, and they are the paths where a communication failure is a safety failure** |

## 62.2 The observability budget, allocated by purpose

**«Determine what must be observable for safety, evaluation, debugging, provenance, and scientific analysis — and what can remain unobserved.»**

| Purpose | **Must be observable** | **May remain unobserved** |
|---|---|---|
| **SAFETY** | `mandatory_path` traffic (full) · S3/S4 (full) · influence-budget exhaustion events · loop-gain violations · cascade signatures (aggregate gain propagation) · **zero-error-at-high-activity (§47 R47.1)** · **confidence-rising-with-flat-`n_effective` (§53.1 R53.1)** · refusal-rate anomalies · opaque-fraction trends | S0/S1 payloads · individual local gain values |
| **EVALUATION** | Sampled warrant metadata per β strata · aggregate class distributions · `n_effective` per aggregate · DISPUTED flags · inert rates | Unsampled payloads |
| **DEBUGGING** | Tier-2 metadata within the window · lifecycle outcome states (§6.2) · failure codes (`E_IN_*`, `E_OUT_*`) | Payloads outside the sample |
| **PROVENANCE** | The anchored root registry · epoch digests · lineage certificates · policy lineage | Intermediate transform payloads |
| **SCIENTIFIC ANALYSIS** | Everything above, permanently, for the sampled sets · fork events · topology prior evolution | — |

**R62.1 (THE OBSERVABILITY PRINCIPLE).** *Spend the budget on WARRANT metadata and on ABSENCES, not on payloads.* **§5.3 established that state 8 (WARRANTED) is observable by nobody at the time it happens, so its audit must be external and retrospective — and the metadata needed for that audit is `O(1)` per message while the payload is not.** **And the two absence-detectors (R47.1's zero-error, R53.1's flat-`n_effective`) are the highest-value observables in the contract, because each detects a pathology that produces no positive signal at all.** ⟵ *P0-02 EIK-INV-53's full-observability-toward-OP requirement is satisfied by these, not by volume.*

---

# §63. INFORMATION-THEORETIC ANALYSIS

**«Do not add information theory merely for terminology. Use it to answer concrete architectural questions.»** Four questions, four answers.

## 63.1 «What is the minimum communication required for two cells to coordinate?»

```
SETUP: cells A and B must choose compatible actions. A has state x_A, B has
x_B. Coordination succeeds iff their actions are compatible given (x_A, x_B).

IF A AND B SHARE NO CONTEXT:
  A must transmit enough to let B determine the compatible action set.
  Minimum = H(action | x_B) − H(action | x_B, m)  bits, where m is the
  message. **In the worst case this is the full entropy of A's relevant
  state.**

IF A AND B SHARE A CONTEXT C (a policy, a type registry, a common
objective reference):
  Minimum = H(action | x_B, C) − H(action | x_B, C, m)
  **⟹ the shared context reduces the required transmission by exactly the
    amount of redundancy it absorbs.**

⟹ **THE ARCHITECTURAL ANSWER, AND IT JUSTIFIES A DESIGN CHOICE THAT WOULD
   OTHERWISE LOOK ARBITRARY:**

   **THE CLOSED TYPE REGISTRY (§11.2) IS A SHARED-CONTEXT COMPRESSION
   SCHEME.** By fixing 14 types × 5 classes in a policy artifact that every
   participant holds, the contract moves O(log |types|) bits of per-message
   information OUT of the message and INTO the shared context. Same for:
   unit and domain conventions (§12.2) · representation (§12.2) · the
   class→mechanism mapping (§2.4) · the delivery semantics (§7.2) · the
   failure-response matrix (§6.2).

   **A message therefore needs to carry only what is NOT shared: the
   payload, the identity, the order, and the warrant pointers.** ⟹ **This is
   an independent derivation of §4.3's eleven-field S2 envelope from
   information theory, and it explains why every one of the eleven is
   non-redundant with the shared context.**

   **THE COST OF THE SCHEME, ALSO DERIVED:** a closed registry cannot express
   a novel type, so the residue is `OPAQUE` — **which pays full price,
   because an opaque pattern carries no shared-context discount.** §49's
   escape hatch is therefore not free: **novelty costs bandwidth, and that
   cost is the mechanism by which §51's specialization economics rewards
   registering a pattern rather than keeping it private.**
```

## 63.2 «When is redundancy useful?»

> ### **When it is on the transport plane. It is harmful on the warrant plane. The same act has opposite value on the two planes — and this is the sharpest information-theoretic result in the package.**

```
TRANSPORT REDUNDANCY (retransmission, FEC, duplicate paths):
  Value = P(loss) × cost(loss) − cost(redundancy).
  **Useful when the channel error rate × the consequence of loss exceeds
    the cost of the extra transmission.** ⟹ §7.2's class assignment is
  exactly this calculation: S3/S4 (high consequence) get retry-until-
  confirmed; S0 (no consequence) gets best-effort.

WARRANT REDUNDANCY (the same evidence arriving twice):
  Value = **NEGATIVE.**
  **Two copies of one observation carry H(observation) bits, not 2·H.**
  Counting them twice does not double the information; it doubles the
  CONFIDENCE WITHOUT DOUBLING THE INFORMATION — which is the definition of
  overconfidence, and it is §14's attack.

⟹ **R63.1: redundancy is a transport resource and a warrant hazard. The
   architecture must therefore be able to distinguish "the same content
   sent twice" (transport redundancy — good) from "the same evidence cited
   twice" (warrant redundancy — bad), and the two look identical at the
   payload level.**

⟹ **THE DISTINGUISHING MECHANISM IS §32.1's TWO DEDUPS:**
     same `msg_id`      ⟹ transport duplicate ⟹ DROP, count, retain
     same `root_commit` ⟹ warrant duplicate   ⟹ **ADMIT both messages,
                          but do not double-count the evidence (§14.4's
                          `n_effective`)**
   **A single dedup mechanism cannot implement both, and the Cell Contract
   had only the first.** ⟵ *This is §0.2's class of defect: one mechanism
   asked to do two jobs whose correct behaviours differ.*
```

## 63.3 «When does compression destroy information necessary for provenance or learning?»

> ### **When it is lossy on the warrant dimensions. The rule is dimension-selective compression.**

```
THE DECOMPOSITION: a message's information content splits into
  PAYLOAD information      — what is being said
  WARRANT information      — what licenses belief in it
  TRANSPORT information    — how it got here

COMPRESSION MAY BE LOSSY ON:
  ✅ payload      ⟹ §56.1's low-bandwidth adaptation; §48.2's heritable
                    compression strategies operate here
  ✅ transport    ⟹ aggregate telemetry instead of per-message ACKs (§7.4)

COMPRESSION MUST BE LOSSLESS ON:
  ❌ **warrant — but "lossless" here has a precise meaning: lossless on
     MEMBERSHIP, not on ENUMERATION.**

     `root_commit` is a Merkle commitment: it DISCARDS the enumeration of
     the root set (lossy) and PRESERVES the ability to prove membership of
     any specific root (lossless on the property that matters).
     **⟹ The warrant property that compression must preserve is "can this
       root be shown to be in or out of this set?" — and a commitment
       preserves exactly that, at O(1) instead of O(|set|).**

     `causal_depth` DISCARDS the ancestry (lossy) and PRESERVES the
     monotonicity test (lossless on the property that COMM-INV-08 needs).

     `corr_class` DISCARDS the correlation details (lossy) and PRESERVES the
     dimension-wise disjointness test (lossless on what §14.4 needs).

⟹ **R63.2 (THE COMPRESSION RULE).** *Every compression in this contract is
   dimension-selective: it preserves the DECISION PROPERTY and discards the
   RECONSTRUCTION DETAIL. Where reconstruction is needed, it is performed
   off-line from the anchored log (§10.2, §61).*

⟹ **AND THE FAILURE MODE IT PREVENTS:** a compression that is lossy on a
   decision property produces a message whose warrant cannot be recomputed
   (§13.4), which means the receiver must either trust the sender (R0.4
   violation) or refuse the message. **§0.2's `evidence_roots[]` array was
   uncompressed; the tempting "fix" of dropping roots entirely would be
   lossy on a decision property. The commitment is the third option, and
   R63.2 is why it is correct.**
```

## 63.4 Bottlenecks, entropy, and the workspace

```
CHANNEL CAPACITY: the binding constraint on a region's communication is
  min(bandwidth, Σ receiver ingress capacity, relay throughput). **All three
  are metered (§27.1) and all three are ceiling-bounded (KC-3).**

ENTROPY AND THE TYPE REGISTRY: §63.1 showed the registry absorbs shared
  entropy. **The residual per-message entropy is therefore close to the
  payload's conditional entropy — which means the envelope overhead is
  small relative to a well-designed payload, and §71's minimality analysis
  confirms it: 11 fields for S2, 5 for S0.**

SNR: **the "noise" in this architecture is not channel noise — it is
  warrant-defective traffic**: duplicates, conflated evidence, correlated
  sources, over-derived claims. **§14's `n_effective` IS the signal-to-noise
  ratio of an aggregate**, and R37.2's rule (a million dim-UNKNOWN messages
  contribute `n_effective = 1` on that dimension) is the SNR calculation
  made explicit. **⟹ A high-volume, low-`n_effective` population has a poor
  epistemic SNR regardless of its channel quality** — and that is a
  measurable, `O(R)`-per-epoch observable (§62.2).

THE WORKSPACE AS A DELIBERATE BOTTLENECK:
  **A bottleneck is information-theoretically optimal when the downstream
  consumer's capacity is the binding constraint.** The workspace's consumers
  are {Memory, Critics, Planners, Regulators} (V3.1 §2) — a small set with
  bounded processing capacity. **Broadcasting everything to them would
  exceed their capacity and destroy the value of what they do receive.**
  ⟹ §43.3's hard capacity limit is a RATE-DISTORTION constraint, and the
    distortion measure is **task-relevance, not MSE**.
  ⟹ **AND THE CONSEQUENCE, WHICH IS A GOVERNANCE FACT: the task-relevance
    distortion measure is not locally computable.** It depends on active
    goals, which are policy/task-owned. **⟹ the workspace admission
    criterion is a POLICY quantity (§43.3), which is why §44 forbids
    attention from becoming authority: the gate applies a policy criterion,
    it does not exercise judgement.**
```

---

# §64. COMPUTATIONAL COMPLEXITY

## 64.1 Per level, per operation

| Operation | **Cell** | **Circuit** | **Region** | **Organism** | **Justification if `O(N)` or worse** |
|---|---|---|---|---|---|
| Emit an S0 signal | `O(1)` | `O(members)` | — | — | — |
| Emit an S1/S2 message | `O(1)` + channel MAC | `O(1)` | — | — | — |
| Ingress validation S1a | `O(1)` | `O(members)` | `O(relay queue)` | — | — |
| Ingress validation S1b | `O(1)` + registry lookups | — | — | — | — |
| Warrant recomputation (§13.4) | `O(inputs)` ≤ `O(degree)` | — | — | — | — |
| Independence check (§14.4) | `O(inputs²)` locally (Bloom) | — | `O(R)` aggregate | **exact: `O(roots)` off-line at EVA** | **`O(inputs²)` is bounded because `inputs ≤ degree ≤ genome cap`** |
| Send/receive per step | `O(degree)` | `O(edges within)` | `O(cross-region)` | — | — |
| Connection handshake | `O(1)` × 3 parties | — | `O(1)` local registry | — | — |
| Connection registration | — | — | `O(edges)` local → **`O(1)` digest** | **`O(R)` per epoch** | — |
| Routing resolution | `O(1)` local; `O(log R)` inter-region | — | `O(region size)` table | — | — |
| Provenance append | `O(1)` local Merkle | `O(1)` | `O(1)` | **`O(R)` per epoch anchor** | — |
| Provenance query (ancestry) | — | — | — | **`O(log)` per query, off-line** | — |
| Workspace notification | — | `O(members)` | `O(region members)` × `O(1)` digest | **`O(R)` per epoch** | — |
| Workspace content transfer | `O(pulls)` | `O(pulls)` | `O(pulls)` | `O(pulls)` | **Pull-based ⟹ `O(demand)`, not `O(N × items)`** |
| Dedup lookup | `O(1)` | — | — | — | — |
| Aggregate statistics digest | `O(1)` counters | `O(members)` | `O(region)` | `O(R)` per epoch | — |
| Epoch/policy reference distribution | `O(1)` cached | — | `O(1)` relay broadcast | **`O(R)` hierarchical push** | — |
| **Synchronization** | **`O(1)` — THERE IS NONE** | — | — | — | **§9.3 R9.1: no mechanism requires global synchronization** |
| Partition reconciliation (§31.5) | — | — | `O(divergence)` | `O(divergence)` | **`O(divergence)`, NOT `O(N)` — a short partition is cheap** |

## 64.2 The three `O(N)`-class items, and their fate

**«Any `O(N)` or worse global operation must be explicitly justified.»**

| Item | Naive cost | **This contract's cost** | Mechanism |
|---|---|---|---|
| **Per-message signature verification** | `O(messages)` cryptographic ops | **`O(S3/S4 messages)`** | P0-02 R19.2's layered signing: channel binding for S0–S2. **S3/S4 are `O(governance + evaluation events)`** |
| **Workspace broadcast** | `O(N × items)` | **`O(R)` notifications + `O(pulls)`** | §43.2's hierarchical pull model |
| **Global broadcast of reward/attention/policy** | `O(N)` per event | **`O(R)` hierarchical + targeted** | §45.1 R45.1 (no learning signal requires global broadcast) · §65 |
| **Per-connection kernel registration** (the inherited design) | `O(edges)` KC acts | **`O(above-envelope requests)` + `O(R)` digests** | §20.3's registration/authorization split |
| **`seq` per `(src,dst,conv)`** | `O(peers × conversations)` state | **`O(degree)` state** | §8.3 R8.2 |
| **Vector clock per message** | `O(N)` bytes per message | **`O(1)` — field removed** | §0.2, §10.3 |
| **Full provenance chain per message** | `O(depth × fan-in)` | **`O(1)` commitment** | §15.3 Tier 1 |

**R64.1 (THE COMPLEXITY VERDICT).** *No operation in this contract is `O(N)` at the cell, circuit, or region level. Organism-level operations are `O(R)` per epoch plus `O(governance + evaluation events)`. **The only `O(N)`-scale quantities are local accumulations (per-subject counters) that aggregate to `O(R)` — and aggregation, not accumulation, is what crosses the network.***

---

# §65. GLOBAL BROADCAST AUDIT

**«Attack every mechanism that requires broadcast to all cells.»**

| Candidate broadcast | **Naive cost** | Verdict | **Replacement** |
|---|---|---|---|
| **Reward** | `O(N)` per reward event | ❌ **REJECTED** | **Targeted, epoch-scoped** (Cell §6.2: `eval.reward.v1`, priority 1, «epoch-scoped»). P0-01's fitness is a **vector with per-subject/circuit/region/population scopes** — delivered to the subjects it describes. **§45.2 R45.1** |
| **Attention** | `O(N)` per attention shift | ❌ **REJECTED** | **Regional modulation digests, `O(R)`, pull-based.** Attention modulates admission and gain *within a scope* (§44.1) — **a scope, not the organism** |
| **Safety** | `O(N)` per safety event | ⚠️ **PARTIALLY JUSTIFIED — and it is the one case where wide dissemination is correct** | **Hierarchical broadcast with relay fan-out + `mandatory_path` edges + retry-until-confirmed (§28.2 R28.2).** **A freeze must reach everyone, and P0-02 KC-4's freeze is `O(1)` to issue and `O(R)` to propagate hierarchically — not `O(N)` point-to-point.** ⟵ *The justification: the consequence of an unreached subject is unbounded, so the cost is warranted; and hierarchical propagation makes the cost `O(R)` anyway* |
| **Policy** | `O(N)` per policy change | ❌ **REJECTED as a push** | **PULL + cached reference.** Every subject caches `policy_version_ref` (`O(1)`); the current version is resolvable from the regional relay. **A policy change invalidates the cache; the subject pulls on next use.** ⟵ P0-02 §49.1's «cached policy + local token check ⟹ `O(1)` local» |
| **Memory updates** | `O(N)` per write | ❌ **REJECTED** | **Request/response + content-addressed retrieval (§42.1).** Memory is pulled, never pushed |
| **Synchronization** | `O(N)` barrier | ❌ **REJECTED — and it does not exist** | **§9.3 R9.1: no mechanism requires synchronization. V3 §9's «thalamus-like synchronization» is deleted (§2.5)** |
| **State updates** | `O(N)` per update | ❌ **REJECTED** | **`STATUS`/`HEARTBEAT` are S1 best-effort and targeted; self-state is reported to the Self-State Monitor, not broadcast (V3.1 §3)** |
| **Epoch advance** | `O(N)`? | ✅ **`O(R)` hierarchical, and monotone-restrictive** | **§9.3 R9.1: a subject at epoch `e` refuses `e+1` artifacts and accepts `e` artifacts, so disagreeing subjects never both accept what the other refuses. ⟹ Propagation delay is safe by construction, which is why a broadcast is not needed** |
| **Morphogen / demand** | `O(region)` | ✅ **JUSTIFIED — regional diffusion** | **Cell §6.2's `dev.morphogen.v1`, organism-signed, «short» TTL. Diffusion is correct because a GRADIENT is the intended semantics (§24.1)** |
| **Workspace items** | `O(N × items)` | ❌ **REJECTED** | **§43.2's three-tier pull model** |

**R65.1 (THE BROADCAST RULE).** *The only organism-wide dissemination in this contract is the SAFETY class, and it is hierarchical (`O(R)` propagation) rather than point-to-point.* **Everything else is targeted, regional, pull-based, or cached.** ⟵ *The six replacement patterns the brief lists are all used: local broadcast (morphogen) · hierarchical broadcast (safety, epoch) · sparse broadcast (regional digests) · event-triggered propagation (invalidation) · pull-based retrieval (policy, memory, workspace) · cached state (policy reference, epoch counter).*

---

# §66. COMMUNICATION ECONOMY

## 66.1 «Could the Digital Brain become communication-bound rather than compute-bound?»

> ### **Yes — and the inherited design was already there. Three of its requirements put communication cost above compute cost.**

```
THE INHERITED DESIGN'S COMMUNICATION BUDGET, PER MESSAGE:
  • Ed25519 signature over the full canonical envelope      ⟹ ~10⁵ ops
  • signature verification at the receiver                  ⟹ ~10⁵ ops
  • `evidence_roots` array construction + hashing           ⟹ O(|roots|)
  • vector clock construction + compression                 ⟹ O(participants)
  • Type Registry resolution                                ⟹ O(1) but with
                                                              a lookup
  • dedup bloom filter probe                                ⟹ O(1)
  • provenance ref resolution                               ⟹ O(1) lookup
  • trust threshold check                                   ⟹ O(1)
  • ACK generation and processing (for reliability EWMA)    ⟹ **doubles the
                                                              message count**
  • payload transform                                       ⟹ O(transform)

**FOR AN S0-CLASS SIGNAL — AN EDGE ACTIVATION CARRYING A BOUNDED FLOAT —
THE OVERHEAD EXCEEDS THE PAYLOAD'S COMPUTATION BY SEVERAL ORDERS OF
MAGNITUDE.** ⟹ **The system spends more computing communicating than
computing. This is not a projection; it is the arithmetic of the Cell
Contract's §6.2/§7.1 requirements applied to its own §S0 traffic.**

AND §68's CONTRADICTION X-J IS THE SAME FACT SEEN FROM THE INGRESS SIDE:
Cell §S1 performs signature verification + schema validation + TTL/epoch
check + dedup + provenance resolution + trust threshold check **on every
input, before S3 aggregation**. **That is governance-class verification cost
on data-class traffic.**
```

## 66.2 The equilibrium, and the mechanisms that reach it

| Budget | **This contract's allocation** | Mechanism |
|---|---|---|
| **Local computation** | **The default.** Anything computable locally is computed locally | §22.1's locality rule: learning is purely local; **§66.3's substitution principle** |
| **Communication** | **`O(S2+ messages)` warrant cost + `O(1)` transport cost for S0/S1** | §7.2's class assignment · §38.1's S1a/S1b split · R19.2's channel binding |
| **Memory** | **Bounded local caches + pull-based retrieval** | §42.1 · §59.3's local memory · Cell §8's eviction with `capability_critical` exemption |
| **Verification** | **`O(S2+ messages)`, and only S1b's registry lookups** | §38.1's ingress split |
| **Routing** | **`O(1)` local; `O(log R)` inter-region** | §23.1's hierarchical addressing · §24.3 |

## 66.3 «Find architectural mechanisms that allow local computation to replace unnecessary communication»

> ### **R66.1 (THE SUBSTITUTION PRINCIPLE) — five mechanisms, and together they are the answer to §66.1.**

```
1. **THE CLASS PARTITION (§72).** 99% of traffic is S0/S1, which carries no
   warrant and therefore pays no warrant cost. **This is the single largest
   saving: it removes verification, provenance, and signature cost from the
   dominant traffic class entirely.**

2. **SHARED CONTEXT INSTEAD OF TRANSMITTED CONTEXT (§63.1).** The closed
   type registry, unit conventions, representation, class→mechanism mapping,
   delivery semantics, and failure matrix are held by every participant as
   POLICY. **A message carries only what is not shared.** ⟹ envelope
   overhead is 11 fields for S2 and 5 for S0, not 20+.

3. **PREDICTION INSTEAD OF TRANSMISSION.** A cell that can PREDICT its
   neighbor's next output does not need to receive it. **Cell §17's
   adaptation requirement («PREDICTION → OBSERVATION → COMPARE») is
   therefore not only a learning mechanism — it is a bandwidth mechanism.**
   ⟹ **The error signal is the communication that actually happened; a
      correct prediction is communication that was avoided.** *This is the
      free-energy-style argument, and it is worth stating carefully: it is
      a bandwidth argument, not a claim about the architecture's
      epistemology.*

4. **AGGREGATION INSTEAD OF RELAY (§15.3, §20.3).** Local Merkle trees and
   epoch digests replace per-event reporting. **`O(events)` local ⟹ `O(R)`
   networked.**

5. **PULL INSTEAD OF PUSH (§43.2, §65).** Workspace, memory, and policy are
   pulled. **A push costs `O(recipients)` whether or not anyone wants it; a
   pull costs `O(requesters)`.**

⟹ **R66.2 (THE EQUILIBRIUM CLAIM, QUALITATIVE — no invented numbers per
   §96):** with these five mechanisms, communication cost per unit of
   computation is bounded by a function of the WARRANT-CLASS DISTRIBUTION
   of traffic, not by the traffic volume. **A system that shifts traffic
   from S2 to S0 becomes cheaper without becoming less capable — because
   S0 traffic was never warrant-bearing, and warrant was the expensive
   part.** ⟹ **§54.1's observable "local/global traffic ratio" and
   "opaque traffic fraction" are therefore economic indicators, not just
   safety indicators: a population moving traffic DOWN the class ladder is
   buying bandwidth, and a population moving it UP is buying warrant.**
```

---

*End of Volume D. Volume E (`21_analysis_adversarial_contradiction.md`) covers §67–§70: the 40+ adversarial attack suite, the cross-system contradiction audit, the circular dependency audit, and the parameter registry.*
