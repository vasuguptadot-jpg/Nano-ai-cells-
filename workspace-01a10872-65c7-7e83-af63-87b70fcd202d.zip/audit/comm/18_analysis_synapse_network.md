# P0-03 — COMMUNICATION, DIGITAL SYNAPSE & SIGNAL CONTRACT
## Volume B: Synapse, Plasticity, and Network Structure (§18–§29)

**Companions:** `17_analysis_signal_message.md` (A) · `19_analysis_partition_planes.md` (C) · `20_analysis_evolution_hardware.md` (D) · `21_analysis_adversarial_contradiction.md` (E) · `22_analysis_formal_invariants.md` (F) · `23_analysis_interfaces_testability.md` (G) · `24_v4_communication_synapse_signal_spec.md` (**Output 42**)
**Outputs delivered here:** **9** (canonical synapse model) · **10** (plasticity boundary) · **11** (connection creation/deletion authority) · **12** (addressing) · **13** (routing) · **14** (topology) · **15** (bandwidth/latency/resource model)

---

# §18. SYNAPTIC WEIGHT — **OUTPUT 9**

## 18.1 The ten candidate meanings, and why one scalar cannot hold them

The brief lists ten interpretations of «weight». **They are not ten readings of one quantity; they are quantities on three different planes with three different owners and three different mutability rules.** V3 §8's single `weight` property and V3 §23's «weighted, contextual, trusted communication» both collapse them.

| Candidate meaning | **Plane** | **Owner / producer** | **Learnable?** | **What breaks if conflated with `gain`** |
|---|---|---|---|---|
| **Probability of transmission** | Transport | Transport mechanism (measured) | ❌ | A learned gain that alters transmission probability makes the transport guarantee a function of learning ⟶ **R0.3's influence⟶transport violation** |
| **Signal gain** | **Influence** | **The cell, within bounds** | ✅ **Yes — this is what plasticity actually is** | — (this is the referent) |
| **Importance** | Influence / policy | Policy for classes; the cell for local attention | ⚠️ Partially | «Important» is §44's attention quantity, and attention must not become warrant |
| **Learned association** | Influence | The cell | ✅ | Synonymous with gain in this architecture — **and stating so removes one ambiguity** |
| **Routing preference** | **Transport** (selection among admissible hops) | The cell, **within the admissible set** | ✅ **but bounded by `mandatory_path`** | **§24.2: unbounded learned routing is how a plasticity process reroutes around a protected verification path** |
| **Trust** | **Warrant** | **EVA, externally assigned** | ❌ **NEVER** | **V3.1 §6 lists trust as synapse-plastic. R3.2 rejects it: a cell that can raise its own inputs' trust can manufacture warrant (§13.2's attack 3, executed locally)** |
| **Reliability** | Transport | **Measured** (Cell §14.5: «a cell may not write its own `reliability`») | ❌ | A learned reliability estimate that replaces measurement makes §7.4's telemetry self-serving |
| **Attention** | Influence | Attention Controller (organism) | ✅ | §44 |
| **Bandwidth allocation** | Transport / resource | Homeostasis **within a KC-3 ceiling** (P0-02 INV-29) | ⚠️ Within envelope | **Resource allocation is P0-02's four-principal split; making it a synaptic property collapses DEFINITION into ALLOCATION** |
| **Expected utility** | **Alethic** | **EVA / the objective** | ❌ | **The most dangerous conflation.** A synapse carrying expected utility makes the communication layer an optimizer, and §47's reward hacking becomes a local weight update |

## 18.2 «Can one connection have multiple parameters?» — yes, and it must

> ### **R18.1 (THE DECOMPOSITION).** *A connection holds five disjoint parameter groups. The word «weight» is prohibited without a group qualifier.*

```
GROUP 1 — INFLUENCE PARAMETERS          (cell-writable, bounded, learnable)
  gain              : f32 [-W_MAX, +W_MAX]     **sign encodes
                                                  excitation/inhibition —
                                                  V3 §8's "weight", correctly
                                                  scoped at last**
  context_sensitivity: f32[C]                  modulation by context vector
  plasticity_rate   : f32 [0, PR_MAX]          bounded
  eligibility_trace : f32, λ-decayed per step   **the credit-assignment
                                                  mechanism (Cell §14.3)**
  usage_frequency   : f32 [0,1] EWMA

GROUP 2 — TRANSPORT MEASUREMENTS          (transport-writable, cell READ-ONLY)
  reliability       : f32 [0,1]  EWMA(delivered/sent), **aggregate for S0/S1
                                  per §7.4; per-message ACK for S3/S4 only**
  latency_measured  : u32, EWMA + percentiles, **UNKNOWN when no drift bound**
  failure_count, consecutive_failures, last_failure_ts
  in_flight         : u16                     **for teardown safety**
  bandwidth_cost    : u32 bytes/s, **METERED not declared (§4.2)**

GROUP 3 — WARRANT ASSIGNMENTS             (EVA-writable, cell READ-ONLY)
  trust_out_assigned: how OTHERS should weight this source
                      (Cell Contract's term, preserved; producer renamed
                       EIK→EVA per P0-02 R8.7)
  calib_ref         : (producer, type) → calibration record pointer

GROUP 4 — PROTOCOL / POLICY FACTS         (set at creation, IMMUTABLE)
  conn_id, src, dst, direction
  conn_type         : **fixed for the connection's life (§19.2)**
  mandatory_path    : bool — **no plasticity or mutation operator may remove
                      or reroute** (Cell §14.1, resolving audit C15)
  authorization_ref : handshake ticket
  created_at, created_by

GROUP 5 — LIFECYCLE STATE                 (§21's state machine)
  state ∈ {PROPOSED, PENDING_CONSENT, ACTIVE, DEGRADED, FROZEN,
           DRAINING, CLOSED}
  pruning_score     : **computed by the Organism Topology Service (GP), NOT
                      "the kernel"** — §68 X-A1
```

## 18.3 «Determine the minimal representation»

**The minimality test, applied per parameter: what breaks if it is removed?**

| Parameter | Removed ⟹ what breaks | **Verdict** |
|---|---|---|
| `gain` | No learning at the connection level; aggregation becomes uniform | **NECESSARY** |
| `context_sensitivity` | No context modulation; V3 §8's «contextual» is lost; specialization (§51) has no local mechanism | **NECESSARY** |
| `plasticity_rate` | All edges learn at one rate; **multi-timescale learning collapses** — Cell §9.4's `lr_fast ≥ lr_medium ≥ lr_slow` ordering (kernel-enforced so «a fast process cannot undo a slow commitment inside its window») becomes inexpressible | **NECESSARY** |
| `eligibility_trace` | **Credit assignment becomes purely temporal.** Cell §14.3: «Without it, a connection is strengthened because it was *active*, not because it *contributed*» | **NECESSARY — and it is the single highest-value parameter in the group** |
| `usage_frequency` | Pruning loses its primary input; §51's demand-driven specialization loses its signal | **NECESSARY** |
| `reliability` | Loss is undetectable per connection; rerouting (§29) has no criterion | **NECESSARY** |
| `latency_measured` | §28's fast-vs-reliable trade-off is unlearnable; **and V3 §8 listed latency with no measurement mechanism, which the Cell Contract correctly fixed** | **NECESSARY** |
| `in_flight` | **Teardown drops live messages.** Cell §14.4's DRAIN state becomes unsafe | **NECESSARY** |
| `failure_count` / `consecutive_failures` | DEGRADED transition (§21) has no trigger; circuit-breaking impossible | **NECESSARY** |
| `bandwidth_cost` | §27's economics has no cost term; **communication becomes free in the model and therefore unlimited in the design** | **NECESSARY** |
| `trust_out_assigned` | Aggregation cannot weight by external reliability ⟹ **every source counts equally ⟹ §35's amplification attack has no attenuation** | **NECESSARY** |
| `calib_ref` | §13.4's recomputation loses input 3 | **NECESSARY** |
| `conn_type` | §12's type partition collapses at the connection level; **warrant class becomes per-message only, so a connection cannot be restricted to a class** | **NECESSARY** |
| `mandatory_path` | Protected verification and safety paths become prunable ⟹ audit C15 returns | **NECESSARY** |
| `context_sensitivity` **per-dimension vector** | ⚠️ A scalar would suffice for many tasks | **`[T]`-dependent — the vector length is task-defined** |
| `pruning_score` | Could be computed on demand rather than stored | **DERIVABLE — should NOT be stored.** Storing it creates a stale-value hazard and a writable field where a computation belongs |
| `latency_preference` (brief's §19 candidate) | Nothing: it is `gain`-weighted route selection among admissible hops | **REDUNDANT — REJECTED as a separate parameter** |
| `importance` | Nothing: it is attention (§44), which is an organism-level quantity, not an edge parameter | **REDUNDANT AT THIS LEVEL — REJECTED** |
| `expected_utility` | Nothing desirable. **Its presence makes the edge an optimizer** | **FORBIDDEN (§18.1's last row)** |

**R18.2 (OUTPUT 9 — THE MINIMAL REPRESENTATION).** *A connection holds **16 stored parameters across 5 groups**, of which **5 are cell-writable, 6 are transport-writable and cell-read-only, 2 are EVA-writable and cell-read-only, and 3 are immutable after creation.** `pruning_score` is computed, not stored. `latency_preference` and `importance` do not exist as edge parameters. `expected_utility` is forbidden.*

**R18.3 (THE PROPERTY THAT MAKES THE DECOMPOSITION SAFE).** *Each group has exactly one writer, and the writer sets are disjoint.* **This is P0-02 EIK-INV-29's four-principal resource split applied to the connection object, and it is conformance-testable: assert that no code path writes a Group-3 field from a cell context (§90's T-PATH class).** ⟵ *A parameter object with one writer per field is auditable; one with a shared writable `weight` is not, because any writer can claim any meaning.*

---

# §19. SYNAPTIC PLASTICITY BOUNDARY — **OUTPUT 10**

## 19.1 What may change during lifetime learning

| Property | **Mutable by learning?** | Bound | Authority that sets the bound |
|---|---|---|---|
| `gain` (weight) | ✅ **YES** | `|w| ≤ W_MAX`; `Σ|w_in|` normalized to `≤ W_IN_TOTAL` | Policy (L2) |
| `context_sensitivity` | ✅ **YES** | Per-dimension bound | Policy |
| `plasticity_rate` | ⚠️ **Within a genome prior and a policy ceiling** | `≤ PR_MAX`; **the `lr_fast ≥ lr_medium ≥ lr_slow` ordering is enforced so a fast process cannot undo a slow commitment** (Cell §9.4) | **Genome (prior) + policy (ceiling)** |
| `eligibility_trace` | ✅ **YES — it is the learning state itself** | λ-decay; `‖Δθ‖∞ ≤ Δ_MAX`; `Σ‖Δθ‖ ≤ DELTA_BUDGET` | Policy |
| `usage_frequency` | ✅ (it is a measurement of use) | EWMA | — |
| `reliability`, `latency_measured` | ❌ **MEASURED, never learned** (Cell §14.5) | — | Transport |
| `trust_out_assigned`, `calib_ref` | ❌ **EXTERNALLY ASSIGNED, cell read-only** — **V3.1 §6's plastic «trust» is REJECTED (R3.2)** | — | **EVA** |
| **Connection existence** | ⚠️ **Within envelope only** | Degree caps (`max_connections`, `max_fanout` from genome) · locality policy · loop-gain constraint · lineage-concentration limit · **`mandatory_path` non-violation** | **Policy defines the envelope; KC-3 enforces the ceilings; the Topology Service allocates within** (P0-02 RO-05's `E` within envelope, `A` above) |
| **`conn_type`** | ❌ **IMMUTABLE for the connection's life** | — | Set at creation |
| Routing preference (selection among admissible hops) | ✅ **Within the admissible set** | **`mandatory_path` edges are always admissible and may not be bypassed** | Policy |
| Bandwidth allocation | ⚠️ **Within the KC-3 ceiling** | Homeostasis allocates; KC-3 enforces | **P0-02 INV-29's split** |

## 19.2 **OUTPUT 10 — the three questions, answered**

### Q1: «Can learning create a connection that bypasses EIK governance?»

> ### **NO — for governance traffic. YES — for monitoring coverage, and that residue must be stated.**

```
WHY NOT FOR GOVERNANCE TRAFFIC (structural, four independent closures):

  1. **CLASS IS TYPE-DETERMINED, AND THE TYPE REGISTRY IS POLICY.**
     A governance message is S3/S4 (§72). A connection cannot change the
     class of what flows on it, because class is a function of `type`, and
     `type` is resolved against a policy-owned registry that no cell may
     write (P0-02 Channel 1, hash-referenced, NAUL-3).
     ⟹ **A new edge between two cells carries only the classes its endpoints
        are AUTHORIZED to emit and accept.** An S0/S1-only cell pair cannot
        create an S3 channel by creating an edge.

  2. **S3/S4 REQUIRE A SIGNATURE THE CELL DOES NOT HOLD.**
     P0-02 R19.2 retains per-message signatures for governance-class
     messages. A cell's key cannot produce a valid S3 signature. **Creating
     a connection does not create a key.**

  3. **`mandatory_path` IS IMMUTABLE UNDER EVERY OPERATOR.**
     Cell §14.1: connections carrying EVALUATIVE signals through
     lineage-independent verifiers, and SAFETY signals to the kernel, are
     «marked mandatory at creation and **no plasticity or mutation operator
     may remove or reroute them**». **So the protected paths cannot be
     pruned, weakened out of use, or routed around.**

  4. **GOVERNANCE DOES NOT TRAVEL OVER LEARNED CONNECTIONS AT ALL.**
     P0-02's Channel 1 and Channel 2 are KC↔GP↔organism-service paths.
     **A cell-to-cell edge is not on them.** Learning can create as many
     edges as the envelope permits and none of them is a governance channel.

THE RESIDUE — AND IT IS REAL:
  **A learned connection can create a path that avoids a MONITORED route.**
  If anomaly detection, opaque-traffic accounting (§50), or regional
  aggregation is applied at regional relays, then a directly-learned
  cell-to-cell edge across a region boundary evades the relay.

  BOUNDS (each partial, together sufficient to make it detectable):
    • `mandatory_path` protects the specific paths that matter
    • degree caps bound how many such edges one subject can hold
    • **region-crossing rate limits on `OPAQUE` traffic (§50)**
    • lineage-concentration limits (Cell §14.2 step 3's diversity policy)
      prevent a single lineage from wiring a private bypass mesh
    • **Tier-2 local logs are retained per subject (§15.3), so a bypass edge
      is visible in the local record even when it is invisible at the relay**

  ⟹ **R19.1: governance bypass is structurally impossible. MONITORING bypass
     is bounded, not impossible, and §91 OR-C5 records it.**
```

### Q2: «Can learning create a communication path that bypasses provenance?»

> ### **NO — and this one is closed by a type-level impossibility rather than by a bound.**

```
PROVENANCE IS A PROPERTY OF THE MESSAGE CLASS, NOT OF THE PATH.

  An S2+ message MUST carry `root_commit`, `causal_depth`, `calib_ref`,
  `corr_class` (§4.3). **R12.1: a message missing a mandatory field for its
  class is MALFORMED — it is rejected at ingress, not downgraded.**

  ⟹ Therefore:
    • A path cannot strip provenance, because a stripped S2 message is
      MALFORMED and never reaches PROCESSED (§6.2).
    • A path cannot DOWNGRADE an S2 message to S0 to avoid provenance,
      because class is determined by `type` and the endpoint's authorization
      to emit that type — **and downgrading would also remove the message's
      ability to serve as evidence, which defeats the purpose of the attack.**
    • A path cannot carry warrant-bearing content as `OPAQUE`, because
      `OPAQUE` carries MINIMUM WARRANT (§49): it cannot increment `n_obs`,
      cannot be cited as provenance, cannot satisfy a verification
      requirement. **Smuggling evidence through the opaque class buys
      transport and forfeits warrant — which is the opposite of what the
      attacker wants.**

  ⟹ **COMM-INV-11 (the structural closure): a message's warrant class is a
     function of its type and its signer's authorization. It is not a
     function of its path, its volume, its propagation depth, or its
     receiver's preference.**

  **THE ONE REAL PROVENANCE RISK IS NOT A PATH — IT IS A TRANSFORM (§16).**
  Laundering happens by rewriting roots, resetting depth, or escalating type,
  and all four forms are closed by COMM-INV-08's inheritance rules. **No
  amount of rewiring closes a laundering hole, because rewiring is not where
  the hole is.** ⟵ *This is a useful negative result: it tells the
  implementer where to spend the verification budget.*
```

### Q3: «Can learning turn an ordinary signal into a governance command?»

> ### **NO — four independent closures, and the fourth is the decisive one.**

```
1. TYPE-LEVEL: `GOVERNANCE`, `SAFETY`, `IMMUNE_EXECUTE`, `VERDICT`, `REWARD`
   are S3/S4 types. **An S0/S1/S2 message cannot be parsed by an S3 handler**
   because the handler requires a signature the class does not carry.

2. SIGNATURE-LEVEL: S3 requires a signature from an authorized principal
   (KC-2, EVA, the Immune Service under budget). **A cell key does not
   produce one.** Cell Contract §6.2 already established the pattern: «A cell
   signature on a `REWARD` message is **structurally invalid** — S1 rejects
   it. This closes the audit's most severe communication defect (any cell
   could forge reward) **at the type level rather than by policy**.»

3. PROPAGATION-LEVEL: **COMM-INV-04 — a cell-generated message cannot acquire
   authority through propagation.** Ten million relays of «FREEZE region 7»
   produce ten million authenticated relays of a cell's *recommendation*.
   This is P0-02's NAUL-1 in communication form.

4. **VOCABULARY-LEVEL — AND THIS IS THE DECISIVE ONE.**
   **The deontic vocabulary is reserved.** P0-02's six KC-2 outputs
   (PERMIT · DENY · DEFER · FREEZE · ESCALATE · HALT) are S3 type values.
   **A cell-generated message may not carry them in an authority position at
   all** — not in `type`, not in `prio`, not in a governance-shaped payload
   field. It may carry them only inside a `RECOMMEND` payload, where
   §12.1's typing makes the recommendation structurally distinct from the
   command (Cell §7.3(b): «a recommendation is not an action and confers no
   authority», with `utility_basis` naming the objective «so a
   recommendation is always *relative to an assigned objective* — never to a
   self-chosen one»).

   ⟹ **«Cell A recommends freeze» is an S2 RECOMMEND with a payload naming
      FREEZE. «KC authorizes freeze» is an S3 GOVERNANCE signed by KC-2.
      They differ in class, in signer, in schema, and in the handler that
      accepts them. There is no continuous path from one to the other.**
```

**R19.2 (OUTPUT 10 — THE PLASTICITY BOUNDARY, STATED AS ONE RULE).**

> ### *Learning may modify **influence-plane parameters** (gain, context sensitivity, plasticity rate within ceiling, eligibility trace, usage) and **transport-plane route selection among admissible hops**, and may **create or delete connections within the pre-authorized envelope**. Learning may never modify: **warrant rules** (policy, RO-13) · **warrant assignments** (trust, calibration — EVA) · **transport measurements** (reliability, latency — measured) · **protocol facts** (`conn_type`, `mandatory_path`, class→mechanism mapping) · **transport ceilings** (KC-3) · **the type registry** (policy) · **or the deontic vocabulary** (reserved).*
>
> **The boundary is exactly R0.3's plane separation: learning owns the influence plane, measures nothing, warrants nothing, and enforces nothing.**

---

# §20. CONNECTION CREATION — **OUTPUT 11 (part 1)**

## 20.1 «Who may create a new connection?»

| Candidate | Verdict | **Mechanism** |
|---|---|---|
| **Cell** | ⚠️ **May PROPOSE and CONSENT; may not create unilaterally** | Cell Contract §14.2's three-party handshake, **preserved**. «Unilateral connection creation is a denial-of-service vector: an attacker can force itself into a target's input set and consume its aggregation budget» |
| **Local circuit** | ✅ May propose on behalf of members; **may not override a member's refusal** | Consent is per-endpoint |
| **Region** | ✅ May allocate within its envelope | Topology Service (GP) |
| **Developmental process** | ✅ **Batch-authorized** | Cell Contract's `created_by = DEVELOPMENT`, «initial wiring from the genome's developmental program, **batch-authorized**» — **and this is the scalability key: `O(genome program)`, not `O(edges)`** |
| **Evolutionary process** | ⚠️ **May vary topology PRIORS, not specific connections** | §68 X-G: the Cell Contract forbids inheriting «a specific connection table»; §48 permits inheriting degree bounds, `conn_type` distribution bias, locality kernel |
| **EIK (KC)** | ⚠️ **Authorizes ONLY above envelope (RO-05) and authorizes the envelope itself (RO-15)** | P0-02 §7.3's matrix: cell `E` (within envelope), KC `A` **only above envelope** |
| **External controller** | ❌ Not a creation path | OP changes the envelope, not edges |

## 20.2 «Is connection creation itself an EIK-governed operation?»

> ### **It is EIK-*bounded* and only sometimes EIK-*authorized*. The distinction resolves contradiction A.**

```
P0-02 §7.3'S MATRIX, VERBATIM:
  RO-05 Create connection :  Cell `E` (within envelope) · Circuit `E` ·
                             Region `E` · Organism `r` · EVA `M` (post-hoc) ·
                             **KC `A` ONLY ABOVE ENVELOPE** · GP `r` (Attestor)
  RO-06 Modify connection :  identical

P0-02 §6.2'S FAILURE MATRIX, VERBATIM:
  «**RO-05/06 Create/modify connection | Within envelope | `FO` — PERMIT** |
    Reversible, local, high-frequency. **Requiring KC here is SPOF-3**»

⟹ **WITHIN ENVELOPE: NOT A GOVERNANCE ACT.** The cell executes under a
   pre-authorized envelope, with negative authority (P0-02 §7.4 R7.6: act
   first within the box, be vetoable afterward).
⟹ **ABOVE ENVELOPE: RO-05, reserved, live authorization required**
   (P0-02 EIK-INV-15: irreversible ops never use a cached token — and an
   above-envelope connection is above envelope precisely because it exceeds
   a bound, which is what makes it consequential).

**THE ENVELOPE IS THE GOVERNANCE, NOT THE EDGE.** Its components (all policy,
all RO-15/RO-13):
  • degree caps            (genome-declared, policy-bounded)
  • locality policy        (§22's minimum-locality rule)
  • loop-gain constraint   (Cell §14.2 step 3, from audit §B.12 —
                            **and note this is an INFLUENCE-plane bound:
                            Σ gain around a cycle < 1, which is §35's
                            cascade defence expressed structurally**)
  • mandatory-path non-violation
  • lineage-concentration limit (diversity policy)
  • bandwidth budget       (charged to the creator — §27)
  • conn_type admissibility per endpoint port schema
```

## 20.3 «How can billions of ordinary synaptic changes occur without EIK becoming an O(N) bottleneck?»

> ### **By splitting REGISTRATION from AUTHORIZATION — the conflation of which is contradiction A's actual mechanism.**

**The Cell Contract says:** «A connection is a directed, typed, mutually-consented, **kernel-registered** edge» and «Organism Topology Service checks … ⟶ issues `authorization_ref`; both sides set state = ACTIVE. ⟶ **Kernel-enforced. Neither cell can bypass.**»

**That is two distinct acts described as one:**

| Act | Nature | Frequency | **Correct principal** | Cost |
|---|---|---|---|---|
| **AUTHORIZATION** — is this edge permitted? | A **decision** | Rare (above envelope only) | **KC-2 (RO-05)** | `O(above-envelope requests)` |
| **REGISTRATION** — record that this edge exists | A **record** | Every edge | **Topology Service (GP), under I16 delegation** | `O(edges)` local → **`O(R)` per epoch as a Merkle digest** |

```
THE FOUR TECHNIQUES (P0-02 §49.2), APPLIED TO TOPOLOGY:

1. **PRE-AUTHORIZED ENVELOPE.** Within envelope, no authorization act occurs
   at all. **This removes KC from every ordinary synaptic change.**

2. **CAPABILITY TOKENS.** The Topology Service holds a standing delegation
   (P0-02 I16) scoped to RO-05/RO-06 *within envelope*. It issues
   `authorization_ref` locally. **O(1) verification per handshake; no KC
   round-trip.**

3. **HIERARCHICAL DELEGATION.** Regional Topology Services handle O(N_region)
   edges; KC sees O(R) delegation renewals per epoch. **R is 10¹–10².**

4. **MERKLE AGGREGATION.** The regional connection registry is a local Merkle
   tree; **its root is anchored once per epoch (O(R) hashes), not per edge.**
   ⟹ Registration is batched, and the batch is what is provenanced.

⟹ **KC LOAD FROM TOPOLOGY = O(above-envelope requests) + O(R) per epoch.**
   **NOT O(edges).** At 10¹² cells with bounded degree, edges are 10¹³;
   the epoch digest is O(R). **This is four to ten orders of magnitude,
   and it is the entire answer to §20's second question.**

⟹ **AND THE SAFETY PROPERTY IS PRESERVED, NOT TRADED:**
   • `mandatory_path` edges are marked at creation and verified off-substrate
     at every candidate evaluation (Cell §14.1) — **unchanged**
   • above-envelope requests still get live KC-2 authorization — **unchanged**
   • the regional registry root is anchored, so a Topology Service that
     registers an unauthorized edge produces a digest disagreement with its
     siblings (P0-02 §10.1's P3 path) — **detectable**
   • **the envelope itself is policy (RO-15), so widening it is a
     constitutional-adjacent act requiring OP** — **unchanged**
```

**R20.1 (OUTPUT 11, PART 1 — CREATION AUTHORITY).** *Connection creation is a **three-party handshake** (propose → consent → register) executed by the endpoints and a **delegated GP Topology Service within a pre-authorized envelope**. KC-2 authorizes **only above-envelope** creation (RO-05) and **only the envelope itself** (RO-15). Registration is batched into `O(R)` epoch digests. **Developmental wiring is batch-authorized from the genome program.***

**R20.2 (THE CONSENT REQUIREMENT IS A SECURITY MECHANISM, NOT A COURTESY).** *The target's right of refusal is load-bearing.* **«Refusal is recorded and is NOT an error»** (Cell §14.2). Without it, connection creation is an ingress-forcing attack: an attacker proposes edges until it occupies a victim's aggregation budget. **⟹ refusal rate is an I-18 observable, and a subject with an anomalous refusal rate is either attacking or being attacked — §67 #21 (connection hijacking) and #22 (connection explosion) are both detected by this one statistic.**

---

# §21. CONNECTION DELETION — **OUTPUT 11 (part 2)**

## 21.1 The three acts that «removing a connection» conflates

> ### **R21.1.** *Weakening, deletion, and revocation are three acts on three planes with three authorities and three reversibilities.*

| | **LEARNED WEAKENING** | **STRUCTURAL DELETION** | **GOVERNANCE REVOCATION** |
|---|---|---|---|
| **Plane** | Influence | Transport | **Deontic** |
| **What changes** | `gain → 0` (and `Σ|w_in|` renormalization) | `state → DRAINING → CLOSED`; the edge ceases to exist | `state → FROZEN` or forced `CLOSED`; **overrides both other acts** |
| **Authority** | The cell, within bounds | Topology Service (GP) **within envelope**; KC-2 (RO-06) **above envelope** | **KC-2 / KC-4** (freeze at scope), or the Immune Service under budget |
| **Reversible?** | ✅ **Instantly** — gain is a bounded float | ⚠️ **Within `ROLLBACK_DEPTH` epochs** (Cell §14.4 step 8) | ⚠️ **Only by RO-08, KC-2 sole authority** (P0-02) |
| **Evidence required** | Correlational (usage, failure, weight magnitude) | **Correlational suffices — because it is reversible within the window** | Policy violation or safety trigger |
| **Guards** | `W_MAX`, normalization | `mandatory_path` ⟹ **NEVER**; `min_in_degree` for role; circuit functional contract not orphaned | None — **a freeze has no guard, by design (P0-02 EIK-INV-52: non-discretionary)** |
| **Cost** | `O(1)` local | `O(degree)` + drain + notify | `O(1)` broadcast |

**R21.2 (WHY DELETION NEEDS ONLY CORRELATIONAL EVIDENCE WHILE RETIREMENT NEEDS CAUSAL).** *P0-01 §23.2 requires causal ablation for **pruning/retirement of a subject**, because a subject is not recoverable. An edge is recoverable for `ROLLBACK_DEPTH` epochs (Cell §14.4 step 8), and **the fact of the connection persists in the lineage/audit record even after closure** (Cell §14.4 step 7: «the FACT of the connection persists even though the connection does not»).* **⟹ P0-02's partition-by-irreversibility applied to topology: reversible acts need correlational evidence; irreversible acts need causal evidence. An edge inside its rollback window is reversible; an edge outside it is not, and deleting a `mandatory_path` edge is never permitted at all.**

## 21.2 The seven deletion causes, and who acts

| Cause | Act | Authority | Reversible? | **Note** |
|---|---|---|---|---|
| **Pruning** (`pruning_score > θ_prune`) | Structural deletion | Topology Service (GP) within envelope | ✅ Within window | **`pruning_score` is computed by the Topology Service from measured inputs — NOT «by the kernel» (Cell §14.4 step 1's wording, corrected in §68 X-A1) and NOT self-reported by the cell** |
| **Temporary disconnection** | `state → FROZEN` | Cell (self, for its own inputs) or Immune (for a peer) | ✅ Immediate | **A frozen edge is not a deleted edge: the record persists, `gain` persists, and thawing restores it. This is the cheapest defensive act in the contract and is under-used** |
| **Quarantine** | `FROZEN` + peer added to `quarantine_flags` | **Immune Service under KC-3 budget** (P0-02 §8.2) | ✅ By EVA retest + KC-2 RO-08 | Cell §6.1's `quarantine_flags: [CellID]` — «peers whose output to discount» — **is the mildest rung (DISCOUNT) and requires no authority at all** |
| **Failure** (`consecutive_failures ≥ θ`) | `state → DEGRADED`, then `CLOSED` | Transport + Topology Service | ✅ | **DEGRADED is a reroute candidate, not a deletion** |
| **Resource pressure** | Weakening first, deletion only if pressure persists | **Homeostasis allocates; KC-3 enforces the ceiling; the Topology Service deletes** | ✅ | **P0-02 INV-29's split. Homeostasis may not delete edges — that would make allocation an irreversible act (§7.4 R7.6's constraint)** |
| **Inactivity** | Weakening (usage EWMA decays) ⟹ eventually pruning candidate | Cell (weaken) → Topology Service (delete) | ✅ | **Cell §14.4's anti-fragility guards exist precisely because naive inactivity pruning severs rarely-used critical paths — «the connection-level analogue of Attack M»** |
| **Developmental remodeling** | Batch structural change | Developmental program, batch-authorized | ⚠️ Per program | Same mechanism as §20.3's batch creation |

## 21.3 **OUTPUT 11 (part 2) — the deletion state machine**

```
ACTIVE ──(reliability < θ_rel)──► DEGRADED ──(recovery)──► ACTIVE
   │                                  │
   │                                  └──(consecutive_failures ≥ θ)──┐
   │                                                                 │
   ├──(immune discount / self-freeze / KC-4 scope freeze)──► FROZEN ─┤
   │                                            │                    │
   │                                     (thaw / RO-08 clear)         │
   │                                            ▼                    │
   │                                          ACTIVE                 │
   │                                                                 │
   ├──(pruning_score > θ_prune)──► [GUARD CHECK]                     │
   │                                mandatory_path?  ⟹ **REFUSED,    │
   │                                                   permanent**   │
   │                                below min_in_degree? ⟹ REFUSED   │
   │                                orphans a circuit contract? ⟹    │
   │                                                   REFUSED       │
   │                                above envelope? ⟹ **KC-2 RO-06   │
   │                                                   authorization**│
   │                                            │                    │
   │                                            ▼                    │
   └────────────────────────────────────► DRAINING ◄──────────────────┘
                                            │  in_flight → 0
                                            │  no new messages accepted
                                            │  dependents NOTIFIED
                                            ▼
                                          CLOSED
                                            │  **record RETAINED in the
                                            │   lineage/audit anchor**
                                            ▼
                                   (reversible for ROLLBACK_DEPTH epochs)
                                            │
                                            ▼
                                     PERMANENTLY CLOSED
```

**R21.3 (THE ORDERING CONSTRAINT THAT IS EASY TO GET WRONG).** *DRAIN must precede CLOSE, and NOTIFY must precede CLOSE.* **Closing an edge with `in_flight > 0` silently drops messages, and a silent drop on a warrant-bearing class violates COMM-INV-06 (failure must not become invisible).** **Notifying dependents before closure is what allows circuits to reroute (§24) rather than discover the loss by timeout — and the difference is one epoch of degraded computation versus one timeout interval of *no* computation.**

---

# §22. LOCALITY

## 22.1 «How much information should a cell have about the network?»

| Candidate | Cost | Verdict |
|---|---|---|
| **Purely local** (only immediate connections) | `O(degree)` | ✅ **Sufficient for 6 of 7 functions** |
| **Neighborhood-aware** (local topology, 2 hops) | `O(degree²)` | ⚠️ **Needed only for rerouting** |
| **Regional** (regional context, relay identity, regional demand) | `O(1)` per region summary | ✅ **Needed, and cheap because it is a summary, not a topology** |
| **Global** (can query global topology) | `O(N)` state or `O(N)` query | ❌ **NEVER MANDATORY** |

## 22.2 The minimum locality per function

| Function | **Minimum locality required** | **Why not more** |
|---|---|---|
| **Learning** | **PURELY LOCAL.** Eligibility traces + gated error + `gain` bounds | Cell §9's learning rule is `Δw = plasticity_rate × lr_fast × eligibility_trace × gated_error_signal` — **every term is local.** A learning rule requiring global topology would be `O(N)` per update, and P0-01 §23.2 already establishes that per-step learning must be correlational and cheap |
| **Routing** | **NEIGHBORHOOD + REGIONAL RELAY IDENTITY.** Know your admissible next hops and your region's relay | §24.3: hierarchical routing needs one upward pointer, not a table |
| **Specialization** | **LOCAL + REGIONAL DEMAND.** Cell §15's `DEMAND(role, region, magnitude)` is a regional morphogen, not a global one | Global demand would make every specialization decision depend on global state ⟹ `O(N)` coupling |
| **Evidence aggregation** | **LOCAL root set + EPOCH-DELAYED ACCESS TO THE ANCHORED REGISTRY** | §14.4: local checking is Bloom-approximate; exact checking needs Tier 3, which is epoch-delayed. **The delay is the cost of not requiring global state on-line** |
| **Attention** | **REGIONAL.** Attention modulates admission and gain within a scope | §44: a global attention mechanism is §65's broadcast audit target |
| **Fault tolerance** | **NEIGHBORHOOD.** Reroute around a DEGRADED edge using 2-hop knowledge | Global rerouting would require global topology and would be slower than local rerouting |
| **Emergence** | **LOCAL.** Novel local protocols (§50) arise in neighborhoods | **Global visibility of local experimentation is what makes experimentation impossible** — §59's privacy argument |

**R22.1 (THE LOCALITY RULE).** *No communication function may require global topology knowledge. The only global artifacts a cell needs are **the epoch counter** and **the policy version reference** — both `O(1)`, both distributed hierarchically, both cached.* **⟹ §84 confirms: there is no `O(N)` per-cell state requirement anywhere in this contract.**

**R22.2 (WHY THIS IS NOT MERELY A SCALABILITY PREFERENCE).** *Global topology knowledge in every cell is also a **security** defect and an **evolutionary** defect.*
- **Security:** a cell that knows the global topology knows where the hubs, the mandatory paths, and the relay bottlenecks are — **which is exactly the information §67's #15 (hub capture), #20 (route manipulation), and #23 (`O(N²)` topology collapse) attacks need.** Least privilege (§59) applies to topology as much as to payload.
- **Evolutionary:** a population whose members all share a global view cannot diverge locally, and **local divergence is the substrate of specialization (§51) and of the exploratory behaviour P0-01 §37's P1–P6 mechanisms protect.**

---

# §23. ADDRESSING — **OUTPUT 12**

## 23.1 «Analyze the scalability of global addressing at 10 → 10¹²»

| N | Flat global ID + global routing table | **Hierarchical + local resolution** |
|---|---|---|
| **10** | Trivial either way | Trivial |
| **10³** | Table = 10³ entries per node ⟹ 10⁶ total. Feasible | Feasible, unnecessary |
| **10⁶** | Table = 10⁶ per node ⟹ **10¹² entries total.** Infeasible in cell bounded memory | `O(R)` per node |
| **10⁹** | **10¹⁸ entries.** Absurd | `O(R)` per node |
| **10¹²** | **10²⁴ entries.** Absurd | `O(R)` per node, `R = 10¹–10²` |
| **Table churn** | Every creation/deletion invalidates every table ⟹ **`O(N)` per topology event** | Local only ⟹ `O(degree)` |

> ### **R23.1 (THE IDENTITY/ADDRESS SEPARATION — OUTPUT 12's core).** *A globally unique **identity** is required and affordable. A globally unique **routing address** is neither required nor affordable. They must be different objects.*

```
IDENTITY  (for ATTRIBUTION, WARRANT, PROVENANCE)
   cell_id : bytes<16>, Registrar-issued under KC-1 delegation (P0-02 §2.3)
   **Globally unique, permanent, never reused, never routable.**
   Used in: src attribution · root registry · anchored logs · lineage
            certificates · correlation dimension 2 (§14.3)
   Cost: O(1) per subject. **No table anywhere.**

ADDRESS   (for ROUTING)
   addr = { region_id : u16, local_id : u32 }
   **Hierarchical, locally significant, REASSIGNABLE on migration (§60).**
   Resolution: local_id within region (O(1) local table, bounded by region
   size); region_id via the regional relay hierarchy (O(log R) hops).
   Cost: O(region size) per relay, O(1) per cell.

THE THREE OTHER ADDRESSING FORMS (all already latent in the Cell Contract's
`dst : ⟨CellID | RegionID | CapabilityQuery | BroadcastScope⟩`):

   CAPABILITY ADDRESS   `CapabilityQuery{role, region, conn_type, min_class}`
                        ⟹ resolved by the regional registry, not by the
                          sender. **This is pub/sub (Alt E) done correctly:
                          the query is the topic, and resolution is a
                          regional service.**
   CONTENT ADDRESS      `content_hash` ⟹ **for memory retrieval only (§42)**,
                        where the content IS the identity of what is wanted.
                        **Not used for cell addressing** — content addressing
                        for cells would make identity mutable by content,
                        which breaks attribution.
   BROADCAST SCOPE      `{NEIGHBORHOOD | CIRCUIT | REGION}` ⟹ **never
                        ORGANISM or GLOBAL (§65).** A broadcast scope that
                        includes the whole organism is prohibited by
                        construction, not by policy.
   TEMPORARY ADDRESS    a session-scoped alias for privacy (§59) and for
                        migration (§60). **Binds to a cell_id for attribution;
                        expires with the session.**
```

**R23.2 (NO GLOBAL ROUTING TABLES).** *The architecture has no global routing table at any level.* Regional relays hold `O(region size)` local tables; the relay hierarchy holds `O(R)` pointers. **A cell holds `O(degree)` neighbor addresses and one relay pointer.** ⟹ **§89's agreement item «how connections work» is satisfiable by two teams without either building a global directory — which is the interoperability consequence, and it is why R23.1 is a contract requirement rather than an optimization.**

**R23.3 (THE COST OF REASSIGNABILITY).** *Because addresses are hierarchical and reassignable, an address is not a durable reference.* **Any durable reference — a provenance record, an evidence root, a lineage certificate, a `mandatory_path` designation — MUST use `cell_id`, never `addr`.** ⟵ *A provenance record keyed by address becomes meaningless after migration (§60), and §61's replay would then be unreconstructible. This is a defect class that is invisible until the first hardware migration, which is why it is stated as a rule.*

---

# §24. ROUTING — **OUTPUT 13**

## 24.1 The eight candidates

| Mechanism | Latency | State cost | Adaptivity | **Provenance/audit** | Verdict |
|---|---|---|---|---|---|
| **Direct routing** (only along existing edges) | ✅✅ Minimum | `O(degree)` | ❌ None | ✅ Fully local | ✅ **The default for S0/S1 within a neighborhood** |
| **Multi-hop routing** | ⚠️ `O(path length)` | `O(degree)` | ⚠️ | ✅ Per-hop logged | ✅ **Necessary where A does not connect to B** |
| **Hierarchical routing** | ✅ `O(log R)` | `O(R)` per relay | ✅ At region granularity | ✅ Per-relay digests | ✅ **ADOPTED as the inter-region mechanism** |
| **Learned routing** | ⚠️ Converges slowly | `O(degree)` | ✅✅ | ⚠️ **The route becomes a learned quantity, so route choice is not reproducible from policy alone** | ⚠️ **ADOPTED ONLY for next-hop selection among admissible hops (§24.2)** |
| **Content-addressed routing** | ⚠️ Lookup cost | `O(content index)` | ✅ | ⚠️ | ⚠️ **Memory retrieval only (§23.1)** |
| **Broadcast** | ✅ | `O(1)` sender / `O(scope)` total | ❌ | ❌ **No per-receiver record** | ⚠️ **Scope-bounded to NEIGHBORHOOD/CIRCUIT/REGION (R23.1)** |
| **Local diffusion** | ⚠️ Slow, `O(diameter)` | `O(1)` | ✅ | ⚠️ | ✅ **For morphogen/demand/modulation (Cell §6.2), where a gradient is the intended semantics** |
| **Hybrid** | — | — | — | — | ✅ **ADOPTED, partitioned by class (§24.3)** |

## 24.2 «Is routing itself cognitive or merely transport infrastructure?»

> ### **It is both, and the split is the answer — because the unsplit version permits §19's most dangerous plasticity path.**

```
TRANSPORT ROUTING — **INFRASTRUCTURE, NOT COGNITIVE, NOT LEARNABLE**
  • the address hierarchy and relay structure
  • the admissible next-hop SET for a message of a given class
  • `mandatory_path` inclusion in the admissible set (always)
  • region-crossing permissions and rate limits
  • loop prevention, TTL enforcement, broadcast scope enforcement
  ⟹ **Deterministic, policy-defined, identical across implementations.**
     Two teams must agree on this (§89), so it cannot be learned.

COGNITIVE ROUTING — **INFLUENCE PLANE, LEARNABLE, BOUNDED**
  • SELECTION among admissible next hops (which of the three permitted
    relays to use now)
  • `gain`-weighted propagation decisions (whether to forward at all,
    within the influence budget)
  • local rerouting around a DEGRADED edge, **within the admissible set**
  ⟹ **Learnable, because it is a preference among permitted options.**

**WHY THE SPLIT IS NECESSARY AND NOT MERELY TIDY:**
  If routing were wholly cognitive, then plasticity could learn a route that
  avoids a monitored relay (§19.2 Q1's residue) or deprioritizes a
  `mandatory_path` until it is pruned for inactivity (Cell §14.4's
  anti-fragility concern at the routing layer). **Both are R0.3
  influence⟶transport violations.**
  If routing were wholly infrastructure, then §28's "fast but noisy vs slow
  but reliable" trade-off could not be learned, and the organism would need
  a policy for every context — which is unscalable and unadaptive.

⟹ **R24.1: the ADMISSIBLE SET is infrastructure; the SELECTION within it is
   cognition. `mandatory_path` edges are in every admissible set that
   contains any of their endpoints, and their selection weight has a
   policy-defined floor.**
```

## 24.3 **OUTPUT 13 — the routing model**

| Class | Mechanism | Scope | Ordering |
|---|---|---|---|
| **S0** | **Direct** along existing edges; **local diffusion** for modulation | Neighborhood | None |
| **S1** | Direct within region; **hierarchical** across regions; capability-query resolution for `CapabilityQuery` destinations | Region → relay hierarchy | Per-channel `seq` |
| **S2** | Same as S1, **plus: a route that cannot preserve `root_commit` integrity is not admissible** | Region → hierarchy → anchor at epoch | Per-channel `seq` |
| **S3/S4** | **Deterministic, policy-defined routes over `mandatory_path` edges where they exist**; **no learned selection** | Hierarchy, with total order | **Epoch-total** |

**R24.2 (THE FIVE ROUTING FAILURE CASES).**

| Event | Response | **Class-dependent?** |
|---|---|---|
| **A does not connect to B** | Hierarchical: A → regional relay → B's regional relay → B. `O(log R)` | No |
| **Topology changes** | Local table update `O(degree)`; relay digest at epoch | **No — and crucially, no global invalidation (R23.2)** |
| **Cells die** | Neighbors detect by heartbeat absence (§7.2: best-effort, «a missed heartbeat is the signal»); route marked inadmissible; **dependents notified per R21.3** | No |
| **Regions reorganize** | Address reassignment (R23.1's reassignability); **`cell_id` references unaffected (R23.3)** | No |
| **Hardware changes** | §56/§57: transport-layer re-binding; **semantic layer and admissible sets unchanged** | No |
| **Communication partitioned** | §30: both sides continue within their admissible sets; **S3/S4 stall (`FC`), S0–S2 degrade (`FD`)** — P0-02's partition-by-irreversibility applied to routing | **YES — and this is the only class-dependent routing behaviour** |

---

# §25. NETWORK TOPOLOGY — **OUTPUT 14**

## 25.1 «Do not assume biological topology is computationally optimal»

| Topology | Diameter | Robustness to random failure | Robustness to targeted failure | Modularity | Cost | **Verdict** |
|---|---|---|---|---|---|---|
| **Random (Erdős–Rényi)** | `O(log N)` | ✅ | ✅ | ❌ **None ⟹ no specialization substrate** | `O(N log N)` edges for connectivity | ❌ |
| **Sparse random** | `O(log N)` | ✅ | ✅ | ❌ | `O(N)` | ⚠️ Baseline only |
| **Small-world (Watts–Strogatz)** | **`O(log N)`** | ✅ | ✅ | ✅ **Local clustering + long-range shortcuts** | `O(N × degree)` | ✅ **ADOPTED as the base structure** |
| **Scale-free (Barabási–Albert)** | `O(log log N)` | ✅✅ Excellent to random failure | ❌ **CATASTROPHIC to targeted hub removal** | ⚠️ | `O(N)` | ❌ **REJECTED as a global structure — §52's hub analysis** |
| **Lattice / local** | **`O(N^{1/d})`** ⟹ infeasible at 10⁹ | ⚠️ | ✅ | ✅✅ | `O(N)` | ❌ Alone; ✅ as the local substrate |
| **Hierarchical** | `O(log R)` | ⚠️ Relay is a SPOF | ❌ | ✅✅ | `O(N + R)` | ✅ **ADOPTED for inter-region** |
| **Modular** | `O(within) + O(between)` | ✅ | ⚠️ | ✅✅ | `O(N)` | ✅ **ADOPTED — but §53's echo-chamber risk requires bounded inter-module links** |
| **Dynamic / adaptive** | varies | ✅ | ✅ | ✅ | Rewiring cost | ✅ **Within envelope (§20)** |
| **Heterogeneous** (mixed degree) | — | ✅ | ⚠️ | ✅ | — | ✅ **Necessary: uniform degree has no hubs and `O(N)` diameter (§2.5)** |

## 25.2 **OUTPUT 14 — the topology model**

> ### **R25.1.** *Bounded-degree small-world over a local lattice substrate, organized into modules with hierarchical inter-module relays, heterogeneous degree within policy bounds, and dynamically rewirable within the pre-authorized envelope.*

```
THE STRUCTURE, LEVEL BY LEVEL:

  LOCAL (within a circuit):  lattice/low-diameter, degree ≤ genome cap.
                             Direct edges, S0 diffusion. **No relay.**
  MODULE (circuit → region): small-world — high local clustering plus a
                             bounded number of long-range shortcuts.
                             **The shortcuts are what give O(log N) diameter
                             without hubs.**
  REGION:                    a relay per region; regional registry;
                             regional Topology Service (GP, delegated).
  INTER-REGION:              hierarchical relay tree, O(log R) hops.
                             **R is 10¹–10² (P0-02 §27).**
  ORGANISM:                  **no topological node.** There is no root
                             router. The only organism-wide structures are
                             the epoch counter, the policy reference, the
                             workspace (§43), and the anchor (§15.3) —
                             **all O(R) or O(1), none a routing node.**

WHAT EACH PROPERTY BUYS:
  low latency        ⟵ small-world diameter O(log N) + hierarchical relays
  robustness         ⟵ bounded degree ⟹ no hub whose removal partitions
                       (§52); redundant local paths
  specialization     ⟵ modularity (§51's demand-driven differentiation)
  modularity         ⟵ modules with bounded inter-module link density
  emergence          ⟵ local rewiring within envelope (§20) + OPAQUE class
                       (§49) + local privacy (§59)
  fault tolerance    ⟵ local rerouting (§24.2 cognitive routing), DEGRADED
                       states, drain-before-close (R21.3)
  evolutionary exploration ⟵ topology PRIORS are heritable (§48), specific
                       connections are not (Cell §3.4)
  resource efficiency ⟵ degree caps + influence budgets (§35) +
                       bandwidth charging (§27)

**WHY NOT SCALE-FREE, PRECISELY:**
  Scale-free topology is robust to random failure and **catastrophic to
  targeted failure** — and this architecture has an adversary (§67). A
  topology whose failure mode under attack is fragmentation is a topology
  that hands the attacker a target list. **Small-world with bounded degree
  has no such list.** §52 develops this: hubs are permitted as *useful*
  structures but bounded in *influence*, which is a different axis from
  degree.
```

**R25.2 (THE BIOLOGICAL COMPARISON, HONESTLY).** *Cortex is approximately small-world with heterogeneous degree and hierarchical modularity — so R25.1 is consistent with biology.* **But the derivation did not use that fact.** Small-world was selected because it minimizes diameter subject to a degree bound, and hierarchical modularity because it makes `O(R)` aggregation possible. **Had biology pointed elsewhere, the scoring in §25.1 would have prevailed** — which is what §96's «do not assume biological communication is computationally optimal» requires.

---

# §26. THE `O(N²)` FAILURE

## 26.1 The constraint set

> ### **R26.1.** *Total connections are `O(N × degree)`, and degree is bounded by the genome and by policy. `O(N²)` arises only within an explicitly bounded local population, and the bound is a policy parameter.*

| Mechanism | What it constrains | **Where it lives** |
|---|---|---|
| **Maximum in-degree** (`max_connections`) | Aggregate input volume per cell | **Genome** (Cell Contract §4.1: `max_connections : u16`, «in-degree cap») — **heritable as a prior, bounded by policy** |
| **Maximum out-degree** (`max_fanout`) | Amplification per cell (§35) | **Genome** (`max_fanout : u16`, «out-degree cap») |
| **Local neighborhood** | S0/S1 scope | Topology (lattice/module) |
| **Hierarchical aggregation** | `O(N)` → `O(R)` | §15.3 Tier 3 · §20.3 delegation · §25.1 relays |
| **Sparse routing** | Path count | §24.3 |
| **Dynamic rewiring** | Degree concentration | §20/§21 within envelope |
| **Regional communication** | Cross-region volume | Rate limits (§50), relay-mediated |
| **Broadcast domains** | Broadcast fan-out | **R23.1: scope ∈ {NEIGHBORHOOD, CIRCUIT, REGION}; ORGANISM and GLOBAL are prohibited by construction** |
| **Loop-gain constraint** | Cascade amplification | Cell §14.2 step 3 (from audit §B.12): **`Σ gain around a cycle < 1`** — an influence-plane bound enforced at connection *creation*, which is strictly cheaper than enforcing it at propagation |
| **Influence budget** | `fan_out × gain` per subject per window | §35 — **the mechanism that makes degree caps insufficient on their own** |

## 26.2 «Do not invent fixed numbers without evidence»

**No degree bound, region size, relay count, shortcut density, or budget value is asserted anywhere in this contract.** Each is a §70 parameter with a class:

| Parameter | Class | Derivation |
|---|---|---|
| `max_connections`, `max_fanout` | `[D]` architecture-defined bound + `[V]` evolutionary prior | **Derivable from the aggregation cost model: a cell's per-step budget must cover `Σ degree × transform_cost`. Given a compute budget, degree is determined — not chosen** |
| Region size `R_size` | `[H]` hardware-defined + `[D]` | Determined by the latency/bandwidth profile: a region is the set of subjects within one low-latency domain. **P0-02 §27's `R = 10¹–10²` is a consequence of this, not an assumption** |
| Shortcut density | `[D]` | Determined by the target diameter: `O(log N)` requires `O(1)` shortcuts per node in a Watts–Strogatz construction. **The relation is analytic; the value follows from the target** |
| Influence budget | `[G]` governance + `[E]` environment | Set against the measured cascade threshold (§35) |
| Broadcast scope sizes | `[D]` | Bounded by region size |

**R26.2 (THE `O(N²)` AUDIT RULE).** *Any proposed mechanism whose connection, message, or state count is `Ω(N²)` — or `Ω(N × degree)` with unbounded degree — must be rejected unless it is scoped to a bounded local population whose bound is a declared policy parameter.* **Applied to the record: the Cell Contract's `seq per (src,dst,conv)` is `O(peers × conversations)` per cell (§8.3's correction), and its per-message signature is `O(N × degree)` cryptographic operations per epoch (P0-02 R19.2). Both are caught by R26.2.**

---

# §27. BANDWIDTH ECONOMICS — **OUTPUT 15 (part 1)**

## 27.1 The eight costs

| Cost | Borne by | **Scaling** | Reducible by |
|---|---|---|---|
| **Payload size** | Sender + receiver | `O(bytes)` | Compression — **but lossy only on payload, never on warrant (§63.3)** |
| **Transmission cost** | Transport | `O(bytes × hops)` | Locality (§22), hierarchical routing (§24) |
| **Reception cost** | Receiver | `O(bytes)` + ingress validation | **S1a/S1b split (§68 X-J): ordinary traffic skips warrant validation entirely** |
| **Processing cost** | Receiver | `O(transform)` | Bounded by the cell's compute budget |
| **Storage cost** | Holder | `O(retained)` | §15.2's discard rules; TTL; eviction with `capability_critical` exemption |
| **Routing cost** | Relays | `O(log R)` per hop | Local resolution (§23) |
| **Provenance cost** | Sender + anchor | **`O(1)` in-message + `O(R)` per epoch anchored** | §15.3's three tiers — **the single largest saving in the contract** |
| **Verification cost** | Receiver | **`O(warrant-class messages)`, NOT `O(messages)`** | §7.2's class assignment: S0/S1 get channel binding, not signatures |

## 27.2 «Should communication be optimized by information gain, relevance, urgency, novelty, uncertainty, task value, or resource cost?»

> ### **By the RATIO of expected information gain to resource cost — and the exchange rate is policy, not local.**

```
THE LOCAL RULE (what a cell computes):
   send(m)  iff  E[Δ information | m]  >  cost(m) × exchange_rate

   where:
     E[Δ information | m] is estimable LOCALLY from:
       • novelty       — does the receiver already hold these roots?
                       (**§14.4's root_overlap, computed at the sender for
                       its known neighbors: a message whose roots the
                       receiver already holds has zero marginal warrant**)
       • uncertainty   — the sufficient statistics' epistemic component
       • relevance     — conn_type / port compatibility with the receiver
     cost(m) is METERED, not declared (§4.2): bytes × hops + verification
       class cost + provenance cost
     **exchange_rate is POLICY (RO-15/RO-13), not a cell parameter.**

WHY THE EXCHANGE RATE MUST BE POLICY AND NOT LOCAL:
  If each cell chose its own exchange rate, the population would optimize
  communication volume per-cell, and the aggregate would be unbounded —
  §34's flooding arising from locally-rational behaviour. **The exchange
  rate is how the organism's communication budget is expressed to its
  parts, and P0-02 §7.4's four-principal resource split applies: DEFINITION
  (OP) · ENFORCEMENT (KC-3 ceiling) · ALLOCATION (homeostasis) ·
  ATTRIBUTION (metering/EVA).**

THE SEVEN CANDIDATE OPTIMIZATION CRITERIA, ADJUDICATED:
  information gain  ✅ **the numerator**
  relevance         ✅ **a gate, not a term** — an irrelevant message has
                      zero gain regardless of cost
  urgency           ⚠️ **DERIVED from type (§4.2), never sender-asserted**
                      — otherwise §38's false-urgency attack
  novelty           ✅ **a component of information gain** (root_overlap)
  uncertainty       ✅ **a component of information gain** (epistemic var)
  task value        ❌ **NOT a local criterion.** Task value is EVA's
                      (P0-01) and is not computable inside the organism.
                      **A cell that estimates task value is performing
                      alethic work it is not authorized to perform
                      (P0-01's authority lattice L4/L5: organism and cell
                      estimates, never verdicts)**
  resource cost     ✅ **the denominator, metered**
```

## 27.3 «Can communication economics create useful specialization?»

> ### **Yes — and it creates pathological specialization by the same mechanism. §51 analyzes the feedback; the stabilizers are there.**

**R27.1 (THE POSITIVE MECHANISM).** *Charging for communication makes local computation cheaper than remote consultation, which selects for subjects that can compute locally — i.e., for specialists.* **Cell §15's demand-driven specialization (`DEMAND(role, region, magnitude)` on service-level deficit) is this mechanism operating: a region that pays heavily for a capability generates demand for a local provider.**

**R27.2 (THE PATHOLOGY, NAMED HERE AND ANALYZED IN §51).** *The same feedback can produce a communication monopoly: a subject that is cheap to consult becomes more consulted, which makes it more specialized, which makes it cheaper, which concentrates demand.* **§51's stabilizers: influence budgets · degree caps · lineage-concentration limits · the sole-occupant exemption (P0-01 INV-34) cutting the other way · and mandatory redundancy for `mandatory_path` services.**

---

# §28. LATENCY ECONOMICS — **OUTPUT 15 (part 2)**

## 28.1 «Is latency a physical, routing, learned, task-dependent, or cognitive property?»

| Candidate | Verdict | **Form** |
|---|---|---|
| **Physical hardware property** | ✅ **The floor** | `latency_hw(platform_class, distance)` — `[H]`, not learnable, not negotiable |
| **Routing property** | ✅ **The variable part** | `hops × per_hop_latency` — determined by §24's route, `O(log R)` inter-region |
| **Learned property** | ⚠️ **Only as selection among admissible routes** | §24.2's cognitive routing. **A learned route preference changes latency; it cannot change the latency floor or the admissible set** |
| **Task-dependent property** | ✅ **As a DEADLINE, not as a latency** | P0-01's task specification may impose a deadline; **latency is measured, deadlines are imposed, and conflating them makes a task requirement look like a system property** |
| **Cognitive property** | ❌ **REJECTED** | **Latency is not a mental state.** What is cognitive is the *trade-off preference* between latency and reliability, which is a learned selection policy (§28.2) — not latency itself |

## 28.2 «Can circuits learn to prefer fast-but-noisy versus slow-but-reliable?»

> ### **Yes — and this is a legitimate, useful, learnable trade-off, provided it is confined to the transport and influence planes.**

```
THE TRADE-OFF IS REAL AND IS ALREADY REPRESENTABLE:
  Cell §14.5 measures `latency_measured` and `reliability` SEPARATELY, as
  distinct EWMAs. **The brief's instruction "do not collapse latency into
  reliability" is already satisfied by the prior contract, and this package
  preserves it and explains why the separation is load-bearing:**

  A fast-noisy route and a slow-reliable route have the SAME expected
  information delivery rate when  reliability_fast × (1/latency_fast)
  ≈  reliability_slow × (1/latency_slow)  — **but they differ in VARIANCE
  and in TAIL BEHAVIOUR, and the difference matters for deadlines.**

  ⟹ **The learnable quantity is a preference over (latency, reliability)
     pairs, and it is legitimate because both are MEASURED (§18.1 Group 2,
     cell read-only) rather than asserted.** A circuit can learn "for
     deadline-bearing traffic prefer the fast route; for warrant-bearing
     traffic prefer the reliable one."

THE CONSTRAINT THAT MAKES IT SAFE (R0.3, applied):
  ❌ **The learned preference may NOT alter the WARRANT of what arrives.**
     A message that took the fast-noisy route and arrived intact warrants
     identically to one that took the slow-reliable route. **Route choice
     affects the probability of arrival, never the licensing of the content.**
  ❌ **The learned preference may NOT bypass `mandatory_path`** (§24.1:
     S3/S4 use policy-defined routes with no learned selection).
  ✅ **The learned preference MAY affect S0/S1/S2 route selection within the
     admissible set, and MAY affect retry policy within the retry budget
     (§7.4 R7.2).**

⟹ **R28.1: latency/reliability preference is an influence-plane learned
   quantity bounded by the transport-plane admissible set. It is the cleanest
   available example of R0.3 working as intended: something genuinely
   adaptive, genuinely useful, and genuinely incapable of becoming an
   authority.**
```

**R28.2 (THE ONE PLACE LATENCY MUST NOT BE OPTIMIZED).** *S3/S4 governance and safety traffic uses policy-defined routes and retry-until-confirmed (§7.2).* **Optimizing freeze-command latency by route learning would make the safety response a function of learned preference — and a learned preference is evolvable, which means §19.2's Q3 closure would depend on the routing learner's cooperation.** *Safety commands take the slow, certain, non-learned path.*

---

# §29. PACKET LOSS / COMMUNICATION FAILURE

## 29.1 The nine failure cases

**«Assume communication failures occur.»** The response set the brief offers: retry · infer missing information · lower confidence · reroute · ignore · quarantine · escalate · continue autonomously. **The correct response is class-dependent, and one of the eight is prohibited outright.**

| Failure | Detected by | **S0** | **S1** | **S2** | **S3/S4** |
|---|---|---|---|---|---|
| **Dropped** | `seq` gap / timeout | **ignore** (loss is normal and is information) | **ignore + count**; requester sees a timeout | **lower confidence + report**; `E_IN_MISSING` ⟹ «use prior `h`; **degrade `epistemic_var` upward**; report» (Cell §6.3 case 1, preserved) | **retry until confirmed** (§7.2) + escalate on exhaustion |
| **Corrupted** | Integrity check | ignore + count | drop, `E_IN_INTEGRITY` | **drop; quarantine-candidate the source; PRESERVE the corrupt artifact as evidence** (Cell §6.3 case 6: «do NOT discard — audit §B.11») | drop + **immediate escalation** |
| **Delayed** | `ttl_hops` / `epoch` | ignore | EXPIRED | EXPIRED; **systemic staleness (rate > θ) reported as the `COMMUNICATION` error class** (Cell §6.3 case 4) | EXPIRED + escalate (a late safety command is a failed safety command) |
| **Duplicated** | `msg_id` dedup | n/a (no dedup on S0 — **and this is correct: deduplicating edge activations would require state the cell does not have**) | DUPLICATE, counted | **DUPLICATE, counted, and `msg_id` retained past expiry (§32)** | DUPLICATE + **idempotent application mandatory (R7.3)** |
| **Reordered** | `seq` | n/a | **process out of order** (window-based aggregation) | process out of order; **warrant computed jointly (§6.1 R6.1's CONFLATED check)** | **hold until ordered** (epoch-total) |
| **Stale** | `epoch` mismatch | ignore | EXPIRED | EXPIRED | EXPIRED + escalate |
| **Partial** | Length/schema check | ignore | MALFORMED | MALFORMED, `E_IN_SCHEMA` | MALFORMED + escalate |
| **Malformed** | Type Registry resolution | ignore | **drop, `E_IN_SCHEMA`; increment `invariant_violations` if repeated from the same source; report source to immune** (Cell §6.3 case 2) | same | same + escalate |
| **Adversarial** (valid signature, valid schema, statistically anomalous) | Anomaly detector on payload distribution + emission rate + provenance depth | ignore (S0 has no warrant to attack) | rate-limit + count | **DIVERT TO EVIDENCE SANDBOX** — «admitted to a *non-influential* path where it cannot affect `θ` or output until independently corroborated; source flagged» (Cell §6.3 case 8, **preserved verbatim — it is the best-designed response in the prior contract**) | **quarantine + escalate + preserve** |

## 29.2 The prohibited response

> ### **R29.1. «Infer missing information» is PROHIBITED for warrant-bearing classes.**

```
THE TEMPTATION: a message is missing, the receiver has a model, the model can
predict what the missing message said. Why not use the prediction?

WHY NOT — AND IT IS NOT A CAUTION, IT IS A STRUCTURAL PROHIBITION:

  1. **AN INFERRED MESSAGE HAS NO EVIDENCE ROOT.** Fabricating a root is
     P0-01 R6.1's E0 prohibition (an observation at E0 MUST NOT contribute
     to `evidence_roots`) executed by the receiver instead of the sender.

  2. **IT CONVERTS COMMUNICATION FAILURE INTO EVIDENCE.** This is
     COMM-INV-06's exact target: «communication failure cannot silently
     become evidence of success.» A dropped message that is inferred has
     become a *successful* observation, and the drop is now invisible.

  3. **IT CLOSES THE LOOP THAT DETECTION NEEDS OPEN.** §14's independence
     checking compares a receiver's root set against incoming roots. If the
     receiver manufactures roots from its own model, the comparison becomes
     self-referential — **and this is precisely Cell Contract FM-4
     (self-confirming recall), which the prior contract already identified
     as «the dangerous one».** Inference-on-loss is FM-4 with the memory
     system replaced by the transport.

  4. **IT IS UNDETECTABLE.** §0.5's warrant-plane failure. A receiver that
     infers has no way to know it inferred, because the inference is
     indistinguishable from a reception in its own state.

WHAT IS PERMITTED INSTEAD — and the Cell Contract already specifies it:
  «Missing (expected input absent past deadline) → Emit
   `AbstainCode.INPUT_MISSING`; **use prior `h`**; **degrade `epistemic_var`
   upward**; report» (Cell §6.3 case 1).

  ⟹ **Using the prior is not inferring the message.** The prior is the
     receiver's existing state, honestly labelled as unchanged; the
     variance increase is the honest representation of the missing
     information; and the report makes the loss observable.
     **Three acts, none of which fabricates a root.**

⟹ **R29.1 (restated): on loss, a receiver may DEGRADE (raise variance),
   ABSTAIN, or REPORT. It may never IMPUTE.** For S0/S1 (no warrant),
   imputation is harmless because nothing is being believed — and indeed
   S0's "ignore" response is exactly that. **The prohibition binds where
   belief binds.**
```

## 29.3 The systemic-failure escalation

**Individual failures are handled per §29.1. Systemic failure is a different object:**

| Signal | Threshold | Response |
|---|---|---|
| **Staleness rate** | `> θ_stale_rate` | Report as the `COMMUNICATION` error class (Cell §6.3 case 4 — the class audit §E.1 found **missing from V3.1's taxonomy**) |
| **Repeated malformation from one source** | `invariant_violations` increments | **Immune report** (Cell §6.3 case 2) |
| **Repeated authentication failure** | `E_IN_AUTH` from one source | **Drop; immune report; increment the source's anomaly counter; for S3/S4 classes: immediate escalation** (Cell §6.3 case 7) |
| **Connection reliability below `θ_rel`** | measured | `state → DEGRADED`, reroute candidate (Cell §14.5) |
| **`consecutive_failures ≥ θ`** | measured | Circuit-break the link (Cell §10 case 6: «Mark link `DEGRADED`; reroute; circuit-break after θ retries») |
| **Aggregate loss rate across a region** | epoch digest | **Homeostasis → congestion response (§83); if it correlates with a topology change, immune investigation** |
| **Partition** | relay unreachable | **§30's full protocol** |

**R29.2 (THE LEARNING CONSTRAINT ON FAILURE).** *Cell §10 case 6's directive is preserved and generalized: **«Reduce connection `reliability`; do NOT learn `θ` from missing data.»*** **A communication failure is evidence about the CHANNEL, never about the WORLD.** Learning `θ` from a dropped message teaches the transform that the world withheld information, which is a category error and a §47 reward-hacking channel (a subject that can induce drops can induce learning). ⟵ **This is R0.3's transport⟶warrant prohibition in its most consequential application.**

---

*End of Volume B. Volume C (`19_analysis_partition_planes.md`) covers §30–§47: network partition, split-brain reconciliation, replay, forgery, flooding, amplification, cascades, correlated failure, adversarial content, the four planes, governance and evaluator signals, memory communication, the global workspace, attention, learning signals, credit assignment, and reward hacking.*
