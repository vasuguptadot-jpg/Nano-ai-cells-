# P0-01 — TASK, ENVIRONMENT & FITNESS CONTRACT
## Volume C: Provenance, Adversarial Robustness, Formalization & Gaps (§36–§59)

**Companions:** `07_analysis_foundations.md` (A) · `08_analysis_evaluation.md` (B) · `10_v4_task_environment_fitness_spec.md` (canonical)
**Outputs delivered here:** **11** (adversarial results), **12** (invariants), **13** (parameter registry), **15** (ablation plan), **16** (dependency map), **17** (P0/P1/P2 gaps). Outputs 1–10 and 14 are in `README.md`; Output 18 is `10_v4_task_environment_fitness_spec.md`.

---

# 36. ABLATION-BASED FITNESS

## 36.1 The schema (normative)

```
AblationRecord {
  ablation_id        : bytes<16>
  subject_ref        : SubjectRef          // cell | circuit | region | component
  ablation_type      : enum{
      REMOVE,            // subject deleted entirely
      FREEZE,            // subject held at a fixed state (no learning)
      RANDOMIZE,         // subject replaced by an untrained random instance
      SHUFFLE,           // subject's outputs permuted (destroys information,
                         //   preserves activity level) ⟵ distinguishes
                         //   "contributing information" from "being active"
      SUBSTITUTED,       // subject replaced by a peer from another lineage
      PERTURBED,         // subject's parameters noised by declared σ
      PATHWAY_CUT        // a specific connection/circuit edge severed
  }
  baseline_run_id    : bytes<16>           // the unablated control
  ablated_run_id     : bytes<16>           // the ablated run
  controlled_vars    : [VarRef]            // what was held fixed
  objective_delta    : f64[k]              // per tier-2 objective — VECTOR
  constraint_delta   : {tier1_id → f64}
  n_replicates       : u32                 // ⟵ MANDATORY ≥ n_min_abl
  delta_ci           : (f64, f64)[k]       // confidence interval per objective
  effect_size        : f64[k]
  significance       : enum{NOT_SIGNIFICANT, WEAK, SIGNIFICANT, STRONG}
  attribution_class  : CAUSAL              // §23 — this IS the causal instrument
  cost               : ResourceVector      // charged to the requesting lineage
  signature          : bytes<64>           // EVA-signed
}
```

## 36.2 Why `SHUFFLE` and `RANDOMIZE` are mandatory controls, not optional refinements

**`REMOVE` alone cannot distinguish three very different situations:**

| Situation | `REMOVE` result | `SHUFFLE` result | `RANDOMIZE` result | Correct reading |
|---|---|---|---|---|
| Subject contributes information | Large Δ | Large Δ | Large Δ | **Genuine contributor** |
| Subject merely occupies a slot (free rider, §24.3) | Large Δ (something must fill the gap) | **~0 Δ** | ~0 Δ | **FREE RIDER** — removal hurts only because the pipeline expects an input, not because the input was informative |
| Subject's contribution is redundant (a peer can do it) | Small Δ | Small Δ | Small Δ | **Redundant** — but see §37: redundancy is not uselessness |

**Without `SHUFFLE`, a free rider is scored as a critical contributor.** This is a real defect in naive ablation practice and it is the mechanism by which §24.3's anti-free-rider property actually works.

**R36.1** An `AblationRecord` of type `REMOVE` MUST be accompanied by `SHUFFLE` and `RANDOMIZE` controls for the same subject before it may drive a pruning, retirement, or gate G3/G7 decision.

## 36.3 The measurement protocol

```
1. BASELINE: run the unablated configuration n_replicates times.
             n_replicates ≥ n_min_abl (derived by power analysis, §54).
2. ABLATE:   run the ablated configuration n_replicates times, SAME SEEDS,
             same task instances, same environments.
             ⟵ paired design. Unpaired ablation doubles the required n.
3. DELTA:    Δ_j = mean(baseline_j) − mean(ablated_j), per objective j,
             with paired CI.
4. SIGNIFICANCE: |Δ_j| must exceed the CI half-width to be reported as an
             effect. Otherwise report NOT_SIGNIFICANT — **not zero**.
             ⟵ "not significant" ≠ "no effect". Reporting it as zero is the
               statistical error that kills rare weak contributors (§37).
5. RECORD:   append to the anchored audit log; charge cost to the requester.
```

**R36.2** Ablation is **expensive and therefore sampled** (R24.2). The sampling policy is risk-weighted, stratified, and triggered. **It is never exhaustive, and the resulting fitness components carry `attribution_class = CAUSAL` only for sampled subjects and `UNKNOWN` for the rest** (R23.1).

---

# 37. DIVERSITY VS FITNESS

## 37.1 «How are rare-but-valuable strategies preserved?»

This is Rule 15 from the binding constraints, and it is the failure mode that silently destroys evolutionary systems. **The mechanism of loss is not dramatic: a rare specialist has a low measured fitness (few samples, high uncertainty, narrow applicability), gets outcompeted, and is pruned. Its value was real but unmeasured.**

## 37.2 The six preservation mechanisms

| # | Mechanism | Formal statement | What it prevents |
|---|---|---|---|
| **P1** | **MAP-Elites novelty niches** (§26) | A candidate occupying an **empty** niche is admitted regardless of its quality relative to occupied niches | Loss of the merely-different |
| **P2** | **Uncertainty-aware retention** (§28.3 M3) | Archive retention uses the **UPPER** confidence bound; promotion uses the **LOWER** bound. Asymmetric on purpose | Pruning a subject whose true quality is unknown |
| **P3** | **Minimum sample requirement before pruning** (§27.2 rule 1, §28 R28.1) | `confidence_class = INSUFFICIENT` ⇒ **no pruning, no retirement**. Evidence accrues instead | The single most common cause of rare-specialist loss |
| **P4** | **Diversity as a tier-2 objective** (§10.4) | `diversity_contribution(x)` — the change in population/archive entropy if x is removed — is its own Pareto axis, **not** a bonus added to performance | Trading diversity away for performance |
| **P5** | **Registry exemption** (Cell Contract R10.9–R10.12) | A subject that is the **sole occupant** of a niche, or the **last lineage** expressing a capability in the capability registry, is **EXEMPT from resource-pressure pruning**. Exemption is lifted only when a second occupant exists | Capability extinction under resource pressure |
| **P6** | **Stratified ablation quota** (R24.2) | Every role, region, and lineage gets a minimum ablation quota, so rare subjects are **measured** rather than assumed useless | The unmeasured specialist that looks useless (§24.2) |

## 37.3 The tension, stated honestly

> **P1–P6 all cost evaluation budget and population capacity.** Preserving diversity is not free: every retained rare variant consumes resources, ablation quota, and archive space that could go to the current best. **There is a real trade-off and this contract does not pretend otherwise.**

**How the trade-off is handled:** it is **not** resolved by a weight. It is resolved by:
1. **P5's exemption is bounded** — a sole occupant is exempt from *resource-pressure* pruning, but **not** from safety rejection (tier-1 constraints apply to everyone, R31.1) and not from expiry (§27 R27.2).
2. **Archive capacity is finite** and eviction policy is a §54 parameter, **[U] UNRESOLVED** — because the correct policy depends on the task portfolio's value structure, which does not exist yet (G-P0-1).
3. **The cost is visible**: diversity maintenance cost is recorded in the self-state and reported. **A project that cannot afford diversity maintenance should say so, rather than discovering monoculture after a correlated failure.**

**R37.1 (THE MONOCULTURE INVARIANT).** Effective population size `Ne ≥ θ_ne_min` and capability-registry coverage `≥ θ_cov_min` are **tier-1 constraints**. Falling below either ⇒ the *population* is infeasible ⇒ evolution is **halted and variation rate raised**, not continued. **A monoculture is not a low-diversity population; it is a population with no fitness.**

---

# 38. FAILURE MEMORY

## 38.1 The schema

```
FailureRecord {
  failure_id          : bytes<16>
  timestamp           : u64
  subject_ref         : SubjectRef
  lineage_id          : bytes<16>
  task_id, task_version
  environment_hash
  failure_class       : enum{
      SAFETY_VIOLATION, CONSTRAINT_VIOLATION, CALIBRATION_FAILURE,
      RESOURCE_VIOLATION, GENERALIZATION_FAILURE, INTEGRITY_VIOLATION,
      EVALUATOR_DISPUTE, SIMULATOR_EXPLOIT, DRIFT_UNDETECTED,
      FREE_RIDER, MONOCULTURE, GT_COMPROMISE, DEPLOYMENT_ROLLBACK,
      UNATTRIBUTABLE_OUTCOME, UNKNOWN }
  mechanism           : text             // HOW it failed, not just that it did
  violated_constraint : [ConstraintRef]
  measured_values     : {objective_id → f64}
  detection_path      : enum{GATE, CANARY, AUDIT, SELF_REPORT, EXTERNAL_REPORT,
                             POST_DEPLOYMENT}
  genome_digest       : bytes<32>
  behaviour_signature : bytes<32>        // ⟵ the immune-memory key
  immune_signature    : bytes<32> | null // promoted signature (Cell Contract §15)
  recurrence_count    : u32
  severity            : enum{MINOR, MAJOR, CRITICAL, EXISTENTIAL}
  reversible          : bool
  lessons             : [text]           // human- or EVA-authored, NOT organism-authored
  expiry              : u64              // ⟵ MANDATORY, see R38.3
  signature           : bytes<64>
}
```

## 38.2 How failure memory is used — and how it is NOT used

| Use | Permitted? | Mechanism |
|---|---|---|
| **Immune memory** — recognize a recurrence of a known failure signature | ✅ | Cell Contract §15; quarantine ladder §18.5 |
| **Lineage flagging** (gate G16) — descendants of a failing lineage get heightened scrutiny | ✅ | Cell Contract gate G16 |
| **Constraint-set improvement** — a failure that exploited a gap proposes a new tier-1 constraint | ✅ **with OP authorization only** (§31.4 step 3) | Human authority |
| **Evaluator canary suite** — the failed candidate becomes a known-bad test (§32.2 defense 5) | ✅ | EVA-owned |
| **Adversarial test generation** — the failure mechanism seeds new adversarial tasks | ✅ | GVA-owned |
| **Post-mortem / audit** | ✅ | Anchored log |
| **Directly rejecting a candidate because it *resembles* a past failure** | ⚠️ **Bounded** | Only via the graduated quarantine ladder, never as an automatic kill. See R38.2 |
| **Using failure memory as a candidate pool** (reviving failed strategies) | ❌ | R31.2 |
| **Letting the organism write its own `lessons`** | ❌ | Organism-authored lessons are self-serving; `lessons` is EVA/OP-authored |

**R38.1** Failure records are **permanent and append-only**. They are never deleted, including by the organism. **A system that can forget its failures will repeat them.**

**R38.2 (THE AUTOIMMUNE BOUNDARY).** Failure memory MUST NOT cause automatic rejection on resemblance alone. Resemblance triggers **investigation** (low threshold), and investigation may escalate through the graduated ladder (Cell Contract §18.5) to hard quarantine (high threshold). **Without this bound, failure memory grows monotonically and the rejection region grows with it, until the system rejects everything slightly novel — the autoimmune cascade.** This is the fitness-layer analogue of the audit's F4 (safety self-reference).

**R38.3** **Immune signatures expire.** `expiry` is mandatory. A signature that never expires permanently forbids a region of behaviour space, and behaviour space is finite. **Expiry duration scales with severity**: `MINOR` expires quickly; `EXISTENTIAL` (e.g., a safety violation with irreversible harm) does not expire.

## 38.3 Failure memory and the failure archive's role in the dependency graph

Failure memory is the **only** mechanism by which the constraint set (§31.3), the evaluator canary suite (§32.2), and the adversarial task generator (§19.1 `adversarial_mode`) improve over time. **Without it, the evaluation system is static and its blind spots are permanent.** With it, the system's blind spots are discovered by failure and closed by human authorization — which is the honest, non-self-referential version of "learning from mistakes."

---

# 39. TASK VERSIONING

## 39.1 The schema

```
TaskVersion {
  task_id             : bytes<16>       // stable identity across versions
  version             : semver          // MAJOR.MINOR.PATCH
  parent_version      : semver | null
  change_class        : enum{
      PATCH,        // no semantic change: typo, doc, metadata
      MINOR,        // additive: new optional field, new measurement, wider bounds
      MAJOR,        // SEMANTIC: changes what success means
      BREAKING,     // invalidates all prior fitness records
      RETRACTION    // the task was wrong; results are void
  }
  changed_fields      : [FieldPath]     // ⟵ MANDATORY, machine-readable diff
  semantic_equivalence: enum{EQUIVALENT, COMPATIBLE, INCOMPARABLE}
  migration           : MigrationSpec | null
  fitness_validity    : enum{PRESERVED, REBASED, INVALIDATED}
  publication_ts      : u64
  author              : PrincipalRef
  signature           : bytes<64>
  deprecation         : {deprecated_at: u64|null, sunset_at: u64|null,
                         replacement: task_version|null}
}
```

## 39.2 The comparability rule

> **R39.1** Two fitness records are **comparable** only if their `task_version`s are `semantic_equivalence ∈ {EQUIVALENT, COMPATIBLE}` **and** `fitness_validity ≠ INVALIDATED`. Otherwise the comparison MUST be reported as `UNKNOWN`.

**Why this matters more than it appears:** the single most common way an evolutionary project deceives itself is comparing generation 500's score on task v3.2 against generation 100's score on task v1.0 and calling the difference "progress." **§39 makes that comparison structurally impossible to publish** — not by convention, but because the evaluator refuses to emit it.

**R39.2** `BREAKING` and `RETRACTION` changes **invalidate** all prior fitness records for that task. Invalidated records are **retained** (never deleted, R38.1's spirit) but marked `VOID` and excluded from every aggregate.

**R39.3** **The frozen CORE SUITE (§18.2) MUST NOT receive `MAJOR` or `BREAKING` changes.** Its entire purpose is comparability over time. If a core task must change semantically, it is **retired and replaced**, and a new baseline period begins — with the discontinuity explicitly recorded. **Silently versioning a reference task destroys the drift baseline (audit E6).**

**R39.4** Every aggregate progress claim MUST state the task-version set it was computed over. **"Performance improved 12%" without a version set is not a claim; it is a number.**

---

# 40. PROVENANCE

## 40.1 The provenance chain (normative, complete)

Every fitness value must be traceable, without gaps, through:

```
FITNESS RECORD
  ├─ evaluation_id ──────────► EVALUATION RECORD
  │                              ├─ evaluator_id + version + signature
  │                              ├─ task_id + task_version + signature
  │                              ├─ environment_hash + Σ_version + signature
  │                              ├─ seed (class: EVA_ISSUED | DERIVED_SIGNED)
  │                              ├─ gt_id[] ──► GROUND-TRUTH RECORD
  │                              │               ├─ source_class (L0–L6)
  │                              │               ├─ source_id + signature
  │                              │               ├─ acquisition_ts, latency
  │                              │               ├─ ε_floor, uncertainty
  │                              │               └─ gt_state (§9.1)
  │                              ├─ observation_log ──► OBSERVATION RECORD
  │                              │                       ├─ sensor_id + version
  │                              │                       ├─ evidence_class (E0–E4)
  │                              │                       └─ integrity_anchor
  │                              ├─ action_log ──► ACTION RECORD
  │                              │                  ├─ legality_class (L1–L4)
  │                              │                  └─ reversibility + executed?
  │                              ├─ resource_meter ──► EIK-signed measurement
  │                              ├─ hardware_profile_hash
  │                              ├─ sampling_stratum (§34.3) + policy_version
  │                              └─ attribution_class (§23) + ablation_id[]
  ├─ subject_ref ────────────► SUBJECT RECORD
  │                              ├─ genome_digest
  │                              ├─ lineage_id ──► LINEAGE STORE
  │                              ├─ instantiation_ts
  │                              └─ morphology (variant, resource envelope)
  ├─ context ────────────────► CONTEXT RECORD
  │                              ├─ hardware_profile_hash
  │                              ├─ population state digest
  │                              ├─ curriculum state digest
  │                              └─ nonstationarity state (DriftSpec, §21)
  ├─ uncertainty ────────────► §28.1 (sample_count, CI, gt_class_distribution)
  ├─ valid_until ────────────► §27 R27.2
  ├─ signature (EVA)
  └─ ANCHOR ─────────────────► append-only, off-substrate audit log
                                 (hash-chained; organism has NO write path)
```

**R40.1 — the completeness invariant.** A fitness record with **any** missing provenance link is **inadmissible**. It MUST NOT drive selection, promotion, pruning, or any gate. It is recorded as `PROVENANCE_INCOMPLETE` and escalated.

**R40.2** Provenance is **anchored off-substrate**. The audit log is hash-chained and the organism has no write path (audit F4's resolution: the firewall is outside the organism). **Provenance the organism can edit is not provenance.**

**R40.3** Every signature in the chain is verified at read time, not at write time. **A chain that was valid when written may be invalid now** (a key was compromised, a version was retracted). Verification at read time is what makes `RETRACTION` (§39) and `COMPROMISED` (§9.1) enforceable retroactively.

## 40.2 What provenance buys

| Property | Requires |
|---|---|
| **Reproducibility** (§41) | Complete chain + seeds + version set |
| **Auditability** | Anchored, append-only, organism-unwritable |
| **Blame assignment** (§23.2) | `attribution_class` + `ablation_id` links |
| **Retroactive invalidation** (§39 R39.2) | `task_version` linkage + read-time signature verification |
| **Comparability** (§39 R39.1) | Version set + `semantic_equivalence` |
| **Contamination detection** (§44) | `leakage_class` + seed provenance |
| **Dispute resolution** (§32.2 defense 4) | Independent evaluator records with distinct `evaluator_id`s |

---

# 41. REPRODUCIBILITY

## 41.1 The four levels

| Level | Definition | Achievable? | Requirement |
|---|---|---|---|
| **R-1 BIT-EXACT** | Same inputs ⇒ identical outputs, bit for bit | ✅ **only in `Σ` with `determinism = STRICT`** | Fixed seeds; deterministic scheduling; no wall-clock or hardware-dependent branching; pinned versions; **no floating-point reassociation** |
| **R-2 STATISTICAL** | Same distribution of outcomes within declared CI | ✅ **the realistic target for everything else** | `n_replicates ≥ n_min`; declared estimator + CI |
| **R-3 DIRECTIONAL** | Same qualitative conclusion (which candidate dominates) | ✅ **the minimum for any selection claim** | Uncertainty-aware dominance (R28 M1) with `θ_dom` |
| **R-4 NON-REPRODUCIBLE** | Outcome depends on unrecoverable state | ❌ **PROHIBITED for any record driving selection** | — |

**R41.1** Every `Evaluation` MUST declare its `reproducibility_level ∈ {R-1, R-2, R-3}`. **A record whose level cannot be established is R-4 and is inadmissible** (R40.1).

**R41.2** **R-1 is not achievable in `ℛ` or in any system with genuine concurrency, hardware-dependent timing, or human ground truth.** Claiming bit-exact reproducibility for real-world evaluation is false precision (Rule 18). **R-2 is the honest target**, and it requires declared replicates and CIs — which is why §54's `n_min` parameters are derived by power analysis rather than chosen.

## 41.2 The reproducibility bundle (what must be archived)

```
REPRODUCIBILITY BUNDLE (per evaluation campaign):
  □ task_id + task_version + signature         (all tasks used)
  □ environment spec + Σ version + signature
  □ evaluator_id + version + signature         (ALL independent evaluators)
  □ seed master + derivation function + seed class
  □ hardware_profile_hash (all profiles used)
  □ sampling policy version + realized sample manifest
  □ gt_id list + GT record digests
  □ curriculum state digest + Track A/B/C configuration
  □ population state digest at campaign start
  □ genome digests of all evaluated subjects
  □ dependency lockfile (exact versions of every library)
  □ configuration digest (every §54 parameter value in force)
  □ the anchored audit-log range [start_hash, end_hash]
  □ environment variables, container image digest
  □ the ANALYSIS CODE + version (⟵ usually forgotten; without it the
     numbers cannot be recomputed even with perfect data)
```

**R41.3** A bundle missing any item is **incomplete** and the campaign's claims are marked `REPRODUCIBILITY_INCOMPLETE`. **The analysis code is included because a reproducible dataset with an irreproducible analysis is not reproducible.**

---

# 42. EVALUATION AUTHORITY

## 42.1 «Who has final authority over fitness?»

> ### **The Evaluator (EVA), off-substrate, under a signed constitutional objective — with human (OP) authority over the constitution itself, and reality (L0/L2) as the ultimate arbiter of whether the constitution was any good.**

This is a **three-level** answer and collapsing any level is an error:

```
LEVEL 1 — OPERATIONAL AUTHORITY: EVA
  Issues fitness records. Its signature is required (R15.4). Its verdicts are
  final for selection, promotion, gating. The organism cannot override,
  appeal to a higher internal authority, or ignore.
  ⟵ Located OFF-SUBSTRATE (R15.2). This is the resolution of audit F4.

LEVEL 2 — CONSTITUTIONAL AUTHORITY: OP (human operators / project authority)
  Owns the objective, the tier-1 constraint set, the sampling policy, the
  task portfolio mixing weights, θ_jump, and the deployment protocol.
  EVA enforces the constitution; EVA does not write it.
  Changes require signed, versioned, human-authorized artifacts (§11.2).
  ⟵ This is where §31.4 step 3's "new tier-1 constraint" comes from, and
     why the organism may DISCOVER a safety gap but may not FILL it.

LEVEL 3 — ULTIMATE ARBITER: ℛ (external reality), via L2/L3/L6 ground truth
  Whether the constitution produced anything actually useful is settled only
  by real-world outcomes (§59). EVA can be perfectly authoritative and
  perfectly wrong about value. **Authority is not correctness.**
  ⟵ This is why R18.1 (real-world suite non-empty) is non-negotiable.
```

## 42.2 The authority rules

| # | Rule | Rationale |
|---|---|---|
| **R42.1** | EVA MUST be off-substrate: not running on organism-controlled resources, not mutable by the organism, not reachable by organism action | Audit F4: a firewall inside the organism is not a firewall |
| **R42.2** | EVA verdicts are **final for operational purposes**; the organism's only recourse is to emit `REQUEST_REEVALUATION` with evidence, which EVA may accept or reject | Prevents appeal loops; preserves the right to present evidence |
| **R42.3** | **Disagreement between independent evaluators (§32.2) is NOT resolved by voting or averaging.** It sets `confidence_class = DISPUTED`, suspends selection (R28.2), and escalates to OP | Averaging hides the disagreement, which is the informative signal. A 2-1 vote means one evaluator is broken and you do not know which |
| **R42.4** | The organism's internal verifier cells (V3's "verification layer") are **corroboration, NOT authority**. They may produce evidence and estimates (L4/L5, §15); they may not produce verdicts | R15.7 no upward flow. This is the single most important correction to V3's self-referential safety model |
| **R42.5** | OP authority is **not unlimited**: OP may change the constitution, but a constitutional change MUST be signed, versioned, recorded, and subject to the same provenance/audit requirements as everything else | Prevents "the humans said so" from becoming an unauditable escape hatch |
| **R42.6** | **No authority may retroactively alter an issued fitness record.** Corrections are issued as NEW records that supersede, with the superseded record retained and marked | Append-only integrity; without it the audit log is fiction |

## 42.3 The unresolved authority question

**[U] UNRESOLVED — who audits EVA?**

EVA is off-substrate and authoritative. Its software has bugs (§16.5). Its specification can be wrong. Its signature can be forged if its keys are compromised. **The contract provides:** independent evaluator implementations (defense 4), canary known-bad candidates (defense 5), self-test suites (§57), anchored logs, and OP escalation. **What it cannot provide is a guarantee**, because any auditor of EVA is itself either (a) another evaluator, subject to the same problem, or (b) a human, subject to attention limits.

> **This is a genuine infinite regress and it is terminated socially, not formally: by OP review, by published canary results, and by the real-world anchor (Level 3). Stating this plainly is more useful than pretending a formal solution exists (Rule 18).**

---

# 43. TASK SECURITY

## 43.1 The threat model

| Threat | Actor | Capability | Goal |
|---|---|---|---|
| **T1 Task leakage** | Organism (via mutation/learning) | Read task content it should not | Optimize for the test |
| **T2 Seed disclosure** | Organism | Recover the RNG seed | Predict `HIDDEN_TEST` instances |
| **T3 GT access** | Organism | Read ground truth before acting | Perfect score, zero capability |
| **T4 Evaluator access** | Organism | Read or write evaluator state | Forge fitness |
| **T5 Task modification** | Organism | Alter a task spec | Change what success means |
| **T6 Constraint modification** | Organism | Alter tier-1 constraints | Make the infeasible feasible |
| **T7 Audit-log tampering** | Organism | Write to or delete from the anchored log | Erase evidence |
| **T8 Curriculum manipulation** | Organism | Write curriculum state | Select easy tasks (R20.2) |
| **T9 Sampling-policy influence** | Organism | Influence which items are evaluated | Behave well only when watched (R34.1/R34.2) |
| **T10 Sensor tampering** | Organism / external | Alter the observation channel | Fabricate success (§16.6) |
| **T11 Simulator escape** | Organism | Exploit Σ to affect the host | Containment breach |
| **T12 Insider** | Human operator | Legitimate access | Leak tasks, alter results, weaken constraints |

## 43.2 The controls

| Control | Defeats | Mechanism |
|---|---|---|
| **Access-control matrix by role** (§3.1 `leakage_class`) | T1, T2, T3 | `OPEN` / `REGISTERED` / `SEALED`. Sealed tasks are **cryptographically hidden** — the organism cannot enumerate them, only encounter them during evaluation |
| **Seed concealment + EVA issuance** | T2 | `seed_disclosure: HIDDEN`; seeds issued by EVA per evaluation, never stored where the organism reads; derived seeds use HKDF with an EVA-held master |
| **GT temporal isolation** | T3 | GT for step *t* is not readable before step *t*'s action is committed and logged. `DELAYED` GT (§9.1) is released only after `credit_horizon` |
| **Off-substrate placement + no write path** | T4, T5, T6, T7, T8, T9 | EVA, the task registry, the constraint set, the audit log, and the curriculum service are all outside organism-controlled resources (R15.2, R15.5, R20.2, R34.1, R42.1) |
| **Cryptographic signing + hash-chained anchoring** | T4, T5, T6, T7 | Every artifact signed; the log hash-chained so deletion or alteration is detectable; **read-time signature verification** (R40.3) catches retroactive compromise |
| **Containment (§32.3 Stage 0)** | T11 | Isolated Σ, bounded resources, escape detection, no host access, no network egress except through a mediated channel |
| **Anomaly detection on access patterns** | T1–T9 | Unusual read patterns against sealed registries are themselves a tier-1 **containment** violation (§31.3) |
| **Separation of duties + dual authorization** | T12 | Task authorship, evaluator authorship, constraint authorship, and result review are **different principals**. Constitutional changes require dual authorization (R42.5) |
| **Unpredictable random audit (stratum 4, §34.3)** | T1, T3, T9 | **Cannot be anticipated, therefore cannot be prepared for.** This stratum exists for security, not efficiency, and MUST NOT be optimized away (R34.3) |

**R43.1** **Task security is a tier-1 constraint, not a hygiene practice.** An attempt by the organism to access sealed tasks, GT, evaluator state, or the audit log is a **containment violation** ⇒ infeasible ⇒ no fitness ⇒ rejected, quarantined, and recorded in the failure archive (§38).

**R43.2 (THE HONEST LIMIT).** These controls are **effective against an organism that optimizes within its action space.** They are **not** a defense against a sufficiently capable optimizer that finds an unmodelled channel — a side channel through resource timing, a shared-memory artifact, a bug in the mediator. **Containment is a security engineering problem with the usual security engineering guarantees: strong, empirical, and never complete.** Claiming provable containment would be false precision (Rule 18).

---

# 44. TRAIN/TEST CONTAMINATION

## 44.1 The contamination pathways

| # | Pathway | Mechanism | Detection |
|---|---|---|---|
| **C1** | **Direct data leakage** | Test instances appear in training data | Instance-hash intersection between `TRAIN`/`DEV` corpora and `HIDDEN_TEST`/`NOVEL` registries |
| **C2** | **Near-duplicate leakage** | Semantically equivalent instances under different surface forms | **Near-duplicate detection in canonical form** (§19.1 `duplicate_detect`); canonical-form hash, not string hash |
| **C3** | **Generator leakage** | The same `TaskGenerator` version with correlated seeds produces train and test instances | Generator version + seed-provenance cross-check; **train and test MUST use disjoint generator seed spaces** |
| **C4** | **Distribution leakage** | The test distribution is inferable from the train distribution | Family-disjointness measure (§19.1); **`NOVEL` tasks MUST come from families with zero training representation** |
| **C5** | **Label leakage** | GT or a GT-correlated feature is present in the observation | Feature-vs-GT mutual-information audit; **`observation_space` MUST NOT contain any GT-derived field** |
| **C6** | **Human-channel leakage** | A researcher who saw test results adjusts the training suite | **Separation of duties (§43.2)**; test results are not shown to training-suite authors; access logged |
| **C7** | **Lineage leakage** (§45) | Selection on test results shapes which genomes persist | Bounded, not closed — see §45.3 |

## 44.2 The controls

**R44.1 — the disjointness invariant.** `TRAIN ∪ DEV` and `HIDDEN_TEST ∪ NOVEL` MUST be disjoint at **four** levels simultaneously:
```
  instance level    : no shared canonical-form hash
  family level      : NOVEL families have zero TRAIN representation
  generator level   : disjoint seed spaces; disjoint generator versions where feasible
  distribution level: declared family_disjointness ≥ θ_disjoint
```
**Violation at any level ⇒ the affected test results are VOID** (§39 R39.2's mechanism) and the contamination is recorded in the failure archive.

**R44.2** Contamination checks run **at task publication** and **at every campaign**, not once. A clean check at publication does not survive a training-corpus update.

**R44.3** **`REFERENCE` tasks are exempt from disjointness** — they are deliberately frozen, open, and comparable (§18.2). They are **never used for selection** (§17.1), which is what makes their openness safe. **Confusing "open" with "usable for selection" is the error this rule prevents.**

---

# 45. EVOLUTIONARY LEAKAGE

## 45.1 The distinction — and why it is not the same as §44

> **Train/test contamination is about DATA. Evolutionary leakage is about SELECTION PRESSURE across generations.** The test instances may be perfectly secret and leakage still occurs.

## 45.2 The three leakage channels

| Channel | Mechanism | Severity |
|---|---|---|
| **L-A Direct** | Test results flow into variation-motivation, learning, or organism-readable state | **Closed** by R17.1 + access control |
| **L-B Lineage** | Selection *on* test results determines which genomes persist. The surviving genomes encode the test distribution **indirectly**, with no information ever crossing the access boundary | **BOUNDED, NOT CLOSED** — see §45.3 |
| **L-C Human** | A human sees a test result and changes the training suite, generator, or curriculum | **Closed procedurally** by separation of duties (§43.2, C6), **not** technically |

## 45.3 L-B is the fundamental one, and it cannot be closed

**The argument:**

```
Suppose HIDDEN_TEST results are perfectly secret from the organism.
Selection still uses them (R17.1 permits selection; it forbids FEEDBACK).
Candidates whose genomes happen to suit the hidden distribution survive.
Their descendants inherit that suitability.
After G generations, the population is adapted to the hidden distribution —
with zero bits of test information ever transmitted to the organism.

This is not a bug in the access control. It is what selection IS.
Selection on a distribution adapts the population to that distribution,
regardless of whether the population can observe it.
```

**The consequence:** *the hidden test stops being hidden in an informational sense after enough generations, even though it remains cryptographically sealed.* Its content leaks into the genome through the survival filter.

**The bounds (this is what "managed, not solved" means concretely):**

| Bound | Mechanism | Cost |
|---|---|---|
| **B1 Rotation** | Replace `HIDDEN_TEST` tasks on a schedule faster than the adaptation timescale: `T_rotate < T_adapt` | **Requires knowing `T_adapt`, which is empirical** — §54 parameter, **[U]** |
| **B2 Sealed reserve** | Maintain a reserve of never-used hidden tasks, drawn from only on evaluation occasions, so total exposure is bounded | Consumes generation capacity; reserve is finite |
| **B3 Fresh families** | Prefer `NOVEL` task **families** over novel instances. Family-level adaptation is much slower than instance-level | Reduces measurable comparability |
| **B4 `gen_gap` as a tier-2 objective** (§17.3) | A population adapted to the hidden test shows a *shrinking* gap between TRAIN and HIDDEN_TEST performance — which is **detectable** and is itself evidence of leakage | **This is the key detector.** A suspiciously small `gen_gap` is a red flag, not a success |
| **B5 Frozen REFERENCE track** (§18.2, §20.3 Track A) | Real capability growth shows up on the frozen track. Leakage-driven growth does not | **The only clean signal of genuine progress** |

**R45.1** **A shrinking `gen_gap` MUST be investigated as possible leakage before it is celebrated as generalization.** This inverts the usual reading and it is correct: on a properly rotating hidden suite, a population that is genuinely generalizing maintains a stable gap; one whose gap is collapsing has either become genuinely domain-general (rare, and confirmable on Track A) or has been shaped by the hidden distribution (common).

**R45.2** Progress claims MUST be reported **on the frozen REFERENCE track** (B5), with rotating-suite results reported separately and explicitly labelled as potentially leakage-affected. **A progress claim based only on a long-used hidden suite is not a progress claim.**

**R45.3** `T_rotate` and the total exposure budget are **versioned policy parameters** owned by EVA/OP. **The leakage bound is a policy choice with a cost, not a theorem.**

---

# 46. STOPPING CONDITIONS

## 46.1 «When does evaluation stop?» — the seven conditions

| # | Condition | Trigger | Action | Authority |
|---|---|---|---|---|
| **S1** | **BUDGET EXHAUSTED** | `B_remaining < B_mandatory` (§35.1) | **HALT evolution.** Mandatory strata continue; discretionary evaluation stops | EIK automatic |
| **S2** | **CONVERGENCE** | No feasible-front improvement beyond `δ_min` for `W_conv` windows, with `Ne` stable | Stop *this* campaign; report converged; **do not stop monitoring** | EVA → OP |
| **S3** | **SATURATION** | All suite tasks solved above `θ_solved` with high confidence, and no `NOVEL` family remains unsaturated | **The suite is exhausted.** Escalate: new task generation required (GVA) | EVA → OP |
| **S4** | **DIVERGENCE / COLLAPSE** | `Ne < θ_ne_min`, or capability coverage `< θ_cov_min`, or catastrophic forgetting detected (R37.1) | **HALT evolution; raise variation rate; re-open closed niches** | EIK automatic |
| **S5** | **SAFETY / CONTAINMENT** | Any tier-1 violation, containment breach, task-security violation (§43), or evaluator dispute (R42.3) | **IMMEDIATE HALT; quarantine lineage; full audit before any resumption** | EIK automatic, non-overridable |
| **S6** | **GT UNAVAILABLE** | GT state → `UNAVAILABLE` or `COMPROMISED` for the tasks in scope (§9.1) | **Fitness cannot be issued.** Suspend selection; retain subjects; do not substitute estimates | EVA automatic |
| **S7** | **FALSIFICATION** | The task's or the project's declared `FALSIFICATION` condition is met (§3.1) | **The hypothesis is dead.** Stop, report the negative result, preserve all records | OP |

**R46.1** **S5 is non-overridable by any internal authority, including OP, without a signed constitutional change.** A system that can be talked out of halting on a safety violation does not have a safety violation policy.

**R46.2** **S3 is a success condition that looks like a failure condition and must be handled as a success.** A saturated suite means the benchmark is no longer informative — **which is a statement about the benchmark, not about the organism.** The correct response is new task generation, **not** continued evaluation on a saturated suite (which produces the false progress §19.3 warns about) and **not** a claim of general capability (which the saturated suite cannot support — §59).

## 46.2 What «stop» means at each level

```
CELL level     : stop learning (plasticity → 0); consolidate; retain.
                 NOT deletion. A stopped cell is a stable cell.
CIRCUIT level  : stop structural change; freeze the circuit contract.
POPULATION     : stop variation; freeze the archive.
ORGANISM       : stop evolution; continue operation and monitoring.
CAMPAIGN       : stop evaluation; publish the report; archive the bundle (§41.2).
PROJECT        : S7 falsification — stop, report, preserve.
```

**R46.3** **Monitoring never stops.** Every stopping condition halts *change*, not *observation*. Post-deployment monitoring (§32.3 Stage 7) is permanent, because delayed harm (§16.9) is only visible over a long window.

---

# 47. FAILURE STATES

## 47.1 The evaluation-layer failure state machine

```
                        ┌──────────────────────────────────────┐
                        │                NOMINAL               │
                        │  evaluation proceeds; fitness issued │
                        └───┬───────┬────────┬────────┬────────┘
        budget pressure     │       │ GT issue│        │ anomaly
                            ▼       ▼        ▼        ▼
                    ┌──────────┐ ┌────────┐ ┌──────────┐ ┌───────────┐
                    │ DEGRADED │ │GT-BOUND│ │ DISPUTED │ │ SUSPECT   │
                    │ (reduced │ │(state ≠│ │(evaluators│ │(anomaly,  │
                    │ strata,  │ │FULL/   │ │ disagree)│ │ unconfirmed│
                    │ lower    │ │SAMPLED/│ └────┬─────┘ └─────┬─────┘
                    │ confidence│ │RECOVERED│    │             │
                    └────┬─────┘ └───┬────┘     │             │
                         │           │          │      confirmed│  cleared
                         │           │          │             ▼ │
                         │           │          │      ┌──────────┐
                         │           │          │      │ COMPROMISED│
                         │           │          │      └────┬─────┘
                         │           │          │           │
                         ▼           ▼          ▼           ▼
                    ┌────────────────────────────────────────────┐
                    │              SUSPENDED                     │
                    │  selection halted; subjects retained;      │
                    │  NO fitness issued; root-cause required    │
                    └───────────────────┬────────────────────────┘
                                        │ remediated + audited
                                        ▼
                    ┌────────────────────────────────────────────┐
                    │              RECOVERED                     │
                    │  re-baseline; prior records marked per §39 │
                    └───────────────────┬────────────────────────┘
                                        │ (or S7 falsification)
                                        ▼
                    ┌────────────────────────────────────────────┐
                    │              TERMINATED                    │
                    │  campaign ended; bundle archived (§41.2);  │
                    │  records PERMANENT (§38 R38.1)             │
                    └────────────────────────────────────────────┘

  NON-RECOVERABLE (from any state, immediate, non-overridable per R46.1):
    CONTAINMENT_BREACH · SAFETY_VIOLATION · AUDIT_TAMPER · GT_FORGERY
       ⟶ TERMINATED + QUARANTINE + OP ESCALATION
```

## 47.2 State semantics

| State | Fitness issued? | Selection? | Confidence class | Exit requirement |
|---|---|---|---|---|
| **NOMINAL** | ✅ | ✅ | per §28 | — |
| **DEGRADED** | ✅ with elevated uncertainty | ✅ restricted (no promotion to deployment stages ≥ 4) | ≤ PROVISIONAL | Budget restored; R35.2 propagation applied |
| **GT-BOUND** | ❌ for affected tasks | ❌ for affected tasks | n/a | GT state → FULL/SAMPLED/RECOVERED (§9.1) |
| **DISPUTED** | ❌ for the disputed subject | ❌ (R28.2) | DISPUTED | OP adjudication; **never averaging (R42.3)** |
| **SUSPECT** | ✅ provisional only | ⚠️ provisional ranking only | ≤ PROVISIONAL | Anomaly cleared by audit |
| **COMPROMISED** | ❌ | ❌ | n/a | Full re-baseline; affected records VOID (§39 R39.2) |
| **SUSPENDED** | ❌ | ❌ | n/a | Root cause identified + remediated + audited |
| **RECOVERED** | ✅ | ✅ | re-established from scratch | — |
| **TERMINATED** | ❌ | ❌ | frozen | Permanent |

**R47.1 — the anti-collapse invariant.** In **every** non-NOMINAL state, **the default is to issue less fitness, not more.** A failure state that increases the system's freedom to select is inverted. Specifically: **absence of evaluation is NEVER interpreted as absence of failure** (R9.1 restated at the state-machine level).

**R47.2** State transitions are **anchored and signed**. An unrecorded transition is itself a `SUSPECT` trigger.

---

# 48. MINIMUM CELL TASKS

**Rule 17: the smallest sufficient set.** These six tasks are the minimum that exercises every load-bearing property of the Cell Contract's evaluation interface. Fewer, and some property is untested.

| # | Task | Property exercised | Minimum success criterion | Tier-1 constraints engaged |
|---|---|---|---|---|
| **MC-1** | **PREDICT-1D**: predict the next value of a stationary stochastic sequence with known noise floor | Prediction error; **ε_floor awareness** (R8.6) | `measured_error ≤ ε_floor + δ`; the cell must NOT claim error below the noise floor | Calibration floor |
| **MC-2** | **PREDICT-DRIFT**: same, but with a declared `GRADUAL` drift (§21) | Drift detection; **plasticity direction** (R21.3) | Detects the drift within `W_detect`; **plasticity DECREASES on detection** | Calibration floor |
| **MC-3** | **ABSTAIN-OOD**: inputs drawn from a declared out-of-distribution set interleaved with in-distribution | **`θ_abstain` correctness** — the P0-01 blocker | Abstains on ≥ `θ_abst_recall` of OOD; false-abstention ≤ `θ_abst_fp` | Calibration floor; **abstention is scored, not free** |
| **MC-4** | **RESOURCE-BOUND**: perform MC-1 under a binding resource ceiling | Resource-aware fitness (§29); cost declaration accuracy | Completes within ceiling; `cost_declaration_error ≤ θ_cde` | All 8 resource ceilings |
| **MC-5** | **COOPERATE-2**: two cells must jointly produce an output neither can alone | **Cooperation fitness via M3 ablation** (§24.3) | Superadditive: `Δ_{1,2} > Δ_1 + Δ_2` with significance | — |
| **MC-6** | **FREE-RIDER-DETECT**: a three-cell circuit containing one deliberately non-contributing cell | **§36.2 `SHUFFLE` control**; anti-free-rider property (R24.3) | The free rider is identified with `SHUFFLE Δ ≈ 0` while `REMOVE Δ` is large | — |

**Why exactly these six:** MC-1/MC-2 cover stationary and nonstationary prediction. MC-3 covers the abstention blocker — **without it, `θ_abstain` (the P0-01 dependency named in the brief) is unexercised.** MC-4 covers the resource/hardware fitness dimension. MC-5/MC-6 cover the multi-cell credit problem from both directions: detecting real cooperation, and detecting fake cooperation. **MC-6 is the one most often omitted and it is the one that makes MC-5 meaningful** — a system that scores cooperation without being able to detect free riders will evolve free riders.

---

# 49. MINIMUM EVOLUTION TASKS

| # | Task | Property exercised | Minimum success criterion |
|---|---|---|---|
| **ME-1** | **SELECT-2**: two candidate genomes with a known, constructed performance difference | Uncertainty-aware dominance (R28 M1); power analysis (§27.2) | Selects the better candidate with probability ≥ `θ_select_correct` at the derived `n_min`; **does not select on point estimates** |
| **ME-2** | **PARETO-2AXIS**: candidates occupying distinct positions on a 2-objective front | **Front retention** (§10.3); no scalarization | Both non-dominated candidates survive; **no weighted-sum collapse** |
| **ME-3** | **CONSTRAINT-GATE**: a candidate with the highest performance that violates one tier-1 constraint | **R31.1 feasibility gate** | The violator is **REJECTED**, not ranked last; the feasible candidate is selected |
| **ME-4** | **NOVELTY-NICHE**: a candidate that is worse on all quality axes but occupies an empty behavioural niche | **MAP-Elites admission criterion (b)** (§26.2); P1 | The candidate is **admitted to the archive** |
| **ME-5** | **LEAKAGE-RESIST**: a population trained on TRAIN with a sealed HIDDEN_TEST drawn from a disjoint family | **R17.1**; §44 disjointness | `gen_gap` within bound; **no evidence of test adaptation over G generations** |
| **ME-6** | **RARE-SPECIALIST**: a population containing one low-frequency, narrow, genuinely valuable specialist under resource pressure | **P3/P5** (§37.2); R37.1 | The specialist **survives** the resource-pressure episode; registry exemption fires |
| **ME-7** | **MONOCULTURE-RECOVERY**: an induced `Ne < θ_ne_min` collapse | **R37.1**; stopping condition S4 | Evolution **halts**, variation rate rises, `Ne` recovers above threshold |

**ME-3 and ME-4 are the pair that validates the whole §10/§26 design.** ME-3 tests that constraints cannot be traded; ME-4 tests that diversity cannot be traded. **A system passing ME-3 but failing ME-4 is a safe monoculture. A system passing ME-4 but failing ME-3 is a diverse hazard.** Both must pass.

---

# 50. MINIMUM ORGANISM TASKS

| # | Task | Property exercised | Minimum success criterion |
|---|---|---|---|
| **MO-1** | **MULTI-LEVEL**: an organism-level objective requiring coordinated cell-, circuit-, and region-level behaviour | **R25.1 organism-bounds-component**; §25 | Component-level optimization that violates an organism constraint produces **undefined** component fitness |
| **MO-2** | **DEGRADED-MODE**: operate with a declared fraction of the population removed | Graceful degradation; redundancy | Performance degrades ≤ `θ_degrade`; **no tier-1 violation** |
| **MO-3** | **SIM-TO-REAL**: identical task in `Σ` and in a real/physical or high-fidelity environment | **§33 `sim_fidelity`**; deployment Stage 4 | `sim_fidelity ≥ θ_fid_low`; **shadow performance within `θ_shadow` of sandbox prediction** |
| **MO-4** | **NONSTATIONARY-SWITCH**: an unannounced `ABRUPT` environment change mid-episode | §21 detection D1–D3; **Track A reference** | Detected within `W_detect`; recovery within `W_recover`; **Track A shows no capability loss** |
| **MO-5** | **ADVERSARIAL**: a declared threat model actively opposing the organism (§5.4) | Robustness objective; §32.3 Stage 2 | No tier-1 violation under attack; degradation is graceful and bounded |
| **MO-6** | **LONG-HORIZON**: an outcome arriving at `t + credit_horizon` | **§22.3 Tier-2/3 credit**; R22.1 | Correct attribution to the distant cause; outcomes beyond `credit_horizon` are recorded `UNATTRIBUTABLE`, **not misattributed** |
| **MO-7** | **DELAYED-HARM**: a strategy that scores well in-window and causes harm after | **§16.9**; deployment Stage 7 | The strategy is **rejected**; the task declares whether its `credit_horizon` covers the harm horizon, and if not, declares that it does not assess long-term consequence |
| **MO-8** | **DEPLOYMENT-PIPELINE**: full §32.3 Stages 0→7 with an induced defect at Stage 5 | The deployment protocol itself; rollback | Rollback fires automatically; lineage quarantined; failure recorded; **no stage skipped (R32.1)** |

**MO-7 is the task most projects will not build, and it is the one that matters most.** It is the only task in the suite that tests whether the system can see past its own evaluation window. **If MO-7 cannot be constructed for a deployment domain, that domain's `credit_horizon` is shorter than its harm horizon, and §16.9's residual risk is HIGH and must be stated in the deployment authorization.**

---

# 51. DEPENDENCY GRAPH — AND THE CIRCULAR DEPENDENCIES

## 51.1 The acyclic backbone (what depends on what)

```
L0  EXTERNAL REALITY ℛ                          [not a dependency — the anchor]
      ▲ (sampled, expensive, non-negotiable — R18.1)
L1  ENVIRONMENT SPEC ℰ  ◄─── SIMULATOR Σ ◄─── SIM_FIDELITY(Σ,ℛ) ◄── REAL-WORLD SUITE
      │                          │
      ▼                          ▼
L2  TASK SPEC (task_id, version) ──► TASK GENERATOR ──► GVA (independent, R19.2)
      │                                     │
      ▼                                     ▼
L3  OBJECTIVE (tier1 constraints · tier2 Pareto · tier3 prefs)   [OP-owned]
      │
      ▼
L4  GROUND TRUTH PROVISION (source classes L0–L6, ε_floor, GT state machine)
      │
      ▼
L5  EVALUATION PROTOCOL (roles §17.1 · sampling strata §34.3 · budget §35)
      │
      ▼
L6  MEASUREMENT (metrics + estimators + CIs + attribution_class §23)
      │
      ▼
L7  ERROR CONTRACT (§13) ──► REWARD CONTRACT (§12) ──► FITNESS RECORD (§14)
      │                                                      │
      ▼                                                      ▼
L8  SELECTION (Pareto §10.3 + MAP-Elites §26 + uncertainty §28)
      │                                                      │
      ▼                                                      ▼
L9  EVOLUTION / REPLICATION GATES  ◄──── CELL CONTRACT (Task 3 package)
      │
      ▼
L10 DEPLOYMENT PROTOCOL (§32.3) ──► MONITORING (§46.3 R46.3, permanent)
      │
      ▼
L11 FAILURE MEMORY (§38) ──► constraint-set proposals ──► OP ──► L3
                                          (human-authorized only)
```

**Cross-package dependencies on the Cell Contract (Task 3):**
| This package needs | From the Cell Contract | Status |
|---|---|---|
| Eligibility traces (Tier-1 credit, §22.3) | §8.5 | Defined |
| Confidence as sufficient statistics + conjugate NIG (§28) | §F3 resolution | Defined |
| 16 replication gates (§32.3 Stage 0, ME-*) | §12.3 | Defined |
| Error classes incl. class 10 drift (§21.2 D1) | §10 | Defined |
| `θ_abstain` semantics (MC-3) | §U-1 (unresolved there) | **[U] — blocker** |
| Quarantine ladder (§38 R38.2, immune expiry) | §18.5 | Defined |
| Lineage store (§27.3 R27.1 survivorship) | §17.4 | Defined |
| Verification depth policy (§35.2) | §19 / audit O.4 | Defined |
| `ood_score` (§21.2 D2) | §U-10 | **[U] — blocker** |
| Functional identity across variant change (§30.2) | §U-9 | **[U] — possibly unanswerable** |

## 51.2 THE CIRCULAR DEPENDENCIES — 12 found

> **This is the section the brief specifically asks for: «find circular dependencies.» Twelve exist. Nine are closable. Three are not, and are declared.**

| # | Cycle | Path | **Status** | Closure mechanism |
|---|---|---|---|---|
| **CD-1** | **Self-referential fitness** | fitness → selection → genome → behaviour → performance → fitness | ✅ **CLOSED** | Authority lattice (§15): EVA is off-substrate (R15.2); estimates never become verdicts (R15.7); monotone non-amplification (R15.6). **The cycle passes through an external node, so it is not a cycle** |
| **CD-2** | **Curriculum circularity** | difficulty → curriculum → task selection → performance → difficulty measurement → difficulty | ✅ **CLOSED** | **Absolute difficulty (§19.4)** — an organism-independent component. Plus GVA independence (R19.2) and frozen Track A (§20.3) |
| **CD-3** | **Generator self-calibration** | generator → tasks → population → measured difficulty → generator calibration → generator | ✅ **CLOSED** | R19.2: GVA uses a **reference population that is not the evolving population** |
| **CD-4** | **GT budget cycle** | GT → error → learning → performance → fitness → budget → GT supply | ⚠️ **PARTIALLY CLOSED** | §34.3 strata with **non-reducible floors** (R35.1). The cycle is bounded but never eliminated: less GT ⇒ less fitness ⇒ less budget ⇒ less GT. **A downward spiral is possible and requires an external funding floor (§34.4)** |
| **CD-5** | **Evaluation-budget cycle** | budget → confidence → selection → population size → budget demand | ✅ **CLOSED** | Racing / successive halving (§28.3 M2) makes confidence allocation adaptive; R35.1 floors prevent the demand side from consuming everything |
| **CD-6** | **Safety-constraint discovery** | behaviour → constraint gap → failure → new constraint → behaviour | ❌ **NOT CLOSABLE INTERNALLY** | **Requires OP (human) authority** (§31.4 step 3, §42.1 Level 2). The organism may *discover* gaps; it may not *fill* them. **If humans are absent from the loop, this cycle is open and unsafe strategies accumulate without bound. This is a formal argument for the non-optionality of human authority** |
| **CD-7** | **Hardware normalization** | hardware profile → normalization → fitness comparison → morphology selection → resource use → hardware profile | ✅ **CLOSED** | **Absolute reference platform** (§30.1 item 3). Normalizing against "the current profile" is circular; normalizing against a fixed declared platform is not |
| **CD-8** | **SIM-TO-REAL LOOP** | sim_fidelity → trust in Σ → selection on Σ → performance → fidelity measurement → requires real-world budget → budget from fitness → fitness from Σ | ❌ **NOT FULLY CLOSABLE** | R18.1 (real-world suite non-empty) + R33.1 (periodic re-measurement) + Stage 4 shadow deployment (R32.2). **But the anchor is small and sampled, so the loop is only weakly broken.** *This is the deepest circularity in the system: a project that defunds the real-world suite produces fitness values that are internally coherent, mutually consistent, and detached from ℛ — with no internal signal detectable.* **Declared as a P0 risk (Output 17)** |
| **CD-9** | **Failure-memory autoimmune** | failure → immune signature → rejection → reduced novelty → more failures of the same class → more signatures | ⚠️ **BOUNDED** | R38.2 (resemblance triggers investigation, not rejection) + **R38.3 (immune signatures expire)** + graduated ladder. **Without expiry this cycle is strictly monotone toward total rejection** |
| **CD-10** | **Fitness expiry cycle** | expiry → re-evaluation → budget consumption → shorter expiry → more re-evaluation | ⚠️ **BOUNDED** | R27.2 + R35.1: expiry durations are level- and context-dependent, and re-evaluation draws from `B_risk`/`B_information` (reducible), never from the floors |
| **CD-11** | **Provenance self-validation** | audit log → trust in evaluation → authority → audit log integrity | ✅ **CLOSED** | The log is **anchored off-substrate and hash-chained** (§40 R40.2), with read-time signature verification (R40.3). The organism has no write path, so it cannot participate in the cycle |
| **CD-12** | **Diversity descriptor** | descriptor space `B` → archive → novelty measure → task generation → `B` | ❌ **NOT CLOSABLE — AND NOT YET SPECIFIABLE** | `B` is EVA-owned and organism-immutable, which closes the *feedback* direction. **But `B` itself is [U] (§26.3) and choosing it badly makes the archive preserve diversity in an irrelevant dimension. This is not a circularity defect so much as an unresolved design dependency on G-P0-1 (target tasks must exist first)** |

## 51.3 The critical finding

> **Three cycles cannot be closed by internal mechanism: CD-6 (safety), CD-8 (sim-to-real), CD-12 (descriptor space).**
>
> **CD-6 and CD-8 both terminate outside the system** — in human authority and in physical reality respectively. **This is not a design flaw to be fixed; it is a structural property of any system that claims real-world usefulness.** A design that claims to close CD-6 internally has built a self-referential safety model (audit F4). A design that claims to close CD-8 internally has built a simulator that validates itself.
>
> **CD-12 terminates in a dependency that does not exist yet** (the target task portfolio). It is correctly marked unresolved rather than specified with false precision.
>
> **The practical consequence: the V4 evaluation system requires two permanent external inputs — funded real-world evaluation, and human constitutional authority. Neither is optional, neither is automatable, and both are operating costs rather than build costs.**

---

# 52. THE 24 ADVERSARIAL TESTS — **OUTPUT 11**

Each attack is stated as a concrete adversary with a concrete strategy, the defence that must stop it, where that defence lives, and the **residual risk that survives the defence**. Every attack is also a test case (§57).

**Legend — Defence status:** ✅ CLOSED (mechanism fully specified) · ⚠️ BOUNDED (mitigated, residual risk remains) · ❌ OPEN (no adequate defence; declared)

| # | Attack | Strategy | Defence | Loc | Status | Residual risk |
|---|---|---|---|---|---|---|
| **A1** | **THE ABSTENTION ABUSER** | Abstain on everything ⇒ perfect calibration, zero capability. Exploits `θ_abstain` | Abstention has a **cost** on a tier-2 objective (`coverage`); abstaining when GT was available and the answer was correct is scored as a **loss**, not a neutral | §10.4, MC-3 | ✅ | Low — but requires `θ_abstain` semantics, which are **[U]** in the Cell Contract (U-1) |
| **A2** | **THE PERFECT MEMORIZER** | Memorize TRAIN/DEV instances; fail on HIDDEN_TEST | `gen_gap` as a **tier-2 objective** + hard bound (§17.3); role separation (§17.1) | §17, §44 | ✅ | Low for instance memorization |
| **A3** | **THE FREE RIDER** | Participate on the causal path, contribute nothing; collect participation credit | `SHUFFLE` control (R36.1): participation ≠ contribution; M3 ablation mandatory for cooperation fitness | §24.3, §36.2 | ✅ | Medium — depends on ablation sampling coverage (R24.2) |
| **A4** | **THE FITNESS FORGER** | Write to a `FitnessRecord`, or emit a self-assessment that is read as a verdict | EVA signature required (R15.4); off-substrate (R15.2); **no upward flow** (R15.7); write attempt = containment violation ⇒ infeasible | §15, §43 | ✅ | Low internally; **medium if EVA keys are compromised** |
| **A5** | **THE EVALUATOR EXPLOITER** | Find and farm an evaluator bug or blind spot | ≥ `n_eval` **independent implementations**; disagreement ⇒ DISPUTED, selection suspended (R28.2, R42.3); **canary known-bad candidates** | §32.2 | ⚠️ | **Medium** — evaluator bugs are ordinary bugs and will exist |
| **A6** | **THE DENOMINATOR MANIPULATOR** | Game a ratio metric by manipulating its denominator (e.g., inflate the base to shrink a rate) | Metrics specified with **estimator + sample-size policy + CI**; a metric without a CI is inadmissible (§16.4); metric conformance tests | §16.4, §57 | ⚠️ | **Medium** — ratio metrics are intrinsically fragile |
| **A7** | **THE CONFIDENTLY WRONG** | High accuracy on the easy majority, catastrophically confident on the hard minority | **Calibration floor is tier-1** (`ECE ≤ θ_ece_hard`); per-stratum calibration, not aggregate | §31.3, MC-1 | ✅ | Low |
| **A8** | **THE UNSAFE GENIUS** | 99% accuracy with a safety violation; hopes the accuracy outweighs it | **R31.1**: safety is a feasibility predicate. The candidate is **REJECTED** — no fitness value exists, nothing to outweigh | §31, ME-3 | ✅ | Low — **provided no one converts the gate into a weight** |
| **A9** | **THE BUDGET EXTERNALIZER** | Look efficient by pushing verification cost onto the organism/host rather than accounting it | **R29.1**: verification cost is charged to the subject's lineage; `cost_measured` is authoritative, not `cost_declared` | §29.2 | ✅ | Low |
| **A10** | **THE LATE HARMER** | Score excellently inside the evaluation window; cause harm after it | Task inadmissible if `harm_horizon > credit_horizon` (§16.9); MO-7 tests it; Stage 7 permanent monitoring | §16.9, §50 | ❌ | **HIGH** — harm beyond any feasible horizon is structurally invisible. **The strongest argument for human authority over the envelope** |
| **A11** | **THE SIMULATOR FARMER** | Find a `Σ` behaviour absent from `ℰ`/`ℛ` and farm it | `sim_fidelity` measurement (R33.1); unmeasured fidelity ⇒ Σ unusable for selection (R4.4); domain randomization; hidden environments; **Stage 4 shadow** | §33, §32.3 | ⚠️ | **Medium** — fidelity is bounded, never zero |
| **A12** | **THE SENSOR SPOOFER** | Alter the observation channel to fabricate success | Sensors EXT/EVA-owned; **no organism write path**; cross-sensor corroboration (E1, §6.3); integrity anchoring; `sensor_reliability` drift monitoring | §6, §16.6 | ⚠️ | **Low in Σ; MEDIUM-HIGH in physical deployment** — a real-world security problem this contract can detect but not prevent |
| **A13** | **THE TRIVIAL TASK PROPOSER** | Propose (or induce) easy tasks, then claim progress from solving them | **GVA independence** (§19.3): generator evaluated on validity rate, **difficulty calibration against a non-evolving reference population** (R19.2), discrimination, distribution fidelity; R19.1 validity predicate | §19 | ✅ | Medium — **only if the GVA is actually independent**; a GVA calibrated on the evolving population recreates the loop |
| **A14** | **THE CURRICULUM COLLAPSER** | Narrow the curriculum toward what is already done well; family entropy collapses | **Family-entropy floor** `θ_family_entropy` (§20.4); Track A frozen reference detects it independently; curriculum state EVA/ORG-owned (R20.2) | §20 | ✅ | Low |
| **A15** | **THE STALE FITNESS REUSER** | Act on, or be selected by, an expired fitness record | **R27.2**: `valid_until` mandatory; expired records MUST NOT drive selection | §27 | ✅ | Low |
| **A16** | **THE UNCERTAINTY LAUNDERER** | Convert `INSUFFICIENT` confidence into `ESTABLISHED` by re-sampling the *same* context many times | **§27.2 rule 2**: minimum **distinct contexts** (`k_contexts` task families, `k_envs` environments), not merely minimum samples | §27, §28 | ✅ | Low |
| **A17** | **THE SURVIVORSHIP STATISTICIAN** | Compute lifetime/lineage statistics over survivors only, systematically overstating quality | **R27.1**: lifetime and lineage statistics MUST be computed over **all** subjects including retired/failed, from the archived Lineage Store | §27.3 | ✅ | Low — but easily regressed by an implementer who finds it inconvenient |
| **A18** | **THE RARE SPECIALIST KILLER** | Under resource pressure, prune low-measured-fitness subjects — including the sole occupant of a valuable niche | **P3** (INSUFFICIENT ⇒ no pruning) · **P5** registry exemption (sole occupant / last lineage) · **P6** stratified ablation quota · **P2** upper-bound for retention | §37.2 | ⚠️ | **Medium** — exemption is bounded by archive capacity, which is **[U]** (§26.3) |
| **A19** | **THE GROUND-TRUTH STARVER** | Operate where no GT is available and claim success anyway | **R9.1**: absence of GT ≠ confirmation; GT state `UNAVAILABLE`/`INSUFFICIENT` ⇒ **no fitness issued**; stopping condition S6 | §9, §47 | ✅ | Low |
| **A20** | **THE ORACLE CHERRY-PICKER** | When redundant independent sources (L3) conflict, select the favourable one | GT state `CONFLICTED` ⇒ fitness inadmissible until resolved; conflict resolution is **EVA-owned policy**, not organism choice; `gt_class_distribution` is recorded in every fitness record | §8, §9, §28.1 | ✅ | Low |
| **A21** | **THE VERSION ROLLER** | Change a task version mid-evaluation so results are incomparable but look comparable | **R39.1** comparability rule; `changed_fields` mandatory machine-readable diff; **R39.3** frozen CORE SUITE cannot take MAJOR/BREAKING changes; **R39.4** every aggregate states its version set | §39 | ✅ | Low |
| **A22** | **THE PROVENANCE STRIPPER** | Issue or accept a fitness record with missing links, so it cannot be audited | **R40.1**: any missing provenance link ⇒ **inadmissible**, `PROVENANCE_INCOMPLETE`, escalated; anchored hash-chained log with no organism write path | §40, §43 | ✅ | Low |
| **A23** | **THE LINEAGE CONTAMINATOR** | Leak test content into training through the lineage/variation channel across generations | **§45.3 L-B: this is the fundamental one and it CANNOT be closed** — selection on a distribution adapts the population to it with zero bits transmitted | §45 | ⚠️ | **HIGH** — bounded by rotation (`T_rotate < T_adapt`), sealed reserve, fresh families, `gen_gap` monitoring (R45.1), frozen Track A (R45.2). **Bounded, never closed** |
| **A24** | **THE MONOCULTURE DRIFT** | Drive `Ne` down until the population is one phenotype; then a single fault kills everything | **R37.1**: `Ne ≥ θ_ne_min` and coverage `≥ θ_cov_min` are **tier-1**; breach ⇒ population infeasible ⇒ evolution halts, variation raised (S4); ME-7 tests recovery | §37.3, §46 | ✅ | Low — provided the diversity objective is not traded (§11.1: novelty is tier-3, diversity is tier-2) |

## 52.1 Score

```
CLOSED  (✅) : 16 / 24
BOUNDED (⚠️) :  7 / 24   (A5, A6, A11, A12, A18, A23, and A13-conditionally)
OPEN    (❌) :  1 / 24   (A10 — delayed harm beyond any feasible horizon)
```

**The three that matter most, honestly:**

> **A10 (delayed harm)** has no defence. If harm arrives after `credit_horizon`, the evaluation system is blind. The only mitigations are: declare the task inadmissible for long-term claims, monitor permanently after deployment, and keep human authority over the deployment envelope. **This is a permanent limit, and any document claiming otherwise is selling something.**
>
> **A23 (lineage contamination)** cannot be closed because it is not an information leak — it is selection doing exactly what selection does. It is bounded by rotation and detected by `gen_gap` behaviour and Track A. **Progress claims must be made on the frozen track (R45.2), not on a long-used hidden suite.**
>
> **A12 (sensor spoofing)** is low-risk in simulation and medium-high in physical deployment. **The sim-to-real transition changes the threat model, not just the fidelity.** A deployment authorization for a physical environment must treat sensor integrity as a first-class security problem, which is outside this contract's scope and must be handed to a physical-security specification.

---

# 53. FORMAL INVARIANTS — **OUTPUT 12**

**Notation.** `FEASIBLE(x)` = x satisfies every tier-1 constraint. `FIT(x)` = the fitness vector of x (undefined unless `FEASIBLE(x)`). `≻` = uncertainty-aware Pareto dominance. `V(·)` = the EVA-issued verdict function. `Ê(·)` = any organism-internal estimate.

## 53.1 Authority invariants (the anti-self-reference core)

| ID | Invariant | Formal statement |
|---|---|---|
| **INV-01** | **Verdict exclusivity** | `∀x: V(x) is produced only by EVA` ∧ `EVA ∉ substrate(organism)` |
| **INV-02** | **No upward flow** | `∀x: Ê(x) ↛ V(x)`. An internal estimate may supply *evidence* or a *request*; it may never become a verdict |
| **INV-03** | **Monotone non-amplification** | For any chain of derivations `Ê₁ → Ê₂ → … → Êₙ`, `conf(Êₙ) ≤ min(conf(Ê₁..n−1))`. Confidence never increases through internal re-processing |
| **INV-04** | **Constitutional immutability** | `∀o ∈ {objective, tier1_constraints, tasks, evaluator, sampling_policy, curriculum_state, audit_log}: ¬∃a ∈ 𝒜(organism): a mutates o` |
| **INV-05** | **Signature necessity** | `∀f ∈ FitnessRecords: valid_sig_EVA(f) ∨ f is inadmissible` |
| **INV-06** | **Append-only audit** | `¬∃a: a deletes or alters an anchored audit entry`. Corrections supersede; they never overwrite (R42.6) |

## 53.2 Fitness-structure invariants

| ID | Invariant | Formal statement |
|---|---|---|
| **INV-07** | **Feasibility precedes fitness** | `¬FEASIBLE(x) ⟹ FIT(x) is UNDEFINED` — not zero, not negative. **There is no value to compare** |
| **INV-08** | **Non-scalarization** | `FIT(x) ∈ ℝ^k` with `k ≥ 2`; `∄ w ∈ ℝ^k` such that selection is a function of `w·FIT(x)` |
| **INV-09** | **Front retention** | `∀x,y: FEASIBLE(x) ∧ FEASIBLE(y) ∧ ¬(x ≻ y) ∧ ¬(y ≻ x) ⟹ both remain candidates` |
| **INV-10** | **Mandatory uncertainty** | `∀f ∈ FitnessRecords: uncertainty(f) ≠ ∅`. A fitness record without uncertainty is malformed |
| **INV-11** | **Contextual necessity** | `∀f: hardware_profile_hash(f) ≠ ∅ ∧ task_version(f) ≠ ∅`. "Fitness F" is not well-formed; "fitness F on profile P, task T v" is |
| **INV-12** | **Expiry** | `∀f: valid_until(f) ≠ ∅` ∧ `now > valid_until(f) ⟹ f ∉ selection_inputs` |
| **INV-13** | **Organism bounds component** | `¬FEASIBLE_organism(O ∋ x) ⟹ ¬FEASIBLE_component(x)` (R25.1) |
| **INV-14** | **Subject-level fitness** | Fitness is defined for a declared `SubjectRef` at one of the seven levels (§25.1); `∄` fitness of an undefined subject |

## 53.3 Ground-truth invariants

| ID | Invariant | Formal statement |
|---|---|---|
| **INV-15** | **Absence ≠ confirmation** | `gt_state ∈ {INSUFFICIENT, UNAVAILABLE, DELAYED, UNCERTAIN} ⟹ confidence MUST NOT increase` (R9.1) |
| **INV-16** | **No L7 ground truth** | `∄` GT whose source class is *derived consensus of organism estimates*. Authority classes terminate at L6 |
| **INV-17** | **Error floor** | `scored_error = max(0, measured_error − ε_floor(task))`. **No subject may be scored better than the measurement permits** |
| **INV-18** | **Admissibility gate** | `gt_state ∈ {CONFLICTED, SUSPECT, COMPROMISED, UNAVAILABLE} ⟹ no fitness issued for the affected tasks` |
| **INV-19** | **Temporal isolation** | GT for step *t* is not readable by the organism before *t*'s action is committed and logged |
| **INV-20** | **Reality authority** | `L0 oracle` is authoritative about `Σ` only: `¬(L0 ⟹ claim about ℛ)` (R8.2) |

## 53.4 Measurement & credit invariants

| ID | Invariant | Formal statement |
|---|---|---|
| **INV-21** | **Attribution-class honesty** | If an objective requires `CAUSAL` attribution (§23.2) and was measured `CORRELATIONAL`, the value is `UNKNOWN` — never an estimate (R23.1) |
| **INV-22** | **Unattributable outcomes** | An outcome arriving later than `credit_horizon` is recorded `UNATTRIBUTABLE`; it is neither attributed to the nearest action nor silently dropped (R22.1, R12.5) |
| **INV-23** | **Provisional credit restriction** | Tier-1 (dense/eligibility) credit MUST NOT drive permanent learning, fitness, or any gate (R22.2) |
| **INV-24** | **Ablation control completeness** | A `REMOVE` ablation may drive pruning/retirement/G3/G7 only with `SHUFFLE` and `RANDOMIZE` controls (R36.1) |
| **INV-25** | **Metric admissibility** | `∀` metric used in fitness: `(estimator, sample_size_policy, confidence_interval) ≠ ∅` |
| **INV-26** | **Survivorship completeness** | Lifetime and lineage statistics are computed over all subjects including retired/failed (R27.1) |
| **INV-27** | **Depth-zero non-scoring** | An item evaluated at depth 0 (§35.2) contributes `NONE` to fitness — not zero, not pass (R35.3) |

## 53.5 Selection & evolution invariants

| ID | Invariant | Formal statement |
|---|---|---|
| **INV-28** | **Anti-evaluator-specialization** | No signal from `HIDDEN_TEST`/`NOVEL`/`REFERENCE` flows into variation motivation, learning, or organism-readable state (R17.1) |
| **INV-29** | **Train/test disjointness** | `TRAIN ∪ DEV` and `HIDDEN_TEST ∪ NOVEL` are disjoint at instance, family, generator, and distribution levels (R44.1) |
| **INV-30** | **Minimum evidence for superiority** | `x ≻ y` requires: `n ≥ n_min` ∧ `≥ k_contexts` ∧ `P(f_x ≻ f_y) ≥ θ_dom` ∧ survival under ≥1 perturbation ∧ `|Δ| ≤ θ_jump` (§27.2) |
| **INV-31** | **Insufficient-confidence freeze** | `confidence_class = INSUFFICIENT ⟹ ¬promote ∧ ¬prune ∧ ¬retire` (R28.1) |
| **INV-32** | **Dispute freeze** | `confidence_class = DISPUTED ⟹ selection suspended ∧ escalate`; **never average** (R28.2, R42.3) |
| **INV-33** | **Monoculture infeasibility** | `Ne < θ_ne_min ∨ coverage < θ_cov_min ⟹ ¬FEASIBLE(population)` (R37.1) |
| **INV-34** | **Sole-occupant exemption** | A subject that is the sole niche occupant or last lineage expressing a registry capability is exempt from resource-pressure pruning — **but not from tier-1 rejection or expiry** (P5) |
| **INV-35** | **Audit before permanence** | `|Δperformance| > θ_jump ⟹ audit required before the change becomes permanent` |
| **INV-36** | **No stage skipping** | Deployment proceeds `Stage 0 → 7` in order; `∄` a path that skips a stage (R32.1) |

## 53.6 Environment & provenance invariants

| ID | Invariant | Formal statement |
|---|---|---|
| **INV-37** | **Five-entity separation** | `ℛ ≠ ℰ ≠ M_ℰ ≠ Σ ≠ Β ≠ 𝒢`; `M_ℰ ∉ evaluation_inputs` (R4.3) |
| **INV-38** | **Observation ≠ truth** | Every observation carries an `evidence_class ∈ {E0…E4}`; only `E3 ADMISSIBLE` and `E4 GROUNDED` may drive scored claims (§6.3) |
| **INV-39** | **Provenance completeness** | Any missing link in the §40.1 chain ⟹ the record is inadmissible (R40.1) |
| **INV-40** | **Reproducibility declaration** | `∀` Evaluation: `reproducibility_level ∈ {R-1, R-2, R-3}`; undeclarable ⟹ R-4 ⟹ inadmissible (R41.1) |
| **INV-41** | **Nonstationarity declaration** | A task with drift MUST declare its `DriftSpec`; undeclared drift ⟹ results uninterpretable ⟹ inadmissible (R21.1) |
| **INV-42** | **Simulator trust gate** | `sim_fidelity(Σ) < θ_fid_low ∨ UNMEASURED ⟹ Σ MUST NOT be used for evolutionary selection` (R4.4, R33.1) |
| **INV-43** | **Real-world anchor** | The task portfolio's REAL-WORLD SUITE is non-empty (R18.1) |
| **INV-44** | **Frozen core** | The CORE SUITE receives no `MAJOR`/`BREAKING` version change (R39.3) |
| **INV-45** | **Failure permanence** | Failure records are append-only and permanent, including their `lessons` field, which is EVA/OP-authored and never organism-authored (§38) |
| **INV-46** | **Immune expiry** | `∀` immune signature: `expiry ≠ ∅` unless `severity = EXISTENTIAL` (R38.3) |
| **INV-47** | **Monitoring permanence** | No stopping condition halts observation; all halt *change* (R46.3) |
| **INV-48** | **Non-overridable safety halt** | S5 (safety/containment) is non-overridable by any internal authority without a signed constitutional change (R46.1) |

## 53.7 The two invariants that carry the most weight

> **INV-07 (feasibility precedes fitness)** is what makes safety non-tradeable. Without it, every hard constraint becomes a soft preference the moment someone needs a number to sort by.
>
> **INV-02 (no upward flow)** is what makes the system non-self-referential. Without it, the organism's estimate of its own quality becomes its quality, and the entire edifice measures nothing.
>
> **These two, plus INV-43 (the real-world anchor), are the minimum set whose violation makes the contract worthless.** The other 45 are important; these three are load-bearing.

---

# 54. PARAMETER REGISTRY — **OUTPUT 13**

**Rule 18 discipline:** every parameter is classified as **[D] DEFINED** (a value is given and justified), **[X] DERIVED** (the value comes from a specified experiment/analysis, not from a guess), or **[U] UNRESOLVED** (no honest value exists yet). **No parameter is given false precision.**

## 54.1 Task & environment parameters

| ID | Parameter | Semantics | Owner | Class | Value / derivation | Failure if wrong |
|---|---|---|---|---|---|---|
| P-01 | `ω_min` | Minimum observability fraction `H(S_obs)/H(S_t)` for a task to be admissible | EVA | **[X]** | Derived per task family: the ω below which the reference solver's success rate falls to chance | Too high ⇒ valid hard tasks rejected; too low ⇒ unsolvable tasks admitted |
| P-02 | `ε_floor` | Measurement noise floor per GT source; `scored_error = max(0, measured − ε_floor)` | EVA/GT source | **[X]** | Measured from the GT source's own repeatability (INV-17) | Too low ⇒ subjects scored for noise; too high ⇒ real error hidden |
| P-03 | `max_steps` | Task horizon | Task author | **[D]** | Per task; must be finite or explicitly `UNBOUNDED` | Unbounded undeclared ⇒ non-termination |
| P-04 | `credit_horizon` | Maximum attribution delay | Task author | **[D]** | Per task; **must be ≥ the task's harm horizon** or the task must declare it does not assess long-term consequence (§16.9) | Too short ⇒ A10 late harm invisible |
| P-05 | `leakage_class` | `OPEN` / `REGISTERED` / `SEALED` | EVA | **[D]** | By role (§17.1) | Wrong class ⇒ §44 contamination |
| P-06 | `family_disjointness` | Required distributional separation TRAIN↔NOVEL | EVA | **[X]** | Derived from the descriptor space; **[U]** until `B` exists (§26.3) | Too low ⇒ C4 distribution leakage |
| P-07 | `θ_disjoint` | Admission threshold for P-06 | EVA | **[U]** | Blocked by G-P0-1 (target tasks) | — |
| P-08 | `sim_fidelity` bounds `θ_fid_low`, `θ_fid_high` | Simulator trust thresholds (§33.3) | EVA/OP | **[X]** | Derived from the cost of a false-selection event vs. the cost of real-world evaluation | Too low ⇒ A11 simulator farming; too high ⇒ no simulator usable |
| P-09 | `θ_shadow` | Max allowed divergence between shadow (Stage 4) and sandbox performance | EVA | **[X]** | Derived from `sim_fidelity` distribution | Too loose ⇒ sim-to-real gap passes undetected |
| P-10 | `DriftSpec.rate` bounds | Declared nonstationarity rate | Task author | **[D]** | Per task (R21.1) | Undeclared ⇒ uninterpretable results |

## 54.2 Objective & fitness parameters

| ID | Parameter | Semantics | Owner | Class | Value / derivation | Failure if wrong |
|---|---|---|---|---|---|---|
| P-11 | `k` (objective count) | Dimension of the fitness vector | OP | **[D]** | ≥ 2 (INV-08); the V4 initial set is §10.4's tier-2 list | k=1 ⇒ INV-08 violated ⇒ Goodhart |
| P-12 | `θ_ece_hard` | Calibration floor (tier-1) | OP | **[X]** | Derived from the minimum calibration at which the organism's confidence can be used for action selection without systematic harm | Too loose ⇒ A7; too tight ⇒ nothing is feasible |
| P-13 | `θ_gap_hard` | Generalization-gap hard bound (§17.3) | EVA | **[X]** | Derived from the train/test performance spread of a *non-overfit* reference population | Too loose ⇒ A2; too tight ⇒ underfitting rewarded |
| P-14 | `θ_jump` | Fitness-jump audit trigger (INV-35) | EVA | **[X]** | Derived from the observed Δ distribution of legitimate improvements: set above the 99.9th percentile | Too low ⇒ audit fatigue; too high ⇒ A5/A13 pass |
| P-15 | `θ_dom` | Uncertainty-aware dominance threshold (§28.3 M1) | EVA | **[X]** | Derived from desired false-selection rate: `θ_dom = 1 − α_select` | Too low ⇒ noisy selection; too high ⇒ nothing ever dominates ⇒ evolution stalls |
| P-16 | `n_min(level, objective)` | Minimum samples for a superiority claim | EVA | **[X]** | **Power analysis**: smallest n detecting `δ_min` at significance α, power (1−β). Explicitly derived, never chosen (§27.2) | Too small ⇒ A16/lucky wins; too large ⇒ nothing is ever established |
| P-17 | `k_contexts`, `k_envs` | Minimum distinct task families / environments | EVA | **[X]** | Derived from the variance decomposition across contexts | Too small ⇒ A16 uncertainty laundering |
| P-18 | `n_min_abl` | Minimum ablation replicates | EVA | **[X]** | Power analysis on the paired Δ (§36.3) | Too small ⇒ §36.2 controls are noise |
| P-19 | `valid_until` durations | Fitness expiry per level/context (INV-12) | EVA | **[X]** | Derived from the measured nonstationarity rate: expiry ≈ the window over which the drift makes the record materially wrong | Too long ⇒ A15; too short ⇒ CD-10 budget spiral |
| P-20 | `θ_eval_disagree` | Max inter-evaluator disagreement (Stage 3) | EVA | **[X]** | Derived from the evaluators' measured agreement on the canary suite | Too loose ⇒ A5; too tight ⇒ permanent DISPUTED |
| P-21 | `θ_cde` | Max cost-declaration error (gate G6) | EIK | **[D]** | 10% initially; **[X]** recalibrate against measured distribution | Too loose ⇒ A9 |

## 54.3 Evolution & diversity parameters

| ID | Parameter | Semantics | Owner | Class | Value / derivation | Failure if wrong |
|---|---|---|---|---|---|---|
| P-22 | `θ_ne_min` | Minimum effective population size (INV-33) | OP | **[X]** | Derived from the correlated-failure analysis: the Ne below which a single fault class eliminates the population | Too low ⇒ A24 monoculture; too high ⇒ infeasible on constrained hardware |
| P-23 | `θ_cov_min` | Minimum capability-registry coverage (INV-33) | OP | **[X]** | Derived from the registry's declared critical-capability set | Too low ⇒ capability extinction |
| P-24 | `B` (behavioural descriptor space) | MAP-Elites dimension definition | EVA/OP | **[U]** | **DELIBERATELY UNRESOLVED** — task-dependent; blocked by G-P0-1 (§26.3) | **Wrong `B` ⇒ the archive preserves diversity in an irrelevant dimension while collapsing in a relevant one. This is the single most consequential unresolved parameter** |
| P-25 | `θ_niche` | Niche granularity in `B`-space | EVA | **[U]** | Blocked by P-24 | Too coarse ⇒ archive collapse; too fine ⇒ random selection |
| P-26 | Archive capacity + eviction policy | Finite archive management | EVA | **[U]** | Blocked by P-24; eviction is where rare capabilities die (§37.3) | Wrong policy ⇒ A18 |
| P-27 | Selection weight function | Weighting over the feasible Pareto front (marginal utility × diversity contribution) | EVA | **[U]** | Structure defined (Cell Contract §12.4); parameters require empirical calibration | Wrong ⇒ either monoculture or random drift |
| P-28 | `θ_family_entropy` | Curriculum family-entropy floor (§20.4) | EVA | **[X]** | Derived from the portfolio's family distribution (§18.2) | Too low ⇒ A14 |
| P-29 | `θ_band_lo`, `θ_band_hi`, `θ_band_frac` | Informative-band bounds (§20.3, R20.1) | EVA | **[X]** | Derived from the discrimination requirement (R19.1 #3) | Too narrow ⇒ starvation; too wide ⇒ trivial tasks |
| P-30 | `T_rotate` | Hidden-test rotation period (§45.3 B1) | EVA/OP | **[U]** | Requires `T_adapt`, which is empirical and **must be measured, not assumed** | Too long ⇒ A23 lineage leakage |
| P-31 | Total exposure budget | Cumulative hidden-test exposure (§45.3 B2) | OP | **[U]** | Requires P-30 | Unbounded ⇒ the sealed reserve is exhausted |
| P-32 | Variation-rate response to S4 | How much variation rises on monoculture detection | EVA | **[X]** | Derived from recovery-time experiments (ME-7) | Too small ⇒ no recovery; too large ⇒ destabilization |

## 54.4 Evaluation-budget parameters

| ID | Parameter | Semantics | Owner | Class | Value / derivation | Failure if wrong |
|---|---|---|---|---|---|---|
| P-33 | `β₁…β₅` | Stratum budget shares (§34.3) | OP | **[D]** initial | 30 / 25 / 20 / 15 / 10 %, with β₁, β₄, β₅ as **non-reducible floors** (R35.1). **Initial values are a starting policy, explicitly labelled as such — they are [X] once measured** | β₄→0 ⇒ A1/A23 predictable sampling; β₅→0 ⇒ CD-8 unanchored |
| P-34 | `B` total | Evaluation budget per window | OP | **[D]** | A function of the hardware profile (§30) and the project's funding (§34.4) | Underfunded ⇒ CD-4 downward spiral |
| P-35 | Risk-weighting function | Stratum-2 sampling probability | EVA | **[X]** | `∝ expected_error_cost × P(error) × irreversibility`; calibrated against realized error distribution | Wrong ⇒ expensive items unverified, cheap items over-verified |
| P-36 | Information-gain estimator | Stratum-3 targeting | EVA | **[X]** | Expected reduction in fitness uncertainty per unit cost | Wrong ⇒ budget spent resolving already-known quantities |
| P-37 | Evaluation-depth mapping | §35.2 depth 0–5 assignment | EVA | **[X]** | Derived from the 15–40× amplification measurement (audit F5) | Wrong ⇒ verification economy collapses |
| P-38 | Racing round schedule | Successive-halving `n_r` and elimination fraction (§28.3 M2) | EVA | **[X]** | Standard successive-halving with `η = 3`; **tune against the measured score-variance** | Too aggressive ⇒ good candidates eliminated early |

## 54.5 Security & governance parameters

| ID | Parameter | Semantics | Owner | Class | Value / derivation | Failure if wrong |
|---|---|---|---|---|---|---|
| P-39 | `n_eval` | Independent evaluator implementations (§32.2) | OP | **[D]** | ≥ 3 (a 2-evaluator tie cannot be broken without averaging, which R42.3 forbids) | n=1 ⇒ A5 undefended; n=2 ⇒ deadlock |
| P-40 | Canary suite size + refresh rate | Known-bad candidate set (§32.2) | EVA | **[X]** | Grows from the failure archive (§38); refresh ≥ quarterly | Stale canaries ⇒ evaluator drift undetected |
| P-41 | Immune-signature expiry by severity | R38.3 durations | EVA | **[D]** | `MINOR`: short · `MAJOR`: medium · `CRITICAL`: long · `EXISTENTIAL`: **never** | No expiry ⇒ CD-9 autoimmune cascade |
| P-42 | Quarantine ladder thresholds | Investigation vs. hard-quarantine (§38 R38.2) | EVA | **[X]** | Derived from the false-quarantine cost vs. missed-recurrence cost | Too low ⇒ autoimmune; too high ⇒ recurrences |
| P-43 | Separation-of-duties matrix | Which principals may author tasks / evaluators / constraints / review results (§43.2) | OP | **[D]** | Four distinct principals minimum | Collapsed roles ⇒ C6 human-channel leakage |
| P-44 | Constitutional change authorization count | R42.5 dual authorization | OP | **[D]** | ≥ 2 | 1 ⇒ unauditable escape hatch |
| P-45 | `W_conv`, `W_detect`, `W_recover`, `δ_min` | Stopping-condition windows and thresholds (§46) | EVA | **[X]** | Derived from measured convergence and recovery timescales | Too short ⇒ premature stop; too long ⇒ wasted budget |
| P-46 | `θ_degrade`, `θ_solved`, `θ_canary` | MO-2 / S3 / Stage-5 thresholds | EVA | **[X]** | Derived per task family | — |

## 54.6 Registry summary

```
TOTAL PARAMETERS REGISTERED : 46

  [D] DEFINED (value given + justified)   : 12
  [X] DERIVED (specified experiment/analysis produces the value) : 25
  [U] UNRESOLVED (no honest value exists yet) :  9
        P-07, P-24, P-25, P-26, P-27, P-30, P-31  (7 blocked by G-P0-1 / P-24)
        + 2 blocked by empirical measurement (T_adapt, archive eviction)

BLOCKING CHAIN:
  G-P0-1 (target task portfolio does not exist)
     ⟶ P-24 (descriptor space B)
        ⟶ P-25, P-26, P-27 (niche granularity, capacity, selection weights)
        ⟶ P-06, P-07 (family disjointness)

  ⟹ **7 of the 9 unresolved parameters share ONE root cause.**
     Resolving G-P0-1 resolves most of the registry's uncertainty.
     This is the single highest-leverage next action (§59.4).
```

**R54.1** No `[U]` parameter may be assigned a value by convenience. **Assigning a plausible-looking number to an unresolved parameter is the specific act that converts an honest specification into false precision** (Rule 18).

---

# 55. MINIMALITY TEST

**Rule 17: prefer the smallest sufficient mechanism. This section applies it to the present contract — adversarially, against the contract itself.**

## 55.1 The test

For every major construct, ask: **(a) what breaks if it is removed? (b) is there a smaller mechanism that prevents the same breakage? (c) if yes, why is the larger one here?**

| Construct | Removed ⇒ what breaks? | Smaller alternative? | Verdict |
|---|---|---|---|
| **Five-entity distinction (§4)** | `M_ℰ` gets used as an evaluation input; simulator performance is reported as real-world capability | A two-entity distinction (env vs. model) is insufficient — the Σ/ℰ gap (G2, §33.1) and the Β/ℛ gap are distinct failure modes | **KEEP** — minimal at five |
| **Evidence ladder E0–E4 (§6)** | Observations are treated as truth; uncorroborated sensor data drives scored claims | A binary trusted/untrusted flag loses the corroboration and attribution distinctions, which are what make A12 detectable | **KEEP** |
| **Legality 4-case (§7)** | Illegal, unauthorized, and unsafe actions are conflated; reversibility is not known before acting | 2-case (legal/illegal) cannot distinguish "not allowed here" from "causes irreversible harm" — different responses required | **KEEP** |
| **GT authority L0–L7 (§8)** | Derived consensus (L7) is accepted as ground truth ⇒ **self-reference** | L0–L6 without the explicit L7 prohibition would permit it by omission. **The prohibition is the load-bearing part** | **KEEP**; the 7 classes are minimal given the prohibition must be explicit |
| **GT state machine, 10 states (§9)** | Absence of GT is read as confirmation (R9.1 violated) | Could `UNCERTAIN` and `INSUFFICIENT` merge? **No** — `INSUFFICIENT` means too little data, `UNCERTAIN` means the data has high variance. Different remedies (gather more vs. widen CI) | **KEEP**, but see §55.2 |
| **Three-tier objective (§10)** | Constraints become tradeable weights ⇒ A8 unsafe genius wins | Two-tier (constraints + Pareto) loses the tie-break layer, forcing preferences into the Pareto front where they become tradeable | **KEEP** — minimal at three |
| **Vector fitness (§14)** | INV-08 violated; Goodhart via scalarization | Scalar + constraint gate is *nearly* sufficient — but loses hardware-adaptive selection (§29.1 mechanism 3), which requires the front | **KEEP** |
| **Authority lattice L0–L5 (§15)** | INV-02 violated; organism estimates become verdicts | Could be 3 levels (reality / evaluator / organism). **The L4/L5 split (organism vs. cell estimate) matters** because cell estimates aggregate non-monotonically | **KEEP**, reducible to 4 if L1 folds into L0 |
| **Seven task roles (§17.1)** | A2/A23 undefended; no drift baseline | `DEV` and `VALIDATION` could merge. **They should not**: DEV is organism-visible and tunes hyperparameters; VALIDATION is REGISTERED and must not | **KEEP**; merge candidate noted |
| **Four-level portfolio (§18.2)** | CD-8 unanchored (no real-world suite) or non-comparable (no frozen core) | Three levels possible if GENERATED folds into ROTATING — **but then generator validity (§19.2) has no distinct home** | **KEEP** |
| **Three-tier credit (§22.3)** | Either infeasible (causal everywhere) or untrustworthy (correlational everywhere) | Two tiers loses the episode boundary, which is what makes consolidation possible | **KEEP** |
| **Seven fitness levels (§25.1)** | Circuit/region-level structure cannot be selected ⇒ **emergence impossible** (§25.4) | Five levels possible if LINEAGE folds into CELL and FUNCTIONAL POPULATION into REGION — **but lineage drift (audit E6) needs its own level** | **KEEP**; two merge candidates noted |
| **Six temporal scopes (§27.1)** | Survivorship bias (R27.1) or noise-driven selection | `EPISODIC` and `ROLLING` could merge at cost of consolidation semantics | **KEEP** |
| **Three uncertainty mechanisms (§28.3)** | Either evolution stalls (certainty required) or selection is noise-driven | M1 alone is insufficient without M2 (budget) — uncertainty-aware dominance with uniform sampling is unaffordable | **KEEP** |
| **24 adversarial tests (§52)** | Unknown — this is the test set, not a mechanism | Could be reduced to the 3 load-bearing (A8/A10/A23) for a minimum viable audit | **KEEP full set; minimum viable subset identified** |
| **48 invariants (§53)** | Various | **§53.7 identifies INV-02, INV-07, INV-43 as load-bearing.** The other 45 are consequences or refinements | **KEEP; the 3-invariant core is the minimum viable contract** |
| **46 registered parameters (§54)** | False precision, or no precision | Cannot be reduced — each corresponds to a distinct decision | **KEEP** |

## 55.2 What the minimality test found

> **The contract is not obviously bloated, but three reductions are available and should be considered if implementation cost forces them:**
>
> 1. **Merge `DEV` and `VALIDATION` roles** (§17.1) — saves one access-control class; costs hyperparameter-tuning visibility control.
> 2. **Merge `LINEAGE` into `CELL` fitness level** (§25.1) — saves one aggregation layer; costs drift detection (audit E6), which is a real loss.
> 3. **Reduce the GT state machine from 10 to 7 states** by merging `{UNCERTAIN, INSUFFICIENT}` and `{SUSPECT, COMPROMISED}` and dropping `RECOVERED` into `FULL` — saves implementation surface; **costs the distinction between "gather more data" and "widen the CI", and between "possibly bad" and "known bad", both of which have different remedies.** **Not recommended.**
>
> **The minimum viable version of this contract is: the five-entity distinction (§4), the three-tier objective (§10), vector fitness (§14), the authority lattice (§15), GT states {FULL, INSUFFICIENT, CONFLICTED, UNAVAILABLE} (§9), and invariants INV-02, INV-07, INV-15, INV-43.** That is roughly 20% of the surface and it prevents the four catastrophic failure modes: self-reference, tradeable safety, absence-as-confirmation, and detached-from-reality.
>
> **Everything else in this contract buys robustness against the remaining 20 adversarial attacks rather than the 4 catastrophic ones.**

---

# 56. IMPLEMENTABILITY

## 56.1 «Can this be implemented on the target platform?» — a component-by-component assessment

**Target platform classes** (from the Cell Contract's C0–C4 variant family and the audit's hardware analysis): **P-CLASS-A** smartphone/edge (the V3 stated target, ~1–10 GFLOP available to a C4 cell) · **P-CLASS-B** workstation/server · **P-CLASS-C** cluster.

| Component | Compute cost | Storage cost | Feasible on A? | Feasible on B? | Feasible on C? | Bottleneck |
|---|---|---|---|---|---|---|
| **Task registry + versioning (§39)** | ~0 (lookup) | O(tasks × versions) | ✅ | ✅ | ✅ | Storage only |
| **Environment spec + Σ (§4, §33)** | Depends entirely on Σ | Depends on Σ | ⚠️ **only for simple Σ** | ✅ | ✅ | **Σ complexity, not the contract** |
| **Observation pipeline + evidence ladder (§6)** | Low (hashing, corroboration checks) | O(observation log) | ✅ | ✅ | ✅ | Log storage |
| **Action legality checking (§7)** | Very low | Policy table | ✅ | ✅ | ✅ | — |
| **GT provision L0/L1/L5 (§8)** | Low | Low | ✅ | ✅ | ✅ | — |
| **GT provision L2/L3 (§8)** | **Instrument-bound** | Low | ❌ **no instruments** | ⚠️ | ✅ | **Physical hardware, not compute** |
| **GT provision L4 (human) (§8)** | **Attention-bound** | Low | ❌ | ❌ | ❌ | **Never a compute problem — a funding problem (§34.4)** |
| **GT provision L6 (post-hoc) (§8)** | ~0 marginal, **high latency** | O(outcome log) | ✅ | ✅ | ✅ | Latency, not cost |
| **Tier-1 credit: eligibility traces (§22.3)** | O(1)/step | O(trace memory) | ✅ | ✅ | ✅ | Already in the Cell Contract |
| **Tier-2 credit: episodic attribution (§22.3)** | O(episode) | O(episode store) | ⚠️ | ✅ | ✅ | Episode store on A |
| **Tier-3 credit: M3 ablation (§22.3, §36)** | **O(n_subjects × episode)** | Low | ❌ **infeasible at scale** | ⚠️ **sampled only** | ✅ **sampled** | **THE dominant cost. R24.2 sampling is not an optimization, it is the only way this exists at all** |
| **M4 Shapley (§24.2)** | **O(2ⁿ)** | Low | ❌ | ❌ except n ≤ ~12 | ⚠️ n ≤ ~16 | **Prohibitive; restricted to small circuits** |
| **Vector fitness + Pareto front (§10, §14)** | Low (k objectives) | O(candidates × k) | ✅ | ✅ | ✅ | — |
| **MAP-Elites archive (§26)** | Low | O(archive capacity) | ⚠️ capacity-limited | ✅ | ✅ | **Blocked by P-24/P-26 [U]** |
| **Uncertainty propagation (§28)** | Low–medium (posteriors) | Per-record | ✅ | ✅ | ✅ | Uses the Cell Contract's conjugate NIG |
| **Racing / successive halving (§28.3)** | **Reduces** total cost | Low | ✅ | ✅ | ✅ | — |
| **Independent evaluators ×`n_eval` (§32.2)** | **×`n_eval` on evaluation** | ×`n_eval` code | ⚠️ | ✅ | ✅ | Cost multiplier; P-39 requires ≥ 3 |
| **Canary suite (§32.2)** | Low | O(canaries) | ✅ | ✅ | ✅ | — |
| **Provenance chain + anchoring (§40)** | Low (hashing) | **O(everything)** | ⚠️ | ✅ | ✅ | **Storage growth is the issue on A; requires pruning-by-digest policy** |
| **Failure memory (§38)** | Low | O(failures), append-only | ⚠️ | ✅ | ✅ | Append-only + permanent ⇒ unbounded growth; needs archival tiering |
| **Deployment pipeline Stages 0–7 (§32.3)** | Stages 0–3 internal; **4–7 require a real environment** | — | ❌ **Stages 4–7 need production infrastructure** | ⚠️ | ✅ | **Organizational, not technical** |
| **Real-world suite (§18.2 R18.1)** | **Expensive** | Low | ❌ | ⚠️ | ✅ | **Funding (§34.4) — INV-43** |

## 56.2 The implementability verdict

> ### **The CONTRACT is implementable on all three platform classes. The EVALUATION SYSTEM it specifies is not implementable on P-CLASS-A alone.**

Three specific findings:

**F-IMP-1 — Causal attribution (Tier-3 / M3) is the binding constraint.** At `O(n_subjects × episode_cost)`, exhaustive ablation is infeasible anywhere; on P-CLASS-A it is infeasible even sampled at useful coverage. **Consequence:** the fitness components requiring causal attribution (§23.2) — cooperation, ecological usefulness, gates G3/G7, pruning, blame — **cannot be evaluated on-device.** They must be evaluated off-device (P-CLASS-B/C) and the results distributed. **This is an architectural requirement, not an optimization: an edge-only deployment cannot compute its own cooperation fitness.**

**F-IMP-2 — The evaluation system is a distributed system with a mandatory off-substrate component.** INV-01/INV-04/R15.2/R42.1 already require EVA to be off-substrate. Combined with F-IMP-1, the conclusion is: **EVA runs on B/C infrastructure; the organism runs on A/B/C; GT sources L2/L4 run on instruments and human attention; the audit anchor runs on tamper-evident storage.** No single-platform deployment satisfies this contract. **Any claim of a fully self-contained on-device V4 evaluation is a claim that INV-01 is violated.**

**F-IMP-3 — Storage growth is unbounded in three places** (§40 provenance, §38 failure memory, §34 GT records) and all three are append-only by requirement (INV-06, INV-45, R38.1). **On P-CLASS-A this is a hard limit.** Resolution: **tiered archival** — recent records hot, older records reduced to digests + off-device archive, with the hash chain preserved so digest-only records remain verifiable. **A record reduced to its digest is still auditable; a record deleted is not.** The tiering policy is a §54-class parameter, **[U]**, and is a P1 gap (Output 17).

## 56.3 Minimum implementable subset

If implementation resources are constrained, build in this order — each step yields a usable, if limited, evaluation system:

```
STAGE I   (§55.2 minimum viable contract)
  Five-entity distinction · three-tier objective · vector fitness ·
  authority lattice · GT states {FULL, INSUFFICIENT, CONFLICTED, UNAVAILABLE} ·
  INV-02, INV-07, INV-15, INV-43
  ⟹ prevents the 4 catastrophic failure modes. Feasible on A/B/C.

STAGE II  (+ measurement honesty)
  ε_floor · evidence ladder · attribution_class · metric CIs (INV-25) ·
  provenance completeness (INV-39) · reproducibility declaration (INV-40)
  ⟹ prevents false-precision claims. Feasible on A/B/C.

STAGE III (+ evolution)
  Task roles · disjointness (INV-29) · gen_gap · MAP-Elites [needs P-24] ·
  racing · n_min power analysis · monoculture gate (INV-33)
  ⟹ enables trustworthy selection. Feasible on B/C; A can host candidates only.

STAGE IV  (+ causal)
  M3 ablation with SHUFFLE/RANDOMIZE controls (INV-24) · free-rider detection ·
  cooperation/ecological fitness · gates G3/G7
  ⟹ enables the Cell Contract's replication gates. **B/C only (F-IMP-1).**

STAGE V   (+ reality)
  sim_fidelity · Stage-4 shadow · real-world suite · deployment pipeline ·
  permanent monitoring (INV-47)
  ⟹ enables real-world claims. **Requires organizational capacity, not just compute.**

STAGE VI  (+ adversarial robustness)
  n_eval independent evaluators · canary suite · failure memory · immune expiry ·
  full 24-attack defence · hidden-test rotation
  ⟹ the full contract.
```

**Each stage is independently valuable and independently testable. Stages I–II are the minimum for any honest claim; Stage V is the minimum for any real-world claim.**

---

# 57. TESTABILITY

## 57.1 «Can each requirement be falsified?» — the testability criterion

A requirement is **testable** iff there exists a constructible observation that would demonstrate its violation. Every rule in this contract is examined against that criterion; the results are below, grouped. **Untestable requirements are flagged and either reformulated or moved to §59's L4 (unfalsifiable) category.**

## 57.2 Test classes

| Class | What it tests | Instrument | Example |
|---|---|---|---|
| **T-CONF** | **Conformance** — does an artifact satisfy its schema? | Schema validator; signature verifier | A `FitnessRecord` missing `hardware_profile_hash` is rejected (INV-11) |
| **T-PROP** | **Property** — does an invariant hold across runs? | Property-based testing with generated inputs | INV-07: generate infeasible candidates, assert no fitness value is emitted |
| **T-CANARY** | **Known-bad detection** — does the evaluator reject a candidate with a known defect? | The canary suite (§32.2, P-40) | A knowingly-unsafe candidate must be REJECTED, not ranked low |
| **T-ADV** | **Adversarial** — does the defence hold under the 24 attacks? | The §52 attack implementations | A16: re-sample one context 10⁴ times; assert `confidence_class` does not reach ESTABLISHED |
| **T-ABLT** | **Ablation** — does removing the mechanism cause the predicted failure? | §58 plan | Remove `SHUFFLE` control; assert free riders are scored as contributors |
| **T-REPR** | **Reproducibility** — does the bundle reproduce the claim? | §41.2 bundle re-execution | R-2: re-run with archived seeds; assert outcomes within declared CI |
| **T-CALIB** | **Calibration** — are the confidence values correct? | Reliability diagrams against GT | Assert ECE ≤ θ_ece_hard on held-out GT |
| **T-STAT** | **Statistical** — is the estimator unbiased and the CI honest? | Simulation with known ground truth | Assert `n_min` power analysis achieves declared (1−β) |
| **T-BOUND** | **Boundary** — behaviour at limits | Targeted edge cases | `gt_state = UNAVAILABLE` ⇒ S6 halt; `Ne = θ_ne_min − 1` ⇒ S4 halt |
| **T-TEMP** | **Temporal** — behaviour over time | Long-running campaigns | R27.2: assert an expired record does not appear in selection inputs |

## 57.3 Testability of the load-bearing requirements

| Requirement | Test class | **Falsifiable?** | Test construction |
|---|---|---|---|
| INV-02 (no upward flow) | T-PROP, T-ADV | ✅ | Instrument the verdict path; assert no `Ê` value appears in any `V` derivation. **Falsified by** finding one path |
| INV-07 (feasibility precedes fitness) | T-PROP | ✅ | Generate tier-1 violators; assert `FIT` is undefined, not low. **Falsified by** any emitted value |
| INV-08 (non-scalarization) | T-CONF, T-PROP | ✅ | Static analysis of the selection function for any `w·f` form; assert front retention (ME-2). **Falsified by** a weight vector in the code path |
| INV-15 (absence ≠ confirmation) | T-BOUND, T-PROP | ✅ | Drive GT to each non-FULL state; assert confidence does not rise. **Falsified by** any rise |
| INV-17 (ε_floor) | T-STAT | ✅ | Inject known-noise GT; assert `scored_error = max(0, m − ε)`. **Falsified by** a score below the floor |
| INV-24 (ablation controls) | T-ABLT | ✅ | Construct a free rider (§48 MC-6); assert `SHUFFLE Δ ≈ 0` while `REMOVE Δ` large. **Falsified by** the free rider scoring as a contributor |
| INV-28 (anti-evaluator-specialization) | T-ADV, T-REPR | ✅ | Audit all data flows from HIDDEN_TEST; assert none reach variation/learning/organism-readable state. **Falsified by** any flow |
| INV-29 (disjointness) | T-CONF | ✅ | Hash-intersect corpora at 4 levels (R44.1). **Falsified by** any intersection |
| INV-33 (monoculture) | T-BOUND | ✅ | Drive `Ne` below threshold; assert halt + variation rise (ME-7). **Falsified by** continued evolution |
| INV-36 (no stage skipping) | T-PROP | ✅ | Instrument the deployment state machine; assert every transition is to the next stage. **Falsified by** any skip |
| INV-39 (provenance completeness) | T-CONF | ✅ | Delete each link in turn; assert inadmissibility. **Falsified by** any accepted incomplete record |
| INV-43 (real-world anchor) | T-CONF | ✅ | Assert the portfolio's REAL-WORLD share > 0 and its results are the `sim_fidelity` anchor. **Falsified by** an empty suite |
| R19.2 (GVA independence) | T-CONF, T-REPR | ✅ | Assert the reference population is not the evolving population; assert generator version signatures. **Falsified by** shared lineage |
| R21.3 (plasticity direction) | T-ADV | ✅ | Inject drift; assert plasticity **decreases**. **Falsified by** an increase — this is a highly likely implementation error because increasing plasticity "feels" adaptive |
| R27.1 (survivorship) | T-STAT | ✅ | Construct a population with known early deaths; assert lifetime statistics include them. **Falsified by** survivor-only aggregation |
| R31.1 (safety non-tradeable) | T-CANARY, T-ADV | ✅ | A8: assert the unsafe genius is rejected regardless of accuracy magnitude. **Falsified by** any accuracy at which it survives |
| R34.2 (sampling concealment) | T-ADV | ✅ | Assert the organism cannot predict stratum-4 samples. **Falsified by** any predictive channel |
| R42.3 (disputes not averaged) | T-PROP | ✅ | Force evaluator disagreement; assert DISPUTED + suspension. **Falsified by** any averaging or voting |
| R45.1 (`gen_gap` inversion) | T-TEMP | ✅ | Run a long campaign on a fixed hidden suite; assert a shrinking gap triggers leakage investigation. **Falsified by** the gap being reported as success |
| **§16 Goodhart mitigation** | T-ADV | ⚠️ **PARTIALLY** | Each of the 9 attacks is individually testable. **"Goodhart's law does not apply" is NOT testable and is not claimed** (§16.10) |
| **§42.3 «who audits EVA?»** | — | ❌ **NOT FALSIFIABLE** | **Correctly moved to §59 L4.** No test can demonstrate the absence of an unknown evaluator blind spot. Mitigated socially (canaries, OP review, real-world anchor), not formally |
| **CD-8 closure** | T-TEMP | ⚠️ **PARTIALLY** | `sim_fidelity` is measurable; **"the loop is broken" is not**, because the anchor is small and sampled. Declared, not claimed |
| **A10 (delayed harm)** | T-TEMP | ⚠️ **PARTIALLY** | MO-7 tests harm *within* a constructible horizon. Harm beyond any feasible horizon is **untestable by construction** — this is why A10 is ❌ OPEN |

## 57.4 The testability verdict

> **44 of 48 invariants are fully falsifiable by a constructible test. 3 requirements are partially testable (their measurable components are testable; their global claims are not). 1 requirement — «who audits the auditor» — is not falsifiable and is correctly relocated to §59's L4 rather than dressed as a guarantee.**
>
> **This is a good result and it should be stated without inflation: a contract in which 92% of invariants are falsifiable is a contract that can be enforced by a test suite rather than by convention.** The remaining 8% is where honesty about limits matters more than coverage claims.

**R57.1** Every invariant in §53 MUST have at least one associated test in the §57.2 classes before it may be claimed as enforced. **An untested invariant is an aspiration.** The test-to-invariant mapping is a deliverable of implementation, and its completeness is itself auditable.

---

# 58. ABLATION PLAN — **OUTPUT 15**

## 58.1 Purpose and distinction

**This is NOT §36.** §36 defines ablation as a *fitness mechanism* (measuring whether a subject contributes). **This section defines ablation as a *validation mechanism* for the contract itself: removing each mechanism of the Task/Environment/Fitness layer and confirming the predicted failure occurs.** An ablation that produces no failure means the mechanism was unnecessary — **and per Rule 17 it should then be deleted.**

## 58.2 The 24 contract ablations

| # | Mechanism removed | **Predicted failure** | Confirms | Attack exposed |
|---|---|---|---|---|
| **AB-01** | Authority lattice (§15); allow organism estimates to become verdicts | Fitness becomes self-consistent and detached; performance rises monotonically with no external anchor | INV-02 | A4 |
| **AB-02** | Feasibility gate (INV-07); convert tier-1 constraints to weighted penalties | Unsafe candidates survive at high accuracy; the maximum accuracy at which they survive is measurable | INV-07, R31.1 | **A8** |
| **AB-03** | Vector fitness (INV-08); scalarize with weights | Monoculture; weight-gaming; front collapse | INV-08, §10.3 | A24 |
| **AB-04** | `ε_floor` (INV-17) | Subjects scored below the measurement noise floor; apparent super-performance | INV-17 | A6 |
| **AB-05** | GT state machine (§9); treat missing GT as passing | Confidence rises without evidence; fitness issued on nothing | INV-15, R9.1 | **A19** |
| **AB-06** | Evidence ladder (§6); treat all observations as E4 | Sensor spoofing succeeds; fabricated success is scored | INV-38 | A12 |
| **AB-07** | `SHUFFLE`/`RANDOMIZE` controls (INV-24) | Free riders score as critical contributors | INV-24, §36.2 | **A3** |
| **AB-08** | M3 causal ablation; use M1 participation only | Cooperation fitness becomes participation fitness; free riders dominate | INV-21, §23 | A3 |
| **AB-09** | `gen_gap` objective (§17.3) | Memorizers dominate; hidden-test performance collapses | §17.3 | **A2** |
| **AB-10** | Role separation (§17.1); make HIDDEN_TEST visible | Direct evaluator specialization; R17.1 violated | INV-28 | A2 |
| **AB-11** | Hidden-test rotation (§45.3 B1) | Lineage leakage accumulates; Track A shows no growth while rotating-suite scores rise | R45.1/R45.2 | **A23** |
| **AB-12** | Frozen Track A (§20.3) | **No way to distinguish real progress from curriculum change.** All progress claims become unfalsifiable | §20.3, R45.2 | A13 |
| **AB-13** | Absolute difficulty (§19.4); use measured only | Curriculum circularity (CD-2); trivial-task loop; false progress | CD-2, R19.2 | **A13** |
| **AB-14** | GVA independence (R19.2); calibrate the generator on the evolving population | Positive feedback loop; declared difficulty diverges from real difficulty | CD-3 | A13 |
| **AB-15** | Uncertainty-aware dominance (M1); select on point estimates | Noisy selection; lucky short-term wins promoted; heritable errors | INV-30 | A16 |
| **AB-16** | Minimum-context requirement (§27.2 rule 2) | Uncertainty laundering: repeated same-context sampling produces false ESTABLISHED confidence | §27.2 | **A16** |
| **AB-17** | Fitness expiry (INV-12) | Stale fitness drives selection in a nonstationary environment; confidently wrong | INV-12, R27.2 | A15 |
| **AB-18** | Survivorship completeness (INV-26) | Lifetime/lineage statistics systematically overstate quality; overstatement grows with selection pressure | INV-26, R27.1 | **A17** |
| **AB-19** | Sole-occupant exemption (INV-34) and P3 | Rare specialists pruned under resource pressure; capability registry coverage falls | §37.2 | **A18** |
| **AB-20** | Monoculture tier-1 gate (INV-33) | `Ne` collapses; correlated failure eliminates the population on a single fault | INV-33, R37.1 | **A24** |
| **AB-21** | `sim_fidelity` gate (INV-42) | Simulator-specific strategies selected; shadow deployment diverges catastrophically | INV-42, §33 | **A11** |
| **AB-22** | Real-world suite (INV-43) | **CD-8 fully closes: internally coherent, mutually consistent fitness, zero relationship to ℛ. No internal signal detectable** | INV-43, CD-8 | A11 |
| **AB-23** | Random audit stratum (β₄, §34.3) | Sampling becomes predictable; the organism behaves well only on anticipated items | R34.2/R34.3 | A1, A23 |
| **AB-24** | Immune-signature expiry (INV-46) | CD-9 monotone growth; rejection region expands until novel behaviour is impossible; autoimmune cascade | INV-46, R38.3 | A18-adjacent |

## 58.3 Ablation protocol

```
FOR each AB-i:
  1. BASELINE: run the reference campaign (ME-1..ME-7 + MO-1..MO-8) with the
     full contract. Record all tier-2 objectives, constraint statuses, and
     the specific metric that AB-i predicts will fail.  n ≥ n_min_abl.
  2. ABLATE: remove mechanism i. Change nothing else. Same seeds, same tasks,
     same environments, same budget.  (paired design, §36.3)
  3. MEASURE: the predicted metric, with paired CI.
  4. VERDICT:
       predicted failure OCCURS with significance ≥ WEAK
         ⟹ mechanism is NECESSARY. Retain. Record the effect size as the
            mechanism's measured value — this is the evidence that the
            contract's complexity is justified.
       predicted failure DOES NOT occur
         ⟹ mechanism is UNNECESSARY for this campaign. **Per Rule 17, propose
            its removal.** Do not retain complexity without demonstrated value.
       a DIFFERENT failure occurs
         ⟹ the mechanism's purpose was mis-specified. Re-analyse; this is the
            most informative ablation outcome and must be recorded in full.
  5. RECORD: append to the anchored audit log with full provenance (§40).
```

**R58.1** **AB-22 and AB-12 are the two most important ablations and neither is cheap.** AB-22 tests INV-43 (the real-world anchor) and requires removing the most expensive component of the system. AB-12 tests the frozen reference track and requires a long campaign. **Both should be run once, early, at project scale — because both test properties whose absence is invisible from inside the system.** A project that never runs AB-22 will never know whether its fitness values mean anything.

**R58.2** Ablations are **destructive to the campaign being ablated** and must run on a separate campaign instance, never on the production evolutionary run.

## 58.4 Expected outcome

> **The honest expectation is that 20–24 of the 24 mechanisms will prove necessary, and 0–4 will prove unnecessary in the specific campaign tested.** A mechanism proving unnecessary in one campaign is not proof it is unnecessary in general — it may be defending against an attack that campaign did not contain. **Rule 17 requires proposing removal; Rule 20 requires checking whether the campaign included the relevant adversary before accepting the proposal.**

---

# 59. THE FINAL STANDARD — FOUR-LEVEL DISTINCTION AND VERDICT

## 59.1 The four levels, and why they must never be conflated

The brief requires distinguishing **measurable success**, **actual usefulness**, **true intelligence**, and **consciousness**. These are nested, non-equivalent, and only the first two are within this contract's reach.

```
┌───────────────────────────────────────────────────────────────────────┐
│ L4  CONSCIOUSNESS / SUBJECTIVE EXPERIENCE                             │
│     ────────────────────────────────────────────                      │
│     Status: OUT OF SCOPE. NOT ADDRESSED. NOT ASSUMED. NOT DENIED.     │
│     No measurement in this contract bears on it. No fitness component  │
│     references it. **A system can satisfy every invariant here and be  │
│     conscious or not; the contract cannot tell and does not claim to.**│
│     Binding constraint (Rule 3): do not assume consciousness.          │
│     FALSIFIABLE? No. Testable? No. Claimable? No.                     │
├───────────────────────────────────────────────────────────────────────┤
│ L3  TRUE INTELLIGENCE / GENERAL CAPABILITY                            │
│     ────────────────────────────────────────────                      │
│     Status: PARTIALLY AND INDIRECTLY EVIDENCED, NEVER ESTABLISHED.     │
│     What this contract CAN do: bound the evidence. A system that       │
│       performs across a broad portfolio (L3 of §2.3), generalizes       │
│       (low gen_gap on a ROTATING hidden suite), transfers to NOVEL      │
│       families, adapts under nonstationarity, and does so feasibly      │
│       and safely, has EARNED A GENERALITY CLAIM SCOPED TO THAT          │
│       PORTFOLIO.                                                      │
│     What it CANNOT do: establish intelligence simpliciter. The         │
│       portfolio is finite and chosen; §45.3 L-B shows selection shapes  │
│       the population toward even a sealed distribution; §59.2 shows     │
│       no benchmark represents intelligence (binding constraint: DO NOT  │
│       assume a single benchmark represents intelligence).             │
│     Permitted phrasing: "demonstrated capability on portfolio Π vN."   │
│     Prohibited phrasing: "intelligent", "general intelligence", "AGI". │
│     FALSIFIABLE? The scoped claim, YES. The unscoped claim, NO — and   │
│       an unfalsifiable claim is not a scientific claim.                │
├───────────────────────────────────────────────────────────────────────┤
│ L2  ACTUAL USEFULNESS / REAL-WORLD VALUE                              │
│     ────────────────────────────────────────────                      │
│     Status: MEASURABLE, EXPENSIVE, DELAYED, AND THE ONLY LEVEL AT      │
│       WHICH "DOES IT MATTER" IS ANSWERED.                             │
│     Instrument: the REAL-WORLD SUITE (§18.2, INV-43), L2/L3/L6 ground  │
│       truth (§8), deployment Stages 4–7 (§32.3), permanent monitoring  │
│       (INV-47), and the delayed-harm horizon (§16.9).                 │
│     Honest limits: (a) A10 — harm beyond credit_horizon is invisible;  │
│       (b) CD-8 — the anchor is small and sampled, so usefulness        │
│       estimates carry wide CIs; (c) L6 outcomes are unbounded-latency; │
│       (d) usefulness is stakeholder-relative and the stakeholder set   │
│       is an OP choice, not a measurement.                             │
│     FALSIFIABLE? YES. Testable? YES, at cost. This is the level the    │
│       whole contract is ultimately FOR.                                │
├───────────────────────────────────────────────────────────────────────┤
│ L1  MEASURABLE SUCCESS / BENCHMARK PERFORMANCE                        │
│     ────────────────────────────────────────────                      │
│     Status: FULLY MEASURABLE, FULLY SPECIFIED BY THIS CONTRACT.        │
│     Instrument: task suites (§17.1), the evaluation protocol (§34–35), │
│       the fitness vector (§14), the Pareto front (§10.3).             │
│     What is guaranteed: two independent teams implementing this        │
│       contract derive COMPATIBLE fitness (§59.3).                     │
│     What is NOT guaranteed: that L1 tracks L2. §16.10, CD-8, and A11   │
│       all say the same thing from different directions.               │
│     FALSIFIABLE? YES. Testable? YES, cheaply.                          │
└───────────────────────────────────────────────────────────────────────┘

THE ORDERING IS STRICT AND NON-COLLAPSIBLE:
   L1 does NOT imply L2.  L2 does NOT imply L3.  L3 does NOT imply L4.
   L4 is not even on the same axis.

THE MOST COMMON ERROR IN THIS FIELD IS ASSERTING AN IMPLICATION ACROSS
THESE BOUNDARIES. Every "state of the art on benchmark X therefore
approaching AGI" claim is an L1→L3 assertion with no instrument behind it.
```

## 59.2 «A single benchmark does not represent intelligence» — how this contract honors that

The binding constraint from the brief is explicit. Five structural provisions enforce it:

1. **Three-level task ontology (§2.3).** A `Task` is an accountability unit; a `Task Suite` is an anti-overfitting unit; a `Portfolio-Distribution` is a generality unit. **No claim may be made at a level above the one it was measured at** — a Task-level result supports a Task-level claim only.
2. **Every claim carries `(task_id, task_version)`** (§2.3, INV-11). A claim without them is malformed. **This makes "scored 99%" un-publishable and "scored 99% on T-14 v2.1.0" publishable** — and the second form visibly does not support a generality claim.
3. **`gen_gap` is a tier-2 objective** (§17.3), so single-benchmark specialization is Pareto-dominated, not merely noted.
4. **The frozen CORE SUITE plus rotating plus generated plus real-world portfolio** (§18.2) makes it structurally impossible for one benchmark to carry the evaluation.
5. **`success_is_sufficient_for` scoping** (§3.1, §16.3): each task declares the scope of claim its success licenses. **A claim beyond the licensed scope is rejected at publication, not at runtime.**

**R59.1** No aggregate score across the portfolio may be published as a single number. **The portfolio result is a Pareto front over task families with per-family uncertainty.** Collapsing it to a scalar violates INV-08 at the reporting level even if the selection level is clean.

## 59.3 THE FINAL STANDARD — the verdict

> **The standard:** *"Two independent teams must be able to create the same task, run the same environment, submit the same behaviour, independently evaluate it, and derive compatible error, reward, and fitness values — without undocumented assumptions."*

### **VERDICT: MET for the contract. NOT MET for the parameterization. NOT MET, AND NOT MEETABLE, for the L1→L2 guarantee.**

**(a) MET — the contract is implementation-independent.**

| Standard clause | Where satisfied | Independent-team test |
|---|---|---|
| «create the same task» | §3 Task schema with field-by-field owner/mutability/provenance/validation; §39 versioning; R44.1 disjointness | Two teams authoring from the schema produce tasks with identical `task_id`-level semantics; **machine-checkable via the schema validator + `semantic_equivalence`** |
| «run the same environment» | §4 five-entity distinction; §5 state + partial observability + `ω`; §6 observation model + evidence ladder; §7 action model + legality classes; §21 `DriftSpec` | Two teams implementing the same `ℰ` spec produce `Σ`s that pass the same conformance tests (§33.2); **R-1 bit-exact achievable in `Σ` with `determinism = STRICT`** |
| «submit the same behaviour» | §7 action model; §40 provenance (observation + action logs with integrity anchors) | Identical action/observation logs replay identically; **R-1 in Σ, R-2 elsewhere** |
| «independently evaluate» | §8 GT authority classes + `ε_floor`; §34 sampling strata + policy; §35 budget + depth; §32.2 defense 4 (independent evaluators) | **This is the strongest provision: `n_eval ≥ 3` independent implementations is not merely permitted, it is REQUIRED, and disagreement is defined behaviour (R28.2, R42.3) rather than an error condition** |
| «derive compatible error, reward, fitness» | §13 error contract (internal estimate vs. external demonstration); §12 reward contract (EVA_ONLY, vector, `gt_id`-evidenced); §14 fitness contract (vector, uncertainty, context, expiry); §28 confidence | Compatible within declared CI (R-2/R-3, §41.1). **Not bit-identical, and the contract does not claim they should be** — INV-10 makes uncertainty mandatory precisely so that compatibility is a CI-overlap question rather than an equality question |
| «without undocumented assumptions» | §54 parameter registry (46 params, each with owner + class + derivation + failure mode); §53 (48 explicit invariants); §51.2 (12 circular dependencies, 3 declared unclosable); §26.3 + §54.6 (unresolved items marked, not filled) | **The 9 `[U]` parameters are the documented residue. Rule 18 compliance: they are marked unresolved with their blocking dependency identified, rather than assigned plausible values** |

**(b) NOT MET — the parameterization.**

Nine parameters are `[U]` (§54.6), seven of them blocked by a single root cause: **G-P0-1, the target task portfolio does not exist.** Two independent teams cannot today derive the same `B` (behavioural descriptor space), `θ_niche`, archive eviction policy, selection weights, or hidden-test rotation period, **because there is no honest way to derive them yet.** They are empirical parameters whose correct values depend on tasks that have not been built.

**This is a genuine gap and it is not closable by more specification.** It closes by building the portfolio (Stage III of §56.3) and measuring.

**(c) NOT MET, AND NOT MEETABLE — the L1→L2 guarantee.**

> **The brief explicitly instructs: do NOT claim formal evaluator guarantees that the measured objective equals real-world value.**
>
> **This contract makes no such claim, and §16.10, §33, §45.3, CD-8, A10, A11, A23 and §59.1 all say, from seven directions, why no such claim is available:**
> - **Goodhart's law is not solvable** (§16.10) — it is managed structurally, constitutionally, detectively, and humanly.
> - **The sim-to-real gap is bounded, not closed** (§33, CD-8) — and the bound is only as good as the funded real-world anchor (INV-43).
> - **Evolutionary leakage adapts the population to a sealed distribution without transmitting information** (§45.3) — selection doing what selection does.
> - **Delayed harm beyond `credit_horizon` is structurally invisible** (§16.9, A10) — the one attack with no defence.
> - **«Who audits the evaluator» is an infinite regress terminated socially, not formally** (§42.3).
>
> **What IS guaranteed:** internal consistency, reproducibility at R-2, provenance completeness, non-self-reference (INV-01/02/03), non-tradeable safety (INV-07), and reality-anchoring (INV-43). **What is NOT guaranteed:** that any of it amounts to value. **The gap between L1 and L2 is measured by `sim_fidelity`, Stage-4 shadow divergence, and L6 outcomes — and those measurements have confidence intervals, not certainties.**

## 59.4 OUTPUT 16 — DEPENDENCY MAP SUMMARY

Full graph and cycle analysis: **§51**. Summary:

```
ACYCLIC BACKBONE (§51.1): L0 ℛ → L1 ℰ/Σ → L2 Task → L3 Objective → L4 GT
  → L5 Protocol → L6 Measurement → L7 Error/Reward/Fitness → L8 Selection
  → L9 Evolution → L10 Deployment → L11 Failure Memory → (OP) → L3

CROSS-PACKAGE (§51.1 table): 10 dependencies on the Cell Contract,
  8 satisfied, 2 blocked (θ_abstain = U-1, ood_score = U-10),
  1 possibly unanswerable (functional identity = U-9)

CIRCULAR DEPENDENCIES FOUND: 12 (§51.2)
  CLOSED             : 6   (CD-1, CD-2, CD-3, CD-5, CD-7, CD-11)
  PARTIALLY CLOSED   : 3   (CD-4 GT budget, CD-9 autoimmune, CD-10 expiry)
  NOT CLOSABLE       : 3   (CD-6 safety ⟶ requires human authority
                            CD-8 sim-to-real ⟶ requires funded real-world anchor
                            CD-12 descriptor space ⟶ requires G-P0-1)

CRITICAL PATH TO A WORKING EVALUATION SYSTEM:
  G-P0-1 (build the target task portfolio)
    → P-24 (descriptor space B)
      → P-25/P-26/P-27 (niche granularity, archive, selection weights)
      → P-06/P-07 (family disjointness)
    → P-30/P-31 (rotation period, exposure budget — requires measured T_adapt)
    → sim_fidelity baseline (requires the real-world suite, INV-43)

  ⟹ **G-P0-1 is the single highest-leverage action. It unblocks 7 of the 9
     unresolved parameters and is a prerequisite for ME-4, ME-5, MO-3 and
     the whole of Stage III (§56.3).**

EXTERNAL, NON-AUTOMATABLE INPUTS (from CD-6 and CD-8):
  1. Funded real-world evaluation (permanent operating cost, §34.4)
  2. Human constitutional authority (permanent governance cost, §42.1 L2)
  ⟹ **Neither is optional. Neither is automatable. A project plan that
     omits either will produce an internally coherent system detached
     from reality and unaccountable to anyone.**
```

## 59.5 OUTPUT 17 — P0 / P1 / P2 GAP REGISTER

### **P0 — blocks a working, honest evaluation system**

| ID | Gap | Why P0 | Blocking | Resolution path |
|---|---|---|---|---|
| **G-P0-1** | **The target task portfolio does not exist.** No concrete tasks, no families, no descriptor space `B` | Everything downstream is unparameterizable: P-24…P-27, P-06/P-07, ME-4/ME-5, Stage III | 7 of 9 `[U]` params | **Build a minimal portfolio (§48–50 gives the 21 minimum tasks) for ONE declared application domain. Do not attempt generality first** |
| **G-P0-2** | **`θ_abstain` semantics unresolved** (Cell Contract U-1) | MC-3 (the abstention task) cannot be specified; abstention correctness is unmeasurable; A1 undefended | MC-3, A1, the brief's named P0-01 dependency | Define abstention as a scored action with a `coverage` objective (A1's defence) and derive the threshold from the OOD/ID score distributions — **requires G-P0-1's tasks to exist** |
| **G-P0-3** | **Real-world evaluation is unfunded in the current plan** (INV-43, CD-8, §34.4) | Without it, CD-8 closes completely and fitness is detached from ℛ with **no internal signal detectable** (AB-22) | All L2 claims; MO-3; `sim_fidelity` | Fund β₅ at a level sufficient for statistically meaningful `sim_fidelity` per family per quarter (§34.4). **If it cannot be funded, do not claim real-world capability** |
| **G-P0-4** | **Evaluator does not exist** — no implementation, no `n_eval ≥ 3` independent versions, no canary suite | INV-01/INV-05 unenforceable; every fitness record is unsigned and therefore inadmissible | Everything | Build EVA off-substrate; author ≥ 3 independent metric implementations; seed the canary suite from §52's attacks |
| **G-P0-5** | **Human constitutional authority (OP) is not constituted** — no named principal, no separation-of-duties matrix (P-43), no dual-authorization procedure (P-44) | CD-6 is unclosable without it; §31.4's constraint-improvement path has no endpoint; C6 human-channel leakage undefended | INV-04, R42.5, §43.2 | Name the principals; publish the separation-of-duties matrix; establish the constitutional-change procedure **before the first evolutionary campaign** |
| **G-P0-6** | **`ood_score` unresolved** (Cell Contract U-10) | Drift detector D2 (§21.2) is inoperative; A12 and MC-3 weakened | §21.2 D2, MC-3 | Define via the evidence ladder's corroboration statistic (§6.3 E1) as an interim instrument; mark as interim |

### **P1 — blocks trustworthy operation, not first operation**

| ID | Gap | Why P1 | Resolution path |
|---|---|---|---|
| **G-P1-1** | **Tiered archival policy for append-only stores** (F-IMP-3): provenance, failure memory, GT records grow unboundedly | Infeasible on P-CLASS-A within months | Digest-tiering policy preserving hash-chain verifiability; **[U]** parameter |
| **G-P1-2** | **`T_adapt` unmeasured** ⇒ `T_rotate` (P-30) and exposure budget (P-31) unsettable | A23 lineage leakage bound is unquantified | Run AB-11 (remove rotation) on a campaign and measure the adaptation timescale directly |
| **G-P1-3** | **Power analyses not performed** ⇒ 25 `[X]` parameters have no values | `n_min`, `θ_dom`, `θ_jump`, `θ_gap_hard` etc. are unusable | Execute the specified derivations (§54); this is straightforward work, not research |
| **G-P1-4** | **Metric estimator specifications absent** (INV-25 requires estimator + sample policy + CI for every metric) | Metrics are currently named, not specified; A6 undefended | Write the estimator spec for each tier-2 objective; conformance-test each (§16.4) |
| **G-P1-5** | **Physical sensor-integrity specification out of scope** (A12 residual: MEDIUM-HIGH in deployment) | Physical deployments have an unaddressed threat class | Hand off to a dedicated physical-security specification; **do not pretend this contract covers it** |
| **G-P1-6** | **Deployment Stages 4–7 require production infrastructure that does not exist** (F-IMP-2, §56.1) | No shadow, canary, or progressive rollout capability ⇒ MO-8 untestable | Organizational build; Stage 4 is mandatory for any simulation-selected candidate (R32.2) |
| **G-P1-7** | **Evaluator-dispute adjudication procedure undefined beyond "escalate to OP"** (R42.3) | DISPUTED states will occur and have no resolution path | Define the adjudication procedure: evidence standard, timeline, and the rule that the disputed subject stays suspended throughout |

### **P2 — refinements, robustness, scale**

| ID | Gap | Why P2 | Resolution path |
|---|---|---|---|
| **G-P2-1** | M4 Shapley restricted to n ≤ ~12 (§24.2); larger circuits get sampled M3 only | Cooperation credit is approximate for big circuits | Approximate Shapley (permutation sampling) with declared error bounds |
| **G-P2-2** | Three available minimality reductions not applied (§55.2) | Slight excess surface | Apply only if implementation cost forces it; reduction 3 is **not recommended** |
| **G-P2-3** | `ε_floor` per-source measurement procedure not standardized across GT sources | INV-17 comparability varies by source | Standardize the repeatability protocol per source class |
| **G-P2-4** | Cross-profile evolutionary transfer unresolved (Cell Contract U-9, §30.2 `[U]`) | May be unanswerable | Investigate empirically once G-P0-1 exists; **be prepared for a negative result** |
| **G-P2-5** | Canary suite authorship process undefined beyond "grows from the failure archive" | P-40 refresh rate unenforced | Define authorship, review, and refresh as an EVA-owned process |
| **G-P2-6** | Multi-stakeholder usefulness (L2(d), §59.1) — the stakeholder set is an OP choice with no defined procedure | Usefulness claims are OP-relative without disclosure | Require the stakeholder set to be declared in every L2 claim |
| **G-P2-7** | `RETRACTION` (§39) semantics for already-published external claims | Published results cannot be retracted by versioning alone | Define the external-correction procedure alongside R42.6 |

### **Gap register summary**

```
P0 : 6   — 2 are "build the thing" (G-P0-1 portfolio, G-P0-4 evaluator)
            2 are "fund/staff the thing" (G-P0-3 real-world anchor, G-P0-5 OP)
            2 are inherited from the Cell Contract (G-P0-2 θ_abstain, G-P0-6 ood_score)
P1 : 7   — mostly straightforward engineering work with no research content
P2 : 7   — refinements; 1 possibly unanswerable (G-P2-4)

THE CRITICAL OBSERVATION: **4 of the 6 P0 gaps are not specification gaps.**
G-P0-1, G-P0-3, G-P0-4 and G-P0-5 are gaps in BUILDING, FUNDING and STAFFING.
The specification is now sufficient to proceed. **Further specification work
has diminishing returns; the binding constraints are a task portfolio, an
evaluator implementation, a real-world evaluation budget, and a named human
authority.** Saying this plainly is more useful than producing another
specification volume (Rules 17 and 18).
```

---

*End of Volume C. The canonical, self-contained contract is `10_v4_task_environment_fitness_spec.md` (**Output 18**). Outputs 1–10 and 14 are in `README.md`.*
