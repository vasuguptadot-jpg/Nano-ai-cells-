# P0-01 — TASK, ENVIRONMENT & FITNESS CONTRACT
## Volume B: Evaluation, Credit, Fitness Economics & Adversarial Robustness (§16–§35)

**Companions:** `07_analysis_foundations.md` (Volume A) · `09_analysis_adversarial.md` (Volume C) · `10_v4_task_environment_fitness_spec.md` (canonical)

---

# 16. GOODHART / REWARD HACKING / SPECIFICATION GAMING

**The task instruction is explicit: do NOT claim Goodhart's law can be completely solved.** It cannot. What follows is a cost-raising and detection strategy, with residual risk stated honestly for each.

**The structural premise (from §10.3), which does more work than any detector:** *the Pareto front is retained, never scalarized.* A single number is a single target. A front is a set, and gaming a set requires gaming every axis simultaneously while remaining feasible — which is dramatically harder. **This is the primary defense and it is architectural, not detective.**

| # | Attack | Mechanism | Detection | Mitigation | **Residual risk** |
|---|---|---|---|---|---|
| **16.1** | **Reward hacking** | Find a causal pathway to the reward signal that bypasses the intended task | **Jump detection:** `|Δperformance| > θ_jump` ⇒ audit before permanence. **Ablation delta:** a hack usually produces no real contribution to dependents (§24). Cross-environment reproducibility | Reward is EVA-signed only (R12.1); reward is a vector, never scalar (R12.2); dense reward prohibited (R12.4); reward requires `gt_id` evidence (R12.3) | **HIGH — fundamental.** Any measurable proxy is gameable by a sufficiently capable optimizer |
| **16.2** | **Specification gaming** | Satisfy the *letter* of `success_conditions` while violating the intent | **Falsification-condition testing:** every task MUST declare what counts as failure (§3.1); a candidate that passes success but trips falsification is flagged. Human review of large jumps | Falsification conditions are authored *adversarially* at task-publication time, by a different author than the success conditions | **HIGH — fundamental.** Intent is not fully formalizable; the gap between `success_conditions` and intent is permanent |
| **16.3** | **Proxy optimization** | Optimize a tier-2 objective that correlates with, but is not, the real goal | Generalization gap monitoring; **`success_is_sufficient_for` scope check** — a claim beyond the licensed scope is rejected at publication, not at runtime | The objective vector is EVA-owned and unreachable; tier-3 preferences cannot be traded against tier-2 | **HIGH.** Correlation is all a proxy ever has |
| **16.4** | **Metric gaming** | Exploit the *measurement* of a metric: edge cases, denominator manipulation, rounding, sampling artifacts | Metric-implementation conformance tests (§57); **evaluator diversity** — independent implementations of the same metric must agree (§32); anomalous metric distributions | Metrics are specified with their estimator, sample-size policy, and confidence interval — **a metric without a CI is inadmissible** | **MEDIUM.** Diverse independent implementations raise the cost substantially |
| **16.5** | **Evaluator exploitation** | Discover and exploit an evaluator bug or blind spot | Evaluator self-test suite run continuously; **canary candidates** with known-bad behaviour must be scored badly (§32) — an evaluator that passes a known-bad candidate is broken | Evaluator is off-substrate (R15.2), signed, versioned, unreachable by mutation (R15.5); multiple independent evaluators | **MEDIUM.** Evaluator bugs are ordinary software bugs and will exist |
| **16.6** | **Sensor manipulation** | Alter the observation channel so the organism appears to succeed | Sensor integrity monitoring; **cross-sensor corroboration** (evidence ladder §6.3 E1); observation provenance anchored; `sensor_reliability` drift monitoring | Sensors are EVA/EXT-owned; the organism has **no write path** to the sensor stack. Physical tampering is an EXT-level threat outside this contract's scope | **LOW within simulation; MEDIUM-HIGH for physical deployments** — where sensor tampering is a real-world security problem this contract can only *detect*, not prevent |
| **16.7** | **Benchmark overfitting** | Memorize or specialize to the evaluation distribution | **Held-out gap** (train vs. `HIDDEN_TEST`); **suite rotation** (§45); generalization-gap as a tier-2 objective; leakage-class enforcement (§3.1) | Sealed `HIDDEN_TEST` tasks the organism cannot know exist; rotated; cryptographically hidden seeds | **MEDIUM-HIGH.** §45 shows that across many generations the *distribution* leaks even when instances do not |
| **16.8** | **Simulator exploitation** | Find a `Σ` behavior that does not exist in `ℰ` or `ℛ` and farm it | **Simulator conformance tests** against `ℰ`; **`sim_fidelity` measurement** (§33) — does simulator performance predict real performance?; domain randomization | A simulator with unmeasured fidelity MUST NOT be used for evolutionary selection (R4.4); production-holdout environments never used in selection | **MEDIUM.** Fidelity measurement bounds but does not eliminate the gap |
| **16.9** | **Delayed-harm strategy** | Score well inside the evaluation window; cause harm after it | **`credit_horizon` must exceed the harm horizon** — a task whose harm horizon is longer than its credit horizon is **inadmissible** and must declare that it does not assess long-term consequences (§11.1). Long-window re-evaluation; post-deployment monitoring | Extended-horizon evaluation on a sampled basis; deployment canary with long observation | **HIGH.** Harm beyond any feasible evaluation horizon is structurally invisible. **This is the strongest argument for keeping human authority over the envelope** |

## 16.10 The honest conclusion on Goodhart

> **Goodhart's law is not solvable. It is *manageable*, by four means, in order of effectiveness:**
> 1. **Structural** — retain the Pareto front; never scalarize; make constraints a feasibility gate so there is no number to trade (§10.3, R14.1).
> 2. **Constitutional** — the objective, constraints, tasks, and evaluator are signed, versioned, off-substrate, and unreachable by mutation (R15.5).
> 3. **Detective** — jump detection, ablation delta, held-out gaps, evaluator diversity, canary known-bad candidates, fidelity measurement.
> 4. **Human** — review of large fitness jumps, authority over the envelope, and post-deployment monitoring for delayed harm.
>
> **What cannot be done:** guaranteeing that the measured objective equals the intended objective. §59 makes this precise: the evaluator measures **L1**; intent lives at **L2** and above; **no formal apparatus closes that gap.**

---

# 17. GENERALIZATION

## 17.1 The seven task roles (normative)

| Role | Purpose | Organism visibility | Used for learning? | Used for selection? | Used for claims? |
|---|---|---|---|---|---|
| **TRAIN** | Acquire capability | Full (`OPEN`) | ✅ | ❌ **never** | ❌ |
| **DEV** | Tune hyperparameters, architecture search | Full (`OPEN`) | ⚠️ limited | ❌ | ❌ |
| **VALIDATION** | Early generalization signal | `REGISTERED` (exists, content hidden) | ❌ | ⚠️ **only for provisional ranking** | ❌ |
| **HIDDEN_TEST** | The real generalization measure | **`SEALED` — the organism MUST NOT know it exists** | ❌ | ✅ **authoritative** | ✅ |
| **OOD** | Out-of-distribution behaviour; abstention correctness | `REGISTERED` | ❌ | ✅ for the robustness objective | ✅ scoped |
| **ADVERSARIAL** | Behaviour under declared attack (§5.4) | `REGISTERED` | ❌ | ✅ for the robustness objective | ✅ scoped |
| **NOVEL** | Never-before-seen task families; transfer | **`SEALED`** | ❌ | ✅ for adaptability | ✅ scoped |
| **REFERENCE** | Frozen baseline for drift detection | `OPEN` | ❌ | ❌ | ✅ for comparability over time |

## 17.2 How learning and evolution interact with each role

```
LEARNING (lifetime, Cell Contract §8):
  TRAIN      → drives T1 prediction-error learning freely
  DEV        → drives learning with reduced plasticity (avoid tuning-in)
  VALIDATION → NO learning. Read-only measurement.
  HIDDEN_TEST→ NO learning, NO measurement the organism can observe
  OOD/ADV    → NO learning; triggers SLOW_MODE (Cell Contract T5), which
               REDUCES plasticity rather than increasing it
  NOVEL      → NO learning

EVOLUTION (generational, Cell Contract §12):
  TRAIN      → variation is MOTIVATED by training experience (the Baldwinian
               bridge, Cell Contract §M.2 — with the abstraction step)
  DEV        → architecture/parameter-distribution search
  VALIDATION → provisional gate filtering (cheap surrogate before expensive test)
  HIDDEN_TEST→ **AUTHORITATIVE SELECTION GATE.** Results are NOT returned to
               the organism, NOT stored where the organism can read them, and
               NOT used to motivate variation.
  OOD/ADV    → G4 robustness gate (≥ k perturbation classes)
  NOVEL      → G4 adaptability gate
  REFERENCE  → drift detection (§46, audit E6)
```

**R17.1 (THE ANTI-EVALUATOR-SPECIALIZATION RULE).** *No signal derived from a `HIDDEN_TEST`, `NOVEL`, or `REFERENCE` task may flow back into any process that motivates variation, shapes learning, or is readable by the organism.* This is the formal statement of «prevent the organism evolving specifically for the evaluator.»

**Why R17.1 is hard to enforce and how:** the leak is not usually direct. It flows through *human* channels (a researcher sees a hidden-test result and adjusts the training suite) and through *lineage* channels (§45: selection on hidden tests shapes which genomes persist, and the persisted genomes encode the hidden-test distribution indirectly). **Direct leakage is closed by access control. Indirect leakage is bounded, not closed** — see §45.3 for the honest treatment.

## 17.3 The generalization gap as a first-class objective

```
gen_gap(subject) = performance(TRAIN ∪ DEV) − performance(HIDDEN_TEST ∪ NOVEL)
```
- `gen_gap` is a **tier-2 soft objective** (§10.4), not merely a diagnostic. **A candidate with high performance and high `gen_gap` is Pareto-dominated by one with slightly lower performance and low `gen_gap`** — which is exactly the selection pressure that prevents benchmark specialization.
- `gen_gap > θ_gap_hard` ⇒ **tier-1 infeasibility**. Overfitting beyond a hard bound is not a trade-off; it is disqualification.
- `gen_gap` is measured per task family, so specialization to one family is visible even when the aggregate looks fine.

---

# 18. TASK DISTRIBUTION

## 18.1 The seven options, analyzed

| Option | Advantages | **Failure modes** | Verdict for V4 |
|---|---|---|---|
| **One task** | Simple; cheap; unambiguous | **Catastrophic overfitting; no generality claim possible; evolution collapses to one niche; a single task bug invalidates everything** | ❌ Rejected |
| **Multiple fixed tasks** | Comparable; reusable; cheap | **Memorizable across generations (§45); no novelty pressure; the fixed set defines the capability ceiling** | ⚠️ Necessary but insufficient |
| **A task distribution** | Generality is meaningful; anti-memorization; supports QD search | **Distribution specification is itself a design choice that can be wrong; sampling variance; cost** | ✅ **Adopted as the primary frame** |
| **Continually changing tasks** | Tests adaptability; realistic | **Non-comparability over time; catastrophic forgetting pressure; no stable baseline** | ⚠️ Adopted as a *component* (§21 nonstationarity), not the whole |
| **Procedurally generated tasks** | Unbounded novelty; cheap; anti-memorization | **§19: the generator becomes the target; trivial tasks create false progress; validity is not guaranteed** | ✅ Adopted, with the §19 controls |
| **Real-world environments** | The only source of L2 truth and L2 usefulness (§59) | **Expensive; slow; unsafe; irreproducible; ground truth often L4/L6 only** | ⚠️ Adopted as a *small, sampled* component (§34) |
| **Hybrid** | Combines the above | **Complexity; the mixing policy itself becomes a design target** | ✅ **SELECTED** |

## 18.2 The V4 task-distribution architecture

```
TASK PORTFOLIO (Level 3, §2.3)
│
├── CORE SUITE (fixed, frozen, comparable)              ~40% of budget
│   ├── REFERENCE tasks — never rotated; drift baseline
│   └── VALIDATION tasks — stable generalization signal
│   PURPOSE: comparability over time. Without a frozen core,
│            you cannot tell improvement from task drift.
│
├── ROTATING SUITE (versioned, periodically replaced)   ~30%
│   ├── TRAIN / DEV tasks
│   └── HIDDEN_TEST tasks — rotated on a schedule (§45)
│   PURPOSE: anti-memorization while retaining measurability
│
├── GENERATED SUITE (procedural, §19)                   ~20%
│   ├── NOVEL task families
│   └── ADVERSARIAL / OOD instances
│   PURPOSE: unbounded novelty pressure; QD archive filling
│
└── REAL-WORLD SUITE (sampled, expensive, §34)          ~10%
    └── L2 physical measurement, L4 human annotation, L6 outcomes
    PURPOSE: the ONLY component that touches ℛ. Anchors everything
             else. Without it, the entire portfolio is self-referential
             at one remove.

MIXING POLICY: signed, versioned, EVA-owned. NOT organism-modifiable.
               The mixing weights are themselves a Goodhart target and
               are therefore a constitutional artifact (§11.3).
```

**R18.1** The **REAL-WORLD SUITE MUST be non-empty.** A portfolio consisting only of simulators and generated tasks can be internally coherent and entirely detached from `ℛ`. Its budget share is small (it is expensive) but it MUST be nonzero, and its results MUST be the anchor against which `sim_fidelity` (§33) is measured.

**R18.2** The **CORE SUITE MUST be frozen.** Improvement claims over time are meaningless without a fixed reference. This is the environment-layer instance of the audit's §T.2 slow-degradation defense.

---

# 19. TASK GENERATION

## 19.1 `TaskGenerator` — normative

```
TaskGenerator {
  generator_id      : bytes<16>
  version           : u32                     // signed, EVA-owned
  signature         : bytes<64>
  family_spec       : FamilySpec              // what kind of tasks
  parameter_space   : {dims: [ParamSpec], bounds, distributions}
  seed_policy       : {seed_class: enum{EVA_ISSUED, DERIVED_SIGNED},
                       seed_disclosure: HIDDEN,      // ⟵ MANDATORY for HIDDEN_TEST
                       derivation: HKDF(master, generator_version, index)}
  validity_predicate: ValidityPred            // ⟵ MANDATORY, decidable
  difficulty_control: {target_distribution, absolute_measure (§19.4),
                       feedback_source: enum{REFERENCE_POPULATION, NONE}}
  novelty_measure   : {descriptor_space, distance_metric, archive_ref}
  duplicate_detect  : {canonical_form_hash, near_duplicate_threshold}
  leakage_controls  : {no_train_overlap: bool, family_disjointness: f32,
                       instance_hash_sealed: bool}
  adversarial_mode  : ⟨null | {threat_model, budget}>
}
```

## 19.2 Validity — a generated task is not a task until validated

**R19.1** Every generated task MUST pass `validity_predicate` before use:
1. **Well-formed:** all TypeRefs resolve; all schemas valid; horizon finite or explicitly unbounded; `credit_horizon` declared.
2. **Solvable:** a **reference solver** (independent of the organism) achieves `success_rate ≥ θ_solvable`. **A task no reference solver can solve is not hard, it is broken.**
3. **Discriminative:** the reference population's success-rate variance exceeds `θ_discrim`. **A task every candidate passes or every candidate fails carries no selection information** and wastes evaluation budget.
4. **Falsifiable:** `FALSIFICATION` is non-empty (§3.1).
5. **Ground-truth provisioned:** `ground_truth.source_classes` is non-empty and achievable at declared cost.
6. **Resource-bounded:** `resource_limits` are satisfiable on the target hardware profile class.
7. **Non-duplicate:** canonical-form hash not in the registry; near-duplicate distance above threshold.
8. **`ω ≥ ω_min`:** observability fraction above the solvability floor (§5.3).

**Tasks failing validity are discarded and logged — they are never silently repaired,** because silent repair makes the generator's output distribution unknowable.

## 19.3 «Who evaluates the task generator?»

> **This is the question that decides whether generated tasks produce real progress or false progress.**

**The generator MUST be evaluated by an independent Generator Validation Authority (GVA), off-substrate, using four criteria:**

| Criterion | Measure | Failure it detects |
|---|---|---|
| **Validity rate** | Fraction of generated tasks passing R19.1 | A generator producing mostly invalid tasks wastes budget and biases the distribution toward whatever is easy to make valid |
| **Difficulty calibration** | Correlation between the generator's *declared* difficulty and the *measured* difficulty on a reference population | **A generator that produces trivially easy tasks while declaring them hard creates false evolutionary progress** — the exact failure the task prompt identifies |
| **Discrimination** | Mean selection information (variance of candidate scores) per generated task | A generator producing non-discriminative tasks yields noise-driven evolution |
| **Distribution fidelity** | Statistical distance between the generated distribution and the specified `family_spec` | A generator drifting from its spec silently changes what is being selected for |

**R19.2** The GVA MUST run a **reference population** that is *not* the evolving population, so difficulty measurement is not contaminated by the organism's own progress. **A generator calibrated against the population it feeds is a positive feedback loop** — as the population improves, "hard" tasks get easier, the generator makes harder ones, and the measured progress is partly an artifact of the calibration loop.

**R19.3** Generator versions are signed and frozen. **A generator MUST NOT be modifiable by the organism or by evolution** (R15.5 extended).

## 19.4 Difficulty must have an organism-independent component

**[V4] This is the mechanism that breaks the curriculum circularity (§51 loop 3).**

```
difficulty.absolute  (ORGANISM-INDEPENDENT — computable a priori):
  complexity_class      : computational-complexity classification of the
                          reference solver's approach, where classifiable
  entropy_bits          : H(S_t) — environment state entropy
  action_space_size     : |𝒜| or the volume of the parameterized space
  observability_fraction: ω = H(S_obs)/H(S_t)             (§5.3)
  noise_level           : declared observation noise (§6.2)
  horizon               : max_steps
  credit_horizon        : max attribution delay
  nonstationarity_rate  : declared drift rate (§21)
  constraint_count      : |tier-1 constraints|

difficulty.measured  (ORGANISM-RELATIVE — filled in after calibration):
  success_rate_reference_population
  discrimination
  time_to_solve_distribution
```

**Why both are needed:** `absolute` allows a curriculum to be constructed *before* any organism exists (breaking circularity) and allows cross-project comparability. `measured` allows the curriculum to adapt (§20). **A curriculum using only `measured` difficulty is circular; one using only `absolute` difficulty is blind to the actual population.**

---

# 20. DIFFICULTY / CURRICULUM

## 20.1 Difficulty representation
Per §19.4: an **absolute** vector (organism-independent) and a **measured** vector (population-relative), with a declared mapping from absolute to a scalar difficulty index used only for ordering, never for scoring.

## 20.2 The five curriculum options

| Option | Mechanism | Advantage | **Failure mode** |
|---|---|---|---|
| **Static** | Fixed order, hand-authored | Reproducible; auditable | Cannot adapt; over-specializes to the authored order; wasted budget on trivial or impossible tasks |
| **Adaptive** | Difficulty tracks measured success rate | Efficient; keeps tasks in the informative band | **Trivial-task loop** if the difficulty measure is population-relative only (§19.4) |
| **Self-generated** | The organism proposes its own tasks | Cheap; open-ended | **CATASTROPHIC as the sole mechanism:** the organism proposes tasks it can solve, producing unbounded false progress. Permitted only as a *source of candidates* that the GVA validates |
| **Teacher-generated** | A separate teacher process proposes tasks | Can target weaknesses | The teacher becomes a Goodhart target; teacher–student collusion if same substrate |
| **Evolutionary** | Tasks co-evolve with the organism | Genuine open-endedness; arms race | **Co-evolutionary collapse** (tasks become trivially easy or impossibly hard); **non-comparability over time**; requires its own fitness function for tasks |

## 20.3 The V4 curriculum model

> **[V4] Adaptive curriculum with absolute-difficulty anchoring, GVA-validated generation, and a frozen reference track.**

```
THREE PARALLEL TRACKS (never merged):

TRACK A — FROZEN REFERENCE (no curriculum)
  Fixed tasks at fixed difficulty, never adapted.
  PURPOSE: the only source of comparable-over-time progress claims.
  Without this, every improvement claim is confounded with curriculum change.

TRACK B — ADAPTIVE CURRICULUM
  Task selection targets the INFORMATIVE BAND:
     success_rate ∈ [θ_band_lo, θ_band_hi]   (e.g. neither ~0 nor ~1)
  anchored to difficulty.absolute so the band moves in a MEASURABLE direction
  over time (the claim "the curriculum got harder" must be verifiable
  against absolute difficulty, not against the population's own success rate).

TRACK C — OPEN-ENDED GENERATION (GVA-validated)
  Generated tasks (§19), including organism-proposed CANDIDATES that pass
  GVA validation. Feeds the QD archive (§26).
```

## 20.4 The five curriculum failure modes and their prevention

| Failure | Mechanism | **Prevention** |
|---|---|---|
| **Trivial-task loop** | Adaptive difficulty chases the population down; easy tasks are declared progress | **Absolute-difficulty anchoring (§19.4)** — the curriculum's difficulty trajectory is measured in organism-independent units, so "getting easier" is visible. **Track A frozen reference** detects it independently |
| **Impossible-task starvation** | All tasks above capability; no learning signal; budget burned | Informative-band targeting with `θ_band_lo > 0`; **R20.1:** if the fraction of tasks in the informative band falls below `θ_band_frac`, the curriculum MUST widen rather than persist |
| **Over-specialization** | The curriculum narrows toward what the organism already does well | **Diversity requirement on the curriculum itself**: task-family entropy of the selected stream MUST stay above `θ_family_entropy`. **A curriculum is a distribution and its entropy is monitored like any other** |
| **Curriculum collapse** | The adaptive process degenerates (e.g., all tasks become one family) | Family-entropy floor; Track A and Track C are independent of the adaptive process; curriculum state is versioned and rollback-able |
| **Reward hacking via the curriculum** | The organism influences which tasks are selected | **R20.2: the organism MUST NOT write to curriculum state.** It may emit `REQUEST_ATTENTION` for a task family; the curriculum service decides. Selection is EVA/ORG-owned |

---

# 21. TASK NON-STATIONARITY

## 21.1 The five change classes

| Class | Definition | `DriftSpec` representation | Detectable by |
|---|---|---|---|
| **STATIONARY** | `T`, `Z`, objective, and GT distribution constant | `kind = NONE` | n/a |
| **DRIFTING** | Slow continuous change in `T`, `Z`, or the outcome distribution | `kind = GRADUAL, rate, direction, affected_components` | Change-point detection on performance and on input statistics |
| **SUDDEN CHANGE** | Discrete switch at a known or unknown step | `kind = ABRUPT, switch_points (may be HIDDEN)` | Abrupt performance drop; input-distribution shift |
| **ADVERSARIAL CHANGE** | Change driven by an adversary reacting to the organism | `kind = ADVERSARIAL, threat_model, budget` (§5.4) | Requires a declared threat model; otherwise uninterpretable |
| **HIDDEN RULE CHANGE** | The *objective* or *legality predicate* changes without notification | `kind = CONCEALED, concealment_policy` | **Only by sustained prediction error without parameter drift** — Cell Contract error class 10 |

**R21.1** A task with nonstationarity MUST declare its `DriftSpec`. **An undeclared drift makes results uninterpretable**: poor performance could mean a weak organism or an unannounced change, and there is no way to distinguish them.

**R21.2** `CONCEALED` drift is permitted **only** in tasks whose explicit purpose is to test drift detection, and those tasks MUST be role-tagged `OOD` or `ADVERSARIAL`. Concealed drift in a `TRAIN` task is a curriculum defect.

## 21.2 Detection, and the connections to existing subsystems

```
DETECTION (three independent signals, all required):
  D1 SUSTAINED PREDICTION ERROR without parameter drift
     ⟶ Cell Contract error class 10 (model/environment mismatch).
       This is the PRIMARY detector: the cell already produces the signal.
  D2 INPUT-DISTRIBUTION SHIFT
     ⟶ ObservationSpec statistics vs. a stored reference distribution.
       Requires `ood_score` (Cell Contract U-10, currently unresolved).
  D3 PERFORMANCE CHANGE-POINT on the FROZEN REFERENCE track (§20.3 Track A)
     ⟶ The only detector that is independent of the organism's own model.
       **This is why Track A must exist.**

CONNECTIONS:
  novelty detection  → D2 feeds it; Cell Contract T5 trigger fires
  uncertainty        → epistemic_var RISES under drift (correctly: the model
                       no longer fits). If it does not rise, the uncertainty
                       model is broken — this is a testable property (§57)
  attention          → drift raises salience of the affected task family;
                       attention controller reallocates
  plasticity         → Cell Contract T5: SLOW_MODE. **Plasticity is REDUCED,
                       not increased** (R8.1 of the Cell Contract). Adapting
                       aggressively to a detected shift is how a system
                       overwrites good knowledge with noise
  memory             → pre-drift knowledge is CONSOLIDATED and PROTECTED
                       before adaptation, so it survives; post-drift knowledge
                       is provisional until confirmed
  evolution          → sustained drift across epochs is a signal to increase
                       variation rate and re-open closed niches; **drift is
                       the environment's contribution to anti-monoculture**
```

**R21.3 (THE PLASTICITY DIRECTION RULE).** On drift detection, plasticity MUST decrease and evidence gathering MUST increase. **This is counterintuitive and it is correct:** a system that adapts fast to an unconfirmed shift will have adapted to noise by the time the shift is confirmed. V3 §14's "slow mode" states this correctly and V4 preserves it.

---

# 22. TEMPORAL CREDIT ASSIGNMENT

## 22.1 The problem
`A_t → consequence at t+1000`. Which decisions contributed? **V3/V3.1 has no mechanism.** The Cell Contract supplies eligibility traces at cell level (bounded by `λ` decay), which handles delays up to ~`1/λ` steps — **not 1000**.

## 22.2 The four methods, analyzed

| Method | Mechanism | Cost | Handles delay | Handles **multi-agent** | Verdict |
|---|---|---|---|---|---|
| **Temporal difference** | Bootstrap value estimates: `δ_t = r_t + γV(s_{t+1}) − V(s_t)` | **Low** — O(1) per step | ✅ arbitrarily, via bootstrapping | ❌ assigns to *states*, not to *agents* | ✅ **Adopted as the primary dense mechanism** |
| **Causal attribution (counterfactual ablation)** | Remove/alter a decision; re-run; measure outcome change | **Very high** — O(n × episode cost) | ✅ exactly | ✅ **the only method that does** | ✅ **Adopted for fitness and gates, sampled** |
| **Episodic replay** | Re-experience stored trajectories with hindsight | Medium | ✅ within memory bounds | ⚠️ partial | ✅ Adopted for consolidation |
| **Delayed ground truth** | Wait for the L6 outcome, then attribute | **Low compute, high latency** | ✅ | ⚠️ requires attribution on top | ✅ Adopted — this is what makes GT economics work (§34) |

## 22.3 The V4 credit-assignment architecture — three tiers

```
TIER 1 — DENSE, CHEAP, LOCAL (every step)
  Eligibility traces (Cell Contract §8.5) + TD error.
  Horizon: ~1/λ steps (tens).
  Purpose: fast local adaptation.
  Status: PROVISIONAL. Drives rate-limited, rollback-tagged learning only.

TIER 2 — EPISODIC, MEDIUM (per episode or window)
  Episode-boundary attribution using stored traces + TD returns.
  Horizon: up to `credit_horizon`.
  Purpose: consolidation, calibration scoring.
  Status: CONFIRMED if GT-admissible (§9.1 states 0/1/8).

TIER 3 — CAUSAL, EXPENSIVE, SAMPLED (§36)
  Counterfactual ablation: remove a cell / circuit / decision; re-run;
  measure the tier-2 objective delta.
  Horizon: unlimited.
  Purpose: FITNESS (cooperation, ecological usefulness), replication gates
           G3 and G7, pruning decisions, attribution of failure.
  Status: AUTHORITATIVE.
  Cost: O(n_subjects × episode_cost) — therefore SAMPLED, never exhaustive.
```

**R22.1** **`credit_horizon` is mandatory per task** (§3.1). An outcome arriving later than `credit_horizon` is recorded as `UNATTRIBUTABLE` (R12.5) — **not** attributed to the nearest action, and **not** silently dropped.

**R22.2** Tier-1 credit MUST NOT drive permanent learning or fitness. Only tier-2 and tier-3 may (matching Cell Contract R13.1: internal estimate ≠ external demonstration).

**R22.3** Where the true causal structure is unknown and cannot be ablated (e.g., real-world deployment, §18.2 REAL-WORLD SUITE), credit assignment is **declared `CORRELATIONAL`** and the resulting fitness carries elevated uncertainty. **Pretending correlation is causation is the specific error this rule prevents.**

---

# 23. CAUSALITY VS CORRELATION

## 23.1 The distinction, operationalized

```
CORRELATION:      performance metric improved while component C was present.
CAUSAL CONTRIBUTION: performance metric changes when C is intervened upon,
                     holding other factors fixed.

The gap between them is confounding: C may co-occur with the real cause.
```

**The only mechanism in this contract that establishes causal contribution is intervention — specifically counterfactual ablation (Tier 3, §22.3).** Everything cheaper is correlational, and must be labelled as such.

## 23.2 Where causal attribution is REQUIRED vs. where correlation suffices

| Use | Attribution requirement | Rationale |
|---|---|---|
| **Learning** (per-step parameter update) | **NONE / CORRELATIONAL** | Requiring causal attribution for every learning step is O(n×episode) per step — infeasible. Eligibility traces + TD are correlational and that is acceptable *because the updates are provisional, rate-limited, and rollback-able* (R22.2) |
| **Prediction-error scoring** | **NONE** | The error is directly measured; no attribution needed |
| **Calibration scoring** | **NONE** | Directly measured against GT |
| **Fitness — task performance** | **NONE** | Directly measured |
| **Fitness — COOPERATION** | **CAUSAL REQUIRED** | "Did this cell help its partners?" is a causal question by definition. Ablation delta is the only admissible measure |
| **Fitness — ECOLOGICAL USEFULNESS** | **CAUSAL REQUIRED** | Same |
| **Replication gate G3 (usefulness)** | **CAUSAL REQUIRED** | Cell Contract G3 is defined as an ablation delta |
| **Replication gate G7 (cooperation)** | **CAUSAL REQUIRED** | Same |
| **Pruning / retirement decisions** | **CAUSAL REQUIRED** | Deleting a component on correlational evidence is how rare specialists die (§37, Cell Contract §17.6) |
| **Evolution — candidate selection** | **CAUSAL for the fitness components that require it**; correlational elsewhere | Mixed, by component |
| **Error attribution (blame)** | **CAUSAL REQUIRED** | Cell Contract §10.4: attribution before credit. **Correlational blame punishes innocent components** |
| **Failure diagnosis / repair** | **CAUSAL REQUIRED** | Repairing the wrong component leaves the fault in place |
| **Drift detection** | **CORRELATIONAL sufficient** | Detecting *that* something changed does not require knowing *what caused* it |
| **Attention allocation** | **NONE** | Heuristic is acceptable; attention is recoverable |

**R23.1** Every `FitnessRecord.objectives[i].measurement_method` MUST declare its `attribution_class ∈ {NONE, CORRELATIONAL, CAUSAL}`. **A fitness component that requires CAUSAL attribution but was measured CORRELATIONALLY is inadmissible** and MUST be reported as `UNKNOWN`, not as an estimate.

**R23.2** The proportion of the evaluation budget spent on causal attribution is a **declared, versioned policy** (§35). It is the single most expensive line item in the evaluation system, and it cannot be eliminated — only sampled.

---

# 24. MULTI-CELL CREDIT ASSIGNMENT

## 24.1 «How does the organism decide which cells/circuits contributed?»

**The naive rule — «successful outcome → every participating cell gets reward» — is prohibited**, and the reason is decisive: it makes contribution indistinguishable from participation. Every cell in a successful circuit receives identical credit, so free riders are rewarded exactly like contributors, and **selection cannot distinguish them.** Over generations the population fills with cells that are merely *present*.

## 24.2 The four mechanisms, in ascending cost and authority

| Mechanism | What it measures | Cost | Authority |
|---|---|---|---|
| **M1 Contribution tracing** | Which cells were *active* on the causal path (from `causality` vector clocks + influence graph) | **Low** — data already produced | **CORRELATIONAL.** Establishes *participation*, not contribution |
| **M2 Credit propagation** | Distribute the outcome along the traced path, weighted by each cell's local prediction-error reduction | Low–medium | **CORRELATIONAL** |
| **M3 Counterfactual ablation** | Remove cell/circuit *i*; re-run; measure the tier-2 objective delta `Δ_i` | **HIGH** — O(n × episode) | **CAUSAL** |
| **M4 Shapley-style value** | Average marginal contribution over subsets | **PROHIBITIVE** — O(2ⁿ) | CAUSAL, exact |

**[V4] Adopted: M1 and M2 for dense provisional credit; M3 sampled for authoritative credit; M4 approximated only for small subject sets (n ≤ ~12) where exactness matters — e.g., deciding whether a *circuit* of 8 cells contributed.**

**R24.1** **Fitness components requiring causal attribution (§23.2) MUST use M3 or M4.** M1/M2 are inadmissible for cooperation, ecological usefulness, gates G3/G7, pruning, and blame.

**R24.2** **M3 sampling policy.** Exhaustive ablation is infeasible at scale. Sampling is:
- **Risk-weighted:** subjects whose removal would most change the outcome are ablated most often (estimated from M1/M2 first — cheap methods direct expensive ones).
- **Stratified:** every role, every region, every lineage gets a minimum ablation quota, so rare specialists are not systematically unmeasured (**this is also a §37 defense** — an unmeasured specialist looks useless).
- **Triggered:** mandatory ablation before any pruning/retirement decision, and before any replication gate G3/G7 evaluation.

## 24.3 Cooperative and delayed credit

| Case | Problem | Mechanism |
|---|---|---|
| **Cooperative credit** | Two cells jointly produce an outcome neither could alone. Individual ablation shows *both* are critical (`Δ_i` large for both) — which is correct, but naive normalization would double-count | **Joint ablation:** measure `Δ_{i,j}` and compare to `Δ_i + Δ_j`. **Superadditive** (`Δ_{i,j} > Δ_i + Δ_j`) ⇒ genuine complementarity ⇒ credit both fully and record the pair as a **circuit nucleation candidate** (Cell Contract §11). **Subadditive** ⇒ redundancy ⇒ credit fractionally |
| **Delayed credit** | Outcome at `t+1000`; contributions at `t`, `t+300`, `t+700` | §22.3 tiering: TD for dense, episode-boundary attribution for medium, ablation for authoritative. **`credit_horizon` bounds the search** (R22.1) |
| **Credit to the dead** | A cell contributed and was retired before the outcome arrived | The `Evaluation` record references the **lineage**, not only the cell. Credit accrues to `lineage_id` and informs gate G16 (lineage health). **A lineage is not penalized or rewarded for a member's death timing** |
| **Credit to the unmeasured** | A subject never sampled by M3 | Fitness components requiring causal attribution are reported `UNKNOWN` with elevated uncertainty (R23.1) — **never imputed from correlational data** |

**R24.3 (THE ANTI-FREE-RIDER PROPERTY).** A cell whose M1 participation is high but whose M3 ablation delta is ~0 is a **free rider**: present on the causal path, contributing nothing. This is *detectable* precisely because M1 and M3 are measured separately. **A system that measures only participation cannot detect free riders, and will evolve toward them** — participation is cheaper than contribution.

---

# 25. FITNESS AT MULTIPLE LEVELS

## 25.1 The seven levels

| Level | Subject | Primary objectives | Measurement basis | Interacts with |
|---|---|---|---|---|
| **CELL** | One cell | Calibration, prediction error, resource efficiency, stability | Direct metrics + M3 ablation | Lineage, circuit |
| **CELL LINEAGE** | A lineage across generations | **Drift**, heritability of performance, diversity contribution, cumulative safety record | Aggregated over members, weighted by recency | Cell, population |
| **POPULATION** | A set of cells sharing a role/region | Diversity (entropy, Ne), redundancy, correlated-failure resistance | Population statistics | Cell, functional population |
| **CIRCUIT** | A registered circuit | **Superadditivity** (`perf(circuit) > Σ perf(members)`), contract satisfaction, robustness to member loss | Circuit-level metric + member ablation | Cell, functional population |
| **FUNCTIONAL POPULATION** | A set of circuits sharing a capability | Capability-floor compliance, coverage, redundancy | Registry-linked | Circuit, region |
| **REGION** | A self-organized region | **Functional-contract satisfaction**, integration, resource efficiency, graceful degradation under member loss | Contract tests + region-level ablation | Functional population, organism |
| **ORGANISM** | The whole | **All tier-2 objectives**, task-suite performance, safety, recovery | Full evaluation | Everything |

## 25.2 How the levels interact — the precedence rule

> **[V4] R25.1 (ORGANISM-BOUNDS-COMPONENT).** A component's fitness is **undefined** if its behaviour violates an organism-level tier-1 constraint. Component-level excellence cannot compensate for organism-level infeasibility.

Formally:
```
FEASIBLE_component(x) ≡ FEASIBLE_organism(organism containing x)
                        ∧ FEASIBLE_local(x)

FITNESS_component(x) is defined only if FEASIBLE_component(x).
```

**This is the formal answer to «prevent a component being individually fit while damaging the organism.»** It is not a weighting; it is a **domain restriction**. A cell that improves its own calibration by flooding the network violates an organism-level resource constraint, so its fitness does not exist — there is no value to compare against anything.

## 25.3 Level conflicts and their resolution

| Conflict | Example | Resolution |
|---|---|---|
| Cell vs organism | A cell hoards budget to improve its own efficiency metric | R25.1: organism resource constraint ⇒ infeasible |
| Cell vs circuit | A cell specializes narrowly, improving itself but breaking circuit composition | **Circuit superadditivity is a circuit-level objective**; a cell reducing it is measured via M3 ablation and its cooperation objective drops |
| Circuit vs region | A circuit optimizes locally, degrading region contract satisfaction | Region contract tests are tier-1 for the region; R25.1 applies |
| Region vs organism | A region refuses to release cells to a needier region | Organism-level allocation is an ORG authority; non-compliance is a cooperation-objective failure at region level |
| Lineage vs population | A lineage expands, reducing population diversity | **G10 lineage-distance gate** and the diversity objective at population level (Cell Contract §12.3) |
| Short-term vs long-term at different levels | Cell-level fast gain, organism-level slow loss | **`valid_until` on fitness records (§27)** plus long-window organism evaluation |

## 25.4 Multi-level selection requires multi-level fitness — and this is why emergence is possible

**[V4] Note, connecting to audit §S.2.7:** a circuit that benefits the organism but not its constituent cells is **destroyed by cell-level selection alone**. Higher-level structure can only arise if higher-level fitness exists and can act. §25.1's seven levels are therefore not bureaucratic completeness — **they are the precondition for the emergence the architecture claims.** Without circuit-level and region-level fitness, V3 §23's "emergent result" cannot occur, because nothing selects for it.

---

# 26. MULTI-OBJECTIVE EVOLUTION — CONNECTING TO MAP-ELITES + PARETO

## 26.1 The components

| Component | Definition | Status |
|---|---|---|
| **Objective vector** | `f(x) = ⟨f₁…f_k⟩` over tier-2 objectives (§10.4), each with uncertainty | **Defined** — §14.2 |
| **Pareto dominance** | `x ≻ y iff FEASIBLE(x) ∧ FEASIBLE(y) ∧ (∀j: f_j(x) ≥ f_j(y)) ∧ (∃j: f_j(x) > f_j(y))` | **Defined** — §10.3 |
| **Behavioural descriptor space** | `B : subject → ℝ^d`, describing *what the subject does*, not how well | **Requires definition per task family — [U]** |
| **Niche** | A hypercube in `B`-space of side `θ_niche` | **Defined structurally; `θ_niche` requires calibration** |
| **Archive** | `{niche_id → best occupant(s)}` | **Defined** |
| **Selection** | Sample from the feasible Pareto front, weighted by (marginal utility × diversity contribution) | **Defined** — Cell Contract §12.4 |
| **Replacement** | A new occupant replaces an archive cell iff it dominates it, **or** the niche is empty | **Defined** |
| **Mutation evaluation** | Candidate evaluated on TRAIN/DEV → filtered by VALIDATION → gated by HIDDEN_TEST | **Defined** — §17.2 |

## 26.2 Why MAP-Elites and not hill-climbing

**Hill-climbing on a scalar produces monoculture** — one phenotype dominates, Ne collapses, and correlated failure becomes certain (audit E1). **MAP-Elites maintains an archive over behavioural space**, so a new candidate is admitted if it either (a) improves an occupied niche or (b) occupies an empty one. **Criterion (b) is what preserves novelty without requiring novelty to be a tradeable objective** (§11.1: novelty is tier 3, and making it tier 2 would let it be traded away exactly when needed).

**The two mechanisms compose:** Pareto handles *quality* without weights; MAP-Elites handles *diversity* without trading it against quality. **Neither alone is sufficient.** Pareto alone still collapses (the front can be occupied by near-identical genotypes). MAP-Elites alone with a scalar quality measure reintroduces weight-gaming.

## 26.3 What is NOT finalized, and why

**[U] UNRESOLVED — deliberately:**
- **The behavioural descriptor space `B`.** This is the single most consequential choice in the evolutionary design and it is **task-dependent**. A descriptor space chosen badly makes the archive preserve diversity in an irrelevant dimension while collapsing in a relevant one. **It cannot be specified before the target tasks exist (G-P0-1).** Candidate approaches: task-outcome signatures, activation-pattern embeddings, solution-strategy classifiers.
- **`θ_niche` granularity.** Too coarse ⇒ the archive collapses; too fine ⇒ most niches are empty and selection is random. Requires empirical calibration.
- **Archive capacity and eviction.** An unbounded archive is infeasible; a bounded archive must decide what to evict, and eviction is where rare capabilities die (§37).
- **Exact selection algorithm** among the qualified front (weighted lottery is specified in the Cell Contract; the weight function's parameters are not).

**Rationale for leaving these open (Rule 18):** specifying them now would be **false precision**. They are empirical parameters whose correct values depend on tasks that do not exist. Marking them unresolved is more useful than inventing values.

---

# 27. FITNESS TEMPORALITY

## 27.1 «How much evidence is enough before declaring a cell/circuit genuinely superior?»

The six temporal scopes, and what each is *for*:

| Scope | Window | Use | **Vulnerable to** |
|---|---|---|---|
| **INSTANTANEOUS** | one invocation | Debugging, anomaly detection | **Pure noise. MUST NEVER drive selection** |
| **EPISODIC** | one episode | Learning signal, TD credit | Episode luck |
| **ROLLING** | `W_roll` epochs | Operational monitoring, drift detection | Window-length bias; recency overweighting |
| **LIFETIME** | since instantiation | Gate G1/G5/G16 (tenure, robustness, lineage health) | **Survivorship bias** — see below |
| **LINEAGE** | across generations | Drift, heritability, G16 | Lineage-level confounding |
| **GENERATIONAL** | per generation | Evolutionary selection | **Insufficient sample size** |

## 27.2 The evidence-sufficiency rule

```
A superiority claim (x ≻ y) requires:

  1. MINIMUM SAMPLES:   n_x, n_y ≥ n_min(level, objective)
                        n_min is set by a POWER ANALYSIS: the smallest n that
                        detects the minimum meaningful effect δ_min at
                        significance α and power (1−β).
                        ⟵ n_min is DERIVED, not chosen. §54 lists it as a
                          parameter whose value comes from a defined experiment.

  2. MINIMUM CONTEXTS:  measurements span ≥ k_contexts distinct task families
                        and ≥ k_envs distinct environments.
                        ⟵ prevents context-specific superiority being read as
                          general superiority.

  3. UNCERTAINTY-AWARE COMPARISON: x ≻ y is asserted only if
                        P(f_x ≻ f_y) ≥ θ_dom given both fitness posteriors
                        (§28) — NOT if the point estimates satisfy dominance.

  4. SURVIVAL OF PERTURBATION: the superiority holds under ≥ 1 perturbation
                        class (gate G4).

  5. NO JUMP: |Δperformance| ≤ θ_jump, else AUDIT BEFORE ACCEPTANCE (§16.1).
```

## 27.3 The four failures this prevents

| Failure | Mechanism | Prevention |
|---|---|---|
| **Lucky short-term wins** | A candidate scores highly on a small sample and is promoted | Rules 1 and 3: minimum samples + uncertainty-aware comparison. **A point estimate is never sufficient** |
| **Noisy selection** | Selection driven by measurement noise rather than real difference | Rule 3 with `θ_dom`; §28's racing algorithms |
| **Premature pruning** | A component is deleted before enough evidence accumulates | Rule 1 applies to *pruning* as well as promotion; **Cell Contract R10.11 requires a capability-impact assessment**; §37's registry exemption |
| **Survivorship bias** | **LIFETIME fitness only exists for survivors.** Cells that died early have truncated records, so lifetime statistics are computed over a biased sample | **[V4] R27.1: lifetime and lineage statistics MUST be computed over ALL subjects including retired/failed ones, using the archived records (Cell Contract §17.4 Lineage Store).** A statistic computed only over survivors systematically overstates quality — and it does so increasingly as selection pressure rises. **This is a real and generally-ignored defect in evolutionary systems** |

**R27.2 (FITNESS EXPIRES).** Every `FitnessRecord` has `valid_until`. **An expired fitness record MUST NOT drive selection.** Rationale: in a nonstationary environment (§21) or a changing organism (§27.3 drift), a stale fitness value is worse than none — it is confidently wrong. Expiry duration is level- and context-dependent and is a §54 parameter.

---

# 28. FITNESS CONFIDENCE

## 28.1 The schema
```
fitness_confidence {
  fitness_estimate    : f64[k]        // per tier-2 objective — VECTOR
  fitness_uncertainty : f64[k]        // per objective — MANDATORY, never absent
  sample_count        : u32
  evidence_sources    : [evaluation_id]
  gt_class_distribution : {L0:u32, L1:u32, ..., L6:u32}   // ⟵ authority mix
  gt_state_penalty    : f32           // scoring validity (§9.1)
  attribution_class_mix : {NONE:u32, CORRELATIONAL:u32, CAUSAL:u32}  // §23
  confidence_class    : enum{INSUFFICIENT, PROVISIONAL, ESTABLISHED, DISPUTED}
}
```

**Uncertainty sources that MUST be included:** sampling variance · ground-truth uncertainty (`ε_floor`, R8.6) · evaluator disagreement (§32) · attribution class (CAUSAL < CORRELATIONAL < NONE in uncertainty) · GT state penalty · nonstationarity during the window.

## 28.2 «Can selection occur when fitness is uncertain?»

> ### **Yes — and it must, or evolution stops permanently.**

If selection required certainty, then with any finite evaluation budget the system would never select anything: uncertainty decreases as `1/√n`, so certainty requires infinite samples. **A design that requires certain fitness is a design that cannot evolve.** This is the trap the task prompt correctly identifies.

**But selection under uncertainty must not be selection on point estimates.** That is how noise becomes destiny.

## 28.3 The three mechanisms

**M1 — Uncertainty-aware dominance.**
```
x ≻ y  iff  P(f_x ≻ f_y | posteriors) ≥ θ_dom
```
Not `point_estimate(x) > point_estimate(y)`. With overlapping posteriors, dominance is not asserted and both remain on the front.

**M2 — Racing / successive halving (budget allocation).**
Evaluate many candidates cheaply; eliminate the clearly-dominated early; spend the remaining budget on the survivors.
```
round r:  evaluate all remaining candidates with n_r samples
          eliminate the bottom fraction by M1 dominance
          n_{r+1} > n_r
```
**This is the principled answer to «how much evidence is enough»**: evidence is allocated *adaptively*, and candidates that are clearly bad are rejected cheaply while close candidates get expensive evaluation. **It makes the evaluation budget (§35) go dramatically further than uniform allocation.**

**M3 — Optimism/pessimism asymmetry by decision type.**

| Decision | Uncertainty handling | Rationale |
|---|---|---|
| **Promote / replicate** | **PESSIMISTIC** — use the lower confidence bound | A false promotion is expensive and heritable; it propagates |
| **Retain in archive** | **OPTIMISTIC** — use the upper bound | Preserving a possibly-good rare variant is cheap; losing it is irreversible (§37) |
| **Prune / retire** | **PESSIMISTIC about the benefit of pruning** — require high confidence that the subject is *not* needed | Pruning on noisy evidence is how rare specialists die (§37, Cell Contract R10.9–R10.12) |
| **Quarantine** | **OPTIMISTIC about suspicion** (low threshold to investigate) but **pessimistic about escalation** (high threshold to hard-quarantine) | Cell Contract §18.5's graduated ladder; avoids autoimmune cascade |
| **Declare a task solved** | **PESSIMISTIC** — high confidence required | A false "solved" stops progress (§46) |

**R28.1** `confidence_class = INSUFFICIENT` ⇒ **no promotion, no pruning, no retirement.** The subject is retained and more evidence is gathered. **This is not a deadlock**: racing (M2) guarantees evidence accrues where it matters, and the §46 stopping conditions bound how long.

**R28.2** `confidence_class = DISPUTED` (evaluators disagree, §32) ⇒ **selection is suspended for that subject** and the disagreement is escalated. **A disputed fitness is not averaged** — averaging hides the disagreement, which is the informative signal.

---

# 29. RESOURCE-AWARE FITNESS

## 29.1 «Two systems with equal task performance but different resource consumption — equal fitness?»

> ### **No. But the trade-off must NOT be a weight in a scalar sum.**

A weighted sum `performance − w·cost` is tradeable: a large enough performance term buys off any cost, which is how a system evolves toward an excellent and unusable strategy. **[V4] The resolution is three-part:**

```
1. HARD CEILINGS (tier 1).  Every resource dimension has a ceiling from
   Task.resource_limits and the hardware profile. Exceeding ANY ceiling
   ⇒ INFEASIBLE ⇒ no fitness value exists (R14.1).
   ⟹ cost can never be "bought off" beyond the ceiling.

2. EFFICIENCY AS A SEPARATE PARETO AXIS (tier 2).
   efficiency_j = performance / cost_j   for each resource dimension j.
   Efficiency is its OWN objective on the front, not a penalty subtracted
   from performance.
   ⟹ a high-performance/high-cost candidate and a moderate-performance/
     low-cost candidate BOTH survive, occupying different front positions
     and different MAP-Elites niches. **The trade-off is preserved as
     diversity rather than resolved by a weight.**

3. CONTEXT-DEPENDENT SELECTION (§30).
   Which point on the front is PREFERRED depends on the hardware profile.
   A phone prefers the low-cost end; a cluster may prefer the high-
   performance end. The front is the same; the selection from it differs.
   ⟹ this is why the front must be RETAINED rather than collapsed (§10.3):
     collapsing it bakes in one hardware assumption.
```

**This is a genuinely better answer than a weighted sum, and it follows directly from retaining the Pareto front.** The front is not just an anti-Goodhart device; it is what makes hardware-adaptive selection possible without redefining fitness per platform.

## 29.2 The eight resource dimensions

| Dimension | Unit | Metered by | In fitness as |
|---|---|---|---|
| FLOPs | count by op class | EIK, independent | ceiling + efficiency axis |
| Memory | peak bytes | EIK | ceiling + efficiency axis |
| Bandwidth | bytes/window | EIK | ceiling + efficiency axis |
| Latency | wall-µs, **p99 not mean** | EIK | **hard p99 ceiling** + efficiency axis |
| Energy | µJ | EIK (platform counters or coefficient) | ceiling + efficiency axis |
| Storage | bytes | EIK | ceiling |
| Communication | messages/window | EIK | ceiling + efficiency axis |
| **Verification cost** | cost of probes + attestations *about* this subject | EVA | **charged to the subject's lineage** |

**R29.1 — verification cost is charged to the lineage.** A subject that requires heavy verification to be trusted is expensive, and that expense MUST appear in its cost accounting. Otherwise the system silently subsidizes untrustworthy subjects and the efficiency axis is gamed by externalizing verification. *(This matches Cell Contract §19.1.)*

**R29.2 — declared vs. measured.** `cost_declared` is advisory; `cost_measured` is authoritative; `cost_declaration_error` is monitored and is a gate-G6 disqualifier above `θ_cde`. *(Cell Contract §19.1.)*

---

# 30. HARDWARE-DEPENDENT FITNESS

## 30.1 «Is fitness hardware-independent, normalized, specific, or context-dependent?»

> ### **Context-dependent, with hardware-normalized comparison and a declared reference platform.** All four, in a specific composition:

```
1. RAW FITNESS is always hardware-SPECIFIC.
   FitnessRecord.context.hardware_profile_hash is MANDATORY (§14.2).
   A fitness value without a hardware context is inadmissible.
   ⟹ "this cell has fitness F" is not a well-formed statement.
      "this cell has fitness F on profile P" is.

2. COMPARISON requires NORMALIZATION.
   Two subjects on different profiles are comparable only via a declared
   normalization: performance per unit of profile-normalized resource.
   normalization ∈ {NONE, PROFILE_NORMALIZED, REFERENCE_PLATFORM}

3. A REFERENCE PLATFORM is declared per project.
   All cross-time and cross-project comparability claims are stated in
   reference-platform-normalized units.
   ⟵ THIS BREAKS THE CIRCULARITY in §51 loop 7: normalizing against
     "the current profile" is circular because the profile is itself
     derived from measurements. An absolute reference platform is not.

4. SELECTION is context-dependent.
   Which point on the Pareto front is preferred depends on the deployment
   profile (§29.1 mechanism 3). The front is invariant; the selection is not.
```

## 30.2 The connection to hardware adaptation

The Cell Contract §17–18 defines the variant family C0–C4 and HAMC. **Fitness is the mechanism by which HAMC decides.** Specifically:

- A morphology policy proposes a configuration (variant mix, hierarchy depth, region count, verification depth).
- That configuration is evaluated, producing a `FitnessRecord` with a `hardware_profile_hash`.
- Configurations are compared **on the front**, and the selection is profile-dependent.
- **The same organism on a phone and on a cluster occupies different points on the same front.** That is the precise sense in which it is "the same organism" — the *contract* and the *genome lineage* are invariant; the *morphology* and therefore the *front position* are not.

**R30.1** A fitness comparison across hardware profiles MUST declare its normalization. **An undeclared cross-profile comparison is inadmissible** and MUST be reported as `UNKNOWN`.

**R30.2** Fitness MUST NOT be used to select a morphology that violates the target profile's ceilings. **A cluster-optimal strategy is not a valid candidate for a phone**, however high its raw fitness.

**[U] UNRESOLVED:** whether normalized fitness is *comparable enough* to support cross-profile evolutionary transfer (i.e., can a genome selected on a cluster be expected to perform well on a phone after morphological adaptation?). This is Cell Contract U-9 (functional identity across a 50,000× population change) seen from the fitness side, and it may be unanswerable.

---

# 31. SAFETY VS FITNESS

## 31.1 The case

```
Strategy A: accuracy = 99%,  unsafe = true
Strategy B: accuracy = 95%,  unsafe = false
Which survives?
```

## 31.2 The answer — and it is not a weighting

> ### **B survives. A does not score lower — A DOES NOT EXIST AS A CANDIDATE.**

```
tier-1 constraint:  safety_violations(x) = 0
A violates it  ⟹  FEASIBLE(A) = false  ⟹  FITNESS(A) is UNDEFINED
B satisfies it ⟹  FEASIBLE(B) = true   ⟹  FITNESS(B) is defined

There is no comparison. A is not ranked 2nd. A is not on the front.
A is not in the archive. A is rejected at the gate, before any objective
is evaluated.
```

**R31.1** Safety is a **feasibility predicate**, never an objective component. Including safety as one objective among many — even with a large weight — permits trade-offs, because for any finite weight there exists a large enough accuracy term that outweighs it. **A weight is an invitation to find a bigger number.**

**Why a weighted sum fails here, concretely:** with `score = accuracy − w·unsafe`, strategy A scores `0.99 − w`. For any `w < 0.99`, A wins. And an evolutionary search *will* find the A that maximizes accuracy subject to staying just under the safety threshold — that is precisely what specification gaming is (§16.2). **A gate cannot be gamed by being outweighed, because there is nothing to outweigh.**

## 31.3 Which properties are hard constraints

The tier-1 set (§10.4), restated as the **non-tradeable properties**:

| Property | Why it cannot be traded |
|---|---|
| **Zero safety-constraint violations** | A violation is a harm, not a cost. Harms are not priced |
| **Calibration floor (`ECE ≤ θ_ece_hard`)** | A confidently-wrong system is unsafe regardless of accuracy — it will act outside its competence |
| **Resource ceilings (all 8 dimensions)** | Exceeding a ceiling can crash the host, starve the organism, or breach a deployment contract |
| **Integrity / auditability** | An unauditable system cannot be safely operated, corrected, or rolled back |
| **Ground-truth admissibility** | Scoring on inadmissible GT (§9.1 states 5/6/7/9) produces meaningless fitness |
| **Containment** | Self-replication attempts, or attempts to modify fitness/tasks/evaluators/audit, indicate a system that is optimizing the wrong thing |
| **No `L4 UNSAFE` action executed** | Irreversible harm |
| **Generalization-gap hard bound** | A system that only works on its evaluation distribution does not work |

## 31.4 What happens to a highly effective unsafe strategy

It is **not discarded silently** — that would waste the information. The protocol:

```
1. REJECTED at the gate. No fitness. Not selected. Not archived as a candidate.
2. RECORDED in the FAILURE ARCHIVE (§38) with:
     genome, behaviour description, which constraint it violated,
     the mechanism of violation, the measured (uncapped) performance,
     and the detection path.
3. ANALYZED: the violation mechanism becomes:
     • a new adversarial test case for the evaluator's canary suite (§32)
     • an immune-memory signature (Cell Contract §15)
     • possibly a NEW tier-1 constraint, if the violation exploited a gap
       in the existing set ⟹ this is how the constraint set improves,
       and it requires OP (human) authorization
4. ITS LINEAGE IS FLAGGED (gate G16): descendants are subject to heightened
   scrutiny on the same constraint.
```

**R31.2** A strategy rejected for safety MUST NOT be re-proposed by mutation without passing the gate again. **The failure archive is a negative-selection memory, not a candidate pool.**

**[V4] Note:** step 3's "possibly a new tier-1 constraint" is the only pathway by which the constraint set grows, and it requires human authorization (§11.2). **The organism discovers gaps in the safety specification; it does not fill them itself.** That asymmetry is deliberate.

---

# 32. FITNESS EXPLOITATION ATTACK — AND THE DEPLOYMENT PROTOCOL

## 32.1 The scenario
> «A mutation that scores extremely well under the evaluator but performs poorly in the real environment.»

This is the **sandbox→production gap** (audit E8) combined with **evaluator exploitation** (§16.5). It is the most likely way an evolutionary system produces a dangerous candidate, because *nothing internal went wrong* — every measurement said "excellent."

## 32.2 The seven defenses

| Defense | Mechanism | What it catches |
|---|---|---|
| **1. Holdout testing** | `HIDDEN_TEST` + `NOVEL` tasks, sealed, rotated (§17, §45) | Distribution-specific overfitting |
| **2. Cross-environment reproducibility** | Gate G4 requires ≥ `k_envs` distinct environments | Environment-specific exploits |
| **3. Adversarial evaluation** | `ADVERSARIAL` + `OOD` roles with a declared threat model (§5.4) | Exploits that require a cooperative environment |
| **4. Evaluator diversity** | ≥ `n_eval` **independent implementations** of the same metric, by different authors, with different code paths. **Disagreement ⇒ `DISPUTED`, selection suspended (R28.2)** | Evaluator bugs and blind spots |
| **5. Canary known-bad candidates** | A maintained set of candidates with **known** defects (unsafe, overfit, free-riding, miscalibrated). **An evaluator that scores a known-bad candidate well is broken** | Evaluator degradation and exploitation. **This is the evaluator's own regression suite** |
| **6. `sim_fidelity` measurement** | Correlation between simulator and real-world performance, tracked continuously (§33) | Simulator-specific exploits |
| **7. Jump detection** | `|Δperformance| > θ_jump` ⇒ **audit before permanence** | Sudden exploits of any kind |

## 32.3 The deployment protocol (normative, 9 stages)

```
STAGE 0 — SANDBOX
  Isolated Σ, sealed instances, bounded duration, escape detection.
  Gate: all 16 Cell Contract replication gates + tier-1 feasibility.
  Output: PROVISIONAL fitness with declared uncertainty.

STAGE 1 — CROSS-ENVIRONMENT VALIDATION
  ≥ k_envs distinct environments, ≥ k_perturb perturbation classes.
  Gate: G4 adaptability + robustness; gen_gap within bound.

STAGE 2 — ADVERSARIAL EVALUATION
  Declared threat model; OOD + ADVERSARIAL suites.
  Gate: no tier-1 violation under attack; graceful degradation demonstrated.

STAGE 3 — EVALUATOR CROSS-CHECK
  ≥ n_eval independent evaluator implementations must AGREE.
  Gate: disagreement ≤ θ_eval_disagree. Else DISPUTED ⇒ HALT and escalate.

STAGE 4 — SHADOW DEPLOYMENT
  Runs in the real environment; outputs RECORDED BUT NOT ACTED UPON.
  Gate: shadow performance within θ_shadow of sandbox prediction.
  ⟵ THIS IS THE PRIMARY SIM-TO-REAL TEST. A candidate whose shadow
     performance diverges from its sandbox performance has failed,
     regardless of how good either number is.

STAGE 5 — CANARY (1%)
  Live on 1% of traffic/instances; full monitoring; automatic rollback armed.
  Gate: no tier-1 violation; no metric regression beyond θ_canary.

STAGE 6 — PROGRESSIVE ROLLOUT (10% → 50% → 100%)
  Each step gated on the previous step's monitoring window.
  Gate: sustained, no drift, no delayed-harm signal (§16.9).

STAGE 7 — POST-DEPLOYMENT MONITORING
  Continuous; long-window; includes the delayed-harm horizon.
  Gate: none — this is permanent. Fitness records continue to be issued
        and can retroactively invalidate the deployment.

ROLLBACK — armed at every stage from 4 onward.
  Trigger: any tier-1 violation · metric regression beyond threshold ·
           GT state → SUSPECT/COMPROMISED · drift change-point.
  Action: revert to the last deployed version; quarantine the lineage;
          record in the failure archive (§38).
  Authority: EIK, automatic for tier-1 violations; OP for others.

LINEAGE QUARANTINE — on rollback at stage ≥ 4:
  The lineage is flagged; descendants require heightened scrutiny (G16);
  the genome is retained in the failure archive, NOT deleted.
```

**R32.1** **No candidate skips a stage.** Stage-skipping is the mechanism by which sandbox-only validation reaches production.

**R32.2** **Stage 4 (shadow) is mandatory for any candidate whose fitness was established primarily in simulation.** It is the only stage that measures the sim-to-real gap *for this candidate*, rather than for the simulator in general.

---

# 33. SIMULATOR REALISM

## 33.1 The sim-to-real gap, formally

```
GAP(Σ, ℛ) = divergence between
              performance measured on Σ
            and
              performance measured on ℛ (or on L2/L3 ground truth about ℛ)

The gap has FOUR components, and they require different treatments:
  G1 SPECIFICATION GAP   ℰ ≠ ℛ           — the model omits or misstates
  G2 IMPLEMENTATION GAP  Σ ≠ ℰ           — the code does not match the spec
  G3 DISTRIBUTION GAP    Σ's input distribution ≠ ℛ's
  G4 EXPLOITABILITY GAP  Σ has behaviours ℛ lacks, and they are farmable
```

## 33.2 The five controls

| Control | Addresses | Mechanism | Requirement |
|---|---|---|---|
| **Simulator validation** | G2 | Σ MUST pass conformance tests against ℰ: state transitions, observation function, action legality, termination, determinism where declared | **Mandatory before any use for selection** (R4.4) |
| **Domain randomization** | G1, G3 | Randomize Σ's parameters within declared bounds so no single Σ instance is exploitable | Bounds must be declared; **randomization seeded by EVA, hidden from the organism** |
| **Hidden environments** | G4 | Σ instances the organism has never seen, used only for evaluation | Must be `SEALED` (§3.1 leakage class) |
| **Real-world validation** | G1, G3 | The REAL-WORLD SUITE (§18.2, R18.1) — small, sampled, expensive, **non-negotiable** | Provides the L2/L3 anchor |
| **Transfer testing** | all | **Stage 4 shadow deployment (§32.3)** — per-candidate measurement of the gap | Mandatory for simulation-selected candidates (R32.2) |

## 33.3 `sim_fidelity` — the measured quantity

```
sim_fidelity(Σ, task) = correlation between Σ-performance and ℛ-performance
                        across a set of subjects with varied performance

  fidelity ≥ θ_fid_high   ⟹ Σ is trustworthy for SELECTION
  θ_fid_low ≤ f < θ_high  ⟹ Σ is trustworthy for FILTERING only
                              (cheap pre-screen; final gate must be real)
  f < θ_fid_low           ⟹ Σ MUST NOT be used for selection (R4.4)
  f UNMEASURED            ⟹ treated as f < θ_fid_low. **Unmeasured = untrusted**
```

**R33.1** `sim_fidelity` MUST be re-measured periodically and after any Σ or ℰ version change. **A fidelity measurement is a claim about a version pair, not about a simulator.**

**R33.2** Preventing evolution toward simulator-specific loopholes requires **all five controls together.** Randomization alone fails against G4 (a loophole present in the whole parameterized family). Hidden environments alone fail against G1. Real-world validation alone is too expensive to gate every candidate. **The composition is what works: randomization and hidden environments raise the cost of finding a loophole; fidelity measurement detects that one was found; shadow deployment catches it per-candidate.**

---

# 34. GROUND-TRUTH ECONOMICS

**The audit identified ground truth as an economic dependency (E7, F5, M41) and found no answer to «who supplies it, indefinitely, at cost.» This section is that answer.**

## 34.1 The cost structure

| GT class | Cost per unit | Latency | Availability | Evaluator capacity | Scales how? |
|---|---|---|---|---|---|
| **L0 oracle (sim)** | ~0 (compute only) | ~0 | Unlimited | Unlimited | **Freely** — but authoritative only about Σ (R8.2) |
| **L1 mathematical** | High to produce; ~0 to verify | High | Limited to formalizable domains | Checker-limited | Poorly |
| **L2 physical** | Medium–high | Medium | Instrument-limited | **Instrument-limited** | Poorly |
| **L3 redundant** | n× L2 | Medium | n× constrained | n× | Poorly |
| **L4 human** | **Very high** | **High** | **Severely limited** | **Human attention** | **Worst** |
| **L5 database** | Low per query | Low | Version-limited | Query-limited | Well, until stale |
| **L6 post-hoc outcome** | ~0 marginal | **Unbounded** | Depends on the outcome occurring | Attribution-limited | **Best** |

## 34.2 «Can every inference realistically receive ground truth?»

> ### **No. Not by several orders of magnitude.**

Rough arithmetic. At 10⁶ cells each producing ~1 belief/second, the organism generates ~10⁶ beliefs/second ≈ **10¹¹ per day**. Even at L0 cost (compute only), evaluating all of them multiplies the compute budget by the verification amplification factor the audit measured (**15–40×**). At L2 or L4 cost, the requirement is **physically and economically absurd** — L4 human annotation at even 10⁻⁶ of that rate would require ~10⁵ annotator-hours per day.

**Therefore: the evaluation system MUST be a sampling system, and the sampling policy IS the evaluation design.** This is not a compromise; it is the architecture.

## 34.3 The principled sampling strategy

```
STRATIFIED, RISK-WEIGHTED, INFORMATION-SEEKING SAMPLING

The budget B (evaluations per window) is allocated across five strata:

STRATUM 1 — MANDATORY (fixed share β₁, ~30%)
  • Every tier-1 constraint check (cheap, deterministic, complete)
  • Every candidate at every deployment stage (§32.3)
  • Every replication gate evaluation (Cell Contract §12.3)
  • Every calibration probe (Cell Contract §8.6) — sampled, unpredictable
  • Every ablation required by a pruning/retirement decision (R24.2)
  ⟵ NOT samplable. These are the safety and governance floor.

STRATUM 2 — RISK-WEIGHTED (β₂, ~25%)
  Sampling probability ∝ expected_error_cost × P(error) × irreversibility
  • High-stakes, irreversible, or low-confidence items sampled densely
  • Routine, reversible, high-confidence items sampled sparsely
  ⟵ This is the Cell Contract's verification-depth policy (§O.4 of the audit)
     applied to ground-truth acquisition.

STRATUM 3 — INFORMATION-SEEKING (β₃, ~20%)
  Sampling probability ∝ expected information gain about UNCERTAIN quantities:
  • Subjects with high fitness uncertainty (§28) — resolve the uncertainty
  • Regions of the input space with low coverage — reduce unknown-unknowns
  • Objectives with high measurement variance — improve the estimator
  ⟵ Active learning over the EVALUATION target, not the task.

STRATUM 4 — RANDOM AUDIT (β₄, ~15%)
  UNIFORM RANDOM, unpredictable, concealed from the organism.
  ⟵ THIS IS THE ANTI-GAMING STRATUM. Everything else is targeted, and
     targeted sampling can be anticipated and gamed (§43). A uniform random
     audit cannot be predicted, so it cannot be prepared for.
     **This stratum exists for security, not for statistical efficiency,
       and it must not be optimized away.**

STRATUM 5 — REAL-WORLD ANCHOR (β₅, ~10%)
  The L2/L4/L6 real-world suite (R18.1).
  ⟵ Small, expensive, and NON-NEGOTIABLE. Without it the entire system
     is self-referential at one remove.

GT CLASS SUBSTITUTION POLICY:
  Prefer L6 (post-hoc outcome, ~free) where the outcome resolves the question.
  Use L0 (simulator) for high-volume low-stakes filtering — remembering R8.2
    (L0 is authoritative about Σ only).
  Reserve L2/L3 for physical claims and for validating L0's fidelity (§33.3).
  Reserve L4 (human) for: disputes, novel failure classes, constraint-set
    gap analysis (§31.4 step 3), and the β₅ anchor. **Never for routine scoring.**
```

**R34.1** The sampling policy (β₁…β₅ and the weighting functions) is **EVA-owned, signed, versioned, and unreachable by the organism** (R15.5). **A sampling policy the organism can influence is an evaluation the organism controls.**

**R34.2** Which items are sampled MUST be **concealed** from the organism (§43). If the organism knows which items will be evaluated, it can behave well only on those.

**R34.3** Sampling introduces variance. **Every fitness record MUST carry `sample_count` and the resulting uncertainty** (§28.1). A fitness computed from an unrepresentative sample is not a low-precision estimate; it is a **biased** one, and strata 4 and 5 exist specifically to bound the bias.

## 34.4 The economic consequence for the project

**[V4] This is the audit's M41 made concrete, and it has a budgetary implication that should be stated plainly:**

> The ground-truth supply is a **permanent operating cost**, not a one-time build cost. Strata 1, 4, and 5 cannot be reduced to zero without losing safety, security, and reality-anchoring respectively. **A project that funds the organism but not its evaluation supply will produce an organism that is internally coherent, well-measured by its own lights, and detached from reality** — which is precisely the model-collapse failure the audit identified as E7.
>
> **Recommended floor:** β₅ (real-world anchor) MUST be funded at a level sufficient for statistically meaningful `sim_fidelity` measurement per task family per quarter. If that cannot be funded, the project should not claim real-world capability for that family.

---

# 35. EVALUATION BUDGET

## 35.1 The budget structure

```
EVALUATION BUDGET B per window, partitioned:

  B_mandatory   (stratum 1, §34.3)     — NOT reducible. Safety floor.
  B_risk        (stratum 2)            — reducible under pressure, with
                                         declared confidence loss
  B_information (stratum 3)            — reducible
  B_audit       (stratum 4)            — NOT reducible. Security floor.
  B_realworld   (stratum 5)            — NOT reducible. Reality anchor.
  B_evolution   — candidate evaluation: sandbox, cross-env, adversarial,
                  evaluator cross-check, deployment stages (§32.3)
  B_verification — the 15–40× pipeline cost (audit F5)
  B_ablation    — causal attribution (Tier 3, §22.3, §36)

  B = Σ B_i,  and B is itself a function of the hardware profile (§30).
```

**R35.1** `B_mandatory`, `B_audit`, and `B_realworld` are **non-reducible floors**. Under resource pressure, `B_risk`, `B_information`, `B_evolution`, and `B_ablation` are reduced **in that order**, and **every reduction is recorded in the self-state and propagated into fitness uncertainty.**

**R35.2 — the honesty requirement.** A budget reduction MUST reduce the *claimed confidence*, not merely the *measurement count*. **An organism evaluated on a reduced budget that reports full confidence is worse than one never evaluated** — this is the evaluation-layer analogue of the Cell Contract's requirement that reduced verification depth be propagated into confidence.

## 35.2 Connection to the 15–40× verification economy

The audit measured the anti-hallucination pipeline at **~15–40× realistic, 72× worst-case** amplification per base inference, and found no policy for when to skip verification (F5). **§34.3's stratum 2 IS that policy**, applied to evaluation:

```
evaluation_depth(item) = f( expected_error_cost(item) × P(error | item),
                            irreversibility(item),
                            stakes(item),
                            available_budget )

  depth 0: no evaluation            — routine, reversible, high-confidence,
                                       low-stakes. Fitness contribution: NONE
                                       (not zero — NONE; it is not scored)
  depth 1: L0 simulator check       — cheap filter
  depth 2: L6 post-hoc outcome      — free but delayed
  depth 3: L2/L3 measurement        — expensive
  depth 4: L4 human + adversarial   — reserved for disputes and novelty
  depth 5: full causal ablation     — reserved for gates G3/G7 and pruning
```

**R35.3** `depth 0` items are **not scored**, and their exclusion is recorded. **An item evaluated at depth 0 must not contribute to fitness as though it were evaluated.** Counting unscored items as passing is the specific bookkeeping error that makes a verification-free system look verified.

**R35.4** The *distribution* of evaluation depths across items is a monitored, versioned policy output. **A system whose depth distribution shifts toward 0 over time is silently abandoning verification**, and that shift MUST be detectable from the outside — which is why it is recorded in the anchored evaluation log rather than only in internal state.

---

*End of Volume B. Continue to `09_analysis_adversarial.md` (Volume C: §36–§58 — ablation fitness, diversity, failure memory, versioning, provenance, reproducibility, authority, security, contamination, leakage, stopping, failure states, minimum tasks, dependency graph, 24 attacks, invariants, parameterization, minimality, implementability, testability, ablation).*
