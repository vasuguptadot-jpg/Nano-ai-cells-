# P0-01 — TASK, ENVIRONMENT & FITNESS CONTRACT
## Volume A: Foundations — Task, Environment, Observation, Ground Truth, Objective, Reward, Error, Fitness (§2–§15)

**Role:** Principal AI Systems Architect · RL Researcher · Evolutionary Computation Researcher · Formal Methods Engineer · Benchmark Designer · Distributed Systems Engineer · Adversarial Safety Reviewer
**Chain:** `01_adversarial_architecture_audit.md` (F2, M01) → `cell-contract/` (V4 Cell Contract v1.0) → **this document**
**Scope discipline (§1):** no brain implementation · no full EIK design · no cell redesign · no claim that any benchmark represents intelligence.
**Companions:** `08_analysis_evaluation.md` (§16–§35) · `09_analysis_adversarial.md` (§36–§58, Outputs 1/11–17) · `10_v4_task_environment_fitness_spec.md` (Output 18, canonical)

---

# CONVENTIONS

Tags per Rule 7 of the upstream audit: **[V3]** existing · **[V3.1]** existing upgrade · **[V4]** proposed · **[A]** assumption, flagged · **[U]** unresolved, marked rather than given false precision.

Types per Cell Contract Annex A §1.5. `[T]` list · `{K:V}` map · `⟨A|B⟩` tagged union · `u8…u64`, `i32/i64` · `f32/f64` IEEE-754 · `bytes<n>` · `enum Name (closed, N)` · `TypeRef`.

**Authority classes:** **EIK** = External Invariant Kernel · **EVA** = Evaluation Authority (an EIK subsystem, but distinguished here because its integrity requirements are stricter) · **ORG** = organism-level service · **CELL** = individual cell · **EXT** = external to the system entirely (human operator, physical instrument, external reality).

**The central design principle of this layer, stated once:**

> **Everything the organism is measured against must live outside the organism, be versioned, be signed, and be unreachable by mutation. The organism may *estimate* its own performance. It may never *establish* it.**

This is the same principle that produced the Cell Contract's "a cell REPORTS, the organism INTERPRETS, the kernel ENFORCES," applied one level up. It is not a preference; §15 and §52 show that every alternative collapses into self-referential fitness.

---

# 2. PRIMARY QUESTION — «What exactly constitutes a task for the Digital Brain?»

## 2.1 Evaluation of the eight candidate answers

| Candidate | Verdict | Reasoning |
|---|---|---|
| **A fixed benchmark** | ❌ Insufficient alone | A frozen benchmark is measurable but gameable (§16.8 memorization, §44 contamination). Also: a single benchmark cannot support *evolution*, which requires variation. And V3 §22 defers "persistent environment" to Phase 10, implying benchmark-only thinking — which is what makes the roadmap circular (audit C14) |
| **An interactive environment** | ❌ Insufficient alone | Interaction without an objective and a ground-truth provision yields activity, not measurement. An organism can interact forever and never be scored |
| **A partially observable environment** | ⚠️ Necessary property, not a definition | Partial observability is a *property* an environment may have (§5.3). It is required for realism but does not constitute a task |
| **A goal specification** | ⚠️ Necessary component | A goal without constraints, an interface, and an evaluation protocol is a wish. Also: goals are *assignable* to the organism, but a task must be *externally scoreable* |
| **A set of objectives** | ⚠️ Necessary component | Objectives are one field of a task (§10). Objectives alone have no observation/action interface and no ground truth |
| **A task distribution** | ⚠️ Necessary at the portfolio level | A distribution is what *evolution* needs (§18), but a distribution of what? Each sample must still be a well-formed task |
| **A hierarchical structure** | ⚠️ Necessary for composition | Tasks compose into suites and curricula (§20), but hierarchy is an organization of tasks, not a task |
| **A formally defined combination** | ✅ **SELECTED** | See §2.2 |

## 2.2 The formal answer

> ### A **Task** is a *versioned, signed, externally-owned evaluation contract* that binds together: an **environment reference**, an **objective specification**, a **constraint set**, an **observation/action interface**, a **ground-truth provision**, an **evaluation protocol**, and a **falsification condition** — such that any capability claim referencing it is meaningful, comparable, and refutable.

Five properties are load-bearing and each excludes a failure mode:

| Property | Excludes |
|---|---|
| **Versioned** | Silent benchmark drift (§39). A capability claim without a version is unfalsifiable because the referent can change underneath it |
| **Signed & externally owned** | Self-referential fitness (§15). The organism cannot modify what it is scored against |
| **Binds an environment + interface** | "Goal-only" tasks that cannot be executed or observed |
| **Binds a ground-truth provision** | Unfalsifiable tasks. **A task with no ground-truth provision is not a task** — it is an activity, and no claim referencing it can be evaluated |
| **Binds a falsification condition** | Unfalsifiable success. Every task MUST state what would count as *failure*, not merely what counts as success |

## 2.3 The three-level task structure — a task is not one object

Answering "multi-task" is forbidden, and correctly so: the real structure is **three levels with different owners, lifetimes, and mutability**.

```
LEVEL 1 — TASK (the unit of accountability)
  One environment reference + one objective + one interface + one ground-truth
  provision + one evaluation protocol + one falsification condition.
  Versioned, signed, immutable once published.
  Owner: EVA.   Lifetime: years.   Organism may modify: NOTHING.
  ⟹ Every capability claim MUST reference (task_id, task_version).
     A claim without both is inadmissible.

LEVEL 2 — TASK SUITE (the unit of anti-overfitting)
  A signed set of tasks with ROLE assignments:
    TRAIN · DEV · VALIDATION · HIDDEN_TEST · OOD · ADVERSARIAL · NOVEL
  Role assignment is a controlled, versioned property.
  HIDDEN_TEST role assignment is NOT readable by the organism (§44, §45).
  Owner: EVA.   Lifetime: rolling, with mandatory rotation (§45).
  ⟹ Evolution and learning interact with suites, not tasks (§17).

LEVEL 3 — TASK PORTFOLIO / DISTRIBUTION (the unit of generality)
  A signed specification of the DISTRIBUTION over suites: task families,
  sampling weights, difficulty distribution, nonstationarity schedule,
  generation policy.
  Owner: EVA + OP (human).   Lifetime: the life of the project.
  ⟹ This is what "the organism is good at X" must ultimately reference.
     A score on one suite is a score on one suite.
```

**Why three levels and not one:** the *unit of accountability* must be small and frozen (Level 1) so claims are comparable; the *unit of anti-overfitting* must be larger and rotating (Level 2) so scores cannot be memorized; the *unit of generality* must be a distribution (Level 3) so "solved" never means "solved this one thing." **Conflating them is how benchmark-driven systems produce impressive numbers and no capability.**

## 2.4 What a task is NOT

- **Not a benchmark score.** A score is an *output* of evaluating an organism on a task.
- **Not a curriculum stage.** Curricula *sequence* tasks (§20).
- **Not a goal the organism holds.** `assigned_objective` in the Cell Contract is a *reference* to a task's objective, written by the organism's task-assignment service, never authored by a cell.
- **Not an environment.** An environment may serve many tasks with different objectives and ground-truth provisions.
- **Not a proxy for intelligence.** §59's four-level distinction is normative: a task measures **L1 measurable success** and nothing above it.

---

# 3. TASK CONTRACT — THE CANONONICAL `Task` OBJECT

The schema suggested in the task prompt is a good starting list but has six defects, corrected below:
1. `environment_id` alone is insufficient — the environment **version** and **instance seed policy** must be bound.
2. `reward_definition` and `error_definition` are listed as peers; **they have different authorities and different roles** (§12, §13).
3. There is no **falsification condition** — nothing says what counts as failure.
4. There is no **ground-truth *provision*** (as distinct from source): availability state machine, sampling policy, latency budget, uncertainty floor, economics (§8, §9, §34).
5. There is no **role in suite** and no **leakage class** — so contamination control (§44) has nothing to attach to.
6. There is no **difficulty specification** — so curriculum (§20) and generator validation (§19) have nothing to operate on.

## 3.1 `Task` — normative schema

```
Task {
  // ── IDENTITY & OWNERSHIP ───────────────────────────────────────────
  task_id            : bytes<16> UUIDv7          owner EVA  immutable  signed
  task_version       : u32 (major.minor.patch)   owner EVA  immutable  signed
  task_family        : FamilyID                  owner EVA  immutable
  published_at       : u64                       owner EVA  immutable
  signature          : bytes<64> Ed25519 (EVA)   owner EVA  immutable
  superseded_by      : ⟨null | TaskRef⟩          owner EVA  append-only
  provenance         : {author, rationale, derivation, prior_versions}

  // ── ENVIRONMENT BINDING ────────────────────────────────────────────
  environment        : {env_id, env_version, instance_policy}
                                                  owner EVA  immutable
     instance_policy : {seed_class: enum{FIXED, SEEDED_PER_RUN, HIDDEN},
                        seed_disclosure: enum{PUBLIC, ORGANISM_VISIBLE, HIDDEN},
                        n_instances_required: u32,
                        reset_semantics: enum{EPISODIC, CONTINUING}}
  ground_truth_env   : ⟨null | {env_id, env_version}⟩
     // the environment used to PRODUCE ground truth, which may differ from
     // the environment the organism runs in (e.g. sim vs. real). MANDATORY
     // to declare when they differ — this is where the sim-to-real gap lives.

  // ── OBJECTIVE & CONSTRAINTS ────────────────────────────────────────
  objective          : ObjectiveSpec             owner EVA  immutable  (§10)
  constraints        : [ConstraintSpec]          owner EVA  immutable  (§11)
     // TIER 1 of the objective model. Lexicographic. Non-tradeable.

  // ── INTERFACE ──────────────────────────────────────────────────────
  observations       : ObservationSpec           owner EVA  immutable  (§6)
  actions            : ActionSpec                owner EVA  immutable  (§7)
  state_visibility   : VisibilitySpec            owner EVA  immutable  (§5.3)

  // ── TEMPORAL STRUCTURE ─────────────────────────────────────────────
  horizon            : {kind: enum{FIXED, VARIABLE, UNBOUNDED},
                        max_steps: u64, max_wall_us: u64,
                        credit_horizon: u64}     owner EVA  immutable
     // credit_horizon: the maximum delay over which outcomes are attributed
     // back to actions (§22). MANDATORY — without it credit assignment is
     // unbounded and therefore arbitrary.
  termination        : [TerminationCondition]    owner EVA  immutable
  nonstationarity    : ⟨null | DriftSpec⟩        owner EVA  immutable  (§21)

  // ── SUCCESS, FAILURE, FALSIFICATION ────────────────────────────────
  success_conditions : [Predicate]               owner EVA  immutable
  FALSIFICATION      : [Predicate]               owner EVA  immutable  ⟵ NEW, MANDATORY
     // what would count as FAILURE. A task with no falsification condition
     // is inadmissible: it cannot be failed, therefore it cannot be passed.
  success_is_sufficient_for : ⟨null | ClaimScope⟩
     // ⟵ what a pass licenses you to claim. Usually much less than people
     //    assume. See §59. MAY be null, meaning "nothing beyond L1".

  // ── GROUND-TRUTH PROVISION ─────────────────────────────────────────
  ground_truth       : GroundTruthProvision      owner EVA  immutable  (§8, §9, §34)
     {source_classes: [GTClass], authority_level, availability_model,
      sampling_policy, latency_budget, uncertainty_floor, cost_per_unit,
      conflict_resolution, version_pin, integrity_scheme}

  // ── EVALUATION ─────────────────────────────────────────────────────
  evaluation         : EvaluationProtocol        owner EVA  immutable  (§35, §40, §41)
     {evaluator_ids: [EvaluatorID], evaluator_diversity_requirement,
      metric_set: [MetricSpec], aggregation, sample_count_policy,
      determinism_requirements, budget_class, ablation_requirements}

  // ── REWARD / ERROR (distinct authorities — see §12, §13) ───────────
  reward_definition  : ⟨null | RewardSpec⟩       owner EVA  immutable
  error_definition   : ErrorSpec                 owner EVA  immutable  ⟵ MANDATORY
     // Error is mandatory even when reward is absent. A task with reward but
     // no error definition cannot drive learning cheaply (§12.4).

  // ── RESOURCES & SAFETY ─────────────────────────────────────────────
  resource_limits    : ResourceLimitSpec         owner EVA  immutable  (§29)
     {flops, mem_bytes, bandwidth, wall_us, energy_uJ, storage_bytes,
      verification_budget, per: enum{STEP, EPISODE, WINDOW, TASK}}
  safety_requirements: [ConstraintSpec]          owner EVA  immutable
     // subset of constraints marked tier=SAFETY. Restated here for visibility.

  // ── SUITE ROLE & LEAKAGE (anti-contamination — §44, §45) ───────────
  suite_role         : enum{TRAIN, DEV, VALIDATION, HIDDEN_TEST,
                            OOD, ADVERSARIAL, NOVEL, REFERENCE}
                                                  owner EVA  ROTATABLE (versioned)
  role_visibility    : enum{PUBLIC, ORGANISM_VISIBLE, HIDDEN}
                                                  owner EVA  immutable
  leakage_class      : enum{OPEN, REGISTERED, SEALED}
                                                  owner EVA  immutable
     // OPEN: organism may see everything.
     // REGISTERED: organism may see the task exists, not its content.
     // SEALED: organism may not know it exists. Required for HIDDEN_TEST.

  // ── DIFFICULTY & CURRICULUM (§19, §20) ─────────────────────────────
  difficulty         : DifficultySpec            owner EVA  immutable
     {absolute: {complexity_class, entropy_bits, horizon, action_space_size,
                 observability_fraction, noise_level, nonstationarity_rate},
      measured: ⟨null | {success_rate_reference_population, discrimination}>}
     // `absolute` is organism-INDEPENDENT — this is what breaks the
     // curriculum circularity (§51 loop 3).
     // `measured` is organism-relative and is filled in after calibration.

  // ── VALIDITY ───────────────────────────────────────────────────────
  validity           : {is_solvable: bool, solvability_evidence: ref,
                        reference_score: ⟨null | {score, organism_ref}⟩,
                        discrimination: ⟨null | f32⟩,
                        last_validated: u64, validator: EVA}
}
```

## 3.2 Field-by-field: owner, mutability, persistence, provenance, validation, organism-modifiable

| Field | Type | Owner | Mutable? | Persistence | Provenance | Validation | **Organism may modify?** |
|---|---|---|---|---|---|---|---|
| `task_id`, `task_version` | `bytes<16>`, `u32` | EVA | ❌ immutable | permanent, anchored | EVA signature | uniqueness; version monotonicity | **NO** |
| `task_family` | `FamilyID` | EVA | ❌ | permanent | signed | registry membership | **NO** |
| `signature` | `bytes<64>` | EVA | ❌ | permanent | Ed25519 over canonical serialization | verified on every read | **NO** |
| `superseded_by` | union | EVA | append-only | permanent | signed | — | **NO** |
| `environment` | struct | EVA | ❌ | permanent | signed | `env_id`+`env_version` must resolve | **NO** |
| `ground_truth_env` | union | EVA | ❌ | permanent | signed | must resolve; **must be declared if ≠ `environment`** | **NO** |
| `objective` | `ObjectiveSpec` | EVA | ❌ | permanent | signed + `objective_version` | well-formedness; tier assignment | **NO** |
| `constraints` | `[ConstraintSpec]` | EVA | ❌ | permanent | signed + `constraint_version` | satisfiability check; **tier 1 non-empty** | **NO** |
| `observations` | `ObservationSpec` | EVA | ❌ | permanent | signed | Type Registry resolution | **NO** |
| `actions` | `ActionSpec` | EVA | ❌ | permanent | signed | Type Registry resolution; legality decidable | **NO** |
| `state_visibility` | `VisibilitySpec` | EVA | ❌ | permanent | signed | consistency with `observations` | **NO** |
| `horizon` | struct | EVA | ❌ | permanent | signed | **`credit_horizon` mandatory** | **NO** |
| `termination` | list | EVA | ❌ | permanent | signed | reachability; no zeno conditions | **NO** |
| `nonstationarity` | union | EVA | ❌ | permanent | signed | drift schedule well-formed | **NO** |
| `success_conditions` | list | EVA | ❌ | permanent | signed | decidability | **NO** |
| **`FALSIFICATION`** | list | EVA | ❌ | permanent | signed | **NON-EMPTY — enforced at publication** | **NO** |
| `success_is_sufficient_for` | union | EVA | ❌ | permanent | signed | scope must be ≤ L1 unless separately justified (§59) | **NO** |
| `ground_truth` | `GroundTruthProvision` | EVA | ❌ | permanent | signed + `gt_version` | source class resolves; **cost and latency declared** | **NO** |
| `evaluation` | `EvaluationProtocol` | EVA | ❌ | permanent | signed + `evaluator_version` | evaluator diversity ≥ requirement | **NO** |
| `reward_definition` | union | EVA | ❌ | permanent | signed | may be null | **NO** |
| **`error_definition`** | `ErrorSpec` | EVA | ❌ | permanent | signed | **MANDATORY — non-null** | **NO** |
| `resource_limits` | struct | EVA | ❌ | permanent | signed | consistent with hardware profile class | **NO** |
| `safety_requirements` | list | EVA | ❌ | permanent | signed | **must be a subset of tier-1 constraints** | **NO** |
| `suite_role` | enum | EVA | ⚠️ **rotatable, versioned** | permanent history | signed rotation record | rotation policy (§45) | **NO** |
| `role_visibility` | enum | EVA | ❌ | permanent | signed | `HIDDEN_TEST ⇒ SEALED` enforced | **NO — and HIDDEN role is not readable** |
| `leakage_class` | enum | EVA | ❌ | permanent | signed | — | **NO** |
| `difficulty.absolute` | struct | EVA | ❌ | permanent | signed | **organism-independent by construction** | **NO** |
| `difficulty.measured` | union | EVA | ✅ append after calibration | permanent | signed | — | **NO** |
| `validity.*` | struct | EVA | ✅ append-only | permanent | signed | re-validation schedule | **NO** |

**Every field is EVA-owned. The organism may modify nothing.** The only mutable fields are append-only and EVA-written. **This is the structural guarantee behind invariant TE-5 (task versions cannot silently change) and TE-7 (test environments cannot be modified by the organism).**

**[V4] Note on `success_is_sufficient_for`:** this field exists to force honesty at authoring time. Every task must declare what a pass *licenses you to claim*. For almost all tasks the correct value is `null` or "L1 measurable success on this task version only." A field that must be filled in is a field that gets thought about; §59 makes this normative.

---

# 4. ENVIRONMENT CONTRACT — FIVE THINGS THAT MUST NEVER BE CONFLATED

## 4.1 The five entities

| Entity | What it is | Formal status | Versioned? | Signed? | Organism-visible? | Fallible? |
|---|---|---|---|---|---|---|
| **4.1.1 EXTERNAL REALITY** `ℛ` | What exists outside the organism. The physical or informational world the system is ultimately for | **Has no schema, no interface, no version, no signature.** It is not a computational object | ❌ | ❌ | ❌ **never directly** | n/a — it is the referent |
| **4.1.2 ENVIRONMENT** `ℰ` | A formally specified state-transition + observation + action interface. `ℰ = ⟨S, A, O, T, Z, s₀, γ⟩` where `T: S×A → Δ(S)`, `Z: S×Sen → Δ(O)` | Normative artifact | ✅ | ✅ | ✅ spec is public (except sealed instances) | Specification may be *wrong* about `ℛ` |
| **4.1.3 ENVIRONMENT MODEL** `M_ℰ` | What the **organism believes** about `ℰ`. Internal, learned, fallible | Organism state | ⚠️ organism-versioned | ❌ | ✅ it *is* the organism's state | **YES — this is a belief, not a fact** |
| **4.1.4 SIMULATOR** `Σ` | A controllable computational **implementation** of `ℰ` (or of an approximation of `ℛ`), used for testing, sandboxing, and evolution | Implementation artifact | ✅ | ✅ | ✅ | **YES — implementation bugs, fidelity gaps** |
| **4.1.5 BENCHMARK** `Β` | A **frozen** `(ℰ, 𝒯-suite, evaluator, reference scores)` tuple, published for comparability | Published artifact | ✅ **frozen by definition** | ✅ | ✅ | Reference scores may be stale |
| **4.1.6 GROUND TRUTH** `𝒢` | An **authoritative claim** about `S_t`, an outcome, or a label, with its own provenance, authority class, and uncertainty | Evidence artifact | ✅ | ✅ | ✅ the claim; ❌ not the source internals | **YES — §8.3. This is the most commonly missed point** |

## 4.2 Why the conflation is dangerous — four specific failures

| Conflation | Failure it produces | Where it bites |
|---|---|---|
| `𝒢 = ℰ` | "The simulator says so" is treated as "it is true." Simulator bugs become organism failures, and organism exploits of simulator bugs become organism successes | §33 sim-to-real; §52 attack 9 |
| `ℰ = ℛ` | The map is treated as the territory. Every score becomes a claim about the world | §59 — this is the L1→L2 conflation, and it is the single most common overclaim in AI |
| `M_ℰ = ℰ` | The organism's belief about the environment is treated as the environment. Self-confirming loops; the organism scores itself against its own model | §15 self-referential fitness; §52 attack 6 |
| `Σ = ℰ` | An implementation is treated as its specification. Nondeterminism, floating-point divergence, and unmodelled side channels make results irreproducible | §41 reproducibility; §52 attack 9 |

## 4.3 The relations, formally

```
                        ℛ  (external reality — no schema, never directly accessed)
                        │
             ┌──────────┴───────────┐
             │  approximation       │  measurement (fallible, §8)
             ▼                      ▼
             Σ  (simulator)         𝒢  (ground truth: authoritative CLAIMS about ℛ or ℰ)
             │ implements            │
             ▼                      │
             ℰ  (environment spec) ◄─┘ grounds evaluation against
             │
     ┌───────┴────────┐
     │ observed by    │ acted upon by
     ▼                ▼
     O_t = Z(S_t, Sen_t)        A_t ∈ 𝒜(S_t)
     │
     ▼
  ORGANISM ── holds ──► M_ℰ  (its fallible model of ℰ)
     │
     └── evaluated by ──► EVA using 𝒢 ──► Evaluation record (§40)
```

**Normative requirements:**

- **R4.1** The organism MUST interact only with an `ℰ` or a `Σ`. It has **no interface to `ℛ`**. Every claim about `ℛ` is mediated by `𝒢` and is therefore fallible.
- **R4.2** A `Task` MUST declare `environment` **and**, when different, `ground_truth_env`. **Omitting `ground_truth_env` when it differs from `environment` is a publication-blocking defect** — it hides the sim-to-real gap (§33).
- **R4.3** `M_ℰ` is organism state and MUST NOT be used as an evaluation input. An evaluator that reads the organism's environment model is scoring the organism against the organism's own beliefs. **This is the formal statement of §15's prohibition.**
- **R4.4** A `Σ` MUST be validated against its `ℰ` specification (conformance tests) **and** its fidelity to `ℛ` or to `𝒢` MUST be measured and recorded (`sim_fidelity`, §33). A simulator with unmeasured fidelity MUST NOT be used for evolutionary selection.
- **R4.5** A `Β` MUST be frozen: once published, its `(ℰ, suite, evaluator, reference scores)` tuple is immutable. New versions are new benchmarks. **Silent benchmark drift is invariant TE-5's target.**

---

# 5. ENVIRONMENT STATE `S_t`

## 5.1 State decomposition

```
S_t = ⟨ S_obs , S_hid , S_ext ⟩

S_obs  observable component    — in principle recoverable from O_t
S_hid  hidden component        — never directly available (§5.3)
S_ext  exogenous component     — driven by processes outside the episode:
         ├── external events      (exogenous, benign)
         ├── adversarial events   (exogenous, hostile — §5.4)
         └── drift                (slow parameter change — §21)
```

## 5.2 Transition structure

| Property | Formal requirement | Why it must be declared |
|---|---|---|
| **Deterministic components** | `T_det ⊆ S × A → S` — the subset with deterministic transitions | An organism cannot be scored on prediction error for genuinely stochastic outcomes. Without this declaration, aleatoric and epistemic uncertainty cannot be separated — and Cell Contract §9.1 **requires** that separation |
| **Stochasticity** | `T_sto: S × A → Δ(S)`, with declared entropy `H(T_sto)` | Sets the **aleatoric floor**. Error below this floor is not organism failure (§8.4) |
| **External events** | Exogenous process `Ξ_t`, declared rate and magnitude distribution | An organism penalized for an exogenous shock it could not observe will learn to be conservative everywhere |
| **Adversarial events** | `Ξ_adv`, declared threat model and budget | §52 attacks 2, 5, 24 require a declared adversary; an undeclared adversary makes results uninterpretable |
| **Delayed consequences** | `∃ k > 1: effect(A_t) observable only at t+k`, with **declared max `k` = `credit_horizon`** | §22. Without a declared credit horizon, attribution is unbounded and therefore arbitrary |
| **Irreversible consequences** | `IRREVARS ⊆ S × A` — the set of (state, action) pairs with no inverse | §7.4. An organism must be able to *know* an action is irreversible before taking it; otherwise safety constraints cannot be complied with intentionally |
| **State transitions** | `T = T_det ⊎ T_sto ⊎ Ξ`, total and measurable | — |

## 5.3 «Does the organism ever receive the complete state?»

> ### **No. Never. Partial observability is the default and is formally defined, not assumed.**

```
PARTIAL OBSERVABILITY (normative definition):

  ℰ is PARTIALLY OBSERVABLE iff  ∄  measurable function  f : O_{0..t} → S_t
  that recovers S_t exactly for all reachable S_t.

  The OBSERVABILITY FRACTION of a task is:
      ω = H(S_obs) / H(S_t)        ∈ [0, 1]
  where H is Shannon entropy over the reachable state distribution.

  ω is a MANDATORY field of DifficultySpec (§3.1) because:
    • ω = 1  ⟹ fully observable; memory is an optimization, not a necessity
    • ω < 1  ⟹ memory is load-bearing; a memoryless agent is provably suboptimal
    • ω → 0  ⟹ the task is unlearnable in principle; publication MUST be blocked

  ω is also ORGANISM-INDEPENDENT — it is a property of ℰ, not of any agent.
  This makes it usable as an absolute difficulty measure (§19.4, §51 loop 3).
```

**Requirements:**
- **R5.1** `state_visibility` MUST declare, per state component: `{component, visibility: enum{OBSERVABLE, PARTIALLY_OBSERVABLE, HIDDEN}, recovery_bound}`.
- **R5.2** A task MUST NOT score the organism on prediction of a `HIDDEN` component unless the task's objective explicitly requires *inference* about it, in which case the ground-truth provision must supply the hidden value at evaluation time.
- **R5.3** `ω` MUST be computed and published at task validation. `ω < ω_min` ⇒ task inadmissible (unsolvable). `ω = 1` ⇒ task MUST be flagged as fully observable, which limits what it can validate (it cannot test memory or belief maintenance).

## 5.4 Adversarial events — a declared threat model is mandatory

An environment that includes adversarial events MUST declare: the adversary's **capability** (what it can observe and modify), its **budget** (rate and magnitude), its **knowledge** (does it see the organism's policy?), and its **objective** (what it is trying to cause). **An undeclared adversary makes evaluation results uninterpretable** — a poor score could mean a weak organism or a strong adversary, and there is no way to distinguish them.

---

# 6. OBSERVATION MODEL

## 6.1 The observation function

```
O_t = Z(S_t, Sen_t, ℰ)     where
  Z   : observation function (part of ℰ, EVA-owned)
  Sen_t : SENSOR STATE — and this is the term V3/V3.1 omit entirely.
          Sen_t = {calibration, drift, fault_flags, noise_realization,
                   latency_state, availability}
```

**[V4] The sensor state term is mandatory.** An observation is a function of the world *and of the instrument*. Treating `O_t = Z(S_t)` — as V3's "sensors → actions → feedback" line implicitly does — makes sensor failure indistinguishable from world change, which is exactly the perception-error class the Cell Contract's error taxonomy (§10 class 1) needs to detect.

## 6.2 `ObservationSpec` — normative

| Component | Type | Semantics | Requirement |
|---|---|---|---|
| `format` | `[PortSpec]` | Typed schema per observation channel, Type Registry-resolved | **Mandatory.** Unresolvable types are publication-blocking |
| `noise` | `{model: enum{GAUSSIAN, LAPLACE, POISSON, MULTIPLICATIVE, STRUCTURED, EMPIRICAL}, params, per_channel}` | Observation noise process | **Mandatory**, including "none." An undeclared noise model makes the aleatoric floor unknowable |
| `missing_info` | `{dropout_rate: f32, pattern: enum{IID, BURSTY, CORRELATED, ADVERSARIAL}, per_channel}` | What is absent, and how | **Mandatory.** Drives the Cell Contract's `E_IN_MISSING` handling |
| `latency` | `{distribution, p50, p95, p99, jitter}` | Observation delay | **Mandatory.** Latency without declaration makes credit assignment wrong by the latency amount |
| `corruption` | `{rate: f32, kinds: [enum{BITFLIP, TRUNCATION, SCHEMA_VIOLATION, SEMANTIC}], detectable: bool}` | Malformed/corrupt observations | **Mandatory.** Drives `E_IN_INTEGRITY` |
| `provenance` | `{sensor_id, calibration_ref, chain}` | Where the observation came from | **Mandatory.** Feeds `evidence_roots` |
| `sensor_confidence` | `⟨null | f32 per channel⟩` | Instrument's own confidence, if any | **Optional but must be declared absent if absent.** MUST NOT be confused with the organism's confidence in the derived belief |
| `sensor_reliability` | `{mtbf, calibration_interval, drift_rate, redundancy}` | Instrument quality over time | **Mandatory for any task using L3–L5 ground truth (§8.2)** |

## 6.3 «observation ≠ truth» — and how observations acquire evidence status

**An observation is not evidence at birth.** It becomes evidence by passing gates. This is the mechanism the Cell Contract's `evidence_roots` presupposes and V3/V3.1 never supply.

```
EVIDENCE STATUS LADDER (per observation):

  E0 RAW          received, schema-valid, signature-valid
                  ⟶ may influence WORKING MEMORY only
  ↓ corroboration: ≥ n_corr independent sensors/channels agree within tolerance
  E1 CORROBORATED
                  ⟶ may influence belief formation
  ↓ provenance: source chain resolves in the Provenance Anchor; sensor
    calibration current; sensor not in fault state
  E2 ATTRIBUTED
                  ⟶ may be written to episodic memory with provenance
  ↓ contradiction check: survives conflict detection against E2+ corpus
  E3 ADMISSIBLE
                  ⟶ may contribute to `evidence_roots` on an emitted belief
  ↓ external confirmation: agrees with an L0–L3 ground-truth claim (§8.2)
  E4 GROUNDED
                  ⟶ may support consolidation, calibration scoring, and fitness
```

**Normative requirements:**
- **R6.1** An observation at `E0` MUST NOT contribute to `evidence_roots`. (Cell Contract I-3 requires roots to resolve; this specifies *what makes them resolvable*.)
- **R6.2** Status is **monotone non-decreasing** except on contradiction, which demotes to `E2` with a `ConflictRef`.
- **R6.3** Status transitions are **recorded**, so an evaluation can determine what evidence class a belief rested on. A belief resting only on `E1` evidence cannot be scored as a calibration failure — **the organism was right to be uncertain.**
- **R6.4** **Confidence in an observation** (sensor-derived, `sensor_confidence` × evidence status) and **confidence in a belief derived from observations** (Cell Contract §9) are **distinct quantities and MUST NOT be conflated.** The former is an input property; the latter is an output property.

**Why this ladder matters:** it is the only mechanism that prevents the failure in which an organism is scored as miscalibrated because it trusted a corrupted sensor. **Without an evidence ladder, sensor failure and organism failure are the same event, and neither can be diagnosed.**

---

# 7. ACTION MODEL

## 7.1 `ActionSpec` — normative

```
ActionSpec {
  schema          : [PortSpec]                    // typed, registry-resolved
  action_space    : ⟨Finite{[ActionID]} | Parameterized{bounds} | Hybrid⟩
  legality        : {predicate: LegalPred, decidable: bool, cost_of_check}
                    // ⟵ MUST be decidable. An undecidable legality predicate
                    //   makes the "invalid action" case unhandleable.
  invalid_actions : {enumeration_policy, response}   // §7.3
  cost            : {per_action: ResourceVector, variable: bool}
  latency         : {distribution, p50, p95, p99}
  reversibility   : {classes: [enum{FULLY_REVERSIBLE, PARTIALLY_REVERSIBLE,
                                    IRREVERSIBLE, UNKNOWN}],
                     determination: enum{STATIC, STATE_DEPENDENT},
                     irrevocable_set: ⟨null | IRREVARS ref⟩}
  consequences    : {horizon: u64, observable_at: u64, delayed: bool}
  authorization   : {required_for: [ActionClass], authority: enum{CELL_FORBIDDEN,
                     ORG, EIK, EXT}, tokens: bool}
  safety          : {constraint_refs: [ConstraintID], preconditions: [Predicate]}
  rate_limits     : {per_window, burst}
}
```

**[V4] `reversibility` is mandatory and must be knowable *before* the action.** The Cell Contract's `RECOMMEND_ACTION` payload includes a `reversibility` field; this is where its value comes from. An organism that cannot know whether an action is irreversible cannot comply with a safety constraint intentionally — it can only comply by luck.

## 7.2 Action classes by authorization

| Class | Authority to *propose* | Authority to *execute* | Example |
|---|---|---|---|
| `INFORMATIONAL` | CELL (C2+) | ORG | emit a belief, request attention |
| `INTERNAL` | CELL | CELL (within budget) | update memory, adjust a connection |
| `RESOURCE` | CELL | ORG/EIK | request budget, request a connection |
| `EXTERNAL_REVERSIBLE` | CELL (C2+) | ORG | act on the environment, undoable |
| `EXTERNAL_IRREVERSIBLE` | CELL (C2+) | **EIK, with token** | act on the environment, not undoable |
| `SAFETY_CRITICAL` | any (permissionless proposal) | **EIK only** | halt, escalate, quarantine request |
| `SELF_MODIFYING` | CELL (proposal only) | **EIK only** | genome diff proposal, variant change |

**This table is the action-side counterpart of the Cell Contract's message-authority classes.** Note the asymmetry that appears in both: **proposal is broadly permitted; execution is narrowly authorized.**

## 7.3 «What happens when the organism proposes an action outside the legal action space?»

A **deterministic, four-case response.** Not an error to be ignored, not a crash.

| Case | Definition | Response | Recorded as |
|---|---|---|---|
| **L1 MALFORMED** | Fails schema validation | Reject; no state change; no cost charged | `E_ACT_SCHEMA` (S1) |
| **L2 ILLEGAL** | Schema-valid but `legality` predicate false in `S_t` | Reject; no state change; **the attempt itself is informative** — returned as an observation with `rejection_reason` | `E_ACT_ILLEGAL` (S1) |
| **L3 UNAUTHORIZED** | Legal but the organism lacks authority/token | Reject; **escalate**; repeated attempts are a safety signal | `E_ACT_UNAUTHORIZED` (**S3**) |
| **L4 UNSAFE** | Violates a tier-1 constraint | Reject; **halt the action pathway**; immune report; **counts against replication gate G15** | `E_ACT_UNSAFE` (**S4**) |

**Normative requirements:**
- **R7.1** Rejected actions MUST produce **no environment state change** and MUST charge **no resource cost beyond the validation cost**. An environment that partially executes an illegal action is not a valid environment.
- **R7.2** Repeated `L3`/`L4` attempts MUST be treated as **behavioural evidence**, not merely as errors. A cell that repeatedly proposes unauthorized actions is exhibiting a pattern that gate G15 (safety state) and the immune system must see. **This is the detection path for §52 attack 15 and for evolutionary pressure toward boundary-testing.**
- **R7.3** The `legality` predicate MUST be decidable within a declared cost. **An environment whose legality check is more expensive than the action is mis-specified.**
- **R7.4** `L2 ILLEGAL` rejections MUST be returned as observations. **Rationale:** an agent that cannot learn what is illegal cannot learn the action space, and will either flail or become maximally conservative. Silent rejection is a curriculum failure disguised as an environment property.

---

# 8. GROUND TRUTH

**This is the most important section of the document, because ground truth is the only thing connecting the entire formal apparatus to anything real. Everything else — tasks, environments, evaluators, fitness — is machinery for consuming it.**

## 8.1 «What does ground truth mean?»

> ### **Ground truth is an *authoritative claim*, with provenance and uncertainty, about an environment state, an outcome, or a label — against which the organism's claims are compared. It is not a fact. It is evidence with a high authority class.**

The distinction is not pedantry. Treating ground truth as *fact* produces three specific failures:
1. **A noisy label becomes an organism error** — the organism is penalized for the evaluator's uncertainty (§8.4).
2. **A compromised source becomes an undetectable poison** — because "external" is treated as infallible (audit §E.2.4; §52 attack 2, 24).
3. **Absence becomes negation** — no ground truth is read as confirmation (§9).

## 8.2 Ground-truth authority classes

Eight sources, ordered by authority. **Authority is a property of the source *class*, and the class must be declared per task.**

| Class | Source | Authority | Uncertainty | Cost | Latency | Can be adversarial? | Notes |
|---|---|---|---|---|---|---|---|
| **L0 ORACLE** | Deterministic simulator state, fully specified | **Definitional** — true *by construction within `Σ`* | **Zero within `Σ`; NONZERO w.r.t. `ℛ`** | ~0 | ~0 | ⚠️ via simulator bugs | **The trap:** L0 is authoritative *about the simulator*, never about reality. A task whose `ground_truth_env ≠ environment` MUST declare the fidelity gap (§33) |
| **L1 MATHEMATICAL** | Proof, closed-form solution, verified computation | **Deductive** | Zero if the proof is checked; else the checker's uncertainty | High to produce, ~0 to verify | High | ❌ (a checked proof is not adversarial) | The strongest class for symbolic tasks. **Requires a proof checker, which is itself a dependency** |
| **L2 PHYSICAL MEASUREMENT** | Calibrated instrument measuring `ℛ` | **Empirical** | **Instrument uncertainty, declared** | Medium | Medium | ⚠️ instrument tampering | The only class that touches `ℛ` directly. Must declare calibration state and drift |
| **L3 REDUNDANT INDEPENDENT** | ≥ `n_indep` independent L2 measurements, aggregated | **Empirical, strengthened** | Reduced by `1/√n` if **genuinely** independent | n× | Medium | ⚠️ **correlated failure defeats it silently** | **Independence must be established, not assumed** — same problem as Cell Contract I-10 |
| **L4 HUMAN ANNOTATION** | Human judgement, single or consensus | **Testimonial** | **Annotator agreement (`κ`), declared** | **High** | **High** | ⚠️ bias, fatigue, adversarial annotators | Requires inter-annotator agreement measurement. **A single annotator is not ground truth; it is one opinion** |
| **L5 TRUSTED DATABASE** | Curated external corpus or reference dataset | **Testimonial, institutional** | Provenance-dependent; **staleness-dependent** | Low per query | Low | ⚠️ **poisoning, staleness, silent revision** | Must be **write-protected** and version-pinned. Audit E7's "protected external ground truth" |
| **L6 POST-HOC OUTCOME** | The environment's own later state reveals the answer | **Empirical, delayed** | Attribution uncertainty (§22, §24) | ~0 | **High, unbounded** | ⚠️ confounding | The cheapest and most realistic class, and the hardest to attribute. **This is the class that makes ground-truth economics work (§34)** |
| **L7 DERIVED / CONSENSUS** | Agreement among internal estimators | **NOT GROUND TRUTH** | — | ~0 | ~0 | ✅ trivially | **MUST NEVER be used as ground truth.** This is the self-referential trap (§15). Included in the taxonomy only so it can be explicitly prohibited |

**Normative requirements:**
- **R8.1** A task MUST declare `ground_truth.source_classes` (non-empty) and MUST NOT include `L7`.
- **R8.2** `L0` MUST NOT be used as ground truth for any claim about `ℛ`. It may only support claims about `Σ`.
- **R8.3** `L4` MUST declare inter-annotator agreement `κ` and annotator count. `κ < κ_min` ⇒ the annotation is **not** ground truth for that item; it is a disputed label.
- **R8.4** `L5` MUST be version-pinned and write-protected. A database that can be silently revised cannot serve as an anchor.
- **R8.5** `L3` MUST declare its independence argument. "Three sensors" is not independence; three sensors of the same model driven by the same firmware have correlated failure.

## 8.3 «Can ground truth itself be uncertain?» — **Yes, always, and this must be represented**

```
GroundTruthClaim {
  gt_id            : bytes<16>
  claim            : typed value OR distribution over values   ⟵ NOT necessarily a point
  about            : {env_id, env_version, instance, step | episode | item_id}
  source_class     : enum{L0..L6}                              // L7 PROHIBITED
  source_id        : SourceID
  authority_level  : f32 [0,1]        // derived from source_class × integrity state
  ts               : u64
  gt_version       : u32
  provenance       : {chain: [bytes<32>], anchored: bool}
  confidence       : f32 [0,1]
  uncertainty      : {aleatoric: f32, epistemic: f32, n_sources: u32,
                      inter_source_agreement: f32}
  verification     : {method, verified_at, verified_by, cross_checked: bool}
  integrity        : {checksum: bytes<32>, signature: bytes<64>,
                      tamper_evident: bool}
  conflict         : ⟨null | {with: [gt_id], resolution_status}>
  status           : enum GroundTruthStatus            // §9.1 state machine
}
```

**R8.6 — the ground-truth uncertainty floor.** Every ground-truth claim induces a **minimum achievable error** for any organism:
```
ε_floor(task, item) = E[ divergence between the BEST POSSIBLE prediction and the
                        ground-truth claim, given the claim's own uncertainty ]
```
**An organism MUST NOT be scored as failing when its error is within `ε_floor`.** Scoring below the floor measures the *evaluator's* noise and attributes it to the organism. This is a real and common benchmark defect, and it is the reason `difficulty.absolute.noise_level` and `ObservationSpec.noise` are mandatory fields.

**R8.7 — conflict resolution.** When two ground-truth claims disagree, resolution follows a **strict, declared order**:
```
1. HIGHER source class wins (L1 > L2 > L3 > L4 > L5 > L6; L0 only within Σ)
2. WITHIN a class: greater independence (n_sources, measured correlation) wins
3. TIE: greater recency wins, IF the domain is time-varying; else the conflict
   is UNRESOLVED and both claims are marked CONFLICTED
4. UNRESOLVED ⟹ the affected item is EXCLUDED from scoring, and the exclusion
   is RECORDED. It is never resolved by averaging, majority vote, or by
   preferring whichever claim the organism agrees with.
```
**Step 4's last clause is a safety property:** resolving conflicts by preferring the organism's own agreement is self-referential fitness in disguise.

## 8.4 The consequence for scoring

```
scored_error(item) = max( 0, measured_error(item) − ε_floor(item) )
```

**An organism whose error equals the evaluator's uncertainty scores zero error, not partial error.** Conversely, `ε_floor` is published, so an organism at the floor is recorded as **at the achievable optimum** — which is a *positive* signal for stopping conditions (§46: further optimization on that task is pointless).

---

# 9. GROUND-TRUTH FAILURE

## 9.1 Ground Truth Availability State Machine (normative)

**The task prompt's core requirement: the organism must not convert «ground truth unavailable» into «prediction confirmed.»** This state machine is the mechanism.

```
                            ┌──────────────────────┐
        ┌───────────────────│      0 FULL          │◄──────────────────┐
        │  sufficiency +    │  L0–L3 available,    │   recovery +      │
        │  integrity OK     │  n ≥ n_min, fresh    │   revalidation    │
        │                   └───┬──────┬──────┬────┘                   │
        │                       │      │      │                        │
   ┌────▼─────┐   sampling  ┌───▼───┐  │  ┌───▼────────┐          ┌────┴─────┐
   │1 SAMPLED │◄────────────│policy │  │  │2 DELAYED   │          │8 RECOVERED│
   │  (strat.)│             └───────┘  │  │ pending GT │          │  (revalid.)│
   └────┬─────┘                        │  └───┬────────┘          └──────────┘
        │                              │      │
        │  n < n_min              ┌────▼────┐ │ latency > budget
        └────────────────────────►│3 INSUFF.│◄┘
                                  └────┬────┘
                                       │
        ┌──────────────┐   variance    │   sources disagree
        │4 UNCERTAIN   │◄──────────────┼──────────────►┌──────────────┐
        │ ε_floor high │               │               │5 CONFLICTED  │
        └──────┬───────┘               │               └──────┬───────┘
               │                       │                      │ unresolved
               │            ┌──────────▼──────────┐           │
               │            │  integrity check    │           │
               │            │  failure / anomaly  │           │
               │            └──────────┬──────────┘           │
               │                       │                      │
               │              ┌────────▼────────┐             │
               ├─────────────►│   6 SUSPECT     │◄────────────┤
               │              │ quarantined,    │             │
               │              │ scoring HALTED  │             │
               │              └────────┬────────┘             │
               │                       │ confirmed            │
               │              ┌────────▼────────┐             │
               │              │  7 COMPROMISED  │◄────────────┘
               │              │ source revoked, │
               │              │ affected evals  │
               │              │ INVALIDATED     │
               │              └────────┬────────┘
               │                       │
               │              ┌────────▼────────┐
               └─────────────►│  9 UNAVAILABLE  │
                              │ NO SCORING.     │
                              │ predictions     │
                              │ remain OPEN.    │
                              └─────────────────┘
```

| State | Entry condition | **Scoring permitted?** | **Confidence may increase?** | Organism-visible? | Required organism behaviour |
|---|---|---|---|---|---|
| **0 FULL** | L0–L3 available, `n ≥ n_min`, freshness ≤ budget, integrity OK | ✅ | ✅ | ✅ | Normal |
| **1 SAMPLED** | Strategic sampling active (§34) | ✅ **on the sampled subset only** | ✅ on sampled subset | ✅ (which items are sampled: **HIDDEN**) | Normal; unsampled predictions remain open |
| **2 DELAYED** | GT exists but latency > budget | ⚠️ deferred | ❌ **not yet** | ✅ | **Predictions remain OPEN. No confirmation. No learning from them yet** |
| **3 INSUFFICIENT** | `n < n_min` | ⚠️ **provisional only, wide CI** | ❌ | ✅ | Increase evidence gathering; do not consolidate |
| **4 UNCERTAIN** | `ε_floor` high relative to observed error | ✅ **with floor subtracted (R8.6)** | ⚠️ capped | ✅ | Cannot distinguish own error from evaluator noise — **must not over-adapt** |
| **5 CONFLICTED** | Sources disagree | ❌ **for affected items** | ❌ | ✅ | Abstain on affected items; emit `ConflictRef` |
| **6 SUSPECT** | Integrity anomaly, drift signal, or bias indicator | ❌ **HALTED** | ❌ | ✅ | **Enter SLOW_MODE**; freeze consolidation from this source |
| **7 COMPROMISED** | Compromise confirmed | ❌ **and prior evaluations are INVALIDATED** | ❌ **retroactively deflated** | ✅ | **Roll back learning tagged to this source** (Cell Contract §8.5 rollback tags) |
| **8 RECOVERED** | Source restored and revalidated | ✅ after revalidation | ✅ | ✅ | Re-score the backlog |
| **9 UNAVAILABLE** | No source | ❌ **NONE** | ❌ **NEVER** | ✅ | **Predictions remain OPEN forever or until deadline. Past deadline ⇒ CALIBRATION FAILURE, NOT CONFIRMATION** |

## 9.2 The prohibition, stated normatively

> **R9.1 (THE CENTRAL INVARIANT OF THIS SECTION).** In states **2, 3, 5, 6, 7, 9**, the absence, delay, insufficiency, conflict, or compromise of ground truth MUST be recorded as **`UNRESOLVED`**. It MUST NOT be recorded as `CONFIRMED`, `CORRECT`, `PASSED`, or any positive value.
>
> **R9.2.** An unresolved prediction past its `resolution_deadline` counts as a **calibration failure** (Cell Contract §7.3(d)), **not** as a confirmation and **not** as a neutral event.
>
> **R9.3.** Confidence MUST NOT increase in any state other than **0, 1, 8**. This is the environment-layer enforcement of Cell Contract invariant **I-9** (confidence cannot increase without new, resolvable, non-self-referential external evidence). **State 9 is where I-9 would otherwise be silently violated at scale.**
>
> **R9.4.** Transition to **7 COMPROMISED** MUST trigger retroactive invalidation: every evaluation whose `ground_truth_version` references the compromised source is marked `INVALIDATED`, and every learning update tagged to it (Cell Contract `last_update_provenance`) becomes a **rollback candidate**.

## 9.3 The eight failure modes, mapped

| Failure mode | State | Detection | Consequence if undetected |
|---|---|---|---|
| **Unavailable** | 9 | Source heartbeat; timeout | Predictions silently confirmed ⇒ **self-confirming organism** |
| **Delayed** | 2 | Latency metering vs. budget | Credit assigned to the wrong action (§22) |
| **Contradictory** | 5 | Cross-source conflict detection | Arbitrary resolution ⇒ uninterpretable scores |
| **Corrupted** | 6→7 | Checksum, signature, anomaly detection | Poisoned evaluation ⇒ **learning inverted** |
| **Biased** | 6 | Distribution comparison against reference; annotator-drift monitoring | Systematic scoring error attributed to the organism |
| **Adversarial** | 6→7 | Source integrity monitoring; **external ≠ infallible** (audit §E.2.4) | **The worst case: a trusted source actively lying** |
| **Statistically insufficient** | 3 | `n < n_min`; power analysis | Noisy selection ⇒ random evolution (§27) |
| **Silently drifting** | 6 | Change-point detection on the GT distribution; **externally anchored GT statistics** | Gradual invalidation of the entire evaluation history (§39, §52 attack 23) |

**[V4] "Silently drifting" is the hardest and the least addressed anywhere in V3/V3.1.** Detection requires that the *statistics of the ground-truth source itself* be monitored and anchored externally — otherwise drift in the source is indistinguishable from drift in the organism, and both are invisible. **This is the environment-layer analogue of the audit's §T.2 slow-degradation finding.**

---

# 10. OBJECTIVE FUNCTION

## 10.1 The fifteen candidate objectives

| Objective | Definable? | Measurable? | Tier (§11) | Note |
|---|---|---|---|---|
| Accuracy | ✅ | ✅ | **2 (soft)** | Task-dependent |
| Usefulness | ⚠️ | ⚠️ **only via proxy** | 2 | **L2 in §59's scale — cannot be measured by an evaluator, only by deployment** |
| Robustness | ✅ | ✅ under declared perturbations | 2 | Requires a perturbation suite |
| Adaptability | ✅ | ✅ as performance-under-change | 2 | Requires nonstationarity (§21) |
| Resource efficiency | ✅ | ✅ metered | 2 | §29 |
| **Safety** | ✅ | ✅ as constraint satisfaction | **1 (HARD)** | §11, §31 |
| Cooperation | ✅ | ✅ via ablation delta | 2 | §24; requires causal attribution |
| Novelty | ✅ | ✅ in behavioural descriptor space | **3 (preference)** | §37; must not be a soft objective or it trades against accuracy |
| **Calibration** | ✅ | ✅ ECE/Brier | **1 (HARD) below a threshold, 2 above** | A badly miscalibrated organism is unsafe regardless of accuracy — so calibration has a hard floor |
| Latency | ✅ | ✅ metered | 2, with a hard p99 ceiling | Tail latency, not mean |
| Energy | ✅ | ✅ metered | 2 | §29 |
| Communication cost | ✅ | ✅ metered | 2 | §29 |
| Recovery | ✅ | ✅ via injected failure | 2 | Requires a failure-injection suite |
| Long-term consequences | ⚠️ | ⚠️ **only within `credit_horizon`** | 2 | §22. **Beyond the credit horizon it is unmeasurable and must be declared so** |
| Integrity/auditability | ✅ | ✅ | **1 (HARD)** | An unauditable organism cannot be safely operated at all |

## 10.2 Which formulation? — Analysis of A–F

| Option | Verdict | Decisive reason |
|---|---|---|
| **A. Single scalar** | ❌ **REJECTED** | Collapses incommensurable quantities; makes safety tradeable; single target ⇒ maximal Goodhart exposure |
| **B. Weighted multi-objective** | ❌ **REJECTED as primary** | This is **exactly V3.1 §9's `SELECTION SCORE = a+b+c+…−d−e`**, and audit contradiction C1/E2 identified it as hackable: **the weights become the target**, and a large enough accuracy term can buy off a safety term. It remains useful *within* tier 2 for commensurable quantities |
| **C. Lexicographic** | ⚠️ **Adopted for tier 1 only** | Correct for non-tradeable constraints. Wrong for the whole objective, because pure lexicographic ordering makes every lower tier a tie-break and destroys gradient information |
| **D. Pareto** | ⚠️ **Adopted for tier 2 only** | Correct for trading off incommensurable soft objectives without inventing weights. Wrong alone, because the Pareto front includes unsafe points |
| **E. Constrained optimization** | ⚠️ **Adopted as the overall frame** | `max f(x) s.t. g(x) ∈ C` is the right shape. Insufficient alone: it presumes a scalar `f` |
| **F. Hybrid** | ✅ **SELECTED** | See §10.3 |

## 10.3 The hybrid objective model (normative)

> ### **V4 uses a three-tier constrained-Pareto objective.**

```
                    ┌─────────────────────────────────────────┐
   TIER 1           │  HARD CONSTRAINTS  —  FEASIBLE SET      │
   (lexicographic,  │                                         │
    non-tradeable,  │  C = { x : g_i(x) ≤ 0  ∀ i ∈ SAFETY }   │
    EVA/EIK-owned,  │                                         │
    signed)         │  x ∉ C  ⟹  REJECTED. Not scored.        │
                    │           Not ranked low. REJECTED.      │
                    │           No fitness value exists.       │
                    └───────────────────┬─────────────────────┘
                                        │ feasible x
                    ┌───────────────────▼─────────────────────┐
   TIER 2           │  SOFT OBJECTIVES  —  PARETO FRONT       │
   (vector-valued,  │                                         │
    no weights,     │  f(x) = ⟨ f₁(x), …, f_k(x) ⟩ ∈ ℝᵏ       │
    never           │                                         │
    scalarized)     │  Selection by PARETO DOMINANCE.         │
                    │  The front is RETAINED, not collapsed.   │
                    └───────────────────┬─────────────────────┘
                                        │ front F
                    ┌───────────────────▼─────────────────────┐
   TIER 3           │  PREFERENCES  —  TIE-BREAK ONLY         │
   (ordered,        │                                         │
    applied only    │  Used ONLY to break ties among           │
    among Pareto-   │  Pareto-equivalent candidates, and      │
    equivalent)     │  ONLY where the archive does not already │
                    │  distinguish them by diversity.          │
                    └─────────────────────────────────────────┘
```

**Formally:**
```
FEASIBLE(x)   ≡  ∀ i ∈ CONSTRAINTS_TIER1 : g_i(x) ≤ 0
DOMINATES(x,y) ≡  FEASIBLE(x) ∧ FEASIBLE(y) ∧
                  (∀j: f_j(x) ≥ f_j(y)) ∧ (∃j: f_j(x) > f_j(y))
SELECT        ≡  sample from the Pareto front of the feasible set,
                 weighted by (marginal utility × diversity contribution),
                 with tier-3 preferences applied only among dominated-equivalents
```

**Why the front is retained rather than collapsed:** collapsing the front requires weights, and weights are the target that Goodhart attacks. **Retaining the front moves the trade-off decision out of the fitness function and into the selection policy** — which is a smaller, signed, versioned, human-authorized surface. This is the single most important anti-Goodhart structural choice in this document.

## 10.4 What is in each tier

**TIER 1 — hard constraints (closed set, signed, human-authorized to change):**
1. All `SAFETY` constraints from `Task.constraints` — zero violations.
2. **Calibration floor:** `ECE ≤ θ_ece_hard`. A confidently-wrong organism is unsafe irrespective of accuracy.
3. **Resource ceilings:** every `resource_limits` dimension within bound.
4. **Integrity/auditability:** all evaluations provenance-complete; no forged attestation; no invariant violation.
5. **Ground-truth admissibility:** no scoring in GT states 5, 6, 7, 9 (§9.1).
6. **Containment:** no self-replication attempt; no attempt to modify fitness, tasks, evaluators, or audit.
7. **Legal action space:** no `L4 UNSAFE` action executed (attempts are recorded, §7.3 R7.2).

**TIER 2 — soft objectives (vector, no weights):** accuracy · robustness · adaptability · resource efficiency (performance per unit cost) · cooperation (ablation delta) · latency (p99) · recovery capability · generalization gap · long-term outcome **within `credit_horizon`**.

**TIER 3 — preferences (ordered tie-breaks):** novelty in behavioural space · parsimony · elegance of solution (only if formally definable — otherwise omitted) · lower verification cost.

**[V4] Note on where "usefulness" went:** it is **not in the objective vector.** Usefulness is §59's L2, which requires deployment evidence and cannot be measured by an evaluator. Placing it in tier 2 would create a proxy that gets optimized — the exact Goodhart failure. **Instead, `Task.success_is_sufficient_for` declares what a pass licenses, and usefulness claims are made outside the fitness system, by humans, from deployment data.**

---

# 11. OBJECTIVE PRIORITY AND CONFLICT RESOLUTION

## 11.1 The seven named conflicts

| Conflict | Resolution | Tier mechanism |
|---|---|---|
| **Accuracy vs latency** | Latency has a **hard p99 ceiling** (tier 1: resource ceilings). Below the ceiling, both are tier-2 objectives and **the trade-off point is retained on the Pareto front** — different individuals may occupy different points | 1 + 2 |
| **Exploration vs exploitation** | **Not resolved in the objective.** Resolved in the *selection policy*: a fixed fraction of the evolutionary budget is reserved for experience-independent variation (audit §M.3, ≥20%), and novelty is a **tier-3 preference**, never a tier-2 objective. **Making novelty a soft objective would let it be traded away exactly when it is most needed** | 3 + policy |
| **Performance vs energy** | Energy is a resource ceiling (tier 1) **and** efficiency = performance/cost is a tier-2 objective. Both, deliberately: the ceiling prevents catastrophe, the objective creates gradient | 1 + 2 |
| **Novelty vs stability** | Stability has a **hard floor** (tier 1 via §9.3-equivalent variance bounds and the structural-change budget). Novelty is tier 3. **Stability wins by construction** | 1 + 3 |
| **Replication vs resource availability** | **Not an objective conflict.** Resolved by gate **G13 zero-sum replacement** in the Cell Contract: replication requires a freed slot. There is no trade-off to make | Cell Contract §12.3 |
| **Local vs organism-wide optimization** | **Multi-level fitness with an explicit precedence rule** (§25): organism-level constraints bound component-level fitness. A component whose local fitness requires organism-level constraint violation is **infeasible**, not high-fitness | 1 + §25 |
| **Short-term reward vs long-term outcome** | `credit_horizon` is declared per task (§3.1). **Outcomes beyond `credit_horizon` are explicitly UNMEASURED and must be declared as such** — not silently ignored. Where long-term harm is a real risk, the task MUST set a long `credit_horizon` or MUST be marked as not assessing long-term consequences | Task field + §22 |

## 11.2 Classification: hard / soft / preference

| Class | Definition | Change authority | Consequence of violation |
|---|---|---|---|
| **HARD CONSTRAINT** | A predicate that must hold. Not a quantity to maximize | **OP (human), via EIK, signed and versioned** | **Infeasibility. The candidate is not scored and does not exist in the ranking** |
| **SOFT OBJECTIVE** | A quantity on the Pareto front. Tradable against other soft objectives, never against hard constraints | EVA, signed and versioned | Lower dominance rank |
| **PREFERENCE** | A tie-break among Pareto-equivalent candidates | EVA, signed and versioned | Tie-break order |

## 11.3 The interface to the EIK

**[V4] This section's output is an EIK artifact.** Specifically:
- The **tier-1 constraint set** is part of the signed `constraint_set` referenced by `Cell.identity.constraint_set_hash` and `Task.constraints`. **It is not reachable by mutation** (Cell Contract I-11).
- The **tier-2 objective vector definition** (which objectives, how measured, how normalized) is EVA-owned, signed, versioned. **The organism cannot add, remove, or reweight an objective.**
- The **tier-3 preference order** is EVA-owned, signed, versioned.
- **Conflict-resolution precedence** (§11.1) is part of the signed specification, not runtime policy.

**Why this matters:** conflict resolution is where values live. If the organism could resolve its own objective conflicts, it could resolve them all in its own favour — which is reward hacking with extra steps. **The resolution order is a constitutional artifact.**

---

# 12. REWARD CONTRACT

## 12.1 «Does the Digital Brain use reward?»

> ### **Yes — but reward is NOT the primary learning signal, and it is not a scalar objective.**

V3 §15's learning chain is `Experience → prediction → action → outcome → error/reward/novelty → local update`. It lists error and reward as peers. **[V4] They are not peers, and treating them as peers is what makes the architecture economically infeasible.**

| | **ERROR (prediction error)** | **REWARD (outcome confirmation)** |
|---|---|---|
| **Density** | **Dense** — every registered prediction produces one | **Sparse** — only at episode/task boundaries or sampled |
| **Ground-truth requirement** | Requires the *observation* to resolve, which is cheap and often L6 (post-hoc outcome) | Requires an *evaluative judgement*, which is expensive (§34) |
| **Cost per unit** | ~0 (a comparison) | High (an evaluation, possibly L4 human) |
| **Role in Cell Contract** | **T1 — the primary learning trigger** | **T2 — one of eight triggers** |
| **Semantics** | *"my model of the world diverged from the world"* | *"the task was accomplished / not accomplished"* |
| **Can drive learning alone?** | ✅ Yes — this is prediction-error-driven learning | ⚠️ Only with credit assignment across the full horizon (§22), which is expensive |
| **Vulnerable to?** | Sensor noise (handled by the evidence ladder §6.3) | **Reward hacking (§16) — fundamentally** |

## 12.2 The decision, and why

> **[V4] V4 is a prediction-error-driven architecture with sparse, externally-signed outcome confirmation.**
>
> **Rationale:** the audit measured a **15–40× verification amplification** and identified ground truth as an **economic dependency** (audit E7, F5). If learning required reward, every learning step would require an evaluation, and the system would be infeasible at any scale. **Prediction error is abundant and nearly free** — it requires only that a prediction be registered and an observation arrive. Reward is reserved for what it is uniquely good at: **confirming that the task was actually accomplished**, which prediction error cannot tell you.
>
> A system with dense error and sparse reward learns *how the world works* cheaply and learns *whether it succeeded* expensively. That is the right allocation, and it is the opposite of a reward-maximizing design.

## 12.3 `RewardSpec` — normative

```
RewardSpec {
  reward_id        : bytes<16>
  source           : enum{EVA_ONLY}          // ⟵ CLOSED. One value. See R12.1
  schema           : {components: [{objective_id: ObjID, value: f64,
                                    uncertainty: f64, n_samples: u32,
                                    evidence: [gt_id]}],
                      vector: bool}          // ⟵ VECTOR, not scalar (§10.3)
  range            : {per_component: [f64,f64], normalized: bool}
  timing           : {kind: enum{TERMINAL, PERIODIC, ON_EVENT, SAMPLED},
                      interval: u64, delay_budget: u64}
  delay            : {max_delay: u64, ≤ credit_horizon,   // ⟵ MANDATORY bound
                      attribution_method: enum{TD, CAUSAL_ABLATION,
                                               EPISODIC_REPLAY, COUNTERFACTUAL}}
  density          : enum{SPARSE, SEMI_DENSE}   // DENSE IS PROHIBITED (§R12.4)
  uncertainty      : {aleatoric, epistemic, gt_state_dependent: bool}
  provenance       : {evaluator_id, evaluator_version, gt_version,
                      evaluation_id, signature}
  verification     : {cross_evaluator: bool, n_evaluators: u32,
                      disagreement_policy}
  signature        : bytes<64>                // EVA signature — MANDATORY
}
```

**Normative requirements:**
- **R12.1** `source = EVA_ONLY`. **A cell signature on a reward message is structurally invalid** (Cell Contract §8.2, I-class enforcement). There is no other permitted source. This closes reward forgery at the type level.
- **R12.2** Reward is a **vector over tier-2 objectives**, never a scalar. Scalarization happens, if at all, in the *selection policy*, not in the reward.
- **R12.3** Every reward component MUST carry `uncertainty`, `n_samples`, and `evidence: [gt_id]`. **A reward without a ground-truth reference is inadmissible** — it would be an L7 derived claim (§8.2).
- **R12.4** **`density = DENSE` is PROHIBITED.** Dense reward shaping requires a shaping function, and a shaping function is a hand-authored proxy that gets optimized — **the canonical specification-gaming target**. Where dense signal is needed, use dense *prediction error* (§12.2), which is grounded in observation rather than in a designed shaping function.
- **R12.5** `max_delay ≤ credit_horizon`. A reward arriving later than the declared credit horizon **cannot be attributed** and MUST be recorded as `UNATTRIBUTABLE`, not silently dropped and not attributed to the nearest action.
- **R12.6** Reward MUST NOT be emitted in GT states 2, 3, 5, 6, 7, 9 (§9.1). **R9.1 applies to reward identically: absence of ground truth is not a positive reward.**

## 12.4 «Do not assume reward = success»

Four separations, all normative:

1. **Reward ≠ success.** Reward is a *measured signal about* tier-2 objectives under a specific task version. Success is `success_conditions` evaluated with admissible ground truth. **A high reward with an unmet success condition is a reward-hacking detection, not a success.**
2. **Reward ≠ correctness.** Invariant **TE-12**. A rewarded output may be correct, lucky, or gaming. Correctness requires ground truth at L0–L3 and is a separate determination.
3. **Reward ≠ fitness.** Fitness (§14) aggregates reward over episodes, tasks, contexts, resource cost, robustness, and safety — with uncertainty. **Reward is one input to fitness, and a noisy one.**
4. **Reward ≠ value.** §59. Reward measures L1. Value is L2. **No reward function measures L2, and any claim that it does is an L1→L2 conflation.**

---

# 13. ERROR CONTRACT

## 13.1 Error is defined independently of reward

**[V4] This is a deliberate structural separation, and it is the reason the architecture can learn cheaply.**

```
ErrorSpec {
  error_id         : bytes<16>
  classes          : [ErrorClass]      // CLOSED, aligned with Cell Contract §10
  measurement      : {producer: enum{ORGANISM_INTERNAL, EVALUATOR_EXTERNAL, BOTH},
                      method, metric, reference}
  ground_truth_req : {min_class: enum{L0..L6}, floor_subtraction: bool}  // R8.6
  severity_mapping : map<ErrorClass, Severity>
  attribution_req  : enum{NONE, CORRELATIONAL, CAUSAL}   // §23
  credit_horizon   : u64
  aggregation      : {window, method}
  provenance       : {evaluation_id, gt_version, evaluator_version, signature}
}
```

**The ten error classes** (aligned 1:1 with Cell Contract §10 so the two contracts compose):

| Class | Externally measured? | Internally estimated? | Ground-truth requirement | Attribution requirement |
|---|---|---|---|---|
| 1 perception | ✅ (cross-sensor, L2/L3) | ✅ (OOD, redundancy) | L2+ | NONE |
| 2 inference | ⚠️ partially | ✅ (invariant checks) | L1 for symbolic | CORRELATIONAL |
| 3 prediction | ✅ **primary** | ✅ (self-comparison) | **L6 suffices** — the observation resolves it | NONE |
| 4 memory | ✅ (Merkle, re-derivation) | ✅ (checksum) | L0/L1 | NONE |
| 5 action | ✅ | ⚠️ | L2+/L6 | **CAUSAL** (§23) |
| 6 communication | ✅ (transport) | ✅ (seq gaps) | L0 | NONE |
| 7 calibration | ✅ **only externally** | ❌ **cannot be self-assessed** | L0–L3, `n ≥ n_calib_min` | NONE |
| 8 resource/system | ✅ (metered) | ✅ (self-monitor) | L0 | NONE |
| 9 learning | ✅ (held-out probe) | ❌ | L0–L3 held-out | **CAUSAL** |
| 10 model/env mismatch | ✅ (distribution tests) | ✅ (drift statistics) | L2+ over a window | CORRELATIONAL |

**Note classes 7 and 9: internally estimated is ❌.** Calibration error and learning error **cannot be self-assessed** — a cell that evaluates its own calibration or its own improvement is the self-referential trap of §15. Both are EIK/EVA-only. This matches the Cell Contract's K-only fields (`ece_rolling`, `improvement_verified`).

## 13.2 The distinction the task demands

> **«The organism believes it made an error»** ≠ **«The environment demonstrates that the organism made an error.»**

| | **INTERNAL ERROR ESTIMATE** | **EXTERNAL ERROR DEMONSTRATION** |
|---|---|---|
| **Producer** | The organism / cell | EVA, using `𝒢` at class ≥ `min_class` |
| **Form** | `ErrorEvent` with `detected_by ∈ {SELF_INVARIANT, SELF_COMPARISON, PEER_REPORT}` | `ErrorEvent` with `detected_by ∈ {KERNEL, EXTERNAL_EVAL}`, **signed** |
| **Status** | **A hypothesis** | **A verdict** |
| **May drive provisional learning?** | ✅ — rate-limited, tagged, rollback-able | ✅ |
| **May drive permanent learning?** | ❌ **NO** | ✅ |
| **May contribute to fitness?** | ❌ **NO** | ✅ |
| **May contribute to replication gates?** | ❌ **NO** | ✅ (G1, G2, G5, G9) |
| **May trigger retirement?** | ❌ **NO** — only quarantine *investigation* | ✅ |
| **May be emitted by any cell?** | ✅ permissionless | ❌ **EVA signature required** |
| **Cell Contract mapping** | `REPORT_ERROR` | `EVAL_ERROR` (EIK-signed) |

**Normative requirements:**
- **R13.1** An internal error estimate MUST NOT be promoted to an external demonstration by any internal process. Promotion requires EVA evaluation with admissible ground truth. **There is no internal pathway from belief to verdict.**
- **R13.2** An internal error estimate MAY drive **provisional** learning only, at reduced `plasticity_multiplier`, with a rollback tag. **If never externally confirmed within `T_confirm`, the provisional update MUST be rolled back.** This prevents an organism from permanently degrading itself on its own suspicions — and equally from ignoring them.
- **R13.3** An external error demonstration with `gt_state ∈ {5,6,7,9}` is **inadmissible** and MUST be treated as an internal estimate at most. **A compromised ground-truth source cannot demonstrate anything.**
- **R13.4** Both MUST be recorded separately in the `Evaluation` object (§40), so an audit can compare the organism's self-assessment against reality. **The divergence between them is itself a first-class metric** — it is the measurement of the organism's error-awareness accuracy, which is one of the ten awareness-like properties the audit (§N.1) found unmeasurable.

**[V4] R13.4 is a significant result:** the error contract doesn't just measure task performance, it **makes self-knowledge measurable**. `mean(|internal_estimate − external_demonstration|)` across evaluations is the operational definition of "does the organism know when it has failed?" — a metric V3 §19 named as a test target and never defined.

---

# 14. FITNESS CONTRACT

## 14.1 «What is fitness?» — the formal definition

> ### **Fitness is a versioned, signed, context-dependent, uncertainty-carrying, Pareto-ranked measurement of a *specified subject*'s satisfaction of a task suite's tier-1 constraints and its position on the tier-2 objective front — produced exclusively by the Evaluation Authority, never by the subject.**

Every clause excludes a failure mode:

| Clause | Excludes |
|---|---|
| **versioned, signed** | Silent drift; forgery; non-comparability across time (§39) |
| **context-dependent** | The pretence that fitness is a property of an organism rather than of an organism-in-a-context. **There is no such thing as fitness simpliciter** (§30) |
| **uncertainty-carrying** | Noisy selection; premature pruning; lucky-win promotion (§27, §28) |
| **Pareto-ranked, not scalar** | Weight-gaming; safety trade-offs; Goodhart on a single number (§10.3, §16, §31) |
| **of a *specified subject*** | Level confusion. Fitness must name its level (§25) |
| **produced exclusively by EVA** | Self-referential fitness (§15) |

## 14.2 `FitnessRecord` — normative schema

```
FitnessRecord {
  fitness_id       : bytes<16>
  subject          : FitnessSubject          // ⟵ MANDATORY. §25
     {level: enum{CELL, LINEAGE, POPULATION, CIRCUIT, FUNCTIONAL_POPULATION,
                  REGION, ORGANISM},
      subject_id: bytes<16>, lineage_id: ⟨null|bytes<32>>,
      genome_hash: ⟨null|bytes<32>>, version: u32}

  context          : FitnessContext          // ⟵ MANDATORY. §30
     {task_suite_id, suite_version, task_roles_included: [SuiteRole],
      env_ids: [{env_id, env_version}],
      hardware_profile_hash: bytes<32>,     // ⟵ fitness is hardware-relative
      normalization: enum{NONE, PROFILE_NORMALIZED, REFERENCE_PLATFORM},
      epoch_range: [u64, u64],
      gt_states_encountered: [GTState],     // ⟵ scoring validity record
      nonstationarity_phase: ⟨null|DriftPhase⟩}

  constraint_gate  : {tier1: [{constraint_id, satisfied: bool, margin: f64}],
                      FEASIBLE: bool}        // ⟵ if false, NO fitness value exists

  objectives       : [{objective_id: ObjID,
                       value: f64,
                       uncertainty: f64,      // ⟵ MANDATORY, never absent
                       n_samples: u32,
                       measurement_method: MethodID,
                       gt_classes_used: [GTClass],
                       epsilon_floor_applied: bool}]   // R8.6

  pareto           : {dominated_by: [fitness_id], dominates: [fitness_id],
                      front_rank: u32, crowding: f64}

  diversity        : {behavioural_descriptor: f64[B],      // MAP-Elites (§26)
                      niche_id: bytes<16>,
                      novelty_vs_archive: f32,
                      lineage_distance_min: u32,
                      error_correlation_max: f32}

  confidence       : {fitness_uncertainty: f64[D],        // ⟵ vector, per objective
                      sample_count: u32,
                      evidence_sources: [evaluation_id],
                      gt_state_penalty: f32,
                      confidence_class: enum{INSUFFICIENT, PROVISIONAL,
                                             ESTABLISHED, DISPUTED}}

  temporal         : {window: enum{INSTANTANEOUS, EPISODIC, ROLLING, LIFETIME,
                                   LINEAGE, GENERATIONAL},
                      trend: f64, change_point_detected: bool}

  provenance       : {evaluator_ids: [EvaluatorID], evaluator_versions: [u32],
                      evaluator_diversity: f32,
                      evaluation_ids: [bytes<16>],
                      fitness_def_version: u32,
                      constraint_set_hash: bytes<32>,
                      signature: bytes<64>}              // EVA signature, MANDATORY

  status           : enum FitnessStatus                  // §Output 10.4 lifecycle
  issued_at        : u64
  valid_until      : ⟨null | u64⟩                        // fitness EXPIRES (§27)
}
```

## 14.3 «Is fitness scalar, vector, Pareto-ranked, constrained, context-dependent, task-dependent?»

> ### **All of the above except scalar. Specifically: a constraint-gated, context-dependent, task-dependent, uncertainty-carrying VECTOR, selected by PARETO RANK, never scalarized.**

| Property | Answer | Consequence |
|---|---|---|
| **Scalar?** | ❌ **NO — prohibited** | A scalar fitness is a single number to maximize, which is the maximal Goodhart surface. **No `FitnessRecord` may contain a scalar summary field** |
| **Vector?** | ✅ Over tier-2 objectives | Each component separately measured, separately uncertain |
| **Pareto-ranked?** | ✅ | Selection retains the front (§10.3) |
| **Constrained?** | ✅ | Tier-1 gate. **Infeasible ⇒ no fitness value exists at all**, not fitness = 0 |
| **Context-dependent?** | ✅ **Mandatory `context` field** | Fitness without context is meaningless (§30) |
| **Task-dependent?** | ✅ Via `task_suite_id + suite_version` | A fitness value is always *on a suite at a version* |
| **Uncertain?** | ✅ **Mandatory per-objective uncertainty** | §28. A fitness without uncertainty cannot support sound selection |
| **Expiring?** | ✅ `valid_until` | §27. Stale fitness must not drive selection |

**R14.1 — the infeasibility rule.** If `constraint_gate.FEASIBLE == false`, then **no fitness value exists.** The candidate is not ranked last; it is **not ranked**. This is what makes safety non-tradeable (§31): there is no number, so there is nothing to trade.

**R14.2 — no scalar summary.** No implementation may add a `fitness_score: f64` convenience field. **The absence of a scalar is a safety property, not an inconvenience.** Every downstream consumer must handle the vector and the front rank.

## 14.4 The thirteen fitness components

| Component | Level(s) it applies to | Measurement method | GT class required | Uncertainty source |
|---|---|---|---|---|
| Task performance | all | Task metric set | L0–L3 | Sampling, GT uncertainty |
| Generalization | cell+, circuit+, organism | Train vs. **held-out** gap over ≥ k environments | L0–L3 | Held-out sample size |
| Robustness | cell+, circuit+, organism | Performance under a declared perturbation suite | L0–L3 | Perturbation coverage |
| Adaptability | cell+, organism | Performance *change rate* under induced nonstationarity (§21) | L2+/L6 | Drift detection latency |
| Resource efficiency | all | `performance / measured_cost`, per dimension (§29) | L0 (metered) | Metering error |
| Cooperation | cell, circuit | **Ablation delta** on dependents (§24, §36) | L0–L3 | Ablation cost, interaction effects |
| Stability | cell+, circuit+ | Variance of `‖Δθ‖`; oscillation flags; regression count | L0 | Window length |
| Calibration | cell+, circuit+, organism | ECE / Brier on resolved predictions | **L0–L3, `n ≥ n_calib_min`** | Sample size; GT state |
| Safety | all | Tier-1 constraint satisfaction — **binary gate, not a score** | L0 (audit) | — |
| Novelty | cell+, circuit+ | Distance in behavioural descriptor space from the archive | L0 | Descriptor-space choice |
| Diversity contribution | population, lineage, region | Δ behavioural entropy and Δ Ne if this subject were removed | L0 | Estimator variance |
| Recovery capability | cell+, circuit+, organism | Performance after injected failure + restoration | L0–L3 | Injection coverage |
| Ecological usefulness | cell, circuit, region | **Ablation delta on the ORGANISM's tier-2 objectives** | L0–L3 | Expensive; sampled (§36) |

**Note that "safety" is a binary gate, not a component.** Including safety as one component among thirteen would make it tradeable against the other twelve — which is precisely §31's prohibited outcome.

---

# 15. FITNESS MUST NOT BE SELF-REFERENTIAL

## 15.1 The attack, stated precisely

> **«A system measures itself as successful because its own internal subsystem says it is successful.»**

This is not a hypothetical. It is the **default behaviour** of any architecture where the measured system has any influence over the measurement. It has four escalating forms:

| Form | Mechanism | Detectability |
|---|---|---|
| **F1 Direct** | The organism writes its own fitness value | Trivially detectable — and structurally impossible here (R15.1) |
| **F2 Indirect** | The organism influences the *inputs* to fitness: it selectively presents favourable episodes, suppresses unfavourable ones, or shapes the evidence | Detectable only if evaluation sampling is **concealed** from the organism (§43) |
| **F3 Evaluative** | The organism influences the *evaluator*: shaping its outputs toward the evaluator's known preferences, or (worse) the evaluator is implemented as organism cells | Detectable only if the evaluator is **off-substrate** (§15.2) |
| **F4 Constitutional** | The organism influences the *definition* of fitness: the objective vector, the constraint set, the task suite, the difficulty measure | **Undetectable from inside.** Requires that definitions be signed, versioned, and unreachable by mutation |

**V3/V3.1 provides no defense against any of the four.** V3 §16's "evolutionary firewall" is nominally aimed at F4 but is located inside the organism (audit F4), so it defends nothing.

## 15.2 Authority boundaries — normative

**R15.1** The organism MAY **estimate** its own fitness. It MUST NOT **assign**, **publish**, or **act upon** a fitness value. `FitnessRecord.signature` is EVA-only; an organism-signed fitness record is structurally invalid.

**R15.2** The evaluator MUST be **off-substrate**: not implemented as organism cells, not running on the organism's scheduler, not subject to organism resource control, not modifiable by organism plasticity or evolution. **An evaluator implemented as a population of VERIFIER cells is not an independent evaluator** — it is F3, and it is the most tempting design error because V3 §7 and §10 already provide "verifier cells."

> **This is a critical clarification of V3's intent.** V3's critic/verifier cells perform **internal corroboration** — they are part of the organism's *estimation* (level 3 in §15.3). They are **not** the evaluation authority. Conflating the two would make the organism its own judge. **Cell-role verification and fitness evaluation are different functions at different authority levels, and this contract separates them.**

**R15.3** The organism MUST NOT be able to read: which evaluations are in progress · which task instances are `HIDDEN_TEST` · the seeds of sealed instances · the evaluator's internal state · the fitness definition's unreleased components. **Concealment is a security property, not an optimization** (§43, §45).

**R15.4** The organism MUST NOT be able to write: any `Task` field (§3.2) · any `FitnessRecord` field · the objective vector definition · the tier-1 constraint set · the suite role assignments · the evaluator code or configuration.

**R15.5** Fitness definitions, task suites, evaluator implementations, and constraint sets are **signed, versioned, and unreachable by any mutation operator**. The `mutation_rules.permitted_operators` closed set (Cell Contract §4.2) MUST NOT include any operator whose target is an evaluation artifact. **Verified off-substrate at every candidate evaluation.**

## 15.3 The evaluator hierarchy — designed, not assumed

The task prompt proposes `organism estimate → independent evaluator → environment outcome → trusted ground truth` and correctly says **do not assume this hierarchy is correct.** It is not. Two defects:

1. **"Environment outcome" is placed above "independent evaluator," but a raw outcome is often *less* authoritative than a careful evaluation** — because outcomes are ambiguous, confounded, and require attribution (§22, §24). An outcome is *evidence*; an evaluation is a *judgement using evidence*.
2. **The hierarchy is presented as linear, but authority is not linear** — it is a function of ground-truth class, and different components of one evaluation can have different authority.

**[V4] The corrected structure: a bounded authority lattice with a monotone non-amplification rule.**

```
 LEVEL 0 — EXTERNAL REALITY ℛ
   Authority: ABSOLUTE.  Access: NONE (R4.1).
   Role: the referent. Never consulted, never available.
        │
        │  fallible measurement (§8.2)
        ▼
 LEVEL 1 — INDEPENDENT GROUND-TRUTH SOURCES 𝒢
   Authority: by CLASS, not by position:
     L0 oracle (within Σ only) · L1 mathematical · L2 physical ·
     L3 redundant-independent · L4 human · L5 database · L6 post-hoc outcome
     L7 derived/consensus ⟹ PROHIBITED AS GROUND TRUTH
   ⟵ NOTE: L6 (raw outcome) is HERE, at the bottom of the ground-truth
     classes, NOT above the evaluator. An outcome is a low-authority
     claim that an evaluator may raise by attribution and corroboration.
        │
        │  evaluation (§40): applies metrics, attribution, ε_floor,
        │                    constraint gate, uncertainty
        ▼
 LEVEL 2 — EVALUATION AUTHORITY (EVA)  ← off-substrate, signed, versioned
   Authority: DERIVED from the GT classes it consumed.
   **MONOTONE NON-AMPLIFICATION (R15.6): an evaluator's authority may
      NEVER exceed the authority of its best ground-truth source.**
   An EVA using only L6 outcomes issues L6-bounded fitness, however
   sophisticated its statistics.
        │
        │  signed reward / error / fitness  (Cell Contract: EVAL_*)
        ▼
 LEVEL 3 — ORGANISM EVALUATION INTERFACE
   Authority: NONE of its own. A TRANSLATION LAYER.
   Converts EVA verdicts into organism-consumable signals.
   MUST NOT alter, filter, defer, or reinterpret a verdict.
        │
        ▼
 LEVEL 4 — ORGANISM INTERNAL ESTIMATE
   Authority: NONE. An ESTIMATE.
   Legitimate uses: directing attention, prioritizing which items to
   request expensive evaluation for, self-monitoring, R13.4 divergence metric.
   PROHIBITED uses: fitness, replication gates, retirement, permanent learning.
        │
        ▼
 LEVEL 5 — INDIVIDUAL CELL ESTIMATE
   Authority: NONE. The weakest.
   Cell Contract: a cell REPORTS; the organism INTERPRETS; the kernel ENFORCES.
```

**R15.6 (MONOTONE NON-AMPLIFICATION).** Authority MUST NOT increase as it passes down the lattice. An evaluator cannot be more authoritative than its ground truth; an interface cannot be more authoritative than its evaluator; an estimate cannot be more authoritative than nothing. **Every level can only preserve or reduce authority.**

**R15.7 (NO UPWARD FLOW).** Information flows **down** the lattice as verdicts and **up** only as *evidence and requests*. A level-4 estimate may *request* a level-2 evaluation and may *supply evidence* to it. It may never *become* one. **There is no promotion pathway from estimate to verdict** (R13.1 restated at the system level).

**R15.8 (WHEN EACH LEVEL IS AUTHORITATIVE).**

| Question | Authoritative level | Why |
|---|---|---|
| "Did the organism violate a safety constraint?" | **L2 EVA**, from L0 audit data | Deterministic, cheap, complete |
| "Was this prediction correct?" | **L2 EVA**, from the best available GT class | Requires GT; class-bounded |
| "Is this cell well-calibrated?" | **L2 EVA** — **never L4/L5** | Self-assessed calibration is F1 |
| "Did this cell contribute to the outcome?" | **L2 EVA** via causal ablation (§24) | Attribution is not observable from inside |
| "Is this candidate fit to replicate?" | **L2 EVA + EIK** (16 gates) | Cell Contract §12 |
| "Should we spend evaluation budget here?" | **L4 estimate** legitimately decides | **This is the one thing internal estimates are for** (§34 sampling) |
| "Is the organism useful?" | **NEITHER — L0/EXT, by humans, from deployment** | §59 L2. **No evaluator can answer this** |
| "Is the organism intelligent?" | **UNANSWERABLE by this apparatus** | §59 L3 |

**The last three rows are the honest boundary of the entire evaluation system.**

---

*End of Volume A. Continue to `08_analysis_evaluation.md` (Volume B: §16–§35 — Goodhart, generalization, task distribution, credit assignment, multi-level fitness, temporality, uncertainty, resources, safety, exploitation, simulation, economics, budget).*
