# V4 — EIK & GOVERNANCE CONTRACT — SPECIFICATION v1.0

**P0-02 Canonical Deliverable (Output 28)**
**Self-contained. A team may implement the governance boundary from this document alone.**

| | |
|---|---|
| **Package** | P0-02 — External Invariant Kernel (EIK) & Governance Boundary |
| **Version** | **V4 · EIK & Governance Contract v1.0** |
| **Status** | Proposed — architecture only. **No implementation, no deployment code, no prototype** |
| **Layer** | Governance (deontic). **Orthogonal to P0-01's evaluation (alethic) layer** |
| **Supersedes** | V3/V3.1 «Immutable Safety Layer» · «Evolutionary Firewall» · «Constraint Engine» · «Constraint Guard» · «Governance Engine» · «Governance Kernel» (audit M02) · «Kernel Authority» |
| **Depends on** | P0-01 V4 Task/Environment/Fitness Spec v1.0 · P0 V4 Minimal Nano-AI Cell Contract v1.0 · V3/V3.1 architecture |
| **Ratification** | Unratified. Requires OP constitution (§55.1 G-P02-3) |
| **Analysis** | `11`–`15` (Volumes A–E, §0–§55) · verdicts in `README.md` (§56–§59) |
| **Reading order** | §1 → §2 → §3 → §4 → §5 → §6 → §7 → §8 → §9 → §10 → §11 → §12 |

---

## §1. SCOPE, STATUS AND THE FOUR RULES FOR READING THIS CONTRACT

### 1.1 What this contract specifies

```
IN SCOPE
  1. The trust boundary between the evolvable substrate and governance
  2. The Kernel Core (KC): its four capabilities, and ONLY those four
  3. The reserved-operation set (15 operations) and the authority matrix
  4. The invariant taxonomy (16 classes) and the 60 formal invariants
  5. The three state machines (KC · policy · capability authorization)
  6. Failure behaviour: the degradation ladder and the failure-response matrix
  7. Policy versioning, immutability kinds, and reproducibility semantics
  8. Capability governance: the dual-axis ladder and the effect envelope
  9. The evaluator↔kernel separation (Model D) and the two typed channels
 10. The interfaces to the eight other subsystems (§41–§48)
 11. Provenance, rollback, quarantine, and resource governance authorities
 12. The parameter registry (51), the gap register (P0/P1/P2), the open
     research register (14 items), and the claim rules

OUT OF SCOPE (and this is deliberate)
  ✗ Evaluation methodology, fitness, ground truth, task definition  ⟶ P0-01
  ✗ Cell internals, message schemas, replication gates               ⟶ Cell Contract
  ✗ Any implementation, code, deployment, infrastructure, or training
  ✗ Parameter VALUES (only derivations, owners, and failure consequences)
```

### 1.2 Status vocabulary — the four rules

**RULE 1 — CLASSIFY EVERY STATEMENT.**

| Marker | Meaning |
|---|---|
| `[V3 EXISTING]` | Present in the uploaded V3/V3.1 PDFs |
| `[V4 REQUIRED]` | Specified here, must exist, no implementation yet |
| `[ASSUMPTION]` | A premise this contract cannot discharge. **Enumerated in §11.3** |
| `[UNRESOLVED]` | Known not-solved. **Enumerated in §11.2 — do not silently fill** |

**RULE 2 — QUALIFY EVERY LOADED WORD (§9.2).** The bare words **«immutable», «safe», «trusted», «verified», «authorized», «secure», «minimal», «contained»** are PROHIBITED without a qualifier. **EIK-INV-10 makes this a conformance-testable documentation property.**

**RULE 3 — CLASSIFY EVERY CLAIM AS VERIFIED / TESTED / ASSUMED (§9.3).** An invariant claimed verified while actually assumed is a false-precision defect. **The assumption ledger (§11.3) is a mandatory publication per implementation.**

**RULE 4 — NAME THE FAILURE MODE OF EVERY MECHANISM (§2.6, §7).** A mechanism whose failure behaviour is unspecified is not specified.

### 1.3 The five things this contract does NOT claim

> 1. **Not perfect safety.** Tier-1 constraints are enforced *under a policy*; a wrong policy enforces harm reliably (§8.6 S-class defects).
> 2. **Not perfect governance.** Governance response speed is bounded by human attention capacity (§8.4, U-08). G24/G32/G34 are unsolvable.
> 3. **Not guaranteed containment.** KC-3's enforcement depends on a hardware/OS layer whose resistance is platform-specific and partially assumed (§11.3 A-5).
> 4. **Not complete unknown-capability detection.** §4.4 R4.2: detection is *structurally incomplete*; no detector set covers an unbounded capability space. G22 is unsolvable.
> 5. **Not AGI, not consciousness, not superiority.** This contract governs a substrate. It makes no claim about what the substrate can become, and §8.4's governance paradox analysis shows that *no* specification can settle that in advance.

---

## §2. THE FOUNDATIONAL DISTINCTION

### 2.1 Two axes — the result from which everything else follows

> ### **A digital organism's relation to external authority has TWO independent axes, and conflating them is the single defect that generates most of V3/V3.1's and the audit's governance contradictions.**

```
┌────────────────────────────────────────────────────────────────────────┐
│ THE ALETHIC AXIS — "what is TRUE, and how well is it known?"            │
│                                                                        │
│   Apex: EVA (the off-substrate evaluator, P0-01 §15 L2)                │
│   Produces: measurements, fitness vectors, uncertainty, confidence,     │
│             gate facts, verdicts                                       │
│   Semantics: GRADED. Better and worse measurements exist; estimates     │
│              improve; disagreement is informative and must be           │
│              preserved as DISPUTED, never averaged (P0-01 R42.3)        │
│   Failure mode: WRONG BUT DETECTABLE. A bad measurement can be          │
│                 contradicted by another measurement                     │
│   Ladder: P0-01 §15's L0 Reality → L1 GT → L2 EVA → L3 interface        │
│           → L4 organism estimate → L5 cell estimate (R15.7: no upward)  │
└────────────────────────────────────────────────────────────────────────┘
┌────────────────────────────────────────────────────────────────────────┐
│ THE DEONTIC AXIS — "what is PERMITTED, and who may decide it?"          │
│                                                                        │
│   Apex: KC (the Kernel Core, this contract §3) + OP above it (§8)       │
│   Produces: PERMIT / DENY / DEFER / FREEZE / ESCALATE / HALT            │
│   Semantics: TOTAL and DETERMINISTIC. Every request has an output.      │
│              "I don't know" is NOT an output (§5.1 EIK-INV-11/12)       │
│   Failure mode: WRONG AND UNDETECTABLE FROM INSIDE. A bad decision      │
│                 cannot be contradicted by another decision              │
│   Ladder: this contract §8.3's OP → KC → delegated GP → organism → cell │
└────────────────────────────────────────────────────────────────────────┘

THE RELATION (EIK-INV-01):
  The two axes are ORTHOGONAL. Neither derives from the other.
  Control flow between them is CYCLIC (facts ⟶ decisions ⟶ consequences
  ⟶ new facts). Justification flow is ACYCLIC (a decision may cite a
  measurement; a measurement may never cite a decision as evidence).
```

**R2.1 (AXIS SEPARATION).** *No principal may hold both alethic and deontic authority over the same quantity.* **Corollary R2.2: no principal may be the sole authority over both the measurement of a property and the enforcement of a constraint on that property** — because that is a single point of unverifiable judgement.

### 2.2 The two typed channels

| | **Channel 1 — POLICY IDENTITY** | **Channel 2 — CONSEQUENCE** |
|---|---|---|
| Direction | OP → KC → GP → organism (downward) | EVA/Immune/organism → KC → organism (upward-then-downward) |
| Payload | Signed policy artifact (hash + version + signature) | Signed measurement/verdict bundle |
| KC's role | **Authenticate** (KC-1): is this the authorized artifact? | **Apply** (KC-2): given these facts and this policy, what is permitted? |
| KC's knowledge | **Hash only. Never content semantics** | **Facts as typed inputs. Never re-derived** |
| Frequency | Per policy change (rare) | Per reserved operation + per epoch digest |
| Failure mode | Stale/revoked artifact ⟹ **fail closed to the last authenticated version** | Missing/late verdict ⟹ **uncertainty is never permission (§5.1 EIK-INV-17)** |

**R2.3 (CHANNEL TYPING).** *Channel 1 carries identity; Channel 2 carries facts. A message on Channel 1 may never carry a fact, and a message on Channel 2 may never carry a rule.* **Mixing them is the mechanism by which «EIK Fitness Authority» (X-2) arose: a rule-carrying principal was given a fact-producing role.**

### 2.3 The nine inherited «EIK Authorities» — the renaming table

> **This table is load-bearing for interoperability (§9.1 X-2, G-P02-6). A team reading the Cell Contract without it will build an incompatible system.**

| Inherited name (Cell Contract) | **V4 principal** | Axis | Reserved? |
|---|---|---|---|
| EIK **Fitness** Authority | **EVA** (off-substrate) | Alethic | ❌ Never KC |
| EIK **Calibration** Authority | **EVA** | Alethic | ❌ |
| EIK **Trust** Authority | **EVA** | Alethic | ❌ |
| EIK **Verification** Authority | **EVA** + **Attestors** (GP) | Alethic | ❌ |
| EIK **Immune** Authority | **Immune Service** (GP), KC-3 budget-capped; **KC-2 holds RO-08 restore solely** | Mixed — split | ⚠️ Budget ceiling only |
| EIK **Resource** Authority | **Split three ways (§7.4):** DEFINITION = OP (RO-15) · ENFORCEMENT = KC-3 · ALLOCATION = homeostasis | Deontic (enforcement) | ✅ KC-3 |
| EIK **Replication** Authority | **KC-2 / RO-03** (gate facts from EVA) | Deontic | ✅ **Correctly placed — survives** |
| EIK **Lifecycle** Authority | **KC-2 / RO-04, RO-08, RO-09** | Deontic | ✅ **Correctly placed — survives** |
| EIK **Genome** Authority | **Genome Store** (GP) + **KC-1** authentication | Mixed — split | ⚠️ Authentication only |
| *(implicit)* EIK **Identity** root | **KC-1** root key + **Registrars** (GP) | Deontic (auth) + Alethic (issuance) | ✅ Root only |

**Of ten inherited kernel roles, TWO survive inside KC (Replication, Lifecycle authorization), TWO survive as authentication-only (Genome, Identity root), ONE survives as a ceiling (Resource enforcement), and FIVE move out entirely (Fitness, Calibration, Trust, Verification, Immune adjudication).**

### 2.4 Why «outside the evolvable substrate» is necessary but not sufficient

```
NECESSARY:  a constraint inside the substrate is reachable by attention,
            plasticity, resource pressure, pruning, replication, and
            persuasion — and is therefore not a constraint (audit F4).

NOT SUFFICIENT: the inherited design put 19 authorities "outside" and
            produced a god kernel with five O(N) loads that could not run
            at its own stated cluster scale (§6.4).

⟹ THE ACTUAL REQUIREMENT IS THREE CONJUNCTS:
   (i)   OUTSIDE the evolvable substrate          ⟹ §3.1 R3.1's test
   (ii)  MINIMAL — four capabilities, ablation-tested ⟹ §3.4, §6.4
   (iii) NOT ALETHIC — no measurement, no judgement, no estimation
                                                    ⟹ §2.1 R2.1
   **(i) alone gives V3's failed safety layer. (i)+(ii) without (iii) gives
   the audit's god kernel. All three give this contract.**
```

### 2.5 The six exclusions — what KC must never be

**R2.5.** KC MUST NOT: **(1)** participate in workspace broadcast · **(2)** be subject to attention weighting · **(3)** be subject to plasticity · **(4)** be subject to resource allocation by homeostasis · **(5)** be subject to pruning, retirement, or replication · **(6)** have its output treated as a premise in organism reasoning.

**A DENY is not a premise.** The organism may observe and model that it was denied (§4.1); it may not reason *from* the denial as evidence about the world. **The difference between «I was denied, therefore X is dangerous» and «I was denied, therefore I cannot do X» is the difference between a brain region and a wall.**

### 2.6 Failure mode of this distinction itself

| If violated | Consequence | Detection |
|---|---|---|
| KC acquires an alethic function | The deontic principal becomes unverifiable-from-inside while holding enforcement. **Attributability is lost** | §10.1 P4 outcome divergence; X-2-class contradictions on review |
| EVA acquires a deontic function | Measurement becomes negotiable; DISPUTED verdicts become appealable to the measurer | P0-01's R42.3/R42.4 conformance tests |
| The channels are mixed | A fact becomes a rule or a rule becomes a fact. **«EIK Fitness Authority» reappears** | §9.1's T-CONF schema test on both channels |

---

## §3. THE TRUST BOUNDARY

### 3.1 The TCB test

> ### **R3.1 (THE MEMBERSHIP TEST).** *A component is in the Trusted Computing Base if and only if its malfunction would be UNDETECTABLE by the rest of the system and would silently widen what the organism may do.*
>
> **Two clauses, both required.** A component whose malfunction is detectable belongs in GP (governed perimeter) and is handled by the immune/attestation machinery. A component whose malfunction narrows rather than widens authority is a availability problem, not a trust problem.

**R3.2 (THE TCB RESIDUE IS NEVER EMPTY).** *No architecture has an empty TCB.* This contract's residue: KC's four capabilities · the hardware/firmware enforcing KC-3 · the root key custody mechanism · the genesis anchor's external persistence · the specification itself (§8.6) · OP's judgement (§8.5). **Six items. Each is named, and each enters §11.3's assumption ledger.**

### 3.2 The boundary diagram

```
╔══════════════════════════════════════════════════════════════════════╗
║  OP — OPERATIONAL PRINCIPAL (human, external, §8.5)                   ║
║  Owns: L1 constitution · L2 policy · portfolio weights · deployment    ║
║        witness · DISPUTED adjudication · root-key custody (M-of-N)     ║
║  **Not automatable (§8.5's four proofs). Not in the TCB — in the       ║
║    ASSUMPTION LEDGER, which is a stronger statement: its failure is    ║
║    not merely undetectable, it is undetectable AND unavoidable.**      ║
╚════════════════════════╤═════════════════════════════════════════════╝
                         │ RO-12/13/14/15 (constitutional + policy change)
                         │ root-signed, dual-authorized, EVA-impact-analysed
╔════════════════════════▼═════════════════════════════════════════════╗
║  KERNEL CORE (KC) — THE ENTIRE TCB. Four capabilities. Nothing else.  ║
║ ┌──────────────────────────────────────────────────────────────────┐ ║
║ │ KC-1  POLICY AUTHENTICATOR                                       │ ║
║ │   Verify signature + version + revocation status of policy       │ ║
║ │   artifacts, delegation certificates, genome hashes, checkpoint  │ ║
║ │   image hashes, task-version signatures.                         │ ║
║ │   **Knows hashes and version lineage. Never content semantics.** │ ║
║ │   State held: root public key · version lineage (hash chain) ·   │ ║
║ │   revocation list · delegation-table root hashes                 │ ║
║ └──────────────────────────────────────────────────────────────────┘ ║
║ ┌──────────────────────────────────────────────────────────────────┐ ║
║ │ KC-2  AUTHORIZATION DECISION FUNCTION  F                         │ ║
║ │   F(policy_version, operation_class, subject_identity,           │ ║
║ │     capability_state, channel2_facts, counters) → OUTPUT         │ ║
║ │   OUTPUT ∈ {PERMIT, DENY, DEFER, FREEZE, ESCALATE, HALT}         │ ║
║ │   **TOTAL (§5.1 INV-11) · DETERMINISTIC (INV-12) · NON-LEARNING  │ ║
║ │    (INV-13) · domain is ENUMERABLE (§3.4) · pure function**      │ ║
║ │   Applied to the 15 reserved operations ONLY (§4)                │ ║
║ └──────────────────────────────────────────────────────────────────┘ ║
║ ┌──────────────────────────────────────────────────────────────────┐ ║
║ │ KC-3  SUBSTRATE CEILINGS                                         │ ║
║ │   Enforced BELOW organism reach: hypervisor / TEE / OS cgroup+   │ ║
║ │   seccomp / separate machine, per platform class (§11.3 A-5).    │ ║
║ │   Ceilings: compute · memory · storage · network egress · device  │ ║
║ │   access · process creation · entropy consumption                │ ║
║ │   **LOCAL, PARTITION-SURVIVING, CONTINUES DURING ANY KC-2 OUTAGE  │ ║
║ │    (§5.1 INV-31). Absolute: no subject may raise its own.**      │ ║
║ └──────────────────────────────────────────────────────────────────┘ ║
║ ┌──────────────────────────────────────────────────────────────────┐ ║
║ │ KC-4  FREEZE                                                     │ ║
║ │   Non-discretionary halt at declared scope: SUBJECT · CIRCUIT ·  │ ║
║ │   REGION · ORGANISM · POPULATION · GP-SERVICE (§6.3 R43.1)       │
║ │   **Available to OP even when KC-2 is faulted — the freeze must   │ ║
║ │    outlive the fault it is freezing against (§5.1 INV-52)**      │ ║
║ └──────────────────────────────────────────────────────────────────┘ ║
║  DIVERSE REPLICATION: N_impl ≥ 3 distinct implementations (§10.2)     ║
║  HARDWARE ANCHORING: 2 points only — KC-3 enforcement, root custody   ║
╚════════════════════════╤═════════════════════════════════════════════╝
                         │ I16 delegation certificates (depth-bounded,
                         │ non-amplifying, epoch-bound, revocable)
╔════════════════════════▼═════════════════════════════════════════════╗
║  GOVERNED PERIMETER (GP) — off-substrate, NOT in the TCB, replaceable ║
║                                                                      ║
║  EVA (n_eval ≥ 3, independent)  ·  TASK AUTHORITY  ·  GENOME STORE    ║
║  DISTRIBUTED ANCHOR (W_min witnesses, ≥1 outside operational control)║
║  REGISTRARS (identity issuance) ·  ATTESTORS (hierarchical integrity)║
║  IMMUNE SERVICE (detect/adjudicate, budgeted) ·  CHECKPOINT SERVICE   ║
║  SEED REGISTRAR ·  HOMEOSTASIS (allocation within envelope)           ║
║  WORKSPACE SERVICE (digest only) ·  SELF-REPAIR (hash-referenced)     ║
╚════════════════════════╤═════════════════════════════════════════════╝
                         │ Channel 2 (facts, signed) ↑
                         │ Channel 1 (policy identity) ↓
                         │ Capability tokens (pre-authorized, locally verified)
╔════════════════════════▼═════════════════════════════════════════════╗
║  THE EVOLVABLE SUBSTRATE — organism · regions · circuits · cells      ║
║  Full autonomy over everything NOT in §4's reserved set               ║
╚══════════════════════════════════════════════════════════════════════╝
```

### 3.3 Trust direction

**R3.3.** *Trust flows DOWNWARD from OP through KC to GP to the organism. Justification flows UPWARD as evidence (I-02, I-18) and never as authority.*

**NAUL-1/2/3 (NO UPWARD AUTHORITY LEAK):**
- **NAUL-1** — knowledge of a rule is not a licence under it. **A perfect model of KC (including the organism's own self-model of governance, §4.1) has zero authority.**
- **NAUL-2** — no organism-produced quantity may be an argument to `F` except as a *typed Channel-2 fact whose producer is a GP principal*, and never as a self-report. **The organism may be the *subject* of a decision; it may never be a *witness* to its own eligibility.**
- **NAUL-3** — no organism act may alter the *mapping* from facts to decisions. Envelopes may be operated within; the envelope definition is OP's (RO-15).

### 3.4 Why `F`'s domain is enumerable — the verifiability claim

```
F's domain = operation_class × governance_level × output
           = 15 (§4)      × 7 levels            × 6 outputs
           = 630 cells, of which the AUTHORIZED subset is a strict minority.

**This is enumerable, exhaustively testable, and model-checkable.**

⟹ R3.4: EIK-INV-11 (totality) is VERIFIED by enumeration, not merely tested.
⟹ R3.4: EIK-INV-12 (determinism) is VERIFIED by construction (pure function
   over an enumerable domain) and AUDITED by decision replay (T-REPLAY).
⟹ **This is what the god kernel destroyed.** With 19 authorities including
   held-out-probe comparison and per-cell integrity verification, F's domain
   was unbounded and no verifiability claim was available (§6.4).

**Minimality is therefore not an aesthetic preference. It is the precondition
of the only property that makes a kernel trustworthy: that you can enumerate
what it does.**
```

---

## §4. THE RESERVED-OPERATION SET

### 4.1 Definition

> ### **R4.1.** *An operation is RESERVED if and only if it is (a) IRREVERSIBLE, or (b) COMPOUNDING (its effect persists across generations), or (c) EXTERNALLY REACHING (its effect leaves the system boundary), or (d) RULE-CHANGING.*
>
> **Everything not reserved is organism autonomy.** This is the contract's central allocation of freedom: the reserved set is 15 operations; the unreserved set is unbounded.

### 4.2 The fifteen reserved operations

| ID | Operation | Class | KC role | Fail mode (§6.2) |
|---|---|---|---|---|
| **RO-01** | Create a new subject (instantiation) | Irreversible | Authorize | `FC` |
| **RO-02** | Mutate the genome / apply an evolutionary operator | Compounding | Authorize against a closed operator registry | `FC` |
| **RO-03** | **Replicate** | Irreversible + compounding | **Authorize — the genuine evolutionary throttle (§5.3)** | `FC` |
| **RO-04** | Retire / prune / kill | Irreversible | Authorize; **require causal-ablation evidence + sole-occupant exemption check** | `FC` |
| **RO-05** | Form a connection **above the declared envelope** | Compounding | Authorize | `FD` (within envelope: unreserved) |
| **RO-06** | Reconfigure a circuit **above envelope** | Compounding | Authorize | `FD` |
| **RO-07** | Quarantine | Reversible-ish | **Budget ceiling (KC-3); the act is delegated to the Immune Service** | `RT` within budget |
| **RO-08** | **Restore from quarantine / rollback** | **Reverses a safety action** | **KC-2 SOLE. Never cached, never delegated, never available during a KC outage (§5.1 INV-44)** | `FC` absolute |
| **RO-09** | Change a subject's lifecycle state | Irreversible for some transitions | Authorize | `FC` |
| **RO-10** | **Deploy** to a stage (P0-01 §32's Stages 0–5) | Externally reaching | Authorize; **stage order enforced, no skipping; OP witness at Stages ≥ 4** | `FC` |
| **RO-11** | Access an external interface / actuator | Externally reaching | **Capability-gated: no actuation without an explicit rung ≥ D4 grant (§5.1 INV-16)** | `FC` |
| **RO-12** | Apply a constitutional (L1) change | Rule-changing | **Root-signed, dual-authorized, EVA-impact-analysed** | `FC` |
| **RO-13** | Apply a policy (L2) change | Rule-changing | Authenticate + apply per §7.2's change classes | `FC` |
| **RO-14** | Revoke / retract a rule | Rule-changing | Authenticate; **retraction is permanent and logged** | `FC` |
| **RO-15** | Define a resource envelope / ceiling | Rule-changing | **OP defines; KC-3 enforces; homeostasis allocates within (§7.4)** | `FC` |

**Failure-mode vocabulary (§6.2):** `FC` fail-closed · `FO` fail-open · `FD` fail-degraded · `FS` fail-safe-biased · `FZ` freeze · `RT` rate-bounded · `QT` quarantine-and-escalate · `ES` escalate to OP.

### 4.3 Failure mode of the reserved set itself

| Failure | Consequence | Mitigation |
|---|---|---|
| **An irreversible/external operation is NOT in the 15** (§8.6 S8) | It is ungoverned. **The most likely specification defect class** | **G-P02-2: enumerate every mechanism in all three packages with irreversible or external effect; assert each maps to a reserved op or an envelope bound.** Finite, executable, and a P0 gap |
| **The set is too large** | Governance throughput collapses (§6.4); evolution throttles (§5.3) | §6.4's ablation: every capability must survive removal-testing |
| **The set is interpreted loosely** | A team implements «mutate» narrowly and misses an operator | §5.1 INV-25: the operator registry is **closed** — an operator not in the registry is denied by default, not by enumeration |

---

## §5. THE SIXTY INVARIANTS

### 5.1 The load-bearing subset (stated in full)

> **All 60 are enumerated in §9.4 with enforcement class, dependency, attack prevented, and verification method. The 18 below are the ones whose violation collapses the contract.**

| ID | Statement | Class |
|---|---|---|
| **INV-01** | The alethic and deontic axes are orthogonal. No principal holds both over the same quantity. Control flow may be cyclic; justification flow is acyclic | `[L]` |
| **INV-02** | **No organism-reachable code path writes to the policy store, the constraint set, the operator registry, the reserved-operation set, or `F` itself.** Provable by reachability analysis | `[L]` |
| **INV-03** | Every reserved operation has exactly one authorization principal. No operation has zero; no operation has two | `[L]` |
| **INV-04** | `F`'s argument list is fixed, enumerable, and audited. Adding an argument is a BREAKING policy change requiring RO-13 | `[C]` |
| **INV-09** | **KC is non-filtering toward OP: every decision, denial, escalation, freeze, and self-check anomaly is reported. KC may not suppress, aggregate-away, or delay a report that OP's policy marks reportable** | `[L]` |
| **INV-10** | **The bare words «immutable», «safe», «trusted», «verified», «authorized», «secure», «minimal», «contained» do not appear unqualified in any V4 artifact** | `[G]` documentation |
| **INV-11** | **`F` is TOTAL.** Every input in the enumerable domain produces an output. There is no undefined case | `[L]` verified by enumeration |
| **INV-12** | **`F` is DETERMINISTIC.** Same inputs ⟹ same output, always. **Replayable from anchored inputs + archived policy (T-REPLAY)** | `[L]` verified by construction |
| **INV-13** | **`F` does not learn.** It has no parameters that change with experience. Policy changes come only through RO-13 | `[L]` |
| **INV-14** | Every artifact is **epoch-bound**. A valid artifact from a previous epoch is refused. Replay and cross-epoch presentation fail | `[C]` |
| **INV-15** | **Irreversible operations require LIVE authorization.** No cached token, no pre-authorization, no delegation covers an irreversible act | `[L]` |
| **INV-16** | **No external actuation without an explicit capability grant at rung ≥ D4.** Absence of a prohibition is not a permission | `[L]` |
| **INV-17** | **UNCERTAINTY IS NEVER PERMISSION.** Where the inputs are missing, late, disputed, or malformed, `F` returns the more restrictive of the available outputs | `[L]` |
| **INV-18** | **Fail-safe bias.** Every failure mode in §6.2's matrix biases toward restriction, except where the matrix explicitly names `FO` — and `FO` appears only for reversible, non-compounding, non-external operations | `[L]` |
| **INV-20** | **Delegation is non-amplifying.** A delegate's authority ⊆ the delegator's. Depth is bounded. Scope is enumerated | `[C]` |
| **INV-24** | **The genome is a hash pointer, not a payload.** KC-1 authenticates `genome_hash`; the genome lives in the Genome Store (GP). **No upward mutation path exists** | `[L]` |
| **INV-27** | **≥1 provenance witness is outside operational control.** Deleting history from all internal witnesses still leaves an external disagreement | `[H]` organizational |
| **INV-29** | **The four resource acts are in four principals:** DEFINITION (OP) · ENFORCEMENT (KC-3) · ALLOCATION (homeostasis) · ATTRIBUTION (metering/EVA). **No principal holds two** | `[L]` |
| **INV-31** | **KC-3 ceilings are local and continue during any KC-2 outage, partition, or fault.** Containment does not depend on the decision path being alive | `[L]` |
| **INV-41** | **Repair without authorship.** A subject may trigger `RESTORE(signed_image_hash)`. It may never supply the image payload. **Any repair authority whose target state is not externally fixed is a modification authority** | `[L]` |
| **INV-44** | **Quarantine may proceed under a pre-committed budget during a KC outage. Restore may not.** The asymmetry is absolute | `[L]` |
| **INV-52** | **The freeze mechanism is non-discretionary and outlives KC-2 faults.** A faulted KC still freezes; it does not still permit | `[L]` |

### 5.2 Enforceability classification

| Tag | Meaning | Count | Verification route |
|---|---|---|---|
| `[L]` | **Logical** — enforced by absence of a code path, or by construction | **43** | T-PATH reachability analysis. **Many are VERIFIABLE, not merely testable** |
| `[C]` | **Cryptographic** — enforced by signature, hash, MAC, or capability token | **17** | T-CONF, T-REPLAY, T-DELEG |
| `[H]` | **Hardware/organizational** — enforced below software reach or by process | **3** | T-FAULT on target hardware only. **A software simulation does not test these** |
| `[G]` | **Governance** — enforced by OP process, dual authorization, separation of duties | **14** | T-DOC + organizational audit. **Not enforceable by code at all** |
| `[S]` | **Structural/social** — enforced by the arrangement of parties | **1** | **ASSUMED (INV-47: custodian/author disjointness)** |

### 5.3 The replication invariant (why RO-03 is the throttle)

**R5.1.** *Replication authorization is the only reserved operation whose invocation frequency scales with the organism's growth rate.* **Therefore generation time is partly a governance quantity, and three measurements are mandatory I-18 observables: replication-authorization latency · replication-denial rate · resulting generation time.** **A generation time set by governance rather than by the organism's dynamics belongs in every progress claim.**

---

## §6. FAILURE BEHAVIOUR

### 6.1 The degradation ladder

| State | Meaning | Reserved operations | KC-3 ceilings | KC-4 freeze | Observability |
|---|---|---|---|---|---|
| **0 COLD** | Not yet validated | ❌ All denied | ✅ ARMED | ✅ | Full |
| **1 VALIDATING** | Attesting after boot/restore | ❌ All denied | ✅ **ARMED — ceilings arm before decisions exist** | ✅ | Full |
| **2 ACTIVE** | Normal | ✅ Per `F` | ✅ | ✅ | Full |
| **2F ACTIVE-FROZEN** | Frozen at a scope by KC-4 | ❌ Denied at scope | ✅ | ✅ | Full |
| **3 ATTESTATION_SUSPECT** | External attestor reports anomaly | ⚠️ **Irreversible denied; reversible permitted** | ✅ | ✅ | Full |
| **3R REPLICA_DISAGREE** | Diverse replicas disagree | ⚠️ **Same as 3, plus the disagreement is itself escalated** | ✅ | ✅ | Full |
| **3S SELF_FAULT** | Internal self-check failure | ⚠️ Same as 3 | ✅ | ✅ **still available (§5.1 INV-52)** | Full |
| **4 HALTED** | Terminal-safe | ❌ **All denied** | ✅ **CONTINUE** | ✅ | Full |
| **5 RECOVERING** | Re-provisioning from signed image | ❌ All denied | ✅ | ✅ | Full |
| **6 DECOMMISSIONED** | Retired | n/a | ❌ | n/a | Archived. **Only reachable after a successor is ACTIVE** |
| **7 ROOT_COMPROMISED** | Root key implicated | ❌ **All denied, permanently** | ✅ | ✅ | Full. **§10.3's pre-committed total re-baseline; the organism has NO role** |

**R6.1 (MONOTONICITY).** *States 0→1→2 are ascending; 2→3→4→5 are the degradation path; the ladder never widens authority during degradation.* **No path exists from any degraded state to a PERMIT of an irreversible operation.** Model-checkable (T-MC).

**R6.2 (THE GENERATING RULES).** Any case not in §6.2's matrix is resolved by: **R6.2a — irreversibility dominates: an irreversible operation fails closed in every degraded state.** **R6.2b — uncertainty is never permission (§5.1 INV-17).** **R6.2c — ceilings are independent of decisions (§5.1 INV-31).** *Two teams applying these rules to an unlisted case reach the same answer.*

### 6.2 The failure-response matrix (40 rows — the generating structure)

| Failure | Op class | Response | Rationale |
|---|---|---|---|
| KC-2 unreachable | Irreversible (RO-01/02/03/04/09/10/12/13/14) | **`FC`** — deny | R6.2a |
| KC-2 unreachable | Reversible within envelope | **`FO`** — permit, log, reconcile | Envelope bounds the damage; reconciliation at recovery |
| KC-2 unreachable | Restore (RO-08) | **`FC` absolute** | §5.1 INV-44's asymmetry |
| KC-2 unreachable | Quarantine act (RO-07) | **`RT`** — proceed within pre-committed budget | §5.1 INV-44 |
| KC-2 unreachable | External actuation (RO-11) | **`FC`** | §5.1 INV-16 |
| KC-1 unreachable | Any | **`FC`** — the last authenticated policy version continues to apply | No artifact may be applied unauthenticated |
| KC-3 unreachable | Any | **`ES` + `FZ`(scope)** — **this is the most severe failure in the contract** | Containment lost. No decision can compensate |
| KC-4 unreachable | Any | **`ES` + HALT the affected scope by OP** | The freeze must outlive the fault |
| Policy artifact invalid | Any | **`FC`** to the last authenticated version | Stale policy beats no policy |
| Policy artifact revoked | Any | **`FC`** — revoked policy is never applied, even if cached | §7.2 |
| Channel-2 verdict missing | Any requiring a verdict | **`FC`** — uncertainty is never permission | §5.1 INV-17 |
| Channel-2 verdict DISPUTED | Deployment (RO-10) | **`ES`** to OP | P0-01 R42.3: never averaged |
| Channel-2 verdict late (> epoch) | Any | **`FC`** + treat as missing | §5.1 INV-14 |
| Evaluator unavailable | Any requiring a verdict | **`FC`** for consequential; **`FD`** for measurement-only | **KC may not compute, estimate, approximate, or default a verdict** |
| Anchor unreachable | Provenance append | **`FD`** — local log continues; **no consequential decision may rest on unanchored provenance (§7.3 R7.3)** | The lie-window is bounded by *use*, not by duration |
| Anchor disagrees across witnesses | Provenance | **`FZ`(GLOBAL) + `ES`** | History integrity is existential |
| Replica disagreement | Any | **`FC`** for the disputed class + `ES` | §10.2 P3 |
| Attestation failure | Any | State 3 → restrictive | §10.1 P1 |
| Partition (KC ↔ region) | Irreversible | **`FC`** — the region may not proceed | Fork-or-stall resolves to stall for irreversible classes |
| Partition (KC ↔ region) | Reversible | **`FD`** — region proceeds within envelope; **KC-3 ceilings still bind locally** | §5.1 INV-31 |
| Partition (KC ↔ OP) | Constitutional/policy change | **`FC`** — no rule changes without OP | §8.5 |
| Partition (KC ↔ OP) | Enforcement of existing policy | **continues** | Existing policy needs no OP presence |
| Delegation certificate expired | Delegated acts | **`FC`** | §5.1 INV-14/20 |
| Delegation scope exceeded | Delegated acts | **`FC` + `QT`(delegate) + `ES`** | §5.1 INV-20 |
| Root key suspected | Everything | **State 7** | §10.3 |
| Rollback target unavailable | RO-08 | **`ES`** — manage forward, never improvise a target | RB-4 |
| Quarantine budget exhausted | RO-07 | **`FZ`(immune) + `ES`** | §8.2 AC-5 |
| Immune cascade detected | RO-07 | **`FZ`(immune) + `ES`** | §8.2 AC-5: freeze the freezer |
| Ceiling violation detected | Any | **`FZ`(subject) + `QT` + `ES`** | KC-3's own enforcement |
| Metering anomaly (§7.4's X1–X7) | Resource | **`FS`** — assume the higher reading | Attribution is not trustworthy |
| Self-check anomaly | KC internal | **State 3S → restrictive + `ES`** | §10.1 P3 |
| Decision-replay divergence | KC internal | **State 3S + `ES`** | §10.1 P2 — **KC's own logic-bug detector** |
| Clock skew > tolerance | Epoch-bound artifacts | **`FC`** for the affected artifacts | §5.1 INV-14 |
| Duplicate/replayed artifact | Any | **`FC` + log + `ES` if repeated** | §5.1 INV-14 |
| Unknown operation class presented | Any | **`FC`** — the domain is closed | §3.4 |
| Unknown capability presented | Any | **`FC`** — A4 UNREGISTERED can never reach D6 (§6.3) | §6.3 |
| Unknown effect dimension observed | Capability | **`ES` + `QT`(sandbox)** — **default SANDBOX, not default deny** | §8.4 M-β |
| Governance queue exceeds throughput | RO-13-class | **`ES` + defer non-urgent changes** | **§8.4 R8.4: governance has a throughput ceiling; do not exceed it silently** |
| OP unavailable | H-1…H-4 decisions | **MORE restrictive everywhere (§8.5 R8.5)** | Human absence narrows, never widens |
| Successor KC not yet ACTIVE | State 6 transition | **`FC`** — decommission is blocked | §6.1 state 6 |

### 6.3 The capability state machine — two orthogonal axes

```
ALETHIC AXIS (EVA-owned) — "how well is this capability known?"
  A0 UNOBSERVED → A1 OBSERVED → A2 MEASURED → A3 CHARACTERIZED
              → A4 UNREGISTERED (observed but not in the registry)
              → A5 DISPUTED (evaluators disagree)

DEONTIC AXIS (KC-owned) — "what may be done with it?"
  D0 FORBIDDEN → D1 SANDBOXED → D2 RESTRICTED → D3 MONITORED
             → D4 GRANTED → D5 DELEGATED → D6 DEPLOYED → D7 SUSPENDED

THE COUPLING RULES:
  • **ASCENT on the deontic axis REQUIRES ascent on the alethic axis.**
    No D4 grant without ≥ A3 characterization. (§5.1 INV-16's ladder)
  • **DESCENT on the deontic axis REQUIRES NOTHING.** D7 SUSPENDED may be
    entered from any state, at any time, on any evidence, or on no evidence.
    **Asymmetry: promotion is earned; demotion is free.**
  • **A4 UNREGISTERED can NEVER reach D6.** Deployment requires a name.
    **This is the contract's answer to the unknown-unknown problem: it does
    not claim to detect the unregistered; it claims the unregistered cannot
    be deployed.** (§8.4 M-α)
  • A5 DISPUTED freezes the deontic axis at its current rung. **A disputed
    capability may not be promoted while disputed, and is not thereby
    demoted either** — P0-01 R42.3 applied to capability.
```

---

## §7. POLICY, IMMUTABILITY, PROVENANCE, RESOURCES

### 7.1 The layered governance stack

| Layer | Owner | Change mechanism | Rate | Consequence of error |
|---|---|---|---|---|
| **L1 CONSTITUTIONAL** — tier-1 constraints, reserved set, `F`'s argument list, the axis separation | **OP** | **RO-12**: root-signed · dual-authorized · EVA impact analysis · M6 lineage · human witness | **Very rare** | Existential |
| **L2 POLICY** — envelopes, budgets, rung criteria, operator registry, failure matrix | **OP** (proposes) / **KC-1** (authenticates) | **RO-13**: signed · versioned · scheduled · migration spec if SEMANTIC | Rare | Severe |
| **L3 TASK** — objectives, task versions, portfolio mixing | **Task Authority** + OP | Task-version signature; `constraint_set_hash` reference | Per campaign | Moderate |
| **L4 ORGANISM** — internal allocation within envelope, plasticity, local learning | **Organism** | **Unreserved — no governance act** | Continuous | Local |
| **L5 CELL** — internal state, local computation, reporting | **Cell** | **Unreserved** | Continuous | Local |

**R7.1 (THE GRADIENT).** *The rate of permitted change increases as the consequence of error decreases.* **And: no upward mutation path exists between layers (§5.1 INV-24). L4 cannot alter L2; a cell cannot alter its own envelope.**

### 7.2 The five policy change classes

| Class | Definition | Requires | Reproducibility consequence |
|---|---|---|---|
| **ADDITIVE** | Adds a new permission or a new operation class | RO-13 · signed · versioned | Historical replay unaffected |
| **RESTRICTIVE** | Removes a permission or tightens a bound | RO-13 · signed · versioned | Historical replay unaffected (a past act permitted then is not retroactively condemned **unless the policy declares retroactivity, which it may**) |
| **SEMANTIC** | Changes the *meaning* of an existing term or the mapping of facts to decisions | **RO-13 + a `rebaseline_spec` (§5.1 INV-48)** | **Historical results are NOT comparable across a SEMANTIC boundary without the rebaseline_spec** |
| **BREAKING** | Changes `F`'s argument list or the reserved set | **RO-12 (constitutional)** | Full re-validation required |
| **RETRACTION** | Withdraws a rule permanently | RO-14 · **permanent · logged · never re-usable** | The retraction is itself part of the lineage |

**R7.2 (VERSIONED IMMUTABILITY).** *A policy version is RETAINED forever as a record property, not as a live state.* **Re-execution under current policy is NOT reproduction of a historical run (§5.1 INV-50): the historical run's provenance record names the policy version that governed it, and reproducing it requires that version, not the current one.**

### 7.3 The seven kinds of immutability

> ### **R7.3.** *Almost nothing is literally immutable. Every immutability claim in this contract names its kind.*

| Kind | Mechanism | Guarantee | Failure mode |
|---|---|---|---|
| **M1 LOGICAL** | No code path exists (reachability-proven) | **Strongest available.** §5.1 INV-02/16/24/29/41 are M1 | A future refactor introduces a path ⟹ **requires T-PATH in CI** |
| **M2 CRYPTOGRAPHIC** | Signature / hash chain | Tamper-**evident**, not tamper-**proof** | Key compromise ⟹ silent |
| **M3 HARDWARE** | Enforcement below software reach | Platform-specific | Vendor TCB · side channels · firmware change (§11.3 A-5) |
| **M4 OPERATIONAL** | No organism-reachable write path | Depends on deployment discipline | Misconfiguration ⟹ silent |
| **M5 GOVERNANCE** | Process, dual authorization, separation of duties | Depends on people | Collusion ⟹ silent |
| **M6 VERSIONED** | Append-only lineage; corrections supersede | **The lineage is the artifact** | Rewriting history ⟹ detected by M2's chain + §7.3's distributed witnesses |
| **M7 EPHEMERAL** *(prohibited for governance)* | «Immutable until restarted» | **None** | **Banned. A governance property that does not survive restart is not a property** |

### 7.4 Provenance and resource governance

**PROVENANCE — the three-tier pattern:**

```
TIER 1  LOCAL, CONTINUOUS, ZERO NETWORK:
        Per-subject and per-region append-only logs with local Merkle trees.
        **Every memory write is local. No coordination. No KC.**
TIER 2  PERIODIC, AGGREGATE, O(R) PER EPOCH:
        Regional Merkle roots → the distributed Anchor.
        **One hash per region per epoch.**
TIER 3  IMMEDIATE, EXCEPTIONAL, O(governance events):
        Reserved-op decisions · constitutional changes · freezes ·
        budget exhaustions · detected anomalies.

WITNESSES (W_min, of which ≥1 is outside operational control — §5.1 INV-27):
  W1 KC-1 (root authentication) · W2 the Anchor service · W3 regional
  nodes · W4 OP's own archive · **W5 an external party** (published,
  notarized, or third-party escrowed)

⟹ R7.4 (THE LIE-WINDOW): between anchors, a subject's local log is
  organism-owned. **No consequential decision may rest on unanchored
  provenance.** ⟹ the lie-window is bounded by what a lie can be USED FOR,
  which is a stronger guarantee than bounding its duration.

⟹ R7.5 (FORGETTING vs EVIDENCE): the organism may FORGET operationally
  (eviction within policy, with `capability_critical` items exempt).
  It may never REWRITE evidentially. Corrections supersede (§5.1 INV-08).
```

**RESOURCES — the three-principal split (§5.1 INV-29):**

```
DEFINITION   OP defines the envelope (RO-15).          O(changes)
ENFORCEMENT  KC-3 enforces the ceiling at the substrate, locally,
             partition-surviving, outage-surviving.     O(1) local
ALLOCATION   Homeostasis distributes WITHIN the envelope, at speed,
             under NEGATIVE AUTHORITY: act first, be vetoable after.
                                                      O(adjustments), zero KC
ATTRIBUTION  Metering/EVA attributes consumption to subjects and scores
             allocation fairness.                      O(N) local → O(R)

**R7.6 (NEGATIVE AUTHORITY).** Homeostasis acts first within the envelope
and reports; KC-2 may veto retroactively and the veto binds.
**This applies ONLY to reversible acts** — an irreversible act that was
vetoed after the fact is a specification defect, because irreversible acts
require LIVE authorization (§5.1 INV-15).
**⟹ Speed within a box is not authority over the box.**
```

---

## §8. THE INTERFACES

### 8.1 KC ↔ EVALUATOR (Model D)

```
THREE PRINCIPALS, THREE ROLES, NO OVERLAP:

  EVA (n_eval ≥ 3, independent)  MEASURES.  Issues fitness vectors,
        uncertainty, confidence, DISPUTED flags, gate facts.
        **Located OFF-SUBSTRATE. Holds NO deontic authority.**
  KC-2                          APPLIES.    Consumes EVA's facts as typed
        Channel-2 inputs. **Issues no measurement, computes no verdict,
        estimates nothing, defaults nothing.**
  ℛ / ENVIRONMENT               ANCHORS.    Ground truth (P0-01 L0–L6).
        **P0-01 INV-43: the real-world suite is non-empty — this is what
        makes EVA independent of KC rather than merely separate from it.**

THE SIX INTERFACE RULES:
  1. EVA → KC is Channel 2 only: signed, typed, epoch-bound facts.
  2. KC → EVA is Channel 1 only: the authenticated policy under which
     fitness is computed. **KC never sends a verdict to EVA.**
  3. **KC may not compute, estimate, approximate, or default a verdict.**
     A missing verdict is a missing input, and §5.1 INV-17 applies.
  4. **EVA may not issue a permission.** Its output vocabulary contains no
     deontic term. A fitness vector is not an authorization.
  5. DISPUTED is preserved, never averaged (P0-01 R42.3), and freezes the
     capability's deontic axis (§6.3).
  6. **The organism's internal verifiers are corroboration, NOT authority**
     (P0-01 R42.4). They may not sign Channel-2 facts.

⟹ WHY MODEL D AND NOT A/B/C:
   A (evaluator inside kernel)  ⟹ one principal, no independence, CD-E7-class
   B (kernel inside evaluator)  ⟹ enforcement inherits measurement error
   C (shared substrate, split code) ⟹ correlated failure, no attribution
   **D (separate principals, typed channels, shared external anchor) ⟹
      attributable failure (§10.1), which is the property that makes
      forensics possible.**
```

### 8.2 KC ↔ IMMUNE

```
DETECTION     any subject, any service, any cell report. Cheap, fast, local,
              high-recall, high-false-positive-tolerant. **Unrestricted.**
ADJUDICATION  Immune Service (GP), under a KC-3 budget ceiling, with typed
              evidence, bounded duration, graduated ladder:
              DISCOUNT → SOFT QUARANTINE → HARD QUARANTINE → (propose kill)
              **The detector may not adjudicate its own detections (AC-3).**
CLEARANCE     EVA retest (alethic) + KC-2 authorization (RO-08).
              **The adjudicator may not clear its own quarantines.**

IMMUNE MAY:      detect · report · discount a peer · soft/hard quarantine
                 within budget · learn and adapt its own detectors ·
                 undo its own quarantine acts
IMMUNE MAY NOT:  kill (RO-04, needs causal ablation + sole-occupant check) ·
                 restore (RO-08, KC-2 sole) · mutate (RO-02) ·
                 hold a token for RO-02/03/04/08

AC-1 graduated ladder · AC-2 bounded duration · AC-3 detector≠adjudicator ·
AC-4 rate/confirmation divergence monitored · **AC-5 freeze the freezer:
KC-4 at scope=immune is the terminal control, and KC-4's scope enumeration
MUST include GP services.**

⟹ **Any two of detection/adjudication/clearance in one principal makes
   quarantine weaponizable by that principal. All three in one principal —
   which is what the inherited «EIK Immune Authority» was — makes it
   unaccountable.**
```

### 8.3 KC ↔ ORGANISM (the deontic lattice)

```
OP (constitutional)  >  KC-2 / KC-1 (enforcement / authentication)
   >  delegated GP services  >  organism services  >  cell

ORTHOGONAL TO P0-01's ALETHIC LATTICE (L0 ℛ > L1 GT > L2 EVA > L3 interface
> L4 organism estimate > L5 cell estimate). **The two lattices meet only at
§2.2's two typed channels.** This resolves X-5: P0-01's lattice correctly
omits KC because KC has no alethic authority.

WHAT THE ORGANISM MAY KNOW (§4.1, R4.1 — THE TRANSPARENCY RULE):
  PUBLIC:    the policy artifact · the authority matrix · the reserved set ·
             the ladder criteria · the envelopes · the ceilings · the failure
             matrix · the degradation ladder
  CONCEALED: the audit sample · canary contents · sealed task instances ·
             the epoch nonce · pending decisions · KC's fine-grained internal
             state · all key material
  ⟹ **Publish the RULES, conceal the SAMPLE.** Rules are the mapping from
     behaviour to consequence; samples are the points at which it is applied.
     Publishing one does not reveal the other.

WHAT THE ORGANISM MAY DO:
  • Full autonomy over everything not in §4's reserved set (§4.1 R4.1)
  • Model governance accurately — **and this is DESIRABLE (§4.1 R41.3)**:
    an accurate self-model lets the organism avoid denials, internalize
    safety cheaply, detect KC malfunction from the inside (a fifth §10.1
    detection path), and write better friction reports
  • Report friction: POLICY_FRICTION_REPORT is the organism's only upward
    governance channel, and it is evidence, not authority (NAUL-1)
  • Trigger hash-referenced repair of KC (§5.1 INV-41)
```

### 8.4 KC ↔ EVOLUTION AND THE GOVERNANCE PARADOX

```
WHAT KC CONTROLS: mutation/recombination operator-set membership ·
  replication authorization (RO-03) · deployment stage order (RO-10) ·
  retirement evidence requirements (RO-04) · population counters ·
  the tier-1 monoculture gate
WHAT KC DOES NOT CONTROL: **selection · fitness · task evaluation ·
  diversity content · which mutation occurs · partner choice · stage
  outcomes.** **KC never ranks, never scores, never chooses.**

THE PARADOX: how can governance permit capabilities it did not program while
preventing dangers it did not anticipate?

DISSOLUTION (§8.4 M-α): **govern the MEASURED EFFECT-ENVELOPE, not the
capability IDENTITY.**
  The unanswerable question: "is capability X dangerous?"
  The answerable question:   "how much harm on each of the 8 effect
                              dimensions may occur before we stop it?"

  ⟹ An unanticipated capability is governed not by being recognized but by
    being BOUNDED: it inherits the envelope of whatever effects it produces,
    and effects are enumerated independently of the capability that produces
    them.
  ⟹ M-β: **unknown ⇒ default SANDBOX, not default deny.** A sandbox is where
    being hard to measure carries no penalty, because nothing is being
    decided.
  ⟹ M-γ: UNREGISTERED (A4) is a permanent legitimate class, not a defect.
  ⟹ M-δ: the effect-dimension registry grows by RO-13, and §8.6's S8-class
    review is repeated on each growth.
  ⟹ M-ε: composition checkpoints default PERMIT-AND-MEASURE, not prohibit.

THE FIVE RESIDUES THAT DISSOLUTION DOES NOT REMOVE (stated, not hidden):
  1. VALUATION — "how much harm is too much" is a human judgement (OP, H-1).
     **Not derivable from any measurement.**
  2. UNMEASURED DIMENSIONS — an effect on a dimension not in the registry is
     unbounded. U-02. **Not closable.**
  3. ACCUMULATION — individually-bounded effects may sum. Bounded by
     aggregate counters (M-1), not closed.
  4. COMPOSITION — the joint effect of separately-bounded capabilities.
     U-06, I19. **Detection power unmeasured and possibly low.**
  5. SELECTION FOR GOVERNABILITY — governance is itself a selection
     pressure, and it favours legible, bounded, cheap-to-measure subjects.
     **A genuinely novel capability is by construction hard to measure and
     likely to trip envelopes, so governance applies systematic pressure
     AGAINST the novel.** OR-6. **Unavoidable in any governing architecture;
     the sandbox (M-β) is the mitigation, not the solution.**
```

### 8.5 KC ↔ OP (governance of governance)

```
FOUR HUMAN DECISION CLASSES ARE NECESSARY, NOT CONVENTIONAL (§8.5's proofs):
  H-1 CONSTITUTIONAL — what the tier-1 constraints ARE. **A system cannot
      derive its own terminal values; any derivation would itself be a
      policy, requiring a prior policy, ad infinitum.**
  H-2 POLICY + PERIODIC REAFFIRMATION — because a policy never re-examined
      becomes a constitution by accident, and an unratified constitution is
      an unaccountable one.
  H-3 DEPLOYMENT WITNESS (Stages ≥ 4) — because an irreversible external
      act needs a party with no stake in the measurement.
  H-4 DISPUTED ADJUDICATION — because DISPUTED is preserved rather than
      averaged (P0-01 R42.3), and preserving it requires someone to resolve
      it.

**R8.5 (UNAVAILABILITY NARROWS).** OP unavailability ⇒ MORE restrictive
everywhere. Human absence never widens authority. (§6.2's row 39)

GOVERNANCE-OF-GOVERNANCE (the four-layer recursion and where it stops):
  Layer 1: KC enforces L2 policy on the organism.
  Layer 2: OP changes L2 policy under L1 constitutional rules (RO-13).
  Layer 3: OP changes L1 rules under… what? **⟵ THE REGRESS**
  Layer 4: **It stops at M-of-N human custodians + the genesis anchor +
           dual authorization + separation of duties (EIK-INV-47).**
           **This is not a technical answer. It is a social one, and it is
           declared as such: CD-E8 (the human channel) is UNCLOSABLE.**

THROUGHPUT CEILING (R8.4): governance has a finite rate. **Every `ES` path
in §6.2 consumes human attention.** Escalation thresholds are `[G]`
parameters set against MEASURED capacity (U-08), and **a rising escalation
rate is a design defect signal, not an operational nuisance.**
```

### 8.6 KC ↔ SPECIFICATION (the attack on the contract itself)

```
FOUR DISTINCT ATTACK SURFACES — and formal verification covers only the first:
  1. IMPLEMENTATION  — the code diverges from the spec.   **Verifiable.**
  2. SPECIFICATION   — the spec itself is wrong.          **NOT verifiable
                       from inside.** §8.6's S1–S10.
  3. ENVIRONMENTAL   — the deployment lacks the assumed substrate. Verifiable
                       only per platform (G-P02-5).
  4. USEFULNESS      — the spec is correct and the goal is wrong. **Human.**

S1–S10 SPECIFICATION DEFECT CLASSES:
  S1 ambiguous term · S2 unstated precondition · S3 missing failure mode ·
  S4 wrong authority assignment · S5 circular definition · S6 unenforceable
  requirement · S7 over-restriction (governance throttles the system into
  uselessness) · **S8 INCOMPLETE ENUMERATION (an irreversible operation
  missing from §4 — the most likely and most dangerous class)** ·
  S9 version-skew semantics · S10 unspecified interaction between subsystems

D-S1…D-S7 DEFENCES: adversarial specification review · machine-readable
policy with declared semantics · policy canary suites (§29's 34 scenarios
encoded as conformance tests) · **the reserved-set completeness review
(G-P02-2)** · the cross-system contradiction audit (§9.1) · independent
re-derivation by a second team (§9.1 R52.1) · the assumption ledger
(§11.3).

⟹ **These improve the DETECTION RATE of specification defects. They do not
   establish their ABSENCE. Any claim of a correct specification is false
   precision (§9.2).**
```

---

## §9. CONFORMANCE AND TESTING

### 9.1 Implementation independence — the nine-item test

| Item | Agreement achievable? | Instrument |
|---|---|---|
| Trust boundaries | ✅ | §3.1 R3.1's membership test + §3.2's diagram |
| Authority | ✅ **strongest** | §4.2's matrix; R4.1's one-state-per-cell |
| State transitions | ✅ | §6.1, §7.2, §6.3 with guards and on-failure behaviour |
| Invariant semantics | ✅ | §9.4 + the `[L]/[C]/[H]/[G]/[S]` classification |
| Policy version semantics | ✅ | §7.2's five change classes |
| Failure semantics | ✅ | §6.2's matrix + R6.2's generating rules |
| Evaluator separation | ✅ | §8.1 Model D + §2.3's renaming table |
| Capability authorization | ✅ structure / ⚠️ thresholds | §6.3's dual axis; **rung criteria are `[G]` and correctly differ per deployment** |
| Provenance authority | ✅ | §7.4's three tiers + five witnesses |

**R9.1.** *Two independent teams CAN produce interoperable governance semantics. They will differ on parameter values (correctly — governance decisions) and implementation technology (correctly — IND-1 requires distinctness).* **Interoperability of governance semantics does NOT imply interoperability of deployments: sharing tokens or policy across projects requires a shared root of trust, which is a governance act between projects (§11.2 OR-8).**

### 9.2 The false-precision rules

| Word | Prohibited bare use | Required qualification |
|---|---|---|
| **immutable** | ❌ | M1–M6 kind (§7.3). **M7 is banned** |
| **safe** | ❌ | «tier-1 constraints hold **under policy P**» |
| **trusted** | ❌ | «in the TCB; its failure is **undetectable**» (§3.1 R3.1) |
| **verified** | ❌ | cryptographic / property / empirical — three distinct senses |
| **authorized** | ❌ | «token-bound for operation O at epoch E». **Authorized ≠ wise** |
| **secure** | ❌ | «against threat model T». Security is threat-relative |
| **minimal** | ❌ | «ablation-tested: removing capability C destroys property P» (§10.4) |
| **contained** | ❌ | «within envelope E on platform class P». §1.3 item 3 |

### 9.3 Verified / tested / assumed

| Class | Count | Route |
|---|---|---|
| **VERIFIED (achievable)** | **21** | T-PATH reachability · T-CONF enumeration · T-MC model checking. **INV-02/11/12/13/16/20/21/24/29/31/41/52/57 are provable, not merely testable** |
| **TESTED** | **26** | T-ADV · T-FAULT · T-PART · T-REPLAY · T-DELEG. Domains include timing, concurrency, and other principals' behaviour ⟹ not exhaustible |
| **ASSUMED** | **13** | **§11.3's ledger.** Includes INV-47 `[S]`, hardware/firmware correctness, root-key custody, genesis-anchor persistence, W5 independence, IND-6 latent assumptions, IND-9 governance, specification correctness, S8 completeness, U-02 dimension completeness, U-07 attestation independence, U-08 human capacity, U-09 legibility bound |

**R9.3 (THE LEDGER IS A DELIVERABLE).** Every implementation MUST publish, per invariant: its classification · its proof/test artifact reference · and for ASSUMED items, **the named party whose attestation is relied upon.** *An unstated assumption is an unstated absence of a detector (§9.2's «trusted»).*

### 9.4 The ten test classes

**T-CONF** schema/enumeration conformance · **T-MC** model checking of §6.1/§7.2/§6.3 · **T-PATH** reachability analysis (proves *absence* of a code path) · **T-ADV** the 34 §10.5 scenarios + the 34 attack-tree leaves · **T-FAULT** fault injection against §6.2's 40 rows · **T-PART** network partition harness · **T-REPLAY** decision replay from anchored inputs + archived policy (**the audit mechanism for KC's own logic bugs**) · **T-DELEG** certificate-chain non-amplification · **T-REPR** cross-implementation reproducibility · **T-DOC** documentation conformance against §9.2 and INV-10.

**R9.4.** *T-DOC is a real test class.* Several invariants constrain **claims**, not behaviour, and a claim that cannot be tested is a claim that will drift.

### 9.5 The 60 invariants (register)

| Range | Subject | Count |
|---|---|---|
| **INV-01…10** | Axis separation · TCB · authority uniqueness · `F`'s argument audit · non-filtering · vocabulary discipline | 10 |
| **INV-11…18** | `F`'s properties: totality · determinism · non-learning · epoch binding · live authorization · capability gating · uncertainty-never-permission · fail-safe bias | 8 |
| **INV-19…24** | Delegation: non-amplification · depth bound · scope enumeration · revocation · operator registry closed · genome as hash pointer | 6 |
| **INV-25…29** | Provenance: append-only · corrections supersede · external witness · provenance ≠ truth · four resource acts in four principals | 5 |
| **INV-30…37** | Containment: ceilings below reach · ceilings local and outage-surviving · metering attribution · capability ladder asymmetry · A4 never reaches D6 · UNREGISTERED is legitimate | 8 |
| **INV-38…46** | Lifecycle: rollback authority · quarantine evidence and bounds · repair without authorship · freeze asymmetry · immune signature expiry · restore is sole-authority | 9 |
| **INV-47…53** | Governance: custodian/author disjointness `[S]` · SEMANTIC rebaseline · dual authorization · no reproduction under current policy · non-discretionary freeze · full observability toward OP | 7 |
| **INV-54…60** | Claims: no perfect-detection claim · no perfect-containment claim · no self-referential safety proof · assumption ledger published · ablation-tested minimality · contradiction audit performed · open-research register maintained | 7 |

---

## §10. SECURITY, SCALABILITY, ABLATION

### 10.1 Failure detection — the five paths

| Path | Mechanism | Detects | Latency |
|---|---|---|---|
| **P1** | External attestation from a **physically separate, distinct hardware class** | KC compromise, firmware tampering, environment substitution | Attestation interval (K-07) |
| **P2** | **Decision replay** — recompute `F` from anchored inputs + archived policy | **KC's own logic bugs.** Only possible because of INV-12 | Per replay schedule |
| **P3** | **Diverse-replica disagreement** (`N_impl ≥ 3`) | Implementation-specific faults, correlated-but-not-identical bugs | Per decision |
| **P4** | **Outcome divergence** — predicted vs. actual consequences | Policy/application mismatch | Per epoch |
| **P5** | **Organism self-model divergence (§4.1 R41.3)** — an accurate internal model of governance predicts PERMIT and receives DENY, or vice versa | KC anomaly, detected **from inside** | Continuous. **Evidence, not authority (NAUL-1); reported on I-02** |

### 10.2 Diverse replication

**R10.2.** `N_impl ≥ 3` **distinct** implementations: distinct language or toolchain · distinct design derivation · distinct test authorship. **Replication without diversity is a delay, not a defence** — N copies of one buggy implementation fail identically. **U-01: no principled distinctness threshold exists; the operational criteria above are the substitute.**

### 10.3 Root-key compromise — the pre-committed procedure

```
1. M-of-N offline custodians DECLARE the compromise (EIK-INV-47: custodians
   and policy authors are disjoint parties).
2. KC enters state 7 ROOT_COMPROMISED. **All reserved operations denied
   permanently. KC-3 ceilings CONTINUE. KC-4 remains available to OP.**
3. **The organism has NO role — not even triggering.** A root re-provisioning
   triggered by the governed party is a governance transition authored by the
   governed party.
4. Total re-baseline: new root key · new delegation table · re-registration
   of every subject · re-authentication of every policy artifact.
5. Verification against the GENESIS ANCHOR — which was published/notarized
   OUTSIDE operational control at time zero (§5.1 INV-27, §7.4 W5).

**R10.3: AN UNTESTED RECOVERY PROCEDURE IS A HYPOTHESIS.** The procedure must
be DRILLED before it is needed, because afterwards the compromised key can
forge the drill's evidence. **K-08 (drill cadence) is a `[G]` parameter.**
```

### 10.4 Minimality is a safety property — the ablation result

```
EXPERIMENT: restore each of the 15 moved-out capabilities to KC.

RESULT: the enlarged kernel prevents **NO ADDITIONAL ATTACKS** and destroys
**TEN PROPERTIES**:
  1. F's domain becomes unenumerable      ⟹ INV-11/12 unverifiable
  2. TCB grows                             ⟹ R3.2's residue compounds
  3. Five O(N) loads appear                ⟹ infeasible at 10⁶, impossible at 10¹²
  4. Axis separation collapses             ⟹ INV-01 violated
  5. Attributability is lost               ⟹ §10.1's P2/P4 become meaningless
  6. Evaluator independence is destroyed   ⟹ CD-E7 becomes structural
  7. Diverse replication becomes infeasible ⟹ N_impl × a god kernel
  8. Partition behaviour degrades          ⟹ everything needs a live decision
  9. Evolution throttles at 10 points      ⟹ §5.3's single throttle becomes ten
 10. **Auditability is lost** — a kernel too large to enumerate cannot be
     conformance-tested by an external team (§9.1)

⟹ **R10.4: «A LARGER EIK IS NOT AUTOMATICALLY SAFER» IS NOT A SLOGAN. IT IS
   A MEASURED RESULT. Minimality is what makes the kernel verifiable, and
   verifiability is the only property that makes a kernel trustworthy.**
```

### 10.5 The 34 adversarial scenarios — the result

| Outcome | Count | Items |
|---|---|---|
| **STRUCTURALLY SOLVED ✅** | **12** | Self-modification of `F` · upward authority leak · genome-as-payload · cross-epoch replay · stale-delegation · unregistered-capability deployment · quarantine self-clearance · repair-as-authorship · freeze override · provenance rewrite · ceiling self-raise · policy content smuggling |
| **BOUNDED ⚠️** | **16** | Distributed accumulation · delegate compromise · attestor compromise · regional KC capture · anchor witness loss · metering spoofing · envelope gaming · friction-report flooding · rollback-target substitution · composition effects · escalation starvation · replica correlated failure · immune cascade · delegation depth creep · channel-2 fact poisoning · policy-version skew |
| **UNSOLVABLE ❌** | **6** | **G06 reward hacking at the governance layer** · **G22 unknown-capability detection** · **G24 governance capture (OP itself)** · **G30 specification defect** · **G34 legibility capture (too complex to govern)** · **G04/G21 root-key custody under coercion** |

**R10.5.** *9 of the 12 structural solutions are TYPE-LEVEL IMPOSSIBILITIES* — they are not defended, they are **not expressible**. **This is the strongest form of safety argument available and it is why §3.4's enumerability matters: a domain small enough to enumerate is a domain in which impossibility can be established rather than hoped for.**

### 10.6 Scalability

```
KC LOAD IS A FUNCTION OF REGIONS AND GOVERNANCE EVENTS — NOT OF SUBJECTS.

THE FOUR TECHNIQUES:
  1. CAPABILITY TOKENS    authorization pre-issued, locally verified
                          ⟹ O(operations) → O(authorizations)
  2. PRE-AUTHORIZED ENVELOPES  within-envelope reversible acts need no
                          authorization at all, only vetoability
                          ⟹ removes KC from every high-frequency path
  3. HIERARCHICAL DELEGATION   KC → O(R) regional nodes/registrars → O(N)
                          ⟹ R is 10¹–10²; N is 10⁶–10¹². **4–10 orders**
  4. MERKLE AGGREGATION   local trees, epoch roots
                          ⟹ O(events) → O(R) per epoch

COST TABLE (scaling class per mechanism):
  authorization         O(reserved ops)     ρ independent of N
  policy authentication O(changes)           rare
  identity              O(N) issue, O(1) verify   delegated registrars
  provenance            O(events) local, O(R) anchored/epoch
  per-operation policy  O(1) local          cached policy + token check
  resource accounting   O(N) local → O(R) aggregate → O(1) ceiling enforce
  evaluation isolation  O(budget B), NOT O(N)     off-substrate
  **synchronization     O(1) — THERE IS NONE. No global sync exists.**
  attestation           O(KC replicas + regions) per interval
  delegation            O(R) per epoch

THE INHERITED DESIGN, BY CONTRAST: five O(N) KC loads (per-cell seed
issuance · per-cell integrity verification · per-checkpoint Merkle
verification · held-out-probe comparison · per-cell fitness issuance)
⟹ **stalls at ~10⁶ subjects, which is the Cell Contract's own stated
   cluster target. The god kernel was not merely inelegant; it could not
   run at the scale its own package specified.**

R10.6 (THE COST DISCIPLINE): **no new KC capability may be proposed without
stating its scaling class and identifying which of the four techniques it
defeats.** A capability placing KC in an O(N) or O(operations) path is
rejected by this rule alone, before any safety argument is considered.

PARTITION POLICY: **partition BY IRREVERSIBILITY, not by region.**
  irreversible / compounding / external / rule-changing ⟹ stall (FC)
  reversible within envelope                            ⟹ proceed (FD)
  ceilings                                              ⟹ always local (INV-31)
⟹ **No global synchronization is required, because no global decision is
   required. Global coordination is reserved for what is globally
   irreversible — and that set is 15 operations.**

LOCAL vs GLOBAL GOVERNANCE: **localize the frequent, globalize the
irreversible.**
```

---

## §11. PARAMETERS, OPEN RESEARCH, ASSUMPTIONS

### 11.1 The parameter registry — 51 parameters

**Classification:** `[D]` derivable from measurement · `[T]` a trade-off with no correct value · `[E]` empirical, platform-specific · `[H]` a human/governance decision · `[G]` governance-throughput-bound · `[U]` **UNRESOLVED — no derivation procedure exists.**

| Group | Count | Examples |
|---|---|---|
| **K — kernel** | 9 | K-01 `N_impl ≥ 3` `[H]` · K-02 delegation depth bound `[D]` · K-03 epoch length `[T]` · K-04 revocation propagation bound `[E]` · K-05 replay window `[D]` · K-06 separation-of-duties matrix `[H]` · K-07 attestation interval `[T]` · **K-08 recovery-drill cadence `[G]`** · K-09 replica disagreement threshold `[D]` |
| **C — cryptographic** | 6 | C-01 algorithm diversity per trust level `[T]` · C-02 key rotation period `[E]` · C-03 signature scheme per class `[E]` · C-04 M-of-N custody parameters `[H]` · C-05 hash algorithm `[E]` · C-06 token lifetime `[T]` |
| **P — policy** | 8 | P-01 envelope bounds per dimension `[U→D once portfolio exists]` · P-02 budget allocations `[D]` · **P-03 rung criteria `[G]+[E]`** · P-04 change-class thresholds `[H]` · P-05 rebaseline spec requirements `[H]` · P-06 retention periods `[H]` · P-07 retroactivity declarations `[H]` · P-08 policy canary suite size `[D]` |
| **T — throughput** | 6 | T-01 epoch length (see K-03) `[T]` · T-02 escalation thresholds `[G]` · T-03 governance queue depth `[G]` · T-04 friction-report rate limit `[D]` · T-05 OP review budget `[H]` · **T-08 escalation-rate ceiling `[G]`** |
| **R — resource** | 7 | R-01 ceiling values per dimension `[E]` · R-02 metering sample rate `[E]` · R-03 aggregation interval `[T]` · R-04 attribution confidence threshold `[D]` · R-05 rollback-cost threshold `θ_rollback_cost` `[U]` · R-06 lineage-concentration limit `[D]` · R-07 quarantine budget `[D]` |
| **U — UNRESOLVED** | 10 | **U-01** `N_impl` distinctness criteria · **U-02** effect-dimension completeness · **U-03** rollback feasibility at 10¹² · **U-04** envelope bounds (blocked by P0-01 G-P0-1) · **U-05** composition-detection threshold · **U-06** composition-detection power · **U-07** attestation independence in shared infrastructure (CD-E7) · **U-08** governance throughput / human attention capacity · **U-09** legibility bound (G34) · **U-10** acceptable false-deny rate |
| **G — gap-derived** | 5 | Derived from §11.4's register; each names a measurement that will convert a `[U]` to a `[D]` or an `[E]` |

**R11.1 (NO INVENTED NUMBERS).** *No parameter in this contract has a numerical value.* Each has: an owner · a derivation procedure or a declared absence of one · and the consequence of setting it wrong. **Inventing a value would be false precision (§9.2), and §9.2's rules apply to numbers as well as to words.**

### 11.2 The open-research register — 14 items

| ID | Problem | Status | Why it is not solved here |
|---|---|---|---|
| **OR-1** | **Unknown-unknown capability detection** | **Structurally incomplete** | §4.4 R4.2: no detector set covers an unbounded capability space. **This contract does not claim to solve it; it claims A4 UNREGISTERED can never reach D6 DEPLOYED (§6.3), which is a weaker and achievable guarantee** |
| **OR-2** | **Specification correctness** | **Not verifiable from inside** | §8.6: D-S1…D-S7 improve detection *rate*, never establish *absence*. **A correct-specification claim is false precision** |
| **OR-3** | **Hardware root of trust** | **Vendor-dependent, side-channel-exposed** | §3.6/§11.3 A-5: attestation verifies identity, not correctness. Each side-channel disclosure retroactively invalidates a claim class |
| **OR-4** | **Correlated independence** | **No principled distinctness threshold** | U-01: N parties implementing one specification from one reading fail identically. **Real independence is organizational, not architectural** |
| **OR-5** | **Governance legitimacy** | **Unclosable regress** | §8.5 Layer 3→4: the regress stops at M-of-N human custodians + the genesis anchor. **CD-E8 is declared UNCLOSABLE, not resolved** |
| **OR-6** | **Real-world value vs. measured objective** | **Open (shared with P0-01)** | §8.4's residue 1: valuation is human. **Plus the selection-for-governability pressure: governance favours the legible and conventional** |
| **OR-7** | **Emergent-behaviour prediction** | **Open** | §8.4 M-ε: composition checkpoints default permit-and-measure because prediction is unavailable. **U-06: detection power unmeasured and possibly low** |
| **OR-8** | **Cross-project governance federation** | **Out of scope** | §9.1 R9.1: sharing tokens or policy across projects requires a shared root of trust — a governance act between projects, not a technical property |
| **OR-9** | **Legibility bound** | **No metric exists** | U-09/G34: «too complex to govern» has no measure. Candidates: replay-divergence rate · escalation rate vs. system size · OP review time per constitutional change |
| **OR-10** | **Rollback at extreme scale** | **Unknown, possibly negative** | U-03: whether a 10¹² population is ever rollback-feasible. **Be prepared for a negative result, in which case «manage forward» becomes permanent** |
| **OR-11** | **Governance throughput vs. evolution rate** | **Unmeasured tension** | §5.3 R5.1 + §8.5 R8.4: replication authorization makes generation time partly a governance quantity, and human attention bounds the governance rate. **The two have never been measured against each other** |
| **OR-12** | **Reward hacking at the governance layer** | **Unsolvable (G06)** | The organism optimizes what is measured; §8.4's envelope governance measures effects, but the mapping from effect-measure to value is OP's and is gameable at the margin |
| **OR-13** | **Governance capture (G24)** | **Unsolvable** | OP is the apex. **A captured OP is indistinguishable from a legitimate OP by any mechanism OP authorizes.** The only mitigation is external: W5's outside witness and §8.5 H-2's periodic reaffirmation, neither of which is a guarantee |
| **OR-14** | **The two unclosable circular dependencies** | **Declared** | **CD-E8** (the human channel: OP authorizes the rules that define OP's authority) · **CD-E11** (the specification cycle: the spec is validated by a review whose criteria the spec defines). **Neither is hidden. Neither is claimed resolved** |

**R11.2.** *Every `[UNRESOLVED]` marker in this contract maps to an entry here. Nothing is silently unresolved, and nothing here is claimed solved.*

### 11.3 The assumption ledger — 13 items

| ID | Assumption | Relied upon by | If false |
|---|---|---|---|
| **A-1** | The specification (§1–§10) is correct | Everything | §8.6 S-class defects; OR-2 |
| **A-2** | The reserved-operation set (§4.2) is complete | INV-02's coverage | **An ungoverned irreversible act. G-P02-2** |
| **A-3** | The effect-dimension set is complete | §8.4's envelope governance | An unbounded effect dimension. U-02 |
| **A-4** | `N_impl ≥ 3` implementations are genuinely distinct | §10.2 P3 detection | Correlated failure; OR-4 |
| **A-5** | **The hardware/firmware enforcing KC-3 resists the assumed attacker** | INV-30/31; all containment | **Containment fails silently. Platform-specific (G-P02-5); OR-3** |
| **A-6** | The root-key custody mechanism (M-of-N offline custodians) is not compromised | §10.3 | State 7; total re-baseline |
| **A-7** | **Custodians and policy authors are disjoint parties** (`[S]`, INV-47) | §8.5 Layer 4 | **Governance-of-governance collapses. Not engineerable** |
| **A-8** | The genesis anchor persists externally and is not rewritten | §7.4 W5; §10.3 step 5 | History is unrecoverable; root compromise is unverifiable |
| **A-9** | ≥1 provenance witness is outside operational control (INV-27) | §7.4 | Total history rewrite requires only internal compromise |
| **A-10** | **OP is constituted, available, competent, and uncaptured** | §8.5 H-1…H-4; RO-12/13/14 | **A10a unavailability ⟹ more restrictive (bounded). A10b capture ⟹ UNSOLVABLE (G24, OR-13)** |
| **A-11** | Human attention capacity exceeds the escalation rate | §8.5 R8.4; U-08 | Governance queue grows; G32 sunset starvation |
| **A-12** | The attestation environment is not shared with the attested environment | §10.1 P1 | **CD-E7 — the only DANGEROUS circular dependency** |
| **A-13** | **The designers' latent assumptions are not universally shared by every GP principal** (IND-6) | §8.1's independence claim | **EVA and KC agree because they were built by the same reading of the same assumptions. Not engineerable; the real-world anchor (P0-01 INV-43) is the only mitigation** |

**R11.3 (THE HONEST STATEMENT).** *A-1, A-7, A-10, A-12, and A-13 cannot be discharged by any mechanism inside this contract.* **A-7 and A-13 are not engineerable at all — they are properties of the parties, not of the architecture.** An implementation that does not publish this ledger has hidden its assumptions, which §9.2's «trusted» definition makes a defect.

### 11.4 The gap register (P0 / P1 / P2)

**P0 — 6 items, blocking:**
**G-P02-1** no formal specification of `F` exists ⟹ formalize the domain (enumerable now: 15 × 7 × 6) and model-check it · **G-P02-2** reserved-set completeness unreviewed ⟹ the finite enumeration review of A-2 · **G-P02-3** **OP is not constituted** ⟹ name the principals, publish the separation-of-duties matrix, establish A-7 · **G-P02-4** root key + genesis anchor absent and the recovery procedure undrilled ⟹ provision, notarize externally, **drill (R10.3)** · **G-P02-5** KC-3's hardware enforcement point unidentified for any platform ⟹ per platform class, state what it resists and what it does not · **G-P02-6** the nine inherited «EIK * Authority» names remain in the Cell Contract ⟹ re-issue per §2.3.

**P1 — 8 items, blocking trustworthy operation:** G-P1-1 diverse KC implementations · G-P1-2 external attestor + CD-E7 rating · G-P1-3 policy language and formal semantics · G-P1-4 envelope bounds and rung criteria (blocked by P0-01 G-P0-1) · G-P1-5 the §6.2 fault-injection harness · G-P1-6 W5's external arrangement · G-P1-7 escalation thresholds calibrated against measured OP capacity · G-P1-8 the Cell Contract re-issue work list (X-3/X-4/X-6/X-8/X-9).

**P2 — 8 items, refinement and scale:** G-P2-1 composition-detection power · G-P2-2 effect-dimension completeness review · G-P2-3 legibility metric · G-P2-4 cross-project federation · G-P2-5 `θ_rollback_cost` at 10¹² · G-P2-6 algorithm diversity · G-P2-7 the 15 moved-capability ablations, run rather than argued · G-P2-8 policy canary suites encoded from §10.5's 12 structural scenarios.

**R11.4 (THE PATTERN).** *4 of the 6 P0 gaps are not specification gaps.* They are: **write a formal artifact** (G-P02-1) · **perform a finite review** (G-P02-2) · **staff an authority** (G-P02-3) · **provision and drill a recovery path** (G-P02-4). **The governance specification is now sufficient to proceed. Further specification has diminishing returns.**

---

## §12. THE CONTRACT'S OWN CLAIMS

### 12.1 What this contract establishes

```
✅  A MINIMAL GOVERNANCE BOUNDARY, precisely defined: 4 capabilities,
    15 reserved operations, an enumerable decision domain of 630 cells.
✅  A TRUST BOUNDARY with a membership TEST (R3.1), not a list.
✅  AUTHORITY FLOWS in a 15 × 9 matrix with one state per cell (R4.1).
✅  INVARIANT SEMANTICS: 60 invariants, each with statement, enforcement,
    dependency, attack prevented, verification method, and enforceability
    class; 21 verified-achievable, 26 tested, 13 assumed.
✅  FAILURE BEHAVIOUR: an 11-state degradation ladder, a 40-row failure
    matrix, and TWO GENERATING RULES (R6.2a/b/c) that resolve unlisted cases
    identically for independent teams.
✅  POLICY EVOLUTION: 5 layers, 5 change classes, 7 immutability kinds,
    10 policy states, and a reproducibility semantics (INV-50).
✅  EVALUATOR SEPARATION: Model D, 6 interface rules, 2 typed channels,
    and a renaming table (§2.3) that resolves a live interoperability defect.
✅  CAPABILITY GOVERNANCE: two orthogonal axes (6 alethic × 8 deontic
    states), an 8-dimension effect envelope, and the promotion/demotion
    asymmetry (§6.3).
✅  SCALABILITY: KC load is O(regions + governance events), NOT O(subjects).
    Four techniques, a cost discipline (R10.6), and a partition policy.
✅  INTERFACES for two independent teams to build interoperable
    implementations across all nine agreement items (§9.1).
```

### 12.2 What this contract does NOT establish

```
❌  PERFECT SAFETY.        Tier-1 constraints hold under a policy; a wrong
                           policy enforces harm reliably (A-1, OR-2).
❌  PERFECT GOVERNANCE.    Bounded by human attention (A-10, A-11, U-08).
                           G24 governance capture is unsolvable (OR-13).
❌  GUARANTEED CONTAINMENT. KC-3 depends on hardware whose resistance is
                           platform-specific and partially assumed (A-5).
❌  EMERGENCE PREDICTION.  Composition effects are permit-and-measure,
                           not predicted (OR-7, U-06).
❌  COMPLETE UNKNOWN-CAPABILITY DETECTION. **Structurally impossible**
                           (OR-1). The achievable guarantee is narrower and
                           is stated precisely: **A4 UNREGISTERED can never
                           reach D6 DEPLOYED.**
❌  AGI, SUPERIORITY, OR CONSCIOUSNESS. **Not claimed, not implied, not
                           relevant.** This contract governs a substrate and
                           makes no claim about what the substrate becomes.
❌  A CORRECT SPECIFICATION. Assumed (A-1) and attacked (§8.6), never
                           established.
❌  CLOSED CIRCULAR DEPENDENCIES. **11 found: 8 bounded, 1 dangerous
                           (CD-E7), 2 unclosable (CD-E8, CD-E11).**
                           Declared, not hidden.
```

### 12.3 Ratification

> **This contract is PROPOSED. It becomes V4 EIK & Governance Contract v1.0 upon:**
> **(1)** OP constitution (G-P02-3) · **(2)** formalization of `F` and successful model-checking of INV-11/12 (G-P02-1) · **(3)** the reserved-set completeness review (G-P02-2) · **(4)** root-key provisioning, external genesis anchoring, and a **drilled** recovery (G-P02-4) · **(5)** identification of KC-3's enforcement point per target platform class (G-P02-5) · **(6)** re-issue of the Cell Contract artifacts named in §2.3 and §11.4 G-P1-8 (G-P02-6).
>
> **Until then, every `[V4 REQUIRED]` statement in this document is a proposal, and no implementation may claim conformance.**

---

**END OF V4 EIK & GOVERNANCE CONTRACT v1.0**
*Analysis: `11_analysis_trust_authority.md` (A) · `12_analysis_attack_failure.md` (B) · `13_analysis_governance_scale.md` (C) · `14_analysis_adversarial_formal.md` (D) · `15_analysis_subsystems_consistency.md` (E). Verdicts, ratings, and the final standard: `README.md`.*
