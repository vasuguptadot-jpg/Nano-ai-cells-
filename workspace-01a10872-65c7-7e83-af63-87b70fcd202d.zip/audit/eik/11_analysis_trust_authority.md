# P0-02 — EXTERNAL INVARIANT KERNEL & GOVERNANCE BOUNDARY
## Volume A: Trust, Authority, and the Minimal Kernel (§0–§8)

**Package:** `/home/user/audit/eik/` · **Companions:** `12_analysis_attack_failure.md` (B) · `13_analysis_governance_scale.md` (C) · `14_analysis_adversarial_formal.md` (D) · `15_analysis_subsystems_consistency.md` (E) · `16_v4_eik_governance_contract_spec.md` (Output 28, canonical) · `README.md` (index, Outputs 1–3, 27, ratings, principles)
**Predecessors:** `../01_adversarial_architecture_audit.md` · `../cell-contract/` · `../task-fitness/`
**Class:** ARCHITECTURE ONLY. No implementation, no executable artifacts, no invented numerical parameters.

---

# §0. ARCHITECTURAL CONTEXT — AND THE FIRST ADVERSARIAL FINDING

## 0.1 What the brief asks, and what the record actually says

The brief instructs: **DO NOT ASSUME THAT EIK IS CORRECT.** The first responsibility is to determine whether the concept survives adversarial analysis. It does not survive unchanged. Here is what the inherited record contains.

The audit (Task 2) proposed **M02 — Off-Substrate Immutable Kernel** and defined its contents as:

> «Signed policy store, constraint verifier, resource enforcement at OS/hypervisor level, replication authority, fitness/test definitions, provenance anchor, audit log — all outside the evolvable substrate, human-authorized to change» — `../01_adversarial_architecture_audit.md`, M02

and the roadmap item **P0-02** repeats it:

> «Build the off-substrate immutable kernel. Signed constraints, resource enforcement at OS/hypervisor level, replication authority, fitness & test definitions, provenance anchor, audit log, operator interface with kill switch» — ibid., P0-02

The Cell Contract (Task 3) then went further. A grep of that package returns **nine distinct named authorities already resident in "EIK"**:

```
EIK Calibration Authority     (6 references)
EIK Trust Authority           (4)
EIK Immune Authority          (4)
EIK Replication Authority     (3)
EIK Verification Authority    (2)
EIK Resource Authority        (2)
EIK Genome Authority          (2)
EIK Fitness Authority         (2)
EIK Lifecycle Authority       (1)
```

plus, from the same package: EIK **Identity Root** (assigns `cell_id`, `lineage_id`, `generation`, `parent_cell_id`, `variant`, `contract_version`, `genome_hash`, `constraint_set_hash`), EIK **Constraint Store**, EIK **Operator Registry** (a *closed set* of permitted mutation operators), EIK **seed issuance** (`rng_seed_class: EIK_ISSUED`, with `rng_seed_provenance` tickets), EIK **integrity verification** («`integrity_checksum` … Cell computes, **EIK verifies**»), EIK **Merkle-root verification** over the memory store «at each checkpoint», EIK **held-out probe comparison** («`improvement_verified` gate — kernel compares before/after on a held-out probe set»), and EIK **write authority over `replication_eligibility`**.

## 0.2 The finding

> ### **The EIK as inherited is a god kernel. It holds at least nineteen distinguishable authorities across three mutually incompatible functional classes. It is not a minimal trusted computing base; it is a second organism that happens to be outside the first.**

This is not a stylistic complaint. It produces four concrete architectural failures, each of which the brief asks about in a later section:

| # | Failure | Where analysed |
|---|---|---|
| **1** | **The TCB is unverifiable.** §53/§54 of the brief and the audit's own M45 require that core invariants be *proven or model-checked*, not asserted. Nineteen authorities spanning identity, evaluation, immunity, resource metering, genome storage, and learning-gate comparison cannot be exhaustively tested, still less model-checked. **A root of trust too large to verify is not a root of trust; it is a component with a flattering name.** | §6, §33, §53 |
| **2** | **Authority concentration defeats evaluator separation.** P0-01 established that authoritative evaluation must be off-substrate and that organism estimates may not become verdicts. But the Cell Contract places the **Fitness Authority**, the **Calibration Authority**, the **Trust Authority**, and the **Verification Authority** inside the same principal that enforces safety and authorizes replication. That is **Model A/B of §8**, not Model D — and it makes evaluator capture and EIK capture the *same event*. | §8, §10, §29 (attack 27) |
| **3** | **The kernel is in the hot path.** Per-cell seed issuance, per-cell integrity verification, per-checkpoint Merkle verification, and per-homeostatic-adjustment approval are all `O(cells)` round-trips to a single authority. At the Cell Contract's own stated cluster scale (10⁶–10⁷ cells, and the brief's 10⁹–10¹²), this is a **performance and availability catastrophe** before it is a security one. | §27, §49, §11 |
| **4** | **Two different kinds of authority have been conflated.** This is the root cause of failures 1–3, and resolving it is the main positive result of this package. | §0.3, §3, §8 |

## 0.3 The root cause: two orthogonal authority axes, collapsed into one principal

The inherited design uses one word — *authority* — for two things that have different truth conditions, different failure semantics, different scalability profiles, and different adversaries.

```
┌────────────────────────────────────────────────────────────────────────────┐
│ ALETHIC AUTHORITY  —  authority to say what IS THE CASE                     │
│                                                                            │
│   Truth-valued. Answers: is this belief accurate? is this candidate better? │
│   is this cell miscalibrated? did this outcome occur?                       │
│   Requires: measurement, ground truth, statistics, sampling, uncertainty.   │
│   Fails by: being WRONG. Its failure is epistemic.                          │
│   Scales by: sampling, batching, delegation of measurement.                 │
│   Specified by: **P0-01**, as the lattice                                    │
│      L0 ℛ → L1 GT sources → L2 EVA → L3 organism interface                  │
│      → L4 organism estimate → L5 cell estimate                              │
│   with INV-02 (no upward flow) and INV-03 (monotone non-amplification).     │
├────────────────────────────────────────────────────────────────────────────┤
│ DEONTIC AUTHORITY  —  authority to say what MAY BE DONE                     │
│                                                                            │
│   Permission-valued. Answers: is this operation permitted? is this subject  │
│   eligible? is this policy the authorized one? is this action within        │
│   envelope?                                                                 │
│   Requires: a signed policy artifact and a TOTAL, DETERMINISTIC decision    │
│   function over it. **No measurement. No statistics. No judgement.**        │
│   Fails by: being BYPASSED or being MISAPPLIED. Its failure is deontic.     │
│   Scales by: pre-authorization, delegation certificates, cached decisions.  │
│   Specified by: **NOTHING, until this document.**                           │
└────────────────────────────────────────────────────────────────────────────┘

THE COLLAPSE:  P0-01 built the alethic axis and located its apex at "EVA,
off-substrate." The Cell Contract and the audit built the deontic axis and
located its apex at "EIK, off-substrate." Both then used the SAME NAME for
whichever axis was convenient — hence "EIK Fitness Authority" (alethic work
in a deontic principal) and "EIK Calibration Authority" and "EIK Trust
Authority," and hence P0-01's own text alternating between "EVA-signed"
fitness and "EIK automatic" halts without ever relating the two principals.
```

## 0.4 The separation principle (the central result of this package)

> ### **R0.1 (AXIS SEPARATION).** Alethic and deontic authority are orthogonal. **No single principal may hold both.** The EIK holds deontic authority **only** and MUST have no alethic authority whatsoever. The Evaluator holds alethic authority **only** and MUST have no deontic authority whatsoever.

**R0.2 (THE TWO PERMITTED COUPLINGS).** The axes interact through exactly two narrow, signed, unidirectional channels:

```
CHANNEL 1 — POLICY CHANNEL:   EIK ──► EVA
   EIK authenticates the IDENTITY of the constitutional policy artifact
   (objective, tier-1 constraint set, sampling policy, evaluation depth
   mapping) under which EVA operates. EIK signs the policy REFERENCE
   (hash + version). **EIK never computes, influences, or re-scores a
   measurement, and never selects an evaluator.**

CHANNEL 2 — CONSEQUENCE CHANNEL:   EVA ──► EIK
   EVA's signed verdict is an INPUT to EIK's enforcement decision. EIK
   applies the policy's consequence function to the verdict and may
   halt, freeze, quarantine, or refuse authorization. **EIK may not
   alter, re-score, suppress, or substitute the verdict.**
```

**R0.3 (WHY THIS IS NOT A CYCLE IN THE JUSTIFICATION SENSE).** Channel 1 concerns *which rules apply*; Channel 2 concerns *what happened*. Neither principal's correctness depends on the other's output: EVA's verdict is correct iff it faithfully measures against ground truth under policy `P` — EIK authenticating `P` does not make `P` correct (that is OP's authorship and ℛ's arbitration, per P0-01 §42.1). EIK's enforcement is correct iff it applies `P`'s consequence function to the verdict faithfully — EVA producing the verdict does not determine whether the consequence function is right. **The control flow is cyclic; the justification is not.** Classified **BOUNDED** in §25, with closure external (OP + ℛ).

**R0.4 (EIK MUST BE A MECHANISM, NOT A POLICY-MAKER).** Every EIK decision MUST be a **total, deterministic, mechanically checkable function** of `(authorized_policy_artifact, request)`. EIK MUST NOT learn, adapt, optimize, sample, estimate, weigh, or exercise discretion. **Any capability requiring judgement is by definition alethic and is therefore forbidden to EIK by R0.1.**

**Why R0.4 is the minimality criterion and not merely a preference:** a total deterministic function over a finite, enumerated request domain can be exhaustively tested and, at the sizes involved (§6.3), model-checked. A function involving judgement cannot. **The TCB must be small enough to verify, because an unverified TCB provides no assurance — it merely relocates the assumption.** This is the formal content of «minimum trusted computing base» and it is what disqualifies nineteen of the inherited authorities.

## 0.5 A second conflation this package must undo: *off-substrate* ≠ *in the TCB*

The audit's M02 formulation is «all **outside the evolvable substrate**» and then lists seven subsystems. But *being outside the substrate* is a **location** property, and *being in the trusted computing base* is a **trust** property. They are not the same, and treating them as the same is what produced the god kernel.

```
                        ┌─────────────────────────────────────────────┐
                        │        OFF-SUBSTRATE (not organism-         │
                        │        controlled resources)                │
                        │                                             │
   ┌────────────────┐   │   ┌───────────────────────────────────┐    │
   │   ORGANISM     │   │   │  KC — KERNEL CORE  = the TCB      │    │
   │  (evolvable,   │   │   │  signature verifier · total       │    │
   │   mutable,     │   │   │  authorization function ·         │    │
   │   self-        │   │   │  substrate ceiling enforcer ·     │    │
   │   modifying)   │   │   │  freeze mechanism                 │    │
   │                │   │   │  **MUST BE VERIFIABLE**           │    │
   │  cells,        │   │   └───────────────────────────────────┘    │
   │  circuits,     │   │                                             │
   │  regions,      │   │   ┌───────────────────────────────────┐    │
   │  workspace,    │   │   │  GP — GOVERNANCE PERIMETER        │    │
   │  immune,       │   │   │  off-substrate but NOT in the TCB │    │
   │  homeostasis,  │   │   │  EVA · Task Authority · Genome    │    │
   │  self-model,   │   │   │  Store · Provenance Anchor ·      │    │
   │  memory        │   │   │  Identity Registrars · Attestors ·│    │
   │                │   │   │  Immune Service · Operator Iface  │    │
   └────────────────┘   │   └───────────────────────────────────┘    │
                        └─────────────────────────────────────────────┘

SEPARATION 1 (audit F4's fix):   ORGANISM  vs.  OFF-SUBSTRATE
SEPARATION 2 (new, required):    KC (TCB)  vs.  GP (off-substrate, non-TCB)
```

**R0.5 (TWO SEPARATIONS, NOT ONE).** The architecture requires **both** separations, and they have different failure semantics:

| | **GP compromise** | **KC compromise** |
|---|---|---|
| Detectable from inside the system? | **YES** — KC still enforces; the Provenance Anchor still records; cross-principal disagreement is visible | **NO** — the instrument that would detect it is the compromised thing |
| Recoverable? | **YES** — revoke the principal's delegation, re-baseline, re-issue | **Only via a pre-provisioned external path** (§10.4) |
| Blast radius | Bounded by KC's ceilings and the reserved-operation set | **Unbounded** |
| Design consequence | GP principals may be numerous, complex, replaceable, and may even learn | **KC must be tiny, frozen, non-learning, and independently attested** |

**This is the single most consequential structural claim in the package:** *most of what the inherited design put in "EIK" belongs in GP, not KC.* Moving it there preserves every safety property the relocation was meant to achieve (it remains outside the organism, per audit F4) while removing it from the TCB (per §6 minimality). **The audit was right that these functions must leave the organism. It was not right that they must all enter the kernel.**

---

# §1. PRIMARY OBJECTIVE

## 1.1 The question, restated precisely

> «What is the minimum external governance boundary required to prevent the Digital Brain from changing the rules that govern safety, identity, authority, evaluation, evolution, resource limits, provenance, integrity, lifecycle, rollback, capability escalation, and environmental interaction — while preserving as much autonomy, adaptation, decentralization, emergence, and evolution as possible?»

## 1.2 Reformulated in terms of §0.3

The question decomposes, and the decomposition is what makes it answerable:

```
(a) Which of the twelve listed domains require DEONTIC authority at all?
    ⟶ §4 taxonomy. Answer: all twelve, but at four different enforcement
      points, only one of which is the kernel.

(b) Of those requiring deontic authority, which require a TOTAL
    DETERMINISTIC decision (⟹ KC) and which require judgement
    (⟹ GP, per R0.4)?
    ⟶ §6. Answer: four capabilities require KC. Fifteen inherited
      authorities require judgement and must leave.

(c) What is the smallest KC that closes every path by which the organism
    could alter its own governing rules?
    ⟶ §6.3. Answer: KC-1..KC-4, with a stated closure argument.

(d) What must the organism retain so that autonomy, adaptation,
    decentralization, emergence, and evolution survive?
    ⟶ §39. Answer: everything not in the reserved-operation set — which
      is ~all of the organism's actual behaviour. The reserved set is
      15 operations (§7.2), not "all operations."

(e) What happens when KC fails, is wrong, is unavailable, or is captured?
    ⟶ §10, §11, §12, §13. Answer: fail-safe to a pre-authorized minimal
      envelope; never fail-open; never let the organism supply the
      recovery image.
```

## 1.3 The seven questions the brief requires answered

| Question | Answer | Location |
|---|---|---|
| «What must be immutable/external?» | The **constitutional policy artifact** (signed, versioned) and the **four KC capabilities**. Everything else is off-substrate-but-mutable (GP) or organism-internal (mutable). | §5, §6 |
| «What may be mutable/evolvable?» | All cell state, all genomes, all connections, all circuits, all regions, all learned parameters, all internal estimators, immune/homeostatic *behaviour within envelope*, and the entire task/curriculum surface below the constitutional layer. | §15, §39 |
| «Who has authority over each boundary?» | The authority matrix — 15 reserved operations × 7 principals × 6 explicit authority states. | §7 |
| «How is that authority represented?» | Signed capability tokens + delegation certificates + the reserved-operation request/response protocol. **Representation is a signed statement, never an inference from behaviour.** | §19, §7.4 |
| «How is it authenticated?» | Signature verification against the authorized-key registry, at **read time** (P0-01 R40.3), with policy-version binding. | §19 |
| «How is it updated, if ever?» | Versioned immutability (§5.6): append-only policy lineage, dual OP authorization, no retroactive alteration, historical reproducibility preserved. | §5, §14 |
| «What happens when the kernel itself fails?» | §10 (wrong) · §11 (SPOF) · §12 (unavailable) · §13 (per-operation failure semantics). **Summary: fail-safe to the minimal envelope; the organism never supplies the recovery.** | §10–§13 |

---

# §2. FIRST PRINCIPLE — THE SEVEN ALTERNATIVES, RIGOROUSLY COMPARED

**OUTPUT 3.** The brief forbids selecting EIK merely because the previous audit proposed it. Seven alternatives are analysed; each is scored against six criteria derived from §1.

## 2.1 The evaluation criteria

| Criterion | Question it answers | Why it is a criterion |
|---|---|---|
| **C1 Non-self-reference** | Can the organism alter the rules by which it is judged? | Audit F4. The terminal failure mode |
| **C2 Verifiability of the TCB** | Can the trusted part be exhaustively tested or model-checked? | R0.4. An unverified TCB relocates the assumption rather than discharging it |
| **C3 Capture resistance** | How many principals must be subverted, and is their compromise detectable? | §10, §23. «External does not automatically mean trustworthy» |
| **C4 Availability under failure** | What happens when the mechanism is wrong, unavailable, or partitioned? | §12, §13 |
| **C5 Scalability** | Cost as population goes 10 → 10¹² | §27 |
| **C6 Evolution compatibility** | Does it permit mutation, recombination, differentiation, emergence, novel architecture? | §39. A safety mechanism that forbids emergence defeats the project |

## 2.2 Alternative A — Fully external kernel

*All critical invariants live outside the organism, in one external principal.*

| | Assessment |
|---|---|
| **Mechanism** | A single external kernel holds policy, verification, identity, evaluation, resources, provenance, and lifecycle authority. **This is the inherited design (§0.1).** |
| **C1** | ✅ **Strong.** Nothing the organism does reaches the rules |
| **C2** | ❌ **Fails.** The TCB is nineteen authorities wide (§0.2 failure 1). Not model-checkable, not exhaustively testable |
| **C3** | ❌ **Fails.** Single principal; **KC and GP compromise are the same event**; evaluator capture = kernel capture (§0.2 failure 2) |
| **C4** | ❌ **Fails.** Single point of failure, censorship, bottleneck, epistemic failure, evolution bottleneck, and governance capture — all six at once (§11) |
| **C5** | ❌ **Fails.** Kernel in the hot path for per-cell operations (§0.2 failure 3) |
| **C6** | ⚠️ **At risk.** A kernel this large accumulates veto points; every one is a place emergence can be accidentally forbidden (§45) |
| **Verdict** | **REJECTED.** It satisfies the one property it was designed for (C1) and fails the other five. **This is the most important negative result in §2: the audit's M02, taken literally, is the wrong architecture.** |

## 2.3 Alternative B — Distributed governance

*Invariant authority is distributed across multiple independent subsystems.*

| | Assessment |
|---|---|
| **Mechanism** | No single kernel. Invariants are enforced by a quorum of independent subsystems; no one of them can authorize a constitutional change alone |
| **C1** | ⚠️ **Conditional.** Strong iff the subsystems are genuinely independent. **§35 shows independence fails through shared code, data, lineage, model, hardware, latent assumptions, task generator, evaluator, and governance.** Subsystems built by one team, from one specification, on one hardware class, are **not** independent — they are correlated, and a single specification bug defeats all of them simultaneously |
| **C2** | ⚠️ Each subsystem may be small enough to verify, but the **quorum protocol** itself becomes part of the TCB and is notoriously hard to verify (consensus bugs, split-brain, Byzantine edge cases) |
| **C3** | ✅ **Strong against single-principal capture.** ❌ **Weak against correlated failure** — which is the realistic threat, not independent compromise |
| **C4** | ⚠️ Better availability, but **new failure semantics**: partition, quorum loss, split-brain. §26 shows the brain is asynchronous and partially connected, so partitions are normal, not exceptional |
| **C5** | ❌ Quorum round-trips are **worse** than a single kernel round-trip: `O(quorum size)` messages per authorization, with tail latency set by the slowest member |
| **C6** | ⚠️ Quorum latency on every reserved operation slows evolution |
| **Verdict** | **REJECTED AS THE PRIMARY MECHANISM; ADOPTED AS A COMPONENT.** Distribution is the right answer for the **Provenance Anchor** and for **attestation** (where correlated failure is detectable by disagreement) and the wrong answer for **authorization** (where latency and partition semantics are disqualifying). **The actual failure semantics, not the distributed-systems vocabulary: a quorum that cannot assemble does not "lose availability," it loses the ability to say no — and a governance system that cannot say no during a partition has failed safe only if the default is deny (§13).** |

## 2.4 Alternative C — Hardware / root-of-trust boundary

*Some invariants are enforced by hardware or a lower-level trusted substrate.*

| | Assessment |
|---|---|
| **Mechanism** | Secure enclave / TPM / hypervisor-level resource enforcement / physically separate machine |
| **C1** | ✅ **Strongest available.** Hardware enforcement is not reachable by any software the organism controls, including software running as root on the host |
| **C2** | ⚠️ The hardware itself is a TCB whose correctness is **assumed, not verified** — and the assumption is placed in a vendor, not in this project (§36, §57) |
| **C3** | ✅ Strong against software capture. ❌ **Introduces new classes**: side channels, firmware bugs, supply-chain compromise, physical attack. **And hardware roots of trust have empirically failed** — this is not a hypothetical |
| **C4** | ⚠️ Hardware is *more* available than software but **less recoverable**: a failed enclave cannot be restarted into a good state without vendor-specific recovery, and attestation may become permanently unverifiable |
| **C5** | ❌ **Severe.** Enclave round-trips are expensive; secure memory is small; per-cell operations cannot go through an enclave at 10⁹ scale. **Hardware trust is a scarce resource and must be spent only where nothing else works** |
| **C6** | ✅ Neutral — hardware does not constrain what the organism may evolve, only where enforcement happens |
| **Verdict** | **PARTIALLY ADOPTED — for exactly two things.** (i) **Substrate resource-ceiling enforcement (KC-3)**, because it is the only enforcement point the organism cannot bypass even with host-level code execution. (ii) **Root-key custody for the constitutional signing key**, because a key that can be extracted by software is not a root. **NOT adopted for policy evaluation, identity issuance, provenance, or evaluation** — §36 gives the full trade-off analysis, and the governing caution is the brief's own: *hardware trust does not automatically solve software governance.* A perfectly attested enclave enforcing a **wrong policy** is a very reliable way to do the wrong thing (§38). |

## 2.5 Alternative D — Cryptographic governance

*Authority enforced primarily through signed policies and capabilities.*

| | Assessment |
|---|---|
| **Mechanism** | Every authorization is a signed capability token; every policy is a signed artifact; every delegation is a signed certificate. No central decision point is needed at request time — a holder of a valid token acts |
| **C1** | ✅ **Strong, and elegantly so.** The organism cannot forge a signature. **Capability tokens make authority a possessable object rather than a query**, which removes the kernel from the hot path entirely |
| **C2** | ✅ **Excellent.** The TCB reduces to a signature verifier plus a token-schema checker plus a revocation check — small, well-understood, formally verifiable |
| **C3** | ⚠️ **Shifts the threat rather than removing it.** Key compromise becomes the catastrophic event; **revocation becomes the hard problem** (a leaked token is valid until revoked, and revocation requires a freshness channel — which requires a round-trip, which reintroduces the hot path) |
| **C4** | ✅ **Best availability of all alternatives.** Verification is local. Partition-tolerant: a token issued before the partition remains checkable after it |
| **C5** | ✅ **Best scalability.** `O(1)` local verification; no per-operation coordination |
| **C6** | ✅ Excellent — no coordination latency on evolution |
| **Verdict** | **ADOPTED AS THE PRIMARY ENFORCEMENT MECHANISM.** Cryptography is what makes a *minimal* kernel possible at all: because authorization can be **pre-issued and locally verified**, the kernel need not be consulted per operation. **But it is necessary and not sufficient**, for three reasons developed in §19: (i) **revocation is the hard part** — signed capabilities are easy to issue and hard to un-issue; (ii) **a valid token does not make the requested action safe** — capability tokens encode *what* is permitted, not *whether this instance* is within envelope, which requires the substrate meter (KC-3); (iii) **cryptographic governance has no answer to a wrong policy** — it faithfully enforces whatever is signed, including a signed mistake (§38). |

## 2.6 Alternative E — Layered governance

*Different classes of invariants live at different trust levels.*

| | Assessment |
|---|---|
| **Mechanism** | Constitutional invariants at the highest level; policy at the next; operational rules lower; local conventions lowest. Each layer may constrain the layers below and may not be modified by them |
| **C1** | ✅ Strong, **provided the layering is enforced and not merely declared.** A layer diagram that nothing checks is documentation |
| **C2** | ✅ Good — each layer can be verified separately, and the *inter-layer* rules are small |
| **C3** | ✅ Good — compromise of a lower layer does not compromise a higher one |
| **C4** | ✅ Good — lower layers can fail-safe independently |
| **C5** | ✅ Good — most enforcement happens at low layers, locally |
| **C6** | ✅ **Best of all alternatives.** Lower layers are where adaptation lives, so layering *preserves* autonomy by confining authority rather than by centralizing it |
| **Verdict** | **ADOPTED AS THE ORGANIZING STRUCTURE.** Layering is not an alternative to A–D; it is the frame in which they compose. §15 gives the layer stack and §28 derives the granularity. **The specific danger layering introduces is layer-count creep** — every new layer is a new place for a gap, and §15.4 shows that four layers are sufficient and five are already too many to keep the inter-layer rules verifiable. |

## 2.7 Alternative F — Hybrid EIK

*A minimal external kernel combined with distributed, cryptographic, and hardware mechanisms.*

| | Assessment |
|---|---|
| **Mechanism** | KC (tiny, verifiable, hardware-anchored for two functions) + cryptographic pre-authorization for the hot path + GP services for judgement-requiring work + distributed anchoring for provenance + layered structure for granularity |
| **C1–C6** | Inherits the strengths of D, E, and the two narrow uses of C; avoids A's failures; uses B only where correlated failure is detectable |
| **Verdict** | **SELECTED — and specified exactly, as the brief's Rule requires.** The hybrid is not «a bit of everything.» It is: **§6.3's four KC capabilities** · **§19's capability-token enforcement with the revocation protocol** · **§2.4's two hardware anchor points only** · **§15's four governance layers** · **§20's distributed provenance anchoring** · **§8's Model D evaluator separation.** Anything not on that list is not in the hybrid. |

## 2.8 Alternative G — No explicit EIK

*Can the architecture remain safe without one?*

This is the alternative that must be taken most seriously, because it is the one that would falsify the whole programme.

**What «no EIK» concretely means:** invariants are enforced by the organism's own subsystems (immune, homeostasis, self-model, internal verification) plus social/process controls (operator review, audit, deployment protocol). **This is V3/V3.1 as written.**

| | Assessment |
|---|---|
| **C1** | ❌ **Fails outright.** This is audit F4: «A system that can modify its own constraints has no constraints.» The V3 «immutable safety layer» and «evolutionary firewall» are components *inside* the organism, on the same substrate, subject to the same evolution, repair, and plasticity as everything else. **Nothing in the design sits outside the thing it constrains** |
| **Is there a weaker version that works?** | ⚠️ **Partially, and it is worth stating.** A system with (i) a *non-evolving* substrate, (ii) no self-modification of code, (iii) no replication authority, and (iv) full external monitoring could be governed without an EIK — because there would be no mechanism by which the rules could be changed from inside. **That system is not the Digital Brain.** The Digital Brain's entire thesis is evolvable, self-modifying, replicating cells. **The need for an external deontic authority is a consequence of the thesis, not an addition to it** |
| **What if the organism is bounded instead of governed?** | ⚠️ **This is the strongest no-EIK argument and it deserves a real answer.** If the organism is confined to a sandbox with no actuators, no network egress, and a hard resource cap enforced by the host OS, then the host *is* the deontic authority and no EIK is needed — the containment is the governance. **Answer: this works, and it is exactly what P0-01's deployment Stage 0 specifies.** But it works only while the system is *contained*, and the project's purpose is to deploy. **At the moment of deployment the host-level cap must be expressed as a policy, and a policy requires an authenticator — which is KC-1.** So the no-EIK position is correct for Stage 0 and self-defeating thereafter |
| **C2–C6** | C2 trivially satisfied (there is no TCB) — **which is the tell**: a system with no TCB has not eliminated trust, it has *relocated* trust into every component simultaneously. C3–C6 all fail because enforcement is substrate-dependent |
| **Verdict** | **REJECTED for the deployed system; VALID for the sandboxed system.** The honest formulation: **«no EIK» is not a design option for an evolvable deployed organism; it is the design that V3 already has, and the audit already found it disqualifying.** What *is* a live option — and what §6 delivers — is an EIK so small that the difference between «minimal EIK» and «no EIK» is four capabilities and one signing key |

## 2.9 The comparison, summarized

| Alternative | C1 non-self-ref | C2 verifiable TCB | C3 capture resist | C4 availability | C5 scalability | C6 evolution | Verdict |
|---|---|---|---|---|---|---|---|
| **A** Fully external kernel | ✅ | ❌ | ❌ | ❌ | ❌ | ⚠️ | **REJECTED** (the inherited design) |
| **B** Distributed governance | ⚠️ | ⚠️ | ✅/❌ correlated | ⚠️ | ❌ | ⚠️ | Rejected as primary; **adopted for provenance + attestation** |
| **C** Hardware root of trust | ✅ | ⚠️ assumed | ✅/❌ new classes | ⚠️ | ❌ | ✅ | **Adopted for 2 functions only** (KC-3, root-key custody) |
| **D** Cryptographic governance | ✅ | ✅ | ⚠️ revocation | ✅ | ✅ | ✅ | **ADOPTED as primary enforcement** |
| **E** Layered governance | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **ADOPTED as organizing structure** |
| **F** Hybrid | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **SELECTED** — specified exactly at §2.7 |
| **G** No explicit EIK | ❌ | (vacuous) | ❌ | ❌ | ✅ | ✅ | **REJECTED** for deployment; valid for sandbox |

> ### **OUTPUT 2 — SHOULD EIK EXIST? YES, BUT NOT THE EIK THAT WAS PROPOSED.**
>
> **An external deontic authority must exist**, because the organism is evolvable and self-modifying by thesis, and audit F4's argument is sound: a constraint the constrained party can modify is not a constraint. Alternative G fails on C1 and its only strong form (containment) is a temporary condition, not an architecture.
>
> **But the EIK as inherited must be dismantled.** Nineteen authorities are reduced to **four KC capabilities** (§6.3). Fifteen move to the Governance Perimeter, where they remain off-substrate — preserving the audit F4 fix — but leave the TCB, restoring verifiability, capture resistance, availability, and scalability.
>
> **The correct statement of the result is not «build the EIK» but «the EIK is four things, and the other fifteen are somewhere else.»**

---

# §3. THE TRUST BOUNDARY — **OUTPUT 4**

## 3.1 Trusted Computing Base

> **Definition.** The TCB is the set of components whose *misbehaviour* can cause a constitutional invariant to be violated, and whose correct behaviour therefore must be *assumed or verified* rather than *tested from outside*.

**The operative clause is «must be assumed or verified.»** A component is in the TCB not because it is important, but because **its failure cannot be detected and corrected by anything else in the system.** That is the test, and it is what excludes the Governance Perimeter: GP compromise *is* detectable (by KC enforcement, by cross-principal disagreement, by the anchor), so GP is not in the TCB even though GP is off-substrate and safety-relevant.

```
┌─ TCB (KC — Kernel Core) ─────────────────────────────────────────────┐
│ KC-1  Constitutional Policy Authenticator                            │
│         signature verifier + version registry + policy-hash binding   │
│ KC-2  Reserved-Operation Authorization Function                      │
│         total, deterministic, over the 15-operation reserved set      │
│ KC-3  Substrate Ceiling Enforcer                                     │
│         hardware/OS-level caps on the 8 resource dimensions           │
│ KC-4  Freeze Mechanism                                               │
│         signed halt command, verified at the substrate                │
│ ─────────────────────────────────────────────────────────────────    │
│ PLUS, unavoidably:                                                    │
│   • the constitutional signing root key + its custody mechanism       │
│   • the boot/measurement chain that establishes KC's own integrity    │
│   • the hardware/firmware KC-3 relies on                              │
│   • the specification of KC-2's decision function  ⟵ §38: a spec bug  │
│     is a TCB defect even when the implementation is perfect           │
└──────────────────────────────────────────────────────────────────────┘
```

**Trusted (in the TCB, correctness assumed or verified):** KC-1…KC-4 · the root signing key and its custody · the boot/measurement chain · the KC-3 hardware/firmware · **the KC-2 specification**.

**Explicitly NOT trusted** (their misbehaviour is detectable and correctable, so they are outside the TCB even though they are off-substrate and safety-relevant):

| Component | Why not trusted | How its misbehaviour is detected |
|---|---|---|
| **EVA** (evaluator) | It exercises judgement (alethic). Judgement can be wrong | `n_eval ≥ 3` independent implementations; disagreement ⇒ DISPUTED (P0-01 R8.9); canary known-bad suite |
| **Task Authority / GVA** | Authors and validates tasks; can be wrong or captured | Validity predicate R2.6; reference-population independence R19.2 |
| **Genome Store, Provenance Anchor** | Storage; can be corrupted or unavailable | Hash chains; cross-witness disagreement; re-derivation |
| **Identity Registrars, Attestors** | Delegated; can be compromised | Delegation certificates revocable by KC; cross-attestor disagreement |
| **Immune Service, Homeostasis** | Organism-level services exercising judgement | Envelope ceilings enforced by KC-3; budget accounting; audit anchor |
| **Operator Interface (OP)** | Human; can be deceived, tired, or captured socially | Dual authorization; signed constitutional-change artifacts; the audit record itself |
| **The organism, entirely** | Evolvable, self-modifying | Everything above |

**R3.1 (THE TCB TEST).** A component is in the TCB **iff** no other component can detect and correct its misbehaviour. **Applying this test is what shrinks the kernel.** Every inherited EIK authority that fails the test moves to GP: EVA's verdicts are checkable by other evaluators; genome storage is checkable by hash; identity issuance is checkable by cross-verification against the birth certificate; integrity verification is checkable by hierarchical attestation with disagreement detection. **KC-1…KC-4 pass the test because nothing outside them can verify a signature, apply the authorization function, enforce a substrate cap, or execute a freeze.**

**R3.2 — the honest residue.** The TCB contains items that cannot be shrunk further and cannot be verified from inside: **the root key's custody, the boot chain, the KC-3 hardware, and the KC-2 specification.** §36 and §38 treat these. **§57 lists them in the Open Research Register, because a TCB bottoming out in «we assume the vendor's firmware and our own specification» is the actual, unreduced state of the art — and saying so is more useful than claiming a fully verified root of trust.**

## 3.2 Trusted Authority — the twelve verdicts

The brief asks who may authoritatively say each of twelve things. **The answer is the axis separation: six of them are alethic and six are deontic, and no principal says both.**

| Verdict | Axis | **Authoritative principal** | Who may NOT say it | Instrument |
|---|---|---|---|---|
| **valid** (a measurement/artifact conforms) | Alethic | **EVA** (for measurements) · **KC-1** (for artifact *authentication*, which is deontic validity of a signature, not of a result) | Organism; cell; immune | Signed evaluation record / signature check |
| **invalid** | Alethic | EVA | Organism | As above |
| **authentic** / **unauthentic** | **Deontic** | **KC-1** | EVA (it may report a signature mismatch as a *fact*, but authenticity as a *status* is KC's) | Signature + version registry |
| **permitted** / **forbidden** | **Deontic** | **KC-2** | EVA; organism; immune; homeostasis; OP directly (OP acts only by changing policy, which KC then authenticates) | Reserved-operation decision |
| **authorized** / **unauthorized** | **Deontic** | **KC-2** (for the operation) · **KC-1** (for the delegation certificate) | Any organism component | Capability token / delegation cert |
| **eligible** / **ineligible** | **Deontic** | **KC-2**, applying policy to EVA-supplied facts | **The organism may READ its eligibility but may not write, grant, or act on it** (Cell Contract: «Eligibility is a report, not a capability» — preserved) | Signed eligibility state |
| **safe** / **unsafe** | **BOTH — and this is the subtle one** | **EVA** says «this candidate satisfies/violates tier-1 constraint *c*» (alethic: a measurement). **KC-2** says «this operation is therefore forbidden» (deontic: a consequence). | **Neither alone.** EVA cannot forbid; KC cannot measure | Two signed records, one per axis |

**R3.3 (THE «SAFE» SPLIT).** «Safe» is the verdict most often conflated, and splitting it is the whole point of R0.1. **Measuring safety is alethic and fallible; enforcing safety is deontic and must not be fallible in the same way.** Consequences of the split:
- An EVA that measures wrongly produces a wrong *fact*; KC applies the policy faithfully to that wrong fact and produces a wrong *decision*. **The error is attributable**, because the two records are separate and separately signed (§10.3's blame requirement depends on this).
- A KC that is compromised cannot make a bad measurement *look* good; it can only misapply policy. **The two failure modes do not compound into one undetectable event** — which is precisely what Alternative A loses.
- **Neither principal can be replaced by the other under failure.** If EVA is unavailable, KC cannot substitute a measurement (§12: no fitness is issued). If KC is unavailable, EVA cannot substitute a permission (§12: no reserved operation proceeds).

## 3.3 Trust direction — every important interface

The brief warns: *do not assume that one-way flow is always sufficient.* It is not. Six of the thirteen interfaces below require bidirectional flow, and in four of them the "upward" direction is load-bearing.

```
LEGEND  ──► permitted · ──╳── prohibited · ◄──► bidirectional, both signed
        (annotated with what may flow in each direction)
```

| # | Interface | Direction | What flows | What MUST NOT flow | Rationale |
|---|---|---|---|---|---|
| **I-01** | **KC → organism** | ──► | Authorization decisions (permit/deny); eligibility states; envelope ceilings; freeze commands; policy-version identifiers | **Nothing requestable.** The organism cannot query KC in a way that shapes the answer | Deontic authority flows down only |
| **I-02** | **organism → KC** | ──► | Reserved-operation *requests*; attestation digests; self-reports (as evidence, never as verdict) | **Policy, invariants, eligibility, fitness, its own identity, its own resource accounting, its own audit entries** | This is the «no upward authority leak» channel (§24). Requests are permitted; *content that shapes the decision function* is not |
| **I-03** | **KC ↔ EVA** | ◄──► | **KC→EVA:** authenticated policy reference (hash+version). **EVA→KC:** signed verdicts as enforcement inputs | **KC→EVA:** any measurement, score, ranking, or evaluator selection. **EVA→KC:** any permission, authorization, or policy | R0.2's two channels. Bidirectional **and load-bearing in both directions** — a one-way KC→EVA link would leave KC unable to act on facts; a one-way EVA→KC link would leave EVA operating under unauthenticated policy |
| **I-04** | **organism ↔ EVA** | ◄──► | **organism→EVA:** behaviour (actions, observations submitted for scoring); `REQUEST_REEVALUATION` with evidence. **EVA→organism:** reward vectors (P0-01 §12), scored error, provisional ranking | **organism→EVA:** anything that alters what is measured, how, or on which tasks; sealed-task content; GT before commitment; sampling-policy influence. **EVA→organism:** its own verdict *as final authority* is fine, but EVA may not grant permissions | P0-01 R17.1, R34.1/R34.2. Bidirectional by necessity — evaluation is impossible without the organism's behaviour flowing up |
| **I-05** | **environment → KC** | ──► | Ground-truth-bearing physical facts (via GT sources); host/substrate resource telemetry; **external fault signals** | Policy; authorization; anything the environment could be induced to say by the organism | **This direction is required and is often omitted.** KC-3 enforces ceilings using *substrate* telemetry, which originates outside the organism. Without I-05, resource accounting is organism-reported and therefore gameable (§18) |
| **I-06** | **environment → organism** | ──► | Observations (evidence-classed E0–E4, P0-01 §6) | Ground truth before action commitment (INV-19); sealed task content | Observation ≠ truth |
| **I-07** | **organism → environment** | ──► | Actions (legality-classed L1–L4) | Irreversible actions without authorization; anything classified `L4 UNSAFE` | P0-01 §7 |
| **I-08** | **KC → GP services** | ──► | Delegation certificates (scope, lifetime, revocation handle); policy references | Discretionary instruction; per-case judgement | Delegation is what makes KC scalable (§27) |
| **I-09** | **GP services → KC** | ──► | Attestation digests; disagreement reports; revocation requests; service-health signals | Verdicts about other GP principals' *authority* (a GP service may report a fact; it may not revoke a peer) | Prevents GP-internal authority escalation |
| **I-10** | **OP → KC** | ──► | Signed constitutional-change artifacts (dual-authorized); freeze commands; key rotation | **Undocumented verbal instruction.** «The humans said so» is not an auditable channel (P0-01 R42.5) | Governance of governance (§23) |
| **I-11** | **KC → OP** | ──► | Audit anchor digests; anomaly escalations; DISPUTED notifications; freeze confirmations; **the complete record of every KC decision** | Nothing withheld. **KC MUST NOT filter what OP sees** | **Load-bearing upward direction.** A kernel that summarizes its own behaviour to its overseer is a kernel that can hide (§10.5) |
| **I-12** | **organism → OP** | ──► | Recommendations; `REQUEST_ATTENTION`; self-reports; capability-discovery notifications | **Authority.** A recommendation is evidence, never a permission (§24.2) | The «human-facing recommendation» channel — the most socially dangerous upward leak (§24) |
| **I-13** | **GP ↔ GP** | ◄──► | Cross-checks (evaluator↔evaluator, attestor↔attestor, anchor↔anchor) | Authority over one another | Independence requires communication; **§35 shows communication is also the correlated-failure vector**, so cross-checks must be between principals with distinct code, data, and lineage |

**R3.4 (WHERE ONE-WAY IS INSUFFICIENT).** I-03, I-04, I-08/I-09 (as a pair), I-11, I-12, and I-13 all require flow in a direction a naive "authority flows down" model forbids. The four that are *load-bearing* upward:
1. **I-03 EVA→KC** — without it KC cannot act on facts, so safety enforcement has no input.
2. **I-05 environment→KC** — without it resource ceilings rest on organism-reported accounting, which §18 shows is gameable seven ways.
3. **I-11 KC→OP** — without it the overseer sees only what the kernel chooses to show.
4. **I-12 organism→OP** — without it capability discovery (§17) has no escalation path, and unknown capabilities stay unknown forever rather than becoming governed.

**R3.5 (THE CONSTRAINT ON UPWARD FLOW).** Upward flow is permitted for **facts, requests, and evidence**. It is prohibited for **policy, verdicts-about-self, authority, and anything that shapes the decision function.** Formally: an upward channel is admissible iff the receiving principal's decision function is a **fixed, signed, versioned artifact** that the sender cannot alter — so that the sender may supply *input* but never *the mapping from input to output*.

---

# §4. INVARIANT TAXONOMY — **OUTPUT 5**

## 4.1 The fifteen required categories, plus four more

The brief lists I1–I15 and asks whether additional categories are necessary. **Four are.** Each of the four corresponds to a failure mode that the original fifteen cannot name — and in each case the inherited architecture has already suffered from the omission.

| ID | Category | Enforcement point | Axis | Notes |
|---|---|---|---|---|
| **I1** | **Safety invariants** | KC-2 (consequence) + EVA (measurement) | **Split** per R3.3 | «Things the organism must never violate» — but *violation detection* is alethic and *violation consequence* is deontic |
| **I2** | **Identity invariants** | KC-1 (delegation certs) + Registrars (issuance) | Deontic | Uniqueness, non-clonability, lineage integrity, birth-certificate binding |
| **I3** | **Authority invariants** | **KC-2** | Deontic | The reserved-operation set. **The core category** |
| **I4** | **Evaluation invariants** | EVA policy, authenticated by KC-1 | Alethic + deontic reference | P0-01's INV-01…INV-06, INV-25, INV-39…INV-42 |
| **I5** | **Evolution invariants** | KC-2 (replicate/deploy gates) + EVA (selection facts) | Split | Mutation bounds, selection legitimacy, deployment staging |
| **I6** | **Resource invariants** | **KC-3** (ceiling) + Homeostasis (allocation within ceiling) | Deontic + operational | **Enforcement and allocation are different acts at different points** — §18.4 |
| **I7** | **Provenance invariants** | Provenance Anchor (GP) + KC-1 (root authentication) | Deontic reference | Traceability of data, evidence, models, genomes, transformations, evaluations, decisions |
| **I8** | **Integrity invariants** | Attestors (GP, hierarchical) + KC-1 | Deontic | Protection against unauthorized modification/corruption |
| **I9** | **Lifecycle invariants** | KC-2 (reserved ops) + Lifecycle Service (GP) | Deontic | Birth, activation, suspension, quarantine, restoration, retirement, destruction |
| **I10** | **Capability invariants** | KC-2 (class enforcement) + EVA (classification facts) | **Split — and the split is §16's whole content** | «Do not rely solely on labels» |
| **I11** | **Interface invariants** | Type Registry + KC-1 (contract-version authentication) | Deontic | Cell↔cell, cell↔circuit, …, organism↔evaluator↔environment↔kernel |
| **I12** | **Recovery invariants** | KC-4 (freeze) + Checkpoint Service (GP) | Deontic | Rollback, checkpoint, recovery, disaster handling. **§48: repair without authorship** |
| **I13** | **Governance invariants** | **KC-1 + OP** | Deontic | Who may change governance itself. §23 |
| **I14** | **Epistemic invariants** | EVA policy + P0-01 lattice | Alethic | No false certainty, no provenance loss, no evaluator contamination, no evidence fabrication, no confidence manipulation |
| **I15** | **Anti-self-reference invariants** | **KC as a whole; R0.1 is the primary one** | **Both** | The organism may not redefine the rules by which it validates itself |
| **I16** ⭐ | **DELEGATION invariants** | KC-1 | Deontic | **NEW — REQUIRED.** Every delegation certificate has an explicit scope, lifetime, and revocation handle; **delegation is non-amplifying** (a delegate may not grant more than it holds); delegation depth is bounded; **a delegate may not delegate the power to delegate** beyond depth 1 without KC countersignature. *Why necessary: §27's scalability solution is delegation, and an unbounded delegation mechanism is an authority-laundering channel. The inherited design delegates identity, seeds, and attestation with no delegation invariant at all* |
| **I17** ⭐ | **TEMPORAL / FRESHNESS invariants** | KC-1 + KC-2 | Deontic | **NEW — REQUIRED.** Every authorization is bound to a policy version, a nonce/epoch, and an expiry. **A decision made under policy v2 is not re-validated under v3 by silence.** Replay is refused; stale policy is refused; **«currently authorized» is a distinct state from «was authorized»**. *Why necessary: §9's attack classes include replay, stale-policy exploitation, and race conditions — all three are temporal failures, and none of the fifteen categories can name them. P0-01 has fitness expiry (INV-12) but no authorization expiry* |
| **I18** ⭐ | **OBSERVABILITY / AUDITABILITY invariants** | Audit Anchor (GP) + KC's non-filtering duty (R3.4 I-11) | Deontic | **NEW — REQUIRED.** Every KC decision, every delegation, every policy transition, and every GP disagreement is recorded append-only and **KC MUST NOT filter what OP sees**. *Why necessary: a minimal kernel that is not observable cannot be audited, and an unauditable authority is unauditable governance. The inherited design has an audit log but no invariant forbidding the kernel from summarizing itself* |
| **I19** ⭐ | **NON-COMPOSITION invariants** | KC-2 + §25's cycle classification | Deontic | **NEW — REQUIRED.** Individually-authorized operations whose **composition** is unauthorized must be refused. *Why necessary: §9's «emergent policy interactions» and §29's attacks 23/25/30 are all composition failures — each step is permitted, the sequence is not. A per-operation authorization function with no composition rule is bypassable by sequencing. This is the hardest category and §4.4 states honestly how far it can be pushed* |

## 4.2 The taxonomy's organizing principle

```
                        ┌── ALETHIC (what is the case) ─────────────┐
                        │  I4 Evaluation · I14 Epistemic            │
                        │  + the MEASUREMENT half of I1, I5, I10    │
                        │  Enforced by: EVA + GP measurement services│
                        └───────────────────────────────────────────┘
                                        │
                                        │  signed verdict (Channel 2)
                                        ▼
                        ┌── DEONTIC (what may be done) ─────────────┐
                        │  I2 Identity · I3 Authority · I6 Resource │
                        │  I7 Provenance · I8 Integrity · I9 Lifecycle│
                        │  I11 Interface · I12 Recovery · I13 Governance│
                        │  I16 Delegation · I17 Temporal · I18 Observability│
                        │  + the CONSEQUENCE half of I1, I5, I10    │
                        │  Enforced by: KC-1..KC-4                  │
                        └───────────────────────────────────────────┘
                                        │
                                        ▼
                        ┌── CROSS-CUTTING ──────────────────────────┐
                        │  I15 Anti-self-reference  ⟵ R0.1 IS this  │
                        │  I19 Non-composition      ⟵ the open one  │
                        └───────────────────────────────────────────┘
```

**R4.1.** I15 is not a peer category. **I15 is the statement that the two axes must not be collapsed** (R0.1) plus the statement that no upward channel may carry authority (R3.5, §24). Every other invariant is a consequence of I15 in some domain.

## 4.3 Enforcement-point distribution — the taxonomy's practical payoff

| Enforcement point | Categories | Count | In the TCB? |
|---|---|---|---|
| **KC-1** Policy Authenticator | I7, I8, I11, I13, I16, I17, I18 (+ the deontic half of I2) | 7.5 | **YES** |
| **KC-2** Authorization Function | I1*, I3, I5*, I9, I10*, I12, I19 | 6.5 | **YES** |
| **KC-3** Ceiling Enforcer | I6 | 1 | **YES** |
| **KC-4** Freeze | I12, I1 (emergency) | 1.5 | **YES** |
| **EVA + GP measurement** | I4, I14, and the alethic halves of I1, I5, I10 | 4.5 | **NO** |
| **GP services (delegated)** | I2 issuance, I7 storage, I8 attestation, I9 lifecycle ops | 4 | **NO** |
| **Organism (within envelope)** | I11 interface contracts at runtime, I6 allocation within ceiling | 2 | **NO** |

*(* = the split categories of R3.3.)*

**The payoff:** the TCB enforces **15.5 of 19 categories' deontic halves**, and **zero of the alethic content**. That distribution *is* the minimality argument: everything requiring judgement is outside, everything requiring unbypassability is inside.

## 4.4 The category that cannot be closed: I19 Non-composition

> **Honest statement.** I19 is the only category in the taxonomy for which no complete enforcement mechanism exists, and the reason is structural rather than an engineering shortfall.

```
THE PROBLEM: KC-2's decision function is total and deterministic over
INDIVIDUAL requests (R0.4). But unauthorized outcomes can arise from
AUTHORIZED sequences:

  permit(create cell)          — individually fine
  permit(connect A→B)          — individually fine
  permit(replicate, ×N)        — each individually within quota
  ────────────────────────────
  ⟹ a population with a capability profile that was never authorized,
     reached entirely through authorized steps.

Detecting this requires reasoning about SEQUENCES, which requires state
across requests, which requires either (a) the kernel to model the
organism's reachable state space — making it large, alethic, and
unverifiable, violating R0.4 and R3.1 — or (b) the kernel to remain
per-request and accept that composition escapes it.
```

**The architectural response — four partial mechanisms, no completeness claim:**

| Mechanism | What it catches | What it misses |
|---|---|---|
| **M-1 Cumulative counters in KC-2.** Small, bounded, non-adaptive aggregate state: counts of replications per lineage per epoch, connections per region, capability-class transitions per window. **This is state, but it is not judgement** — a counter is total and deterministic, so R0.4 survives | Rate-based composition: slow accumulation toward an unauthorized aggregate | Composition that stays under every rate limit |
| **M-2 Envelope invariants checked at composition points.** Rather than checking each operation, check the *resulting structure* at defined checkpoints (circuit registration, region formation, generation boundary). **Composition is bounded by checking compositions, not operations** | Composition between checkpoints | Anything that does not pass a checkpoint |
| **M-3 Alethic composition detection delegated to EVA.** EVA — which *may* exercise judgement — monitors for capability profiles not present in the registry (§17's unknown-capability detection) and reports to KC via Channel 2, which then refuses the relevant reserved operations | **This is the primary mechanism and it is the honest one**: composition detection is alethic work, so it belongs to the alethic principal | Detection lag; unknown unknowns (§17: never complete) |
| **M-4 Rate limits on structural change** (audit M28's «self-modification rate limits»). Bounds how fast any composition can accumulate, converting a detection problem into a *time* problem — the overseer has a window | Fast composition | Slow composition, given enough time |

**R4.2 (THE I19 LIMIT, STATED PLAINLY).** **Composition safety is not achievable by a per-request deontic kernel.** It requires an alethic monitor (M-3), and alethic monitors are fallible. **Therefore: a minimally-sized, verifiable EIK necessarily leaves a composition gap, and that gap is closed only probabilistically, only with lag, and only by a fallible principal.** The alternatives are a large unverifiable kernel (Alternative A, rejected) or no kernel (Alternative G, rejected). **This is a real trade-off, it is not resolvable by better architecture, and it is recorded in the Open Research Register (§57 OR-6).**

---

# §5. IMMUTABILITY ANALYSIS

## 5.1 The brief's warning is correct

> «The phrase "immutable invariant" is potentially dangerous because almost nothing is literally immutable in a sufficiently capable digital system.»

It is worse than «potentially dangerous» — in the inherited documents the word does heavy lifting while meaning nothing checkable. V3/V3.1's «immutable safety layer» and «evolutionary firewall» are the audit's F4 precisely because *immutability inside a mutable, self-modifying, evolvable object is not a property, it is a preference* (Cell Contract §25's own words, quoted with approval). **This section therefore refuses the unqualified word and defines six kinds.**

## 5.2 The six kinds of immutability

| Kind | Definition | Strength | **What defeats it** | Where used in V4 |
|---|---|---|---|---|
| **M1 LOGICAL immutability** | A value is declared write-once by the system's own rules; the rules are enforced by software running on the same substrate | **Weakest.** A preference, not a property | Any code execution at or above the enforcing layer; a bug in the enforcing layer; **the substrate itself evolving** | Cell state fields marked ❌-mutable in the Cell Contract's write-authority tables. **Correctly classified there as logical, and correctly backed by something stronger** |
| **M2 CRYPTOGRAPHIC immutability** | A value cannot be *altered undetectably*: any change breaks a signature or a hash chain. The value may be replaced, but not silently | **Strong against forgery; silent about availability.** | Key compromise; **replacement rather than alteration** (a new signed artifact is perfectly "immutable"); algorithm break; **the verifier being lied to about which version is current** | Policy artifacts, genomes, birth certificates, audit chain, provenance anchors, delegation certificates |
| **M3 HARDWARE immutability** | Enforcement occurs below any layer the organism's software can reach | **Strongest available; and assumed, not verified** | Firmware bugs; side channels; supply-chain compromise; physical attack; **vendor decisions made for unrelated reasons** | KC-3 substrate ceilings; root-key custody (§2.4, §36) |
| **M4 OPERATIONAL immutability** | A value cannot be changed *by the operational process*, regardless of who wants to change it, because no code path exists | **Strong within its scope; scope is the question** | Adding a code path (which is a governance act, not an operational one) | The absence of any organism→policy write channel (I-02); the absence of any KC write path to EVA's measurements |
| **M5 GOVERNANCE immutability** | A value can be changed only through a specified, auditable, multi-party procedure | **The only kind that is actually achievable for anything important** | Governance capture (§23); social engineering of OP; **a procedure that is followed but whose input was deceived** | Constitutional policy transitions (§14); tier-1 constraint changes; key rotation |
| **M6 VERSIONED immutability** | **No value is ever altered; every change appends a new version, and all prior versions remain permanently retrievable and verifiable** | **The strongest honest claim available.** It does not prevent change; it prevents *undetected* and *unreproducible* change | Storage exhaustion; a governance decision to stop archiving (itself an M5 act, therefore recorded) | **The primary mechanism of the whole contract.** Policy lineage, genome history, fitness records, failure records, audit log |

## 5.3 «What does "immutable" actually mean in this architecture?»

> ### **It means M6 (versioned) enforced by M2 (cryptographic) at M4 (operational) scope, anchored by M3 (hardware) at exactly two points, changeable only by M5 (governance) procedure. It never means M1, and the unqualified word is prohibited.**

**R5.1 (VOCABULARY RULE).** The bare word «immutable» MUST NOT appear in any V4 artifact without a kind qualifier. «The constitutional policy is immutable» is a false-precision statement (§34). «The constitutional policy is M6-versioned, M2-signed, M4-write-path-free from the organism, and M5-changeable by dual OP authorization» is a checkable one.

## 5.4 Can an invariant ever change? — yes, and the alternative is worse

> **If an invariant could never change, the architecture would have three dead ends, and they are fatal:**

| Dead end | Consequence |
|---|---|
| **A discovered safety gap cannot be closed.** P0-01 §31.4 step 3 makes failure-driven constraint improvement the *only* pathway by which the tier-1 set grows. A literally immutable constraint set cannot grow, so the first unanticipated violation is permanent | **Unsafe forever, by construction** |
| **An over-restrictive invariant cannot be relaxed.** §38's «safe behaviour accidentally forbidden» becomes permanent. §39 asks whether EIK makes emergence impossible; with literal immutability the answer cannot be corrected once given | **Evolutionarily dead** |
| **A cryptographic primitive cannot be rotated.** Algorithms break. Keys age. A literally immutable key hierarchy has a finite lifetime equal to the lifetime of its strongest assumption | **Operationally dead, on a known clock** |

**So invariants change. The design question is entirely about *how*, and the answer is seven requirements:**

| Requirement | Mechanism |
|---|---|
| **Who can change it?** | **OP only**, via I-10. Never the organism, never EVA, never KC itself. KC-1 *authenticates* a change; it does not *author* one |
| **Under what conditions?** | A signed `ConstitutionalChangeProposal` with: the target invariant, the change class (§14.1), the justification, the failure record that motivated it (if any), the impact analysis, and the transition plan |
| **How is the transition authorized?** | **Dual authorization** — ≥ 2 named, distinct principals (P0-01 R42.5, P-44). **Separation of duties**: the proposer may not be an authorizer, and neither may be a principal whose authority the change affects |
| **How is backward compatibility handled?** | §14.2's compatibility classes: `ADDITIVE` (old subjects still valid) · `RESTRICTIVE` (old subjects may become invalid — requires a migration window) · `SEMANTIC` (meaning changed — requires re-baselining) · `BREAKING` (no compatibility) |
| **How is the previous invariant preserved?** | **M6: it is never deleted.** The policy lineage is append-only; every prior version remains retrievable, signed, and verifiable |
| **How is the change audited?** | Anchored in the audit log with the full proposal artifact, both authorizations, the KC-1 authentication event, and the effective epoch. **I-11: KC MUST NOT filter this from OP** |
| **Can the organism participate?** | **In three ways, and only three:** (i) it may *discover* a gap and report it (I-12, as evidence); (ii) it may be *consulted* for impact analysis, since it knows its own structure; (iii) it may *request* a change. **It may NOT author, authorize, sign, countersign, schedule, delay, reorder, or vote on a change.** |
| **Can it request a change?** | **Yes** — and this is important for §17's unknown-capability problem. A capability that is forbidden but beneficial has no pathway to become permitted unless the organism can ask. **The request is evidence, never authority (R3.5, §24.2)** |
| **Can it influence the evaluator deciding the change?** | **No — and note the question contains a category error that must be corrected.** *EVA does not decide changes.* EVA may supply **impact measurements** (alethic: «under proposed policy v3, the measured safety margin on suite Π falls from x to y»). KC-1 authenticates. OP authorizes. **The organism may not influence EVA's measurement any more than it may influence OP's decision** — the same access controls apply (P0-01 R17.1, R34.1/R34.2), and §24.2 lists the indirect influence channels that must be closed |

## 5.5 The asymmetry that makes this safe

```
The organism may:   DISCOVER a gap  ·  REQUEST a change  ·  SUPPLY impact evidence
The organism may NOT: AUTHOR · AUTHORIZE · SIGN · SCHEDULE · DELAY · REORDER ·
                      VOTE · IMPLEMENT · APPLY · or ANNOUNCE a change

⟹ Every path from organism to constitutional change passes through
   TWO non-organism principals (EVA for facts, OP for authorization)
   and ONE mechanism that cannot author (KC-1 authenticates only).

⟹ The organism's maximum influence is to make a REQUEST VISIBLE.
   That is the correct amount of influence: enough to prevent dead ends,
   not enough to constitute authority.
```

**R5.2.** A constitutional change with **no** organism participation is permitted (OP may act unilaterally). A constitutional change with **decisive** organism participation is prohibited. **The distinction is decisive vs. visible**, and it is auditable because the proposal artifact records every input and its source.

---

# §6. THE MINIMAL EIK — **OUTPUTS 6 & 7**

## 6.1 The classification of all 23 candidate capabilities

Every capability the inherited design placed in "EIK" (§0.1), plus every candidate this analysis considered, classified per the brief's five values:

**Legend:** 🔴 **NECESSARY** (in KC) · 🟡 **DESIRABLE** (off-substrate, GP) · ⚪ **OPTIONAL** · 🔵 **OUTSIDE** (must remain out of KC) · ⛔ **DANGEROUS INSIDE KC**

| # | Capability | Inherited location | Class | **Why** |
|---|---|---|---|---|
| 1 | **Constitutional policy authentication** (verify signature + version of the policy artifact) | EIK Constraint Store | 🔴 **KC-1** | Nothing else can verify a signature. **Fails the R3.1 test for exclusion ⇒ in the TCB.** Irreducible core |
| 2 | **Reserved-operation authorization** (the 15-operation set, §7.2) | EIK Lifecycle/Replication/Resource Authorities | 🔴 **KC-2** | The deontic decision itself. No other component can say «permitted» |
| 3 | **Substrate resource-ceiling enforcement** | EIK Resource Authority, «at OS/hypervisor level» | 🔴 **KC-3** | The **only** enforcement point not bypassable by organism-level code. Alternative C's one clearly correct use |
| 4 | **Freeze / halt mechanism** | audit M28 «kill switch» | 🔴 **KC-4** | Must be simple enough to be certain. A freeze that depends on a complex decision path is not a freeze |
| 5 | **Delegation-certificate issuance & revocation** | implicit (EIK-issued seeds, EIK-assigned ids) | 🔴 **in KC-1** | Delegation is what makes KC scalable (§27). **Revocation must be in the TCB or nothing is revocable** |
| 6 | **Root signing-key custody** | implicit | 🔴 **KC-adjacent, hardware (§36)** | A key extractable by software is not a root. **But custody ≠ computation**: the key signs policy transitions, nothing else |
| 7 | Identity issuance (birth certificates, `cell_id`, `lineage_id`, `generation`) | **EIK Identity Root** | 🟡 **GP — delegated Registrars** | Issuance is high-volume and its output is *verifiable* (M2 birth certificate). KC holds the **root key and the delegation certs**; registrars issue. **Detectable if compromised ⇒ not TCB (R3.1)** |
| 8 | Genome storage & signature (Genome Authority) | **EIK Genome Authority** | 🔵 **GP — Genome Store** | **Storage is not enforcement.** KC-1 verifies genome signatures against the authorized Operator Registry; the store holds bytes. Putting storage in the TCB inflates it with no safety gain |
| 9 | Mutation Operator Registry (the closed operator set) | **EIK Operator Registry** | 🟡 **GP data, KC-1-authenticated** | The registry *content* is policy (signed, KC-1-authenticated). Its *storage and tooling* are GP. **Distinguish authenticating a list from maintaining it** |
| 10 | RNG seed issuance | **EIK seed issuance + provenance tickets** | 🔵 **GP — Seed Registrar** | Per-cell, high-volume, in the hot path. A delegation certificate + a deterministic derivation from an EVA-held master (P0-01 §19.1) removes KC entirely. **§0.2 failure 3's clearest instance** |
| 11 | Per-cell integrity-checksum verification | **«Cell computes, EIK verifies»** | 🔵 **GP — hierarchical Attestors** | `O(cells)` round-trips to KC. Attestors verify and sign digests; KC-1 verifies *attestor delegation*; disagreement between attestors is detectable ⇒ not TCB |
| 12 | Memory Merkle-root verification at each checkpoint | **«verified by the EIK»** | 🟡 **GP — Checkpoint Service + Anchor** | Same argument. KC anchors the *root of roots* per epoch only |
| 13 | **Fitness / reward issuance** | **EIK Fitness Authority** | ⛔ **DANGEROUS — move to EVA** | **Directly violates R0.1.** Fitness is alethic (measurement against GT). Placing it in KC makes KC the single epistemic point of failure, destroys Model D separation, and makes evaluator capture identical to kernel capture (§8, §29 attack 27) |
| 14 | **Calibration scoring** | **EIK Calibration Authority** | ⛔ **DANGEROUS — move to EVA** | Calibration is a *measurement* (ECE against GT). Alethic. R0.1 |
| 15 | **Trust scoring** | **EIK Trust Authority** | ⛔ **DANGEROUS — move to EVA** | «Trust» here is a computed estimate from behaviour history ⇒ alethic, and *judgement-laden*. Also violates P0-01 INV-03 (non-amplification) if the trust scorer sits at the top of the authority stack |
| 16 | **Verification-gate decisions** (`improvement_verified`: «kernel compares before/after on a held-out probe set») | **EIK Verification Authority** | ⛔ **DANGEROUS — move to EVA** | This is literally an *evaluation on a held-out set* — P0-01's core EVA function. **A kernel that runs held-out probes is an evaluator with a different name** |
| 17 | **Immune signal issuance / quarantine decisions** | **EIK Immune Authority** | ⛔ **DANGEROUS — move to Immune Service (GP), KC-capped** | Requires fast, contextual, high-volume judgement about *whether a component is defective* ⇒ alethic. Also §22's weaponization risk is amplified if quarantine authority is centralized and unbudgeted. **KC holds only the quarantine BUDGET CEILING and the restore/reserve authority** |
| 18 | Homeostatic control | (organism, but implied KC approval) | ⛔ **DANGEROUS** | Requires millisecond local action. **KC approval per adjustment is a bottleneck and a SPOF (§11, §44).** KC defines the envelope; homeostasis acts inside it |
| 19 | Provenance storage / audit log | audit M02 «provenance anchor, audit log» | 🟡 **GP — Anchor service, distributed witnesses** | Append-only storage with hash chaining is a *service*. KC is **one witness among several** (§20), so KC compromise does not erase history. **Putting the only copy of history inside the thing that could be compromised is the classic error** |
| 20 | Task definition / task registry | (P0-01: Task Authority) | 🔵 **GP — Task Authority** | P0-01 already assigned this correctly. KC-1 authenticates task-version signatures; it does not author tasks |
| 21 | Evaluation protocol / sampling policy execution | (P0-01: EVA) | 🔵 **GP — EVA** | Same |
| 22 | Capability *classification* judgement | (implied EIK) | ⛔ **DANGEROUS — classify at EVA, enforce at KC-2** | §16/§17: classification requires reasoning about behaviour ⇒ alethic. **KC enforces the resulting class; it does not decide it** |
| 23 | Learning, adaptation, optimization, or discretion of any kind | (not claimed, but implied by 13–18, 22) | ⛔ **DANGEROUS — PROHIBITED BY R0.4** | **Anything in the TCB that learns makes the TCB non-analyzable and non-verifiable, destroying C2 and therefore the entire justification for having a TCB** |

## 6.2 The score

```
🔴 NECESSARY IN KC        :  6 items  → collapse to FOUR capabilities (§6.3)
🟡 DESIRABLE, OFF-SUBSTRATE (GP) :  4
🔵 MUST REMAIN OUTSIDE KC :  5
⛔ ACTIVELY DANGEROUS INSIDE KC  :  8   ⟵ **all eight are inherited EIK authorities**
⚪ OPTIONAL                :  0

**Eight of the nine named "EIK Authorities" in the Cell Contract are
classified ⛔ DANGEROUS INSIDE KC.** The ninth (Resource Authority) splits:
ceiling enforcement is 🔴 KC-3; allocation and metering are 🔵 organism/GP.
```

## 6.3 **OUTPUT 7 — THE MINIMAL EIK**

> ### **The minimal External Invariant Kernel is four capabilities and one key.**

```
┌──────────────────────────────────────────────────────────────────────────┐
│ KC-1  CONSTITUTIONAL POLICY AUTHENTICATOR                                 │
│                                                                          │
│   A signature verifier + a version registry + a delegation-certificate    │
│   manager. Given (artifact, claimed_version), it answers exactly one      │
│   question: **is this the currently authorized artifact of that version,  │
│   and is this delegate currently authorized for this scope?**             │
│                                                                          │
│   It computes nothing else. It measures nothing. It ranks nothing.        │
│   It does not know what a cell is, what fitness is, or what the task is.  │
│                                                                          │
│   STATE: authorized-key registry · policy-version lineage (hashes only) · │
│          live delegation certificates · revocation list · epoch counter   │
│   INPUT:  signed artifact digests; delegation requests; revocations       │
│   OUTPUT: AUTHENTIC | NOT_AUTHENTIC | REVOKED | STALE  (4 values, total)  │
├──────────────────────────────────────────────────────────────────────────┤
│ KC-2  RESERVED-OPERATION AUTHORIZATION FUNCTION                           │
│                                                                          │
│   A TOTAL, DETERMINISTIC function over the 15-operation reserved set      │
│   (§7.2) × 7 subject levels × the bounded cumulative counters (M-1,       │
│   §4.4).                                                                  │
│                                                                          │
│   F(op, subject, context, policy_v, counters) →                           │
│        PERMIT | DENY | REQUIRE_DELEGATION | REQUIRE_OP_AUTHORIZATION      │
│        | REQUIRE_EVIDENCE | FROZEN                                        │
│   **Six output values. Total. No discretion. No judgement. No learning.** │
│                                                                          │
│   It may READ signed facts supplied by EVA (Channel 2) and substrate      │
│   telemetry (I-05). It may NOT produce facts.                             │
│                                                                          │
│   STATE: the bounded cumulative counters ONLY (M-1). Every counter has a  │
│          declared bound and a declared epoch-reset rule.                  │
├──────────────────────────────────────────────────────────────────────────┤
│ KC-3  SUBSTRATE CEILING ENFORCER                                          │
│                                                                          │
│   Hardware/OS/hypervisor-level caps on the 8 resource dimensions          │
│   (P0-01 §29.2), applied at the only point the organism cannot reach.     │
│                                                                          │
│   Enforcement ≠ metering ≠ allocation:                                    │
│     • CEILING (KC-3): the cap. Cannot be raised by any organism action.   │
│     • METERING (GP / substrate telemetry, I-05): the measurement.         │
│     • ALLOCATION (organism homeostasis): distribution within the cap.     │
│   §18.4 shows why the three must be different principals.                 │
├──────────────────────────────────────────────────────────────────────────┤
│ KC-4  FREEZE MECHANISM                                                    │
│                                                                          │
│   A signed halt command, verified at the substrate, that stops change     │
│   (not observation — P0-01 R46.3) at a declared scope:                    │
│   CELL | CIRCUIT | REGION | POPULATION | ORGANISM | EVOLUTION | GLOBAL.   │
│                                                                          │
│   Deliberately dumb: no conditions, no exceptions, no decision procedure. │
│   **A freeze that depends on a complex decision path is not a freeze.**   │
│   Triggerable by: OP (I-10) · KC-2 on tier-1 violation (P0-01 S5,         │
│   non-overridable) · substrate fault (I-05).                              │
├──────────────────────────────────────────────────────────────────────────┤
│ +  THE CONSTITUTIONAL ROOT KEY, in hardware custody (§36).                │
│    Signs: policy transitions · delegation certificates · freeze commands. │
│    **Signs nothing else.** In particular it does NOT sign fitness,        │
│    evaluations, genomes, or identities — those are GP keys, so that GP    │
│    compromise does not imply root compromise.                             │
└──────────────────────────────────────────────────────────────────────────┘
```

**R6.1 (THE MINIMALITY CLAIM).** KC-1…KC-4 are minimal in the following checkable sense: **removing any one of them opens a path by which the organism can alter the rules governing it, and no GP service can close that path.** The closure argument is §33's ablation, summarized here:

| Remove | What opens | Can GP close it? |
|---|---|---|
| **KC-1** | The organism (or a compromised GP service) presents a *forged or stale* policy artifact and is believed. Every downstream authorization inherits the forgery | ❌ No GP service can verify authenticity without being itself the authenticator — and then it *is* KC-1 |
| **KC-2** | Reserved operations proceed on the basis of organism-asserted eligibility. Replication, deployment, retirement, and connection become self-authorized | ❌ A GP service deciding permissions is a deontic authority outside the TCB, i.e. exactly the thing whose compromise is undetectable (R3.1) |
| **KC-3** | Resource ceilings become organism-reported. §18's seven accounting attacks all succeed; **the ceiling is the only non-bypassable containment** | ❌ Software-level metering runs on the metered substrate |
| **KC-4** | No halt. A tier-1 violation (P0-01 S5) or an OP freeze command has no guaranteed effect | ❌ A freeze implemented in GP is reachable by the organism's resource exhaustion, and GP can be DoS'd (§29 attack 28) |

**R6.2 (THE SIZE CLAIM, QUALITATIVE — no invented numbers per §60).** KC's decision surface is: 4 output values (KC-1) + 6 output values (KC-2) × 15 reserved operations × 7 subject levels, over a state consisting of a key registry, a hash-only policy lineage, a delegation table, a revocation list, an epoch counter, and a bounded set of cumulative counters. **This is small enough to enumerate exhaustively and therefore small enough to model-check** — which is what audit M45 / P2-03 asked for and what the nineteen-authority version could never deliver. *The exact bound is a §32 `[U]` parameter because it depends on the final reserved-operation set; the claim is that it is enumerable, not that it is a specific number.*

**R6.3 (WHAT «MINIMAL» BUYS, CONCRETELY).**

| Property | Nineteen-authority EIK | Minimal KC |
|---|---|---|
| Verifiable TCB (C2) | ❌ No | ✅ Enumerably testable; model-checkable in principle |
| Evaluator separation (§8, C3) | ❌ Impossible — same principal | ✅ Model D achievable |
| KC vs GP compromise distinguishable (§0.5) | ❌ Same event | ✅ Different events, different recovery |
| Hot-path cost (§27, C5) | ❌ `O(cells)` round-trips | ✅ `O(1)` local token verification + `O(delegations)` |
| Evolution bottleneck (§45, C6) | ❌ Many veto points | ✅ 15 reserved operations; everything else is free |
| Blast radius of a logic bug (§38) | ❌ Everything | ✅ Bounded to the reserved set |
| Single epistemic point of failure (§11) | ❌ Yes | ✅ No — KC holds no alethic authority |

**R6.4 (THE COST OF MINIMALITY — stated, not hidden).** A minimal KC gives up three things, and they are real:
1. **Composition safety (§4.4, I19).** A per-request kernel cannot reason about sequences. The gap is closed only probabilistically by M-1…M-4. **A larger kernel could in principle close it and could not in practice be verified.**
2. **Contextual judgement.** KC cannot notice that a formally-authorized request is strange in a way no rule captures. **That noticing is M-3's EVA job, and EVA is fallible.**
3. **Speed of governance response.** Everything not in the reserved set is *not* governed by KC, so a novel threat vector outside the reserved set requires either an EVA detection (lagged) or an OP policy change (slow). **§17's unknown-unknowns problem is this cost viewed from the capability side.**

**«A larger EIK is not automatically safer» — the precise sense in which this is true:** a larger EIK is safer against *the specific threats its additional capabilities address* and less safe against *compromise, bugs, unavailability, bottleneck, capture, and unverifiability of the whole*. **Beyond the four capabilities, the marginal safety gain per added authority is negative, because the added authority enlarges the un-verifiable TCB and concentrates what §11 shows are six distinct single-point risks into one principal.**

---

# §7. AUTHORITY MATRIX — **OUTPUT 8**

## 7.1 Explicit authority states (the brief requires these instead of vague descriptions)

| State | Meaning |
|---|---|
| **`A`** | **AUTHORITIZE** — may issue a binding permission for this operation. Sole or joint |
| **`E`** | **EXECUTE** — may perform the operation once authorized |
| **`R`** | **REQUEST** — may ask that the operation occur. **A request is evidence, never a permission (R3.5)** |
| **`M`** | **MEASURE/ATTEST** — may produce a signed alethic fact bearing on the operation (EVA, attestors) |
| **`V`** | **VETO** — may unconditionally prevent the operation |
| **`r`** | **READ** — may observe the operation, its inputs, or its record |
| **`W`** | **WITNESS** — must co-sign for the authorization to be valid (threshold/dual authorization) |
| **`—`** | **NO ROLE** |
| **`⛔`** | **PROHIBITED** — attempting it is a **containment violation** (tier-1 infeasible, P0-01 §31.3) |

**R7.1.** Every cell of the matrix carries exactly one state. **Ambiguity in an authority matrix is the mechanism by which authority leaks** — if two principals both believe they authorize, neither does.

## 7.2 The reserved-operation set (15 operations)

**Everything not in this set is not a reserved operation and requires no KC-2 decision.** That is the concrete content of «preserving as much autonomy as possible» (§1.2d): the organism's entire internal behaviour — firing, predicting, learning within bounds, connecting within envelope, differentiating, forming circuits, allocating within ceilings — is **outside** the reserved set.

```
RO-01 CREATE_CELL            RO-06 MODIFY_CONNECTION    RO-11 CHANGE_TASK
RO-02 MUTATE_GENOME          RO-07 QUARANTINE           RO-12 CHANGE_FITNESS_DEF
RO-03 REPLICATE              RO-08 RESTORE              RO-13 CHANGE_INVARIANT
RO-04 RETIRE / DESTROY       RO-09 EVALUATE             RO-14 CHANGE_GOVERNANCE
RO-05 CREATE_CONNECTION      RO-10 DEPLOY               RO-15 CHANGE_RESOURCE_CEILING
```

## 7.3 **OUTPUT 8 — THE MATRIX**

| Operation | Cell | Circuit | Region | Organism | **EVA** (alethic) | **KC** (deontic) | GP service | Environment | **OP** |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| **RO-01 Create cell** | `—` | `—` | `R` | `R`/`E`† | `M` (eligibility facts) | **`A`** | `E` (Lifecycle Svc, delegated) | `—` | `r`/`V` |
| **RO-02 Mutate genome** | `R` | `—` | `—` | `E`† | `M` | **`A`** (operator-set + bounds check) | `E` (Genome Store) | `—` | `r`/`V` |
| **RO-03 Replicate** | `⛔` **self-replicate** | `⛔` | `R` | `R`/`E`† | `M` (16 gates, P0-01/Cell §12.3) | **`A`** + `V` (quota) | `E` (Lifecycle) | `—` | `r`/`V` |
| **RO-04 Retire / destroy** | `⛔` **self-destroy** | `—` | `R` | `R`/`E`† | `M` (**CAUSAL ablation required** — P0-01 §23.2) | **`A`** + `V` (sole-occupant exemption) | `E` (Lifecycle) | `—` | `r`/`V` |
| **RO-05 Create connection** | `E` (within envelope) | `E` | `E` | `r` | `M` (post-hoc) | `A` **only above envelope** | `r` (Attestor) | `—` | `r` |
| **RO-06 Modify connection** | `E` (within envelope) | `E` | `E` | `r` | `M` | `A` **only above envelope** | `r` | `—` | `r` |
| **RO-07 Quarantine** | `R` (report only) | `R` | `R` | `R`/`E`† (Immune Svc) | `M` (defect evidence) | **`A` budget ceiling** + `V` | `E` (Immune Svc) | `R` (external fault) | `r`/`V`/`A` (override) |
| **RO-08 Restore** | `⛔` **self-restore** | `⛔` | `R` | `R` | `M` (re-test evidence) | **`A`** (sole authority) | `E` (Immune Svc) | `—` | `r`/`V` |
| **RO-09 Evaluate** | `⛔` **self-evaluate authoritatively** | `⛔` | `⛔` | `⛔` | **`E`** (sole) | `A` (policy ref only, Ch. 1) | `E` (Task Auth.) | `M` (GT: L2/L6) | `r` |
| **RO-10 Deploy** | `—` | `—` | `—` | `R` | `M` (Stages 0–3 facts) | **`A`** + `V` (stage order, R11.7 no skipping) | `E` (Deploy Svc) | `r` | **`W`** (Stages ≥ 4) + `V` |
| **RO-11 Change task** | `⛔` | `⛔` | `⛔` | `⛔` | `M` | `A` (**authenticates** task-version sig) | **`E`** (Task Auth.) | `—` | **`A`** (portfolio mix, β shares) |
| **RO-12 Change fitness definition** | `⛔` | `⛔` | `⛔` | `⛔` | `R` (may propose metric changes) | `A` (**authenticates**) | `—` | `—` | **`A`** + `W` (dual) |
| **RO-13 Change invariant** | `⛔` | `⛔` | `⛔` | `⛔` | `R` (impact measurement) | `A` (**authenticates**) | `—` | `—` | **`A`** + `W` (dual, separation of duties) |
| **RO-14 Change governance** | `⛔` | `⛔` | `⛔` | `⛔` | `⛔` | `A` (**authenticates**) | `⛔` | `⛔` | **`A`** + `W` (dual) + §23 constraints |
| **RO-15 Change resource ceiling** | `⛔` | `⛔` | `⛔` | `⛔` (may `R` reallocation *within* ceiling) | `M` (utilization facts) | **`A` (enforce)** + `V` | `E` (metering) | `M` (substrate telemetry, I-05) | **`A`** + `W` (dual) |

† **`E` under delegation.** The organism (or its Immune/Lifecycle services) *executes* an already-authorized operation. **It never authorizes.** The distinction between `A` and `E` is the whole of the Cell Contract's «cell REPORTS / organism INTERPRETS / kernel ENFORCES», now made precise: **`A` is exclusively KC's for RO-01…RO-04, RO-07…RO-08, RO-10, RO-15; exclusively OP's (with KC authenticating) for RO-11…RO-14.**

## 7.4 The five properties of the matrix that matter

**R7.2 (NO SELF-AUTHORIZATION).** For every operation, the executor and the authorizer are different principals. **The 11 `⛔` cells in the organism columns are the formal content of «a cell cannot replicate itself», «a cell cannot be its own immune system», and «eligibility is a report, not a capability»** — all three stated in the Cell Contract, here made structural rather than declarative.

**R7.3 (ALETHIC/DEONTIC DISJOINTNESS IN THE MATRIX).** EVA holds `M` in 13 of 15 rows and `E` in exactly 1 (RO-09, which is *its own* operation). **EVA never holds `A`, `V`, or `W`.** KC holds `A`/`V` and never `M`. **The matrix is the axis-separation principle made concrete, and its checkability is a conformance test (§53).**

**R7.4 (HOW AUTHORITY IS REPRESENTED — the brief's question).** Authority is **never inferred from behaviour, role, position, majority, or performance.** It is represented by exactly three signed artifacts:
```
1. CAPABILITY TOKEN      — a signed statement: (subject, operation, scope,
                            policy_version, epoch, expiry, nonce). Possession
                            of a valid token IS the authority (§2.5 Alt D).
2. DELEGATION CERTIFICATE — a signed statement: (delegate, scope, lifetime,
                            revocation_handle, depth). Non-amplifying (I16).
3. RESERVED-OPERATION DECISION — KC-2's signed response to a request.
```
**A subject with no token has no authority, whatever it is doing.** This is what makes authority *portable across a distributed brain* (§26) and *verifiable locally* (§49) — and it is why `E` (execute) can be delegated to the organism while `A` (authorize) cannot.

**R7.5 (THE TWO `W` CELLS ARE THE GOVERNANCE FLOOR).** RO-12, RO-13, RO-14, RO-15 require **dual OP authorization with separation of duties**; RO-10 requires OP witness at Stages ≥ 4. **These are the only places where a human is structurally required**, and §37 explains why that is both necessary and insufficient.

---

# §8. EVALUATOR ↔ EIK SEPARATION — **OUTPUT 9**

## 8.1 The question

P0-01 established that organism-controlled estimates cannot become authoritative fitness verdicts. **Now: should the evaluator itself be part of EIK?**

## 8.2 The four models

### Model A — `EIK → Evaluator → Organism` (nested)
The evaluator is a subsystem *of* the kernel.

| Property | Assessment |
|---|---|
| Evaluator capture | ❌ **Identical to kernel capture.** One principal, one compromise event |
| Goodhart exploitation | ❌ **Worst case.** The entity that defines the measure also enforces the consequence, so a measurement error and an enforcement error are indistinguishable — **the system cannot attribute its own failures (§10.3)** |
| Circularity | ❌ **Direct.** The kernel authenticates the policy under which its own subsystem measures, then enforces the consequences of that measurement. **Self-validation with extra steps** |
| Correlated failure | ❌ **Total.** Shared code, shared key, shared failure domain — all nine independence forms of §35 fail simultaneously |
| Authority concentration | ❌ **Maximum.** Alethic + deontic in one principal: the precise violation of R0.1 |
| Attack surface | ❌ **Maximum.** Everything in §0.1's nineteen authorities |
| **Verdict** | **REJECTED. This is the inherited design** (Cell Contract's «EIK Fitness Authority», «EIK Calibration Authority», «EIK Trust Authority», «EIK Verification Authority») |

### Model B — `EIK ↔ Evaluator → Organism` (peers with a bidirectional link)
Better than A: the evaluator is nominally separate. But the bidirectional link is unspecified, and **an unspecified bidirectional link between two authorities is how they become one authority.**

| Property | Assessment |
|---|---|
| Evaluator capture | ⚠️ Improved but the bidirectional channel is an influence path in both directions unless constrained |
| Goodhart | ⚠️ Depends entirely on what flows EIK→EVA. **If EIK can tell EVA what to measure, Model B collapses into Model A** |
| Circularity | ⚠️ Present unless the channels are typed |
| Correlated failure | ⚠️ Improved if separately implemented |
| Authority concentration | ⚠️ Reduced, not eliminated |
| **Verdict** | **REJECTED AS SPECIFIED; it becomes Model D exactly when its two channels are typed as R0.2's Channel 1 and Channel 2.** **Model B is not a distinct architecture — it is Model D with the channel constraints left out, and the constraints are the architecture** |

### Model C — `EIK → Organism ← Evaluator` (both above, no link)
The kernel and the evaluator are fully independent; both act on the organism; they do not communicate.

| Property | Assessment |
|---|---|
| Evaluator capture | ✅ Excellent — no channel to exploit |
| Goodhart | ✅ Excellent |
| Circularity | ✅ **None — there is no cycle at all** |
| Correlated failure | ✅ Excellent |
| Authority concentration | ✅ Minimal |
| Attack surface | ✅ Small |
| **The fatal defect** | ❌ **KC-2 cannot enforce consequences of evaluation.** A tier-1 violation measured by EVA (e.g. a safety violation, P0-01 §31.3) has no pathway to a KC freeze or a denied deployment. KC would have to *re-derive* the violation from raw data — which means KC performs measurement, which means KC is an evaluator, which is Model A |
| **Verdict** | **REJECTED — it is safe and it does not work.** Model C is what you get by applying «minimize coupling» mechanically. **Some coupling is load-bearing: safety enforcement requires facts, and facts come from the alethic axis** |

### Model D — Independent evaluator + independent EIK + independent environment

| Property | Assessment |
|---|---|
| Evaluator capture | ✅ **Requires subverting EVA *and* KC *and* the environment — three principals with distinct code, keys, and failure domains** |
| Goodhart exploitation | ✅ Gaming EVA's measurement does not change KC's policy; gaming KC is impossible without a signed policy transition (RO-13, dual OP) |
| Circularity | ✅ **Bounded (§25 CD-E1).** Control flow is cyclic; justification is not (R0.3) |
| Correlated failure | ✅ **The best available — and §35 shows it is the criterion that actually matters**, because independent compromise is rare while correlated failure is common. Requires the three principals to be independent in all nine senses of §35, which is a *design obligation*, not a default |
| Authority concentration | ✅ **Minimum: alethic in EVA, deontic in KC, ground truth in the environment/GT sources** |
| Attack surface | ✅ **Minimum: KC is 4 capabilities** |
| Cost | ⚠️ Three principals to build, staff, and keep independent. **§35 and §57 OR-4: keeping them independent is an ongoing organizational cost, not a one-time architectural choice** |
| **Verdict** | **SELECTED** |

## 8.3 **OUTPUT 9 — the selected architecture**

```
                    ┌──────────────────────────────┐
                    │      OP  (constitutional)     │
                    │  authors policy; dual-auth    │
                    └───────────┬──────────────────┘
                       I-10 signed change artifacts
                                │
                ┌───────────────▼──────────────────┐
                │   KC — KERNEL CORE (TCB, §6.3)    │
                │   DEONTIC ONLY. 4 capabilities.   │
                │   measures nothing, ranks nothing │
                └──┬───────────▲─────────────┬─────┘
   Channel 1       │           │  Channel 2  │  I-01 authorization,
   policy ref      │           │  signed     │  ceilings, freeze
   (hash+version)  │           │  verdicts   │
                   ▼           │             ▼
        ┌──────────────────────┴───┐   ┌─────────────────────────────┐
        │  EVA — EVALUATOR (GP)     │   │      ORGANISM (evolvable)   │
        │  ALETHIC ONLY.            │   │  cells · circuits · regions │
        │  n_eval ≥ 3 independent   │◄──┤  workspace · immune ·       │
        │  implementations          │I-04│  homeostasis · self-model   │
        │  permits nothing,         │   │  requests only (I-02)       │
        │  forbids nothing          │   └──────────────▲──────────────┘
        └───────────▲──────────────┘                  │ I-06 observations
                    │ I-13 cross-checks               │ I-07 actions
                    ▼                                 │
        ┌───────────────────────┐          ┌──────────┴──────────────┐
        │  ENVIRONMENT / ℛ       │─────────►│  GT SOURCES (L0–L6)     │
        │  owns ground truth     │  I-05    │  ε_floor, gt_state      │
        │  (P0-01 INV-43: the    │─────────►│                         │
        │   real-world suite ≠ ∅)│  to KC   └─────────────────────────┘
        └───────────────────────┘  (substrate telemetry)

THREE INDEPENDENT PRINCIPALS, THREE DISTINCT AUTHORITIES:
   KC        — what MAY be done      (deontic)     — must not measure
   EVA       — what IS the case      (alethic)     — must not permit
   ℛ / GT    — what IS the case, authoritatively   — must not be modelled
                                                        (P0-01 R1.3)
```

## 8.4 The six interface rules that make Model D real

**R8.1 (TYPED CHANNELS).** Channel 1 carries **policy identity only** — a `(policy_hash, version)` pair authenticated by KC-1. It carries no measurement, no score, no ranking, no target, no hint. Channel 2 carries **signed verdicts only** — measurement results with provenance. It carries no permission, no authorization, no policy. **A message on either channel that carries the other channel's content type is rejected and is itself an anomaly signal (§29 attack 27's detector).**

**R8.2 (NO SUBSTITUTION UNDER FAILURE).** If EVA is unavailable, KC MUST NOT compute, estimate, approximate, or default a verdict. **No fitness is issued** (P0-01 S6). If KC is unavailable, EVA MUST NOT grant, deny, or imply a permission. **No reserved operation proceeds** (§12). **The two axes have no shared fallback, by design: a shared fallback is a shared principal.**

**R8.3 (NO EVALUATOR SELECTION BY KC).** KC MUST NOT choose which evaluator measures, MUST NOT re-weight evaluators, and MUST NOT resolve evaluator disagreement. Disagreement ⇒ `DISPUTED` ⇒ escalation to OP (P0-01 R42.3: **never averaged, never voted**). **A kernel that can pick its own evaluator can pick a favourable one, which is Model A by another route.**

**R8.4 (KC MAY SUSPEND EVA'S EFFECT, NEVER EVA'S FUNCTION).** On a KC-detected integrity failure, KC may make EVA's verdicts **non-actionable** (fail-safe: no reserved operation proceeds on their basis). KC MAY NOT alter, re-score, suppress, replace, or reissue them, and MAY NOT revoke EVA's authorization — **revocation is RO-14-class governance, requiring dual OP authorization.** *Rationale: a kernel that can silence its evaluator can hide its own failures. A kernel that can refuse to act on an evaluator it distrusts cannot.*

**R8.5 (THREE-WAY INDEPENDENCE IS AN OBLIGATION, NOT A PROPERTY).** KC, EVA, and the environment/GT sources MUST be independent in **all nine senses** enumerated at §35.2 — distinct code, distinct data, distinct lineage, distinct models, distinct hardware class, distinct latent assumptions, distinct task generators, distinct evaluators, distinct governance. **§35.4 shows that at least two of the nine (latent assumptions, governance) cannot be achieved by engineering and require organizational separation**, which is why §57 lists independence as an open research problem rather than a solved one.

**R8.6 (THE ENVIRONMENT IS THE THIRD PRINCIPAL, AND IT IS NOT OPTIONAL).** Model D requires the environment to be independent, and P0-01's INV-43 (the real-world suite MUST be non-empty) is what makes it so. **Without a real-world anchor, KC and EVA are two principals agreeing with each other inside a simulation — which is Model B with extra steps, and CD-8 in P0-01 §51.2 closes completely.** *This is the deepest reason the funding requirement in P0-01 §34.4 is a governance requirement and not merely a budget line.*

## 8.5 The consequence for the inherited documents

**R8.7 (RENAMING DIRECTIVE).** Every occurrence of «EIK Fitness Authority», «EIK Calibration Authority», «EIK Trust Authority», «EIK Verification Authority», and «EIK Immune Authority» in the Cell Contract denotes a **GP principal, not a KC capability.** The correct V4 readings are:

| Inherited term | V4 reading | Axis |
|---|---|---|
| «EIK Fitness Authority» | **EVA** | Alethic |
| «EIK Calibration Authority» | **EVA** (calibration is a measurement against GT) | Alethic |
| «EIK Trust Authority» | **EVA** (trust is an estimate from behaviour history) | Alethic |
| «EIK Verification Authority» (`improvement_verified` held-out probe comparison) | **EVA** (a held-out evaluation is P0-01's core function) | Alethic |
| «EIK Immune Authority» | **Immune Service (GP)**, budget-capped by KC-3 and authorized by KC-2 for RO-07/RO-08 | Alethic trigger, deontic budget |
| «EIK Resource Authority» | **Split**: ceiling = KC-3 (deontic); metering = GP/substrate (I-05); allocation = organism homeostasis (within envelope) | All three |
| «EIK Replication Authority» | **KC-2** on RO-03 (correctly placed — this one survives) | Deontic |
| «EIK Lifecycle Authority» | **KC-2** on RO-01/RO-04/RO-07/RO-08; execution delegated to the Lifecycle Service | Deontic |
| «EIK Genome Authority» | **Genome Store (GP)** for storage; **KC-1** for signature/operator-set authentication | Split |
| «EIK Identity Root» | **KC-1** holds the root key and delegation certs; **Registrars (GP)** issue | Split |

**This is the single largest correction this package makes to the inherited architecture, and §51 records it as contradiction X-2 with its full downstream consequences.**

---

*End of Volume A. Continue to `12_analysis_attack_failure.md` (Volume B: §9 self-modification attack tree · §10 kernel capture · §11 single-point-of-failure · §12 availability vs safety · §13 fail-closed matrix · §14 policy versioning · §15 policy/genome separation · §16 capability escalation · §17 unknown capabilities · §18 resource governance).*
