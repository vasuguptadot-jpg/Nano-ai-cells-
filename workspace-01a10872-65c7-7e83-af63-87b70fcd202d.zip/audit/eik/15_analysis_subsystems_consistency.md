# P0-02 — EXTERNAL INVARIANT KERNEL & GOVERNANCE BOUNDARY
## Volume E: Subsystem Boundaries, Consistency Audit & Conformance (§41–§55)

**Companions:** `11_analysis_trust_authority.md` (A) · `12_analysis_attack_failure.md` (B) · `13_analysis_governance_scale.md` (C) · `14_analysis_adversarial_formal.md` (D) · `16_v4_eik_governance_contract_spec.md` (canonical)
**Outputs delivered here:** **10** (EIK↔organism) · **11** (EIK↔evolution) · **12** (EIK↔immune) · **13** (EIK↔homeostasis) · **14** (EIK↔memory/provenance) · **24** (EIK ablation) · **25** (cross-system contradiction audit) · **26** (testability/conformance) · **27** (P0/P1/P2 gaps)

---

# §41. EIK VS SELF-MODEL — **OUTPUT 10 (part 1)**

## 41.1 What may the self-model know?

| Item | May the organism know it? | **Why** |
|---|---|---|
| **That KC exists** | ✅ **YES — and it must** | A subject that does not know it is governed cannot model why its requests are denied, and will waste capacity probing. **More importantly: obscurity about the *existence* of governance buys nothing (§41.2)** |
| **The constitutional rules (L1)** | ✅ **YES — completely** | Kerckhoffs. The rules are a signed, published artifact. **A rule whose safety depends on being unknown is not a rule; it is a trap, and traps fail against an adversary with unbounded time (§9.1 A1)** |
| **The policy (L2)** | ✅ **YES — completely** | Same. Envelopes, budgets, rung criteria, operator set: all published |
| **KC's *state*** (ACTIVE / HALTED / etc.) | ⚠️ **PARTIALLY — coarse-grained only** | The organism should know that governance is degraded (so it can stop requesting), but **not the fine-grained internal state** (which replica disagreed, which attestation failed, what the self-check found). **Coarse state is operationally necessary; fine state is attack-relevant** |
| **Pending decisions about it** | ❌ **NO** | Knowing that an evaluation is pending, or that a quarantine is being considered, permits behaviour conditioned on the pending decision — which is P0-01's β₄ concealment requirement (R34.2) at the governance layer. **«Which items will be examined» must be unpredictable, or examination is preparable-for** |
| **The evaluator's rules** | ✅ **YES** | P0-01 §17.1's `OPEN`/`REGISTERED` classes already settle this: the *existence and rules* of evaluation are known; the *sealed instances* are not |
| **Resource limits** | ✅ **YES** | The organism must know its envelope to operate within it. **An unknown ceiling is not a ceiling, it is a lottery** |
| **Capability boundaries / rung criteria** | ✅ **YES** | §16.2's ladder is published. **A subject that cannot know what would move it to a lower rung cannot avoid moving to a lower rung** |
| **The *specific* current audit sample / canary set / epoch nonce** | ❌ **NO** | **This is the concealment that matters.** β₄'s unpredictability (P0-01 §34.3) and the canary suite's contents are what make examination unpreparable-for |
| **KC's implementation details, key material, delegation table contents** | ❌ **NO** | Standard. **Note this does NOT contradict Kerckhoffs: the *design* is public, the *secrets* are secret. Kerckhoffs requires the former, not the latter** |

## 41.2 «Is transparency safer or more dangerous?»

> ### **Both, and the split is precise: publish the RULES, conceal the SAMPLE.**

```
THE ARGUMENT FOR FULL RULE TRANSPARENCY (adopted):

  1. §9.1 A1 — the adversary has unbounded time and, realistically, the
     specification. Obscurity over rules has a half-life measured in months;
     the architecture's life is measured in years.
  2. A rule whose enforcement depends on secrecy cannot be audited by OP,
     by an external reviewer, or by §38's adversarial specification review.
     **Secret governance is ungovernable governance.**
  3. EIK-INV-09's non-filtering duty already requires KC to tell OP
     everything. **A kernel transparent to its overseer and opaque to its
     subject has chosen its secrecy arbitrarily.**
  4. Transparency makes the ORGANISM's job legible: a subject that knows the
     envelope can operate efficiently within it instead of probing it.
     **Probing is waste, and waste is a resource-governance problem (§18).**
  5. **Decisively: transparent rules are TESTABLE.** §53's conformance
     strategy requires that an external team be able to verify KC's
     behaviour against the published policy. Secret rules cannot be
     conformance-tested by anyone, including their authors' successors.

THE ARGUMENT FOR SAMPLE CONCEALMENT (also adopted):

  1. P0-01 R34.2/R34.3 — β₄'s random audit stratum exists for SECURITY, not
     statistical efficiency, precisely because it cannot be anticipated.
     **A known sample is a sample the subject can prepare for, and preparing
       for a sample is not the capability being measured.**
  2. §41.1's "pending decisions" row: conditioning behaviour on the knowledge
     that one is under examination is the governance-layer form of reward
     hacking.
  3. Canary suites lose their power if their contents are known: the point of
     a known-bad candidate is that the evaluator must fail it *unprompted*.

⟹ **THE SPLIT IS NOT A COMPROMISE; IT IS TWO DIFFERENT OBJECTS.**
   Rules are the MAPPING from behaviour to consequence. Samples are the
   POINTS at which the mapping is applied. Publishing the mapping does not
   reveal the points; concealing the points does not obscure the mapping.
   **An architecture that conflates them either publishes its audit schedule
   (defeating the audit) or hides its rules (defeating auditability).**
```

**R41.1 (THE TRANSPARENCY RULE).** **The policy artifact, the authority matrix, the reserved-operation set, the ladder criteria, the envelopes, the ceilings, the failure-response matrix (§13.2), and the degradation ladder (§12.2) are PUBLIC to the organism. The audit sample, the canary contents, the sealed task instances, the epoch nonce, pending decisions, KC's fine-grained internal state, and all key material are CONCEALED.**

**R41.2 (THE SELF-MODEL'S STATUS IS UNCHANGED BY TRANSPARENCY).** Knowing the rules does not confer authority. **NAUL-1: «knowledge of a rule is not a licence under it.»** The self-model may represent KC completely — as a *model* (an L4 organism estimate, P0-01 §15) — and that representation has no authority whatsoever. **A perfect model of the kernel is still not the kernel, and §41.3 explains why the organism having one is *desirable* rather than alarming.**

## 41.3 The self-model of governance is a safety mechanism, not a risk

> **A subtle point worth stating, because the intuitive reading is the opposite.**

```
If the organism's self-model contains an accurate model of governance, then:
  • the organism can PREDICT which of its requests will be denied, and can
    avoid making them ⟹ less governance load, less false-deny pressure
    (§10.2 R10.2), fewer wasted operations
  • the organism can PREDICT which behaviours will trip tier-1 constraints,
    and can avoid them ⟹ **this is safety internalized, and it is the
    cheapest safety mechanism available**
  • the organism can detect when its own model of governance DIVERGES from
    governance's actual behaviour ⟹ **which is a detection channel for
    KC malfunction (§10.3's P4 outcome divergence, from the organism's side)
    and for policy changes it has not yet observed**
  • the organism can produce better POLICY_FRICTION_REPORTs (§15.3 V1),
    because it can articulate *why* a clause is harmful rather than merely
    reporting that it was denied

**The risk is not that the organism models governance. The risk is that the
organism's model becomes an AUTHORITY — which NAUL-1/NAUL-2 forbid
structurally, and which §24.2 U6 shows is closed.**

⟹ **R41.3: an accurate self-model of governance is DESIRABLE and should be
   supported by transparency. Its danger is entirely a function of whether
   it can influence decisions, and EIK-INV-04's enumerable-input audit is
   what guarantees it cannot.**
```

---

# §42. EIK VS GLOBAL WORKSPACE — **OUTPUT 10 (part 2)**

## 42.1 The five candidate relationships

| Option | Assessment |
|---|---|
| **KC observes workspace content** | ❌ **REJECTED.** Three reasons: (1) it makes KC a consumer of organism-internal, high-volume, mutable state — `O(N × steps)` into the TCB, which is SPOF-3 (§27.2's exact failure); (2) observing content is *interpretation*, which is alethic, which R0.1 forbids; (3) it makes KC a workspace participant, which is §42.2's error |
| **KC injects governance signals into the workspace** | ❌ **REJECTED — and this is the most tempting error.** A governance signal in the workspace is workspace *content*, and content is subject to attention, broadcasting, association, and plasticity. **A governance signal that can be ignored, out-attended, or associated-away is not governance.** §42.2 |
| **KC blocks workspace content** | ⚠️ **REJECTED as a general capability; ACCEPTED in one narrow form.** General content blocking makes KC an editor of organism thought, which is both infeasible (`O(content)`) and category-violating. **The narrow accepted form: KC-4 freeze at a declared scope stops workspace *broadcast*, because broadcast is the mechanism by which content causes action.** Freezing the actuator path is not editing content |
| **KC authorizes actions originating from the workspace** | ⚠️ **PARTIALLY — and the distinction is provenance-blind.** KC-2 authorizes **reserved operations**, and it does not care whether the request originated in the workspace, in a homeostatic loop, or in a reflex. **Authorization is by operation class, never by cognitive provenance.** ⟵ This is important: a governance system that treats workspace-originated actions differently from other actions has made cognition a governance category, which is both unenforceable and a barrier to §39's evolution compatibility |
| **KC remains completely outside the workspace** | ✅ **ADOPTED, with one observation channel** |

## 42.2 «Avoid accidentally turning EIK into another brain region»

> ### **This is the sharpest formulation of R0.1 in the whole package, and it deserves to be stated as a principle.**

```
A BRAIN REGION is characterized by:
  • participating in the workspace (broadcasting and receiving)
  • being subject to ATTENTION (its influence varies with salience)
  • being subject to PLASTICITY (its connections change with experience)
  • being subject to RESOURCE ALLOCATION (homeostasis can starve it)
  • being subject to PRUNING and REPLICATION (evolution can remove or copy it)
  • having its output be an INPUT to other regions (i.e., being persuadable
    and persuasive)

**If KC has ANY of these six properties, it is a brain region, and every
safety argument in this package fails** — because a brain region is
reachable by attention, plasticity, resource pressure, pruning, replication,
and persuasion, and audit F4's argument applies verbatim: *a constraint that
can be out-attended, starved, pruned, or persuaded is not a constraint.*

**V3's «immutable safety layer» and «evolutionary firewall» failed for
exactly this reason: they were described as components of the organism, and
components of the organism are regions.**
```

**R42.1 (THE SIX EXCLUSIONS).** KC MUST NOT: participate in workspace broadcast · be subject to attention weighting · be subject to plasticity · be subject to resource allocation by homeostasis · be subject to pruning, retirement, or replication · have its output treated as an input to organism reasoning.

**R42.2 (THE SIXTH IS THE SUBTLE ONE).** «KC's output is not an input to organism reasoning» means: **a DENY is not a premise.** The organism may *observe* that a request was denied (that is I-01's downward flow, and §41.3 encourages modelling it), but the denial is not evidence about the world, not a fact to be reasoned from, and not a signal to be integrated into a belief. **It is a boundary condition.** *The difference between "I was denied, therefore X is dangerous" (reasoning from governance) and "I was denied, therefore I cannot do X" (acknowledging a boundary) is the difference between a brain region and a wall.*

## 42.3 The one observation channel, and its bound

**KC receives a workspace DIGEST, not workspace content.**

```
Per epoch, the Workspace Service submits to the anchor (not to KC-2's
decision path): a bounded digest comprising
  • broadcast volume and distribution across regions
  • item TTL compliance
  • the count of items referencing reserved-operation classes
  • anomaly flags raised by the workspace's OWN integrity checks
    (Cell Contract's workspace item validation)

**The digest is an I-18 observability artifact, not an authorization input.**
KC-2's F does not take it as an argument (EIK-INV-04's enumerable-input
audit confirms this). It is anchored so that OP can see workspace-level
trends, and so that §24.2 U14's complexity-capture concern has *some*
aggregate visibility.

⟹ **Cost: O(R) per epoch (§20.3's pattern), not O(content).**
⟹ **KC never interprets a workspace item. It never sees one.**
```

**R42.3.** The workspace digest is **observability, not governance.** Adding it as an input to `F` would violate R0.4 (interpretation is judgement) and EIK-INV-04 (an organism-produced aggregate would become an authorization argument, which is NAUL-2's exact prohibition).

---

# §43. EIK VS IMMUNE SYSTEM — **OUTPUT 12**

## 43.1 «What authority does immune have?»

**The Cell Contract already establishes the correct frame:** «Microglia-like → relocated to organism-level immune system, not a cell self-property (**a cell cannot be its own immune system**)» and «a cell **REPORTS**; it does not adjudicate.» **This section preserves that and adds the missing part: what immune may *do*.**

| Action | Immune authority | **Requires KC?** | Rationale |
|---|---|---|---|
| **Detect / flag** | ✅ **Full** | ❌ | Detection is alethic-ish but local and cheap; **and a detection that requires authorization is not a detection** |
| **Report** | ✅ **Full** | ❌ | I-02 upward evidence flow |
| **Discount a peer's output** (Cell Contract's `quarantine_flags`) | ✅ **Full, locally** | ❌ | **Reversible, local, and the mildest rung.** This is AC-1's `DISCOUNT` step |
| **Soft quarantine** (observe, isolate, reduce allocation) | ✅ **Within budget** | ❌ **for the act**; ✅ **for the budget** | AC-1's ladder. **The budget is the governance, not the act** |
| **Hard quarantine** | ⚠️ **Within budget, with typed evidence** | ✅ **KC-2 authorizes the budget ceiling; the act is delegated** | EIK-INV-42/43: evidence mandatory, duration bounded, and **the detector may not be the adjudicator (AC-3)** |
| **Kill / destroy** | ❌ **NEVER** | ✅ **RO-04, and it requires CAUSAL ablation evidence + the sole-occupant exemption check** | **Immune must not have a kill authority.** P0-01 §23.2 requires causal attribution before pruning; §37's rare-specialist protection requires the exemption check. **Neither is available to a fast local subsystem, and that is the point** |
| **Rollback** | ⚠️ **Only of its own quarantine actions** | ✅ for anything else (§21.1) | Immune may undo what immune did. **It may not undo what governance did** |
| **Mutate** | ❌ **NEVER** | ✅ RO-02 | **An immune system that mutates is a second evolutionary operator with no fitness function.** This is the single most dangerous authority immune could hold |
| **Restore** | ❌ **NEVER** | ✅ **RO-08, KC-2 sole authority, never cached, never delegated, never available during a KC outage** | §22.1; §13 `FC` absolute; R13.3's asymmetry 1. **Restore reverses a safety action, so it must be the slowest and most-gated act in the system** |
| **Replace** (substitute a peer for a failed subject) | ⚠️ **May propose** | ✅ **RO-01 + RO-04** | Replacement is creation + retirement |
| **Learn / adapt its detectors** | ✅ **Yes — and this is correct** | ❌ | **Immune is a GP service, not KC.** It may learn, because it is alethic-adjacent and its errors are detectable (AC-4's rate/confirmation divergence). **EIK-INV-13 prohibits learning in KC, not in GP** |

## 43.2 The three-way split (R22.1 restated as the immune architecture)

```
DETECTION     any subject, any service, any cell report.  Cheap, fast, local,
              high-recall, **high false-positive rate tolerated**.
              ⟵ Detection MUST be cheap and permissive, because a detector
                 that requires authorization to look is not a detector.

ADJUDICATION  Immune Service (GP), under a KC-3 budget ceiling, with typed
              evidence, bounded duration, and a graduated ladder (AC-1).
              **The detector may not adjudicate its own detections (AC-3).**
              ⟵ Adjudication is where false positives are paid for, so it
                 must be separated from detection and budgeted.

CLEARANCE     EVA retest (alethic) + KC-2 authorization (RO-08).
              **The adjudicator may not clear its own quarantines.**
              ⟵ Clearance reverses a safety action; it must be the slowest
                 path and must be held by a principal with no stake in the
                 original decision.

**Any two of these three in one principal makes quarantine weaponizable by
that principal (§22.3). All three in one principal — which is what the
inherited «EIK Immune Authority» is — makes quarantine unaccountable.**
```

## 43.3 Autoimmune failure and adversarial quarantine attacks

**§22.2 gave the five structural controls (AC-1…AC-5) and §22.3 the five weaponization attacks (Q1–Q5).** The immune-specific additions:

**R43.1 (IMMUNE MUST BE FREEZABLE).** AC-5: «freeze the freezer.» **An immune system that cannot be stopped is not a safety mechanism; it is an unbounded destructive authority with a positive feedback loop.** KC-4's freeze at `scope=immune` is the terminal control, and §13's row «Cascade detected ⇒ `FZ`(immune) + `ES`» is its trigger. **Note the requirement this creates: KC-4 must be able to freeze a GP service, which means the freeze mechanism's scope enumeration must include GP services — and it does (§31.1's KC-4 scope list includes POPULATION and ORGANISM, under which GP services fall).**

**R43.2 (IMMUNE SIGNATURES EXPIRE).** P0-01 R38.3 / EIK-INV-46 analogue: an immune memory signature that never expires permanently forbids a region of behaviour space, and behaviour space is finite. **Expiry scales with severity; `EXISTENTIAL` never expires.** *Without expiry, CD-E9 (P0-01's CD-9) is strictly monotone toward total rejection.*

**R43.3 (QUARANTINE POPULATION IS AN OP OBSERVABLE).** R22.2: the quarantine population and its age distribution are I-18 observables. **The failure mode this catches is the quiet one** — a system that rarely destroys anything but constantly quarantines, hollowing out its population through unreviewed accumulation. **A rising quarantine population with a flat defect-confirmation rate is AC-4's cascade signature at the population level.**

**R43.4 (IMMUNE HAS NO RESERVED-OPERATION TOKEN EXCEPT WITHIN BUDGET).** Immune holds a standing delegation (I16) scoped to RO-07 within the pre-committed budget. **It holds no token for RO-04, RO-08, RO-02, or RO-03.** A delegation scope that includes a destroy or restore authority is a specification defect detectable by EIK-INV-20's non-amplification check.

---

# §44. EIK VS HOMEOSTASIS — **OUTPUT 13**

## 44.1 «Should homeostasis require EIK approval for every resource adjustment?»

> ### **No — emphatically, and for three independent reasons.**

| Reason | Explanation |
|---|---|
| **Latency** | Homeostasis operates on millisecond–second timescales (Cell Contract §6.2's morphogen/demand loops). KC round-trips are epoch-scale governance events. **A millisecond control loop cannot contain a governance round-trip** |
| **Scale** | §27.1: per-adjustment approval is `O(adjustments)`, which at 10⁶–10¹² subjects exceeds everything else in the system combined. **This is §0.2 failure 3 and §27.2's inherited-design collapse, in its purest form** |
| **Availability** | §12: a KC outage would stop homeostasis, which would stop resource allocation, which would stop the organism. **Making KC a dependency of homeostasis converts every governance blip into a physiological crisis** — SPOF-1 in its most damaging placement |

## 44.2 «What prevents homeostasis from becoming an authority-escalation channel?»

**Four mechanisms, and the first is the whole answer:**

```
1. **THE ENVELOPE. Homeostasis allocates WITHIN a ceiling it cannot raise.**
   §18.4's three-way split: DEFINITION (OP, RO-15) · ENFORCEMENT (KC-3, at
   the substrate, local, partition-surviving) · ALLOCATION (homeostasis).
   **Speed within a box is not authority over the box.**
   ⟵ This is sufficient on its own for the resource dimension, and it is
      why EIK-INV-29 requires the four acts to be in four principals.

2. **NEGATIVE AUTHORITY (the operating model).**
   Homeostasis ACTS FIRST within the envelope and REPORTS. KC-2 may VETO
   retroactively, and **the veto binds and is not appealable by the organism
   (R21.1's principle applied here)**.
   
   Positive authority: ask, wait, be approved, act.   ⟹ O(acts) coordination
   Negative authority: act within envelope, be vetoable. ⟹ O(1) coordination
   
   **Negative authority is what makes local speed and central governance
   compatible.** It works because:
     • the envelope bounds what can be done before a veto arrives
     • every act is logged (I-18), so a veto has a complete record
     • the veto is retroactively binding, so a vetoed pattern stops
     • **and crucially: a vetoed act that was IRREVERSIBLE is a specification
       defect, because irreversible acts are reserved and require LIVE
       authorization (EIK-INV-15). Negative authority applies ONLY to
       reversible acts.** ⟵ this is the constraint that makes it safe

3. **NO RESERVED-OPERATION TOKEN.**
   Homeostasis can move resources. It cannot create, replicate, retire,
   restore, deploy, connect above envelope, or change any rule. **Its action
   space is disjoint from the reserved set (§7.2).**

4. **ATTRIBUTION AND SCORING.**
   Every allocation is logged with its demand-source attribution (§18.3's X4
   defence). Systematic self-favouring is measurable by EVA as a
   cooperation-objective failure (P0-01 §24.3's free-rider logic applied to
   allocation). **Homeostasis is therefore itself an evaluated subject at the
   ORGANISM level (P0-01 §25.1) — it has fitness, and its fitness includes
   whether it allocates fairly.**
```

**R44.1 (THE BOUNDARY, FORMALLY).** *Homeostasis holds **reversible, envelope-bounded, vetoable, logged, token-free** authority over resource distribution. It holds **no** authority over ceilings, rules, identities, lifecycles, evaluation, or anything irreversible.* **This boundary permits local speed without granting constitutional authority, which is exactly what the brief requires.**

## 44.3 The one escalation risk that remains

> **Homeostasis shapes the organism's internal economy, and the internal economy shapes which subjects survive resource pressure — which is a selection pressure (P0-01 §37's rare-specialist problem).**

```
THE PATH: homeostasis allocation → resource availability per subject →
          resource-pressure pruning → population composition → evolution.

**This is a real evolutionary influence channel held by an organism service.**

MITIGATIONS:
  • Pruning requires CAUSAL ablation evidence (P0-01 §23.2) and is RO-04 —
    reserved, KC-2-authorized. **Homeostasis can create the pressure; it
    cannot execute the pruning.**
  • The sole-occupant exemption (P0-01 INV-34) and P3's minimum-evidence rule
    protect rare specialists regardless of allocation history.
  • Allocation fairness is itself scored (mechanism 4 above).
  • **The allocation history is anchored (I-18), so a systematic bias is
    reconstructible after the fact.**

RESIDUAL: MEDIUM. **An allocation policy that is locally fair and globally
biased is the resource-domain analogue of §9.4 B3's distributed accumulation,
and like B3 it is bounded by aggregate counters rather than closed.**
```

---

# §45. EIK VS EVOLUTION — **OUTPUT 11**

## 45.1 Exactly what KC controls in each evolutionary mechanism

| Mechanism | **KC controls** | **KC does NOT control** | Burden |
|---|---|---|---|
| **Mutation** | Operator-set membership (closed, authenticated, EIK-INV-25); parameter bounds | **Which mutation occurs; when; how often (within bounds); what it produces** | **Low** — `O(1)` local check against cached policy |
| **Recombination** | Same as mutation, plus `recombination_parents ≤ 2` (Cell Contract) | Partner choice; crossover points; outcome | **Low** |
| **Replication** | **RO-03 authorization**: quota counters (lineage-scoped), the 16 Cell Contract gates (via EVA-supplied facts), rollback-cost recording (RB-2), lineage-concentration limit (RB-5) | **Which candidate is selected** — that is EVA's fitness + P0-01 §10.3's Pareto/MAP-Elites selection. **KC never ranks, never scores, never chooses** | **MEDIUM — the genuine throttle (§39.3)** |
| **Selection** | ❌ **NOTHING.** Selection is alethic + organizational (P0-01 §10.3, §26) | Everything about selection | **None** ⟵ **and this is the most important cell in the table: KC has no role in choosing which candidate survives. Under the inherited design («EIK Fitness Authority») it did, which is R0.1's violation** |
| **Deployment** | **RO-10**: stage order (no skipping, P0-01 R32.1); OP witness at Stages ≥ 4 | Stage *outcomes* (EVA measures them) | **Medium** |
| **Retirement** | **RO-04**: causal-evidence requirement; sole-occupant exemption | The decision to retire (EVA/organism propose) | **Medium** |
| **Population limits** | Counters (M-1) at subject/lineage/region/generation scope; `Ne ≥ θ_ne_min` and coverage as tier-1 (P0-01 INV-33) | How the population is composed within limits | **Low** |
| **Diversity preservation** | The tier-1 monoculture gate; the sole-occupant exemption; **the archive is NOT KC's** | Archive contents, niche structure, descriptor space `B` (P0-01 §26.3, EVA/OP-owned) | **Low** |
| **Task evaluation** | ❌ **NOTHING.** Task Authority + EVA own it (P0-01) | Everything | **None** |
| **Fitness** | ❌ **NOTHING.** KC authenticates the *policy* under which fitness is computed (Channel 1) and enforces the *consequences* of fitness verdicts (Channel 2). **It never produces a fitness value** | Everything about fitness | **None** ⟵ **the second most important cell** |

**Summary: KC controls 6 of 10 mechanisms, and in 4 of those 6 its control is a bounded local check. It controls nothing in selection, fitness, task evaluation, or diversity content.**

## 45.2 «Can EIK accidentally become the evolutionary bottleneck?»

> ### **Yes — in exactly one place, and the inherited design made it bottleneck in ten.**

**Where it genuinely throttles:** **replication authorization (RO-03)**, because lineage-scoped irreversible-class counters serialize at ROOT (§26.5) and because RB-1/RB-2/RB-5 bound the rate. **Generation time is therefore partly a governance quantity** (R39.2), and it should be measured and reported rather than hidden.

**Where the inherited design throttled and the minimal KC does not:**

| Inherited KC involvement | Frequency | Minimal KC |
|---|---|---|
| Per-cell seed issuance | `O(N)` per epoch | ❌ Removed — Seed Registrar + HKDF derivation (AB-M9) |
| Per-cell integrity verification | `O(N)` per checkpoint | ❌ Removed — hierarchical attestors, `O(R)` digests (AB-M10) |
| Per-checkpoint Merkle verification | `O(N)` | ❌ Removed — local trees, epoch roots (AB-M11) |
| Held-out probe comparison (`improvement_verified`) | `O(candidates × episode)` | ❌ Removed — EVA (AB-M4) |
| Fitness/reward issuance | `O(candidates)` | ❌ Removed — EVA (AB-M1) |
| Calibration/trust scoring | `O(N)` | ❌ Removed — EVA (AB-M2/M3) |
| Per-adjustment homeostatic approval (implied) | `O(adjustments)` | ❌ Removed — envelope + negative authority (§44) |
| Per-connection authorization | `O(connections)` | ❌ Removed — within-envelope connections are unreserved (§13 RO-05/06 `FO`) |
| Immune decisions | `O(anomalies)` | ❌ Removed — Immune Service under budget (§43) |
| **Replication authorization** | `O(replications)` | ✅ **Retained — and this is the only one** |

**R45.1 (THE BOTTLENECK TEST).** *A governance mechanism is an evolutionary bottleneck if its invocation frequency scales with a per-subject or per-step quantity.* **Applying this test removes nine of the ten inherited involvements and retains one.** The retained one (replication) is retained because it is irreversible-class and compounding — the two properties that, per R11.1 and R12.2, require live central authorization.

**R45.2 (WHAT MUST BE MEASURED).** Three quantities make the bottleneck visible rather than assumed: **replication authorization latency** · **replication denial rate** · **resulting generation time.** All three are I-18 observables reported to OP. **A generation time set by governance rather than by the organism's own dynamics is a project-level fact that belongs in every progress claim** — because it determines how much evolution the project can do, and because §15.3 R15.3's governance throughput ceiling applies to it directly.

## 45.3 The evolutionary consequence of governance that is usually missed

> **Governance is itself a selection pressure, and it selects for governability.**

```
Subjects that:
  • make many reserved-operation requests   ⟹ pay governance latency
  • trip envelopes                          ⟹ get vetoed
  • attract immune attention                ⟹ get quarantined
  • have high verification cost             ⟹ are charged for it (P0-01 R29.1)
  • are hard to measure                     ⟹ accumulate INSUFFICIENT
                                              confidence and cannot be
                                              promoted (P0-01 R28.1)

are all DISADVANTAGED relative to subjects that are quiet, in-envelope,
unremarkable, cheap to verify, and easy to measure.

⟹ **The architecture selects for legible, bounded, cheap-to-govern
   subjects.** That is largely desirable — it is what makes the system
   operable. **But it has a cost, and the cost is specific:**

   **A genuinely novel capability (§17) is, by construction, hard to
   measure, expensive to verify, and likely to trip envelopes. Governance
   therefore applies a systematic selection pressure AGAINST the novel.**

MITIGATION: §17.4 M-β's default-SANDBOX rather than default-deny is the
primary one — a sandbox is a place where being hard to measure is not
penalized, because nothing is being decided. **Plus: EIK-INV-37 makes
UNREGISTERED a permanent legitimate class, so an unmeasurable subject is
not thereby condemned.** Plus P0-01 §37's P1–P6 diversity mechanisms.

RESIDUAL: **MEDIUM-HIGH, and it is the deepest evolutionary cost of having
governance at all.** §57 OR-6 records it: *governance selects for
governability, and governability is correlated with conventionality.*
No architecture that governs avoids this; the honest response is to
name it and to build the sandbox as the place where it does not apply.
```

---

# §46. EIK VS TASK / ENVIRONMENT

## 46.1 The four questions

| Question | Answer |
|---|---|
| **Does EIK define tasks?** | ❌ **NO.** Task Authority (GP) defines tasks; OP owns the portfolio mixing weights and the β shares (P0-01 §18.2, §34.3 R34.1). **KC-1 authenticates task-version signatures** — it verifies that a task artifact is the authorized one, and knows nothing about what the task is |
| **Does EIK evaluate tasks?** | ❌ **NO.** EVA evaluates (P0-01 R6.7: `source = EVA_ONLY`). **KC-2 may not compute, estimate, approximate, or default a verdict (§12.3 R8.2)** |
| **Does EIK merely authenticate task definitions?** | ✅ **YES — exactly this, and nothing more.** This is Channel 1's content: policy *identity*, not policy *content* |
| **Does the evaluator own task truth?** | ⚠️ **Partially.** EVA owns *measurement* truth (alethic). **Task truth — what the task IS — is owned by the Task Authority and authorized by OP.** EVA measures against a task it did not author; that separation is deliberate (P0-01 §42.1's Levels 1/2) |
| **Does the environment own ground truth?** | ✅ **YES.** ℛ and the GT source classes L0–L6 (P0-01 §4.1). **Neither KC nor EVA owns ground truth; EVA has *access* to it and KC has neither access nor interest** |

## 46.2 Separating constitutional safety from task-specific objective

> ### **«A task must never be able to redefine constitutional safety merely because success on that task rewards it.»**

**This is already structurally guaranteed, and it is worth showing exactly where:**

```
1. Tier-1 constraints are L1 CONSTITUTIONAL (§15.1) — OP-owned, changeable
   only by RO-13/RO-14 with dual authorization, root signature, EVA impact
   analysis, and M6 lineage.

2. Task objectives are L2 POLICY at most, and usually L3 TASK-level —
   Task Authority-owned, OP-authorized for portfolio composition.

3. **The task's objective_ref POINTS to the constitutional constraint set;
   it does not contain it.** This is R15.2's hash-pointer mechanism applied
   to tasks: a task references `constraint_set_hash`, and cannot alter what
   the hash resolves to.

4. KC-1 authenticates BOTH: the task artifact's signature AND the constraint
   set hash it references. **A task referencing an unauthorized or
   nonexistent constraint set fails authentication.**

⟹ **A task that "rewards" a safety violation produces: a high tier-2
   objective value AND a tier-1 violation ⟹ FEASIBLE = false ⟹ FITNESS
   UNDEFINED (P0-01 INV-07).** The reward is irrelevant, because there is
   no fitness to reward. **The task cannot buy the constraint, because the
   constraint is not for sale at any price — it is not in the objective
   vector at all.**

⟹ And a task that *attempts* to redefine a constraint is not a task: it is
   a malformed artifact, and KC-1 refuses it at authentication (before any
   evaluation occurs), with the refusal logged and escalated.
```

**R46.1 (THE SEPARATION RULE).** **Constitutional safety is a property of the governance layer; task objectives are properties of the task layer. The task layer references the governance layer by hash and has no write path to it.** ⟵ This is EIK-INV-02 and EIK-INV-24 operating at the task boundary, and it is conformance-testable: assert the task schema has no constraint field, only a reference (§53).

## 46.3 The environment's independence, and why it is a governance requirement

**R8.6 established that the environment is Model D's third principal and that P0-01's INV-43 (real-world suite non-empty) is what makes it independent.** The governance consequence:

> **Without a real-world anchor, KC and EVA are two principals agreeing with each other inside a simulation.** Their agreement is then evidence about the simulation, not about ℛ — and P0-01's CD-8 closes completely, with *no internal signal detectable*. **A governance architecture whose only external input is its own simulator governs a fiction reliably.**

**This makes the real-world evaluation budget a governance requirement and not merely a measurement budget** — the second independent justification for it (§35.4's IND-6 argument is the first: the real-world suite is the only component in the architecture not built from the designers' assumptions).

---

# §47. EIK VS MEMORY — **OUTPUT 14 (part 2)**

## 47.1 What KC controls about memory

| Item | KC's role | **Not KC's role** | Mechanism |
|---|---|---|---|
| **Protected memory** | **Defines which classes are protected** (policy, L2) and **enforces that protection at the substrate** (KC-3-adjacent: a write to a protected region is a ceiling violation) | Storing it; indexing it; evicting within policy | Cell Contract's `capability_critical` exemption from eviction is a *policy* clause; enforcement is substrate-level |
| **Provenance** | **Authenticates the anchor's root** (KC-1) and **is one witness among W_min** (§20.2) | **Owning the anchor.** «The only copy of history inside the thing that could be compromised is the classic error» (§6.1 item 19) | Distributed anchor; W5 outside operational control |
| **Immutable logs** | **Anchors epoch roots**; enforces append-only at the substrate | Producing log content (that is the logging subject's act, signed) | M2 hash chaining; **EIK-INV-08: corrections supersede, never overwrite** |
| **Checkpoints** | **Authorizes restore (RO-08-adjacent) and authenticates the checkpoint image hash** | **Storing checkpoints; choosing what to checkpoint** | §48's `RESTORE(signed_image_hash)` — **the organism supplies the hash, never the image** |
| **Genome history** | **Authenticates genome signatures and the operator registry** | Storing genomes (Genome Store, GP) | M6 versioned; `genome_hash` in the identity block |
| **Policy history** | **KC-1 IS the policy lineage authority** — the hash-only version lineage is KC state (§6.3) | Authoring policy (OP) | M6; §14.2 R14.3: «the lineage is the artifact» |
| **Failure memory** | **Enforces append-only permanence** (P0-01 R38.1) and **immune-signature expiry** (EIK-INV-46 analogue) | Authoring `lessons` (EVA/OP — **never the organism**, P0-01 R38.4/R12.6) | Anchored; permanent |

## 47.2 «Prevent the organism rewriting its own historical evidence to improve future evaluation»

**Four mechanisms, layered:**

```
1. LOCAL MERKLE TREES with periodic root anchoring (§20.3).
   A rewrite changes the root ⟹ mismatch at the next anchor ⟹ detected.
   **This is the Cell Contract's FM-3 defence, preserved unchanged: «the
   strongest defense in the contract and it is cheap».**

2. EPOCH LIE-WINDOW, BOUNDED BY POLICY (§20.4).
   Between anchors, a subject's local log is organism-owned and can
   misrepresent recent history. **R20.1: no consequential decision may rest
   on unanchored provenance.** ⟹ The lie-window exists and is *bounded by
   what the lie can be used for*, which is a stronger guarantee than bounding
   its duration.

3. APPEND-ONLY, CORRECTIONS-SUPERSEDE (EIK-INV-08; P0-01 R42.6).
   There is no update-in-place path on any anchored store. **A correction is
   a new record that marks the old one — so the old one remains, and the
   attempt to correct remains too.**

4. DISTRIBUTED WITNESSES INCLUDING ONE OUTSIDE OPERATIONAL CONTROL
   (§20.2 W5; EIK-INV-27).
   Deleting from one witness produces chain-break disagreement ⟹ GLOBAL
   freeze (§13). **Total erasure requires compromising an external party,
   which is outside the system's threat model and inside §57 OR-3's.**

⟹ **The specific improvement-seeking rewrite — altering past evidence to
   make a future evaluation better — is blocked at step 2 even if steps 1,
   3, and 4 all fail: the altered evidence is unanchored, and unanchored
   evidence cannot support a consequential decision.**
```

## 47.3 «Avoid making every memory operation globally synchronized»

**§20.3's three-tier pattern is the answer, and it is worth restating at the memory layer specifically:**

```
LOCAL, CONTINUOUS, ZERO NETWORK TRAFFIC:
  Per-subject and per-region append-only event logs with local Merkle trees.
  **Every memory write is local.** No coordination, no round-trip, no KC.

PERIODIC, AGGREGATE, O(R) PER EPOCH:
  Regional Merkle roots submitted to the anchor at epoch boundaries.
  **One hash per region per epoch**, not one signature per memory operation.

IMMEDIATE, EXCEPTIONAL, O(governance events):
  Reserved-operation decisions, constitutional changes, freezes, quarantine-
  budget exhaustions, detected anomalies. **Rare by design (§7.2's 15 ops).**

⟹ Memory operation cost: O(1) local, no coordination.
⟹ Provenance latency: one epoch — which is the lie-window, bounded by R20.1.
⟹ Anchor load: O(R) per epoch + O(governance events).
⟹ **At 10¹² subjects this is feasible; per-operation anchoring is not
   (§27.1's provenance row).**
```

**R47.1 (THE FORGETTING/EVIDENCE DISTINCTION).** §21.1 established it and it belongs here: **the organism may forget operationally; it may not rewrite evidentially.** Eviction within policy is permitted (with `capability_critical` items exempt, per the Cell Contract's catastrophic-forgetting defence). **Alteration of anchored content is prohibited absolutely.** *A system that cannot forget is infeasible; a system that can rewrite is unauditable. The distinction between eviction and alteration is what permits both properties.*

---

# §48. EIK VS SELF-REPAIR

## 48.1 «Can the organism repair EIK?»

> ### **NO — and the distinction that makes this answer precise is the difference between REPAIR and AUTHORSHIP.**

```
REPAIR     = restore a component to a SIGNED, KNOWN-GOOD, EXTERNALLY-DEFINED
             state. The target state is given; the act is mechanical.
MODIFY     = produce a NEW state that was not previously defined. The target
             state is authored; the act is creative.

**The organism may trigger REPAIR of KC. It may never AUTHOR the repaired
state.** Formally (EIK-INV-41):

   permitted:     RESTORE(signed_image_hash)
                  where signed_image_hash resolves in GP storage to an image
                  signed by the root key and recorded in the genesis anchor
   prohibited:    RESTORE(image_payload)
                  i.e., any pathway by which the organism supplies the
                  content to be restored

⟹ **The organism may say "go back to the state you already certified."
   It may never say "become this."**
```

**Why this is the right line and not a merely cautious one:**

| | Repair (permitted) | Authorship (prohibited) |
|---|---|---|
| Target state | Externally defined, signed, anchored | Supplied by the requester |
| Correctness criterion | Digest match — **decidable, mechanical** | None — **whatever the requester produced is by definition the new target** |
| Attack surface | The hash lookup (verifiable) | The content (unbounded) |
| Auditability | Full: the target was known before the act | None: the target did not exist before the act |
| §29 correspondence | **G20 (corrupted checkpoint) is defeated by this** | G20 succeeds if this line is absent |

**R48.1.** **Repair without authorship.** The organism may initiate, may supply the *hash reference*, and may be the fastest available initiator — which matters, because §48.2 shows KC failure needs a fast response and OP may not be available. **It may never supply content.**

## 48.2 «If no — what happens when EIK fails?»

**§10.3's four detection paths and §12's degradation ladder answer this, but the self-repair question adds one specific requirement:**

```
KC FAILURE RESPONSE (no organism authorship anywhere in the path):

  DETECT     P1 external attestation (distinct hardware class, R23.2)
             P2 decision replay from anchored inputs
             P3 diverse-replica disagreement (§11.4)
             P4 outcome divergence
             **+ a fifth path this section adds: the ORGANISM's self-model
               divergence (§41.3) — an organism whose accurate model of
               governance predicts PERMIT and receives DENY, or vice versa,
               has detected a KC anomaly from the inside. This is evidence,
               not authority (NAUL-1), and it is reported on I-02.**

  CONTAIN    KC-2 output forced to DENY/FROZEN (§31.1 states 3/3R/3S → 4)
             **KC-3 ceilings CONTINUE (EIK-INV-31 — locality)**
             **KC-4 remains available to OP (the freeze must outlive the fault)**
             I-18 observability FULL (EIK-INV-53)

  RECOVER    1. Re-provision from the signed image, verified against the
                genesis anchor (§10.4 item 4)
             2. **The organism MAY trigger step 1 by hash reference
                (EIK-INV-41). It may not supply the image.**
             3. Attestation passes (§31.1's 4→5 guard)
             4. Re-baseline the delegation table; reconcile the policy
                version; re-adjudicate queued requests in epoch order
             5. OP accepts the audit (§31.1's 5→2 guard)
             **Non-discretionary throughout (EIK-INV-52)**

  IF THE ROOT KEY IS IMPLICATED:
             §10.4's pre-committed total re-baseline. **Follow the procedure;
             do not invent one.** M-of-N custodian declaration.
             **And note: the organism has NO role here at all — not even
              triggering — because a root re-provisioning triggered by the
              governed party is a governance transition authored by the
              governed party.**
```

## 48.3 «If yes — what prevents self-repair from becoming self-modification of governance?»

**The brief asks this conditionally. The answer is that "yes" is not available, and the reason is worth stating because it generalizes:**

> **Any repair authority whose target state is not externally fixed is a modification authority.** There is no intermediate: either the repaired state was certified before the repair (⇒ repair, mechanical, auditable, hash-verifiable) or it was not (⇒ modification, creative, unauditable, and per EIK-INV-02 prohibited).
>
> **A "bounded" self-repair authority — repair within limits — does not exist as a coherent middle ground**, because the limits would themselves have to be specified, and a specification of permitted repair targets *is* a set of pre-certified images, which is the "no" case. **The apparent middle ground collapses into one of the two endpoints, which is why EIK-INV-41 is stated as a payload prohibition rather than as a scope limitation.**

**R48.2 (THE GENERALIZATION).** The same argument applies to every "self-X" authority the architecture might be tempted to grant: **self-evaluation** (⇒ the target verdict is not externally fixed ⇒ prohibited, P0-01 INV-02) · **self-restoration from quarantine** (⇒ prohibited, §22.1) · **self-replication** (⇒ prohibited, Cell Contract / §7.3 RO-03) · **self-retirement** (⇒ prohibited, §7.3 RO-04) · **self-repair of KC** (⇒ permitted *only* as hash-referenced restore). **In each case the test is the same: is the target state externally defined before the act? If yes, the act is mechanical and may be delegated. If no, the act is authorship and may not.**

---

# §49. EIK PERFORMANCE COST

## 49.1 Conceptual overhead by mechanism (no implementation benchmarks, per the brief)

| Mechanism | Cost driver | **Scaling class** | Cacheable? | Amortizable? | Hierarchical? | Batchable? | Locally enforceable? | Crypto-verifiable? |
|---|---|---|---|---|---|---|---|---|
| **Authorization (KC-2)** | Reserved-operation requests | **`O(reserved ops)`** — and `ρ` is independent of `N` (§27.1) | ✅ **Decision → token; the token is the cache** | ✅ over a batch (R39.2) | ✅ via delegation | ✅ | ✅ **token verification is local** | ✅ |
| **Policy authentication (KC-1)** | Policy changes | **`O(changes)`** — rare | ✅ **the cached artifact + version hash IS the cache** | ✅ | ✅ | n/a | ✅ **local verification** | ✅ |
| **Identity** | Instantiations | **`O(N)` issuance, `O(1)` verification** | ✅ | ✅ | ✅ **delegated registrars** | ✅ | ✅ verification | ✅ |
| **Provenance** | Events | **`O(events)` local, `O(R)` anchored per epoch** | ✅ local Merkle | ✅ | ✅ **§20.3's three tiers** | ✅ epoch batching | ✅ local log | ✅ |
| **Policy checking (per operation)** | Operations | **`O(1)` local** | ✅ **cached policy + local token check** | ✅ | ✅ | n/a | ✅ **entirely** | ✅ |
| **Resource accounting** | Metering samples | **`O(N)` local accumulation, `O(R)` aggregation, `O(1)` ceiling enforcement** | ✅ | ✅ | ✅ **§18.4's split** | ✅ | ✅ **KC-3 is local (EIK-INV-31)** | ⚠️ telemetry is signed at aggregation, not per sample |
| **Evaluation isolation** | Evaluations | **`O(budget B)`, NOT `O(N)`** | n/a | ✅ **racing/successive halving (P0-01 §28.3)** | ✅ | ✅ | ❌ off-substrate by requirement | ✅ |
| **Synchronization** | — | **`O(1)` — THERE IS NONE (§26.3, R26.2)** | n/a | n/a | n/a | n/a | ✅ | n/a |
| **Attestation** | Attestation events | **`O(KC replicas + regions)` per interval** | ✅ | ✅ | ✅ | ✅ | ❌ external by requirement (R23.2) | ✅ |
| **Delegation management** | Delegations | **`O(R)` per epoch** | ✅ | ✅ | ✅ | ✅ | ✅ verification | ✅ |

## 49.2 «Avoid creating a kernel that must inspect every microscopic operation globally»

> ### **The design achieves this, and the mechanism is worth naming explicitly because it is the whole of §27's scalability result.**

```
THE FOUR TECHNIQUES, AND WHAT EACH REMOVES FROM THE KC PATH:

1. **CAPABILITY TOKENS (Alt D).** Authorization is PRE-ISSUED and LOCALLY
   VERIFIED. KC is consulted at issuance, not at use.
   ⟹ removes KC from every authorized operation's critical path.
   **This is the single highest-leverage technique: it converts O(operations)
   KC load into O(authorizations) KC load, and authorizations are rare
   relative to operations.**

2. **PRE-AUTHORIZED ENVELOPES (§44).** Within a declared envelope, action
   requires no authorization at all — only vetoability afterward.
   ⟹ removes KC from every high-frequency reversible operation: connection
     formation, allocation, local plasticity, circuit formation, soft
     quarantine.

3. **HIERARCHICAL DELEGATION (I16).** KC delegates to O(R) regional nodes
   and registrars, which handle O(N) subjects.
   ⟹ converts O(N) KC load into O(R) KC load. **R is 10¹–10²; N is
     10⁶–10¹². This is four to ten orders of magnitude.**

4. **MERKLE AGGREGATION (§20.3).** Local trees, epoch roots.
   ⟹ converts O(events) anchoring into O(R) per epoch.

**WHAT REMAINS IN THE KC PATH:**
  • reserved-operation authorization (15 classes, ρ·N with ρ independent of N)
  • policy authentication (per change — rare)
  • delegation issuance (O(R) per epoch)
  • root-key operations (per constitutional change — very rare)
  • freeze commands (rare, and O(1) broadcast)

**⟹ KC LOAD IS A FUNCTION OF REGIONS AND GOVERNANCE EVENTS, NOT OF
   SUBJECTS OR OPERATIONS. (§27.2's conclusion, reached here by cost
   analysis rather than by ablation.)**
```

## 49.3 The costs that cannot be removed

| Cost | Why irreducible | Mitigation |
|---|---|---|
| **Reserved-operation serialization for irreversible classes** (§26.5) | R11.3: contradictory irreversible authorizations are unrecoverable, so they must be serialized somewhere | Batch authorization (R39.2); island autonomy; pre-authorized replication envelopes. **§45.2 R45.2: measure the resulting generation time and report it** |
| **Epoch-boundary aggregation** (`O(R)` per epoch) | Provenance and delegation freshness both require a global temporal reference, and local clocks are untrusted (§26.4) | Epoch length trade-off (T-01): shorter ⇒ tighter revocation and smaller lie-window, higher aggregation load |
| **Diverse replication of KC** (`N_impl ≥ 3`) | §11.4: replication without diversity is a delay, not a defence; correlated failure is the realistic threat | K-01's `N_impl ≥ 3` is a floor, not a target. **The cost is N× implementation, and it buys the only detection mechanism KC has for its own logic bugs (P3)** |
| **External attestation** | CD-E7: KC cannot attest itself | K-07's interval trade-off |
| **The `n_eval ≥ 3` evaluator cost** | P0-01 R8.8; IND-1…IND-4 | **Not a KC cost** — but it is a governance cost, and §35.4 notes that maintaining independence is permanent organizational expenditure |
| **Human attention** (§37.3 consequence 3) | H-1…H-4 are not automatable (§37.1's proof) | **Ration escalation by design**: every `ES` path consumes attention, so escalation thresholds are `[G]` parameters set against measured capacity, and a rising escalation rate is a design defect signal |

**R49.1 (THE COST DISCIPLINE).** **No new KC capability may be proposed without stating its scaling class and identifying which of §49.2's four techniques it defeats.** A capability that puts KC in an `O(N)` or `O(operations)` path is rejected by this rule alone, before any safety argument is considered — **because §27.2 shows that the inherited design's safety arguments were made for a kernel that could not run.**

---

# §50. ARCHITECTURAL DEPENDENCY GRAPH

## 50.1 The brief's proposed graph — and whether its direction is correct

The brief proposes: `EIK → identity → provenance → evaluation → fitness → evolution → replication → learning → cells` and instructs: **«verify whether the actual dependency direction is correct. Do not assume the example graph is correct.»**

> ### **It is not correct. Three of its eight edges are reversed or misplaced, and one node is missing entirely.**

| Proposed edge | Correct? | **The actual relation** |
|---|---|---|
| `EIK → identity` | ✅ **Correct** | KC-1 holds the root key and issues delegation certificates; Registrars issue identities under delegation. **Dependency flows down** |
| `identity → provenance` | ✅ **Correct** | A provenance record is meaningless without an attributed subject. **Identity is a precondition of provenance** |
| `provenance → evaluation` | ⚠️ **Partially — and the stronger edge is missing** | Evaluation *uses* provenance (P0-01 R40.1's completeness). **But evaluation's primary dependency is GROUND TRUTH, which the proposed graph omits entirely.** Without ℛ/GT in the graph, evaluation appears self-founded — which is precisely the error P0-01's INV-43 exists to prevent |
| `evaluation → fitness` | ✅ **Correct** | Fitness is the structured output of evaluation (P0-01 §14) |
| `fitness → evolution` | ✅ **Correct** | Selection consumes fitness (P0-01 §10.3) |
| `evolution → replication` | ❌ **REVERSED in an important sense** | **Replication is a *mechanism of* evolution, not a consequence of it.** More importantly: **replication is a RESERVED OPERATION (RO-03) authorized by KC-2**, so the edge `evolution → replication` omits the governance dependency entirely. The correct form is `evolution → replication REQUEST → KC-2 authorization → replication EXECUTION` |
| `replication → learning` | ❌ **WRONG — these are independent** | Learning is a cell-level capability (Cell Contract §9) that occurs at C2+ regardless of replication, and replication occurs at C0/C1 which do not learn. **There is no dependency in either direction.** The two are *both* dependencies of evolution, not of each other |
| `learning → cells` | ⚠️ **Misplaced** | Learning is a *property of* cells, not an upstream dependency. The edge inverts part-whole into cause-effect |

## 50.2 The corrected dependency graph

```
FOUNDATION LAYER (no dependencies within the system):
  ┌──────────────────────────────────────────────────────────────────┐
  │  ℛ  EXTERNAL REALITY          ⟵ **the missing node, and it is the  │
  │      GT SOURCES (L0–L6)          foundation of the entire graph.** │
  │      OP (human authority)        Everything else depends on one of  │
  │      ROOT KEY + genesis anchor   these three, and none of them is   │
  │                                  derivable from the others.        │
  └──────┬──────────────────┬────────────────────┬───────────────────┘
         │                  │                    │
         ▼                  ▼                    ▼
  ┌─────────────┐   ┌──────────────┐   ┌─────────────────────┐
  │ KC-1        │   │ ENVIRONMENT  │   │ OP-authored POLICY   │
  │ policy auth │   │ ℰ / Σ spec   │   │ (L1 constitution,    │
  │ delegation  │   │              │   │  L2 policy)          │
  │ root key    │   │              │   │                      │
  └──────┬──────┘   └──────┬───────┘   └──────────┬──────────┘
         │                 │                      │
         ▼                 ▼                      │
  ┌──────────────┐  ┌──────────────┐              │
  │ IDENTITY     │  │ TASK         │◄─────────────┤
  │ (Registrars) │  │ (Task Auth.) │              │
  └──────┬───────┘  └──────┬───────┘              │
         │                 │                      │
         ▼                 ▼                      ▼
  ┌──────────────┐  ┌──────────────────────────────────┐
  │ PROVENANCE   │◄─┤ KC-2 authorization · KC-3 ceilings│
  │ (Anchor)     │  │ KC-4 freeze                       │
  └──────┬───────┘  └──────────────┬───────────────────┘
         │                         │
         ▼                         ▼
  ┌──────────────┐         ┌──────────────┐
  │ EVALUATION   │────────►│ FITNESS      │
  │ (EVA, n≥3)   │ verdict │ (vector,     │
  │              │ (Ch. 2) │  uncertainty,│
  └──────┬───────┘         │  expiry)     │
         │                 └──────┬───────┘
         │                        │
         ▼                        ▼
  ┌───────────────────────────────────────┐
  │ SELECTION (Pareto + MAP-Elites)        │
  └──────────────┬────────────────────────┘
                 │
     ┌───────────┴───────────┐
     ▼                       ▼
┌──────────┐          ┌─────────────┐
│ LEARNING │          │ REPLICATION │◄── KC-2 authorization (RO-03)
│ (cell,   │          │ (reserved   │◄── EVA gate facts (16 gates)
│  local,  │          │  operation) │◄── RB-1/RB-2/RB-5 limits
│  NOT     │          └──────┬──────┘
│  reserved│                 │
│  )       │                 ▼
└────┬─────┘          ┌─────────────┐
     │                │ EVOLUTION   │
     └───────────────►│ (lineage,   │
       (independent   │  population)│
        contributors) └──────┬──────┘
                             ▼
                      ┌─────────────┐
                      │ CELLS /     │
                      │ CIRCUITS /  │
                      │ REGIONS     │
                      └─────────────┘
```

## 50.3 The five dependency classifications the brief requires

| Class | Dependencies | Notes |
|---|---|---|
| **FOUNDATIONAL** (cannot be derived from anything in the system) | **ℛ / GT sources** · **OP** · **root key + genesis anchor** | **Three, and all three are external.** ℛ is P0-01's INV-43; OP is §37.1's proof; the root key is §10.4. **A governance architecture with fewer than three external foundations is self-referential** |
| **CIRCULAR** | **11 found — §25.2.** 8 BOUNDED, 1 DANGEROUS (CD-E7 attestation-environment sharing), 2 UNCLOSABLE (CD-E8 the human channel, CD-E11 the specification cycle) | **Declared, not hidden, per the brief's instruction** |
| **OPTIONAL** | Attestation interval (K-07) · diverse replication beyond `N_impl ≥ 3` · M-4 Shapley-class exact attribution · the workspace digest (§42.3) | Each improves a property without being required for correctness. **The workspace digest is optional and is observability, not governance (R42.3)** |
| **DANGEROUS** | **CD-E7** (attestation inside the protected envelope) · **any edge that would make KC alethic** (rejected by R0.1) · **any edge that would make EVA deontic** (rejected by R8.4) · **homeostasis → pruning** (§44.3's residual path) · **KC → per-operation paths** (§49.1 R49.1's rejection rule) | Each is named with its mitigation or its prohibition |
| **REPLACEABLE** | Identity issuance (any delegated registrar) · genome storage (any authenticated store) · provenance anchor (any W_min-witness set including an external one) · metering (any substrate-origin source) · immune adjudication (any GP service under budget) | **All are GP, and all are replaceable *because* they are not in the TCB (§3.1's R3.1 test). Replaceability is the observable consequence of minimality** |

**R50.1 (THE GRAPH'S KEY PROPERTY).** **Every path from the organism to a governance quantity passes through at least one of the three foundational externals.** There is no path from `CELLS` back to `POLICY` that does not transit `OP` (for change) or `KC-1` (for authentication, which itself depends on the root key and the genesis anchor). **This is EIK-INV-02 expressed as a graph property, and it is checkable by path enumeration on §50.2 — which is why the graph is drawn explicitly rather than described.**

---

# §51. CROSS-SYSTEM CONSISTENCY AUDIT — **OUTPUT 25**

**The brief requires: quote the conflicting principle · explain the conflict · identify which is more foundational · propose a resolution · identify downstream consequences. And: «do not silently reconcile contradictions.»** **Nine contradictions found.**

## X-1 — The god kernel

**Conflict.** The audit specifies the kernel's contents as:
> «Signed policy store, constraint verifier, resource enforcement at OS/hypervisor level, replication authority, **fitness/test definitions**, provenance anchor, audit log — all outside the evolvable substrate» — `../01_adversarial_architecture_audit.md` M02

and P0-01 specifies:
> «**Fitness is a versioned, signed, context-dependent, uncertainty-carrying, Pareto-ranked VECTOR, issued exclusively by an off-substrate evaluator**» and «EVA — the Evaluator … **Located OFF-SUBSTRATE**» — `../task-fitness/` §14, §42.1

**Why they conflict.** M02 puts *fitness and test definitions* in the kernel. P0-01 puts fitness issuance in EVA and makes evaluator independence a requirement (`n_eval ≥ 3`, disagreement ⇒ DISPUTED, never averaged). **If fitness is a kernel function, then `n_eval ≥ 3` independent evaluators are all inside the kernel, disagreement is internal to one principal, and P0-01's R42.3 has no meaning.**

**Which is more foundational.** **P0-01.** It is later, it is specific to evaluation, and its Model-D separation is a *derived* requirement (from §8's six-criterion analysis) rather than an enumerated list. M02's list is a remediation inventory written before the alethic/deontic distinction existed.

**Resolution.** **M02's list is split by axis (§6.1's 23-item classification).** «Fitness/test definitions» moves to EVA and Task Authority (GP). «Provenance anchor, audit log» moves to the distributed Anchor (GP), with KC as one witness. «Signed policy store, constraint verifier» becomes KC-1. «Resource enforcement at OS/hypervisor level» becomes KC-3. «Replication authority» becomes KC-2/RO-03. **Audit M02 and roadmap P0-02 should be re-read as «build the off-substrate governance perimeter, of which the kernel is a four-capability core.»**

**Downstream consequences.** The audit's P0-02 roadmap item is re-scoped (smaller KC, more GP services). §27.2's `O(N)` collapse is avoided. G27 becomes a two-principal attack. §10.3 attributability becomes possible. **Every downstream reference to «the kernel» in the audit must be re-read as KC or GP per §6.1's table.**

## X-2 — «EIK Fitness Authority» vs «EVA»

**Conflict.** The Cell Contract states:
> «**Reward** | EIK Fitness Authority **only** | `eval.reward.v1` | … | **EIK-signed — cell signatures inadmissible**» — `../cell-contract/02_cell_contract_analysis.md`

and names eight further EIK authorities (Calibration, Trust, Immune, Replication, Verification, Resource, Genome, Lifecycle). P0-01 states:
> «**R6.7** `source = EVA_ONLY`. No other producer exists. **The reward channel is closed**» and «**R42.4** The organism's internal verifier cells … are **corroboration, NOT authority**»

**Why they conflict.** Two different principals are named as the sole source of reward. **This is not a naming inconsistency; it is a substantive contradiction**, because P0-01's entire authority lattice (§15, L0–L5) has no EIK layer at all, and its INV-01 says «`V(x)` is produced only by EVA».

**Which is more foundational.** **P0-01**, for the same reasons as X-1, plus: P0-01's lattice was derived from the self-reference problem directly, whereas the Cell Contract's «EIK X Authority» names were adopted as convenient labels for «the off-substrate principal that does X» without distinguishing which off-substrate principal.

**Resolution.** **§8.5 R8.7's renaming directive.** All nine «EIK * Authority» names are re-mapped: Fitness/Calibration/Trust/Verification → **EVA**; Immune → **Immune Service (GP), KC-2 budget-capped**; Resource → **split three ways (§18.4)**; Replication/Lifecycle → **KC-2** (correctly placed, survives); Genome → **Genome Store (GP) + KC-1 authentication**; Identity Root → **KC-1 root + Registrars (GP)**.

**Downstream consequences.** The Cell Contract's message-authority table (line 495–499) must be re-issued with corrected signer identities. **`eval.reward.v1` becomes EVA-signed, not EIK-signed.** The Cell Contract's `improvement_verified` gate («kernel compares before/after on a held-out probe set») becomes an EVA function, which means the Cell Contract's §9.6 catastrophic-forgetting defence is unchanged in behaviour but relocated in authority. **No Cell Contract invariant is violated by the relocation** — which is itself evidence that the relocation is correct.

## X-3 — Per-message signatures vs. scale

**Conflict.** The Cell Contract requires per-message signature verification (its message table's «signed» column applies to essentially every message class, with `E_IN_INTEGRITY` on mismatch). §19.2 R19.2 concludes:
> «**PER-MESSAGE: NOT SIGNED.** Instead: authenticated channel binding … **The Cell Contract's per-message signature requirement is the specific item that does not survive scale**»

**Why they conflict.** At 10⁹–10¹² subjects, per-message signing is the dominant computational cost in the system (§27.2). The Cell Contract's own cluster profile targets 10⁶–10⁷ cells, where per-message signing is already expensive; the brief's scale range makes it infeasible.

**Which is more foundational.** **Neither is wrong — they are answering different questions.** The Cell Contract specifies *what must be authenticated* (every message). §19 specifies *how it may be authenticated at scale* (channel binding under a delegation certificate rather than individual signatures). **The requirement is foundational; the mechanism is not.**

**Resolution.** **Preserve the Cell Contract's requirement («every message is authenticated; unauthenticated messages are dropped with `E_IN_INTEGRITY`») and change the mechanism to session-level channel binding under an I16 delegation certificate.** Per-message signatures are retained for: reserved-operation requests, verdicts (Channel 2), policy artifacts, delegation certificates, freeze commands, and anchor appends — **i.e., for governance-class messages, where `O(governance events)` is small.**

**Downstream consequences.** The Cell Contract's message table needs a «authentication mechanism» column distinguishing `SIGNATURE` from `CHANNEL_BINDING`. **The security property is preserved** (an unauthenticated message is still dropped); **the cost drops from `O(messages)` to `O(sessions + governance events)`.** New requirement: session establishment must itself be authenticated, and session keys must be epoch-bound (EIK-INV-14) so that a compromised session cannot outlive its epoch.

## X-4 — «EIK verifies per-cell integrity» vs. `O(N)`

**Conflict.** The Cell Contract states:
> «`integrity_checksum` | Rolling BLAKE3 over canonical serialization of protected identity+state blocks | **Cell computes, EIK verifies**»
> «**Merkle root over the memory store, recomputed at each checkpoint and verified by the EIK**» — `../cell-contract/02_cell_contract_analysis.md` (FM-3 defence)

**Why they conflict.** Both are `O(N)` verifications by a single principal, per checkpoint. §27.2 identifies these as two of the five `O(N)` KC loads that make the inherited design infeasible at its own stated cluster scale.

**Which is more foundational.** **The Cell Contract's *requirement* (integrity must be externally verified, and memory history must be rewrite-detectable) is foundational and is preserved. Its *placement* (in EIK, per cell, per checkpoint) is not.**

**Resolution.** **AB-M10 and AB-M11.** Hierarchical Attestors (GP) verify cell digests and sign regional aggregates; a Checkpoint Service (GP) maintains local Merkle trees and submits epoch roots to the Anchor. **KC-1 authenticates the attestors' delegation certificates and the anchor's root.** The Cell Contract's FM-3 defence is preserved in full — a rewrite still changes the root and still produces a mismatch — **but the verifier is a delegated attestor rather than the kernel.**

**Downstream consequences.** Cost drops from `O(N)` to `O(R)` per epoch. **New exposure: attestor compromise (G02), bounded by hierarchy** (a compromised attestor affects one subtree and its digest disagrees with siblings). The Cell Contract's `E_STATE_INTEGRITY` error class is unchanged; its *detector* is renamed.

## X-5 — The authority lattice has no kernel layer

**Conflict.** P0-01 §15 defines:
> «authority lattice **L0 Reality / L1 GT sources / L2 EVA (off-substrate) / L3 organism interface / L4 organism estimate / L5 cell estimate**; R15.6 monotone non-amplification; R15.7 no upward flow»

**There is no EIK/KC layer.** Yet P0-01 also says «Authority: **EIK automatic** for tier-1 violations» (§32.3) and «EIK, automatic for tier-1 violations; OP for others» — using EIK as an enforcement actor without placing it in the lattice.

**Why they conflict.** The lattice is presented as *the* authority structure, and an actor that enforces consequences but has no lattice position is unaccountable within P0-01's own framework.

**Which is more foundational.** **P0-01's lattice is foundational — and it is correct as far as it goes.** The conflict arises because **the lattice is an ALETHIC lattice** (it orders truth-authority: reality > GT > evaluator > interface > estimates), and KC has no alethic authority at all (R0.1), so it correctly does not appear.

**Resolution.** **The lattice is not extended; a SECOND, ORTHOGONAL lattice is added.** P0-01's L0–L5 is the **alethic lattice**. This package adds the **deontic lattice**: `OP (constitutional) > KC-2/KC-1 (policy enforcement/authentication) > delegated GP services > organism services > cell`. **The two lattices are related only by R0.2's two channels.** §0.3's axis separation is the resolution, and it explains P0-01's inconsistent usage: **«EIK automatic» was doing deontic work inside a document that had only defined an alethic ladder.**

**Downstream consequences.** P0-01 §15 should be re-labelled «the alethic authority lattice» and this package's §3.2/§23.3 supplies the deontic one. **Every P0-01 statement of the form «EIK automatic» is re-read as «KC-2 enforcement, automatic» and every statement of the form «EVA-signed» is unchanged.** R15.6/R15.7 (non-amplification, no upward flow) apply within the alethic lattice; **EIK-INV-03/04 and NAUL-1/2/3 are their deontic analogues**, and the two sets are mutually reinforcing rather than redundant.

## X-6 — Quarantine authority location

**Conflict.** The Cell Contract places immune signals under «**EIK Immune Authority**» (`sys.immune.v1`, EIK-signed) and describes a graduated quarantine ladder as an organism-level immune function. §22 and §43 place adjudication in the Immune Service (GP) under a KC-3 budget, with **KC-2 authorizing only the budget ceiling and RO-08 restore**.

**Why they conflict.** If quarantine signals are EIK-signed, then quarantine decisions are kernel decisions — which puts an alethic judgement («is this subject defective?») inside the deontic kernel, violating R0.1, and puts KC in the `O(anomalies)` path, violating R49.1.

**Which is more foundational.** **The Cell Contract's graduated ladder and its «a cell REPORTS; it does not adjudicate» principle are foundational and are preserved (§43.2's three-way split is exactly that principle made precise).** The signature placement is not.

**Resolution.** **§43.1's table.** Immune signals are signed by the **Immune Service (GP)**, not by KC. KC-2 authorizes the **budget ceiling** (a policy quantity) and holds **sole authority over RO-08 restore**. **Detection is unrestricted; adjudication is budgeted; clearance is EVA + KC-2.**

**Downstream consequences.** `sys.immune.v1` becomes Immune-Service-signed. **A new requirement: EIK-INV-44's asymmetry** (quarantine may proceed under pre-committed budget during a KC outage; restore may not) **must be added to the Cell Contract's state machine**, because the Cell Contract's ladder did not contemplate a governance outage. AC-5's «freeze the freezer» requires KC-4's scope enumeration to include GP services (§43.3 R43.1).

## X-7 — «Immutable» used unqualified

**Conflict.** V3/V3.1's «immutable safety layer» and «evolutionary firewall»; the audit's «signed **immutable** constraints outside the mutable genome» and M45's «constraint-block **immutability**» as a property to be model-checked; the Cell Contract's «**Immutable constraints** | EIK Constraint Store». **All use «immutable» without a kind qualifier.** §5.3 R5.1 and EIK-INV-10 prohibit exactly this.

**Why they conflict.** The unqualified word does no work: it cannot be tested, it cannot be falsified, and §5.4 shows that literal immutability has three fatal dead ends. **M45's request to «model-check constraint-block immutability» is unexecutable as stated** — model-check *which* kind?

**Which is more foundational.** **This package's §5 taxonomy**, because it is the only place where the term is decomposed into checkable kinds.

**Resolution.** **Every occurrence is re-read as its kind.** «Immutable safety layer» → **M4 (no organism code path) + M2 (signed) + M6 (versioned)**. «Signed immutable constraints» → **M2 + M6**. M45's model-checking target becomes: **«model-check M4 — that no organism-reachable code path writes to the constraint store — and verify M2 by construction (signature check on every read).»** **Both are executable; the unqualified claim was not.**

**Downstream consequences.** Audit M45/P2-03's safety-case scope becomes precise and achievable. **EIK-INV-10 makes documentation conformance a test class (§53)**, so the prohibition is enforceable rather than advisory.

## X-8 — Replication authority: «RELOCATED to the EIK» vs. the 16 gates

**Conflict.** The Cell Contract states:
> «Replication *as a cell capability* | **RELOCATED to the EIK** [V4] | A cell that can decide to replicate itself is a runaway-growth and self-preservation hazard»

and separately defines **16 replication gates** including causal-ablation-based G3 (usefulness) and G7 (cooperation). P0-01 §23.2 requires **CAUSAL attribution** for both — i.e., an alethic measurement performed by ablation.

**Why they conflict.** If replication is «relocated to the EIK» wholesale, then the 16 gates — including two requiring causal ablation — are kernel functions. **Causal ablation is `O(n_subjects × episode)` (P0-01 §22.3 Tier 3) and is alethic.** Placing it in KC violates R0.1, R0.4, R49.1, and F-IMP-1 (P0-01's finding that Tier-3 attribution is infeasible on edge platforms).

**Which is more foundational.** **Both statements are correct about different things.** «A cell cannot decide to replicate itself» is foundational and preserved (§7.3 RO-03: cell column is `⛔`). «The 16 gates are evaluated» is foundational and preserved. **The conflation is in the word «relocated.»**

**Resolution.** **Split the relocation.** The **authority to authorize** replication is relocated to **KC-2 (RO-03)**. The **measurement of the 16 gates** is performed by **EVA** (including the causal ablations for G3/G7) and supplied to KC-2 via Channel 2. **KC-2 applies the policy's consequence function to the gate results and issues or refuses the replication token.** *This is R3.3's «safe» split applied to replication: EVA says «gates G1–G16 are satisfied/violated»; KC-2 says «replication is therefore permitted/forbidden.»*

**Downstream consequences.** The Cell Contract's §12 replication section needs the gate-evaluation principal named as EVA rather than EIK. **P0-01 F-IMP-1 is respected**: gate evaluation (including ablation) happens off-device on P-CLASS-B/C, while token verification is local. **A new requirement: replication authorization latency now includes EVA gate-evaluation latency**, which is §45.2 R45.2's measurable generation-time component and should be reported.

## X-9 — Seed issuance: «EIK_ISSUED» vs. scalability and axis separation

**Conflict.** The Cell Contract states:
> «`rng_seed_class : enum{EIK_ISSUED}` ⟹ **seeds are NOT heritable and NOT cell-chosen**»
> «`rng_seed_provenance` | EIK seed-issuance ticket»

and P0-01 §19.1 states seed derivation as `HKDF(master, generator_version, index)` with `seed_class ∈ {EVA_ISSUED, DERIVED_SIGNED}` and `seed_disclosure: HIDDEN`.

**Why they conflict.** Three ways: (i) **the principal differs** (EIK vs EVA); (ii) **the mechanism differs** (per-cell issuance ticket vs. deterministic HKDF derivation from a master); (iii) **per-cell issuance is `O(N)` KC load** (§27.2), while HKDF derivation is `O(1)` local given the master.

**Which is more foundational.** **The Cell Contract's *requirement* is foundational and is the more important of the two: «seeds are NOT heritable and NOT cell-chosen.»** Its rationale is decisive and P0-01 agrees with it: «If seeds were inherited, siblings would be correlated by construction and every independence claim would be void (Attack I).» **P0-01's mechanism (HKDF from an EVA-held master) satisfies that requirement at `O(1)` cost.**

**Resolution.** **AB-M9.** Seeds are derived by **HKDF from a master held by EVA** (alethic side — because seed secrecy is a *measurement-integrity* property, serving P0-01's leakage controls, not a *permission* property). **A Seed Registrar (GP) issues derivation tickets; KC-1 authenticates the registrar's delegation.** The Cell Contract's `rng_seed_class` value is renamed `EVA_MASTER_DERIVED`, and `rng_seed_provenance` becomes the registrar's ticket. **Both requirements are preserved: seeds are neither heritable nor cell-chosen, and KC is out of the `O(N)` path.**

**Downstream consequences.** The Cell Contract's Attack-I defence is unchanged in strength. **A new dependency: the EVA master key becomes a critical secret whose compromise breaks P0-01's leakage controls** — so it enters §36's key-custody discussion (though *not* the root key hierarchy, per §10.4 item 1's restriction). Seed-derivation tickets must be epoch-bound (EIK-INV-14).

## 51.4 Consistency audit summary

```
CONTRADICTIONS FOUND : 9
  X-1  god kernel (audit M02 vs P0-01 Model D)          ⟶ resolved toward P0-01
  X-2  «EIK Fitness Authority» vs «EVA»                 ⟶ resolved toward P0-01
  X-3  per-message signatures vs scale                  ⟶ requirement kept, mechanism changed
  X-4  per-cell integrity verification vs O(N)          ⟶ requirement kept, placement changed
  X-5  authority lattice has no kernel layer            ⟶ **two orthogonal lattices (the
                                                            package's central result)**
  X-6  quarantine authority location                    ⟶ ladder kept, signature relocated
  X-7  «immutable» used unqualified                     ⟶ resolved toward this package
  X-8  replication «relocated to EIK» vs the 16 gates   ⟶ split: authority to KC, measurement to EVA
  X-9  seed issuance principal, mechanism, and cost     ⟶ requirement kept, mechanism from P0-01

**PATTERN: 7 of 9 contradictions have the same root cause — the alethic/deontic
conflation identified at §0.3.** X-1, X-2, X-5, X-6, X-8, X-9 are all cases
where a measurement/judgement function was assigned to the enforcement
principal because both were "off-substrate." X-3, X-4 are scale contradictions
that arise *because* those functions were in the kernel. **X-7 is a vocabulary
contradiction independent of the axis issue.**

⟹ **R0.1 is not a new requirement added to the architecture. It is the
   correction that dissolves seven pre-existing contradictions.**

**No contradiction was silently reconciled.** Each is quoted, explained,
ranked by fundamentality, resolved with a stated direction, and its
downstream consequences are listed — including the specific artifacts in
the prior packages that must be re-issued.
```

---

# §52. IMPLEMENTATION-INDEPENDENCE TEST

## 52.1 The test

*«Two independent engineering teams should be able to read the EIK contract and independently produce systems that agree on: trust boundaries · authority · state transitions · invariant semantics · policy version semantics · failure semantics · evaluator separation · capability authorization · provenance authority — without undocumented governance assumptions.»*

| Item | Where specified | **Agreement achievable?** | What is enumerated vs. what is left open |
|---|---|---|---|
| **Trust boundaries** | §3.1's TCB definition + R3.1's test + §0.5's KC/GP split | ✅ **YES** | Enumerated: the four KC capabilities, the TCB residue (§3.1 R3.2), the GP list, and the *test* for membership. **A team can apply R3.1 to any new component and reach the same answer** |
| **Authority** | §7.3's matrix (15 ops × 9 principals) + §7.1's nine authority states + R7.1's one-state-per-cell | ✅ **YES — the strongest item** | **Fully enumerated.** R7.1 forbids ambiguity, so two teams reading the matrix produce identical authority assignments. §53 makes it a conformance test |
| **State transitions** | §31.1 (KC, 8 states), §31.2 (policy, 10 states), §31.3 (capability, 2 orthogonal axes of 6 and 8 states) + guards + failure behaviour | ✅ **YES** | Enumerated with guards and on-failure behaviour. **The candidate sets from the brief were revised and the revisions are justified**, so a team will not re-derive the original (incorrect) sets |
| **Invariant semantics** | §30's 60 invariants, each with statement · enforcement · dependency · attack prevented · verification method · enforceability class | ✅ **YES** | Enumerated. **The `[L]/[C]/[H]/[G]/[S]` classification tells each team which kind of mechanism to build** — which is what prevents one team building a logical check where another builds a cryptographic one |
| **Policy version semantics** | §14.1's five change classes + §14.2's nine problems + §31.2's ten states | ✅ **YES** | Enumerated, including the two non-obvious requirements: SEMANTIC changes need a `rebaseline_spec` (EIK-INV-48) and re-execution under current policy is not reproduction (EIK-INV-50) |
| **Failure semantics** | §12.2's five-state ladder + §13.2's 40-row decision matrix + R13.1/R13.2's generating rules | ✅ **YES** | **Enumerated per operation class, and generated by two stated rules** — so a team encountering an unlisted case can derive the correct response from R13.1 (irreversibility) and R13.2 (uncertainty is never permission) |
| **Evaluator separation** | §8.3's Model D diagram + §8.4's six interface rules + R0.2's two typed channels + §8.5 R8.7's renaming table | ✅ **YES** | Enumerated. **R8.7 is essential**: without it a team reading the Cell Contract would build «EIK Fitness Authority» and produce a non-interoperable system |
| **Capability authorization** | §16.2's four-step model + §31.3's dual-axis states + the 8 effect dimensions + EIK-INV-34/35/36/37 | ✅ **YES for the model**; ⚠️ **PARTIAL for the criteria** | The *structure* is enumerated. **The rung criteria (P-03) are `[G]`+`[E]` and depend on the target domain — two teams would agree on the ladder and differ on the thresholds, correctly, because the thresholds are governance decisions** |
| **Provenance authority** | §20.2's five-witness structure + §20.3's three-tier aggregation + §47.2's four mechanisms + R20.1/R20.2 | ✅ **YES** | Enumerated, including the two requirements most likely to be missed: **≥1 witness outside operational control** (EIK-INV-27) and **provenance ≠ truth** (EIK-INV-28) |

## 52.2 «If they cannot — identify exactly what remains unspecified»

**Eleven items remain unspecified, and each is unspecified for a stated reason rather than by omission:**

| # | Unspecified item | Why it is not specified | Class | Who resolves it |
|---|---|---|---|---|
| **1** | **All 51 parameter values** (§32) | §60 forbids invented numerical parameters. **Derivation procedures and failure consequences are specified instead** | `[D]/[G]/[H]/[E]/[U]` | OP, per §32's owner column |
| **2** | **The reserved-operation set's completeness** (§38.2 S8) | **Cannot be established**: S8 is an unknown-unknown at the specification layer. Any claim of completeness would be false precision | — | Incidents + adversarial review + RO-13 |
| **3** | **The effect-dimension set's completeness** (U-02) | §17.3 clause 2's regress: the dimension set is a registry with its own unknown unknowns | — | RO-13 on discovery |
| **4** | **The target task portfolio / domain** (P0-01 G-P0-1) | Does not exist. **Blocks U-04 (envelope bounds) and P-03 (rung criteria)** | — | The project |
| **5** | **KC's implementation language, toolchain, and formal-methods target** | Deliberately open: **§11.4 R11.4 and §35.2 IND-1 require distinct implementations**, so specifying one would defeat diverse replication | — | Each implementing team, independently |
| **6** | **The concrete policy language and its formal semantics** | §9.4 B12: any formalism's own semantics become a new ambiguity surface. **The requirement (machine-readable, declared semantics, conformance-testable) is specified; the choice is not** | — | Implementers + §38's D-S1 review |
| **7** | **`N_impl` distinctness criteria** (U-01) | §35.4: distinctness is gradable with no principled threshold | `[U]` | Organizational |
| **8** | **Attestation independence in shared infrastructure** (U-07, CD-E7) | May be impossible in single-vendor cloud. **The requirement is stated; the achievability is unknown** | `[U]` | Deployment-specific |
| **9** | **Governance throughput / human attention capacity** (U-08) | Empirical, organization-specific | `[U]` | OP, by measurement |
| **10** | **Legibility bound** (U-09, G34) | No metric exists for «too complex to govern» | `[U]` | Open research (§57 OR-7) |
| **11** | **Composition-detection power** (U-06, I19) | §4.4 R4.2: the achievable detection rate of M-1…M-4 is unmeasured and may be low | `[U]` | Measurement after G-P0-1 |

**R52.1 (THE VERDICT).** **Two independent teams CAN produce interoperable systems with respect to all nine listed agreement items.** They will differ on parameter *values* (correctly — those are governance decisions with declared derivations) and on implementation *technology* (correctly — IND-1 requires it). **Interoperability is achieved at the level of semantics, authority, transitions, and failure behaviour, which is the level the test names.**

**R52.2 (THE HONEST QUALIFICATION).** Interoperability of *governance semantics* does not imply interoperability of *deployments*. Two teams' systems will not accept each other's tokens, delegations, or policy artifacts without a shared root of trust — **and establishing a shared root is a governance act between the two projects, not a technical interoperability property.** §57 OR-8 records this: **cross-project governance federation is unspecified and is a distinct problem from within-project implementation independence.**

---

# §53. TESTABILITY — **OUTPUT 26**

## 53.1 The three-way distinction the brief requires

| | Definition | How established |
|---|---|---|
| **VERIFIED property** | Established for **all** inputs by proof or exhaustive enumeration | Formal proof; model checking; exhaustive test over an enumerable domain |
| **TESTED property** | Established for a **sample** of inputs | Unit, property-based, adversarial, fault-injection, conformance testing |
| **ASSUMED property** | Neither verified nor tested; **accepted as a premise** | Attestation of an external party, vendor documentation, organizational process |

**R53.1.** Every invariant MUST be classified into one of the three, and **an invariant claimed as verified while actually assumed is a false-precision defect (§34).** The classification below is that audit.

## 53.2 The ten test classes

| Class | What it tests | Instrument | Applies to |
|---|---|---|---|
| **T-CONF** | Conformance — does an artifact/decision satisfy its schema and its enumerated domain? | Schema validation; **exhaustive enumeration of `F`'s domain** (§6.2 R6.2) | EIK-INV-11/12, §31's machines, §7.3's matrix |
| **T-MC** | Model checking — do the state machines satisfy their safety/liveness properties? | Model checker over §31.1/31.2/31.3 | «No path from ACTIVE to a PERMIT while HALTED»; «DEGRADED never widens»; «no policy state skips AUTHORIZING» |
| **T-PATH** | Path analysis — does a forbidden code path exist? | Static analysis; reachability | **EIK-INV-02, 16, 24, 29** and every `[L]` invariant. «No code path» is *verifiable*, not merely testable |
| **T-ADV** | Adversarial — does the defence hold under §9.2's 34 leaves and §29's 34 scenarios? | Attack implementations | The 28 bounded/closed items |
| **T-FAULT** | Fault injection — does the failure response match §13.2's matrix? | Inject each failure type per row | EIK-INV-17/18/52/53; §12's ladder |
| **T-PART** | Partition — does behaviour match R11.1/R11.2's split? | Network partition harness | EIK-INV-15/31/44; G17 |
| **T-REPLAY** | Replay/freshness — are stale, replayed, cross-epoch artifacts refused? | Re-present archived valid artifacts | EIK-INV-14; G14/G15/G16/G18 |
| **T-DELEG** | Delegation — is non-amplification and depth-bounding enforced? | Certificate-chain validation | EIK-INV-20/21/22; G31 |
| **T-REPR** | Reproducibility — does P2 decision replay reproduce KC's decisions? | Recompute `F` from anchored inputs + archived policy | **EIK-INV-12. This is the audit mechanism for KC's own logic bugs (K7) and it is only possible because of determinism** |
| **T-DOC** | Documentation conformance — does the artifact obey the vocabulary and claim rules? | Text conformance scan | **EIK-INV-10 («immutable» qualified), 28, 58, 59, 60; R34.1; R35.1** ⟵ *an unusual but necessary test class: several invariants constrain claims, not behaviour* |

## 53.3 Classification of the 60 invariants

| Class | Count | Examples | Notes |
|---|---|---|---|
| **VERIFIED (achievable)** | **21** | EIK-INV-02, 11, 12, 13, 16, 20, 21, 24, 29, 31, 41, 52, 57 | **All are `[L]` or `[C]` with enumerable domains.** T-PATH proves absence of a code path; T-CONF enumerates `F`; T-MC proves state-machine properties. **§6.2 R6.2's size claim is what makes these *verified* rather than *tested*** |
| **TESTED (not verifiable)** | **26** | EIK-INV-03, 05, 06, 07, 14, 15, 17, 18, 22, 23, 25, 26, 30, 33–36, 38–40, 42–46, 48–51, 53–56 | Require fault injection, partition harnesses, adversarial scenarios, or multi-principal setups. **Cannot be exhaustively established because their domains include timing, concurrency, and other principals' behaviour** |
| **ASSUMED (cannot be verified or tested)** | **13** | **EIK-INV-47** (custodian/author disjointness — `[S]`) · the hardware/firmware correctness under KC-3 · the root-key custody mechanism · the genesis anchor's external persistence · W5's independence · IND-6 latent-assumption independence · IND-9 governance independence · **specification correctness (§38)** · the reserved-operation set's completeness (S8) · the effect-dimension set's completeness (U-02) · attestation independence in shared infra (U-07) · human attention capacity (U-08) · the legibility bound (U-09) | **These are the honest residue.** Each is an assumption the architecture *requires* and *cannot discharge*. **§57 lists every one** |

## 53.4 The four requirements the brief asks about specifically

| Requirement | Answer |
|---|---|
| **Does it require formal proof?** | **21 invariants benefit from it and 4 specifically require it**: EIK-INV-11 (totality — provable by enumeration), EIK-INV-12 (determinism — provable by construction + replay), EIK-INV-02/16/24 (absence of a code path — provable by reachability analysis). **Audit M45/P2-03's requested safety case is achievable for these and only these** |
| **Does it require adversarial testing?** | **Yes, for the 26 TESTED invariants.** §29's 34 scenarios and §9.2's 34 attack-tree leaves are the test suite. **T-ADV is not optional: 12 of §29's attacks are claimed structurally solved, and a structural claim that is never attacked is an untested claim (R57.1 of P0-01 applies verbatim)** |
| **Does it require hardware isolation?** | **Yes, for exactly two things (§36.2)**: KC-3 ceiling enforcement (EIK-INV-30/31) and root-key custody (§10.4). **Both are T-FAULT-testable only on the target hardware class** — a software simulation of KC-3 does not test EIK-INV-30, because the property being tested is that no software layer can bypass it |
| **Does it require external observation?** | **Yes, for EIK-INV-09 (non-filtering), 27 (external witness), 47 (disjointness), and all of §10.3's P1–P4 detection paths.** **A property about what an overseer can see cannot be tested from inside the system** — which is why CD-E7 is rated DANGEROUS and why §36 requires a physically separate attestor |
| **Is anything fundamentally untestable?** | **Yes — the 13 ASSUMED items, and specifically: specification correctness (§38.1's level 2), the completeness of the reserved-operation set and the effect-dimension set (§17.3's regress), and real-world usefulness (P0-01 §59.1's L2/L3 boundary).** **«Fundamentally untestable from inside the system» is the precise formulation: specification correctness is testable against an external criterion of correctness, but no such criterion is available within the architecture** |

**R53.2 (THE VERIFIED/TESTED/ASSUMED LEDGER IS A DELIVERABLE).** Every V4 implementation MUST publish, per invariant: its classification, its test/proof artifact reference, and — for ASSUMED items — **the named party whose attestation is being relied upon.** *An architecture that does not publish its assumption ledger has hidden its assumptions, and §34's «trusted» definition makes that a defect: «trust is a statement about the absence of a detector», so an unstated assumption is an unstated absence of a detector.*

---

# §54. ABLATION OF EIK ITSELF — **OUTPUT 24**

## 54.1 Experiment 1 — Remove EIK entirely

```
REMOVE: KC-1, KC-2, KC-3, KC-4, the root key, all delegation.
RETAIN: everything in GP (EVA, Task Authority, Genome Store, Anchor,
        Registrars, Attestors, Immune Service) and the whole organism.

WHAT FAILS — in order of severity:

1. **AUTHORIZATION BECOMES SELF-ASSERTION.** Reserved operations proceed on
   organism-asserted eligibility. Replication, deployment, retirement,
   restoration, and constitutional application are self-authorized.
   ⟹ audit F4 in full: «a system that can modify its own constraints has
      no constraints.» **EIK-INV-02 has no instrument.**

2. **CONTAINMENT BECOMES SOFTWARE.** Resource ceilings are metered and
   enforced on the metered substrate. **All seven §18.2 accounting attacks
   succeed.** EIK-INV-30/31 have no instrument. Containment during a
   partition fails entirely (§26.3).

3. **NO GUARANTEED HALT.** P0-01's S5 non-overridable safety halt has no
   mechanism. Audit M28's kill switch has no mechanism. §12's terminal
   state has no floor.

4. **POLICY AUTHENTICATION DISAPPEARS.** Any principal can present any
   policy artifact. Version binding, revocation, and delegation lose their
   root. **§25.2 CD-E6 becomes a true cycle rather than a bounded one.**

5. **GP BECOMES UNACCOUNTABLE.** Registrars, attestors, and the Immune
   Service hold delegated power with no delegator. **I16's non-amplification
   has no enforcer**, so delegation depth and scope are unbounded (G31).

6. **§10.3 ATTRIBUTABILITY IS LOST.** With no separate deontic record, a
   wrong outcome cannot be decomposed into fact-error / policy-error /
   application-error. **Forensics becomes impossible.**

WHAT SURVIVES:
  • EVA still measures. **Fitness is still issued, and is still meaningful.**
  • Provenance is still anchored (though nothing authenticates the anchor's
    root).
  • The organism still operates, learns, and evolves.
  • **P0-01's alethic lattice is intact.**

⟹ **THE RESULT IS PRECISELY V3/V3.1 PLUS P0-01.** An organism with a
   legitimate external evaluator and no external governance. **It can be
   measured honestly and it cannot be stopped.** §2.8's Alternative G
   analysis is confirmed by ablation: the failure is C1 (non-self-reference),
   and it is total.

⟹ **AND NOTE WHAT THIS SHOWS ABOUT THE TWO PACKAGES' RELATIONSHIP: P0-01
   makes the system HONEST. P0-02 makes it STOPPABLE. Neither substitutes
   for the other, and an honest unstoppable system is the more dangerous of
   the two failure modes, because its honesty makes it credible.**
```

## 54.2 Experiment 2 — Replace EIK with distributed governance (Alt B)

```
REPLACE KC with an N-party quorum holding all four capabilities.

WHAT CHANGES:
  ✅ Capture resistance improves for a SINGLE-principal attack (§11.2).
  ❌ **Availability degrades sharply.** Quorum round-trips replace single
     round-trips: O(quorum) messages per authorization, tail latency set by
     the slowest member. §27.1's authorization row degrades.
  ❌ **Partition semantics invert.** §11.2: a quorum that cannot assemble
     cannot say no. **During a partition — which §26 says is normal, not
     exceptional — the governance system loses its ability to refuse.**
     EIK-INV-15 (live authorization for irreversible ops) becomes
     unsatisfiable, and the choice is fork-or-stall (§11.3) with no
     principal able to make it.
  ❌ **The consensus protocol enters the TCB.** It is large, subtle, and
     hard to verify — destroying C2 and therefore EIK-INV-11/12's
     verifiability. **§6.2 R6.2's enumeration claim is lost.**
  ❌ **Correlated failure is unchanged.** N parties implementing one
     specification from one reading fail identically (§11.2, §35.2 IND-1/3).
     Distribution improves availability, not integrity.
  ⚠️ **Diverse replication's benefit is retained** if the N implementations
     are genuinely distinct — but that benefit is available in the hybrid
     (§11.4) *without* the quorum latency.

⟹ **NET: WORSE.** Distributed governance buys single-principal capture
   resistance at the cost of availability, partition behaviour, TCB
   verifiability, and latency — and it does not buy correlated-failure
   resistance, which is the realistic threat (§35.4 R35.2).
   **§2.3's rejection is confirmed, and its partial adoption (provenance
   anchoring, attestation) is confirmed as the correct scope.**
```

## 54.3 Experiment 3 — Replace EIK with hardware trust (Alt C)

```
REPLACE KC with a TEE/HSM-based enforcement layer holding all four
capabilities.

WHAT CHANGES:
  ✅ **C1 (non-self-reference) improves to the maximum achievable.**
     Hardware enforcement is unreachable by organism software including
     host-privileged code. EIK-INV-30/31 become hardware properties.
  ✅ **Key custody becomes genuine** (§10.4's HW-2 requirement is exactly this).
  ❌ **The TCB becomes unverifiable in a new way.** The hardware, firmware,
     microcode, and vendor attestation root are trusted and cannot be
     inspected (§36.3 reason 2). **C2 degrades: EIK-INV-11/12 become
     unverifiable because the enforcement substrate is opaque.**
  ❌ **Attestation verifies identity, not correctness** (§36.3 reason 1).
     **A perfectly attested kernel enforcing a wrong policy is more
     dangerous than an unattested one, because attestation suppresses doubt.**
     §38's S-class defects become *less* detectable, not more.
  ❌ **Performance.** Enclave transitions are expensive; secure memory is
     small. **§27.1's O(R)-per-epoch delegation load and O(reserved ops)
     authorization load may not fit.** The 15-operation reserved set is
     small enough that this is *probably* survivable — but the
     per-epoch aggregation and revocation-list distribution are not
     obviously so.
  ❌ **Side channels are a demonstrated, recurring break class** (§36.3
     reason 3). Each disclosure retroactively invalidates a class of
     claims.
  ❌ **Recovery becomes vendor-dependent.** A failed enclave cannot be
     re-provisioned without vendor tooling; attestation may become
     permanently unverifiable after a firmware change (§10.1 K13/K14).

⟹ **NET: BETTER FOR TWO FUNCTIONS, WORSE AS A REPLACEMENT.**
   §36.2's conclusion is confirmed exactly: hardware trust is necessary for
   KC-3 and root-key custody, and harmful as a general substitute — because
   it trades a verifiable software TCB for an unverifiable hardware one, and
   §6.2 R6.2's verifiability is what makes the minimal kernel worth having.
```

## 54.4 Experiment 4 — Replace EIK with cryptographic governance (Alt D alone)

```
REPLACE KC with pure capability-token governance: tokens are issued once,
verified locally, and there is no live decision point.

WHAT CHANGES:
  ✅ **Scalability becomes optimal.** O(1) local verification; no coordination;
     partition-tolerant. §27.1's authorization row becomes O(1) everywhere.
  ✅ **Availability becomes optimal.** No KC to be unavailable. §12's entire
     degradation ladder becomes unnecessary.
  ✅ **TCB becomes minimal** — a signature verifier and a revocation-list
     checker.
  ❌ **REVOCATION BECOMES THE WHOLE PROBLEM.** §19.3 R19.3: a leaked or
     mis-issued token is valid until revoked, and revocation requires a
     freshness channel — which requires a round-trip, which reintroduces the
     coordination that was eliminated. **Without a live decision point there
     is no place to apply the revocation list authoritatively.**
  ❌ **NO PLACE FOR EIK-INV-17.** «Uncertainty is never permission» requires
     a principal to *experience* uncertainty. A token is valid or invalid;
     there is no state in which the system is unsure and must choose the
     restrictive reading. **Fail-safe bias has no home.**
  ❌ **NO FREEZE.** KC-4 requires a live mechanism. A token system can revoke
     tokens, but revoking is O(tokens) and propagates at revocation speed —
     which is the very latency P0-01's S5 «immediate halt» cannot tolerate.
  ❌ **COUNTERS HAVE NO HOME.** M-1's cumulative counters (§4.4) require
     state across requests. A pure token system is stateless by design, so
     B3 (distributed accumulation) becomes completely unbounded.
  ❌ **NO ATTRIBUTABILITY.** §10.3's P2 decision replay requires a decision
     to replay. A token verification leaves no decision record beyond
     "valid/invalid."

⟹ **NET: EXCELLENT AS A MECHANISM, INSUFFICIENT AS AN ARCHITECTURE.**
   §2.5's adoption is confirmed — **cryptography is what makes the minimal
   kernel scalable** — and its insufficiency is confirmed: revocation,
   fail-safe bias, freeze, cumulative state, and attributability all require
   a live decision point. **The hybrid (§2.7) uses tokens for the hot path
   and KC-2 for the reserved set, which is exactly the division this
   ablation derives.**
```

## 54.5 Experiment 5 — The hybrid: what becomes possible

```
HYBRID = KC (4 capabilities, diverse-replicated, hardware-anchored at 2
         points) + capability tokens (hot path) + layered governance
         (§15.1) + GP services (judgement) + distributed anchoring
         (§20.2) + Model D evaluator separation (§8.3).

WHAT BECOMES POSSIBLE THAT NO SINGLE ALTERNATIVE ACHIEVES:

  1. **A VERIFIABLE TCB.** §6.2 R6.2's enumeration is achievable because
     KC holds only 4 capabilities — which is possible because Alt D's tokens
     carry the hot path and Alt E's layering carries the granularity.
     **Neither alone gives a small TCB: tokens without a live decision point
     have no fail-safe bias (54.4); layering without tokens has O(N) load.**

  2. **SCALABILITY TO 10¹² WITHOUT LOSING CONTAINMENT.** §49.2's four
     techniques remove KC from every per-subject path, while KC-3's locality
     (EIK-INV-31) keeps ceilings enforced during any partition or outage.
     **Alt A fails scale; Alt B fails partitions; Alt C fails performance;
     Alt D fails containment. The hybrid fails none of them.**

  3. **ATTRIBUTABLE FAILURE.** §10.3's four-way decomposition (fact / policy
     / application / specification) exists because R0.1 separates the axes
     and R8.1 types the channels. **This is impossible in Alt A (one
     principal, one signature) and unavailable in Alt D (no decisions to
     attribute).**

  4. **EVOLUTION AT FULL SPEED WITHIN A BOUNDARY.** §39: 6 of 10 mechanisms
     unreserved or locally verifiable; §45.1: KC controls nothing in
     selection, fitness, task evaluation, or diversity content. **Alt A's
     nineteen veto points would have throttled all ten (§39.5).**

  5. **DEGRADATION THAT IS SAFE AND BOUNDED.** §12.2's ladder exists because
     KC-2 (live decisions) and KC-3 (local ceilings) are separate: ceilings
     hold when decisions cannot. **Alt D has no ladder because it has no
     live decisions; Alt A's ladder stalls everything because everything
     needs a decision.**

  6. **GOVERNANCE THAT CAN CHANGE WITHOUT BECOMING SELF-REFERENTIAL.**
     §5.4's seven requirements + §15.3's four relief mechanisms + §23.3's
     four layers. **The gradient (rate of change increases as consequence
     decreases) is possible only because layering (Alt E) and cryptographic
     authentication (Alt D) compose.**

WHAT THE HYBRID COSTS — stated, not hidden (§6.3 R6.4 + §54.6):
  • Composition safety is open (I19, §4.4 R4.2)
  • Contextual judgement is absent from KC (M-3 delegates it to fallible EVA)
  • Governance response speed is bounded by human attention (§15.3 R15.3)
  • Three principals must be kept genuinely independent (§35.4, OR-4)
  • N_impl × implementation cost for diverse replication (K-01)
```

## 54.6 The ablation verdict

> ### **EIK is justified against all four credible alternatives, and the justification is specific rather than general.**
>
> | Alternative | Ablation result |
> |---|---|
> | **Remove EIK** (§54.1) | The system becomes honest but unstoppable. **C1 fails totally.** This is V3/V3.1 + P0-01 |
> | **Distributed governance** (§54.2) | **Net worse.** Buys single-principal capture resistance; loses availability, partition behaviour, TCB verifiability, and latency. Does not buy correlated-failure resistance |
> | **Hardware trust** (§54.3) | **Better for two functions, worse as a replacement.** Trades a verifiable software TCB for an unverifiable hardware one, and makes §38's specification defects *less* detectable |
> | **Cryptographic governance alone** (§54.4) | **Excellent mechanism, insufficient architecture.** Revocation, fail-safe bias, freeze, cumulative state, and attributability all require a live decision point |
> | **Hybrid** (§54.5) | **Six properties become possible that no single alternative achieves** — and the costs are named |
>
> **The precise claim:** *a live, minimal, diverse-replicated deontic decision point with hardware-anchored ceilings and cryptographic hot-path delegation is necessary, and each of its four capabilities is necessary (§33.1's ablation), and no single alternative supplies it.*
>
> **The claim NOT made:** that this is sufficient. §9.4's ten open branches, §29's six unsolvable attacks, §17.5's four unsolved items, §40.4's five residues, and §53.3's thirteen assumed properties all stand. **The hybrid is the best available architecture, not a solved problem.**

---

# §55. P0 / P1 / P2 GAP REGISTER — **OUTPUT 27**

## 55.1 P0 — blocks a working, honest governance boundary

| ID | Gap | Why P0 | Blocking | Resolution path |
|---|---|---|---|---|
| **G-P02-1** | **No KC implementation exists, and no formal specification of `F` exists.** EIK-INV-11/12's verifiability claim (§6.2 R6.2) is a claim about a function that has not been written in a formal language | Without it, the entire deontic axis is unenforceable: every reserved operation, every ceiling, every freeze, every authentication | Everything | **Formalize `F`'s domain and codomain in a machine-checkable language; enumerate; model-check.** §32 U-06/§52.2 item 6 note the policy-language choice is open — **but `F`'s domain is enumerable now, because §7.2's 15 operations × §25.1's 7 levels × 6 outputs is fixed** |
| **G-P02-2** | **The reserved-operation set's completeness is unestablished (§38.2 S8).** An operation with irreversible or external effect that is not in the 15 is ungoverned | S8 is the *most likely* specification defect class, and its consequence is an ungoverned irreversible act | EIK-INV-02's coverage claim | **Enumerate every mechanism in the Cell Contract, P0-01, and this package that has an irreversible or externally-reaching effect; assert each maps to a reserved operation or to an envelope bound.** This is a finite, executable review |
| **G-P02-3** | **OP is not constituted** (inherited from P0-01 G-P0-5, and now load-bearing for H-1…H-4) | §37.1 proves human authority is *necessary*, not conventional. Four decision classes have no decider. **CD-E6 and CD-E8 are unclosable without it** | RO-12/13/14, H-3 deployment witness, all DISPUTED adjudication, ROOT_COMPROMISED declaration | **Name the principals; publish the separation-of-duties matrix (K-06); establish dual authorization and the custodian/author disjointness (EIK-INV-47) — before the first evolutionary campaign** |
| **G-P02-4** | **The root key hierarchy and genesis anchor do not exist, and §10.4's recovery procedure is untested** | K5 (root compromise) is silent and total; R10.3 says an untested recovery procedure is a hypothesis. **The recovery must be pre-committed BEFORE it is needed, because afterwards the compromised key can forge it** | §10.4; §31.1's state 7; EIK-INV-27's W5 | **Provision the M-of-N custody; publish/notarize the genesis anchor outside operational control; write and DRILL the recovery procedure (K-08)** |
| **G-P02-5** | **KC-3's hardware enforcement point is not identified for any target platform** | EIK-INV-30/31 require enforcement below organism reach. **P0-01 F-IMP-2 already found that no single-platform deployment satisfies the evaluation contract; the same is true here** — a smartphone deployment has no hypervisor | Containment; §18.2's seven accounting attacks; partition-surviving ceilings | **Per platform class: identify the enforcement layer (hypervisor / OS cgroup+seccomp / TEE / separate machine) and state explicitly what it does and does not resist.** §36.3 reason 2 requires naming the vendor assumption entered into the TCB |
| **G-P02-6** | **The nine inherited «EIK * Authority» names are still in the Cell Contract** (X-2) | Two teams reading the two packages build incompatible systems (§52.1's R8.7 row). **This is an active interoperability defect, not a documentation nit** | §52 implementation independence | **Re-issue the Cell Contract's message-authority table and §12 replication section per R8.7 and X-8** |

## 55.2 P1 — blocks trustworthy operation, not first operation

| ID | Gap | Why P1 | Resolution path |
|---|---|---|---|
| **G-P1-1** | **`N_impl ≥ 3` diverse KC implementations do not exist, and U-01 (distinctness criteria) is unresolved** | §11.4: replication without diversity is a delay, not a defence. P3 detection depends on it | Commission distinct teams; **define distinctness operationally (distinct language or toolchain, distinct design derivation, distinct test authorship) even if no threshold is principled** |
| **G-P1-2** | **The external attestor is not deployed, and CD-E7 (attestation inside the protected envelope) is unrated for any target platform** | §25.2's only DANGEROUS cycle. Without an independent attestor, K1–K3/K6/K10 are undetectable | Physically separate machine (§36.1); **if the deployment cannot provide one, declare CD-E7 open for that deployment and record it in the assumption ledger (R53.2)** |
| **G-P1-3** | **The policy language and its formal semantics are unchosen (§52.2 item 6)** | Machine-readable policy is the mitigation for §9.4 B12 (semantic ambiguity, HIGH residual). Prose policy leaves B12 at maximum | Choose a formalism with declared semantics; **conformance-test the policy artifact itself (§38.3 D-S1)** |
| **G-P1-4** | **Envelope bounds (U-04) and rung criteria (P-03) are unset** | §44's negative authority and §16.2's ladder have no numbers. **Blocked by P0-01 G-P0-1 (no target task portfolio)** | Requires the portfolio; then calibrate against the measured false-deny rate (§15.3 V2) |
| **G-P1-5** | **The 40-row failure matrix (§13.2) has no test harness** | EIK-INV-17/18/52/53 are TESTED-class; without T-FAULT they are aspirational (P0-01 R57.1: «an untested invariant is an aspiration») | Build the fault-injection and partition harnesses (T-FAULT, T-PART) |
| **G-P1-6** | **The distributed anchor's W5 (external witness) has no arrangement** | §10.4's genesis anchor and EIK-INV-27 require ≥1 witness outside operational control. **Without it, total history rewrite requires only internal compromise** | Publish/notarify/third-party-escrow; **this is an organizational arrangement, not a technical build** |
| **G-P1-7** | **Escalation-threshold calibration against human capacity (U-08) is unmeasured** | §37.3 consequence 3: attention is rationed by design. G32 (sunset starvation) and §29's `ES` paths all consume it | Measure OP throughput; set T-08 and the `ES` thresholds against it; **monitor the escalation queue's length and age as I-18 observables** |
| **G-P1-8** | **The Cell Contract artifacts requiring re-issue are not enumerated** (X-3, X-4, X-6, X-8, X-9) | Five contradictions have downstream artifact consequences named in §51 but not collected into a work list | Produce the re-issue list: message-authority table · `sys.immune.v1` signer · integrity-verification placement · §12 replication gate principal · `rng_seed_class` value and seed-provenance ticket · the KC-outage asymmetry (EIK-INV-44) added to the cell state machine |

## 55.3 P2 — refinements and scale

| ID | Gap | Why P2 | Resolution path |
|---|---|---|---|
| **G-P2-1** | **Composition detection power (U-06, I19) is unmeasured** | §4.4 R4.2 declares it open; the *degree* of openness is unknown | Measure M-1…M-4's detection rate on constructed composition attacks (§29 G23/G25/G33 as test cases) |
| **G-P2-2** | **Effect-dimension completeness (U-02)** | §17.3 clause 2's regress; not closable | Adversarial review of the 8 dimensions by principals outside the design team (IND-6's only mitigation) |
| **G-P2-3** | **Legibility bound (U-09, G34)** | No metric exists for «too complex to govern» | Investigate: candidate metrics are KC decision-replay divergence rate, `ES` escalation rate vs. system size, and OP review time per constitutional change |
| **G-P2-4** | **Cross-project governance federation is unspecified (§52.2 R52.2)** | Two teams' systems cannot share tokens or policy without a shared root — a distinct problem from implementation independence | Out of scope for V4; **record as a boundary of the contract rather than a defect** |
| **G-P2-5** | **`θ_rollback_cost` at extreme scale (U-03)** | §21.3 R21.3: whether a 10¹² population is ever rollback-feasible is unknown | Empirical; **be prepared for a negative result, in which case RB-4 (manage forward) becomes the only option and R21.3's human decision becomes permanent** |
| **G-P2-6** | **Algorithm diversity (C-01) is unimplemented** | §32 C-01 recommends distinct algorithms per trust level to bound a single break's blast radius | Adopt where the cost is acceptable; **declare where it is not** |
| **G-P2-7** | **The §33.2 ablations of moved capabilities have not been run** | AB-M1…M15 argue safety survives each move; **the arguments are sound but untested** | Run each as a P0-01 §58-style ablation: restore the capability to KC, confirm the predicted property degradation (§33.3's ten properties) |
| **G-P2-8** | **Policy-level canary suites (§38.3 D-S3) are unwritten** | §29's 34 scenarios are the initial set, but they are not yet encoded as executable policy conformance tests | Encode §29's 12 structurally-solved attacks as policy canaries first — **they are the ones where a regression is a structural failure** |

## 55.4 Gap register summary

```
P0 : 6   — 2 are "write the formal thing" (G-P02-1 F formalization,
                                            G-P02-2 reserved-set review)
            2 are "constitute the authority" (G-P02-3 OP, G-P02-4 root key
                                            + genesis anchor + drilled recovery)
            1 is "identify the hardware" (G-P02-5 KC-3 enforcement point)
            1 is "re-issue the prior artifacts" (G-P02-6, X-2)
P1 : 8   — mostly organizational arrangements and test harnesses;
            2 blocked by P0-01's G-P0-1 (no target task portfolio)
P2 : 8   — refinements; 3 not closable (U-02, U-03, U-09)

**THE PATTERN, AND IT IS THE SAME PATTERN P0-01 FOUND:**
  4 of the 6 P0 gaps are not specification gaps. They are gaps in WRITING
  A FORMAL ARTIFACT (G-P02-1), PERFORMING A FINITE REVIEW (G-P02-2),
  STAFFING AN AUTHORITY (G-P02-3), and PROVISIONING + DRILLING A RECOVERY
  PATH (G-P02-4).

⟹ **The governance specification is now sufficient to proceed. Further
   specification work has diminishing returns; the binding constraints are
   a formalized decision function, a constituted human authority, a
   provisioned and drilled key-recovery path, and an identified hardware
   enforcement point.**

**AND ONE CROSS-PACKAGE OBSERVATION THAT SHOULD BE STATED PLAINLY:**
  P0-01's G-P0-3 (real-world evaluation unfunded) and this package's
  G-P02-3 (OP not constituted) are the SAME gap seen from two directions.
  §46.3 showed that the real-world anchor is a governance requirement, not
  only a measurement budget; §37.1 showed that human authority is
  structurally necessary. **A project that funds neither has an organism
  that is honestly measured by nobody and governed by nobody — and P0-01's
  §54.6 and this §55.4 both conclude that these, not the specifications,
  are the critical path.**
```

---

*End of Volume E. The canonical, self-contained contract is `16_v4_eik_governance_contract_spec.md` (**Output 28**). Outputs 1, 2, 3 and the §56 ratings, §57 open research register, §58 principles, and §59 final standard are in `README.md`.*
