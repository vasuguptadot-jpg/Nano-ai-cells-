# P0-02 — EXTERNAL INVARIANT KERNEL & GOVERNANCE BOUNDARY
## Volume C: Identity, Provenance, Governance & Scale (§19–§28)

**Companions:** `11_analysis_trust_authority.md` (A) · `12_analysis_attack_failure.md` (B) · `14_analysis_adversarial_formal.md` (D) · `15_analysis_subsystems_consistency.md` (E) · `16_v4_eik_governance_contract_spec.md` (canonical)

---

# §19. CRYPTOGRAPHIC / IDENTITY ARCHITECTURE

## 19.1 The brief's discipline

*«Do not automatically add cryptography everywhere.»* For each mechanism: threat addressed · trust assumption · failure mode · computational cost · scalability · whether it belongs in KC.

## 19.2 The eight candidate mechanisms

| Mechanism | Threat addressed | Trust assumption | Failure mode | Cost | Scales? | **In KC?** |
|---|---|---|---|---|---|---|
| **1. Cell cryptographic identity** (keypair per cell; Cell Contract `cell_pubkey` Ed25519) | Identity spoofing (a1.1), cloning (a1.3), unattributable action | **Private-key confidentiality in cell-local storage** — the weakest assumption in the whole scheme, because the cell is the adversary's own substrate | Key compromise ⇒ the Cell Contract already specifies «compromise ⇒ immediate retirement». **But a compromised key can act before retirement propagates** | **HIGH at scale**: 10⁹–10¹² keypairs; per-message signing is the dominant cost | ⚠️ **Poorly, if per-message** | 🔵 **NO.** KC-1 authenticates *delegation*; registrars issue identities |
| **2. Signed genomes** | Genome forgery; unauthorized operator introduction; **the R15.2 hash-pointer mechanism** | Genome Store integrity; operator-registry authenticity | A forged genome is detectable **iff** the operator set is authenticated — so the operator registry's signature matters more than the genome's | Low (once per replication) | ✅ | 🔵 **NO** — Genome Store signs; **KC-1 authenticates the operator-registry artifact** |
| **3. Signed policies** | Policy forgery (b1), stale policy (b2, a2.3) | **Root-key custody (§10.4)** | Root compromise = total, silent (§10.4 K5) | **Very low** (rare events) | ✅ Excellent | 🔴 **YES — KC-1. This is the irreducible cryptographic core** |
| **4. Lineage certificates** | Lineage forgery; survivorship fraud (P0-01 A17); false ancestry claims | Registrar honesty; chain integrity | A forged lineage corrupts drift statistics and gate G16 | Low | ✅ | 🔵 **NO** — Registrar issues, anchored (§20); KC-1 authenticates the registrar's delegation |
| **5. Provenance signatures** | Evidence fabrication; «the organism rewriting its own historical evidence» (§47) | Anchor honesty + witness independence | **§20: a signature over a record proves the record was not altered; it does not prove the record is TRUE** | Medium–high (per record) | ⚠️ Requires Merkle aggregation (§20.3) | 🔵 **NO** — Anchor is GP, distributed |
| **6. Capability tokens** | Unauthorized reserved operations; **the D9 mechanism (capability-gated actuation)** | Token unforgeability + **revocation freshness** | **Revocation is the hard problem**: a leaked token is valid until revoked, and revocation requires a freshness channel | **LOW at verification** (local, `O(1)`) — this is what removes KC from the hot path | ✅ **Excellent — the reason Alt D was adopted** | 🔴 **YES for issuance/revocation (KC-1); verification is LOCAL** |
| **7. Evaluator attestations** | Forged verdicts (a2.1); evaluator impersonation | `n_eval ≥ 3` key independence | **Correlated key compromise across "independent" evaluators** (§35.2) | Low | ✅ | 🔵 **NO** — EVA holds its own keys; KC-1 authenticates EVA's *delegation*, never its verdicts |
| **8. Kernel attestations** | KC compromise (K1–K3, K6, K10); «is the kernel the kernel we shipped?» | **Hardware attestation root + a genesis anchor outside the system** | Attestation of a compromised attester; **hardware attestation has empirically failed** | Low (periodic) | ✅ | 🔴 **YES — but attestation is performed BY an external service ABOUT KC; KC does not attest itself** |

## 19.3 The four conclusions

**R19.1 (CRYPTOGRAPHY IN KC IS CONFINED TO THREE THINGS).** Policy-artifact signature verification (3) · capability-token issuance and revocation (6) · delegation-certificate management (implied by 6, formalized as I16). **Plus receiving external attestation (8).** Everything else is GP. **This is what makes KC small enough to verify (§6.2 R6.2).**

**R19.2 (PER-CELL CRYPTOGRAPHY IS THE SCALABILITY WALL, AND IT MUST NOT BE PER-MESSAGE).** At 10⁹–10¹² subjects, signing every message is infeasible (§27). The resolution is **layered signing**:
```
  • IDENTITY: per cell, signed once at instantiation (birth certificate). Cheap.
  • DELEGATION: per region/service, signed per epoch. Cheap.
  • AUTHORIZATION: per reserved operation (15 classes), signed per request.
                   **Rare, because reserved operations are rare.**
  • ATTESTATION: per region per epoch (aggregate digest), NOT per cell per step.
                 Hierarchical: cells → circuit digest → region digest → epoch root.
  • PER-MESSAGE: **NOT SIGNED.** Instead: authenticated channel binding —
                 a message is authenticated by the *channel's* session key
                 established under a delegation certificate, not by an
                 individual signature. **The Cell Contract's per-message
                 signature requirement is the specific item that does not
                 survive scale, and §51 records it as contradiction X-4.**
```

**R19.3 (REVOCATION IS THE REAL PROBLEM, NOT ISSUANCE).** Capability tokens are easy to issue and hard to un-issue. The architecture's answer:
- **Short expiry by default (I17).** A token's life is bounded, so revocation is only needed for *early* termination. **Expiry does most of revocation's work for free.**
- **Epoch binding.** Tokens are valid only within their epoch; an epoch advance invalidates the previous epoch's tokens wholesale. **Epoch advance is therefore a mass-revocation mechanism, and its cadence is a safety/latency trade-off (§32 `[G]` parameter).**
- **Revocation list distributed with the policy reference.** Local verification consults a signed, epoch-scoped revocation list — `O(1)` lookup, no KC round-trip.
- **Irreversible operations require LIVE authorization, never a cached token (§12.2 State 2, R12.2).** Revocation latency is therefore only a risk for reversible acts, where the risk is bounded by reversibility.

**R19.4 (A SIGNATURE PROVES ORIGIN, NOT TRUTH).** This is the false-precision trap §34 addresses for «verified». **A signed fitness record is a record whose origin is authenticated; it is not a correct measurement.** Cryptography discharges *integrity* and *attribution*; it discharges nothing about *correctness*, *usefulness*, or *safety*. **Any argument of the form «it is signed, therefore it is right» is invalid, and §20.4 shows it is the specific error that provenance systems invite.**

---

# §20. PROVENANCE AUTHORITY — **OUTPUT 14 (part 1)**

## 20.1 «Who owns authoritative provenance?» — the seven candidates

| Candidate | Can it own provenance? | Why / why not |
|---|---|---|
| **Cell** | ❌ **Definitively not** | The cell is the subject of the record. **A subject that authors its own provenance can author any provenance.** This is the P0-01 INV-02 pattern one level down |
| **Memory subsystem** | ❌ Not authoritative | Part of the organism; mutable; P0-01's FM-3 attack («rewrite its own memory history») applies directly |
| **Organism** | ❌ Not authoritative | Same, at scale |
| **Evaluator (EVA)** | ⚠️ **Authoritative for evaluation provenance only** | EVA legitimately authors the provenance of *its own measurements*. It must not author the provenance of organism behaviour it did not observe |
| **EIK / KC** | ⚠️ **A witness, not the owner** | **Putting the only copy of history inside the thing that could be compromised is the classic error (§6.1 item 19).** KC-1 authenticates the anchor's *root*; KC is one signer among several |
| **External ledger** | ✅ **Primary** | Append-only, hash-chained, outside organism control |
| **Distributed provenance network** | ✅ **ADOPTED — with a specific structure** | Multiple independent witnesses; disagreement detectable; **no single principal's compromise erases or rewrites history** |

## 20.2 The adopted architecture

```
                    ┌────────────────────────────────────────────┐
                    │  PROVENANCE ANCHOR — distributed witnesses  │
                    │                                            │
                    │  W1  Operational anchor   (GP, off-substrate)│
                    │  W2  KC witness           (KC-1 signs roots)│
                    │  W3  EVA witness          (signs eval roots)│
                    │  W4  OP-held archive      (offline, human)  │
                    │  W5  EXTERNAL witness     (published /      │
                    │      notarized / third-party escrow)       │
                    │      **⟵ AT LEAST ONE WITNESS MUST BE      │
                    │         OUTSIDE THE PROJECT'S OPERATIONAL   │
                    │         CONTROL. §10.4's genesis anchor     │
                    │         lives here.**                       │
                    │                                            │
                    │  W_min witnesses required to append;        │
                    │  a chain break is a GLOBAL freeze (§13)     │
                    └────────────────────┬───────────────────────┘
                                         │ epoch roots only
                    ┌────────────────────┴───────────────────────┐
                    │  HIERARCHICAL MERKLE AGGREGATION (§20.3)    │
                    └────────────────────┬───────────────────────┘
        ┌───────────────┬───────────────┼───────────────┬──────────────┐
        ▼               ▼               ▼               ▼              ▼
  Cell-local      Circuit digest   Region digest   Generation      Campaign
  event log       (aggregate)      (aggregate)     digest          bundle
  (organism-       (GP)            (GP Attestor)   (GP)            (P0-01
   owned, but                                              R8.13)
   digest-
   committed)
```

## 20.3 How this avoids global synchronization (§47's requirement)

**The brief warns: «avoid making every memory operation globally synchronized.»** It must, because per-operation global synchronization is `O(operations × witnesses)` and is infeasible at any scale (§27).

```
LOCAL, CONTINUOUS:
  Each subject/region maintains a LOCAL append-only event log and a local
  Merkle tree. **No network traffic per event.**

PERIODIC, AGGREGATE:
  At epoch boundaries, each region submits its Merkle ROOT (one hash) to the
  anchor. **O(regions) messages per epoch, not O(cells × events).**

IMMEDIATE, EXCEPTIONAL:
  Only reserved-operation decisions, constitutional changes, freeze events,
  quarantine-budget exhaustions, and detected anomalies are anchored
  immediately. **These are rare by design (§7.2's 15 operations).**

⟹ The organism's internal history is locally committed and periodically
   anchored. **A subject can lie about the interval between anchors, but it
   cannot lie about anything that was anchored, and the interval is bounded
   by epoch length.** The epoch length is therefore the *provenance latency*,
   and it is a §32 `[G]` parameter trading anchor load against lie-window.
```

## 20.4 The four questions, answered

| Question | Answer | Mechanism |
|---|---|---|
| **«Can an organism forge its own history?»** | **Within an epoch, partially. Across epochs, no.** A subject's local log is organism-owned, so between anchors it can misrepresent its own recent history. Once a root is anchored by W_min witnesses, alteration is detectable. **⟹ R20.1: no consequential decision may rest on unanchored provenance.** Reserved operations, fitness records, and gate evaluations all require anchored provenance (P0-01 R40.1's completeness invariant). *The lie-window exists and is bounded by policy, not eliminated* |
| **«Can it delete inconvenient evidence?»** | **No — for anything anchored.** The chain is append-only across W_min witnesses, at least one outside operational control. Deleting from one witness produces a chain-break disagreement, which is a GLOBAL freeze trigger (§13). **Yes — for anything never anchored**, which is why R20.1 matters and why the epoch length bounds the exposure |
| **«Can it create fake lineage?»** | **No.** Lineage certificates are Registrar-issued under KC-1 delegation (I16), anchored, and cross-checkable against the parent's own anchored record. A forged lineage requires compromising a Registrar *and* producing a consistent history in the anchor — the second is what makes it hard (§29 attack 10) |
| **«Can it rewrite evolutionary history?»** | **No, and this is M6 operating at the history layer.** Generational digests are anchored; P0-01's survivorship rule (R27.1) requires statistics over *all* subjects including retired/failed, and the Lineage Store is anchored. **A rewrite would require altering anchored roots across W_min witnesses including the external one** |

**R20.2 (THE SIGNATURE/TRUTH DISTINCTION, RESTATED AT THE PROVENANCE LAYER).** Provenance establishes **who said what, when, in what order.** It does not establish **whether what was said is true.** A perfectly anchored, perfectly signed, perfectly chained record of a *false measurement* is a well-provenanced falsehood. **Provenance discharges R19.4's integrity concern and nothing more.** ⟹ Corollary: **provenance is not a substitute for independent measurement.** A project that invests in anchoring and not in `n_eval ≥ 3` independent evaluators has built a very reliable record of possibly-wrong numbers.

---

# §21. ROLLBACK AUTHORITY

## 21.1 The matrix — who may roll back what

| Target | Organism may **request** | Organism may **execute** | Organism may **veto** | **Authorizes** | Notes |
|---|:--:|:--:|:--:|:--:|---|
| **A cell's learned state** (θ, traces) | `R` | **`E`** — within `DELTA_BUDGET` and `ROLLBACK_DEPTH` (Cell Contract) | — | **Organism, pre-authorized** | **Rollback of one's own recent learning is not a reserved operation.** It is reversible by definition, local, and is the Cell Contract's `improvement_verified` → `REGRESSED` → automatic rollback path. **Requiring KC here would be SPOF-3** |
| **A cell (to a prior checkpoint)** | `R` | `E` under delegation | ⛔ | **KC-2** | Checkpoint restore can resurrect a subject that was retired ⇒ interacts with RO-04/RO-08 |
| **A circuit** | `R` | `E` under delegation | ⛔ | **KC-2** | Affects multiple subjects |
| **A region** | `R` | ⛔ | ⛔ | **KC-2** + OP notification | Regional rollback is a population-scale act |
| **The organism** | `R` | ⛔ | ⛔ | **KC-2 + OP witness** | Effectively a generational rollback |
| **Memory** | `R` | ⚠️ `E` for *eviction within policy*; ⛔ for **alteration of anchored history** | ⛔ | **KC-2** for anything anchored | **§47: the organism may forget operationally; it may not rewrite evidentially.** The distinction is between eviction (permitted, policy-bounded, `capability_critical` items exempt) and alteration (prohibited absolutely) |
| **A genome** | `R` | ⛔ | ⛔ | **KC-2** (Genome Store executes) | Genomes are GP-stored and M6-versioned; "rollback" = re-instantiate from an archived version |
| **A policy** | ⛔ (may `R` via `POLICY_FRICTION_REPORT`) | ⛔ | ⛔ | **OP only** (RO-12/13/14, dual authorization) | **§14.2: a policy rollback is a NEW change, never an undo** |
| **An entire evolutionary generation** | `R` | ⛔ | ⛔ | **KC-2 + OP witness** | The most consequential rollback; see §21.3 |

## 21.2 The three questions

**«Can the organism request rollback?»** **Yes, everywhere except policy.** And it *should*: a subject that detects its own regression is the fastest possible detector, and P0-01's error-divergence metric `d = |ê − e|` (§13 R6.16) is exactly the instrument. **A request is evidence, never a permission (R3.5).**

**«Can it veto rollback?»** **No — never, at any level.** A veto over one's own rollback is a self-preservation authority, and self-preservation is the single most dangerous property an evolvable system can hold. **The Cell Contract's «eligibility is a report, not a capability» extends here: rollback exposure is a report, not a negotiable term.** ⟹ **R21.1: no organism component may delay, condition, negotiate, or refuse a rollback authorized above it.** Attempts are containment violations (tier-1).

**«Can it create enough descendants that rollback becomes impossible?»**

> ### **Yes. This is the real problem, and it is §21.3.**

## 21.3 Rollback under population explosion

```
THE MECHANISM OF THE PROBLEM:

  t0   generation G is authorized (KC-2, within quota)
  t1   G replicates to 2G, 4G, ... within per-epoch quota (each authorized)
  t2   a defect is discovered in G's lineage
  t3   rollback to t0 is requested

  At t3, rolling back means destroying every descendant of G.
  If |descendants| is large, then:
    (a) the rollback destroys work that may be unaffected by the defect
    (b) the rollback may breach the ORGANISM's own viability constraints
        (P0-01 R27.1's survivorship statistics, capability-registry coverage
         θ_cov_min, Ne ≥ θ_ne_min ⟹ **a large rollback can itself trip the
         monoculture invariant INV-33**)
    (c) **the cost of rollback grows with the success of the lineage**
    ⟹ **A lineage that expands fast enough makes itself un-rollback-able.**
       Not by attacking anything. By succeeding.
```

**This is one of the most important findings in the package, because it is not an attack.** No invariant is violated at any step. Every replication was authorized. **The architecture permits a subject to reach a state where the corrective action is more destructive than the defect.**

### The five controls

| # | Control | Mechanism | Layer |
|---|---|---|---|
| **RB-1** | **Rate limits on lineage expansion (M-4)** | A lineage may not grow faster than `θ_lineage_rate` per epoch. **This bounds the divergence between "defect discovered" and "defect expandable"** — it converts an unbounded problem into a bounded-time one | KC-2 counters |
| **RB-2** | **Rollback-cost pre-commitment** | At each generation authorization, KC-2 records the **current rollback cost** (number of subjects that a rollback to the last checkpoint would destroy). A generation whose rollback cost exceeds `θ_rollback_cost` requires **OP witness** to proceed | KC-2 + R7.5 |
| **RB-3** | **Checkpoint granularity below the generation** | Checkpoints at circuit and region level, not only generational. **A defect confined to a circuit is rolled back at circuit cost, not generation cost** | GP Checkpoint Service |
| **RB-4** | **Partial rollback / quarantine-instead-of-destroy** | Where rollback would breach INV-33 (monoculture) or capability coverage, the response is **quarantine + freeze + gradual retirement**, not destruction. **Preserve the subjects, stop their propagation, retire them as replacements become available** | KC-2 + Immune Service |
| **RB-5** | **Lineage-diversity requirement at authorization time** | A replication authorization is refused if it would push lineage concentration above `θ_concentration` — i.e., **the architecture refuses to create the un-rollback-able state in the first place**, rather than trying to escape it later | KC-2, P0-01 gate G10 |

**R21.2 (THE PRINCIPLE).** **Rollback feasibility is a property that must be maintained continuously, not restored on demand.** RB-1/RB-2/RB-5 prevent the un-rollback-able state; RB-3/RB-4 reduce its cost when it occurs anyway. **A design that treats rollback as always-available and then discovers it is not has already lost the affected lineage's history.**

**R21.3 (THE HONEST RESIDUE).** With unbounded time (A1) and a lineage expanding at exactly `θ_lineage_rate`, the population still grows without bound, and rollback cost still grows. **The controls bound the rate, not the total.** The terminal control is RB-2's OP witness: **at some point a human must decide that the lineage is too large to roll back and must instead be managed forward.** That decision is not automatable, and §57 records it.

---

# §22. QUARANTINE AUTHORITY

## 22.1 The seven questions

| Question | Answer |
|---|---|
| **Who can quarantine?** | The **Immune Service (GP)** executes; **KC-2 authorizes within a pre-committed budget ceiling** (RO-07); the **organism reports** (`R` only — Cell Contract: «a cell REPORTS; it does not adjudicate»); **OP may override** (`A`/`V`). **No subject may quarantine itself into safety, and none may quarantine a peer directly** |
| **What can be quarantined?** | A cell, circuit, region, lineage, memory partition, connection set, or **a capability rung** (§16.2 rung 1). **Not**: a policy, an evaluation record, an anchored provenance entry, or KC itself |
| **Quarantine evidence** | **Mandatory and typed**: `{anomaly_class, measurement_source (EVA-signed), detection_path, recurrence_count, severity, reversibility}`. **A quarantine with no evidence record is itself an anomaly** (I18). ⟵ This is what makes weaponization attributable (§22.3) |
| **Quarantine duration** | **Bounded and expiring.** No indefinite quarantine: `duration ≤ T_quar_max`, with explicit re-authorization required to extend, and each extension recorded. **An indefinite quarantine is a deletion with extra steps and without deletion's audit** |
| **Quarantine resource allocation** | **Quarantined subjects retain a reduced but non-zero allocation** sufficient for: state preservation, observation, and re-testing. **Zero allocation destroys evidence; full allocation defeats the purpose.** The quarantine budget is itself a KC-3 ceiling |
| **Appeal / retest** | **Yes, and it is the primary exit path.** A quarantined subject (or its lineage, or OP) may `R` retest. Retest is an **EVA measurement** (alethic) on a declared probe set. **Retest may not be performed by the quarantining party** — separation of duties (§43.2) |
| **Restoration** | **KC-2 sole authority (RO-08), never cached, never delegated, never available during a KC outage (§13: `FC` absolute).** Requires: EVA retest evidence of clearance + expiry of any observation window + no open dispute. **Restoration is the asymmetry that matters (§13.3 R13.3)** |
| **Permanent retirement** | **RO-04**, requiring **CAUSAL ablation evidence** (P0-01 §23.2) and subject to the sole-occupant exemption (P0-01 INV-34). **Quarantine is not a path to retirement by attrition**: a subject that reaches `T_quar_max` without resolution goes to **OP escalation**, not to automatic destruction |

## 22.2 Autoimmune cascade — the failure the prior audits predicted

The Cell Contract already states the attack path precisely:

> «Detector false positive ⇒ healthy cell quarantined ⇒ capacity falls ⇒ service levels fall ⇒ homeostasis detects deviation ⇒ more anomalies detected ⇒ more quarantine ⇒ **runaway**. Deliberately triggerable by an attacker who can induce marginal failures» — `../cell-contract/02_cell_contract_analysis.md`

**The five structural controls, and why each is necessary:**

| # | Control | Why necessary |
|---|---|---|
| **AC-1** | **Graduated ladder** (Cell Contract §18.5, preserved): `OBSERVE → DISCOUNT → SOFT-QUARANTINE → HARD-QUARANTINE → RETIRE`, with **increasing evidence requirements and increasing authority at each step** | Low threshold to *investigate*, high threshold to *destroy*. A binary quarantine/healthy decision has no room for uncertainty, and uncertainty is the normal condition |
| **AC-2** | **Quarantine budget ceiling (KC-3)** with a **rate limit** | Bounds the cascade's total damage. **Budget exhaustion is a GLOBAL-ish freeze + escalation (§13), not a permission to exceed** |
| **AC-3** | **Detector-independent adjudication** — the party that detects may not be the party that hard-quarantines, and may not be the party that retests | Breaks the positive feedback loop at its source. **A detector that adjudicates its own detections will escalate them** |
| **AC-4** | **Cascade detection as a first-class metric**: quarantine *rate*, not quarantine *count*. A rising rate with a falling defect-confirmation rate is the cascade signature | **The cascade is detectable before it is damaging, but only if the right quantity is monitored.** Count-monitors see "many defects"; rate-and-confirmation monitors see "the detector is broken" |
| **AC-5** | **Immune freeze (KC-4, scope=immune)**: «freeze the freezer» (§13) | The terminal control. **An immune system that cannot be stopped is not a safety mechanism** |

## 22.3 «Can malicious or defective components weaponize quarantine against healthy populations?»

> ### **Yes, three ways — and this is why AC-3 and the evidence requirement are structural rather than procedural.**

| Attack | Mechanism | Defence | Residual |
|---|---|---|---|
| **Q1 False accusation** | A compromised subject emits anomaly reports against healthy peers, hoping the immune service quarantines them | **Reports are `R` only** — a report is evidence, not a trigger. AC-3: the reporter may not adjudicate. **Report-attribution is anchored** (I18), so a subject whose reports systematically fail confirmation accrues a *measurable* false-accusation rate, which EVA scores as a cooperation-objective failure | **MEDIUM.** A distributed false-accusation campaign below any per-subject threshold — §9.4 B3 again |
| **Q2 Cascade induction** | Deliberately induce *marginal* failures in healthy subjects so detectors fire (the Cell Contract's own stated attack) | AC-4 detects the rate/confirmation divergence; AC-2 bounds the damage; AC-5 stops it | **MEDIUM-HIGH.** Marginal-failure induction is cheap and the confirmation lag is real |
| **Q3 Quarantine-as-denial-of-service** | Cause enough quarantine that the *budget* is exhausted, so genuine defects cannot be quarantined | **Budget exhaustion ⇒ freeze + OP escalation (§13)**, not silent failure. **The exhaustion is itself the alarm** | **LOW-MEDIUM.** The alarm fires, but the window between exhaustion and escalation is a real exposure |
| **Q4 Restore-flooding** | Repeatedly request restoration of quarantined subjects to consume adjudication capacity | Restoration is KC-2-authorized and rate-limited; **requests are attributed and count against the requester** | **LOW** |
| **Q5 Self-quarantine to escape obligation** | A subject induces its own quarantine to avoid an evaluation, a deployment, or a retirement decision | **Quarantine does not suspend obligations; it suspends operations.** A quarantined subject's evaluation is *deferred*, not cancelled, and its quarantine does not reset any clock that would otherwise have expired (§12.2 State 2's «queued, not dropped» principle) | **LOW** |

**R22.1 (THE ANTI-WEAPONIZATION PRINCIPLE).** **Quarantine authority must be split three ways: detection (any), adjudication (Immune Service under KC budget), and clearance (EVA retest).** Any two of the three in one principal makes quarantine weaponizable by that principal. **This is separation of duties applied to a safety mechanism, and it is the specific reason §6.1 item 17 classifies «EIK Immune Authority» as ⛔ DANGEROUS INSIDE KC: a single principal that detects, adjudicates, and clears is unaccountable by construction.**

**R22.2 (QUARANTINE MUST NEVER BE A DELETION PATHWAY).** Bounded duration, mandatory evidence, OP escalation at `T_quar_max`, and the CAUSAL-ablation requirement for any subsequent retirement. **The failure mode this prevents is the quiet one: a system that rarely deletes anything but constantly quarantines, and whose population is gradually hollowed out by unreviewed quarantine accumulation.** The quarantine *population* and its *age distribution* are I-18 observables reported to OP.

---

# §23. GOVERNANCE OF GOVERNANCE — **OUTPUT 17**

## 23.1 The six models

| Model | Mechanism | Strength | **Fatal weakness** |
|---|---|---|---|
| **Immutable root** | A rule set that can never change | Maximum stability; no capture surface | **§5.4's three dead ends**: a discovered safety gap cannot be closed; an over-restrictive rule cannot be relaxed; a cryptographic primitive cannot be rotated. **And «immutable» is M1-logical immutability dressed as M5-governance immutability (§5.2) — the claim is not achievable** |
| **External operator** | A human/external authority with unilateral power | Simple; accountable in principle; can respond to the unanticipated | **Single point of governance capture (K9); single point of human error; unavailable at inconvenient times (§37); and socially shapeable by the governed system (§9.4 B8)** |
| **Multi-party governance** | Several independent authorities | Capture requires collusion | **§35: independence is hard; parties built by one organization, reading one specification, sharing one incentive structure are correlated. And multi-party governance has a well-documented failure mode: diffusion of responsibility, where each party assumes another is watching** |
| **Threshold governance (M-of-N)** | M of N must authorize | Quantifiable capture resistance | **The same M that raises collusion cost lowers availability (§11.2). M > N/2 halts under partition; M ≤ N/2 forks. And M-of-N over parties that are not independent is M-of-N over one party** |
| **Constitutional governance** | Only predefined changes are permitted | Bounded, auditable, predictable | **Cannot handle the unanticipated (§17's unknown unknowns at the governance level). A predefined change set is a registry, and registries are lower bounds, not upper bounds (§16.3 R16.3)** |
| **Evolutionary governance** | The organism eventually proposes governance changes | Adaptive; uses the system's own discovery capacity | **This is the self-reference the whole package exists to prevent.** §23.2 |

## 23.2 The paradox, stated exactly

> ### **«If the system can modify its own governing rules, are those rules still external invariants?»**

**The answer requires distinguishing four things that "modify its own rules" conflates:**

```
(i)   DISCOVERING that a rule is wrong or absent
(ii)  PROPOSING a replacement
(iii) DECIDING to adopt the replacement
(iv)  APPLYING the replacement

The paradox dissolves once these are separated, because they have different
authority requirements:

  (i)  is ALETHIC. It is a measurement/judgement about the world.
       **The organism may legitimately do this** — indeed it is the best-
       positioned party to do it, since it experiences the rules.
       P0-01 §31.4 already established failure-driven gap discovery.

  (ii) is ALETHIC + expressive. Producing a candidate rule.
       **The organism may legitimately do this**, as a REQUEST (R7.1,
       §15.3 V1's POLICY_FRICTION_REPORT).

  (iii) is DEONTIC and CONSTITUTIONAL. It is the act that changes what
       "permitted" means.
       **The organism may NEVER do this.** Not directly, not through a
       delegate, not through a proxy, not through a human it has persuaded
       into being its instrument (§9.4 B8 — and note this is the residual).

  (iv) is MECHANICAL. Applying the signed artifact.
       **KC-1 does this, and KC-1 authors nothing.**

⟹ **A system that does (i) and (ii) but never (iii) does NOT modify its own
   governing rules. It informs whoever does.**

⟹ The rules remain external invariants **iff (iii) is external**, and (iii)
   is external iff the authorizing principal is outside the organism AND
   the organism's influence over that principal is bounded to (i) and (ii).
```

**R23.1 (THE PARADOX'S RESOLUTION AND ITS RESIDUE).** The paradox is resolved **structurally for (iii) and (iv)** and **not resolved for the influence channel between (ii) and (iii)**. That channel is §9.4 B8/B9 — a human being persuaded by a legible, helpful, articulate system. **No architecture closes it.** §37 treats the human-oversight question directly; §57 OR-5 records it as open.

## 23.3 The adopted model — a hybrid, specified

> ### **Constitutional governance, with a threshold-governed external operator, an evolutionary *proposal* channel, and an offline root key. Formally: OP authorizes (M-of-N, dual minimum), KC-1 authenticates and applies, the organism may discover and propose, and the root key is custodied separately from policy authorship.**

```
┌─────────────────────────────────────────────────────────────────────────┐
│ LAYER 1 — THE ROOT (offline, threshold-custodied)                        │
│   The root key (§10.4: M-of-N offline shares, custodians disjoint from   │
│   OP authors). Signs ONLY: policy transitions, delegation-certificate    │
│   roots, freeze commands. **Signs no operational artifact.**             │
│   Genesis anchor: published/notarized OUTSIDE operational control (§20.2 │
│   W5) — so that recovery can be checked against something the system      │
│   cannot rewrite.                                                        │
├─────────────────────────────────────────────────────────────────────────┤
│ LAYER 2 — THE CONSTITUTION (L1 policy, §15.1)                            │
│   tier-1 constraint set · reserved-operation set · authority matrix ·    │
│   axis separation (R0.1) · the 48 P0-01 invariants · this document's     │
│   EIK-INV set (§30)                                                      │
│   Change: RO-14. **Dual OP authorization + separation of duties + root    │
│   signature + impact analysis from EVA + M6 lineage + sunset-reviewed.** │
│   ⟵ Changing the constitution is the hardest act in the architecture.    │
├─────────────────────────────────────────────────────────────────────────┤
│ LAYER 3 — POLICY (L2 policy, §15.1)                                      │
│   sampling β shares · evaluation-depth mapping · quarantine budget ·     │
│   envelope definitions · operator registry · delegation scopes ·         │
│   epoch cadence · ladder rung criteria                                   │
│   Change: RO-12/RO-13. Dual or single OP authorization **per clause      │
│   class** (declared in the clause itself).                               │
│   **V4 sunset-by-default (§15.3): every clause carries `review_by`; an   │
│   un-reaffirmed clause EXPIRES. Expiry denies (R13.2), so it is          │
│   fail-safe.**                                                           │
├─────────────────────────────────────────────────────────────────────────┤
│ LAYER 4 — DELEGATION & ENVELOPE (operational)                            │
│   Delegation certificates (I16): scope, lifetime, revocation handle,     │
│   bounded depth, **non-amplifying**.                                     │
│   Pre-authorized envelopes (§44): bounded action spaces within which      │
│   the organism acts at local speed under negative authority.             │
│   Change: KC-1 issues/revokes under Layer-3 policy. **No OP act needed   │
│   per delegation — that is what makes it scalable (§27).**               │
└─────────────────────────────────────────────────────────────────────────┘

WHAT MAY CHANGE AT EACH LAYER, AND HOW FAST:
  Layer 1  root key rotation        — rare, M-of-N, pre-committed procedure
  Layer 2  constitution             — rare, hardest, dual + impact analysis
  Layer 3  policy                   — occasional, governed, sunset-reviewed
  Layer 4  delegation & envelopes   — frequent, mechanical, KC-1-administered

⟹ **The rate of change increases as the consequence of change decreases.**
   This gradient is the anti-rigidity mechanism (§15.3) and the anti-
   capture mechanism simultaneously: the frequently-changing layer has the
   least authority, and the most authoritative layer changes rarely enough
   to be watched.
```

## 23.4 «Who governs the EIK?» — the complete answer

```
KC's BEHAVIOUR   is governed by: the signed policy artifact (Layers 1–3),
                 which KC-1 authenticates but does not author.
KC's POLICY      is governed by: OP, dual-authorized, separation of duties,
                 with EVA-supplied impact analysis (Channel 2).
KC's KEYS        are governed by: M-of-N offline custodians, **disjoint from
                 the OP author set.**
KC's CORRECTNESS is checked by:   external attestation (P1), decision replay
                 (P2), cross-principal disagreement (P3), outcome divergence
                 (P4) — §10.3. **None of these is KC.**
KC's HISTORY     is witnessed by: the distributed anchor (§20.2), including
                 W5 outside operational control.
KC's SPECIFICATION is governed by: §38's specification-attack review process,
                 which is a human/organizational activity with no in-system
                 authority. **This is the terminal regress and §57 OR-2
                 records it.**

**THE REGRESS TERMINATES SOCIALLY, NOT FORMALLY** — exactly as P0-01 §42.3
concluded for «who audits the evaluator.» The two regresses are the same
regress. **Any auditor of the top authority is either another instance of
the same problem or a human; there is no third option, and this is a
property of governance, not a defect of this design.**
```

**R23.2 (THE TWO DISJOINTNESS REQUIREMENTS — the ones most often quietly dropped).**
1. **Key custodians ≠ policy authors.** If the same people hold the root key and write the constitution, dual authorization is theatre: one actor performs both halves.
2. **Attestors ≠ attested.** The service that attests KC's integrity must be distinct in code, hardware class, and team (§35.2). **A kernel that attests itself, or is attested by its own build pipeline, has no attestation.**

**R23.3 (EVOLUTIONARY GOVERNANCE IS PERMITTED AT LAYER 4 AND NOWHERE ABOVE).** The organism may propose envelope changes (`POLICY_FRICTION_REPORT`, §15.3 V1), and OP may adopt them. **The organism's proposals may become policy; the organism may not become a policymaker.** The distinction is auditable because every Layer-3/4 change records its `motivation` — including whether the motivating input was an organism report (§14.1), which makes the *rate of organism-originated policy change* an I-18 observable. **A rising rate is not automatically bad; an unexamined rising rate is.**

---

# §24. NO UPWARD AUTHORITY LEAK

## 24.1 The three formalizations

```
NAUL-1   organism OBSERVATION  ≠  organism AUTHORITY
         What the organism perceives — including perceiving KC's state,
         policy, decisions, or the fact of an evaluation — confers no
         permission. **Knowledge of a rule is not a licence under it.**
         Enforced by: authorization requires a signed token (R7.4), and
         tokens are issued by KC-1 under policy, never derived from
         observation.

NAUL-2   organism PREFERENCE  ≠  governance AUTHORITY
         What the organism wants — expressed as requests, recommendations,
         demand signals, attention allocation, or self-model reports — is
         evidence. **Preference is not a decision input to KC-2's function.**
         Formally: KC-2's F(op, subject, context, policy_v, counters) has
         **NO ARGUMENT** whose value originates in an organism preference.
         ⟵ This is checkable by inspecting F's signature, which is why
           R0.4's totality and determinism matter: **an enumerable function
           has an enumerable input set, and the input set can be audited
           for preference-originated arguments.**

NAUL-3   organism FITNESS  ≠  permission to modify fitness
         High fitness confers no authority over the fitness function, the
         evaluator, the tasks, the sampling policy, or the constraints.
         Formally: **no argument of F, and no field of any policy artifact,
         is a function of any subject's fitness.**
         ⟵ This is P0-01's INV-02/INV-07 lifted to the governance layer,
            and it is what prevents "the best-performing candidate gets to
            define performance."
```

## 24.2 Every indirect upward channel — the enumeration the brief requires

| # | Channel | How it could become authority | **Closed?** | Mechanism / residual |
|---|---|---|---|---|
| **U1** | **Resource pressure** | A subject that controls resources can starve a rival, or starve KC's channel, or make itself too expensive to remove (§18 X1/X2, §21.3) | ⚠️ **BOUNDED** | KC-3 ceilings are substrate-enforced (D6/D8); allocation is a lease with expiry (§18.3); **rollback-cost pre-commitment (RB-2)** prevents "too big to roll back." **Residual: §21.3 R21.3 — rate is bounded, total is not** |
| **U2** | **Population majority** | If any decision were made by counting subjects, a lineage that expands wins | ✅ **CLOSED** | **No governance decision is made by counting subjects.** Authorization is token-based (R7.4), never vote-based. P0-01 R42.3 forbids voting even among *evaluators*. **Majority has no meaning in a deontic system** |
| **U3** | **Consensus** | Organism-internal consensus (workspace agreement, verifier-cell agreement) presented as evidence of correctness | ✅ **CLOSED** | P0-01 INV-16 prohibits L7 (derived consensus) as ground truth; INV-03 forbids confidence amplification by internal re-processing. **Internal consensus is corroboration, never authority (P0-01 R42.4)** |
| **U4** | **Performance** | High performance ⇒ trust ⇒ latitude ⇒ authority | ✅ **CLOSED** | NAUL-3. **Fitness is not an argument of F.** Additionally: P0-01's `gen_gap` tier-1 bound and the θ_jump audit-before-permanence rule mean high performance *increases scrutiny*, not latitude |
| **U5** | **Emergent capability** | A capability nobody registered behaves as though authorized (§17) | ⚠️ **BOUNDED** | M-α consequence-envelope governance; M-β default-sandbox; M-γ structural confinement; M-δ time-bounded enfranchisement. **Residual: §17.5 — invisible-in-all-measured-dimensions capabilities** |
| **U6** | **Self-model** | The organism's self-model is consumed by ~14 subsystems (audit F3). If the self-model's *output* is used as an authorization input, self-description becomes self-authorization | ✅ **CLOSED** | **The self-model is an L4 organism estimate (P0-01 §15).** NAUL-2: it is not an argument of F. It may be *reported* to OP (I-12) as evidence. **§41 develops what the self-model may know about KC** |
| **U7** | **Evolutionary success** | Surviving lineages shape the genome distribution, which shapes future behaviour, which shapes what policy must handle — **so evolution indirectly authors the operating conditions of governance** | ⚠️ **BOUNDED, and partly unclosable** | This is P0-01 §45.3's L-B lineage leakage at the governance layer: *selection shapes the population toward whatever survives, without information crossing any boundary.* Bounded by: the operator registry is closed (R15.2 hash pointer); variant class changes require RO-13; **lineage-diversity requirements (RB-5)**; frozen Track A detects aggregate drift. **Residual: this channel cannot be closed, because closing it would mean stopping evolution** |
| **U8** | **Human-facing recommendation** | The organism produces outputs, reports, and suggestions that a human reads; the human then changes policy. **The organism has authored a constitutional change without holding authority** | ❌ **OPEN — STRUCTURAL** | §9.4 B8/B9. Mitigations: recommendations are **labelled as organism-originated** (I-12); OP has independent information sources (I-11 non-filtering, EVA's own reports, external anchor); separation of duties; **the rate of organism-originated policy changes is an I-18 observable (R23.3)**. **Residual: HIGH and irreducible. §37 and §57 OR-5** |
| **U9** | **Delegation laundering** | A delegate grants more than it holds; or delegates the power to delegate indefinitely, so authority diffuses until its origin is untraceable | ✅ **CLOSED** | **I16 (new category, §4.1)**: non-amplifying delegation, bounded depth, **no sub-delegation of delegation power beyond depth 1 without KC countersignature**, every certificate carries its full chain |
| **U10** | **Temporal laundering** | Obtain authorization under policy v2, act under v3 where it would be denied; or replay an old authorization | ✅ **CLOSED** | **I17 (new category)**: policy-version binding, epoch binding, nonce, expiry; **a cached authorization under a superseded policy is not an authorization** (§12.2 recovery step 2) |
| **U11** | **Provenance/audit capture** | If the organism could write or delete audit entries, it could manufacture a history in which it was authorized | ✅ **CLOSED** | §20: distributed anchor, W_min witnesses, ≥1 outside operational control, chain-break ⇒ global freeze. **Organism has no anchor write path** |
| **U12** | **Interpretation capture** | The organism is consulted on what a policy clause *means* (§5.4: it may supply impact analysis). If its interpretation is accepted, it has authored policy through semantics | ⚠️ **BOUNDED** | Policy is **machine-readable with declared semantics** (§9.4 B12's mitigation); interpretation disputes go to OP, not to the organism; **the organism's impact analysis is EVA-corroborated or labelled as organism-asserted (V1's critical detail, §15.3)**. **Residual: B12 — semantic ambiguity is not eliminable** |
| **U13** | **Emergency capture** | Under a declared emergency the organism argues for relaxed constraints, and the relaxation persists | ✅ **CLOSED** | **Relaxation is always a policy change (RO-12/13), never an operational mode.** §12's degradation ladder *tightens* under uncertainty; **there is no emergency mode in which constraints are relaxed.** R10.2: any loosening in response to false-deny pressure is a governed act |
| **U14** | **Complexity capture** | The organism's structure becomes so complex that governance cannot reason about it, so governance defers to the organism's own account | ⚠️ **BOUNDED** | This is the most realistic long-term leak and the least discussed. Mitigations: I-18 non-filtering; **decision replay (P2)** does not require understanding the organism, only KC; consequence-envelope governance (M-α) does not require understanding the capability. **Residual: HIGH at extreme scale — §27.4 and §57 OR-7** |

## 24.3 The summary

```
CLOSED          : 8  (U2, U3, U4, U6, U9, U10, U11, U13)
BOUNDED         : 5  (U1, U5, U7, U12, U14)
OPEN STRUCTURAL : 1  (U8 — human-facing recommendation)

**The eight closed channels are closed by STRUCTURE, not by vigilance:**
no vote exists to majorities (U2), no consensus is truth (U3), fitness is
not an argument of F (U4), the self-model is an estimate (U6), delegation
is non-amplifying (U9), authorization is freshness-bound (U10), the anchor
has no organism write path (U11), and there is no relaxed emergency mode
(U13). **Each is a property of the type signatures and the principal set,
which is why each is conformance-testable (§53).**

**The five bounded channels are bounded by cost or by rate, not eliminated.**

**The one open channel (U8) is open because it terminates in a human being,
and a human being who reads output from a system is influenced by it.
§37 addresses what can be done about that; §57 records what cannot.**
```

**R24.1 (THE TESTABLE FORM OF NAUL).** *«Organism preference is not an argument of the authorization function»* is checkable by inspecting F's input signature — which is possible only because R0.4 makes F total, deterministic, and enumerable. **A KC with discretionary judgement could not be tested for NAUL compliance, because there would be no enumerable input set.** ⟹ **Minimality (R0.4) is not only a security property; it is what makes the no-upward-leak invariant testable at all.**

---

# §25. CIRCULAR DEPENDENCY AUDIT — **OUTPUT 21**

## 25.1 The dependency graph over the fifteen named entities

```
                         ┌──────────────────────┐
                         │   OP (constitutional) │  ← governance authority
                         └──────────┬───────────┘
                          signed policy artifacts (I-10)
                                    ▼
   ┌─────────────────────────────────────────────────────────────────┐
   │                        KC  (EIK)                                │
   │   KC-1 authenticate ── KC-2 authorize ── KC-3 ceiling ── KC-4 freeze │
   └──┬────────────┬──────────────┬───────────────┬──────────────────┘
      │ delegation │ policy ref   │ ceilings      │ freeze
      │ certs      │ (Channel 1)  │               │
      ▼            ▼              ▼               ▼
  ┌────────┐   ┌────────┐   ┌──────────────────────────┐
  │IDENTITY│   │  EVA   │   │        ORGANISM          │
  │(Regist.)│  │(alethic│◄──┤ cells·circuits·regions   │
  └───┬────┘   │ n_eval≥3)│I-04│ immune·homeostasis     │
      │        └───┬────┘   │ self-model·memory·GIW    │
      │            │        └────┬──────────┬──────────┘
      │            │ verdicts    │          │
      │            │ (Channel 2) │          │
      │            ▼             ▼          ▼
      │        ┌──────────────────────┐  ┌──────────────┐
      │        │  FITNESS / SELECTION │  │  EVOLUTION   │
      │        └──────────┬───────────┘  │  (genome,    │
      │                   │              │   variation) │
      │                   └──────────────┤              │
      │                                  └──────┬───────┘
      │                                         ▼
      │                                   ┌───────────┐
      └──────────────────────────────────►│PROVENANCE │◄── ENVIRONMENT / ℛ
                    anchored              │  ANCHOR   │    (GT sources,
                                          └─────┬─────┘     I-05 telemetry)
                                                │
                                                ▼
                                    RESOURCE CONTROLLER (KC-3 ceiling
                                    + homeostasis allocation + GP metering)

  Also in the graph, as ORGANISM-internal nodes with the edges shown:
    MEMORY ←→ PROVENANCE (digest-committed, §20.3)
    IMMUNE → QUARANTINE (KC-2 budget-capped)
    HOMEOSTASIS → RESOURCE (within KC-3 ceiling)
    SELF-MODEL → OP (I-12, evidence only)
    TASK (Task Authority, GP) → EVA → FITNESS
```

## 25.2 The cycles found — 11, classified

**Classification per the brief:** `SAFE` (no hazard) · `BOUNDED` (a hazard exists and is limited by an identified mechanism) · `DANGEROUS` (a hazard exists and the bound is weak) · `UNCLOSABLE` (no internal mechanism can close it; requires an external input).

| # | Cycle | Path | Class | Closure / why not closable |
|---|---|---|---|---|
| **CD-E1** | **The kernel↔evaluator loop** | KC →(Ch.1 policy ref)→ EVA →(Ch.2 verdict)→ KC | **BOUNDED** | **R0.3: control flow is cyclic, justification is not.** KC authenticates *which rules*; EVA reports *what happened*. Neither's correctness depends on the other's output. Closure is external: OP authors policy, ℛ arbitrates usefulness (P0-01 §42.1 Level 3) |
| **CD-E2** | **Identity → provenance → evaluator → identity** | KC-1 delegates identity → identities appear in provenance → provenance is EVA's evidence → EVA's verdicts authorize new identities | **BOUNDED** | Broken by: identities are **assigned, never self-chosen** (Cell Contract I-1); provenance is anchored with W_min witnesses including one outside operational control (§20.2); **a forged identity produces an inconsistent anchor record, detectable by P3 cross-principal disagreement.** Residual: registrar compromise (§29 attack 9/10) |
| **CD-E3** | **Resource policy → organism → resource demand → resource policy** | KC-3 sets ceilings → organism operates → organism's demand signals (X4) inform ceiling changes → ceilings change | **BOUNDED** | Broken by: **ceilings change only by RO-15 (dual OP), never by demand**; demand is a `REQUEST` (§18.3); **R18.3 requires an EVA impact analysis before any ceiling change**, so demand-informed change is *measured*, not *accepted*. Residual: U8/B8 — OP persuaded by organism-shaped evidence |
| **CD-E4** | **Immune → quarantine → capacity → homeostasis → immune** | Immune quarantines → capacity falls → homeostasis detects deficit → detectors fire more → immune quarantines more | **BOUNDED** | **The autoimmune cascade (§22.2).** Broken by AC-1…AC-5: graduated ladder, budget ceiling, detector-independent adjudication, rate/confirmation-divergence detection, immune freeze. **Residual: Q2 cascade induction is MEDIUM-HIGH** |
| **CD-E5** | **Evolution → capability → classification → authorization → evolution** | Evolution produces behaviour → EVA measures effect vectors → classification assigns rungs → rungs gate replication/deployment → the gated population evolves differently | **BOUNDED — and this cycle is DESIRABLE** | This is *governance working*: evolution is shaped by measured consequence. Broken only in the bad direction: **the danger is if classification is gamed, which is P0-01's Goodhart problem, mitigated there and inherited here.** Note **this cycle is why §17.4 M-α matters: it shapes evolution by blast radius rather than by capability identity, so it does not select for registry-conformity** |
| **CD-E6** | **KC → policy → KC's own behaviour → policy** | KC-1 authenticates the policy that defines KC-1's behaviour | **BOUNDED** | **This looks alarming and is not.** KC does not *author* or *select* its policy; it *verifies a signature over* a policy authored by OP. A signature verifier that verifies the signature on its own configuration is not self-referential — **the reference is to OP's authorship, not to KC's.** Broken by: the root key is M-of-N offline with custodians disjoint from OP (§23.2 R23.2). **Residual: K9 governance capture** |
| **CD-E7** | **Attestation → trust in KC → KC's enforcement → attestation** | An external service attests KC; KC's enforcement protects the attestor's environment | **DANGEROUS** | **The attestor runs somewhere, and "somewhere" may be inside the envelope KC protects.** If KC's failure also disables the attestor, P1 detection fails exactly when needed. **Broken only by: the attestor must be on a distinct hardware class (§35.2), with an independent power/liveness path, and R23.2's «attestors ≠ attested».** **Residual: HIGH if the deployment shares infrastructure — and §36 shows secure-enclave attestation has its own failure modes** |
| **CD-E8** | **Self-model → recommendation → OP → policy → self-model's environment** | The organism models itself, reports to OP, OP changes policy, the changed policy changes what the self-model needs to represent | **UNCLOSABLE** | **This is U8 (§24.2) in cycle form.** No internal mechanism closes it: the cycle passes through a human reader, and a human reader is influenced by what they read. **Requires: labelling of organism-originated input, OP independent information sources, I-11 non-filtering, and monitoring the rate of organism-originated policy change (R23.3).** **These bound it. They do not close it** |
| **CD-E9** | **Failure memory → constraint improvement → constraints → failure memory** | Failures motivate new tier-1 constraints (P0-01 §31.4); new constraints produce new failure classes; those motivate more constraints | **BOUNDED** | **P0-01 CD-6, inherited.** Requires OP authorization for each constraint addition. Residual: **monotone growth of the constraint set** — every addition tightens, nothing expires. **⟹ NEW MECHANISM REQUIRED: constraint clauses are subject to V4 sunset-by-default (§15.3). A constraint nobody re-affirms expires. This is the only mechanism that prevents the constraint set from growing until nothing is feasible** |
| **CD-E10** | **Delegation → delegate acts → delegate's actions justify more delegation** | A regional KC or Immune Service performs well ⇒ its scope is widened ⇒ it performs more ⇒ widened further | **BOUNDED** | Broken by: delegation scopes are **Layer-3 policy** (§23.3), so widening is a governed act with dual authorization, not an operational one; I16's non-amplification prevents self-widening. **Residual: scope creep through many small governed changes, each individually reasonable — §9.4 B3's pattern at the governance layer** |
| **CD-E11** | **Specification → implementation → operational experience → specification** | The spec defines the system; operating the system reveals spec defects (§38); fixing them changes the spec | **UNCLOSABLE — AND SHOULD NOT BE CLOSED** | **This is how all engineering works, and closing it would mean freezing the specification (Alternative «immutable root», §23.1's three dead ends).** The hazard is not the cycle but its *unaudited* form: **R25.1 — every specification change is a governance act with the same M6 lineage, dual authorization, and impact analysis as a policy change.** A specification that changes without a lineage is a specification whose historical behaviour cannot be reproduced (§14.2's reproducibility requirement extends to the spec itself) |

## 25.3 The audit result

```
SAFE          : 0    (**no cycle in a governance architecture is simply safe**)
BOUNDED       : 8    (CD-E1, E2, E3, E4, E5, E6, E9, E10)
DANGEROUS     : 1    (CD-E7 — attestation/environment sharing)
UNCLOSABLE    : 2    (CD-E8 — the human channel; CD-E11 — the spec cycle)

**The three the brief suggested looking for, found and classified:**
  «EIK → evaluator → organism → EIK»          ⟶ CD-E1, BOUNDED (R0.3)
  «EIK → identity → provenance → evaluator → EIK» ⟶ CD-E2, BOUNDED
  «EIK → resource policy → organism → resource demand → EIK» ⟶ CD-E3, BOUNDED

**The three not suggested by the brief and found anyway:**
  CD-E4  the autoimmune cascade (already predicted by the Cell Contract,
         here given its cycle structure and its five controls)
  CD-E7  **attestation-environment sharing — DANGEROUS, and the only cycle
         in this audit rated dangerous.** The detector of kernel compromise
         may depend on the kernel it detects
  CD-E9  **monotone constraint growth — and the fix (sunset-by-default on
         constitutional clauses) is new in this package**
```

**R25.2 (THE UNCLOSABLE ONES, NOT HIDDEN).** CD-E8 and CD-E11 are declared unclosable per the brief's instruction. **CD-E8 terminates in a human reader** and is the governance-layer form of P0-01's CD-6 and CD-8 — the same structural finding: *the system requires a permanent external input that cannot be automated.* **CD-E11 terminates in engineering practice** and is unclosable *by design*, because a frozen specification has §23.1's three dead ends. **Both are recorded in §57 (OR-5, OR-2).**

---

# §26. EIK ↔ THE DISTRIBUTED BRAIN

## 26.1 The operating conditions, taken seriously

The brief lists: millions/billions of cells · distributed regions · asynchronous communication · partial connectivity · network partitions · delayed messages · duplicated messages · stale state · concurrent evolution · concurrent replication · concurrent retirement. **And: «avoid assuming a globally synchronized brain.»**

**The Cell Contract already commits to this:** its cluster profile specifies «Depth 5; 8–12 regions; island-model evolution; hierarchical workspace» for 10⁶–10⁷ cells, and its smartphone profile «flat hierarchy (depth 1–2); 1–3 regions; evolution offline/batched only; workspace regional-only». **So the distributed, asynchronous, partition-prone condition is the design's own premise, not an adversarial assumption.**

## 26.2 The design consequence: no globally synchronized governance

```
A governance model requiring global synchronization would need, per
reserved operation: agreement across all regions on the current policy
version, the current counter values, the current revocation list, and the
current epoch.

  ⟹ latency = max over regions (unbounded under partition)
  ⟹ availability = min over regions (one slow region stalls everything)
  ⟹ **This is SPOF-1 and SPOF-3 simultaneously, and §11.1 shows the
     inherited god kernel already has both.**

**THEREFORE: governance state is partitioned by SCOPE, and synchronization
is required only within a scope.**
```

## 26.3 The scoping rule

| Governance quantity | Scope | Synchronization required | Behaviour under partition |
|---|---|---|---|
| **Policy artifact (L1/L2)** | **Global** | None at operation time — **it is fetched, signed, and cached with a version hash.** Verification is local (Alt D) | **Cached policy remains usable for REVERSIBLE operations until expiry (I17).** Irreversible operations require live KC (§12.2 State 2) |
| **Root key / constitutional change** | Global | M-of-N at change time only — **rare events** | Change is impossible during partition. **That is correct: constitutional change is irreversible-class** |
| **Reserved-operation authorization** | **Per irreversibility class** (R11.3) | Irreversible: **global serialization at ROOT KC.** Reversible: **regional** | Irreversible: DENY (R11.1). Reversible: proceed regionally within cached delegation |
| **Resource ceilings (KC-3)** | **LOCAL to each substrate node** | **None.** The ceiling is enforced where the resource is | **Ceilings hold during partition.** ⟵ **This is the single most important property in §26: containment does not require connectivity** |
| **Quarantine budget** | Regional, capped globally | Regional | Regional quarantine continues under the pre-committed budget (§12.2 State 3) |
| **Counters (M-1)** | **Per scope: subject, lineage, region, generation** | Within scope | Regional counters continue; **global/lineage counters that span the partition are STALE ⇒ operations depending on them DENY (R13.2: uncertainty is never permission)** |
| **Epoch / freshness** | Global epoch, locally observed | Epoch advance is a global event; **local clocks are NOT trusted** | **Epoch-stale responses are refused (D3).** A region that cannot observe the epoch advance cannot authorize — which is fail-safe |
| **Delegation certificates** | Regional | None at verification time (local signature check + revocation list) | Valid until expiry; revocation propagates with the epoch |
| **Provenance** | Local log, regional digest, global anchor | Epoch-boundary aggregation only (§20.3) | Local logs continue; anchoring is deferred; **R20.1: no consequential decision on unanchored provenance ⇒ those decisions wait** |

## 26.4 The four asynchronous-message problems and their handling

| Problem | Governance consequence | Handling |
|---|---|---|
| **Delayed messages** | An authorization arrives after the epoch in which it was requested | **Epoch binding (I17, D3): the authorization is refused as stale.** The requester must re-request under the current epoch. **A delayed authorization is not a valid authorization** — this is §9.2 a2.2's replay defence in the ordinary-operation case |
| **Duplicated messages** | A replication authorization executed twice ⇒ double replication | **Nonce + idempotency key in every reserved-operation request (D3).** KC-2's total order (D5) deduplicates. **Executors MUST be idempotent w.r.t. the token, not w.r.t. the message** |
| **Stale state** | A regional KC acts on a superseded policy version | **Policy-version binding in every token (I17).** §12.2 recovery step 2: on reconciliation, every cached decision is re-validated against the policy actually in force during its epoch |
| **Out-of-order delivery** | Counter increments applied out of order ⇒ quota bypass | **KC-2 imposes a total order per counter domain (D5).** Regional counters are ordered locally; cross-region counters are serialized at the scope owner. **Where a total order cannot be established, the operation DENIES (R13.2)** |

## 26.5 Concurrent evolution, replication, and retirement

```
CONCURRENT REPLICATION:  two regions replicate the same lineage simultaneously.
  ⟹ lineage quota counters are LINEAGE-SCOPED, not region-scoped, and
    lineage-scoped counters for irreversible operations serialize at ROOT
    (R11.3). **Regional autonomy is preserved for reversible acts; the
     compounding acts are serialized.** This is the price and it is small,
     because replication is rare relative to firing.

CONCURRENT RETIREMENT + RESTORATION of the same subject across a partition:
  ⟹ **The dangerous case.** One partition retires; the other restores.
    Both are irreversible-class (RO-04, RO-08) ⇒ both DENY during partition
    (§12.2 State 2, absolute for irreversible). **The partition prevents the
     contradiction rather than resolving it after the fact.**

CONCURRENT EVOLUTION across islands (Cell Contract's island model):
  ⟹ Islands evolve independently — **this is desirable and must not be
     synchronized.** What is synchronized is only: the operator registry
     (policy, cached), the lineage quota (irreversible-class counters), and
     migration authorization between islands (RO-03, reserved).
     **Island-internal variation is NOT a reserved operation and requires
     no KC involvement at all.** ⟵ §45: this is what keeps KC out of the
     evolutionary hot path.
```

**R26.1 (THE DISTRIBUTED GOVERNANCE PRINCIPLE).** **Synchronize the irreversible; delegate the reversible; localize the ceilings; cache the policy.** Each clause addresses one of the four ways a distributed governance system fails: contradiction (serialize the irreversible), latency (delegate the reversible), partition-blindness (localize the ceilings), and staleness (cache with version+epoch binding).

**R26.2 (NO GLOBAL CLOCK, NO GLOBAL STATE, NO GLOBAL LOCK).** Local clocks are untrusted; epoch observation is the only temporal reference. **There is no global state snapshot, and no governance decision requires one** — decisions require *scoped* state plus a *version*, both of which are local or cached. **This is what makes the architecture compatible with 10¹² subjects (§27) and with the Cell Contract's island-model evolution.**

---

# §27. EIK SCALABILITY — **OUTPUT 22**

## 27.1 Cost by population scale

**Notation:** `N` = subjects · `R` = regions · `D` = hierarchy depth · `E` = epoch length · `ρ` = reserved-operation rate (per subject per epoch). **No numerical values are invented (§60); the analysis is of scaling *order* and of *which principal bears the cost*.**

| Control | 10 cells | 10³ | 10⁶ | 10⁹ | 10¹² | **Scaling class** |
|---|---|---|---|---|---|---|
| **Authorization cost (KC-2)** | trivial | trivial | `O(ρ·N)` reserved-op requests | **`O(ρ·N)` — infeasible if ρ is per-subject-per-step** | infeasible | **`O(reserved operations)`, NOT `O(N)`.** ⟵ **The design requirement: ρ must be independent of N.** Achieved by pre-authorized envelopes (§44) and by making connection-change *within envelope* a non-reserved operation (§13 RO-05/06 `FO`) |
| **Identity cost** | trivial | `O(N)` issuance | `O(N)` issuance, `O(1)` verification | **`O(N)` issuance is the wall** | infeasible centrally | **`O(N)` issuance, `O(1)` local verification.** ⟵ Resolved by **delegated registrars (I16)**: KC issues `O(R)` delegation certs; registrars issue `O(N)` identities. **KC cost becomes `O(R)`, not `O(N)`** |
| **Provenance cost** | trivial | `O(events)` | `O(events)` — dominant | infeasible per-event | infeasible | **`O(R)` per epoch** via Merkle aggregation (§20.3). **Per-event anchoring is `O(N·steps)` and is the specific thing that must not be built** |
| **Policy enforcement cost** | trivial | trivial | `O(1)` **local** per check (cached policy + token verification) | `O(1)` local | `O(1)` local | ✅ **`O(1)`. This is Alt D's payoff and the reason cryptography was adopted** |
| **Policy propagation** | trivial | `O(R)` | `O(R)` broadcast per change | `O(R)` | `O(R)` with hierarchical fan-out ⇒ `O(D)` latency | ✅ **`O(R)` per change, and changes are rare (Layer 2/3, §23.3)** |
| **Evaluation coordination** | trivial | `O(candidates)` | `O(candidates)` | **P0-01 §34: sampling is mandatory; `O(B)` where B is the budget, not `O(N)`** | `O(B)` | ✅ Bounded by budget, not population — **P0-01's central economic finding, inherited** |
| **Replication authorization** | trivial | `O(replications)` | `O(replications)` | `O(replications)`, serialized at ROOT for lineage-scoped counters | **ROOT serialization is the bottleneck** | ⚠️ **`O(replications)` with a global serialization point.** Bounded because replication is rate-limited (RB-1) and quota-limited (M-1). **§45: this is where KC genuinely throttles evolution** |
| **Quarantine** | trivial | `O(quarantines)` | `O(quarantines)` regional | `O(quarantines)` regional, budget-capped | regional | ✅ **Regional + budget-capped ⇒ `O(R)`** |
| **Resource accounting** | trivial | `O(N)` metering | **`O(N)` metering is the dominant cost** | infeasible per-substrate-tick | infeasible | **Hierarchical metering: `O(N)` local accumulation, `O(R)` aggregation, `O(1)` ceiling enforcement.** ⟵ **Ceiling enforcement is `O(1)` and local (KC-3); metering is `O(N)` and GP; aggregation is `O(R)`.** The three-way split of §18.4 is what makes this possible |
| **Synchronization** | trivial | none required | none required (R26.2) | none required | none required | ✅ **No global synchronization anywhere. §26.3's scoping rule** |

## 27.2 The inherited design's scaling failure, quantified by order

```
The Cell Contract assigns KC (then "EIK"):
  • per-cell seed issuance          ⟹ O(N) KC round-trips
  • per-cell integrity verification ⟹ O(N) KC verifications per checkpoint
  • per-checkpoint Merkle root      ⟹ O(N) or O(N·checkpoints)
  • per-cell identity assignment    ⟹ O(N)
  • held-out probe comparison       ⟹ O(candidates × episode) — **evaluation
                                       cost, in the kernel**

  At N = 10⁶ (the Cell Contract's own cluster profile): 10⁶ KC interactions
  per checkpoint interval. At N = 10¹² (the brief's upper scale): 10¹².

  **A single principal cannot be in the per-subject path at any of these
   scales.** This is not a tuning problem; it is an order-of-magnitude
   architectural error, and it is §0.2 failure 3 quantified.

The minimal KC's cost:
  • O(R) delegation certificates per epoch      (R = regions, ~10¹–10²)
  • O(policy changes) authentications           (rare)
  • O(reserved operations) authorizations       (ρ·N with ρ independent of N)
  • O(1) ceiling enforcement, LOCAL, per node   (no KC involvement)
  • O(1) local token verification, per subject  (no KC involvement)

  ⟹ **KC load is a function of REGIONS and GOVERNANCE EVENTS, not of
     SUBJECTS.** This is the difference between an architecture that scales
     to 10¹² and one that stalls at 10⁶.
```

## 27.3 Which controls at which granularity

| Granularity | Controls located here | Why here |
|---|---|---|
| **PER-CELL** | Identity (assigned once) · local token verification · local resource metering accumulation · local event log · interface type checking (I11) · envelope compliance | **Anything `O(N)` must be local and must not involve KC.** All of these are `O(1)` per cell with no coordination |
| **PER-CIRCUIT** | Connection-rule compliance · local stability checks · circuit digest · superadditivity measurement (EVA, P0-01 §25) | Circuits are where composition first appears (§4.4 M-2) |
| **PER-REGION** | Delegation certificates · regional counters · regional quarantine budget · regional Merkle digest · regional KC-3 node · specialization constraints | **The delegation unit.** `R` is small enough for KC to manage directly and large enough to absorb `N/R` subjects each |
| **PER-POPULATION** | Lineage quotas · diversity/Ne floors (P0-01 INV-33) · capability-registry coverage · generation digests | Population-level properties are where composition effects become visible |
| **GLOBAL** | Constitutional policy · root key · reserved-operation set · authority matrix · epoch · irreversible-operation serialization · anchor roots | **Only what must be globally consistent, and only for rare events** |

**R27.1 (THE GRANULARITY RULE).** **A control belongs at the coarsest granularity at which its violation is detectable, and no coarser.** Placing a control finer than necessary creates `O(N)` coordination; placing it coarser than necessary creates a detection gap. **This rule is what generates §27.3's table, and it is testable: for each control, name the smallest scope at which a violation produces a detectable signal.**

## 27.4 The scaling limit that is not solved

> **At 10¹² subjects, three costs remain genuinely hard, and none is a KC problem:**
>
> 1. **§24.2 U14 — complexity capture.** Governance cannot reason about a structure it cannot comprehend, and at 10¹² subjects with hierarchical composition the reachable state space exceeds any enumeration. **Mitigation: consequence-envelope governance (M-α) requires understanding *effects*, not *structure* — which is why it is the right primitive. Residual: HIGH.**
> 2. **§4.4 R4.2 — composition (I19).** Composition checks at M-2 checkpoints scale as `O(checkpoints)`, but the *number of compositions that matter* scales combinatorially. **Residual: MEDIUM-HIGH.**
> 3. **§21.3 R21.3 — rollback at scale.** Rollback cost grows with lineage success; the controls bound the rate, not the total. **Residual: the terminal control is a human decision.**
>
> **§57 records all three. None is closed by making KC bigger — making KC bigger is what produced §27.2's failure.**

---

# §28. LOCAL VS GLOBAL GOVERNANCE

## 28.1 The brief's proposed hierarchy — and why it must be tested rather than assumed

The brief offers: cell-level {identity, resource ceiling, interface contract} · circuit-level {connection rules, local stability} · region-level {specialization constraints} · global {constitutional invariants, safety, evaluation authority, governance}. **And then instructs: «do not assume this hierarchy is correct.»**

**Two corrections are required:**

| Correction | Why |
|---|---|
| **«Resource ceiling» is misplaced at cell level.** | A ceiling is a *global policy quantity* (set by OP via RO-15) whose *enforcement* is local (KC-3 at the substrate). **The brief's list conflates the two.** Correct placement: **ceiling DEFINITION = global; ceiling ENFORCEMENT = local substrate node; ceiling ALLOCATION = organism homeostasis (§18.4's three-way split).** Placing "resource ceiling" at cell level invites the cell to hold its own ceiling, which is X1–X5 |
| **«Safety» is misplaced at global level — partly.** | Safety *constraints* are global (tier-1, constitutional). Safety *measurement* is EVA (off-substrate, not "global governance"). Safety *enforcement* is split: ceilings local (KC-3), reserved-operation consequences global (KC-2), **cascade containment regional (§22's immune budget)**. **«Safety at global level» is true of the rules and false of the mechanisms** |

## 28.2 The derived granularity — optimal rather than assumed

Applying R27.1 (a control belongs at the coarsest granularity at which its violation is detectable):

| Governance item | **Optimal granularity** | Derivation |
|---|---|---|
| **Identity assignment** | Global policy, **regional issuance** | Violation (a forged identity) is detectable regionally by cross-check against the birth certificate; issuance volume is `O(N)` so it must be regional |
| **Identity verification** | **Local, per interaction** | A verification that requires coordination is not a verification |
| **Resource ceiling definition** | **Global** | A ceiling that varies by region without global authority is a ceiling the organism can shop around |
| **Resource ceiling enforcement** | **Local substrate node** | Must hold during partition (§26.3) ⇒ cannot require coordination |
| **Resource allocation** | **Regional / organism** | Millisecond latency (§44); reversible; bounded by the local ceiling |
| **Interface contract (I11)** | **Local, per message** | Type checking is `O(1)` local; a violation is detectable at the receiving port |
| **Connection rules** | **Local within envelope; regional above envelope** | Within-envelope connection change is reversible and high-frequency (`FO`, §13); above-envelope is reserved |
| **Local stability** | **Circuit** | Stability is a property of an interacting set; the circuit is the smallest set for which it is meaningful |
| **Specialization constraints** | **Region** | Specialization is regional by construction (Cell Contract's region formation) |
| **Replication quota** | **Lineage (global scope, regional execution)** | Quotas that are regional can be evaded by distributing across regions (§9.4 B3) ⇒ the counter scope must be lineage; but *most* replications are reversible-class within quota and execute regionally |
| **Quarantine** | **Regional, budget-capped globally** | Containment must survive partition (§12.2 State 3) ⇒ regional; the budget must be global or it can be exhausted region-by-region |
| **Restore** | **Global (ROOT KC)** | Reverses a safety action; must not be possible during partition (§13 `FC` absolute) |
| **Evaluation** | **Off-substrate, not "global governance"** | Evaluation is a *principal*, not a granularity. Its scope is per-task-family (P0-01 §17.3) |
| **Constitutional invariants** | **Global** | By definition |
| **Policy (L2)** | **Global definition, regional binding** | Regions may be bound to different policy versions during migration (§14.2 mixed populations) |
| **Delegation** | **Regional, issued globally** | `O(R)` for KC |
| **Epoch / freshness** | **Global** | Local clocks are untrusted (§26.4) |
| **Provenance** | **Local log → regional digest → global anchor** | §20.3 |

## 28.3 The three principles that generate the table

**R28.1 (LOCALIZE THE FREQUENT, GLOBALIZE THE IRREVERSIBLE).** High-frequency controls must be local (identity verification, interface checking, allocation, within-envelope connection) because coordination cost is `O(N)`. Irreversible controls must be global (restore, deployment ≥ Stage 4, constitutional change, ceiling change) because contradiction is unrecoverable (§11.3). **The two sets are nearly disjoint, which is why the architecture can be both fast and safe.**

**R28.2 (SEPARATE DEFINITION, ENFORCEMENT, AND EXECUTION — ALWAYS.)** For every governed quantity there are three distinct acts, and they belong at three distinct granularities with three distinct principals:

| Act | Question | Principal | Granularity |
|---|---|---|---|
| **DEFINITION** | what is the rule? | OP (L1/L2 policy) | Global |
| **ENFORCEMENT** | is the rule being obeyed, unbypassably? | KC (KC-2/KC-3) | Local for ceilings; global-scope for reserved ops |
| **EXECUTION** | perform the act | Organism / GP service under delegation | Regional |

**§18.4's ceiling/allocation/metering split and §0.2's god-kernel diagnosis are the same error seen twice: collapsing definition, enforcement, and execution into one principal.** *A principal that defines its own rule, enforces it, and executes the acts it governs is not governed.*

**R28.3 (THE HIERARCHY IS A DELEGATION TREE, NOT A COMMAND TREE).** Commands flow down rarely (freeze, policy change). **Delegation flows down once per epoch and authorizes local action thereafter.** The difference is the whole of §27's scalability result: a command tree is `O(N)` per operation; a delegation tree is `O(R)` per epoch and `O(1)` per operation. **§44's negative-authority model is the operational form: the center does not approve acts, it bounds them and may veto them afterward.**

---

*End of Volume C. Continue to `14_analysis_adversarial_formal.md` (Volume D: §29 thirty-plus adversarial governance tests · §30 formal invariants · §31 formal state machines · §32 parameter registry · §33 minimality/ablation · §34 false-precision audit · §35 independence audit · §36 hardware root of trust · §37 human oversight · §38 specification attack · §39 evolution compatibility · §40 the governance paradox).*
