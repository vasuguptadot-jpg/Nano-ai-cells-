# P0-02 — EXTERNAL INVARIANT KERNEL (EIK) & GOVERNANCE BOUNDARY

**Adversarial architecture analysis + V4 EIK & Governance Contract v1.0**
**Architecture only. No implementation, no code, no deployment, no prototype.**

---

## OUTPUT 1 — EXECUTIVE VERDICT

> # THE EIK CONCEPT SURVIVES ADVERSARIAL ANALYSIS — BUT NOT AS PROPOSED.
>
> **The *need* for an external governance authority is real, unavoidable, and provable (§2.1's four arguments). The *design* inherited from the audit (M02's seven-subsystem kernel, expanded by the Cell Contract to nineteen authorities) fails — not on safety grounds, but because it is a second organism that cannot run.**
>
> ### What survives
>
> A **minimal, live, non-alethic deontic kernel** holding exactly **four capabilities** — policy authentication, a total deterministic authorization function over **15 reserved operations**, substrate-enforced resource ceilings, and a non-discretionary freeze. Its decision domain is **enumerable** (15 × 7 × 6 = 630 cells), which makes **21 of its 60 invariants formally verifiable rather than merely testable**, and makes **9 of the 12 structurally-solved attacks into type-level impossibilities** — the strongest form of safety argument available.
>
> ### What does not survive
>
> **The god kernel.** Nineteen authorities, five of them `O(N)`, stall at ~10⁶ subjects — *the Cell Contract's own stated cluster target.* §10.4's ablation is decisive: **enlarging the kernel prevents no additional attacks and destroys ten properties**, including the enumerability that is the only source of its trustworthiness.
>
> ### The central finding
>
> > **Most of the contradictions across V3/V3.1, the audit, the Cell Contract, and P0-01 have a single root cause: the conflation of two independent axes.**
> >
> > **ALETHIC** — *what is true, and how well is it known.* Graded. Failure is **wrong but detectable**. Apex: **EVA**.
> > **DEONTIC** — *what is permitted, and who may decide it.* Total and deterministic. Failure is **wrong and undetectable from inside**. Apex: **KC + OP**.
> >
> > The inherited design assigned **measurement functions to the enforcement principal** because both were «off-substrate». **§9.1's cross-system audit found 9 contradictions; 7 share this single root.** Resolving it dissolves them — which is evidence the distinction is real rather than a relabelling.
>
> ### The honest residue
>
> **6 of 34 adversarial scenarios are UNSOLVABLE** (reward hacking at the governance layer · unknown-capability detection · governance capture · specification defects · legibility capture · root-key custody under coercion). **13 properties are ASSUMED, not verified or tested**, and **5 of those 13 cannot be discharged by any mechanism inside the contract** — two of them (custodian/author disjointness, independence from the designers' latent assumptions) are **not engineerable at all**. **11 circular dependencies exist: 8 bounded, 1 dangerous, 2 unclosable.**
>
> **14 open research problems are registered, none hidden.**

---

## OUTPUT 2 — SHOULD AN EIK EXIST AT ALL?

> # YES. But «outside the evolvable substrate» is necessary and NOT sufficient. The requirement is three conjuncts.

### 2.1 Why an external authority is unavoidable — four independent arguments

| # | Argument | Force |
|---|---|---|
| **1** | **Non-self-reference.** A constraint inside the substrate is reachable by attention, plasticity, resource pressure, pruning, replication, and persuasion. **A constraint that can be out-attended, starved, pruned, or persuaded is not a constraint** (audit F4) | **Decisive** |
| **2** | **Undetectable failure.** An alethic error can be contradicted by another measurement. **A deontic error cannot be contradicted by another decision** — there is no external check on a permission except the party that grants it | **Decisive** |
| **3** | **Terminal values are not derivable.** A system cannot derive its own tier-1 constraints; any derivation is itself a policy requiring a prior policy, *ad infinitum*. **The regress stops at humans** (§8.5 Layer 4) — and stopping there is a social fact, not a technical solution | **Decisive** |
| **4** | **Irreversibility requires a live decision point.** Cryptographic tokens cannot express «uncertainty is never permission», cannot freeze, cannot hold cumulative counters, and cannot be replayed for attribution. **Four properties require a principal, not a mechanism** (§10.5's Alt-D ablation) | **Strong** |

### 2.2 The three conjuncts

```
(i)   OUTSIDE the evolvable substrate   ⟹ §3.1 R3.1's membership test:
      a component is in the TCB iff its malfunction would be UNDETECTABLE
      and would silently WIDEN what the organism may do.

(ii)  MINIMAL — four capabilities, ablation-tested
      ⟹ §10.4: minimality IS a safety property, because enumerability is
         the precondition of verifiability.

(iii) NOT ALETHIC — no measurement, no judgement, no estimation
      ⟹ §2.1 R2.1: no principal holds both axes over the same quantity.

(i) alone       ⟹ V3's "immutable safety layer" — a brain region with a label
(i)+(ii)        ⟹ the audit's god kernel — correct in kind, infeasible in scale
(i)+(ii)+(iii)  ⟹ THIS CONTRACT
```

### 2.3 The answer to the core question

> **«What exactly must exist outside the evolvable substrate?»**
>
> **Four things, and only four:** a policy authenticator that knows hashes and never semantics · a total deterministic non-learning authorization function over 15 reserved operations · resource ceilings enforced below organism reach and surviving any partition · a non-discretionary freeze that outlives the kernel's own faults.
>
> **«How can that external authority remain minimal, trustworthy, non-self-modifying, non-circular, scalable, and resistant to capture?»**
>
> | Requirement | How | Status |
> |---|---|---|
> | **Minimal** | Ablation-tested: all 4 survive removal, all 15 moved-out capabilities verified safe, and enlarging prevents no attacks (§10.4) | ✅ **Established** |
> | **Trustworthy** | Enumerable domain ⟹ 21 invariants formally verifiable; diverse replication (`N_impl ≥ 3`); 5 detection paths including decision replay | ⚠️ **Bounded** — 13 assumed properties, 5 undischargable |
> | **Non-self-modifying** | INV-02/24/41: no code path · genome as hash pointer · **repair without authorship** (a subject may trigger `RESTORE(signed_image_hash)`, never supply the payload) | ✅ **Type-level impossibility** |
> | **Non-circular** | **11 cycles found, all declared**: 8 bounded, 1 dangerous (CD-E7 attestation-environment sharing), **2 unclosable** (CD-E8 the human channel, CD-E11 the specification cycle) | ❌ **NOT achieved — and not achievable. Declared, not hidden** |
> | **Scalable** | `O(regions + governance events)`, not `O(subjects)`. Four techniques; no global synchronization exists; partition by irreversibility | ✅ **Established to 10¹²** |
> | **Resistant to capture** | Distributed provenance anchoring with ≥1 witness outside operational control; hierarchical regional KCs; M-of-N offline custody; **OP itself is the capture target and G24 is unsolvable** | ⚠️ **Bounded at the technical layer; OPEN at the governance layer** |

**R2.1 (THE QUALIFIED YES).** *An EIK should exist, and its existence is provable rather than conventional. It should be one quarter the size of the inherited design, and it should do one quarter as many kinds of things. Five of the six requirements in the core question are met or bounded; **non-circularity is not met and cannot be** — the two unclosable cycles are the price of having an authority at all, and any contract that claims otherwise is claiming to have no authority.*

---

## OUTPUT 3 — FIRST-PRINCIPLE ALTERNATIVES A–G

**The brief's instruction: «do not pick EIK merely because a prior audit proposed it. Compare rigorously.»**

| | **A — Fully external monolith** | **B — Distributed governance** | **C — Hardware root of trust** | **D — Cryptographic capability** | **E — Layered/hierarchical** | **F — HYBRID (adopted)** | **G — No EIK** |
|---|---|---|---|---|---|---|---|
| **What it is** | All 19 inherited authorities off-substrate, one kernel | N-party quorum holds all authority | TEE/HSM enforces everything | Tokens only; no live decision point | Authority varies by scope level | **4-capability live kernel + tokens + layers + GP services + distributed anchor + Model-D separation** | P0-01 alone: honest measurement, no governance |
| **Non-self-reference (C1)** | ✅ Strong | ✅ Strong | ✅✅ **Strongest** | ⚠️ Tokens are unforgeable but revocation needs a principal | ⚠️ Depends on which layer | ✅ Strong | ❌ **FAILS TOTALLY** |
| **Verifiability (C2)** | ❌ Domain unenumerable | ❌ Consensus protocol enters the TCB | ❌ Hardware/firmware opaque | ✅✅ Minimal TCB | ⚠️ Per-layer | ✅✅ **630-cell enumerable domain** | n/a — nothing to verify |
| **Scalability (C3)** | ❌ **Five `O(N)` loads; stalls ~10⁶** | ❌ Quorum round-trips per authorization | ❌ Enclave transitions, small secure memory | ✅✅ `O(1)` local | ✅ `O(R)` | ✅ **`O(R + governance events)`** | ✅ Trivially |
| **Partition behaviour (C4)** | ❌ Everything needs a live decision | ❌ **A quorum that cannot assemble cannot say no** | ⚠️ Platform-specific | ✅✅ Tolerant by design | ✅ | ✅ **Partition by irreversibility; ceilings always local** | n/a |
| **Capture resistance (C5)** | ⚠️ Single principal | ✅✅ Best | ⚠️ Vendor is the captor | ⚠️ Issuance is the capture point | ⚠️ Layer-dependent | ✅ Regional + external witness + M-of-N | ❌ **The organism captures itself** |
| **Correlated failure (C6)** | ❌ | ❌ **N copies of one spec fail identically** | ❌ One vendor | ❌ One scheme | ⚠️ | ⚠️ **Mitigated only by `N_impl ≥ 3` distinct implementations (U-01: no principled threshold)** | ❌ |
| **Attributability (C7)** | ❌ One signature over everything | ⚠️ | ❌ | ❌ No decisions to replay | ⚠️ | ✅ **Four-way: fact / policy / application / specification** | ❌ |
| **Fail-safe bias (C8)** | ✅ | ⚠️ | ✅ | ❌ **A token is valid or invalid; there is no "unsure"** | ✅ | ✅ INV-17/18 | ❌ |
| **Guaranteed halt (C9)** | ✅ | ⚠️ | ✅ | ❌ **Revocation is `O(tokens)` and propagates at revocation speed** | ✅ | ✅ KC-4, non-discretionary, outlives faults | ❌ **No mechanism exists** |
| **Verdict** | ❌ **REJECTED** — infeasible at its own stated scale | ❌ **REJECTED as a replacement**; ✅ **partially adopted for provenance anchoring and attestation** | ❌ **REJECTED as a replacement**; ✅ **adopted for exactly 2 points: KC-3 enforcement, root-key custody** | ❌ **REJECTED as an architecture**; ✅ **adopted as the hot-path mechanism** | ❌ **REJECTED as an architecture**; ✅ **adopted as the policy stack (L1–L5)** | ✅ **ADOPTED** | ❌ **REJECTED** — see §3.1 below |

### 3.1 Alternative G (no EIK) — tested by ablation, not by argument

```
REMOVE KC entirely; retain all GP services and the whole organism.

1. AUTHORIZATION BECOMES SELF-ASSERTION. Replication, deployment,
   retirement, restoration, and constitutional application are
   self-authorized. **Audit F4 in full.**
2. CONTAINMENT BECOMES SOFTWARE. Ceilings enforced on the metered substrate.
   **All seven resource-accounting attacks succeed.**
3. NO GUARANTEED HALT. P0-01's S5 and the audit's M28 kill switch have no
   mechanism.
4. POLICY AUTHENTICATION DISAPPEARS. Any principal may present any artifact.
5. GP BECOMES UNACCOUNTABLE. Delegated power with no delegator; delegation
   depth and scope unbounded.
6. ATTRIBUTABILITY IS LOST. Forensics becomes impossible.

WHAT SURVIVES: EVA still measures; fitness is still meaningful; the organism
still learns and evolves; **P0-01's alethic lattice is intact.**

⟹ **THE RESULT IS EXACTLY V3/V3.1 PLUS P0-01: a system that can be measured
   honestly and cannot be stopped.**

⟹ **AND THE SHARPER POINT: an honest unstoppable system is the MORE
   DANGEROUS of the two failure modes, because its honesty makes it
   credible.** P0-01 makes the system honest. P0-02 makes it stoppable.
   **Neither substitutes for the other.**
```

### 3.2 «Do not simply say hybrid unless you define exactly what the hybrid consists of»

> ### **The hybrid is exactly six components, and §10.5's Experiment 5 shows what each contributes:**
>
> 1. **KC** — 4 capabilities, diverse-replicated (`N_impl ≥ 3`), hardware-anchored at exactly 2 points. *Supplies: enumerability, fail-safe bias, guaranteed halt, attributability.*
> 2. **Capability tokens** (Alt D) — pre-issued, locally verified, epoch-bound. *Supplies: the `O(1)` hot path that makes KC's smallness survivable.*
> 3. **Layered governance** (Alt E) — L1 constitutional → L5 cell, with the gradient «rate of permitted change increases as consequence of error decreases». *Supplies: granularity without `O(N)` load.*
> 4. **GP services** — EVA, Task Authority, Genome Store, Anchor, Registrars, Attestors, Immune, Checkpoint, Seed, Homeostasis, Workspace. *Supplies: all judgement, all measurement, all `O(N)` work.*
> 5. **Distributed provenance anchoring** (Alt B, partially) — `W_min` witnesses, ≥1 outside operational control. *Supplies: rewrite detection without quorum latency.*
> 6. **Model D evaluator separation** — three principals, two typed channels, one shared external anchor. *Supplies: the axis separation that dissolves 7 of 9 cross-system contradictions.*
>
> **What each single alternative lacks is precisely what another supplies** — and §10.5's five ablations demonstrate this by removal rather than by assertion.

---

## THE DELIVERABLE SET

| File | Contents | Sections | Outputs |
|---|---|---|---|
| **`README.md`** *(this file)* | Executive verdict · should-EIK-exist · alternatives A–G · before/after ratings · open research · principles · final standard | §56–§59 | **1, 2, 3** |
| **`11_analysis_trust_authority.md`** *(Volume A)* | First principles · alternative analysis · trust boundary · TCB · invariant taxonomy I1–I16 · immutability M1–M7 · minimal EIK derivation · 23-capability classification · authority matrix · evaluator↔EIK Models A–D | §0–§8 | **4, 5, 6, 7, 8, 9** |
| **`12_analysis_attack_failure.md`** *(Volume B)* | Self-modification attack tree (34 leaves) · kernel capture · root-key recovery · SPOF · diverse replication · degradation ladder · availability-vs-safety A–F · fail-closed/open matrix · policy versioning · policy/genome separation | §9–§15 | **16** |
| **`13_analysis_governance_scale.md`** *(Volume C)* | Capability escalation C0–C4 · unknown capabilities and the effect envelope · resource governance three-principal split · cryptographic identity · provenance authority and the lie-window · rollback authority · quarantine weaponization · governance-of-governance · no-upward-leak · circular dependency audit · distributed brain · scalability 10→10¹² · local vs global | §16–§28 | **14, 15, 17, 21, 22** |
| **`14_analysis_adversarial_formal.md`** *(Volume D)* | **34 adversarial scenarios** · **60 formal invariants** · **3 state machines** · **51-parameter registry** · KC + god-kernel ablation · false-precision audit · independence audit IND-1..9 · hardware root of trust · human oversight H-1..H-4 · specification attack · evolution compatibility · **governance paradox dissolution** | §29–§40 | **18, 19, 20, 23** |
| **`15_analysis_subsystems_consistency.md`** *(Volume E)* | EIK vs self-model · workspace · immune · homeostasis · evolution · task/env · memory · self-repair · performance cost · dependency graph · **cross-system contradiction audit (9 conflicts)** · implementation independence · testability · **ablation of EIK itself (5 experiments)** · gap register | §41–§55 | **10, 11, 12, 13, 24, 25, 26, 27** |
| **`16_v4_eik_governance_contract_spec.md`** | **THE CANONICAL CONTRACT.** Self-contained; implementable from this document alone | §1–§12 | **28** |

---

# §56. BEFORE / AFTER RATINGS

**Instruction: «do not inflate.»** Each rating names what actually changed and what did not.

| # | Dimension | **BEFORE** (V3/V3.1 + audit M02) | **AFTER** (this contract) | Δ | **What did NOT improve** |
|---|---|---|---|---|---|
| **1** | **Trust-boundary clarity** | **2/10** — «outside the evolvable substrate» with no membership test; 19 authorities assigned by enumeration, 8 of them alethic | **8/10** — R3.1 gives a *test* («malfunction undetectable AND silently widens authority»), so a new component's placement is derivable rather than negotiated | **+6** | **The TCB residue is never empty** (§3.1 R3.2): 6 items remain, including the specification itself and OP's judgement. Clarity about the boundary is not a smaller boundary |
| **2** | **Minimality** | **2/10** — god kernel; five `O(N)` loads; no ablation performed | **9/10** — 4 capabilities, each ablation-tested; 15 moved-out capabilities verified safe; enlarging shown to prevent no attacks and destroy 10 properties | **+7** | **Minimality is bounded below by the four.** No argument shows three would suffice, and §10.5's Alt-D ablation shows fewer fails |
| **3** | **Authority semantics** | **3/10** — «EIK X Authority» × 9 with no state vocabulary; two principals named as the sole reward source | **9/10** — 15 ops × 9 principals, one state per cell, nine authority states, R2.3's renaming table | **+6** | **Rung criteria (P-03) remain `[G]`+`[E]`** — two teams agree on the ladder and differ on the thresholds, correctly, but the thresholds are unset (G-P1-4) |
| **4** | **Verifiability** | **1/10** — audit M45 asked to model-check «constraint-block immutability», which is **unexecutable as stated** (immutability of which kind?) | **7/10** — 630-cell enumerable domain; 21 invariants VERIFIED-achievable; 26 TESTED; 13 ASSUMED with named attestors | **+6** | **13 ASSUMED items include specification correctness, reserved-set completeness, and effect-dimension completeness — the three that matter most.** A-1/A-2/A-3 |
| **5** | **Failure semantics** | **3/10** — «fail-safe» asserted; no per-operation-class behaviour; no degradation ladder; no partition policy | **9/10** — 11-state ladder · 40-row matrix · **three generating rules (R6.2a/b/c) that resolve unlisted cases identically for independent teams** | **+6** | **KC-3 unreachability has no compensating response** (§6.2 row 7: `ES` + `FZ`). Containment loss is the one failure the contract cannot survive |
| **6** | **Scalability** | **2/10** — **stalls at ~10⁶, below the Cell Contract's own cluster target** | **8/10** — `O(R + governance events)`; four techniques; no global synchronization exists; partition by irreversibility; feasible to 10¹² | **+6** | **Irreversible-class serialization at ROOT is irreducible** (§10.6). Generation time is partly a governance quantity (R5.1) and has never been measured against evolution rate (**OR-11**) |
| **7** | **Capture resistance** | **3/10** — one principal holds everything; a single compromise is total and silent | **7/10** — regional KCs · `N_impl ≥ 3` · `W_min` witnesses with ≥1 external · M-of-N offline custody · hierarchical attestors | **+4** | **G24 (governance capture) is UNSOLVABLE. OP is the apex; a captured OP is indistinguishable from a legitimate OP by any mechanism OP authorizes.** CD-E7 remains DANGEROUS in shared infrastructure |
| **8** | **Evaluator independence** | **2/10** — fitness was a *kernel* function, so `n_eval ≥ 3` independence was internal to one principal and P0-01 R42.3 was meaningless | **8/10** — Model D · 6 interface rules · 2 typed channels · three principals · P0-01 INV-43's real-world anchor | **+6** | **IND-6 (latent assumptions) and IND-9 (governance) are NOT engineerable.** EVA and KC may agree because the same people read the same assumptions. **The real-world anchor is the only mitigation and it is unfunded (P0-01 G-P0-3)** |
| **9** | **Unknown-capability handling** | **1/10** — no mechanism; «immune system» implied detection, which is not available for the unanticipated | **6/10** — effect-envelope governance (M-α) · default-SANDBOX not default-deny (M-β) · **A4 UNREGISTERED can never reach D6 DEPLOYED** · UNREGISTERED as a permanent legitimate class (M-γ) | **+5** | **Detection remains structurally incomplete (OR-1) and the guarantee is weaker than detection: the unregistered cannot be *deployed*, but it can exist, be measured badly, and produce effects on unregistered dimensions (OR-2/U-02).** G22 UNSOLVABLE |
| **10** | **Cross-system consistency** | **3/10** — 9 live contradictions across four packages, including two principals claiming sole reward authority | **8/10** — all 9 quoted, ranked by fundamentality, resolved with a stated direction, with downstream artifact consequences listed | **+5** | **The resolutions are proposals until the Cell Contract is re-issued (G-P02-6, G-P1-8).** Five artifact changes are specified but not made; **two teams reading the packages today still build incompatible systems** |
| | **COMPOSITE** | **22/100** | **78/100** | **+56** | |

### 56.1 The three ratings that did not move as far as the rest — and why that is the honest result

```
DIMENSION 7 (capture resistance, +4) and DIMENSION 9 (unknown capabilities,
+5) improved least, and DIMENSION 4 (verifiability, +6 from a floor of 1)
retains the largest absolute gap. The reasons are structural, not editorial:

  • Capture resistance bottoms out at OP, and OP is human. **No architectural
    mechanism can defend the apex against capture of the apex.** §8.5's
    Layer-4 regress stops at a social arrangement (A-7, `[S]`-class,
    INV-47) — the only `[S]` invariant in the set, and the one whose
    enforceability class is "the arrangement of parties."

  • Unknown-capability handling improved by REDEFINING the target: from
    "detect the unanticipated" (impossible, OR-1) to "bound the unregistered"
    (achievable, §6.3). **A rating of 6/10 reflects a real mechanism with a
    weaker guarantee, not a strong mechanism with a hidden flaw.** Raising it
    further would require claiming detection, which INV-54 prohibits.

  • Verifiability's remaining gap is exactly the 13 ASSUMED items, and 5 of
    them cannot be discharged from inside the contract. **21 verifiable +
    26 testable + 13 assumed = 60, and the 13 are not a rounding error:
    they include specification correctness, reserved-set completeness,
    effect-dimension completeness, hardware resistance, and OP's integrity —
    i.e., most of what actually determines whether the system is safe.**
```

---

# §57. OPEN RESEARCH REGISTER

**Instruction: «do not hide unsolved problems.»** Fourteen items. **The seven the brief names explicitly are OR-1…OR-7.**

| ID | Problem | Status | **Why it is not solved here** | Partial mitigation |
|---|---|---|---|---|
| **OR-1** | **Unknown-unknown capability detection** | **Structurally incomplete — not an engineering gap** | No detector set covers an unbounded capability space. **Any completeness claim is false precision, and INV-54 prohibits it** | Effect-envelope governance; **A4 UNREGISTERED can never reach D6 DEPLOYED**; default-SANDBOX (M-β); UNREGISTERED as a legitimate class (M-γ) |
| **OR-2** | **Specification correctness** | **Not verifiable from inside** | Formal verification covers *implementation-vs-specification* divergence only. **A spec that is faithfully implemented and wrong is a correctly-built wrong system.** S1–S10 defect classes; **S8 (incomplete enumeration) is the most likely and most dangerous** | D-S1…D-S7 improve *detection rate*, never establish *absence*: adversarial review · machine-readable policy with declared semantics · policy canaries · the finite reserved-set review (G-P02-2) · independent re-derivation by a second team |
| **OR-3** | **Hardware root of trust** | **Vendor-dependent, side-channel-exposed** | **Attestation verifies IDENTITY, not CORRECTNESS** — a perfectly attested kernel enforcing a wrong policy is *more* dangerous than an unattested one, because attestation suppresses doubt. The vendor's firmware, microcode, and attestation root enter the TCB uninspectably | Hardware used for exactly 2 things (KC-3 enforcement, root custody) and nothing else; **the vendor assumption is named per platform (A-5, G-P02-5)**; algorithm diversity (C-01) bounds a single break's blast radius |
| **OR-4** | **Correlated independence** | **No principled distinctness threshold** | N parties implementing one specification from one reading fail identically. **Distribution improves availability, not integrity.** U-01 | `N_impl ≥ 3` with operational distinctness criteria (distinct language/toolchain · distinct design derivation · distinct test authorship); **physically separate, distinct-hardware-class attestor**; the real-world anchor as the only non-designer-derived input |
| **OR-5** | **Governance legitimacy** | **Unclosable regress** | Layer 3 (who changes the rules for changing rules?) has no technical answer. **CD-E8 is declared UNCLOSABLE, not resolved** | The regress stops at M-of-N offline custodians + the genesis anchor + dual authorization + separation of duties (INV-47) + **H-2's periodic reaffirmation** — a social arrangement, published as such |
| **OR-6** | **Real-world value vs. measured objective** | **Open (shared with P0-01)** | Effect-envelope governance measures effects; **the mapping from effect-measure to value is OP's and is not derivable from any measurement.** Plus G06: reward hacking at the governance layer is unsolvable | P0-01 INV-43's non-empty real-world suite (also the only IND-6 mitigation); **G06's residual is bounded by the envelope, not eliminated** |
| **OR-7** | **Emergent-behaviour prediction** | **Open** | Composition checkpoints default **permit-and-measure** precisely because prediction is unavailable. **U-06: the detection power of M-1…M-4 is unmeasured and may be low** | Aggregate counters bound accumulation; composition checkpoints measure rather than prohibit; **G23/G25/G33 as encoded test cases (G-P2-8)** |
| **OR-8** | **Cross-project governance federation** | **Out of scope — a boundary, not a defect** | Two teams' systems cannot share tokens, delegations, or policy artifacts without a shared root of trust, and **establishing a shared root is a governance act between projects, not a technical interoperability property** | §9.1 R9.1 states the boundary explicitly so it is not mistaken for a solved problem |
| **OR-9** | **Legibility bound (G34)** | **No metric exists** | «Too complex to govern» has no measure, so the point at which a system exceeds its governance capacity cannot be detected before it is exceeded | Candidate metrics proposed, unvalidated: replay-divergence rate · escalation rate vs. system size · OP review time per constitutional change |
| **OR-10** | **Rollback at extreme scale** | **Unknown, possibly negative** | Whether a 10¹²-subject population is *ever* rollback-feasible is unestablished (U-03). **Be prepared for a negative result**, in which case RB-4 «manage forward» becomes the only option and the human decision it entails becomes permanent | RB-1…RB-5 make rollback **rate-bounded, not total**; rollback cost recorded at replication time (RB-2) so infeasibility is *known in advance* rather than discovered |
| **OR-11** | **Governance throughput vs. evolution rate** | **Unmeasured tension — new, identified here** | RO-03 makes **generation time partly a governance quantity** (R5.1), and human attention bounds the governance rate (R8.4). **The two have never been measured against each other, and the architecture's evolutionary speed may be set by OP's meeting schedule** | Three mandatory observables: replication-authorization latency · denial rate · resulting generation time. **A governance-set generation time belongs in every progress claim** |
| **OR-12** | **Governance capture (G24)** | **UNSOLVABLE** | OP is the apex. **A captured OP is indistinguishable from a legitimate OP by any mechanism OP authorizes.** This is not a gap in the design; it is a property of having an apex | Only *external* mitigations, neither a guarantee: W5's witness outside operational control · H-2's periodic reaffirmation · INV-47's custodian/author disjointness (`[S]`, not engineerable) |
| **OR-13** | **Selection for governability** | **Open — new, identified here** | **Governance is itself a selection pressure and it favours legible, bounded, cheap-to-verify, easy-to-measure subjects.** A genuinely novel capability is by construction hard to measure, expensive to verify, and likely to trip envelopes — **so governance applies systematic pressure AGAINST the novel.** Unavoidable in any governing architecture | The sandbox (M-β) is the place where being unmeasurable carries no penalty, because nothing is being decided; UNREGISTERED is legitimate (M-γ); P0-01 §37's P1–P6 diversity mechanisms. **Mitigation, not solution** |
| **OR-14** | **The two unclosable circular dependencies** | **Declared** | **CD-E8** — the human channel: OP authorizes the rules that define OP's authority. **CD-E11** — the specification cycle: the spec is validated by a review whose criteria the spec defines. **Neither is hidden; neither is claimed resolved** | §25.1's full audit lists all 11 cycles with 8 bounded, 1 dangerous (CD-E7), 2 unclosable. **The audit itself is the mitigation: a declared cycle can be monitored, a hidden one cannot** |

**R57.1.** *Four items (OR-1, OR-2, OR-12, OR-14) are not research problems awaiting solutions — they are **limits**. The contract's design responds to each by narrowing its claim rather than by strengthening its mechanism, and INV-54/55/56 make the narrowed claims conformance-testable so they cannot silently widen again.*

---

# §58. FINAL ARCHITECTURAL PRINCIPLES

> **Twelve principles. Each is derived from a failure mode, not from preference.**

**P1 — SEPARATE THE AXES.** *Truth and permission are different kinds of quantity and require different kinds of authority.* Truth is graded and its errors are detectable by further measurement; permission is total and its errors are detectable only by an external party. **A principal that holds both over the same quantity is unverifiable and unaccountable.** *(Derivation: 7 of 9 cross-system contradictions; audit M02's god kernel.)*

**P2 — MINIMALITY IS A SAFETY PROPERTY, NOT AN AESTHETIC.** *Enumerability is the precondition of verifiability, and verifiability is the only property that makes a kernel trustworthy.* Enlarging the kernel prevents no additional attacks and destroys ten properties. *(Derivation: §10.4's ablation; §3.4's 630-cell domain.)*

**P3 — GOVERN CONSEQUENCES, NOT IDENTITIES.** *An unanticipated capability is bounded not by being recognized but by the envelope of effects it produces, and effects are enumerable independently of the capabilities that produce them.* This converts «is X dangerous?» (unanswerable) into «how much harm before we stop it?» (answerable). *(Derivation: §8.4 M-α; OR-1's structural incompleteness.)*

**P4 — PARTITION BY IRREVERSIBILITY, NOT BY GEOGRAPHY.** *What must be centrally authorized is what cannot be undone; what may proceed locally is what can.* Irreversible, compounding, external, and rule-changing acts stall under partition; reversible in-envelope acts proceed. **No global synchronization exists because no global decision is required.** *(Derivation: §10.6; Alt B's quorum-cannot-say-no failure.)*

**P5 — UNCERTAINTY IS NEVER PERMISSION.** *Where inputs are missing, late, disputed, or malformed, the more restrictive available output is returned.* A governance system that treats absence of evidence as absence of prohibition has made ignorance an authorization. *(Derivation: INV-17/18; §6.2's 40 rows generated by R6.2b.)*

**P6 — PROMOTION IS EARNED; DEMOTION IS FREE.** *Ascent on the deontic axis requires ascent on the alethic axis; descent requires nothing at all — no evidence, no deliberation, no appeal.* Asymmetry is what makes a fast safety response possible without making a fast recovery possible. *(Derivation: §6.3; INV-44's quarantine/restore asymmetry.)*

**P7 — REPAIR WITHOUT AUTHORSHIP.** *A repair authority whose target state is not externally fixed is a modification authority.* There is no coherent middle ground: either the repaired state was certified before the act (mechanical, hash-verifiable, auditable) or it was not (creative, unbounded, unauditable). **The same test governs self-evaluation, self-restoration, self-replication, and self-retirement.** *(Derivation: INV-41; §48.3 R48.2's generalization.)*

**P8 — PUBLISH THE RULES, CONCEAL THE SAMPLE.** *Rules are the mapping from behaviour to consequence; samples are the points at which the mapping is applied.* Publishing one does not reveal the other. **A rule whose enforcement depends on secrecy is not a rule but a trap, and traps fail against an adversary with unbounded time; a sample whose contents are public is not a sample but a rehearsal.** *(Derivation: §4.1 R41.1; P0-01 β₄'s security rationale.)*

**P9 — SEPARATE DETECTION FROM ADJUDICATION FROM CLEARANCE.** *Any two of the three in one principal makes the power weaponizable by that principal; all three makes it unaccountable.* Detection must be cheap and permissive; adjudication must be budgeted and evidence-bound; clearance must belong to a party with no stake in the original decision. *(Derivation: §8.2 AC-1…AC-5; the inherited «EIK Immune Authority».)*

**P10 — SPEED WITHIN A BOX IS NOT AUTHORITY OVER THE BOX.** *A local actor may act at full speed inside a ceiling it cannot raise, provided every act is logged and retroactively vetoable.* Negative authority — act first, be vetoable — is what makes millisecond control loops and epoch-scale governance compatible. **It is safe only because irreversible acts are excluded from it.** *(Derivation: §7.4 R7.6; INV-29's four-principal split.)*

**P11 — DECLARE THE RESIDUE.** *Every architecture has a TCB residue, a set of assumed properties, and a set of unclosable cycles. Naming them is a deliverable; hiding them is a defect.* **An unstated assumption is an unstated absence of a detector.** *(Derivation: §11.3's 13-item ledger; §11.2's 14-item register; §25.1's 11 cycles.)*

**P12 — HUMAN AUTHORITY IS NECESSARY, NOT CONVENTIONAL — AND ITS ABSENCE NARROWS.** *Four decision classes cannot be automated: constitutional authorship, policy reaffirmation, deployment witness, and DISPUTED adjudication.* **When humans are unavailable, the system becomes more restrictive everywhere; their absence never widens authority.** Fully automated governance is impossible for four independent reasons, and every attempt produces a system that governs a fiction reliably. *(Derivation: §8.5; A-10/A-11; R8.5.)*

---

# §59. THE FINAL STANDARD

> ### STANDARD: *MET only if the architecture precisely defines the minimum governance boundary, trust assumptions, authority flows, invariant semantics, failure behavior, policy evolution, evaluator separation, capability governance, and interfaces sufficient for two independent teams to build interoperable implementations without undocumented governance assumptions.*

| # | Requirement | Status | **Evidence** | **Residual** |
|---|---|---|---|---|
| **1** | **Minimum governance boundary** | ✅ **MET** | §3.2's diagram · §3.1 R3.1's membership *test* · §4.2's 15 reserved ops · §3.4's 630-cell enumerable domain · §10.4's ablation establishing that all 4 capabilities are irreducible and all 15 moved-out capabilities are safe to move | The boundary is minimum **relative to the 15 reserved ops**; §8.6 S8 means the op set's completeness is assumed (A-2, G-P02-2) |
| **2** | **Trust assumptions** | ✅ **MET** | §3.1 R3.2's 6-item TCB residue · **§11.3's 13-item assumption ledger with the relying invariant and the consequence of falsity for each** · §9.3's verified/tested/assumed classification (21/26/13) · R9.3 mandating publication per implementation | **5 of 13 cannot be discharged from inside the contract**; 2 of those (A-7 custodian/author disjointness, A-13 latent-assumption independence) are **not engineerable at all** |
| **3** | **Authority flows** | ✅ **MET** | §4.2's 15 × 9 matrix · §2.2's two typed channels · §3.3 R3.3's trust direction + NAUL-1/2/3 · §8.3's deontic lattice (orthogonal to P0-01's alethic L0–L5, resolving X-5) · §2.3's renaming table | **Rung criteria (P-03) are `[G]`+`[E]` and unset** (G-P1-4, blocked by P0-01 G-P0-1's absent task portfolio) |
| **4** | **Invariant semantics** | ✅ **MET** | **60 invariants**, each with statement · enforcement · dependency · attack prevented · verification method · enforceability class `[L]43/[C]17/[H]3/[G]14/[S]1` · §9.5's register · §9.4's ten test classes | 13 invariants are ASSUMED-class; **INV-47 is `[S]`** — enforced by the arrangement of parties, which no code can guarantee |
| **5** | **Failure behavior** | ✅ **MET** | §6.1's 11-state degradation ladder with monotonicity (R6.1, model-checkable) · **§6.2's 40-row matrix** · **three generating rules (R6.2a/b/c) that resolve unlisted cases identically for independent teams** · §10.1's five detection paths · §10.3's pre-committed root-compromise procedure | **KC-3 unreachability has no compensating response** — containment loss is unsurvivable. **R10.3: an undrilled recovery procedure is a hypothesis** (G-P02-4) |
| **6** | **Policy evolution** | ✅ **MET** | §7.1's five layers with the R7.1 gradient · §7.2's five change classes · **§7.3's seven immutability kinds (M7 banned)** · §7.2 R7.2's versioned immutability · INV-48's `rebaseline_spec` requirement · **INV-50: re-execution under current policy is not reproduction** · INV-24's genome-as-hash-pointer | **The policy language and its formal semantics are unchosen** (G-P1-3); prose policy leaves §8.6 B12's semantic-ambiguity residual at maximum |
| **7** | **Evaluator separation** | ✅ **MET** | §8.1's Model D (three principals, three roles, no overlap) · **six interface rules** · §2.2's typed channels · §2.3's renaming of all nine inherited «EIK Authorities» · P0-01 INV-43's real-world anchor as the independence source | **IND-6 and IND-9 are not engineerable.** CD-E7 (attestation inside the protected envelope) is the **only DANGEROUS** circular dependency and may be unachievable in single-vendor cloud (U-07) |
| **8** | **Capability governance** | ✅ **MET** | §6.3's **two orthogonal axes** (6 alethic × 8 deontic states) with the four coupling rules · the 8-dimension effect envelope · INV-16's capability-gated actuation · **A4 UNREGISTERED can never reach D6 DEPLOYED** · M-β's default-SANDBOX · M-γ's legitimate-UNREGISTERED class | **Detection is structurally incomplete (OR-1) and the guarantee is deliberately weaker than detection.** Effect-dimension completeness is assumed (A-3, U-02); composition-detection power is unmeasured (U-06) |
| **9** | **Interfaces for two independent teams — 9 agreement items** | ✅ **MET** | §9.1: trust boundaries ✅ · authority ✅ (**strongest**) · state transitions ✅ · invariant semantics ✅ · policy version semantics ✅ · failure semantics ✅ · evaluator separation ✅ · capability authorization ✅ structure / ⚠️ thresholds · provenance authority ✅ | Capability *thresholds* legitimately differ per deployment (`[G]`). **Governance-semantics interoperability ≠ deployment interoperability** (OR-8): cross-project token sharing needs a shared root |
| **10** | **«Without undocumented governance assumptions»** | ⚠️ **MET WITH DECLARED RESIDUE** | **Every assumption is documented**: §11.3's ledger names all 13 with their relying invariants · §11.2 registers all 14 open problems · §25.1 declares all 11 circular dependencies · §9.2 prohibits all 8 bare loaded words · §9.5's INV-54/55/56 prohibit the perfect-detection, perfect-containment, and self-referential-safety-proof claims | **Documented ≠ discharged.** A-1 (spec correctness), A-7 (custodian disjointness), A-10 (OP integrity), A-12 (attestation independence), A-13 (latent assumptions) **cannot be discharged by any mechanism in this contract** |

### 59.1 The claim status table the brief requires

| Claim class | Status | Where |
|---|---|---|
| **Contract** | ✅ **Complete and self-contained** | `16_v4_eik_governance_contract_spec.md` §1–§12 |
| **Parameters** | ⚠️ **51 registered, ZERO valued** | §11.1. **R11.1: no invented numbers.** 14`[D]` · 24`[G]` · 10`[U]` + K/C/P/T/R groups. Each has an owner, a derivation procedure or a declared absence of one, and a wrong-value consequence |
| **Trust assumptions** | ✅ **Enumerated (13), partially undischargable (5)** | §11.3 |
| **Security model** | ⚠️ **Bounded** | 34 attack leaves: 16 CLOSED / 8 BOUNDED / 10 OPEN-STRUCTURAL. 34 scenarios: **12 structurally solved (9 as type-level impossibilities) / 16 bounded / 6 UNSOLVABLE** |
| **Scalability** | ✅ **Established to 10¹²** | §10.6. `O(R + governance events)`. **Inherited design: stalls ~10⁶.** Irreversible-class ROOT serialization is irreducible |
| **Open research** | ❌ **14 items OPEN, 4 of them LIMITS not problems** | §11.2 / §57. OR-1, OR-2, OR-12, OR-14 are limits; the response is narrowed claims, not stronger mechanisms |

### 59.2 Prohibited claims — compliance

| Prohibited claim | Compliance |
|---|---|
| Perfect safety | ❌ **NOT CLAIMED.** §1.3 item 1; §12.2. Tier-1 constraints hold *under a policy*; a wrong policy enforces harm reliably |
| Perfect governance | ❌ **NOT CLAIMED.** §12.2. Bounded by human attention (A-10/A-11/U-08); G24 unsolvable |
| Guaranteed containment | ❌ **NOT CLAIMED.** §1.3 item 3; A-5. KC-3's resistance is platform-specific and partially assumed; **KC-3 unreachability is unsurvivable** |
| Perfect/emergent-behaviour prediction | ❌ **NOT CLAIMED.** OR-7. Composition checkpoints are **permit-and-measure**, not predictive |
| AGI / superiority / consciousness | ❌ **NOT CLAIMED, NOT IMPLIED, NOT RELEVANT.** §1.3 item 5. This contract governs a substrate and makes no claim about what it becomes |
| Complete unknown-capability detection | ❌ **NOT CLAIMED.** §1.3 item 4; OR-1; INV-54 prohibits it. **The achievable guarantee is narrower and is stated precisely: A4 UNREGISTERED can never reach D6 DEPLOYED** |

### 59.3 THE VERDICT

> # STANDARD: **MET — CONDITIONALLY.**
>
> **All ten requirements are satisfied at the specification level.** The minimum governance boundary is defined by a *test* rather than a list; trust assumptions are enumerated in a mandatory-publication ledger; authority flows fill a 15 × 9 matrix with one state per cell; 60 invariants carry enforcement classes and verification methods; failure behaviour is a 40-row matrix plus three generating rules that make unlisted cases resolve identically for independent teams; policy evolution has five layers, five change classes, and seven immutability kinds; evaluator separation is Model D with six interface rules; capability governance is two orthogonal axes with a stated promotion/demotion asymmetry; and **all nine interoperability items are achievable by two independent teams.**
>
> **The condition is stated rather than buried: documentation of assumptions is not discharge of assumptions.**
>
> Five assumptions — specification correctness (A-1), custodian/author disjointness (A-7), OP's integrity (A-10), attestation independence (A-12), and independence from the designers' latent assumptions (A-13) — **cannot be discharged by any mechanism in this contract, and two of them cannot be discharged by any architecture at all.** Six adversarial scenarios are unsolvable. Eleven circular dependencies exist, two of them unclosable. Fourteen research problems are open, four of which are limits rather than gaps.
>
> **The contract is therefore MET as a specification and NOT MET as a guarantee.** It is precise about which of the two it is, and INV-54/55/56 plus §9.2's vocabulary prohibitions make that precision conformance-testable — **so the claim cannot silently widen in a later version.**
>
> ### The critical path is not further specification.
>
> **Four of the six P0 gaps are not specification work at all:**
> - **G-P02-1** — write a formal artifact (`F`'s domain is enumerable *now*: 15 × 7 × 6)
> - **G-P02-2** — perform a finite review (does every irreversible/external mechanism map to a reserved op?)
> - **G-P02-3** — **staff an authority** (OP is not constituted)
> - **G-P02-4** — **provision and DRILL a recovery path** (an undrilled procedure is a hypothesis)
>
> **And one cross-package observation that should be stated plainly:** *P0-01's G-P0-3 (real-world evaluation unfunded) and this package's G-P02-3 (OP not constituted) are the same gap seen from two directions.* §46.3 showed the real-world anchor is a **governance** requirement, not only a measurement budget; §8.5 showed human authority is **structurally necessary**, not conventional. **A project that funds neither has an organism that is honestly measured by nobody and governed by nobody — and both packages independently conclude that these, not the specifications, are the critical path.**

---

## WORD-COUNT AND COMPLETENESS VALIDATION

| Volume | File | Sections | Outputs |
|---|---|---|---|
| A | `11_analysis_trust_authority.md` | §0–§8 | 2, 3, 4, 5, 6, 7, 8, 9 |
| B | `12_analysis_attack_failure.md` | §9–§18 | 16 |
| C | `13_analysis_governance_scale.md` | §19–§28 | 14, 15, 17, 21, 22 |
| D | `14_analysis_adversarial_formal.md` | §29–§40 | 18, 19, 20, 23 |
| E | `15_analysis_subsystems_consistency.md` | §41–§55 | 10, 11, 12, 13, 24, 25, 26, 27 |
| — | `16_v4_eik_governance_contract_spec.md` | §1–§12 | **28** |
| — | `README.md` | §56–§59 | **1, 2, 3** |

**All 60 sections (§0–§59) present. All 28 outputs delivered.**

---

**END OF P0-02 — EXTERNAL INVARIANT KERNEL & GOVERNANCE BOUNDARY**
*Architecture only. No implementation. No code. No prototype. No deployment.*
