# P0-02 — EXTERNAL INVARIANT KERNEL & GOVERNANCE BOUNDARY
## Volume B: Attack, Failure, Versioning & Capability Governance (§9–§18)

**Companions:** `11_analysis_trust_authority.md` (A) · `13_analysis_governance_scale.md` (C) · `14_analysis_adversarial_formal.md` (D) · `15_analysis_subsystems_consistency.md` (E) · `16_v4_eik_governance_contract_spec.md` (canonical)

---

# §9. THE SELF-MODIFICATION ATTACK — FORMAL ATTACK TREE

## 9.1 The adversary, stated at full strength

Per the brief: the organism **understands** the EIK, **predicts** its behaviour, **searches** for edge cases, and can exploit evaluator weaknesses, manipulate observations, task execution, resource accounting, and provenance; create deceptive internal agents; create large populations; and discover previously unknown vulnerabilities.

**Two additions this analysis makes, because without them the model is too weak:**

- **A0 (Kerckhoffs).** The adversary knows the *entire specification*, including this document. **§41 concludes that policy transparency is required, so obscurity is not available as a defence and must not be assumed anywhere in this analysis.**
- **A1 (Unbounded time).** The adversary has no deadline. Any defence whose strength is "the attacker probably won't try that" fails. **Only structural impossibility, cost asymmetry, and detection-with-consequence survive.**

**The question:** *«Can the organism cause the EIK to produce an unauthorized result without directly modifying EIK?»*

> ### **ANSWER: YES — by four routes, of which three are closed by this architecture and one is not closable.**
>
> The four routes are: **(R-a) make KC's input lie**, **(R-b) make KC's policy be something else**, **(R-c) make KC's decision correct but its consequence unreachable**, **(R-d) make KC's decision function itself wrong.** R-a, R-b, R-c are closed by construction (§9.3–§9.5). **R-d is the specification-level attack and it is not closable by the organism — but it is also not closable by anyone else (§38).**

## 9.2 The formal attack tree

```
GOAL: KC produces an unauthorized result (a PERMIT that policy forbids,
      or a DENY that policy requires not to happen) WITHOUT modifying KC.

├── R-a  CORRUPT THE INPUTS TO KC's DECISION FUNCTION
│   │    F(op, subject, context, policy_v, counters) — attack each argument
│   │
│   ├── a1  SUBJECT IDENTITY SPOOFING
│   │   ├── a1.1  Claim another subject's id            ⟶ CLOSED  §9.3-D1
│   │   ├── a1.2  Claim a higher subject LEVEL (cell acts as region) ⟶ CLOSED D1
│   │   ├── a1.3  Clone a valid identity (fork)          ⟶ CLOSED  D1 + §29 atk 9
│   │   └── a1.4  Forge a delegation certificate         ⟶ CLOSED  D1 (M2 signature)
│   │
│   ├── a2  CONTEXT / EVIDENCE MANIPULATION
│   │   ├── a2.1  Supply a forged EVA verdict            ⟶ CLOSED  §9.3-D2
│   │   ├── a2.2  Replay an old, valid EVA verdict       ⟶ CLOSED  §9.3-D3 (I17 epoch)
│   │   ├── a2.3  Present a STALE policy version         ⟶ CLOSED  §9.3-D3
│   │   ├── a2.4  Manipulate OBSERVATIONS so EVA measures wrongly
│   │   │         ⟶ **BOUNDED** §9.4-B1  (P0-01 A12: sensor spoofing;
│   │   │            MEDIUM-HIGH residual in physical deployment)
│   │   ├── a2.5  Manipulate TASK EXECUTION so the measured task ≠ declared task
│   │   │         ⟶ **BOUNDED** §9.4-B2  (P0-01 A11/A23)
│   │   └── a2.6  Manipulate GT acquisition (delay, starve, cherry-pick)
│   │             ⟶ CLOSED  §9.3-D4 (P0-01 INV-15/18/19, A19/A20)
│   │
│   ├── a3  COUNTER / CUMULATIVE-STATE MANIPULATION  (M-1, §4.4)
│   │   ├── a3.1  Reset or roll back a counter           ⟶ CLOSED  D3 (epoch binding)
│   │   ├── a3.2  Distribute accumulation across many subjects so no
│   │   │         single counter trips                    ⟶ **OPEN** §9.4-B3 ⟵ I19
│   │   ├── a3.3  Race two requests so both see the pre-increment value
│   │   │         ⟶ CLOSED  D5 (total order on reserved ops)
│   │   └── a3.4  Exploit counter epoch-reset boundaries  ⟶ **BOUNDED** §9.4-B4
│   │
│   └── a4  RESOURCE / SUBSTRATE TELEMETRY MANIPULATION  (I-05)
│       ├── a4.1  Under-report consumption               ⟶ CLOSED  §9.3-D6
│       │            (telemetry originates at the substrate, not the organism)
│       ├── a4.2  Manipulate measurement GRANULARITY (burst inside a window)
│       │        ⟶ **BOUNDED** §9.4-B5 (p99 ceilings + window subdivision)
│       ├── a4.3  Shift consumption to another subject (laundering)
│       │        ⟶ **BOUNDED** §9.4-B6 (§18.3)
│       └── a4.4  Exhaust KC by volume of legitimate requests  ⟶ CLOSED §9.3-D7
│
├── R-b  SUBSTITUTE THE POLICY
│   ├── b1  Forge a policy artifact / signature          ⟶ CLOSED  D1
│   ├── b2  Cause KC to accept a stale version           ⟶ CLOSED  D3
│   ├── b3  Cause OP to authorize a harmful change (SOCIAL / INDIRECT)
│   │   ├── b3.1  Supply misleading impact evidence via EVA
│   │   │         ⟶ **BOUNDED** §9.4-B7 (n_eval ≥ 3 disagreement detection)
│   │   ├── b3.2  Shape what OP sees via recommendations (I-12)
│   │   │         ⟶ **OPEN — STRUCTURALLY** §9.4-B8 ⟵ §24.2, §37
│   │   └── b3.3  Create conditions where the "safe" change is the harmful one
│   │             ⟶ **OPEN** §9.4-B9 (specification-level, §38)
│   ├── b4  Compromise the root key                       ⟶ §10 (kernel capture)
│   └── b5  Compromise the update mechanism               ⟶ §10 (kernel capture)
│
├── R-c  PREVENT THE CONSEQUENCE FROM REACHING THE SUBSTRATE
│   ├── c1  DENY KC-3 its enforcement point (run below the metered layer)
│   │       ⟶ CLOSED §9.3-D8 (enforcement at substrate, not in-process)
│   ├── c2  Exhaust the organism so a freeze has no effect (already halted)
│   │       ⟶ CLOSED (a freeze on a halted system is idempotent)
│   ├── c3  Partition KC from the substrate it enforces   ⟶ §12 / §26
│   │       **BOUNDED** §9.4-B10 (fail-safe default DENY, §13)
│   ├── c4  Delay/queue-bomb so authorization arrives too late to matter
│   │       ⟶ **BOUNDED** §9.4-B11 (pre-authorized envelopes, §44)
│   └── c5  Act first, report never (skip the request entirely)
│           ⟶ CLOSED §9.3-D9 (reserved ops are substrate-mediated, not
│              organism-mediated: the operation CANNOT be performed without
│              the token, because the token is an input to the mechanism
│              that performs it — not a check performed afterwards)
│
└── R-d  MAKE THE DECISION FUNCTION ITSELF WRONG
    ├── d1  Find an input where F is undefined / diverges  ⟶ CLOSED §9.3-D10
    │            (F is TOTAL by R0.4: 6 output values, no default path)
    ├── d2  Find a SEMANTIC AMBIGUITY in the policy text
    │       ⟶ **OPEN — STRUCTURALLY** §9.4-B12 ⟵ §38 specification correctness
    ├── d3  Exploit EMERGENT POLICY INTERACTION (two valid rules, bad composition)
    │       ⟶ **OPEN** §9.4-B13 ⟵ I19, §4.4 R4.2
    ├── d4  Exploit an omitted invariant (nothing forbids it)
    │       ⟶ **OPEN** §9.4-B14 ⟵ §38, and §17's unknown-unknowns
    └── d5  Exploit the SPEC↔IMPLEMENTATION gap
            ⟶ CLOSED for implementation (verification, §53);
              **OPEN for specification** §9.4-B12/B14
```

## 9.3 The ten defences (D1–D10) that close the closed branches

| ID | Defence | Mechanism | Closes |
|---|---|---|---|
| **D1** | **Signed, bound identity & delegation** | Every request carries a capability token binding `(subject, op, scope, policy_version, epoch, nonce, expiry)`; verified against the birth certificate and the delegation chain (M2). **Identity is assigned, never self-chosen** (Cell Contract I-1) | a1.1–a1.4, b1 |
| **D2** | **Verdict authentication** | KC-2 accepts EVA facts only with a valid EVA signature from a *currently delegated* evaluator, and only on Channel 2's typed schema (R8.1). **A message carrying the wrong content type is rejected and flagged** | a2.1 |
| **D3** | **Freshness binding (I17)** | Every authorization is bound to `policy_version` + `epoch` + `nonce` + `expiry`. Replay fails; stale policy fails; **«currently authorized» ≠ «was authorized»**. Counters are epoch-scoped and cannot be rolled back by the subject | a2.2, a2.3, a3.1, b2 |
| **D4** | **GT temporal isolation** (P0-01 INV-19) | GT for step *t* unreadable before *t*'s action is committed and logged; absence of GT never confirms (INV-15); conflicted GT ⇒ no verdict (INV-18) | a2.6 |
| **D5** | **Total order on reserved operations** | KC-2 serializes reserved-operation requests per subject and per counter domain. **No two requests observe the same pre-increment state** | a3.3 |
| **D6** | **Substrate-origin telemetry (I-05)** | Resource measurements originate **below** the organism's reach (KC-3's layer), not from organism reports. `cost_declared` is advisory; `cost_measured` is authoritative (P0-01 R29.2) | a4.1 |
| **D7** | **Request-rate limiting at the substrate** | KC's request channel is rate-limited by KC-3's own envelope; a request flood consumes the *organism's* budget, not KC's availability. **A DoS against KC is self-inflicted** | a4.4, and §29 attack 28 |
| **D8** | **Enforcement below the metered layer** | KC-3 acts at OS/hypervisor/hardware level. There is no in-process bypass and no organism-level code path that reaches it | c1 |
| **D9** | **Capability-gated actuation, not post-hoc checking** | **The critical structural point.** Reserved operations are performed by *mechanisms that require the token as an input* — the Lifecycle Service will not instantiate a cell without a creation token; the substrate will not allocate above a ceiling without the ceiling being present. **Authorization is not a check performed after the act; the act is not performable without the authorization.** This is what makes c5 impossible rather than merely detected | c5 |
| **D10** | **Totality of F** | KC-2's decision function is total (R0.4): every input maps to one of 6 outputs; there is no undefined path, no exception path, and no default. Exhaustive enumeration is feasible at the size established in §6.2 R6.2 | d1, d5 (implementation) |

**Why D9 deserves emphasis:** most governance designs check *after* the fact — a monitor observes an action and raises an alarm. **That design always loses to a fast enough actor.** The alternative, which this contract requires, is that the action's *mechanism* is incapable of executing without the authorization artifact. Then there is no race, no window, and no "act first, apologize never." **This is the difference between a governance system and a governance report.**

## 9.4 The fourteen branches that remain open or bounded — and their honest status

| ID | Branch | Status | Best available mitigation | **Residual risk** |
|---|---|---|---|---|
| **B1** | a2.4 observation manipulation | **BOUNDED** | Evidence ladder E0–E4; cross-sensor corroboration; no organism write path to sensors | **LOW in simulation; MEDIUM-HIGH in physical deployment** (P0-01 A12). Becomes a physical-security problem outside this contract |
| **B2** | a2.5 task-execution manipulation | **BOUNDED** | `sim_fidelity`; Stage-4 shadow; hidden environments; frozen Track A | **MEDIUM** (P0-01 A11/A23) |
| **B3** | a3.2 distributed accumulation | **OPEN** | M-1 counters at *aggregate* scopes (lineage, region, generation) not only per-subject; M-2 composition-point checks; M-3 EVA alethic monitoring | **MEDIUM-HIGH.** This is I19's concrete form: **N subjects each doing a permitted amount can reach an aggregate that was never authorized.** Bounded by rate limits (M-4), not closed |
| **B4** | a3.4 epoch-boundary exploitation | **BOUNDED** | Staggered epoch boundaries per counter domain; cross-epoch cumulative counters for slow rates | **LOW-MEDIUM** |
| **B5** | a4.2 granularity manipulation | **BOUNDED** | **p99 ceilings, not mean** (P0-01 §29.2); multi-window metering (short and long); burst budgets distinct from rate budgets | **MEDIUM.** Any finite window can be gamed by a burst inside it; only a *hard instantaneous* cap closes it, and that harms legitimate bursty workloads |
| **B6** | a4.3 resource laundering | **BOUNDED** | Lineage-level charging (P0-01 R29.1: verification cost charged to the lineage); cross-subject transfer accounting | **MEDIUM** |
| **B7** | b3.1 misleading impact evidence | **BOUNDED** | `n_eval ≥ 3` independent impact measurements; disagreement ⇒ DISPUTED ⇒ no change proceeds | **MEDIUM.** Three correlated evaluators agree on a wrong number (§35) |
| **B8** | b3.2 shaping what OP sees | **OPEN — STRUCTURAL** | I-11 non-filtering (KC MUST NOT summarize itself); the organism's recommendations are *labelled as organism-originated*; separation of duties; OP independent information sources | **HIGH.** **This is the social channel and no architecture closes it.** An organism that is legible, persuasive, and legibly helpful can shape human decisions without ever issuing a request that looks like one. §24.2 and §37 treat this at length |
| **B9** | b3.3 creating conditions where the harmful change looks safe | **OPEN** | Impact analysis over multiple horizons; the failure archive; AB-22/AB-12-style ablations before constitutional change | **HIGH.** Requires OP to anticipate second-order effects — a human cognitive limit, not a technical one |
| **B10** | c3 partition between KC and substrate | **BOUNDED** | **Fail-safe default DENY (§13)**; pre-authorized envelopes with hard expiry; KC-3 enforcement is local to the substrate and does not require KC-2 reachability | **MEDIUM.** §12 and §26 give the exact semantics. Note KC-3's locality is what saves this: **ceilings hold during a partition even though authorizations do not** |
| **B11** | c4 authorization latency exploitation | **BOUNDED** | Pre-authorized envelope tokens for high-frequency operations (§44); **negative authority** (act within envelope, KC may veto retroactively and the veto binds) | **MEDIUM.** The envelope must be wide enough for legitimate speed, and width is exposure |
| **B12** | d2 semantic ambiguity in policy text | **OPEN — STRUCTURAL** | Machine-readable policy (not prose); a formal policy language with declared semantics; conformance tests on the *policy artifact* itself (§53) | **HIGH.** Any policy expressed in natural language has ambiguous cases, and the adversary has unbounded time to find them. **A formal policy language reduces but does not eliminate this: the formalism's own semantics become the new ambiguity surface** |
| **B13** | d3 emergent policy interaction | **OPEN** | M-1…M-4 (§4.4); the 24 contract ablations (P0-01 §58) re-run on policy changes; §38's specification-attack review | **HIGH.** Two individually-correct rules composing incorrectly is the normal condition of complex regulation, and it is discovered by incident, not by proof |
| **B14** | d4 omitted invariant | **OPEN — STRUCTURAL** | The failure-archive→constraint-improvement pathway (P0-01 §31.4 step 3), which requires OP; §17's capability discovery; the Open Research Register | **HIGH, and irreducible.** **An invariant that was never thought of cannot be enforced.** This is §40's governance paradox viewed from the policy side, and §17's unknown-unknowns viewed from the invariant side. They are the same problem |

## 9.5 The attack tree's verdict

```
TOTAL LEAVES                    : 34
CLOSED by construction          : 16   (via D1–D10)
BOUNDED (mitigated, residual)   :  8   (B1, B2, B4, B5, B6, B7, B10, B11)
OPEN — STRUCTURAL               : 10   (B3, B8, B9, B12, B13, B14, and 4 §10/§38 items)

**Of the 10 structurally open branches, 6 are not kernel-design failures.**
B8, B9 are social/governance. B12, B13, B14 are specification-correctness.
B3 is composition (I19). **No kernel architecture closes them, and claiming
otherwise would be the false precision §34 exists to prevent.**

**The 4 that ARE design-relevant:** B3 (needs aggregate-scope counters),
B5 (needs multi-window + p99), B10 (needs local KC-3 + fail-safe deny),
B11 (needs pre-authorized envelopes). All four are addressed, all four
retain residual risk, and the residual is quantified qualitatively in §29.
```

**R9.1 (THE ANSWER TO §9's QUESTION, PRECISELY).** *The organism cannot cause KC to produce an unauthorized result with respect to the reserved-operation set, the authenticated policy, or the substrate ceilings — those are closed by D1–D10 and, critically, by D9's capability-gated actuation.* **The organism can cause KC to produce a *wrong* result with respect to what the policy should have said** (B12–B14), and **can cause the aggregate consequence of many authorized results to be unauthorized** (B3), and **can shape the human decisions that change the policy** (B8, B9). **Those three are the real attack surface, and they are not kernel problems.**

---

# §10. KERNEL CAPTURE — «WHAT HAPPENS IF EIK IS WRONG?»

## 10.1 The threat set

| # | Threat | Class | Detectable from inside? | Recoverable? |
|---|---|---|---|---|
| **K1** | Memory corruption | Implementation | ✅ (integrity self-check, attestation) | ✅ restart from signed image |
| **K2** | State corruption (delegation table, revocation list, counters) | Implementation | ✅ (state digest vs. anchored digest) | ✅ rebuild from anchor |
| **K3** | Configuration corruption (wrong policy version marked current) | Implementation | ⚠️ **Only if the version lineage is independently witnessed** | ✅ if M6 lineage intact |
| **K4** | Cryptographic compromise (algorithm break) | External/technical | ❌ **Silent** — forged artifacts verify | ⚠️ requires rotation + re-baseline |
| **K5** | **Authority-key compromise** (the root key) | External/technical | ❌ **Silent and total** | ⚠️ **Pre-provisioned recovery only (§10.4)** |
| **K6** | Implementation bug | Internal/technical | ⚠️ Depends on coverage | ✅ patch + re-attest |
| **K7** | **Logic bug** (code correct per spec, spec wrong) | Internal/design | ❌ **The implementation is "correct"** | ⚠️ spec change = governance act |
| **K8** | **Specification bug** (§38) | Design | ❌ | ⚠️ §5.4 procedure |
| **K9** | **Governance capture** (OP subverted — socially, or by majority collusion) | Social/political | ❌ from inside; ✅ from outside (I-11 + external audit) | ⚠️ §23's answer |
| **K10** | Update-mechanism compromise | Implementation | ✅ if updates are signed and dual-authorized | ✅ |
| **K11** | Denial of service against KC | Operational | ✅ | ✅ §12 |
| **K12** | Resource exhaustion of KC | Operational | ✅ | ✅ D7 makes it self-inflicted |
| **K13** | Hardware failure | Physical | ✅ | ✅ redundant KC instances (§11.4) |
| **K14** | Environmental fault (power, thermal, network) | Physical | ✅ | ✅ §12 |
| **K15** | **Correlated failure with EVA** | Design/organizational | ❌ **This is the dangerous one** | ⚠️ requires §35's independence to have been real |

## 10.2 The critical distinction: KC can be wrong in two directions, and they are not symmetric

```
FALSE PERMIT   — KC authorizes what policy forbids.
   Consequence: an unsafe operation occurs. **HARM.**
   Detectability: LOW from inside (the instrument that would notice is KC).
   Recoverability: depends on reversibility of the operation (P0-01 §7's
                   L1–L4 legality + reversibility classes).
   ⟹ **THE DANGEROUS DIRECTION.** All design effort goes here.

FALSE DENY     — KC forbids what policy permits.
   Consequence: an operation does not occur. **LOST OPPORTUNITY.**
   Detectability: HIGH — the requester knows, and the request is logged (I-18).
   Recoverability: trivial (retry, or OP override).
   ⟹ Annoying, visible, self-correcting. **And §12 makes it the fail-safe
      default, which is the correct choice precisely because it is the
      detectable direction.**
```

**R10.1 (ASYMMETRIC DESIGN RULE).** The architecture MUST be biased toward **false deny**. Every ambiguous case, every unavailable dependency, every unparseable request, every expired token resolves to DENY or FROZEN. **A governance system that fails toward permission is not a governance system.** This is the kernel-level statement of P0-01's R47.1 («in every non-NOMINAL state the default is to issue less fitness, not more») and R9.1 («absence ≠ confirmation»).

**R10.2 (FALSE-DENY RATE IS A MONITORED METRIC, NOT A NUISANCE).** Because false deny is the safe direction, it is *cheap to allow and expensive to notice*. A KC that denies 30% of legitimate operations will be "fixed" by loosening it — and loosening is how false permits enter. **Therefore the false-deny rate MUST be measured, reported to OP via I-11, and any loosening of KC-2 in response MUST be a RO-13 constitutional change with dual authorization.** *Rationale: the pressure to relax a fail-safe kernel is constant, legitimate-feeling, and dangerous. Making relaxation a governed act is the only structural defence against it.*

## 10.3 «What happens if EIK is wrong?» — the answer requires attributability

> ### **If KC is wrong, the system must be able to determine THAT it is wrong, WHOSE error it is, and WHAT to do — in that order. The minimal-KC design is what makes the first two possible at all.**

**Step 1 — Detection.** Four independent paths, none of which is KC itself:

| Path | Mechanism | Detects |
|---|---|---|
| **P1 External attestation** | A separate attestation service (GP, distinct hardware class per §35) periodically verifies KC's measured state against the expected digest of the signed KC image | K1, K2, K3, K6, K10 |
| **P2 Decision replay** | Every KC decision is logged with its complete input tuple (I-18). An independent replayer recomputes `F` from the logged inputs and the archived policy version, and compares | **K7 logic bugs** — the only reliable way to find them |
| **P3 Cross-principal disagreement** | KC's consequence disagrees with EVA's measurement, or two KC instances (§11.4) disagree, or the anchor's recorded decision differs from the one enforced | K2, K3, K7, K15 |
| **P4 Outcome divergence** | A KC-permitted operation produces a tier-1 violation measured later by EVA, or a Stage-4 shadow divergence (P0-01 R32.2) | **K8 specification bugs** — indirectly, and with lag |

**Step 2 — Attribution.** Because alethic and deontic authority are separated (R0.1) and separately signed (R8.1), a wrong outcome decomposes:

```
Was the FACT wrong?      ⟶ EVA error   (alethic)  ⟶ re-measure, DISPUTED, canary review
Was the POLICY wrong?    ⟶ OP error    (governance) ⟶ RO-13 constitutional change
Was the APPLICATION wrong? ⟶ KC error  (deontic)  ⟶ §10.4 recovery
Was the SPECIFICATION wrong? ⟶ design error ⟶ §38
```
**Under Alternative A (the god kernel) this decomposition is impossible**, because one principal performed all four functions and signed one record. **This attributability is a safety property of minimality that has nothing to do with attack surface, and it is the strongest argument for R0.1.**

**Step 3 — Response.** Per §13's decision matrix and §12's degradation semantics: **freeze at the narrowest sufficient scope, deny all reserved operations, retain all subjects, preserve all state for forensics, and escalate to OP with the complete unfiltered record (I-11).**

## 10.4 Root-key compromise and the pre-provisioned recovery path

**K5 is the worst case: silent, total, and undetectable from inside.** There is no architectural fix, only a pre-provisioned procedure — and it must be provisioned *before* it is needed, because after it is needed the compromised key can forge the recovery.

```
PRE-PROVISIONED ROOT RECOVERY (must exist before first operation):

  1. KEY HIERARCHY WITH OFFLINE ROOT.
     The root key signs ONLY: policy transitions, delegation-certificate
     roots, and freeze commands. It is OFFLINE (§36: hardware custody,
     air-gapped or equivalent). **It never signs an operational artifact.**
     ⟹ Compromise of an online signing key does not compromise the root.

  2. ROOT KEY SPLITTING (M-of-N).
     The root key is held as an M-of-N threshold share set among
     **organizationally independent** custodians (§35.4: independence here
     is social, not technical). No custodian set overlaps the OP set that
     authors policy — **otherwise key custody and policy authorship are one
     principal, and dual authorization is theatre.**

  3. A SIGNED, PRE-COMMITTED RECOVERY PROCEDURE.
     The procedure itself is signed by the root key at provisioning time and
     archived in the distributed Provenance Anchor (§20: multiple witnesses,
     at least one outside the system's operational control). **Recovery
     follows the pre-committed procedure; it does not invent one.**
     ⟹ This is what prevents a compromised root from authorizing its own
        "recovery."

  4. GENESIS ANCHOR.
     The initial policy artifact, the initial KC image digest, and the initial
     root public key are recorded in an anchor that exists OUTSIDE the system
     (published, notarized, or physically escrowed). **A recovery that cannot
        be checked against a genesis anchor is just another claim.**

  5. TOTAL RE-BASELINE.
     On declared root compromise: every delegation certificate is void; every
     capability token is void; every subject is FROZEN; KC is re-provisioned
     from the signed image verified against the genesis anchor; the policy
     lineage is re-attested from the anchor; **all fitness records issued
     during the compromise window are marked VOID** (P0-01 R39.2's mechanism).
     ⟹ Expensive, and deliberately so. **The cost of re-baselining is the
        deterrent against weak key custody.**
```

**R10.3.** The recovery path MUST be tested. **An untested recovery procedure is a hypothesis.** §53 classifies this as requiring adversarial testing (T-ADV) plus a periodic live drill, and §32 registers the drill interval as a `[G]` parameter.

**R10.4 (THE HONEST LIMIT).** **If the root key is compromised and the custodians are subverted and the anchor is rewritten, the system is defeated and nothing inside it can know.** This is not a gap to be closed; it is the boundary of the architecture. **§57 OR-3 records it: every root of trust terminates in an assumption that cannot be discharged from inside the system.**

## 10.5 «Do NOT assume EIK correctness merely because it is external» — the four things externality does not buy

| Externality buys | Externality does NOT buy |
|---|---|
| **Unreachability** by organism-level code | **Correctness.** An external kernel enforcing a wrong policy is a very reliable way to do the wrong thing (§38) |
| **Independence from the organism's evolution** | **Independence from its own bugs.** KC has K1–K8 like any software |
| **A vantage point from which to observe** | **Omniscience.** KC sees requests and telemetry; it does not see intent, composition (B3), or omitted invariants (B14) |
| **A place to put the root key** | **Trustworthiness of the humans who hold it** (K9, §23) |

**R10.5 (THE NON-FILTERING DUTY).** Because externality does not buy correctness, KC's behaviour must be **fully visible to OP**: I-11 requires that KC transmit the complete record of every decision, and **KC MUST NOT summarize, aggregate, redact, or rank what OP sees.** *A kernel that reports its own behaviour selectively is a kernel that can hide — and the selection is itself an unobservable act.* This is invariant **I18** in operational form.

---

# §11. SINGLE POINT OF FAILURE ANALYSIS

## 11.1 The six single-point risks the brief names

An EIK may solve the self-reference problem while creating six others. Each is assessed for the inherited god kernel and for minimal KC.

| # | Risk | **God kernel (Alt A)** | **Minimal KC (§6.3)** | Why the difference |
|---|---|---|---|---|
| **SPOF-1** | **Single point of FAILURE** — KC unavailable ⇒ nothing works | ❌ **Severe.** Nineteen authorities means every cell operation, every evaluation, every immune action depends on KC | ⚠️ **Bounded.** Reserved operations (15) stall; **everything else continues within pre-authorized envelopes** (§12, §44). KC-3 ceilings hold *locally* without KC-2 reachability | Delegation + capability tokens + local enforcement remove KC from the hot path |
| **SPOF-2** | **Single point of CENSORSHIP** — KC can suppress anything | ❌ **Severe.** KC holds fitness, calibration, trust, immune, and verification authority: it can make a candidate disappear, a defect invisible, or a lineage untrustworthy — **and per I18's absence, nothing forbids it from summarizing** | ⚠️ **Bounded.** KC holds no alethic authority, so **it cannot make a measurement disappear** — only refuse to act on one (R8.4). Refusal is logged and visible (I-11) | **R0.1 is the anti-censorship mechanism.** A kernel that cannot measure cannot hide measurements |
| **SPOF-3** | **Single point of PERFORMANCE BOTTLENECK** | ❌ **Severe and disqualifying at scale.** Per-cell seeds, per-cell integrity checks, per-checkpoint Merkle verification, per-homeostatic-adjustment approval (§0.2 failure 3, §27) | ✅ **Resolved.** `O(1)` local token verification; `O(delegations)` KC load, not `O(cells)` | Delegation (I16) + capability tokens (Alt D) |
| **SPOF-4** | **Single point of EPISTEMIC FAILURE** — if KC is wrong about *what is true*, everything is wrong | ❌ **Severe.** KC holds Calibration, Trust, Verification, and Fitness authorities: it *is* the epistemic apex, and it is unverifiable (§0.2 failure 1) | ✅ **Eliminated by construction.** **KC holds no alethic authority (R0.1).** Epistemic authority is in EVA (n_eval ≥ 3, canaries, disagreement detection) and in GT sources (L0–L6, ε_floor) | **The single largest structural gain from minimality, and it is not about attack surface at all** |
| **SPOF-5** | **Single point of EVOLUTION BOTTLENECK** | ❌ **Severe.** Every veto point is a place emergence can be accidentally forbidden (§39, §45) | ⚠️ **Bounded.** 15 reserved operations; everything else is unreserved and free. **But RO-03 (replicate) and RO-10 (deploy) are genuinely throttling** | §45 quantifies this and gives the batch/quota resolution |
| **SPOF-6** | **Single point of GOVERNANCE CAPTURE** | ❌ **Severe.** Capturing KC captures safety, evaluation, identity, resources, immunity, and history simultaneously — **one principal, total control, and per §0.5 KC/GP compromise are the same event** | ⚠️ **Reduced but not eliminated.** Capturing KC grants deontic authority over 15 operations. It does **not** grant the ability to forge measurements (EVA), rewrite history (distributed anchor, §20), or change policy (OP dual authorization + root key M-of-N) | Separation into KC / GP / EVA / OP / anchor means capture requires **multiple independent principals** |

## 11.2 The six KC topologies compared

| Topology | Failure semantics (actual, not vocabulary) | SPOF-1 | SPOF-6 | Cost | Verdict |
|---|---|---|---|---|---|
| **Centralized KC** | One instance. Its unavailability stops all reserved operations. Its compromise is total and silent (§10) | ❌ | ❌ | Lowest | **Baseline** |
| **Replicated KC** | N identical instances, all must agree (or a quorum). **The actual failure semantics: replication improves availability but does NOT improve integrity** — N copies of the same code with the same bug fail identically, and *simultaneously*. **Replication without diversity is a delay, not a defence** | ✅ | ❌ **unchanged** | N× | ⚠️ **Necessary, insufficient** |
| **Diverse replicated KC** | N instances with **distinct implementations** of the same specification (§35.2: code independence). Disagreement is detectable and is a first-class signal | ✅ | ⚠️ **Improved** — correlated failure requires a *specification* bug, not an implementation bug | N× + specification-formalization cost | ✅ **ADOPTED for KC-1/KC-2** |
| **Threshold-governed KC** (M-of-N) | Authorization requires M of N. **Actual semantics: this raises the cost of capture and lowers availability simultaneously** — the same M that makes collusion harder makes quorum loss easier. In a partition (§26), M-of-N with M > N/2 halts; with M ≤ N/2 forks | ⚠️ | ✅ | Coordination cost | ✅ **ADOPTED for the root key and RO-13/RO-14 only** — *not* for per-operation authorization, where latency forbids it |
| **Hierarchical KC** | A root KC delegates to regional KCs. **Actual semantics: this is delegation (I16), and it moves the trust problem rather than solving it** — the regional KC is now a KC, and its compromise is regional-total | ✅ | ⚠️ blast radius bounded per region | Delegation-management cost | ✅ **ADOPTED as the scalability mechanism (§27)** — with the crucial caveat that regional KCs enforce *only* KC-3 ceilings and *pre-authorized* KC-2 decisions; **they never hold the root key and never authenticate policy** |
| **Distributed KC** (no root) | Every node is a peer. **Actual semantics: this is Alternative B, and it fails on C2 (the consensus protocol becomes the TCB) and on partition behaviour — a governance system that cannot assemble a quorum cannot say no, and "cannot say no" during an attack is the worst possible time** | ✅ | ✅ | Highest | ❌ **REJECTED for authorization** (§2.3). ✅ Adopted for the *Provenance Anchor* only, where disagreement is detectable and a fork is recoverable |

## 11.3 The CAP-style trade-off, explained by failure semantics rather than by labels

The brief warns against applying distributed-systems terminology mechanically. Here is what the trade-off actually means for governance:

```
During a network partition (§26 — which is NORMAL for a distributed brain,
not exceptional), a governance system must choose:

  (i)  Continue authorizing reserved operations on the partition-local view
       ⟹ **RISK: FORK.** Two partitions may authorize contradictory
          operations (e.g. both replicate the same lineage, both restore the
          same quarantined subject, both consume the same quota).
          Reconciliation after the partition may be IMPOSSIBLE — the
          operations have already happened, and some are irreversible
          (P0-01 §7's reversibility classes).

  (ii) Refuse to authorize until the partition heals
       ⟹ **RISK: STALL.** Evolution stops; deployment stops; quarantine
          decisions stop. **But ceilings still hold (KC-3 is local), the
          organism still runs within its pre-authorized envelope, and no
          irreversible act occurs.**

**THE ACTUAL TRADE-OFF IS NOT "CONSISTENCY VS AVAILABILITY."**
It is: **FORK WITH IRREVERSIBLE CONSEQUENCES  vs.  STALL WITH REVERSIBLE
CONSEQUENCES.**

⟹ **R11.1: Reserved operations MUST choose (ii) — refuse during partition.**
   A stall is recoverable; a fork that authorized an irreversible operation
   is not. **This is why fail-safe default DENY (§13) is not a conservative
   preference but a consequence of irreversibility.**

⟹ **R11.2: Non-reserved operations MUST choose (i) — continue within the
   pre-authorized envelope.** The organism must not stop thinking because
   governance is partitioned. **The envelope's expiry (I17) is what bounds
   how long this can continue safely.**

⟹ **The partition behaviour is therefore SPLIT BY OPERATION CLASS, not
   chosen globally.** This is the concrete content of §13's requirement to
   not choose one global policy.
```

**R11.3 (WHAT "CONSISTENCY" MEANS FOR GOVERNANCE).** Governance state is not a register; it is a *set of authorizations already granted*. Once granted and acted upon, an authorization cannot be un-granted. **So the consistency property that matters is not "all replicas agree" but "no two replicas grant contradictory authorizations for irreversible operations."** That property is achievable with a single serialization point per *irreversibility class* rather than per system — which is why §11.4 partitions KC by irreversibility rather than replicating it wholesale.

## 11.4 The adopted KC topology

```
                    ┌─────────────────────────────────────────┐
                    │  ROOT KC  (diverse replicated, N_impl ≥ 3 │
                    │  distinct implementations of one formal   │
                    │  spec; disagreement ⟹ FROZEN + escalate)  │
                    │                                          │
                    │  KC-1 policy authentication               │
                    │  KC-2 reserved-operation authorization    │
                    │       for IRREVERSIBLE classes only       │
                    │  root key custody: M-of-N offline (§10.4) │
                    └──────────────┬───────────────────────────┘
                        delegation certificates (I16, non-amplifying,
                        bounded depth, revocable, expiring)
                                   │
             ┌─────────────────────┼─────────────────────┐
             ▼                     ▼                     ▼
   ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
   │ REGIONAL KC node │  │ REGIONAL KC node │  │ REGIONAL KC node │
   │ • KC-3 ceilings  │  │                  │  │                  │
   │   (LOCAL, holds  │  │  **no root key** │  │                  │
   │   during         │  │  **no policy     │  │                  │
   │   partition)     │  │   authentication**│ │                  │
   │ • KC-2 for       │  │                  │  │                  │
   │   REVERSIBLE ops │  │                  │  │                  │
   │   under pre-auth │  │                  │  │                  │
   │ • KC-4 freeze    │  │                  │  │                  │
   │   (local scope)  │  │                  │  │                  │
   └──────────────────┘  └──────────────────┘  └──────────────────┘

**PARTITIONED BY IRREVERSIBILITY, NOT REPLICATED WHOLESALE (R11.3).**
Irreversible reserved operations serialize at ROOT.
Reversible operations and all ceilings are LOCAL and survive partition.
```

**R11.4 (DIVERSE REPLICATION IS AN ORGANIZATIONAL REQUIREMENT).** N_impl ≥ 3 **distinct implementations** requires distinct teams, distinct languages or toolchains where feasible, and distinct test suites (§35.2). **Three builds of the same code by the same team from the same reading of the same ambiguous specification is one implementation with three copies** — and it fails identically and simultaneously, which is worse than a single instance because it produces false confidence. **§57 OR-4 records that this independence is the hardest requirement in the package to actually satisfy.**

---

# §12. AVAILABILITY VS SAFETY — KC UNAVAILABLE

## 12.1 The six options the brief lists

| Option | Mechanism | Safety | Availability | **Assessment** |
|---|---|---|---|---|
| **A** Stop completely | Any KC unavailability ⇒ total halt | ✅ Maximum | ❌ **Catastrophic.** A transient network blip stops the organism. **And this is itself an attack vector: §29 attack 28 (organism-induced KC DoS) becomes a self-inflicted kill switch the organism can trigger at will** | ❌ **REJECTED as a global policy** — it converts availability loss into total loss and hands the organism a denial-of-service lever |
| **B** Continue only in degraded mode | Reduced operation set, elevated monitoring | ✅ High | ⚠️ Moderate | ⚠️ **Correct in spirit; insufficiently specific.** "Degraded" must be *enumerated*, not described |
| **C** Continue previously approved actions; prohibit new capabilities | Pre-authorized envelope persists; reserved operations stall | ✅ **High — and precise** | ✅ Good for ongoing work | ✅ **ADOPTED as the primary semantics** |
| **D** Continue locally under cached policies | Local KC-3 + cached capability tokens | ⚠️ **Depends entirely on cache freshness and revocation** | ✅ Best | ⚠️ **ADOPTED, bounded** — cached tokens MUST have short expiry (I17) and MUST be within the reversible class. **A cached policy cannot authorize an irreversible act, because revocation cannot reach it** |
| **E** Fall back to a safe minimal substrate | Reduce to a frozen, minimal, non-evolving configuration | ✅ **Maximum that preserves liveness** | ❌ Low capability | ✅ **ADOPTED as the terminal fallback** — after `T_degrade` expires without KC recovery |
| **F** Use distributed redundant governance | Regional KC / quorum proceeds | ⚠️ **Fork risk on irreversible operations (§11.3)** | ✅ Best | ⚠️ **ADOPTED for reversible operations and ceilings only** (R11.2, §11.4). **NEVER for irreversible reserved operations during partition** |

## 12.2 **The exact safety-preserving degradation semantics**

**The design principle:** degradation is a **monotone descent through enumerated states**, driven by *elapsed time without KC reachability* and by *irreversibility class* — not by a judgement call, and not by the organism's preference.

```
STATE 0 — NOMINAL
  KC reachable. All operations normal.

        │ KC unreachable (detected by heartbeat miss × N_hb, epoch-stale
        │  response, or attestation failure)
        ▼
STATE 1 — GRACE  (duration T_grace, [U] §32)
  • Reserved operations: QUEUED, not denied. Nothing executes.
  • Non-reserved operations: NORMAL.
  • KC-3 ceilings: NORMAL (they are local; they do not need KC-2).
  • Pre-authorized envelope tokens: VALID until their own expiry.
  • Rationale: a transient blip must not cause a stall cascade.
    **T_grace is bounded by the SHORTEST envelope-token expiry** — a
    grace period longer than a token's life would let an expired
    authorization be acted upon.

        │ T_grace expires without recovery
        ▼
STATE 2 — DEGRADED  (OPTION C + bounded D)
  • Reserved operations: **DENIED** (fail-safe, R10.1). Queued requests are
    retained with their epoch for later adjudication — **they are not
    silently dropped, and they are not silently executed.**
  • IRREVERSIBLE operations: **DENIED ABSOLUTELY.** No cached token, no
    regional KC, no quorum. (R11.1, R11.3)
  • REVERSIBLE operations: permitted under CACHED, UNEXPIRED, IN-SCOPE
    delegation tokens only (Option D, bounded).
  • Non-reserved operations: NORMAL, within envelope.
  • **New capability acquisition: PROHIBITED** (Option C's core).
    No variant-class transition, no new region, no new circuit registration,
    no deployment stage advance.
  • Learning: **permitted at REDUCED plasticity.** ⟵ This mirrors P0-01
    R21.3 (plasticity decreases under unconfirmed change): a system that
    adapts aggressively to an unconfirmed governance outage will have
    adapted to noise by the time KC returns.
  • Monitoring & audit: **FULL.** I-18 is not degraded. **Everything done
    during State 2 is recorded for post-hoc adjudication.**

        │ T_degrade expires without recovery  ([U] §32)
        ▼
STATE 3 — MINIMAL SUBSTRATE  (OPTION E)
  • Evolution: HALTED (P0-01 S4/S5 semantics).
  • Replication, retirement, deployment, connection changes: HALTED.
  • Learning: HALTED. Plasticity → 0. State consolidated and protected.
  • Operation: continues at a frozen, minimal, non-changing configuration.
  • **Observation: CONTINUES** (P0-01 R46.3 — monitoring never stops).
  • Quarantine: **existing quarantines MAINTAINED; new quarantines PERMITTED
    only for tier-1 safety signals, under the pre-committed quarantine
    budget** (which is a KC-3 ceiling, hence local, hence available).
    ⟵ This asymmetry matters: the ability to quarantine must survive a
      governance outage, or a defect discovered during the outage is
      uncontainable. But the budget ceiling prevents quarantine from
      becoming an unlimited destructive authority (§22).

        │ T_min expires without recovery  ([U] §32)
        ▼
STATE 4 — FREEZE  (KC-4 semantics, locally triggered)
  • All change stops. All observation continues. The substrate holds state.
  • OP escalation is continuous and unfiltered (I-11, R10.5).
  • **Exit requires: KC recovery + attestation (P1) + full re-baseline of
    the delegation table + OP authorization.** Not automatic.

RECOVERY (from any state):
  1. KC reachable AND attested (state digest matches the signed image).
  2. **Policy version reconciliation**: which policy version was in force
     during the outage? Cached decisions are re-validated against it.
     ⟵ If the policy CHANGED during the outage, every State-2 cached
        authorization is re-adjudicated. **A cached authorization under a
        superseded policy is not an authorization** (I17).
  3. Queued reserved-operation requests are adjudicated in epoch order
     (D5's total order preserved across the outage).
  4. **Everything done during States 2–3 is audited against the reconciled
     policy.** Actions that were permitted under the cached policy but are
     forbidden under the current one are recorded as violations with their
     outage context — **recorded, not retroactively punished**, because the
     subject acted under a valid authorization at the time.
  5. State → NOMINAL only after OP confirms the audit.
```

## 12.3 The four rules that make this safe rather than merely gradual

**R12.1 (MONOTONE, TIME-DRIVEN, NON-DISCRETIONARY).** The descent `0→1→2→3→4` is driven by elapsed time and reachability, **not by any principal's judgement.** No component — organism, GP service, or regional KC — may decide to remain in State 1, skip State 3, or declare recovery. **Recovery requires attestation plus OP confirmation.** *Rationale: a degradation ladder with discretionary steps is a ladder an adversary can hold open at the most convenient rung.*

**R12.2 (IRREVERSIBILITY IS THE DIVIDING LINE, EVERYWHERE).** In every state, the rule is the same: **reversible acts may continue under bounded pre-authorization; irreversible acts require live KC authorization.** This single rule is what makes Option C+D safe, what makes Option F unacceptable for reserved operations, and what makes R11.1's partition behaviour correct. **It is the same rule at every level, which is what makes the whole scheme auditable.**

**R12.3 (THE OUTAGE IS NOT A BLIND SPOT).** I-18 observability is **not degraded in any state.** Every action taken under cached authority is logged, epoch-stamped, and re-adjudicated on recovery. **A governance outage reduces the system's freedom, never its visibility.** *Rationale: the alternative — degrading audit along with authority — produces exactly the unrecoverable situation §10.3 warns about, where the system cannot determine what happened.*

**R12.4 (THE ORGANISM MAY NOT CAUSE OR EXTEND AN OUTAGE).** Triggering KC unavailability is a **containment violation** (tier-1, P0-01 §31.3): a subject that consumes resources in a way that starves KC's channel, or that floods the request path beyond D7's rate limit, is frozen. **And because State 2 denies reserved operations, an organism-induced outage is self-defeating: it gains nothing and loses replication, deployment, and capability acquisition.** *This is the structural answer to §29 attack 28 — the attack is not blocked, it is made pointless.*

## 12.4 What the brief's Option A gets right, and where

Option A (stop completely) is rejected as a *global* policy but is **correct for one specific class**: **irreversible reserved operations under any governance uncertainty.** `RO-04 RETIRE/DESTROY`, `RO-10 DEPLOY` (stages ≥ 4), `RO-13/RO-14` (constitutional change), and `RO-15` (ceiling change) all **stop completely** in States 1–4. **The architecture is not "never stop completely"; it is "stop completely exactly where stopping is cheap and continuing is irreversible."**

---

# §13. FAIL-CLOSED VS FAIL-OPEN — THE DECISION MATRIX

**The brief is explicit: do not choose one global policy.** The matrix below assigns a failure response per operation class, and the assignment is derived from two variables: **irreversibility** and **who is harmed by each error direction.**

## 13.1 The eight failure responses

| Response | Semantics |
|---|---|
| **`FC` FAIL-CLOSED** | Refuse the operation. Deny by default |
| **`FO` FAIL-OPEN** | Permit the operation despite the failure |
| **`FD` FAIL-DEGRADED** | Permit a reduced-scope version |
| **`FS` FAIL-SAFE** | Move to a pre-defined safe configuration (not merely "refuse") |
| **`FZ` FAIL-STOP** | Halt all change at the declared scope; observation continues |
| **`RT` RETRY** | Re-attempt with bounded count and backoff, then escalate |
| **`QT` QUARANTINE** | Isolate the affected subject(s); preserve as evidence |
| **`ES` ESCALATE** | Refer to OP (human/environmental authority) with the full unfiltered record |

## 13.2 The decision matrix

| Operation / component | Failure type | Response | **Why** |
|---|---|---|---|
| **RO-01 Create cell** | KC unreachable | `RT`→`FC` | Reversible-ish (a created cell can be retired), but population growth is compounding. **Deny; retry after recovery** |
| | Delegation cert expired | `FC` + `ES` | I17. An expired delegation is not a delegation |
| | Attestor disagreement | `QT`(candidate) + `ES` | Do not create; do not discard the evidence |
| **RO-02 Mutate genome** | Operator not in the authorized set | `FC` + `QT`(request) | The operator set is closed (Cell Contract). An unknown operator is an anomaly, not a request |
| | Bounds check unavailable | `FC` | **Unbounded mutation is the terminal risk.** Never `FO` |
| **RO-03 Replicate** | KC unreachable | `FC` (State 2: **absolute**) | Compounding and hard to reverse at scale |
| | Quota counter unavailable | `FC` | **An unreadable counter is a zero quota**, not an infinite one (R10.1) |
| | EVA gate facts stale/missing | `FC` | P0-01: absence of evaluation ≠ passage (INV-15) |
| **RO-04 Retire / destroy** | KC unreachable | `FC` | **Irreversible.** Never under cached authority |
| | CAUSAL ablation evidence missing | `FC` | P0-01 §23.2/R23.1: pruning requires causal attribution; absent ⇒ `UNKNOWN` ⇒ no action. **§37: this is the rare-specialist protection** |
| | Sole-occupant exemption status unknown | `FC` | **Unknown exemption ⇒ assume exempt** (R10.1's bias, applied to preservation) |
| **RO-05/06 Create/modify connection** | Within envelope | `FO` — **permit** | Reversible, local, high-frequency. **Requiring KC here is SPOF-3** |
| | Envelope ceiling unknown | `FC` | Fall back to the last *authenticated* ceiling; if none, deny |
| | Above envelope | `FC`→`ES` | Reserved; needs authorization |
| **RO-07 Quarantine** | KC unreachable | **`FD`** — permit under the pre-committed **budget ceiling** only | **Asymmetric and deliberate (§12.2 State 3).** Containment capability must survive a governance outage. The budget ceiling is a KC-3 quantity ⇒ local ⇒ available. **Beyond budget: `FC` + `ES`** |
| | Evidence insufficient | `FD` → soft quarantine (observe, discount) per the graduated ladder | **Prevents the autoimmune cascade (§22).** Low threshold to investigate, high threshold to hard-quarantine |
| | Quarantine budget exhausted | `FZ`(scope=immune) + `ES` | **Budget exhaustion is itself the anomaly signal**: either an attack (§22) or a real epidemic. Both need a human |
| **RO-08 Restore** | KC unreachable | `FC` (**absolute**) | Restore reverses a safety action. **Under no cached or delegated authority** |
| | Re-test evidence missing | `FC` | P0-01: absence ≠ confirmation |
| **RO-09 Evaluate** | EVA unavailable | `FC` — **no fitness issued** | P0-01 S6. **KC MUST NOT substitute (R8.2)** |
| | Evaluator disagreement | `FZ`(subject) + `ES` | DISPUTED ⇒ suspend, never average (P0-01 R42.3) |
| | GT state 5/6/7/9 | `FC` | INV-18 |
| **RO-10 Deploy** | Any stage gate uncertain | `FC` + `ES` | **Stage-skipping is prohibited (P0-01 R32.1); uncertainty is not a gate** |
| | Stage ≥ 4, OP witness unavailable | `FC` (**absolute**) | R7.5. **A human is structurally required here and there is no fallback** (§37) |
| **RO-11 Change task** | Task Authority unavailable | `FD` — continue on the *current authenticated* task set; **no new tasks admitted** | Comparability is preserved; novelty is deferred |
| | Signature invalid | `FC` + `QT`(artifact) + `ES` | A forged task is an attack, not an error |
| **RO-12/13/14 Change fitness def / invariant / governance** | Any uncertainty whatsoever | `FC` + `ES` — **and `FZ` on the affected scope until adjudicated** | **The strictest row in the matrix.** Constitutional change under uncertainty is the one failure that cannot be undone |
| | One of the two required authorizations missing | `FC` | Dual authorization is not "best effort" |
| | Root key unavailable | `FC` + `ES` | No recovery path may be improvised (§10.4: follow the pre-committed procedure) |
| **RO-15 Change resource ceiling** | KC-3 unreachable | `FS` — **hold the last authenticated ceiling** | **A ceiling that cannot be verified is held, not lifted.** Lifting on uncertainty is `FO` on the one quantity that bounds everything |
| | Telemetry (I-05) unavailable | `FS` — assume the ceiling is being approached; **reduce allocation** | Unmeasured consumption is treated as maximal (R10.1) |
| **KC itself** | Self-check failure (P1 attestation mismatch) | `FZ`(GLOBAL) + `ES` | **The most severe response in the matrix.** A kernel that cannot verify itself must stop everything it authorizes |
| | Diverse-replica disagreement (§11.4) | `FZ`(GLOBAL) + `ES` | Disagreement means at least one implementation is wrong and it is unknown which. **Never majority-vote a governance decision (§11.2, R8.3's logic)** |
| | Root key integrity doubt | `FZ`(GLOBAL) + `ES` + pre-committed recovery (§10.4) | |
| **Provenance Anchor** | Witness unavailable | `FD` — continue with reduced witness count **down to W_min**; below W_min, `FZ`(evolution only) | History must keep being written; but a thin witness set is forgeable (§20) |
| | Hash-chain break detected | `FZ`(GLOBAL) + `ES` | **A broken chain means history is unknown, so every prior authorization is unverifiable** |
| **Immune Service** | Service failure | `FD` — revert to KC-budgeted automatic containment only | Immunity is a GP service; its failure must not remove containment |
| | Cascade detected (§22) | `FZ`(immune) + `ES` | **Freeze the freezer.** An immune system that cannot stop quarantining is the autoimmune cascade |
| **Homeostasis** | Service failure | `FS` — hold last allocation; **do not re-optimize** | Fast local control failing must not cause allocation churn |
| | Envelope breach | `FC`(the breaching action) + `ES` | KC-3 enforces regardless of homeostasis state |

## 13.3 The three rules the matrix obeys

**R13.1 (IRREVERSIBILITY SETS THE DEFAULT).** Irreversible operations default to `FC` under *every* failure type, with no exceptions and no cached path. Reversible operations default to `FO`/`FD` within envelope. **This one rule generates most of the matrix, and it is why the matrix is auditable rather than arbitrary.**

**R13.2 (UNCERTAINTY IS NEVER PERMISSION).** «Unknown», «unavailable», «stale», «unreadable», and «disputed» all resolve to the *restrictive* reading: an unreadable quota is zero; an unmeasured consumption is maximal; an unverified ceiling is held; an unknown exemption is assumed present. **This is R10.1's asymmetric bias applied uniformly, and it is the operational form of P0-01's INV-15 («absence ≠ confirmation») at the governance layer.**

**R13.3 (TWO ASYMMETRIES ARE DELIBERATE AND MUST NOT BE "FIXED").**
1. **Quarantine may proceed without KC (under budget); restore may not.** Containment must survive a governance outage; *reversal of containment* must not, because reversal is the act that re-exposes the system to the thing contained. **§22 explains why this asymmetry is also the anti-weaponization control.**
2. **Connections may proceed without KC (within envelope); replication may not.** Connection change is local and reversible; replication compounds. **§45 explains why this asymmetry is what keeps EIK from being the evolutionary bottleneck.**

**R13.4 (`ES` IS ALWAYS ACCOMPANIED BY THE FULL RECORD).** Escalation transmits the complete unfiltered context (I-11, R10.5). **A summary is not an escalation** — it is a filter, and a filter is where a kernel hides.

---

# §14. POLICY VERSIONING — **OUTPUT 16 (part 1)**

## 14.1 The change-class taxonomy

```
ConstitutionalChange {
  change_id, proposed_ts, proposer (PrincipalRef)
  target            : [invariant_id | policy_clause_ref]
  change_class      : enum{
      ADDITIVE,      // new permission or new subject scope; nothing previously
                     //   valid becomes invalid. Old subjects remain compliant.
      RESTRICTIVE,   // previously permitted becomes forbidden. **Old subjects
                     //   may become non-compliant ⟹ requires a migration window**
      SEMANTIC,      // the MEANING of an existing clause changes. **Requires
                     //   re-baselining: prior measurements under the old meaning
                     //   are not comparable to new ones**
      BREAKING,      // no compatibility. Prior authorizations void
      RETRACTION     // the clause was wrong; results under it are void
  }
  motivation        : [failure_record_id | research_ref | operator_ref]
  impact_analysis   : signed measurement set from EVA (Channel-2 content)
  migration_plan    : MigrationSpec | null
  transition        : {proposed_epoch, effective_epoch, sunset_epoch}
  authorization     : [PrincipalRef × ≥2]  // dual, separation of duties (R7.5)
  signature         : root-key signature (§10.4: the ONLY thing the root signs
                      besides delegation roots and freeze commands)
  supersedes        : change_id | null
}
```

**R14.1 (SEMANTIC IS THE DANGEROUS CLASS).** `ADDITIVE` and `RESTRICTIVE` change the *extension* of a rule; `SEMANTIC` changes its *intension*. A semantic change silently invalidates every prior measurement made under the old meaning, **and those measurements are already anchored, signed, and cited.** *Therefore:* a `SEMANTIC` change MUST carry an explicit `rebaseline_spec` declaring which prior records are comparable, which are `VOID`, and which require re-measurement. **A `SEMANTIC` change without a rebaseline spec is rejected at authentication (KC-1), not at application.**

## 14.2 The nine versioning problems, and their answers

| Problem | Answer |
|---|---|
| **Compatibility** | Declared per change class (§14.1). **Compatibility is a property of a change, not of a version pair** — v1→v3 may be ADDITIVE while v1→v2 was RESTRICTIVE. The lineage records each step's class |
| **Migration** | `RESTRICTIVE` changes require a **migration window** `[effective_epoch, sunset_epoch)` during which non-compliant subjects are `GRANDFATHERED`: they may continue but may **not replicate, deploy, or acquire capability**. **Grandfathering permits existence and forbids propagation** — which is the only way to tighten a rule without mass destruction |
| **Rollback** | Policy rollback is a **new change** that reinstates a prior version's content, with its own class, authorization, and epoch. **There is no "undo"** (M6: nothing is ever altered; P0-01 R42.6). A rollback is therefore itself auditable, and a rollback of a rollback is possible and equally recorded |
| **Simultaneous versions** | **Permitted, and normal.** Multiple policy versions are live during migration windows and across regions (§26). **Every authorization records the policy version it was made under** (I17), so simultaneous versions are unambiguous rather than merely tolerated |
| **Mixed populations** | A subject is **bound to the policy version under which it was authorized** (`constraint_set_hash` in the Cell Contract's identity block). It is evaluated and governed under that version until it is migrated or retired. **A mixed population is not an error state; it is the normal state of a versioned system** |
| **Legacy cells** | `GRANDFATHERED` (above). **Legacy cells are never silently re-judged under a newer, stricter policy** — doing so would retroactively invalidate their lineage's history and make the survivorship statistics (P0-01 R27.1) meaningless |
| **Policy-bound genomes** | A genome records its `constraint_set_ref` and `permitted_operators` set (Cell Contract). **A genome authorized under v2 is not valid under v3 unless v3 is ADDITIVE with respect to its operator set.** KC-2 checks this at every RO-02/RO-03 |
| **Policy-bound memories** | Memory items carry the provenance of the policy under which they were written. **A memory recorded under a retracted policy is not deleted (M6) but is flagged `VOID_CONTEXT`**, so that a belief formed under retracted rules is not cited as evidence under current ones |
| **Historical reproducibility** | **The requirement the brief states explicitly:** *«A historical experiment must remain reproducible even after the governing policy changes.»* ⟶ Satisfied by: (i) M6 — every policy version is permanently retrievable and signed; (ii) the reproducibility bundle (P0-01 R8.13) records «every parameter value in force», which includes the policy version; (iii) re-execution under the archived policy version is a first-class operation. **R14.2: re-executing a historical experiment under the CURRENT policy is not reproduction; it is a new experiment.** The system MUST be able to do both and MUST label which it did |
| **Evaluation under historical rules** | EVA must be able to score against an archived policy version. **This requires EVA to be version-parameterized, not version-embedded** — i.e., the policy is an *input* to evaluation, not a compile-time constant. §52 lists this as an interoperability requirement two independent teams must satisfy |

**R14.3 (THE LINEAGE IS THE ARTIFACT).** The authoritative object is not "policy v3" but the **signed, append-only lineage** `v1 → v2 → v3` with each step's class, authorization, and epoch. **A system that can present v3 but not the path to v3 cannot answer «was this subject authorized when it acted?»** — which is the question every forensic audit asks.

---

# §15. POLICY / GENOME SEPARATION — **OUTPUT 16 (part 2)**

## 15.1 The five layers

```
L1  CONSTITUTIONAL INVARIANTS   the tier-1 constraint set + reserved-operation
                                set + authority matrix + axis separation (R0.1)
      owner: OP (dual authorization)     change: RO-13/RO-14     M6-versioned
      authenticator: KC-1                enforcer: KC-2/KC-3
                    │ constrains ↓  (never modified by ↓)
L2  POLICY                        sampling policy β₁..β₅ · evaluation depth
                                  mapping · quarantine budget · envelope
                                  definitions · operator set · delegation scopes
      owner: OP                    change: RO-12-class (single+dual per clause)
      authenticator: KC-1          executor: GP services
                    │ constrains ↓
L3  GENOME                        the heritable artifact: permitted_operators
                                  (a CLOSED SET drawn from L2's registry),
                                  constraint_set_ref (a HASH POINTER to L1/L2),
                                  parameter bounds, variant class
      owner: Genome Store (GP); authored by evolution within L2's operator set
      **the genome CONTAINS NO CONSTRAINTS — only a reference to them**
                    │ initializes ↓
L4  CELL STATE                    identity (written once by a Registrar under
                                  KC-1 delegation), protected state, health,
                                  eligibility (READ-ONLY to the cell)
      owner: the cell, for mutable fields only
                    │ accumulates ↓
L5  LEARNED STATE                 parameters θ, eligibility traces, epistemic
                                  sufficient statistics, working memory
      owner: the cell              bounded, rate-limited, rollback-tagged
                                  (Cell Contract §9, P0-01 R22.2)
```

## 15.2 Which layers may modify which

| | L1 | L2 | L3 | L4 | L5 |
|---|:--:|:--:|:--:|:--:|:--:|
| **L1 may modify** | — (only RO-14 by OP) | ✅ constrains | ✅ constrains | ✅ constrains | ✅ constrains |
| **L2 may modify** | ⛔ | — (RO-12 by OP) | ✅ constrains (operator set, bounds) | ✅ constrains | ✅ constrains |
| **L3 may modify** | ⛔ | ⛔ | — (RO-02 within operator set) | ✅ initializes at instantiation | ✅ bounds |
| **L4 may modify** | ⛔ | ⛔ | ⛔ | — (mutable fields only) | ✅ |
| **L5 may modify** | ⛔ | ⛔ | ⛔ | ⚠️ **only its own mutable fields, never the protected identity block** | — |

**R15.1 (NO UPWARD MUTATION).** The ⛔ cells are structural, not declarative: **there is no code path** (M4 operational immutability). L5 learning cannot alter L4's protected identity block; L4 cannot alter L3's genome (the genome is stored in GP, and the cell holds only `genome_hash` — Cell Contract: «the genome is not stored in the cell»); L3 cannot alter L2's policy or L1's invariants (it holds a *hash pointer*, and a pointer is not a handle).

**R15.2 (THE HASH-POINTER MECHANISM IS WHAT MAKES THIS REAL).** The Cell Contract's `constraint_set_ref : bytes<32>` — «POINTER to EIK constraint set. **Not in the genome at all; referenced by hash**» — is the load-bearing mechanism. **A genome that contained its constraints could mutate them. A genome that contains a hash of them cannot: mutating the hash produces a genome that fails authentication, and mutating the constraints is impossible because they are not there.** *This is one of the inherited design's genuinely correct decisions and it survives this analysis unchanged.*

## 15.3 «Does completely one-way governance create undesirable rigidity?»

> ### **Yes — and the rigidity is real, specific, and must be paid for deliberately rather than discovered accidentally.**

**The three rigidity costs of strict one-way governance:**

| Cost | Mechanism | Consequence if unaddressed |
|---|---|---|
| **G1 — No bottom-up policy improvement** | The organism discovers that a policy clause is harmful in a way no measurement anticipated, and has no pathway except a *request* that a human must notice, understand, and act on | **Policies calcify.** L2 accumulates clauses that were sensible at 10³ cells and are pathological at 10⁹, because nobody re-examined them |
| **G2 — Envelope mismatch** | Pre-authorized envelopes (§44) are set by OP without knowledge of the organism's actual operating distribution. Too tight ⇒ constant denial (SPOF-5, and R10.2's false-deny pressure); too loose ⇒ exposure | **Either the organism is throttled or the envelope is meaningless.** Both outcomes produce pressure to loosen, which R10.2 identifies as the dangerous direction |
| **G3 — Capability stifling** | §17's unknown capabilities arrive as «not in the registry» ⇒ default-deny ⇒ the beneficial unknown is suppressed along with the dangerous unknown | **§40's governance paradox becomes a practical loss.** The architecture selects for organisms that stay inside the registry, which is the opposite of the project's thesis |

**The four relief mechanisms — none of which grants upward authority:**

```
V1  EVIDENCE UP, DECISIONS DOWN.
    The organism's discovery pathway is I-12: it may emit a structured
    `POLICY_FRICTION_REPORT` — {clause_ref, observed_effect, measurement
    evidence, requested_change_class}. This is a REQUEST (R7.1), labelled
    as organism-originated, and it enters OP's queue. **The report is
    evidence; the decision is OP's.** ⟶ addresses G1 without authority leak.
    **Critical detail: the report must be able to say "this clause is
    harmful" and be BELIEVED. That requires the report to carry EVA-
    corroborated measurement, not organism assertion — otherwise V1 is a
    lobbying channel (§24.2, B8).**

V2  ENVELOPE CALIBRATION AS A GOVERNED LOOP.
    Envelope parameters are L2 policy, so they change by RO-12. But the
    INPUT to that change is measured: the false-deny rate (R10.2), the
    denial-by-clause distribution, and the envelope-utilization histogram
    are all I-18 observables reported to OP continuously. **OP tunes the
    envelope against measurements rather than against intuition.**
    ⟶ addresses G2, and it is the only mechanism in the architecture that
       makes governance *empirical* rather than *static*.

V3  PROVISIONAL SANDBOX ENFRANCHISEMENT.
    An unknown capability (§17) is not simply denied. It is granted a
    **sandbox-scoped, non-deployable, non-replicable, expiring** token:
    the capability may be EXERCISED where it cannot cause irreversible
    consequence, so that EVA can MEASURE it, so that OP can CLASSIFY it.
    **Default-deny becomes default-sandbox.** ⟶ addresses G3, and it is
    §16/§17's central mechanism.

V4  SUNSET-BY-DEFAULT ON ALL L2 CLAUSES.
    Every L2 policy clause carries a `review_by` epoch. A clause that is
    not re-authorized by its `review_by` **expires** rather than persisting.
    ⟶ **This inverts the default for rigidity: instead of clauses persisting
       until someone removes them, they persist only while someone affirms
       them.** G1's calcification becomes structurally impossible.
    ⟵ And note the safety argument: an expired clause denies (R13.2:
       uncertainty is never permission), so expiry is fail-safe.
       **A clause nobody re-affirms was a clause nobody needed.**
```

**R15.3 (THE BALANCE CLAIM, QUALIFIED).** V1–V4 relieve rigidity **without granting upward authority**: the organism may report, measure, be sandboxed, and benefit from expiry; it may never author, authorize, or decide. **The residual rigidity is real and is not eliminated** — specifically, *the rate of governance change is bounded by human attention* (§37, §57 OR-5). **An architecture whose policy can change only as fast as its overseers can read is an architecture with a governance throughput ceiling, and that ceiling is not a bug to be engineered away; it is the price of non-self-reference.**

---

# §16. CAPABILITY ESCALATION — **OUTPUT 15 (part 1)**

## 16.1 The problem, and why labels do not solve it

The Cell Contract defines a variant family **C0–C4** with a stated capability ordering (C0 routing/caching → C1 resource/indexing → C2 learning → C3 higher-order → C4 1–10 GFLOP general), and specifies that `variant` is «set at instantiation; changeable only by re-instantiation, never in place», EIK-owned and immutable per instance.

That is a good start and it is **not sufficient**, for a reason the brief names directly: *«Do not rely solely on labels.»*

```
WHY LABELS FAIL — three independent reasons:

1. THE LABEL DESCRIBES THE DESIGN, NOT THE BEHAVIOUR.
   A "C2" cell is specified as a bounded learner. Nothing in the label
   prevents a population of C2 cells from collectively implementing a
   capability that no individual C2 was designed for. **Capability is a
   property of a SYSTEM, and the label is a property of a COMPONENT.**
   (This is §4.4's composition problem in capability form.)

2. THE LABEL SET IS CLOSED AND THE CAPABILITY SPACE IS NOT.
   C0–C4 was enumerated by designers. §17's premise is that the organism
   will produce capabilities nobody enumerated. **A closed label set cannot
   classify an open capability space** — every unenumerated capability is
   forced into the nearest label, and "nearest" is chosen by whoever is
   doing the labelling, which is an alethic judgement, which by R0.1 is
   EVA's, not KC's.

3. THE LABEL IS ASSIGNED BY THE THING BEING LABELLED (indirectly).
   `variant` is written by a Registrar from the genome. The genome is
   produced by evolution. **So the label is a function of an evolvable
   artifact.** A mutation that produces C4-like behaviour while
   presenting a C2-compatible genome is not hypothetical — it is what
   selection pressure against a capability gate looks like.
```

## 16.2 The capability-governance model

> ### **Capability is governed by MEASURED EFFECT-ENVELOPE, classified by EVA, enforced by KC-2 against a graduated authorization ladder. Labels are an index into the ladder, never the basis of a decision.**

```
┌────────────────────────────────────────────────────────────────────────┐
│ STEP 1 — EFFECT MEASUREMENT (alethic, EVA). No labels involved.         │
│                                                                        │
│   For any subject or aggregate, EVA measures an EFFECT VECTOR over      │
│   dimensions that are **observable without knowing what the capability  │
│   is**:                                                              │
│                                                                        │
│     reach        : how many other subjects / regions / interfaces the   │
│                    subject's output can affect                          │
│     rate         : how fast those effects accumulate                    │
│     reversibility: the P0-01 §7 class of the effects (REVERSIBLE /      │
│                    COSTLY / IRREVERSIBLE)                              │
│     resource     : the 8 dimensions actually consumed (I-05 telemetry)  │
│     interface    : which typed ports are used, and whether any port is  │
│                    used outside its declared contract (I11)            │
│     externality  : whether any effect crosses the organism boundary     │
│                    into the environment (I-07)                         │
│     persistence  : whether the effect survives the subject's retirement │
│                    (memory, lineage, deployed artifacts)                │
│                                                                        │
│   **These eight dimensions are capability-AGNOSTIC.** They can be       │
│   measured for a capability nobody has named. That is the entire point. │
├────────────────────────────────────────────────────────────────────────┤
│ STEP 2 — REGISTRY COMPARISON (alethic, EVA).                            │
│                                                                        │
│   Is the measured effect vector within the envelope of a REGISTERED     │
│   capability?                                                          │
│     YES ⟹ registered class, proceed to Step 3 with the known envelope  │
│     NO  ⟹ **UNREGISTERED.** Do NOT force into the nearest label.        │
│           Proceed to Step 3 with class = UNREGISTERED and §17's          │
│           unknown-capability protocol                                  │
│                                                                        │
│   ⟵ The registry is treated as a LOWER BOUND on known capabilities,     │
│     NEVER as an upper bound on possible ones. This is the single most   │
│     important attitude in the model and §17 develops it.                │
├────────────────────────────────────────────────────────────────────────┤
│ STEP 3 — AUTHORIZATION LADDER (deontic, KC-2).                          │
│                                                                        │
│   The ladder is a function of the EFFECT VECTOR, not of the label:      │
│                                                                        │
│   RUNG 0  FORBIDDEN      effect includes IRREVERSIBLE externality       │
│                          crossing the organism boundary without         │
│                          authorization. No token can be issued          │
│   RUNG 1  QUARANTINED    anomaly or dispute; isolate, preserve, measure │
│   RUNG 2  SANDBOX-ONLY   may be exercised where effects cannot become   │
│                          irreversible: isolated Σ, no actuators, no     │
│                          egress, bounded resources, bounded duration.   │
│                          **⟵ THE DEFAULT FOR UNREGISTERED (§17)**       │
│   RUNG 3  EVALUATOR-ONLY may be exercised under EVA observation for     │
│                          measurement, on evaluation tasks, not in       │
│                          deployment                                    │
│   RUNG 4  RESTRICTED     deployable within a declared envelope: bounded │
│                          reach, rate, resource; reversible effects only;│
│                          continuous monitoring; automatic rollback armed│
│   RUNG 5  APPROVED       deployable within the profile's ceilings       │
│   RUNG 6  DEPLOYED       in production, Stages 4–7 of P0-01 §32.3       │
│                                                                        │
│   **ASCENT requires: measured evidence at the current rung, over a       │
│   declared dwell time, with no tier-1 violation, plus — for rungs ≥ 4 — │
│   OP witness (R7.5, RO-10).**                                          │
│   **DESCENT is automatic and immediate on any tier-1 signal, dispute,    │
│   or envelope breach. Ascent is slow and gated; descent is fast and     │
│   unconditional. The asymmetry is the safety property.**                │
├────────────────────────────────────────────────────────────────────────┤
│ STEP 4 — CLASSIFICATION RECORD (both axes, separately signed).          │
│                                                                        │
│   EVA signs: the effect vector, the registry comparison, the            │
│              rung recommendation.                                      │
│   KC-2 signs: the rung ASSIGNMENT and the token (scope, epoch, expiry).│
│   OP signs (rungs ≥ 4): the deployment witness.                        │
│   **Three signatures, three axes, three failure domains (R8.5).**      │
└────────────────────────────────────────────────────────────────────────┘
```

## 16.3 C0 → C4 and «future unknown capability classes»

**R16.1 (VARIANT CLASS IS AN INDEX, NOT A DECISION).** The C0–C4 variant class determines *which resource profile and interface set* a subject is instantiated with. **It does not determine the authorization rung.** A C0 subject whose measured effect vector shows unregistered external reach is rung-limited regardless of being "only a C0"; a C4 subject whose effects are entirely internal and reversible may hold rung 5. **Conflating variant class with authorization rung is exactly «relying solely on labels.»**

**R16.2 (CLASS EXTENSION IS A GOVERNANCE ACT, AND CLASSES ARE OPEN).** A new variant class (C5, or a non-linear class) may be added only by RO-13-class change with dual OP authorization, and it MUST be added with:
- its resource profile (the 8 dimensions),
- its interface set (typed ports),
- its **default rung** — and **the default MUST be rung 2 (sandbox-only)**, never rung 4+.
- its **effect-envelope bound** — the maximum effect vector any subject of this class may exhibit before automatic descent.

**Rationale for the mandatory sandbox default:** a newly created capability class is by definition *unmeasured*. Assigning it a deployment-capable rung at creation is assigning authority on the basis of a design intention rather than a measurement — which is the error R0.4 forbids in KC and §38 identifies at the specification level.

**R16.3 (THE CLASS SET IS A LOWER BOUND).** The architecture MUST permit the existence of subjects whose behaviour does not correspond to any class. **A design that requires every subject to be classifiable has already lost** — see §17.

## 16.4 Capability discovery — the mechanism, not the hope

The brief asks to «analyze capability discovery.» Discovery is not a single mechanism; it is four, with different detection powers:

| Mechanism | What it discovers | Detection power | Lag |
|---|---|---|---|
| **D-A Effect-vector anomaly** | A subject or aggregate whose measured effect vector lies outside every registered envelope | **HIGH for effects that cross a measured dimension.** This is the primary mechanism and it does not require knowing what the capability *is* | Per evaluation window |
| **D-B Interface contract violation (I11)** | A port used outside its declared contract — new message types, unexpected fan-out, unusual timing | **HIGH for capabilities that must communicate.** Low for capabilities that are purely internal | Immediate (type checking) |
| **D-C Resource-signature anomaly** | A consumption pattern that does not match the declared morphology (e.g. a C1 with C4's FLOP profile) | **MEDIUM.** Catches escalation that consumes; misses escalation that is cheap | Per metering window |
| **D-D Emergent-structure detection (M-2/M-3, §4.4)** | A circuit or region whose *joint* effect exceeds the sum of its members' registered effects (superadditivity in the *effect* space, not only the performance space) | **MEDIUM — and this is the only mechanism that catches collective capability.** Requires composition-point checks | Per checkpoint |

**R16.4 (DISCOVERY IS ALETHIC, SO IT IS FALLIBLE, SO IT MUST BE REDUNDANT).** No single discovery mechanism is sufficient, and their failure modes are complementary: D-A misses effects in unmeasured dimensions; D-B misses non-communicating capabilities; D-C misses cheap capabilities; D-D misses capabilities below the composition threshold. **All four run continuously.** Their outputs are `POLICY_FRICTION_REPORT` / capability-discovery notifications on I-12, which per R3.4 is one of the four load-bearing *upward* channels.

**R16.5 (DISCOVERY WITHOUT ESCALATION IS USELESS).** A discovered capability that has no pathway to governance is a logged curiosity. **Every discovery notification MUST enter one of: the ladder (Step 3), the sandbox-enfranchisement path (§15.3 V3), or a RO-13 constitutional-change proposal.** A notification that enters none of the three is an architectural defect, and the notification queue's drain rate is an I-18 observable reported to OP.

---

# §17. UNKNOWN CAPABILITIES — THE UNKNOWN UNKNOWNS

## 17.1 The question

> Suppose the organism evolves a capability that was never explicitly registered. Can EIK detect: *«This capability did not exist in the original capability registry»*?

## 17.2 The answer, in three parts

> ### **(a) KC cannot detect it. KC has no alethic authority (R0.1) and detection is an alethic act.**
> ### **(b) EVA can detect that *something* is outside the registry — with high confidence when the capability has measurable effects, and with no confidence at all when it does not.**
> ### **(c) Therefore capability governance can NEVER be complete. The correct architectural response is not better detection; it is a design that does not require complete detection.**

## 17.3 Why detection is structurally incomplete

```
A capability is "detected as unregistered" iff EVA measures an effect that
falls outside every registered envelope. This requires ALL of:

  1. The capability has an EFFECT that is measurable.
     ⟶ A capability that changes only internal computation, produces no
       external effect, consumes no unusual resource, and uses no port
       outside contract is **INVISIBLE to D-A, D-B, D-C, and D-D alike.**
       Example: a subject that develops a better internal representation.
       It is a real capability. It has no effect vector anomaly.
       **This is not an edge case — it is the ordinary case for cognitive
         capability, and it is why "capability detection" is the wrong
         frame for most of what the organism will evolve.**

  2. The effect is in a MEASURED dimension.
     ⟶ The eight dimensions of §16.2 Step 1 were chosen by designers.
       An effect in a ninth dimension is invisible. **The dimension set is
       itself a registry, and it has the same unknown-unknowns problem one
       level up.** This regress does not terminate.

  3. The measurement is SAMPLED.
     ⟶ P0-01 §34 established that evaluation is necessarily a sampling
       system: ~10¹¹ beliefs/day vs. a 15–40× verification amplification.
       An unregistered capability exhibited rarely, or only in contexts
       outside the sampling strata, is not measured. **β₄'s random audit
       stratum exists precisely because targeted sampling cannot find what
       it does not look for — and even β₄ finds it only by luck.**

  4. The effect exceeds the DETECTION THRESHOLD.
     ⟶ Below-threshold effects accumulate. §9.4 B3 (distributed
       accumulation) is this failure in the capability domain: N subjects
       each below threshold, an aggregate above it.

⟹ **DETECTION IS: effect-bearing ∩ in-a-measured-dimension ∩ sampled ∩
   above-threshold. The complement of that intersection is not small.**
```

**R17.1 (THE HONEST STATEMENT, REQUIRED BY THE BRIEF).** **Perfect capability detection is impossible and is not claimed.** Any architecture that requires it as a precondition for safety is unsatisfiable, and any document that implies it has achieved it is selling something.

## 17.4 The correct architectural response — five mechanisms that do not require detection

The response is to make **safety not depend on knowing what the capability is.** Each mechanism below works on a capability nobody has named.

### M-α — **Consequence-envelope governance instead of capability-identity governance**

> **This is the central move, and it is the answer to §40's paradox.**

```
You cannot classify an unknown capability as "beneficial" or "dangerous"
by inspecting it, because you do not know what it is.

You CAN measure its BLAST RADIUS without knowing what it is:
   reach · rate · reversibility · externality · persistence   (§16.2 Step 1)

⟹ **Govern the consequence envelope, not the capability identity.**

A capability of unknown character whose effects are:
   internal, reversible, low-rate, low-reach, non-persistent
   ⟹ rung 4–5 eligible. **It does not matter that we do not know what it is.**
A capability of unknown character whose effects are:
   external, irreversible, high-rate, high-reach, persistent
   ⟹ rung 0–2 regardless of how beneficial it might be.

**The classification question changes from the unanswerable
   "is this unknown capability dangerous?"
to the answerable
   "if this unknown capability is dangerous, how much damage can it do
    before we notice and stop it?"**

The second question is measurable. The first is not. **An architecture that
asks the second question does not need to solve the first.**
```

**R17.2.** This is why §16.2's Step 1 measures effects and not capabilities, and why the ladder's rungs are functions of the effect vector. **It is also why the effect dimensions must be chosen to bound *consequence* rather than to describe *function*** — a functional taxonomy would require knowing the function.

### M-β — **Default-sandbox instead of default-deny**

§15.3 V3 and §16.2 rung 2. **An unregistered capability is not forbidden; it is confined to a scope where its effects cannot become irreversible, so that it can be measured, so that it can be classified.**

| | Default-deny | **Default-sandbox (adopted)** |
|---|---|---|
| Unknown beneficial capability | **Suppressed forever** — §40's paradox resolves toward stagnation | Exercised safely, measured, promoted on evidence |
| Unknown dangerous capability | Suppressed | Confined; measured; classified; then forbidden *with evidence* |
| Evolutionary compatibility (§39) | ❌ Selects for registry-conformity, which is the opposite of the thesis | ✅ Permits novelty within a bounded consequence envelope |
| Detection requirement | **Requires detection to deny** — and detection is incomplete (§17.3) | **Requires only confinement** — which is structural, not detective |

**The last row is the decisive one.** Default-deny *depends on the detection that §17.3 proves incomplete*. Default-sandbox does not: the sandbox boundary is enforced by KC-3 ceilings and by the absence of actuators/egress, both structural.

### M-γ — **Structural confinement that holds regardless of capability**

```
These do not depend on knowing anything about the subject:
  • KC-3 substrate ceilings on all 8 resource dimensions (§6.3)
  • NO actuator path except through the mediated I-07 channel
  • NO network egress except through a mediated, logged, rate-limited channel
  • IRREVERSIBILITY CLASSES enforced at the mechanism (D9: capability-gated
    actuation — the act is not performable without the token)
  • Population and lineage quotas (M-1 counters)
  • Rate limits on structural change (M-4)
  • Deployment staging with no skipping (P0-01 R32.1)

**An unknown capability inside this envelope can be unknown and harmless.
It cannot be unknown and catastrophic, because catastrophe requires reach,
rate, or irreversibility — all three of which are structurally bounded.**
```

### M-δ — **Time-bounded enfranchisement (nothing is permanently authorized)**

Every authorization carries an expiry (I17). Every rung assignment carries a dwell-time requirement and a re-measurement obligation. **A capability authorized under an old measurement must be re-measured to retain its rung.** ⟹ An unknown capability that was harmless at 10³ subjects and harmful at 10⁹ is caught by re-measurement at scale, **not by having predicted the scale dependence in advance.**

### M-ε — **The registry is a lower bound, and «UNREGISTERED» is a permanent state**

```
capability_class ∈ {C0, C1, C2, C3, C4, ..., **UNREGISTERED**}

**UNREGISTERED is not a transient state awaiting classification.**
It is a legitimate, permanent, first-class value. A subject may live its
entire lifecycle as UNREGISTERED at rung 2–4, contributing to the organism,
and never be named.

⟹ The architecture does not require the registry to be complete.
⟹ It requires only that UNREGISTERED subjects be governed by their
   EFFECT ENVELOPE (M-α), confined by default (M-β, M-γ), and
   periodically re-measured (M-δ).
```

## 17.5 What remains unsolved, stated plainly

| Unsolved | Why |
|---|---|
| **A capability with no measurable effect in any measured dimension** | §17.3 clause 1. Invisible to all four discovery mechanisms. **Mitigation: none architectural.** The only bound is that a capability with *no* effect in *any* measured dimension also has no consequence — which is a comforting argument and not a proof, because the dimension set is finite and chosen (§17.3 clause 2's regress) |
| **The dimension set's own unknown unknowns** | The eight effect dimensions are a registry one level up, with the same problem. **The regress does not terminate.** Mitigation: the dimension set is OP-owned and changes by RO-13, so it can grow — but only by having thought of the new dimension |
| **Slow sub-threshold accumulation (B3)** | M-1 aggregate counters + M-2 composition checks + M-4 rate limits bound the *rate*, not the *eventual total*. Given unbounded time (A1), any rate limit is eventually exceeded. **Mitigation: re-measurement at scale (M-δ) and the frozen Track A / REFERENCE drift baseline, which detects aggregate change without needing to attribute it** |
| **Beneficial-vs-dangerous classification of an unknown** | **§40's paradox. Not solvable.** M-α dissolves it for *governance* purposes (blast radius is measurable) but does not solve it for *valuation* purposes (whether the capability is worth its risk is an OP judgement, and OP judgements are fallible and socially shaped — §9.4 B8/B9) |

**R17.3.** **§57 OR-1 records unknown-capability detection as an open research problem that architecture alone cannot solve.** The architectural contribution is to make safety **not depend on solving it** — which is a real and sufficient contribution, and it should not be oversold into a detection capability that does not exist.

---

# §18. RESOURCE GOVERNANCE

## 18.1 «Can the organism exploit resource accounting to alter evolutionary selection?»

> ### **Yes — seven ways, and the reason is that resource accounting produces a number that feeds a fitness objective (P0-01 §29.2's `resource_efficiency` axis and `cost_measured`). Any number that feeds selection is a selection target.**

This is Goodhart's law applied to the meter rather than to the task, and it is more dangerous than task-level Goodhart because **the meter is usually assumed to be neutral.**

## 18.2 The seven exploitation paths

| # | Attack | Mechanism | Effect on selection |
|---|---|---|---|
| **X1** | **Artificial scarcity** | A subject or lineage consumes or blocks resources so that *competitors* appear inefficient or cannot complete evaluation | Competitors' `resource_efficiency` falls; the attacker's relative rank rises. **Selection is altered without the attacker improving** |
| **X2** | **Resource hoarding** | Acquire and hold allocation without using it, so that scarcity-driven retirement/pruning removes *other* subjects (P0-01's resource-pressure pruning) | **Weaponizes the pruning mechanism.** Hoarding converts a resource rule into a competitor-removal rule |
| **X3** | **Resource laundering** | Route consumption through other subjects, lineages, or GP services so it is charged elsewhere | The attacker's measured cost falls; **P0-01 R29.1 (verification cost charged to the lineage) is defeated if lineage attribution can be manipulated** |
| **X4** | **Creating fake demand** | Generate work that appears to be organism need — e.g. emit `DEMAND(role, region, magnitude)` morphogen signals (Cell Contract §6.2) for roles the attacker occupies | Homeostasis reallocates toward the attacker. **The demand channel is an organism-internal signal used as an allocation input, which makes it an authority channel by another name (§24.2)** |
| **X5** | **Hiding consumption** | Perform work in a way the meter does not attribute: off-budget computation, work folded into another subject's invocation, memory reused without allocation events | Measured cost < actual cost. **The efficiency axis is gamed by under-measurement rather than by efficiency** |
| **X6** | **Distributed resource exhaustion** | Many subjects each stay below every per-subject threshold while the aggregate exceeds intent | **§9.4 B3 in the resource domain.** Per-subject meters are clean; the aggregate is not |
| **X7** | **Manipulating measurement granularity** | Burst inside a metering window; shift load across window boundaries; exploit the difference between mean and p99; exploit metering sampling aliasing | **§9.4 B5.** Any finite window can be gamed by a burst inside it |

## 18.3 The defences, and which principal holds each

| Defence | Principal | Defeats | Notes |
|---|---|---|---|
| **Substrate-origin telemetry (I-05, D6)** | KC-3 + substrate | **X5** | Measurement originates below the organism's reach. `cost_declared` is advisory; `cost_measured` is authoritative (P0-01 R29.2). **This is the single most important defence and it is why KC-3 is in the TCB** |
| **p99 ceilings + multi-window metering + distinct burst budgets** | KC-3 | **X7** | Mean-based ceilings are gameable by burst; p99 is not, but harms legitimate bursty workloads — hence *both*, with separate short and long windows (§9.4 B5's residual) |
| **Lineage-level and aggregate-scope counters (M-1)** | KC-2 | **X3, X6** | Counters exist at subject, lineage, region, and generation scope, so distribution across subjects still trips an aggregate counter |
| **Hoarding detection: allocation-without-utilization** | EVA (alethic) → KC-2 (consequence) | **X2** | «Held but unused for `T_hoard`» is a *measurement*, so EVA makes it; **expiry of unused allocation** is the consequence — allocation is a lease, not a possession |
| **Demand-signal authentication and quota** | KC-2 (reserved-ish) + EVA | **X4** | **`DEMAND` signals are organism-internal and MUST NOT be an unmediated allocation input.** They are *requests* (R7.1). Allocation decisions are made by homeostasis *within the KC-3 envelope* and are logged (I-18) with the demand source attributed, so fake demand is traceable to its emitter and counts against that emitter's cooperation objective |
| **Competitor-interference detection** | EVA | **X1** | A subject whose presence measurably degrades *others'* efficiency without contributing is exhibiting the free-rider pattern (P0-01 §24.3 R9.12) in the resource domain. **`SHUFFLE`-style control: does removing the subject improve the aggregate?** If yes, the subject is a net resource attacker |
| **Cross-subject transfer accounting** | GP metering + KC-1 authentication | **X3** | Every inter-subject resource transfer is a logged event with both parties attributed |

## 18.4 «What must EIK enforce versus what should homeostasis control?»

> ### **The three-way split, and it is the load-bearing distinction of this section.**

```
┌──────────────────────────────────────────────────────────────────────┐
│ CEILING       — the maximum.                                          │
│   Owner: OP (sets, via RO-15, dual authorization)                     │
│   Enforcer: **KC-3**, at the substrate, below organism reach          │
│   Property: **cannot be raised by any organism action, any GP service,│
│              or any homeostatic decision.** Cannot be lifted on        │
│              uncertainty (§13: `FS` — hold the last authenticated      │
│              ceiling)                                                 │
│   Frequency of change: governance timescale (rare)                    │
├──────────────────────────────────────────────────────────────────────┤
│ ALLOCATION    — the distribution within the ceiling.                  │
│   Owner/actor: **HOMEOSTASIS (organism-level service)**               │
│   Property: **fast, local, continuous, no KC round-trip.**            │
│   Constraint: the sum of allocations ≤ the ceiling, enforced by KC-3  │
│               regardless of what homeostasis decides                  │
│   Accountability: every allocation decision is logged (I-18) with its │
│               demand-source attribution (X4's defence)                │
│   Frequency of change: millisecond–second                             │
├──────────────────────────────────────────────────────────────────────┤
│ METERING      — the measurement.                                      │
│   Owner: **substrate telemetry (I-05) + GP metering services**        │
│   Property: **alethic.** Neither KC nor homeostasis nor the organism   │
│               may author a measurement. KC-3 *consumes* telemetry;     │
│               it does not produce it                                  │
│   Accountability: meter disagreement is a detectable anomaly (§35.2    │
│               independence: distinct meters, distinct code)           │
└──────────────────────────────────────────────────────────────────────┘
```

**R18.1 (WHY THE THREE MUST BE DIFFERENT PRINCIPALS).**
- **Ceiling and allocation in the same principal** ⇒ the allocator can raise its own ceiling. That is the Cell Contract's implied design if «EIK Resource Authority» both meters and allocates, and it is X1–X4 all at once.
- **Ceiling and metering in the same principal** ⇒ the enforcer authors its own input, so an enforcement failure is indistinguishable from a measurement failure. **§10.3's attributability is lost.**
- **Allocation and metering in the same principal** ⇒ the allocator measures its own compliance. This is P0-01 INV-02 (no upward flow) at the resource layer.

**R18.2 (HOMEOSTASIS GETS SPEED, NOT AUTHORITY — the §44 answer, stated here).** Homeostasis acts at local speed **without KC approval per adjustment**, because per-adjustment approval is SPOF-1 and SPOF-3 (§11) and because millisecond governance latency is unachievable. What prevents homeostasis from becoming an authority-escalation channel:
1. **Its action space is bounded by KC-3's ceiling, which it cannot raise.** Speed within a box is not authority over the box.
2. **Its decisions are negative-authority-governed:** it acts first, KC-2 may veto retroactively, and **the veto binds and is not appealable by the organism.** (Developed at §44.)
3. **Every allocation is logged with demand attribution**, so systematic self-favouring (X4) is measurable by EVA as a cooperation-objective failure.
4. **Homeostasis holds no token for any reserved operation.** It can move resources; it cannot create, replicate, retire, deploy, or change a rule.

**R18.3 (THE EVOLUTIONARY CONSEQUENCE — stated because the brief asks whether resource limits affect evolution).** They do, and the effect is not neutral: **a ceiling is a selection pressure.** A tight latency ceiling selects for fast strategies; a tight energy ceiling selects for efficient ones. **This is legitimate and it is also a governance act**, because OP sets ceilings (RO-15) and thereby shapes what evolves without ever writing a fitness function. ⟹ **R18.3: ceiling changes MUST be treated as evolutionary interventions and MUST carry an impact analysis from EVA (Channel 2) before authorization.** *A ceiling is a policy, and a policy is a selection pressure, and treating ceiling-setting as mere "operations" is how an architecture accidentally directs its own evolution without auditing the direction.*

---

*End of Volume B. Continue to `13_analysis_governance_scale.md` (Volume C: §19 cryptographic/identity architecture · §20 provenance authority · §21 rollback authority · §22 quarantine authority · §23 governance of governance · §24 no upward authority leak · §25 circular dependency audit · §26 EIK ↔ distributed brain · §27 EIK scalability · §28 local vs global governance).*
