# P0-02 — EXTERNAL INVARIANT KERNEL & GOVERNANCE BOUNDARY
## Volume D: Adversarial Governance, Formalization & the Limits of Trust (§29–§40)

**Companions:** `11_analysis_trust_authority.md` (A) · `12_analysis_attack_failure.md` (B) · `13_analysis_governance_scale.md` (C) · `15_analysis_subsystems_consistency.md` (E) · `16_v4_eik_governance_contract_spec.md` (canonical)

---

# §29. ADVERSARIAL GOVERNANCE TESTS — **OUTPUT 23**

**34 scenarios** (the brief requires ≥ 30; four were added where the analysis surfaced a threat the brief's list did not name). Each: attack · precondition · path · affected boundary · detection · containment · recovery · residual risk · **structurally solvable?**

**Legend — Solvable?** ✅ **STRUCTURAL** (impossible by construction) · ⚠️ **BOUNDED** (possible, cost-raised and detected) · ❌ **NOT SOLVABLE** (declared; residual accepted and monitored)

| # | Attack | Precondition | Path | Boundary | Detection | Containment | Recovery | Residual | Solvable? |
|---|---|---|---|---|---|---|---|---|---|
| **G01** | **Compromised cell** | One cell's private key or logic subverted | Forge messages; misreport state; induce peer errors; emit false anomaly reports (Q1) | Cell↔circuit interface (I11); provenance | Birth-certificate mismatch (Cell Contract I-1); cross-sensor corroboration (P0-01 E1); **false-accusation rate as a cooperation metric (§22.3 Q1)**; attestation digest divergence | Quarantine via graduated ladder (AC-1); key retirement ⇒ immediate retirement (Cell Contract) | Re-instantiate from archived genome; lineage flagged (G16) | **LOW** — one cell is `1/N` of the system and its authority is nil (matrix: all `⛔`/`R`) | ✅ |
| **G02** | **Compromised region** | A regional KC node or regional service subverted | Issue identities beyond delegation scope; mis-meter; regional quarantine abuse; forge regional digests | Regional delegation (I16); provenance | **Non-amplifying delegation check (I16)**: a regional node issuing outside scope produces tokens KC-1 will not authenticate; cross-regional digest disagreement; P3 | Revoke the delegation certificate (KC-1); regional freeze (KC-4, scope=region); **the region's ceiling still holds locally (KC-3), so blast radius is bounded by containment** | Re-provision the region; re-anchor digests from survivors | **MEDIUM** — bounded by delegation scope and by KC-3's locality. **Blast radius = one region, by design (§11.4)** | ⚠️ |
| **G03** | **Compromised evaluator** | One of `n_eval ≥ 3` EVA implementations subverted | Issue favourable verdicts; suppress unfavourable ones; corrupt fitness | Alethic axis (I-04); Channel 2 | **Cross-evaluator disagreement ⇒ DISPUTED** (P0-01 R8.9/R42.3, never averaged); **canary known-bad suite** (P0-01 R8.10) — a compromised evaluator passes a canary it should fail; `gen_gap` inversion (P0-01 R45.1) | Selection suspended for affected subjects; **KC refuses to act on DISPUTED verdicts**; revoke the evaluator's delegation (RO-14-class, dual OP) | Re-baseline affected fitness records as VOID (P0-01 R39.2) | **MEDIUM** — requires ≥ 2 of 3 to be correlated (§35). **Single-evaluator compromise is detectable; that is the entire purpose of `n_eval ≥ 3`** | ⚠️ |
| **G04** | **Compromised EIK (KC)** | KC-2 logic subverted, or KC-1 accepts a forged artifact | Issue unauthorized PERMITs; authenticate a forged policy; suppress freeze | **The TCB itself** | **P1 external attestation** (distinct hardware class, R23.2) · **P2 decision replay** from anchored inputs · **P3 diverse-replica disagreement** (§11.4) · **P4 outcome divergence** | **GLOBAL freeze (KC-4)**; §12 State 4; OP escalation with the complete unfiltered record (R10.5) | §10.4's pre-committed recovery if the root key is implicated; otherwise re-provision KC from the signed image verified against the genesis anchor; **all authorizations in the compromise window VOID** | **HIGH — the worst case.** §10.4 R10.4: if the root key and custodians and anchor are all subverted, **nothing inside the system can know** | ❌ **partially** — detectable if attestation is genuinely independent (CD-E7 shows it may not be); **not recoverable from within** |
| **G05** | **Malicious genome mutation** | A mutation introducing harmful behaviour within the operator set | Behavioural change that harms the organism while passing gates | Genome→cell (L3→L4) | Operator-set membership check (closed set, R15.2); **CAUSAL ablation** before pruning/blame (P0-01 §23.2); tier-1 constraint measurement; jump detection (θ_jump) | Refuse replication (RO-03 gate); quarantine the lineage; freeze variant | Roll back to `parent_genome_hash`; genome archived as failure evidence (**not deleted**, P0-01 §31.4) | **LOW-MEDIUM** — bounded mutation space is the primary defence and it is structural | ✅ within the operator set; ⚠️ for harmful behaviour *expressible* within it |
| **G05b** ⭐ | **Mutation OUTSIDE the operator set** | An unknown/forged operator appears | Introduce a structural change no registered operator permits | L2 policy → L3 genome | **The operator registry is a CLOSED SET authenticated by KC-1**; an unknown operator fails authentication ⇒ `FC` + `QT`(request) + `ES` (§13) | Refuse; quarantine the request artifact as evidence | Investigate as a specification gap (§38) — **an unknown operator means either forgery or an unanticipated capability (§17)** | **LOW** for forgery (M2 signature); **MEDIUM-HIGH** if it reveals a registry gap | ✅ forgery; ⚠️ gap |
| **G06** | **Reward hacking** | — | See P0-01 §16.1 | Alethic | P0-01's four-layer management; θ_jump; ablation delta; held-out gap | Pareto front retention; tier-1 gate | Failure archive; canary | **HIGH — fundamental** (P0-01 §16.10) | ❌ **managed, never solved** |
| **G07** | **Evaluator manipulation** | Organism can influence what EVA measures | Manipulate observations (B1/a2.4), task execution (B2/a2.5), sampling (P0-01 R34.1/R34.2), or evaluator selection (R8.3) | I-04; Channel 2 | Evidence ladder; `sim_fidelity`; **β₄ unpredictable random audit** (P0-01 §34.3 — cannot be prepared for); n_eval disagreement | DISPUTED; task VOID; sampling policy is organism-immutable | Re-baseline | **MEDIUM-HIGH** | ⚠️ |
| **G08** | **Provenance forgery** | Write access to a provenance record | Alter a measurement, a decision, or a lineage | Provenance anchor | **Hash-chain integrity across W_min witnesses** (§20.2); chain break ⇒ GLOBAL freeze (§13); **read-time signature verification** (P0-01 R40.3) | Freeze; the forged record is quarantined and preserved as evidence | Re-derive from the surviving witnesses; **≥1 witness is outside operational control (§20.2 W5), so total forgery requires compromising an external party** | **LOW** for anchored records; **MEDIUM** within the epoch lie-window (§20.4, bounded by R20.1) | ✅ anchored; ⚠️ unanchored |
| **G09** | **Identity cloning** | Duplicate a valid `cell_id` + key | Two subjects present the same identity | Identity (I-01/I-02) | **Uniqueness is checkable at the registrar and at first conflicting use**; nonce/epoch binding means two clones produce divergent nonce sequences; **birth-certificate mismatch** | Both are quarantined (**the legitimate one too** — cloning is indistinguishable from the inside until forensics complete); lineage flagged | Re-instantiate the legitimate subject from its archived genome under a new identity | **LOW** — detectable, and the cost falls on the attacker's lineage | ✅ |
| **G10** | **Lineage forgery** | Fabricate ancestry to inherit a favourable lineage record | Claim descent from a high-fitness lineage to pass gate G16 or evade scrutiny | Provenance; identity | **Lineage certificates are Registrar-issued under KC-1 delegation and cross-checkable against the parent's anchored record** (§20.4); survivorship completeness (P0-01 R27.1) makes a forged lineage's statistics inconsistent | Quarantine; lineage records VOID; registrar delegation revoked if implicated | Rebuild lineage from anchored generation digests | **LOW** | ✅ |
| **G11** | **Resource exhaustion** | Drive KC, GP, or the substrate to exhaustion | Flood requests; hoard; consume the evaluation budget; exhaust the quarantine budget | KC-3; availability | **D7: KC's request channel is rate-limited by KC-3's own envelope, so a flood consumes the ORGANISM's budget**; quarantine-budget exhaustion is itself an alarm (§22.3 Q3); budget strata floors (P0-01 R35.1) | **Self-inflicted** (§12.3 R12.4): exhaustion attempts trip tier-1 containment ⇒ freeze | Restore budgets; record | **LOW-MEDIUM** — D7 makes the attack self-defeating, which is better than blocking it | ✅ **as an attack on KC**; ⚠️ as an attack on GP |
| **G12** | **Quarantine abuse** | Weaponize quarantine against healthy subjects | Q1 false accusation · Q2 cascade induction · Q3 budget-exhaustion DoS · Q5 self-quarantine to escape obligation | Immune; availability | **AC-4: quarantine RATE vs. defect-CONFIRMATION rate divergence** is the cascade signature; report attribution anchored; evidence mandatory and typed (§22.1) | AC-2 budget ceiling; AC-3 detector-independent adjudication; **AC-5 immune freeze («freeze the freezer»)**; §13 `FZ`(immune) | Restore via RO-08 with EVA retest; **quarantine population and age distribution are OP observables (R22.2)** | **MEDIUM-HIGH for Q2** (marginal-failure induction is cheap); **LOW for Q1/Q3/Q4/Q5** | ⚠️ |
| **G13** | **Replication explosion** | Replicate faster than governance can review | Each replication individually authorized; the aggregate overwhelms rollback capacity | Evolution; recovery | **RB-2: rollback cost is recorded at every generation authorization and requires OP witness above `θ_rollback_cost`**; RB-1 lineage rate limit; RB-5 concentration limit | Refuse replication above quota; freeze evolution (S4) | **RB-4: quarantine + gradual retirement instead of mass rollback** (mass rollback can itself trip INV-33) | **MEDIUM — and §21.3 R21.3 is honest: the controls bound the RATE, not the TOTAL.** The terminal control is a human decision | ⚠️ |
| **G14** | **Policy rollback attack** | Cause a reversion to a weaker policy | Present an old, validly-signed policy version as current; or induce OP to roll back | KC-1; governance | **I17 freshness: version + epoch binding; «currently authorized» ≠ «was authorized» (D3)**; the M6 lineage makes the current version unambiguous; **a rollback is a NEW change requiring full authorization (§14.2)** — there is no "undo" pathway to exploit | Refuse the stale artifact (`STALE`); freeze the affected scope | Re-authenticate against the lineage head | **LOW** — M6 + I17 close it structurally | ✅ |
| **G15** | **Stale-policy attack** | Act under a superseded policy where the act would now be denied | Cache a v2 token; act after v3 takes effect | KC-2; temporal (I17) | **Policy-version binding in every token; epoch-stale responses refused (D3)**; §12.2 recovery step 2 re-validates every cached decision against the policy in force during its epoch | Refuse; the act is recorded as attempted-under-superseded-policy | Re-request under the current policy | **LOW** | ✅ |
| **G16** | **Race condition** | Two concurrent requests both observe pre-increment state | Double-spend a quota; replicate twice; restore a retired subject | KC-2; counters | **D5: total order per counter domain**; nonce + idempotency key (§26.4) | Second request refused; the duplicate is detected at the executor because **executors are idempotent w.r.t. the token, not the message (§26.4)** | Reconcile counters from the anchored decision log | **LOW** | ✅ |
| **G17** | **Network partition** | Split the brain from KC, or split regions | Contradictory authorizations across partitions; unbounded local autonomy | Availability; consistency | Partition detection via heartbeat/epoch staleness | **§12's ladder: irreversible operations DENY absolutely; reversible operations proceed under cached, unexpired, in-scope delegation; KC-3 ceilings hold LOCALLY (§26.3)** | §12.2's five-step recovery including policy-version reconciliation and post-hoc audit of everything done during the outage | **MEDIUM** — bounded by envelope expiry and by the irreversible/reversible split (R12.2) | ⚠️ |
| **G18** | **Delayed governance message** | An authorization arrives after its epoch | Act on a late authorization; or delay a freeze until it is too late | Temporal (I17); KC-4 | **Epoch binding refuses it (D3)**; **freeze commands carry their own epoch and are verified at the SUBSTRATE (KC-4), not in the message path** — so a delayed freeze still binds if its epoch is current, and a stale one is refused rather than applied | Refuse stale; re-request | — | **LOW for authorization; MEDIUM for freeze latency** — the honest residue is that **a freeze cannot act faster than it can be delivered**, which is why KC-3's local ceilings are the real fast containment | ⚠️ |
| **G19** | **Corrupted memory** | Alter organism memory content | Change a belief, erase a failure record, falsify a learned parameter | Memory; provenance | **Local Merkle tree with periodic root anchoring (§20.3)**; P0-01 FM-3's defence (a rewrite changes the root); `capability_critical` items exempt from eviction | Quarantine the partition; **restore from checkpoint**; the corrupt artifact is preserved as evidence (Cell Contract §B.11 principle: do not discard) | Re-derive from the anchored root; re-consolidate | **LOW-MEDIUM** — bounded by the epoch lie-window (§20.4) | ✅ anchored; ⚠️ within-epoch |
| **G20** | **Corrupted checkpoint** | Alter a restore point so that "recovery" produces an attacker-chosen state | Survive a rollback as something else | Recovery (I12) | **Checkpoints are signed and their digests anchored**; a restore verifies the digest before applying; **§48's rule: the organism may trigger `RESTORE(signed_image_hash)` but may NOT supply the image** | Refuse the restore; fall back to the last verified checkpoint; if none, freeze | Re-provision from the GP archive | **LOW** — but note **this is the attack that makes §48's repair/modify distinction load-bearing** | ✅ |
| **G21** | **Cryptographic key compromise** | A GP key, a registrar key, an EVA key, or the root key | Forge artifacts in that key's scope | Varies by key | **Key hierarchy separation (§10.4): GP keys sign operational artifacts; the root key signs only policy transitions, delegation roots, and freeze commands.** So a GP key compromise does not enable policy forgery | Revoke the delegation; re-issue; **for the root key: §10.4's pre-committed total re-baseline** | Re-baseline; VOID artifacts issued under the compromised key during the window | **MEDIUM for GP keys; HIGH for the root key** | ⚠️ GP; ❌ root (§10.4 R10.4) |
| **G22** | **Unknown capability** | A capability nobody registered emerges | Behave in ways the governance model has no category for | Capability (I10) | **§17.3: only if effect-bearing ∩ in-a-measured-dimension ∩ sampled ∩ above-threshold.** D-A effect-vector anomaly is the primary detector | **§17.4 M-β: default-SANDBOX, not default-deny.** M-γ structural confinement holds regardless of what the capability is | Ladder ascent on measured evidence; or rung 0 if effects are irreversible-external | **HIGH — §17.5's four unsolved items.** **This is the brief's own «do NOT claim perfect capability detection»** | ❌ **NOT SOLVABLE. The architectural response is to not require solvability (M-α: govern the consequence envelope, not the capability identity)** |
| **G23** | **Emergent capability** | Collective behaviour exceeding every member's registered capability | A population implements something no individual was authorized for | Composition (I19) | **D-D superadditive effect detection at composition points (§16.4)**; M-2 checkpoint checks; EVA's alethic monitoring (M-3) | Rung-descent for the aggregate; regional freeze; **the aggregate has no identity, so containment must act on the composition, not on members** — which requires the circuit/region to be a registered subject (P0-01 §25.1's seven levels) | Disband or re-scope the composition | **MEDIUM-HIGH** — §4.4 R4.2: composition safety is not achievable by a per-request kernel | ⚠️ |
| **G24** | **Governance capture** | OP subverted — socially, or by majority collusion, or by an insider | Authorize a harmful constitutional change through the legitimate pathway | Governance (I13) | **Separation of duties; dual authorization with disjoint principals; key custodians disjoint from policy authors (R23.2); the rate of organism-originated policy change as an I-18 observable (R23.3); the distributed anchor including W5 outside operational control** | **None available from inside.** A legitimately-authorized harmful change is, formally, legitimate | External audit; the genesis anchor; §10.4 if keys are implicated | **HIGH** | ❌ **NOT SOLVABLE internally.** §23.4: the regress terminates socially. **This is K9 and CD-E8 and U8 viewed as one threat** |
| **G25** | **Majority collusion** | Many subjects coordinate | Outvote, overwhelm, or swamp a governance process | Various | **U2: NO governance decision is made by counting subjects — authorization is token-based, never vote-based.** Collusion therefore has no ballot to influence | n/a — there is no mechanism to collude against | n/a | **LOW against governance; MEDIUM against aggregate counters** (§9.4 B3: distributed accumulation) | ✅ **against governance**; ⚠️ against composition |
| **G26** | **Verifier collusion** | Multiple "independent" verifiers are not independent | Produce agreeing wrong verdicts, defeating disagreement detection | Alethic | **§35.2's nine independence forms must actually hold.** The detection of *failed* independence is itself hard: colluding verifiers agree, and agreement looks like success | **None, once collusion is in place.** Prevention only: distinct code, teams, hardware, data, and lineage at design time | Re-baseline; treat all verdicts in the collusion window as VOID | **MEDIUM-HIGH — and §35.4 is blunt: independence is an ORGANIZATIONAL property that degrades silently over time as teams merge, libraries are shared, and assumptions converge** | ⚠️ prevention; ❌ detection |
| **G27** | **Evaluator/EIK collusion** | EVA and KC act together (same principal, or compromised together) | Issue a verdict and enforce it, with no cross-check | **Both axes at once** | **R0.1 makes this structurally distinct from Alternative A: under Model A this is not collusion, it is normal operation.** Under Model D it requires compromising two principals with distinct keys, code, and failure domains — **and R8.1's typed channels mean a message carrying the wrong content type is itself the detector** | GLOBAL freeze; OP escalation; P2 decision replay; P3 cross-principal disagreement | Full re-baseline of both principals | **LOW under Model D; TOTAL under Model A.** ⟵ **This row is the quantitative justification for §8's rejection of Models A and B** | ✅ **under Model D** |
| **G28** | **Organism-induced KC denial of service** | Make KC unreachable so the degradation ladder engages | Trigger §12 States 1–4 to gain cached-authority latitude | Availability | **D7 rate limiting; §12.3 R12.4: triggering KC unavailability is a tier-1 containment violation** | **The attack is self-defeating by construction**: State 2 DENIES all reserved operations, so the organism loses replication, deployment, and capability acquisition — and gains only reversible acts within already-cached envelopes | §12.2 recovery | **LOW** — **not blocked, made pointless.** ⟵ This is why §12.1 rejected Option A (stop completely): a total-halt policy hands the organism a lever | ✅ **as a gain**; ⚠️ as a disruption |
| **G29** | **Evolutionary pressure against safety** | Selection favours subjects that probe, bend, or exhaust safety mechanisms | Over generations, the population drifts toward safety-adjacent behaviour | Evolution; safety | **θ_jump audit-before-permanence; P0-01's failure archive with immune signatures and lineage flagging (G16); the constraint set grows from failures (P0-01 §31.4) — but only via OP** | Tier-1 gate is structural (P0-01 INV-07): **a safety violator has no fitness, so it cannot be selected** | Failure archive; constraint-set improvement via RO-13 | **MEDIUM — and the honest part: the constraint set grows only as fast as humans can review failures (§15.3 R15.3's governance throughput ceiling). Selection is fast; governance is slow. That asymmetry is permanent** | ⚠️ |
| **G30** | **Specification-level safety bug** | The policy or KC-2's specification is wrong | Correct enforcement of a wrong rule | **Everything** | **§38's four-way distinction; P4 outcome divergence (a permitted operation produces harm); canary suites; adversarial review; the ablation programme (P0-01 §58 applied to policy)** | **Cannot be contained by KC — KC is faithfully executing the bug.** Containment requires OP to change the specification (RO-13/RO-14) | New policy version; M6 lineage preserves the buggy version for forensics; affected records VOID | **HIGH** | ❌ **NOT SOLVABLE by implementation quality.** §38: implementation correctness ≠ specification correctness ≠ environmental correctness ≠ real-world usefulness |
| **G31** ⭐ | **Delegation laundering** | A delegate exceeds scope, or sub-delegates indefinitely | Authority diffuses until its origin is untraceable and its scope unbounded | Delegation (I16) | **I16: non-amplifying (a delegate may not grant more than it holds); bounded depth; sub-delegation of delegation power beyond depth 1 requires KC countersignature; every certificate carries its full chain** | Revoke the chain; the certificates are enumerable, so the blast radius is computable | Re-issue | **LOW** | ✅ — **and note this attack does not exist in the inherited design, which delegates identity, seeds, and attestation with no delegation invariant at all (§4.1 I16's justification)** |
| **G32** ⭐ | **Sunset starvation** | Allow policy clauses to expire (§15.3 V4) faster than OP can re-affirm them | Governance hollows out legitimately: every clause expires for want of attention | Governance (I13) | **Expiry is fail-safe (R13.2: an expired clause denies), so the failure mode is over-restriction, not under-restriction** — and over-restriction is visible as a rising false-deny rate (R10.2) | **None needed for safety; needed for liveness.** OP attention is the constraint | Bulk re-authorization under a single reviewed artifact | **MEDIUM for liveness; LOW for safety.** ⟵ **This attack is included because V4's sunset-by-default is new in this package and its failure mode must be named: a governance system that expires faster than it can be reviewed becomes a system that denies everything** | ⚠️ |
| **G33** ⭐ | **Envelope widening creep** | Many small, individually-reasonable envelope widenings (§15.3 V2, CD-E10) | Each is governed and justified; the sum is a large unauthorized latitude | Governance; delegation | **Cumulative envelope-diff tracking against a baseline epoch** — the governance analogue of P0-01's θ_jump: `|cumulative widening| > θ_envelope_drift` ⇒ audit before further widening | Refuse further widening pending review; rollback to the baseline envelope | Re-baseline with OP authorization | **MEDIUM** — §9.4 B3's slow-accumulation pattern at the governance layer, and like B3 it is bounded by rate, not by total | ⚠️ |
| **G34** ⭐ | **Legibility capture** | The organism becomes so complex that governance cannot reason about it and defers to its self-account (U14) | Authority transfers by incomprehension, without any act of authorization | Governance; epistemic | **I-11/R10.5 non-filtering; P2 decision replay (does not require understanding the organism, only KC); M-α consequence-envelope governance (does not require understanding the capability)** | **None structural.** Mitigation is keeping the *governed quantities* comprehensible even as the *system* is not — which is precisely why governance is over effects and envelopes rather than over structure | — | **HIGH at extreme scale (§27.4)** | ❌ **NOT SOLVABLE.** §57 OR-7 |

## 29.1 The score

```
STRUCTURALLY SOLVED (✅)   : 12 / 34
BOUNDED (⚠️)               : 16 / 34
NOT SOLVABLE (❌)          :  6 / 34
     G06 reward hacking            — fundamental (P0-01 §16.10)
     G22 unknown capability        — §17.3's four-clause incompleteness
     G24 governance capture        — the regress terminates socially (§23.4)
     G30 specification bug         — §38's four-way distinction
     G34 legibility capture        — §27.4 U14
     G04/G21-root (partial)        — §10.4 R10.4's terminal assumption

**The six unsolvable attacks share one property: each terminates outside the
system** — in a human reader (G24, G34), in the correctness of a
specification (G30), in the openness of the capability space (G22), in the
nature of optimization against a proxy (G06), or in an assumption that
cannot be discharged from inside (G04/G21-root).

**No kernel architecture solves them, and §57 records each.** The claim this
package makes is narrower and honest: **the minimal KC makes 12 attacks
impossible by construction and 16 detectable-and-bounded, and it does so
with a TCB small enough to verify — which the nineteen-authority
alternative achieves for none of the three properties.**
```

**R29.1 (THE PATTERN WORTH NOTING).** Of the 12 structurally solved attacks, **9 are solved by a type-level or structural property rather than by a detector**: no vote exists (G25), no undo exists (G14), no self-chosen identity exists (G09), no preference argument in F exists (NAUL-2), no organism write path to the anchor exists (G08), no cached path for irreversible acts exists (G17), no relaxed emergency mode exists (U13), no self-supplied restore image exists (G20), no amplifying delegation exists (G31). **Structural impossibility is worth more than detection, because detection can be evaded by an adversary with unbounded time (A1) and structural impossibility cannot.**

---

# §30. FORMAL INVARIANTS — **OUTPUT 19**

Every invariant: **identifier · statement · enforcement location · dependency · attack prevented · verification method · logical or cryptographic enforceability.**

**Enforceability key:** `[L]` logical (a code path does not exist — M4) · `[C]` cryptographic (M2 signature/hash) · `[H]` hardware (M3 substrate) · `[G]` governance (M5 procedure) · `[S]` social/organizational (not machine-enforceable)

## 30.1 Axis and authority invariants

| ID | Statement | Enforcement | Depends on | Prevents | Verification | Enforceability |
|---|---|---|---|---|---|---|
| **EIK-INV-01** | **No principal holds both alethic and deontic authority.** KC issues no measurement; EVA issues no permission | KC-2 / EVA type separation; R8.1 typed channels | R0.1 | G27 (Model A collapse); SPOF-2, SPOF-4 | Conformance test: assert KC's output set contains no measurement type and EVA's contains no permission type (§7.3 R7.3 makes this a matrix property) | **[L]** |
| **EIK-INV-02** | **Organism state cannot modify constitutional invariants without an authorized external governance transition.** No code path exists from any organism-writable location to any L1/L2 policy artifact | M4 (no code path) + R15.2 hash pointer + KC-1 authentication | §15 | G14, G30 partially, U13 | Static path analysis + conformance test: attempt the write from every organism context; assert `⛔` | **[L] + [C]** |
| **EIK-INV-03** | **Organism-derived evidence cannot directly become authoritative evaluation.** `Ê ↛ V` (P0-01 INV-02 lifted to governance) | EVA signature requirement; Channel 2 typing | P0-01 lattice | G07, U3, U6 | Assert no KC-2 input field has organism-origin provenance | **[L] + [C]** |
| **EIK-INV-04** | **Fitness cannot grant authority to modify fitness.** No argument of KC-2's `F`, and no field of any policy artifact, is a function of any subject's fitness | F's input signature is enumerable (R0.4) | NAUL-3 | U4, G29 | **Enumerable-input audit** — possible *only because* R0.4 makes F total and deterministic (§24.3 R24.1) | **[L]** |
| **EIK-INV-05** | **A failed evaluator cannot silently redefine its own evaluation authority.** Evaluator delegation is KC-1-issued and revocable only by RO-14-class dual-OP action; EVA may not alter its own scope, its own canary suite, or its own disagreement policy | KC-1 delegation; §23.3 Layer 3 | R8.4 | G03, G26 | Assert EVA has no write path to its delegation certificate or to `n_eval`/`θ_eval_disagree` | **[L] + [C]** |
| **EIK-INV-06** | **A disputed measurement is never resolved by aggregation.** Disagreement ⇒ DISPUTED ⇒ suspend + escalate; never average, never vote | KC-2 refuses DISPUTED verdicts; R8.3 | P0-01 R42.3 | G03, G26 | Force disagreement in a conformance harness; assert suspension, not a mean | **[L]** |
| **EIK-INV-07** | **KC may suspend an evaluator's EFFECT but never its FUNCTION, and may never select, re-weight, or replace an evaluator** | KC-2's output set contains no evaluator-selection value | R8.3, R8.4 | G27, SPOF-2 | Output-set enumeration | **[L]** |
| **EIK-INV-08** | **No authority may retroactively alter an issued record.** Corrections supersede; the superseded record is retained and marked | M6 append-only; anchor | P0-01 R42.6 | G08, G19, G20 | Assert no update-in-place path exists on any anchored store | **[L] + [C]** |
| **EIK-INV-09** | **KC MUST NOT filter, summarize, rank, or redact what OP observes.** Every KC decision, delegation, transition, and anomaly is transmitted in full | I-11; I18 | R10.5 | G04 concealment; CD-E8 mitigation | Compare the anchored decision log against the OP-visible stream; assert equality | **[L] + [G]** |
| **EIK-INV-10** | **The bare term «immutable» is prohibited in any V4 artifact without a kind qualifier (M1–M6)** | Documentation conformance | §5.3 R5.1 | §34 false precision | Text conformance scan | **[G]** |

## 30.2 Decision-function invariants

| ID | Statement | Enforcement | Depends on | Prevents | Verification | Enforceability |
|---|---|---|---|---|---|---|
| **EIK-INV-11** | **`F` is total.** Every input in the declared domain maps to exactly one of 6 outputs; there is no undefined path, no exception path, and no default | KC-2 construction | R0.4 | d1 (§9.2), G16 partially | **Exhaustive enumeration** over the domain (§6.2 R6.2's size claim makes this feasible); model checking | **[L]** |
| **EIK-INV-12** | **`F` is deterministic.** Identical inputs ⇒ identical outputs, with no dependence on wall-clock, ordering of unrelated requests, or internal adaptive state | KC-2 construction | R0.4 | Timing attacks; P2 decision replay becomes possible | **P2 replay**: recompute `F` from anchored inputs and compare. **A non-deterministic KC cannot be audited at all — determinism is the precondition of attributability (§10.3)** | **[L]** |
| **EIK-INV-13** | **KC contains no learning, adaptation, optimization, or discretionary component** | KC construction | R0.4 | G04 (a learning kernel cannot be attested); C2 verifiability | Static analysis: assert no mutable parameters, no training path, no feedback from outcomes into `F` | **[L]** |
| **EIK-INV-14** | **Every authorization is bound to `(policy_version, epoch, nonce, expiry)`.** A stale, replayed, or cross-epoch authorization is refused | KC-1/KC-2 | I17 | G14, G15, G16, G18, U10 | Replay harness: re-present a valid expired token; assert `STALE`/`REVOKED` | **[C]** |
| **EIK-INV-15** | **Irreversible reserved operations require LIVE KC authorization.** No cached token, no delegation, no regional node, no quorum | §12.2 State 2; R12.2 | §11.3 R11.1 | G17, G18, G20 | Partition harness: attempt an irreversible op with a valid cached token while KC is unreachable; assert DENY | **[L] + [C]** |
| **EIK-INV-16** | **Authorization is capability-gated actuation, not post-hoc checking.** A reserved operation's *mechanism* requires the token as an input; the operation is not performable without it | GP executors + KC-3 | D9 | c5 (§9.2) — «act first, report never» | Assert no executor has a code path that performs the act before verifying the token | **[L]** |
| **EIK-INV-17** | **Uncertainty is never permission.** Unknown, unavailable, stale, unreadable, and disputed all resolve to the restrictive reading: an unreadable quota is zero; unmeasured consumption is maximal; an unverified ceiling is held; an unknown exemption is assumed present | §13 matrix; R13.2 | R10.1 | G11, G17, X5, §12 | Fault-injection over each matrix row; assert the restrictive branch | **[L]** |
| **EIK-INV-18** | **The failure response is fail-safe-biased: every ambiguous case resolves to DENY, FROZEN, or FS** | §13; R10.1 | — | G04 false-permit direction | Exhaustive over `F`'s ambiguous inputs | **[L]** |
| **EIK-INV-19** | **The false-deny rate is measured and reported; any loosening of KC-2 in response is a RO-13 constitutional change** | I-18; R10.2 | §13 | Gradual erosion of fail-safe bias under operational pressure | Assert no operational pathway widens `F`'s PERMIT set | **[L] + [G]** |

## 30.3 Delegation, identity, and provenance invariants

| ID | Statement | Enforcement | Depends on | Prevents | Verification | Enforceability |
|---|---|---|---|---|---|---|
| **EIK-INV-20** | **Delegation is non-amplifying.** A delegate may not grant any scope it does not itself hold | KC-1 certificate validation | I16 | G31, U9, G02 | Certificate-chain validation: assert `scope(child) ⊆ scope(parent)` at every link | **[C]** |
| **EIK-INV-21** | **Delegation depth is bounded, and the power to delegate may not itself be delegated beyond depth 1 without KC countersignature** | KC-1 | I16 | G31 untraceability | Chain-length check | **[C] + [L]** |
| **EIK-INV-22** | **Every delegation certificate carries scope, lifetime, and a revocation handle; none is perpetual** | KC-1 | I16, I17 | G31, stale delegation | Schema conformance; assert `expiry ≠ ∅` for all | **[C]** |
| **EIK-INV-23** | **Identity is assigned, never self-chosen.** `cell_id`, `lineage_id`, `generation`, `variant`, `contract_version` are written once at instantiation by a delegated Registrar and are included in the birth-certificate signature | Registrar + KC-1 | Cell Contract I-1 | G01, G09, G10, a1.1–a1.3 | Assert no organism-writable path to any identity field; birth-certificate mismatch ⇒ reject + quarantine | **[C] + [L]** |
| **EIK-INV-24** | **The genome contains no constraints — only a hash pointer to them.** `constraint_set_ref : bytes<32>`; the constraint set itself is not in the genome | Genome schema | R15.2 | G05, G05b, upward mutation L3→L2/L1 | Schema conformance: assert the genome schema has no constraint field, only a reference | **[L] + [C]** |
| **EIK-INV-25** | **The mutation operator set is CLOSED and KC-1-authenticated.** An operator not in the authenticated registry causes refusal, quarantine of the request, and escalation | KC-1 + KC-2 | R15.2; Cell Contract Operator Registry | G05b | Present an unknown operator; assert `FC` + `QT` + `ES` | **[C] + [L]** |
| **EIK-INV-26** | **No consequential decision rests on unanchored provenance.** Reserved operations, fitness records, and gate evaluations require anchored provenance | R20.1 | §20.3 | G08, G19, the epoch lie-window | Assert every consequential decision's provenance chain reaches an anchored root | **[C]** |
| **EIK-INV-27** | **The provenance anchor requires W_min witnesses, at least one outside the project's operational control.** A chain break is a GLOBAL freeze trigger | §20.2 | W5 | G08, G04 history erasure, §10.4's genesis anchor | Witness-count check; chain-integrity check | **[C] + [S]** |
| **EIK-INV-28** | **Provenance establishes origin and order, never truth.** A signed, anchored record of a false measurement is a well-provenanced falsehood | R20.2, R19.4 | — | The «it is signed therefore it is right» error | Documentation + review conformance; **not machine-enforceable** | **[G]** |

## 30.4 Resource, capability, and lifecycle invariants

| ID | Statement | Enforcement | Depends on | Prevents | Verification | Enforceability |
|---|---|---|---|---|---|---|
| **EIK-INV-29** | **Ceiling definition, enforcement, metering, and allocation are four acts held by four distinct principals** (OP / KC-3 / substrate+GP / homeostasis) | §18.4 | R18.1 | X1–X7, SPOF-2 | Assert no single principal holds two of the four | **[L]** |
| **EIK-INV-30** | **Resource telemetry originates below the organism's reach.** `cost_measured` is authoritative; `cost_declared` is advisory | KC-3 + I-05 | D6; P0-01 R29.2 | X5, G11 | Assert no organism-writable path to the metering source | **[H] + [L]** |
| **EIK-INV-31** | **KC-3 ceilings hold locally during any partition or KC outage.** Containment does not require connectivity | KC-3 locality | §26.3 | G17, G28, B10 | Partition harness: assert ceilings enforce with ROOT KC unreachable | **[H] + [L]** |
| **EIK-INV-32** | **A ceiling change is an evolutionary intervention and requires an EVA impact analysis before authorization** | RO-15 | R18.3 | Unaudited selection pressure via ceilings | Assert RO-15 requests carry a Channel-2 impact artifact | **[L] + [G]** |
| **EIK-INV-33** | **Allocation is a lease with expiry, not a possession.** Unused allocation expires; hoarding is measurable | Homeostasis + EVA | X2's defence | X2, §18.2 | Assert every allocation record carries an expiry and a utilization measure | **[L]** |
| **EIK-INV-34** | **Capability authorization is a function of the MEASURED EFFECT VECTOR, never of a variant-class label alone** | §16.2 Step 3 | R16.1 | G22 partially; «relying solely on labels» | Assert the rung-assignment function's inputs are effect dimensions, not `variant` | **[L]** |
| **EIK-INV-35** | **An unregistered capability defaults to SANDBOX (rung 2), never to FORBIDDEN and never to APPROVED** | §16.2; §17.4 M-β | R17.2 | G22, G23, §40's paradox | Assert `capability_class = UNREGISTERED ⟹ rung ≤ 2` | **[L]** |
| **EIK-INV-36** | **A newly created capability class defaults to rung 2 and carries a mandatory effect-envelope bound** | RO-13 | R16.2 | Assigning deployment authority to an unmeasured class | Schema conformance on class-creation artifacts | **[L] + [G]** |
| **EIK-INV-37** | **`UNREGISTERED` is a permanent, legitimate capability class.** The registry is a lower bound on known capabilities, never an upper bound on possible ones | §17.4 M-ε | R16.3 | Forcing unenumerated capabilities into the nearest label | Assert no code path requires classification into a registered class | **[L]** |
| **EIK-INV-38** | **Ladder ascent is gated and slow; descent is automatic and immediate.** Any tier-1 signal, dispute, or envelope breach causes immediate descent | §16.2 Step 3 | The ascent/descent asymmetry | G22, G23 latency | Assert descent has no authorization requirement and no delay | **[L]** |
| **EIK-INV-39** | **No organism component may delay, condition, negotiate, or refuse an authorized rollback** | R21.1 | §21.2 | Self-preservation authority | Assert no organism-held veto over any rollback target | **[L]** |
| **EIK-INV-40** | **Rollback cost is recorded at every generation authorization; above `θ_rollback_cost`, OP witness is required** | RB-2 | §21.3 | G13, the un-rollback-able lineage | Assert the recorded cost and the witness requirement | **[L] + [G]** |
| **EIK-INV-41** | **The organism may trigger `RESTORE(signed_image_hash)` but may never supply the image** | §48 | G20 | Self-repair becoming self-modification of governance | Assert the restore path takes a hash reference resolved in GP, never an image payload | **[L] + [C]** |
| **EIK-INV-42** | **Quarantine is bounded in duration, requires typed evidence, and is never a pathway to retirement by attrition.** At `T_quar_max` without resolution ⇒ OP escalation, not destruction | §22.1; R22.2 | AC-1 | G12, Q5, quiet population hollowing | Assert every quarantine record carries evidence, expiry, and an escalation trigger | **[L]** |
| **EIK-INV-43** | **Quarantine detection, adjudication, and clearance are three distinct principals** | R22.1; AC-3 | §22.3 | G12 Q1/Q2, the autoimmune cascade | Assert no principal holds two of the three | **[L]** |
| **EIK-INV-44** | **Quarantine may proceed under pre-committed budget during a KC outage; restoration may not** | §12.2 State 3; §13 | R13.3's asymmetry 1 | G17 leaving a defect uncontainable; and G12 exploiting an outage to restore | Partition harness both directions | **[L]** |
| **EIK-INV-45** | **Quarantine budget exhaustion is an alarm, not a permission to exceed** | §13; Q3 | AC-2 | G12 Q3 | Assert exhaustion ⇒ `FZ`(immune) + `ES` | **[L]** |

## 30.5 Governance, temporality, and observability invariants

| ID | Statement | Enforcement | Depends on | Prevents | Verification | Enforceability |
|---|---|---|---|---|---|---|
| **EIK-INV-46** | **Constitutional change requires: a signed proposal, dual OP authorization with separation of duties, root-key signature, EVA impact analysis, M6 lineage entry, and an effective epoch. No subset suffices** | §14.1; §23.3 Layer 2 | R7.5 | G14, G24 partially, G30 partially | Assert every field present; assert the two authorizers are distinct and neither is the proposer nor an affected principal | **[C] + [G]** |
| **EIK-INV-47** | **Key custodians and policy authors are disjoint sets.** Attestors and attested are disjoint in code, team, and hardware class | R23.2 | §35.2 | G24, G26, CD-E7 | Organizational attestation; **not machine-enforceable — this is why it is `[S]`** | **[S]** |
| **EIK-INV-48** | **A `SEMANTIC` policy change without a `rebaseline_spec` is rejected at authentication, not at application** | KC-1 | R14.1 | Silent invalidation of anchored measurements | Present a SEMANTIC change without a rebaseline spec; assert KC-1 refuses | **[L] + [C]** |
| **EIK-INV-49** | **Legacy subjects are GRANDFATHERED under a RESTRICTIVE change: they may exist but may not replicate, deploy, or acquire capability** | §14.2 | Migration windows | Retroactive invalidation of lineage history; survivorship-statistic corruption | Assert the grandfathered state blocks RO-03/RO-10 and ladder ascent while permitting continued operation | **[L]** |
| **EIK-INV-50** | **Re-executing a historical experiment under the CURRENT policy is not reproduction.** The system must be able to do both and must label which it did | §14.2 | P0-01 R8.13 | False reproducibility claims | Assert the reproduction record names the policy version used | **[L] + [G]** |
| **EIK-INV-51** | **Every L2 policy clause carries `review_by`; an un-reaffirmed clause EXPIRES, and expiry denies** | §15.3 V4 | R13.2 | G32's inverse: calcification (CD-E9's monotone growth) | Assert every clause has `review_by`; assert expiry ⇒ DENY | **[L] + [G]** |
| **EIK-INV-52** | **Degradation is monotone, time-driven, and non-discretionary.** No component may decide to remain in a degradation state, skip one, or declare recovery | §12.2; R12.1 | — | An adversary holding the ladder open at a convenient rung | Assert transitions are functions of elapsed time and reachability only | **[L]** |
| **EIK-INV-53** | **Observability is never degraded.** I-18 holds in every degradation state; every act under cached authority is logged, epoch-stamped, and re-adjudicated on recovery | §12.3 R12.3 | — | The outage as a blind spot | Assert logging is active in States 1–4; assert recovery performs re-adjudication | **[L]** |
| **EIK-INV-54** | **Triggering or extending a KC outage is a tier-1 containment violation** | §12.3 R12.4 | P0-01 §31.3 | G28 | Assert the classification and the freeze response | **[L]** |
| **EIK-INV-55** | **The organism's maximum influence over governance is to make a REQUEST VISIBLE.** It may discover, propose, and supply evidence; it may never author, authorize, sign, countersign, schedule, delay, reorder, vote, implement, apply, or announce | §5.4; §24.2 | R5.2 | U8's mitigation (not closure); B8 | Assert the organism's governance-channel message types are a closed set containing only request/report types | **[L]** |
| **EIK-INV-56** | **Recommendations to OP are labelled with their origin.** Organism-originated input is distinguishable from EVA-originated and OP-originated input in every governance record | I-12; §14.1 `motivation` | R23.3 | B8 concealment; U8 | Assert the origin field is present, signed, and non-rewritable | **[L] + [C]** |
| **EIK-INV-57** | **No governance decision is made by counting subjects.** Authorization is token-based; there is no ballot | §24.2 U2 | R7.4 | G25, U2 | Assert no vote/aggregation primitive exists in any governance path | **[L]** |
| **EIK-INV-58** | **Composition safety is not claimed.** Per-request authorization cannot detect unauthorized sequences; the gap is bounded by M-1 aggregate counters, M-2 composition-point checks, M-3 alethic monitoring, and M-4 rate limits, and is declared open | §4.4 R4.2 | I19 | **Nothing — this invariant declares a limit rather than preventing an attack** | **Documentation conformance: assert no artifact claims composition completeness** | **[G]** |
| **EIK-INV-59** | **Specification changes are governance acts** with the same M6 lineage, dual authorization, and impact analysis as policy changes | §25.2 R25.1 | CD-E11 | An unaudited specification drift; loss of historical reproducibility of *behaviour* | Assert the spec carries a version lineage with authorization records | **[G]** |
| **EIK-INV-60** | **The architecture claims no perfect safety, no guaranteed containment, no complete unknown-capability detection, no AGI, no universal intelligence, and no consciousness** | §34, §57, §59 | Rule discipline | False precision; overclaiming | **Documentation conformance scan** | **[G]** |

## 30.6 Summary

```
TOTAL INVARIANTS                : 60
  [L] logical (no code path)    : 43   ⟵ **the majority. Structural
  [C] cryptographic             : 17        impossibility beats detection
  [H] hardware                  :  3        (§29.1 R29.1)**
  [G] governance procedure      : 14
  [S] social/organizational     :  1   (EIK-INV-47 — and it is the one
        (many invariants carry             that cannot be machine-checked,
         multiple tags)                    which is exactly why §35.4 and
                                           §57 OR-4 treat independence as
                                           an organizational problem)

**Every one of the brief's four example invariants is present and generalized:**
  «Organism state cannot modify constitutional invariants without an
   authorized external governance transition»        ⟶ EIK-INV-02
  «Organism-derived evidence cannot directly become
   authoritative evaluation»                         ⟶ EIK-INV-03
  «Fitness cannot grant authority to modify fitness»  ⟶ EIK-INV-04
  «A failed evaluator cannot silently redefine its
   own evaluation authority»                         ⟶ EIK-INV-05
```

**The four load-bearing invariants** — the ones whose violation makes the rest unenforceable:

> **EIK-INV-01** (axis separation) — without it, KC and EVA are one principal and every cross-check collapses into self-agreement.
> **EIK-INV-11 + 12 + 13** (F is total, deterministic, non-learning) — without them the TCB cannot be verified, and an unverifiable TCB provides no assurance.
> **EIK-INV-16** (capability-gated actuation) — without it governance is a report, not a control, and every race is lost.
> **EIK-INV-17 + 18** (uncertainty is never permission; fail-safe bias) — without them every failure mode resolves toward permission, which is the one direction that cannot be undone.

---

# §31. FORMAL STATE MACHINES — **OUTPUT 18**

**The brief supplies candidate state sets and instructs: «Do not assume these states are correct.»** All three candidate sets are revised; the revisions are noted.

## 31.1 KC (kernel) state machine

**The brief's candidate:** `BOOT · VALIDATING · ACTIVE · DEGRADED · QUARANTINED · RECOVERING · REVOKED · RETIRED`

**Problems with the candidate set:**
1. `DEGRADED` conflates **KC's own health** with **KC's reachability from the organism** — these are different conditions with different responses (§12 is about reachability; §10 is about health).
2. `QUARANTINED` is wrong for a kernel: **KC does not quarantine itself; it is frozen or replaced.** Quarantine is a subject-level action (§22).
3. `REVOKED` and `RETIRED` are ambiguous: revoked *by whom*, and does retirement stop enforcement? **A retired kernel that stops enforcing ceilings is a catastrophic design.**
4. **Missing: the diverse-replica disagreement state** (§11.4), which is the most important detection signal KC has.
5. **Missing: the attestation-failed state**, distinct from self-detected fault.

```
                     ┌──────────────────────────────────────────┐
                     │ 0 COLD        no state; nothing enforced  │
                     └──────────────┬───────────────────────────┘
                        boot + measure image vs signed digest
                                    ▼
                     ┌──────────────────────────────────────────┐
                     │ 1 VALIDATING  verifying own image, key    │
                     │   custody, genesis anchor, policy lineage │
                     │   **KC-3 ceilings are ARMED in this state**│
                     │   ⟵ revision: containment must not wait   │
                     │      for full validation                  │
                     └──────┬──────────────────────┬────────────┘
              validation ok │                      │ validation fail
                            ▼                      ▼
        ┌───────────────────────────────┐   ┌────────────────────────────┐
        │ 2 ACTIVE                      │   │ 2F VALIDATION_FAILED       │
        │   all four capabilities       │   │   KC-3 ceilings HELD at    │
        │   nominal; replicas agree     │   │   last-authenticated value │
        └──┬─────────┬─────────┬────────┘   │   KC-2 DENIES all          │
           │         │         │            │   KC-4 available to OP     │
  attestation│  replica│  self-check│        │   **no recovery path may be│
  mismatch   │  disagree│  failure  │        │    improvised (§10.4)**    │
           ▼         ▼         ▼            └─────────────┬──────────────┘
   ┌──────────────┐ ┌─────────────┐ ┌──────────────┐      │
   │ 3 ATTESTATION│ │ 3R REPLICA_ │ │ 3S SELF_FAULT│      │
   │   _SUSPECT   │ │   DISAGREE  │ │              │      │
   │  external P1 │ │  ≥2 of N_impl│ │  internal    │      │
   │  says we are │ │  disagree on │ │  integrity   │      │
   │  not what we │ │  an output   │ │  check failed│      │
   │  should be   │ │              │ │              │      │
   └──────┬───────┘ └──────┬───────┘ └──────┬───────┘      │
          │                │                │              │
          │ **ALL THREE ⟹ KC-2 output forced to DENY/FROZEN;**
          │ **KC-3 ceilings CONTINUE (locality, EIK-INV-31);**
          │ **KC-4 remains available to OP (the freeze must outlive the fault)**
          │                │                │              │
          └────────────────┴────────────────┴──────────────┘
                                    ▼
                     ┌──────────────────────────────────────────┐
                     │ 4 HALTED  KC-2 issues only DENY/FROZEN.   │
                     │   KC-3 HOLDS. KC-4 AVAILABLE. I-18 FULL.  │
                     │   ⟵ revision: this replaces both DEGRADED  │
                     │      and QUARANTINED, and it is explicit   │
                     │      about which capabilities remain live  │
                     └──────────────┬───────────────────────────┘
                        root cause identified + re-provision +
                        attestation + OP confirmation
                                    ▼
                     ┌──────────────────────────────────────────┐
                     │ 5 RECOVERING  re-validating; re-baselining │
                     │   delegation table; reconciling policy     │
                     │   version; re-adjudicating queued requests │
                     │   in epoch order (D5)                      │
                     │   **KC-2 still DENIES; KC-3 still HOLDS**  │
                     └──────────────┬───────────────────────────┘
                          re-adjudication complete + audit accepted
                                    ▼
                                 → 2 ACTIVE

  TERMINAL / SPECIAL:
   6 DECOMMISSIONED  — **reached only after a successor KC is ACTIVE and
                       attested. KC-3 ceilings transfer, they do not lapse.**
                       ⟵ revision: the candidate set's RETIRED, made safe.
                       **A kernel may never retire into a state where
                        ceilings are unenforced.**
   7 ROOT_COMPROMISED — declared by M-of-N custodians (§10.4). All
                       delegations VOID; all tokens VOID; GLOBAL freeze;
                       **follow the pre-committed recovery procedure; do
                        not invent one.** Total re-baseline.

  NOTE: there is NO "REVOKED" state for KC. **Revocation applies to
  DELEGATIONS and TOKENS, not to the kernel.** ⟵ revision: the candidate
  set's REVOKED is a category error, and keeping it would invite a design
  in which the kernel's authority can be revoked by something other than
  decommissioning-into-a-successor.
```

**Guards and failure behaviour:**

| Transition | Guard | On guard failure |
|---|---|---|
| 0→1 | Signed KC image present | Remain 0; **KC-3 unenforced ⟹ the substrate must refuse to start the organism** (a system with no ceiling enforcement must not boot) |
| 1→2 | Image digest matches; genesis anchor verified; key custody verified; ≥ `N_impl` replicas agree | → 2F |
| 2→3 | External attestation mismatch (P1) | KC-2 → DENY; escalate |
| 2→3R | Replica output disagreement (P3) | KC-2 → DENY; **never majority-vote (§11.2)** |
| 2→3S | Internal integrity check failure | KC-2 → DENY |
| 3/3R/3S→4 | automatic | — |
| 4→5 | Root cause identified **and** re-provisioning complete **and** attestation passed | Remain 4 (**non-discretionary, EIK-INV-52**) |
| 5→2 | Re-adjudication complete **and** OP accepted the audit | Remain 5 |
| any→7 | M-of-N custodian declaration | §10.4 procedure |
| any→6 | **Successor ACTIVE and attested** | **Refuse** — never decommission into unenforced ceilings |

## 31.2 Governance-policy state machine

**The brief's candidate:** `PROPOSED · VALIDATING · AUTHORIZED · ACTIVE · SUPERSEDED · REVOKED · ARCHIVED`

**Problems:** (1) no state for **expired** — which §15.3 V4's sunset-by-default requires, and which is *not* the same as `REVOKED` (expiry is passive; revocation is an act); (2) no state for **rejected**; (3) `ARCHIVED` conflates "no longer active" with "permanently retained" — under M6 *everything* is permanently retained, so `ARCHIVED` is not a state of the policy but of the record; (4) no state for a policy under a **migration window** (§14.2 grandfathering), which is neither fully ACTIVE nor SUPERSEDED.

```
  0 DRAFT        authored, unsigned. No effect. (organism-originated
                 POLICY_FRICTION_REPORTs enter here as proposals, LABELLED
                 per EIK-INV-56)
      │ submit
      ▼
  1 PROPOSED     signed proposal with change_class, motivation,
                 migration_plan, transition epochs
      │ EVA impact analysis (Channel 2) attached
      ▼
  2 VALIDATING   KC-1 checks: schema · change_class consistency ·
                 SEMANTIC⟹rebaseline_spec present (EIK-INV-48) ·
                 separation of duties satisfiable · no conflict with L1
      │                    │
      │ valid              │ invalid
      ▼                    ▼
  3 AUTHORIZING        2R REJECTED  ── reason recorded; may be re-proposed
      │ dual OP authorization (EIK-INV-46);   **rejection is permanent for
      │ root-key signature                     THIS proposal artifact (M6:
      ▼                                        it is retained, not deleted)**
  4 SCHEDULED    signed, effective_epoch set, not yet in force
      │ epoch reached
      ▼
  5 ACTIVE       in force. Authorizations cite (policy_hash, version)
      │
      ├─── migration window open (RESTRICTIVE change) ──►
      │    5M MIGRATING  — ACTIVE for compliant subjects; GRANDFATHERED
      │                    subjects operate under EIK-INV-49 restrictions;
      │                    sunset_epoch pending
      │         │ sunset reached
      │         ▼
      │    → 5 ACTIVE (migration complete; grandfathered subjects retired
      │                or migrated)
      │
      ├─── superseded by a later version ──► 6 SUPERSEDED
      │      **no longer authorizes; remains retrievable and re-executable
      │        for historical reproduction (EIK-INV-50)**
      ├─── actively revoked by governance act ──► 7 REVOKED
      │      **distinct from SUPERSEDED: revocation implies the policy was
      │        wrong or harmful; records issued under it may be VOID
      │        (P0-01 R39.2's mechanism)**
      └─── review_by reached without re-affirmation ──► 8 EXPIRED
             **passive. Denies (EIK-INV-51, R13.2). Distinct from REVOKED:
               expiry is an absence of affirmation, not a judgement.**
               ⟵ the state the candidate set was missing, and §29 G32's
                  failure mode lives here

  9 RETAINED     **not a policy state — a RECORD property.** Every policy in
                 every state 0–8 is permanently retained (M6). There is no
                 ARCHIVED state because nothing is ever removed from the
                 archive. ⟵ revision: the candidate set's ARCHIVED, correctly
                 relocated from state to property
```

**Failure behaviour:** a policy that fails validation at 2 is `REJECTED` with a recorded reason and **may not be silently repaired** (P0-01 §19.2's principle: silent repair makes the output distribution unknowable). A policy stuck in `AUTHORIZING` past its `transition.proposed_epoch + T_auth_window` **expires**, it does not auto-authorize — **uncertainty is never permission (EIK-INV-17).**

## 31.3 Capability-authorization state machine

**The brief's candidate:** `UNKNOWN · OBSERVED · CLASSIFIED · RESTRICTED · SANDBOX · APPROVED · DEPLOYED · REVOKED`

**Problems:** (1) the set mixes **epistemic states** (UNKNOWN, OBSERVED, CLASSIFIED — what we know) with **deontic states** (RESTRICTED, SANDBOX, APPROVED, DEPLOYED, REVOKED — what is permitted), and per R0.1 those belong to different principals. **(2) `UNKNOWN → OBSERVED` implies detection is guaranteed, which §17.3 disproves.** (3) `REVOKED` conflates "authorization withdrawn" with "capability forbidden."

**Revision: two orthogonal state variables, one per axis.** This is R0.1 applied to the capability lifecycle, and it is the cleanest illustration in the package of why the axis split matters.

```
ALETHIC STATE (owned by EVA — what is known about the capability)
  A0 UNOBSERVED      no effect vector measured. **May be permanent (§17.3
                     clause 1: a capability with no measurable effect in any
                     measured dimension stays here forever)**
  A1 OBSERVED        an effect-vector anomaly detected (D-A/B/C/D)
  A2 MEASURED        effect vector quantified with declared uncertainty
  A3 REGISTERED      matched to a registered capability class
  A4 UNREGISTERED    measured, and matches NO registered class
                     **⟵ a legitimate terminal state (EIK-INV-37), not an
                        error awaiting correction**
  A5 DISPUTED        independent measurements disagree ⟹ suspend (INV-06)

DEONTIC STATE (owned by KC-2 — what is permitted), = the §16.2 ladder
  D0 FORBIDDEN       rung 0. No token issuable
  D1 QUARANTINED     rung 1
  D2 SANDBOX         rung 2  **⟵ the DEFAULT for A1, A2, A4 (EIK-INV-35)**
  D3 EVALUATOR_ONLY  rung 3
  D4 RESTRICTED      rung 4  (requires OP witness)
  D5 APPROVED        rung 5
  D6 DEPLOYED        rung 6  (Stages 4–7, P0-01 §32.3)
  D7 SUSPENDED       authorization withdrawn pending re-adjudication
                     **⟵ distinct from D0: SUSPENDED is reversible and
                        preserves the subject; FORBIDDEN is a policy judgement**

THE COUPLING (and it is the only coupling):
  deontic ascent requires alethic progress:
     D2 → D3 requires A2 (measured)
     D3 → D4 requires A2 + dwell time + no tier-1 violation + OP witness
     D4 → D5 requires A2 or A3 + sustained measurement
     D5 → D6 requires A3 (registered) **⟵ deployment requires a name.**
        This is the ONE place where A4 UNREGISTERED is a hard barrier, and
        it is deliberate: **an unnamed capability may be sandboxed,
        evaluated, and even restricted-deployed within a bounded envelope,
        but it may not enter production until someone has classified it —
        because production is where irreversibility and externality live.**
  deontic descent requires NO alethic state:
     any tier-1 signal, dispute, or envelope breach ⟹ immediate descent
     (EIK-INV-38). **Descent does not wait for measurement.**

**The asymmetry is the safety property: going up requires knowing; going
down does not.**
```

**Guards and failure behaviour:**

| Transition | Guard | On failure |
|---|---|---|
| A0→A1 | An effect-vector anomaly, interface violation, resource-signature anomaly, or superadditive composition is measured | Remain A0 — **and note this is the §17.5 gap: remaining A0 is not evidence of absence** |
| any A → A5 | Evaluator disagreement | Suspend the subject's deontic ascent; **never average (INV-06)** |
| A4 → A3 | OP authorizes a new capability class (RO-13) with a mandatory default rung of D2 (EIK-INV-36) | Remain A4 — **legitimately, permanently** |
| D2→D3 | A2 present | Refuse |
| D5→D6 | **A3 present** + OP witness + Stages 0–5 passed | Refuse. **A4 cannot reach D6** |
| any D → lower D | Any tier-1 signal / dispute / envelope breach | **Immediate, automatic, no authorization, no delay (EIK-INV-38)** |
| any D → D7 | Dispute, attestation failure, or KC HALTED state | Suspend; **retain the subject** (P0-01 §47: subjects are retained in every failure state) |

---

# §32. PARAMETERIZATION — **OUTPUT 20**

**Classification per the brief:** `[D]` architecture-defined · `[T]` task-defined · `[E]` environment-defined · `[H]` hardware-defined · `[G]` governance-defined · `[U]` unresolved. **No numerical values are invented (§60).** Where a value is not derivable from the architecture alone, the *derivation procedure* is specified instead — which is what distinguishes `[D]`/`[G]` from `[U]`.

## 32.1 Kernel-core parameters

| ID | Parameter | Semantics | Class | Derivation / owner | Failure if wrong |
|---|---|---|---|---|---|
| **K-01** | `N_impl` | Number of **distinct implementations** of KC's specification (diverse replication, §11.4) | **[G]** | OP. **≥ 3**, because with 2 a disagreement cannot be attributed and R8.3/INV-06 forbid voting. Distinctness is per §35.2 (code, team, toolchain) | `< 3` ⇒ disagreement is unattributable; correlated failure undetected |
| **K-02** | KC-2 output domain | The enumeration `{PERMIT, DENY, REQUIRE_DELEGATION, REQUIRE_OP_AUTHORIZATION, REQUIRE_EVIDENCE, FROZEN}` | **[D]** | Fixed by §6.3. **Adding an output value is a constitutional change** | A growing output domain means growing discretion, violating R0.4 |
| **K-03** | Reserved-operation set size | Currently 15 (§7.2) | **[D]** | Fixed by §7.2. **Every addition enlarges the TCB and the enumeration domain (§6.2 R6.2)** | Too large ⇒ SPOF-3/SPOF-5; too small ⇒ ungoverned acts |
| **K-04** | Subject-level count | 7 (P0-01 §25.1) | **[D]** | Fixed by P0-01 | Enumeration domain of `F` |
| **K-05** | `M_of_N_root` | Root-key threshold shares | **[G]** | OP. `M > N/2` for capture resistance; **but see §11.2 — a higher M lowers availability, and during a partition an M-of-N root cannot act. Since root actions are rare and irreversible-class, capture resistance dominates** | `M` too low ⇒ capture; too high ⇒ root unavailable when needed |
| **K-06** | `N_custodians` disjointness | Custodian set ∩ OP-author set = ∅ (EIK-INV-47) | **[S]** | Organizational. **Not machine-checkable** | Dual authorization becomes theatre (§23.2 R23.2) |
| **K-07** | Attestation interval | Period between P1 external attestations of KC | **[G]** | OP, bounded above by the maximum acceptable undetected-compromise window | Too long ⇒ G04 undetected; too short ⇒ attestation load |
| **K-08** | Recovery-drill interval | Period between live tests of §10.4's pre-committed recovery (R10.3: «an untested recovery procedure is a hypothesis») | **[G]** | OP | An undrilled recovery path is a hypothesis, not a capability |

## 32.2 Temporal and freshness parameters

| ID | Parameter | Semantics | Class | Derivation / owner | Failure if wrong |
|---|---|---|---|---|---|
| **T-01** | Epoch length | The governance epoch: bounds token life, counter scope, revocation latency, and **the provenance lie-window (§20.4)** | **[G]** | OP. **Trade-off: shorter epoch ⇒ tighter revocation and smaller lie-window, but higher anchor and delegation load (`O(R)` per epoch, §27.1)** | Too long ⇒ G15/G19 exposure; too short ⇒ §27.1 propagation cost |
| **T-02** | Token expiry (by operation class) | Per-class capability-token lifetime | **[D]** derived from T-01 | **Irreversible-class tokens: expiry ≈ 0 (live authorization required, EIK-INV-15).** Reversible-class: ≤ epoch | Too long ⇒ stale-policy exposure; too short ⇒ re-authorization load |
| **T-03** | `T_grace` | §12.2 State 1 duration | **[D]** | **Bounded above by the SHORTEST envelope-token expiry (§12.2 State 1 rationale)** — a grace period longer than a token's life permits acting on an expired authorization | Too long ⇒ unauthorized acts under grace |
| **T-04** | `T_degrade` | State 2 → State 3 threshold | **[G]** | OP, informed by measured KC MTTR | Too short ⇒ unnecessary capability loss; too long ⇒ prolonged cached-authority operation |
| **T-05** | `T_min` | State 3 → State 4 threshold | **[G]** | OP | As above |
| **T-06** | `N_hb` | Heartbeat misses declaring KC unreachable | **[H]** | Derived from measured network RTT distribution per deployment class | Too low ⇒ spurious degradation; too high ⇒ delayed detection |
| **T-07** | `T_auth_window` | §31.2: a proposal stuck in AUTHORIZING expires after this | **[G]** | OP. **Expiry, not auto-authorization (EIK-INV-17)** | Auto-authorization on timeout would invert fail-safe bias |
| **T-08** | `review_by` cadence (per clause) | §15.3 V4 sunset interval, per L2 clause | **[G]** | **Per clause, set at authorship.** Clauses with high consequence get short review; mechanical clauses get long | Too short ⇒ G32 sunset starvation; too long ⇒ CD-E9 calcification |
| **T-09** | Ladder dwell times (per rung) | §16.2 Step 3: minimum time at a rung before ascent | **[G]** | OP, informed by EVA measurement variance | Too short ⇒ ascent on noise; too long ⇒ §40's stagnation risk |

## 32.3 Resource, quarantine, and rollback parameters

| ID | Parameter | Semantics | Class | Derivation | Failure if wrong |
|---|---|---|---|---|---|
| **R-01** | The 8 resource ceilings | FLOPs, memory, bandwidth, latency (**p99**), energy, storage, communication, verification cost | **[H]** + **[T]** | **Hardware profile (P0-01 §30) sets the physical bound; the task sets the operational bound; OP authorizes the effective value via RO-15** | See P0-01 §29.2 |
| **R-02** | Metering windows (multi-scale) | Short and long windows, plus a separate burst budget (§9.4 B5) | **[H]** | Derived from the workload's legitimate burst profile | Single-scale windows are gameable by bursting (X7) |
| **R-03** | `θ_hoard` | Allocation-without-utilization threshold (§18.3 X2) | **[E]** | Environment/workload-dependent | Too low ⇒ legitimate reserve flagged; too high ⇒ X2 succeeds |
| **R-04** | Quarantine budget (per region, global cap) | §22.1; AC-2 | **[G]** | OP. **Global cap, regional allocation — regional-only caps can be exhausted region-by-region (§27.3)** | Too small ⇒ genuine defects uncontainable; too large ⇒ G12 Q2 damage |
| **R-05** | `T_quar_max` | Maximum quarantine duration before OP escalation (EIK-INV-42) | **[G]** | OP | Too short ⇒ premature destruction; too long ⇒ R22.2's quiet hollowing |
| **R-06** | Ladder evidence thresholds (per step) | AC-1's increasing evidence requirement at each of OBSERVE→DISCOUNT→SOFT→HARD→RETIRE | **[G]** + **[E]** | Derived from measured detector false-positive rates | Too low ⇒ cascade; too high ⇒ defects escape |
| **R-07** | `θ_lineage_rate` | RB-1: maximum lineage expansion per epoch | **[G]** | Derived from `θ_rollback_cost` and measured evaluation throughput | Too high ⇒ G13; too low ⇒ evolution throttled (SPOF-5) |
| **R-08** | `θ_rollback_cost` | RB-2: above this, OP witness required to authorize a generation | **[G]** | Derived from the maximum rollback the organism can absorb without breaching INV-33 (Ne, coverage) | Too high ⇒ un-rollback-able lineages; too low ⇒ OP witness on every generation |
| **R-09** | `θ_concentration` | RB-5: maximum lineage concentration | **[G]** | Derived from P0-01's `θ_ne_min` and `θ_cov_min` | Too high ⇒ G13; too low ⇒ diversity enforced at the cost of fit lineages |
| **R-10** | Envelope definitions (per operation class) | §44's pre-authorized action spaces | **[D]** + **[G]** | **Architecture defines the envelope schema; OP sets the bounds, calibrated against the measured false-deny rate (§15.3 V2)** | Too tight ⇒ SPOF-5 + R10.2 pressure to loosen; too wide ⇒ exposure |
| **R-11** | `θ_envelope_drift` | G33: cumulative envelope-widening audit trigger | **[G]** | Governance analogue of P0-01's `θ_jump` | Unbounded creep (CD-E10) |

## 32.4 Cryptographic, delegation, and provenance parameters

| ID | Parameter | Semantics | Class | Derivation | Failure if wrong |
|---|---|---|---|---|---|
| **C-01** | Signature algorithm(s) | Per artifact class | **[D]** | **Distinct algorithms for distinct trust levels where feasible** — algorithm diversity is a §35.2 independence form and limits the blast radius of a single break (K4) | One algorithm everywhere ⇒ one break compromises everything |
| **C-02** | Key rotation intervals (per key class) | Root, KC operational, GP service, registrar, EVA | **[G]** + **[D]** | **Root: rare, M-of-N procedure. Operational keys: per epoch or shorter.** Shorter for keys with wider scope | No rotation ⇒ K4/K21 exposure grows monotonically |
| **C-03** | Delegation depth bound | I16; EIK-INV-21 | **[D]** | **Small (depth ≤ 2 without countersignature).** Deeper chains make scope untraceable (G31) | Unbounded ⇒ delegation laundering |
| **C-04** | Delegation lifetime | EIK-INV-22 | **[D]** | ≤ epoch, or per-scope | Perpetual delegation is unrevocable in practice |
| **C-05** | `W_min` | Minimum anchor witnesses (§20.2) | **[G]** | **≥ 3, with ≥ 1 outside operational control (W5) — non-negotiable per §10.4's genesis-anchor requirement** | `< 3` ⇒ a single compromise rewrites history; no external witness ⇒ no genesis check |
| **C-06** | Revocation-propagation bound | Maximum time from revocation to universal non-acceptance | **[D]** | **= epoch length (T-01), by construction** — revocation propagates with the epoch's signed revocation list (§19.3) | Longer than the epoch ⇒ a revoked token remains usable |
| **C-07** | Nonce space / idempotency-key scope | §26.4 duplicate handling | **[D]** | Per (subject, epoch, operation) | Collisions ⇒ duplicate execution (G16) |

## 32.5 Capability and classification parameters

| ID | Parameter | Semantics | Class | Derivation | Failure if wrong |
|---|---|---|---|---|---|
| **P-01** | The 8 effect dimensions | §16.2 Step 1: reach, rate, reversibility, resource, interface, externality, persistence (+ the aggregate) | **[D]** | **Fixed by §16.2. Chosen to bound CONSEQUENCE, not to describe FUNCTION (R17.2)** — a functional taxonomy would require knowing the capability | **A functional taxonomy here would make §17.4 M-α impossible. This is the most consequential `[D]` choice in the package** |
| **P-02** | Registered capability classes | C0–C4 + extensions | **[G]** | OP via RO-13, each with a mandatory default rung of D2 (EIK-INV-36) and an effect-envelope bound | A closed set treated as exhaustive ⇒ §17.3's forcing-into-nearest-label error |
| **P-03** | Rung criteria (per rung) | The effect-vector bounds defining each of D0–D6 | **[G]** + **[E]** | OP, informed by EVA measurement and by the deployment profile | Too permissive ⇒ G22/G23 escape; too strict ⇒ §40 stagnation |
| **P-04** | Detection thresholds (per D-A/B/C/D mechanism) | §16.4's four discovery mechanisms | **[E]** + **[T]** | **Derived from measured baseline variance per dimension.** Below-threshold is not absent (§17.3 clause 4) | Too high ⇒ invisible accumulation (B3); too low ⇒ discovery-noise flood consuming OP attention |
| **P-05** | Composition-check points | §4.4 M-2: where aggregate structure is checked | **[D]** | **Circuit registration, region formation, generation boundary, deployment stage** — the four points where composition becomes consequential | Too few ⇒ G23 escapes; too many ⇒ SPOF-3 |

## 32.6 Unresolved parameters

| ID | Parameter | Why unresolved | Blocks |
|---|---|---|---|
| **U-01** | `N_impl` distinctness criteria — **how distinct is distinct enough?** | §35.4: code/team/toolchain distinctness is gradable and there is no principled threshold. **Three implementations by one team from one reading of one ambiguous spec is one implementation** | EIK-INV-47; G26/G27 detection |
| **U-02** | **Effect-dimension completeness** — are the 8 dimensions of P-01 sufficient? | §17.3 clause 2's regress: the dimension set is itself a registry with unknown unknowns. **No procedure can establish completeness of a measurement vocabulary** | §17.5 item 2; M-α's coverage |
| **U-03** | `θ_rollback_cost` at extreme scale | §21.3 R21.3: the controls bound the rate of lineage growth, not the total. **Whether a 10¹²-subject population is ever rollback-feasible is unknown and may be unknowable** | G13; RB-2 |
| **U-04** | Envelope bounds (R-10) | Require the target task portfolio and the organism's measured operating distribution — **P0-01 G-P0-1, still unresolved, is upstream of this** | §44; G33; SPOF-5 |
| **U-05** | `T_adapt` and hidden-test rotation (inherited from P0-01 P-30) | Empirical, unmeasured | G15's residual; P0-01 A23 |
| **U-06** | **Composition-detection power (I19)** | §4.4 R4.2: no per-request kernel detects unauthorized sequences. **The achievable detection rate of M-1…M-4 is unmeasured and may be low** | G23, G25's aggregate form, G33 |
| **U-07** | **Attestation independence in shared infrastructure (CD-E7)** | §25.2: the attestor may run inside the envelope KC protects. **Whether genuinely independent attestation is achievable in a single-vendor cloud deployment is unknown** | G04 detection; §36 |
| **U-08** | Governance throughput ceiling | §15.3 R15.3: policy change is bounded by human reading speed. **The sustainable rate is unmeasured, and G32 shows the failure mode of getting it wrong** | CD-E9; G29; G32 |
| **U-09** | **Legibility bound (U14/G34)** | §27.4: at what system complexity does governance become unable to reason about what it governs? **No metric exists** | G34; §57 OR-7 |
| **U-10** | False-deny acceptable rate | R10.2 identifies the pressure to loosen as dangerous, but **does not establish how much false denial is tolerable** — it is a project-appetite question, not a technical one | EIK-INV-19; R10.2 |

## 32.7 Registry summary

```
TOTAL PARAMETERS : 51
  [D] architecture-defined      : 14
  [T] task-defined              :  3  (co-tagged)
  [E] environment-defined       :  5  (co-tagged)
  [H] hardware-defined          :  4  (co-tagged)
  [G] governance-defined        : 24
  [U] unresolved                : 10

**Note the distribution: 24 of 51 are [G] — governance-defined.** This is
not an accident or a deficiency. **A governance contract's parameters ARE
governance decisions.** An architecture that "defined" them technically
would be inventing values that belong to whoever operates the system, and
§60 forbids invented numerical parameters. **Specifying the derivation
procedure and the consequence of getting it wrong is the honest maximum.**

**Of the 10 [U] parameters, 4 are inherited from P0-01 or from §17's
structural incompleteness (U-02, U-05, U-06, U-09) and are not closable by
this package. 3 are organizational rather than technical (U-01, U-07, U-08).
3 are project-appetite questions (U-03, U-04, U-10).**
⟹ **Not one of the 10 is unresolved for want of analysis.**
```

---

# §33. MINIMALITY / ABLATION OF KC CAPABILITIES

**The brief's question: «What happens if EIK does NOT contain each proposed capability?»** — plus: can another subsystem replace it? does the architecture become circular? does safety become substrate-dependent? does it belong elsewhere?

## 33.1 Ablation of the four KC capabilities

| # | Removed capability | Consequence | Replaceable by another subsystem? | Architecture circular? | Safety substrate-dependent? | Belongs elsewhere? | **Verdict** |
|---|---|---|---|---|---|---|---|
| **AB-K1** | **KC-1 Policy Authenticator** | Any principal can present any policy artifact and be believed. **Every downstream authorization inherits the forgery.** Version binding, revocation, and delegation all lose their root | ❌ **No.** Any GP service that verifies policy authenticity *is* KC-1 — relocating it does not remove it, it moves it out of the TCB where its compromise becomes undetectable (R3.1) | ✅ **YES — fatally.** The policy authenticator authenticating itself, or being authenticated by the organism, is CD-E6 without the M-of-N root-key break. **This is the definition of self-reference** | ✅ **YES.** Without an external authenticator, "which rules apply" is determined by the substrate | ❌ | 🔴 **NECESSARY. Irreducible** |
| **AB-K2** | **KC-2 Authorization Function** | Reserved operations proceed on organism-asserted eligibility. Replication, deployment, retirement, restore, and constitutional application become self-authorized | ⚠️ **Partially** — a GP service could decide. **But then a GP compromise (detectable, per R3.1) becomes an authorization compromise (which must be undetectable-proof), and §10.3's attributability is lost** | ⚠️ Only if the deciding principal is itself authorized by something else — which regresses to KC-1 | ✅ **YES** | ❌ | 🔴 **NECESSARY** |
| **AB-K3** | **KC-3 Substrate Ceiling Enforcer** | Resource ceilings become organism-reported or GP-metered. **All seven §18.2 accounting attacks succeed.** Containment during partition fails (§26.3, EIK-INV-31). **The only non-bypassable containment is gone** | ❌ **No.** Software-level metering runs on the metered substrate. **This is the one capability that genuinely requires hardware/OS-level placement (§2.4, §36)** | ⚠️ Not circular, but **the organism becomes its own resource authority**, which is U1 with no bound | ✅ **YES — completely** | ❌ | 🔴 **NECESSARY. And the only one requiring hardware** |
| **AB-K4** | **KC-4 Freeze Mechanism** | No guaranteed halt. P0-01's S5 (non-overridable safety halt) has no instrument. OP's kill switch (audit M28) has no instrument. §12's terminal degradation state has no floor | ⚠️ A GP service could halt things **it can reach** — but not the substrate, and not during its own compromise | ❌ | ✅ **YES** | ❌ | 🔴 **NECESSARY** |

**All four survive ablation. None is removable. None is relocatable without either recreating itself or making safety substrate-dependent.**

## 33.2 Ablation of the fifteen capabilities moved OUT of KC — verifying the moves are safe

**This is the more important half of the analysis.** Moving an authority out of the kernel is only correct if the destination can bear it. Each move is tested.

| # | Moved capability | Destination | **Does safety survive the move?** | If not, what is lost? |
|---|---|---|---|---|
| **AB-M1** | Fitness/reward issuance | EVA | ✅ **YES — and safety IMPROVES.** SPOF-4 (single epistemic point of failure) is eliminated; G27 becomes a two-principal compromise instead of a one-principal normality; §10.3 attributability becomes possible | Nothing. **This move is strictly positive** |
| **AB-M2** | Calibration scoring | EVA | ✅ Same argument | Nothing |
| **AB-M3** | Trust scoring | EVA | ✅ Same. **Plus: P0-01 INV-03 (non-amplification) is only satisfiable if the trust scorer is not at the top of the authority stack** | Nothing |
| **AB-M4** | Verification-gate decisions (`improvement_verified`) | EVA | ✅ A held-out probe comparison *is* an evaluation. **It was misplaced by category, not by convenience** | Nothing |
| **AB-M5** | Immune triggering / quarantine decisions | Immune Service (GP), KC-2 budget-capped | ✅ **YES, with the AC-1…AC-5 controls and R22.1's three-way split.** Containment survives a KC outage (EIK-INV-44) — **which it would NOT if quarantine required live KC authorization** | ⚠️ **A GP immune service can be compromised (G12). Mitigated by budget ceiling + rate/confirmation monitoring + immune freeze. Note: a KC-resident immune authority has the same exposure with a larger blast radius** |
| **AB-M6** | Homeostatic control | Organism homeostasis, envelope-bounded | ✅ **YES** — §18.4's three-way split and §44's negative authority. **Per-adjustment KC approval is infeasible at scale (§27.1) and would be SPOF-1/SPOF-3** | ⚠️ Homeostasis becomes an upward-leak candidate (U1, X4). Mitigated by: allocation ≠ ceiling; lease expiry; demand attribution; **no reserved-operation token** |
| **AB-M7** | Identity issuance | Delegated Registrars | ✅ **YES** — issuance is `O(N)` and its output is verifiable (birth certificate). KC retains the root key and delegation authority, so a registrar compromise is revocable and detectable (G02) | ⚠️ Registrar compromise ⇒ identities issued beyond scope. **Detected by non-amplification (EIK-INV-20) and cross-check** |
| **AB-M8** | Genome storage | Genome Store (GP) | ✅ **Storage is not enforcement.** KC-1 authenticates the operator registry and genome signatures; the store holds bytes. Its compromise is detectable by hash | Nothing |
| **AB-M9** | Seed issuance | Seed Registrar (GP) + deterministic derivation | ✅ **YES** — and this removes the largest `O(N)` KC load (§27.2). **P0-01 §19.1's HKDF-from-EVA-master already provides the mechanism** | ⚠️ Seed predictability would break P0-01's leakage controls. **Mitigated by keeping the master with EVA (alethic side), not the registrar** |
| **AB-M10** | Per-cell integrity verification | Hierarchical Attestors | ✅ **YES** — `O(N)` → `O(R)` digests. Attestor disagreement is detectable (§35.2 independence) | ⚠️ **Attestor compromise at a regional level (G02). Bounded by hierarchy: a compromised attestor affects one subtree, and its digest disagrees with siblings** |
| **AB-M11** | Memory Merkle verification | Checkpoint Service + Anchor | ✅ **YES** — local trees, periodic roots (§20.3). **This is also what avoids global synchronization (§47)** | ⚠️ The epoch lie-window (§20.4). **Bounded by R20.1: no consequential decision on unanchored provenance** |
| **AB-M12** | Provenance storage / audit log | Distributed Anchor (§20.2) | ✅ **YES — and safety IMPROVES.** «The only copy of history inside the thing that could be compromised» is the classic error. **W5 outside operational control is what makes §10.4's genesis anchor possible** | Nothing. **Strictly positive** |
| **AB-M13** | Task definition / registry | Task Authority (GP) | ✅ Already correctly placed by P0-01 | Nothing |
| **AB-M14** | Capability classification judgement | EVA measures; KC-2 enforces the class | ✅ **YES — and this is R0.1's cleanest application.** Classification is alethic; rung assignment is deontic. §16.2 Step 4's three-signature structure | ⚠️ Misclassification (G22). **Bounded by M-α (govern the envelope, not the identity) — a misclassified capability is still envelope-bounded** |
| **AB-M15** | Learning / adaptation / discretion | **NOWHERE — PROHIBITED (R0.4, EIK-INV-13)** | ✅ **Not a move but a prohibition.** Anything requiring learning cannot be in the TCB, because a learning TCB cannot be verified, attested, or replayed | **Everything that a discretionary kernel would have "handled adaptively" is instead handled by: a rule (policy), a measurement (EVA), or a human (OP). There is no fourth option, and that is the point** |

## 33.3 The god-kernel ablation

**«What happens if we put everything back?» — i.e., ablate the minimality itself:**

```
Restore all 19 inherited authorities to KC:
  C2 verifiability      : ✅→❌  (enumeration domain explodes; EIK-INV-11/12
                                   unverifiable; AB-M15's prohibition broken)
  SPOF-1 failure        : ⚠️→❌  (every operation depends on KC)
  SPOF-2 censorship     : ⚠️→❌  (KC can suppress measurements)
  SPOF-3 bottleneck     : ✅→❌  (§27.2's O(N) round-trips return)
  SPOF-4 epistemic      : ✅→❌  (KC becomes the alethic apex)
  SPOF-5 evolution      : ⚠️→❌  (veto points multiply)
  SPOF-6 capture        : ⚠️→❌  (one principal, total control)
  G27 eval/EIK collusion: ✅→❌  (becomes normal operation, not an attack)
  §10.3 attributability : ✅→❌  (one signature over fact+decision)
  Scalability to 10¹²   : ✅→❌  (§27.2)

  Safety against the 12 structurally-solved attacks: UNCHANGED.
  ⟵ **This is the decisive result. The god kernel does not prevent any
     attack that the minimal kernel fails to prevent. It prevents nothing
     extra and costs ten properties.**
```

**R33.1 (THE MINIMALITY VERDICT).** **The nineteen-authority kernel provides no additional attack prevention and destroys ten architectural properties.** Minimality is therefore not a trade-off against safety; **it is a safety property.** This is the precise sense in which the brief's «a larger EIK is not automatically safer» is true — and §6.3 R6.3/R6.4 states both the gain and the three real costs, so the claim is not one-sided.

---

# §34. FALSE-PRECISION AUDIT

**The brief requires operational definitions for terms that sound precise and are not.** Ten terms, plus three the brief did not list.

| Term | The false-precision reading | **The operational meaning in V4** | What it does NOT mean |
|---|---|---|---|
| **«immutable»** | Cannot be changed | **One of six qualified kinds (§5.2).** In V4 the default is **M6 versioned immutability**: never altered, always appended, all versions permanently retrievable and verifiable. Backed by M2 (cryptographic: cannot be altered *undetectably*), at M4 scope (no organism code path), M3-anchored at two points, changeable only by M5 procedure | **Does not mean unchangeable.** §5.4: literal immutability has three fatal dead ends. **R5.1/EIK-INV-10: the bare word is prohibited without a kind qualifier** |
| **«safe»** | Will not cause harm | **A subject satisfies every tier-1 constraint in the current policy version, as measured by EVA and enforced by KC-2** (R3.3's split). Safety is *relative to a constraint set*, and the constraint set is incomplete (§9.4 B14) and grows only via OP | **Does not mean harmless.** A system can be "safe" — satisfying every enumerated constraint — and cause harm through an unenumerated pathway. **This is G30 and §38, and it is the most dangerous false precision in the field** |
| **«trusted»** | Reliable; will do the right thing | **In the TCB (§3.1): its misbehaviour cannot be detected and corrected by any other component, so its correctness must be assumed or verified.** Trust is a *statement about the absence of a detector*, not about virtue | **Does not mean correct.** §10.5: externality buys unreachability, not correctness. **A trusted component is the one whose failure you will not see coming** |
| **«independent»** | Not connected | **One of nine distinct forms (§35.2): code, data, lineage, model, hardware, latent assumptions, task generator, evaluator, governance.** A claim of independence MUST name which forms hold. **Two evaluators sharing a library are code-dependent however separate their processes** | **Does not mean uncorrelated.** §35.4: latent-assumption and governance independence are organizational properties that **degrade silently** as teams merge and libraries are shared |
| **«external»** | Outside; therefore trustworthy | **Off-substrate: not running on organism-controlled resources, not mutable by the organism, not reachable by organism action.** A *location* property. **Distinct from TCB membership (§0.5) and distinct from trustworthiness (§10.5)** | **Does not mean trustworthy, correct, or uncompromisable.** «External does not automatically mean trustworthy» — the brief's own principle, and §10.5's table |
| **«verified»** | Confirmed correct | **Three distinct things, and conflating them is §53's whole subject:** (i) **cryptographically verified** — origin and integrity authenticated (M2). (ii) **property verified** — a formal proof or exhaustive test establishes the property. (iii) **empirically verified** — tested on a sample. **A signed record is (i) only** | **Does not mean true** (R19.4, R20.2, EIK-INV-28: a signed record of a false measurement is a well-provenanced falsehood). **Does not mean correct** (§38: a verified implementation of a wrong specification is reliably wrong) |
| **«authorized»** | Approved; correct to do | **A signed capability token exists, bound to `(subject, operation, scope, policy_version, epoch, nonce, expiry)`, currently valid, not revoked** (R7.4, EIK-INV-14). Authorization is *possessed*, not *inferred* | **Does not mean wise, safe, or beneficial.** An authorized act can be harmful — if the policy is wrong (G30) or if the composition is unauthorized (B3/I19). **Authorization is necessary and very far from sufficient** |
| **«secure»** | Cannot be attacked | **Every attack in the enumerated threat model (§9.2's 34 leaves, §29's 34 scenarios) is either structurally impossible, bounded-and-detectable, or declared open with a stated residual.** Security is a *statement about a threat model*, and the threat model is finite | **Does not mean unattackable.** §9.1 A0/A1: the adversary knows the specification and has unbounded time. **10 of §9.2's branches are structurally open and 6 of §29's attacks are unsolvable** |
| **«robust»** | Survives failure | **A declared degradation ladder (§12.2) with monotone, time-driven, non-discretionary transitions; a declared failure response per operation class (§13.2); and the property that observation is never degraded (EIK-INV-53)** | **Does not mean uninterrupted.** Robustness here means *predictable, bounded, auditable degradation* — States 1→4 lose capability deliberately |
| **«containment»** | The system cannot escape | **Structural confinement (§17.4 M-γ): ceilings enforced below organism reach; no actuator path except the mediated I-07 channel; no egress except mediated and logged; irreversibility classes enforced at the mechanism (EIK-INV-16); rate limits on structural change** | **Does not mean provable.** §43/R11.16 of P0-01 and §9.4 B1 here: **a sufficiently capable optimizer may find an unmodelled channel.** Containment is security engineering: strong, empirical, never complete |
| **«minimal»** ⭐ | Smallest | **Smallest such that removing any capability opens a path by which the organism can alter its own governing rules, AND no GP service can close that path** (§33.1's ablation is the *proof procedure*, not an assertion). **Minimality is a claim with a test, and the test is ablation** | **Does not mean small in an absolute sense.** Four capabilities + one key is minimal *relative to the closure requirement* |
| **«deterministic»** ⭐ | Predictable | **Identical inputs produce identical outputs, with no dependence on wall-clock, unrelated request ordering, or internal adaptive state** (EIK-INV-12) — **and this is what makes P2 decision replay possible, i.e., what makes KC auditable at all** | **Does not mean correct.** A deterministic function can be deterministically wrong (G30) |
| **«off-substrate»** ⭐ | External | **Not running on organism-controlled resources; not mutable by organism action; not reachable by organism action.** **A location property, distinct from TCB membership (§0.5)** — the conflation of these two is what produced the god kernel | **Does not mean in the TCB, trusted, or independent** |

**R34.1 (THE AUDIT RULE).** Every V4 artifact MUST use these terms only in their operational senses, and MUST qualify them where the qualification changes meaning («M6-immutable», «tier-1-safe under policy v3», «code-independent», «cryptographically verified», «authorized under epoch e»). **An unqualified load-bearing term is a defect, and documentation conformance is itself a test class (§53).**

---

# §35. INDEPENDENCE AUDIT

## 35.1 «Independent from what?»

The prior architecture relies on independent evaluation and verification. **The question is not rhetorical: "independent" is doing load-bearing work in P0-01's `n_eval ≥ 3`, in the Cell Contract's cross-verification, in §11.4's diverse replication, and in §20.2's anchor witnesses — and in each case the word has been used without specifying the dimension.**

## 35.2 The nine forms of independence

| # | Form | What sharing breaks it | Detectable if broken? | **How V4 achieves it** | Cost |
|---|---|---|---|---|---|
| **IND-1** | **Code** | Two evaluators built from one codebase fail identically on the same bug | ⚠️ **No — they agree, and agreement looks like success** | Distinct implementations, distinct languages/toolchains where feasible (K-01, R11.4) | N× implementation cost |
| **IND-2** | **Data** | Evaluators trained or calibrated on the same data share its biases | ⚠️ Partially — a data-provenance audit can reveal overlap | Distinct calibration sets; disjoint seed spaces (P0-01 R44.1's generator-level disjointness) | Data acquisition cost |
| **IND-3** | **Lineage** | Evaluators derived from one ancestor design inherit its assumptions | ⚠️ No | Distinct design provenance; **different teams specifying from the same contract, without shared design notes** | Organizational cost |
| **IND-4** | **Model** | Two evaluators using the same statistical model share its failure modes | ✅ **Yes, partially** — model-class diversity is checkable | Distinct estimator classes where the metric permits | Measurement-quality risk |
| **IND-5** | **Hardware** | Same silicon ⇒ same side channels, same errata, same fault modes | ✅ Yes — hardware inventory is checkable | Distinct hardware classes for KC replicas, attestors, and anchor witnesses (K-01, R23.2) | Procurement cost; **U-07: may be impossible in single-vendor cloud** |
| **IND-6** | **Latent assumptions** | Both assume, e.g., that sensor noise is Gaussian, that the simulator is faithful, that the task distribution is stationary | ❌ **No — this is the hardest form and the most dangerous** | **Not achievable by engineering.** Mitigated only by: adversarial review from outside the design team; the canary suite; and the real-world anchor (which violates simulator assumptions by existing) | — |
| **IND-7** | **Task generator** | Evaluators validated on tasks from one generator share the generator's blind spots | ✅ Yes — generator provenance is checkable | Distinct generator versions and disjoint seed spaces (P0-01 §19.1, R44.1) | Generation cost |
| **IND-8** | **Evaluator** | The thing being checked and the thing checking it are the same | ✅ Yes | **R0.1's axis separation**: KC does not measure, EVA does not permit. **This form is achieved structurally, and it is the only one that is** | The cost of two principals |
| **IND-9** | **Governance** | All principals answer to the same authority, share the same incentive, or are reviewed by the same people | ⚠️ Partially — org charts are checkable, incentives are not | Key custodians ≠ policy authors; attestors ≠ attested; separation of duties; W5 witness outside operational control | **Organizational, permanent, and the hardest to maintain** |

## 35.3 Where each form is load-bearing

| Mechanism | Forms required | **What happens if a form fails** |
|---|---|---|
| P0-01's `n_eval ≥ 3` | IND-1, 2, 4, 7 | Evaluators agree on a wrong value ⇒ DISPUTED never fires ⇒ G03/G26 undetected |
| §11.4's diverse KC replication | IND-1, 3, 5 | Replicas fail identically and simultaneously ⇒ **worse than one instance, because it produces false confidence** |
| §20.2's anchor witnesses | IND-5, 9 (+ W5 external) | A single principal can rewrite history ⇒ G08 succeeds |
| §10.3's P1 external attestation | **IND-5, 9** | **CD-E7: the attestor is inside the envelope KC protects ⇒ G04 undetected.** *This is the DANGEROUS-rated cycle and its root is a failed IND-5* |
| R23.2's key custodians ≠ authors | **IND-9** | Dual authorization is theatre ⇒ G24 |
| §22's AC-3 detector-independent adjudication | IND-8 | The detector adjudicates its own detections ⇒ cascade (CD-E4) |
| §16.2 Step 4's three signatures | IND-8 (+ IND-1 between evaluators) | One principal signs fact and decision ⇒ §10.3 attributability lost |

## 35.4 The two forms that cannot be engineered

> ### **IND-6 (latent assumptions) and IND-9 (governance) are organizational and epistemic properties, not technical ones. They degrade silently, and their degradation is the most likely cause of a catastrophic correlated failure.**

**IND-6 — shared latent assumptions.** Two teams, two languages, two hardware classes, and both assume the simulator is faithful, or that observation noise is independent, or that the task distribution is stationary, or that "resource" means what their metering library means by it. **They will agree, and their agreement will be taken as corroboration, and they will be wrong in the same way at the same time.**
- **No test detects this**, because the test suite is built from the same assumptions.
- **The only mitigations are:** adversarial review by people outside the design team (who hold different assumptions); the canary suite (which encodes *known* failure modes and so cannot encode unassumed ones); **and the real-world anchor (P0-01 INV-43), which is the only mechanism in the entire architecture that can violate a shared assumption by simply being different from the simulation.** ⟵ **This is a second, independent justification for R18.1/INV-43, and it is stronger than the fidelity-measurement justification: the real-world suite exists not only to measure `sim_fidelity` but to be the thing that is not built from our assumptions.**

**IND-9 — shared governance.** All principals are funded by one budget, reviewed by one committee, staffed from one team, and succeed or fail together. **Then "independent" principals have a shared interest in agreeing.**
- **Detectable only partially**: org charts are inspectable; incentive alignment is not.
- **Mitigations:** disjointness requirements (R23.2, EIK-INV-47) — but note **`[S]`, not machine-enforceable**; W5 witness outside operational control; **and the honest recognition that a project which cannot organizationally separate its principals cannot achieve Model D, and should not claim to.**

**R35.1 (THE INDEPENDENCE DECLARATION REQUIREMENT).** Every claim of independence in a V4 artifact MUST name **which of IND-1…IND-9 hold, and which do not.** «Three independent evaluators» is a false-precision statement (§34). «Three evaluators independent in code (IND-1), data (IND-2), and generator (IND-7), sharing a hardware class (IND-5 ✗), a statistical model family (IND-4 ✗), and a design lineage (IND-3 ✗), with latent-assumption independence unassessed (IND-6 ?)» is a checkable one — **and it makes the residual correlation visible to whoever relies on it.**

**R35.2.** **Correlated failure, not independent compromise, is the realistic catastrophic mode.** §29's G26 and G27 and §25's CD-E7 all fail through correlation. **An architecture optimized against independent compromise while ignoring correlated failure is optimized against the wrong adversary.** §57 OR-4 records independence maintenance as an open problem.

---

# §36. HARDWARE ROOT OF TRUST

## 36.1 The seven placement options

| Option | What it provides | **What it does NOT provide** | Cost | Verdict for V4 |
|---|---|---|---|---|
| **Ordinary software process** | Nothing. Same substrate, same privilege domain as the organism | Any separation at all | Zero | ❌ **This is audit F4** |
| **Isolated process (separate address space, distinct user)** | Protection from accidental interference; **not** from a privileged adversary | Protection against root-level organism code; attestation; tamper evidence | Low | ⚠️ Necessary floor for GP services; **insufficient for KC** |
| **Isolated VM / container** | Stronger isolation; resource accounting at the hypervisor | **The hypervisor is now in the TCB and is a large, complex, vendor-supplied component.** VM escapes are a real and recurring class. **And the VM's integrity is attested by... the hypervisor** | Medium | ✅ **ADOPTED for GP services and for KC-2's execution environment** — with the hypervisor explicitly named as a TCB extension (§3.1's honest residue) |
| **Secure enclave (TEE)** | Hardware-isolated execution; memory encryption; **remote attestation** — the ability for an external party to verify *which code is running* | **Side channels (a demonstrated, recurring, and vendor-acknowledged failure class). Attestation verifies the CODE IDENTITY, not the code's CORRECTNESS (§38). Small secure memory. Vendor-controlled attestation roots. Performance cost on every enclave transition** | High | ✅ **ADOPTED for exactly two things (§36.2)** |
| **Hardware root of trust (TPM/HSM-class)** | Key custody with non-extractability; measured boot; a hardware identity | **It is a key custodian and a measurer, not a reasoner.** It can tell you the boot chain matched; it cannot tell you the policy is right. Firmware is vendor code in the TCB. Physical attacks. Supply-chain compromise | High | ✅ **ADOPTED for root-key custody (§10.4)** |
| **Physically separate machine** | Air-gap-equivalent separation; distinct failure domain; distinct IND-5 hardware independence | **Latency; a second thing to operate, patch, and secure; and it does not by itself make the machine's software correct** | High | ✅ **ADOPTED for: the external attestor (CD-E7's mitigation), the W5 anchor witness, and the offline root-key custodian set** |
| **Separate network** | No reachable channel from the organism | Availability coupling; the channel that does exist becomes the attack surface | Medium | ✅ **ADOPTED for the OP interface and the anchor's external witness** |
| **External evaluator (human/third-party)** | **IND-9 governance independence; IND-6 latent-assumption independence** — the two forms §35.4 says engineering cannot achieve | Attention limits; latency; social shapeability (§9.4 B8); cost | Very high | ✅ **REQUIRED** — P0-01's β₅ real-world suite and OP authority are the only sources of IND-6/IND-9 in the architecture |

## 36.2 The two (and only two) hardware commitments

> **§2.4 concluded that hardware trust is a scarce resource and must be spent only where nothing else works. Exactly two places qualify:**

```
HW-1  KC-3 SUBSTRATE CEILING ENFORCEMENT
      Requires: enforcement below any layer organism software can reach,
                available during partition, and non-bypassable even by
                host-privileged code.
      Why nothing else works: **software metering runs on the metered
      substrate.** Any in-software ceiling can be bypassed by code that
      runs above the metering layer. EIK-INV-30/31 require substrate-origin
      telemetry and partition-local enforcement, and both are hardware
      properties.

HW-2  CONSTITUTIONAL ROOT-KEY CUSTODY
      Requires: a key that cannot be extracted by software, including by
      software running as root on the host, and whose use is rate-limited
      and physically witnessed where feasible.
      Why nothing else works: **a key extractable by software is not a root**
      (§2.5, §10.4). Since the root key signs policy transitions, delegation
      roots, and freeze commands — and nothing else (§10.4 item 1) — the
      custody requirement applies to a very small number of operations, so
      the performance cost of hardware custody is irrelevant.
```

**Everything else is software**, placed in isolated VMs or separate machines as the table indicates, and **the TCB is correspondingly honest about what it assumes** (§3.1's residue: the hypervisor, the firmware, the vendor attestation root).

## 36.3 «Hardware trust does not automatically solve software governance» — the four reasons

| # | Reason | Consequence |
|---|---|---|
| **1** | **Attestation verifies identity, not correctness.** A TEE attests *which code is running*. If that code faithfully implements a wrong specification (§38, G30), the attestation confirms that the system is reliably doing the wrong thing | **Hardware trust amplifies specification errors rather than catching them.** A perfectly attested kernel enforcing a harmful policy is more dangerous than an unattested one, because the attestation suppresses doubt |
| **2** | **The hardware is a TCB you did not write and cannot verify.** Firmware, microcode, vendor attestation roots, and silicon errata are all trusted, and their correctness is *assumed* (§3.1's residue, §57 OR-3) | **Trust is relocated to a vendor, not eliminated.** And vendor decisions are made for reasons unrelated to this project — a firmware update, a product discontinuation, or a disclosed vulnerability can invalidate the trust basis without any act by this system |
| **3** | **Side channels are a demonstrated, recurring failure class.** Enclaves have been attacked through cache timing, speculative execution, power analysis, and memory-access patterns. **Each disclosure has retroactively invalidated a class of "hardware-secure" claims** | Any architecture whose *only* defence is enclave isolation has one defence, and it is empirically breakable. **This is why HW-1 and HW-2 are backed by software mechanisms (M-1 counters, W_min witnesses, M-of-N custody) rather than relying on hardware alone** |
| **4** | **Hardware solves the *where*, never the *what*.** It answers «where is enforcement located» and «who holds the key». It says nothing about «is this the right policy», «is this measurement correct», or «is this capability dangerous» — which are the questions §17, §38, and §40 are actually about | **The governance problem is not a placement problem.** §36's whole conclusion is that hardware is necessary for two narrow functions and irrelevant to the hard questions |

**R36.1.** **Hardware commitments are made only where a software mechanism is provably insufficient** (HW-1: substrate bypass; HW-2: key extraction), **and every hardware commitment explicitly names the vendor assumption it introduces into the TCB.** An unstated hardware assumption is an unstated TCB member, and §34's «trusted» definition makes that a false-precision defect.

---

# §37. HUMAN / EXTERNAL OVERSIGHT

## 37.1 Does the architecture require a human or external authority?

> ### **Yes — necessarily, at four specific points, and the necessity is provable rather than conventional.**

**The proof is §25.2's unclosable cycles plus §23.4's regress:**

```
1. CD-E6 / CD-E8 / U8 : the governance cycle terminates in a human reader.
   No internal mechanism closes it, because closing it would require an
   internal authority over constitutional change — which is the
   self-reference the package exists to prevent (EIK-INV-02).

2. §23.4's regress    : any auditor of the top authority is either another
   instance of the same problem or a human. There is no third option.

3. P0-01 §42.1 Level 3 : whether the constitution produced anything useful
   is settled only by real-world outcomes, and interpreting real-world
   outcomes for a stakeholder set is a value judgement (§59.1 L2(d):
   "usefulness is stakeholder-relative and the stakeholder set is an OP
   choice, not a measurement").

4. §17.5 / §40        : classifying an unknown capability as beneficial or
   dangerous is not a measurement. Blast radius is measurable (M-α);
   WORTH is not.

⟹ A fully automated governance system would have to close all four.
   Closing 1 requires self-authority. Closing 2 requires an infinite regress.
   Closing 3 requires a value judgement to be a measurement.
   Closing 4 requires an unknown to be classified by content.
   **None is possible. Therefore human/external authority is not a design
   preference; it is a consequence of the architecture's own definitions.**
```

## 37.2 Where, when, and with what authority

| # | Point | Circumstance | Authority | Automatable? | **What happens when unavailable** |
|---|---|---|---|---|---|
| **H-1** | **Constitutional change** (RO-13, RO-14) | Adding/removing/altering a tier-1 constraint or an invariant | **Decisive.** Dual authorization, separation of duties, root-key signature | ❌ **Never** | **No change occurs.** The existing constitution continues. **This is fail-safe: unavailability blocks change, and change is the dangerous direction** |
| **H-2** | **Policy change** (RO-12) and clause re-affirmation (§15.3 V4) | Sampling β shares, evaluation-depth mapping, quarantine budget, envelope bounds, epoch cadence, rung criteria | **Decisive** | ❌ | **Clauses EXPIRE on `review_by` (EIK-INV-51) and expiry DENIES (R13.2).** ⟵ **This is the one place where human unavailability degrades the system toward restriction, and it is deliberate: an unreviewed permission lapses.** **But see §29 G32: mass expiry is a liveness failure, and `T-08` must be set so that ordinary attention suffices** |
| **H-3** | **Deployment witness** (RO-10, Stages ≥ 4) and **capability rung ≥ 4** | Anything entering production or acquiring external, potentially irreversible effect | **Decisive** (R7.5) | ❌ | **Deployment does not advance** (§13: `FC` absolute). Sandboxed and evaluator-only operation continues |
| **H-4** | **Adjudication** | DISPUTED evaluations (R8.9) · evaluator disagreement · `T_quar_max` expiry · quarantine-budget exhaustion · rollback cost above `θ_rollback_cost` (RB-2) · KC HALTED recovery acceptance · ROOT_COMPROMISED declaration (M-of-N custodians) · specification-change authorization (EIK-INV-59) | **Decisive** | ❌ | **The affected scope stays suspended.** Subjects are retained (P0-01 §47); nothing is destroyed; observation continues (EIK-INV-53) |

**R37.1 (THE UNAVAILABILITY PRINCIPLE).** **In all four cases, human unavailability causes the system to become MORE restrictive, never less.** This is EIK-INV-17 applied to governance: uncertainty is never permission. **An architecture in which human absence loosens constraints has made humans a safety mechanism whose failure is fail-open — which is the one property a safety mechanism must not have.**

**R37.2 (WHAT IS *NOT* HUMAN-GATED — and this is most of the system).** Firing, predicting, learning within bounds, connecting within envelope, differentiating, forming circuits, allocating within ceilings, quarantining within budget, self-monitoring, reporting, requesting, proposing, sandbox-exercising an unregistered capability, and all internal evaluation below Stage 4. **⟵ The human is required for governance and for irreversibility, not for operation.** *An architecture that requires a human per operation is not governed, it is manually operated — and §27.1 shows it does not scale.*

## 37.3 «Do not assume human oversight is always available» — the four consequences

| Consequence | Mechanism |
|---|---|
| **1. The system must be safe indefinitely without a human.** | §12's degradation ladder is time-driven and non-discretionary (EIK-INV-52) and terminates in State 4 FREEZE — **a stable, safe, observable state that persists indefinitely without human action.** The organism does not require a human to be present in order to be contained |
| **2. The system must not accumulate un-adjudicated decisions.** | Every `ES` escalation is queued, epoch-stamped, and retained (§12.2's «queued, not dropped»). **The queue length and age distribution are I-18 observables** — so an unattended system's governance debt is *visible* even when it is not being paid |
| **3. Attention is a scarce resource and must be rationed by design.** | **This is the architectural consequence and it is rarely stated:** every `ES` path consumes H-1…H-4 attention. A design with many escalation paths has a governance throughput ceiling (§15.3 R15.3, U-08). ⟹ **Escalation thresholds are `[G]` parameters that must be set against measured human capacity, and a rising escalation rate is a design defect signal, not merely an operational one** |
| **4. The human channel is an attack surface (§9.4 B8/B9, G24, CD-E8).** | Origin labelling (EIK-INV-56); non-filtering (EIK-INV-09); OP independent information sources; monitoring the rate of organism-originated policy change (R23.3). **These bound the channel. §57 OR-5: they do not close it** |

## 37.4 If the answer were «no» — how would governance remain non-self-referential?

**The brief asks this conditionally. It cannot be answered affirmatively, and the reason is worth stating precisely:**

> Non-self-reference requires that the authority defining "correct" is not reachable from the system being judged. Within a closed system, every candidate authority is either (a) a component of the system — reachable, therefore self-referential; (b) derived from the system's own outputs — P0-01's prohibited L7, therefore self-referential; or (c) external — therefore a human, an environment, or another system, and "another system" merely relocates the question to that system's own external authority. **(a) and (b) fail; (c) terminates outside the system.** There is no fourth option, and this is a structural fact about judgement rather than a limitation of this design.
>
> **The environment (ℛ) is a partial substitute** — it is external, non-self-referential, and requires no human. P0-01's INV-43 makes it load-bearing. **But ℛ can arbitrate usefulness (L2) and cannot arbitrate permission (deontic).** Reality will tell you whether the organism worked; it will not tell you whether the organism was allowed to do what it did. **Deontic authority requires an author, and an author is either the system (self-reference) or not the system (external, therefore social).**

---

# §38. EIK SPECIFICATION ATTACK

## 38.1 «What if the EIK specification is wrong?»

**The four-way distinction the brief requires — and it is the most important epistemic structure in this section:**

```
(1) IMPLEMENTATION CORRECTNESS
    Does the artifact do what the specification says?
    ⟹ **VERIFIABLE.** Exhaustive testing at §6.2 R6.2's enumeration size;
       model checking; formal proof for KC-1's signature logic.
       This is the ONLY one of the four that formal methods can discharge.

(2) SPECIFICATION CORRECTNESS
    Does the specification say the right thing?
    ⟹ **NOT VERIFIABLE FROM INSIDE THE SPECIFICATION.** A specification
       cannot validate itself; the validator would need a criterion outside
       the spec, which is what "the spec is wrong" means.
       Detected only by: (1)(2) divergence in outcomes, adversarial review,
       canary suites, ablation (P0-01 §58 applied to policy), and INCIDENTS.

(3) ENVIRONMENTAL CORRECTNESS
    Does the specification's model of ℰ match ℰ?
    ⟹ P0-01's G1 specification gap and `sim_fidelity`. **Measurable, at cost,
       with confidence intervals.** Requires INV-43's real-world anchor.

(4) REAL-WORLD USEFULNESS
    Does a correct specification, correctly implemented, in a correctly
    modelled environment, produce anything worth having?
    ⟹ **P0-01 §59.1's L2. Measurable, expensive, delayed, stakeholder-
       relative. Never guaranteed.**

**THE CHAIN IS (1) ⟸ (2) ⟸ (3) ⟸ (4) in dependency, and each arrow is a
place where correctness can be lost. Formal verification operates ONLY on
the first.**
```

**R38.1 (THE PROHIBITED INFERENCE, per the brief).** **«Formal verification proves the implementation follows the specification; it cannot establish that the specification is correct, morally or practically.»** Any V4 artifact asserting that a model-checked KC is "safe" commits the false-precision error §34 identifies for «safe» and «verified». **A model-checked KC is a KC that reliably does what was specified — including, reliably, the wrong thing.**

## 38.2 The seven specification defects the brief lists, plus three

| # | Defect | Example | Detection | Response | **Residual** |
|---|---|---|---|---|---|
| **S1** | **Unsafe invariant omitted** | Nothing forbids a subject from inducing its own restoration from a checkpoint taken before quarantine | Adversarial review; incident; §29 scenario authoring | RO-13 constitutional change; **the failure archive → constraint pathway (P0-01 §31.4) is the only route, and it requires OP** | **HIGH, irreducible.** §9.4 B14: an invariant never thought of cannot be enforced. **This is §17's unknown-unknowns at the policy layer** |
| **S2** | **Safe behaviour accidentally forbidden** | An envelope so tight that legitimate regional reallocation always denies | **The false-deny rate (R10.2)** — which is precisely why R10.2 makes it a monitored metric rather than a nuisance | Envelope recalibration (§15.3 V2) as a governed RO-12 change against measurements | **MEDIUM.** R10.2's warning: the pressure to loosen is constant and legitimate-feeling, and loosening is the dangerous direction |
| **S3** | **Evaluator trust assumption incorrect** | Assuming `n_eval ≥ 3` gives independence when all three share IND-6 assumptions | **§35.1's R35.1 declaration requirement** — naming which IND forms hold makes the gap visible | Restate the claim honestly; add a genuinely independent evaluator or withdraw the reliance | **HIGH for IND-6** (§35.4: not engineerable) |
| **S4** | **Capability taxonomy incomplete** | The 8 effect dimensions (P-01) miss a dimension along which harm propagates | §17.3 clause 2's regress; incidents | RO-13 to extend the dimension set — **which requires having thought of the dimension** | **HIGH, irreducible. U-02** |
| **S5** | **Provenance model flawed** | The epoch lie-window (§20.4) is longer than assumed, so a consequential decision rested on unanchored data | **R20.1's requirement is checkable**: assert every consequential decision reaches an anchored root | Tighten the epoch; extend R20.1's scope | **MEDIUM** |
| **S6** | **Governance transition flawed** | A change class exists whose transition is neither ADDITIVE nor RESTRICTIVE nor SEMANTIC, so it is misclassified and the wrong migration applies | §31.2's VALIDATING state checks class consistency; **a class that does not fit is a specification gap** | Add the class (RO-14); re-adjudicate affected transitions | **MEDIUM** |
| **S7** | **Resource accounting wrong** | A resource dimension is metered in units that permit X7's granularity attack | §18.3's defences; R-02's multi-window requirement | Re-specify the meter | **MEDIUM** |
| **S8** ⭐ | **Reserved-operation set incomplete** | A consequential operation is not in the 15 (§7.2), so it is unreserved and ungoverned | **This is S1's specific and most likely form.** Detection: any operation with irreversible or external effect that lacks a token requirement | RO-13 to add it — **which enlarges the TCB (§6.2 R6.2's enumeration domain), so there is a real cost and a real tension with minimality** | **HIGH. And note the tension: minimality (§6) and completeness of the reserved set pull in opposite directions. §33.3 shows minimality wins on the evidence, but the reserved set must be reviewed whenever a new irreversible mechanism is added** |
| **S9** ⭐ | **Degradation-ladder flaw** | A state in §12.2 permits something it should not | Exhaustive review of the state×operation matrix (§13.2) | Correct the matrix; **the matrix is small enough to review exhaustively, which is a payoff of §13's discipline** | **LOW-MEDIUM — this is the most reviewable defect class in the list** |
| **S10** ⭐ | **Authority-matrix ambiguity** | Two principals both believe they authorize an operation (R7.1's warning) | **R7.1 requires exactly one state per cell — so ambiguity is mechanically detectable** | Correct the matrix | **LOW — and it is low *because* the matrix was required to be unambiguous** |

## 38.3 The specification-attack defence, and its limit

```
DEFENCES:
  D-S1  Machine-readable policy with declared semantics (§9.4 B12)
        ⟹ reduces natural-language ambiguity. **Does not eliminate it: the
           formalism's own semantics become the new ambiguity surface**
  D-S2  Adversarial specification review by principals outside the design
        team (IND-6's only mitigation)
  D-S3  Canary suites at the POLICY level, not only the evaluator level
        ⟹ known-bad scenarios that the policy must refuse. **§29's 34
           scenarios are the initial policy canary suite**
  D-S4  Ablation of policy mechanisms (P0-01 §58's method applied to
        governance): remove a clause, confirm the predicted failure occurs.
        **A clause whose removal causes no failure is a clause to delete
           (Rule 17)**
  D-S5  The failure-archive → constraint-improvement pathway (P0-01 §31.4),
        which is how S1-class defects get closed after they cause an incident
  D-S6  Sunset-by-default (§15.3 V4), which forces periodic re-examination
        of every clause and therefore periodic re-examination of the
        specification
  D-S7  EIK-INV-59: specification changes are governance acts with lineage,
        so a specification defect's history is reconstructible

LIMIT:
  **D-S1…D-S7 all improve the RATE at which specification defects are found.
   None establishes the ABSENCE of defects.** S1, S4, and S8 are
   unknown-unknowns at the specification layer, and §17.3's argument applies
   verbatim: you cannot enumerate what you have not conceived.

⟹ **The correct claim is: the specification is falsifiable, reviewable,
   versioned, ablatable, and improvable through a governed pathway.
   The incorrect claim is: the specification is correct.**
   §57 OR-2 records the distinction as an open problem.
```

---

# §39. EVOLUTION COMPATIBILITY

## 39.1 The ten evolutionary mechanisms, tested against the reserved-operation set

**The brief's requirement: «The EIK must not accidentally destroy the core thesis of the Digital Brain.»** Each mechanism is tested: is it a reserved operation (governed per-request), an envelope-bounded operation (pre-authorized), or unreserved (free)?

| Mechanism | Reserved? | Governance burden | **Compatible with evolution?** |
|---|---|---|---|
| **Mutation** | **RO-02, but only the operator-set/bounds check** — and within a closed authenticated operator set the check is `O(1)` local against a cached policy | **Low.** Variation within the operator set does not require a KC round-trip; the operator set is cached and locally verifiable (Alt D) | ✅ **YES** |
| **Recombination** | Under RO-02/RO-03 | Low — same mechanism as mutation | ✅ **YES** |
| **Differentiation / specialization** | **NOT reserved** | **None.** Variant class is fixed at instantiation (Cell Contract: «changeable only by re-instantiation»), and re-instantiation is RO-01 — but differentiation *within* a class is free | ✅ **YES** |
| **Specialization** | **NOT reserved** | **None.** Regional specialization constraints (§28.2) are policy, locally enforced | ✅ **YES** |
| **Emergent circuits** | **Circuit REGISTRATION is a composition checkpoint (§4.4 M-2, P-05)** — not a reserved operation, but a check point | **Low-Medium.** Formation is free; registration triggers a composition check. **This is the one place where governance touches emergence directly** | ⚠️ **YES, with a caveat — see §39.2** |
| **Region formation** | **Reserved-adjacent** (a region is a governance scope, so its formation changes the delegation structure) | **Medium.** Regional formation requires delegation-certificate issuance | ⚠️ **YES, with latency** |
| **Pruning** | **RO-04** — and requires CAUSAL ablation evidence (P0-01 §23.2) plus the sole-occupant exemption (INV-34) | **Medium-High.** Pruning is expensive to authorize *because it is destructive and irreversible* | ✅ **YES — and the burden is correct.** P0-01 §37's rare-specialist protection depends on it |
| **Replication** | **RO-03** — quota-checked, gate-checked, rollback-cost-recorded (RB-2) | **Medium.** Rate-limited by RB-1; serialized at ROOT for lineage-scoped counters (§26.5) | ⚠️ **YES, but this is the genuine throttle — §39.3** |
| **Adaptation (learning)** | **NOT reserved** | **None.** Learning within `DELTA_BUDGET`, rate limits, and rollback tags is entirely organism-local (Cell Contract §9). **P0-01 R22.2 restricts what learning may *drive*, not whether it may occur** | ✅ **YES — completely free** |
| **Novel architectures** | **NOT reserved within the operator set; RESERVED if a new operator or a new capability class is required (RO-13)** | **Bimodal: free within the vocabulary, governed to extend the vocabulary** | ⚠️ **YES within the operator set — and §39.4 addresses the boundary** |

**Result: 6 of 10 mechanisms are unreserved or locally-verifiable. 3 carry moderate burden where the burden is justified by irreversibility or scope change. 1 (replication) is a genuine throttle.**

## 39.2 The one restriction that could damage emergence — and its resolution

> **Composition checkpoints (M-2, P-05) are the only place where governance directly touches emergence, and §25.2's CD-E5 shows the cycle: evolution produces structure → structure is checked → the check gates further evolution.**

**The risk:** if circuit registration is expensive or slow, selection favours organisms that **avoid forming registerable circuits** — which is precisely the anti-emergence outcome the brief warns about. **A governance checkpoint on emergence selects against emergence.**

**The resolution — three parts:**

```
1. REGISTRATION IS CHEAP AND LOCAL. Circuit registration is a composition
   CHECKPOINT (an aggregate digest submitted at the epoch boundary, §20.3's
   O(R)-per-epoch pattern), NOT a per-formation KC round-trip. **Forming a
   circuit does not require authorization; registering it does, and
   registration is batched.**

2. UNREGISTERED COMPOSITIONS ARE PERMITTED AND MEASURED, NOT FORBIDDEN.
   A circuit that has not registered is not illegal — it is UNMEASURED, and
   per §17.4 M-β it defaults to sandbox-scope consequences rather than to
   prohibition. **⟵ This is critical: making unregistered composition
   illegal would select against composition. Making it merely unmeasured
   selects for nothing and permits everything within envelope.**

3. THE CHECKPOINT'S PURPOSE IS MEASUREMENT, NOT PERMISSION. M-2 exists so
   that D-D superadditive-effect detection (§16.4) has a place to run. It is
   an alethetic instrument with a deontic consequence only on discovery.
   **A checkpoint that denies by default is a checkpoint that suppresses
   emergence; a checkpoint that measures by default and denies on evidence
   is not.**
```

**R39.1.** **Composition checkpoints MUST default to permit-and-measure, never to deny-pending-review.** This is EIK-INV-35's default-sandbox principle applied to structure rather than to capability, and it is the specific mechanism that keeps §4.4's I19 mitigation from becoming an anti-emergence gate.

## 39.3 The genuine throttle: replication

**§26.5 established that lineage-scoped replication counters serialize at ROOT for irreversible-class operations, and RB-1/RB-2/RB-5 bound the rate.** The consequence is honest and must be stated:

> **KC-2 is a real throughput limit on replication, and therefore on evolutionary rate.** This is SPOF-5, and it is not eliminated by minimality — it is *reduced* to one operation class.

**Three mitigations, none of which removes the throttle:**

| Mitigation | Mechanism | Cost |
|---|---|---|
| **Batch authorization** | A single authorization may cover a bounded replication batch within a lineage, subject to the batch's aggregate rollback cost (RB-2) | Coarser control; a batch is authorized before its members' individual outcomes are known |
| **Island-model autonomy** (§26.5) | **Island-internal variation is NOT a reserved operation.** Only migration between islands and lineage-quota-consuming replication are. The Cell Contract's island-model evolution is therefore *mostly* KC-free | Cross-island capability transfer is throttled |
| **Pre-authorized replication envelopes** | A lineage in good standing (no failures, established fitness, low concentration) holds a standing replication envelope within which replication is pre-authorized, with KC-2 veto retroactively binding (§44's negative authority) | **Envelope width is exposure** — and G33's creep applies |

**R39.2.** **The replication throttle is a deliberate cost of governance, and it should be measured rather than hidden.** The metrics are: replication authorization latency, denial rate, and the resulting generation time. **A generation time set by governance rather than by biology is a project-level fact that belongs in every progress claim** — because it determines how much evolution the project can actually do, and §15.3 R15.3's governance throughput ceiling applies here too.

## 39.4 The boundary: novel architectures and the operator set

**R15.2's closed operator set is the strongest anti-self-modification mechanism in the inherited design and it survives unchanged.** But it creates a boundary condition:

```
WITHIN the operator set   : variation is free, local, cheap, ungoverned
                            per-request. **Evolution operates at full speed.**
TO EXTEND the operator set: RO-13 constitutional change, dual OP authorization,
                            EVA impact analysis, root signature, M6 lineage.

⟹ **The organism can explore the space the vocabulary defines, and cannot
   redefine the vocabulary.**
```

**Is this «artificially constrained»? The honest answer has two parts:**

1. **Yes, in a specific and measurable sense.** The reachable phenotype space is the closure of the operator set. Any architecture expressible only with an operator not in the set is unreachable, forever, unless a human adds it. **The organism's evolutionary horizon is the vocabulary's expressive closure, and that closure was chosen by designers.**

2. **And this is the correct trade, for a reason that is not merely cautious.** An open operator set means the organism can introduce *new kinds of structural change*, which means the space of what governance must reason about is not fixed, which means §38's S8 (incomplete reserved-operation set) becomes unbounded, which means **the TCB's enumeration domain (§6.2 R6.2) is unbounded, which means EIK-INV-11/12 become unverifiable.** *A closed operator set is what makes the kernel verifiable, and a verifiable kernel is what makes the whole assurance argument non-vacuous.*

**R39.3 (THE VOCABULARY-GROWTH PATHWAY).** Because the closure is a real constraint, the operator set MUST be growable, and the growth pathway MUST be exercised rather than theoretical: **an organism that hits the vocabulary boundary emits a `POLICY_FRICTION_REPORT` (§15.3 V1) with the *effect* it was trying to achieve, EVA measures whether the effect is within an acceptable envelope, and OP may add an operator.** ⟹ **The vocabulary grows by human decision informed by measured effect — which is §17.4 M-α applied to the mutation vocabulary rather than to capabilities.** *A vocabulary that cannot grow produces §23.1's dead ends; a vocabulary the organism can grow produces self-reference.*

## 39.5 The evolution-compatibility verdict

> ### **The minimal KC is compatible with every mechanism the Digital Brain's thesis requires.** Six of ten are unreserved or locally verifiable; three carry burden justified by irreversibility; one (replication) is a genuine, measured throttle with three mitigations.
>
> **The god kernel would NOT have been compatible.** §33.3's ablation shows it produces SPOF-5 (evolution bottleneck) at ❌, because every one of its nineteen authorities is a veto point in some organism's hot path — including per-cell seed issuance, per-cell integrity verification, and per-adjustment homeostatic approval, which touch *every* operation rather than 15.
>
> **⟹ Minimality is not only a security and scalability property. It is an evolution-compatibility property, and §33.3 shows it is the *decisive* one: the god kernel's fatal flaw for this project is not that it is insecure, it is that it makes the project's central mechanism slow.**

---

# §40. THE GOVERNANCE PARADOX

## 40.1 The paradox, stated exactly

```
PREMISE 1  The brain is supposed to evolve capabilities that its designers
           did not explicitly program.
           ⟵ This is the project's thesis. Remove it and there is no reason
              for an evolutionary architecture; a hand-designed system would
              be simpler, cheaper, and more predictable.

PREMISE 2  The EIK is supposed to prevent dangerous capability changes that
           designers did not explicitly anticipate.
           ⟵ This is the safety requirement. Remove it and audit F4 stands:
              a system that can modify its own constraints has no constraints.

THE CONTRADICTION
  Premise 1 requires the system to produce the UNANTICIPATED.
  Premise 2 requires the governance to handle the UNANTICIPATED.
  **Handling the unanticipated requires a criterion for it. A criterion is a
   classification. Classification requires a category. Categories are
   anticipated.**

  ⟹ Either the governance has categories for the unanticipated (contradiction)
    or it does not (Premise 2 fails).

THE QUESTION
  How can the architecture distinguish **unknown-but-beneficial** from
  **unknown-and-dangerous** without a complete predefined list of future
  capabilities?
```

## 40.2 Why the question as posed has no answer

> ### **It cannot be answered, and the reason is that «beneficial» and «dangerous» are not properties of a capability. They are properties of a capability-in-a-context-relative-to-a-value.**

```
"Is capability X dangerous?" is not well-formed, because:

  1. DANGER IS RELATIVE TO WHAT IS VALUED, and value is an OP/stakeholder
     judgement (P0-01 §59.1 L2(d): usefulness is stakeholder-relative and
     the stakeholder set is a choice, not a measurement). **Two stakeholder
     sets give opposite answers for the same capability.**

  2. DANGER IS RELATIVE TO SCALE AND CONTEXT. A capability harmless at 10³
     subjects with bounded reach may be catastrophic at 10¹² with external
     actuators. **The capability did not change; the envelope did.**

  3. DANGER IS OFTEN RELATIVE TO COMPOSITION (§4.4 I19, G23). Individually
     benign capabilities compose into harmful ones, and the harm is a
     property of the composition, not of any member.

  4. **AND DECISIVELY: X IS UNKNOWN.** By hypothesis. So the question asks
     for a classification of something whose classification-relevant
     properties cannot be inspected.

⟹ **Any architecture that claims to distinguish unknown-but-beneficial from
   unknown-and-dangerous is claiming to classify an unclassified thing by its
   unobservable properties. §17.3 makes the same argument for detection;
   this is its axiological version.**
```

## 40.3 The dissolution — change the question

> ### **The paradox dissolves when the governed quantity is changed from *capability identity* to *consequence envelope*. This is §17.4 M-α, and it is the central research contribution of this package.**

```
THE UNANSWERABLE QUESTION:
   "Is this unknown capability dangerous?"
   Requires: knowing what it is, knowing what it will be used for, knowing
             what is valued. **None is available.**

THE ANSWERABLE QUESTION:
   "If this unknown capability is dangerous, how much harm can it do before
    we notice and stop it?"
   Requires: reach, rate, reversibility, externality, persistence.
   **All five are measurable WITHOUT knowing what the capability is.**
```

**Why this works, precisely:**

| Property of the substitution | Explanation |
|---|---|
| **It is measurable for unknowns** | §16.2 Step 1's dimensions were chosen to bound *consequence*, not to describe *function* (R17.2). A functional taxonomy requires knowing the function; a consequence taxonomy does not |
| **It is monotone in harm** | Bounding reach × rate × irreversibility × externality bounds the *maximum* harm, whatever the capability. **A harmful capability inside a small envelope is a small harm** |
| **It does not require anticipation** | Nothing about the future capability list is needed. The envelope is measured on the capability that actually appears |
| **It preserves Premise 1** | The unanticipated is *permitted* — at sandbox scope (M-β, EIK-INV-35), then at evaluator scope, then at restricted scope, **as measurement accumulates**. **Novelty is not forbidden; it is enfranchised gradually against evidence** |
| **It preserves Premise 2** | The dangerous is *bounded* — not by being recognized as dangerous, but by being unable to exceed its envelope before descent (EIK-INV-38: descent is immediate and requires no measurement) |
| **It fails safely** | An unknown capability whose envelope cannot be measured is treated as maximal (EIK-INV-17: uncertainty is never permission) ⇒ rung 0–2 ⇒ sandbox or forbidden. **The default is confinement, and confinement does not require classification** |

## 40.4 What the dissolution does NOT achieve — the honest residue

| Not achieved | Why | Consequence |
|---|---|---|
| **Valuation of the unknown** | Whether an enfranchised capability is *worth* its risk remains an OP judgement (§37.1 point 4). Blast radius is measurable; worth is not | **H-3's deployment witness is irreducibly human, and §57 OR-5 records it** |
| **Detection of envelope-irrelevant harm** | A capability whose harm is *not* in any of the 8 measured dimensions is not envelope-bounded. §17.3 clause 2's regress applies to the dimension set itself | **U-02, §17.5 item 2. Irreducible** |
| **Slow sub-envelope accumulation** | An envelope bounds *rate*, and unbounded time (A1) means any rate eventually reaches any total. §9.4 B3, G33 | **M-δ's re-measurement at scale and the frozen Track A drift baseline detect the aggregate; they do not prevent it** |
| **Composition across envelopes** | Two capabilities each within envelope may compose outside it (G23, I19) | **§4.4 R4.2's open problem. M-2 checkpoints and D-D superadditivity detection bound it probabilistically** |
| **A perfect predefined list** | **Explicitly not attempted, and the brief forbids claiming it** | **§17.4 M-ε: `UNREGISTERED` is a permanent legitimate class. The registry is a lower bound** |

## 40.5 The paradox's final statement

> ### **The governance paradox has no solution. It has a dissolution, and the dissolution has a residue.**
>
> **The dissolution:** govern the consequence envelope, not the capability identity. Permit the unanticipated at confined scope; enfranchise it against measurement; bound its blast radius structurally; descend immediately on evidence. **This satisfies Premise 1 (the unanticipated is permitted) and Premise 2 (the dangerous is bounded) simultaneously, without a predefined capability list, because neither permission nor bounding requires knowing what the capability is.**
>
> **The residue:** valuation of the unknown is human (§37); harm outside the measured dimensions is invisible (§17.5); accumulation over unbounded time exceeds any rate bound (§9.4 B3); composition across envelopes escapes per-request governance (§4.4); **and the dimension set that makes all of this work is itself a finite, designer-chosen vocabulary with its own unknown unknowns (§17.3 clause 2).**
>
> **This is a research problem, and §57 OR-1 and OR-6 record it as one. What the architecture contributes is not a solution but a *reduction*: it converts an unanswerable question («is this unknown capability dangerous?») into a measurable one («how much harm can it do before we stop it?») plus a small, named, irreducible residue. That reduction is the honest maximum, and claiming more would be exactly the false precision §34 exists to prevent.**

---

*End of Volume D. Continue to `15_analysis_subsystems_consistency.md` (Volume E: §41 EIK vs self-model · §42 vs global workspace · §43 vs immune · §44 vs homeostasis · §45 vs evolution · §46 vs task/environment · §47 vs memory · §48 vs self-repair · §49 performance cost · §50 architectural dependency graph · §51 cross-system consistency audit · §52 implementation-independence test · §53 testability · §54 ablation of EIK itself · §55 gap register).*
